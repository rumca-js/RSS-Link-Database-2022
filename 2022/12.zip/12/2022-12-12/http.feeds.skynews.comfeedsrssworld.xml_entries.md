# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Founder of bankrupt crypto firm FTX arrested in Bahamas
 - [https://news.sky.com/story/sam-bankman-fried-founder-of-bankrupt-crypto-firm-ftx-arrested-in-bahamas-12767138](https://news.sky.com/story/sam-bankman-fried-founder-of-bankrupt-crypto-firm-ftx-arrested-in-bahamas-12767138)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 23:39:00+00:00

Police in the Bahamas have arrested Sam Bankman-Fried, the founder of bankrupt crypto firm FTX.

## Man accused of making Lockerbie bomb appears in US court
 - [https://news.sky.com/story/lockerbie-disaster-man-accused-of-making-bomb-that-blew-up-pan-am-flight-103-appears-in-us-court-12767121](https://news.sky.com/story/lockerbie-disaster-man-accused-of-making-bomb-that-blew-up-pan-am-flight-103-appears-in-us-court-12767121)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 22:18:00+00:00

The man accused of making the bomb that brought down Pan Am flight 103 over the Scottish town of Lockerbie in 1988 has appeared in a US court.

## Two police officers killed 'execution-style' in ambush in rural Australia
 - [https://news.sky.com/story/two-police-officers-killed-execution-style-in-ambush-in-rural-australia-12767099](https://news.sky.com/story/two-police-officers-killed-execution-style-in-ambush-in-rural-australia-12767099)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 20:48:00+00:00

Three people have been killed by police at a property in rural Australia after a six-hour standoff that began with the "execution-style" shooting of two officers and a neighbour.

## 'Freedom comes at a price': Power outages and lack of water accompany liberation of Kherson
 - [https://news.sky.com/story/ukraine-war-freedom-comes-at-a-price-as-power-outages-and-lack-of-water-accompany-liberation-of-kherson-12767063](https://news.sky.com/story/ukraine-war-freedom-comes-at-a-price-as-power-outages-and-lack-of-water-accompany-liberation-of-kherson-12767063)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 18:56:00+00:00

The mother wept with relief as she cradled her newborn baby at the only maternity hospital still working in the Ukrainian city of Kherson.

## Freedom comes at a price as Russia switches from occupier to attacker of Kherson
 - [https://news.sky.com/story/ukraine-war-freedom-comes-at-a-price-as-russia-switches-from-occupier-to-attacker-of-kherson-12767063](https://news.sky.com/story/ukraine-war-freedom-comes-at-a-price-as-russia-switches-from-occupier-to-attacker-of-kherson-12767063)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 18:56:00+00:00

The mother wept with relief as she cradled her newborn baby at the only maternity hospital still working in the Ukrainian city of Kherson.

## 'They're afraid': Undeleted social media posts expose the extent of China's COVID protest crackdown
 - [https://news.sky.com/story/weibo-the-covid-19-posts-banned-by-one-of-chinas-biggest-social-media-platforms-12766970](https://news.sky.com/story/weibo-the-covid-19-posts-banned-by-one-of-chinas-biggest-social-media-platforms-12766970)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 15:44:00+00:00

Posts calling on people not to be intimidated by the Chinese authorities are among the slew of messages censored by one of country's biggest social media platforms.&#160;

## Russian arms dealer Viktor Bout joins pro-Kremlin political party after US prisoner swap deal
 - [https://news.sky.com/story/russian-arms-dealer-viktor-bout-joins-pro-kremlin-ldpr-party-after-returning-home-in-us-prisoner-swap-deal-for-wnba-star-brittney-griner-12766969](https://news.sky.com/story/russian-arms-dealer-viktor-bout-joins-pro-kremlin-ldpr-party-after-returning-home-in-us-prisoner-swap-deal-for-wnba-star-brittney-griner-12766969)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 15:38:00+00:00

Russian arms dealer Viktor Bout, who was recently freed in a prisoner swap for US basketball star Brittney Griner, has signed up to a far-right pro-Kremlin political party.

## Congolese farmers barred from own land for French oil giant's tree planting project
 - [https://news.sky.com/story/congolese-farmers-barred-from-own-land-for-tree-planting-project-by-french-oil-giant-total-energies-12766904](https://news.sky.com/story/congolese-farmers-barred-from-own-land-for-tree-planting-project-by-french-oil-giant-total-energies-12766904)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 13:31:00+00:00

Farmers living in the Republic of the Congo say that they have been barred from accessing their land so that the French oil giant Total Energies and the Congolese government can use it for a high-profile carbon offsetting project to plant 40 million trees in the next decade.

## Uber driver stabbed to death by passenger 'who woke up and decided he was going to kill someone'
 - [https://news.sky.com/story/uber-driver-stabbed-to-death-by-passenger-who-posted-video-of-victim-dying-on-facebook-police-say-12766838](https://news.sky.com/story/uber-driver-stabbed-to-death-by-passenger-who-posted-video-of-victim-dying-on-facebook-police-say-12766838)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 12:26:00+00:00

An Uber driver was stabbed to death by a passenger "who woke up and decided he was going to kill someone" and posted a video of his victim dying on Facebook, police said.

## How 'four-legged rehabilitators' are helping Ukrainian children traumatised by war
 - [https://news.sky.com/story/how-four-legged-rehabilitators-are-helping-ukrainian-children-traumatised-by-war-12766793](https://news.sky.com/story/how-four-legged-rehabilitators-are-helping-ukrainian-children-traumatised-by-war-12766793)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 11:40:00+00:00

Children in war-torn Ukraine are seeking comfort from trauma with the help of tail-wagging therapist Bice, an American pit bull terrier.

## North Korea 'ready' to test a nuclear weapon, claims South Korean PM
 - [https://news.sky.com/story/north-korea-ready-to-test-a-nuclear-weapon-claims-south-korean-pm-han-duck-soo-12766766](https://news.sky.com/story/north-korea-ready-to-test-a-nuclear-weapon-claims-south-korean-pm-han-duck-soo-12766766)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 11:10:00+00:00

North Korea is "ready" to test a nuclear weapon and will likely do so, the prime minister of South Korea has said.

## EU corruption scandal of 'utmost concern' after four charged over alleged bribes from Qatar, von der Leyen says
 - [https://news.sky.com/story/eu-corruption-scandal-of-utmost-concern-after-four-charged-over-alleged-bribes-from-qatar-von-der-leyen-says-12766660](https://news.sky.com/story/eu-corruption-scandal-of-utmost-concern-after-four-charged-over-alleged-bribes-from-qatar-von-der-leyen-says-12766660)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 09:54:00+00:00

The EU corruption scandal is of the "utmost concern" after investigators charged four people with allegedly receiving money and gifts from Qatar, European Commission President Ursula von der Leyen has said.

## 'I have nothing to hide': Man named in Farmgate scandal willing to testify over Ramaphosa buffalo deal
 - [https://news.sky.com/story/businessman-named-in-farmgate-scandal-willing-to-testify-over-buffalo-deal-with-president-ramaphosa-12766663](https://news.sky.com/story/businessman-named-in-farmgate-scandal-willing-to-testify-over-buffalo-deal-with-president-ramaphosa-12766663)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 09:52:00+00:00

The Sudanese businessman embroiled in the Farmgate scandal is currently cooperating with the South African authorities - and would be willing to testify in any legal proceedings.

## Three PMs, the death of a monarch, and war in Europe - 2022 in review
 - [https://news.sky.com/story/2022-in-review-three-prime-ministers-the-death-of-a-monarch-and-a-war-in-europe-12766654](https://news.sky.com/story/2022-in-review-three-prime-ministers-the-death-of-a-monarch-and-a-war-in-europe-12766654)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 09:41:00+00:00

For most of us, 2022 has felt like more than just a year.

## How is Christmas celebrated around the world?
 - [https://news.sky.com/story/what-is-christmas-and-when-and-how-is-it-celebrated-around-the-world-12766638](https://news.sky.com/story/what-is-christmas-and-when-and-how-is-it-celebrated-around-the-world-12766638)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 09:25:00+00:00

The festive season has arrived, with sleigh bells ringing and the timely smattering of snow glistening on our streets.

## Police name seven people missing after explosion at Jersey block of flats
 - [https://news.sky.com/story/jersey-flats-explosion-police-name-seven-victims-missing-after-blast-12766568](https://news.sky.com/story/jersey-flats-explosion-police-name-seven-victims-missing-after-blast-12766568)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 07:55:00+00:00

Police have named seven people who are missing following an explosion and fire at a block of flats in Jersey.

## Iran executes another prisoner as nationwide protests continue
 - [https://news.sky.com/story/iran-executes-another-prisoner-as-nationwide-protests-continue-12766566](https://news.sky.com/story/iran-executes-another-prisoner-as-nationwide-protests-continue-12766566)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 07:51:00+00:00

Iran has executed a second prisoner who was detained amid the ongoing nationwide protests against the government.

## Friend of Italian PM among three killed in cafe shooting
 - [https://news.sky.com/story/friend-of-italian-pm-among-three-killed-in-rome-cafe-shooting-12766549](https://news.sky.com/story/friend-of-italian-pm-among-three-killed-in-rome-cafe-shooting-12766549)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 07:29:00+00:00

Italian Prime Minister Giorgia Meloni has paid tribute to a friend who was among three people killed when a gunman open fire in Rome.

## 'Points of invincibility': Ukrainians learning new tricks to beat Putin's energy attacks
 - [https://news.sky.com/story/ukrainians-learning-new-tricks-to-beat-putins-energy-attacks-and-vow-well-never-give-up-12766511](https://news.sky.com/story/ukrainians-learning-new-tricks-to-beat-putins-energy-attacks-and-vow-well-never-give-up-12766511)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-12 05:18:00+00:00

The inside light of a car flickered in the darkness next to a cluster of large apartment blocks in the Ukrainian city of Odesa.


# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## The Pandemic and War — Not Government Spending — Caused Inflation, According to Nobel Prize Winner
 - [https://theintercept.com/2022/12/12/inflation-covid-war-joseph-stiglitz-ira-regmi/](https://theintercept.com/2022/12/12/inflation-covid-war-joseph-stiglitz-ira-regmi/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-12-12 22:17:52+00:00

<p>A new paper by Ira Regmi and Joseph Stiglitz has huge implications for everything about who holds power in American life.</p>
<p>The post <a href="https://theintercept.com/2022/12/12/inflation-covid-war-joseph-stiglitz-ira-regmi/" rel="nofollow">The Pandemic and War — Not Government Spending — Caused Inflation, According to Nobel Prize Winner</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Why Same-Sex Marriage Wins and Abortion Keeps Losing
 - [https://theintercept.com/2022/12/12/abortion-same-sex-marriage-rma/](https://theintercept.com/2022/12/12/abortion-same-sex-marriage-rma/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-12-12 19:14:43+00:00

<p>It’s all about family values.</p>
<p>The post <a href="https://theintercept.com/2022/12/12/abortion-same-sex-marriage-rma/" rel="nofollow">Why Same-Sex Marriage Wins and Abortion Keeps Losing</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Incarcerated People Forced to Do Dangerous Work for "Slave" Wages at Height of Pandemic
 - [https://theintercept.com/2022/12/12/covid-new-york-prison-labor/](https://theintercept.com/2022/12/12/covid-new-york-prison-labor/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-12-12 11:00:08+00:00

<p>New documents show the extent of the prison labor in New York, including jobs like asbestos removal.</p>
<p>The post <a href="https://theintercept.com/2022/12/12/covid-new-york-prison-labor/" rel="nofollow">Incarcerated People Forced to Do Dangerous Work for &#8220;Slave&#8221; Wages at Height of Pandemic</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>


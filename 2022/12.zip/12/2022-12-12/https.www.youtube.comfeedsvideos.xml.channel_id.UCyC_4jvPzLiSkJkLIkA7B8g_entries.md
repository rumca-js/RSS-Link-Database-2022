# Source:Lindsey Stirling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g, language:en-US

## #snowwaltz #behindthescenes #musicvideo #directing
 - [https://www.youtube.com/watch?v=ic9OtvyzJcg](https://www.youtube.com/watch?v=ic9OtvyzJcg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g
 - date published: 2022-12-12 22:44:11+00:00




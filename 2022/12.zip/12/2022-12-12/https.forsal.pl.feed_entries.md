# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Oddziały paramilitarne Obywateli Rzeszy. Organizacja była bardziej rozbudowana, niż sądzono
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8608901,niemcy-obywatele-rzeszy-oddzialy-paramilitarne.html](https://forsal.pl/swiat/aktualnosci/artykuly/8608901,niemcy-obywatele-rzeszy-oddzialy-paramilitarne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 20:59:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hPSktkuTURBXy84ZGVlMzA4My1jZmY1LTRkYjQtYjYwNi1jZWE3NTM4MmM3ODAuanBlZ5GTBc0BHcyg" />Organizacja Obywatele Rzeszy, rozbita w ubiegłym tygodniu przez niemiecką policję, była bardziej rozbudowana, niż pierwotnie sądzono. Po zakończeniu specjalnego posiedzenia w Berlinie, członkowie komisji prawnej Bundestagu poinformowali, że domniemani spiskowcy planowali utworzenie ponad 280 oddziałów paramilitarnych (Heimatschutzkompanie) – podał portal dziennika „Sueddeutsche Zeitung”.

## Spółki PKN Orlen zagospodarują złoża na Norweskim Szelfie Kontynentalnym
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8608885,pkn-orlen-zloza-norweski-szlif-kontynentalny.html](https://forsal.pl/biznes/aktualnosci/artykuly/8608885,pkn-orlen-zloza-norweski-szlif-kontynentalny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 20:26:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4DSktkuTURBXy83OGZhZDFmMS01OThlLTQ0MTMtOTczYi0xZDFlMDlmNmI3NzAuanBlZ5GTBc0BHcyg" />Lotos Norge i PGNiG Norway - spółki PKN Orlen - wraz ze swymi partnerami, podjęły ostateczną decyzję o zagospodarowaniu złóż ropy naftowej i gazu na Norweskim Szelfie Kontynentalnym - poinformował w poniedziałek w komunikacie PKN Orlen. Rozpoczęcie wydobycia z tych złóż planowane jest na 2027 r.

## Zmarł Mirosław Hermaszewski
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/8608810,miroslaw-hermaszewski-pierwszy-polski-kosmonauta-smierc.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/8608810,miroslaw-hermaszewski-pierwszy-polski-kosmonauta-smierc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 19:53:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_QdktkuTURBXy8zOWI0ODc2Mi03YjhlLTQ1MWUtOWIyMC1kMjE3ODk4MzllMjAuanBlZ5GTBc0BHcyg" />Zmarł pierwszy polski kosmonauta Mirosław Hermaszewski.

## Szijjarto: Dziewiąty pakiet sankcji UE wobec Rosji nie zagraża interesom Węgier
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8608805,peter-szijjarto-wegry-sankcje-ue-rosja-dziewiaty-pakiet.html](https://forsal.pl/swiat/aktualnosci/artykuly/8608805,peter-szijjarto-wegry-sankcje-ue-rosja-dziewiaty-pakiet.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 19:31:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Fb1ktkuTURBXy80M2E5ZTliMC0xZTAwLTQyOTgtYTFmNS1jMWIzY2Y4N2I3YTkuanBlZ5GTBc0BHcyg" />Przygotowywany dziewiąty pakiet unijnych sankcji wobec Rosji nie będzie zawierał nowych środków dotyczących sektora energetycznego, a więc nie zagraża naszym interesom narodowym - powiedział w poniedziałek w Brukseli minister spraw zagranicznych i handlu Węgier Peter Szijjarto.

## Szansa rozwojowa w sektorze ekonomii społecznej. Obejmuje spółdzielnie socjalne i organizacje pozarządowe prowadzące odpłatną działalność statutową
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8608802,ekonomia-spoleczna-marek-rymsza-organizacje-pozarzadowe-spoldzielnie-socjalne-fers.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8608802,ekonomia-spoleczna-marek-rymsza-organizacje-pozarzadowe-spoldzielnie-socjalne-fers.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 19:23:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hZyktkuTURBXy81M2NjM2Q2YS03NGMzLTQ0YzUtODMyMS0zYjBlYmIzYmZmMzEuanBlZ5GTBc0BHcyg" />Podczas posiedzenia Rady ds. Społecznych przy prezydencie podjęto rozmowy o rozwoju sektora ekonomii społecznej. Jak zaznaczył w rozmowie z PAP kierujący Radą prof. Marek Rymsza, istnieje duża szansa rozwojowa w tym obszarze m.in. ze względu na funkcjonowanie programu Fundusze Europejskie dla Rozwoju Społecznego.

## Wojna w Ukrainie skończy się, gdy umrze Władimir Putin
 - [https://forsal.pl/swiat/ukraina/artykuly/8608767,zelenski-smierc-putina-koniec-wojny.html](https://forsal.pl/swiat/ukraina/artykuly/8608767,zelenski-smierc-putina-koniec-wojny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 19:05:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/db3ktkuTURBXy9iZWVhZWE4Mi1mNGRjLTQ4ZTctODc2ZC1kYzdjZTAzYTU4ZTguanBlZ5GTBc0BHcyg" />Wierzę, że wojna skończy się wówczas, gdy umrze Władimir Putin - powiedział w poniedziałek prezydent Ukrainy Wołodymyr Zełenski w wywiadzie udzielonym Davidowi Lettermanowi, znanemu amerykańskiemu prezenterowi telewizyjnemu.

## Wotum nieufności wobec Ziobry. Posiedzenie komisji sprawiedliwości
 - [https://forsal.pl/gospodarka/polityka/artykuly/8608661,ziobro-komisja-sprawiedliwosci-wotum-nieufnosci.html](https://forsal.pl/gospodarka/polityka/artykuly/8608661,ziobro-komisja-sprawiedliwosci-wotum-nieufnosci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 18:46:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/THnktkuTURBXy85ZmQ0M2NhYy02MzMzLTRiMTktYTFmMC02ODdkMGFkMzFmN2QuanBlZ5GTBc0BHcyg" />W poniedziałek po godz. 19.00 sejmowa komisja sprawiedliwości rozpoczęła posiedzenie, na którym ma zaopiniować wniosek o wyrażenie wotum nieufności wobec ministra sprawiedliwości Zbigniewa Ziobry. Wniosek ten w połowie listopada złożyły kluby KO i Lewicy oraz koło Polska 2050.

## Brigitte Macron przyjęła w Pałacu Elizejskim pierwszą damę Ukrainy Ołenę Zełenską
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8608657,brigitte-macron-olena-zelenska.html](https://forsal.pl/swiat/aktualnosci/artykuly/8608657,brigitte-macron-olena-zelenska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 18:33:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xHQktkuTURBXy84YjY4Y2Y4My1lZmJhLTRiYjMtYTA3Ny1mZTk2NTE5Njc3ZmIuanBlZ5GTBc0BHcyg" />Małżonka prezydenta Francji Brigitte Macron przyjęła w poniedziałek w Pałacu Elizejskim pierwszą damę Ukrainy Ołenę Zełenską. Panie rozmawiały o francuskiej pomocy dla dzieci z Ukrainy w przeddzień międzynarodowej konferencji „Solidarni z narodem ukraińskim”, która odbędzie się w Paryżu.

## Niemcy: Polska powinna zidentyfikować odpowiedzialnego za zrzut soli do Odry
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8608611,niemcy-odra-zrzut-soli-odpowiedzialny.html](https://forsal.pl/swiat/aktualnosci/artykuly/8608611,niemcy-odra-zrzut-soli-odpowiedzialny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 18:29:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4LSktkuTURBXy85OGU2ZjY5Yy0yZjZiLTQzOGEtOWEyNi1jYjRlMmUwZmQzNWIuanBlZ5GTBc0BHcyg" />W związku z katastrofą ekologiczną w Odrze, do której doszło tego lata, niemiecka minister środowiska Steffi Lemke chce nadal naciskać na Polskę, by zidentyfikowała odpowiedzialnego za zrzut soli do rzeki - pisze w poniedziałek agencja dpa.

## Możliwość wzięcia kredytu na VAT. Projekt uchwały "Czyste Powietrze"
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8608347,czyste-powietrze-kredyt-na-vat.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8608347,czyste-powietrze-kredyt-na-vat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 17:39:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oBlktkuTURBXy8yNDkwZTJjYi03OWMwLTRmMzUtYThhYS1hMzI4NDc3ZGVhZTcuanBlZ5GTBc0BHcyg" />Umożliwienie finansowania kredytem bankowym podatku VAT z inwestycji w ramach programu gwarancyjnego &quot;Czyste Powietrze&quot;, z wykorzystaniem gwarancji BGK, zakłada projekt uchwały opublikowany w poniedziałek w wykazie prac legislacyjnych rządu.

## Belgia bez mandatów. Do 15 stycznia
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8608336,belgia-mandaty-drogowe.html](https://forsal.pl/swiat/aktualnosci/artykuly/8608336,belgia-mandaty-drogowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 17:13:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/w6aktkuTURBXy9lNjQzZTI3YS0yNDQwLTQzOGEtOTE1ZC02ZTVjY2ExM2VhZWIuanBlZ5GTBc0BHcyg" />Od najbliższej środy 14 grudnia 2022 r. do niedzieli 15 stycznia 2023 r. belgijscy policjanci nie będą wystawiać mandatów drogowych oraz za złe parkowanie, informuje w poniedziałek dziennik „Het Nieuwsblad”.

## 165 tys. osób dotkniętych przerwami w dostawach prądu
 - [https://forsal.pl/biznes/energetyka/artykuly/8608332,przerwy-w-dostawach-pradu-pge-dystrybucja.html](https://forsal.pl/biznes/energetyka/artykuly/8608332,przerwy-w-dostawach-pradu-pge-dystrybucja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 16:58:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tOnktkuTURBXy85M2ViYjE1NC0yNzg0LTRjMzYtOGFmYS05Y2VhNmZiMWY2YmQuanBlZ5GTBc0BHcyg" />Przerwy w dostawach prądu z powodu intensywnych opadów śniegu dotknęły ponad 165 tys. odbiorców - podała w poniedziałek PGE Dystrybucja, która dostarcza prąd we wschodniej i środkowej Polsce. Najwięcej awarii było w oddziałach w Skarżysku – Kamiennej, Zamościu i Rzeszowie.

## MSWiA przypomina: Odśnież dach albo zapłacisz mandat
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/8608328,mswia-odsniezanie-dachow-mandat.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/8608328,mswia-odsniezanie-dachow-mandat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 16:49:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zppktkuTURBXy80MjMxOTk0My02YjFiLTQwZDktYTYyMS05MjAyM2M1NTZhZjguanBlZ5GTBc0BHcyg" />Właściciele, zarządcy i administratorzy budynków są zobowiązani do usuwania z dachów śniegu i lodu - przypomina w poniedziałek Ministerstwo Spraw Wewnętrznych i Administracji. Zalegający śnieg może uszkodzić budynek, a lodowe sople i nawisy śnieżne są zagrożeniem dla przechodniów.

## Ponad tysiąc osób bez prądu. Świętokrzyskie zasypane
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/8608322,swietokrzyskie-tysiac-osob-bez-pradu.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/8608322,swietokrzyskie-tysiac-osob-bez-pradu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 16:29:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OR5ktkuTURBXy9jNjNjOGZkZC0wMmJhLTRiYmQtYjEwNi01YjdlNzY0ZDEwYTIuanBlZ5GTBc0BHcyg" />64 razy interweniowali już świętokrzyscy strażacy w związku z intensywnymi opadami śniegu. Bez prądu w regionie pozostaje aktualnie ok. 1050 odbiorców. Trudne warunki jazdy panują także na świętokrzyskich drogach.

## Niemcy chcą jeszcze bardziej oszczędzać gaz. Apel Federalnej Agencji ds. Sieci
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8608314,niemcy-federalna-agencja-ds-sieci-oszczedznosc-gazu.html](https://forsal.pl/swiat/aktualnosci/artykuly/8608314,niemcy-federalna-agencja-ds-sieci-oszczedznosc-gazu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 16:13:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mrCktkuTURBXy81Y2U0ZDY5NC01M2ZjLTRiNzQtOTdiMC04YTBiYTJjYjU0YzguanBlZ5GTBc0BHcyg" />Federalna Agencja ds. Sieci zaapelowała do mieszkańców Niemiec o zmniejszenie zużycia gazu. „Obecnie oszczędności zużycia gazu wynoszą zaledwie 13 procent” – oszacował prezes Agencji Klaus Mueller, dodając, że konieczne są większe oszczędności na poziomie 20 proc.

## W ataku na hotel w Kabulu zginęło trzech napastników, 19 osób zostało rannych
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8608304,afganistan-kabul-atak-na-hotel.html](https://forsal.pl/swiat/aktualnosci/artykuly/8608304,afganistan-kabul-atak-na-hotel.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 15:48:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/C2oktkuTURBXy8xYmNlNWE0Yy05MTkyLTQ5MGQtYmI5ZS1lNTNmMzRiNGYwMmQuanBlZ5GTBc0BHcyg" />W ataku na hotel w Kabulu zginęło w poniedziałek trzech napastników, a 19 osób zostało rannych. Według świadków z hotelu słuchać było strzały i eksplozje. Strzelanina trwała kilka godzin, nadal trwa operacja &quot;oczyszczania budynku” - powiedział rzecznik policji Chalid Zadran.

## Kodeks pracy 2023. Czy wiesz, co się zmieni? [QUIZ]
 - [https://forsal.pl/praca/aktualnosci/quizy/8608303,kodeks-pracy-2023-czy-wiesz-co-sie-zmieni-quiz.html](https://forsal.pl/praca/aktualnosci/quizy/8608303,kodeks-pracy-2023-czy-wiesz-co-sie-zmieni-quiz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 15:46:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CwAktkuTURBXy8yZjJiOWMwNC1hNDIxLTQwN2UtODU5ZS0wMzYwZjQ5Nzc3ZmMuanBlZ5GTBc0BHcyg" />W 2023 roku w Kodeksie pracy pojawi się sporo nowości, w tym przepisy dotyczące pracy zdalnej o kontroli trzeźwości. Sprawdź, czy wiesz, na czym będą polegały najważniejsze zmiany.

## "Na przedstawiciela think tanku". Eksperci ofiarami oszustw
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8608275,korea-polnocna-hakerzy-oszustwa-eksperci-na-przedstawiciela-think-tanku.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8608275,korea-polnocna-hakerzy-oszustwa-eksperci-na-przedstawiciela-think-tanku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 15:38:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HjbktkuTURBXy8yMmRlMjdkYi1lNzdhLTRlMzEtOWM1Zi02YzkzYzI0ZDQyMzMuanBlZ5GTBc0BHcyg" />Północnokoreańscy hakerzy obrali nowy sposób zbierania informacji od zagranicznych ekspertów; zamiast włamywać się do komputerów lub wykradać dane, proszą ich o komentarze, podając się za przedstawicieli think tanków – pisze w poniedziałek agencja Reutera.

## Santander zatrudni specjalistki i specjalistów od AI, API i cyberbezpieczeństwa. Nowe centra w Warszawie i Maladze
 - [https://forsal.pl/praca/aktualnosci/artykuly/8608264,warszawa-malaga-santander-centrum-technologii-praca.html](https://forsal.pl/praca/aktualnosci/artykuly/8608264,warszawa-malaga-santander-centrum-technologii-praca.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 15:21:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XVoktkuTURBXy8zM2MxNjVmMC0xM2VmLTQzNjAtYTVlMi0zNDMyZjBiY2JlMjIuanBlZ5GTBc0BHcyg" />Grupa Santander stworzyła nowe centra technologii w Warszawie i Maladze, jako wsparcie dla jednostek biznesowych, podal bank. Łącznie będą zatrudniać około 1400 specjalistów z wykształceniem naukowym, technologicznym, inżynieryjnym i matematycznym (STEM), którzy pomogą w cyfrowej i biznesowej transformacji banku.

## Hiszpańskie załogi lotnisk zapowiadają strajk w święta
 - [https://forsal.pl/praca/aktualnosci/artykuly/8608256,strajk-zalogi-lotnisk-hiszpania.html](https://forsal.pl/praca/aktualnosci/artykuly/8608256,strajk-zalogi-lotnisk-hiszpania.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 15:03:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eOLktkuTURBXy8xZThiNzYyOC00ZWM1LTQyNjUtYTVhNi1kZWFmOTI3NTIyOTQuanBlZ5GTBc0BHcyg" />Pracownicy spółki Aena, operatora lotnisk w Hiszpanii, ogłosili w poniedziałek przeprowadzenie strajku w okresie bożonarodzeniowo-noworocznym. Protest prowadzony będzie przez co najmniej sześć dni.

## Belgia liderką zamrażania rosyjskich aktywów. Zablokowała już 3,5 mld euro
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8608250,belgia-rosyjskie-aktywa-35-mld-euro.html](https://forsal.pl/swiat/aktualnosci/artykuly/8608250,belgia-rosyjskie-aktywa-35-mld-euro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 14:52:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ul8ktkuTURBXy8xODNlZDJjZC0wZmQ5LTQ0MzctODI0Zi1iNDViODIxOTQ4ODguanBlZ5GTBc0BHcyg" />Belgia zablokowała dotychczas 3,5 mld euro aktywów rosyjskich oligarchów i podmiotów z listy sankcyjnej, najwięcej ze wszystkich krajów Unii Europejskiej - wynika z informacji tamtejszych mediów. Łącznie 27 państw członkowskich zamroziło już 18,9 mld euro rosyjskich środków.

## Grupa WP zainwestowała w farmę PV na Dolnym Śląsku o mocy 1,85 MW kwotę 8,1 mln zł
 - [https://forsal.pl/biznes/energetyka/artykuly/8608247,grupa-wp-zainwestowala-w-farme-pv-na-dolnym-slasku-o-mocy-185-mw-kwote-81-mln-zl.html](https://forsal.pl/biznes/energetyka/artykuly/8608247,grupa-wp-zainwestowala-w-farme-pv-na-dolnym-slasku-o-mocy-185-mw-kwote-81-mln-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 14:48:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Oz4ktkuTURBXy8yZmIwNzU2OC03ZWMzLTQ0Y2ItOGQ1MC1hYWQ0OWY3NDZiZTguanBlZ5GTBc0BHcyg" />Grupa WP zainwestowała farmę PV na Dolnym Śląsku o mocy 1,85 MW kwotę 8,1 mln zł, podała spółka.

## PGE Energia Odnawialna kupiła 28 projektów fotowoltaicznych o łącznej mocy 59 MW
 - [https://forsal.pl/biznes/energetyka/artykuly/8608243,pge-energia-odnawialna-kupila-28-projektow-fotowoltaicznych-o-lacznej-mocy-59-mw.html](https://forsal.pl/biznes/energetyka/artykuly/8608243,pge-energia-odnawialna-kupila-28-projektow-fotowoltaicznych-o-lacznej-mocy-59-mw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 14:46:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dEHktkuTURBXy8yZWQ0ZGIyMy1hMzUxLTQ3MWMtOTA0NC01OWZhNTIwOTkzMjMuanBlZ5GTBc0BHcyg" />PGE Energia Odnawialna -, spółka z Polskiej Grupy Energetycznej (PGE) - kupiła w województwach wielkopolskim oraz łódzkim 28 projektów fotowoltaicznych o łącznej mocy 59 MW, podała spółka. Wszystkie projekty mają ważne warunki techniczne przyłączenia.

## Kryzys polityczny w Peru. Nowa prezydentka ogłasza stan wyjątkowy
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8608239,peru-dina-boluarte-zamieszki-stan-wyjatkowy.html](https://forsal.pl/swiat/aktualnosci/artykuly/8608239,peru-dina-boluarte-zamieszki-stan-wyjatkowy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 14:36:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RjtktkuTURBXy83NmViNTIzMi03ODdkLTRmNzAtODk2My1mZTc1ZmNkZDhiNGIuanBlZ5GTBc0BHcyg" />Prezydent Peru Dina Boluarte, która w środę została zaprzysiężona na najwyższy urząd w państwie po zdymisjonowaniu przez parlament dotychczasowego szefa państwa Pedro Castillo, ogłosiła w poniedziałek stan wyjątkowy w całym kraju.

## Ukraina: Odcięci od prądu ludzie giną w pożarach, używając otwartego ognia w mieszkaniach
 - [https://forsal.pl/swiat/ukraina/artykuly/8608216,ukraina-rosyjskie-bombardowania-brak-pradu-pozary.html](https://forsal.pl/swiat/ukraina/artykuly/8608216,ukraina-rosyjskie-bombardowania-brak-pradu-pozary.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 14:04:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GI-ktkuTURBXy80NjlhZjg2Ny05ZmEwLTRhOTItYWUyNS1iODE0ZjEzMzI5MGQuanBlZ5GTBc0BHcyg" />Osoby mieszkające w Ukrainie, odcięte od prądu przez rosyjskie bombardowania infrastruktury, coraz częściej giną w pożarach, wywołanych przez nieostrożne używanie otwartego ognia w mieszkaniach. Tylko w ciągu ostatniej doby w ten sposób zginęło dziesięć osób – podało w poniedziałek MSW w Kijowie.

## "Prezent dla Putina". W Czechach trwa zbiórka na systemy przeciwlotnicze dla Ukrainy
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8608205,czechy-prezent-dla-putina.html](https://forsal.pl/swiat/aktualnosci/artykuly/8608205,czechy-prezent-dla-putina.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 13:49:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hvqktkuTURBXy9hN2M2OTNhZC01NmI5LTQzZGMtYjdjMy03NzFiZTMwYzRjMjcuanBlZ5GTBc0BHcyg" />Inicjatorzy kampanii „Prezent dla Putina”, którzy prowadzą zbiórkę pieniędzy dla ukraińskiej armii, gromadzą obecnie środki na zakup 15 systemów przeciwlotniczych Viktor. Na stronie internetowej poinformowali, że mają już pieniądze na zakup 7 z nich.

## Sześciocyfrowa kwota gotówki zabezpieczona w domu Kaili. Ursula von der Leyen wyraziła zaniepokojenie
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8608200,ursula-non-der-leyen-eva-kaili-korupcja-parlament-europejski.html](https://forsal.pl/swiat/unia-europejska/artykuly/8608200,ursula-non-der-leyen-eva-kaili-korupcja-parlament-europejski.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 13:37:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HAtktkuTURBXy83NDljOWVlNC1jYjFjLTQxZjgtOGQ3Yi1jMmNjMTg3YmNiNzkuanBlZ5GTBc0BHcyg" />Zarzuty korupcyjne wobec wiceprzewodniczącej Parlamentu Europejskiego Evy Kaili, która została zatrzymana w piątek przez belgijska policję, wzbudzają poważne zaniepokojenie - powiedziała w poniedziałek szefowa Komisji Europejskiej Ursula von der Leyen.

## Nawalny w jednej celi z osobą w kryzysie bezdomności. Chcą go złamać
 - [https://forsal.pl/swiat/rosja/artykuly/8608183,nawalny-osoba-bezdomna-rosja-wiezienie.html](https://forsal.pl/swiat/rosja/artykuly/8608183,nawalny-osoba-bezdomna-rosja-wiezienie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 13:23:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/me-ktkuTURBXy80MGQ1NGZjZi04Mzc4LTQyZjItYTFmZS00YjhlOTRlMzI2MjUuanBlZ5GTBc0BHcyg" />Jeśli nie da się kogoś złamać w więzieniu biciem, ponieważ obowiązuje wobec niego zakaz stosowania przemocy, a także ciągłym wrzucaniem do karceru, to można go jeszcze zmusić do mieszkania w jednej celi z bezdomnym; to właśnie stało się moim udziałem - napisał w poniedziałek na Telegramie uwięziony rosyjski opozycjonista Aleksiej Nawalny.

## Rozkrut z GUS: Cały czas się starzejemy jako społeczeństwo
 - [https://forsal.pl/gospodarka/demografia/artykuly/8608174,rozkrut-z-gus-caly-czas-sie-starzejemy-jako-spoleczenstwo.html](https://forsal.pl/gospodarka/demografia/artykuly/8608174,rozkrut-z-gus-caly-czas-sie-starzejemy-jako-spoleczenstwo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 13:09:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YUCktkuTURBXy81MjdkN2ZiNC1iMTNhLTQzMDAtOTMyZC00MDc0NDFjNGZiN2YuanBlZ5GTBc0BHcyg" />Piramida wieku coraz mniej przypomina piramidę. Zgrubienie przesuwa się sukcesywnie do góry i ma taki efekt, że jako społeczeństwo się po prostu starzejemy – powiedział w poniedziałek podczas konferencji podsumowującej III Kongres Demograficzny prezes GUS dr Dominik Rozkrut.

## Afera korupcyjna w PE. Grecja zamroziła majątek Evy Kaili w związku ze skandalem
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8608159,afera-korupcyjna-w-pe-grecja-zamrozila-majatek-evy-kaili.html](https://forsal.pl/swiat/unia-europejska/artykuly/8608159,afera-korupcyjna-w-pe-grecja-zamrozila-majatek-evy-kaili.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 12:51:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KbkktkuTURBXy81YTI0OTE5Yi03N2UyLTRmODQtYjBlNi1jMGRlMTkxZGNjMjEuanBlZ5GTBc0BHcyg" />Grecja zamroziła majątek wiceszefowej Parlamentu Europejskiego Evy Kaili w związku ze skandalem korupcyjnym – poinformowała w poniedziałek agencja Reutera.

## Moskwa o ustawie wiatrakowej: 5 proc. wyprodukowanej energii przekazywane będzie społeczności lokalnej
 - [https://forsal.pl/biznes/energetyka/artykuly/8608156,moskwa-ustawa-wiatrakowa-5-proc-energii-dla-spolecznosci-lokalnej.html](https://forsal.pl/biznes/energetyka/artykuly/8608156,moskwa-ustawa-wiatrakowa-5-proc-energii-dla-spolecznosci-lokalnej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 12:39:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/M_5ktkuTURBXy9jOTRlYzRhOC04MTUzLTRmZTItYWE5OC1iZTFiNTQzZjk2NWQuanBlZ5GTBc0BHcyg" />Resort klimatu przygotował poprawkę do ustawy wiatrakowej, która zakłada, że 5 proc. energii będzie przekazywane społeczności lokalnej - poinformowała w poniedziałek podczas konferencji prasowej minister klimatu i środowiska Anna Moskwa.

## Baerbock: Podejrzenia o korupcję w PE uderzają w wiarygodność UE
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8608141,baerbock-podejrzenia-o-korupcje-w-pe-uderzaja-w-wiarygodnosc-ue.html](https://forsal.pl/swiat/unia-europejska/artykuly/8608141,baerbock-podejrzenia-o-korupcje-w-pe-uderzaja-w-wiarygodnosc-ue.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 12:16:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pp9ktkuTURBXy9kNWNjMzVhZi0wZDkwLTQ4ZTUtYTVlMS1kZjBkZDJiNzkwZmEuanBlZ5GTBc0BHcyg" />Podejrzenia o korupcję w Parlamencie Europejskim to kwestia wiarygodności Unii Europejskiej - powiedziała w poniedziałek minister spraw zagranicznych Niemiec Annalena Baerbock, odnosząc się do aresztowania jednej z wiceszefowych Parlamentu Europejskiego - Evy Kaili - uwikłanej w skandal korupcyjny.

## Komisja Europejska podpisała uzgodnienia operacyjne dla polskiego KPO
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8608138,komisja-europejska-podpisala-uzgodnienia-operacyjne-dla-polskiego-kpo.html](https://forsal.pl/swiat/unia-europejska/artykuly/8608138,komisja-europejska-podpisala-uzgodnienia-operacyjne-dla-polskiego-kpo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 12:11:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7MAktkuTURBXy9iMjkzMzQ1NC02ZDE4LTRlZmMtOTQwNy04NzlhZjA5OTExYTcuanBlZ5GTBc0BHcyg" />Komisja Europejska podpisała uzgodnienia operacyjne dotyczące Krajowego Planu Odbudowy (KPO) Polski. Jest to kolejny krok na drodze do wypłaty środków z Funduszu Odbudowy i Odporności (RRF). Jako pierwsza informację tę podała korespondentka Polskiego Radia w Brukseli Beata Płomecka. PAP potwierdziła ją równolegle w swoich źródłach.

## von der Leyen: Tej zimy energetyczny szantaż Rosji się nie powiódł
 - [https://forsal.pl/biznes/energetyka/artykuly/8608128,von-der-leyen-tej-zimy-energetyczny-szantaz-rosji-sie-nie-powiodl.html](https://forsal.pl/biznes/energetyka/artykuly/8608128,von-der-leyen-tej-zimy-energetyczny-szantaz-rosji-sie-nie-powiodl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 12:01:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uvbktkuTURBXy9jZWI5OTVkMS0yOTI5LTQyZDUtOWM3ZS1hZDA0NmQ1NWE5MGMuanBlZ5GTBc0BHcyg" />Tej zimy jesteśmy bezpieczni; energetyczny szantaż Rosji się nie powiódł - powiedziała w poniedziałek na konferencji prasowej w Brukseli przewodnicząca Komisji Europejskiej Ursula von der Leyen. Ostrzegła jednak, że następna zima może być większym wyzwaniem.

## Rabenda: 2300 gmin w Polsce podpisało umowy na dystrybucję węgla
 - [https://forsal.pl/biznes/energetyka/artykuly/8608106,rabenda-2300-gmin-w-polsce-podpisalo-umowy-na-dystrybucje-wegla.html](https://forsal.pl/biznes/energetyka/artykuly/8608106,rabenda-2300-gmin-w-polsce-podpisalo-umowy-na-dystrybucje-wegla.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 11:43:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1UpktkuTURBXy82MGM0MzYzNi1hZTcxLTQ0YmYtYWE0NS1kMDQ5NjZkNzY0YzUuanBlZ5GTBc0BHcyg" />Mamy podpisane umowy z 2300 gminami w Polsce na dystrybucję węgla; pozostało jeszcze ok. 100 gmin, w których trwają rozmowy — mówił w poniedziałek w Toruniu wiceminister aktywów państwowych Karol Rabenda. Dodał, że węgiel został już dostarczony zgodnie z umową do 1500 samorządów.

## Wiceszef MSZ Chin spotkał się z wysokiej rangi delegacją z USA
 - [https://forsal.pl/swiat/usa/artykuly/8608102,wiceszef-msz-chin-spotkal-sie-z-wysokiej-rangi-delegacja-z-usa.html](https://forsal.pl/swiat/usa/artykuly/8608102,wiceszef-msz-chin-spotkal-sie-z-wysokiej-rangi-delegacja-z-usa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 11:36:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dG0ktkuTURBXy83ZDFkZDRlNy05NmM1LTQwMmYtYWE0Ny1hMDE5NWZhZWU4MDYuanBlZ5GTBc0BHcyg" />Wiceszef chińskiego MSZ Xie Feng przeprowadził z odwiedzającymi Chiny wysokiej rangi urzędnikami z USA „szczere, dogłębne i konstruktywne” rozmowy na tematy międzynarodowe i regionalne – poinformował w poniedziałek rzecznik resortu w Pekinie Wang Wenbin.

## Wcześniejsza emerytura? Scholz chce, by mniej Niemców wybierało tę opcję
 - [https://forsal.pl/praca/aktualnosci/artykuly/8608103,emerytury-niemcy-wiek-emerytalny-rynek-pracy.html](https://forsal.pl/praca/aktualnosci/artykuly/8608103,emerytury-niemcy-wiek-emerytalny-rynek-pracy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 11:35:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RZJktkuTURBXy85Mzk2YWU1OS01ZWNlLTRkYjAtOWJlOC0wNWQ3YmNlMTkzNDkuanBlZ5GTBc0BHcyg" />Niemcy coraz chętniej przechodzą na wcześniejszą emeryturę. Kanclerz Olaf Scholz (SPD) chce, by więcej obywateli zostało na rynku pracy do osiągnięcia wieku emerytalnego.

## W 2021 r. do Polski przyjechało o 54 proc. mniej turystów z zagranicy niż w 2019
 - [https://forsal.pl/gospodarka/pkb/artykuly/8608081,2021-polska-przyjechalo-o-54-proc-mniej-turystow-z-zagranicy-niz-w-2019.html](https://forsal.pl/gospodarka/pkb/artykuly/8608081,2021-polska-przyjechalo-o-54-proc-mniej-turystow-z-zagranicy-niz-w-2019.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 11:21:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KofktkuTURBXy8xN2VhMzJjZS1iNzBlLTQ4ZWEtYTBlYy00NGJkY2Y2NDcxYzguanBlZ5GTBc0BHcyg" />Po osiągnięciu rekordowego poziomu 21,2 mln zagranicznych turystów w Polsce w 2019 r., ich liczba spadła do 8,4 mln rok później - wynika z raportu OECD. W 2021 r. liczba gości wzrosła do 9,7 mln, ale była o 54 proc. niższa niż przed pandemią - dodano.

## ZUS: Osoby otrzymujące rentę socjalną mogą do niej dorobić
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8608069,zus-osoby-otrzymujace-rente-socjalna-moga-do-niej-dorobic.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8608069,zus-osoby-otrzymujace-rente-socjalna-moga-do-niej-dorobic.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 11:13:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qVyktkuTURBXy9hMDI2OGRiZi1iOGMyLTQwODktYjk2Yi1kMDg0MzljZDZlMTguanBlZ5GTBc0BHcyg" />Od stycznia 2022 r. zmieniły się zasady zawieszania renty socjalnej w przypadku dorabiania do tego świadczenia. Obecnie są stosowane te same reguły co do renty z tytułu niezdolności do pracy. Dla wielu osób pobierających rentę socjalną oznacza to, że ich świadczenie nie będzie zawieszane - przypomina w poniedziałek ZUS.

## Berlin: Prezydent Duda spotka się z prezydentem Niemiec Frankiem-Walterem Steinmeierem
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8608056,berlin-duda-spotka-sie-z-prezydentem-niemiec-steinmeierem.html](https://forsal.pl/swiat/unia-europejska/artykuly/8608056,berlin-duda-spotka-sie-z-prezydentem-niemiec-steinmeierem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 10:48:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LACktkuTURBXy81YmI1MThlMy1mZTFlLTRmODctODhmMC01NDkyY2MxMmYwOTEuanBlZ5GTBc0BHcyg" />Prezydent RP Andrzej Duda przybył w poniedziałek do Berlina z roboczą wizytą; spotka się z prezydentem Niemiec Frankiem-Walterem Steinmeierem. Przywódcy będą rozmawiać o bezpieczeństwie i grożącym Ukrainie kryzysie humanitarnym; omówią także kwestie dwustronne.

## Rynek nieruchomości w Europie Środkowo-Wschodniej. Aż 56 proc. transakcji realizowanych jest w Polsce
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8608049,rynek-nieruchomosci-w-cee-56-proc-transakcji-realizowanych-w-polsce.html](https://forsal.pl/swiat/unia-europejska/artykuly/8608049,rynek-nieruchomosci-w-cee-56-proc-transakcji-realizowanych-w-polsce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 10:38:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/puVktkuTURBXy82ODNhNzJiNC02MjY5LTRkM2QtYTNkNi05NTkwZGFlZjM2OGMuanBlZ5GTBc0BHcyg" />W pierwszym półroczu 2022 r. inwestycje w Polsce stanowiły 56 proc. wolumenu transakcji nieruchomościowych w regionie Europy Środkowo-Wschodniej. Sektor nieruchomości nieco spowolnił, ale wciąż pozostaje stabilnym miejscem do inwestycji – wynika z raportu firmy doradczej KPMG.

## Credit Agricole: Stopy proc. we wszystkich krajach CEE-4 wyniosą 5-6 proc. pod koniec 2024 r.
 - [https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8608023,credit-agricole-stopy-proc-krajach-cee-4-5-6-proc-pod-koniec-2024-r.html](https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8608023,credit-agricole-stopy-proc-krajach-cee-4-5-6-proc-pod-koniec-2024-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 10:18:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ygRktkuTURBXy81NDkxMzA4Ni0wYjFlLTRmOTgtYjdhYi0yZWQ5OGU3NGI4Y2YuanBlZ5GTBc0BHcyg" />Stopy procentowe wyniosą 5-6 proc. w czterech krajach Europy Środkowo-Wschodniej (CEE) pod koniec 2024 r., prognozuje Credit Agricole Bank Polska. Bank oczekuje pierwszych cięć stóp procentowych o 25 pb w I kw. 2024 r. w Polsce.

## Kowalczyk o Kodeksie rolnym: To byłby zbiór przepisów chroniących rolników
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8608012,kowalczyk-kodeks-rolny-zbior-przepisow-chroniacych-rolnikow.html](https://forsal.pl/biznes/rolnictwo/artykuly/8608012,kowalczyk-kodeks-rolny-zbior-przepisow-chroniacych-rolnikow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 10:04:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4UWktkuTURBXy84YzVlYTE3MS1lOWE3LTRlZjgtYWNmMy1kOTY2ZDJlMDg4ZWEuanBlZ5GTBc0BHcyg" />Kodeks rolny to byłby zbiór wszystkich przepisów, które mają chronić rolników - powiedział w poniedziałek wicepremier, minister rolnictwa Henryk Kowalczyk. Jeśli nastąpiłaby jakakolwiek kolizja przepisów z Kodeksu i z innymi ustawami, to on będzie miał pierwszeństwo w stosowaniu - dodał.

## Mercedes-Benz zainwestuje ponad 1 mld euro w fabrykę w Jaworze
 - [https://forsal.pl/biznes/przemysl/artykuly/8608001,mercedes-benz-zainwestuje-ponad-1-mld-euro-w-fabryke-w-jaworze.html](https://forsal.pl/biznes/przemysl/artykuly/8608001,mercedes-benz-zainwestuje-ponad-1-mld-euro-w-fabryke-w-jaworze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 09:36:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sgSktkuTURBXy9iYTBiYWQxYi00NTY2LTRlYTMtOGFjOS1iMTE5ZDMzODFmNjYuanBlZ5GTBc0BHcyg" />Chcemy zainwestować ponad 1 mld euro w fabrykę w Jaworze produkującą elektryczne samochody dostawcze - zapowiedział w poniedziałek szef działu pojazdów użytkowych w Grupie Mercedes-Benz Mathias Geisen.

## Borrell: Na razie brak porozumienia w sprawie kolejnych sankcji przeciwko Rosji
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8607998,borrell-brak-porozumienia-w-sprawie-kolejnych-sankcji-przeciwko-rosji.html](https://forsal.pl/swiat/unia-europejska/artykuly/8607998,borrell-brak-porozumienia-w-sprawie-kolejnych-sankcji-przeciwko-rosji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 09:31:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/n5uktkuTURBXy8yMzRiMmU0Yy02OGM0LTQ3NjAtODhiZS0yMzMwY2IyYWI4M2UuanBlZ5GTBc0BHcyg" />Wciąż nie ma jeszcze porozumienia w sprawie kolejnego - dziewiątego - pakietu sankcji przeciwko Rosji za agresję na Ukrainę - poinformował w poniedziałek w Brukseli szef unijnej dyplomacji Josep Borrell. Wyraził nadzieję, że porozumienie uda się osiągnąć w poniedziałek lub wtorek.

## Afera korupcyjna w PE. Borrell: Informacja o śledztwie to niepokojąca wiadomość
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8608007,afera-korupcyjna-w-pe-borrell-sledztwo-to-niepokojaca-wiadomosc.html](https://forsal.pl/swiat/unia-europejska/artykuly/8608007,afera-korupcyjna-w-pe-borrell-sledztwo-to-niepokojaca-wiadomosc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 09:26:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/U2PktkuTURBXy8xM2ZkZTdlMi0wMmQ4LTRlNDQtYjllOC0wYmUyNDRlN2EzMzYuanBlZ5GTBc0BHcyg" />&quot;Ta wiadomość jest bardzo niepokojąca&quot; - oświadczył wysoki przedstawiciel Unii do spraw zagranicznych i polityki bezpieczeństwa Josep Borell, odnosząc się do aresztowania jednej z wiceszefowych Parlamentu Europejskiego - Evy Kaili - uwikłanej w skandal korupcyjny.

## Jabłoński w Brukseli: To Europa potrzebuje gwarancji bezpieczeństwa od Rosji
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8607956,jablonski-bruksela-europa-potrzebuje-gwarancji-bezpieczenstwa-od-rosji.html](https://forsal.pl/swiat/unia-europejska/artykuly/8607956,jablonski-bruksela-europa-potrzebuje-gwarancji-bezpieczenstwa-od-rosji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 08:42:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BOnktkuTURBXy8zZWJkMjZkYi0wYjBjLTRjZjQtOTZmOS01Yjc3OWQyZGRjNmYuanBlZ5GTBc0BHcyg" />Strategicznym błędem jest rozważanie, że Rosja ma prawo wymagać gwarancji bezpieczeństwa od kogokolwiek - powiedział w poniedziałek w Brukseli Paweł Jabłoński, podsekretarz stanu w Ministerstwie Spraw Zagranicznych RP przed rozpoczęciem spotkania unijnych szefów dyplomacji. Dodał, że to Europa potrzebuje gwarancji od Rosji.

## ISW: Białoruska armia raczej nie zaatakuje Ukrainy
 - [https://forsal.pl/swiat/ukraina/artykuly/8607947,isw-bialoruska-armia-raczej-nie-zaatakuje-ukrainy.html](https://forsal.pl/swiat/ukraina/artykuly/8607947,isw-bialoruska-armia-raczej-nie-zaatakuje-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 08:28:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/J9ektkuTURBXy85ZGFjN2YxOC0xMGFlLTQ4ODQtOGJkNy01MzdmZjkxOWYwNmYuanBlZ5GTBc0BHcyg" />Jako „niezwykle mało prawdopodobne” w przewidywalnej przyszłości włączenie się armii Białorusi do wojny z Ukrainą ocenił amerykański Instytut Badań nad Wojną (ISW) w najnowszym raporcie.

## Zatrudnianie pracowników spoza UE jak lotto. Dla szczęściarzy
 - [https://forsal.pl/praca/aktualnosci/artykuly/8607358,polska-zatrudnianie-pracownikow-spoza-ue.html](https://forsal.pl/praca/aktualnosci/artykuly/8607358,polska-zatrudnianie-pracownikow-spoza-ue.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 08:21:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WkGktkuTURBXy8xZDUyNmYwYi04ZDY0LTQ4NGEtOWQ5Zi02MTI1NTk0Y2ZhNWEuanBlZ5GTBc0BHcyg" />Pracodawcy skarżą się na uciążliwości związane z uzyskiwaniem wiz pracowniczych dla obcokrajowców. Domagają się podjęcia przez rząd natychmiastowych działań, które usprawnią system. Resort spraw zagranicznych zapowiada zmiany, ale nie precyzuje jakie.

## Gigantyczne uzupełnienie zapasów sprzętu wojskowego. USA się zbroi
 - [https://forsal.pl/swiat/usa/artykuly/8607645,usa-obronnosc-budzet-wojsko.html](https://forsal.pl/swiat/usa/artykuly/8607645,usa-obronnosc-budzet-wojsko.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 08:14:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/S_lktkuTURBXy9mZWJiYzc5OS1mNTdjLTRlYjEtYTNmMy0xNGUxMGNjYmU4MGUuanBlZ5GTBc0BHcyg" />Przegłosowany przez Izbę Reprezentantów amerykański budżet na obronność przewiduje gigantyczne uzupełnienie zapasów sprzętu wojskowego, który przekazano Ukrainie.

## Grant Thornton: Liczba ofert pracy spadła o 3,2 proc. r: r w listopadzie
 - [https://forsal.pl/praca/artykuly/8607931,grant-thornton-liczba-ofert-pracy-spadla-o-32-proc-r-r-w-listopadzie.html](https://forsal.pl/praca/artykuly/8607931,grant-thornton-liczba-ofert-pracy-spadla-o-32-proc-r-r-w-listopadzie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 08:12:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QtzktkuTURBXy84ODdmZGU1NC0xNzgzLTQ1NjctOGFjOS00YmI5MTFiM2UzMzUuanBlZ5GTBc0BHcyg" />Pracodawcy w Polsce opublikowali w październiku 297,9 tys. nowych ofert pracy, tj. o 3,2 proc. mniej r/r i o 3,1 proc. mniej m/m, podano w raporcie &quot;Oferty pracy w Polsce&quot; Grant Thornton, którego partnerem technologicznym była firma Element. Podkreślono, że biorąc pod uwagę skalę wzrostu kosztów funkcjonowania firm, wydaje się to nadal relatywnie pozytywnym wynikiem.

## RPP mówi "stop" podwyżkom stóp procentowych
 - [https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8607634,stopy-procentowe-rpp.html](https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8607634,stopy-procentowe-rpp.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 08:09:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/L0HktkuTURBXy80NDY3OGE0Mi1lZWVkLTRjN2EtYTdiNC02ZTFlN2Y2MTZmMjAuanBlZ5GTBc0BHcyg" />Dalsze zaostrzanie polityki pieniężnej jest możliwe już tylko teoretycznie.

## Zaległości branży beauty wzrosły do 109 mln zł na koniec października
 - [https://forsal.pl/biznes/firma/artykuly/8607917,zaleglosci-branzy-beauty-wzrosly-do-109-mln-zl-na-koniec-pazdziernika.html](https://forsal.pl/biznes/firma/artykuly/8607917,zaleglosci-branzy-beauty-wzrosly-do-109-mln-zl-na-koniec-pazdziernika.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 08:05:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xsrktktTURBXy9jYzczODc5My1lODQ5LTQ4ZjktODE4Mi03ZjBhNmRlOTJkYmYucG5nkZMFzQEdzKA" />Sytuacja branży beauty - na tle innych sektorów - jest stabilna. Zaległe zadłużenie tych biznesów w październiku 2022 r. wyniosło 109 mln zł, wynika z danych Rejestru Dłużników BIG InfoMonitor i bazy BIK. To wzrost o 7,5 proc. względem analogicznego okresu w roku ubiegłym.

## Limit cenowy dla OZE ma być bardziej opłacalny
 - [https://forsal.pl/biznes/energetyka/artykuly/8607619,limit-cenowy-dla-oze-ma-byc-bardziej-oplacalny.html](https://forsal.pl/biznes/energetyka/artykuly/8607619,limit-cenowy-dla-oze-ma-byc-bardziej-oplacalny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 08:03:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xRgktkuTURBXy9jMTkxMGFhNC0xMDM1LTRkNTUtOTMwYi1kOGVkOGE3ODNkODkuanBlZ5GTBc0BHcyg" />Zdaniem ekspertów projekt nowelizacji rozporządzenia o limitach cen nie w pełni odpowiada potrzebom.

## KPO trochę mniej odległy. Jakie są scenariusze?
 - [https://forsal.pl/gospodarka/polityka/artykuly/8607614,kpo-scenariusze-polska-ke.html](https://forsal.pl/gospodarka/polityka/artykuly/8607614,kpo-scenariusze-polska-ke.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:58:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QRhktkuTURBXy8yZDM5NjM2MS1mMWZmLTRlOWMtODJkYy0wNjcxMzAwOTQ1NDUuanBlZ5GTBc0BHcyg" />Rządowi i Komisji Europejskiej zależy na obustronnych gwarancjach, że ustalenia tym razem nie zostaną przez nikogo złamane.

## Miedź w Londynie mocno tanieje
 - [https://forsal.pl/finanse/notowania/artykuly/8607906,miedz-w-londynie-mocno-tanieje.html](https://forsal.pl/finanse/notowania/artykuly/8607906,miedz-w-londynie-mocno-tanieje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:57:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FgIktkuTURBXy9kYTI0NTRhMS1jMjk0LTRmOGEtYWQ4My01ODA2MzA1YjAwM2YuanBlZ5GTBc0BHcyg" />Miedź na giełdzie metali LME w Londynie mocno tanieje z powodu obaw związanych z rosnącą liczbą nowych zakażeń koronawirusem w Chinach. Metal w dostawach 3-miesięcznych jest wyceniany niżej o 1,5 proc. - po 8.416 USD za tonę - informują maklerzy.

## Premier deklaruje: Trzynasta i czternasta emerytura zostanie na stałe
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8607901,premier-deklaruje-trzynasta-i-czternasta-emerytura-zostanie-na-stale.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8607901,premier-deklaruje-trzynasta-i-czternasta-emerytura-zostanie-na-stale.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:53:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-96ktkuTURBXy9mMjQyYTQ0YS04N2VhLTRlNjItODYwNi0yMGJmMmNiODNhMjYuanBlZ5GTBc0BHcyg" />Jeśli będziemy nadal rządzić, trzynastka i czternastka będą utrzymane. Chcemy czternastkę na stałe wpisać do ustawy – powiedział premier Mateusz Morawiecki w poniedziałkowym &quot;Super Expressie”.

## Próbne egzaminy maturalne w nowej formule [TERMINY]
 - [https://forsal.pl/lifestyle/edukacja/artykuly/8607897,probne-egzaminy-maturalne-terminy.html](https://forsal.pl/lifestyle/edukacja/artykuly/8607897,probne-egzaminy-maturalne-terminy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:49:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/krTktkuTURBXy9jNmIyMjAwNC05ZWY1LTQ1ZjktOWY2Mi1mYjY4Njg5ZDYzMWMuanBlZ5GTBc0BHcyg" />Od 12 do 21 grudnia odbędą się próbne egzaminy maturalne organizowane przez Centralną Komisję Egzaminacyjną. Chodzi o egzaminy przeprowadzane w nowej formule. Udział szkół w próbnych egzaminach jest dobrowolny.

## Błaszczak: Najlepsza na świecie amunicja trafi do polskiego wojska
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8607896,blaszczak-najlepsza-na-swiecie-amunicja-trafi-do-polskiego-wojska.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8607896,blaszczak-najlepsza-na-swiecie-amunicja-trafi-do-polskiego-wojska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:48:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Y2IktkuTURBXy81MmU4MTcxMy00ZDQ0LTQzZjAtODhkNy03NjY3MTQwMDQzMzEuanBlZ5GTBc0BHcyg" />Jestem dumny z zamówienia najlepszej na świecie amunicji w setkach tysięcy sztuk. Amunicji, której nie oprze się żadnej pancerz, oprócz pancerza Abramsa – powiedział wicepremier, minister obrony narodowej Mariusz Błaszczak w wywiadzie dla &quot;Polska. Metropolia warszawska&quot;.

## Poranne notowanie walut: Złoty traci do głównych walut
 - [https://forsal.pl/finanse/waluty/artykuly/8607893,poranne-notowanie-walut-zloty-traci-do-glownych-walut.html](https://forsal.pl/finanse/waluty/artykuly/8607893,poranne-notowanie-walut-zloty-traci-do-glownych-walut.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:37:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KoWktkuTURBXy85MGJkNmIyNC0zNDQ0LTQzY2MtOTQxNy00OGY5MzU3OWRhOTYuanBlZ5GTBc0BHcyg" />Złoty w poniedziałek rano traci do euro 0,18 proc., wobec dolara - 0,20 proc., a franka szwajcarskiego - 0,14 proc. Euro kosztuje 4,69 zł, dolar - 4,46, a frank szwajcarski - 4,76 zł.

## Szczepienia przeciw COVID-19. Można już rejestrować dzieci w wieku od 6 miesięcy do 4 lat
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8607891,szczepienia-covid-19-dzieci-w-wieku-od-6-miesiecy-do-4-lat.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8607891,szczepienia-covid-19-dzieci-w-wieku-od-6-miesiecy-do-4-lat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:34:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Xt4ktkuTURBXy84MzgwY2RhNC02ODAyLTQ0MWItODk2Yy1hNGE4MzE2MjIwZmQuanBlZ5GTBc0BHcyg" />Od 12 grudnia 2022 r. szczepionkę przeciw COVID-19 mogą otrzymać dzieci w wieku od 6 miesięcy do 4 lat. W nocy z 11 na 12 grudnia wystawiono blisko 2 mln e-skierowań.

## O ile były droższe zakupy w listopadzie? Średnie wzrosty znowu są dwucyfrowe
 - [https://forsal.pl/biznes/handel/artykuly/8607890,inflacja-zakupy-wzrost-cen-polska.html](https://forsal.pl/biznes/handel/artykuly/8607890,inflacja-zakupy-wzrost-cen-polska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:29:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XToktkuTURBXy8xODk0YTRiMC0xNjdkLTRmNjctYTVmMi00ZjhkOTFjMTlmODIuanBlZ5GTBc0BHcyg" />W listopadzie br. codzienne zakupy były droższe średnio o 25,8 proc. rdr - wynika z przekazanego PAP najnowszego &quot;Indeksu cen w sklepach detalicznych&quot;. Zdrożały wszystkie z 12 analizowanych kategorii produktów, a ich średnie wzrosty znowu są dwucyfrowe.

## Szef MRiRW: Piątka dla zwierząt odeszła w niepamięć
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8607887,kowalczyk-mrirw-piatka-dla-zwierzat-odeszla-w-niepamiec.html](https://forsal.pl/biznes/rolnictwo/artykuly/8607887,kowalczyk-mrirw-piatka-dla-zwierzat-odeszla-w-niepamiec.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:24:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DCLktkuTURBXy81MDNmYWUxZC1kNGM1LTQ0NjktYmU1Ni05M2M2OGE4MmI4MWUuanBlZ5GTBc0BHcyg" />Tzw. piątka dla zwierząt odeszła już w niepamięć - powiedział PAP wicepremier, minister rolnictwa i rozwoju wsi Henryk Kowalczyk. Podkreślił, że rolnicy najbardziej dbają o zwierzęta, to jest ich źródło dochodu.

## Kryzys na rynku ropy. Przedłużające się zamknięcie kluczowego naftociągu w USA winduje cenę
 - [https://forsal.pl/finanse/notowania/artykuly/8607880,kryzys-na-rynku-ropy-cena-w-gore-kluczowy-naftociag-w-usa-zamkniety.html](https://forsal.pl/finanse/notowania/artykuly/8607880,kryzys-na-rynku-ropy-cena-w-gore-kluczowy-naftociag-w-usa-zamkniety.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:17:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ywgktkuTURBXy9kODY0ZGQ1OC01OGNiLTQ3MjktYWY1NS1jNmIyNGU2ZDhmYzYuanBlZ5GTBc0BHcyg" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną w poniedziałek. Kluczowy ropociąg w Stanach Zjednoczonych pozostaje zamknięty, co wpływa na ograniczenie dostaw paliw. Inwestorzy analizują też najnowsze informacje dotyczące Covid-19 w Chinach - informują maklerzy.

## Biden: Wzmocnienie obrony powietrznej Ukrainy jest naszym priorytetem
 - [https://forsal.pl/swiat/usa/artykuly/8607876,biden-usa-ukraina.html](https://forsal.pl/swiat/usa/artykuly/8607876,biden-usa-ukraina.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:15:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vxvktkuTURBXy9hN2Q5MjI1NC02ZjE5LTQ5YTYtYmQ1OS05MTcxNjRlYzEwOWYuanBlZ5GTBc0BHcyg" />Prezydent USA Joe Biden podkreślił podczas niedzielnej rozmowy telefonicznej z Wołodymyrem Zełenskim, że USA priorytetowo traktują wysiłki na rzecz wzmocnienia obrony powietrznej Ukrainy poprzez oferowaną pomoc - poinformował w komunikacie Biały Dom.

## Szansa na szybsze wyroki w sprawach frankowych
 - [https://forsal.pl/gospodarka/prawo/artykuly/8607328,kredyty-walutowe-franki-wyroki-sady.html](https://forsal.pl/gospodarka/prawo/artykuly/8607328,kredyty-walutowe-franki-wyroki-sady.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 07:00:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CJdktkuTURBXy9kMWM4ZGExNi1iOWYxLTQ5NzQtOTczYi01MjEyNzYzZDYwYzcuanBlZ5GTBc0BHcyg" />Spory dotyczące kredytów walutowych będą rozpatrywać sądy właściwe dla miejsca zamieszkania konsumenta. Pozwoli to odciążyć Sąd Okręgowy w Warszawie, gdzie terminy rozpraw są wyznaczane na połowę 2025 r.

## Zwolnienie podmiotowe i VAT od aut bez zmian
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8607263,zwolnienie-podmiotowe-i-vat-od-aut-bez-zmian.html](https://forsal.pl/finanse/aktualnosci/artykuly/8607263,zwolnienie-podmiotowe-i-vat-od-aut-bez-zmian.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 06:57:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ffiktkuTURBXy81NDYwMGZjOC05NWI4LTQwYmUtYTlhYS05MmIwYzQ0YTZlZWQuanBlZ5GTBc0BHcyg" />Limit zwolnienia podmiotowego z podatku od towarów i usług pozostanie na poziomie 200 tys. zł do końca 2024 r. – poinformował resort finansów w odpowiedzi na pytanie DGP. Prawo do odliczenia 50-proc. VAT związanego z kupnem auta i jego używaniem będzie obowiązywać do końca 2025 r.

## Rzesza kabaretowa. Co pokazał nieudany przewrót w Niemczech?
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8607672,rzesza-kabaretowa-co-pokazal-nieudany-przewrot-w-niemczech.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8607672,rzesza-kabaretowa-co-pokazal-nieudany-przewrot-w-niemczech.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 06:53:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cXlktkuTURBXy9iMDc2MjVkMi1hNGUyLTQ4NzItYmU5NS1iNDJkYjc3YzViYjAuanBlZ5GTBc0BHcyg" />Choć próba puczu Obywateli Rzeszy przypomina farsę, rośnie liczba przestępstw, które popełniają członkowie tej organizacji. W ekstremizm polityczny znów zamieszani są wojskowi sił specjalnych.

## Chińskie systemy monitoringu w polskiej administracji. Amerykanie zabraniają używania tych kamer
 - [https://forsal.pl/lifestyle/technologie/artykuly/8607624,chinskie-kamery-polska-administracja.html](https://forsal.pl/lifestyle/technologie/artykuly/8607624,chinskie-kamery-polska-administracja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 06:44:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lBGktkuTURBXy84YzE2NjRlMy04NWEwLTQ5NzctYTEzNy02OTE0N2Q2MTVkMDQuanBlZ5GTBc0BHcyg" />Podczas gdy Amerykanie zabraniają używania kamer chińskich firm, budynki polskiej administracji są przez nie obserwowane

## Ropa mocno staniała, ale będzie drożeć
 - [https://forsal.pl/biznes/energetyka/artykuly/8607599,ropa-mocno-staniala-ale-bedzie-drozec.html](https://forsal.pl/biznes/energetyka/artykuly/8607599,ropa-mocno-staniala-ale-bedzie-drozec.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 06:35:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pL_ktkuTURBXy83ODg2YzI1NS1iMzBmLTQxMzItYjEwOC04MzA3MDQ5MDQ2MzMuanBlZ5GTBc0BHcyg" />Rosyjskie groźby o ograniczeniu produkcji nie zatrzymały spadku cen. W przyszłym roku Brent ma jednak kosztować powyżej 90 dol.

## Ceny działek pod budowę domu. Ile trzeba zapłacić za grunty w największych miastach?
 - [https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8606646,ceny-dzialek-w-polsce-grunty-pod-budowe-domu.html](https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8606646,ceny-dzialek-w-polsce-grunty-pod-budowe-domu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 06:18:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OFaktkuTURBXy9kNjU5MDI4Ni03YmNhLTQxMTEtODE2ZS04MzE0OGYzOGE4ZTcuanBlZ5GTBc0BHcyg" />Pojawiły się ciekawe dane o cenach działek pod domy i bloki. Potwierdzają one, że wiele osób musi zapomnieć o budowie domu w mieście.

## Rynki finansowe dostaną kilka potężnych ciosów? To może zaskoczyć inwestorów w 2023 roku
 - [https://forsal.pl/finanse/artykuly/8606426,najwieksze-zaskoczenia-rynki-finansowe-2023.html](https://forsal.pl/finanse/artykuly/8606426,najwieksze-zaskoczenia-rynki-finansowe-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 05:38:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/N0_ktkuTURBXy9jMzc3MGE4MS1jOGM3LTQzNDgtOTZmMy1hNjQ0ZDE5MTRmODguanBlZ5GTBc0BHcyg" />Bank Standard Chartered przedstawił kilka potencjalnych niespodziewanych wydarzeń, których prawdopodobieństwo wystąpienia w 2023 roku jest „niedoszacowane” przez rynek.

## Konflikt w Cieśninie Tajwańskiej. Ta grafika pokazuje, jak wielką przewagę militarną mają Chiny
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8606027,tajwan-chiny-uzbrojenie-porownanie.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8606027,tajwan-chiny-uzbrojenie-porownanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 05:31:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ELOktkuTURBXy9lYWM2NjNiOC00NWYzLTRkMzAtOTY3YS1iNjY4Y2RmODg0NjYuanBlZ5GTBc0BHcyg" />W ostatnim czasie Tajwan raportował gwałtowny wzrost liczby chińskich myśliwców naruszających strefę identyfikacji obrony powietrznej. Chiny nigdy nie wykluczyły możliwości inwazji na wyspę i nadal wzmacniają w tym celu swoje zdolności militarne. Jakim uzbrojeniem dysponuje dziś Państwo Środka i Tajwan?

## Wszystko kosztuje, a prąd w szczególności. Jak na nim oszczędzać?
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8605928,prad-jak-oszczedzac-jak-obnizyc-rachunki.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8605928,prad-jak-oszczedzac-jak-obnizyc-rachunki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 05:31:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wedktkuTURBXy9mNDczNzUyMy00NWU1LTQ5MDYtOGZkNi05ZjBlOWFjNWIyODMuanBlZ5GTBc0BHcyg" />Ceny prądu w całej Europie szaleją. Rachunki, które musimy płacić, są większe nawet o kilkaset procent w stosunku do tych sprzed roku czy dwóch, a zaznaczyć trzeba, że już w poprzednich latach energia drożała. Podpowiadamy, co zrobić, aby obniżyć swoje opłaty za energię.

## Kryzys na szwedzkim rynku nieruchomości trwa w najlepsze. Ceny domów lecą w dół
 - [https://forsal.pl/nieruchomosci/artykuly/8605967,spadki-cen-mieszkan-i-domow-kryzys-na-rynku-nieruchomosci-w-szwecji.html](https://forsal.pl/nieruchomosci/artykuly/8605967,spadki-cen-mieszkan-i-domow-kryzys-na-rynku-nieruchomosci-w-szwecji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-12 05:27:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/N00ktkuTURBXy9mZDQ1NjE2Mi01OTFiLTRkY2ItOTIwZC1iMzc1YmM0N2QzNTguanBlZ5GTBc0BHcyg" />W listopadzie ceny nieruchomości w Szwecji pogłębiły swój spadek. Wpływ na osłabienie rynku, który już teraz jest jednym z najsłabszych wśród krajów rozwiniętych, miały wysokie stopy procentowe.


# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Wojna w Ukrainie. Rosjanie zaczynają wcielać kobiety do wojska
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/wojna-w-ukrainie-rosjanie-zaczynaja-wcielac-kobiety-do-wojska/](https://www.polsatnews.pl/wiadomosc/2022-12-12/wojna-w-ukrainie-rosjanie-zaczynaja-wcielac-kobiety-do-wojska/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 20:16:00+00:00

Rosjanie starają się uzupełnić straty poniesione na wojnie z Ukrainą. W tym celu do wojska wcielane są już nawet kobiety.

## Peru. Gwałtowne zamieszki w całym kraju. Zwolennicy byłego szefa rządu chcą jego zwolnienia
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/peru-gwaltowne-zamieszki-w-calym-kraju/](https://www.polsatnews.pl/wiadomosc/2022-12-12/peru-gwaltowne-zamieszki-w-calym-kraju/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 18:13:00+00:00

Dwie osoby zginęły, a co najmniej pięć zostało rannych w Peru, podczas narastających protestów. Peruwiańczycy demonstrują sprzeciw polityce nowej prezydent Dinie Boluarte oraz aresztowaniu byłego szefa państwa i rządu Pedro Castillo.

## MŚ w Katarze. Kolejna nagła śmierć dziennikarza
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/ms-w-katarze-kolejna-nagla-smierc-dziennikarza/](https://www.polsatnews.pl/wiadomosc/2022-12-12/ms-w-katarze-kolejna-nagla-smierc-dziennikarza/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 17:42:00+00:00

Pochodzący z Kataru dziennikarz i fotoreporter zmarł nagle podczas odbywającego się w tym kraju mundialu. To drugi taki przypadek w czasie trwających mistrzostw świata.

## Wojna w Ukrainie. Ojciec błagał syna, by nie jechał na wojnę z Ukrainą. "To nie jest nasza wojna"
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/wojna-w-ukrainie-ojciec-blagal-syna-by-nie-jechal-na-wojne-z-ukraina-to-nie-jest-nasza-wojna/](https://www.polsatnews.pl/wiadomosc/2022-12-12/wojna-w-ukrainie-ojciec-blagal-syna-by-nie-jechal-na-wojne-z-ukraina-to-nie-jest-nasza-wojna/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 16:51:00+00:00

To nie jest nasza wojna. To nie jest wojna wyzwoleńcza - tłumaczył Rosjanin, swojemu synowi, który wybierał się na wojnę w Ukrainie. Opowiadał także, o szczegółach działania Rosjan na froncie i przygotowaniu poborowych.

## Unia Europejska chce sankcji dla Iranu. "Teheran musi zrozumieć czemu sprzeciwia się UE"
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/unia-europejska-chce-sankcja-dla-iranu-teheran-musi-zrozumiec-czemu-sprzeciwia-sie-ue/](https://www.polsatnews.pl/wiadomosc/2022-12-12/unia-europejska-chce-sankcja-dla-iranu-teheran-musi-zrozumiec-czemu-sprzeciwia-sie-ue/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 16:15:00+00:00

- Iran musi zrozumieć czemu sprzeciwia się wspólnota europejska. Wspieramy żądania kobiet w Iranie - powiedział w poniedziałek Josep Borrell, szef unijnej dyplomacji, zapowiadając unijny pakiet sankcji dla tego kraju.

## Urodziła na pokładzie samolotu. Kobieta nie wiedziała, że jest w ciąży
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/urodzila-na-pokladzie-samolotu-kobieta-nie-wiedziala-ze-jest-w-ciazy/](https://www.polsatnews.pl/wiadomosc/2022-12-12/urodzila-na-pokladzie-samolotu-kobieta-nie-wiedziala-ze-jest-w-ciazy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 16:08:00+00:00

Kobieta z Ekwadoru urodziła dziecko na pokładzie samolotu holenderskich linii lotniczych KLM. Sytuacja, do której doszło kilka tysięcy metrów nad ziemią, zaskoczyła nie tylko personel, ale również samą matkę, która nie zdawała sobie sprawy, że jest w ciąży.

## Rosja. Aleksiej Nawalny: Jak złamać kogoś, kogo nie wolno bić? Wrzucić  mu do celi bezdomnego
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/aleksiej-nawalny/](https://www.polsatnews.pl/wiadomosc/2022-12-12/aleksiej-nawalny/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 13:55:00+00:00

Uwięziony rosyjski opozycjonista Aleksiej Nawalny poinformował, że władze więzienia, w którym go umieszczono, chcą go złamać. W tym celu administracja skierowała do jego celi bezdomnego. Połączenie gróźb i krzyków sprawiło, że się umył - napisał Nawalny. Czuję się jak dziwna nauczycielka - dodał.

## Andrzej Duda: Dziękuję za decyzję o wysłaniu do Polski systemów Patriot
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/andrzej-duda-dziekuje-za-decyzje-o-wyslaniu-do-polski-systemow-patriot/](https://www.polsatnews.pl/wiadomosc/2022-12-12/andrzej-duda-dziekuje-za-decyzje-o-wyslaniu-do-polski-systemow-patriot/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 13:28:00+00:00

- Jestem w Berlinie także po to, by na ręce pana prezydent złożyć podziękowanie dla władz niemieckich za decyzję o wysłaniu do ochrony Polski systemów Patriot - powiedział Andrzej Duda. Prezydent Polski spotkał się w poniedziałek z prezydentem Niemiec Frankiem-Walterem Steinmeierem.

## Ukraińcy zatrzymali rosyjskie agentki. Wyznaczały szkoły i szpitale położnicze jako cele ataków
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/ukraincy-zatrzymali-rosyjskie-agentki-wyznaczaly-szkoly-i-szpitale-poloznicze-jako-cele-atakow/](https://www.polsatnews.pl/wiadomosc/2022-12-12/ukraincy-zatrzymali-rosyjskie-agentki-wyznaczaly-szkoly-i-szpitale-poloznicze-jako-cele-atakow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 13:14:00+00:00

Służba Bezpieczeństwa Ukrainy zatrzymała trzy kobiety, które współpracowały z Rosją. Kolaborantki wchodziły w skład rozbudowanej siatki wywiadowczej Kremla. Agentura przekazywała dane o potencjalnych celach, które Rosja może atakować. Były to np. szkoły, szpitale położnicze czy domy studenckie w obwodzie donieckim.

## Wielka Brytania: Lód załamał się po dziećmi. Nie żyje trzech chłopców
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/wielka-brytania-lod-zalamal-sie-po-dziecmi-nie-zyje-trzech-chlopcow/](https://www.polsatnews.pl/wiadomosc/2022-12-12/wielka-brytania-lod-zalamal-sie-po-dziecmi-nie-zyje-trzech-chlopcow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 12:58:00+00:00

Trzech chłopców nie żyje, a czwarty walczy o życie po tragicznym zdarzeniu w miejscowości Kingshurst w pobliżu Birmingham. Pod bawiącymi się na jeziorze dziećmi załamał się lód. Służby cały czas prowadzą poszukiwania. Możliwe, że nad wodą bawiło się sześcioro dzieci.

## Wojna w Ukrainie. Wiktor But skarży się na warunki w więzieniu w USA. Miał nie dostać... truskawek
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/wojna-w-ukrainie-wiktor-but-skarzy-sie-na-warunki-w-wiezieniu-w-usa-mial-nie-dostac-truskawek/](https://www.polsatnews.pl/wiadomosc/2022-12-12/wojna-w-ukrainie-wiktor-but-skarzy-sie-na-warunki-w-wiezieniu-w-usa-mial-nie-dostac-truskawek/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 12:42:00+00:00

Ani kopru, ani truskawek miał nie dostawać w więzieniu w USA Wiktor But, który na warunki w amerykańskiej celi skarżył się w rosyjskiej telewizji. Przekazał, że miał doznać urazu w czasie odbywania wyroku.

## Holandia: Podejrzani przenieśli rannego w wypadku mężczyznę. Ofiara nie żyje
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/holandia-podejrzani-przeniesli-rannego-w-wypadku-mezczyzne-ofiara-nie-zyje/](https://www.polsatnews.pl/wiadomosc/2022-12-12/holandia-podejrzani-przeniesli-rannego-w-wypadku-mezczyzne-ofiara-nie-zyje/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 12:23:00+00:00

Policja odnalazła 31-latka w miejscowości Walsorden w Holandii. Jak ustalili funkcjonariusze, mężczyzna został najprawdopodobniej potrącony przez quada. Następnie dwóch podejrzanych miało przenieść rannego na jedną z ulic. Tam, mimo udzielonej przez ratowników medycznych pomocy, 31-latek zmarł.

## Atak zimy w Europie. Kontynent zasypany śniegiem
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/atak-zimy-w-europie-kontynent-zasypany-sniegiem/](https://www.polsatnews.pl/wiadomosc/2022-12-12/atak-zimy-w-europie-kontynent-zasypany-sniegiem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 11:23:00+00:00

Obfite opady śniegu dotarły wraz z początkiem tygodnia do większości krajów Starego Kontynentu. Biały puch sparaliżował m.in. pracę londyńskich lotnisk i uwięził słowackich kierowców w autach na autostradach. Zaś Francuzi ataku zimy dopiero się spodziewają.

## Wielka Brytania: Grupa uczniów utknęła na lotnisku pod Londynem
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/wielka-brytania-grupa-polskich-uczniow-utknela-na-lotnisku-pod-londynem/](https://www.polsatnews.pl/wiadomosc/2022-12-12/wielka-brytania-grupa-polskich-uczniow-utknela-na-lotnisku-pod-londynem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 10:20:00+00:00

Uczniowie warszawskiego liceum utknęli na lotnisku Stansted pod Londynem. Ich niedzielny lot odwołano z powodu złych warunków atmosferycznych. Grupa koczuje na lotnisku od kilkunastu godzin.

## Koronawirus. Wirusolog z Wuhan prowadzi badania w jaskini z milionami nietoperzy
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/wirusolog-z-wuhan-prowadzi-badania-w-jaskini-z-milionami-nietoperzy/](https://www.polsatnews.pl/wiadomosc/2022-12-12/wirusolog-z-wuhan-prowadzi-badania-w-jaskini-z-milionami-nietoperzy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 09:41:00+00:00

Wirusolog dr Peter Daszak, który sfinansował powstanie laboratorium w Wuhan, a następnie miał wyciszać teorie o wycieku wirusa, teraz prowadzi badania nad pochodzeniem SARS-CoV-2. Daszak wraz z grupą naukowców bada nietoperze. W tym celu przebywa w jednej z jaskiń w Tajlandii, gdzie żyje około 2,5 mln tych ssaków.

## Wiceprzewodnicząca PE oskarżona o korupcję. Policja znalazła worki z gotówką
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/wiceprzewodniczaca-pe-oskarzona-o-korupcje-policja-znalazla-worki-z-gotowka/](https://www.polsatnews.pl/wiadomosc/2022-12-12/wiceprzewodniczaca-pe-oskarzona-o-korupcje-policja-znalazla-worki-z-gotowka/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 09:06:00+00:00

Wiceprzewodnicząca Parlamentu Europejskiego Eva Kaili została oskarżona o korupcję po tym, jak belgijska policja znalazła w jej domu worki z gotówką.

## Niemieckie media: Rosną obawy z powodu Rosji. Politycy apelują o budowę schronów
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/niemieckie-media-rosna-obawy-z-powodu-rosji-politycy-apeluja-o-budowe-schronow/](https://www.polsatnews.pl/wiadomosc/2022-12-12/niemieckie-media-rosna-obawy-z-powodu-rosji-politycy-apeluja-o-budowe-schronow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 08:50:00+00:00

W Niemczech coraz więcej polityków domaga się od władz stworzenia nowych schronów w związku z zagrożeniami ze strony Rosji. Te, które są w kraju, mogłyby pomieścić jedynie 500 tys. ludzi.

## Prezydent Turcji: Kiedy mówisz "Tajfun", Grek jest przerażony
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/prezydent-turcji-kiedy-mowisz-tajfun-grek-jest-przerazony/](https://www.polsatnews.pl/wiadomosc/2022-12-12/prezydent-turcji-kiedy-mowisz-tajfun-grek-jest-przerazony/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 08:27:00+00:00

Prezydent Turcji Recep Tayyip Erdogan grozi Atenom pociskiem jeśli nie zachowają spokoju. Kilka dni temu turecki minister spraw zagranicznych zagroził Grecji inwazją.

## Rosyjski żołnierz mówi, po co przyjechał do Ukrainy: Walczę z Polakami
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/rosyjski-zolnierz-w-niewoli-opowiada-po-co-przyjechal-do-ukrainy-walcze-z-polakami/](https://www.polsatnews.pl/wiadomosc/2022-12-12/rosyjski-zolnierz-w-niewoli-opowiada-po-co-przyjechal-do-ukrainy-walcze-z-polakami/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 07:41:00+00:00

Rosyjski żołnierz schwytany przez ukraińskich obrońców w Donbasie wyjaśnił, dlaczego przyjechał na wojnę w Ukrainie. - Walczę tutaj z Polakami - mówi. Ukraińcy nie dowierzają i dopytują dlaczego. - Bo chcą zabrać waszą ziemię - odpowiada Rosjanin.

## Strzelanina w Rzymie. Nie żyje przyjaciółka Giorgii Meloni
 - [https://www.polsatnews.pl/wiadomosc/2022-12-12/strzelanina-w-rzymie-nie-zyje-przyjaciolka-giorgii-meloni/](https://www.polsatnews.pl/wiadomosc/2022-12-12/strzelanina-w-rzymie-nie-zyje-przyjaciolka-giorgii-meloni/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-12 07:34:00+00:00

W niedzielę na przedmieściach Rzymu doszło do strzelaniny, w wyniku której zginęły trzy kobiety uczestniczące w spotkaniu wspólnoty mieszkaniowej. Jedną z ofiar była przyjaciółka premier Włoch. Słowo sprawiedliwość nigdy nie może być zastosowane do tej sprawy. Bo nie wypada tak umierać - napisała na Facebooku Giorgia Meloni.


# Source:Reuters - All, URL:https://www.reutersagency.com/feed/?taxonomy=best-topics&post_type=best, language:en-US

## Reuters reveals Microsoft seeks to settle EU antitrust concerns over Teams
 - [https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-microsoft-seeks-to-settle-eu-antitrust-concerns-over-teams/](https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-microsoft-seeks-to-settle-eu-antitrust-concerns-over-teams/)
 - RSS feed: https://www.reutersagency.com/feed/?taxonomy=best-topics&post_type=best
 - date published: 2022-12-12 18:09:00+00:00

<p>Reuters exclusively reported Microsoft is seeking to address European Union (EU) antitrust concerns about its business practices prompted by a [&#8230;]</p>
<p>The post <a href="https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-microsoft-seeks-to-settle-eu-antitrust-concerns-over-teams/" rel="nofollow">Reuters reveals Microsoft seeks to settle EU antitrust concerns over Teams</a> appeared first on <a href="https://www.reutersagency.com/en/" rel="nofollow">Reuters News Agency</a>.</p>

## Reuters reveals U.S. Justice Dept is split over charging Binance as crypto world falters
 - [https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-u-s-justice-dept-is-split-over-charging-binance-as-crypto-world-falters/](https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-u-s-justice-dept-is-split-over-charging-binance-as-crypto-world-falters/)
 - RSS feed: https://www.reutersagency.com/feed/?taxonomy=best-topics&post_type=best
 - date published: 2022-12-12 16:57:00+00:00

<p>Reuters exclusively revealed how splits between U.S. Department of Justice prosecutors are delaying the conclusion of a long-running criminal investigation [&#8230;]</p>
<p>The post <a href="https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-u-s-justice-dept-is-split-over-charging-binance-as-crypto-world-falters/" rel="nofollow">Reuters reveals U.S. Justice Dept is split over charging Binance as crypto world falters</a> appeared first on <a href="https://www.reutersagency.com/en/" rel="nofollow">Reuters News Agency</a>.</p>

## Reuters reveals Air India nears historic order for up to 500 jets
 - [https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-air-india-nears-historic-order-for-up-to-500-jets/](https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-air-india-nears-historic-order-for-up-to-500-jets/)
 - RSS feed: https://www.reutersagency.com/feed/?taxonomy=best-topics&post_type=best
 - date published: 2022-12-12 16:13:00+00:00

<p>Reuters exclusively reported Air India is close to placing landmark orders for as many as 500 jetliners worth tens of [&#8230;]</p>
<p>The post <a href="https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-air-india-nears-historic-order-for-up-to-500-jets/" rel="nofollow">Reuters reveals Air India nears historic order for up to 500 jets</a> appeared first on <a href="https://www.reutersagency.com/en/" rel="nofollow">Reuters News Agency</a>.</p>

## Reuters reveals Zeekr, a premium Geely electric car brand, seeks over $1 billion in U.S. IPO
 - [https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-zeekr-a-premium-geely-electric-car-brand-seeks-over-1-billion-in-u-s-ipo/](https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-zeekr-a-premium-geely-electric-car-brand-seeks-over-1-billion-in-u-s-ipo/)
 - RSS feed: https://www.reutersagency.com/feed/?taxonomy=best-topics&post_type=best
 - date published: 2022-12-12 15:15:00+00:00

<p>Reuters exclusively reported Zeekr, one of Chinese automaker Geely’s upmarket electric car brands, has confidentially filed for a U.S. initial [&#8230;]</p>
<p>The post <a href="https://www.reutersagency.com/en/reutersbest/article/reuters-reveals-zeekr-a-premium-geely-electric-car-brand-seeks-over-1-billion-in-u-s-ipo/" rel="nofollow">Reuters reveals Zeekr, a premium Geely electric car brand, seeks over $1 billion in U.S. IPO</a> appeared first on <a href="https://www.reutersagency.com/en/" rel="nofollow">Reuters News Agency</a>.</p>


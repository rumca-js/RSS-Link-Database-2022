# Source:Washington Examiner - Tech, URL:https://feeds.feedburner.com/dcexaminer/tech, language:en-US

## FTX founder Sam Bankman-Fried arrested in Bahamas
 - [https://www.washingtonexaminer.com/policy/technology/ftx-founder-sam-bankman-fried-arrested-in-bahamas](https://www.washingtonexaminer.com/policy/technology/ftx-founder-sam-bankman-fried-arrested-in-bahamas)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/tech
 - date published: 2022-12-12 23:51:30+00:00

Crypto exchange founder Sam Bankman-Fried was arrested by officials in the Bahamas after the United States filed criminal charges against him and requested his extradition.


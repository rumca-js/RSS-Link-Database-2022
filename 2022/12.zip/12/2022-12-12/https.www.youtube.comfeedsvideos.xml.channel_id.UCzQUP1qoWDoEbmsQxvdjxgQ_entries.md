# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## The Kind of Girl Stavros Halkias is Looking For
 - [https://www.youtube.com/watch?v=vQCCU1Gtgao](https://www.youtube.com/watch?v=vQCCU1Gtgao)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-12-13 00:00:00+00:00

Taken from JRE #1909 w/Stavros Halkias:
https://open.spotify.com/episode/53j4SZe2AbdW44hCKxMRTJ?si=1e0604ddfb9442a5

## The Link Between Sports and War
 - [https://www.youtube.com/watch?v=jdDClU9rgac](https://www.youtube.com/watch?v=jdDClU9rgac)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-12-13 00:00:00+00:00

Taken from JRE #1909 w/Stavros Halkias:
https://open.spotify.com/episode/53j4SZe2AbdW44hCKxMRTJ?si=ff567e05b1cd44e0


# Source:Washington Examiner - politics, URL:https://feeds.feedburner.com/dcexaminer/Politics, language:en-US

## Child tax credit fans gain momentum in GOP infighting over economics
 - [https://www.washingtonexaminer.com/policy/economy/child-tax-credit-gains-momentum-gop-infighting](https://www.washingtonexaminer.com/policy/economy/child-tax-credit-gains-momentum-gop-infighting)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2022-12-12 09:00:32+00:00

A long-running intra-GOP debate over the child tax credit is coming back to the political foreground, pitting supply-siders against more populist, family-focused lawmakers.

## Child tax credit fans gain momentum in GOP infighting over economics
 - [https://www.washingtonexaminer.com/restoring-america/courage-strength-optimism/child-tax-credit-gains-momentum-gop-infighting](https://www.washingtonexaminer.com/restoring-america/courage-strength-optimism/child-tax-credit-gains-momentum-gop-infighting)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2022-12-12 09:00:32+00:00

A long-running intra-GOP debate over the child tax credit is coming back to the political foreground, pitting supply-siders against more populist, family-focused lawmakers.


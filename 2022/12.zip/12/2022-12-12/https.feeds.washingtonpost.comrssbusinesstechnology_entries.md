# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Former Twitter official leaves home after threats unleashed by Musk attacks
 - [https://www.washingtonpost.com/technology/2022/12/12/musk-twitter-harass-yoel-roth/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/12/12/musk-twitter-harass-yoel-roth/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-12-12 19:36:50+00:00

Yoel Roth, Twitter’s former head of trust and safety, left his home after criticism from Musk unleased a torrent of online harassment.

## Sam Bankman-Fried arrested in Bahamas on U.S. request
 - [https://www.washingtonpost.com/technology/2022/12/12/bankman-fried-arrested/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/12/12/bankman-fried-arrested/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-12-12 19:35:38+00:00

FTX and Bankman-Fried have been under investigation by U.S. law enforcement agencies after his company imploded.

## The best video games of 2022
 - [https://www.washingtonpost.com/video-games/2022/12/12/best-video-games-2022/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2022/12/12/best-video-games-2022/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-12-12 16:44:38+00:00

From ‘Elden Ring’ to 'God of War Ragnarok' to even Wordle, 2022 was a great year for games. Here’s The Washington Post's list of the very best.

## Elon Musk uses QAnon tactic in criticizing former Twitter safety chief
 - [https://www.washingtonpost.com/technology/2022/12/12/musk-child-porn-qanon/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/12/12/musk-child-porn-qanon/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-12-12 06:00:00+00:00

Musk used a misleading tweet to imply over the weekend that Twitter's former trust and safety head had been lax about pursuing reports of child porn on the site.

## Cringe quiz: Are you fluent in Gen-Z office speak?
 - [https://www.washingtonpost.com/technology/interactive/2022/gen-z-work-slang-quiz/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/interactive/2022/gen-z-work-slang-quiz/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-12-12 05:00:21+00:00

Take our quiz to find out how well you understand emojis, slang and reactions that your Generation Z colleagues use.

## Gen Z came to ‘slay.’ Their bosses don’t know what that means.
 - [https://www.washingtonpost.com/technology/2022/12/12/gen-z-work-emojis/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/12/12/gen-z-work-emojis/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-12-12 05:00:03+00:00

Gen Z’s use of emojis, slang and punctuation is confusing older colleagues as workplace communications are increasingly online.


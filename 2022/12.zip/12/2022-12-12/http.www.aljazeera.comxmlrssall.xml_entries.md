# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Colombia, ELN rebels conclude first round of ‘successful’ talks
 - [https://www.aljazeera.com/news/2022/12/12/colombia-eln-rebels-conclude-first-round-of-successful-talks](https://www.aljazeera.com/news/2022/12/12/colombia-eln-rebels-conclude-first-round-of-successful-talks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 23:05:24+00:00

While no ceasefire was reached, two sides agree to provide &#039;emergency care&#039; in violence-hit regions starting next month.

## US announces sanctions against son of Zimbabwean president
 - [https://www.aljazeera.com/news/2022/12/12/us-announces-sanctions-against-son-of-zimbabwean-president](https://www.aljazeera.com/news/2022/12/12/us-announces-sanctions-against-son-of-zimbabwean-president)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 22:19:09+00:00

The US Treasury Department has accused Emmerson Mnangagwa Jr of ties to sanctioned businessman Kudakwashe Tagwirei.

## CVS, Walgreens finalise $10bn in deals to settle opioid lawsuits
 - [https://www.aljazeera.com/economy/2022/12/12/cvs-walgreens-finalise-10bn-in-deals-to-settle-opioid-lawsuits](https://www.aljazeera.com/economy/2022/12/12/cvs-walgreens-finalise-10bn-in-deals-to-settle-opioid-lawsuits)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 22:10:31+00:00

The deals are among the largest in a wave of proposed and finalised settlements over opioids in recent years.

## Asylum seeker crossings into US city of El Paso spike on weekend
 - [https://www.aljazeera.com/news/2022/12/12/asylum-seeker-crossings-into-us-city-of-el-paso-spike-on-weekend](https://www.aljazeera.com/news/2022/12/12/asylum-seeker-crossings-into-us-city-of-el-paso-spike-on-weekend)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 22:06:33+00:00

Critics warn looming end of Title 42 immigration policy could lead to more crossings along the US-Mexico border.

## Photos: Mexico’s Guadalupe pilgrimage draws millions of devotees
 - [https://www.aljazeera.com/gallery/2022/12/12/photos-mexicos-guadalupe-pilgrimage-draws-millions-of-devotees](https://www.aljazeera.com/gallery/2022/12/12/photos-mexicos-guadalupe-pilgrimage-draws-millions-of-devotees)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 22:01:40+00:00

The Basilica of Our Lady of Guadalupe is the second-most-visited Catholic shrine in the world after St Peter&#039;s.

## G7 pledges to meet Ukraine’s ‘urgent’ air defence requirements
 - [https://www.aljazeera.com/news/2022/12/12/g7-pledges-to-meet-ukraines-urgent-air-defence-requirements](https://www.aljazeera.com/news/2022/12/12/g7-pledges-to-meet-ukraines-urgent-air-defence-requirements)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 21:44:12+00:00

Zelenskyy also appeals to G7 for tanks, artillery and long-range weapons as Russia maintains barrage of attacks.

## Oath Keepers plotted to use force on January 6: US prosecutor
 - [https://www.aljazeera.com/news/2022/12/12/oath-keepers-plotted-to-use-force-on-january-6-us-prosecutor](https://www.aljazeera.com/news/2022/12/12/oath-keepers-plotted-to-use-force-on-january-6-us-prosecutor)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 21:30:37+00:00

Prosecutor tells US jury that far-right group members plotted to stop transfer of power and keep Donald Trump in office.

## China launches suit against US at WTO over chip curbs: Report
 - [https://www.aljazeera.com/news/2022/12/12/267](https://www.aljazeera.com/news/2022/12/12/267)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 21:06:39+00:00

In October the US published a sweeping set of export controls aimed at kneecapping China&#039;s semiconductor sector.

## EU sanctions Iran over protest crackdown and Russia drone sales
 - [https://www.aljazeera.com/news/2022/12/12/eu-sanctions-iran-over-protest-crackdown-and-russia-drone-sales](https://www.aljazeera.com/news/2022/12/12/eu-sanctions-iran-over-protest-crackdown-and-russia-drone-sales)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 20:53:08+00:00

Russia stands accused of sending Iranian-made drones over Ukraine to strike at power plants, other key infrastructure.

## Argentina fans party in Qatar ahead of World Cup semifinal
 - [https://www.aljazeera.com/gallery/2022/12/12/argentina-fans-party-in-qatar](https://www.aljazeera.com/gallery/2022/12/12/argentina-fans-party-in-qatar)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 20:25:01+00:00

Fans gathered at Doha&#039;s Corniche in support of Argentina&#039;s football team ahead of the semifinal.

## All eyes on Messi as Argentina train ahead of Croatia clash
 - [https://www.aljazeera.com/sports/2022/12/12/argentina-messi-training-world-cup-semifinal-croatia](https://www.aljazeera.com/sports/2022/12/12/argentina-messi-training-world-cup-semifinal-croatia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 19:51:40+00:00

Messi set to become joint record appearance-maker in World Cup history when Argentina take on Croatia in the semifinal.

## Photos: NASA’s Orion capsule visits Moon, returns to Earth
 - [https://www.aljazeera.com/gallery/2022/12/12/photos-nasa-orion-capsule-returns-to-earth](https://www.aljazeera.com/gallery/2022/12/12/photos-nasa-orion-capsule-returns-to-earth)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 19:38:05+00:00

The splashdown ends a 25-day mission less than a week after the capsule passed about 127km above the Moon.

## What is behind the violence between Serbia and Kosovo?
 - [https://www.aljazeera.com/program/inside-story/2022/12/12/what-is-behind-the-violence-between-serbia-and-kosovo](https://www.aljazeera.com/program/inside-story/2022/12/12/what-is-behind-the-violence-between-serbia-and-kosovo)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 19:21:54+00:00

Tensions rise in the Balkans with attacks on police, mass police resignations and delayed elections.

## US city removes last public Confederate statue
 - [https://www.aljazeera.com/news/2022/12/12/us-city-removes-last-public-confederate-statue](https://www.aljazeera.com/news/2022/12/12/us-city-removes-last-public-confederate-statue)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 18:50:25+00:00

Mayor of Richmond, Virginia, ordered Confederate symbols removed amid 2020 racial justice protests across US.

## EU could face gas shortage next year, IEA warns
 - [https://www.aljazeera.com/news/2022/12/12/europe-could-face-gas-shortage-next-year-iea-warns](https://www.aljazeera.com/news/2022/12/12/europe-could-face-gas-shortage-next-year-iea-warns)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 17:36:43+00:00

The EU may avoid an energy crisis this year but needs to take action to prevent a shortage next year, IEA and EU say.

## Frank Soo: English football’s history-maker
 - [https://www.aljazeera.com/features/2022/12/12/frank-soo-english-footballs-history-maker](https://www.aljazeera.com/features/2022/12/12/frank-soo-english-footballs-history-maker)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 17:20:14+00:00

When footballer Frank Soo stepped out at Ninian Park in 1942, he became the first non-white player to represent England.

## Nigerian government rejects report on military abortion programme
 - [https://www.aljazeera.com/news/2022/12/12/nigerian-government-rejects-report-on-military-abortion-programme](https://www.aljazeera.com/news/2022/12/12/nigerian-government-rejects-report-on-military-abortion-programme)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 17:07:34+00:00

Nigeria&#039;s government denounced a Reuters report of clandestine abortion scheme as a &#039;body of insults&#039; against Nigerians.

## Putin cancels annual year-end news conference: Kremlin
 - [https://www.aljazeera.com/news/2022/12/12/russias-putin-cancels-annual-year-end-news-conference-kremlin](https://www.aljazeera.com/news/2022/12/12/russias-putin-cancels-annual-year-end-news-conference-kremlin)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 17:06:48+00:00

Break in tradition comes as Russia&#039;s war in Ukraine falters and its economy struggles under the weight of sanctions.

## Croatia ‘can hurt’ Argentina in semifinal, warns coach Scaloni
 - [https://www.aljazeera.com/news/2022/12/12/croatia-can-hurt-argentina-in-semifinal-warns-coach-scaloni](https://www.aljazeera.com/news/2022/12/12/croatia-can-hurt-argentina-in-semifinal-warns-coach-scaloni)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 16:52:22+00:00

Ahead of Tuesday&#039;s match, Scaloni and his team reveal cautious optimism.

## El Salvador crackdown could prompt gangs to ‘adapt and reshuffle’
 - [https://www.aljazeera.com/news/2022/12/12/el-salvador-crackdown-could-prompt-gangs-to-adapt-and-reshuffle](https://www.aljazeera.com/news/2022/12/12/el-salvador-crackdown-could-prompt-gangs-to-adapt-and-reshuffle)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 16:32:24+00:00

The government’s eight-month state of exception has seen civil liberties suspended and tens of thousands imprisoned.

## Can history-makers Morocco win the World Cup?
 - [https://www.aljazeera.com/sports/2022/12/12/can-morocco-win-the-world-cup](https://www.aljazeera.com/sports/2022/12/12/can-morocco-win-the-world-cup)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 16:12:32+00:00

Fairytale run to the semi-finals has seen the Atlas Lions create footballing history but now France await.

## ‘Hurting people’: The ‘cover-up teams’ operating on the US border
 - [https://www.aljazeera.com/features/2022/12/12/the-cover-up-teams-operating-on-the-us-border](https://www.aljazeera.com/features/2022/12/12/the-cover-up-teams-operating-on-the-us-border)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 15:58:49+00:00

When Border Patrol pursuits of migrant vehicles have led to accidents, an opaque unit has been among those responding.

## Hard bargains, no lectures: What Africa needs at Biden’s summit
 - [https://www.aljazeera.com/opinions/2022/12/12/hard-bargains-no-lectures-what-africa-needs-at-bidens-summit](https://www.aljazeera.com/opinions/2022/12/12/hard-bargains-no-lectures-what-africa-needs-at-bidens-summit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 15:45:26+00:00

The US knows what it wants from Africa — it is not democracy. Does Africa know what it wants from the US?

## Chad releases 139 detainees from protest crackdown in October
 - [https://www.aljazeera.com/news/2022/12/12/chad-releases-139-protesters-related-to-october-deadly-crackdown](https://www.aljazeera.com/news/2022/12/12/chad-releases-139-protesters-related-to-october-deadly-crackdown)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 15:28:52+00:00

The move comes a week after more than 260 people were handed jail terms of between two to three years.

## Macron postpones France’s pension overhaul denounced by unions
 - [https://www.aljazeera.com/news/2022/12/12/macron-postpones-frances-pension-overhaul-denounced-by-unions](https://www.aljazeera.com/news/2022/12/12/macron-postpones-frances-pension-overhaul-denounced-by-unions)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 14:55:14+00:00

The French president delays the announcement of his divisive pension reform plans from this week to January.

## Maria Telkes: Why Google honours her today
 - [https://www.aljazeera.com/news/2022/12/12/maria-telkes-why-google-honours-her-today](https://www.aljazeera.com/news/2022/12/12/maria-telkes-why-google-honours-her-today)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 14:43:07+00:00

Telkes was an innovative scientist recognised for her contributions to the solar energy technologies.

## Guinea ex-dictator Camara denies 2009 massacre role in court
 - [https://www.aljazeera.com/news/2022/12/12/guinea-ex-dictator-denies-role-at-2009-massacre-trial](https://www.aljazeera.com/news/2022/12/12/guinea-ex-dictator-denies-role-at-2009-massacre-trial)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 14:20:37+00:00

The former Guinean strongman is being charged alongside 10 other officials for their roles in the gruesome massacre.

## LGBTQ communities in the US face ‘rising threat of violence’
 - [https://www.aljazeera.com/news/2022/12/12/lgbtq-communities-in-the-us-face-rising-threat-of-violence](https://www.aljazeera.com/news/2022/12/12/lgbtq-communities-in-the-us-face-rising-threat-of-violence)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 14:00:30+00:00

As attacks mount, advocates say the government must do more to combat hate speech and gun crimes.

## Deadly attack on Kabul hotel popular with Chinese nationals
 - [https://www.aljazeera.com/news/2022/12/12/deadly-attack-on-kabul-hotel-popular-with-chinese-nationals](https://www.aljazeera.com/news/2022/12/12/deadly-attack-on-kabul-hotel-popular-with-chinese-nationals)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 13:36:59+00:00

At least three attackers killed by security forces after they open fire at the hotel in central Kabul, says an official.

## Heavy snow disrupts UK travel after this year’s coldest night
 - [https://www.aljazeera.com/news/2022/12/12/heavy-snow-disrupts-uk-travel-after-this-years-coldest-night](https://www.aljazeera.com/news/2022/12/12/heavy-snow-disrupts-uk-travel-after-this-years-coldest-night)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 13:09:38+00:00

Two coal plants are on standby while heavy snowfall blankets parts of the UK, disrupting transportation.

## Why does India still use and trade asbestos?
 - [https://www.aljazeera.com/news/2022/12/12/why-does-india-continue-trading-asbestos](https://www.aljazeera.com/news/2022/12/12/why-does-india-continue-trading-asbestos)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 13:05:52+00:00

Russia is among the nations that supply India with asbestos, a substance banned in several countries.

## England beat hosts Pakistan to clinch cricket Test series
 - [https://www.aljazeera.com/news/2022/12/12/england-beat-pakistan-to-clinch-cricket-test-series](https://www.aljazeera.com/news/2022/12/12/england-beat-pakistan-to-clinch-cricket-test-series)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 12:14:04+00:00

England snatch a 26-run victory against Pakistan in the second Test in Multan to take an unbeatable 2-0 lead.

## Iran blacklists more EU, UK officials in tit-for-tat move
 - [https://www.aljazeera.com/news/2022/12/12/iran-blacklists-more-eu-uk-officials-in-tit-for-tat-move](https://www.aljazeera.com/news/2022/12/12/iran-blacklists-more-eu-uk-officials-in-tit-for-tat-move)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 11:54:23+00:00

Tehran’s new sanctions deal with the assassination of Iran’s top general Qassem Soleimani by the US.

## Analysis: Countdown to perdition for SA’s Ramaphosa or 2nd term?
 - [https://www.aljazeera.com/features/2022/12/12/analysis-countdown-to-perdition-for-sas-ramaphosa-or-2nd-term](https://www.aljazeera.com/features/2022/12/12/analysis-countdown-to-perdition-for-sas-ramaphosa-or-2nd-term)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 11:36:10+00:00

President Ramaphosa could survive an impeachment vote this week but seeking re-election could be harder.

## Released Russian arms dealer Bout joins ultranationalist party
 - [https://www.aljazeera.com/news/2022/12/12/released-russian-arms-dealer-bout-joins-ultranationalist-party](https://www.aljazeera.com/news/2022/12/12/released-russian-arms-dealer-bout-joins-ultranationalist-party)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 11:21:40+00:00

Viktor Bout was freed last week from a 25-year US prison sentence in swap for basketball star Brittney Griner.

## The disabled freestyle footballer wowing World Cup fans
 - [https://www.aljazeera.com/sports/2022/12/12/the-freestyle-footballer-with-a-difference-wowing-world-cup-fans](https://www.aljazeera.com/sports/2022/12/12/the-freestyle-footballer-with-a-difference-wowing-world-cup-fans)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 11:17:18+00:00

Juanro Aguiló was born with only one, incomplete arm. Today he is an ace freestyle footballer and motivational speaker.

## Four people charged in EU parliament corruption investigation
 - [https://www.aljazeera.com/news/2022/12/12/four-people-charged-in-eu-parliament-corruption-investigation](https://www.aljazeera.com/news/2022/12/12/four-people-charged-in-eu-parliament-corruption-investigation)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 10:58:43+00:00

Qatar, the Gulf state that is alleged to be behind the scandal, rejects any attempts to associate it with the misconduct

## Ukraine says it killed Wagner mercenaries, who are they?
 - [https://www.aljazeera.com/news/2022/12/12/ukraine-says-it-has-killed-wagner-mercenaries-who-are-they](https://www.aljazeera.com/news/2022/12/12/ukraine-says-it-has-killed-wagner-mercenaries-who-are-they)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 10:01:37+00:00

Controversial armed group emerged from being a murky guns-for-hire enterprise to a public extension of the Russian army.

## Forced to eat leaves: Hungry and besieged in Burkina Faso
 - [https://www.aljazeera.com/gallery/2022/12/12/forced-to-eat-leaves-hungry-and-besieged-in-burkina-faso](https://www.aljazeera.com/gallery/2022/12/12/forced-to-eat-leaves-hungry-and-besieged-in-burkina-faso)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 09:52:08+00:00

In the northern town of Djibo, 370,000 people are trapped by a continuing blockade - largely cut off from food and aid.

## Israeli forces kill Palestinian girl in occupied West Bank raid
 - [https://www.aljazeera.com/news/2022/12/12/israeli-forces-kill-palestinian-girl-in-occupied-west-bank-raid](https://www.aljazeera.com/news/2022/12/12/israeli-forces-kill-palestinian-girl-in-occupied-west-bank-raid)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 09:37:28+00:00

Jana Majdi Zakarneh, 16, was shot dead while standing on the roof of her home during an Israeli military raid on Jenin.

## Iran publicly carries out second protest-related execution
 - [https://www.aljazeera.com/news/2022/12/12/iran-publicly-carries-out-second-protest-related-execution-2](https://www.aljazeera.com/news/2022/12/12/iran-publicly-carries-out-second-protest-related-execution-2)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 08:40:06+00:00

Iran has signalled more executions could be carried out amid condemnation by rights groups.

## Can Ronaldo rediscover his purpose after World Cup exit?
 - [https://www.aljazeera.com/sports/2022/12/12/ronaldo-needs-to-rediscover-his-purpose](https://www.aljazeera.com/sports/2022/12/12/ronaldo-needs-to-rediscover-his-purpose)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 08:12:29+00:00

At 37, he&#039;s not scoring as much as he used to. Can being on the bench bring out the best of what he can offer now?

## Russia-Ukraine war: List of key events, day 292
 - [https://www.aljazeera.com/news/2022/12/12/russia-ukraine-war-list-of-key-events-day-292](https://www.aljazeera.com/news/2022/12/12/russia-ukraine-war-list-of-key-events-day-292)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 07:55:06+00:00

As the Russia-Ukraine war enters its 292nd day, we take a look at the main developments.

## Bali governor insists sex ban no risk to tourists
 - [https://www.aljazeera.com/economy/2022/12/12/indonesian-governor-claims-bali-bonk-ban-no-risk-to-tourists](https://www.aljazeera.com/economy/2022/12/12/indonesian-governor-claims-bali-bonk-ban-no-risk-to-tourists)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 07:49:53+00:00

Bali Governor Wayan Koster says authorities will not check marital status of those checking in at tourist accommodation.

## Morocco coach says his team is the ‘Rocky of this World Cup’
 - [https://www.aljazeera.com/news/2022/12/12/moroccos-coach-calls-team-rocky-of-this-world](https://www.aljazeera.com/news/2022/12/12/moroccos-coach-calls-team-rocky-of-this-world)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 07:36:29+00:00

&#039;I think now the world is with Morocco,&#039; coach Walid Regragui said, comparing the team&#039;s run to the iconic boxing movie.

## Germany is targeting post-colonial thinkers for a reason
 - [https://www.aljazeera.com/opinions/2022/12/12/germany-is-threatened-by-postcolonialism-for-a-reason](https://www.aljazeera.com/opinions/2022/12/12/germany-is-threatened-by-postcolonialism-for-a-reason)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 07:22:57+00:00

Postcolonialism is threatening the German state’s perception of its national identity and that of Israel.

## Russia’s Wagner mercenaries target in hotel attack, governor says
 - [https://www.aljazeera.com/news/2022/12/12/russias-wagner-mercenaries-target-in-hotel-attack-governor-says](https://www.aljazeera.com/news/2022/12/12/russias-wagner-mercenaries-target-in-hotel-attack-governor-says)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 05:43:30+00:00

Ukrainian governor Serhiy Haidai claimed a &#039;huge number&#039; died in a strike on hotel where Russian mercenaries were based.

## England’s Harry Kane ‘gutted’ by penalty miss against France
 - [https://www.aljazeera.com/news/2022/12/12/harry-kane-absolutely-gutted-by-missed-french-penalty](https://www.aljazeera.com/news/2022/12/12/harry-kane-absolutely-gutted-by-missed-french-penalty)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 04:58:40+00:00

“There’s no hiding from it, it hurts,” England’s captain said on social media about his World Cup penalty miss.

## Taiwan asks state banks to ‘appropriately handle’ China exposure
 - [https://www.aljazeera.com/economy/2022/12/12/taiwan-asks-banks-to-appropriately-handle-china-exposure](https://www.aljazeera.com/economy/2022/12/12/taiwan-asks-banks-to-appropriately-handle-china-exposure)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 03:51:45+00:00

Finance Minister Su Jain-rong makes remarks in response to question about risks of investing in China.

## Zelenskyy renews diplomacy, thanks US for ‘unprecedented’ help
 - [https://www.aljazeera.com/news/2022/12/12/zelenskyy-renews-diplomacy-thanks-bidens-unprecedented-help](https://www.aljazeera.com/news/2022/12/12/zelenskyy-renews-diplomacy-thanks-bidens-unprecedented-help)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 03:44:42+00:00

Ukrainian president holds talks with US, French and Turkish presidents amid fierce, protracted battles on eastern front.

## Two killed in Peru as protests over Castillo’s arrest spread
 - [https://www.aljazeera.com/news/2022/12/12/two-killed-in-peru-as-protests-over-castillos-arrest-spread](https://www.aljazeera.com/news/2022/12/12/two-killed-in-peru-as-protests-over-castillos-arrest-spread)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 03:38:32+00:00

Two teenagers killed in Andahuaylas, where protesters tried to storm the city&#039;s airport, say authorities.

## Australia’s Albanese to meet gas lobby over price cap concerns
 - [https://www.aljazeera.com/economy/2022/12/12/australias-albanese-to-meet-gas-lobby-about-price-cap-concerns](https://www.aljazeera.com/economy/2022/12/12/australias-albanese-to-meet-gas-lobby-about-price-cap-concerns)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 03:11:32+00:00

Australian leader is aiming to pass legislation this week imposing caps on wholesale gas and coal prices.

## Portugal’s Ronaldo says his World Cup dream has ‘ended’
 - [https://www.aljazeera.com/news/2022/12/12/ronaldos-world-cup-dream-has-ended](https://www.aljazeera.com/news/2022/12/12/ronaldos-world-cup-dream-has-ended)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 03:05:36+00:00

&#039;The dream was beautiful as long as it lasted,&#039; Cristiano Ronaldo wrote on Instagram in a possible hint at retirement.

## New ‘dream’ ball introduced for World Cup’s final matches
 - [https://www.aljazeera.com/sports/2022/12/12/new-dream-ball-introduced-for-world-cups-final-matches](https://www.aljazeera.com/sports/2022/12/12/new-dream-ball-introduced-for-world-cups-final-matches)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 02:54:06+00:00

The Al Hilm — &#039;the dream&#039; in Arabic — will be used in the semifinals, third-place playoff, and final.

## After Brazil, tough contenders Croatia aim to end Messi’s dream
 - [https://www.aljazeera.com/sports/2022/12/12/after-neymar-tough-contenders-croatia-aim-to-end-messis-dream](https://www.aljazeera.com/sports/2022/12/12/after-neymar-tough-contenders-croatia-aim-to-end-messis-dream)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-12 01:44:28+00:00

Fresh from Brazil victory, the Croatia side is confident as they prepare for World Cup semifinal against Argentina.


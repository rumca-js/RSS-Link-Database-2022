# Source:CNET, URL:https://www.cnet.com/rss/all/, language:en-US

## FTX Co-Founder Sam Bankman-Fried Arrested in the Bahamas     - CNET
 - [https://www.cnet.com/personal-finance/crypto/ftx-founder-sam-bankman-fried-arrested-in-the-bahamas/#ftag=CADf328eec](https://www.cnet.com/personal-finance/crypto/ftx-founder-sam-bankman-fried-arrested-in-the-bahamas/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 23:53:00+00:00

The co-founder of the collapsed crypto exchange may be extradited to the US.

## Here's How to See What Your Social Security COLA Increase Amount Is for 2023     - CNET
 - [https://www.cnet.com/personal-finance/heres-how-to-see-what-your-social-security-cola-increase-amount-is-for-2023/#ftag=CADf328eec](https://www.cnet.com/personal-finance/heres-how-to-see-what-your-social-security-cola-increase-amount-is-for-2023/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 23:45:30+00:00

This is the impact the cost-of-living adjustment will have on your 2023 benefits.

## A Coyote Unexpectedly Killed a Human in 2009. Scientists Now Know Why     - CNET
 - [https://www.cnet.com/science/biology/a-coyote-unexpectedly-killed-a-human-in-2009-scientists-now-know-why/#ftag=CADf328eec](https://www.cnet.com/science/biology/a-coyote-unexpectedly-killed-a-human-in-2009-scientists-now-know-why/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 23:27:47+00:00

It's likely due to an unexpected dietary adaptation.

## Microsoft Offered Sony 'Call of Duty' Subscription Option Before FTC Lawsuit, Report Says     - CNET
 - [https://www.cnet.com/tech/gaming/microsoft-offered-sony-call-of-duty-subscription-option-before-ftc-lawsuit-report-says/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/microsoft-offered-sony-call-of-duty-subscription-option-before-ftc-lawsuit-report-says/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 23:10:53+00:00

The acquisition of Activision Blizzard is proving to be a tough hill to climb for Microsoft.

## ChatGPT Is a Stunning AI, but Human Jobs Are Safe (for Now)     - CNET
 - [https://www.cnet.com/science/chatgpt-is-a-stunning-ai-but-human-jobs-are-safe-for-now/#ftag=CADf328eec](https://www.cnet.com/science/chatgpt-is-a-stunning-ai-but-human-jobs-are-safe-for-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 23:10:44+00:00

Commentary: Large language models can surprise and delight, but they're not perfect.

## The Full List of Golden Globes Nominees for 2023     - CNET
 - [https://www.cnet.com/culture/entertainment/the-full-list-of-golden-globes-nominees-for-2023/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-full-list-of-golden-globes-nominees-for-2023/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 23:10:00+00:00

Brendan Fraser scores a best actor nom, and House of the Dragon's Emma D'Arcy is up for best actress.

## 'The White Lotus' Season 2 Finale Opening Credits Clues Explained     - CNET
 - [https://www.cnet.com/culture/entertainment/the-white-lotus-season-2-finale-opening-credits-clues-explained/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-white-lotus-season-2-finale-opening-credits-clues-explained/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 23:02:49+00:00

Now that we know who dies in the finale, let's go over the clues laden in the opening titles.

## 13 Best Foods for Healthy Kidneys     - CNET
 - [https://www.cnet.com/health/nutrition/13-best-for-healthy-kidneys/#ftag=CADf328eec](https://www.cnet.com/health/nutrition/13-best-for-healthy-kidneys/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 23:00:02+00:00

Try eating more of these nutrient-rich foods to promote kidney health.

## These States Are Still Sending Out Tax Rebates. Find Out How to Claim Yours     - CNET
 - [https://www.cnet.com/personal-finance/taxes/these-states-still-sending-out-tax-rebates-find-out-how-to-claim-yours/#ftag=CADf328eec](https://www.cnet.com/personal-finance/taxes/these-states-still-sending-out-tax-rebates-find-out-how-to-claim-yours/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 22:53:00+00:00

California isn't expected to finish mailing out "inflation relief checks" until January 2023.

## Diablo 4's Bleak Storyline Is Reason Enough to Be Excited     - CNET
 - [https://www.cnet.com/tech/gaming/diablo-4s-bleak-storyline-is-reason-enough-to-be-excited/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/diablo-4s-bleak-storyline-is-reason-enough-to-be-excited/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 22:34:16+00:00

Commentary: Be ready to be disturbed.

## Gift of Savings: How to Buy I Bonds for Family and Friends (or Yourself)     - CNET
 - [https://www.cnet.com/personal-finance/investing/gift-of-savings-how-to-buy-i-bonds-for-family-and-friends-or-yourself/#ftag=CADf328eec](https://www.cnet.com/personal-finance/investing/gift-of-savings-how-to-buy-i-bonds-for-family-and-friends-or-yourself/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 22:25:02+00:00

Series I savings bonds still offer a great interest rate, and there's no limit on how much you can buy for other people.

## Social Security: When Does the 2023 COLA Take Effect?     - CNET
 - [https://www.cnet.com/personal-finance/social-security-when-does-the-2023-cola-take-effect/#ftag=CADf328eec](https://www.cnet.com/personal-finance/social-security-when-does-the-2023-cola-take-effect/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 22:21:41+00:00

Retirees will see nearly $150 more in their monthly checks on average.

## NASA Reveals Secret Messages Hidden Inside Orion Spacecraft     - CNET
 - [https://www.cnet.com/science/space/nasa-reveals-secret-messages-hidden-inside-orion-spacecraft/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-reveals-secret-messages-hidden-inside-orion-spacecraft/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 21:56:00+00:00

The craft, now safely back on Earth, was packed with Easter eggs, from a Morse code message to a meaningful bird image.

## Updated COVID Boosters Expanded to Babies and Toddlers     - CNET
 - [https://www.cnet.com/health/medical/updated-covid-boosters-expanded-to-babies-and-toddlers/#ftag=CADf328eec](https://www.cnet.com/health/medical/updated-covid-boosters-expanded-to-babies-and-toddlers/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 21:48:58+00:00

Children as young as 6 months can now get a bivalent booster. Here's what we know about the new formulas.

## Eldercare is Expensive and Emotionally Taxing for Families     - CNET
 - [https://www.cnet.com/personal-finance/elder-care-is-expensive-and-emotionally-taxing/#ftag=CADf328eec](https://www.cnet.com/personal-finance/elder-care-is-expensive-and-emotionally-taxing/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 21:19:29+00:00

Here's how we're maneuvering health insurance hurdles and high caretaking costs.

## 'The White Lotus' Season 2 Finale Recap: We Were All Played     - CNET
 - [https://www.cnet.com/culture/entertainment/the-white-lotus-season-2-finale-recap-we-were-all-played/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-white-lotus-season-2-finale-recap-we-were-all-played/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 21:18:00+00:00

And it was absolutely stunning.

## The Child Care System Is Fraying at Both Ends     - CNET
 - [https://www.cnet.com/personal-finance/the-child-care-system-is-fraying-at-both-ends/#ftag=CADf328eec](https://www.cnet.com/personal-finance/the-child-care-system-is-fraying-at-both-ends/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 21:11:29+00:00

Child care costs are steep and providers are earning a pittance. Meanwhile, families are finding creative solutions.

## Childbirth Costs More in the US Than In Any Other Country     - CNET
 - [https://www.cnet.com/personal-finance/childbirth-costs-more-in-the-us-than-in-any-other-country/#ftag=CADf328eec](https://www.cnet.com/personal-finance/childbirth-costs-more-in-the-us-than-in-any-other-country/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 21:06:01+00:00

Health insurance helps, but pregnant parents are finding their own solutions to high out-of-pocket costs.

## Childbirth Costs More in the US Than Any Other Country     - CNET
 - [https://www.cnet.com/personal-finance/childbirth-costs-more-in-the-us-than-any-other-country/#ftag=CADf328eec](https://www.cnet.com/personal-finance/childbirth-costs-more-in-the-us-than-any-other-country/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 21:06:00+00:00

Health insurance helps, but pregnant parents are finding their own solutions to high out-of-pocket costs.

## Food Prices Aren't Showing Signs of Slowing. Here's How Communities Are Stepping In     - CNET
 - [https://www.cnet.com/personal-finance/food-prices-arent-showing-signs-of-slowing-heres-how-communities-are-stepping-in/#ftag=CADf328eec](https://www.cnet.com/personal-finance/food-prices-arent-showing-signs-of-slowing-heres-how-communities-are-stepping-in/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 20:55:53+00:00

As the costs of everyday staples like bread and eggs rise, communities band together to offer free food and services.

## Fossilized Cockroach Sperm Discovered in 30 Million-Year-Old Amber     - CNET
 - [https://www.cnet.com/science/biology/fossilized-cockroach-sperm-discovered-in-30-million-year-old-amber/#ftag=CADf328eec](https://www.cnet.com/science/biology/fossilized-cockroach-sperm-discovered-in-30-million-year-old-amber/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 20:07:00+00:00

Let's not Jurassic Park this roach, mmmkay.

## Lensa AI Selfies: What to Know About the Photo-Editing App Your Friends Are Using     - CNET
 - [https://www.cnet.com/tech/services-and-software/lensa-ai-selfies-what-to-know-about-the-photo-editing-app-your-friends-are-using/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/lensa-ai-selfies-what-to-know-about-the-photo-editing-app-your-friends-are-using/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 19:30:02+00:00

This app is the latest social media craze, but it doesn't come without privacy concerns.

## Smarten Your Home With the Flip of a Switch     - CNET
 - [https://www.cnet.com/how-to/should-you-install-a-smart-light-switch-in-your-home-heres-what-to-consider/#ftag=CADf328eec](https://www.cnet.com/how-to/should-you-install-a-smart-light-switch-in-your-home-heres-what-to-consider/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 19:24:41+00:00

Easy to install, relatively cheap and available in an assortment of styles and colors, smart switches could be just the upgrade your home needs.

## NASA Completes Historic Trip Around the Moon: What's Next for Artemis?     - CNET
 - [https://www.cnet.com/science/space/nasa-completes-historic-trip-around-the-moon-whats-next-for-artemis/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-completes-historic-trip-around-the-moon-whats-next-for-artemis/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 19:23:12+00:00

The impressive success of Artemis I brings NASA a step closer to putting boots on the lunar surface in just a few years.

## Social Security Cheat Sheet 2022: Your Benefits Questions Answered     - CNET
 - [https://www.cnet.com/personal-finance/social-security-cheat-sheet-2022-your-benefits-questions-answered/#ftag=CADf328eec](https://www.cnet.com/personal-finance/social-security-cheat-sheet-2022-your-benefits-questions-answered/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 19:20:03+00:00

We address all the questions you have on Social Security, Supplemental Security Income or Social Security Disability Insurance through this guide.

## For a Whodunit Done Right, Watch This Riveting Series on Prime Video     - CNET
 - [https://www.cnet.com/culture/entertainment/for-a-whodunit-done-right-watch-this-riveting-series-on-prime-video/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/for-a-whodunit-done-right-watch-this-riveting-series-on-prime-video/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 19:16:00+00:00

It's a witty, engaging story within a story that hooks you from the first episode.

## Twitter Blue Relaunches With Blue and Gold Check Marks, Higher iOS Prices     - CNET
 - [https://www.cnet.com/news/social-media/twitter-blue-relaunches-with-blue-and-gold-check-marks-higher-ios-price/#ftag=CADf328eec](https://www.cnet.com/news/social-media/twitter-blue-relaunches-with-blue-and-gold-check-marks-higher-ios-price/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 19:11:00+00:00

The social network says subscribers will get a blue check mark once their account is "reviewed."

## Golden Globes 2023: Here's the Full List of Award Nominees     - CNET
 - [https://www.cnet.com/culture/entertainment/golden-globes-2023-heres-the-full-list-of-award-nominees/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/golden-globes-2023-heres-the-full-list-of-award-nominees/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 19:04:00+00:00

The TV and film awards has dropped its starry list of nominations, with The Banshees of Inisherin and Abbott Elementary getting the most attention.

## Latest 'Harry & Meghan' Trailer Claims People Were 'Happy to Lie' for William     - CNET
 - [https://www.cnet.com/culture/latest-harry-meghan-trailer-claims-people-were-happy-to-lie-for-william/#ftag=CADf328eec](https://www.cnet.com/culture/latest-harry-meghan-trailer-claims-people-were-happy-to-lie-for-william/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 18:54:00+00:00

Buckle up. The next three episodes of the Netflix docuseries look royally juicy.

## Twitter Community Notes Go Global to Collaboratively Add Context to Tweets     - CNET
 - [https://www.cnet.com/tech/services-and-software/twitter-community-notes-go-global-to-collaboratively-add-context-to-tweets/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/twitter-community-notes-go-global-to-collaboratively-add-context-to-tweets/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 18:41:00+00:00

Anyone on Twitter whose account meets the eligibility criteria can sign up to be a contributor to the Community Notes feature and vet potentially misleading tweets.

## Starting Today, Save $1,000 in League of Legends With Xbox Game Pass     - CNET
 - [https://www.cnet.com/tech/gaming/starting-today-save-1000-in-league-of-legends-with-xbox-game-pass/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/starting-today-save-1000-in-league-of-legends-with-xbox-game-pass/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 18:30:03+00:00

The new partnership grants you access to all characters in League of Legends and Valorant, with a catch.

## New 'Harry & Meghan' Trailer Claims People Were 'Happy to Lie' for William     - CNET
 - [https://www.cnet.com/culture/new-harry-meghan-trailer-claims-people-were-happy-to-lie-for-william/#ftag=CADf328eec](https://www.cnet.com/culture/new-harry-meghan-trailer-claims-people-were-happy-to-lie-for-william/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 18:19:00+00:00

Buckle up. The next three episodes of the Netflix docuseries look royally juicy.

## Finished 'Wednesday' on Netflix? Watch These Addams Family Movies and Shows     - CNET
 - [https://www.cnet.com/culture/entertainment/finished-wednesday-on-netflix-watch-these-addams-family-movies-and-shows/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/finished-wednesday-on-netflix-watch-these-addams-family-movies-and-shows/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 18:10:00+00:00

Put on your best black outfit. It's time for more of the ghoulish clan portrayed in the runaway Netflix hit.

## The Absolute Best Fantasy Movies on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-fantasy-movies-you-can-watch-now/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-fantasy-movies-you-can-watch-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:51:22+00:00

Netflix's fantasy options range from pure magic to touching allegories of the human condition.

## These 5 Earbuds Make Great Gifts and Start at Just $16     - CNET
 - [https://www.cnet.com/tech/mobile/these-5-earbuds-make-great-gifts-and-start-at-just-16/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/these-5-earbuds-make-great-gifts-and-start-at-just-16/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:45:00+00:00

Not everyone can afford or wants Apple AirPods. Check out these bargains on five of our favorite inexpensive earbuds.

## Everything We Know About the New COVID Subvariants     - CNET
 - [https://www.cnet.com/health/medical/everything-we-know-about-the-new-covid-subvariants/#ftag=CADf328eec](https://www.cnet.com/health/medical/everything-we-know-about-the-new-covid-subvariants/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:34:46+00:00

COVID levels are high in many communities, which means people should take extra precautions in public. Here's what we know about the newer BQ.1 and BQ.1.1 strains of the virus.

## Guillermo del Toro's 'Pinocchio' on Netflix Is About Life, Death and Mussolini     - CNET
 - [https://www.cnet.com/culture/entertainment/guillermo-del-toros-pinocchio-on-netflix-is-about-life-death-and-mussolini/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/guillermo-del-toros-pinocchio-on-netflix-is-about-life-death-and-mussolini/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:30:00+00:00

The director of Pan's Labyrinth delivers a visually dazzling -- and decidedly grownup -- take on the wooden puppet come to life.

## 2023 Golden Globes: The Full List of Award Nominees     - CNET
 - [https://www.cnet.com/culture/entertainment/2023-golden-globes-the-full-list-of-award-nominees/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/2023-golden-globes-the-full-list-of-award-nominees/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:27:00+00:00

The TV and film awards has dropped its starry list of nominations, with The Banshees of Inisherin and Abbott Elementary getting the most attention.

## Apple TV Plus: Every New TV Show Arriving in December     - CNET
 - [https://www.cnet.com/culture/entertainment/apple-tv-plus-tv-shows-to-watch-in-december-over-the-week/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/apple-tv-plus-tv-shows-to-watch-in-december-over-the-week/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:24:26+00:00

Here's a complete list of shows coming in December.

## Scientists Spot Ghostly Light Glowing Throughout the Solar System     - CNET
 - [https://www.cnet.com/science/space/scientists-spot-ghostly-light-glowing-throughout-the-solar-system/#ftag=CADf328eec](https://www.cnet.com/science/space/scientists-spot-ghostly-light-glowing-throughout-the-solar-system/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:24:00+00:00

Astronomers used NASA's Hubble Space Telescope to identify the presence of an unexplained glow amid the blackness of space.

## The 33 Absolute Best TV Shows to Watch on HBO Max     - CNET
 - [https://www.cnet.com/culture/entertainment/the-33-absolute-best-tv-shows-to-watch-on-hbo-max-december/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-33-absolute-best-tv-shows-to-watch-on-hbo-max-december/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:19:00+00:00

All episodes of The White Lotus season 2 are now available to stream.

## 13 Easy Ways to Tweak Your Pixel 7 Settings     - CNET
 - [https://www.cnet.com/tech/mobile/13-easy-ways-to-tweak-your-pixel-7-settings/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/13-easy-ways-to-tweak-your-pixel-7-settings/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:18:55+00:00

Try out these simple changes to help make your Google phone even better.

## 'Weather Whiplash' Defined My Smoky, Muddy 2022. And Maybe Your 2023     - CNET
 - [https://www.cnet.com/science/climate/weather-whiplash-defined-my-smoky-muddy-2022-and-maybe-your-2023/#ftag=CADf328eec](https://www.cnet.com/science/climate/weather-whiplash-defined-my-smoky-muddy-2022-and-maybe-your-2023/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:18:00+00:00

From fires to floods, this could be our disturbing new normal.

## Get Lenovo's Android-Powered P11 Plus Tablet with Keyboard and Stylus for Just $300     - CNET
 - [https://www.cnet.com/deals/get-lenovos-android-powered-p11-plus-tablet-with-keyboard-and-stylus-for-just-300/#ftag=CADf328eec](https://www.cnet.com/deals/get-lenovos-android-powered-p11-plus-tablet-with-keyboard-and-stylus-for-just-300/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:18:00+00:00

This lightweight tablet boasts impressive specs, comes with a keyboard and stylus and right now you can pick it up on sale for $300.

## New Movies Coming Out in 2023: Biggest Film Release Dates Including Marvel, DC, Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/new-movies-coming-out-in-2023-release-dates-netflix-marvel-dc-disney/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/new-movies-coming-out-in-2023-release-dates-netflix-marvel-dc-disney/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:17:03+00:00

It's another big year for sequels like Guardians of the Galaxy, John Wick, Dune and Indiana Jones, while Christopher Nolan leads the year's original stories.

## Missing Remains of Last Tasmanian Tiger Finally Found, Hidden in Plain Sight     - CNET
 - [https://www.cnet.com/science/biology/missing-remains-of-last-tasmanian-tiger-finally-found-hidden-in-plain-sight/#ftag=CADf328eec](https://www.cnet.com/science/biology/missing-remains-of-last-tasmanian-tiger-finally-found-hidden-in-plain-sight/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:13:00+00:00

The thylacine died many decades ago in captivity, but its story will be told anew.

## Monday Night Football: How to Watch, Stream Patriots vs. Cardinals Tonight Without Cable     - CNET
 - [https://www.cnet.com/tech/services-and-software/monday-night-football-how-to-watch-stream-patriots-vs-cardinals-tonight-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/monday-night-football-how-to-watch-stream-patriots-vs-cardinals-tonight-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 17:01:50+00:00

New England and Arizona wrap up Week 14 tonight on ESPN.

## The Absolute Best Sci-Fi TV Shows on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-sci-fi-tv-shows-to-watch/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-sci-fi-tv-shows-to-watch/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 16:54:47+00:00

These are the best of the sci-fi series on Netflix.

## Bugatti Baby II Carbon Edition Is an $85,000 Tribute to the W16 Mistral     - CNET
 - [https://www.cnet.com/roadshow/news/bugatti-baby-ii-carbon-edition-debut/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/bugatti-baby-ii-carbon-edition-debut/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 16:54:01+00:00

Mistral owners can have the Baby II match their car's specifications if they prefer.

## Tablo's First ATSC 3.0 DVR Delayed Due to DRM Requirements     - CNET
 - [https://www.cnet.com/tech/home-entertainment/tablo-serves-up-four-tuner-atsc-3-0-recorder-at-ces-2022/#ftag=CADf328eec](https://www.cnet.com/tech/home-entertainment/tablo-serves-up-four-tuner-atsc-3-0-recorder-at-ces-2022/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 16:24:00+00:00

Tablo's $300 TV-connected DVR promises four NextGen TV tuners on board but will no longer include automatic ad skipping.

## 2022 Geminid Meteor Shower to Peak Tuesday Night: How To See It     - CNET
 - [https://www.cnet.com/science/space/2022-geminid-meteor-shower-to-peak-tuesday-night-how-to-see-it/#ftag=CADf328eec](https://www.cnet.com/science/space/2022-geminid-meteor-shower-to-peak-tuesday-night-how-to-see-it/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 16:13:00+00:00

Bright cosmic fireballs and even "Earth grazers" are on the calendar this week,

## Is Amazon the Cheapest Place to Buy Household Products? We Do the Math     - CNET
 - [https://www.cnet.com/how-to/is-amazon-the-cheapest-place-to-buy-household-products/#ftag=CADf328eec](https://www.cnet.com/how-to/is-amazon-the-cheapest-place-to-buy-household-products/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 16:01:00+00:00

We compared prices on a slew of household products from Amazon, Walmart and a popular grocery chain. The results will surprise you.

## Kia EV6 GT Owners Get 1,000 kWh of Free Electrify America Charging     - CNET
 - [https://www.cnet.com/roadshow/news/kia-ev6-gt-free-electrify-america-charging/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/kia-ev6-gt-free-electrify-america-charging/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 16:01:00+00:00

That's the equivalent of between 3,500 and 4,000 miles of driving.

## Think Winter Weather Might Knock Out Your Internet? Here's What To Do     - CNET
 - [https://www.cnet.com/how-to/winter-weather-knocked-out-your-internet-heres-what-to-do/#ftag=CADf328eec](https://www.cnet.com/how-to/winter-weather-knocked-out-your-internet-heres-what-to-do/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 16:00:03+00:00

There are a few things you can do ahead of time to minimize home internet disruptions due to wind, snow and ice.

## Snow and Ice Have Arrived. Here's How to Protect Your Home     - CNET
 - [https://www.cnet.com/how-to/snow-and-ice-have-arrived-heres-how-to-protect-your-home/#ftag=CADf328eec](https://www.cnet.com/how-to/snow-and-ice-have-arrived-heres-how-to-protect-your-home/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 15:54:00+00:00

Follow these 10 tips to keep your house safe and warm this winter.

## Upgrade Your Gaming Setup With Deals On New and Refurb Razer Gear     - CNET
 - [https://www.cnet.com/deals/upgrade-your-gaming-setup-with-deals-on-new-and-refurb-razer-gear/#ftag=CADf328eec](https://www.cnet.com/deals/upgrade-your-gaming-setup-with-deals-on-new-and-refurb-razer-gear/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 15:53:00+00:00

Right now at Woot, you can save on both new and used Razer gaming keyboards, headsets, streaming cameras and more. But hurry, some items have already sold out.

## 23 Awesome Gizmos and Gadgets Under $50 That Would Make Great Gifts     - CNET
 - [https://www.cnet.com/deals/23-awesome-gizmos-gadgets-under-50/#ftag=CADf328eec](https://www.cnet.com/deals/23-awesome-gizmos-gadgets-under-50/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 15:21:26+00:00

In need of a small present for a grab bag? We've got you covered.

## Subaru Recalls a Quarter-Million Ascent SUVs Over Fire Concerns     - CNET
 - [https://www.cnet.com/roadshow/news/subaru-ascent-recall-fire-concerns/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/subaru-ascent-recall-fire-concerns/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 15:12:00+00:00

The recall covers 2019-2022 models.

## The Absolute Best Thermostat Temperature to Save Money This Winter     - CNET
 - [https://www.cnet.com/how-to/the-absolute-best-thermostat-temperature-to-save-money-this-winter/#ftag=CADf328eec](https://www.cnet.com/how-to/the-absolute-best-thermostat-temperature-to-save-money-this-winter/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 15:00:10+00:00

Yeah, there's an ideal setting for your thermostat -- and it can save you up to 10% on your energy bills.

## Zoom Games: How to Play Poker, Trivia and More During Your Next Meeting     - CNET
 - [https://www.cnet.com/tech/services-and-software/zoom-games-how-to-play-poker-trivia-and-more-during-your-next-meeting/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/zoom-games-how-to-play-poker-trivia-and-more-during-your-next-meeting/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 15:00:06+00:00

The video calling service has in-app games to play during meetings. Here's how you can try them out.

## 10 Spotify Settings to Change for Better Listening     - CNET
 - [https://www.cnet.com/tech/services-and-software/10-spotify-settings-to-change-for-better-listening/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/10-spotify-settings-to-change-for-better-listening/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 15:00:02+00:00

These changes can make Spotify easier to use, or they could save you some money.

## Stock Up On Anker Charging Gear While It's Up to 50% Off     - CNET
 - [https://www.cnet.com/deals/stock-up-on-anker-charging-gear-while-its-up-to-50-off/#ftag=CADf328eec](https://www.cnet.com/deals/stock-up-on-anker-charging-gear-while-its-up-to-50-off/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 14:47:39+00:00

Right now at Amazon, you can pick up Anker charging cables, batter packs, power stations and more at a discount.

## Relax With Parachute Robes and Loungewear for 20% Off     - CNET
 - [https://www.cnet.com/deals/relax-with-parachute-robes-and-loungewear-for-20-percent-off/#ftag=CADf328eec](https://www.cnet.com/deals/relax-with-parachute-robes-and-loungewear-for-20-percent-off/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 14:40:44+00:00

Feel comfortable and warm in luxury threads this holiday.

## Golden Globes Awards for 2023: The Full List of Nominees     - CNET
 - [https://www.cnet.com/culture/entertainment/golden-globes-awards-for-2023-the-full-list-of-nominees/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/golden-globes-awards-for-2023-the-full-list-of-nominees/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 14:20:00+00:00

The TV and film awards has dropped its starry list of nominations.

## Barclays Bank: 2022 Banking Review     - CNET
 - [https://www.cnet.com/personal-finance/banking/barclays-bank-banking-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/barclays-bank-banking-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 14:00:23+00:00

This global banking giant operates an online-only banking division in the US, with high-yielding savings accounts and CDs.

## Good Skin Care Can Actually Be Super Simple. Here's What to Do     - CNET
 - [https://www.cnet.com/health/personal-care/good-skin-care-can-actually-be-super-simple-heres-what-to-do/#ftag=CADf328eec](https://www.cnet.com/health/personal-care/good-skin-care-can-actually-be-super-simple-heres-what-to-do/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 14:00:18+00:00

Fancy products and routines are nice, but you don't need them to take care of your skin.

## Eat These 12 Foods for Healthy Skin     - CNET
 - [https://www.cnet.com/health/nutrition/eat-these-12-foods-for-healthy-skin/#ftag=CADf328eec](https://www.cnet.com/health/nutrition/eat-these-12-foods-for-healthy-skin/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 14:00:02+00:00

You can easily Incorporate these foods into your diet to help your skin.

## AMD Radeon RX 7900 XT and 7900 XTX Review: Faster, but Is It Enough?     - CNET
 - [https://www.cnet.com/tech/computing/amd-radeon-rx-7900-xt-and-7900-xtx-review-faster-but-is-it-enough/#ftag=CADf328eec](https://www.cnet.com/tech/computing/amd-radeon-rx-7900-xt-and-7900-xtx-review-faster-but-is-it-enough/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 14:00:00+00:00

Reply hazy, try again.

## Here Are Today's Refinance Rates, Dec. 12, 2022: Rates Rise     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/here-are-todays-refinance-rates-dec-12-2022-rates-rise/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/here-are-todays-refinance-rates-dec-12-2022-rates-rise/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 14:00:00+00:00

Multiple key refinance rates climbed over the past week. Though refinance rates change daily, experts expect rates to continue to climb.

## Mortgage Rates for Dec. 12, 2022: Rates Trend Higher     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/mortgage-rates-for-dec-12-2022-rates-trend-higher/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/mortgage-rates-for-dec-12-2022-rates-trend-higher/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 14:00:00+00:00

Over the past week some key mortgage rates climbed higher. As interest rates surge, it's getting more expensive to buy a house.

## This $20 Chef'n Juicer Is the Best Cheap Kitchen Gift     - CNET
 - [https://www.cnet.com/news/this-20-chefn-juicer-is-the-best-cheap-kitchen-gift/#ftag=CADf328eec](https://www.cnet.com/news/this-20-chefn-juicer-is-the-best-cheap-kitchen-gift/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 14:00:00+00:00

Cheap, cheerful and ready to squeeze all your fresh citrus.

## Prosper: 2022 Home Equity Review     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/prosper-home-equity-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/prosper-home-equity-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 13:45:02+00:00

This San Francisco-based peer-to-peer marketplace lender has a streamlined online application process and can get you funds in as little as 11 days.

## How My Family and Others Struggle Financially to Care for Aging Relatives     - CNET
 - [https://www.cnet.com/personal-finance/how-my-family-and-others-struggle-financially-to-care-for-aging-relatives/#ftag=CADf328eec](https://www.cnet.com/personal-finance/how-my-family-and-others-struggle-financially-to-care-for-aging-relatives/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 13:30:00+00:00

The high price of eldercare in the US is putting a strain on households responsible for caretaking and medical costs.

## Should You Upgrade to the iPhone 14? Here's Who Should and Shouldn't Upgrade     - CNET
 - [https://www.cnet.com/tech/mobile/should-you-upgrade-to-iphone-14-heres-who-should-and-who-shouldnt/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/should-you-upgrade-to-iphone-14-heres-who-should-and-who-shouldnt/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 13:00:32+00:00

This guide should help you determine whether it makes sense for you to upgrade to the iPhone 14 or wait for a future iPhone.

## Watch Argentina vs. Croatia World Cup 2022 Semifinal Match From Anywhere     - CNET
 - [https://www.cnet.com/tech/services-and-software/watch-argentina-vs-croatia-world-cup-2022-match-from-anywhere/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/watch-argentina-vs-croatia-world-cup-2022-match-from-anywhere/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 13:00:28+00:00

Lionel Messi is two games away from at last bringing the World Cup back to Argentina.

## 2023 Mitsubishi Outlander PHEV Second Drive Review: A True Underdog Story     - CNET
 - [https://www.cnet.com/roadshow/news/2023-mitsubishi-outlander-phev-second-drive-review/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2023-mitsubishi-outlander-phev-second-drive-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 13:00:20+00:00

Mitsubishi's second-generation plug-in hybrid makes a strong showing in a shrinking, but still very valuable, niche.

## My Favorite Gadget of 2022 Is a Hand-Cranked Gaming Device     - CNET
 - [https://www.cnet.com/tech/gaming/my-favorite-gadget-of-2022-is-a-hand-cranked-gaming-device/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/my-favorite-gadget-of-2022-is-a-hand-cranked-gaming-device/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 13:00:17+00:00

The Panic Playdate has weirdly stuck with me in a year full of new gaming hardware.

## War in Ukraine Dominated Cybersecurity in 2022     - CNET
 - [https://www.cnet.com/tech/services-and-software/war-in-ukraine-dominated-cybersecurity-in-2022/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/war-in-ukraine-dominated-cybersecurity-in-2022/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 13:00:10+00:00

Though some experts worried that Russia would lash out against Ukraine's allies, that hasn't happened, at least not yet.

## Most Exciting New Phones for 2023: iPhone 15, Galaxy S23 and More     - CNET
 - [https://www.cnet.com/tech/mobile/most-exciting-new-phones-for-2023-iphone-15-galaxy-s23-and-more/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/most-exciting-new-phones-for-2023-iphone-15-galaxy-s23-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 13:00:02+00:00

Here's what to expect from Apple, Samsung, Google and OnePlus based on the rumors that have surfaced so far.

## 2023 Mitsubishi Outlander PHEV Is an Underdog Worth Rooting For     - CNET
 - [https://www.cnet.com/roadshow/pictures/2023-mitsubishi-outlander-phev-sel-premium/#ftag=CADf328eec](https://www.cnet.com/roadshow/pictures/2023-mitsubishi-outlander-phev-sel-premium/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 13:00:01+00:00

Plug-in hybrids aren't for everyone, but with more power and more range, the 2023 Outlander PHEV is one of the best values in its class.

## How to Choose Between the Apple Watch 8 and SE video     - CNET
 - [https://www.cnet.com/videos/how-to-choose-between-the-apple-watch-8-and-se/#ftag=CADf328eec](https://www.cnet.com/videos/how-to-choose-between-the-apple-watch-8-and-se/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 13:00:01+00:00

You want an Apple Watch, so here's how to choose between the Apple Watch Series 8 and the 2022 Apple Watch SE. Lexy compares these two smartwatches on fitness features, health sensors, battery life, screens, text size and design.

## Having a Baby Shouldn't Be This Expensive. Here's How Parents Are Managing     - CNET
 - [https://www.cnet.com/personal-finance/having-a-baby-shouldnt-be-this-expensive-heres-how-parents-are-managing/#ftag=CADf328eec](https://www.cnet.com/personal-finance/having-a-baby-shouldnt-be-this-expensive-heres-how-parents-are-managing/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 13:00:00+00:00

Health care coverage can help with high pregnancy costs, but some families are seeking out other resources to lower their expenses.

## Apple's 16-Inch MacBook Pro Is Almost $500 Off at Amazon     - CNET
 - [https://www.cnet.com/deals/apple-16-inch-macbook-pro-almost-500-off-amazon/#ftag=CADf328eec](https://www.cnet.com/deals/apple-16-inch-macbook-pro-almost-500-off-amazon/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 12:54:00+00:00

Score huge savings on Apple's most powerful laptops, plus some decent discounts on entry-level models.

## Skyrocketing Grocery Prices and Food Insecurity: How Families Are Finding Help     - CNET
 - [https://www.cnet.com/personal-finance/skyrocketing-grocery-prices-and-food-insecurity-how-families-are-finding-help/#ftag=CADf328eec](https://www.cnet.com/personal-finance/skyrocketing-grocery-prices-and-food-insecurity-how-families-are-finding-help/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 12:30:03+00:00

With the soaring cost of everyday staples like bread and eggs, communities band together to provide free food and services.

## As Child Care Costs Rise, Parents Make Tough Sacrifices     - CNET
 - [https://www.cnet.com/personal-finance/as-child-care-costs-rise-parents-make-tough-sacrifices/#ftag=CADf328eec](https://www.cnet.com/personal-finance/as-child-care-costs-rise-parents-make-tough-sacrifices/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 12:00:08+00:00

When day care is unaffordable, families are coming up with creative solutions to raise their kids.

## Millions of Americans Can't Afford Their Prescription Drugs. Now What?     - CNET
 - [https://www.cnet.com/personal-finance/millions-of-americans-cant-afford-their-prescription-drugs-now-what/#ftag=CADf328eec](https://www.cnet.com/personal-finance/millions-of-americans-cant-afford-their-prescription-drugs-now-what/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 11:00:02+00:00

As the cost of medication soars, patients are turning to online coupons and financial assistance programs.

## 'The White Lotus' Finale Recap: We Were All Played     - CNET
 - [https://www.cnet.com/culture/entertainment/the-white-lotus-finale-recap-we-were-all-played/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-white-lotus-finale-recap-we-were-all-played/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 05:00:59+00:00

And it was absolutely stunning.

## That Viral Dance From Netflix Megahit 'Wednesday' Is Taking Over TikTok     - CNET
 - [https://www.cnet.com/culture/entertainment/that-viral-dance-from-netflix-megahit-wednesday-is-taking-over-tiktok/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/that-viral-dance-from-netflix-megahit-wednesday-is-taking-over-tiktok/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 03:30:00+00:00

Even Lady Gaga's getting in on it.

## More People Need to Watch One of 2022's Best TV Shows     - CNET
 - [https://www.cnet.com/culture/entertainment/more-people-need-to-watch-one-of-2022s-best-tv-shows/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/more-people-need-to-watch-one-of-2022s-best-tv-shows/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 03:00:02+00:00

The finale is mindblowing.

## A Fusion Energy Breakthrough? Major Announcement Expected from US Scientists     - CNET
 - [https://www.cnet.com/science/climate/a-fusion-energy-breakthrough-major-announcement-expected-from-us-scientists/#ftag=CADf328eec](https://www.cnet.com/science/climate/a-fusion-energy-breakthrough-major-announcement-expected-from-us-scientists/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 02:56:00+00:00

US scientists may have reached a critical milestone in generating fusion power.

## The Classic Christmas Movie More People Need to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/the-classic-christmas-movie-more-people-need-to-watch/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-classic-christmas-movie-more-people-need-to-watch/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 02:39:00+00:00

This 2005 gem starring Sarah Jessica Parker should be on everyone's yuletide watch list.

## Astronomers Spot Ghostly Light Glowing Throughout the Solar System     - CNET
 - [https://www.cnet.com/science/space/astronomers-spot-ghostly-light-glowing-throughout-the-solar-system/#ftag=CADf328eec](https://www.cnet.com/science/space/astronomers-spot-ghostly-light-glowing-throughout-the-solar-system/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 02:25:00+00:00

Scientists used NASA's Hubble Space Telescope to identify the presence of an unexplained glow amid the blackness of space.

## Lost Remains of Last Tasmanian Tiger Finally Found, Hiding in Plain Sight     - CNET
 - [https://www.cnet.com/science/biology/lost-remains-of-last-tasmanian-tiger-finally-found-hiding-in-plain-sight/#ftag=CADf328eec](https://www.cnet.com/science/biology/lost-remains-of-last-tasmanian-tiger-finally-found-hiding-in-plain-sight/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 02:22:00+00:00

The thylacine died many decades ago in captivity, but its story will be told anew.

## Best Wordle Starter Words and Tips: What I Learned Playing for a Year Straight     - CNET
 - [https://www.cnet.com/culture/best-wordle-starter-words-and-tips-what-i-learned-playing-for-a-year-straight/#ftag=CADf328eec](https://www.cnet.com/culture/best-wordle-starter-words-and-tips-what-i-learned-playing-for-a-year-straight/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 01:56:00+00:00

Starter words are so important. But here are other Wordle tricks too.

## The Sci-Fi Video Game Everyone Should Play at Least Once     - CNET
 - [https://www.cnet.com/tech/gaming/the-sci-fi-video-game-everyone-should-play-at-least-once/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/the-sci-fi-video-game-everyone-should-play-at-least-once/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 01:23:00+00:00

There's nothing else like it.

## Done With '1899'? Time to Watch the Best Show on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/done-with-1899-time-to-watch-the-best-show-on-netflix/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/done-with-1899-time-to-watch-the-best-show-on-netflix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 00:35:00+00:00

Dark is arguably the best show on TV.

## More People Should Watch This Utterly Heartbreaking Documentary on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/more-people-should-watch-this-utterly-heartbreaking-documentary-on-netflix/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/more-people-should-watch-this-utterly-heartbreaking-documentary-on-netflix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 00:24:00+00:00

It's a beautiful documentary.

## 'The Witcher' Prequel Series 'Blood Origin' Has One Stellar Episode     - CNET
 - [https://www.cnet.com/culture/entertainment/the-witcher-prequel-series-blood-origin-has-one-stellar-episode/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-witcher-prequel-series-blood-origin-has-one-stellar-episode/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 00:05:00+00:00

Review: Michelle Yeoh shows off her sword skills in this Easter egg-packed origin series.

## Ever Looked Inside Your Keurig? Yeah, You Need to Clean That Thing     - CNET
 - [https://www.cnet.com/how-to/ever-looked-inside-your-keurig-yeah-you-need-to-clean-that-thing/#ftag=CADf328eec](https://www.cnet.com/how-to/ever-looked-inside-your-keurig-yeah-you-need-to-clean-that-thing/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-12 00:00:03+00:00

Your Keurig is probably filled with gunk, which prevents it from making the best coffee. Clean it out in five easy steps.


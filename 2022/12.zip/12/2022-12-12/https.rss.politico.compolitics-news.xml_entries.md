# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Inside the secret $32M effort to stop ‘Stop the Steal’
 - [https://www.politico.com/news/2022/12/12/midterm-election-trump-maga-00073354](https://www.politico.com/news/2022/12/12/midterm-election-trump-maga-00073354)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-12-12 04:31:00+00:00

Operating with absolutely no public notice, two groups plowed millions across a host of battleground states to support voting access and election infrastructure.


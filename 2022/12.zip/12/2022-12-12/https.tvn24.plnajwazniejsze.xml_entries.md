# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Sejmowa komisja przeciw wotum nieufności wobec Ziobry
 - [https://tvn24.pl/polska/zbigniew-ziobro-wniosek-o-wotum-nieufnosci-wobec-ministra-sprawiedliwosci-opinia-sejmowej-komisji-6466299?source=rss](https://tvn24.pl/polska/zbigniew-ziobro-wniosek-o-wotum-nieufnosci-wobec-ministra-sprawiedliwosci-opinia-sejmowej-komisji-6466299?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 23:55:13+00:00

<img alt="Sejmowa komisja przeciw wotum nieufności wobec Ziobry" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4zkhuu-12-1850-komisja-sprawiedliwosci-0032-6466313/alternates/LANDSCAPE_1280" />
    Wniosek złożyły kluby KO i Lewicy oraz koło Polska 2050.

## Amerykanie przeprowadzili pierwszy pełny test rakiety hipersonicznej
 - [https://tvn24.pl/swiat/usa-sily-powietrzne-przeprowadzily-pierwszy-pelny-test-rakiety-hipersonicznej-6466708?source=rss](https://tvn24.pl/swiat/usa-sily-powietrzne-przeprowadzily-pierwszy-pelny-test-rakiety-hipersonicznej-6466708?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 21:52:38+00:00

<img alt="Amerykanie przeprowadzili pierwszy pełny test rakiety hipersonicznej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bthp3j-bombowiec-b-52h-stratofortress-z-prototypem-pocisku-hipersonicznego-zdjecie-wykonano-w-czasie-testow-w-sierpniu-2020-5663160/alternates/LANDSCAPE_1280" />
    Poinformowały Siły Powietrzne USA.

## Czterech półfinalistów, 96 piłkarzy. Najwięcej przedstawicieli ma Bayern i liga hiszpańska
 - [https://eurosport.tvn24.pl/czterech-p--finalist-w--96-pi-karzy--najwi-cej-przedstawicieli-ma-bayern-i-liga-hiszpa-ska,1128882.html?source=rss](https://eurosport.tvn24.pl/czterech-p--finalist-w--96-pi-karzy--najwi-cej-przedstawicieli-ma-bayern-i-liga-hiszpa-ska,1128882.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 21:24:41+00:00

<img alt="Czterech półfinalistów, 96 piłkarzy. Najwięcej przedstawicieli ma Bayern i liga hiszpańska" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eijkpx-dayot-upamecano-6466718/alternates/LANDSCAPE_1280" />
    We wtorek Argentyna zagra z Chorwacją, a w środę Francja zmierzy się z Marokiem.

## Nowy członek angielskiej kadry
 - [https://eurosport.tvn24.pl/nowy-cz-onek-angielskiej-kadry---zamieni-katarskie-ciep-o-na-ch--d-,1128982.html?source=rss](https://eurosport.tvn24.pl/nowy-cz-onek-angielskiej-kadry---zamieni-katarskie-ciep-o-na-ch--d-,1128982.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 21:04:25+00:00

<img alt="Nowy członek angielskiej kadry" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dgkc86-anglia-odpadla-w-cwiercfinale/alternates/LANDSCAPE_1280" />
    "Zamieni katarskie ciepło na chłód".

## Zmierzyli wyskok przy golu. Wynik Ronaldo pobity
 - [https://eurosport.tvn24.pl/zmierzyli-wyskok-przy-golu--wynik-ronaldo-pobity,1128989.html?source=rss](https://eurosport.tvn24.pl/zmierzyli-wyskok-przy-golu--wynik-ronaldo-pobity,1128989.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 20:41:00+00:00

<img alt="Zmierzyli wyskok przy golu. Wynik Ronaldo pobity" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8j1lin-youssef-en-nesyri-z-prawej-skacze-wyzej-od-samego-ronaldo-6466427/alternates/LANDSCAPE_1280" />
    Bramka na mundialu była imponująca.

## Ksiądz przyciska ucznia do ławki i krzyczy "przeproś Pana Boga". Później wykręca chłopcu ręce
 - [https://tvn24.pl/tvnwarszawa/najnowsze/mazowsze-ksiadz-przyciska-ucznia-z-niepelnosprawnoscia-do-lawki-i-krzyczy-nagranie-policja-komentarz-szkoly-6465698?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/mazowsze-ksiadz-przyciska-ucznia-z-niepelnosprawnoscia-do-lawki-i-krzyczy-nagranie-policja-komentarz-szkoly-6465698?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 20:23:26+00:00

<img alt="Ksiądz przyciska ucznia do ławki i krzyczy " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-19ml9y-ksiadz-wykreca-rece-6466347/alternates/LANDSCAPE_1280" />
    Nagranie dostaliśmy na Kontakt 24.

## Nastolatek zatruł się czadem, uratowała go młodsza siostra
 - [https://tvn24.pl/polska/kielce-czternastolatek-podtrul-sie-czadem-podczas-kapieli-uratowala-go-mlodsza-siostra-6466386?source=rss](https://tvn24.pl/polska/kielce-czternastolatek-podtrul-sie-czadem-podczas-kapieli-uratowala-go-mlodsza-siostra-6466386?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 20:13:57+00:00

<img alt="Nastolatek zatruł się czadem, uratowała go młodsza siostra" src="https://tvn24.pl/najnowsze/cdn-zdjecie-amrvb6-strazacy-podkreslaja-ze-zycie-chlopca-uratowala-jego-mlodsza-siostra-zdjecie-ilustracyjne-6466387/alternates/LANDSCAPE_1280" />
    Straż: mówimy o młodej bohaterce.

## Zamknięte przychodnie, długie kolejki i brak rąk do pracy. Chiny odchodzą od "zero covid"
 - [https://tvn24.pl/swiat/chiny-wladza-odchodzi-od-polityki-zero-covid-system-zdrowia-w-trudnej-sytuacji-6466205?source=rss](https://tvn24.pl/swiat/chiny-wladza-odchodzi-od-polityki-zero-covid-system-zdrowia-w-trudnej-sytuacji-6466205?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 20:05:59+00:00

<img alt="Zamknięte przychodnie, długie kolejki i brak rąk do pracy. Chiny odchodzą od " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xac8ws-chiny-luzuja-restrykcje-sluzba-zdrowia-w-trudnej-sytuacji-6466211/alternates/LANDSCAPE_1280" />
    O problemach w państwie środka informują dziennikarze Caixin.

## Zamknięte przychodnie, długie kolejki i brak rąk do pracy. Chiny odchodzą od "zero covid"
 - [https://tvn24.pl/swiat/chiny-wladza-odchodzi-od-polityki-zero-covid-system-ochrony-zdrowia-znalazl-sie-w-trudnej-sytuacji-6466205?source=rss](https://tvn24.pl/swiat/chiny-wladza-odchodzi-od-polityki-zero-covid-system-ochrony-zdrowia-znalazl-sie-w-trudnej-sytuacji-6466205?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 20:05:59+00:00

<img alt="Zamknięte przychodnie, długie kolejki i brak rąk do pracy. Chiny odchodzą od " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xac8ws-chiny-luzuja-restrykcje-sluzba-zdrowia-w-trudnej-sytuacji-6466211/alternates/LANDSCAPE_1280" />
    O problemach w państwie środka informują dziennikarze Caixin.

## "Wszyscy Polacy są zakładnikami Zbigniewa Ziobry"
 - [https://tvn24.pl/polska/napiecie-w-zjednoczonej-prawicy-konflikt-mateusz-morawiecki-zbigniew-ziobro-artur-sobon-i-magdalena-biejat-komentuja-6466268?source=rss](https://tvn24.pl/polska/napiecie-w-zjednoczonej-prawicy-konflikt-mateusz-morawiecki-zbigniew-ziobro-artur-sobon-i-magdalena-biejat-komentuja-6466268?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 20:04:55+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k4nbo5-kropka-nad-i-6466317/alternates/LANDSCAPE_1280" />
    Dyskusja w "Kropce nad i".

## Rząd apeluje o oszczędność, tymczasem Polacy będą musieli zapłacić premierowi i jego ludziom 1,5 miliarda
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2345,S00E2345,935862?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2345,S00E2345,935862?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 19:36:35+00:00

<img alt="Rząd apeluje o oszczędność, tymczasem Polacy będą musieli zapłacić premierowi i jego ludziom 1,5 miliarda" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bj1rpc-czarno-na-bialym-6465931/alternates/LANDSCAPE_1280" />
    Reportaż Artura Zakrzewskiego.

## Mijał mechanika i nagle stało się to. Komedia na trasie Pucharu Świata
 - [https://eurosport.tvn24.pl/mija--mechanika-i-nagle-sta-o-si--to--komedia-na-trasie-pucharu--wiata,1128967.html?source=rss](https://eurosport.tvn24.pl/mija--mechanika-i-nagle-sta-o-si--to--komedia-na-trasie-pucharu--wiata,1128967.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 19:21:00+00:00

<img alt="Mijał mechanika i nagle stało się to. Komedia na trasie Pucharu Świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2azc2q-wout-van-aert-wygral-puchar-swiata-w-dublinie-mimo-problemow/alternates/LANDSCAPE_1280" />
    Niesamowite przygody Wouta van Aerta podczas wyścigu.

## Nie żyje Mirosław Hermaszewski. Miał 81 lat
 - [https://tvn24.pl/polska/miroslaw-hermaszewski-nie-zyje-polski-kosmonauta-mial-81-lat-6466280?source=rss](https://tvn24.pl/polska/miroslaw-hermaszewski-nie-zyje-polski-kosmonauta-mial-81-lat-6466280?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 19:11:31+00:00

<img alt="Nie żyje Mirosław Hermaszewski. Miał 81 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tdvxxs-miroslaw-hermaszewski-6466271/alternates/LANDSCAPE_1280" />
    Był pierwszym i jak dotąd jedynym Polakiem w kosmosie.

## Rosjanie mieli przedstawić warunki dotyczące uwolnienia Paula Whelana. W zamian chcieli zwolnienia agenta FSB
 - [https://fakty.tvn24.pl/rosjanie-mieli-przedstawi--warunki-dotycz-ce-uwolnienia-paula-whelana--w-zamian-chcieli-zwolnienia-agenta-fsb-skazanego-w-niemczech,1128936.html?source=rss](https://fakty.tvn24.pl/rosjanie-mieli-przedstawi--warunki-dotycz-ce-uwolnienia-paula-whelana--w-zamian-chcieli-zwolnienia-agenta-fsb-skazanego-w-niemczech,1128936.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 19:10:00+00:00

<img alt="Rosjanie mieli przedstawić warunki dotyczące uwolnienia Paula Whelana. W zamian chcieli zwolnienia agenta FSB " src="https://tvn24.pl/najnowsze/cdn-zdjecie-0dvu2o-rosjanie-mieli-sie-zgodzic-na-uwolnienie-paula-whelana-w-zamian-chcieli-zwolnienia-agenta-fsb-skazanego-w-niemczech/alternates/LANDSCAPE_1280" />
    Rosja była skłonna oddać Amerykanom byłego żołnierza Paula Whelana - ale w zamian oczekiwała niemożliwego. Materiał "Faktów o Świecie" TVN24 BiS.

## Wiceszef wywiadu Ukrainy: Rosja używa przeciwko nam rakiet, które przekazaliśmy jej w 1990 roku
 - [https://tvn24.pl/swiat/rosja-ukraina-ukrainski-wywiad-rosja-uzywa-przeciwko-nam-rakiet-ktore-przekazalismy-jej-w-1990-roku-6466189?source=rss](https://tvn24.pl/swiat/rosja-ukraina-ukrainski-wywiad-rosja-uzywa-przeciwko-nam-rakiet-ktore-przekazalismy-jej-w-1990-roku-6466189?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 18:57:10+00:00

<img alt="Wiceszef wywiadu Ukrainy: Rosja używa przeciwko nam rakiet, które przekazaliśmy jej w 1990 roku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w8nnm8-zniszczenia-po-rosyjskim-ataku-rakietowym-na-donieck-6432648/alternates/LANDSCAPE_1280" />
    W ramach Memorandum Budapeszteńskiego Ukraina zgodziła się zrzec arsenału nuklearnego i przekazać swe głowice nuklearne Rosji do likwidacji.

## Święta i sylwester pod palmami. Najpopularniejsze kierunki
 - [https://tvn24.pl/biznes/turystyka/swieta-i-sylwester-wyjazdy-jakie-kierunki-6466191?source=rss](https://tvn24.pl/biznes/turystyka/swieta-i-sylwester-wyjazdy-jakie-kierunki-6466191?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 18:52:41+00:00

<img alt="Święta i sylwester pod palmami. Najpopularniejsze kierunki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0zueu8-piramidy-w-gizie-5703968/alternates/LANDSCAPE_1280" />
    Za wyjazdy trzeba zapłacić więcej niż przed rokiem.

## Ukraina tworzy pogotowie lotnicze. Ratowników i lekarzy szkolą Polacy
 - [https://fakty.tvn24.pl/ukraina-tworzy-pogotowie-lotnicze--ratownik-w-i-lekarzy-szkol--polacy,1128963.html?source=rss](https://fakty.tvn24.pl/ukraina-tworzy-pogotowie-lotnicze--ratownik-w-i-lekarzy-szkol--polacy,1128963.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 18:08:00+00:00

<img alt="Ukraina tworzy pogotowie lotnicze. Ratowników i lekarzy szkolą Polacy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sbignb-1212--ukraina-tworzy-pogotowie-lotnicze-ratownikow-i-lekarzy-szkola-polacy/alternates/LANDSCAPE_1280" />
    Już niedługo na Ukrainie powstanie śmigłowcowa służba ratownictwa medycznego.

## Po przeszczepie płuc urodziła dziecko. To pierwszy taki przypadek w Polsce
 - [https://fakty.tvn24.pl/po-przeszczepie-p-uc-urodzi-a-dziecko--to-pierwszy-taki-przypadek-w-polsce,1128978.html?source=rss](https://fakty.tvn24.pl/po-przeszczepie-p-uc-urodzi-a-dziecko--to-pierwszy-taki-przypadek-w-polsce,1128978.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 18:07:00+00:00

<img alt="Po przeszczepie płuc urodziła dziecko. To pierwszy taki przypadek w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xtz7fy-1212--po-przeszczepie-pluc-urodzila-dziecko-to-pierwszy-taki-przypadek-w-polsce/alternates/LANDSCAPE_1280" />
    Trzy lata temu pani Patrycja przeszła udaną operację przeszczepienia płuc, które zniszczyła mukowiscydoza.

## Kilka godzin akcji, 30 kierowców tirów ukaranych za wyprzedzanie na zakazie
 - [https://fakty.tvn24.pl/kilka-godzin-akcji--30-kierowc-w-tir-w-ukaranych-za-wyprzedzanie-na-zakazie---musimy-bezwzgl-dnie-si--stosowa--do-przepis-w-,1128981.html?source=rss](https://fakty.tvn24.pl/kilka-godzin-akcji--30-kierowc-w-tir-w-ukaranych-za-wyprzedzanie-na-zakazie---musimy-bezwzgl-dnie-si--stosowa--do-przepis-w-,1128981.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 18:06:00+00:00

<img alt="Kilka godzin akcji, 30 kierowców tirów ukaranych za wyprzedzanie na zakazie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6mm5cy-1212--kilka-godzin-30-kierowcow-tirow-ukaranych-za-wyprzedzanie-na-zakazie-musimy-bezwzglednie-sie-stosowac-do-przepisow/alternates/LANDSCAPE_1280" />
    Dolnośląscy policjanci zrobili akcję na autostradzie A4. Latali dronami i filmowali tiry wyprzedzające na zakazie.

## Przepłynął ponad dwa kilometry w wodzie o temperaturze poniżej zera. Krzysztof Gajewski pobił rekord Guinnessa
 - [https://fakty.tvn24.pl/przep-yn---ponad-dwa-kilometry-w-wodzie-o-temperaturze-poni-ej-zera--krzysztof-gajewski-pobi--rekord-guinnessa,1128964.html?source=rss](https://fakty.tvn24.pl/przep-yn---ponad-dwa-kilometry-w-wodzie-o-temperaturze-poni-ej-zera--krzysztof-gajewski-pobi--rekord-guinnessa,1128964.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 18:05:00+00:00

<img alt="Przepłynął ponad dwa kilometry w wodzie o temperaturze poniżej zera. Krzysztof Gajewski pobił rekord Guinnessa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4lowgk-przeplynal-ponad-dwa-kilometry-w-wodzie-o-temperaturze-ponizej-zera-krzysztof-gajewski-pobil-rekord-guinessa/alternates/LANDSCAPE_1280" />
    Ten wyczyn nawet na doświadczonych w morsowaniu musi robić wrażenie.

## Przez atak zimy utknęli na lotnisku Londyn-Luton. "Od wczoraj nie wiemy, kiedy wylecimy"
 - [https://tvn24.pl/najnowsze/kilkaset-osob-z-polski-utknelo-na-lotnisku-londyn-luton-przez-atak-zimy-w-wielkiej-brytanii-6466168?source=rss](https://tvn24.pl/najnowsze/kilkaset-osob-z-polski-utknelo-na-lotnisku-londyn-luton-przez-atak-zimy-w-wielkiej-brytanii-6466168?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 17:51:42+00:00

<img alt="Przez atak zimy utknęli na lotnisku Londyn-Luton. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-r54rh6-kilkaset-osob-z-polski-utknelo-na-lotnisku-londyn-luton-przez-atak-zimy-w-wielkiej-brytanii-6466165/alternates/LANDSCAPE_1280" />
    Relację z lotniska Londyn-Luton otrzymaliśmy na Kontakt 24.

## Polska ambasada wydała ostrzeżenie przed meczem mundialu
 - [https://eurosport.tvn24.pl/polska-ambasada-wyda-a-ostrze-enie-przed-meczem-mundialu,1128945.html?source=rss](https://eurosport.tvn24.pl/polska-ambasada-wyda-a-ostrze-enie-przed-meczem-mundialu,1128945.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 17:12:00+00:00

<img alt="Polska ambasada wydała ostrzeżenie przed meczem mundialu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bsw8ho-marokanczycy-swietowali-awans-do-polfinalu-min-na-ulicach-paryza-6466139/alternates/LANDSCAPE_1280" />
    "Prosimy o unikanie zgromadzeń na ulicach i bezwzględne stosowanie się do poleceń służb porządkowych".

## Zapadła się kopuła nad boiskiem sportowym
 - [https://tvn24.pl/katowice/zabrze-zapadla-sie-kopula-boiska-sportowego-straz-pozarna-prawdopodobnie-pod-naporem-sniegu-6466088?source=rss](https://tvn24.pl/katowice/zabrze-zapadla-sie-kopula-boiska-sportowego-straz-pozarna-prawdopodobnie-pod-naporem-sniegu-6466088?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 17:10:20+00:00

<img alt="Zapadła się kopuła nad boiskiem sportowym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lpbi6q-straz-pozarna-6357057/alternates/LANDSCAPE_1280" />
    Straż pożarna: prawdopodobną przyczyną zalegający na niej śnieg.

## Mark Brzeziński odwiedził gospodarstwo niedaleko Zambrowa
 - [https://fakty.tvn24.pl/mark-brzezi-ski-odwiedzi--gospodarstwo-niedaleko-zambrowa,1128940.html?source=rss](https://fakty.tvn24.pl/mark-brzezi-ski-odwiedzi--gospodarstwo-niedaleko-zambrowa,1128940.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 17:08:00+00:00

<img alt="Mark Brzeziński odwiedził gospodarstwo niedaleko Zambrowa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zisu6d-mark-brzezinski-odwiedzil-rodzinna-farme-niedaleko-zambrowa/alternates/LANDSCAPE_1280" />
    Ambasador Stanów Zjednoczonych powiedział również kilka słów po polsku.

## Kim jest bohaterka "najbardziej szokującego skandalu w historii Unii"
 - [https://tvn24.pl/swiat/kim-jest-eva-kaili-bohaterka-najbardziej-szokujacego-skandalu-w-historii-unii-6466073?source=rss](https://tvn24.pl/swiat/kim-jest-eva-kaili-bohaterka-najbardziej-szokujacego-skandalu-w-historii-unii-6466073?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 16:58:45+00:00

<img alt="Kim jest bohaterka " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dv6u66-kariera-44-letniej-evy-kaili-do-piatku-bylo-pasmem-sukcesow-6466078/alternates/LANDSCAPE_1280" />
    Do piątku Eva Kaili kroczyła od sukcesu do sukcesu.

## Żona Brittney Griner o pierwszych dniach koszykarki po powrocie do domu. "Rozpoczynamy drogę ku uleczeniu"
 - [https://tvn24.pl/swiat/usa-zona-brittney-griner-o-pierwszych-dniach-koszykarki-po-powrocie-do-domu-rozpoczynamy-droge-ku-uleczeniu-6466052?source=rss](https://tvn24.pl/swiat/usa-zona-brittney-griner-o-pierwszych-dniach-koszykarki-po-powrocie-do-domu-rozpoczynamy-droge-ku-uleczeniu-6466052?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 16:57:38+00:00

<img alt="Żona Brittney Griner o pierwszych dniach koszykarki po powrocie do domu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-phs2cm-brittney-i-cherelle-griner-6466032/alternates/LANDSCAPE_1280" />
    "Wczoraj moje serce stało się ponownie kompletne".

## Nie ma podwyżki, ma być strajk. Szykują się duże utrudnienia dla pasażerów
 - [https://tvn24.pl/biznes/ze-swiata/strajk-pracownikow-spolki-aena-operatora-lotnisk-w-hiszpanii-6465937?source=rss](https://tvn24.pl/biznes/ze-swiata/strajk-pracownikow-spolki-aena-operatora-lotnisk-w-hiszpanii-6465937?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 16:54:38+00:00

Głównym postulatem jest kilkuprocentowa podwyżka płac.

## Coraz więcej Polaków zmaga się z biedą. "Na cały miesiąc zostaje na przykład 60 złotych. Jak żyć?"
 - [https://fakty.tvn24.pl/coraz-wi-cej-polak-w-zmaga-si--z-bied----na-ca-y-miesi-c-zostaje-na-przyk-ad-60-z-otych--jak--y---,1128904.html?source=rss](https://fakty.tvn24.pl/coraz-wi-cej-polak-w-zmaga-si--z-bied----na-ca-y-miesi-c-zostaje-na-przyk-ad-60-z-otych--jak--y---,1128904.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 16:53:00+00:00

<img alt="Coraz więcej Polaków zmaga się z biedą. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gfidcu-coraz-wiecej-polakow-zmaga-sie-z-bieda-na-caly-miesiac-zostaje-na-przyklad-60-zlotych-jak-zyc/alternates/LANDSCAPE_1280" />
    Ponad półtora miliona Polaków żyje w skrajnym ubóstwie. 300 tysięcy to dzieci, a ponad 200 tysięcy to seniorzy.

## Kilka godzin utrudnień po wypadku w metrze
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wypadek-w-metrze-nie-kursowaly-pociagi-6466071?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wypadek-w-metrze-nie-kursowaly-pociagi-6466071?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 16:50:57+00:00

<img alt="Kilka godzin utrudnień po wypadku w metrze" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-u7xbca-nie-dziala-pierwsza-linia-metra-6466153/alternates/LANDSCAPE_1280" />
    Na stacji Racławicka pod kołami pociągu zginął mężczyzna.

## Utrudnienia w metrze po wypadku. Wstrzymany ruch na odcinku Dworzec Gdański–Stokłosy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-nie-kursuje-pierwsza-linia-metra-na-odcinku-dworzec-gdanski-stoklosy-6466071?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-nie-kursuje-pierwsza-linia-metra-na-odcinku-dworzec-gdanski-stoklosy-6466071?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 16:50:57+00:00

<img alt="Utrudnienia w metrze po wypadku. Wstrzymany ruch na odcinku Dworzec Gdański–Stokłosy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-dbfk9f-nie-kursuje-pierwsza-linia-metra-6466153/alternates/LANDSCAPE_1280" />
    W obu kierunkach.

## Niespodziewana kandydatura na nowego selekcjonera Brazylii
 - [https://eurosport.tvn24.pl/niespodziewana-kandydatura-na-nowego-selekcjonera-brazylii,1128917.html?source=rss](https://eurosport.tvn24.pl/niespodziewana-kandydatura-na-nowego-selekcjonera-brazylii,1128917.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 16:13:00+00:00

<img alt="Niespodziewana kandydatura na nowego selekcjonera Brazylii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mmqta5-brazylia-odpadla-z-mundialu-w-cwiercfinale/alternates/LANDSCAPE_1280" />
    Podaje portal UOL Esporte.

## Eksperci ostrzegają przed tusi. "Narkotyk elit" coraz częściej dociera do Europy
 - [https://tvn24.pl/ciekawostki/tusi-rozowa-kokaina-z-kolumbii-narkotyk-oparty-na-2c-b-coraz-czesciej-dociera-do-europy-6465618?source=rss](https://tvn24.pl/ciekawostki/tusi-rozowa-kokaina-z-kolumbii-narkotyk-oparty-na-2c-b-coraz-czesciej-dociera-do-europy-6465618?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 16:12:49+00:00

<img alt="Eksperci ostrzegają przed tusi. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-48qky7-pink-cocaine-6465661/alternates/LANDSCAPE_1280" />
    To bardzo nieprzewidywalna mieszanka, jej zażywanie może prowadzić do uszkodzenia układu nerwowego, a nawet do śmierci.

## Kubacki ma dla kogo wygrywać
 - [https://eurosport.tvn24.pl/kubacki-ma-dla-kogo-wygrywa---du-a-ogl-dalno---konkurs-w-w-titisee-neustadt,1128919.html?source=rss](https://eurosport.tvn24.pl/kubacki-ma-dla-kogo-wygrywa---du-a-ogl-dalno---konkurs-w-w-titisee-neustadt,1128919.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 16:02:00+00:00

<img alt="Kubacki ma dla kogo wygrywać" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hx0t1p-dawid-kubacki-jest-w-wysmienitej-formie-6466029/alternates/LANDSCAPE_1280" />
    Duża oglądalność konkursów w Titisee-Neustadt.

## "Poważne zakłócenia" w Wielkiej Brytanii. Oświadczenie linii lotniczej
 - [https://tvn24.pl/biznes/ze-swiata/odwolane-loty-w-wielkiej-brytanii-komunikat-wizz-air-6465969?source=rss](https://tvn24.pl/biznes/ze-swiata/odwolane-loty-w-wielkiej-brytanii-komunikat-wizz-air-6465969?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 15:53:46+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cyjtg0-shutterstock127280357-6466010/alternates/LANDSCAPE_1280" />
    W związku z dużymi opadami śniegu.

## Klub PiS spotkał się przed "najważniejszym w tym roku głosowaniem"
 - [https://tvn24.pl/polska/posiedzenie-klubu-parlamentarnego-pis-omowiono-glosowania-w-sejmie-w-tym-to-budzetowe-6465985?source=rss](https://tvn24.pl/polska/posiedzenie-klubu-parlamentarnego-pis-omowiono-glosowania-w-sejmie-w-tym-to-budzetowe-6465985?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 15:45:02+00:00

<img alt="Klub PiS spotkał się przed " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5moczj-pis-6466111/alternates/LANDSCAPE_1280" />
    Posiedzenie odbyło się w siedzibie PiS-u.

## Spotkał się klub PiS. Czy był Ziobro? Terlecki: nie widziałem, może przeoczyłem
 - [https://tvn24.pl/polska/klub-parlamentarny-pis-omowil-glosowania-w-sejmie-w-tym-budzetowe-pytania-o-zbigniewa-ziobro-6465985?source=rss](https://tvn24.pl/polska/klub-parlamentarny-pis-omowil-glosowania-w-sejmie-w-tym-budzetowe-pytania-o-zbigniewa-ziobro-6465985?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 15:45:02+00:00

<img alt="Spotkał się klub PiS. Czy był Ziobro? Terlecki: nie widziałem, może przeoczyłem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5moczj-pis-6466111/alternates/LANDSCAPE_1280" />
    Posiedzenie odbyło się w siedzibie PiS przy Nowogrodzkiej w Warszawie.

## Spięcie na granicy Indii i Chin. Obrażenia żołnierzy po obu stronach
 - [https://tvn24.pl/swiat/indie-chiny-starcie-zolnierzy-dwoch-mocarstw-w-stanie-arunachal-pradesh-6465778?source=rss](https://tvn24.pl/swiat/indie-chiny-starcie-zolnierzy-dwoch-mocarstw-w-stanie-arunachal-pradesh-6465778?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 15:11:53+00:00

<img alt="Spięcie na granicy Indii i Chin. Obrażenia żołnierzy po obu stronach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5yw35a-konwoj-chinskich-zolniery-w-poblizu-granicy-z-indiami-zdjecie-z-wrzesnia-2020-orku-6465938/alternates/LANDSCAPE_1280" />
    W okolicach miasta Tawang w stanie Arunachal Pradesh.

## Wracali z koncertu, uderzyli w słup. Jeden z młodych mężczyzn nie żyje, drugi jest ranny. Kierowca aresztowany
 - [https://tvn24.pl/tvnwarszawa/najnowsze/runow-wracali-z-koncertu-jeden-z-mlodych-mezczyzn-nie-zyje-drugi-jest-ranny-kierowca-z-zarzutami-i-aresztem-6465819?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/runow-wracali-z-koncertu-jeden-z-mlodych-mezczyzn-nie-zyje-drugi-jest-ranny-kierowca-z-zarzutami-i-aresztem-6465819?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 15:09:43+00:00

<img alt="Wracali z koncertu, uderzyli w słup. Jeden z młodych mężczyzn nie żyje, drugi jest ranny. Kierowca aresztowany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3irmqp-smiertelny-wypadek-w-runowie-6443243/alternates/LANDSCAPE_1280" />
    Do wypadku doszło w Runowie (powiat piaseczyński).

## Ile śniegu dosypie? Gdzie i kiedy będzie najzimniej? Prognoza pogody na 5 dni
 - [https://tvn24.pl/tvnmeteo/pogoda/ile-sniegu-dosypie-gdzie-i-kiedy-bedzie-najzimniej-prognoza-pogody-na-5-dni-6465797?source=rss](https://tvn24.pl/tvnmeteo/pogoda/ile-sniegu-dosypie-gdzie-i-kiedy-bedzie-najzimniej-prognoza-pogody-na-5-dni-6465797?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 15:07:23+00:00

<img alt="Ile śniegu dosypie? Gdzie i kiedy będzie najzimniej? Prognoza pogody na 5 dni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-yr95se-do-sniegu-dolaczy-mroz-6465933/alternates/LANDSCAPE_1280" />
    Pogoda w najbliższych dniach wciąż będzie pochmurna i śnieżna.

## Trzeszczy w rządowej koalicji. Rzecznik: wtedy też głosami opozycji udało się ustawę przegłosować
 - [https://tvn24.pl/biznes/z-kraju/kpo-srodki-z-ue-rzecznik-rzadu-o-glosowaniu-w-parlamencie-i-roli-solidarnej-polski-6465686?source=rss](https://tvn24.pl/biznes/z-kraju/kpo-srodki-z-ue-rzecznik-rzadu-o-glosowaniu-w-parlamencie-i-roli-solidarnej-polski-6465686?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 14:59:00+00:00

<img alt="Trzeszczy w rządowej koalicji. Rzecznik: wtedy też głosami opozycji udało się ustawę przegłosować" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hcswmh-rzecznik-rzadu-piotr-mueller-6465860/alternates/LANDSCAPE_1280" />
    Rzecznik rządu Piotr Mueller o kwestii głosowania Solidarnej Polski i środkach z KPO dla Polski.

## Poznaliśmy nominacje do Złotych Globów
 - [https://tvn24.pl/kultura-i-styl/zlote-globy-2023-nominacje-filmy-seriale-aktorzy-lista-6464687?source=rss](https://tvn24.pl/kultura-i-styl/zlote-globy-2023-nominacje-filmy-seriale-aktorzy-lista-6464687?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 14:45:07+00:00

<img alt="Poznaliśmy nominacje do Złotych Globów " src="https://tvn24.pl/najnowsze/cdn-zdjecie-zelra1-zlote-globy-6465629/alternates/LANDSCAPE_1280" />
    Wśród filmów listę zdominowała czarna komedia "Duchy Inisherin", która zdobyła osiem nominacji.

## Iga Świątek wybrana najlepszą tenisistką roku przez WTA
 - [https://eurosport.tvn24.pl/iga--wi-tek-wybrana-najlepsz--tenisistk--roku-przez-wta,1128901.html?source=rss](https://eurosport.tvn24.pl/iga--wi-tek-wybrana-najlepsz--tenisistk--roku-przez-wta,1128901.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 14:34:00+00:00

<img alt="Iga Świątek wybrana najlepszą tenisistką roku przez WTA" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c28aou-iga-swiatek/alternates/LANDSCAPE_1280" />
    Wielkie wyróżnienie dla polskiej zawodniczki.

## Komunikat PZPN w sprawie Czesława Michniewicza
 - [https://eurosport.tvn24.pl/komunikat-pzpn-w-sprawie-czes-awa-michniewicza,1128893.html?source=rss](https://eurosport.tvn24.pl/komunikat-pzpn-w-sprawie-czes-awa-michniewicza,1128893.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 14:10:36+00:00

<img alt="Komunikat PZPN w sprawie Czesława Michniewicza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mvvfa0-michniewicz-prowadzil-reprezentacje-polski-w-13-meczach-6465765/alternates/LANDSCAPE_1280" />
    Po spotkaniu z prezesem.

## Pływacy "zjednoczeni pod nową marką"
 - [https://eurosport.tvn24.pl/p-ywacy--zjednoczeni-pod-now--mark----ich-federacja-zmieni-a-nazw-,1128891.html?source=rss](https://eurosport.tvn24.pl/p-ywacy--zjednoczeni-pod-now--mark----ich-federacja-zmieni-a-nazw-,1128891.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 13:52:33+00:00

<img alt="Pływacy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-o2ehbv-plywanie/alternates/LANDSCAPE_1280" />
    Ich federacja zmieniła nazwę.

## Miliony psów i kotów powinny zginąć, żeby zmniejszyć ślad węglowy? To fejk
 - [https://konkret24.tvn24.pl/swiat/miliony-psow-i-kotow-powinny-zginac-zeby-zmniejszyc-slad-weglowy-to-fejk-6464825?source=rss](https://konkret24.tvn24.pl/swiat/miliony-psow-i-kotow-powinny-zginac-zeby-zmniejszyc-slad-weglowy-to-fejk-6464825?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 13:49:09+00:00

<img alt="Miliony psów i kotów powinny zginąć, żeby zmniejszyć ślad węglowy? To fejk" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5jy75b-swiatowe-forum-ekonomiczne-wzywa-do-zabicia-milionow-kotow-i-psow-zeby-zmniejszyc-slad-weglowy-to-fejk-6465242/alternates/LANDSCAPE_1280" />
    Źródłem tych doniesień jest niewiarygodny serwis.

## "Chodzi o wiarygodność Europy". Unijni przywódcy reagują na skandal
 - [https://tvn24.pl/swiat/parlament-europejski-aresztowanie-evy-kaili-unijni-przywodcy-o-aferze-korupcyjnej-6465496?source=rss](https://tvn24.pl/swiat/parlament-europejski-aresztowanie-evy-kaili-unijni-przywodcy-o-aferze-korupcyjnej-6465496?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 13:45:45+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wu7k9n-parlament-europejski-zatwierdzil-18-mld-euro-pozyczki-dla-ukrainy-w-2023-roku-6235628/alternates/LANDSCAPE_1280" />
    Sprawa dotyczy zarzutów wobec Evy Kaili.

## Nazywają to "telefonem do Putina". Wróciła rosyjska tortura z czasów czeczeńskich
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-telefon-do-putina-rosyjska-tortura-z-czasow-czeczenskich-6465235?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-telefon-do-putina-rosyjska-tortura-z-czasow-czeczenskich-6465235?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 13:42:01+00:00

<img alt="Nazywają to " src="https://tvn24.pl/najnowsze/cdn-zdjecie-yldm2j-masowy-grob-w-lesie-w-poblizu-wyzwolonego-miasta-izium-w-obwodzie-charkowskim-6465560/alternates/LANDSCAPE_1280" />
    "Mogli być kreatywni w wielu rzeczach, ale zdecydowali się być kreatywni w zadawaniu bólu".

## Opublikowano pierwszą kartkę świąteczną Karola w roli króla. Na zdjęciu wpatrzona w niego Kamila
 - [https://tvn24.pl/swiat/wielka-brytania-pierwsza-kartka-swiateczna-krola-karola-iii-na-zdjeciu-monarcha-z-zona-kamila-6465559?source=rss](https://tvn24.pl/swiat/wielka-brytania-pierwsza-kartka-swiateczna-krola-karola-iii-na-zdjeciu-monarcha-z-zona-kamila-6465559?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 13:25:31+00:00

<img alt="Opublikowano pierwszą kartkę świąteczną Karola w roli króla. Na zdjęciu wpatrzona w niego Kamila" src="https://tvn24.pl/najnowsze/cdn-zdjecie-71gfm1-ksiaze-karol-5401578/alternates/LANDSCAPE_1280" />
    Zdjęcie zrobiono pięć dni przed śmiercią królowej Elżbiety II.

## Oto laureaci Nagrody im. Marcina Pawłowskiego i Dariusza Kmiecika
 - [https://tvn24.pl/kultura-i-styl/nagroda-imienia-marcina-pawlowskiego-i-dariusza-kmiecika-za-2022-rok-laureaci-i-finalisci-6464911?source=rss](https://tvn24.pl/kultura-i-styl/nagroda-imienia-marcina-pawlowskiego-i-dariusza-kmiecika-za-2022-rok-laureaci-i-finalisci-6464911?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 13:05:43+00:00

<img alt="Oto laureaci Nagrody im. Marcina Pawłowskiego i Dariusza Kmiecika " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xt6h35-nagrody-imienia-marcina-pawlowskiego-i-dariusza-kmiecika-za-2022-rok-6465521/alternates/LANDSCAPE_1280" />
    Zobacz wyróżnione materiały.

## "FT": Przełom w badaniach nad fuzją jądrową. Wkrótce oświadczenie Departamentu Energii USA
 - [https://tvn24.pl/biznes/ze-swiata/przelom-w-pracach-nad-fuzja-jadrowa-wkrotce-oswiadczenie-departamentu-energii-usa-financial-times-6464844?source=rss](https://tvn24.pl/biznes/ze-swiata/przelom-w-pracach-nad-fuzja-jadrowa-wkrotce-oswiadczenie-departamentu-energii-usa-financial-times-6464844?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 12:57:40+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-i7rjeg-wzmacniacze-national-ignition-facility-lasera-ktory-pomogl-odtworzyc-warunki-panujace-w-planetarnych-wnetrzach-4836083/alternates/LANDSCAPE_1280" />
    Fuzja jądrowa może stać się niemal nieograniczonym źródłem energii.

## "Io" czaruje za oceanem. Jest kolejna nagroda
 - [https://tvn24.pl/kultura-i-styl/io-jerzego-skolimowskiego-z-kolejnymi-nagrodami-amerykanskich-krytykow-6464590?source=rss](https://tvn24.pl/kultura-i-styl/io-jerzego-skolimowskiego-z-kolejnymi-nagrodami-amerykanskich-krytykow-6464590?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 12:56:54+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-23exyq-kadr-z-filmu-io-jerzego-skolimowskiego-6464589/alternates/LANDSCAPE_1280" />
    Stowarzyszenie Krytyków Filmowych z Los Angeles uhonorowało najnowszy film Jerzego Skolimowskiego.

## Nowa piłka na najważniejsze mecze mundialu
 - [https://eurosport.tvn24.pl/nowa-pi-ka-na-najwa-niejsze-mecze-mundialu--czyje-spe-ni-sny-,1128877.html?source=rss](https://eurosport.tvn24.pl/nowa-pi-ka-na-najwa-niejsze-mecze-mundialu--czyje-spe-ni-sny-,1128877.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 12:47:42+00:00

<img alt="Nowa piłka na najważniejsze mecze mundialu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8x2mqk-al-hilm-nowa-pilka-na-ostatnie-mecze-mundialu/alternates/LANDSCAPE_1280" />
    Czyje spełni sny?

## "Jesteś pieszym, więc znaj swoje miejsce!" Jezdnie czarne, ale przystanki zasypane
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-kto-odpowiada-za-odsniezanie-przystankow-6465382?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-kto-odpowiada-za-odsniezanie-przystankow-6465382?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 12:37:01+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-fxnp7t-zasniezone-chodniki-i-przystanki-w-warszawie-6465422/alternates/LANDSCAPE_1280" />
     Zarząd Oczyszczania Miasta tłumaczy.

## Ważą się losy Michniewicza. Prezes PZPN: czekam na niego
 - [https://eurosport.tvn24.pl/wa---si--losy-michniewicza--prezes-pzpn--czekam-na-niego,1128886.html?source=rss](https://eurosport.tvn24.pl/wa---si--losy-michniewicza--prezes-pzpn--czekam-na-niego,1128886.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 12:27:28+00:00

<img alt="Ważą się losy Michniewicza. Prezes PZPN: czekam na niego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hhol1j-cezary-kulesza-i-czeslaw-michniewicz-6465512/alternates/LANDSCAPE_1280" />
    W poniedziałek dojdzie do spotkania na szczycie w PZPN.

## Tutaj w niedzielę spadło najwięcej śniegu
 - [https://tvn24.pl/tvnmeteo/pogoda/snieg-w-polsce-gdzie-spadlo-go-najwiecej-imgw-podal-dane-6465333?source=rss](https://tvn24.pl/tvnmeteo/pogoda/snieg-w-polsce-gdzie-spadlo-go-najwiecej-imgw-podal-dane-6465333?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 12:25:37+00:00

<img alt="Tutaj w niedzielę spadło najwięcej śniegu" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-wz3sm2-intensywne-opady-sniegu-6465469/alternates/LANDSCAPE_1280" />
    IMGW podał dane.

## Żaryn o śledztwie w sprawie Tomasza L.: ma charakter wielowątkowy i jest niejawne
 - [https://tvn24.pl/polska/sprawa-tomasza-l-stanislaw-zaryn-zastepca-koordynatora-sluzb-specjalnych-sledztwo-wielowatkowe-i-niejawne-6465339?source=rss](https://tvn24.pl/polska/sprawa-tomasza-l-stanislaw-zaryn-zastepca-koordynatora-sluzb-specjalnych-sledztwo-wielowatkowe-i-niejawne-6465339?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 12:24:45+00:00

<img alt="Żaryn o śledztwie w sprawie Tomasza L.: ma charakter wielowątkowy i jest niejawne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-15j8bj-stanislaw-zaryn-6465375/alternates/LANDSCAPE_1280" />
    Oświadczenie zastępcy ministra koordynatora służb specjalnych.

## Kosztowny atak zimy, miliony na odśnieżanie dróg
 - [https://tvn24.pl/najnowsze/lodz-lublin-kosztowny-atak-zimy-miliony-na-odsniezanie-drog-6465347?source=rss](https://tvn24.pl/najnowsze/lodz-lublin-kosztowny-atak-zimy-miliony-na-odsniezanie-drog-6465347?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 12:20:36+00:00

<img alt="Kosztowny atak zimy, miliony na odśnieżanie dróg" src="https://tvn24.pl/najnowsze/cdn-zdjecie-71j8ky-drogie-odsniezanie-miast-6465220/alternates/LANDSCAPE_1280" />
    Łódź przez weekend wydała ponad 2,5 miliona złotych, Lublin już 1,2 miliona.

## Zatrzymali ją, bo jechała nieodśnieżonym autem. Miała blisko pięć promili
 - [https://tvn24.pl/polska/bielsko-biala-zatrzymali-ja-bo-jechala-nieodsniezonym-autem-miala-blisko-piec-promili-6465445?source=rss](https://tvn24.pl/polska/bielsko-biala-zatrzymali-ja-bo-jechala-nieodsniezonym-autem-miala-blisko-piec-promili-6465445?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 12:08:38+00:00

<img alt="Zatrzymali ją, bo jechała nieodśnieżonym autem. Miała blisko pięć promili" src="https://tvn24.pl/pomorze/cdn-zdjecie-ozrzzh-nietrzezwy-mezczyzna-prowadzil-karawan-mial-ponad-05-promila-6109718/alternates/LANDSCAPE_1280" />

## Na opuszczonej posesji odnaleźli tablicę upamiętniającą ofiary egzekucji z II wojny światowej
 - [https://tvn24.pl/tvnwarszawa/praga-poludnie/warszawa-na-opuszczonej-posesji-na-pradze-odnalezli-pamiatkowa-tablice-6431596?source=rss](https://tvn24.pl/tvnwarszawa/praga-poludnie/warszawa-na-opuszczonej-posesji-na-pradze-odnalezli-pamiatkowa-tablice-6431596?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 12:01:20+00:00

<img alt="Na opuszczonej posesji odnaleźli tablicę upamiętniającą ofiary egzekucji z II wojny światowej" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6qh0xx-tablica-zostala-odnaleziona-na-opuszczonej-praskiej-posesji-6431916/alternates/LANDSCAPE_1280" />
    Sprawie przygląda się urząd Mazowieckiego Wojewódzkiego Konserwatora Zabytków.

## Andrzej Duda w Berlinie. Powitał go Frank-Walter Steinmeier
 - [https://tvn24.pl/swiat/niemcy-wizyta-andrzeja-dudy-w-berlinie-prezydent-andrzej-duda-powitany-przez-franka-waltera-steinmeiera-6465282?source=rss](https://tvn24.pl/swiat/niemcy-wizyta-andrzeja-dudy-w-berlinie-prezydent-andrzej-duda-powitany-przez-franka-waltera-steinmeiera-6465282?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 11:56:27+00:00

<img alt="Andrzej Duda w Berlinie. Powitał go Frank-Walter Steinmeier" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b4rszh-duda-6465276/alternates/LANDSCAPE_1280" />
    Prezydent Polski z roboczą wizytą w Niemczech.

## Projektantka wnętrz oskarżona o zabójstwo ojczyma. Znalazła swoje nagie zdjęcia na jego komputerze
 - [https://tvn24.pl/swiat/usa-projektantka-wnetrz-oskarzona-o-zabojstwo-znalazla-swoje-nagie-zdjecia-u-ojczyma-6464678?source=rss](https://tvn24.pl/swiat/usa-projektantka-wnetrz-oskarzona-o-zabojstwo-znalazla-swoje-nagie-zdjecia-u-ojczyma-6464678?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 11:55:57+00:00

<img alt="Projektantka wnętrz oskarżona o zabójstwo ojczyma. Znalazła swoje nagie zdjęcia na jego komputerze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9d9gxy-jade-6464689/alternates/LANDSCAPE_1280" />
    Nagie zdjęcie przybranej córki miało być wygaszaczem ekranu 64-latka.

## Ustalenia operacyjne w sprawie polskiego KPO podpisane. Jest decyzja Komisji Europejskiej
 - [https://tvn24.pl/biznes/z-kraju/kpo-komisja-europojska-podpisala-ustalenia-operacyjne-w-sprawie-polskiego-kpo-grzegorz-puda-o-szczegolach-6465380?source=rss](https://tvn24.pl/biznes/z-kraju/kpo-komisja-europojska-podpisala-ustalenia-operacyjne-w-sprawie-polskiego-kpo-grzegorz-puda-o-szczegolach-6465380?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 11:54:32+00:00

<img alt="Ustalenia operacyjne w sprawie polskiego KPO podpisane. Jest decyzja Komisji Europejskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0jl13x-komisja-europejska-5452065/alternates/LANDSCAPE_1280" />
    Przekazał Grzegorz Puda, minister funduszy i polityki regionalnej.

## Kilkaset tysięcy wniosków o dodatek węglowy nadal pod lupą
 - [https://tvn24.pl/biznes/z-kraju/dodatek-weglowy-kilkaset-tysiecy-wnioskow-w-trakcie-rozpatrywania-anna-moskwa-podala-nowe-dane-6465233?source=rss](https://tvn24.pl/biznes/z-kraju/dodatek-weglowy-kilkaset-tysiecy-wnioskow-w-trakcie-rozpatrywania-anna-moskwa-podala-nowe-dane-6465233?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 11:52:50+00:00

<img alt="Kilkaset tysięcy wniosków o dodatek węglowy nadal pod lupą" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-25ef8c-wegiel-torun-6465320/alternates/LANDSCAPE_1280" />
    Nowe dane.

## "Nigdy nie traktowałam igrzysk jako sposobu zarobkowania". Świątek odpowiada byłemu szefowi PZT
 - [https://eurosport.tvn24.pl/-nigdy-nie-traktowa-am-igrzysk-jako-sposobu-zarobkowania----wi-tek-odpowiada-na-s-owa-by-ego-prezesa-pzt,1128881.html?source=rss](https://eurosport.tvn24.pl/-nigdy-nie-traktowa-am-igrzysk-jako-sposobu-zarobkowania----wi-tek-odpowiada-na-s-owa-by-ego-prezesa-pzt,1128881.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 11:49:45+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rzd0qi-iga-swiatek-6110376/alternates/LANDSCAPE_1280" />
    Mirosław Skrzypczyński, były prezes Polskiego Związku Tenisowego, odniósł się do występu polskich tenisistów w igrzyskach olimpijskich w Tokio.

## Pięć osób rannych w karambolu. W tym dzieci i kobiety w ciąży
 - [https://tvn24.pl/polska/korczowa-karambol-na-a4-piec-osob-rannych-w-zderzeniu-pieciu-samochodow-6465187?source=rss](https://tvn24.pl/polska/korczowa-karambol-na-a4-piec-osob-rannych-w-zderzeniu-pieciu-samochodow-6465187?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 11:17:26+00:00

<img alt="Pięć osób rannych w karambolu. W tym dzieci i kobiety w ciąży" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zxbomb-z-zderzeniu-pieciu-samochodow-ranne-zostaly-trzy-kobiety-i-dwoje-dzieci-6465188/alternates/LANDSCAPE_1280" />
    Do zdarzenia doszło na autostradzie A4 w Korczowej (woj. podkarpackie).

## Lód załamał się pod grupą dzieci. Czworo jest w stanie krytycznym
 - [https://tvn24.pl/swiat/wielka-brytania-lod-zalamal-sie-pod-grupa-dzieci-czworo-jest-w-stanie-krytycznym-6465150?source=rss](https://tvn24.pl/swiat/wielka-brytania-lod-zalamal-sie-pod-grupa-dzieci-czworo-jest-w-stanie-krytycznym-6465150?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 11:13:23+00:00

<img alt="Lód załamał się pod grupą dzieci. Czworo jest w stanie krytycznym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l9nk8n-lod-zima-kra-jezioro-shutterstock147580883-6465175/alternates/LANDSCAPE_1280" />
    Zespół ratowników "pracuje w bardzo trudnych warunkach, przy bardzo niskiej temperaturze".

## Lód załamał się pod grupą dzieci. Troje nie żyje, jedno w stanie krytycznym
 - [https://tvn24.pl/swiat/wielka-brytania-lod-zalamal-sie-pod-grupa-dzieci-troje-z-nich-nie-zyje-6465150?source=rss](https://tvn24.pl/swiat/wielka-brytania-lod-zalamal-sie-pod-grupa-dzieci-troje-z-nich-nie-zyje-6465150?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 11:13:23+00:00

<img alt="Lód załamał się pod grupą dzieci. Troje nie żyje, jedno w stanie krytycznym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l9nk8n-lod-zima-kra-jezioro-shutterstock147580883-6465175/alternates/LANDSCAPE_1280" />
    Zespół ratowników "pracuje w bardzo trudnych warunkach, przy bardzo niskiej temperaturze".

## Piętnaście nowych miast w Polsce od stycznia
 - [https://tvn24.pl/biznes/z-kraju/nowe-miasta-2023-pietnascie-nowych-miast-w-polsce-od-1-stycznia-2023-zmiany-dla-blisko-137-tysiecy-mieszkancow-6465190?source=rss](https://tvn24.pl/biznes/z-kraju/nowe-miasta-2023-pietnascie-nowych-miast-w-polsce-od-1-stycznia-2023-zmiany-dla-blisko-137-tysiecy-mieszkancow-6465190?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 11:08:55+00:00

<img alt="Piętnaście nowych miast w Polsce od stycznia" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-uj9wuv-miekinia-5781618/alternates/LANDSCAPE_1280" />
    Rozporządzenie czeka na wejście w życie.

## Piętnaście nowych miast w Polsce od stycznia
 - [https://tvn24.pl/biznes/z-kraju/nowe-miasta-w-polsce-od-stycznia-2023-lista-6465190?source=rss](https://tvn24.pl/biznes/z-kraju/nowe-miasta-w-polsce-od-stycznia-2023-lista-6465190?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 11:08:55+00:00

<img alt="Piętnaście nowych miast w Polsce od stycznia" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-uj9wuv-miekinia-5781618/alternates/LANDSCAPE_1280" />
    Rozporządzenie czeka na wejście w życie.

## Sześciolatka w samej piżamie i bez butów błąkała się po osiedlu
 - [https://tvn24.pl/krakow/kielce-szesciolatka-w-samej-pizamie-boso-szla-chodnikiem-6465154?source=rss](https://tvn24.pl/krakow/kielce-szesciolatka-w-samej-pizamie-boso-szla-chodnikiem-6465154?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 11:02:49+00:00

<img alt="Sześciolatka w samej piżamie i bez butów błąkała się po osiedlu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cb1omu-zima-plac-zabaw-6465197/alternates/LANDSCAPE_1280" />
    W niedzielę w Kielcach.

## Prawie 900 osób nadal bez prądu po ataku zimy
 - [https://tvn24.pl/polska/podkarpackie-prawie-900-osob-nadal-bez-pradu-strazacy-pomagali-chorym-w-domach-6465119?source=rss](https://tvn24.pl/polska/podkarpackie-prawie-900-osob-nadal-bez-pradu-strazacy-pomagali-chorym-w-domach-6465119?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 10:49:17+00:00

<img alt="Prawie 900 osób nadal bez prądu po ataku zimy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fuimgl-podkarpaccy-strazacy-po-intensywnych-opadach-sniegu-w-ciagu-ostatniej-doby-interweniowali-ponad-160-razy-6465120/alternates/LANDSCAPE_1280" />
    Strażacy pomagali chorym w domach. Udostępniali agregaty prądotwórcze

## Sejmowa komisja zajmie się wnioskiem o wotum nieufności wobec Zbigniewa Ziobry
 - [https://tvn24.pl/polska/zbigniew-ziobro-wniosek-o-wotum-nieufnosci-wobec-ministra-sprawiedliwosci-posiedzenie-komisji-w-sejmie-6465117?source=rss](https://tvn24.pl/polska/zbigniew-ziobro-wniosek-o-wotum-nieufnosci-wobec-ministra-sprawiedliwosci-posiedzenie-komisji-w-sejmie-6465117?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 10:19:12+00:00

<img alt="Sejmowa komisja zajmie się wnioskiem o wotum nieufności wobec Zbigniewa Ziobry" src="https://tvn24.pl/najnowsze/cdn-zdjecie-upvc7s-zbigniew-ziobro-6225241/alternates/LANDSCAPE_1280" />
    O wotum nieufności wobec ministra sprawiedliwości zawnioskowała opozycja.

## Jedenastu bohaterów 1/4 finału mistrzostw świata
 - [https://eurosport.tvn24.pl/mundial-2022--wybrali-my-jedenastu-bohater-w-1-4-fina-u-mistrzostw--wiata,1128758.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--wybrali-my-jedenastu-bohater-w-1-4-fina-u-mistrzostw--wiata,1128758.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 10:15:54+00:00

<img alt="Jedenastu bohaterów 1/4 finału mistrzostw świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-56bv0z-jedenastu-najlepszych-w-cwiercfinale-mundialu/alternates/LANDSCAPE_1280" />
    Były gole, kontrowersje i niespodzianki.

## -60 stopni Celsjusza. Tak zimno w Rosji nie było od dekady
 - [https://tvn24.pl/tvnmeteo/swiat/rosja-jakucja-60-stopni-we-wsi-tomtor-najzimniej-w-rosji-od-10-lat-6465074?source=rss](https://tvn24.pl/tvnmeteo/swiat/rosja-jakucja-60-stopni-we-wsi-tomtor-najzimniej-w-rosji-od-10-lat-6465074?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 10:09:33+00:00

<img alt="-60 stopni Celsjusza. Tak zimno w Rosji nie było od dekady" src="https://tvn24.pl/najnowsze/cdn-zdjecie-as0ge1-tomtor-jakucja-rosja-zima-shutterstock1226228035-6465062/alternates/LANDSCAPE_1280" />
    Temperaturę zmierzono na rosyjskim biegunie zimna.

## Adam Glapiński z nagrodą za "wybitne zarządzanie". "To policzek w twarz dla wszystkich Polaków"
 - [https://tvn24.pl/biznes/z-kraju/adam-glapinski-prezes-nbp-otrzymal-nagrode-od-polska-press-komentarze-6464969?source=rss](https://tvn24.pl/biznes/z-kraju/adam-glapinski-prezes-nbp-otrzymal-nagrode-od-polska-press-komentarze-6464969?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 10:02:19+00:00

<img alt="Adam Glapiński z nagrodą za " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-rs65hn-adam-glapinski-otrzymal-nagrode-od-polska-press-6465075/alternates/LANDSCAPE_1280" />
    Nagroda dla prezesa NBP wywołała wiele emocji.

## "Dobre i niedobre wiadomości" od synoptyka
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-brygida-wroca-obfite-opady-sniegu-pozniej-odwilz-synoptyk-o-tym-jaka-pogoda-czeka-nas-w-najblizszych-dniach-i-w-swieta-bozego-narodzenia-2022-6464878?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-brygida-wroca-obfite-opady-sniegu-pozniej-odwilz-synoptyk-o-tym-jaka-pogoda-czeka-nas-w-najblizszych-dniach-i-w-swieta-bozego-narodzenia-2022-6464878?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 09:52:55+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-7v72b1-duze-ilosci-sniegu-spadly-w-warszawie-6464982/alternates/LANDSCAPE_1280" />
    Artur Chrzanowski we "Wstajesz i wiesz" w TVN24.

## Dyskretny, ale znaczący gest "chińskiego Kissingera"
 - [https://tvn24.pl/swiat/chiny-wang-huning-kim-jest-chinski-kissinger-o-czym-mowi-jego-gest-na-zjezdzie-partii-6461332?source=rss](https://tvn24.pl/swiat/chiny-wang-huning-kim-jest-chinski-kissinger-o-czym-mowi-jego-gest-na-zjezdzie-partii-6461332?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 09:31:17+00:00

<img alt="Dyskretny, ale znaczący gest " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5s0hoy-wang-huning-6464623/alternates/LANDSCAPE_1280" />
    Jeden z najbliższych doradców Xi Jinpinga znalazł się w centrum uwagi.

## Ruszyły próbne matury. Od 2023 roku maturzystów czekają zmiany
 - [https://tvn24.pl/polska/probne-matury-terminy-matura-2023-odbedzie-sie-na-zmienionych-zasadach-6464772?source=rss](https://tvn24.pl/polska/probne-matury-terminy-matura-2023-odbedzie-sie-na-zmienionych-zasadach-6464772?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 09:27:41+00:00

<img alt="Ruszyły próbne matury. Od 2023 roku maturzystów czekają zmiany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zupdvb-egzaminy-dzieci-szkola1091564912-4595550/alternates/LANDSCAPE_1280" />
    Próbne egzaminy maturalne potrwają od 12 do 21 grudnia.

## Ruszyły próbne matury. Od 2023 roku maturzystów czekają zmiany
 - [https://tvn24.pl/polska/probna-matura-2023-harmonogram-egzamin-probny-cke-z-jezyka-polskiego-12-grudnia-6464772?source=rss](https://tvn24.pl/polska/probna-matura-2023-harmonogram-egzamin-probny-cke-z-jezyka-polskiego-12-grudnia-6464772?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 09:27:41+00:00

<img alt="Ruszyły próbne matury. Od 2023 roku maturzystów czekają zmiany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zupdvb-egzaminy-dzieci-szkola1091564912-4595550/alternates/LANDSCAPE_1280" />
    Próbne egzaminy maturalne potrwają od 12 do 21 grudnia.

## Ruszyły próbne matury. Od 2023 roku maturzystów czekają zmiany
 - [https://tvn24.pl/polska/probna-matura-w-nowej-formuje-harmonogram-egzamin-probny-cke-z-jezyka-polskiego-12-grudnia-6464772?source=rss](https://tvn24.pl/polska/probna-matura-w-nowej-formuje-harmonogram-egzamin-probny-cke-z-jezyka-polskiego-12-grudnia-6464772?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 09:27:41+00:00

<img alt="Ruszyły próbne matury. Od 2023 roku maturzystów czekają zmiany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zupdvb-egzaminy-dzieci-szkola1091564912-4595550/alternates/LANDSCAPE_1280" />
    Próbne egzaminy maturalne potrwają od 12 do 21 grudnia.

## Wstrzymane loty. "Pasażerowie powinni skontaktować się ze swoją linią"
 - [https://tvn24.pl/swiat/wielka-brytania-wstrzymane-loty-na-londynskich-lotniskach-silne-opady-sniegu-na-wyspach-6464801?source=rss](https://tvn24.pl/swiat/wielka-brytania-wstrzymane-loty-na-londynskich-lotniskach-silne-opady-sniegu-na-wyspach-6464801?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 09:10:41+00:00

<img alt="Wstrzymane loty. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-zydu64-lotnisko-heathrow-12-grudnia-w-nocy-6464880/alternates/LANDSCAPE_1280" />
    Utrudnienia na brytyjskich lotniskach.

## A2: zderzenie auta i trzech busów, kierowca się oddalił. Utrudnienia w kierunku Warszawy
 - [https://tvn24.pl/tvnwarszawa/ulice/wiskitki-a2-zderzenie-auta-i-trzech-busow-kierowca-uciekl-utrudnienia-w-kierunku-warszawy-6464916?source=rss](https://tvn24.pl/tvnwarszawa/ulice/wiskitki-a2-zderzenie-auta-i-trzech-busow-kierowca-uciekl-utrudnienia-w-kierunku-warszawy-6464916?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 09:04:11+00:00

<img alt="A2: zderzenie auta i trzech busów, kierowca się oddalił. Utrudnienia w kierunku Warszawy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4yfac9-na-a2-zderzyly-sie-cztery-pojazdy-6464941/alternates/LANDSCAPE_1280" />
    Za węzłem Wiskitki.

## Ciężarówka "złamała się" na autostradzie A4
 - [https://tvn24.pl/katowice/chorzow-ciezarowka-zlamala-sie-na-autostradzie-a4-utrudniony-przejazd-w-obu-kierunkach-6464906?source=rss](https://tvn24.pl/katowice/chorzow-ciezarowka-zlamala-sie-na-autostradzie-a4-utrudniony-przejazd-w-obu-kierunkach-6464906?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 09:01:31+00:00

<img alt="Ciężarówka " src="https://tvn24.pl/najnowsze/cdn-zdjecie-zpb7gf-ciezarowka-zablokowala-czesciowo-ruch-na-a4-w-chorzowie-6464913/alternates/LANDSCAPE_1280" />
    Utrudniony przejazd w obu kierunkach

## Jeszcze nie otwarty, a już do naprawy. Oddanie węzła Zakręt uzależnione od pogody
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-pekniecia-w-nawierzchni-nowego-odcinka-s17-termin-otwarcia-uzalezniony-od-pogody-6412310?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-pekniecia-w-nawierzchni-nowego-odcinka-s17-termin-otwarcia-uzalezniony-od-pogody-6412310?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 08:47:50+00:00

<img alt="Jeszcze nie otwarty, a już do naprawy. Oddanie węzła Zakręt uzależnione od pogody" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ntnxxu-prace-na-trasie-s17-6412474/alternates/LANDSCAPE_1280" />
    Podczas odbiorów odkryto pęknięcia nawierzchni.

## "Czuć było wstrząs, widać mocne pęknięcie stropu". W nocy z budynku ewakuowano 16 mieszkańców
 - [https://tvn24.pl/katowice/chorzow-mieszkancy-poczuli-w-nocy-wstrzas-w-budynku-pekly-strop-i-sciana-ewakuowano-16-osob-6464823?source=rss](https://tvn24.pl/katowice/chorzow-mieszkancy-poczuli-w-nocy-wstrzas-w-budynku-pekly-strop-i-sciana-ewakuowano-16-osob-6464823?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 08:47:09+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-chk047-straz-pozarna-zdjecie-ilustracyjne-6417061/alternates/LANDSCAPE_1280" />
    W Chorzowie.

## Niemiecki gigant ogłosił nową inwestycję w Polsce
 - [https://tvn24.pl/biznes/moto/mercedes-benz-chce-produkowac-w-jaworze-elektryczne-samochody-dostawcze-6464808?source=rss](https://tvn24.pl/biznes/moto/mercedes-benz-chce-produkowac-w-jaworze-elektryczne-samochody-dostawcze-6464808?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 08:37:03+00:00

<img alt="Niemiecki gigant ogłosił nową inwestycję w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gvzi95-pilne-5496805/alternates/LANDSCAPE_1280" />
    Chce zainwestować ponad 1 miliard euro.

## "Przygarniał je, a potem się nad nimi znęcał". Trzy psy nie żyją
 - [https://tvn24.pl/lodz/ozorkow-najpierw-je-przygarnial-potem-sie-nad-nimi-znecal-trzy-psy-nie-zyja-6464791?source=rss](https://tvn24.pl/lodz/ozorkow-najpierw-je-przygarnial-potem-sie-nad-nimi-znecal-trzy-psy-nie-zyja-6464791?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 08:25:18+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-viz0i7-pies-lapy-shutterstock233728108-2982724/alternates/LANDSCAPE_1280" />
    39-latek został aresztowany na trzy miesiące.

## Nie żyje Georgia Holt. Aktorka i matka Cher miała 96 lat
 - [https://tvn24.pl/swiat/georgia-holt-nie-zyje-matka-cher-aktorka-i-piosenkarka-zmarla-w-wieku-96-lat-6464669?source=rss](https://tvn24.pl/swiat/georgia-holt-nie-zyje-matka-cher-aktorka-i-piosenkarka-zmarla-w-wieku-96-lat-6464669?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 08:12:41+00:00

<img alt="Nie żyje Georgia Holt. Aktorka i matka Cher miała 96 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bulyhp-georgia-holt-6464698/alternates/LANDSCAPE_1280" />
    "Mama odeszła" - poinformowała wokalistka w mediach społecznościowych.

## Alert RCB. "Zostań w domu, jeśli możesz"
 - [https://tvn24.pl/tvnmeteo/pogoda/alert-rcb-zawieje-zamiecie-sniezne-i-silny-wiatr-gdzie-zostal-wydany-alert-rcb-6464780?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alert-rcb-zawieje-zamiecie-sniezne-i-silny-wiatr-gdzie-zostal-wydany-alert-rcb-6464780?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 08:07:22+00:00

<img alt="Alert RCB. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5nf5j0-rcb-6464790/alternates/LANDSCAPE_1280" />
    Ostrzeżenie przed silnym wiatrem, zawiejami i zamieciami śnieżnymi.

## Atak zimy. Pokazujecie jak jest u Was
 - [https://tvn24.pl/tvnmeteo/prognoza/atak-zimy-pokazujecie-jak-jest-u-was-6464711?source=rss](https://tvn24.pl/tvnmeteo/prognoza/atak-zimy-pokazujecie-jak-jest-u-was-6464711?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 07:53:12+00:00

<img alt="Atak zimy. Pokazujecie jak jest u Was" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-i8apav-6ffad6a6-a99b-4508-aa19-b8516954711d-6464756/alternates/LANDSCAPE_1280" />
    W wielu miejscach sypało przez całą niedzielę.

## Leon i Semeniuk wywalczyli klubowe mistrzostwo świata
 - [https://eurosport.tvn24.pl/leon-i-semeniuk-wywalczyli-klubowe-mistrzostwo--wiata,1128870.html?source=rss](https://eurosport.tvn24.pl/leon-i-semeniuk-wywalczyli-klubowe-mistrzostwo--wiata,1128870.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 07:52:51+00:00

<img alt="Leon i Semeniuk wywalczyli klubowe mistrzostwo świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1kvn4c-wilfredo-leon-w-barwach-sir-safety-perugia/alternates/LANDSCAPE_1280" />
    Z włoskim zespołem Sir Safety Perugia.

## Iga Świątek inspiruje lidera męskiego rankingu. "Chciałbym być jak ona"
 - [https://eurosport.tvn24.pl/iga--wi-tek-inspiruje-lidera-m-skiego-rankingu---chcia-bym-by--jak-ona-,1128871.html?source=rss](https://eurosport.tvn24.pl/iga--wi-tek-inspiruje-lidera-m-skiego-rankingu---chcia-bym-by--jak-ona-,1128871.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 07:42:02+00:00

<img alt="Iga Świątek inspiruje lidera męskiego rankingu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2mxoac-iga-swiatek/alternates/LANDSCAPE_1280" />
    Na jej osiągnięcia z podziwem patrzy Carlos Alcaraz.

## Trudne warunki na drogach w wielu miejscach Polski i kolejne ostrzeżenia przed śniegiem
 - [https://tvn24.pl/polska/atak-zimy-trudne-warunki-na-drogach-w-wielu-miejscach-polski-i-kolejne-ostrzezenia-przed-sniegiem-6464699?source=rss](https://tvn24.pl/polska/atak-zimy-trudne-warunki-na-drogach-w-wielu-miejscach-polski-i-kolejne-ostrzezenia-przed-sniegiem-6464699?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 07:33:25+00:00

<img alt="Trudne warunki na drogach w wielu miejscach Polski i kolejne ostrzeżenia przed śniegiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0lnmwc-snieg-w-przemyslu-6458574/alternates/LANDSCAPE_1280" />
    Drogowcy apelują o ostrożność.

## Bielan o słowach Ziobry: jeśli ktoś jest od siedmiu lat w rządzie, to jest to wypowiedź dziwna
 - [https://tvn24.pl/polska/zjednoczona-prawicy-adam-bielan-o-sporach-oboz-rzadzacy-to-nie-jest-klub-towarzyski-w-ktorym-kazdy-ma-sie-lubic-6464644?source=rss](https://tvn24.pl/polska/zjednoczona-prawicy-adam-bielan-o-sporach-oboz-rzadzacy-to-nie-jest-klub-towarzyski-w-ktorym-kazdy-ma-sie-lubic-6464644?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 07:14:28+00:00

<img alt="Bielan o słowach Ziobry: jeśli ktoś jest od siedmiu lat w rządzie, to jest to wypowiedź dziwna" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9j5i5j-adam-bielan-6464659/alternates/LANDSCAPE_1280" />
    Adam Bielan o sporach w Zjednoczonej Prawicy.

## Warszawa ma odetchnąć od franków
 - [https://tvn24.pl/biznes/z-kraju/kredyty-frankowe-frankowicze-sad-okregowy-w-warszawie-ma-odetchnac-od-spraw-frankowych-poprawki-poslow-pis-6464628?source=rss](https://tvn24.pl/biznes/z-kraju/kredyty-frankowe-frankowicze-sad-okregowy-w-warszawie-ma-odetchnac-od-spraw-frankowych-poprawki-poslow-pis-6464628?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 07:06:38+00:00

<img alt="Warszawa ma odetchnąć od franków" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjeciebdcd89b46e4a43121bc4e0e270089642-coraz-mniej-kredytow-we-frankach-szwajcarskich-4405560/alternates/LANDSCAPE_1280" />
    Kolejne zmiany w kodeksie postępowania cywilnego na horyzoncie.

## Dwie nieprzytomne osoby w rozbitym aucie. Kobiety nie udało się uratować
 - [https://tvn24.pl/lodz/ozorkow-czolowe-zderzenie-dwoch-samochodow-jedna-osoba-nie-zyje-6464663?source=rss](https://tvn24.pl/lodz/ozorkow-czolowe-zderzenie-dwoch-samochodow-jedna-osoba-nie-zyje-6464663?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 06:59:47+00:00

<img alt="Dwie nieprzytomne osoby w rozbitym aucie. Kobiety nie udało się uratować" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mjibo2-smiertelny-wypadek-na-dk91-w-ozorkowie-6464647/alternates/LANDSCAPE_1280" />
    Do czołowe zderzenia doszło na drodze 91 w Ozorkowie (województwo łódzkie).

## Ciała 27 mężczyzn porzucone na obrzeżach miasta
 - [https://tvn24.pl/swiat/zambia-w-stolicy-odnaleziono-ciala-27-migrantow-porzucone-na-poboczu-drogi-6461342?source=rss](https://tvn24.pl/swiat/zambia-w-stolicy-odnaleziono-ciala-27-migrantow-porzucone-na-poboczu-drogi-6461342?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 06:55:25+00:00

<img alt="Ciała 27 mężczyzn porzucone na obrzeżach miasta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ez7748-lusaka-zambia-travel-stock-shutterstock2107644629-6464654/alternates/LANDSCAPE_1280" />
    Prawdopodobnie zmarli z głodu i wyczerpania.

## Niepokojące informacje dla piłkarzy. Wysoka ocena wielokrotnego odbijania piłki głową
 - [https://eurosport.tvn24.pl/niepokoj-ce-informacje-dla-pi-karzy--wysoka-ocena-wielokrotnego-odbijania-pi-ki-g-ow-,1128588.html?source=rss](https://eurosport.tvn24.pl/niepokoj-ce-informacje-dla-pi-karzy--wysoka-ocena-wielokrotnego-odbijania-pi-ki-g-ow-,1128588.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 06:52:46+00:00

<img alt="Niepokojące informacje dla piłkarzy. Wysoka ocena wielokrotnego odbijania piłki głową" src="https://tvn24.pl/najnowsze/cdn-zdjecie-380rsa-luka-modric-mimo-37-lat-gra-znakomicie/alternates/LANDSCAPE_1280" />
    Naukowcy z University of East Anglia dowiedli w badaniach, że piłkarze są bardziej narażeni na problemy ze zdrowiem mózgu po 65. roku życia niż reszta populacji.

## Niepokojące informacje dla piłkarzy. Wysoka ocena wielokrotnego odbijania piłki głową
 - [https://eurosport.tvn24.pl/niepokoj-ce-informacje-dla-pi-karzy--wysoka-cena-wielokrotnego-odbijania-pi-ki-g-ow-,1128588.html?source=rss](https://eurosport.tvn24.pl/niepokoj-ce-informacje-dla-pi-karzy--wysoka-cena-wielokrotnego-odbijania-pi-ki-g-ow-,1128588.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 06:52:46+00:00

<img alt="Niepokojące informacje dla piłkarzy. Wysoka ocena wielokrotnego odbijania piłki głową" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hagne9-francja-anglia-podczas-ms-w-katarze-6464675/alternates/LANDSCAPE_1280" />
    Badania naukowców z University of East England.

## Wybory jak "kronika zapowiedzianej śmierci. "Sasin był narzędziem. Robił to, co chciał Kaczyński i Morawiecki"
 - [https://tvn24.pl/go/programy,7/to-byl-temat-odcinki,888539/odcinek-6,S01E06,935140?source=rss](https://tvn24.pl/go/programy,7/to-byl-temat-odcinki,888539/odcinek-6,S01E06,935140?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 06:30:07+00:00

<img alt="Wybory jak " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gj1hl5-jacek-sasin-6464652/alternates/LANDSCAPE_1280" />
    Kto ponosi odpowiedzialność za wydanie 70 milionów złotych z budżetu państwa na wybory, które ostatecznie się nie odbyły?

## Kubacki krezusem. W tym sezonie zarobił najwięcej
 - [https://eurosport.tvn24.pl/kubacki-krezusem--w-tym-sezonie-zarobi--najwi-cej,1128867.html?source=rss](https://eurosport.tvn24.pl/kubacki-krezusem--w-tym-sezonie-zarobi--najwi-cej,1128867.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 06:29:53+00:00

<img alt="Kubacki krezusem. W tym sezonie zarobił najwięcej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vt4hir-dawid-kubacki-jest-w-swietnej-formie-6429379/alternates/LANDSCAPE_1280" />
    Jest liderem nie tylko klasyfikacji generalnej Pucharu Świata.

## Został wybrany do Kongresu, nie stać go na wynajem mieszkania w Waszyngtonie
 - [https://tvn24.pl/swiat/usa-maxwell-frost-dostal-sie-do-kongresu-w-waszyngtonie-nie-mogl-wynajac-mieszkania-6464591?source=rss](https://tvn24.pl/swiat/usa-maxwell-frost-dostal-sie-do-kongresu-w-waszyngtonie-nie-mogl-wynajac-mieszkania-6464591?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 06:21:01+00:00

<img alt="Został wybrany do Kongresu, nie stać go na wynajem mieszkania w Waszyngtonie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gxc60e-maxwell-alejandro-frost-6464593/alternates/LANDSCAPE_1280" />
    25-letni demokrata zostanie jednym z najmłodszych kongresmenów w historii.

## Te produkty podrożały najbardziej
 - [https://tvn24.pl/biznes/z-kraju/inflacja-zakupy-drozsze-o-ponad-jedna-czwarta-najmocniej-podrozal-cukier-i-papier-toaletowy-analiza-uce-research-i-wyzszych-szkol-bankowych-6464618?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-zakupy-drozsze-o-ponad-jedna-czwarta-najmocniej-podrozal-cukier-i-papier-toaletowy-analiza-uce-research-i-wyzszych-szkol-bankowych-6464618?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 06:14:01+00:00

<img alt="Te produkty podrożały najbardziej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ar7jzh-sklep-market-koszyk-zakupy-shutterstock1688252332-5421612/alternates/LANDSCAPE_1280" />
    Ceny w listopadzie.

## Strefa opadów kroczy przez Polskę. Alerty IMGW drugiego stopnia
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-drugiego-stopnia-sniezyce-w-poniedzialek-gdzie-spadnie-najwiecej-sniegu-niz-brygida-w-polsce-6464619?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-drugiego-stopnia-sniezyce-w-poniedzialek-gdzie-spadnie-najwiecej-sniegu-niz-brygida-w-polsce-6464619?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 05:47:15+00:00

<img alt="Strefa opadów kroczy przez Polskę. Alerty IMGW drugiego stopnia" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-58kypd-22c11061-6464626/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie obowiązują ostrzeżenia.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-12-grudnia-2022-roku-6464606?source=rss](https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-12-grudnia-2022-roku-6464606?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 05:39:55+00:00

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lekh4u-ukrainscy-zolnierze-bachmut-donbas-donieck-rosja-zniszczenia-08122022-6431569/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja trwa 292. dzień.

## Ratownicy nie poznali Neuera. Było zbyt niebezpiecznie, wezwano helikopter
 - [https://eurosport.tvn24.pl/ratownicy-nie-poznali-neuera--by-o-zbyt-niebezpiecznie--wezwano-helikopter,1128856.html?source=rss](https://eurosport.tvn24.pl/ratownicy-nie-poznali-neuera--by-o-zbyt-niebezpiecznie--wezwano-helikopter,1128856.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 05:33:00+00:00

<img alt="Ratownicy nie poznali Neuera. Było zbyt niebezpiecznie, wezwano helikopter" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jf8tus-manuel-neuer-szybko-nie-wybiegnie-na-boisko/alternates/LANDSCAPE_1280" />
    Niemieckie media ujawniły szczegóły dramatycznej akcji ratunkowej.

## Były norweski skoczek o Kubackim: muszę zdjąć słuchawki, kapelusz, a potem mu się ukłonić
 - [https://eurosport.tvn24.pl/by-y-norweski-skoczek-o-kubackim--musz--zdj---s-uchawki--kapelusz--a-potem-mu-si--uk-oni-,1128862.html?source=rss](https://eurosport.tvn24.pl/by-y-norweski-skoczek-o-kubackim--musz--zdj---s-uchawki--kapelusz--a-potem-mu-si--uk-oni-,1128862.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 05:18:25+00:00

<img alt="Były norweski skoczek o Kubackim: muszę zdjąć słuchawki, kapelusz, a potem mu się ukłonić" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d9e615-dawid-kubacki-wygral-niedzielny-konkurs-w-titisee-neustadt/alternates/LANDSCAPE_1280" />
    Po niedzielnym konkursie Pucharu Świata w Titisee-Neustadt.

## "Zdarzenie na terenie Litwy". Przejście graniczne w Budzisku odblokowane, ale nadal są utrudnienia w ruchu
 - [https://tvn24.pl/polska/ruch-na-przejsciu-granicznym-w-budzisku-wznowiony-ale-sa-utrudnienia-6464607?source=rss](https://tvn24.pl/polska/ruch-na-przejsciu-granicznym-w-budzisku-wznowiony-ale-sa-utrudnienia-6464607?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 05:14:39+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wkm16n-kolejny-akt-oskarzenia-w-sprawie-zniewazenia-strazy-granicznej-zdj-ilustracyjne-5889575/alternates/LANDSCAPE_1280" />
    Informuje GDDKiA.

## Przejście graniczne w Budzisku zablokowane. "Z powodu zdarzenia na terenie Litwy"
 - [https://tvn24.pl/polska/przejscie-graniczne-z-litwa-w-budzisku-zablokowane-6464607?source=rss](https://tvn24.pl/polska/przejscie-graniczne-z-litwa-w-budzisku-zablokowane-6464607?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 05:14:39+00:00

<img alt="Przejście graniczne w Budzisku zablokowane. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wkm16n-kolejny-akt-oskarzenia-w-sprawie-zniewazenia-strazy-granicznej-zdj-ilustracyjne-5889575/alternates/LANDSCAPE_1280" />
    Poinformowała w poniedziałek nad ranem Generalna Dyrekcja Dróg Krajowych i Autostrad.

## "Ciąg dalszy dialogu". Erdogan rozmawiał z Putinem, potem z Zełenskim
 - [https://tvn24.pl/swiat/erdogan-rozmawial-z-putinem-i-zelenskim-wsrod-tematow-kwestia-korytarza-zbozowego-6461352?source=rss](https://tvn24.pl/swiat/erdogan-rozmawial-z-putinem-i-zelenskim-wsrod-tematow-kwestia-korytarza-zbozowego-6461352?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 05:10:38+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sbltob-gettyimages-800101526-5729102/alternates/LANDSCAPE_1280" />
    Prezydent Turcji podkreślił, że wszystkie kroki Ankary mają na celu osiągnięcie pokoju w regionie Morza Czarnego.

## 11 osób czeka na wykonanie kary śmierci. Apele o presję na Teheran, by uniknąć "rzezi"
 - [https://tvn24.pl/swiat/protesty-w-iranie-11-osob-czeka-na-wykonanie-kary-smierci-za-udzial-w-demonstracjach-6461340?source=rss](https://tvn24.pl/swiat/protesty-w-iranie-11-osob-czeka-na-wykonanie-kary-smierci-za-udzial-w-demonstracjach-6461340?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 04:48:19+00:00

<img alt="11 osób czeka na wykonanie kary śmierci. Apele o presję na Teheran, by uniknąć " src="https://tvn24.pl/najnowsze/cdn-zdjecie-zmu9on-iranczycy-protestuja-przed-ambasada-iranu-w-rzymie-6463202/alternates/LANDSCAPE_1280" />
    Protesty w Iranie.

## Kolejny stracony pod zarzutem "moharebeh". Apele o sankcje na Teheran
 - [https://tvn24.pl/swiat/protesty-w-iranie-23-letni-madzidreza-rahnaward-stracony-apel-o-radykalne-sankcje-6461340?source=rss](https://tvn24.pl/swiat/protesty-w-iranie-23-letni-madzidreza-rahnaward-stracony-apel-o-radykalne-sankcje-6461340?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 04:48:19+00:00

<img alt="Kolejny stracony pod zarzutem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-sgbdqm-iran-6464681/alternates/LANDSCAPE_1280" />
    Egzekucje po protestach w Iranie.

## "Kiedy mówisz Tajfun, Grek jest przerażony"
 - [https://tvn24.pl/swiat/prezydent-turcji-o-rakietach-dalekiego-zasiegu-i-grecji-kiedy-mowisz-tajfun-grek-jest-przerazony-6461350?source=rss](https://tvn24.pl/swiat/prezydent-turcji-o-rakietach-dalekiego-zasiegu-i-grecji-kiedy-mowisz-tajfun-grek-jest-przerazony-6461350?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-12 04:36:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qxmmo7-erdogan-5541840/alternates/LANDSCAPE_1280" />
    Prezydent Turcji o rakietach balistycznych dalekiego zasięgu.


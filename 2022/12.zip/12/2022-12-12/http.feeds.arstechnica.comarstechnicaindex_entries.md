# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Effective, fast, and unrecoverable: Wiper malware is popping up everywhere
 - [https://arstechnica.com/?p=1903915](https://arstechnica.com/?p=1903915)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 23:44:44+00:00

Wiper malware from no fewer than 9 families has appeared this year. Now there are 2 more.

## Officials, experts call for masking as illnesses slam US ahead of holidays
 - [https://arstechnica.com/?p=1903918](https://arstechnica.com/?p=1903918)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 23:24:59+00:00

Nearly 10% of US counties have "high" transmission levels and should be masking.

## Chrome delays plan to limit ad blockers, new timeline coming in March
 - [https://arstechnica.com/?p=1903852](https://arstechnica.com/?p=1903852)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 23:08:37+00:00

Manifest V3 transition is delayed again to the relief of Chrome users everywhere.

## China bans AI-generated media without watermarks
 - [https://arstechnica.com/?p=1903773](https://arstechnica.com/?p=1903773)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 22:44:03+00:00

China regulates generative AI tech with rules that aim to spur growth and ban deception.

## DOJ divided over charging Binance for alleged crypto crimes, report says
 - [https://arstechnica.com/?p=1903824](https://arstechnica.com/?p=1903824)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 19:54:45+00:00

Illicit funds processed by Binance in 2022 allegedly amounted to $10 billion.

## Xiaomi’s new phone takes a ton of inspiration from Apple, as usual
 - [https://arstechnica.com/?p=1903713](https://arstechnica.com/?p=1903713)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 18:54:04+00:00

Xiaomi's 2023 flagship falls back into old habits.

## The Moon landing was faked, and wind farms are bad
 - [https://arstechnica.com/?p=1903755](https://arstechnica.com/?p=1903755)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 18:40:44+00:00

In Germany, opposition to wind farms correlated with conspiratorial thinking.

## Leaked email shows Musk threatened to sue Twitter employees who leak to media
 - [https://arstechnica.com/?p=1903765](https://arstechnica.com/?p=1903765)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 17:55:48+00:00

Musk email complains of "many detailed leaks of confidential Twitter information."

## NASA official “very confident” Artemis spacesuits will be ready on time
 - [https://arstechnica.com/?p=1903666](https://arstechnica.com/?p=1903666)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 17:09:34+00:00

"They have invested a lot of their own money into the suits."

## Ubisoft won’t bring its Assassin’s Creed Valhalla achievements to Steam
 - [https://arstechnica.com/?p=1903732](https://arstechnica.com/?p=1903732)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 16:35:22+00:00

Since-deleted forum post suggested "no current plans" to bring them over.

## Support for Windows 7 and 8 fully ends in January, including Microsoft Edge
 - [https://arstechnica.com/?p=1903678](https://arstechnica.com/?p=1903678)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 16:10:23+00:00

Even businesses that will pay for it won't get new Windows 7 security updates.

## GM and LG get $2.5 billion battery loan from the Department of Energy
 - [https://arstechnica.com/?p=1903704](https://arstechnica.com/?p=1903704)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 15:44:59+00:00

11,000 new jobs will be created in Michigan, Ohio, and Tennessee.

## Raspberry Pi inventory improving, could reach pre-pandemic levels in 2023
 - [https://arstechnica.com/?p=1903653](https://arstechnica.com/?p=1903653)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 15:15:50+00:00

"Hundreds of thousands" of Pi Zero, 3A+, and 4 models should show up next year.

## Fusion energy breakthrough by US scientists boosts clean power hopes
 - [https://arstechnica.com/?p=1903679](https://arstechnica.com/?p=1903679)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 14:57:13+00:00

First-ever net energy gain from fusion raises hopes for zero-carbon alternative.

## Radeon 7900 XTX and XT review: Faster, hotter, and cheaper than the RTX 4080
 - [https://arstechnica.com/?p=1903251](https://arstechnica.com/?p=1903251)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 14:00:58+00:00

New $899 and $999 GPUs maintain the status quo in the Nvidia-AMD rivalry.

## The 2023 Mitsubishi Outlander PHEV is a much-improved hybrid SUV
 - [https://arstechnica.com/?p=1903600](https://arstechnica.com/?p=1903600)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-12 13:00:50+00:00

26 mpg once the battery is depleted is not amazing, however.


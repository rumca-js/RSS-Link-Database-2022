# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Lauren Boebert Officially Wins Reelection Bid
 - [https://www.dailywire.com/news/lauren-boebert-officially-wins-reelection-bid](https://www.dailywire.com/news/lauren-boebert-officially-wins-reelection-bid)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 23:31:56+00:00

Rep. Lauren Boebert (R-CO) won her bid for reelection after a tight race decided by roughly 550 votes, a recount confirmed on Monday. The final results in Colorado’s Congressional District 3 showed the incumbent received 50.06% of the votes, while her Democratic rival, Adam Frisch, received 49.89%. Tallies showed Boebert with 163,293 votes following a ...

## Criminal Charges Against Sam Bankman-Fried Revealed
 - [https://www.dailywire.com/news/criminal-charges-against-sam-bankman-fried-revealed](https://www.dailywire.com/news/criminal-charges-against-sam-bankman-fried-revealed)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 22:03:09+00:00

Sam Bankman-Fried, the disgraced founder and former CEO of FTX, is facing numerous federal felonies for alleged financial crimes related to the collapse of the company. The disheveled 30-year-old was arrested Monday night by authorities in the Bahamas after they received word from U.S. officials that charges had been filed against Bankman-Fried and that the ...

## BREAKING: Biden Official Sam Brinton Out Of A Job After Multiple Alleged Luggage Thefts At Airports
 - [https://www.dailywire.com/news/breaking-biden-official-sam-brinton-out-of-a-job-after-multiple-alleged-luggage-thefts-at-airports](https://www.dailywire.com/news/breaking-biden-official-sam-brinton-out-of-a-job-after-multiple-alleged-luggage-thefts-at-airports)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 20:33:31+00:00

A controversial figure in the Biden administration is reportedly out of the job after being accused of stealing luggage in two separate incidents. The Department of Energy is no longer employing Sam Brinton, who claims he is non-binary, after he was accused of stealing luggage in Las Vegas and Minneapolis. “Sam Brinton is no longer ...

## New York Dem Proposes Climate Change Bill Allowing Citizens To Sue Big Oil Companies
 - [https://www.dailywire.com/news/new-york-dem-proposes-climate-change-bill-allowing-citizens-to-sue-big-oil-companies](https://www.dailywire.com/news/new-york-dem-proposes-climate-change-bill-allowing-citizens-to-sue-big-oil-companies)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 20:15:42+00:00

New Yorkers may have the chance to sue big oil companies and other fossil fuel producers under new climate change legislation proposed by a Brooklyn Democrat, which emulates a Texas law against abortion providers. State Sen. Zellnor Myrie (D-Brooklyn) introduced the legislation last week that would target fossil fuel companies with annual revenues over $1 ...

## Study Finds More Screen Time Associated With Future OCD In Preteens
 - [https://www.dailywire.com/news/study-finds-more-screen-time-associated-with-future-ocd-in-preteens](https://www.dailywire.com/news/study-finds-more-screen-time-associated-with-future-ocd-in-preteens)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 20:01:03+00:00

Higher amounts of screen time might be connected to an increased risk of developing obsessive-compulsive disorder, according to a new study. The study, published on Monday in the Journal of Adolescent Health, included around 9,200 children between the ages of nine and ten who reported how long they use screens. The different uses involved video ...

## P-22, ‘World-Famous ’ Los Angeles Mountain Lion, Captured
 - [https://www.dailywire.com/news/p-22-world-famous-los-angeles-mountain-lion-captured](https://www.dailywire.com/news/p-22-world-famous-los-angeles-mountain-lion-captured)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 19:49:49+00:00

A famous mountain lion in the Los Angeles area has been captured after it recently carried out several attacks. The lion, called P-22, is well known in the area and lived in Griffith Park, a 4,000-acre area in the Hollywood Hills. However, the animal has attacked two dogs and also been spotted near houses, leading ...

## Joe Manchin Has ‘No Intention’ Of Leaving Democratic Party Right Now
 - [https://www.dailywire.com/news/joe-manchin-has-no-intention-of-leaving-democratic-party-right-now](https://www.dailywire.com/news/joe-manchin-has-no-intention-of-leaving-democratic-party-right-now)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 19:21:40+00:00

Sen. Joe Manchin (D-WV) says he has no plans to leave the Democratic Party, but he isn&#8217;t ruling out the possibility either. A journalist asked the senator on Monday if he might become an independent like Sen. Kyrsten Sinema of Arizona, a move that could complicate the grip Democrats have on the upper chamber next ...

## Rage Against The Machine’s Tim Commerford Reveals ‘Serious’ Health Diagnosis
 - [https://www.dailywire.com/news/rage-against-the-machines-tim-commerford-reveals-serious-health-diagnosis](https://www.dailywire.com/news/rage-against-the-machines-tim-commerford-reveals-serious-health-diagnosis)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 19:16:54+00:00

Rage Against the Machine&#8217;s Tim Commerford revealed he was diagnosed recently with prostate cancer, something only those closest to him knew about before his recent interview with Spin magazine. The 54-year-old rocker said that two months before he and former bandmates were to hit the road on their 2022 reunion tour, he was diagnosed with ...

## Putin Won’t Hold Annual Press Conference For First Time In Ten Years
 - [https://www.dailywire.com/news/putin-wont-hold-annual-press-conference-for-first-time-in-ten-years](https://www.dailywire.com/news/putin-wont-hold-annual-press-conference-for-first-time-in-ten-years)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 19:10:54+00:00

Russian president Vladimir Putin will not hold his typical yearly press conference for the first time in at least ten years. Kremlin spokesman Dmitry Peskov was asked about the event during a call with the press. When asked if there was a date for the “big news conference,” Peskov said, &#8220;No, there won&#8217;t be one ...

## BREAKING: Democrat Megadonor Sam Bankman-Fried Arrested In Bahamas, Faces Criminal Charges In U.S.
 - [https://www.dailywire.com/news/breaking-democrat-megadonor-sam-bankman-fried-arrested-in-bahamas-faces-criminal-charges-in-u-s](https://www.dailywire.com/news/breaking-democrat-megadonor-sam-bankman-fried-arrested-in-bahamas-faces-criminal-charges-in-u-s)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 19:03:05+00:00

Former FTX CEO Sam Bankman-Fried was arrested Monday by authorities in the Bahamas because they were notified that the U.S. Department of Justice has filed criminal charges against him and is expected to request extradition. &#8220;On 12 December 2022, the Office of the Attorney General of The Bahamas is announcing the arrest by The Royal ...

## The Twitter Files Part V: Chinese Employee Warned Co-Workers Against Censoring Trump
 - [https://www.dailywire.com/news/the-twitter-files-part-v-chinese-employee-warned-co-workers-against-censoring-trump](https://www.dailywire.com/news/the-twitter-files-part-v-chinese-employee-warned-co-workers-against-censoring-trump)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 18:55:22+00:00

The fifth installment of &#8220;The Twitter Files&#8221; focused on the actions inside of Twitter following the January 6, 2021, riot at the U.S. Capitol that ultimately resulted in former President Donald Trump being banned from the platform. Journalist Bari Weiss highlighted the two tweets that the president posted that day before getting banned: 3. 7:44 ...

## Prosecutors Won’t Seek Death Penalty In Trial Over Lockerbie Bombing That Killed 270
 - [https://www.dailywire.com/news/prosecutors-wont-seek-death-penalty-in-trial-over-lockerbie-bombing-that-killed-270](https://www.dailywire.com/news/prosecutors-wont-seek-death-penalty-in-trial-over-lockerbie-bombing-that-killed-270)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 18:45:38+00:00

Prosecutors told the man accused of crafting the bomb used in the deadliest terror attack ever to take place in the United Kingdom that they will not push for the death penalty if he is convicted. Abu Agila Mohammad Mas’ud Kheir Al-Marimi, a Libyan intelligence operative, appeared in a federal court in Washington, D.C., on ...

## Simultaneous Use Of Cannabis And Alcohol Went Up In People Ages 21-50 As States Legalized Recreational Marijuana, Study Finds
 - [https://www.dailywire.com/news/simultaneous-use-of-cannabis-and-alcohol-went-up-in-people-ages-21-50-as-states-legalized-recreational-marijuana-study-finds](https://www.dailywire.com/news/simultaneous-use-of-cannabis-and-alcohol-went-up-in-people-ages-21-50-as-states-legalized-recreational-marijuana-study-finds)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 18:18:23+00:00

A new study revealed the potential connection between the combined use of alcohol and marijuana and the laws concerning recreational marijuana use across the United States. The study, published in the Journal of Internal Medicine late last month, showed that the combined use of alcohol and cannabis went up from 2008 to 2019 in people ...

## Monday Afternoon Update: Fetterman Has A Face For Movies, Confederate Statue Comes Down, Gigantic Caravan Crosses Border
 - [https://www.dailywire.com/news/monday-afternoon-update-fetterman-has-a-face-for-movies-confederate-statue-comes-down-gigantic-caravan-crosses-border](https://www.dailywire.com/news/monday-afternoon-update-fetterman-has-a-face-for-movies-confederate-statue-comes-down-gigantic-caravan-crosses-border)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 18:07:11+00:00

This article is a companion piece to today’s Morning Wire Afternoon Update. To listen to the podcast version, click here. Future Fusion Energy? A new report indicates that U.S. scientists have found a “breakthrough” in viable nuclear fusion. In the past two weeks, scientists at a federal facility in California were able to produce more energy ...

## Ben Shapiro: Dorsey’s To Blame For Letting Twitter’s Inmates Run Asylum
 - [https://www.dailywire.com/news/ben-shapiro-dorseys-to-blame-for-letting-twitters-inmates-run-asylum](https://www.dailywire.com/news/ben-shapiro-dorseys-to-blame-for-letting-twitters-inmates-run-asylum)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 17:38:38+00:00

The Twitter Files now being revealed under new owner Elon Musk’s supervision show that a cabal of woke fanatics drunk on censorship ran the internet’s town square while its founder, Jack Dorsey, was oblivious, Ben Shapiro said Monday. Speaking on his popular podcast and radio show, Shapiro said the evidence being rolled out by Musk’s ...

## Why I Discriminate And You Should, Too
 - [https://www.dailywire.com/news/why-i-discriminate-and-you-should-too](https://www.dailywire.com/news/why-i-discriminate-and-you-should-too)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 17:21:39+00:00

I&#8217;m just going to come right out and say it: I discriminate. I&#8217;m already feeling lighter now that I&#8217;ve gotten that off of my chest. Yes, I do discriminate. You know who wants you to believe discriminating is always a bad thing? The Left. The Left is very good with linguistics. Liberals often take certain ...

## Trump Or Biden In 2024? Americans — Neither!
 - [https://www.dailywire.com/news/trump-or-biden-in-2024-americans-neither](https://www.dailywire.com/news/trump-or-biden-in-2024-americans-neither)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 17:17:16+00:00

The 2024 presidential election is still 694 days away, but already the pollsters are polling away. Their takeaway? None of the above. Pollsters with the CNBC All-America Economic Survey asked if President Joe Biden or former President Donald Trump should run again. The resounding answer for both: No. The survey found that 61% of the ...

## Family Of Second Loudoun Victim Breaks Silence, Faults ‘Staggering’ Ineptitude, Lack Of Empathy
 - [https://www.dailywire.com/news/family-of-second-loudoun-victim-breaks-silence-faults-staggering-ineptitude-lack-of-empathy](https://www.dailywire.com/news/family-of-second-loudoun-victim-breaks-silence-faults-staggering-ineptitude-lack-of-empathy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 17:05:41+00:00

The family of the second girl assaulted by a Virginia teen broke its silence Monday to say that her plight could have been avoided if not for the &#8220;ineptitude&#8221; of Loudoun County school officials who kept the skirt-wearing assailant in school even after he was charged with felony forcible sodomy for an earlier bathroom rape.

## Mississippi State Football Coach Mike Leach In ‘Critical Condition’ After Suffering Massive Heart Attack, Report Says
 - [https://www.dailywire.com/news/mississippi-state-football-coach-mike-leach-in-critical-condition-after-suffering-massive-heart-attack-report-says](https://www.dailywire.com/news/mississippi-state-football-coach-mike-leach-in-critical-condition-after-suffering-massive-heart-attack-report-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 17:01:10+00:00

Mississippi State University Head Football Coach Mike Leach is listed in &#8220;critical condition&#8221; after reportedly suffering a massive heart attack at his home over the weekend. The Clarion Ledger reported that Leach, 61, did not receive medical attention for 10-15 minutes after collapsing, leading to the possibility that he suffered brain damage. Leach was transported ...

## Investors Much More Skeptical Of Crypto After Brutal Bear Market, FTX Collapse
 - [https://www.dailywire.com/news/investors-much-more-skeptical-of-crypto-after-brutal-bear-market-ftx-collapse](https://www.dailywire.com/news/investors-much-more-skeptical-of-crypto-after-brutal-bear-market-ftx-collapse)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 16:51:29+00:00

Americans are significantly more skeptical about cryptocurrency following severe disruptions in the digital asset market, according to a poll from CNBC and Momentive. The survey, taken from the end of November to the beginning of December, showed that roughly 60% of Americans see the risk of cryptocurrency investments as “high,” marking an increase from 45% ...

## Three Years Later, Gibson’s Bakery Finally Receives $36 Million From Oberlin College After False Racism Claim
 - [https://www.dailywire.com/news/three-years-later-gibsons-bakery-finally-receives-36-million-from-oberlin-college-after-false-racism-claim](https://www.dailywire.com/news/three-years-later-gibsons-bakery-finally-receives-36-million-from-oberlin-college-after-false-racism-claim)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 16:41:31+00:00

Gibson’s Bakery, which was falsely accused of racism by Oberlin College officials and won a multi-million-dollar verdict, has finally received the money it is owed after more than three years of waiting. Legal Insurrection’s William Jacobson confirmed with the bakery’s lawyers that the family has finally received its share of the more than $36 million ...

## ‘Sister Wives’ Star Kody Brown Announces He’s ‘Separated’ From Another Wife
 - [https://www.dailywire.com/news/sister-wives-star-kody-brown-announces-hes-separated-from-another-wife](https://www.dailywire.com/news/sister-wives-star-kody-brown-announces-hes-separated-from-another-wife)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 16:29:22+00:00

“Sister Wives” family patriarch Kody Brown just announced his second separation, this time from Janelle Brown. The TLC reality star made the admission during a recently released promo for the upcoming special, “Sister Wives: One on One.”  &#8220;I am separated from Janelle,&#8221; Kody admitted. &#8220;And I&#8217;m divorced from Christine [Brown].&#8221; Janelle reiterated that the pair ...

## Supreme Court To Hear Second Case Challenging Biden Student Loan Forgiveness Program
 - [https://www.dailywire.com/news/supreme-court-to-hear-second-case-challenging-biden-student-loan-forgiveness-program](https://www.dailywire.com/news/supreme-court-to-hear-second-case-challenging-biden-student-loan-forgiveness-program)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 16:18:40+00:00

The U.S. Supreme Court agreed Monday to hold arguments in a second case against the Biden administration’s student loan forgiveness program from a small business organization challenging the constitutionality of canceling billions of dollars in student loan debt. The nation&#8217;s highest court agreed to hear the case after a federal judge in Texas ruled last ...

## ‘Pinocchio’ Director Says New Netflix Adaptation Is ‘Not Made For Kids’
 - [https://www.dailywire.com/news/pinocchio-director-says-new-netflix-adaptation-is-not-made-for-kids](https://www.dailywire.com/news/pinocchio-director-says-new-netflix-adaptation-is-not-made-for-kids)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 16:00:41+00:00

“Pinocchio” director Guillermo del Toro is cautioning parents that the stop-motion animated remake of the film is not meant for children to watch without supervision. The Oscar-winning director discussed the guidelines for his new Netflix project at the movie’s premiere. It’s being described as an “anti-fascist morality play” that’s “dark and gritty.” “People ask us ...

## ‘I Started To Cry’: Hollywood Star Credits Tom Cruise’s Rather Blunt Advice With Helping Her Get Through Sci-Fi Action Role
 - [https://www.dailywire.com/news/i-started-to-cry-hollywood-star-credits-tom-cruises-rather-blunt-advice-with-helping-her-get-through-sci-fi-action-role](https://www.dailywire.com/news/i-started-to-cry-hollywood-star-credits-tom-cruises-rather-blunt-advice-with-helping-her-get-through-sci-fi-action-role)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 15:55:37+00:00

Hollywood star Emily Blunt credited Tom Cruise&#8217;s non-PC advice with helping her get through filming the role of an action star in their 2014 sci-fi thriller hit &#8220;Edge of Tomorrow.&#8221; During the 39-year-old actress&#8217;s recent appearance on the &#8220;Smartless&#8221; podcast with Jason Bateman, Will Arnett, and Sean Hayes, Blunt talked about the challenges of the ...

## ‘Tough Slog’: Al Roker Finally Gives Fans An Update After Being Released From The Hospital For A Second Time
 - [https://www.dailywire.com/news/tough-slog-al-roker-finally-gives-fans-an-update-after-being-released-from-the-hospital-for-a-second-time](https://www.dailywire.com/news/tough-slog-al-roker-finally-gives-fans-an-update-after-being-released-from-the-hospital-for-a-second-time)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 15:49:29+00:00

Longtime &#8220;Today&#8221; show host Al Roker didn&#8217;t beat around the bush when he finally gave fans an update about his condition following a second hospitalization in recent weeks. In a video call from his home on Monday, the 68-year-old weather personality said his recent hospitalizations have been a &#8220;tough slog,&#8221; but thanked fans for all ...

## Buttigieg Took Taxpayer-Funded Private Jets. Trump’s HHS Sec Was Forced To Resign For Doing That.
 - [https://www.dailywire.com/news/buttigieg-took-taxpayer-funded-private-jets-trumps-hhs-sec-was-forced-to-resign-for-doing-that](https://www.dailywire.com/news/buttigieg-took-taxpayer-funded-private-jets-trumps-hhs-sec-was-forced-to-resign-for-doing-that)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 15:46:58+00:00

Secretary of Transportation Pete Buttigieg, an ardent proponent of reducing carbon emissions, has taken taxpayer-funded private jets rather than commercial planes at least 18 times since he was inaugurated into office, a new report says. Buttigieg has utilized a private jet fleet whose private records match his schedule of external and public engagements, as Americans ...

## Biden Invites Drag Queen To Attend Bill Signing At The White House
 - [https://www.dailywire.com/news/biden-invites-drag-queen-to-attend-bill-signing-at-the-white-house](https://www.dailywire.com/news/biden-invites-drag-queen-to-attend-bill-signing-at-the-white-house)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 15:36:15+00:00

President Joe Biden invited drag queen Marti G. Cummings to attend the signing of the Respect for Marriage Act at the White House. Both the House of Representatives and the Senate have greenlit the legislation, which enshrines same-sex marriage protections into federal law in accordance with the Supreme Court’s opinion in Obergefell v. Hodges. Democratic ...

## Marjorie Taylor Greene Responds To Outrage Over January 6 Remarks: ‘Learn How Sarcasm Works’
 - [https://www.dailywire.com/news/marjorie-taylor-greene-responds-to-outrage-over-january-6-remarks-learn-how-sarcasm-works](https://www.dailywire.com/news/marjorie-taylor-greene-responds-to-outrage-over-january-6-remarks-learn-how-sarcasm-works)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 15:21:18+00:00

Rep. Marjorie Taylor Greene (R-GA) shot back at critics upset over her saying Capitol rioters would have been armed and &#8220;won&#8221; if she and former Trump adviser Steve Bannon had planned it. The conservative firebrand released a statement Monday standing by her &#8220;sarcastic joke&#8221; after the White House condemned Greene for the comments she made ...

## Bald Eagles Get Sick, Die After Likely Poisoning From Eating Euthanized Animals
 - [https://www.dailywire.com/news/bald-eagles-get-sick-die-after-likely-poisoning-from-eating-euthanized-animals](https://www.dailywire.com/news/bald-eagles-get-sick-die-after-likely-poisoning-from-eating-euthanized-animals)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 15:14:42+00:00

Bald eagles have been getting sick and dying after potentially eating euthanized animals out of a landfill in Minnesota.  Last week, eagles were discovered in the vicinity of the Pine Bend Landfill in Inver Grove Heights, a Minneapolis suburb.  As the Star Tribune reported, the police department recently transferred an extremely ill young eagle found ...

## ‘They Fed Me To The Wolves’: Meghan Markle Blames Royal Family In New ‘Harry & Meghan’ Trailer
 - [https://www.dailywire.com/news/they-fed-me-to-the-wolves-meghan-markle-blames-royal-family-in-new-harry-meghan-trailer](https://www.dailywire.com/news/they-fed-me-to-the-wolves-meghan-markle-blames-royal-family-in-new-harry-meghan-trailer)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 15:04:12+00:00

A new trailer for Netflix’s docuseries “Harry &amp; Meghan” has some fans anxious to see the final three episodes, especially after a lackluster reception for the first three.  Many viewers were underwhelmed by the first half of the limited series, saying it didn’t provide any new information about Prince Harry and Meghan Markle that fans ...

## Sam Bankman-Fried’s Well-Connected Democrat Parents Hiding Out In Bahamas With Him
 - [https://www.dailywire.com/news/sam-bankman-frieds-well-connected-democrat-parents-hiding-out-in-bahamas-with-him](https://www.dailywire.com/news/sam-bankman-frieds-well-connected-democrat-parents-hiding-out-in-bahamas-with-him)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 14:56:41+00:00

Joseph Bankman and Barbara Fried, the parents of former FTX CEO Sam Bankman-Fried, have been in the Bahamas with their son for more than one month. FTX recently filed for bankruptcy after users discovered that the company was likely fraudulently intertwined with sister trading firm Alameda Research; both were controlled by Bankman-Fried and a close-knit ...

## ‘Effective Immediately’: Utah Bans TikTok From State Devices
 - [https://www.dailywire.com/news/effective-immediately-utah-bans-tiktok-from-state-devices](https://www.dailywire.com/news/effective-immediately-utah-bans-tiktok-from-state-devices)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 14:36:29+00:00

Utah Republican Governor Spencer Cox issued an executive order on Monday that bans TikTok from all state-owned devices, citing &#8220;security threats by China and China-based entities.&#8221; “China’s access to data collected by TikTok presents a threat to our cybersecurity,” Cox said. “As a result, we’ve deleted our TikTok account and ordered the same on all ...

## Loudoun Superintendent, Spokesman Criminally Indicted In Rape Coverup
 - [https://www.dailywire.com/news/loudoun-superintendent-spokesman-criminally-indicted-in-rape-coverup](https://www.dailywire.com/news/loudoun-superintendent-spokesman-criminally-indicted-in-rape-coverup)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 14:25:11+00:00

Two top officials of a Northern Virginia public school district were indicted Monday for their roles in the handling of a bathroom rape by a skirt-wearing boy after The Daily Wire revealed the apparent coverup last year, court documents unsealed Monday showed.

## Red Kettles And Racism: Where Do Your Salvation Army Donations Really Go?
 - [https://www.dailywire.com/news/red-kettles-and-racism-where-do-your-salvation-army-donations-really-go](https://www.dailywire.com/news/red-kettles-and-racism-where-do-your-salvation-army-donations-really-go)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 14:19:36+00:00

With locations in every zip code, the Salvation Army helps millions of Americans escape poverty every year by providing a host of services such as financial assistance, counseling, job training, and disaster relief. For decades, the Salvation Army has used the generous donations of Americans to better society by providing these services to people in ...

## Bank Of America CEO Could Be The Next Treasury Secretary: Report
 - [https://www.dailywire.com/news/bank-of-america-ceo-could-be-the-next-treasury-secretary-report](https://www.dailywire.com/news/bank-of-america-ceo-could-be-the-next-treasury-secretary-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 13:55:02+00:00

Bank of America CEO Brian Moynihan is on the shortlist to succeed Treasury Secretary Janet Yellen, according to a report from Fox Business. Multiple sources told the outlet the longtime investment banker joined Commerce Secretary Gina Raimondo and Securities and Exchange Commission Chair Gary Gensler on the list of potential candidates to take over the ...

## 10 Million Views Of Child Sexual Exploitation Material Allegedly Watched On ‘Old Twitter’: Report
 - [https://www.dailywire.com/news/10-million-views-of-child-sexual-exploitation-material-allegedly-watched-on-old-twitter-report](https://www.dailywire.com/news/10-million-views-of-child-sexual-exploitation-material-allegedly-watched-on-old-twitter-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 13:36:05+00:00

An independent cybersecurity data analyst working alongside top officials at Twitter found accounts posting content that allegedly sexually exploited children garnered more than ten million views on the platform under previous ownership. Andrea Stroppa, founder of cybersecurity group Ghost Data, personally funded research last summer that resulted in the eradication of more than 500 accounts ...

## Black Comedian Accuses Hotel Of Racial Profiling For Asking If He Was Staying There
 - [https://www.dailywire.com/news/black-comedian-accuses-hotel-of-racial-profiling-for-asking-if-he-was-staying-there](https://www.dailywire.com/news/black-comedian-accuses-hotel-of-racial-profiling-for-asking-if-he-was-staying-there)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 13:33:24+00:00

Comedian and 90s sitcom actor Mark Curry posted a video to social media over the weekend that has since gone viral, showing him being asked by employees to verify that he was a guest in a Colorado Springs hotel.  In the lengthy Instagram video, the 61-year-old actor accuses hotel staff of racially profiling him. He ...

## Speaker McCarthy? Not So Fast, Some Republicans Say
 - [https://www.dailywire.com/news/speaker-mccarthy-not-so-fast-some-republicans-say](https://www.dailywire.com/news/speaker-mccarthy-not-so-fast-some-republicans-say)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 13:29:01+00:00

A week after the 2022 midterm elections, Rep. Kevin McCarthy (R-CA) won the Republican Party’s nomination to become the next speaker of the House. But that isn&#8217;t the end of the story. Not even close. The GOP caucus is fractured, and McCarthy already has at least one challenger for the post. A candidate must win ...

## ‘A Tremendous Loss’: Georgia City’s Mayor And His Wife Killed In Car Crash By Driver Charged With DUI
 - [https://www.dailywire.com/news/a-tremendous-loss-georgia-citys-mayor-and-his-wife-killed-in-car-crash-by-driver-charged-with-dui](https://www.dailywire.com/news/a-tremendous-loss-georgia-citys-mayor-and-his-wife-killed-in-car-crash-by-driver-charged-with-dui)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 13:07:55+00:00

The longtime mayor of a Georgia city and his wife died in a car accident over the weekend. Albert and Camilla Pallone were killed on Saturday after a pickup truck swerved into their lane and struck the mayor&#8217;s sports utility vehicle, according to the Cherokee County Sheriff&#8217;s Office. Albert Pallone was the mayor of Emerson, ...

## J.K. Rowling On Why She Chose To Stand Up To Trans Activists: ‘A Phenomenally Privileged Position’
 - [https://www.dailywire.com/news/j-k-rowling-on-why-she-chose-to-stand-up-to-trans-activists-a-phenomenally-privileged-position](https://www.dailywire.com/news/j-k-rowling-on-why-she-chose-to-stand-up-to-trans-activists-a-phenomenally-privileged-position)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 13:02:19+00:00

Best-selling author J.K. Rowling is one of the few mainstream celebrities willing to stand up to trans activists publicly, and during a recent interview she explained her reasons for doing so.  The 57-year-old “Harry Potter” writer said it all came down to knowing she had enough funds to withstand the inevitable backlash.  “It’s going to ...

## Golden Globe Nominees Announced: ‘The Banshees of Inisherin’ Leads With 8 Nominations
 - [https://www.dailywire.com/news/golden-globe-nominees-announced-the-banshees-of-inisherin-leads-with-8-nominations](https://www.dailywire.com/news/golden-globe-nominees-announced-the-banshees-of-inisherin-leads-with-8-nominations)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 12:59:16+00:00

The Golden Globes, whose ratings crashed 64% in 2021, then had its 2022 event canceled following an investigation by The Los Angeles Times accusing the Hollywood Foreign Press Association, which hosts the awards, of ethical failures, announced their 2022 nominees for film and television for their event on January 10. Only 6.9 million people watched ...

## Second Journalist Suddenly Dies At World Cup
 - [https://www.dailywire.com/news/second-journalist-suddenly-dies-at-world-cup](https://www.dailywire.com/news/second-journalist-suddenly-dies-at-world-cup)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 12:46:30+00:00

A Qatari photographer died on Saturday while covering the World Cup, making him the second journalist to pass away during the global soccer event following the death of American reporter Grant Wahl. Khalid al-Misslam, who worked for Qatari sports outlet Al Kass TV, &#8220;died suddenly while covering&#8221; the tournament, according to Doha&#8217;s Gulf Times. “We ...

## Twitter Is Auctioning Off Espresso Machines, Lounge Chairs, Other Employee Toys. Here’s What Else Is For Sale.
 - [https://www.dailywire.com/news/twitter-is-auctioning-off-espresso-machines-lounge-chairs-other-employee-toys-heres-what-else-is-for-sale](https://www.dailywire.com/news/twitter-is-auctioning-off-espresso-machines-lounge-chairs-other-employee-toys-heres-what-else-is-for-sale)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 12:37:44+00:00

Members of the public will have an opportunity to rob the graveyard of old Twitter as dismissed employees’ once-beloved espresso machines and lounge chairs are put up for auction. The social media company will sell off kitchen equipment and furniture from its San Francisco office next month to interested buyers through Heritage Global Partners, a ...

## ‘There’s Nothing Worse Than Whiny Celebrities’: Jay Leno Jokes, Refuses To Complain About Burn Accident
 - [https://www.dailywire.com/news/theres-nothing-worse-than-whiny-celebrities-jay-leno-jokes-refuses-to-complain-about-burn-accident](https://www.dailywire.com/news/theres-nothing-worse-than-whiny-celebrities-jay-leno-jokes-refuses-to-complain-about-burn-accident)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 12:28:56+00:00

Former late-night host Jay Leno, who suffered third-degree burns on his face when he was working on his 1907 White Steam Car and an explosion occurred, gave a succinct explanation for why he has not complained about his recovery. Leno, who hosted The Tonight Show between 1992 and 2009, was working on a clogged fuel ...

## Fundraiser Explodes For Child After Family Says Duke Denying Kidney Transplant Over COVID Vax
 - [https://www.dailywire.com/news/fundraiser-explodes-for-child-after-family-says-duke-denying-kidney-transplant-over-covid-vax](https://www.dailywire.com/news/fundraiser-explodes-for-child-after-family-says-duke-denying-kidney-transplant-over-covid-vax)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 12:16:49+00:00

A fundraiser has exploded online for a child who was reportedly denied a kidney transplant by Duke University&#8217;s children’s hospital, raising nearly $230,000 in a matter of days. Yulia Hicks, 14, has a genetic kidney disorder that requires a transplant, but her family says the hospital is refusing to put her on the kidney wait ...

## ‘Nature Is Healing’: Elon Musk Responds As Silicon Valley CEOs Follow His Lead And Dismiss Surplus Employees
 - [https://www.dailywire.com/news/nature-is-healing-elon-musk-responds-as-silicon-valley-ceos-follow-his-lead-and-dismiss-surplus-employees](https://www.dailywire.com/news/nature-is-healing-elon-musk-responds-as-silicon-valley-ceos-follow-his-lead-and-dismiss-surplus-employees)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 11:01:09+00:00

Inspired by the recent actions of new Twitter owner and chief executive Elon Musk, more business leaders in California&#8217;s Silicon Valley are dismissing surplus employees. The startup and venture capital industries appeared to take note as Musk acquired the social media company and dismissed two-thirds of employees with no apparent impact on the platform’s operations. ...

## WATCH: More Than 1,000 Migrants Cross Border Into El Paso Overnight
 - [https://www.dailywire.com/news/watch-more-than-1000-migrants-cross-border-into-el-paso-overnight](https://www.dailywire.com/news/watch-more-than-1000-migrants-cross-border-into-el-paso-overnight)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 10:51:07+00:00

A massive caravan of more than 1,000 migrants crossed the southern border of the U.S. into El Paso, Texas, on Sunday night. Video posted to Twitter by Fox News correspondent Bill Melugin showed the group wading across the Rio Grande River from Mexico. &#8220;A huge migrant caravan of over 1,000 people crossed illegally into El ...

## University Of Texas Men’s Basketball Head Coach Arrested For Felony Assault
 - [https://www.dailywire.com/news/university-of-texas-mens-basketball-head-coach-arrested-for-felony-assault](https://www.dailywire.com/news/university-of-texas-mens-basketball-head-coach-arrested-for-felony-assault)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 10:01:37+00:00

Chris Beard, the head coach of the University of Texas men&#8217;s basketball team, was arrested during the early morning hours on Monday and charged with third-degree assault on a family member. Beard, 49, was arrested after Austin Police reportedly responded to a &#8220;disturbance hot shot,&#8221; which the department says are incidents that &#8220;are in progress ...

## Sam Bankman-Fried Worried About Arrest But Would ‘Give Anything’ To Start Another Business
 - [https://www.dailywire.com/news/sam-bankman-fried-worried-about-arrest-but-would-give-anything-to-start-another-business](https://www.dailywire.com/news/sam-bankman-fried-worried-about-arrest-but-would-give-anything-to-start-another-business)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 09:58:26+00:00

Former FTX CEO Sam Bankman-Fried desires to launch a new business that would pay back customers of his now-bankrupt cryptocurrency exchange. FTX filed for bankruptcy last month after users discovered that the company was likely fraudulently intertwined with trading firm Alameda Research; both were controlled by Bankman-Fried and a close-knit group of amateur executives. During ...

## Elon Musk Fires: ‘The Woke Mind Virus Is Either Defeated Or Nothing Else Matters’
 - [https://www.dailywire.com/news/elon-musk-fires-the-woke-mind-virus-is-either-defeated-or-nothing-else-matters](https://www.dailywire.com/news/elon-musk-fires-the-woke-mind-virus-is-either-defeated-or-nothing-else-matters)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-12 08:53:20+00:00

After he was booed when he made a surprise appearance on stage with Dave Chappelle at Chappelle’s show at the Chase Center in San Francisco Sunday night, Twitter CEO Elon Musk followed by issuing a ringing denunciation of his leftist foes on Monday morning. When Chappelle introduced Musk, much of the crowd booed, prompting Chappelle to ...


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Rob Alderman, Middle-earth Brand Manager, Games Workshop
 - [https://www.youtube.com/watch?v=FGZL-k6ziUg](https://www.youtube.com/watch?v=FGZL-k6ziUg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-12-13 00:00:00+00:00

We chat with Rob Alderman of Games Workshop - creators of The Middle-earth Strategy Battle Game and Warhammer!  We'll talk about the challenges of adapting Tolkien for tabletop gaming, expanding into lesser-known realms like Harad and Rhûn, and some of the brand new releases (like the mighty ELROND and the Battle of Osgiliath!)

Check out the game:
https://middle-earthstrategybattlegame.com/

#gamesworkshop #lordoftherings #warhammer


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## The Witcher 3 NEXT-GEN - Before You Buy
 - [https://www.youtube.com/watch?v=hUsFjzY2Mi8](https://www.youtube.com/watch?v=hUsFjzY2Mi8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-12-13 00:00:00+00:00

The Witcher 3 (PC, PS5, Xbox Series X/S) is now updated to take advantage of next gen systems. How is it? Let's take a quick look at the upgrades and fixes.
Subscribe for more: http://youtube.com/gameranxtv ▼

Buy Witcher 3: https://amzn.to/3BzxCNU
 

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

#thewitcher3

## 10 BIG Video Game Items That Turned Out To BE USELESS [Part 2]
 - [https://www.youtube.com/watch?v=bxgFdv9DpUA](https://www.youtube.com/watch?v=bxgFdv9DpUA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-12-12 00:00:00+00:00

Video games often give you tons of useless items, but only the worst of the worst are remembered. Here are more examples of bad items in games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:52 Number 10
2:35 Number 9
3:21 Number 8
4:18 Number 7
5:04 Number 6
6:12 Number 5
7:26 Number 4
8:43 Number 3
9:49 Number 2
11:11 Number 1


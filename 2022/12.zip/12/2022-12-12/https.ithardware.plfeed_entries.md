# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## GOG. Wystartowała Zimowa Wyprzedaż 2022, platforma udostępnia grę za darmo
 - [https://ithardware.pl/aktualnosci/gog_wystartowala_zimowa_wyprzedaz_2022_platforma_udostepnia_gre_za_darmo-24831.html](https://ithardware.pl/aktualnosci/gog_wystartowala_zimowa_wyprzedaz_2022_platforma_udostepnia_gre_za_darmo-24831.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 22:50:00+00:00

<img src="https://ithardware.pl/artykuly/min/24831_1.jpg" />            Na GOG wystartowała Zimowa Wyprzedaż, kt&oacute;ra potrwa do początku 2023 roku. W ramach akcji obniżono ceny wielu tytuł&oacute;w a rabaty sięgają nawet 95%. Oto najciekawsze propozycje z wyprzedaży.

GOG ruszył z Zimową Wyprzedażą...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gog_wystartowala_zimowa_wyprzedaz_2022_platforma_udostepnia_gre_za_darmo-24831.html">https://ithardware.pl/aktualnosci/gog_wystartowala_zimowa_wyprzedaz_2022_platforma_udostepnia_gre_za_darmo-24831.html</a></p>

## Xiaomi chwali się, że ich smartfon osiąga znacznie niższe temperatury od iPhona 14 podczas grania
 - [https://ithardware.pl/aktualnosci/xiaomi_chwali_sie_ze_ich_smartfon_osiaga_znacznie_nizsze_temperatury_od_iphona_14_podczas_grania-24830.html](https://ithardware.pl/aktualnosci/xiaomi_chwali_sie_ze_ich_smartfon_osiaga_znacznie_nizsze_temperatury_od_iphona_14_podczas_grania-24830.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 21:29:10+00:00

<img src="https://ithardware.pl/artykuly/min/24830_1.jpg" />            Oficjalna prezentacja najnowszych flagowc&oacute;w Xiaomi odbyła się jak dotąd&nbsp;jedynie w Chinach. Nie zabrakło pierwszych przechwałek oraz por&oacute;wnań do konkurencyjnego smartfona od Apple. Według chińskiego producenta, podczas grania...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/xiaomi_chwali_sie_ze_ich_smartfon_osiaga_znacznie_nizsze_temperatury_od_iphona_14_podczas_grania-24830.html">https://ithardware.pl/aktualnosci/xiaomi_chwali_sie_ze_ich_smartfon_osiaga_znacznie_nizsze_temperatury_od_iphona_14_podczas_grania-24830.html</a></p>

## Infinity Ward zmieniło skina w Call of Duty. Gracze domagają się zwrotu pieniędzy
 - [https://ithardware.pl/aktualnosci/infinity_ward_zmienilo_skina_w_call_of_duty_gracze_domagaja_sie_zwrotu_pieniedzy-24829.html](https://ithardware.pl/aktualnosci/infinity_ward_zmienilo_skina_w_call_of_duty_gracze_domagaja_sie_zwrotu_pieniedzy-24829.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 20:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/24829_1.jpg" />            Infinity Ward zmieniło wygląd skina do Call of Duty, kt&oacute;ry spotkał się z tak dużym zainteresowaniem, że trafił&nbsp;na listę bestseller&oacute;w Steam. Gracze nie są z tej poprawki zadowoleni, ale mają ku temu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/infinity_ward_zmienilo_skina_w_call_of_duty_gracze_domagaja_sie_zwrotu_pieniedzy-24829.html">https://ithardware.pl/aktualnosci/infinity_ward_zmienilo_skina_w_call_of_duty_gracze_domagaja_sie_zwrotu_pieniedzy-24829.html</a></p>

## Kolejny MacBook Air może przynieść rewolucyjną zmianę w kwestii ekranu
 - [https://ithardware.pl/aktualnosci/kolejny_macbook_air_moze_przyniesc_rewolucyjna_zmiane_w_kwestii_ekranu-24828.html](https://ithardware.pl/aktualnosci/kolejny_macbook_air_moze_przyniesc_rewolucyjna_zmiane_w_kwestii_ekranu-24828.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 19:51:40+00:00

<img src="https://ithardware.pl/artykuly/min/24828_1.jpg" />            Apple może zrezygnować z wyświetlacza LCD na rzecz OLED-owego ekranu&nbsp;w przypadku nowego&nbsp;MacBooka&nbsp;Air. Jeden z analityk&oacute;w wskazuje, że sam komputer będzie miał rozmiar 13,3&quot;, a jego premiera odbędzie się już w 2024...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kolejny_macbook_air_moze_przyniesc_rewolucyjna_zmiane_w_kwestii_ekranu-24828.html">https://ithardware.pl/aktualnosci/kolejny_macbook_air_moze_przyniesc_rewolucyjna_zmiane_w_kwestii_ekranu-24828.html</a></p>

## Phil Spencer uważa, że Sony chce osłabić pozycję Xboxa
 - [https://ithardware.pl/aktualnosci/phil_spencer_uwaza_ze_sony_chce_oslabic_pozycje_xboxa-24827.html](https://ithardware.pl/aktualnosci/phil_spencer_uwaza_ze_sony_chce_oslabic_pozycje_xboxa-24827.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 18:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/24827_1.jpg" />            Przejęcie Activision Blizzard stało się kością niezgody między Microsoftem a Sony i rozpoczęło nowy etap wojny dw&oacute;jki gigant&oacute;w technologicznych. Do działania Japończyk&oacute;w odni&oacute;sł się szef marki Xbox, Phil...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/phil_spencer_uwaza_ze_sony_chce_oslabic_pozycje_xboxa-24827.html">https://ithardware.pl/aktualnosci/phil_spencer_uwaza_ze_sony_chce_oslabic_pozycje_xboxa-24827.html</a></p>

## ENDORFY – polska marka dostępna w grze PC Building Simulator 2
 - [https://ithardware.pl/aktualnosci/endorfy_polska_marka_dostepna_w_grze_pc_building_simulator_2-24826.html](https://ithardware.pl/aktualnosci/endorfy_polska_marka_dostepna_w_grze_pc_building_simulator_2-24826.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 16:40:20+00:00

<img src="https://ithardware.pl/artykuly/min/24826_1.jpg" />            ENDORFY to nowa globalna marka powstała&nbsp;z połączenia SPC Gear oraz SilentiuPC, kt&oacute;ra należy do&nbsp;sp&oacute;łki Cooling.&nbsp;Marka ENDORFY poinformowała o zostaniu&nbsp;partnerem gry PC Building Simulator 2.

PC Building Simulator...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/endorfy_polska_marka_dostepna_w_grze_pc_building_simulator_2-24826.html">https://ithardware.pl/aktualnosci/endorfy_polska_marka_dostepna_w_grze_pc_building_simulator_2-24826.html</a></p>

## TP-Link przedstawia nowe urządzenia smart home z serii Tapo
 - [https://ithardware.pl/aktualnosci/tp_link_przedstawia_nowe_urzadzenia_smart_home_z_serii_tapo-24824.html](https://ithardware.pl/aktualnosci/tp_link_przedstawia_nowe_urzadzenia_smart_home_z_serii_tapo-24824.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 15:10:00+00:00

<img src="https://ithardware.pl/artykuly/min/24824_1.jpg" />            TP-Link wprowadził do oferty nowe urządzenia smart,&nbsp;hub Tapo H100, czujnik ruchu Tapo T100, czujnik magnetyczny Tapo T110, włączniki światła Tapo S210 i S220 oraz przycisk smart Tapo S200B.

Inteligentny Hub Tapo H100 wyposażono we...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tp_link_przedstawia_nowe_urzadzenia_smart_home_z_serii_tapo-24824.html">https://ithardware.pl/aktualnosci/tp_link_przedstawia_nowe_urzadzenia_smart_home_z_serii_tapo-24824.html</a></p>

## Dyrektor Apple wyrzucony z hukiem za parafrazę żartu z filmu. Nie wszyscy się z tym zgadzają
 - [https://ithardware.pl/aktualnosci/dyrektor_apple_wyrzucony_za_parafraze_zartu_z_filmu_na_tiktoku_nie_wszyscy_sie_z_tym_zgadzaja-24823.html](https://ithardware.pl/aktualnosci/dyrektor_apple_wyrzucony_za_parafraze_zartu_z_filmu_na_tiktoku_nie_wszyscy_sie_z_tym_zgadzaja-24823.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 13:48:50+00:00

<img src="https://ithardware.pl/artykuly/min/24823_1.jpg" />            Zaoszczędził firmie setki milion&oacute;w dolar&oacute;w i zapewnił utrzymanie łańcucha dostaw. Lata kariery przekreślił jeden żart opublikowany na TikToku. Pracownicy Apple są podzieleni w reakcji na zwolnienie jednego z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dyrektor_apple_wyrzucony_za_parafraze_zartu_z_filmu_na_tiktoku_nie_wszyscy_sie_z_tym_zgadzaja-24823.html">https://ithardware.pl/aktualnosci/dyrektor_apple_wyrzucony_za_parafraze_zartu_z_filmu_na_tiktoku_nie_wszyscy_sie_z_tym_zgadzaja-24823.html</a></p>

## Administracja Bidena odcina się od cenzury Twittera. „Nie byliśmy zaangażowani”
 - [https://ithardware.pl/aktualnosci/administracja_bidena_odcina_sie_od_cenzury_twittera_nie_bylismy_zaangazowani-24821.html](https://ithardware.pl/aktualnosci/administracja_bidena_odcina_sie_od_cenzury_twittera_nie_bylismy_zaangazowani-24821.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 13:08:30+00:00

<img src="https://ithardware.pl/artykuly/min/24821_1.jpg" />            Administracja Bidena podkreśliła, że ​​&bdquo;nie była zaangażowana&rdquo; w pr&oacute;by wpływania na decyzje&nbsp;Twittera&nbsp;dotyczące moderacji treści, ani nie wsp&oacute;łpracowała z byłym zastępcą gł&oacute;wnego radcy prawnego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/administracja_bidena_odcina_sie_od_cenzury_twittera_nie_bylismy_zaangazowani-24821.html">https://ithardware.pl/aktualnosci/administracja_bidena_odcina_sie_od_cenzury_twittera_nie_bylismy_zaangazowani-24821.html</a></p>

## Test Lenovo Legion Slim 7i (16IAH7). Jeden z najlepszych gamingowych laptopów na rynku
 - [https://ithardware.pl/testyirecenzje/test_lenovo_legion_slim_7i_16iah7_jeden_z_najlepszych_gamingowych_laptopow_na_rynku-24786.html](https://ithardware.pl/testyirecenzje/test_lenovo_legion_slim_7i_16iah7_jeden_z_najlepszych_gamingowych_laptopow_na_rynku-24786.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 12:37:50+00:00

<img src="https://ithardware.pl/artykuly/min/24786_1.jpg" />            Test Lenovo Legion Slim 7i (16IAH7). Jeden z najlepszych gamingowych laptop&oacute;w na rynku

Laptopy Lenovo, bądź co bądź jednego z lider&oacute;w rynku notebook&oacute;w, raczej rzadko trafiają do naszej redakcji na testy (mamy nadzieję, że...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/test_lenovo_legion_slim_7i_16iah7_jeden_z_najlepszych_gamingowych_laptopow_na_rynku-24786.html">https://ithardware.pl/testyirecenzje/test_lenovo_legion_slim_7i_16iah7_jeden_z_najlepszych_gamingowych_laptopow_na_rynku-24786.html</a></p>

## Podobno nie zabraknie nowych Radeonów na premierę. AMD miało zadbać o odpowiednie zapasy
 - [https://ithardware.pl/aktualnosci/podobno_nie_zabraknie_nowych_radeonow_na_premiere_amd_mialo_zadbac_o_odpowiednie_zapasy-24808.html](https://ithardware.pl/aktualnosci/podobno_nie_zabraknie_nowych_radeonow_na_premiere_amd_mialo_zadbac_o_odpowiednie_zapasy-24808.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 12:33:01+00:00

<img src="https://ithardware.pl/artykuly/min/24808_1.jpg" />            Dotychczas docierały do nas dość sprzeczne informacji na temat dostępności kart graficznych z serii Radeon RX 7900 na premierę, ale najnowsze z nich wskazują, że będziemy mogli bez problem&oacute;w kupić te grafiki, co może być mocnym ciosem...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/podobno_nie_zabraknie_nowych_radeonow_na_premiere_amd_mialo_zadbac_o_odpowiednie_zapasy-24808.html">https://ithardware.pl/aktualnosci/podobno_nie_zabraknie_nowych_radeonow_na_premiere_amd_mialo_zadbac_o_odpowiednie_zapasy-24808.html</a></p>

## Apple żąda zbyt wysokiej prowizji, więc Musk podnosi ceny użytkownikom iPhone'ów
 - [https://ithardware.pl/aktualnosci/apple_zada_zbyt_wysokiej_prowizji_wiec_musk_podnosi_ceny_uzytkownikom_iphone_ow-24818.html](https://ithardware.pl/aktualnosci/apple_zada_zbyt_wysokiej_prowizji_wiec_musk_podnosi_ceny_uzytkownikom_iphone_ow-24818.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 12:07:10+00:00

<img src="https://ithardware.pl/artykuly/min/24818_1.jpg" />            Elon Musk niedawno mocno krytykował Apple m.in. za ich wysokie 30% prowizje i brak możliwości pobierania płatności&nbsp;poza systemem producenta iPhone'&oacute;w. Niedługo potem właściciel Twittera spotkał się z Timem Cookiem z Apple, co...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_zada_zbyt_wysokiej_prowizji_wiec_musk_podnosi_ceny_uzytkownikom_iphone_ow-24818.html">https://ithardware.pl/aktualnosci/apple_zada_zbyt_wysokiej_prowizji_wiec_musk_podnosi_ceny_uzytkownikom_iphone_ow-24818.html</a></p>

## Gigabyte Radeon RX 7900 XTX z fabrycznym taktowaniem 2,68 GHz
 - [https://ithardware.pl/aktualnosci/gigabyte_radeon_rx_7900_xtx_z_fabrycznym_taktowaniem_2_68_ghz-24815.html](https://ithardware.pl/aktualnosci/gigabyte_radeon_rx_7900_xtx_z_fabrycznym_taktowaniem_2_68_ghz-24815.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 11:31:50+00:00

<img src="https://ithardware.pl/artykuly/min/24815_1.jpg" />            Jeszcze tylko jeden dzień dzieli nas od premiery nowych Radeon&oacute;w&nbsp;RX 7900 na sklepowych p&oacute;łkach, ale już teraz wiemy, że&nbsp;Gigabyte wprowadzi 5 modeli, przy czym ten najwyżej taktowany będzie sięgać częstotliwości boost na...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gigabyte_radeon_rx_7900_xtx_z_fabrycznym_taktowaniem_2_68_ghz-24815.html">https://ithardware.pl/aktualnosci/gigabyte_radeon_rx_7900_xtx_z_fabrycznym_taktowaniem_2_68_ghz-24815.html</a></p>

## NVIDIA chwali się swoimi sterownikami. AMD i Intel mocno z tyłu
 - [https://ithardware.pl/aktualnosci/nvidia_chwali_sie_swoimi_sterownikami_amd_i_intel_mocno_z_tylu-24807.html](https://ithardware.pl/aktualnosci/nvidia_chwali_sie_swoimi_sterownikami_amd_i_intel_mocno_z_tylu-24807.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 11:26:01+00:00

<img src="https://ithardware.pl/artykuly/min/24807_1.jpg" />            NVIDIA właśnie pochwaliła się swoimi przewagami, jeśli chodzi wydawanie sterownik&oacute;w do kart graficznych. Liczby m&oacute;wią tu same za siebie i Zieloni rzeczywiście zostawiają Intela i AMD wyraźnie z tyłu.&nbsp;

Jeśli chodzi o karty...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_chwali_sie_swoimi_sterownikami_amd_i_intel_mocno_z_tylu-24807.html">https://ithardware.pl/aktualnosci/nvidia_chwali_sie_swoimi_sterownikami_amd_i_intel_mocno_z_tylu-24807.html</a></p>

## Huawei podpisuje umowę patentową z największym chińskim rywalem
 - [https://ithardware.pl/aktualnosci/huawei_podpisuje_umowe_patentowa_z_najwiekszym_chinskim_rywalem-24806.html](https://ithardware.pl/aktualnosci/huawei_podpisuje_umowe_patentowa_z_najwiekszym_chinskim_rywalem-24806.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 10:49:01+00:00

<img src="https://ithardware.pl/artykuly/min/24806_1.jpg" />            Zanim sankcje z czas&oacute;w Trumpa sprawiły, że przestało być jednym z największych graczy na rynku smartfon&oacute;w, Huawei było nawet przez kr&oacute;tki czas największym producentem telefon&oacute;w na świecie, wyprzedzając zar&oacute;wno...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/huawei_podpisuje_umowe_patentowa_z_najwiekszym_chinskim_rywalem-24806.html">https://ithardware.pl/aktualnosci/huawei_podpisuje_umowe_patentowa_z_najwiekszym_chinskim_rywalem-24806.html</a></p>

## Wyciekła specyfikacja nowej generacji laptopów HP Omen 17. Core i7-13700HX i GeForce RTX 4090
 - [https://ithardware.pl/aktualnosci/wyciekla_specyfikacja_nowej_generacji_laptopow_hp_omen_17_core_i7_13700hx_i_geforce_rtx_4090-24805.html](https://ithardware.pl/aktualnosci/wyciekla_specyfikacja_nowej_generacji_laptopow_hp_omen_17_core_i7_13700hx_i_geforce_rtx_4090-24805.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 10:16:01+00:00

<img src="https://ithardware.pl/artykuly/min/24805_1.jpg" />            Jak wynika z najnowszego wycieku opublikowanego przez znanego informatora @momomo_us, HP przygotowuje co najmniej sześć r&oacute;żnych laptop&oacute;w HP Omen z r&oacute;żnymi konfiguracjami pamięci systemowej, dysk&oacute;w i grafiki. Te laptopy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wyciekla_specyfikacja_nowej_generacji_laptopow_hp_omen_17_core_i7_13700hx_i_geforce_rtx_4090-24805.html">https://ithardware.pl/aktualnosci/wyciekla_specyfikacja_nowej_generacji_laptopow_hp_omen_17_core_i7_13700hx_i_geforce_rtx_4090-24805.html</a></p>

## Intel Core i5-13400 nawet 30% wydajniejszy od poprzednika
 - [https://ithardware.pl/aktualnosci/intel_core_i5_13400_nawet_30_wydajniejszy_od_poprzednika-24804.html](https://ithardware.pl/aktualnosci/intel_core_i5_13400_nawet_30_wydajniejszy_od_poprzednika-24804.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 09:12:01+00:00

<img src="https://ithardware.pl/artykuly/min/24804_1.jpg" />            Procesor Intel Core i5-13400 do komputer&oacute;w stacjonarnych pojawił się w testach przeprowadzonych przez indonezyjski portal technologiczny Jawara. Wyniki pokazują do 30% poprawę w stosunku do poprzednika.

Niedawno pojawiły się doniesienia,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_core_i5_13400_nawet_30_wydajniejszy_od_poprzednika-24804.html">https://ithardware.pl/aktualnosci/intel_core_i5_13400_nawet_30_wydajniejszy_od_poprzednika-24804.html</a></p>

## Wyciekły szczegóły specyfikacji karty GeForce RTX 4070. Mocno okrojone GPU AD104
 - [https://ithardware.pl/aktualnosci/wyciekly_szczegoly_specyfikacji_karty_geforce_rtx_4070_mocno_okrojone_gpu_ad104-24803.html](https://ithardware.pl/aktualnosci/wyciekly_szczegoly_specyfikacji_karty_geforce_rtx_4070_mocno_okrojone_gpu_ad104-24803.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 08:24:10+00:00

<img src="https://ithardware.pl/artykuly/min/24803_1.jpg" />            Znany branżowy informator @kopite7kimi ujawnił wstępne specyfikacje nadchodzącej karty graficznej GeForce RTX 4070 (nie Ti). Jak wynika z jego danych, Zieloni zdecydowali się użyć mocno okrojonego procesora graficznego AD104 w tym modelu.

Warto...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wyciekly_szczegoly_specyfikacji_karty_geforce_rtx_4070_mocno_okrojone_gpu_ad104-24803.html">https://ithardware.pl/aktualnosci/wyciekly_szczegoly_specyfikacji_karty_geforce_rtx_4070_mocno_okrojone_gpu_ad104-24803.html</a></p>

## Radeony RX 7900 XTX i XT przetestowane w grach. To może być gwóźdź do trumny GeForce'a RTX 4080
 - [https://ithardware.pl/aktualnosci/radeony_rx_7900_xtx_i_xt_przetestowane_w_grach_to_moze_byc_gwozdz_do_trumny_geforce_a_rtx_4080-24802.html](https://ithardware.pl/aktualnosci/radeony_rx_7900_xtx_i_xt_przetestowane_w_grach_to_moze_byc_gwozdz_do_trumny_geforce_a_rtx_4080-24802.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 07:55:56+00:00

<img src="https://ithardware.pl/artykuly/min/24802_1.jpg" />            Już jutro karty graficzne AMD z serii Radeon RX 7900 wylądują na sklepowych p&oacute;łkach i w związku z tym otrzymamy ich pierwsze recenzje. Niekt&oacute;rzy są jednak niecierpliwi i postanowili już teraz podzielić się z nami wynikami...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/radeony_rx_7900_xtx_i_xt_przetestowane_w_grach_to_moze_byc_gwozdz_do_trumny_geforce_a_rtx_4080-24802.html">https://ithardware.pl/aktualnosci/radeony_rx_7900_xtx_i_xt_przetestowane_w_grach_to_moze_byc_gwozdz_do_trumny_geforce_a_rtx_4080-24802.html</a></p>

## Elon Musk przeprowadzi czystkę na Twitterze. Do śmieci trafi 1,5 miliarda kont użytkowników
 - [https://ithardware.pl/aktualnosci/elon_musk_przeprowadzi_czystke_na_twitterze_do_smieci_trafi_1_5_miliarda_kont_uzytkownikow-24801.html](https://ithardware.pl/aktualnosci/elon_musk_przeprowadzi_czystke_na_twitterze_do_smieci_trafi_1_5_miliarda_kont_uzytkownikow-24801.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 07:37:40+00:00

<img src="https://ithardware.pl/artykuly/min/24801_1.jpg" />            Elon Musk planuje rozpocząć wielką czystkę na Twitterze.&nbsp;W niedalekiej przyszłości usunięta zostanie niewiarygodna liczba 1,5 miliarda kont użytkownik&oacute;w.&nbsp;Dla por&oacute;wnania aktywnych użytkownik&oacute;w jest około 330...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/elon_musk_przeprowadzi_czystke_na_twitterze_do_smieci_trafi_1_5_miliarda_kont_uzytkownikow-24801.html">https://ithardware.pl/aktualnosci/elon_musk_przeprowadzi_czystke_na_twitterze_do_smieci_trafi_1_5_miliarda_kont_uzytkownikow-24801.html</a></p>

## Konkurs adwentowy z ITHardware! - Dzień #12
 - [https://ithardware.pl/aktualnosci/konkurs_adwentowy_2022_dzien_12-24799.html](https://ithardware.pl/aktualnosci/konkurs_adwentowy_2022_dzien_12-24799.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-12 06:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/24799_1.jpg" />            P&oacute;łmetek! Dwunasty dzień Konkursu Adwentowego z ITHardware to kolejna nagroda do zdobycia. Tym razem sklep HardPC ufundował bezprzewodową myszkę gamingową Pulsar Xlite Wireless V2!

&nbsp;

&nbsp;

Nagroda - myszka gamingowa Pulsar...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/konkurs_adwentowy_2022_dzien_12-24799.html">https://ithardware.pl/aktualnosci/konkurs_adwentowy_2022_dzien_12-24799.html</a></p>


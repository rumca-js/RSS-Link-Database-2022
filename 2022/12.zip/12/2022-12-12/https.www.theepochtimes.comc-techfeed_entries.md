# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## Twitter’s New Head of Trust and Safety Reveals Plans After Previous Chief Departs
 - [https://www.theepochtimes.com/twitters-new-head-of-trust-and-safety-reveals-plans-after-previous-chief-departs_4918658.html](https://www.theepochtimes.com/twitters-new-head-of-trust-and-safety-reveals-plans-after-previous-chief-departs_4918658.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-12 18:31:59+00:00

Tesla CEO Elon Musk speaks about new Autopilot features during a Tesla event in Palo Alto, Calif., on Oct. 14, 2015. (Beck Diefenbach/Reuters)

## Elon Musk Targets Fauci in Viral Posts: ‘Just One More Lockdown, My King…’
 - [https://www.theepochtimes.com/elon-musk-targets-fauci-in-viral-posts-just-one-more-lockdown-my-king_4918123.html](https://www.theepochtimes.com/elon-musk-targets-fauci-in-viral-posts-just-one-more-lockdown-my-king_4918123.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-12 13:16:38+00:00

Dr. Anthony Fauci, director of the National Institute of Allergy and Infectious Diseases, on Capitol Hill in Washington on Sept. 14, 2022. (Drew Angerer/Getty Images)

## Lawsuit Filed After Children Stopped Eating and Sleeping to Play ‘Fortnite’
 - [https://www.theepochtimes.com/lawsuit-filed-after-children-stopped-eating-and-sleeping-to-play-fortnite_4918072.html](https://www.theepochtimes.com/lawsuit-filed-after-children-stopped-eating-and-sleeping-to-play-fortnite_4918072.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-12 11:31:26+00:00

Fans cheer during the final of the Solo competition at the 2019 Fortnite World Cup inside of Arthur Ashe Stadium, in New York City, on July 28, 2019. (Johannes Eisele/AFP via Getty Images)

## Taiwan Mulls Nationwide Ban on TikTok After Banning It From Government Devices
 - [https://www.theepochtimes.com/taiwan-mulls-nationwide-ban-on-tiktok-after-banning-it-from-government-devices_4917819.html](https://www.theepochtimes.com/taiwan-mulls-nationwide-ban-on-tiktok-after-banning-it-from-government-devices_4917819.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-12 11:15:47+00:00

The download page for the TikTok app is displayed on an Apple iPhone in Washington, on Aug. 7, 2020. (Drew Angerer/Getty Images)


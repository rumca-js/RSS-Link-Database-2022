# Source:NBC tech, URL:https://feeds.nbcnews.com/nbcnews/public/tech, language:en-US

## Elon Musk, astronaut Scott Kelly spar on Twitter over pronoun use
 - [https://www.nbcnews.com/nbc-out/out-news/elon-musk-astronaut-scott-kelly-spar-twitter-pronoun-use-rcna61309](https://www.nbcnews.com/nbc-out/out-news/elon-musk-astronaut-scott-kelly-spar-twitter-pronoun-use-rcna61309)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2022-12-12 22:57:41+00:00

Elon Musk got into a Twitter spat with former NASA astronaut Scott Kelly on Sunday after the billionaire entrepreneur appeared to take another high-profile

## Chappelle audience members describe Elon Musk being booed off stage: 'more boos than I’d ever heard'
 - [https://www.nbcnews.com/tech/internet/chappelle-elon-musk-dave-video-audience-members-boo-rcna61330](https://www.nbcnews.com/tech/internet/chappelle-elon-musk-dave-video-audience-members-boo-rcna61330)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2022-12-12 22:23:37+00:00

Three audience members who were at Dave Chappelle’s show where Elon Musk was booed off stage say Musk’s characterization of the night wasn’t fully accurate.


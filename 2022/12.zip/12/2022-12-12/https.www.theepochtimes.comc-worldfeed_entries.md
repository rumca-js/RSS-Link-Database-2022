# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## Home Price Rebound Likely: CoreLogic
 - [https://www.theepochtimes.com/home-price-rebound-likely-corelogic_4919758.html](https://www.theepochtimes.com/home-price-rebound-likely-corelogic_4919758.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 23:57:34+00:00

A real estate sign is seen at a property in Sydney, Australia, on Sept. 6, 2022. (Lisa Maree Williams/Getty Images)

## Bank of Canada to Consult Canadians on Digital Currency in 2023, Says Governor
 - [https://www.theepochtimes.com/bank-of-canada-to-consult-canadians-on-digital-currency-in-2023-says-governor_4919773.html](https://www.theepochtimes.com/bank-of-canada-to-consult-canadians-on-digital-currency-in-2023-says-governor_4919773.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 23:52:35+00:00

Bank of Canada Governor Tiff Macklem ponders a question at a press conference in Ottawa on June 9, 2022. (The Canadian Press/ Patrick Doyle)

## Deadly Ambush on Australian Police Leaves 6 Dead, Including 2 Police Officers
 - [https://www.theepochtimes.com/deadly-ambush-on-australian-police-leaves-6-dead-including-2-police-officers_4919656.html](https://www.theepochtimes.com/deadly-ambush-on-australian-police-leaves-6-dead-including-2-police-officers_4919656.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 23:34:10+00:00

A supplied undated combined image obtained Dec.13, 2022 shows Constable Matthew Arnold (left) and Constable Rachel McCrow who were killed in an ambush at a remote Queensland property in Australia. Police have shot dead three people at a remote property on Queensland's Darling Downs after an ambush in which two officers and a bystander were killed. (AAP Image/Supplied by Queensland Police)

## NSW Labor Call for Power Bills Relief For Families
 - [https://www.theepochtimes.com/nsw-labor-call-for-power-bills-relief-for-families_4919725.html](https://www.theepochtimes.com/nsw-labor-call-for-power-bills-relief-for-families_4919725.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 23:10:16+00:00

NSW Labor Leader Chris Minns speaks to the media during a press conference at NSW State Parliament, Sydney, Australia, on June 4, 2021. (AAP Image/Dean Lewins)

## Crown Argues Two Men Planned Murder of BC Resident for Banking Information
 - [https://www.theepochtimes.com/crown-argues-two-men-planned-murder-of-bc-resident-for-banking-information_4919729.html](https://www.theepochtimes.com/crown-argues-two-men-planned-murder-of-bc-resident-for-banking-information_4919729.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 23:07:56+00:00

William Head Institution is shown through a security fence in Victoria, B.C., on Feb. 27, 2008. (Canadian Press/Adrian Lam)

## RCMP Officers Investigating Chinese Influence Visit Non-Profit Group’s Office in BC
 - [https://www.theepochtimes.com/rcmp-officers-investigating-chinese-influence-visit-non-profit-groups-office-in-bc_4919029.html](https://www.theepochtimes.com/rcmp-officers-investigating-chinese-influence-visit-non-profit-groups-office-in-bc_4919029.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 23:04:59+00:00

The RCMP logo is seen outside Royal Canadian Mounted Police "E" Division Headquarters in Surrey, B.C., on April 13, 2018. (Darryl Dyck/The Canadian Press)

## Jamie Dimon Says America Needs a ‘Marshall Plan for Energy’ With More Fossil Fuel Production
 - [https://www.theepochtimes.com/jamie-dimon-says-america-needs-a-marshall-plan-for-energy-with-more-fossil-fuel-production_4918619.html](https://www.theepochtimes.com/jamie-dimon-says-america-needs-a-marshall-plan-for-energy-with-more-fossil-fuel-production_4918619.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 21:21:33+00:00

JPMorgan CEO Jamie Dimon speaks during the Business Roundtable CEO Innovation Summit in Washington, on Dec. 6, 2018. (Jim Waton/AFP via Getty Images)

## ‘Stress Test’ for Homebuyers Should Stay, Says Canada’s Bank Regulator
 - [https://www.theepochtimes.com/stress-test-for-homebuyers-should-stay-says-canadas-bank-regulator_4919184.html](https://www.theepochtimes.com/stress-test-for-homebuyers-should-stay-says-canadas-bank-regulator_4919184.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 21:00:40+00:00

A new home is displayed for sale in Ottawa on July 14, 2020. (Sean Kilpatrick/The Canadian Press)

## Ottawa Police Cut Email Access Over Fears Info Would Leak During Freedom Convoy
 - [https://www.theepochtimes.com/ottawa-police-cut-email-access-over-fears-info-would-leak-during-freedom-convoy_4919355.html](https://www.theepochtimes.com/ottawa-police-cut-email-access-over-fears-info-would-leak-during-freedom-convoy_4919355.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 20:54:34+00:00

A person is led away after leaving his truck as police aim to end an ongoing protest against COVID-19 measures that has grown into a broader anti-government protest, on its 22nd day, in Ottawa, on Feb. 18, 2022. (The Canadian Press/Justin Tang)

## Subsidised Psychology Visits to Be Halved
 - [https://www.theepochtimes.com/subsidised-psychology-visits-to-be-halved_4917966.html](https://www.theepochtimes.com/subsidised-psychology-visits-to-be-halved_4917966.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 20:30:20+00:00

The Medicare logo is seen  in Sydney, Australia, on May 23, 2016. (Brendon Thorne/Getty Images)

## Documents Detail Financial Institution Calls to RCMP on Convoy-Supporting Account Holders
 - [https://www.theepochtimes.com/documents-detail-bank-calls-to-rcmp-on-convoy-supporting-account-holders_4919106.html](https://www.theepochtimes.com/documents-detail-bank-calls-to-rcmp-on-convoy-supporting-account-holders_4919106.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 20:26:13+00:00

Chalk art asking for freedom is seen across the street from Parliament Hill in downtown Ottawa on May 1, 2022. (The Canadian Press/Sean Kilpatrick)

## Business Group Offers $100,000 Reward Over Attack on Coastal GasLink Site
 - [https://www.theepochtimes.com/business-group-offers-100000-reward-over-attack-on-coastal-gaslink-site_4919289.html](https://www.theepochtimes.com/business-group-offers-100000-reward-over-attack-on-coastal-gaslink-site_4919289.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 20:24:48+00:00

Machinery, which police allege were destroyed by protesters, are seen in a Feb. 17, 2022, handout photo. (The Canadian Press/HO-Royal Canadian Mounted Police)

## Violent Crime Involving Firearms Down Five Percent: Statistics Canada
 - [https://www.theepochtimes.com/violent-crime-involving-firearms-down-five-percent-statistics-canada_4919264.html](https://www.theepochtimes.com/violent-crime-involving-firearms-down-five-percent-statistics-canada_4919264.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 20:20:33+00:00

A Walther PDP pistol is seen at the booth of an exhibitor that provides weapons to government, military and law enforcement clients, at the CANSEC trade show in Ottawa, on June 1, 2022. (The Canadian Press/Justin Tang)

## Winnipeg MP and Former Liberal Cabinet Minister Jim Carr Dies After Long Illness
 - [https://www.theepochtimes.com/winnipeg-mp-and-former-liberal-cabinet-minister-jim-carr-dies-after-long-illness_4919244.html](https://www.theepochtimes.com/winnipeg-mp-and-former-liberal-cabinet-minister-jim-carr-dies-after-long-illness_4919244.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 20:05:58+00:00

Jim Carr, a former Liberal cabinet minister, is now the prime minister’s special representative for the Prairie provinces. (The Canadian Press)

## Mendicino to Testify Before Commons Committee on RCMP Contract With China-Linked Company
 - [https://www.theepochtimes.com/mendicino-to-testify-before-commons-committee-on-rcmp-contract-with-china-linked-company_4919018.html](https://www.theepochtimes.com/mendicino-to-testify-before-commons-committee-on-rcmp-contract-with-china-linked-company_4919018.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 19:36:58+00:00

Public Safety Minister Marco Mendicino rises during Question Period in Ottawa on Sept. 29, 2022. (Adrian Wyld/The Canadian Press)

## Some Canadian Institutions Continue to Host China’s Confucius Institute Despite Latest Revelations
 - [https://www.theepochtimes.com/some-canadian-institutions-continue-to-host-chinas-confucius-institute-despite-latest-revelations_4915486.html](https://www.theepochtimes.com/some-canadian-institutions-continue-to-host-chinas-confucius-institute-despite-latest-revelations_4915486.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 19:21:02+00:00

A view of the Confucius Institute building on the Troy University campus in Troy, Alabama, on March 16, 2018. (Kreeder13 via Wikimedia Commons)

## Federal Employees Face Renewed Questions from MPs About Governor General’s $1.3M Middle East Trip
 - [https://www.theepochtimes.com/federal-employees-face-renewed-questions-from-mps-about-governor-generals-1-3m-middle-east-trip_4918872.html](https://www.theepochtimes.com/federal-employees-face-renewed-questions-from-mps-about-governor-generals-1-3m-middle-east-trip_4918872.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 19:04:36+00:00

Governor General Mary Simon speaks during an address at Rideau Hall, in Ottawa on Sept. 8, 2022. (Adrian Wyld/The Canadian Press)

## NATO Chief Issues Warning of Potential for ‘Major War’ With Russia
 - [https://www.theepochtimes.com/nato-chief-issues-warning-of-potential-for-major-war-with-russia_4918829.html](https://www.theepochtimes.com/nato-chief-issues-warning-of-potential-for-major-war-with-russia_4918829.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 18:26:25+00:00

NATO Secretary General Jens Stoltenberg gestures during a news conference at the alliance's headquarters in Brussels on July 5, 2022. (Yves Herman/Reuters)

## Chinese ‘Police Stations’ in Canada Amounts to the Presence of a Hostile Foreign Power in Our Front Yard
 - [https://www.theepochtimes.com/chinese-police-stations-in-canada-amounts-to-the-presence-of-a-hostile-foreign-power-in-our-front-yard_4918299.html](https://www.theepochtimes.com/chinese-police-stations-in-canada-amounts-to-the-presence-of-a-hostile-foreign-power-in-our-front-yard_4918299.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 18:14:12+00:00

A Chinese state-media outlet lists this single-storey commercial building in Markham, Ont., as one of the overseas Chinese police stations in Canada.  (Michelle Hu/The Epoch Times)

## Statistics Canada Says Household Debt-to-Income Ratio Climbed Higher in Third Quarter
 - [https://www.theepochtimes.com/statistics-canada-says-household-debt-to-income-ratio-climbed-higher-in-third-quarter_4918884.html](https://www.theepochtimes.com/statistics-canada-says-household-debt-to-income-ratio-climbed-higher-in-third-quarter_4918884.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 18:02:06+00:00

Statistics Canada building and signs are pictured in Ottawa in a file photo. (The Canadian Press/Sean Kilpatrick)

## 3 Boys Killed After Falling Through Ice Into Lake Near Birmingham as Cold Snap Grips UK
 - [https://www.theepochtimes.com/3-boys-killed-after-falling-through-ice-into-lake-near-birmingham-as-cold-snap-grips-uk_4918567.html](https://www.theepochtimes.com/3-boys-killed-after-falling-through-ice-into-lake-near-birmingham-as-cold-snap-grips-uk_4918567.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 17:51:29+00:00

Police officers scour the lake, where three boys died, at Babbs Mill Park in Birmingham, England, on Dec. 12, 2022. (PA)

## 8 Pakistanis, 1 Afghan Soldier Killed in Cross-Border Clash
 - [https://www.theepochtimes.com/8-pakistanis-1-afghan-soldier-killed-in-cross-border-clash_4918229.html](https://www.theepochtimes.com/8-pakistanis-1-afghan-soldier-killed-in-cross-border-clash_4918229.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 17:22:12+00:00

People at the scene of a cross-border shelling between Afghanistan and Pakistan in this image taken from video on Dec. 11, 2022. (Reuters/Screenshot via The Epoch Times)

## Ex-Sinn Fein Councillor Says Irish Gangster Asked for Dissident Republican Help to End Underworld Feud
 - [https://www.theepochtimes.com/ex-sinn-fein-councillor-says-irish-gangster-asked-for-dissident-republican-help-to-end-underworld-feud_4918241.html](https://www.theepochtimes.com/ex-sinn-fein-councillor-says-irish-gangster-asked-for-dissident-republican-help-to-end-underworld-feud_4918241.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 17:16:33+00:00

An artist's sketch of the scene as Jonathan Dowdall (centre, by microphone) gives evidence against Gerry Hutch (seated third from left) at a murder trial at the Special Criminal Court in Dublin, Republic of Ireland, on Dec. 12, 2022. (Elizabeth Cook/PA)

## Peru President Proposes Moving up Elections Amid Protests
 - [https://www.theepochtimes.com/peru-president-proposes-moving-up-elections-amid-protests_4918044.html](https://www.theepochtimes.com/peru-president-proposes-moving-up-elections-amid-protests_4918044.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 16:43:13+00:00

Tear gas is returned to police trying to break up supporters of ousted President Pedro Castillo at plaza San Martin in Lima, Peru on Dec. 11, 2022. (Martin Mejia/AP Photo)

## Zelenskyy Praises US for ‘Unprecedented’ Support After Pentagon Authorizes Additional $275 Million in Aid
 - [https://www.theepochtimes.com/zelensky-praises-us-for-unprecedented-support-after-pentagon-authorizes-additional-275-million-in-aid_4918423.html](https://www.theepochtimes.com/zelensky-praises-us-for-unprecedented-support-after-pentagon-authorizes-additional-275-million-in-aid_4918423.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 16:15:09+00:00

Ukrainian President Volodymyr Zelenskyy during a meeting with the U.S. secretary of state in Kyiv on Sept. 8, 2022. (Genya Savilov/POOL/AFP via Getty Images)

## Countering CCP Military Threat, Japan Establishing Defense in Okinawa
 - [https://www.theepochtimes.com/countering-ccp-military-threat-japan-establishing-defense-in-okinawa_4917818.html](https://www.theepochtimes.com/countering-ccp-military-threat-japan-establishing-defense-in-okinawa_4917818.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 15:54:19+00:00

Members of the Japan Ground Self-Defense Force (JGSDF) take  the Japanese national flag down in the early evening at JGSDF Miyako camp on Miyako Island, Okinawa prefecture, Japan, on  April 20, 2022. (Issei Kato/Reuters)

## Fire Engulfs Another Moscow Mall, 2nd Such Fire in 4 Days
 - [https://www.theepochtimes.com/fire-engulfs-another-moscow-mall-2nd-such-fire-in-4-days_4918274.html](https://www.theepochtimes.com/fire-engulfs-another-moscow-mall-2nd-such-fire-in-4-days_4918274.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 15:36:34+00:00

Smoke rises from the mall in Balashikha, just outside Moscow on Dec. 12, 2022. (Russian Emergency Ministry Press Service via AP)

## NDP Leader Requests Emergency Debate on Urgent Situation in Children’s Health Care
 - [https://www.theepochtimes.com/ndp-leader-requests-emergency-debate-on-urgent-situation-in-childrens-health-care_4918462.html](https://www.theepochtimes.com/ndp-leader-requests-emergency-debate-on-urgent-situation-in-childrens-health-care_4918462.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 15:17:30+00:00

NDP leader Jagmeet Singh speaks to reporters on Parliament Hill in Ottawa on Dec. 7, 2022. (The Canadian Press/Sean Kilpatrick)

## ‘Tough Road Ahead’ for UK Economy Despite October Rebound, Chancellor Warns
 - [https://www.theepochtimes.com/tough-road-ahead-for-uk-economy-despite-october-rebound-chancellor-warns_4918314.html](https://www.theepochtimes.com/tough-road-ahead-for-uk-economy-despite-october-rebound-chancellor-warns_4918314.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 15:15:31+00:00

Chancellor of the Exchequer Jeremy Hunt, leaves Downing Street following the first Cabinet meeting with Rishi Sunak as prime minister, in London on Oct. 26, 2022. (Victoria Jones/PA)

## Messi, Modric Carry Argentina, Croatia Into World Cup Semis
 - [https://www.theepochtimes.com/messi-modric-carry-argentina-croatia-into-world-cup-semis_4918117.html](https://www.theepochtimes.com/messi-modric-carry-argentina-croatia-into-world-cup-semis_4918117.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 15:10:30+00:00

Argentina's Lionel Messi celebrates after scoring Argentina's second goal during the World Cup quarterfinal soccer match between the Netherlands and Argentina, at the Lusail Stadium in Lusail, Qatar, on Dec. 9, 2022. (Francisco Seco/AP Photo)

## EU Could Face Gas Shortage Next Year, IEA Warns
 - [https://www.theepochtimes.com/eu-could-face-gas-shortage-next-year-iea-warns_4918331.html](https://www.theepochtimes.com/eu-could-face-gas-shortage-next-year-iea-warns_4918331.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 14:58:47+00:00

The President of the European Commission Ursula von der Leyen gives a press conference on REPowerEU: outlook on EU gas supply in 2023, at the European Council Building in Brussels on Dec. 12, 2022. (John Thys/AFP via Getty Images)

## Canada Among Worst of G7 Countries for Lagging in Publishing Public Spending Accounts: PBO
 - [https://www.theepochtimes.com/canada-among-worst-of-g7-countries-for-lagging-in-publishing-public-spending-accounts-pbo_4918290.html](https://www.theepochtimes.com/canada-among-worst-of-g7-countries-for-lagging-in-publishing-public-spending-accounts-pbo_4918290.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 14:39:56+00:00

Parliamentary Budget Officer Yves Giroux prepares to appear before the Senate Committee on Official Languages in Ottawa on June 13, 2022. (Justin Tang/The Canadian Press)

## Taiwan Considers Filing WTO Complaint Against China’s ‘Unfair’ Import Bans: Premier
 - [https://www.theepochtimes.com/taiwan-considers-filing-wto-complaint-against-chinas-unfair-import-bans-premier_4918070.html](https://www.theepochtimes.com/taiwan-considers-filing-wto-complaint-against-chinas-unfair-import-bans-premier_4918070.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 14:31:56+00:00

Taiwan's Premier Su Tseng-chang speaks during a session on the crisis between Russia and Ukraine, at the parliament in Taipei, Taiwan, on March 1, 2022. (Sam Yeh/AFP via Getty Images)

## Trump Says He Rejected Deal Swapping ‘Merchant of Death’ for Former Marine Paul Whelan
 - [https://www.theepochtimes.com/trump-says-he-rejected-deal-swapping-merchant-of-death-for-former-marine-paul-whelan_4918132.html](https://www.theepochtimes.com/trump-says-he-rejected-deal-swapping-merchant-of-death-for-former-marine-paul-whelan_4918132.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 14:30:45+00:00

Former President Donald Trump speaks at the Mar-a-Lago Club in Palm Beach, Florida, on Nov. 15, 2022. (Alon SkuyAFP via Getty Images)

## Anthony Furey: The Real Problem With Canada’s RCMP-China Contract
 - [https://www.theepochtimes.com/anthony-furey-the-real-problem-with-canadas-rcmp-china-contract_4917097.html](https://www.theepochtimes.com/anthony-furey-the-real-problem-with-canadas-rcmp-china-contract_4917097.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 14:27:15+00:00

A police officer stands guard outside the Great Hall of the People in Beijing, China, on March 10, 2022. (Kevin Frayer/Getty Images)

## Murderer Russell Causley Is 1st Prisoner to Face UK Parole Hearing in Public
 - [https://www.theepochtimes.com/murderer-russell-causley-is-1st-prisoner-to-face-uk-parole-hearing-in-public_4918088.html](https://www.theepochtimes.com/murderer-russell-causley-is-1st-prisoner-to-face-uk-parole-hearing-in-public_4918088.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 12:43:57+00:00

Undated family handout photo of Russell Causley with his wife Carole, who he was convicted of murdering in 1985, and daughter Samantha at their home in Bournemouth, Dorset, England. (Family/PA)

## Sam Bankman-Fried Reveals Plans to Launch New Business After FTX Collapse
 - [https://www.theepochtimes.com/sam-bankman-fried-reveals-plans-to-launch-new-business-after-ftx-collapse_4918078.html](https://www.theepochtimes.com/sam-bankman-fried-reveals-plans-to-launch-new-business-after-ftx-collapse_4918078.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 12:26:59+00:00

Then-CEO of FTX Sam Bankman-Fried testifies during a hearing before the House Financial Services Committee on Capitol Hill, in Washington, on Dec. 8, 2021. (Alex Wong/Getty Images)

## US to Invite Russia to Attend 2023 APEC Meetings in San Francisco: State Department
 - [https://www.theepochtimes.com/us-to-invite-russia-to-attend-2023-apec-meetings-in-san-francisco-state-department_4918050.html](https://www.theepochtimes.com/us-to-invite-russia-to-attend-2023-apec-meetings-in-san-francisco-state-department_4918050.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 11:55:24+00:00

Russian and U.S. flags before talks between Russian Deputy Foreign Minister Sergei Ryabkov and U.S. Deputy Secretary of State Wendy Sherman at the U.S. Mission in Geneva, Switzerland, on Jan. 10, 2022. (Denis Balibouse/Reuters)

## Four Children Critical After Plunging Into Birmingham Frozen Lake, Search Continues
 - [https://www.theepochtimes.com/four-children-critical-after-plunging-into-birmingham-frozen-lake-search-continues_4918084.html](https://www.theepochtimes.com/four-children-critical-after-plunging-into-birmingham-frozen-lake-search-continues_4918084.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 10:39:10+00:00

Emergency personnel at the scene in Solihull, England after several children fell into a frozen lake on Dec. 11, 2022. (Jacob King/PA)

## National Grid Asks Two Coal Plants to Fire up Amid Britain’s Big Freeze
 - [https://www.theepochtimes.com/national-grid-asks-two-coal-plants-to-fire-up-amid-britains-big-freeze_4918075.html](https://www.theepochtimes.com/national-grid-asks-two-coal-plants-to-fire-up-amid-britains-big-freeze_4918075.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 10:31:49+00:00

Drax Power Station, the largest in the UK, is pictured in Selby, England on March 02, 2020. (Christopher Furlong/Getty Images)

## In Rare Move, Health Body of Chinese City Publicly Criticizes ‘Zero-COVID’
 - [https://www.theepochtimes.com/in-rare-move-health-body-of-chinese-city-publicly-criticizes-zero-covid_4917656.html](https://www.theepochtimes.com/in-rare-move-health-body-of-chinese-city-publicly-criticizes-zero-covid_4917656.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 08:17:35+00:00

Residents queue to undergo nucleic acid tests for COVID-19 in Anyang in central China's Henan Province on Jan. 26, 2022. (STR/AFP via Getty Images)

## New Zealand Imposes Travel Bans on 22 Iranian Security Guards
 - [https://www.theepochtimes.com/new-zealand-imposes-travel-bans-on-22-iranian-security-guards_4917931.html](https://www.theepochtimes.com/new-zealand-imposes-travel-bans-on-22-iranian-security-guards_4917931.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 07:23:12+00:00

New Zealand’s Prime Minister Jacinda Ardern makes a statement on North Korea’s missile launch during the 2022 APEC meeting in Bangkok, Thailand, on Nov. 18, 2022. (AAP Image/POOL/Mick Tsikas)

## 4 Charged Over Alleged EU Corruption, Bribery Campaign by ‘Gulf Country’: Belgian Prosecutor
 - [https://www.theepochtimes.com/4-charged-over-alleged-eu-corruption-bribery-campaign-by-gulf-country-belgian-prosecutor_4917704.html](https://www.theepochtimes.com/4-charged-over-alleged-eu-corruption-bribery-campaign-by-gulf-country-belgian-prosecutor_4917704.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 07:13:48+00:00

Eva Kaili of the Social Democrats party PASOK looks on as the confidence vote takes place in the Greek parliament in Athens, Greece, on Nov. 4, 2011. (Vladimir Rys/Getty Images)

## US Condemns Hong Kong Media Tycoon’s ‘Grossly Unjust’ Jail Sentence
 - [https://www.theepochtimes.com/us-condemns-hong-kong-media-tycoons-grossly-unjust-jail-sentence_4917581.html](https://www.theepochtimes.com/us-condemns-hong-kong-media-tycoons-grossly-unjust-jail-sentence_4917581.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 05:51:41+00:00

Media tycoon Jimmy Lai, founder of Apple Daily, looks on as he leaves the Court of Final Appeal by prison van, in Hong Kong, on Feb. 1, 2021. (Tyrone Siu/Reuters)

## Chinese Surveillance Technology Aids Iranian Regime As Tehran Clamps Down on Protesters
 - [https://www.theepochtimes.com/chinese-surveillance-technology-aids-iranian-regime-as-tehran-clamps-down-on-protesters_4876337.html](https://www.theepochtimes.com/chinese-surveillance-technology-aids-iranian-regime-as-tehran-clamps-down-on-protesters_4876337.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 05:33:57+00:00

Protesters chant slogans during a protest over the death of a woman who was detained by the morality police, in downtown Tehran, Iran, on Sept. 21, 2022. (Obtained by AP)

## PCR Tests No Longer a ‘Surveillance Tool’: Labor Government Hopes to Move Australia Away From ‘COVID Exceptionalism’
 - [https://www.theepochtimes.com/pcr-tests-no-longer-a-surveillance-tool-labor-government-hopes-to-move-australia-away-from-covid-exceptionalism_4917732.html](https://www.theepochtimes.com/pcr-tests-no-longer-a-surveillance-tool-labor-government-hopes-to-move-australia-away-from-covid-exceptionalism_4917732.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 05:11:30+00:00

A health worker carries out a COVID-19 testing at the Merrylands drive-through clinic on Jan. 7, 2021 in Sydney, Australia. (Brook Mitchell/Getty Images)

## Rise in Suicide Deaths in Australia Following COVID-19 Pandemic
 - [https://www.theepochtimes.com/rise-in-suicide-deaths-in-australia-following-covid-19-pandemic_4917792.html](https://www.theepochtimes.com/rise-in-suicide-deaths-in-australia-following-covid-19-pandemic_4917792.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 05:03:44+00:00

In this photo illustration, a teenager in distress poses for a picture in Arlington, Virginia, on June 11, 2021. (Olivier Douliery/AFP via Getty Images)

## Germany: Suspect Dead After Killing Mother, Taking Hostages
 - [https://www.theepochtimes.com/germany-suspect-dead-after-killing-mother-taking-hostages_4916137.html](https://www.theepochtimes.com/germany-suspect-dead-after-killing-mother-taking-hostages_4916137.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 04:59:20+00:00

Police vehicles are parked around a cordoned off area at the Altmarktgalerie during a hostage situation in Dresden, Germany, on Dec. 10, 2022. (Jorg Schurig/dpa via AP)

## Peru’s President Boluarte Names Cabinet Following Castillo Ouster
 - [https://www.theepochtimes.com/perus-president-boluarte-names-cabinet-following-castillo-ouster_4911867.html](https://www.theepochtimes.com/perus-president-boluarte-names-cabinet-following-castillo-ouster_4911867.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 04:59:12+00:00

Peru's President Dina Boluarte, who took office after her predecessor Pedro Castillo was ousted, poses along with her new Cabinet in Lima, Peru December 10, 2022. REUTERS/Sebastian Castaneda

## Greens, Liberal Party Could Scuttle Federal Government Attempts to Control Energy Prices
 - [https://www.theepochtimes.com/greens-liberal-party-could-scuttle-federal-government-attempts-to-control-energy-prices_4917498.html](https://www.theepochtimes.com/greens-liberal-party-could-scuttle-federal-government-attempts-to-control-energy-prices_4917498.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 04:58:41+00:00

Undated photo showing some cash in Sterling with a mobile photo displaying the words "your latest energy bill." (Jacob King/PA Media)

## TC Energy Says Has Not Found Cause of Keystone Oil Pipeline Leak
 - [https://www.theepochtimes.com/tc-energy-says-has-not-found-cause-of-keystone-oil-pipeline-leak_4917791.html](https://www.theepochtimes.com/tc-energy-says-has-not-found-cause-of-keystone-oil-pipeline-leak_4917791.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 03:58:05+00:00

A satellite image from Saturday shows an overview of the crude oil spill along Mill Creek in Kansas following the leak at the Keystone pipeline operated by TC Energy. (Maxar Technologies via Reuters)

## Iran Executes First Known Prisoner Arrested in Protests
 - [https://www.theepochtimes.com/iran-executes-first-known-prisoner-arrested-in-protests_4911946.html](https://www.theepochtimes.com/iran-executes-first-known-prisoner-arrested-in-protests_4911946.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 03:55:35+00:00

This is a locator map for Iran with its capital, Tehran. (AP Photo)

## Alcohol Might Have Played Role in Quebec Crash That Left Man Dead, Police Say
 - [https://www.theepochtimes.com/alcohol-might-have-played-role-in-quebec-crash-that-left-man-dead-police-say_4917785.html](https://www.theepochtimes.com/alcohol-might-have-played-role-in-quebec-crash-that-left-man-dead-police-say_4917785.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 03:48:43+00:00

A Quebec City police badge is seen in Quebec City, Dec. 3, 2021. (The Canadian Press/Jacques Boissinot)

## Ontario Government Reaches Tentative Deal With Ontario Council of Educational Workers
 - [https://www.theepochtimes.com/ontario-government-reaches-tentative-deal-with-ontario-council-of-educational-workers_4917781.html](https://www.theepochtimes.com/ontario-government-reaches-tentative-deal-with-ontario-council-of-educational-workers_4917781.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 03:45:20+00:00

Stephen Lecce, Minister of Education for Ontario makes an announcement on preparations underway for the return to in-person learning during the COVID-19 pandemic in Toronto on Jan. 12, 2022. (The Canadian Press/Nathan Denette)

## Eastern Canada to See ‘Significant’ Snow and Heavy Winds, Environment Canada Says
 - [https://www.theepochtimes.com/eastern-canada-to-see-significant-snow-and-heavy-winds-environment-canada-says_4917779.html](https://www.theepochtimes.com/eastern-canada-to-see-significant-snow-and-heavy-winds-environment-canada-says_4917779.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 03:42:42+00:00

A woman shovels snow away from her car during the first heavy snowfall of the season in Montreal, Canada on Jan. 2, 2021. (Graham Hughes/The Canadian Press)

## Fire in Quebec Suburb Engulfs Apartment Building Leaving Woman in Critical Condition
 - [https://www.theepochtimes.com/fire-in-quebec-suburb-engulfs-apartment-building-leaving-woman-in-critical-condition_4917775.html](https://www.theepochtimes.com/fire-in-quebec-suburb-engulfs-apartment-building-leaving-woman-in-critical-condition_4917775.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 03:39:15+00:00

Rescue personnel search through the icy rubble of fire that destroyed a seniors' residence Friday, Jan. 24, 2014, in L'Isle-Verte, Quebec. (The Canadian Press/Ryan Remiorz)

## Not yet Over the Moon: Here’s What’s on the Horizon for Canadian Space Exploration
 - [https://www.theepochtimes.com/not-yet-over-the-moon-heres-whats-on-the-horizon-for-canadian-space-exploration_4917753.html](https://www.theepochtimes.com/not-yet-over-the-moon-heres-whats-on-the-horizon-for-canadian-space-exploration_4917753.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 03:31:18+00:00

This image released by NASA on Tuesday, July 12, 2022, shows the edge of a nearby, young, star-forming region NGC 3324 in the Carina Nebula. Captured in infrared light by the Near-Infrared Camera (NIRCam) on the James Webb Space Telescope, this image reveals previously obscured areas of star birth, according to NASA. (The Canadian Press/NASA, ESA, CSA, and STScI via AP)

## Who Is to Blame for Australia’s Sliding Education Standards?
 - [https://www.theepochtimes.com/who-is-to-blame-for-australias-sliding-education-standards_4917573.html](https://www.theepochtimes.com/who-is-to-blame-for-australias-sliding-education-standards_4917573.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 03:18:35+00:00

Year 12 students pose for a media opportunity following their first HSC exam at Sydney Secondary College in Sydney, Australia, on Nov. 9, 2021. (AAP Image/Mick Tsikas)

## Budget Bill’s Proposed Tax Reporting Obligations Violate Charter, Solicitor-Client Privilege: Lawyers
 - [https://www.theepochtimes.com/budget-bills-proposed-tax-reporting-obligations-violate-charter-solicitor-client-privilege-lawyers_4917453.html](https://www.theepochtimes.com/budget-bills-proposed-tax-reporting-obligations-violate-charter-solicitor-client-privilege-lawyers_4917453.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 02:09:49+00:00

A sign outside the Canada Revenue Agency building in Ottawa on May 10, 2021. (The Canadian Press/Adrian Wyld)

## Christmas Tree Shortage Stumps Australian Christmas Celebrations
 - [https://www.theepochtimes.com/christmas-tree-shortage-stumps-australian-christmas-celebrations_4904194.html](https://www.theepochtimes.com/christmas-tree-shortage-stumps-australian-christmas-celebrations_4904194.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 02:07:25+00:00

The Martin Place Christmas tree lights up in Sydney, Australia, on Nov. 28, 2020. (Brook Mitchell/Getty Images)

## Saudi Foreign Minister: ‘All Bets Off’ If Iran Gets Nuclear Weapon
 - [https://www.theepochtimes.com/saudi-foreign-minister-all-bets-off-if-iran-gets-nuclear-weapon_4917644.html](https://www.theepochtimes.com/saudi-foreign-minister-all-bets-off-if-iran-gets-nuclear-weapon_4917644.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 01:59:55+00:00

Saudi Minister of Foreign Affairs Prince Faisal bin Farhan Al-Saud attends a news conference at the Arab Gulf Summit in Riyadh, Saudi Arabia, on Dec. 9, 2022. (Ahmed Yosri/Reuters)

## Strong 6.0-Magnitude Earthquake Shakes Southern Mexico
 - [https://www.theepochtimes.com/strong-6-0-magnitude-earthquake-shakes-southern-mexico_4917554.html](https://www.theepochtimes.com/strong-6-0-magnitude-earthquake-shakes-southern-mexico_4917554.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 01:55:45+00:00

People stand outside after a tremor was felt in Mexico City, Mexico, on Dec. 11, 2022. (Raquel Cunha/Reuters)

## China ‘Incredibly Challenging’ on Global Stage: UK Foreign Secretary
 - [https://www.theepochtimes.com/china-incredibly-challenging-on-global-stage-uk-foreign-secretary_4917153.html](https://www.theepochtimes.com/china-incredibly-challenging-on-global-stage-uk-foreign-secretary_4917153.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 01:15:17+00:00

UK Foreign Secretary James Cleverly gives an interview outside BBC Broadcasting House in London, before appearing on the BBC One current affairs programme Sunday with Laura Kuenssberg, on Dec. 11, 2022. (Lucy North/PA Media)

## Australian Governments’ Intervention In Energy Market Does Little to Address Supply Issues: Peak Bodies
 - [https://www.theepochtimes.com/australian-governments-intervention-in-energy-market-does-little-to-address-supply-issues-peak-bodies_4917472.html](https://www.theepochtimes.com/australian-governments-intervention-in-energy-market-does-little-to-address-supply-issues-peak-bodies_4917472.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-12 01:06:43+00:00

China Sinopec's Tianjin terminal receiving its first liquefied natural gas (LNG) cargo from Australia on Feb. 6, 2018. (VCG via Getty Images)


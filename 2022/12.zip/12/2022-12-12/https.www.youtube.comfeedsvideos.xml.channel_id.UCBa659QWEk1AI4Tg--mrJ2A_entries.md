# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The US government is giving out free wasps
 - [https://www.youtube.com/watch?v=vIfC4Aj05Ps](https://www.youtube.com/watch?v=vIfC4Aj05Ps)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-12-12 16:00:21+00:00

The brown marmorated stink bug is an invasive pest. To help deal with its numbers, the Oregon Department of Agriculture is releasing its natural enemy: the tiny samurai wasp. There's a lot of work that goes into it. ▪  Thanks to all the team at the ODA, and to Chris Hedstrom for the macro footage.

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


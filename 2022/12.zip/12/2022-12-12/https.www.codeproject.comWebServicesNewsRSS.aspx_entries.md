# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## A whole new world
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59776](https://www.codeproject.com/script/News/View.aspx?nwid=59776)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00



## Artemis lands successful in Pacific
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59774](https://www.codeproject.com/script/News/View.aspx?nwid=59774)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

"The Moon! Artemis! the great goddess of the splendid past of men! Are you going to tell me she is a dead lump?"

## Artemis lands successful in Pacific
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59775](https://www.codeproject.com/script/News/View.aspx?nwid=59775)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

"The more one reads the more one sees we have to read."

## Deloitte identifies trust as a common theme in its 2023 Tech Trends
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59785](https://www.codeproject.com/script/News/View.aspx?nwid=59785)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

If you trust their advice

## Experiment: The hidden costs of waiting on slow build times
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59787](https://www.codeproject.com/script/News/View.aspx?nwid=59787)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

Another one to leave where your purchasing manager will find it

## FTC sues to block Microsoft's Activision Blizzard merger
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59782](https://www.codeproject.com/script/News/View.aspx?nwid=59782)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

I guess they're big Call of Duty fans (on Playstation)?

## Gartner discovers top trend impacting infrastructure and operations for 2023
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59786](https://www.codeproject.com/script/News/View.aspx?nwid=59786)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

Fresh from their crystal ball

## Google's Dart language soon won't take null for an answer
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59780](https://www.codeproject.com/script/News/View.aspx?nwid=59780)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

Nooooooooooooo!

## How to nail the 'Do you have any questions for me?' part of the interview
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59778](https://www.codeproject.com/script/News/View.aspx?nwid=59778)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

"Who wrote the book of love?" didn't make the cut?

## Physicist says the laws of physics don't actually exist
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59783](https://www.codeproject.com/script/News/View.aspx?nwid=59783)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

'Guidelines of Thermodynamics' just doesn't have the same ring

## Researchers managed to transfer twice the global internet traffic in a single second
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59779](https://www.codeproject.com/script/News/View.aspx?nwid=59779)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

That's my cat video watching planned for

## Results from our .NET and Windows Developer Community Survey
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59781](https://www.codeproject.com/script/News/View.aspx?nwid=59781)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

Just in case you don't have any opinions of your own

## This is what happens to your brain when you're in back-to-back meetings
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59784](https://www.codeproject.com/script/News/View.aspx?nwid=59784)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

"There is no pain, you are receding"

## Windows 11's screenshot tool gets a screen recorder
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59777](https://www.codeproject.com/script/News/View.aspx?nwid=59777)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-12 05:00:00+00:00

Video killed the screenshot star


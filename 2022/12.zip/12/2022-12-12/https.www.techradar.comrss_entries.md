# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Antivirus software can be hijacked to wipe data
 - [https://www.techradar.com/news/antivirus-software-can-be-hijacked-to-wipe-data](https://www.techradar.com/news/antivirus-software-can-be-hijacked-to-wipe-data)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 22:17:34+00:00

Cybersecurity researcher claims to have unearthed a way to "trick" popular antivirus tools into deleting user data.

## There's some really good news if you want to buy a Raspberry Pi
 - [https://www.techradar.com/news/theres-some-really-good-news-if-you-want-to-buy-a-raspberry-pi](https://www.techradar.com/news/theres-some-really-good-news-if-you-want-to-buy-a-raspberry-pi)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 20:57:49+00:00

Raspberry Pi says it hopes to return to pre-pandemic levels in 2023.

## A third of all internet users have been victims of a data breach
 - [https://www.techradar.com/news/a-third-of-all-internet-users-have-been-victims-of-a-data-breach](https://www.techradar.com/news/a-third-of-all-internet-users-have-been-victims-of-a-data-breach)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 19:46:59+00:00

Thales claims huge number of internet users have been data breach victims.

## Whatsapp messages could soon disappear as soon as they're read
 - [https://www.techradar.com/news/whatsapp-messages-could-soon-disappear-as-soon-as-theyre-read](https://www.techradar.com/news/whatsapp-messages-could-soon-disappear-as-soon-as-theyre-read)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 19:28:56+00:00

Currently only available on Android, the upcoming feature will delete text messages after the recipient opens them.

## New attack method can steal offline PC data through walls
 - [https://www.techradar.com/news/new-attack-method-can-steal-offline-pc-data-through-walls](https://www.techradar.com/news/new-attack-method-can-steal-offline-pc-data-through-walls)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 18:13:29+00:00

New concept can reportedly gather data by decoding power supply radiation.

## Marvel's Spider-Man 2 news could be imminent – here's why
 - [https://www.techradar.com/news/marvels-spider-man-2-news-could-be-imminent-heres-why](https://www.techradar.com/news/marvels-spider-man-2-news-could-be-imminent-heres-why)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 17:51:41+00:00

Cryptic tweets and a dedicated PlayStation Store page suggest Marvel’s Spider-Man 2 news could be on the horizon.

## Microsoft Teams is launching a chat feature in Outlook
 - [https://www.techradar.com/news/microsoft-teams-is-launching-a-further-invasion-of-outlook](https://www.techradar.com/news/microsoft-teams-is-launching-a-further-invasion-of-outlook)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 17:05:01+00:00

Outlook users will soon enjoy a Microsoft Teams chat experience.

## C++ just overtook Java as the world's most popular programming language
 - [https://www.techradar.com/news/c-just-overtook-java-as-the-worlds-most-popular-programming-language](https://www.techradar.com/news/c-just-overtook-java-as-the-worlds-most-popular-programming-language)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 16:18:14+00:00

Java falls out of top three, below Python and C, as C++ storms in with a major increase in rankings.

## Activision Blizzard acquisition is 'in the best interest of gamers', says Xbox boss
 - [https://www.techradar.com/news/activision-blizzard-acquisition-is-in-the-best-interest-of-gamers-says-xbox-boss](https://www.techradar.com/news/activision-blizzard-acquisition-is-in-the-best-interest-of-gamers-says-xbox-boss)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 15:24:50+00:00

Xbox boss Phil Spencer has spoken about how Microsoft’s acquisition of Activision Blizzard could benefit players.

## Low-code is becoming more crucial than ever
 - [https://www.techradar.com/news/low-code-is-becoming-more-crucial-than-ever](https://www.techradar.com/news/low-code-is-becoming-more-crucial-than-ever)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 15:03:03+00:00

Low-code got many businesses through the pandemic: Mendix reckons its on the trajectory for huge growth.

## Rackspace warns of phishing risks following ransomware attack
 - [https://www.techradar.com/news/rackspace-warns-of-phishing-risks-following-ransomware-attack](https://www.techradar.com/news/rackspace-warns-of-phishing-risks-following-ransomware-attack)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 14:21:47+00:00

Scammers could be exploiting Rackspace users’ vulnerability following recent ransomware attack.

## Samsung Galaxy S23 Ultra specs revealed almost in full in an official listing
 - [https://www.techradar.com/news/samsung-galaxy-s23-ultra-specs-revealed-almost-in-full-in-an-official-listing](https://www.techradar.com/news/samsung-galaxy-s23-ultra-specs-revealed-almost-in-full-in-an-official-listing)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 14:17:54+00:00

A Chinese certification agency has certified the Samsung Galaxy S23 Ultra, and listed a lot of specs in the process.

## Intel Arc GPUs just got faster – and next-gen graphics cards are on track
 - [https://www.techradar.com/news/intel-arc-gpus-just-got-faster-and-next-gen-graphics-cards-are-on-track](https://www.techradar.com/news/intel-arc-gpus-just-got-faster-and-next-gen-graphics-cards-are-on-track)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 14:15:02+00:00

Recent drivers have been ushering in solid gains, but this latest release is a big leap.

## Feast your ears: Focal’s flagship speakers are now inspired by oysters and chocolate
 - [https://www.techradar.com/news/feast-your-ears-focals-flagship-speakers-are-now-inspired-by-oysters-and-chocolate](https://www.techradar.com/news/feast-your-ears-focals-flagship-speakers-are-now-inspired-by-oysters-and-chocolate)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 12:32:21+00:00

We've been good all year – now all we want for Christmas is a set of Focal’s new oyster-finish Sopra 2 speakers.

## Forspoken release date, trailers, news and rumors
 - [https://www.techradar.com/news/forspoken-release-date-trailers-news-and-rumors](https://www.techradar.com/news/forspoken-release-date-trailers-news-and-rumors)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 12:32:14+00:00

Here's everything we know so far about PS5 exclusive Forspoken.

## New AMD Radeon RX 7000 GPUs could beat Nvidia RTX 4090 sales
 - [https://www.techradar.com/news/new-amd-radeon-rx-7000-gpus-could-beat-nvidia-rtx-4090-sales](https://www.techradar.com/news/new-amd-radeon-rx-7000-gpus-could-beat-nvidia-rtx-4090-sales)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 11:51:22+00:00

AMD RDNA 3 graphics card stock could be plentiful – and might outgun Nvidia’s Lovelace efforts.

## Fortnite is purposely 'highly addictive', claims class-action lawsuit
 - [https://www.techradar.com/news/fortnite-is-purposely-highly-addictive-claims-class-action-lawsuit](https://www.techradar.com/news/fortnite-is-purposely-highly-addictive-claims-class-action-lawsuit)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 11:48:10+00:00

A class-action lawsuit in Canada claims Fortnite is deliberately 'highly addictive.'

## Microsoft has bought a 4% share in the London Stock Exchange
 - [https://www.techradar.com/news/microsoft-has-bought-a-4-share-in-the-london-stock-exchange](https://www.techradar.com/news/microsoft-has-bought-a-4-share-in-the-london-stock-exchange)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 11:15:58+00:00

Partnership with the London Stock Exchange group will bring various Microsoft products, and new market analysis tools, to finance customers.

## Ant-Man 3 might hold the key to a big Kang reveal in the MCU
 - [https://www.techradar.com/news/ant-man-3-might-hold-the-key-to-a-big-kang-reveal-in-the-mcu](https://www.techradar.com/news/ant-man-3-might-hold-the-key-to-a-big-kang-reveal-in-the-mcu)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-12 10:44:12+00:00

We might see other fan-favorite Kang variants appear in the MCU after Ant-Man and the Wasp: Quantumania.


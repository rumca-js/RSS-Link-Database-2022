# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Iran sprzeda Rosji rakiety. Jednak nie chce łamać ograniczeń ONZ
 - [https://www.money.pl/gospodarka/iran-sprzeda-rosji-rakiety-jednak-nie-chce-lamac-ograniczen-onz-6843905391114784a.html](https://www.money.pl/gospodarka/iran-sprzeda-rosji-rakiety-jednak-nie-chce-lamac-ograniczen-onz-6843905391114784a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 20:02:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/99907f35-a4f4-446a-a4e8-da6f458afc57" width="308" /> Iran planuje sprzedać Rosji rakiety balistyczne Fateh-110. Jednak zmodyfikuje ich zasięg poniżej 300 km, aby nie łamać ograniczeń nałożonych przez Radę Bezpieczeństwa ONZ – donosi portal Axios i powołuje się na przedstawicieli izraelskich władz. Wcześniej Teheran miał rozważać sprzedaż rakiet o dalszym zasięgu.

## Strajk na lotniskach w Hiszpanii. Pracownicy domagają się podwyżek
 - [https://www.money.pl/gospodarka/strajk-na-lotniskach-w-hiszpanii-pracownicy-domagaja-sie-podwyzek-6843885350414912a.html](https://www.money.pl/gospodarka/strajk-na-lotniskach-w-hiszpanii-pracownicy-domagaja-sie-podwyzek-6843885350414912a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 18:40:42+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2c055619-45b6-472e-8e41-d8cf68501e45" width="308" /> Pracownicy firmy Aena, operatora lotnisk w Hiszpanii, ogłosili w poniedziałek przeprowadzenie strajku w okresie bożonarodzeniowo-noworocznym. Zgodnie z ich planami protest ma potrwać przez co najmniej sześć dni. Zatrudnieni domagają się kilkuprocentowej podwyżki wynagrodzeń.

## Afera korupcyjna w Parlamencie Europejskim. Jest reakcja przewodniczącej
 - [https://www.money.pl/gospodarka/afera-korupcyjna-w-parlamencie-europejskim-jest-reakcja-przewodniczacej-6843863649241664a.html](https://www.money.pl/gospodarka/afera-korupcyjna-w-parlamencie-europejskim-jest-reakcja-przewodniczacej-6843863649241664a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 17:12:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b3cb0844-9239-45a5-ac6c-3edded5ca8f7" width="308" /> W trakcie otwarcia sesji plenarnej Parlamentu Europejskiego w Strasburgu Roberta Metsola zapowiedziała rozpoczęcie procedury odwołania wiceprzewodniczącej Evy Kaili "w celu ochrony integralności" PE. – Zaatakowano europejską demokrację – oceniła.

## Śnieg w Polsce daje się we znaki. Prawie 170 tys. odbiorców bez prądu
 - [https://www.money.pl/gospodarka/snieg-w-polsce-daje-sie-we-znaki-prawie-170-tys-odbiorcow-bez-pradu-6843854607223360a.html](https://www.money.pl/gospodarka/snieg-w-polsce-daje-sie-we-znaki-prawie-170-tys-odbiorcow-bez-pradu-6843854607223360a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 16:35:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/651080fb-048d-45c6-b4d2-4d9a54b206d3" width="308" /> Intensywne opady śniegu sprawiły, że niemal 170 tys. odbiorców w Polsce jest bez prądu. O problemach raportuje Tauron i PGE Dystrybucja, która dostarcza prąd we wschodniej i środkowej Polsce. Obie spółki w komunikacie prasowym zapewniły, że uszkodzenia były usuwane na bieżąco przez służby techniczne.

## Oto najwyższa emerytura w Polsce. Prezes ZUS podała kwotę
 - [https://www.money.pl/pieniadze/oto-najwyzsza-emerytura-w-polsce-prezes-zus-podala-kwote-6843825418295872a.html](https://www.money.pl/pieniadze/oto-najwyzsza-emerytura-w-polsce-prezes-zus-podala-kwote-6843825418295872a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 15:23:34+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bfa7d0eb-b097-439f-bed8-0891068d2b72" width="308" /> Nieco ponad 1,3 tysiąca złotych brutto wynosi w Polsce minimalna emerytura. Około 2,7 tysiąca złotych to z kolei średnia kwota świadczenia, jaką dostają seniorzy. Są jednak osoby, które mają dużo wyższe, pięciocyfrowe emerytury. Rekordowa kwota to 37 tysięcy złotych - podała prezes ZUS prof. Gertruda Uścińska. Jak tłumaczy ZUS, kluczem do takich pieniędzy jest długi staż pracy.

## Na tę zimę Europa jest gotowa. Wyzwaniem będzie przyszły sezon grzewczy
 - [https://www.money.pl/gospodarka/na-te-zime-europa-jest-gotowa-wyzwaniem-bedzie-przyszly-sezon-grzewczy-6843832806697536a.html](https://www.money.pl/gospodarka/na-te-zime-europa-jest-gotowa-wyzwaniem-bedzie-przyszly-sezon-grzewczy-6843832806697536a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 15:06:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/050d9b07-1911-4168-b0d4-ddffa4165a32" width="308" /> Na nadchodzącą zimę kraje Unii Europejskiej są gotowe dzięki pełnym magazynom gazu. Problem pojawi się w następnym okresie grzewczym, czyli w 2023 r. Jeżeli nie uda się zastąpić rosyjskiego błękitnego paliwa dostawami od innych państw i inwestycjami w OZE, to w trakcie przyszłej zimy Europie może zabraknąć gazu – ostrzega Międzynarodowa Agencja Energetyczna (MAE).

## TVN i TVN7 kończą z wróżkami. Ezoteryka przeniesie się do internetu
 - [https://www.money.pl/gospodarka/tvn-i-tvn7-koncza-z-wrozkami-ezoteryka-przeniesie-sie-do-internetu-6843809016842784a.html](https://www.money.pl/gospodarka/tvn-i-tvn7-koncza-z-wrozkami-ezoteryka-przeniesie-sie-do-internetu-6843809016842784a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 13:30:05+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ce441668-9625-44f3-b89a-75ddc4f6aafe" width="308" /> TVN i TVN7 od kilku tygodni nie nadają już programu "Noc magii". Zastąpiły ją archiwalne programy. Twórcy programu jednak nie zamierzają z niego rezygnować. W swoich mediach społecznościowych zapowiadają, że będzie się ukazywać dalej, tym razem w internecie – podaje portal Wirtualnemedia.pl.

## Renciści i wcześniejsi emeryci mogą dorobić więcej. Od grudnia zmieniły się zasady
 - [https://www.money.pl/pieniadze/rencisci-i-wczesniejsi-emeryci-moga-dorobic-wiecej-od-grudnia-zmienily-sie-zasady-6843769814735392a.html](https://www.money.pl/pieniadze/rencisci-i-wczesniejsi-emeryci-moga-dorobic-wiecej-od-grudnia-zmienily-sie-zasady-6843769814735392a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 10:50:36+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/88fe719d-b74b-424c-a0db-3c5b5407bbca" width="308" /> Osoby, które pobierają świadczenia z ZUS i jednocześnie pracują, a nie osiągnęły jeszcze powszechnego wieku emerytalnego, od grudnia mogą dorobić więcej do budżetu domowego. Niższy, bezpieczny próg limitu zwiększył się o ponad 227 zł brutto.

## Atak zimy w Europie. Oto jak zareagowały ceny gazu
 - [https://www.money.pl/gielda/atak-zimy-w-europie-oto-jak-zareagowaly-ceny-gazu-6843734763240000a.html](https://www.money.pl/gielda/atak-zimy-w-europie-oto-jak-zareagowaly-ceny-gazu-6843734763240000a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 09:25:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bf83a90a-2299-481e-8b24-307239cd57a6" width="308" /> Ceny gazu na holenderskiej giełdzie (TTF) w poniedziałek rano spadły do poziomu 130 euro za MWh. Eksperci podkreślają jednak, że im niższe będą temperatury tej zimy, tym drastyczniejszych możemy spodziewać się wahań cenowych. Tymczasem nad Europę dotarł arktyczny front, a w najbliższych dniach można się spodziewać znacznych spadków temperatury powietrza.

## Czym jest satoshi – ile kosztuje i od czego wzięła się jego nazwa?
 - [https://www.money.pl/gospodarka/czym-jest-satoshi-ile-kosztuje-i-od-czego-wziela-sie-jego-nazwa-6843733037595168a.html](https://www.money.pl/gospodarka/czym-jest-satoshi-ile-kosztuje-i-od-czego-wziela-sie-jego-nazwa-6843733037595168a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 08:20:58+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf124979-0a8e-4216-8c30-374b5ac17e6f" width="308" /> Bitcoin jest najsłynniejszą i najcenniejszą kryptowalutą na świecie. Co ciekawe, nie wiadomo, kto ją stworzył. W sieci z końcem 2008 roku pojawił się manifest Satoshi Nakamoto, który opisuje funkcjonowanie sieci bitcoina z wykorzystaniem łańcucha bloków, czyli technologii blockchain. Imię anonimowego twórcy bitcoina – Satoshiego – zostało wykorzystane do nazwania najmniejszej jednostki, na jaką dzieli się BTC.

## Kursy walut 12.12.2022. Poniedziałkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-12-12-2022-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6843708322290208a.html](https://www.money.pl/pieniadze/kursy-walut-12-12-2022-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6843708322290208a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 06:40:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 12.12.2022. W poniedziałek za jednego dolara (USD) zapłacimy 4.46 zł. Cena jednego funta szterlinga (GBP) to 5.45 zł, a franka szwajcarskiego (CHF) 4.76 zł. Z kolei euro (EUR) możemy zakupić za 4.69 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 12.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-12-12-2022-6843699701234240a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-12-12-2022-6843699701234240a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 06:05:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 12.12.2022. W poniedziałek za jedno euro (EUR) trzeba zapłacić 4.689 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 12.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-12-12-2022-6843699696765504a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-12-12-2022-6843699696765504a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 06:05:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 12.12.2022. W poniedziałek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.4517 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 12.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-12-12-2022-6843699691801152a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-12-12-2022-6843699691801152a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 06:05:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 12.12.2022. W poniedziałek za jednego franka (CHF) trzeba zapłacić 4.7608 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 12.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-12-12-2022-6843699685521984a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-12-12-2022-6843699685521984a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 06:05:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 12.12.2022. W poniedziałek za jednego dolara (USD) trzeba zapłacić 4.4585 zł.

## Premier o emeryturach: trzynastka i czternastka będą utrzymane
 - [https://www.money.pl/emerytury/premier-o-emeryturach-trzynastka-i-czternastka-beda-utrzymane-6843695722461760a.html](https://www.money.pl/emerytury/premier-o-emeryturach-trzynastka-i-czternastka-beda-utrzymane-6843695722461760a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-12 05:49:09+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/013e29ff-a33e-4156-a33e-d7012177b2fb" width="308" /> Premier Mateusz Morawiecki złożył deklarację dotyczącą wypłat dodatkowych emerytur. - Trzynastka i czternastka będą dalej utrzymane. Jeśli będziemy nadal rządzić, wpiszemy 14. emeryturę do ustawy, żeby stała się dodatkiem sformalizowanym - powiedział w rozmowie z "Super Expressem". Jak dodał, na wsparcie emerytów rząd ma wydać łącznie około 70 mld zł.


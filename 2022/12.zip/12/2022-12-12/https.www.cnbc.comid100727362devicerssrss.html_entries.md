# Source:CNBC, URL:https://www.cnbc.com/id/100727362/device/rss/rss.html, language:en-US

## Jim Cramer says three key deals helped the market rally on Monday
 - [https://www.cnbc.com/2022/12/12/jim-cramer-says-three-key-deals-helped-the-market-rally-on-monday.html](https://www.cnbc.com/2022/12/12/jim-cramer-says-three-key-deals-helped-the-market-rally-on-monday.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 23:51:41+00:00

Stocks rose on Monday ahead of the monthly consumer price index report set to release Tuesday and the Federal Reserve’s December meeting.

## Former FTX CEO Sam Bankman-Fried refuses to testify before Senate, committee says
 - [https://www.cnbc.com/2022/12/12/former-ftx-ceo-sam-bankman-fried-refuses-to-testify-by-senate-banking-.html](https://www.cnbc.com/2022/12/12/former-ftx-ceo-sam-bankman-fried-refuses-to-testify-by-senate-banking-.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 22:38:01+00:00

FTX CEO Sam Bankman-Fried refused to testify at a Wednesday hearing in front of the Senate Banking Committee.

## GM, Stellantis rank as worst automakers for fuel efficiency, even amid EV push, EPA says
 - [https://www.cnbc.com/2022/12/12/epa-gm-stellantis-rank-worst-for-fuel-efficiency-even-amid-ev-push.html](https://www.cnbc.com/2022/12/12/epa-gm-stellantis-rank-worst-for-fuel-efficiency-even-amid-ev-push.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 21:54:52+00:00

Both automakers decreased their fuel economy and increased C02 emissions since the 2016 model-year, as did Hyundai Motor, Mazda and Volkswagen.

## Twitter Blue relaunches, now costs $11 per month if you subscribe from an iPhone
 - [https://www.cnbc.com/2022/12/12/twitter-blue-relaunches-with-steeper-price-for-apple-users-.html](https://www.cnbc.com/2022/12/12/twitter-blue-relaunches-with-steeper-price-for-apple-users-.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 21:31:40+00:00

Twitter relaunched its updated Twitter Blue subscription service Monday after the company's new owner Elon Musk pulled and delayed the launch in November.

## Consumer inflation expected to have continued cooling in November but still high
 - [https://www.cnbc.com/2022/12/12/consumer-inflation-expected-to-have-continued-cooling-in-november-but-still-high.html](https://www.cnbc.com/2022/12/12/consumer-inflation-expected-to-have-continued-cooling-in-november-but-still-high.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 21:18:03+00:00

Consumer inflation likely cooled in November, but prices continue to rise at a still high rate, particularly for services.

## Elon Musk is no longer the richest person in the world
 - [https://www.cnbc.com/2022/12/12/elon-musk-is-no-longer-the-richest-person-in-the-world.html](https://www.cnbc.com/2022/12/12/elon-musk-is-no-longer-the-richest-person-in-the-world.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 21:14:11+00:00

Bernard Arnault is now the richest man in the world, dethroning Tesla CEO Elon Musk after a continued decline in Tesla share price, according to Forbes.

## New FTX CEO to tell Congress that bankrupt crypto exchange had an 'utter failure of corporate controls'
 - [https://www.cnbc.com/2022/12/12/new-ftx-ceo-will-testify-about-utter-failure-of-corporate-controls-.html](https://www.cnbc.com/2022/12/12/new-ftx-ceo-will-testify-about-utter-failure-of-corporate-controls-.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 20:16:16+00:00

FTX CEO John J. Ray III plans to testify before the House Financial Services Committee on Tuesday.

## Police in China arrest gang who laundered $1.7 billion via crypto even after Beijing's crackdown
 - [https://www.cnbc.com/2022/12/12/chinese-police-arrest-gang-who-laundered-1point7-billion-via-cryptocurrency.html](https://www.cnbc.com/2022/12/12/chinese-police-arrest-gang-who-laundered-1point7-billion-via-cryptocurrency.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 15:54:24+00:00

Police in China arrested 63 people accused of laundering as much as 12 billion Chinese yuan ($1.7 billion) via cryptocurrency Tether.

## Iran executes second protester after rapid trial as EU plans more sanctions
 - [https://www.cnbc.com/2022/12/12/iran-executes-second-protester-after-rapid-trial-as-eu-plans-more-sanctions-.html](https://www.cnbc.com/2022/12/12/iran-executes-second-protester-after-rapid-trial-as-eu-plans-more-sanctions-.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 15:02:35+00:00

Iran has long held what activists and other governments say are sham trials in order to imprison or execute critics of the state.

## Trust between the West and Russia has been destroyed, NATO chief says
 - [https://www.cnbc.com/2022/12/12/trust-between-the-west-and-russia-has-been-destroyed-nato-chief-says.html](https://www.cnbc.com/2022/12/12/trust-between-the-west-and-russia-has-been-destroyed-nato-chief-says.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 13:34:01+00:00

Russia continues to pound Ukraine's energy infrastructure too with devastating consequences for civilians.

## Elon Musk booed by crowd after Dave Chapelle brings him on stage at comedy gig
 - [https://www.cnbc.com/2022/12/12/elon-musk-booed-by-crowd-at-dave-chapelle-comedy-gig.html](https://www.cnbc.com/2022/12/12/elon-musk-booed-by-crowd-at-dave-chapelle-comedy-gig.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 12:34:38+00:00

Musk's appearance at a Dave Chappelle show in San Francisco was met with a chorus of boos from the crowd.

## Rivian pauses plans to make electric vans in Europe with Mercedes-Benz
 - [https://www.cnbc.com/2022/12/12/rivian-pauses-plans-to-make-electric-vans-in-europe-with-mercedes-benz.html](https://www.cnbc.com/2022/12/12/rivian-pauses-plans-to-make-electric-vans-in-europe-with-mercedes-benz.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 09:42:32+00:00

Rivian said it remains open to exploring future work with Mercedes-Benz "at a more appropriate time."

## Microsoft buys near 4% stake in London Stock Exchange and launches 10-year partnership
 - [https://www.cnbc.com/2022/12/12/microsoft-buys-near-4percent-stake-in-london-stock-exchange-and-launches-10-year-partnership.html](https://www.cnbc.com/2022/12/12/microsoft-buys-near-4percent-stake-in-london-stock-exchange-and-launches-10-year-partnership.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 07:36:59+00:00

U.S. tech giant Microsoft on Monday announced a 10-year partnership with the London Stock Exchange and took a near 4% stake in the U.K. bourse operator.

## Danish bioscience firms Novozymes and Chr. Hansen to merge
 - [https://www.cnbc.com/2022/12/12/danish-bioscience-firms-novozymes-and-chr-hansen-to-merge.html](https://www.cnbc.com/2022/12/12/danish-bioscience-firms-novozymes-and-chr-hansen-to-merge.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 07:36:16+00:00

Novozymes and Chr. Hansen have agreed to merge in a massive deal for the Danish biotech sector.

## Inflation has peaked — but it's not returning to pre-Covid levels in 2023, Mastercard says
 - [https://www.cnbc.com/2022/12/12/inflation-peaked-but-will-remain-above-pre-covid-levels-mastercard.html](https://www.cnbc.com/2022/12/12/inflation-peaked-but-will-remain-above-pre-covid-levels-mastercard.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 06:27:34+00:00

It'll take a few years to return to 2019 levels, said David Mann of the Mastercard Economics Institute.

## Putin's old EU ally Orban is once again aggravating Brussels with knockbacks
 - [https://www.cnbc.com/2022/12/12/putins-old-eu-ally-orban-is-once-again-aggravating-brussels-with-knockbacks.html](https://www.cnbc.com/2022/12/12/putins-old-eu-ally-orban-is-once-again-aggravating-brussels-with-knockbacks.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 06:23:13+00:00

Hungary is blocking new financial support for Ukraine as the country attempts to wrestle free its own EU funds.

## Europe's power crisis has 'very little to do with Putin,' portfolio manager says
 - [https://www.cnbc.com/2022/12/12/europes-power-crisis-has-very-little-to-do-with-putin-ceo.html](https://www.cnbc.com/2022/12/12/europes-power-crisis-has-very-little-to-do-with-putin-ceo.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 06:22:11+00:00

Lekander's comments come at a time of huge disruption within global energy markets following Russia's invasion of Ukraine in February.

## Southeast Asian markets are in for a 'bungee jump' in 2023, says JPMorgan
 - [https://www.cnbc.com/2022/12/12/southeast-asian-markets-are-in-for-a-bungee-jump-says-jpmorgan.html](https://www.cnbc.com/2022/12/12/southeast-asian-markets-are-in-for-a-bungee-jump-says-jpmorgan.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 02:37:18+00:00

The region's markets are likely to plunge before surging in the second half of 2023, according to JPMorgan analysts.

## Cramer: Apple, Amazon, Microsoft and Google will fuel the next rally — but not in the usual way
 - [https://www.cnbc.com/2022/12/11/cramer-apple-amazon-microsoft-and-google-will-fuel-the-next-rally.html](https://www.cnbc.com/2022/12/11/cramer-apple-amazon-microsoft-and-google-will-fuel-the-next-rally.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 01:18:14+00:00

Unlike the trillions that vanished into thin crypto air, the money for the next upswing will come from four stocks with a combined $6 trillion to donate.

## What do hotel 'star' ratings really mean? Here's a breakdown
 - [https://www.cnbc.com/2022/12/11/what-do-hotel-star-ratings-mean-heres-a-breakdown.html](https://www.cnbc.com/2022/12/11/what-do-hotel-star-ratings-mean-heres-a-breakdown.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-12 00:05:10+00:00

One hotel can be rated three, four and even five stars — that's because ratings are "not regulated in a consistent way across the industry," one insider says.


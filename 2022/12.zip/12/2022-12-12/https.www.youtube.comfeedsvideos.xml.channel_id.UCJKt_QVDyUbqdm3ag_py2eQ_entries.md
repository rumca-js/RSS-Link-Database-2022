# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: FireBoy - Refroteen (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=eQv_jkpE6go](https://www.youtube.com/watch?v=eQv_jkpE6go)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-12-13 00:00:00+00:00

"Refroteen" by FireBoy/Obsolet^Crane (Carlos Gimeno Franco), shared 1st place at Posadas 2022.
Art "The Nudge" (1995, unsure) by Made/Scoopex^Bomb. Original art (the male figure at least) by Boris Vallejo (1983).

A lot of samples are from "Intimate with the Firebird" by Darius+Rotteen, found from the following album:
https://halleylabs.com/album/adventures-with-tweesee
Amiga remix even?... you be the judge.

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.


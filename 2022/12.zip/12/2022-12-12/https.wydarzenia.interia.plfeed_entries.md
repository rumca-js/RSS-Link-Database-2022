# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Przywódcy G7 chcą pociągnąć Putina do odpowiedzialności
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przywodcy-g7-chca-pociagnac-putina-do-odpowiedzialnosci,nId,6468678](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przywodcy-g7-chca-pociagnac-putina-do-odpowiedzialnosci,nId,6468678)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 22:30:13+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przywodcy-g7-chca-pociagnac-putina-do-odpowiedzialnosci,nId,6468678"><img align="left" alt="Przywódcy G7 chcą pociągnąć Putina do odpowiedzialności" src="https://i.iplsc.com/przywodcy-g7-chca-pociagnac-putina-do-odpowiedzialnosci/000A7Z5W3U0E1XLA-C321.jpg" /></a>Przywódcy państw grupy G7 ogłosili, że pociągną Władimira Putina do odpowiedzialności za inwazję na Ukrainę. Oświadczenie w tej sprawie zostało wydane w poniedziałek po zakończeniu wirtualnego szczytu z udziałem Wołodymyra Zełenskiego. </p><br clear="all" />

## USA przeprowadziły test pocisku hipersonicznego
 - [https://wydarzenia.interia.pl/zagranica/news-usa-przeprowadzily-test-pocisku-hipersonicznego,nId,6468673](https://wydarzenia.interia.pl/zagranica/news-usa-przeprowadzily-test-pocisku-hipersonicznego,nId,6468673)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 22:01:22+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-przeprowadzily-test-pocisku-hipersonicznego,nId,6468673"><img align="left" alt="USA przeprowadziły test pocisku hipersonicznego " src="https://i.iplsc.com/usa-przeprowadzily-test-pocisku-hipersonicznego/000GH9CQHYGA4RG0-C321.jpg" /></a>Stany Zjednoczone przeprowadziły pierwszą pełną próbę swojego pocisku hipersonicznego AGM-138A ARRW. Jak podały Siły Powietrzne USA, operacja miała zakończyć się osiągnięciem wszystkich zamierzonych celów. </p><br clear="all" />

## Media: Obywatele Rzeszy tworzyli własne oddziały paramilitarne
 - [https://wydarzenia.interia.pl/zagranica/news-media-obywatele-rzeszy-tworzyli-wlasne-oddzialy-paramilitarn,nId,6468668](https://wydarzenia.interia.pl/zagranica/news-media-obywatele-rzeszy-tworzyli-wlasne-oddzialy-paramilitarn,nId,6468668)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 21:33:18+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-media-obywatele-rzeszy-tworzyli-wlasne-oddzialy-paramilitarn,nId,6468668"><img align="left" alt="Media: Obywatele Rzeszy tworzyli własne oddziały paramilitarne" src="https://i.iplsc.com/media-obywatele-rzeszy-tworzyli-wlasne-oddzialy-paramilitarn/000EE0WZ430T3YL6-C321.jpg" /></a>W ubiegłym tygodniu niemiecka policja rozbiła organizację Obywatele Rzeszy. Teraz jak się okazuje, była to struktura bardziej rozbudowana, niż pierwotnie sądzono. &quot;Po zakończeniu specjalnego posiedzenia w Berlinie, członkowie komisji prawnej Bundestagu poinformowali, że domniemani spiskowcy planowali utworzenie ponad 280 oddziałów paramilitarnych (Heimatschutzkompanie)&quot; - podał portal dziennika &quot;Sueddeutsche Zeitung&quot;.</p><br clear="all" />

## Wyjątkowe zdjęcia z zoo. "Zwierzaki polubiły śnieg"
 - [https://wydarzenia.interia.pl/zagranica/news-wyjatkowe-zdjecia-z-zoo-zwierzaki-polubily-snieg,nId,6468662](https://wydarzenia.interia.pl/zagranica/news-wyjatkowe-zdjecia-z-zoo-zwierzaki-polubily-snieg,nId,6468662)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 21:30:52+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wyjatkowe-zdjecia-z-zoo-zwierzaki-polubily-snieg,nId,6468662"><img align="left" alt="Wyjątkowe zdjęcia z zoo. &quot;Zwierzaki polubiły śnieg&quot;" src="https://i.iplsc.com/wyjatkowe-zdjecia-z-zoo-zwierzaki-polubily-snieg/000GH988GEKOQO83-C321.jpg" /></a>Zima zawitała do Londynu. Choć obfite opady białego puchu to poważny kłopot kierowców, to ich skutki stanowią dla zwierząt w stołecznym zoo nie lada atrakcję. Miejscowy ogród zoologiczny pokazał w swoich mediach społecznościowych, jak ich podopieczni spędzili pierwszy śnieżny dzień w tej zimy.</p><br clear="all" />

## Tarnowskie Góry: Nauczyciel miał zamontować kamerę w szkolnej toalecie
 - [https://wydarzenia.interia.pl/slaskie/news-tarnowskie-gory-nauczyciel-mial-zamontowac-kamere-w-szkolnej,nId,6468645](https://wydarzenia.interia.pl/slaskie/news-tarnowskie-gory-nauczyciel-mial-zamontowac-kamere-w-szkolnej,nId,6468645)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 21:03:09+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-tarnowskie-gory-nauczyciel-mial-zamontowac-kamere-w-szkolnej,nId,6468645"><img align="left" alt="Tarnowskie Góry: Nauczyciel miał zamontować kamerę w szkolnej toalecie" src="https://i.iplsc.com/tarnowskie-gory-nauczyciel-mial-zamontowac-kamere-w-szkolnej/000GH90Z1U58NM89-C321.jpg" /></a>Nauczyciel informatyki miał zainstalować w szkolnej toalecie niewielką kamerę. Ukryty w spłuczce sprzęt zauważył, a następnie zdemontował jeden z uczniów. Gdy 37-letni nauczyciel zorientował się kto to zrobił, poszedł do klasy za nastolatkiem, ten jednak nie chciał z nim rozmawiać i zwrócić kamery. Sprawą zajmuje się policja. Szkoła rozwiązała umowę z 37-latkiem.</p><br clear="all" />

## Ukradli beczki z kiszoną kapustą. Wpadli, gdy toczyli je po ulicy
 - [https://wydarzenia.interia.pl/lodzkie/news-ukradli-beczki-z-kiszona-kapusta-wpadli-gdy-toczyli-je-po-ul,nId,6468652](https://wydarzenia.interia.pl/lodzkie/news-ukradli-beczki-z-kiszona-kapusta-wpadli-gdy-toczyli-je-po-ul,nId,6468652)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 20:48:54+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-ukradli-beczki-z-kiszona-kapusta-wpadli-gdy-toczyli-je-po-ul,nId,6468652"><img align="left" alt="Ukradli beczki z kiszoną kapustą. Wpadli, gdy toczyli je po ulicy" src="https://i.iplsc.com/ukradli-beczki-z-kiszona-kapusta-wpadli-gdy-toczyli-je-po-ul/000GH936X64YM88I-C321.jpg" /></a>Trzech mężczyzn toczyło beczki ulicami Tomaszowa Mazowieckiego (woj. łódzkie), kiedy zostali dostrzeżeni na monitoringu przez dyżurnego komendy policji. Po ich zatrzymaniu okazało się, że w pojemnikach jest kiszona kapusta. </p><br clear="all" />

## Ziobro do opozycji: Jedyne, co wam wychodzi, to robienie hucpy
 - [https://wydarzenia.interia.pl/kraj/news-ziobro-do-opozycji-jedyne-co-wam-wychodzi-to-robienie-hucpy,nId,6468641](https://wydarzenia.interia.pl/kraj/news-ziobro-do-opozycji-jedyne-co-wam-wychodzi-to-robienie-hucpy,nId,6468641)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 20:21:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ziobro-do-opozycji-jedyne-co-wam-wychodzi-to-robienie-hucpy,nId,6468641"><img align="left" alt="Ziobro do opozycji: Jedyne, co wam wychodzi, to robienie hucpy" src="https://i.iplsc.com/ziobro-do-opozycji-jedyne-co-wam-wychodzi-to-robienie-hucpy/000EA7NQDWEA7546-C321.jpg" /></a>Jedyne, o co wam wychodzi, to robienie hucpy - powiedział w poniedziałek do posłów opozycji podczas obrad sejmowej komisji minister sprawiedliwości Zbigniew Ziobro. Dodał, że jego polityczni oponenci &quot;nawiązują do najgorszej tradycji związanej z Targowicą&quot;. - Spoceni biegacie po obcych stolicach domagając się wsparcia w ataku na własną ojczyznę. (...) Potem pytacie, gdzie są pieniądze z KPO - mówił. </p><br clear="all" />

## Śmierć Hermaszewskiego. Spędził osiem dni w kosmosie, okrążył Ziemię 126 razy
 - [https://wydarzenia.interia.pl/kraj/news-smierc-hermaszewskiego-spedzil-osiem-dni-w-kosmosie-okrazyl-,nId,6468628](https://wydarzenia.interia.pl/kraj/news-smierc-hermaszewskiego-spedzil-osiem-dni-w-kosmosie-okrazyl-,nId,6468628)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 19:55:49+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-smierc-hermaszewskiego-spedzil-osiem-dni-w-kosmosie-okrazyl-,nId,6468628"><img align="left" alt="Śmierć Hermaszewskiego. Spędził osiem dni w kosmosie, okrążył Ziemię 126 razy" src="https://i.iplsc.com/smierc-hermaszewskiego-spedzil-osiem-dni-w-kosmosie-okrazyl/000GH8WXML5UX741-C321.jpg" /></a>Mirosław Hermaszewski był pierwszym i do dziś pozostaje jedynym Polakiem w kosmosie. Przez lata pracował jako lotnik i piął się w górę po szczeblach kariery wojskowej. W grupie kandydatów na kosmonautę znalazł się w 1976 roku, a jego statek Sojuz 30 wystartował dwa lata później. Jego udział w misji na orbicie nie był jednak przesądzony od samego początku, ponieważ chętnych było kilkuset, a inne państwa bloku wschodniego także zabiegały o angaż swoich obywateli.</p><br clear="all" />

## Ukraiński wywiad: Rosja używa przeciwko nam naszych rakiet
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainski-wywiad-rosja-uzywa-przeciwko-nam-naszych-rakiet,nId,6468627](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainski-wywiad-rosja-uzywa-przeciwko-nam-naszych-rakiet,nId,6468627)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 19:46:42+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainski-wywiad-rosja-uzywa-przeciwko-nam-naszych-rakiet,nId,6468627"><img align="left" alt="Ukraiński wywiad: Rosja używa przeciwko nam naszych rakiet" src="https://i.iplsc.com/ukrainski-wywiad-rosja-uzywa-przeciwko-nam-naszych-rakiet/000ES10BPYQQJIY9-C321.jpg" /></a>Rosja używa przeciwko nam ukraińskich rakiet, które przekazaliśmy jej w ramach porozumienia z 1990 roku, znanego jako Memorandum Budapesztańskie - powiedział zastępca ukraińskiego wywiadu wojskowego (HUR) Wadym Skibicki w wywiadzie opublikowanym w poniedziałek przez &quot;New York Times&quot;. Przypomniał też, że w ramach tego porozumienia Moskwa miała zapewnić Ukrainie bezpieczeństwo, suwerenność i integralność terytorialną.</p><br clear="all" />

## Marija Zacharowa czytała rosyjski wiersz. Nie potrafiła ukryć łez
 - [https://wydarzenia.interia.pl/zagranica/news-marija-zacharowa-czytala-rosyjski-wiersz-nie-potrafila-ukryc,nId,6468601](https://wydarzenia.interia.pl/zagranica/news-marija-zacharowa-czytala-rosyjski-wiersz-nie-potrafila-ukryc,nId,6468601)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 19:23:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-marija-zacharowa-czytala-rosyjski-wiersz-nie-potrafila-ukryc,nId,6468601"><img align="left" alt="Marija Zacharowa czytała rosyjski wiersz. Nie potrafiła ukryć łez" src="https://i.iplsc.com/marija-zacharowa-czytala-rosyjski-wiersz-nie-potrafila-ukryc/000GH8S613A78HTM-C321.jpg" /></a>Marija Zacharowa nie mogła powstrzymać łez, czytając wiersz o rosyjskich żołnierzach, co zostało uwiecznione przez kamery. Największe wzruszenie rzeczniczki rosyjskiego resortu dyplomacji wywołał wers o &quot;batalionie pełznącym na zachód&quot;.</p><br clear="all" />

## Nie żyje gen. Mirosław Hermaszewski
 - [https://wydarzenia.interia.pl/kraj/news-nie-zyje-gen-miroslaw-hermaszewski,nId,6468610](https://wydarzenia.interia.pl/kraj/news-nie-zyje-gen-miroslaw-hermaszewski,nId,6468610)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 19:15:14+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nie-zyje-gen-miroslaw-hermaszewski,nId,6468610"><img align="left" alt="Nie żyje gen. Mirosław Hermaszewski" src="https://i.iplsc.com/nie-zyje-gen-miroslaw-hermaszewski/000GH8T4U8J3RO2B-C321.jpg" /></a>Nie żyje generał Mirosław Hermaszewski, zmarł w wieku 81 lat w jednym z warszawskich szpitali.</p><br clear="all" />

## Premier Ukrainy Denys Szmyhal: Potrzebujemy systemów Mamba
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-ukrainy-denys-szmyhal-potrzebujemy-systemow-mamba,nId,6468607](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-ukrainy-denys-szmyhal-potrzebujemy-systemow-mamba,nId,6468607)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 19:10:45+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-premier-ukrainy-denys-szmyhal-potrzebujemy-systemow-mamba,nId,6468607"><img align="left" alt="Premier Ukrainy Denys Szmyhal: Potrzebujemy systemów Mamba" src="https://i.iplsc.com/premier-ukrainy-denys-szmyhal-potrzebujemy-systemow-mamba/000GH8VAQ92LR33A-C321.jpg" /></a>Liczymy na otrzymanie francuskiego systemu Mamba, który pomoże nam w walce z irańskimi dronami i rosyjskimi rakietami - powiedział premier Ukrainy Denys Szmyhal w wywiadzie udzielonym francuskiej telewizji LCI-TF1. Dodał, że Ukraina prosi również o czołgi w standardzie NATO. Wymienił amerykańskie Abramsy i niemieckie Leopardy.</p><br clear="all" />

## Abp Jędraszewski tuszował molestowanie kapelana? Śledztwo umorzone
 - [https://wydarzenia.interia.pl/kraj/news-abp-jedraszewski-tuszowal-molestowanie-kapelana-sledztwo-umo,nId,6468597](https://wydarzenia.interia.pl/kraj/news-abp-jedraszewski-tuszowal-molestowanie-kapelana-sledztwo-umo,nId,6468597)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 19:07:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-abp-jedraszewski-tuszowal-molestowanie-kapelana-sledztwo-umo,nId,6468597"><img align="left" alt="Abp Jędraszewski tuszował molestowanie kapelana? Śledztwo umorzone" src="https://i.iplsc.com/abp-jedraszewski-tuszowal-molestowanie-kapelana-sledztwo-umo/000FQ2M0EN6TNT7K-C321.jpg" /></a>Prokuratura Okręgowa w Krakowie po prawie 1,5-rocznym śledztwie stwierdziła, że abp Marek Jędraszewski nie tuszował przestępstwa wykorzystywania seksualnego jednego z krakowskich księży - podał w poniedziałek Onet. Postępowanie dotyczyło sprawy szpitalnego kapelana, który molestował pacjentkę oddziału geriatrycznego. </p><br clear="all" />

## Nestle zainwestuje 40 mln franków w Ukrainie. Praca dla 7 tys. osób
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nestle-zainwestuje-40-mln-frankow-w-ukrainie-praca-dla-7-tys,nId,6468599](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nestle-zainwestuje-40-mln-frankow-w-ukrainie-praca-dla-7-tys,nId,6468599)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 18:48:22+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nestle-zainwestuje-40-mln-frankow-w-ukrainie-praca-dla-7-tys,nId,6468599"><img align="left" alt="Nestle zainwestuje 40 mln franków w Ukrainie. Praca dla 7 tys. osób" src="https://i.iplsc.com/nestle-zainwestuje-40-mln-frankow-w-ukrainie-praca-dla-7-tys/000GH8P315LK3PCJ-C321.jpg" /></a>Szwajcarski koncern spożywczy Nestle poinformował w poniedziałek, że zainwestuje 40 mln franków szwajcarskich w nową fabrykę na Ukrainie. - Chcemy zapewnić nowe miejsca pracy i służyć potrzebom Ukraińców i wszystkich obywateli Europy - powiedział szef firmy na Wschodnią Europę Alessandro Zanelli. W pierwszych miesiącach wojny Nestle mierzyło się z silną presją społeczną, a nawet atakiem hakerskim grupy Annymous w związku z decyzją o niewycofaniu się z Rosji po inwazji na Ukrainę. </p><br clear="all" />

## Cezary Tomczyk: Składamy wniosek o zdymisjonowanie wiceministrów SP
 - [https://wydarzenia.interia.pl/kraj/news-cezary-tomczyk-skladamy-wniosek-o-zdymisjonowanie-wiceminist,nId,6468576](https://wydarzenia.interia.pl/kraj/news-cezary-tomczyk-skladamy-wniosek-o-zdymisjonowanie-wiceminist,nId,6468576)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 18:11:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-cezary-tomczyk-skladamy-wniosek-o-zdymisjonowanie-wiceminist,nId,6468576"><img align="left" alt="Cezary Tomczyk: Składamy wniosek o zdymisjonowanie wiceministrów SP" src="https://i.iplsc.com/cezary-tomczyk-skladamy-wniosek-o-zdymisjonowanie-wiceminist/000GH8J3PAE38X1C-C321.jpg" /></a>&quot;Dziś składamy wniosek do premiera Mateusza Morawieckiego o zdymisjonowanie wszystkich wiceministrów Solidarnej Polski&quot; - poinformował na Twitterze wiceprzewodniczący Platformy Obywatelskiej Cezary Tomczyk. Nawiązał do wiceministra klimatu i środowiska Jacka Ozdoby, który - jak ocenił Tomczyk - stracił kompetencje, po czym &quot;dostaje prawie 15 tys. zł za nic&quot;. &quot;To skrajna patologia&quot; - napisał poseł Tomczyk.</p><br clear="all" />

## Zełenski: Kiedy wygramy, chciałbym pojechać nad morze i napić się piwa
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-kiedy-wygramy-chcialbym-pojechac-nad-morze-i-napic-,nId,6468481](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-kiedy-wygramy-chcialbym-pojechac-nad-morze-i-napic-,nId,6468481)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 17:50:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-kiedy-wygramy-chcialbym-pojechac-nad-morze-i-napic-,nId,6468481"><img align="left" alt="Zełenski: Kiedy wygramy, chciałbym pojechać nad morze i napić się piwa" src="https://i.iplsc.com/zelenski-kiedy-wygramy-chcialbym-pojechac-nad-morze-i-napic/000GH8G8SUY89ME6-C321.jpg" /></a>Będę prezydentem Ukrainy dopóki nie zwyciężymy, a potem - nie wiem. Chętnie pojechałbym nad morze i napił się piwa - powiedział ukraiński przywódca Wołodymyr Zełenski w wywiadzie amerykańskiego dziennikarza Davida Lettermana na Netflixie. Prezydent dodał, że jego zdaniem wojna skończy się wtedy, kiedy Władimir Putin umrze.</p><br clear="all" />

## Tunel na zakopiance. Prawie trzy tysiące przekroczeń prędkości w ciągu miesiąca
 - [https://wydarzenia.interia.pl/malopolskie/news-tunel-na-zakopiance-prawie-trzy-tysiace-przekroczen-predkosc,nId,6468572](https://wydarzenia.interia.pl/malopolskie/news-tunel-na-zakopiance-prawie-trzy-tysiace-przekroczen-predkosc,nId,6468572)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 17:44:21+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-tunel-na-zakopiance-prawie-trzy-tysiace-przekroczen-predkosc,nId,6468572"><img align="left" alt="Tunel na zakopiance. Prawie trzy tysiące przekroczeń prędkości w ciągu miesiąca" src="https://i.iplsc.com/tunel-na-zakopiance-prawie-trzy-tysiace-przekroczen-predkosc/000GH8MEGQCIJ69S-C321.jpg" /></a>Do niemal trzech tysięcy przypadków przekroczenia dozwolonej prędkości doszło w tunelu na zakopiance, do znaczącej większości z nich na nitce w kierunku Krakowa. Jak także przekazał Główny Inspektorat Transportu Drogowego (GITD), przy ograniczeniu do 100 km/h, rekordzista osiągnął prędkość 201 km/h. Od otwarcia tunelu pomiędzy Naprawą a Skomielną Białą minął miesiąc.</p><br clear="all" />

## Przyszedł do sklepu po piwo i papierosy. Zamiast pieniędzy miał tasak
 - [https://wydarzenia.interia.pl/lubelskie/news-przyszedl-do-sklepu-po-piwo-i-papierosy-zamiast-pieniedzy-mi,nId,6468570](https://wydarzenia.interia.pl/lubelskie/news-przyszedl-do-sklepu-po-piwo-i-papierosy-zamiast-pieniedzy-mi,nId,6468570)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 17:38:49+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-przyszedl-do-sklepu-po-piwo-i-papierosy-zamiast-pieniedzy-mi,nId,6468570"><img align="left" alt="Przyszedł do sklepu po piwo i papierosy. Zamiast pieniędzy miał tasak " src="https://i.iplsc.com/przyszedl-do-sklepu-po-piwo-i-papierosy-zamiast-pieniedzy-mi/000GH8EQ0S2WC001-C321.jpg" /></a>Mężczyzna z tasakiem pojawił się w jednym ze sklepów w Lublinie. Zastraszył ekspedientkę i wyszedł z pięcioma piwami. Później wrócił jeszcze po papierosy. Policjanci szybko go złapali. Okazało się, że 29-latek jest recydywistą. </p><br clear="all" />

## Opisał na Instagramie sen o Zełenskim. Rosjanin trafił przed sąd
 - [https://wydarzenia.interia.pl/zagranica/news-opisal-na-instagramie-sen-o-zelenskim-rosjanin-trafil-przed-,nId,6468391](https://wydarzenia.interia.pl/zagranica/news-opisal-na-instagramie-sen-o-zelenskim-rosjanin-trafil-przed-,nId,6468391)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 17:02:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-opisal-na-instagramie-sen-o-zelenskim-rosjanin-trafil-przed-,nId,6468391"><img align="left" alt="Opisał na Instagramie sen o Zełenskim. Rosjanin trafił przed sąd" src="https://i.iplsc.com/opisal-na-instagramie-sen-o-zelenskim-rosjanin-trafil-przed/000GH7TQC7W09D14-C321.jpg" /></a>Iwan Łosew, 26-letni Rosjanin opisał na Instagramie swój sen, którego bohaterem był prezydent Ukrainy Wołodymyr Zełenski. Okazało się, że jego konto obserwowali agenci FSB. W konsekwencji trafił przed sąd i został ukarany grzywną. </p><br clear="all" />

## Rosyjski samolot miał wlecieć w polską przestrzeń. Służby dementują
 - [https://wydarzenia.interia.pl/zagranica/news-rosyjski-samolot-mial-wleciec-w-polska-przestrzen-sluzby-dem,nId,6468385](https://wydarzenia.interia.pl/zagranica/news-rosyjski-samolot-mial-wleciec-w-polska-przestrzen-sluzby-dem,nId,6468385)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 16:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosyjski-samolot-mial-wleciec-w-polska-przestrzen-sluzby-dem,nId,6468385"><img align="left" alt="Rosyjski samolot miał wlecieć w polską przestrzeń. Służby dementują" src="https://i.iplsc.com/rosyjski-samolot-mial-wleciec-w-polska-przestrzen-sluzby-dem/000GH7R1EXK1G7LD-C321.jpg" /></a>Rosyjski samolot pasażerski długo krążył Kaliningradem, a następnie miał wlecieć w polską przestrzeń powietrzną, gdzie wykonał manewr zawracania - tak wynika z zapisu trasy lotu maszyny na Flightradar24. Według rosyjskich mediów jej problemy wynikały z trudnych warunków na kaliningradzkim lotnisku Chrabrowo. Jak się jednak okazuje, wskazania Flightradar24 mogą być mylące. - Nie zarejestrowaliśmy takiego lotu nad Polską - mówi Interii rzeczniczka PAŻP.</p><br clear="all" />

## Rosyjski samolot wleciał w polską przestrzeń. "To wina pogody"
 - [https://wydarzenia.interia.pl/zagranica/news-rosyjski-samolot-wlecial-w-polska-przestrzen-to-wina-pogody,nId,6468385](https://wydarzenia.interia.pl/zagranica/news-rosyjski-samolot-wlecial-w-polska-przestrzen-to-wina-pogody,nId,6468385)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 16:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosyjski-samolot-wlecial-w-polska-przestrzen-to-wina-pogody,nId,6468385"><img align="left" alt="Rosyjski samolot wleciał w polską przestrzeń. &quot;To wina pogody&quot;" src="https://i.iplsc.com/rosyjski-samolot-wlecial-w-polska-przestrzen-to-wina-pogody/000GH7R1EXK1G7LD-C321.jpg" /></a>Rosyjski samolot pasażerski wleciał rano w polską przestrzeń powietrzną, gdzie wykonał manewr zawracania. Według rosyjskich mediów, to skutek trudnych warunków pogodowych, jakie panowały na kaliningradzkim lotnisku Chrabrowo. Obfite opady śniegu wymusiły przekierowanie wielu samolotów na lotnisko zastępcze w Petersburgu.</p><br clear="all" />

## Obrady klubu parlamentarnego PiS. Na Nowogrodzkiej Kaczyński i Morawiecki
 - [https://wydarzenia.interia.pl/kraj/news-obrady-klubu-parlamentarnego-pis-na-nowogrodzkiej-kaczynski-,nId,6468359](https://wydarzenia.interia.pl/kraj/news-obrady-klubu-parlamentarnego-pis-na-nowogrodzkiej-kaczynski-,nId,6468359)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 16:08:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-obrady-klubu-parlamentarnego-pis-na-nowogrodzkiej-kaczynski-,nId,6468359"><img align="left" alt="Obrady klubu parlamentarnego PiS. Na Nowogrodzkiej Kaczyński i Morawiecki" src="https://i.iplsc.com/obrady-klubu-parlamentarnego-pis-na-nowogrodzkiej-kaczynski/000FEFO9AMBPKR5D-C321.jpg" /></a>W poniedziałek po godz. 16 na wyjazdowym posiedzeniu zebrał się Klub Parlamentarny Prawa i Sprawiedliwości. Wśród omawianych tematów jest m.in. kwestia współpracy struktur w terenie czy przygotowania do kampanii wyborczej, w tym przymiarki do kształtu list wyborczych.</p><br clear="all" />

## Ryszard Terlecki: Głosowanie budżetowe jest najważniejszym w tym roku
 - [https://wydarzenia.interia.pl/kraj/news-ryszard-terlecki-glosowanie-budzetowe-jest-najwazniejszym-w-,nId,6468359](https://wydarzenia.interia.pl/kraj/news-ryszard-terlecki-glosowanie-budzetowe-jest-najwazniejszym-w-,nId,6468359)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 16:08:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ryszard-terlecki-glosowanie-budzetowe-jest-najwazniejszym-w-,nId,6468359"><img align="left" alt="Ryszard Terlecki: Głosowanie budżetowe jest najważniejszym w tym roku" src="https://i.iplsc.com/ryszard-terlecki-glosowanie-budzetowe-jest-najwazniejszym-w/000GH82U20RYHJAT-C321.jpg" /></a>- Zjednoczona Prawica jest całkowicie zjednoczona, na pewno obronimy naszego ministra sprawiedliwości - powiedział po posiedzeniu Klubu Parlamentarnego PiS rzecznik ugrupowania Rafał Bochenek. Dodał, że jednym z głównych tematów poruszanych podczas spotkania była mobilizacja. Z kolei Ryszard Terlecki, szef klubu PiS odniósł się do głosowania budżetu na 2023. - To najważniejsze głosowanie w tym roku, Solidarna Polska będzie głosować z nami. Mamy policzone głosy, wygramy - powiedział.</p><br clear="all" />

## Rzecznik prokuratury: Trzaskowski nie wskazał na jakiekolwiek nadużycia
 - [https://wydarzenia.interia.pl/kraj/news-rzecznik-prokuratury-trzaskowski-nie-wskazal-na-jakiekolwiek,nId,6468370](https://wydarzenia.interia.pl/kraj/news-rzecznik-prokuratury-trzaskowski-nie-wskazal-na-jakiekolwiek,nId,6468370)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 16:02:16+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rzecznik-prokuratury-trzaskowski-nie-wskazal-na-jakiekolwiek,nId,6468370"><img align="left" alt="Rzecznik prokuratury: Trzaskowski nie wskazał na jakiekolwiek nadużycia" src="https://i.iplsc.com/rzecznik-prokuratury-trzaskowski-nie-wskazal-na-jakiekolwiek/000F6SCNMRWARWCX-C321.jpg" /></a>Nie usłyszałem z ust pana Trzaskowskiego jakichkolwiek konkretnych informacji, które mogłyby wskazywać na nadużycia - powiedział rzecznik Prokuratury Regionalnej w Szczecinie Marcin Lorenc, odnosząc się do słów prezydenta Warszawy, który wskazał, że śledztwo ws. prok. Wrzosek ma kontekst polityczny. Prezydent Warszawy po przesłuchaniu przekazał dziennikarzom, że zaniepokoiło go, iż treść smsów prezydenta miasta z dyrektorem bezpieczeństwa, która z natury jest wrażliwa, została ujawniona.</p><br clear="all" />

## Turcja grozi atakiem na Ateny. Jest odpowiedź greckiego MSZ
 - [https://wydarzenia.interia.pl/zagranica/news-turcja-grozi-atakiem-na-ateny-jest-odpowiedz-greckiego-msz,nId,6468363](https://wydarzenia.interia.pl/zagranica/news-turcja-grozi-atakiem-na-ateny-jest-odpowiedz-greckiego-msz,nId,6468363)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 15:50:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-turcja-grozi-atakiem-na-ateny-jest-odpowiedz-greckiego-msz,nId,6468363"><img align="left" alt="Turcja grozi atakiem na Ateny. Jest odpowiedź greckiego MSZ" src="https://i.iplsc.com/turcja-grozi-atakiem-na-ateny-jest-odpowiedz-greckiego-msz/000GH7MEELS8OT2U-C321.jpg" /></a>Turcja zachowuje się jak Korea Północna, co jest niedopuszczalne w przypadku kraju należącego do NATO - stwierdził w poniedziałek szef greckiej dyplomacji Nikos Dendias . Jego słowa są odpowiedzią na groźbę Recepa Tayyipa Erdogana, który zasugerował, że Ankara jest w stanie przeprowadzić atak rakietowy na Ateny. </p><br clear="all" />

## Rosyjscy żołnierze zmuszani do walki. "Za odmowę wsadza się ich do piwnic"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjscy-zolnierze-zmuszani-do-walki-za-odmowe-wsadza-sie-ic,nId,6468329](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjscy-zolnierze-zmuszani-do-walki-za-odmowe-wsadza-sie-ic,nId,6468329)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 15:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjscy-zolnierze-zmuszani-do-walki-za-odmowe-wsadza-sie-ic,nId,6468329"><img align="left" alt="Rosyjscy żołnierze zmuszani do walki. &quot;Za odmowę wsadza się ich do piwnic&quot;" src="https://i.iplsc.com/rosyjscy-zolnierze-zmuszani-do-walki-za-odmowe-wsadza-sie-ic/000GH7GICLWUKBVH-C321.jpg" /></a>Bicie, zastraszanie i przetrzymywanie w piwnicach - to standardowe procedury rosyjskiej armii wobec żołnierzy, którzy odmawiają walki na wojnie w Ukrainie - donosi BBC. Brytyjskie media przeprowadziły rozmowy z rodzinami powołanych, by dowiedzieć się u źródła, jak wyglądają realia na linii frontu. &quot;Traktowanie mojego syna było nie tylko nielegalne, ale także nieludzkie&quot; - mówi matka żołnierza, który był więziony przez rosyjskie dowództwo.</p><br clear="all" />

## Rosja ściąga sprzęt wojskowy do Białorusi. Poligon przy polskiej granicy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-sciaga-sprzet-wojskowy-do-bialorusi-poligon-przy-polsk,nId,6468343](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-sciaga-sprzet-wojskowy-do-bialorusi-poligon-przy-polsk,nId,6468343)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 15:19:51+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-sciaga-sprzet-wojskowy-do-bialorusi-poligon-przy-polsk,nId,6468343"><img align="left" alt="Rosja ściąga sprzęt wojskowy do Białorusi. Poligon przy polskiej granicy" src="https://i.iplsc.com/rosja-sciaga-sprzet-wojskowy-do-bialorusi-poligon-przy-polsk/000GH7FMR1SV1KR4-C321.jpg" /></a>W obwodzie brzeskim na Białorusi, w pobliżu trójstyku polskiej, ukraińskiej i białoruskiej granicy, przemieszczają się 24 jednostki sprzętu wojskowego, w tym cztery przyczepy z czołgami T-80, bateria moździerzy, pojazdy łączności i sprzęt inżynieryjny - poinformował w poniedziałek niezależny kanał na Telegramie Biełaruski Hajun. Pierwsza kolumna ze sprzętem Sił Zbrojnych Federacji Rosyjskiej ruszyła z poligonu Obuz-Lesnowski (rejon baranowicki, obwód brzeski) w kierunku poligonu Brześć (rejon brzeski, obwód brzeski) w poniedziałek rano.</p><br clear="all" />

## Chiny: Koniec z ogólnokrajową aplikacją śledzącą. Władze łagodzą obostrzenia
 - [https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-chiny-koniec-z-ogolnokrajowa-aplikacja-sledzaca-wladze-lagod,nId,6468326](https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-chiny-koniec-z-ogolnokrajowa-aplikacja-sledzaca-wladze-lagod,nId,6468326)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 14:56:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-chiny-koniec-z-ogolnokrajowa-aplikacja-sledzaca-wladze-lagod,nId,6468326"><img align="left" alt="Chiny: Koniec z ogólnokrajową aplikacją śledzącą. Władze łagodzą obostrzenia" src="https://i.iplsc.com/chiny-koniec-z-ogolnokrajowa-aplikacja-sledzaca-wladze-lagod/000A203U3TUSEO96-C321.jpg" /></a>W Chinach władze ogłosiły w poniedziałek wstrzymanie działania ogólnokrajowej aplikacji śledzącej. Do tej pory była ona wymagana od podróżnych oraz przy wejściu do niektórych miejsc publicznych. Wszystko wskazuje na to, że to kolejna oznaka łagodzenia surowych środków walki z pandemią COVID-19.</p><br clear="all" />

## Grecja zamraża majątek Ewy Kaili. Skandal korupcyjny wokół wiceszefowej PE
 - [https://wydarzenia.interia.pl/zagranica/news-grecja-zamraza-majatek-ewy-kaili-skandal-korupcyjny-wokol-wi,nId,6468323](https://wydarzenia.interia.pl/zagranica/news-grecja-zamraza-majatek-ewy-kaili-skandal-korupcyjny-wokol-wi,nId,6468323)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 14:40:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-grecja-zamraza-majatek-ewy-kaili-skandal-korupcyjny-wokol-wi,nId,6468323"><img align="left" alt="Grecja zamraża majątek Ewy Kaili. Skandal korupcyjny wokół wiceszefowej PE" src="https://i.iplsc.com/grecja-zamraza-majatek-ewy-kaili-skandal-korupcyjny-wokol-wi/000GH6P9WC017TMM-C321.jpg" /></a>Grecja zamroziła majątek wiceszefowej Parlamentu Europejskiego Ewy Kaili w związku ze skandalem korupcyjnym - poinformowała w poniedziałek agencja Reutera. Kaili została zawieszona w obowiązkach przez Parlament Europejski, a grecka partia socjalistyczna PASOK poinformowała, że usuwa ją ze swoich szeregów. Zdaniem mediów w skandal z udziałem Kaili zamieszani mogą być urzędnicy z Kataru.</p><br clear="all" />

## Doroczna konferencja Putina odwołana. Media: Boi się niewygodnych pytań
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-doroczna-konferencja-putina-odwolana-media-boi-sie-niewygodn,nId,6468313](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-doroczna-konferencja-putina-odwolana-media-boi-sie-niewygodn,nId,6468313)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 14:27:10+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-doroczna-konferencja-putina-odwolana-media-boi-sie-niewygodn,nId,6468313"><img align="left" alt="Doroczna konferencja Putina odwołana. Media: Boi się niewygodnych pytań" src="https://i.iplsc.com/doroczna-konferencja-putina-odwolana-media-boi-sie-niewygodn/000GH6N4K4RLPSTR-C321.jpg" /></a>Doroczna grudniowa konferencja prasowa Władimira Putina w tym roku się nie odbędzie. Poinformowały o tym niezależne media, które powołują się na rzecznika Kremla. Niepewna jest też organizacja tzw. gorącej linii, w której prezydent miał rozmawiać ze &quot;zwykłymi Rosjanami&quot;. W ocenie mediów, w obawie przed niewygodnymi pytaniami, wszystkie wystąpienia Putina są planowane pod kątem &quot;komfortu&quot; prezydenta.</p><br clear="all" />

## PiS ma plan, jak ograć Ziobrę i pozyskać miliardy z UE
 - [https://wydarzenia.interia.pl/kraj/news-pis-ma-plan-jak-ograc-ziobre-i-pozyskac-miliardy-z-ue,nId,6468229](https://wydarzenia.interia.pl/kraj/news-pis-ma-plan-jak-ograc-ziobre-i-pozyskac-miliardy-z-ue,nId,6468229)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 13:50:18+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pis-ma-plan-jak-ograc-ziobre-i-pozyskac-miliardy-z-ue,nId,6468229"><img align="left" alt="PiS ma plan, jak ograć Ziobrę i pozyskać miliardy z UE" src="https://i.iplsc.com/pis-ma-plan-jak-ograc-ziobre-i-pozyskac-miliardy-z-ue/000GH6B0YY03ESRG-C321.jpg" /></a>PiS nie chce mniejszościowego rządu, ale dla pieniędzy z Krajowego Planu Odbudowy jest w stanie machnąć ręką na Solidarną Polskę i zacząć wspólnie głosować z opozycją. Tylko czy uda się wypracować rozwiązania, które Zjednoczona Prawica poprze wspólnie ze swoimi politycznymi przeciwnikami? Odpowiedź na to pytanie, po rozmowie z Komisją Europejską, ma przynieść minister do spraw Unii Europejskiej, Szymon Szynkowski vel Sęk. - Chcemy jasnych procedur - mówi Interii Grzegorz Puda, minister funduszy i polityki regionalnej. Jeśli wszystko pójdzie...</p><br clear="all" />

## Piotr Müller: Programy operacyjne dla wszystkich województw zaakceptowane
 - [https://wydarzenia.interia.pl/kraj/news-piotr-muller-programy-operacyjne-dla-wszystkich-wojewodztw-z,nId,6468265](https://wydarzenia.interia.pl/kraj/news-piotr-muller-programy-operacyjne-dla-wszystkich-wojewodztw-z,nId,6468265)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 13:37:46+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-piotr-muller-programy-operacyjne-dla-wszystkich-wojewodztw-z,nId,6468265"><img align="left" alt="Piotr Müller: Programy operacyjne dla wszystkich województw zaakceptowane" src="https://i.iplsc.com/piotr-muller-programy-operacyjne-dla-wszystkich-wojewodztw-z/000GH6BGHUWXY2DP-C321.jpg" /></a>- Programy operacyjne dla wszystkich województw w Polsce zostały zaakceptowane - powiedział Piotr Müller, rzecznik prasowy rządu. Wyjaśnił, że są to &quot;programy z nowej perspektywy unijnej&quot;. - Krótko mówiąc, regionalne programy operacyjne z środków unijnych, umowy partnerstwa, klasycznych środków unijnych, przechodzą do fazy realizacji - mówił. Müller dodał, że chodzi o łączną kwotę 33,5 miliarda euro. Pieniądze trafią do Polski w ramach Krajowego Planu Odbudowy.</p><br clear="all" />

## Andrzej Duda: "Dziękuję Niemcom za wysłanie do Polski systemów Patriot"
 - [https://wydarzenia.interia.pl/kraj/news-andrzej-duda-dziekuje-niemcom-za-wyslanie-do-polski-systemow,nId,6467986](https://wydarzenia.interia.pl/kraj/news-andrzej-duda-dziekuje-niemcom-za-wyslanie-do-polski-systemow,nId,6467986)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 13:18:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-andrzej-duda-dziekuje-niemcom-za-wyslanie-do-polski-systemow,nId,6467986"><img align="left" alt="Andrzej Duda: &quot;Dziękuję Niemcom za wysłanie do Polski systemów Patriot&quot;" src="https://i.iplsc.com/andrzej-duda-dziekuje-niemcom-za-wyslanie-do-polski-systemow/000GH499E82LR6GU-C321.jpg" /></a>Prezydent Andrzej Duda spotkał się w Niemczech z Frankiem-Walterem Steinmeierem. W rozmowie &quot;w cztery oczy&quot; politycy poruszyli kwestie związane z bezpieczeństwem oraz stosunkami bilateralnymi. - Dziękuję, że władze niemieckie podjęły decyzję o wysłaniu baterii Patriot do Polski. Mamy nadzieję z panem prezydentem, że w najbliższych dniach grupy ekspertów ustalą miejsce dyslokacji baterii - podkreślił prezydent Andrzej Duda. </p><br clear="all" />

## Strzelanina w Rzymie. Zginęła przyjaciółka premier Giorgii Meloni
 - [https://wydarzenia.interia.pl/zagranica/news-strzelanina-w-rzymie-zginela-przyjaciolka-premier-giorgii-me,nId,6468141](https://wydarzenia.interia.pl/zagranica/news-strzelanina-w-rzymie-zginela-przyjaciolka-premier-giorgii-me,nId,6468141)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 12:58:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-strzelanina-w-rzymie-zginela-przyjaciolka-premier-giorgii-me,nId,6468141"><img align="left" alt="Strzelanina w Rzymie. Zginęła przyjaciółka premier Giorgii Meloni" src="https://i.iplsc.com/strzelanina-w-rzymie-zginela-przyjaciolka-premier-giorgii-me/000GH5NWVFG2WGKF-C321.jpg" /></a>W niedzielę na przedmieściach Rzymu doszło do strzelaniny, w wyniku której zginęły trzy kobiety uczestniczące w spotkaniu wspólnoty mieszkaniowej. Jedną z ofiar była przyjaciółka premier Włoch. Policja jak dotąd nie poinformowała, jaka była motywacja sprawcy. </p><br clear="all" />

## Sondaż: Topnieje poparcie dla PiS. W Sejmie pięć partii
 - [https://wydarzenia.interia.pl/kraj/news-sondaz-topnieje-poparcie-dla-pis-w-sejmie-piec-partii,nId,6468195](https://wydarzenia.interia.pl/kraj/news-sondaz-topnieje-poparcie-dla-pis-w-sejmie-piec-partii,nId,6468195)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 12:55:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sondaz-topnieje-poparcie-dla-pis-w-sejmie-piec-partii,nId,6468195"><img align="left" alt="Sondaż: Topnieje poparcie dla PiS. W Sejmie pięć partii" src="https://i.iplsc.com/sondaz-topnieje-poparcie-dla-pis-w-sejmie-piec-partii/000GH60S43226NT5-C321.jpg" /></a>32 proc. dla KO, 28 proc. dla PiS, 10 proc. Lewica, 9 proc. Polska 2050, a 5 proc. Konfederacja - tak zakończyłoby się głosowanie, gdyby wybory do Sejmu odbywały się w grudniu. Jak wynika z najnowszego sondażu Kantar Public, pozostałe ugrupowania nie przekroczyłyby progu wyborczego.</p><br clear="all" />

## Von der Leyen o działaniach Putina. "Szantaż się nie powiódł"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-von-der-leyen-o-dzialaniach-putina-szantaz-sie-nie-powiodl,nId,6468202](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-von-der-leyen-o-dzialaniach-putina-szantaz-sie-nie-powiodl,nId,6468202)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 12:51:39+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-von-der-leyen-o-dzialaniach-putina-szantaz-sie-nie-powiodl,nId,6468202"><img align="left" alt="Von der Leyen o działaniach Putina. &quot;Szantaż się nie powiódł&quot;" src="https://i.iplsc.com/von-der-leyen-o-dzialaniach-putina-szantaz-sie-nie-powiodl/000EOCBK2G46ML3N-C321.jpg" /></a>Ursula von der Leyen zabrała głos w sprawie działań Rosji. Jak oceniła szefowa Komisji Europejskiej, &quot;energetyczny szantaż Rosji się nie powiódł&quot;. - Tej zimy jesteśmy bezpieczni - podkreśliła Von der Leyen. Zastrzegła jednak, że przyszłoroczna zima może okazać się trudniejsza do przetrwania.</p><br clear="all" />

## Groźby pod adresem ministra zdrowia. Adam Niedzielski mówi o zamachu
 - [https://wydarzenia.interia.pl/kraj/news-grozby-pod-adresem-ministra-zdrowia-adam-niedzielski-mowi-o-,nId,6468168](https://wydarzenia.interia.pl/kraj/news-grozby-pod-adresem-ministra-zdrowia-adam-niedzielski-mowi-o-,nId,6468168)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 12:41:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-grozby-pod-adresem-ministra-zdrowia-adam-niedzielski-mowi-o-,nId,6468168"><img align="left" alt="Groźby pod adresem ministra zdrowia. Adam Niedzielski mówi o zamachu" src="https://i.iplsc.com/grozby-pod-adresem-ministra-zdrowia-adam-niedzielski-mowi-o/000GH61IS337OVEB-C321.jpg" /></a>Grupa tzw. kamratów publicznie ogłosiła, że planuje zamordować ministra zdrowia Adama Niedzielskiego. - Z mojego puntu widzenia to jest sytuacja absolutnie niebezpieczna. To jest regularne planowanie zamachu - komentuje minister.</p><br clear="all" />

## Rafał Trzaskowski stawił się na przesłuchaniu. "Martwi mnie to i niepokoi"
 - [https://wydarzenia.interia.pl/kraj/news-rafal-trzaskowski-stawil-sie-na-przesluchaniu-martwi-mnie-to,nId,6468174](https://wydarzenia.interia.pl/kraj/news-rafal-trzaskowski-stawil-sie-na-przesluchaniu-martwi-mnie-to,nId,6468174)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 12:29:56+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rafal-trzaskowski-stawil-sie-na-przesluchaniu-martwi-mnie-to,nId,6468174"><img align="left" alt="Rafał Trzaskowski stawił się na przesłuchaniu. &quot;Martwi mnie to i niepokoi&quot;" src="https://i.iplsc.com/rafal-trzaskowski-stawil-sie-na-przesluchaniu-martwi-mnie-to/000GH5Y5JVTJ8HTL-C321.jpg" /></a>- Czy teraz każda moja wymiana smsów z ludźmi odpowiedzialnymi za bezpieczeństwo w mieście będzie podawana do opinii publicznej? - pytał po przesłuchaniu w sprawie prokurator Ewy Wrzosek prezydent Warszawy Rafał Trzaskowski. Jak dodał, jest zaniepokojony, że &quot;treść smsów prezydenta miasta z dyrektorem bezpieczeństwa, z natury wrażliwa, jest ujawniana&quot;. </p><br clear="all" />

## Krok w stronę KPO. Puda: Komisja podpisała "ustalenia operacyjne"
 - [https://wydarzenia.interia.pl/kraj/news-krok-w-strone-kpo-puda-komisja-podpisala-ustalenia-operacyjn,nId,6468173](https://wydarzenia.interia.pl/kraj/news-krok-w-strone-kpo-puda-komisja-podpisala-ustalenia-operacyjn,nId,6468173)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 12:15:56+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-krok-w-strone-kpo-puda-komisja-podpisala-ustalenia-operacyjn,nId,6468173"><img align="left" alt="Krok w stronę KPO. Puda: Komisja podpisała &quot;ustalenia operacyjne&quot;" src="https://i.iplsc.com/krok-w-strone-kpo-puda-komisja-podpisala-ustalenia-operacyjn/0009XIKPVC5O13DK-C321.jpg" /></a>Kolejny krok w sprawie funduszy z Krajowego Planu Odbudowy. Jak przekazał minister Grzegorz Puda, Komisja Europejska podpisała &quot;ustalenia operacyjne&quot; dla KPO. Wkrótce gotowy ma być też pierwszy wniosek o płatność. </p><br clear="all" />

## Wielka Brytania chce chronić kobiety przed wulgarnymi komentarzami na ulicy
 - [https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-chce-chronic-kobiety-przed-wulgarnymi-koment,nId,6467969](https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-chce-chronic-kobiety-przed-wulgarnymi-koment,nId,6467969)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 12:15:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-chce-chronic-kobiety-przed-wulgarnymi-koment,nId,6467969"><img align="left" alt="Wielka Brytania chce chronić kobiety przed wulgarnymi komentarzami na ulicy" src="https://i.iplsc.com/wielka-brytania-chce-chronic-kobiety-przed-wulgarnymi-koment/000GH4FS7VR7OT46-C321.jpg" /></a>Osoby, które dopuszczają się publicznego molestowania kobiet w Wielkiej Brytanii, już wkrótce będą mogły trafić na dwa lata do więzienia. Zmiany w prawie mają przyczynić się do zaostrzenia kar i uznania za przestępstwo m.in. celowego podążania za kimś, blokowania jego drogi, czy wypowiadaniu seksualnie nacechowanych uwag.</p><br clear="all" />

## Zatrzymanie Tomasza L. Żaryn o "współpracy z Rosją"
 - [https://wydarzenia.interia.pl/kraj/news-zatrzymanie-tomasza-l-zaryn-o-wspolpracy-z-rosja,nId,6468167](https://wydarzenia.interia.pl/kraj/news-zatrzymanie-tomasza-l-zaryn-o-wspolpracy-z-rosja,nId,6468167)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 12:05:53+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zatrzymanie-tomasza-l-zaryn-o-wspolpracy-z-rosja,nId,6468167"><img align="left" alt="Zatrzymanie Tomasza L. Żaryn o &quot;współpracy z Rosją&quot;" src="https://i.iplsc.com/zatrzymanie-tomasza-l-zaryn-o-wspolpracy-z-rosja/000DMB6ZHLJWY6X6-C321.jpg" /></a>Nie milkną echa zatrzymania stołecznego urzędnika Tomasza L. Mężczyzna jest oskarżony o szpiegowanie na rzecz Rosji. - Zgromadzony do tej pory materiał wskazuje, że Tomasz L., pracując w Wydziale Archiwalnym Ksiąg Stanu Cywilnego w Archiwum USC m.st. Warszawy, współpracował z wywiadem rosyjskim - przekazał zastępca ministra koordynatora służb specjalnych Stanisław Żaryn.</p><br clear="all" />

## Szkolenia medyków z Ukrainy w Polsce. "Medycyna jest elementem bezpieczeństwa narodowego"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szkolenia-medykow-z-ukrainy-w-polsce-medycyna-jest-elementem,nId,6468146](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szkolenia-medykow-z-ukrainy-w-polsce-medycyna-jest-elementem,nId,6468146)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 12:03:26+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szkolenia-medykow-z-ukrainy-w-polsce-medycyna-jest-elementem,nId,6468146"><img align="left" alt="Szkolenia medyków z Ukrainy w Polsce. &quot;Medycyna jest elementem bezpieczeństwa narodowego&quot;" src="https://i.iplsc.com/szkolenia-medykow-z-ukrainy-w-polsce-medycyna-jest-elementem/000GH5LQFRNXR0PL-C321.jpg" /></a>- Odbudowa państwa ukraińskiego rozpoczyna się już dziś, cieszymy się, że możemy wspólnie brać w niej udział - mówił szef BBN Jacek Siewiera podczas inauguracji szkoleń dla ukraińskiej służby lotniczego pogotowia ratunkowego. Szkolenia powstały z inicjatywy pierwszych dam Polski i Ukrainy Agaty Kornhauser-Dudy i Ołeny Zełenskiej.</p><br clear="all" />

## Sześciolatka bez butów, w samej piżamie szukała matki. Kobieta była nietrzeźwa
 - [https://wydarzenia.interia.pl/swietokrzyskie/news-szesciolatka-bez-butow-w-samej-pizamie-szukala-matki-kobieta,nId,6468131](https://wydarzenia.interia.pl/swietokrzyskie/news-szesciolatka-bez-butow-w-samej-pizamie-szukala-matki-kobieta,nId,6468131)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 11:55:09+00:00

<p><a href="https://wydarzenia.interia.pl/swietokrzyskie/news-szesciolatka-bez-butow-w-samej-pizamie-szukala-matki-kobieta,nId,6468131"><img align="left" alt="Sześciolatka bez butów, w samej piżamie szukała matki. Kobieta była nietrzeźwa" src="https://i.iplsc.com/szesciolatka-bez-butow-w-samej-pizamie-szukala-matki-kobieta/000D5EFR2LTDCL3J-C321.jpg" /></a>Sześcioletnia dziewczynka bez butów i w samej piżamie błąkała się po jednym z osiedli w Kielcach. Dziecko wyszło z domu, żeby poszukać matki - wcześniej partner kobiety, który zajmował się dziewczynką, powiedział, że &quot;mama już nie wróci&quot;. Kiedy pojawiła się matka sześciolatki, okazało się, że ma blisko półtora promila alkoholu w organizmie.</p><br clear="all" />

## Niż Brygida nad Polską. Pogoda w Tatrach, Beskidach i Karkonoszach nie rozpieszcza. Śnieg i zagrożenie lawinowe
 - [https://wydarzenia.interia.pl/kraj/news-niz-brygida-nad-polska-pogoda-w-tatrach-beskidach-i-karkonos,nId,6468149](https://wydarzenia.interia.pl/kraj/news-niz-brygida-nad-polska-pogoda-w-tatrach-beskidach-i-karkonos,nId,6468149)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 11:43:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-niz-brygida-nad-polska-pogoda-w-tatrach-beskidach-i-karkonos,nId,6468149"><img align="left" alt="Niż Brygida nad Polską. Pogoda w Tatrach, Beskidach i Karkonoszach nie rozpieszcza. Śnieg i zagrożenie lawinowe" src="https://i.iplsc.com/niz-brygida-nad-polska-pogoda-w-tatrach-beskidach-i-karkonos/000GH5M1EXHLM9IR-C321.jpg" /></a>W wyniku wytworzenia się niżu Brygida pogoda w Polsce uległa znacznemu pogorszeniu. Opady śniegu występują praktycznie w całym kraju. Najwięcej białego puchu spadło w górach. Tatry, Beskidy, Bieszczady i Karkonosze znalazły się pod śniegiem. Jego pokrywa miejscami osiąga nawet 70 centymetrów. W Tatrach i Karkonoszach obowiązują także zagrożenia lawinowe.</p><br clear="all" />

## Ukraina: Rosjanin przyjechał na wojnę "walczyć z Polakami"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-rosjanin-przyjechal-na-wojne-walczyc-z-polakami,nId,6468117](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-rosjanin-przyjechal-na-wojne-walczyc-z-polakami,nId,6468117)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 11:34:39+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-rosjanin-przyjechal-na-wojne-walczyc-z-polakami,nId,6468117"><img align="left" alt="Ukraina: Rosjanin przyjechał na wojnę &quot;walczyć z Polakami&quot;" src="https://i.iplsc.com/ukraina-rosjanin-przyjechal-na-wojne-walczyc-z-polakami/000GH5DBC851OF4A-C321.jpg" /></a>W mediach społecznościowych pojawiło się nagranie, na którym zobaczyć można kolejnego Rosjanina zatrzymanego przez siły ukraińskie. Żołnierz zapytany o to, dlaczego walczy w Ukrainie odpowiedział: - Walczę tu z Polakami. - Bo chcą zabrać waszą ziemię - dodał. </p><br clear="all" />

## Odnotowano minus 60 stopni Celsjusza. "Najniższa temperatura od 10 lat"
 - [https://wydarzenia.interia.pl/zagranica/news-odnotowano-minus-60-stopni-celsjusza-najnizsza-temperatura-o,nId,6468111](https://wydarzenia.interia.pl/zagranica/news-odnotowano-minus-60-stopni-celsjusza-najnizsza-temperatura-o,nId,6468111)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 10:59:53+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-odnotowano-minus-60-stopni-celsjusza-najnizsza-temperatura-o,nId,6468111"><img align="left" alt="Odnotowano minus 60 stopni Celsjusza. &quot;Najniższa temperatura od 10 lat&quot;" src="https://i.iplsc.com/odnotowano-minus-60-stopni-celsjusza-najnizsza-temperatura-o/000GH59N4P6SJ8K5-C321.jpg" /></a>Minus 60 stopni Celsjusza - taką temperaturę wykazały termometry w poniedziałek rano w miejscowości Tomtor w Jakucji. Miejscowość ta znana jest jako &quot;biegun zimna&quot; na Syberii i w całej Rosji. Jak przekazał Jakucki Zarząd ds. Hydrometeorologii i Monitorowania Środowiska Naturalnego, to najniższa temperatura odnotowana od 10 lat.</p><br clear="all" />

## 20-lecie zakończenia negocjacji Polska-UE. Donald Tusk wzywa do odwołania Ziobry
 - [https://wydarzenia.interia.pl/kraj/news-20-lecie-zakonczenia-negocjacji-polska-ue-donald-tusk-wzywa-,nId,6468105](https://wydarzenia.interia.pl/kraj/news-20-lecie-zakonczenia-negocjacji-polska-ue-donald-tusk-wzywa-,nId,6468105)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 10:44:35+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-20-lecie-zakonczenia-negocjacji-polska-ue-donald-tusk-wzywa-,nId,6468105"><img align="left" alt="20-lecie zakończenia negocjacji Polska-UE. Donald Tusk wzywa do odwołania Ziobry" src="https://i.iplsc.com/20-lecie-zakonczenia-negocjacji-polska-ue-donald-tusk-wzywa/000GH58PRNYXR0QP-C321.jpg" /></a>W Senacie odbyła się konferencja poświęcona 20. rocznicy zakończenia negocjacji między Polską a Unią Europejską w kontekście akcesji. W wydarzeniu wzięli udział m.in. byli premierzy: Włodzimierz Cimoszewicz, Leszek Miller oraz Donald Tusk. </p><br clear="all" />

## Eksplozje w głębi Rosji. Co wiemy o ukraińskich dronach?
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-eksplozje-w-glebi-rosji-co-wiemy-o-ukrainskich-dronach,nId,6468063](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-eksplozje-w-glebi-rosji-co-wiemy-o-ukrainskich-dronach,nId,6468063)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 10:39:49+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-eksplozje-w-glebi-rosji-co-wiemy-o-ukrainskich-dronach,nId,6468063"><img align="left" alt="Eksplozje w głębi Rosji. Co wiemy o ukraińskich dronach?" src="https://i.iplsc.com/eksplozje-w-glebi-rosji-co-wiemy-o-ukrainskich-dronach/000GH53O1JLD3A9G-C321.jpg" /></a>Moskwa oficjalnie bagatelizuje skutki ukraińskich nalotów na swoje lotniska wojskowe. Są to jednak ważne sygnały dla dalszego przebiegu wojny - pisze Deutsche Welle.</p><br clear="all" />

## Zakrwawiona przesyłka w ambasadzie Ukrainy w Grecji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zakrwawiona-przesylka-w-ambasadzie-ukrainy-w-grecji,nId,6468101](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zakrwawiona-przesylka-w-ambasadzie-ukrainy-w-grecji,nId,6468101)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 10:37:04+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zakrwawiona-przesylka-w-ambasadzie-ukrainy-w-grecji,nId,6468101"><img align="left" alt="Zakrwawiona przesyłka w ambasadzie Ukrainy w Grecji" src="https://i.iplsc.com/zakrwawiona-przesylka-w-ambasadzie-ukrainy-w-grecji/000GH58KB9CYTAY1-C321.jpg" /></a>Kolejna placówka dyplomatyczna Ukrainy otrzymała zakrwawioną przesyłkę. Tym razem trafiła ona do ambasady w Grecji. MSZ w Kijowie odnotowało już 33 podobne groźby. W ubiegłym tygodniu przesyłki z groźbami przesłano m.in. do ambasad we Włoszech, Polsce, Portugalii, Rumunii i Danii oraz do konsulatu w Gdańsku. </p><br clear="all" />

## Przekazanie armatohaubic. Mariusz Błaszczak: Chodzi o to, żeby odstraszyć agresora
 - [https://wydarzenia.interia.pl/kraj/news-przekazanie-armatohaubic-mariusz-blaszczak-chodzi-o-to-zeby-,nId,6468047](https://wydarzenia.interia.pl/kraj/news-przekazanie-armatohaubic-mariusz-blaszczak-chodzi-o-to-zeby-,nId,6468047)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 10:28:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-przekazanie-armatohaubic-mariusz-blaszczak-chodzi-o-to-zeby-,nId,6468047"><img align="left" alt="Przekazanie armatohaubic. Mariusz Błaszczak: Chodzi o to, żeby odstraszyć agresora" src="https://i.iplsc.com/przekazanie-armatohaubic-mariusz-blaszczak-chodzi-o-to-zeby/000EMILY2TX79OL2-C321.jpg" /></a>- Agresja rosyjska na Ukrainę pokazała jak ważne jest to, żeby wojsko polskie było silne, wyposażone w nowoczesną broń. Chodzi o to, żeby odstraszyć agresora, żeby spowodować, że agresor nie odważy się napaść na Polskę - powiedział Mariusz Błaszczak, minister obrony narodowej, który w poniedziałek przekazał armatohaubice K9 żołnierzom Wojska Polskiego. Do wojska ma trafić łącznie 212 armatohaubic, a Polska ma zapłacić za nie 2,4 mld dolarów netto. Umowa na zakup sprzętu została podpisana w lipcu 2022 r. </p><br clear="all" />

## IPN: 38 wniosków do Sądu Najwyższego ws. zbrodni sądowych w stanie wojennym
 - [https://wydarzenia.interia.pl/kraj/news-ipn-38-wnioskow-do-sadu-najwyzszego-ws-zbrodni-sadowych-w-st,nId,6468082](https://wydarzenia.interia.pl/kraj/news-ipn-38-wnioskow-do-sadu-najwyzszego-ws-zbrodni-sadowych-w-st,nId,6468082)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 10:20:46+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ipn-38-wnioskow-do-sadu-najwyzszego-ws-zbrodni-sadowych-w-st,nId,6468082"><img align="left" alt="IPN: 38 wniosków do Sądu Najwyższego ws. zbrodni sądowych w stanie wojennym" src="https://i.iplsc.com/ipn-38-wnioskow-do-sadu-najwyzszego-ws-zbrodni-sadowych-w-st/000G87D762U532YS-C321.jpg" /></a>Prezes IPN poinformował, że w ciągu roku prokuratorzy oddziałowych Komisji Ścigania Zbrodni przeciwko Narodowi Polskiemu złożyli do Sądu Najwyższego 38 wniosków dotyczących zbrodni sądowych popełnianych w stanie wojennym w PRL. Jak uściślił dr Karol Nawrocki, działania Instytutu mają &quot;doprowadzić do pociągnięcia do odpowiedzialności 25 sędziów i pięciu prokuratorów&quot;.</p><br clear="all" />

## Seks pozamałżeński przestępstwem. Władze Bali zwracają się do turystów
 - [https://wydarzenia.interia.pl/zagranica/news-seks-pozamalzenski-przestepstwem-wladze-bali-zwracaja-sie-do,nId,6468026](https://wydarzenia.interia.pl/zagranica/news-seks-pozamalzenski-przestepstwem-wladze-bali-zwracaja-sie-do,nId,6468026)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 10:04:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-seks-pozamalzenski-przestepstwem-wladze-bali-zwracaja-sie-do,nId,6468026"><img align="left" alt="Seks pozamałżeński przestępstwem. Władze Bali zwracają się do turystów" src="https://i.iplsc.com/seks-pozamalzenski-przestepstwem-wladze-bali-zwracaja-sie-do/000GH4RW0PMWS8SB-C321.jpg" /></a>Przyjęte niedawno przez Indonezję prawo uznaje seks pozamałżeński za przestępstwo. Przepisy mają zacząć obowiązywać za trzy lata. Gubernator Bali uspokaja turystów, że nie powinni się jednak obawiać konsekwencji zmian przepisów. </p><br clear="all" />

## Karambol na A2. Prawdopodobny sprawca uciekł z miejsca zdarzenia
 - [https://wydarzenia.interia.pl/mazowieckie/news-karambol-na-a2-prawdopodobny-sprawca-uciekl-z-miejsca-zdarze,nId,6468060](https://wydarzenia.interia.pl/mazowieckie/news-karambol-na-a2-prawdopodobny-sprawca-uciekl-z-miejsca-zdarze,nId,6468060)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 09:56:33+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-karambol-na-a2-prawdopodobny-sprawca-uciekl-z-miejsca-zdarze,nId,6468060"><img align="left" alt="Karambol na A2. Prawdopodobny sprawca uciekł z miejsca zdarzenia" src="https://i.iplsc.com/karambol-na-a2-prawdopodobny-sprawca-uciekl-z-miejsca-zdarze/0003DQMEANE24EN2-C321.jpg" /></a>Na A2 zderzyły się trzy busy i samochód osobowy. Jak przekazała asp. szt. Katarzyna Zych z Komendy Powiatowej Policji w Grodzisku Mazowieckim, kierowca osobówki, który był najprawdopodobniej sprawcą zdarzenia oddalił się z miejsca i jest poszukiwany. Ruch w kierunku Warszawy odbywa się jednym pasem.</p><br clear="all" />

## Die Welt: Vucić ma zadatki na drugiego Orbana
 - [https://wydarzenia.interia.pl/zagranica/news-die-welt-vucic-ma-zadatki-na-drugiego-orbana,nId,6468032](https://wydarzenia.interia.pl/zagranica/news-die-welt-vucic-ma-zadatki-na-drugiego-orbana,nId,6468032)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 09:52:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-die-welt-vucic-ma-zadatki-na-drugiego-orbana,nId,6468032"><img align="left" alt="Die Welt: Vucić ma zadatki na drugiego Orbana" src="https://i.iplsc.com/die-welt-vucic-ma-zadatki-na-drugiego-orbana/000GH4O3Y9E6P13B-C321.jpg" /></a>Aleksandar Vucić ma zadatki na drugiego Viktora Orbana - pisze &quot;Die Welt&quot;. Podobnie jak premier Węgier, prezydent Serbii &quot;szuka bliskości z rosyjskim reżimem&quot;. Jednak Bruksela chce utrzymać Serbię w &quot;europejskiej drużynie&quot;, ponieważ jest strategicznie ważna. </p><br clear="all" />

## Jeden dzień zmienił ich życie. "Zuzia mogła być zdrowa. Szpital popełnił błąd"
 - [https://wydarzenia.interia.pl/kraj/news-jeden-dzien-zmienil-ich-zycie-zuzia-mogla-byc-zdrowa-szpital,nId,6462958](https://wydarzenia.interia.pl/kraj/news-jeden-dzien-zmienil-ich-zycie-zuzia-mogla-byc-zdrowa-szpital,nId,6462958)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 09:49:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jeden-dzien-zmienil-ich-zycie-zuzia-mogla-byc-zdrowa-szpital,nId,6462958"><img align="left" alt="Jeden dzień zmienił ich życie. &quot;Zuzia mogła być zdrowa. Szpital popełnił błąd&quot;" src="https://i.iplsc.com/jeden-dzien-zmienil-ich-zycie-zuzia-mogla-byc-zdrowa-szpital/000GH1HCSNWL9GLN-C321.jpg" /></a>- Naszym największym marzeniem jest rozmowa z córką - mówi Aldona. Choć Zuzia ma już siedem lat, to rodzice nigdy nie usłyszeli jej głosu. Porusza się na wózku, nie siedzi, potrafi nie spać przez 48 godzin. Ma padaczkę, refluks, małogłowie i korowe zaburzenia widzenia. Wszystko to związane jest z mózgowym porażeniem dziecięcym, które jest konsekwencją niedotlenienia okołoporodowego. Rodzice Zuzi twierdzą, że doszło do błędu medycznego, za który odpowiada szpital. Po raz pierwszy zdecydowali się na opowiedzenie swojej historii. </p><br clear="all" />

## Rafał Trzaskowski w Szczecinie. Przesłuchanie w sprawie Ewy Wrzosek
 - [https://wydarzenia.interia.pl/kraj/news-rafal-trzaskowski-w-szczecinie-przesluchanie-w-sprawie-ewy-w,nId,6468049](https://wydarzenia.interia.pl/kraj/news-rafal-trzaskowski-w-szczecinie-przesluchanie-w-sprawie-ewy-w,nId,6468049)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 09:41:44+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rafal-trzaskowski-w-szczecinie-przesluchanie-w-sprawie-ewy-w,nId,6468049"><img align="left" alt="Rafał Trzaskowski w Szczecinie. Przesłuchanie w sprawie Ewy Wrzosek" src="https://i.iplsc.com/rafal-trzaskowski-w-szczecinie-przesluchanie-w-sprawie-ewy-w/000GH4VA5V1IGSNT-C321.jpg" /></a>Rafał Trzaskowski stawił się w Prokuraturze Regionalnej w Szczecinie, gdzie ma złożyć zeznania w sprawie prokurator Ewy Wrzosek. Wcześniej prezydent Warszawy podkreślał, że &quot;mamy do czynienia z sytuacją absolutnie bezprecedensową i skandaliczną&quot;. Chodzi o upublicznioną przez prokuraturę korespondencję między Trzaskowskim a Michałem Domaradzkim. Szef Biura Bezpieczeństwa i Zarządzania Kryzysowego stołecznego ratusza miał prosić prokurator Ewę Wrzosek o przekazanie mu informacji nt. wypadku autobusu miejskiego, do którego doszło w 2020 roku.</p><br clear="all" />

## Grzane wino, Breżniew i kiełbasa. Odwiedziliśmy świąteczne jarmarki w Berlinie
 - [https://wydarzenia.interia.pl/zagranica/news-grzane-wino-brezniew-i-kielbasa-odwiedzilismy-swiateczne-jar,nId,6466555](https://wydarzenia.interia.pl/zagranica/news-grzane-wino-brezniew-i-kielbasa-odwiedzilismy-swiateczne-jar,nId,6466555)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 09:10:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-grzane-wino-brezniew-i-kielbasa-odwiedzilismy-swiateczne-jar,nId,6466555"><img align="left" alt="Grzane wino, Breżniew i kiełbasa. Odwiedziliśmy świąteczne jarmarki w Berlinie" src="https://i.iplsc.com/grzane-wino-brezniew-i-kielbasa-odwiedzilismy-swiateczne-jar/000GH3ILJOT2TYE5-C321.jpg" /></a>Szopek z Jezuskiem jak na lekarstwo, sporo jest za to bluz z Pokemonami, liśćmi konopi i radziecką symboliką. Na jarmarkach bożonarodzeniowych w stolicy Niemiec komercja rośnie w siłę, ale przewagę nadal ma tradycja - choćby w postaci płacenia gotówką, na co niekoniecznie się przygotowaliśmy. Nie zabrakło też tradycyjnej kiełbasy w sosie, grzanego wina w różnych wariacjach oraz dziesiątek Polaków, których spotykaliśmy niemal na każdym kroku.</p><br clear="all" />

## Dramatyczna sytuacja w Odessie. Miasto bez prądu po atakach Rosjan
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dramatyczna-sytuacja-w-odessie-miasto-bez-pradu-po-atakach-r,nId,6468002](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dramatyczna-sytuacja-w-odessie-miasto-bez-pradu-po-atakach-r,nId,6468002)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 09:08:04+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dramatyczna-sytuacja-w-odessie-miasto-bez-pradu-po-atakach-r,nId,6468002"><img align="left" alt="Dramatyczna sytuacja w Odessie. Miasto bez prądu po atakach Rosjan" src="https://i.iplsc.com/dramatyczna-sytuacja-w-odessie-miasto-bez-pradu-po-atakach-r/000GH4K3436KAT8O-C321.jpg" /></a>W wyniku rosyjskich ataków w Odessie w weekend ponad 1,5 miliona mieszkańców pozostawało bez prądu. Ponieważ naprawy mogą potrwać do trzech miesięcy i zaapelowano do mieszkańców, by w miarę możliwości się ewakuowali. &quot;Sytuacja ciągle się zmienia. Głównym zadaniem jest utrzymanie infrastruktury krytycznej&quot; - przekazał mer miasta, dodając, że &quot;sytuacja jest w pełni kontrolowana, choć nie jest łatwa&quot;. Ataki przeprowadzone przez Rosjan na infrastrukturę energetyczną, które sparaliżowały dostawy w mieście, nastąpiły, gdy w Odessie udało się...</p><br clear="all" />

## Akcja na granicy z Białorusią. Próbowali sforsować rzekę
 - [https://wydarzenia.interia.pl/podlaskie/news-akcja-na-granicy-z-bialorusia-probowali-sforsowac-rzeke,nId,6468015](https://wydarzenia.interia.pl/podlaskie/news-akcja-na-granicy-z-bialorusia-probowali-sforsowac-rzeke,nId,6468015)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 09:02:37+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-akcja-na-granicy-z-bialorusia-probowali-sforsowac-rzeke,nId,6468015"><img align="left" alt="Akcja na granicy z Białorusią. Próbowali sforsować rzekę" src="https://i.iplsc.com/akcja-na-granicy-z-bialorusia-probowali-sforsowac-rzeke/000FCIZLFIB2DN72-C321.jpg" /></a>Kolejna akcja Straży Granicznej na granicy Polski i Białorusi. Jak czytamy w komunikacie, na teren naszego państwa próbowało nielegalnie wtargnąć 82 migrantów. Chodzi m.in. o obywateli Egiptu, Sudanu i Kuby. Mimo złej pogody kilkanaście osób zdecydowało się na przepłynięcie granicznej rzeki Świsłocz. </p><br clear="all" />

## Wsparcie w wojnie. Łukaszenka potajemnie zbiera pieniądze rosyjskich rezerwistów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wsparcie-w-wojnie-lukaszenka-potajemnie-zbiera-pieniadze-ros,nId,6468010](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wsparcie-w-wojnie-lukaszenka-potajemnie-zbiera-pieniadze-ros,nId,6468010)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 08:59:10+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wsparcie-w-wojnie-lukaszenka-potajemnie-zbiera-pieniadze-ros,nId,6468010"><img align="left" alt="Wsparcie w wojnie. Łukaszenka potajemnie zbiera pieniądze rosyjskich rezerwistów" src="https://i.iplsc.com/wsparcie-w-wojnie-lukaszenka-potajemnie-zbiera-pieniadze-ros/000GH4ME6X655A3I-C321.jpg" /></a>&quot;Niezwykle mało prawdopodobne&quot; - tak amerykański Instytut Badań nad Wojną (ISW) ocenia włączenie się białoruskiej armii do wojny w Ukrainie. Nie oznacza to jednak, że Alaksandr Łukaszenka nie ma wkładu w rosyjską agresję. Białoruś udostępniła swoje terytorium do ataku na Ukrainę, szkoli rosyjskich żołnierzy, a także potajemnie zbiera pieniądze dla rezerwistów. </p><br clear="all" />

## Wiceminister finansów: W styczniu i lutym inflacja prawdopodobnie przekroczy 19 proc.
 - [https://wydarzenia.interia.pl/kraj/news-wiceminister-finansow-w-styczniu-i-lutym-inflacja-prawdopodo,nId,6467966](https://wydarzenia.interia.pl/kraj/news-wiceminister-finansow-w-styczniu-i-lutym-inflacja-prawdopodo,nId,6467966)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 08:45:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wiceminister-finansow-w-styczniu-i-lutym-inflacja-prawdopodo,nId,6467966"><img align="left" alt="Wiceminister finansów: W styczniu i lutym inflacja prawdopodobnie przekroczy 19 proc." src="https://i.iplsc.com/wiceminister-finansow-w-styczniu-i-lutym-inflacja-prawdopodo/000GH448EN180F23-C321.jpg" /></a>- W styczniu i w lutym inflacja będzie pewnie jeszcze wyższa niż w październiku, ale marzec będzie już okresem silnej dezinflacji - ocenia w rozmowie z Interią Piotr Patkowski. Wiceminister finansów przyznaje także, że pieniądze z KPO są Polsce bardzo potrzebne i dodaje, że byłoby dobrze, gdyby zrozumieli to wszyscy koalicjanci Zjednoczonej Prawicy. Patkowski przy okazji podpisuje się pod stwierdzeniem, że prezes PiS Jarosław Kaczyński &quot;zna się na finansach lepiej niż minister finansów&quot;. </p><br clear="all" />

## Płonie centrum handlowe nieopodal Moskwy. Jedna osoba ranna
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-plonie-centrum-handlowe-nieopodal-moskwy-jedna-osoba-ranna,nId,6467979](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-plonie-centrum-handlowe-nieopodal-moskwy-jedna-osoba-ranna,nId,6467979)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 08:08:47+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-plonie-centrum-handlowe-nieopodal-moskwy-jedna-osoba-ranna,nId,6467979"><img align="left" alt="Płonie centrum handlowe nieopodal Moskwy. Jedna osoba ranna" src="https://i.iplsc.com/plonie-centrum-handlowe-nieopodal-moskwy-jedna-osoba-ranna/000GH45L1WIVWUJ7-C321.jpg" /></a>Płonie centrum handlowe w Stroypark w mieście Bałaszycha, które znajduje się na wschód od Moskwy. Służby ratunkowe przekazały, że ranny został pracownik ochrony. To kolejny pożar w Rosji w ostatnich dniach. W piątek doszło do dwóch takich zdarzeń - w Moskwie i Barnauł.</p><br clear="all" />

## Solarny dach albo panele w ogrodzeniu. Nowe pomysły na fotowoltaikę
 - [https://wydarzenia.interia.pl/nauka/news-solarny-dach-albo-panele-w-ogrodzeniu-nowe-pomysly-na-fotowo,nId,6456060](https://wydarzenia.interia.pl/nauka/news-solarny-dach-albo-panele-w-ogrodzeniu-nowe-pomysly-na-fotowo,nId,6456060)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 07:57:57+00:00

<p><a href="https://wydarzenia.interia.pl/nauka/news-solarny-dach-albo-panele-w-ogrodzeniu-nowe-pomysly-na-fotowo,nId,6456060"><img align="left" alt="Solarny dach albo panele w ogrodzeniu. Nowe pomysły na fotowoltaikę " src="https://i.iplsc.com/solarny-dach-albo-panele-w-ogrodzeniu-nowe-pomysly-na-fotowo/000GG5BCPXMBQSQE-C321.jpg" /></a>Fotowoltaika to bardzo szybko rozwijająca się gałąź odnawialnych źródeł energii. Pokusa taniego prądu sprawia, że coraz więcej konsumentów sięga po panele słoneczne. Czy jednak zawsze trzeba układać je na dachu? Oto cztery nowe propozycje - dwie już dostępne na rynku, a dwie wciąż w fazie dopracowywania.</p><br clear="all" />

## Rosyjscy neonaziści szpiegują kraje bałtyckie. Media o możliwych atakach
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjscy-neonazisci-szpieguja-kraje-baltyckie-media-o-mozliw,nId,6467938](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjscy-neonazisci-szpieguja-kraje-baltyckie-media-o-mozliw,nId,6467938)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 07:54:18+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjscy-neonazisci-szpieguja-kraje-baltyckie-media-o-mozliw,nId,6467938"><img align="left" alt="Rosyjscy neonaziści szpiegują kraje bałtyckie. Media o możliwych atakach" src="https://i.iplsc.com/rosyjscy-neonazisci-szpieguja-kraje-baltyckie-media-o-mozliw/000GH3XBOQMVNJUK-C321.jpg" /></a>Rosyjska neonazistowska bojówka z grupy rozpoznania dywersyjnego i szturmowego &quot;Rusicz&quot; zbiera dane wywiadowcze na temat aktywności granicznej i wojskowej na Łotwie, Litwie i w Estonii - poinformował brytyjski &quot;The Guardian&quot;. Może to wskazywać na planowany atak terrorystyczny w krajach bałtyckich. Chodzi zwłaszcza o informacje dotyczące rozmieszczenia jednostek wojskowych, posterunków straży granicznej oraz personaliów funkcjonariuszy i ich pojazdów.</p><br clear="all" />

## Andrzej Duda w Berlinie. Spotka się z prezydentem Steinmeierem
 - [https://wydarzenia.interia.pl/kraj/news-andrzej-duda-w-berlinie-spotka-sie-z-prezydentem-steinmeiere,nId,6467962](https://wydarzenia.interia.pl/kraj/news-andrzej-duda-w-berlinie-spotka-sie-z-prezydentem-steinmeiere,nId,6467962)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 07:49:26+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-andrzej-duda-w-berlinie-spotka-sie-z-prezydentem-steinmeiere,nId,6467962"><img align="left" alt="Andrzej Duda w Berlinie. Spotka się z prezydentem Steinmeierem" src="https://i.iplsc.com/andrzej-duda-w-berlinie-spotka-sie-z-prezydentem-steinmeiere/0007DU3JKGKJX62S-C321.jpg" /></a>W poniedziałek prezydent Andrzej Duda udaje się do Niemiec, gdzie spotka się z Frankiem-Walterem Steinmeierem. Jak zapowiadano przed wizytą głowy państwa w Berlinie, tematami rozmów Dudy ze Steinmeierem mają być bezpieczeństwo, kryzys humanitarny w Ukrainie oraz relacje dwustronne między Polską a Niemcami.</p><br clear="all" />

## Pogoda zaskoczyła kierowców. Niż Brygida przyniósł sporo śniegu
 - [https://wydarzenia.interia.pl/kraj/news-pogoda-zaskoczyla-kierowcow-niz-brygida-przyniosl-sporo-snie,nId,6467952](https://wydarzenia.interia.pl/kraj/news-pogoda-zaskoczyla-kierowcow-niz-brygida-przyniosl-sporo-snie,nId,6467952)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 07:27:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogoda-zaskoczyla-kierowcow-niz-brygida-przyniosl-sporo-snie,nId,6467952"><img align="left" alt="Pogoda zaskoczyła kierowców. Niż Brygida przyniósł sporo śniegu" src="https://i.iplsc.com/pogoda-zaskoczyla-kierowcow-niz-brygida-przyniosl-sporo-snie/000GH3TSKORQIC5N-C321.jpg" /></a>Polska znalazła się pod białym puchem. Wszystko z powodu niżu Brygida, który do kraju nad Wisłą przyniósł duże pokłady śniegu. Ten przysypał nie tylko podwórka i pola, ale też drogi i chodniki. Co chwila pojawiają się informacje o problemach drogowców i kierowców. Tylko w niedzielę straż pożarna musiała interweniować ponad 600 razy. Niż Brygida dał się we znaki także w Londynie.</p><br clear="all" />

## Iran: Dokonano drugiej egzekucji uczestnika antyrządowych protestów
 - [https://wydarzenia.interia.pl/zagranica/news-iran-dokonano-drugiej-egzekucji-uczestnika-antyrzadowych-pro,nId,6467940](https://wydarzenia.interia.pl/zagranica/news-iran-dokonano-drugiej-egzekucji-uczestnika-antyrzadowych-pro,nId,6467940)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 07:20:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-iran-dokonano-drugiej-egzekucji-uczestnika-antyrzadowych-pro,nId,6467940"><img align="left" alt="Iran: Dokonano drugiej egzekucji uczestnika antyrządowych protestów" src="https://i.iplsc.com/iran-dokonano-drugiej-egzekucji-uczestnika-antyrzadowych-pro/000GH3OA78J0F6J9-C321.jpg" /></a>W Iranie dokonano drugiej egzekucji uczestnika antyrządowych protestów, 23-letniego Madżidreza Rahnawarda - przekazała w poniedziałek agencja AP. Rahnaward został stracony za rzekome rzekome śmiertelne ugodzenie nożem dwóch funkcjonariuszy służb bezpieczeństwa i ranienie czterech kolejnych. Według Amnesty International w roku 2021 w Iranie wykonano co najmniej 314 wyroków śmierci. </p><br clear="all" />

## Prognoza: Nawet -16 stopni C. Przed nami prawdziwe uderzenie zimy
 - [https://wydarzenia.interia.pl/kraj/news-prognoza-nawet-16-stopni-c-przed-nami-prawdziwe-uderzenie-zi,nId,6467912](https://wydarzenia.interia.pl/kraj/news-prognoza-nawet-16-stopni-c-przed-nami-prawdziwe-uderzenie-zi,nId,6467912)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 07:03:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prognoza-nawet-16-stopni-c-przed-nami-prawdziwe-uderzenie-zi,nId,6467912"><img align="left" alt="Prognoza: Nawet -16 stopni C. Przed nami prawdziwe uderzenie zimy" src="https://i.iplsc.com/prognoza-nawet-16-stopni-c-przed-nami-prawdziwe-uderzenie-zi/000GH3KG3FWANGA6-C321.jpg" /></a>W poniedziałek w całym kraju prognozowane są opady śniegu - w związku z ich intensywnością Instytut Meteorologii i Gospodarki Wodnej wydał ostrzeżenia pierwszego i drugiego stopnia. Alerty dotyczą także możliwych śnieżyc i zawiei. W ciągu rozpoczynającego się tygodnia zima nie odpuści. Synoptycy prognozują, że w środę temperatury w części kraju mogą spaść do minus 16 stopni. </p><br clear="all" />

## Tarzymiechy: Pożar ciężarówki. Utrudnienia na DK 17
 - [https://wydarzenia.interia.pl/lubelskie/news-tarzymiechy-pozar-ciezarowki-utrudnienia-na-dk-17,nId,6467941](https://wydarzenia.interia.pl/lubelskie/news-tarzymiechy-pozar-ciezarowki-utrudnienia-na-dk-17,nId,6467941)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 06:55:47+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-tarzymiechy-pozar-ciezarowki-utrudnienia-na-dk-17,nId,6467941"><img align="left" alt="Tarzymiechy: Pożar ciężarówki. Utrudnienia na DK 17" src="https://i.iplsc.com/tarzymiechy-pozar-ciezarowki-utrudnienia-na-dk-17/000GH3KURSO3EQIC-C321.jpg" /></a>Pożar ciężarówki na drodze krajowej nr 17 na wysokości miejscowości Tarzymiechy między Krasnymstawem a Zamościem. Droga jest zablokowana, a na miejscu trwa akcja gaśnicza. Utrudnienia mogą potrwać około trzech godzin.</p><br clear="all" />

## Biała zima w Polsce [ZDJĘCIA]
 - [https://wydarzenia.interia.pl/galerie/kraj/zdjecie,iId,3280585,iAId,442086](https://wydarzenia.interia.pl/galerie/kraj/zdjecie,iId,3280585,iAId,442086)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 06:28:16+00:00

<p><a href="https://wydarzenia.interia.pl/galerie/kraj/zdjecie,iId,3280585,iAId,442086"><img align="left" alt="Biała zima w Polsce [ZDJĘCIA]" src="https://i.iplsc.com/biala-zima-w-polsce-zdjecia/000GH3IKMR2XL5W6-C321.jpg" /></a>Niż Brygida przyniósł do Polski intensywne opady śniegu. W niedzielę Państwowa Straż Pożarna interweniowała ponad 600 razy w związku z opadami śniegu - poinformował rzecznik prasowy PSP bryg. Karol Kierzkowski. Najwięcej wyjazdów odnotowano w województwie małopolskim. Tymczasem - jak wynika z najnowszych prognoz, białego puchu będzie jeszcze więcej. Największe opady - jak podaje IMGW - są spodziewane na północy, wschodzie oraz w rejonach podgórskich kraju.</p><br clear="all" />

## Premier zapowiada: 13. i 14. emerytura będą utrzymane
 - [https://wydarzenia.interia.pl/kraj/news-premier-zapowiada-13-i-14-emerytura-beda-utrzymane,nId,6467923](https://wydarzenia.interia.pl/kraj/news-premier-zapowiada-13-i-14-emerytura-beda-utrzymane,nId,6467923)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 06:15:56+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-zapowiada-13-i-14-emerytura-beda-utrzymane,nId,6467923"><img align="left" alt="Premier zapowiada: 13. i 14. emerytura będą utrzymane" src="https://i.iplsc.com/premier-zapowiada-13-i-14-emerytura-beda-utrzymane/000G8BFXB4QAAJTK-C321.jpg" /></a>- Jeśli będziemy nadal rządzić, trzynastka i czternastka będą utrzymane. Wpiszemy 14. emeryturę do ustawy, aby była dodatkiem sformalizowanym - stwierdził premier Mateusz Morawiecki. Jak dodał, na wsparcie emerytów w przyszłym roku zostanie przeznaczone w sumie 70 mld zł.</p><br clear="all" />

## Premier zapowiada: Trzynasta i czternasta emerytura będą utrzymane
 - [https://wydarzenia.interia.pl/kraj/news-premier-zapowiada-trzynasta-i-czternasta-emerytura-beda-utrz,nId,6467923](https://wydarzenia.interia.pl/kraj/news-premier-zapowiada-trzynasta-i-czternasta-emerytura-beda-utrz,nId,6467923)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 06:15:56+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-zapowiada-trzynasta-i-czternasta-emerytura-beda-utrz,nId,6467923"><img align="left" alt="Premier zapowiada: Trzynasta i czternasta emerytura będą utrzymane" src="https://i.iplsc.com/premier-zapowiada-trzynasta-i-czternasta-emerytura-beda-utrz/000G8BFXB4QAAJTK-C321.jpg" /></a>- Jeśli będziemy nadal rządzić, trzynastka i czternastka będą utrzymane. Wpiszemy 14. emeryturę do ustawy, aby była dodatkiem sformalizowanym - stwierdził premier Mateusz Morawiecki. Jak dodał, na wsparcie emerytów w przyszłym roku zostanie przeznaczone w sumie 70 mld zł.</p><br clear="all" />

## Witamina D a demencja. Najnowsze ustalenia naukowców
 - [https://wydarzenia.interia.pl/zagranica/news-witamina-d-a-demencja-najnowsze-ustalenia-naukowcow,nId,6467911](https://wydarzenia.interia.pl/zagranica/news-witamina-d-a-demencja-najnowsze-ustalenia-naukowcow,nId,6467911)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 05:48:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-witamina-d-a-demencja-najnowsze-ustalenia-naukowcow,nId,6467911"><img align="left" alt="Witamina D a demencja. Najnowsze ustalenia naukowców " src="https://i.iplsc.com/witamina-d-a-demencja-najnowsze-ustalenia-naukowcow/000F9F45UD9659SB-C321.jpg" /></a>Obecność witaminy D w mózgu pomaga chronić seniorów przed objawami demencji – wynika z analizy naukowców opublikowanej w piśmie &quot;Alzheimer's &amp; Dementia&quot;. Chociaż wykazano, że witamina ta przekłada się na lepszą sprawność umysłową, to wciąż nie jest jasne, w jaki sposób dokładnie wpływa na funkcjonowanie organu.</p><br clear="all" />

## Ukraina. Dmytro Kułeba: Nie ma potrzeby udzielania Ukrainie lekcji moralności
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-dmytro-kuleba-nie-ma-potrzeby-udzielania-ukrainie-le,nId,6467908](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-dmytro-kuleba-nie-ma-potrzeby-udzielania-ukrainie-le,nId,6467908)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 05:31:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-dmytro-kuleba-nie-ma-potrzeby-udzielania-ukrainie-le,nId,6467908"><img align="left" alt="Ukraina. Dmytro Kułeba: Nie ma potrzeby udzielania Ukrainie lekcji moralności" src="https://i.iplsc.com/ukraina-dmytro-kuleba-nie-ma-potrzeby-udzielania-ukrainie-le/000GH3EF04LOLY3H-C321.jpg" /></a>Ukraina dostaje niemiecką broni - tylko jaką? Nie dostajemy, przynajmniej na razie, czołgów Leopard 2, których potrzebujemy najbardziej - przekazał minister spraw zagranicznych Ukrainy Dmytro Kułeba w niemieckiej telewizji ARD. - Nie ma potrzeby udzielania Ukrainie lekcji moralności - mówił, odnosząc się do krytyki o rzekomych ukraińskich atakach na terytorium Rosji. </p><br clear="all" />

## Rozpoczęły się szczepienia przeciw COVID-19 dla półrocznych dzieci
 - [https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-rozpoczely-sie-szczepienia-przeciw-covid-19-dla-polrocznych-,nId,6467905](https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-rozpoczely-sie-szczepienia-przeciw-covid-19-dla-polrocznych-,nId,6467905)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 05:15:46+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-rozpoczely-sie-szczepienia-przeciw-covid-19-dla-polrocznych-,nId,6467905"><img align="left" alt="Rozpoczęły się szczepienia przeciw COVID-19 dla półrocznych dzieci" src="https://i.iplsc.com/rozpoczely-sie-szczepienia-przeciw-covid-19-dla-polrocznych/000GH3DZDXK4TSH5-C321.jpg" /></a>Dzieci w wieku od 6 miesięcy do 4 lat mogą od poniedziałku otrzymać szczepionkę przeciw COVID-19. W nocy z 11 na 12 grudnia wystawiono niemal 2 miliony e-skierowań. Szczepienie podstawowe składa się z trzech dawek preparatu: dwóch podawanych w odstępie trzech tygodni i trzeciej, po ośmiu tygodniach od przyjęcia poprzedniej dawki.</p><br clear="all" />

## Wojna w Ukrainie. 292. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo,nzId,3507,akt,120602](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo,nzId,3507,akt,120602)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 04:49:10+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo,nzId,3507,akt,120602"><img align="left" alt="Wojna w Ukrainie. 292. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo/000GH3D282JLD291-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 292. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo,nzId,3507,akt,120650](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo,nzId,3507,akt,120650)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 04:49:10+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo,nzId,3507,akt,120650"><img align="left" alt="Wojna w Ukrainie. 292. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo/000GH3D282JLD291-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 292. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo,nzId,3507,akt,120801](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo,nzId,3507,akt,120801)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-12 04:49:10+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo,nzId,3507,akt,120801"><img align="left" alt="Wojna w Ukrainie. 292. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-292-dzien-inwazji-rosji-relacja-na-zywo/000GH3D282JLD291-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />


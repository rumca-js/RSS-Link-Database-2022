# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Major Nuclear Fusion Energy Breakthrough to Be Announced by Scientists
 - [https://www.nytimes.com/2022/12/12/science/nuclear-fusion-energy-breakthrough.html](https://www.nytimes.com/2022/12/12/science/nuclear-fusion-energy-breakthrough.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-12-12 18:24:34+00:00

Researchers working with lasers at Lawrence Livermore National Laboratory are expected to say they made a major advance that could lead to future energy sources.

## China Maps Out Plans to Put Astronauts on the Moon and on Mars
 - [https://www.nytimes.com/2022/12/12/science/china-space-moon-mars.html](https://www.nytimes.com/2022/12/12/science/china-space-moon-mars.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-12-12 18:20:34+00:00

Chinese officials at a desert rocket base described plans for their new space station and for reusable rockets, as well as travel beyond near-Earth orbit.

## Why Some Scientists Choose China’s Space Station for Research
 - [https://www.nytimes.com/2022/12/12/science/tiangong-science-physics.html](https://www.nytimes.com/2022/12/12/science/tiangong-science-physics.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-12-12 18:19:13+00:00

A project led by researchers from a Swiss university highlights China’s ambition to make the Tiangong outpost broadly available for science.


# Source:Filmento, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG_nvdTLdijiAAuPKxtvBjA, language:en-US

## 300: Rise of an Empire — The Successor that Cancelled a Series | Anatomy of a Failure
 - [https://www.youtube.com/watch?v=P9DFrSLIIuU](https://www.youtube.com/watch?v=P9DFrSLIIuU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG_nvdTLdijiAAuPKxtvBjA
 - date published: 2022-12-12 20:59:15+00:00

Get 22-33% off ALL posters on Displate's site for Xmas (discount applies automatically at checkout): https://displate.com/promo/filmento?art=5f1ae994a3377

300: Rise of an Empire is a 2014 successor to Zack Snyder's legendary 2006 testosterone movie 300, about the stand made against the Persian army by Leonidas and his Spartans. This time the focus is on the sea, where the Athens navy faces off with the mighty Persian fleet. And the movie didn't turn out too well, because it flopped pretty badly at the box office compared to the predecessor and thus got the whole series of 300 movies cancelled. Bye bye 300: American Revolutionary war. And the biggest issue about Rise of an Empire could be that it fails to follow the rules of the series established by the first movie. So today, let's investigate the importance of rules in a series, and how Rise of an Empire fails to live up to 300 and got the whole franchise cancelled.

Support:     https://patreon.com/filmento
Follow:        https://twitter.com/filmento

Filmento en Español: 
https://youtu.be/ViDZUofaZd8

#300     #anatomyofafailure

Music:



-
300: Rise of an Empire (2014)
Greek general Themistokles (Sullivan Stapleton) assembles his troops to fend off an invading Persian army led by the immortal Xerxes (Rodrigo Santoro) and the vindictive Persian navy commander Artemisia (Eva Green) in this sequel to 300 based on the graphic novel Xerses by Frank Miller. In the wake of the Persians' victory over King Leonidas and his 300 Spartans, the God King Xerxes (Santoro) appears poised to conquer Greece. As the ruthless Artemisia (Eva Green) assembles a massive fleet of ships and sets sail for conquest, Greek general Themistokles (Sullivan Stapleton) strives to rally his countrymen to fight for freedom, and he manages to gain the upper hand over the invaders by confronting them at sea. Meanwhile, Leonidas' former advisor and wife Queen Gorgo (Lena Headey) is reluctant to sacrifice any more Spartans in a fight that appears to be unwinnable. When the Greeks enjoy an early victory over Artemisia and her soldiers, however, it appears that Themistokles' unconventional tactics are more effective than the Persian Empire's formidable 300 Rise of an empire only action best scenes everything wrong with 300 rise of an empire honest trailers bad movie great movie 300 sequel 300 3 third movie zack snyder why did rise of an empire fail flop box office flop rise of an empire best moments fight battle 300 fight scenes brawn. But later, after Artemisia's attempt to seduce Themistokles to her side proves unsuccessful, the spurned naval commander deals a devastating blow to her Greek opponents. In the aftermath of that skirmish, Themistokles is presumed dead and Athens falls. The Persian Empire seems on the verge of victory, though when Xerxes and Artemisia learn that Themistokles lives, they realize the fight won't be over until he takes his final breath.
-
300 (2006)
Sin City author Frank Miller's sweeping take on the historic Battle of Thermopylae comes to the screen courtesy of Dawn of the Dead director Zack Snyder. Gerard Butler stars as Spartan King Leonidas and Lena Headey plays Queen Gorgo. The massive army of the Persian Empire is sweeping across the globe, crushing every force that dares stand in its path. When a Persian envoy arrives in Sparta offering King Leonidas power over all of Greece if he will only bow to the will of the all powerful Xerxes (Rodrigo Santoro), the strong-willed leader assembles a small army comprised of his empire's best fighters and marches off to battle. Though they have virtually no hope of defeating Xerxes' intimidating battalion, Leonidas' men soldier on, intent on letting it be known they will bow to no man but their king. Meanwhile, back in Sparta, the loyal Queen Gorgo attempts to convince both the skeptical council and the devious Theron (Dominic West) to send more troops despite the fact that many view Leonidas' unsanctioned war march as a serious transgression. As Xerxes' fearsome "immortals" draw near, a few noble Greeks vow to assist the Spartans on the battlefield. When King Leonidas and his 300 Spartan warriors fell to the overwhelming Persian army at the Battle of Thermopylae, the fearless actions of the noble fighters inspired all of Greece to stand up against their Persian enemy and wage the battle that would ultimately give birth to the modern concept of democracy.~Jason Buchanan


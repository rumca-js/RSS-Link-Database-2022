## In wider diversity push, Norway proposes 40% gender quota for large unlisted firms | Reuters
 - [https://www.reuters.com/business/wider-diversity-push-norway-proposes-40-gender-quota-large-unlisted-firms-2022-12-12/](https://www.reuters.com/business/wider-diversity-push-norway-proposes-40-gender-quota-large-unlisted-firms-2022-12-12/)
 - RSS feed: https://www.reuters.com
 - date published: 2022-12-12 21:04:56+00:00

In wider diversity push, Norway proposes 40% gender quota for large unlisted firms | Reuters


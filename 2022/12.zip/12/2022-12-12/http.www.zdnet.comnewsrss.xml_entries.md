# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## Despite the gloomy headlines, demand for tech skills is strong
 - [https://www.zdnet.com/article/despite-the-gloomy-headlines-demand-for-tech-skills-is-strong/#ftag=RSSbaffb68](https://www.zdnet.com/article/despite-the-gloomy-headlines-demand-for-tech-skills-is-strong/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 23:25:00+00:00

Paychex exec: 'As businesses continue to adapt to technology, technology professionals with business acumen remain extremely sought after.'

## What is OpenIndiana and why does it matter?
 - [https://www.zdnet.com/article/what-is-openindiana-and-why-does-it-matter/#ftag=RSSbaffb68](https://www.zdnet.com/article/what-is-openindiana-and-why-does-it-matter/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 21:54:14+00:00

If you miss Solaris, you'll be glad to hear it's been revived as OpenIndiana.

## The 5 best gaming mice of 2022
 - [https://www.zdnet.com/home-and-office/home-entertainment/best-gaming-mouse/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/best-gaming-mouse/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 21:27:00+00:00

A gaming mouse can make all the difference in online matches or solo missions. With programmable buttons and ergonomic designs, gaming mice are built from the ground up to give you the best experience -- and they're great for everyday work, too.

## Ember smart mug deal: Save $30 on the 10-ounce mug
 - [https://www.zdnet.com/home-and-office/smart-home/ember-smart-mug-deal-sale/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/ember-smart-mug-deal-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 21:12:00+00:00

Ideal for coffee or tea enthusiasts, the Ember smart mug can keep your beverages toasty warm this holiday season.

## Best Buy's 'always-on' Samsung wearables sale: Save $50 on a Galaxy Watch 5 or 5 Pro
 - [https://www.zdnet.com/article/best-buy-always-on-samsung-wearables-sale-galaxy-watch-deals/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-buy-always-on-samsung-wearables-sale-galaxy-watch-deals/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 20:44:00+00:00

As part of Best Buy's 'always-on' Samsung Wearables sale, Galaxy watches are discounted by up to $50. These watches are perfect for the fitness enthusiast or just yourself this holiday season.

## 18 best Samsung deals: Galaxy phones, TVs, tech holiday sales
 - [https://www.zdnet.com/article/samsung-deals/#ftag=RSSbaffb68](https://www.zdnet.com/article/samsung-deals/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 20:22:00+00:00

Calling all Samsung fans! Let this hub serve as your home ground for the latest and best deals on Samsung Galaxy smartphones, wearables, TVs, appliances, and more.

## How to add RAM to a laptop
 - [https://www.zdnet.com/article/how-to-add-ram-to-a-laptop/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-add-ram-to-a-laptop/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 19:59:00+00:00

Is your laptop rather sluggish? Adding more RAM could give your system a new lease of life. Here's how to do it.

## The 5 best book lights of 2022
 - [https://www.zdnet.com/home-and-office/smart-home/best-book-light/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/best-book-light/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 19:46:00+00:00

If you have an avid reader on your holiday shopping list, a book light is a perfect gift. We found the best book lights for paperback and e-readers.

## Amazon Kindle Scribe review: 7 ways it could be even more remarkable
 - [https://www.zdnet.com/article/amazon-kindle-scribe-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/amazon-kindle-scribe-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 19:42:00+00:00

The Amazon Kindle Scribe is a valiant first attempt at cracking into the digital note-taking market. It has its flaws, but for my needs, the Scribe is good enough.

## Instagram is currently down
 - [https://www.zdnet.com/article/instagram-is-currently-down/#ftag=RSSbaffb68](https://www.zdnet.com/article/instagram-is-currently-down/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 19:28:39+00:00

If your Instagram feed is not refreshing or you can't access your profile, don't worry, its not just you.

## The 10 best large monitors of 2023
 - [https://www.zdnet.com/home-and-office/smart-office/best-large-monitor/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-office/best-large-monitor/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 19:08:00+00:00

If you need to toggle between programs, design, or have a full range of view for gaming, the best large monitors will make your life easier. They also offer fast refresh rates, exceptional resolution, and much more.

## The 5 best ergonomic mice of 2022
 - [https://www.zdnet.com/home-and-office/smart-office/best-ergonomic-mouse/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-office/best-ergonomic-mouse/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 19:07:00+00:00

What is the best ergonomic mouse? The Logitech MX Vertical takes our top spot! We analyzed configuration, compatibility, comfort, and more below.

## How high performing sales teams use technology to win in today's economy
 - [https://www.zdnet.com/article/how-high-performing-sales-teams-use-technology-to-win-in-todays-economy/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-high-performing-sales-teams-use-technology-to-win-in-todays-economy/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 17:51:56+00:00

Insights from more than 7,700 sales professionals on driving productivity reveals that selling is harder now than before the pandemic. Nonetheless, most sellers see a clear path forward by leaning more into technology.

## LG C2 42-inch OLED TV drops to $800 -- that's $500 off
 - [https://www.zdnet.com/home-and-office/home-entertainment/lg-c2-42-inch-oled-tv-deal/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/lg-c2-42-inch-oled-tv-deal/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 17:48:17+00:00

LG's most popular TV just dropped to less than $1,000. Get it while supplies last.

## The future of finance belongs to open source
 - [https://www.zdnet.com/finance/the-future-of-finance-belongs-to-open-source/#ftag=RSSbaffb68](https://www.zdnet.com/finance/the-future-of-finance-belongs-to-open-source/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 17:48:06+00:00

The Fintech Open Source Foundation has found banks and other financial organizations are no longer just using open-source software, they're building and sharing it.

## You've got Mastodon questions, I've got answers
 - [https://www.zdnet.com/article/youve-got-mastodon-questions-weve-got-answers/#ftag=RSSbaffb68](https://www.zdnet.com/article/youve-got-mastodon-questions-weve-got-answers/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 17:27:04+00:00

Mastodon has been attracting Twitter expatriates at a brisk pace. If you've set up an account on this federated social media network, you're probably wondering just how things work. I've been gathering questions from Mastodon newcomers and have some answers here.

## How to enable folder colors in Ubuntu-based Linux distributions
 - [https://www.zdnet.com/article/how-to-enable-folder-colors-in-ubuntu-based-linux-distributions/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-enable-folder-colors-in-ubuntu-based-linux-distributions/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 17:08:15+00:00

In a bid to make the Ubuntu default file manager easier to use, a new feature called Folder's Color can be installed. Now you can better tell what's what in your file manager.

## I'm a keyboard enthusiast and this is the best gaming keyboard right now
 - [https://www.zdnet.com/article/wooting-60he-gaming-keyboard-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/wooting-60he-gaming-keyboard-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 16:46:00+00:00

Review: The wildly in-demand Wooting 60HE keyboard delivers the biggest shock to the PC gaming peripheral world in years.

## Heybike Cityrun review: The perfect e-bike for commuting
 - [https://www.zdnet.com/article/heybike-cityrun-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/heybike-cityrun-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 16:33:38+00:00

The Heybike Cityrun stands out for safety and security features, and even has a place to put your water bottle.

## How to record your screen in Windows with Xbox Game Bar
 - [https://www.zdnet.com/article/how-to-record-your-screen-in-windows-with-xbox-game-bar/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-record-your-screen-in-windows-with-xbox-game-bar/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 16:29:56+00:00

Windows 10 and 11 both offer a screen recording tool that's geared for gameplay but can record just about any type of screen activity.

## Are massage guns worth it? Only if you find feeling better valuable
 - [https://www.zdnet.com/article/are-massage-guns-worth-it-only-if-you-find-feeling-better-valuable/#ftag=RSSbaffb68](https://www.zdnet.com/article/are-massage-guns-worth-it-only-if-you-find-feeling-better-valuable/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 16:26:58+00:00

There's only one inconvenient drawback to this fine machine.

## The 5 best small tablets of 2023
 - [https://www.zdnet.com/article/best-small-tablet/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-small-tablet/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 16:23:00+00:00

Not all devices need the biggest screen. Sometimes, you want something small and portable, especially during holiday travel. The best small tablets come from Apple, Amazon, and Samsung.

## This evasive new cyberattack can bypass air-gapped systems to steal data from the most sensitive networks
 - [https://www.zdnet.com/article/this-evasive-new-cyberattack-can-bypass-air-gapped-systems-to-steal-data-from-the-most-sensitive-networks/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-evasive-new-cyberattack-can-bypass-air-gapped-systems-to-steal-data-from-the-most-sensitive-networks/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 15:37:08+00:00

Cybersecurity researchers at Ben-Gurion University demonstrate a novel technique that steals data using electromagnetic radiation and a $1 antenna.

## 100,000 Raspberry Pi units go to resellers now, but Pi Zero sees a price hike
 - [https://www.zdnet.com/article/100000-raspberry-pi-units-go-to-resellers-now-but-pi-zero-sees-a-price-hike/#ftag=RSSbaffb68](https://www.zdnet.com/article/100000-raspberry-pi-units-go-to-resellers-now-but-pi-zero-sees-a-price-hike/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 15:27:43+00:00

More Pi Zero W, 3A+ and 2GB/4GB Raspberry Pi 4s are available ahead of the holiday season.

## I survived using my iPad Pro as my main desktop PC for a day (mostly)
 - [https://www.zdnet.com/article/i-survived-using-my-ipad-pro-as-my-main-desktop-pc-for-a-day-mostly/#ftag=RSSbaffb68](https://www.zdnet.com/article/i-survived-using-my-ipad-pro-as-my-main-desktop-pc-for-a-day-mostly/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 15:02:00+00:00

Can a diehard desktop PC and Mac user be happy using an iPad Pro for work? Let's find out

## Roku Stick vs Fire TV Stick: Which is right for your streaming needs?
 - [https://www.zdnet.com/article/amazon-fire-tv-stick-vs-roku-streaming-stick/#ftag=RSSbaffb68](https://www.zdnet.com/article/amazon-fire-tv-stick-vs-roku-streaming-stick/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 14:00:00+00:00

Out of the abundance of streaming devices on the market, two have dominated for years: the Roku Streaming Stick and the Fire TV Stick. But how do you choose the best one for your TV streaming habits?

## Roku Stick vs Fire TV Stick: Which is right for your streaming needs?
 - [https://www.zdnet.com/article/roku-stick-vs-fire-tv-which-is-right-for-your-streaming-needs/#ftag=RSSbaffb68](https://www.zdnet.com/article/roku-stick-vs-fire-tv-which-is-right-for-your-streaming-needs/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 14:00:00+00:00

Out of the abundance of streaming devices on the market, two have dominated for years: The Roku Streaming Stick and the Fire TV Stick. But how do you choose the best one for your TV streaming habits?

## Linux 6.1 stable lands as Linus Torvalds frets over a frantic pre-holidays 6.2 merge
 - [https://www.zdnet.com/article/linux-6-1-stable-lands-as-linus-torvalds-frets-over-a-frantic-pre-holidays-6-2-merge/#ftag=RSSbaffb68](https://www.zdnet.com/article/linux-6-1-stable-lands-as-linus-torvalds-frets-over-a-frantic-pre-holidays-6-2-merge/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 13:31:40+00:00

Linus Torvalds is happy with some early pull requests after blasting developers for late submissions, and says he'll maintain strict rules to keep the merge window calm as the holiday season approaches.

## Orion parachute splashdown completes Artemis I moon mission
 - [https://www.zdnet.com/article/orion-parachute-splashdown-completes-artemis-i-moon-mission/#ftag=RSSbaffb68](https://www.zdnet.com/article/orion-parachute-splashdown-completes-artemis-i-moon-mission/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 13:12:45+00:00

NASA's Orion spacecraft for the Artemis I mission has successfully splashed down and been retrieved from the Pacific Ocean for analysis.

## China wants legal sector to be AI-powered by 2025
 - [https://www.zdnet.com/article/china-wants-legal-sector-to-be-ai-powered-by-2025/#ftag=RSSbaffb68](https://www.zdnet.com/article/china-wants-legal-sector-to-be-ai-powered-by-2025/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 10:49:28+00:00

Supreme People's Court issues directive for an artificial intelligence network to be in place by 2025 to support and enhance legal services, but says court rulings will remain decisions made by judges.

## Muse 2 sleep, meditation smart headband is 20% off in new sale
 - [https://www.zdnet.com/home-and-office/muse-2-sleep-meditation-smart-headband-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/muse-2-sleep-meditation-smart-headband-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 09:48:06+00:00

If you're struggling to nod off during the night, this smart headband could be a great purchase to improve your well-being.

## Medibank systems back online after weekend shutdown for security update
 - [https://www.zdnet.com/article/medibank-systems-back-online-after-weekend-shutdown-for-security-update/#ftag=RSSbaffb68](https://www.zdnet.com/article/medibank-systems-back-online-after-weekend-shutdown-for-security-update/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-12 09:05:33+00:00

Australian insurance group brings in Microsoft to roll out "enhanced security operations", shutting down its systems including website and apps as well as retail outlets over the weekend for the upgrade.


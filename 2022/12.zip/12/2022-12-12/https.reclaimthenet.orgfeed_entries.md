# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## UK government asked Twitter and Facebook to “tweak” algorithms during Covid
 - [https://reclaimthenet.org/uk-government-asked-twitter-fb-tweak-algorithms/](https://reclaimthenet.org/uk-government-asked-twitter-fb-tweak-algorithms/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-12 23:57:38+00:00

<a href="https://reclaimthenet.org/uk-government-asked-twitter-fb-tweak-algorithms/" rel="nofollow" title="UK government asked Twitter and Facebook to &#8220;tweak&#8221; algorithms during Covid"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/hancock-w.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>And a Facebook executive was "happy to oblige."</p>
<p>The post <a href="https://reclaimthenet.org/uk-government-asked-twitter-fb-tweak-algorithms/" rel="nofollow">UK government asked Twitter and Facebook to &#8220;tweak&#8221; algorithms during Covid</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Protests and hunger strike take place at Apple’s HQ, after the company’s censorship in China and more
 - [https://reclaimthenet.org/protests-apple-park/](https://reclaimthenet.org/protests-apple-park/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-12 20:11:52+00:00

<a href="https://reclaimthenet.org/protests-apple-park/" rel="nofollow" title="Protests and hunger strike take place at Apple&#8217;s HQ, after the company&#8217;s censorship in China and more"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/apple-park.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Apple is getting more attention for helping the Chinese Communist Party censor critics.</p>
<p>The post <a href="https://reclaimthenet.org/protests-apple-park/" rel="nofollow">Protests and hunger strike take place at Apple&#8217;s HQ, after the company&#8217;s censorship in China and more</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Democrat Congressman Ro Khanna is open to investigating Big Tech’s political censorship
 - [https://reclaimthenet.org/ro-khanna-investigation-big-techs-political-censorship/](https://reclaimthenet.org/ro-khanna-investigation-big-techs-political-censorship/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-12 17:48:04+00:00

<a href="https://reclaimthenet.org/ro-khanna-investigation-big-techs-political-censorship/" rel="nofollow" title="Democrat Congressman Ro Khanna is open to investigating Big Tech&#8217;s political censorship"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/ro.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Khanna is the only Democrat who spoke out against Twitter's censorship of the Hunter Biden story.</p>
<p>The post <a href="https://reclaimthenet.org/ro-khanna-investigation-big-techs-political-censorship/" rel="nofollow">Democrat Congressman Ro Khanna is open to investigating Big Tech&#8217;s political censorship</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## The browser for those that like Firefox but think Mozilla lost its way
 - [https://reclaimthenet.org/the-browser-for-those-that-like-firefox-but-think-mozilla-lost-its-way/](https://reclaimthenet.org/the-browser-for-those-that-like-firefox-but-think-mozilla-lost-its-way/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-12 00:00:22+00:00

<a href="https://reclaimthenet.org/the-browser-for-those-that-like-firefox-but-think-mozilla-lost-its-way/" rel="nofollow" title="The browser for those that like Firefox but think Mozilla lost its way"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/lwolfw2.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>🛡</p>
<p>The post <a href="https://reclaimthenet.org/the-browser-for-those-that-like-firefox-but-think-mozilla-lost-its-way/" rel="nofollow">The browser for those that like Firefox but think Mozilla lost its way</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>


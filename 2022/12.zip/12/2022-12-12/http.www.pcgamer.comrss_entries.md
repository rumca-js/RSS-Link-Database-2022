# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## In 2022, battle royale finally got some real competition
 - [https://www.pcgamer.com/in-2022-battle-royale-finally-got-some-real-competition](https://www.pcgamer.com/in-2022-battle-royale-finally-got-some-real-competition)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 23:47:21+00:00

The state of extraction shooters at the end of 2022.

## The writer of Minecraft's ending poem wants to 'liberate it from the corporate economy'
 - [https://www.pcgamer.com/the-writer-of-minecrafts-ending-poem-wants-to-liberate-it-from-the-corporate-economy](https://www.pcgamer.com/the-writer-of-minecrafts-ending-poem-wants-to-liberate-it-from-the-corporate-economy)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 23:42:09+00:00

Julian Gough wrote the poem for Markus "Notch" Persson on spec, and says he never technically signed away his rights.

## The Grammy Awards videogame category is kind of a mess
 - [https://www.pcgamer.com/the-grammy-awards-videogame-category-is-kind-of-a-mess](https://www.pcgamer.com/the-grammy-awards-videogame-category-is-kind-of-a-mess)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 22:38:52+00:00

Part of the problem is the Grammy's old-school nomination process, but there are questions around eligibility timing too.

## PC Gamer's GOTY 2023 and end-of-year award nominees
 - [https://www.pcgamer.com/pc-gamer-nominees-goty-2023](https://www.pcgamer.com/pc-gamer-nominees-goty-2023)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 22:00:56+00:00

Which game will win Game of the Year?

## FromSoftware says Armored Core 6 won't emulate Dark Souls or Elden Ring, is all about mech customization
 - [https://www.pcgamer.com/fromsoftware-says-armored-core-6-wont-emulate-dark-souls-or-elden-ring-is-all-about-mech-customization](https://www.pcgamer.com/fromsoftware-says-armored-core-6-wont-emulate-dark-souls-or-elden-ring-is-all-about-mech-customization)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 22:00:53+00:00

The singleplayer story will be mission-based, and there'll be a separate versus mode.

## Hold onto your hats, Returnal PC system requirements recommends 32GB RAM
 - [https://www.pcgamer.com/returnal-pc-system-requirements](https://www.pcgamer.com/returnal-pc-system-requirements)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 20:16:25+00:00

That's a whole lotta RAM in one place.

## The creator of Dusk says his cat went behind his back to release this $5 'bite-sized' FPS early
 - [https://www.pcgamer.com/the-creator-of-dusk-says-his-cat-went-behind-his-back-to-release-this-dollar5-bite-sized-fps-early](https://www.pcgamer.com/the-creator-of-dusk-says-his-cat-went-behind-his-back-to-release-this-dollar5-bite-sized-fps-early)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 19:35:49+00:00

Chop Goblins, a "micro shooter" where Goblins will be chopped, was originally set for an early January launch.

## Full Witcher 3 update patch notes include PC-exclusive 'Ultra+' graphics setting
 - [https://www.pcgamer.com/full-witcher-3-update-patch-notes-include-pc-exclusive-ultra-graphics-setting](https://www.pcgamer.com/full-witcher-3-update-patch-notes-include-pc-exclusive-ultra-graphics-setting)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 18:56:38+00:00

The big update goes live on December 14. Here's the full list of what it does.

## Trying to play Destiny 2 without the API this weekend was a trip to the Dark Ages
 - [https://www.pcgamer.com/trying-to-play-destiny-2-without-the-api-this-weekend-was-a-trip-to-the-dark-ages](https://www.pcgamer.com/trying-to-play-destiny-2-without-the-api-this-weekend-was-a-trip-to-the-dark-ages)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 18:35:12+00:00

How has Bungie allowed its game to become so reliant on third-party tools?

## All romances you can pursue in the The Witcher 3
 - [https://www.pcgamer.com/the-witcher-3-romances](https://www.pcgamer.com/the-witcher-3-romances)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 18:05:06+00:00

Yen or Triss? Or everyone? Or no one?

## How to complete the Calming the Land world quest in WoW: Dragonflight
 - [https://www.pcgamer.com/world-of-warcraft-dragonflight-calming-the-land](https://www.pcgamer.com/world-of-warcraft-dragonflight-calming-the-land)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 18:01:40+00:00

Tip: Don't rush in and kill the elementals.

## GOG is giving away a free game to start its big Winter Sale
 - [https://www.pcgamer.com/gog-winter-sale-2022](https://www.pcgamer.com/gog-winter-sale-2022)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 16:55:33+00:00

The season of seasonal sales is officially upon us.

## AMD Radeon RX 7900 XT
 - [https://www.pcgamer.com/amd-rx-7900-xt-review-performance-specs](https://www.pcgamer.com/amd-rx-7900-xt-review-performance-specs)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 16:47:03+00:00

Should you settle for the second-best RDNA 3 GPU?

## The first glossy OLED gaming monitor is coming from weird-name-great-screens Dough
 - [https://www.pcgamer.com/the-first-glossy-oled-gaming-monitor-is-coming-from-weird-name-great-screens-dough](https://www.pcgamer.com/the-first-glossy-oled-gaming-monitor-is-coming-from-weird-name-great-screens-dough)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 16:36:41+00:00

Ignore the doughy name change, the makers of one of the best gaming monitors around is going OLED.

## Pink peripherals have taken over my setup and I never want to go back to black
 - [https://www.pcgamer.com/pink-peripherals-have-taken-over-my-setup-and-i-never-want-to-go-back-to-black](https://www.pcgamer.com/pink-peripherals-have-taken-over-my-setup-and-i-never-want-to-go-back-to-black)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 16:13:50+00:00

I've been bitten by the Quartz bug.

## How to find and gather Yggdrasil wood in Valheim
 - [https://www.pcgamer.com/valheim-yggdrasil-wood](https://www.pcgamer.com/valheim-yggdrasil-wood)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 16:09:10+00:00

This new resource is found in the Mistlands.

## Every new hairstyle in the Elden Ring Colosseum update
 - [https://www.pcgamer.com/elden-ring-new-hairstyles](https://www.pcgamer.com/elden-ring-new-hairstyles)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 15:44:09+00:00

Change your style in time for some PvP.

## The Witcher 3: How to get all Ursine armor and weapons
 - [https://www.pcgamer.com/the-witcher-3-ursine-armor-bear-school-gear](https://www.pcgamer.com/the-witcher-3-ursine-armor-bear-school-gear)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 14:58:46+00:00

Shield yourself with this Bear School gear.

## The Witcher 3: How to get all Feline armor and weapons
 - [https://www.pcgamer.com/the-witcher-3-feline-armor-cat-school-gear](https://www.pcgamer.com/the-witcher-3-feline-armor-cat-school-gear)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 14:51:34+00:00

Become a sly Witcher with this Cat School gear.

## WoW's most stubborn peacenik hits max level without hurting anyone once again
 - [https://www.pcgamer.com/wows-most-stubborn-peacenik-hits-max-level-without-hurting-anyone-once-again](https://www.pcgamer.com/wows-most-stubborn-peacenik-hits-max-level-without-hurting-anyone-once-again)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 14:38:42+00:00

With over 200 days in-game, Doubleagent still refuses to leave the starting area.

## Sabrent may have just dropped the Steam Deck NVMe SSD of my dreams
 - [https://www.pcgamer.com/sabrent-may-have-just-dropped-the-steam-deck-nvme-ssd-of-my-dreams](https://www.pcgamer.com/sabrent-may-have-just-dropped-the-steam-deck-nvme-ssd-of-my-dreams)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 14:30:17+00:00

This should reduce your need to risk buying some OEM SSD without a warranty.

## Intel XeSS vs DLSS vs FSR: How does Intel's upscaling compare?
 - [https://www.pcgamer.com/intel-xess-vs-dlss-vs-fsr](https://www.pcgamer.com/intel-xess-vs-dlss-vs-fsr)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 14:23:57+00:00

Intel's XeSS is an intriguing cross-platform addition to the super sampling genre.

## AMD RX 7900 XTX
 - [https://www.pcgamer.com/amd-radeon-rx-7900-xtx-review-benchmarks-performance](https://www.pcgamer.com/amd-radeon-rx-7900-xtx-review-benchmarks-performance)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 14:03:22+00:00

AMD's fastest graphics card, powered by chiplets.

## The Last of Us will run on Steam Deck, creator confirms
 - [https://www.pcgamer.com/the-last-of-us-will-run-on-steam-deck-creator-confirms](https://www.pcgamer.com/the-last-of-us-will-run-on-steam-deck-creator-confirms)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 11:54:17+00:00

Joel and Ellie hit the Deck.

## Today's Wordle 541 answer and hint for Monday, December 12
 - [https://www.pcgamer.com/wordle-541-answer-december-12](https://www.pcgamer.com/wordle-541-answer-december-12)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 08:05:46+00:00

Wordle today: The solution and a hint for the #541 puzzle.

## Unsurprisingly, there are already nude mods for Midnight Suns
 - [https://www.pcgamer.com/unsurprisingly-there-are-already-nude-mods-for-midnight-suns](https://www.pcgamer.com/unsurprisingly-there-are-already-nude-mods-for-midnight-suns)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 04:48:13+00:00

Now when will someone mod Tony Stark to give him a goatee?

## Dyson's air-purification headphones will cost nearly $1k a pair
 - [https://www.pcgamer.com/dysons-air-purification-headphones-will-cost-nearly-dollar1k-a-pair](https://www.pcgamer.com/dysons-air-purification-headphones-will-cost-nearly-dollar1k-a-pair)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 04:31:23+00:00

Curing air and noise pollution with money!

## This Pi Pico project can generate guest Wi-Fi networks complete with QR logins
 - [https://www.pcgamer.com/this-pi-pico-project-can-generate-guest-wi-fi-networks-complete-with-qr-logins](https://www.pcgamer.com/this-pi-pico-project-can-generate-guest-wi-fi-networks-complete-with-qr-logins)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 03:34:21+00:00

For those who want a little class and security around their Wi-Fi sharing.

## Black Mesa: Blue Shift releases its fourth chapter
 - [https://www.pcgamer.com/black-mesa-blue-shift-releases-its-fourth-chapter](https://www.pcgamer.com/black-mesa-blue-shift-releases-its-fourth-chapter)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 03:26:34+00:00

Barney's solo adventure continues.

## Tekken 7 has sold over 10 million copies
 - [https://www.pcgamer.com/tekken-7-has-sold-over-10-million-copies](https://www.pcgamer.com/tekken-7-has-sold-over-10-million-copies)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 02:40:43+00:00

That's a lot of people wondering how Paul gets his hair to stay up.

## One of the best-reviewed games on Steam is about watching plastic ducks
 - [https://www.pcgamer.com/one-of-the-best-reviewed-games-on-steam-is-about-watching-plastic-ducks](https://www.pcgamer.com/one-of-the-best-reviewed-games-on-steam-is-about-watching-plastic-ducks)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 01:23:09+00:00

It's a game about nothing.

## Five new Steam games you probably missed (December 12, 2022)
 - [https://www.pcgamer.com/five-new-steam-games-you-probably-missed-december-12-2022](https://www.pcgamer.com/five-new-steam-games-you-probably-missed-december-12-2022)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 00:28:15+00:00

Sorting through every new game on Steam so you don't have to.

## This Marathon mod 15 years in the making is practically an entirely new game
 - [https://www.pcgamer.com/marathon-mod-apotheosis-x](https://www.pcgamer.com/marathon-mod-apotheosis-x)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-12 00:11:43+00:00

Apotheosis X creator hypersleep wanted to "push the boundaries of what's possible aesthetically with the Marathon engine."


# Source:Thoughty2, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA, language:en-US

## The Truth Behind The Most Impossible Survival Story Ever Told
 - [https://www.youtube.com/watch?v=8DGi-u2j5_w](https://www.youtube.com/watch?v=8DGi-u2j5_w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA
 - date published: 2022-12-12 16:22:23+00:00

Get Surfshark VPN at https://Surfshark.deals/thoughty2 and enter promo code THOUGHTY2 for 83% off and 3 extra months for free! 



Thoughty2 Audiobook: https://geni.us/t2audio
Thoughty2 Book: https://geni.us/t2book
Support Me & Get Early Access: http://bit.ly/t2club
Thoughty2 Merchandise: https://bit.ly/t2merch

Follow Thoughty2
Facebook: https://facebook.com/thoughty2
Instagram: https://instagram.com/thoughty2
Website: http://thoughty2.com

About Thoughty2
Thoughty2 (Arran) is a British YouTuber and gatekeeper of useless facts. Thoughty2 creates mind-blowing factual videos about science, tech, history, opinion and just about everything else.
#Thoughty2

Writing: Steven Rix
Editing: Jack Stevens


# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Największy wycieczkowiec na świecie został zwodowany
 - [https://businessinsider.com.pl/lifestyle/icon-of-the-seas-najwiekszy-wycieczkowiec-na-swiecie-zostal-zwodowany/djbl8r3](https://businessinsider.com.pl/lifestyle/icon-of-the-seas-najwiekszy-wycieczkowiec-na-swiecie-zostal-zwodowany/djbl8r3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 20:33:58+00:00

Icon of the Seas – największy na świecie wycieczkowiec budowany dla Royal Caribbean International został zwodowany w fińskiej stoczni. Gigant o długości 365 m pomieści 7,6 tys. gości.

## Wzór do malowania twarzy mógł zmylić 15 tys. kamer na mundialu w Katarze
 - [https://businessinsider.com.pl/wiadomosci/wzor-do-malowania-twarzy-mogl-zmylic-15-tys-kamer-na-mundialu-w-katarze/ezjx37b](https://businessinsider.com.pl/wiadomosci/wzor-do-malowania-twarzy-mogl-zmylic-15-tys-kamer-na-mundialu-w-katarze/ezjx37b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 18:41:26+00:00

Odkryto, że zaprojektowany przez sztuczną inteligencję wzór do malowania twarzy może zmylić 15 tys. kamer do rozpoznawania wizerunku podczas Mistrzostw Świata w Katarze. Tzw. makijaż Juggalo jest szczególnie skuteczny w oszukiwaniu systemów rozpoznawania twarzy.

## Iran przekaże Rosji kolejną broń. Chce sprytnie ominąć sankcje
 - [https://businessinsider.com.pl/technologie/iran-przekaze-rosji-kolejna-bron-chce-sprytnie-ominac-sankcje/by3vfs0](https://businessinsider.com.pl/technologie/iran-przekaze-rosji-kolejna-bron-chce-sprytnie-ominac-sankcje/by3vfs0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 18:39:31+00:00

Iran planuje sprzedać Rosji rakiety balistyczne Fateh-110. Zmodyfikuje jednak ich zasięg poniżej 300 km. W ten sposób nie złamie ograniczeń nałożonych przez Radę Bezpieczeństwa ONZ — tak informuje portal Axios, powołując się na przedstawicieli izraelskich władz. Pierwotnie Teheran miał rozważać nawet sprzedaż rakiet o dalszym zasięgu.

## Niemiecki wiceminister: "uniezależniamy się od Rosji". Mówi też o innym przeciwniku
 - [https://businessinsider.com.pl/gospodarka/niemiecki-wiceminister-uniezalezniamy-sie-od-rosji-mowi-tez-przeciwniku-z-chin/hk6451e](https://businessinsider.com.pl/gospodarka/niemiecki-wiceminister-uniezalezniamy-sie-od-rosji-mowi-tez-przeciwniku-z-chin/hk6451e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 18:23:27+00:00

Niemiecki wiceminister spraw zagranicznych Tobias Lindner z Zielonych, zapewnił w rozmowie z amerykańską stacją telewizyjną Fox News, że Niemcy całkowicie uniezależniają się od rosyjskich paliw kopalnych. Wskazał również, że Berlin dostrzega innego, strategicznego przeciwnika.

## Zyskał sławę zabójcy dronów. Ukraiński pilot myśliwców mianowany bohaterem Ukrainy
 - [https://businessinsider.com.pl/wiadomosci/pilot-karaja-zabojca-dronow-mianowany-bohaterem-ukrainy/52spz0t](https://businessinsider.com.pl/wiadomosci/pilot-karaja-zabojca-dronow-mianowany-bohaterem-ukrainy/52spz0t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 17:43:04+00:00

Ukraiński pilot myśliwca Wadim Woroszyłow zamieszcza w mediach społecznościowych zdjęcia i materiały filmowe wykonane kamerami GoPro, które dają unikalny obraz wojny powietrznej toczonej nad Ukrainą. Ostatnio otrzymał tytuł Bohatera Ukrainy.

## Niemiecka minister środowiska naciska na Polskę. Chodzi o Odrę
 - [https://businessinsider.com.pl/wiadomosci/niemiecka-minister-srodowiska-naciska-na-polske-chodzi-o-katastrofe-na-odrze/m3e2sde](https://businessinsider.com.pl/wiadomosci/niemiecka-minister-srodowiska-naciska-na-polske-chodzi-o-katastrofe-na-odrze/m3e2sde)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 17:34:37+00:00

Jak donosi agencja dpa, w związku z katastrofą ekologiczną w Odrze, do której doszło tego lata, niemiecka minister środowiska Steffi Lemke chce nadal naciskać na Polskę, by zidentyfikowała odpowiedzialnego za zrzut soli do rzeki. Zwłaszcza, że jej zasolenie nadal jest wysokie.

## Się pomaga, się odlicza w PIT. O tym warto pamiętać
 - [https://businessinsider.com.pl/prawo/podatki/darowizny-na-szlachetna-paczke-siepomaga-subkonta-czy-mozna-odliczyc-od-podatku/xl7xzsr](https://businessinsider.com.pl/prawo/podatki/darowizny-na-szlachetna-paczke-siepomaga-subkonta-czy-mozna-odliczyc-od-podatku/xl7xzsr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 17:07:16+00:00

Grudzień to czas, w którym wiele osób decyduje się pomóc potrzebującym. To również miesiąc, w którym wielu zastanawia się, jak zmniejszyć swój podatek za kończący się rok. W praktyce jedno może iść w parze z drugim. Osoby, które przekazują pieniądze fundacjom pożytku publicznego, np. Szlachetnej Paczce, Siepomaga i innym, mogą je odliczyć od dochodu lub przychodu, o ile zostaną właściwie udokumentowane. Można też odliczyć wpłaty dla indywidualnych osób, ale pod warunkiem, że taka osoba ma specjalne konto w organizacji (darowizna jest wpłacana na konto fundacji lub stowarzyszenia). Wyjaśniamy, jak to zrobić.

## Nowy PIT-2. Jest projekt objaśnień podatkowych, i tak są wątpliwości
 - [https://businessinsider.com.pl/prawo/podatki/nowy-pit-2-jest-projekt-objasnien-podatkowych-a-i-tak-budzi-watpliwosci/ppm4vlx](https://businessinsider.com.pl/prawo/podatki/nowy-pit-2-jest-projekt-objasnien-podatkowych-a-i-tak-budzi-watpliwosci/ppm4vlx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 16:48:20+00:00

Nowy PIT-2 będzie można stosować od 1 stycznia 2023 r. Opcji będzie dużo więcej niż dotychczas. Tłumaczy je Ministerstwo Finansów w projekcie objaśnień podatkowych. Część wniosków zaskakuje. Eksperci wskazują np. że osoba zatrudniona w firmie na umowę o pracę i jednocześnie umowę zlecenie będzie musiała składać dwa formularze PIT-2. Niektórzy będą też musieli ten formularz składać co roku.

## Szefowa PE o aferze korupcyjnej. "Zaatakowano europejską demokrację"
 - [https://businessinsider.com.pl/wiadomosci/szefowa-pe-o-aferze-korupcyjnej-zaatakowano-europejska-demokracje/g09j88w](https://businessinsider.com.pl/wiadomosci/szefowa-pe-o-aferze-korupcyjnej-zaatakowano-europejska-demokracje/g09j88w)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 16:47:34+00:00

Przewodnicząca Parlamentu Europejskiego rozpoczęła procedurę odwołania swojej zastępczyni. Pozbawiła ją wszelkich zadań i obowiązków. To efekt afery korupcyjnej. — Zaatakowano europejską demokrację — powiedziała szefowa PE.

## Obowiązkowe ćwiczenia wojskowe. Oto co myślą Polacy [SONDAŻ]
 - [https://businessinsider.com.pl/wiadomosci/obowiazkowe-cwiczenia-wojskowe-oto-co-mysla-polacy-sondaz/edeqe4c](https://businessinsider.com.pl/wiadomosci/obowiazkowe-cwiczenia-wojskowe-oto-co-mysla-polacy-sondaz/edeqe4c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 16:32:31+00:00

Informacje o liczbie osób, które mogą być powołane w 2023 r. do czynnej służby wojskowej, wywołały medialną wrzawę. Oto co na ten temat myślą Polacy. W sondażu pytano m.in. o przywrócenie zasadniczej służby wojskowej.

## Tej firmie wojna niestraszna. Wybuduje w Ukrainie fabrykę za miliardy
 - [https://businessinsider.com.pl/firmy/tej-firmie-wojna-niestraszna-wybuduje-w-ukrainie-fabryke-za-miliardy/0d65vqj](https://businessinsider.com.pl/firmy/tej-firmie-wojna-niestraszna-wybuduje-w-ukrainie-fabryke-za-miliardy/0d65vqj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 16:30:02+00:00

Szwajcarski koncern spożywczy Nestle poinformował w poniedziałek, że zainwestuje 40 mln franków szwajcarskich w nową fabrykę na Ukrainie. Firma zdecydowała się na ten krok, pomimo trwającej wojny.

## Aukcje na 5G coraz bliżej. Ruszają konsultacje
 - [https://businessinsider.com.pl/technologie/aukcje-na-5g-coraz-blizej-ruszaja-konsultacje/1e0rnye](https://businessinsider.com.pl/technologie/aukcje-na-5g-coraz-blizej-ruszaja-konsultacje/1e0rnye)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 16:17:35+00:00

20 grudnia wystartują konsultacje w sprawie aukcji na pasmo "C" w technologii 5G. To ważny krok we wdrażaniu tej technologii w Polsce.

## PiS zmienia zdanie w sprawie "dawana w szyję" na dworcach
 - [https://businessinsider.com.pl/gospodarka/przepisy/nie-dla-dawania-w-szyje-na-dworcach-pis-wycofuje-sie-z-projektu/p53nn6m](https://businessinsider.com.pl/gospodarka/przepisy/nie-dla-dawania-w-szyje-na-dworcach-pis-wycofuje-sie-z-projektu/p53nn6m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 15:52:45+00:00

Posłowie PiS chcieli zmienić obowiązujący od wielu lat zakaz sprzedaży alkoholu w lokalach gastronomicznych na dworcach, co miało zwiększyć atrakcyjność prowadzenia działalności gospodarczej w tych miejscach. Projekt trafił do Sejmu, jednak sejmowa komisja usunęła poprawki majce na celu zmianę przepisów.

## Tysiące mieszkańców Małopolski bez prądu. Tauron podaje dane
 - [https://businessinsider.com.pl/twoje-pieniadze/tysiace-mieszkancow-malopolski-bez-pradu-tauron-podaje-dane/yw6y6wt](https://businessinsider.com.pl/twoje-pieniadze/tysiace-mieszkancow-malopolski-bez-pradu-tauron-podaje-dane/yw6y6wt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 15:34:38+00:00

Intensywne opady śniegu spowodowały liczne awarie sieci energetycznych. W Małopolsce bez prądu pozostaje 2,5 tys. mieszkańców. Jak informuje tamtejszy dystrybutor energii, przez sobotę i niedzielę, przerwy w zasilaniu dotknęły nawet kilkunastu tysięcy osób.

## Zgrzyty w NATO. "Turcja zachowuje się jak Korea Północna"
 - [https://businessinsider.com.pl/gospodarka/zgrzyty-w-nato-turcja-zachowuje-sie-jak-korea-polnocna/rn22l2j](https://businessinsider.com.pl/gospodarka/zgrzyty-w-nato-turcja-zachowuje-sie-jak-korea-polnocna/rn22l2j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 15:20:13+00:00

Szef greckiej dyplomacji Nikos Dendias skrytykował tureckie władze za groźbę ataku rakietowego na Ateny. Powiedział, że Ankara zachowuje się jak Korea Północna. A to, w przypadku sojuszniczego kraju należącego do NATO, jest niedopuszczalne.

## Rynki szykują się na recesję. To będzie "tydzień prawdy"
 - [https://businessinsider.com.pl/gielda/wiadomosci/recesja-na-swiecie-nie-wszystkich-dotknie-to-bedzie-tydzien-prawdy/n23bg97](https://businessinsider.com.pl/gielda/wiadomosci/recesja-na-swiecie-nie-wszystkich-dotknie-to-bedzie-tydzien-prawdy/n23bg97)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 15:11:07+00:00

To może być jedna z najbardziej oczekiwanych recesji w historii. Tym samym nie powinna się przerodzić w głęboki kryzys. Eksperci twierdzą, że Europa może być bardziej dotknięta niż USA czy Azja. Wskazują na dużą rolę, jaką do odegrania mają banki centralne. Kilka istotnych decyzji zapadnie właśnie w tym tygodniu.

## Prawo do zapomnienia w Google. Ważny wyrok TSUE o tym, jak zniknąć z wyszukiwarki
 - [https://businessinsider.com.pl/prawo/prawo-do-zapomnienia-w-google-wazny-wyrok-tsue/pe83h4f](https://businessinsider.com.pl/prawo/prawo-do-zapomnienia-w-google-wazny-wyrok-tsue/pe83h4f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 15:10:19+00:00

Każdy ma prawo skorzystać z prawa do bycia zapomnianym i np. poprosić Google, aby z wyników wyszukania usunął linki artykułów z nieprawdziwymi informacjami. Musi jednak udowodnić, że link prowadzi do kłamliwych treści. Operator wyszukiwarki nie musi tego robić samodzielnie. Tak orzekł TSUE w sprawie przeciwko Google.

## Tak wyłudzają informacje hakerzy z Korei Północnej. Bez łamania haseł
 - [https://businessinsider.com.pl/technologie/tak-wyludzaja-informacje-hakerzy-nie-lamia-do-tego-hasla/zx8g998](https://businessinsider.com.pl/technologie/tak-wyludzaja-informacje-hakerzy-nie-lamia-do-tego-hasla/zx8g998)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 15:02:32+00:00

Północnokoreańscy hakerzy mają nowy sposób zbierania informacji od zagranicznych ekspertów. Nie włamują się do komputerów i nie kradną danych. Wystarczy, że... poproszą ich o komentarz. To nowa metoda na szpiegowanie Zachodu.

## Ranking szczoteczek sonicznych — które modele wybrać na prezent?
 - [https://businessinsider.com.pl/technologie/ranking-szczoteczek-sonicznych-ktore-modele-wybrac-na-prezent/7dkvvgz](https://businessinsider.com.pl/technologie/ranking-szczoteczek-sonicznych-ktore-modele-wybrac-na-prezent/7dkvvgz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 14:48:00+00:00

Nie wiesz, co kupić na prezent pod choinkę? Poniżej znajdziesz odpowiedź. Przedstawiamy ranking najpopularniejszych szczoteczek sonicznych w grudniu według danych ze Skąpiec.pl. To modele w różnych przedziałach cenowych.

## Ten kraj zamroził największy majątek oligarchów z Rosji. Chodzi o miliardy
 - [https://businessinsider.com.pl/wiadomosci/ten-kraj-zamrozil-najwiekszy-majatek-rosyjskich-oligarchow-chodzi-o-miliardy/zcbf57m](https://businessinsider.com.pl/wiadomosci/ten-kraj-zamrozil-najwiekszy-majatek-rosyjskich-oligarchow-chodzi-o-miliardy/zcbf57m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 14:43:09+00:00

Belgia zablokowała dotychczas 3,5 mld euro aktywów rosyjskich oligarchów i podmiotów z listy sankcyjnej, najwięcej ze wszystkich krajów Unii Europejskiej. Łącznie 27 państw członkowskich zamroziło już 18,9 mld euro rosyjskich środków.

## W tym roku nie będzie tradycyjnej konferencji Putina. Z powodu Ukrainy
 - [https://businessinsider.com.pl/wiadomosci/w-tym-roku-nie-bedzie-tradycyjnej-konferencji-putina-z-powodu-ukrainy/vyz12gm](https://businessinsider.com.pl/wiadomosci/w-tym-roku-nie-bedzie-tradycyjnej-konferencji-putina-z-powodu-ukrainy/vyz12gm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 14:25:25+00:00

W tym roku nie odbędzie się doroczna grudniowa konferencja prasowa prezydenta Rosji Władimira Putina. Pod znakiem zapytania stoi także organizacja tzw. gorącej linii z udziałem obywateli. Według mediów zależy to m.in. od sytuacji na froncie wojny w Ukrainie.

## Węgiel. Premier mówił o klęsce urodzaju. A tak wygląda rzeczywistość
 - [https://businessinsider.com.pl/gospodarka/wegiel-premier-mowil-o-klesce-urodzaju-a-tak-wyglada-rzeczywistosc/w63y1f1](https://businessinsider.com.pl/gospodarka/wegiel-premier-mowil-o-klesce-urodzaju-a-tak-wyglada-rzeczywistosc/w63y1f1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 14:19:17+00:00

Okazuje się, że nie wszystkie gminy odczuwają "klęskę urodzaju" w kwestii dostaw węgla, o której mówił ostatnio premier. "W Jarocinie mamy zapotrzebowanie na węgiel od 2200 osób, na razie rząd dostarczył go dla… 250 mieszkańców" — napisał burmistrz miasta.

## Komisja zatwierdziła programy unijne. Rzecznik rządu o tym, gdzie trafią pieniądze
 - [https://businessinsider.com.pl/finanse/fundusze/komisja-zatwierdzila-programy-unijne-gdzie-trafia-pieniadze/7sjf0le](https://businessinsider.com.pl/finanse/fundusze/komisja-zatwierdzila-programy-unijne-gdzie-trafia-pieniadze/7sjf0le)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 14:06:46+00:00

Jak poinformował w poniedziałek rzecznik rządu Piotr Müller, Komisja Europejska zaakceptowała w poniedziałek wszystkie programy operacyjne na poziomie krajowym. Teraz rozpoczyna się realizacja regionalnych programów operacyjnych, które opiewają na łączną kwotę 33,5 mld euro.

## Zrób sobie prezent przed świętami — ranking popularności myjek do okien
 - [https://businessinsider.com.pl/technologie/zrob-sobie-prezent-przed-swietami-ranking-popularnosci-myjek-do-okien/xqe4rz6](https://businessinsider.com.pl/technologie/zrob-sobie-prezent-przed-swietami-ranking-popularnosci-myjek-do-okien/xqe4rz6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 14:01:00+00:00

Nie czekaj na prezenty pod choinką i kup sobie myjkę do okien. Przyda się podczas przedświątecznego sprzątania. Przedstawiamy ranking pięciu najpopularniejszych myjek według najświeższych danych ze Skąpiec.pl. Każda z nich jest warta zakupu.

## KNF rozlicza za aferę GetBack. Anna Paczuska ma zapłacić miliony
 - [https://businessinsider.com.pl/wiadomosci/afera-getback-anna-paczuska-i-alicja-kornasiewicz-ukarane-przez-knf/swb1k8t](https://businessinsider.com.pl/wiadomosci/afera-getback-anna-paczuska-i-alicja-kornasiewicz-ukarane-przez-knf/swb1k8t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 13:53:07+00:00

Alicja Kornasiewicz, będąca w przeszłości w radzie nadzorczej GetBack i Anna Paczuska, zasiadająca w zarządzie windykatora, otrzymały kary pieniężne od KNF. W sumie sięgają blisko 3,5 mln zł. Urzędnicy wskazali na kilkadziesiąt różnych naruszeń związanych z niewypełnieniem obowiązków informacyjnych.

## Skandal korupcyjny. Majątek wiceszefowej PE zamrożony
 - [https://businessinsider.com.pl/wiadomosci/skandal-korupcyjny-w-brukseli-majatek-evy-kaili-zamrozony/d82g3hk](https://businessinsider.com.pl/wiadomosci/skandal-korupcyjny-w-brukseli-majatek-evy-kaili-zamrozony/d82g3hk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 13:46:57+00:00

Grecja zamroziła majątek wiceprzewodniczącej Parlamentu Europejskiego Evy Kaili w związku z dochodzeniem wszczętego przez belgijskie władze w sprawie prania pieniędzy i korupcji w parlamencie — informuje Reuters. "Zarzuty są bardzo niepokojące, bardzo poważne" — oceniła przewodnicząca KE Ursula von der Leyen.

## Wiceminister o polskiej dzietności: potencjał jest
 - [https://businessinsider.com.pl/wiadomosci/wiceminister-o-polskiej-dzietnosci-potencjal-jest/kek116k](https://businessinsider.com.pl/wiadomosci/wiceminister-o-polskiej-dzietnosci-potencjal-jest/kek116k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 13:43:53+00:00

— Polacy chcą mieć dzieci, ale napotykają na szereg problemów, które uniemożliwiają bądź powodują odkładanie w czasie planów, co skutkuje spadającą dzietnością — powiedziała wiceminister rodziny i polityki społecznej Barbara Socha podczas Kongresu Demograficznego odbywającego się na Uniwersytecie Warszawskim. Prezydencki minister Paweł Szrot mówił natomiast o wpływie uchodźców z Ukrainy na polską demografię.

## Zaplanuj urlop na greckiej wyspie. Skorzystaj z przedsprzedaży oferty na lato 2023
 - [https://businessinsider.com.pl/lifestyle/podroze/zaplanuj-urlop-na-greckiej-wyspie-i-skorzystaj-z-przedsprzedazy-oferty-na-lato-2023/bm1gjmx](https://businessinsider.com.pl/lifestyle/podroze/zaplanuj-urlop-na-greckiej-wyspie-i-skorzystaj-z-przedsprzedazy-oferty-na-lato-2023/bm1gjmx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 13:26:00+00:00

Śródziemnomorski klimat, znakomita kuchnia, starożytne zabytki, taniec zorba, oliwki oraz piękne wyspy. Grecja to z pewnością jeden z najbardziej malowniczych krajów i doskonały pomysł na urlop. U jej wybrzeża znajduje się około dwóch i pół tysiąca wysp i wysepek. Wiele z nich jest niezamieszkałych, a część z nich to perły światowej turystyki. Do najpiękniejszych i najpopularniejszych należą Rodos, Korfu i Lesbos. To na tych wyspach znaleźliśmy wolne miejsca w hotelach położonych przy samej plaży. Warto podkreślić, że ceny pobytów w przedsprzedaży są szczególnie atrakcyjne.

## Rosyjski gaz trafi przez Turcję? Erdogan liczy na pomoc... Polski
 - [https://businessinsider.com.pl/gospodarka/rosyjski-gaz-trafi-przez-turcje-erdogan-liczy-na-pomoc-polski/e2bfv7k](https://businessinsider.com.pl/gospodarka/rosyjski-gaz-trafi-przez-turcje-erdogan-liczy-na-pomoc-polski/e2bfv7k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 13:14:27+00:00

Portal biznesalert.pl analizuje tematykę rozmów prezydenta Rosji Władimira Putina i Turcji Recepa Tayyipa Erdoğana. Liderzy obu państw rozmawiali o roli, jaką może odegrać Turcja w transporcie rosyjskiego gazu do Europy. Tureckie media wskazują, że pomóc w tym może... Polska.

## Zbudował przydomową elektrownię. Teraz musi się tłumaczyć
 - [https://businessinsider.com.pl/wiadomosci/zbudowal-przydomowa-elektrownie-moze-pojsc-do-wiezienia-na-lata/v5hetnq](https://businessinsider.com.pl/wiadomosci/zbudowal-przydomowa-elektrownie-moze-pojsc-do-wiezienia-na-lata/v5hetnq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 12:44:09+00:00

38-letni mieszkaniec Starachowic chciał zaoszczędzić i na swojej działce postawił niewielką elektrownię solarno-wiatrową. Konstrukcja, a właściwie część jej elementów, wzbudziła wątpliwości policjantów. Teraz 38-latkowi grozi do 10 lat więzienia.

## Ponad 42 tys. wypadków przy pracy. Gdzie najczęściej do nich dochodzi?
 - [https://businessinsider.com.pl/wiadomosci/wypadki-w-pracy-ponad-42-tys-poszkodowanych-w-ciagu-9-miesiecy-2022-r/bfj9pdc](https://businessinsider.com.pl/wiadomosci/wypadki-w-pracy-ponad-42-tys-poszkodowanych-w-ciagu-9-miesiecy-2022-r/bfj9pdc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 12:41:08+00:00

W ciągu dziewięciu pierwszych miesięcy tego roku w pracy zostało poszkodowanych ponad 42 tys. osób. Najczęściej do wypadków dochodzi na Śląsku. Na tysiąc zatrudnionych w górnictwie, dziewięciu odniosło szkody. Prawie o połowę mniejszy jest wskaźnik wypadkowości w przemyśle.

## Granat w pralce i inne "niespodzianki". Oto co zostawili po sobie Rosjanie
 - [https://businessinsider.com.pl/wiadomosci/cherson-granat-w-pralce-i-inne-niespodzianki-oto-co-zostawili-po-sobie-rosjanie/hw8pz31](https://businessinsider.com.pl/wiadomosci/cherson-granat-w-pralce-i-inne-niespodzianki-oto-co-zostawili-po-sobie-rosjanie/hw8pz31)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 12:26:18+00:00

Rosyjskie siły, wycofując się z Chersonia, zostawiły po sobie pułapki — w tym granat w pralce i znak uliczny kierujący ludzi na pole minowe.

## Skandal w Parlamencie Europejskim. "Wiadomość jest bardzo niepokojąca"
 - [https://businessinsider.com.pl/wiadomosci/skandal-w-parlamencie-europejskim-wiadomosc-jest-bardzo-niepokojaca/be1xn9s](https://businessinsider.com.pl/wiadomosci/skandal-w-parlamencie-europejskim-wiadomosc-jest-bardzo-niepokojaca/be1xn9s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 12:18:45+00:00

Wiceszefowa Parlamentu Europejskiego Eva Kaili została w niedzielę postawiona w stan oskarżenia i aresztowana decyzją belgijskiego sądu w związku z aferą korupcyjną. Głos w tej sprawie wydał wysoki przedstawiciel Unii do spraw zagranicznych i polityki bezpieczeństwa Josep Borell. — Ta wiadomość jest bardzo niepokojąca — wskazał.

## Zakaz pieców gazowych w UE może stracić kolce. Oto najnowsze plany Brukseli [TYLKO U NAS]
 - [https://businessinsider.com.pl/gospodarka/zakaz-piecow-gazowych-w-ue-moze-stracic-kolce/nf9n6lq](https://businessinsider.com.pl/gospodarka/zakaz-piecow-gazowych-w-ue-moze-stracic-kolce/nf9n6lq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 12:12:18+00:00

Bruksela chciała, by w 2029 r. wszedł w życie zakaz sprzedaży pieców na paliwa kopalne, czyli w tym tych gazowych. W Komisji Europejskiej dowiadujemy się jednak, że zwyciężyć ma nieco łagodniejszy pomysł. Pewne jest natomiast, że walka Unii z kotłami będzie trwać – i że władze Wspólnoty tu nie odpuszczą.

## Ustalenia organizacyjne. Czy ich uzgodnienie uruchomi miliardy euro?
 - [https://businessinsider.com.pl/prawo/co-to-sa-ustalenia-organizacyjne-kpo/z5kpbx3](https://businessinsider.com.pl/prawo/co-to-sa-ustalenia-organizacyjne-kpo/z5kpbx3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 11:59:58+00:00

Aby Unia wypłaciła pieniądze z Funduszu Odbudowy na rzecz Krajowego Programu Odbudowy, muszą być spełnione tzw. kamienie milowe. Sposób ich weryfikacji określają liczące kilkaset stron tzw. ustalenia operacyjne. Komisja Europejska właśnie je zatwierdziła.

## KE podpisała ważny dokument. Piłeczka ws. KPO już tylko po stronie Polski
 - [https://businessinsider.com.pl/gospodarka/ke-podpisala-wazny-dokument-pileczka-ws-kpo-juz-tylko-po-stronie-polski/kq5mtt2](https://businessinsider.com.pl/gospodarka/ke-podpisala-wazny-dokument-pileczka-ws-kpo-juz-tylko-po-stronie-polski/kq5mtt2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 11:56:51+00:00

Minister funduszy Grzegorz Puda poinformował w poniedziałek, że Komisja Europejska podpisała ustalenia operacyjne w sprawie polskiego KPO. Oznacza to, że nie ma już formalnie żadnych przeszkód, by Polska otrzymała pieniądze z Brukseli. Oczywiście pod warunkiem wypełnienia kamieni milowych.

## Nowości w Czystym powietrzu. "Pierwsza zmiana to zmiana finansowa"
 - [https://businessinsider.com.pl/wiadomosci/czyste-powietrze-minister-zapowiada-zmiany-finansowe-w-programie/sb3yvrf](https://businessinsider.com.pl/wiadomosci/czyste-powietrze-minister-zapowiada-zmiany-finansowe-w-programie/sb3yvrf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 11:53:09+00:00

Minister klimatu Anna Moskwa zapowiedziała, że w najbliższych dniach jej resort będzie kompleksowo komunikować zmiany w programie Czyste powietrze. Jak zaznaczyła, podstawowe kwestie dotyczą finansów, bo zmieniły się realia rynkowe. Minister zdradziła także, czego można spodziewać się w tzw. ustawie wiatrakowej.

## Na głównym parkiecie GPW debiutuje nowa spółka. Notowania na plusie
 - [https://businessinsider.com.pl/gielda/wiadomosci/cloud-technologies-debiutuje-na-gpw-co-z-notowaniami-akcji/zwqr6em](https://businessinsider.com.pl/gielda/wiadomosci/cloud-technologies-debiutuje-na-gpw-co-z-notowaniami-akcji/zwqr6em)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 11:39:46+00:00

Całkiem udany był poniedziałkowy debiut na głównym rynku GPW spółki Cloud Technologies. Spółka chce postawić w 2023 r. na akwizycję i zakup technologii. Dostarcza dane do targetowania reklam cyfrowych, których odbiorcami są domy mediowe i agencje marketingu online.

## Szefowa Komisji Europejskiej: tej zimy jesteśmy bezpieczni
 - [https://businessinsider.com.pl/gospodarka/szefowa-komisji-europejskiej-tej-zimy-jestesmy-bezpieczni/lvl42rf](https://businessinsider.com.pl/gospodarka/szefowa-komisji-europejskiej-tej-zimy-jestesmy-bezpieczni/lvl42rf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 11:37:26+00:00

Przewodnicząca Komisji Europejskiej, Ursula von der Leyen zapewniła, że tej zimy UE jest bezpieczna. - Energetyczny szantaż Rosji się nie powiódł - wskazała podczas konferencji prasowej poświęconej sytuacji energetycznej na kontynencie.

## Turyści nie chcą przyjeżdżać do Polski. Dane pokazują zapaść
 - [https://businessinsider.com.pl/gospodarka/turysci-nie-chca-przyjezdzac-do-polski-dane-pokazuja-zapasc/tc6wrx8](https://businessinsider.com.pl/gospodarka/turysci-nie-chca-przyjezdzac-do-polski-dane-pokazuja-zapasc/tc6wrx8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 11:16:22+00:00

Po osiągnięciu rekordowego poziomu 21,2 mln zagranicznych turystów w Polsce w 2019 r., ich liczba spadła do 8,4 mln rok później - wynika z raportu OECD. W 2021 r. liczba gości wzrosła do 9,7 mln, ale nadal była o 54 proc. niższa niż przed pandemią. Wśród najczęściej odwiedzających nasz kraj cudzoziemców dominują Niemcy.

## W budowie jest o ponad 50 tys. mniej mieszkań niż rok temu. Wydłużył się czas prac
 - [https://businessinsider.com.pl/twoje-pieniadze/nieruchomosci/nowe-mieszkania-2022-w-budowie-ponad-50-tys-mniej-niz-rok-temu/tk5btle](https://businessinsider.com.pl/twoje-pieniadze/nieruchomosci/nowe-mieszkania-2022-w-budowie-ponad-50-tys-mniej-niz-rok-temu/tk5btle)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 11:08:26+00:00

Do użytkowania oddano w tym roku o 2 proc. więcej mieszkań, ale w budowie jest o 24 proc. mniej. To oznacza, że w kolejnych latach może być większy problem z dostępnością nowych lokali. Tym bardziej że wydłuża się przeciętny czas trwania budowy. Średnio wynosi niecałe 43 miesiące.

## Małe i średnie firmy muszą uważać na ustawę o cenach energii. Prawnik wyjaśnia dlaczego
 - [https://businessinsider.com.pl/prawo/firma/definicja-msp-w-ustawie-o-maksymalnych-cenach-energii-jak-ja-stosowac/zcmbgym](https://businessinsider.com.pl/prawo/firma/definicja-msp-w-ustawie-o-maksymalnych-cenach-energii-jak-ja-stosowac/zcmbgym)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 11:02:48+00:00

Ustawa o maksymalnych cenach energii odsyła do polskiej definicji mikro, małego i średniego przedsiębiorstwa, a powinna do unijnej — uważa dr Magdalena Porzeżyńska, radca prawny i wspólnik w kancelarii Brysiewicz Bokina Sakławski i Wspólnicy. Zastosowanie polskich kryteriów może słono kosztować, bo one nie przewidują uwzględnienia danych firm powiązanych. To realny problem, z podobnym mierzyły się firmy, które korzystały z tarczy finansowej PFR.

## Elon Musk straszy pracowników pozwami. Dostali ostrzegawczy e-mail
 - [https://businessinsider.com.pl/wiadomosci/elon-musk-straszy-pracownikow-pozwami-dostali-ostrzegawczy-e-mail/qs9kzjm](https://businessinsider.com.pl/wiadomosci/elon-musk-straszy-pracownikow-pozwami-dostali-ostrzegawczy-e-mail/qs9kzjm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 10:58:13+00:00

Elon Musk wysłał e-mail, w którym grozi, że pozwie pracowników Twittera, którzy ujawnią poufne informacje. "Twitter będzie natychmiast ubiegał się o odszkodowanie" — podkreślił.

## Chciała kupić bilet na autobus. Automat ściągnął jej 5 tys. zł z konta
 - [https://businessinsider.com.pl/gospodarka/chciala-kupic-bilet-na-autobus-automat-sciagnal-jej-5-tys-zl-z-konta/g07nv88](https://businessinsider.com.pl/gospodarka/chciala-kupic-bilet-na-autobus-automat-sciagnal-jej-5-tys-zl-z-konta/g07nv88)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 10:50:26+00:00

Jedna z mieszkanek Rzeszowa straciła 5 tys. zł. Nie padła jednak ofiarą oszustwa czy kradzieży, ale... awarii biletomatu Zakładu Transportu Miejskiego. Chciała ona kupić bilet za 18 zł, a automat ściągnął jej z konta aż 5 tys. zł. Kobieta o wszystkim dowiedziała się dopiero grubo po fakcie.

## Kiedy obniżka stóp procentowych w Polsce? Analitycy banku wskazali termin
 - [https://businessinsider.com.pl/finanse/kiedy-obnizka-stop-procentowych-w-polsce-analitycy-credit-agricole-wskazali-termin/ngbn68q](https://businessinsider.com.pl/finanse/kiedy-obnizka-stop-procentowych-w-polsce-analitycy-credit-agricole-wskazali-termin/ngbn68q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 10:12:26+00:00

Stopy procentowe wyniosą 5-6 proc. w czterech krajach Europy Środkowo-Wschodniej (Czechy, Polska, Rumunia Węgry) pod koniec 2024 r., prognozuje Credit Agricole Bank Polska. W przypadku Polski analitycy oczekują pierwszych cięć stóp procentowych o 25 pb w I kw. 2024 r.

## Siódma fala pandemii COVID-19. Niedzielski mówi, co nas czeka
 - [https://businessinsider.com.pl/wiadomosci/siodma-fala-pandemii-covid-19-niedzielski-mowi-co-nas-czeka/9dbvxh4](https://businessinsider.com.pl/wiadomosci/siodma-fala-pandemii-covid-19-niedzielski-mowi-co-nas-czeka/9dbvxh4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 09:55:20+00:00

"Tendencja się odwróciła" — mówi o procentowym wzroście liczby zakażeń COVID-19 w Polsce minister zdrowia Adam Niedzielski. Jak dodaje jednak, w liczbach bezwzględnych sytuacja nie wydaje się szczególnie niepokojąca.

## Czesi nie cieszyli się długo z obniżki inflacji. Duże wahania efektem działań rządu
 - [https://businessinsider.com.pl/gospodarka/inflacja-w-czechach-w-listopadzie-przyspieszyly-podwyzki-cen/r85c89k](https://businessinsider.com.pl/gospodarka/inflacja-w-czechach-w-listopadzie-przyspieszyly-podwyzki-cen/r85c89k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 09:47:33+00:00

Po krótkiej przerwie podwyżki cen w Czechach przyspieszyły. Bardziej niż spodziewali się eksperci. Wskazują, że w październiku inflacja spadła przez rządowe subsydia, a w listopadzie wzrosła przez efekty bazowe związane z obniżką VAT.

## Blisko 18 proc. mikrofirm chce zmienić formę działalności. Głównym powodem są obciążenia ZUS-owskie
 - [https://businessinsider.com.pl/firmy/skladki-na-zus-blisko-18-proc-mikrofirm-chce-zmienic-forme-dzialalnosci/bwsp5rx](https://businessinsider.com.pl/firmy/skladki-na-zus-blisko-18-proc-mikrofirm-chce-zmienic-forme-dzialalnosci/bwsp5rx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 09:36:10+00:00

Obciążenia ZUS-owskie oraz podatkowe to główne powody, dla których mikrofirmy chcą zmieniać formę działalności. Ponad połowa spośród tych, którzy planują zmiany, deklaruje przejście na spółkę z ograniczoną odpowiedzialnością, a co dziesiąty respondent planujący przekształcenie chce wybrać spółkę komandytową.

## Miał być kolejny pakiet sankcji, ale w UE wciąż nie ma porozumienia
 - [https://businessinsider.com.pl/gospodarka/mial-byc-kolejny-pakiet-sankcji-ale-w-ue-wciaz-nie-ma-porozumienia/gy0x7w2](https://businessinsider.com.pl/gospodarka/mial-byc-kolejny-pakiet-sankcji-ale-w-ue-wciaz-nie-ma-porozumienia/gy0x7w2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 09:26:49+00:00

Wciąż nie ma jeszcze porozumienia w sprawie kolejnego — dziewiątego — pakietu sankcji przeciwko Rosji za agresję na Ukrainę — poinformował w poniedziałek w Brukseli szef unijnej dyplomacji Josep Borrell. Wyraził nadzieję, że porozumienie uda się osiągnąć w poniedziałek lub wtorek.

## Rząd tworzy nowe przejście graniczne
 - [https://businessinsider.com.pl/wiadomosci/nowy-swiat-nowe-przejscie-graniczne-w-miejscu-przekopu-mierzei/exnt6h2](https://businessinsider.com.pl/wiadomosci/nowy-swiat-nowe-przejscie-graniczne-w-miejscu-przekopu-mierzei/exnt6h2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 09:03:18+00:00

Utworzenie nowego morskiego przejścia granicznego Nowy Świat w miejscu przekopu Mierzei Wiślanej – to jedno z rozwiązań projektowanego rozporządzenia Rady Ministrów, które trafiło do opiniowania. Zmienić ma się ponadto status przejścia granicznego na terenie lotniska w Radomiu.

## Słodko-gorzkie wnioski z badania ofert pracy. Nie spełnił się czarny scenariusz
 - [https://businessinsider.com.pl/wiadomosci/ogloszenia-o-prace-na-portalach-kogo-szukaja-firmy/qx4ex7j](https://businessinsider.com.pl/wiadomosci/ogloszenia-o-prace-na-portalach-kogo-szukaja-firmy/qx4ex7j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 08:54:30+00:00

W listopadzie w internecie pojawiło się prawie 298 tys. nowych ofert pracy. Jest ich więcej niż przed i w trakcie pandemii, ale zarysowuje się negatywny trend. Największy wzrost liczby ofert pracy zanotowano w finansach. W przypadku zawodów fizycznych już od kilku miesięcy notowane są duże spadki.

## Mercedes zapowiada wielką inwestycję w Polsce. Zostawi u nas miliard euro
 - [https://businessinsider.com.pl/biznes/mercedes-zapowiada-wielka-inwestycje-otworzy-nowa-fabryke-w-polsce/flp8gbc](https://businessinsider.com.pl/biznes/mercedes-zapowiada-wielka-inwestycje-otworzy-nowa-fabryke-w-polsce/flp8gbc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 08:25:31+00:00

Mercedes-Benz zainwestuje miliard euro w fabrykę w Jaworze - poinformowali podczas konferencji prasowej z udziałem premiera Morawieckiego i marszałek Sejmu Elżbiety Witek przedstawiciele niemieckiego giganta.

## Wypadek na śliskim chodniku. Wyjaśniamy, co z odszkodowaniem
 - [https://businessinsider.com.pl/twoje-pieniadze/budzet-domowy/nieodsniezone-chodniki-odszkodowanie-za-upadek-na-lodzie/rd8lr4p](https://businessinsider.com.pl/twoje-pieniadze/budzet-domowy/nieodsniezone-chodniki-odszkodowanie-za-upadek-na-lodzie/rd8lr4p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 08:20:00+00:00

Skręcona kostka lub złamana noga na oblodzonym chodniku? W takiej sytuacji można dochodzić odszkodowania i zadośćuczynienia sięgającego nawet kilkudziesięciu tysięcy złotych.

## Kurs franka 12 grudnia w okolicach 4,75 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-12-grudnia-2022/gp4myxw](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-12-grudnia-2022/gp4myxw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 08:12:20+00:00

Frank szwajcarski w okolicach 4,75 zł. W poniedziałek rano 12 grudnia 2022 r. kurs tej waluty wobec polskiego złotego wynosi 4,7593.

## Kurs euro 12 grudnia poniżej 4,7
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-12-grudnia-2022/h3ztmxs](https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-12-grudnia-2022/h3ztmxs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 08:10:33+00:00

Kurs euro poniżej 4,7 zł. W poniedziałek rano 12 grudnia 2022 r. kurs EUR/PLN wynosił 4,6863 zł.

## Kurs dolara 12 grudnia poniżej 4,5 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-12-grudnia-2022/962ykxj](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-12-grudnia-2022/962ykxj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 08:08:41+00:00

Kurs dolara poniżej 4,5 zł. W poniedziałek rano 12 grudnia 2022 r. kurs USD/PLN wynosi 4,4526.

## Zakonnica na liście najbardziej wpływowych kobiet. "Jedyna z prawem głosu"
 - [https://businessinsider.com.pl/wiadomosci/siostra-zakonna-jedna-z-najbardziej-wplywowych-kobiet-swiata-czym-sie-zajmuje/sgdxzjl](https://businessinsider.com.pl/wiadomosci/siostra-zakonna-jedna-z-najbardziej-wplywowych-kobiet-swiata-czym-sie-zajmuje/sgdxzjl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 08:05:06+00:00

Nathalie Becquart znalazła się na liście stu najbardziej wpływowych i inspirujących kobiet 2022 r. według BBC. Siostra należąca do zgromadzenia ksawerianek jest ważną postacią w Watykanie, a papież Franciszek powołał ją na podsekretarza Synodu Biskupów. Jest pierwszą kobietą w historii, która sprawuje tę funkcję.

## Od tego zaczynał Jerzy Starak. Dziś bogatszy jest tylko jeden Polak
 - [https://businessinsider.com.pl/od-tego-zaczynal-jerzy-starak-dzis-bogatszy-jest-tylko-jeden-polak/f16d6mr](https://businessinsider.com.pl/od-tego-zaczynal-jerzy-starak-dzis-bogatszy-jest-tylko-jeden-polak/f16d6mr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 08:03:55+00:00

Jerzy Starak, drugi na liście najbogatszych Polaków, zaczynał w latach 70. od sprzedaży maszyn, perfum i keczupu. Największe zyski przyniosły mu inwestycje w produkcję leków. Tylko w ostatnim roku wzbogacił się na nich o 5,6 mld zł.

## Za źle odśnieżone auto można dostać po kieszeni. Kierowcom grozi nawet do 500 zł mandatu
 - [https://businessinsider.com.pl/technologie/motoryzacja/mandat-za-nieodsniezone-auto-kierowcom-grozi-nawet-do-500-zl-kary/9gle6ke](https://businessinsider.com.pl/technologie/motoryzacja/mandat-za-nieodsniezone-auto-kierowcom-grozi-nawet-do-500-zl-kary/9gle6ke)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 07:55:00+00:00

Tegoroczna zima wyjątkowo obfituje w śnieg. To, oprócz frajdy dla dzieci, obowiązek dla kierowców. Warto przed ruszeniem w trasę poświęcić kilka minut na odśnieżenie samochodu, bo kara za pokryte śniegiem części auta może być dotkliwa.

## Za źle odśnieżone auto można dostać po kieszeni. Kierowcom grozi nawet do kilka tys. zł mandatu
 - [https://businessinsider.com.pl/technologie/motoryzacja/mandat-za-nieodsniezone-auto-kierowcom-grozi-nawet-do-3-tys-zl-kary/9gle6ke](https://businessinsider.com.pl/technologie/motoryzacja/mandat-za-nieodsniezone-auto-kierowcom-grozi-nawet-do-3-tys-zl-kary/9gle6ke)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 07:55:00+00:00

Tegoroczna zima wyjątkowo obfituje w śnieg. To, oprócz frajdy dla dzieci, obowiązek dla kierowców. Warto przed ruszeniem w trasę poświęcić kilka minut na odśnieżenie samochodu, bo kara za pokryte śniegiem części auta może być dotkliwa.

## Chcesz wiedzieć, czy pracownik pił? Prawnik wyjaśnia, jak korzystać z nowych przepisów prawa pracy
 - [https://businessinsider.com.pl/prawo/praca/jak-i-gdzie-zbadac-trzezwosc-pracownikow-analiza-prawna-nowych-przepisow/2wpgffy](https://businessinsider.com.pl/prawo/praca/jak-i-gdzie-zbadac-trzezwosc-pracownikow-analiza-prawna-nowych-przepisow/2wpgffy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 07:46:23+00:00

Lepiej zlecić badanie pracowników swojemu podwładnemu niż ochroniarzowi. Warto rozważyć wydzielenie odrębnego pomieszczenia do testowania — mówi dr Dominika Dörre-Kolasa, partner w kancelarii Raczkowski. W rozmowie z Business Insider tłumaczy, co ma zrobić pracodawca, gdy badanie wskaże stężenie poniżej 0,1 mg w wydychanym powietrzu.

## Magia świąt w 250 mln produktów
 - [https://businessinsider.com.pl/twoje-pieniadze/zakupy-business-insider/magia-swiat-w-250-mln-produktow/q6335bq](https://businessinsider.com.pl/twoje-pieniadze/zakupy-business-insider/magia-swiat-w-250-mln-produktow/q6335bq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 07:37:17+00:00

Prezenty na święta. Co kupić, by było oryginalnie, z pomysłem, a przy tym, by prezent był trafiony? I czy można połączyć kupowanie prezentów ze wsparciem dla polskich firm i artystów? A do tego, wesprzeć charytatywny cel?

## Neurobiolożka wyjaśnia, jakie ćwiczenia są najlepsze dla mózgu
 - [https://businessinsider.com.pl/lifestyle/jak-cwiczyc-by-wspomoc-mozg/3rlf0gb](https://businessinsider.com.pl/lifestyle/jak-cwiczyc-by-wspomoc-mozg/3rlf0gb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 07:25:00+00:00

Dr Wendy Suzuki, neurobiolożka z Uniwersytetu Nowojorskiego, mówi, kiedy najlepiej wykonywać ćwiczenia fizyczne, by pozytywnie wpływały one na mózg. Zastrzega jednak, że wiele zależy od tego, na jakim poziomie aktywności już się jest.

## Jak powiedzieć "nie" szefowi, gdy dorzuca ci zadań. Podpowiada ekspertka
 - [https://businessinsider.com.pl/rozwoj-osobisty/kariera/jak-powiedziec-nie-szefowi/7vr2bnn](https://businessinsider.com.pl/rozwoj-osobisty/kariera/jak-powiedziec-nie-szefowi/7vr2bnn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 07:24:00+00:00

Pewnie wiele razy zdarzyło się, że szef prosił cię o zrobienie czegoś, co powinno być wykonane przez kolegę na innym stanowisku lub kogoś, kto w danym momencie miał mniej na głowie niż ty. Kusi, by w takiej sytuacji powiedzieć: "To nie należy do moich obowiązków". Nie jest to jednak najlepsze wyjście z sytuacji.

## Kary za seks pozamałżeński w Indonezji. "Nie będzie sprawdzania stanu cywilnego w hotelach na Bali"
 - [https://businessinsider.com.pl/wiadomosci/kary-za-seks-pozamalzenski-w-indonezji-gubernator-bali-mowi-co-z-turystami/c9d491l](https://businessinsider.com.pl/wiadomosci/kary-za-seks-pozamalzenski-w-indonezji-gubernator-bali-mowi-co-z-turystami/c9d491l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 07:18:03+00:00

Nowoprzyjęte przez Indonezję prawo uznaje seks pozamałżeński za przestępstwo. Przepisy mają formalnie wejść w życie za trzy lata. Gubernator Bali uspokaja turystów, że zmienione prawo nie powinno być dla nich zagrożeniem.

## UE ma dość obchodzenia sankcji na Rosję. Znalazła rozwiązanie
 - [https://businessinsider.com.pl/gospodarka/ue-ma-dosc-obchodzenia-sankcji-na-rosje-znalazla-rozwiazanie/2pms1jb](https://businessinsider.com.pl/gospodarka/ue-ma-dosc-obchodzenia-sankcji-na-rosje-znalazla-rozwiazanie/2pms1jb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 07:09:28+00:00

Bruksela ma powołać nowego pełnomocnika ds. sankcji, który będzie naciskał na ich ściślejsze egzekwowanie. Ma skupić się przede wszystkim na Turcji, która najczęściej próbuje obchodzić unijne sankcje na kraj Rosję. Na celowniku są też dwa inne kraje.

## Nie hamuj łez. Płacz w miejscu pracy jest dobry dla twojego zdrowia
 - [https://businessinsider.com.pl/rozwoj-osobisty/kariera/plakanie-w-pracy-dobre-dla-zdrowia-badania-2019/zdljsym](https://businessinsider.com.pl/rozwoj-osobisty/kariera/plakanie-w-pracy-dobre-dla-zdrowia-badania-2019/zdljsym)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 07:03:00+00:00

Z ankiety przeprowadzonej przez Monster wynika, że 8 na 10 pracowników płakało kiedyś w swoim miejscu pracy. Niemal 50 proc. badanych zdarzyło się to więcej niż raz. Również prawie połowa z nich przyznała, że płacz był spowodowany tym, jak zostali potraktowani przez szefa lub kolegów z biura. Choć takie sytuacje nie powinny się zdarzać, ostatnie badania pokazują, że jeśli już zostaniemy doprowadzeni do płaczu w pracy, absolutnie nie powinniśmy hamować łez.

## Jak firma może zwiększać swoją efektywność energetyczną?
 - [https://businessinsider.com.pl/technologie/jak-firma-moze-zwiekszac-swoja-efektywnosc-energetyczna/x09bdqd](https://businessinsider.com.pl/technologie/jak-firma-moze-zwiekszac-swoja-efektywnosc-energetyczna/x09bdqd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 06:50:00+00:00

Kryzys na rynku energetycznym jest faktem. Przedsiębiorcy mogą jednak zmniejszać swoje koszty oraz zabezpieczyć się przed ewentualną niedostępnością energii, podejmując liczne działania — o charakterze bieżącym i krótkoterminowym oraz długofalowym. Podpowiadamy, jakie kroki mogą przedsięwziąć – na przykładzie firm, które już je wykonały.

## Wicepremier: to koniec gwałtownego wzrostu cen żywności
 - [https://businessinsider.com.pl/gospodarka/wicepremier-to-koniec-gwaltownego-wzrostu-cen-zywnosci/p6x7j4q](https://businessinsider.com.pl/gospodarka/wicepremier-to-koniec-gwaltownego-wzrostu-cen-zywnosci/p6x7j4q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 06:35:49+00:00

Zdaniem Henryka Kowalczyka gwałtowny wzrost cen żywności mamy już za sobą. O ile na Ukrainie nie wydarzy się nic takiego, co znów spowodowałoby wzrost cen energii - zastrzegł minister rolnictwa i rozwoju wsi.

## Czego pragną dzisiaj klienci, czyli jaki powinien być sklep idealny
 - [https://businessinsider.com.pl/twoje-pieniadze/zakupy-business-insider/czego-pragna-dzisiaj-klienci-czyli-jaki-powinien-byc-sklep-idealny/nygxj1q](https://businessinsider.com.pl/twoje-pieniadze/zakupy-business-insider/czego-pragna-dzisiaj-klienci-czyli-jaki-powinien-byc-sklep-idealny/nygxj1q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 06:30:00+00:00

Klienci mają dzisiaj dużo większe wymagania wobec sprzedających niż w przeszłości. 9 na 10 osób deklaruje na przykład, że w sklepie tradycyjnym oczekuje podobnych doświadczeń zakupowych jak w e-commerce – zakupy mają być szybkie, wygodne i bezpieczne. Pytanie, jak to zrobić?

## Zmiany dla właścicieli psów. PiS chce wprowadzić nowy obowiązek
 - [https://businessinsider.com.pl/wiadomosci/zmiany-dla-wlascicieli-psow-pis-chce-wprowadzic-nowy-obowiazek/wtbzsbw](https://businessinsider.com.pl/wiadomosci/zmiany-dla-wlascicieli-psow-pis-chce-wprowadzic-nowy-obowiazek/wtbzsbw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 06:24:21+00:00

Szykują się nowe obowiązki dla właścicieli czworonogów. Mówił o nich podczas niedzielnej konferencji w Przysusze wicepremier i minister rolnictwa Henryk Kowalczyk. - Chcemy wprowadzić ustawę o obowiązku czipowania psów. Tak, żeby każdy był odpowiedzialny za to zwierzę, którym się opiekuje - zapowiedział.

## Erdogan straszy Greków. Mówi o rakietach, które "przerażają" Ateny
 - [https://businessinsider.com.pl/wiadomosci/tureckie-rakiety-tajfun-recep-erdogan-straszy-grekow/ml4jclf](https://businessinsider.com.pl/wiadomosci/tureckie-rakiety-tajfun-recep-erdogan-straszy-grekow/ml4jclf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 06:21:37+00:00

Rośnie napięcie między Grecją a Turcją po zakupie amerykańskiego uzbrojenia przez Greków. "Tureckie testy rakiet balistycznych przerażają Ateny" — powiedział w niedzielę prezydent Recep Tayyip Erdogan, zapewniając, że wyprodukowana przez Turcję rakieta balistyczna krótkiego zasięgu jest w stanie uderzyć w grecką stolicę. Oba państwa od lat spierają się o terytoria na Morzu Egejskim.

## To może być frankowa rewolucja. Sprawy wreszcie przyspieszą
 - [https://businessinsider.com.pl/gospodarka/to-moze-byc-frankowa-rewolucja-sprawy-wreszcie-przyspiesza/0f4kbnr](https://businessinsider.com.pl/gospodarka/to-moze-byc-frankowa-rewolucja-sprawy-wreszcie-przyspiesza/0f4kbnr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 06:14:45+00:00

Pozew w sprawie kredytu walutowego będzie można złożyć tylko w sądzie właściwym dla miejsca zamieszkania konsumenta. Dzięki temu frankowicze na wyrok poczekają znacznie krócej – informuje poniedziałkowy "Dziennik Gazeta Prawna". Dziś na pierwszy termin trzeba czekać nawet do połowy 2025 r.

## W listopadzie zakupy były droższe o 26 proc. Najnowsza analiza
 - [https://businessinsider.com.pl/gospodarka/w-listopadzie-zakupy-byly-drozsze-o-26-proc-najnowsza-analiza/7lqgj0t](https://businessinsider.com.pl/gospodarka/w-listopadzie-zakupy-byly-drozsze-o-26-proc-najnowsza-analiza/7lqgj0t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 06:00:52+00:00

Codzienne zakupy w listopadzie były droższe średnio o 25,8 proc. niż w tym samym miesiącu rok temu - wynika z najnowszego "Indeksu cen w sklepach detalicznych". Zdrożały wszystkie z 12 analizowanych kategorii produktów, a ich średnie wzrosty znowu są dwucyfrowe. Najgorzej jest w przypadku żywności.

## Schematy podatkowe. Kto nie składa, popełnia błąd i ułatwia zadanie fiskusowi
 - [https://businessinsider.com.pl/prawo/podatki/schematy-podatkowe-czasie-pandemii-czy-skladac-mdr-jak-i-dlaczego/qm22s5g](https://businessinsider.com.pl/prawo/podatki/schematy-podatkowe-czasie-pandemii-czy-skladac-mdr-jak-i-dlaczego/qm22s5g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 05:59:18+00:00

Część podatników zapomniała w ogóle o krajowych schematach podatkowych. Zdaniem ekspertów to błąd. Warto je zbierać, a najlepiej składać na bieżąco. W tym roku zrobiło to już kilka tysięcy podmiotów. Trwają też ciągle spory o to, kto powinien zgłaszać schematy. W czwartek 8 grudnia 2022 r. zapadł precedensowy wyrok Trybunału Sprawiedliwości UE w tej sprawie, a kolejne sprawy czekają na rozpatrzenie. Polski Trybunał Konstytucyjny też ma zbadać te przepisy.

## Nowe ryzyko w sektorze bankowym. Sąd unieważnił kredyt hipoteczny w złotych
 - [https://businessinsider.com.pl/gospodarka/piec-najciekawszych-wydarzen-w-gospodarce-teraz-12122022/d3n5gjk](https://businessinsider.com.pl/gospodarka/piec-najciekawszych-wydarzen-w-gospodarce-teraz-12122022/d3n5gjk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 05:52:50+00:00

Dziś przekonamy się, czy notowania giełdowe banków zareagują na pierwszy wyrok sądowy unieważniający kredyt hipoteczny w złotych, a nie we frankach. Wyrok jest na razie nieprawomocny i dotyczy dość specyficznej sprawy. Firmy ubezpieczeniowe wypłacają coraz więcej odszkodowań związanych z kataklizmami pogodowymi, przez co mają mniejsze zyski. Unia znalazła sposób na to, aby obejść weto Węgier i pożyczyć Ukrainie 18 mld euro. Z kolei europejskie banki spłacają przed terminem blisko pół biliona pożyczek z Europejskiego Banku Centralnego, a najnowsze dane o inflacji z USA są pozytywne i negatywne jednocześnie. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Trzynastki i czternastki będą co roku. Jest deklaracja Morawieckiego
 - [https://businessinsider.com.pl/twoje-pieniadze/emerytury/trzynastki-i-czternastki-beda-co-roku-jest-deklaracja-morawieckiego/b8sqsk2](https://businessinsider.com.pl/twoje-pieniadze/emerytury/trzynastki-i-czternastki-beda-co-roku-jest-deklaracja-morawieckiego/b8sqsk2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 05:49:43+00:00

Jeśli będziemy nadal rządzić, trzynastka i czternastka będą utrzymane. Chcemy czternastkę na stałe wpisać do ustawy – powiedział premier Mateusz Morawiecki w poniedziałkowym "Super Expressie".

## Izera potrzebuje 6 mld zł, by ruszyć. Prezes firmy mówi, skąd je weźmie i gdzie sprzeda 100 tys. polskich elektryków [WYWIAD]
 - [https://businessinsider.com.pl/technologie/motoryzacja/izera-potrzebuje-6-mld-zl-skad-pieniadze-na-polski-samochod-elektryczny-wywiad/pfnrcmf](https://businessinsider.com.pl/technologie/motoryzacja/izera-potrzebuje-6-mld-zl-skad-pieniadze-na-polski-samochod-elektryczny-wywiad/pfnrcmf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 05:40:00+00:00

Chcą sprzedawać 100 tys. samochodów, choć nie będą budować sieci dilerskiej. Wierzą, że uda im się zachęcić do kupna polskiego elektryka nie tylko Polaków, ale też wyprzedzić znane marki i przekonać do niego pozostałych Europejczyków. W rozmowie z Business Insider Polska prezes ElectroMobility Poland (EMP) mówi o szczegółach współpracy z Chińczykami, o tym, jak długo "projekt Izera" będzie finansowany z publicznych pieniędzy, a także czy są plany, by w przyszłości odsprzedać markę zagranicznemu kapitałowi.

## Nieoficjalnie: PiS ma plan na KPO. Rozłam w rządzie? "Kluczowy tydzień"
 - [https://businessinsider.com.pl/gospodarka/pis-ma-plan-na-kpo-rozlam-w-rzadzie-kluczowy-tydzien/x9xflxj](https://businessinsider.com.pl/gospodarka/pis-ma-plan-na-kpo-rozlam-w-rzadzie-kluczowy-tydzien/x9xflxj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 05:31:47+00:00

Mateusz Morawiecki ma świadomość, że bez pieniędzy z Krajowego Planu Odbudowy Polsce będzie trudno spiąć przyszłoroczny budżet. Dlatego ma już plan, jak te środki odzyskać. W tym celu chce pominąć Solidarną Polskę, która akceptacji planu mocno się sprzeciwia - donosi "Rzeczpospolita".

## Zapaść na rynku kredytów. Jak wpłynie na ceny mieszkań?
 - [https://businessinsider.com.pl/twoje-pieniadze/ceny-mieszkan-zapasc-na-rynku-kredytow-przelozy-sie-na-obnizki/bdm8qtw](https://businessinsider.com.pl/twoje-pieniadze/ceny-mieszkan-zapasc-na-rynku-kredytow-przelozy-sie-na-obnizki/bdm8qtw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 05:22:56+00:00

Mocny spadek liczby udzielanych kredytów wpływa na zmniejszony ruch na rynku nieruchomości zarówno wtórnym, jak i pierwotnym. Mieszkania coraz gorzej się sprzedają. To każe wypatrywać spadków cen. Na horyzoncie dużych obniżek jednak na razie nie widać. Czy sytuacja zmieni się w najbliższym czasie?

## Glapiński dostał nagrodę. "Za wybitne zarządzanie NBP"
 - [https://businessinsider.com.pl/gospodarka/glapinski-dostal-nagrode-za-wybitne-zarzadzanie-nbp/ytm05rw](https://businessinsider.com.pl/gospodarka/glapinski-dostal-nagrode-za-wybitne-zarzadzanie-nbp/ytm05rw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 05:19:15+00:00

Prezes NBP Adam Glapiński otrzymał w niedzielę nagrodę za wybitne zarządzanie Narodowym Bankiem Polskim w czasach pandemii, wojny w Ukrainie i kryzysu energetycznego. Wyróżnienie przyznała grupa Polska Press, przejęta w 2021 r. przez Orlen. Wśród nagrodzonych znaleźli się też m.in. Mariusz Błaszczak, Henryk Kowalczyk czy TVP.

## To może być gospodarcze słowo 2023 r. Czym dokładnie jest dezinflacja?
 - [https://businessinsider.com.pl/finanse/makroekonomia/dezinflacja-to-moze-byc-gospodarcze-slowo-2023-r-co-oznacza/wr66vv8](https://businessinsider.com.pl/finanse/makroekonomia/dezinflacja-to-moze-byc-gospodarcze-slowo-2023-r-co-oznacza/wr66vv8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-12 05:10:09+00:00

Tak jak młodzieżowym słowem w 2022 r. została "essa", tak najpopularniejszym wyrażeniem w świecie gospodarczym może w 2023 r. być "dezinflacja". Od razu tonujemy jednak nadmierny optymizm. Termin ten nie oznacza, że ceny będą spadały.


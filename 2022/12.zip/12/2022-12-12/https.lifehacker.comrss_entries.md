# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## 7 of the Best Videos to Start (or Perfect) Your Deadlift
 - [https://lifehacker.com/7-of-the-best-videos-to-start-or-perfect-your-deadlif-1849884715](https://lifehacker.com/7-of-the-best-videos-to-start-or-perfect-your-deadlif-1849884715)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 23:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--IoG0Kni0--/c_fit,fl_progressive,q_80,w_636/3e8fb011374de0f9cdaa63dea1e67cb9.jpg" /><p>The deadlift is one of the simplest things you can do in the gym: You just grab a barbell, and stand up. But it’s also one of the most intimidating. If you’ve been told all your life to “lift with your legs, not your back,” you may worry that you’ll accidentally lift with your back and something terrible will happen.…</p><p><a href="https://lifehacker.com/7-of-the-best-videos-to-start-or-perfect-your-deadlif-1849884715">Read more...</a></p>

## The Geminid Meteor Shower Is About to Peak
 - [https://lifehacker.com/the-geminid-meteor-shower-is-about-to-peak-1849884314](https://lifehacker.com/the-geminid-meteor-shower-is-about-to-peak-1849884314)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 22:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--hIHLNG9T--/c_fit,fl_progressive,q_80,w_636/5ff2c179301b97fb7a1eb2a463c6f04f.jpg" /><p>This Wednesday and Thursday, Dec. 14 and 15, marks the peak of the annual Geminid meteor shower, a highlight of the year for meteor fans. You should be able to spot many shooting stars for the low, low price of looking into the nighttime sky.<br /></p><p><a href="https://lifehacker.com/the-geminid-meteor-shower-is-about-to-peak-1849884314">Read more...</a></p>

## Don’t Let a Future Breakup Ruin This Year’s Holiday Photos
 - [https://lifehacker.com/don-t-let-a-future-breakup-ruin-this-year-s-holiday-pho-1849883978](https://lifehacker.com/don-t-let-a-future-breakup-ruin-this-year-s-holiday-pho-1849883978)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 22:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--y4WVi_bA--/c_fit,fl_progressive,q_80,w_636/7bfd091b559b4cc3c1629e34b2055b10.jpg" /><p>It’s so uniquely aggravating to scroll through old photos and see one where you look great or are having a wonderful time, but your ex is right there next to you. You can’t repost that picture as a throwback. Depending on how toxic the breakup was, you might even feel compelled to archive it so it’s no longer visible…</p><p><a href="https://lifehacker.com/don-t-let-a-future-breakup-ruin-this-year-s-holiday-pho-1849883978">Read more...</a></p>

## 12 of the Best Gifts for Someone Who Needs Help Relaxing
 - [https://lifehacker.com/12-of-the-best-gifts-for-someone-who-needs-help-relaxin-1849883700](https://lifehacker.com/12-of-the-best-gifts-for-someone-who-needs-help-relaxin-1849883700)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--sTCCszXL--/c_fit,fl_progressive,q_80,w_636/d55b96a67d51ae51f179ec3cf65a9b8a.jpg" /><p>You know when you are checking out at a department or drug store during the holiday season and you see those big, pre-made gift baskets filled with lotion and fuzzy socks? Those are fine. I usually get, like, two or three of those as gifts every year, and I have no real issue with fuzzy socks. <br /><br />But if you’re trying to…</p><p><a href="https://lifehacker.com/12-of-the-best-gifts-for-someone-who-needs-help-relaxin-1849883700">Read more...</a></p>

## How to Feel More at Home When Traveling for the Holidays
 - [https://lifehacker.com/how-to-feel-more-at-home-when-traveling-for-the-holiday-1849882815](https://lifehacker.com/how-to-feel-more-at-home-when-traveling-for-the-holiday-1849882815)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--rMlY7-m_--/c_fit,fl_progressive,q_80,w_636/96c114431e338090d68e523087a7258f.jpg" /><p>Travel—whether it’s for the holidays, vacation, or for business—is a double-edged experience. It can be exciting to see new places, comforting to be with family, or thrilling to pursue professional goals, but <a href="https://www.webmd.com/anxiety-panic/what-to-know-travel-anxiety" rel="noopener noreferrer" target="_blank">travel can also be stressful</a>, and <a href="https://lifehacker.com/how-to-manage-your-anxiety-during-the-holidays-1849862228">doubly so during the holidays</a>. Aside from the frantic nature of actually…</p><p><a href="https://lifehacker.com/how-to-feel-more-at-home-when-traveling-for-the-holiday-1849882815">Read more...</a></p>

## That Terrifying Call From Your ‘Mom’ Might Be a Scam
 - [https://lifehacker.com/that-terrifying-call-from-your-mom-might-be-a-scam-1849883646](https://lifehacker.com/that-terrifying-call-from-your-mom-might-be-a-scam-1849883646)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--EqNSun8r--/c_fit,fl_progressive,q_80,w_636/9569a2a9ff4ca9b2a50311e1faefac09.jpg" /><p>These days, I get so many spam calls I hardly pick up the phone anymore. However, if I see a call from someone I know, whether they’re a friend or family member, I, of course, answer them (usually). Unlike a random number, I <em>know</em> the person on the other end of the line, because I have their contact in my phone, right?…</p><p><a href="https://lifehacker.com/that-terrifying-call-from-your-mom-might-be-a-scam-1849883646">Read more...</a></p>

## Why You Should Slice the Potatoes for Your Next Mash
 - [https://lifehacker.com/why-you-should-slice-the-potatoes-for-your-next-mash-1849883620](https://lifehacker.com/why-you-should-slice-the-potatoes-for-your-next-mash-1849883620)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--DZROYMLZ--/c_fit,fl_progressive,q_80,w_636/ff46396fc35bea35fddaf7af83463daf.jpg" /><p>There are <a href="https://lifehacker.com/9-tips-for-perfect-mashed-potatoes-1845692616">a lot of ways</a> to prepare mashed potatoes, and almost all of them are valid (even, or especially, <a href="https://lifehacker.com/how-to-make-perfect-mashed-potatoes-in-the-microwave-1846629900">the microwave method</a>). Most mashed potato recipes start the same way: Cube the spuds into roughly 1 1/2-inch chunks, then cook them in simmering water until they can be easily mashed with a fork. This usually…</p><p><a href="https://lifehacker.com/why-you-should-slice-the-potatoes-for-your-next-mash-1849883620">Read more...</a></p>

## You Can Get a Free McDonald’s Crispy Chicken Sandwich Right Now
 - [https://lifehacker.com/you-can-get-a-free-mcdonald-s-crispy-chicken-sandwich-r-1849883072](https://lifehacker.com/you-can-get-a-free-mcdonald-s-crispy-chicken-sandwich-r-1849883072)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 19:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--BOvYwBYy--/c_fit,fl_progressive,q_80,w_636/ff6bf2378eea2c0e09a20d51cf5fcb69.jpg" /><p><a href="https://corporate.mcdonalds.com/corpmcd/our-stories/article/holiday-McGold-card.html#:~:text=Introducing%3A%20the-,SZN%20of%20Sharing,-%2C%20a%20first%2Dof" rel="noopener noreferrer" target="_blank">McDonald’s “SZN 0f Sharing</a>” is in full force, and this week’s deal features the <a href="https://www.mcdonalds.com/us/en-us/product/crispy-chicken-sandwich.html" rel="noopener noreferrer" target="_blank">Crispy Chicken Sandwich</a>, a classic item made of just four ingredients: a potato roll bun, pickles, crispy fried chicken, and salted butter. The featured sandwich is currently offered as a buy one, get one free (BOGO) deal until Dec. 14.…</p><p><a href="https://lifehacker.com/you-can-get-a-free-mcdonald-s-crispy-chicken-sandwich-r-1849883072">Read more...</a></p>

## Host the Best Freakin' Holiday Cookie Exchange Ever
 - [https://lifehacker.com/host-the-best-freakin-holiday-cookie-exchange-ever-1849883109](https://lifehacker.com/host-the-best-freakin-holiday-cookie-exchange-ever-1849883109)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--5uCdYs_C--/c_fit,fl_progressive,q_80,w_636/5179eb116a45dca809bebf3455f5f316.jpg" /><p>A good holiday cookie exchange can leave you feeling cozy, content, and full of joy and sugar. A bad cookie exchange is disappointing, unexpectedly competitive, and might make you realize there is such a thing as too many cookies. Don’t let a terrible cookie exchange come to pass. Follow these tips to host a cookie…</p><p><a href="https://lifehacker.com/host-the-best-freakin-holiday-cookie-exchange-ever-1849883109">Read more...</a></p>

## Stop Using These ‘Hacks’ That Will Dry Out Your Christmas Tree
 - [https://lifehacker.com/stop-using-these-hacks-that-will-kill-your-christmas-1849883207](https://lifehacker.com/stop-using-these-hacks-that-will-kill-your-christmas-1849883207)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 18:46:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--6lJRrgBq--/c_fit,fl_progressive,q_80,w_636/39e0dc46731cffb1ff137aa0f2b63d10.jpg" /><p>A live Christmas tree would seem to be a fine project for somebody with a brown thumb. You only have to tend it for a month, and then it’ll get chucked to the curb. But it’s important to keep your tree fresh and happy during that time, lest it <a href="https://lifehacker.com/your-neglected-christmas-tree-is-a-huge-fire-hazard-1790551563">turn into a fire hazard</a>. <br /><br />Unfortunately, bogus “hacks” abound that will…</p><p><a href="https://lifehacker.com/stop-using-these-hacks-that-will-kill-your-christmas-1849883207">Read more...</a></p>

## Eight of the Best Reusable Alternatives to Traditional Wrapping Paper
 - [https://lifehacker.com/eight-of-the-best-reusable-alternatives-to-traditional-1849881129](https://lifehacker.com/eight-of-the-best-reusable-alternatives-to-traditional-1849881129)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 18:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--JqwrONNs--/c_fit,fl_progressive,q_80,w_636/5e1b655eb90bc1388e224e36edae23d3.jpg" /><p>While wrapped presents are a big part of the joy of holiday gifting, all that disposable wrapping paper can seem pretty wasteful, not to mention expensive. Bringing in some reusable alternatives that actually look nice can add some sustainable and cost-effective beauty to your holiday gift-giving routine. The best…</p><p><a href="https://lifehacker.com/eight-of-the-best-reusable-alternatives-to-traditional-1849881129">Read more...</a></p>

## Stop Your MacBook Charger From Falling Off the Wall
 - [https://lifehacker.com/stop-your-macbook-charger-from-falling-off-the-wall-1849882528](https://lifehacker.com/stop-your-macbook-charger-from-falling-off-the-wall-1849882528)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 17:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--r6DDuCIQ--/c_fit,fl_progressive,q_80,w_636/91bdb95944bb0b88e4e2181b8413b381.jpg" /><p>Whether you have a MacBook, MacBook Air, or MacBook Pro, your charger likely has one fatal flaw: the plug. The power adapter needs to connect directly to an outlet, a design that works fine for smaller charging bricks. However, the bigger your MacBook, the bigger the brick, all without changing the design. As such,…</p><p><a href="https://lifehacker.com/stop-your-macbook-charger-from-falling-off-the-wall-1849882528">Read more...</a></p>

## The 20 Best TV Shows of 2022
 - [https://lifehacker.com/the-20-best-tv-shows-of-2022-1849880017](https://lifehacker.com/the-20-best-tv-shows-of-2022-1849880017)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--yBISvhTr--/c_fit,fl_progressive,q_80,w_636/8c3ddb35a8a86af63ef383e7099dcc18.jpg" /><p>As movie theaters become ever more focused on four-quadrant blockbusters designed to offend as few people as possible, TV has become a playground for experimentation. At least for now—if the streaming service buuble didn’t pop in 2022, it’s definitely leaking. As Netflix stock cratered and HBO Max tried to figure out…</p><p><a href="https://lifehacker.com/the-20-best-tv-shows-of-2022-1849880017">Read more...</a></p>

## You Can Still Buy These Apple Devices as Holiday Gifts
 - [https://lifehacker.com/you-can-still-buy-these-apple-devices-as-holiday-gifts-1849878232](https://lifehacker.com/you-can-still-buy-these-apple-devices-as-holiday-gifts-1849878232)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--xaBstnGb--/c_fit,fl_progressive,q_80,w_636/144431fe37cc49b65c1eb43ec53eaee9.jpg" /><p>If you’re buying Apple devices as last-minute gifts this holiday season, there’s an easy way to figure out if you still time to get them delivered before the big day. When ordering directly from Apple’s online store, you can quickly check if the iPhones, iPads, MacBooks, and Apple Watches you’re looking for are indeed…</p><p><a href="https://lifehacker.com/you-can-still-buy-these-apple-devices-as-holiday-gifts-1849878232">Read more...</a></p>

## These Mini Baked Potatoes Are Party Potatoes
 - [https://lifehacker.com/these-mini-baked-potatoes-are-party-potatoes-1849882015](https://lifehacker.com/these-mini-baked-potatoes-are-party-potatoes-1849882015)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Eh5FTifc--/c_fit,fl_progressive,q_80,w_636/5849abbc57847d74ef68f8eefce92bdb.jpg" /><p>Sliders, cupcakes, petite quiche, and pigs ‘n blankets have something in common: They were all mad ideas, miniaturized food favorites that quickly became the greatest party food of our time. Now the baked potato wants in on the appetizer action. Make it mini, pop it on a skewer, and you’ve got a new classic party…</p><p><a href="https://lifehacker.com/these-mini-baked-potatoes-are-party-potatoes-1849882015">Read more...</a></p>

## The Most Common Reasons Your Ice Maker Is Malfunctioning
 - [https://lifehacker.com/the-most-common-reasons-your-ice-maker-is-malfunctionin-1849881088](https://lifehacker.com/the-most-common-reasons-your-ice-maker-is-malfunctionin-1849881088)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 15:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--3dR3pj3V--/c_fit,fl_progressive,q_80,w_636/a1d123fa0b54c9590f5921db347a8866.jpg" /><p>A malfunctioning ice maker can really put a hitch in your holiday cocktail plans. Discovering the ice maker is no longer, well, making ice might make you want to call in a professional, but there are some things to check yourself for before taking that step. Here are the most common reasons your ice maker is malfunctio…</p><p><a href="https://lifehacker.com/the-most-common-reasons-your-ice-maker-is-malfunctionin-1849881088">Read more...</a></p>

## Five Small Job-Search Tasks You Can Do While Watching TV
 - [https://lifehacker.com/five-small-job-search-tasks-you-can-do-while-watching-t-1849871421](https://lifehacker.com/five-small-job-search-tasks-you-can-do-while-watching-t-1849871421)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--zCgQFwR5--/c_fit,fl_progressive,q_80,w_636/ec19cd372dbfa11af0b75f93a2148332.jpg" /><p>Whether you’re actively looking for a new gig or just exploring your options, it can be easy for a job search to eat up all your waking hours. Spending 18 hours a day thinking about finding the next step on your career path is a sure-fire way to build stress, do worse in interviews, and burn out—plus, imagine all the…</p><p><a href="https://lifehacker.com/five-small-job-search-tasks-you-can-do-while-watching-t-1849871421">Read more...</a></p>

## Scammers Are Lurking on Etsy
 - [https://lifehacker.com/scammers-are-lurking-on-etsy-1849877094](https://lifehacker.com/scammers-are-lurking-on-etsy-1849877094)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 14:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--9813jCiL--/c_fit,fl_progressive,q_80,w_636/55a60ed7ce5691d04138eb494d4b1213.jpg" /><p>You may have noticed sellers on Etsy might say something like, “buy this item on my independent website instead,” and offering a discount to buy directly from them instead of using Etsy as the intermediary. And in most cases, that’s totally fine—it’s usually better for a small business’s bottom line. But if the…</p><p><a href="https://lifehacker.com/scammers-are-lurking-on-etsy-1849877094">Read more...</a></p>

## Schedule These Maintenance Tasks to Keep Your Robot Vacuum Running
 - [https://lifehacker.com/schedule-these-maintenance-tasks-to-keep-your-robot-vac-1849880400](https://lifehacker.com/schedule-these-maintenance-tasks-to-keep-your-robot-vac-1849880400)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-12 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--1bt08ulg--/c_fit,fl_progressive,q_80,w_636/617c225d91e5cc855b43eba271d17cf0.jpg" /><p>If you’re into practical gift-giving, robot vacuums are a slam dunk. Once they’re properly set up, they can take one of the worst time-sucking chores off your to-do list for good—or at least until they break. Thankfully, robot vacuum maintenance is fairly simple. Here’s everything you need to do to keep yours from…</p><p><a href="https://lifehacker.com/schedule-these-maintenance-tasks-to-keep-your-robot-vac-1849880400">Read more...</a></p>


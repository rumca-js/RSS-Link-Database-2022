# Source:Virtual Reality Oasis, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsmk8NDVMct75j_Bfb9Ah7w, language:en-US

## Quest Pro Controllers With Quest 2 - Worth The Upgrade?
 - [https://www.youtube.com/watch?v=goJTVY6VEvM](https://www.youtube.com/watch?v=goJTVY6VEvM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsmk8NDVMct75j_Bfb9Ah7w
 - date published: 2022-12-12 18:00:14+00:00

I test out the Quest Pro controllers with the Quest 2. Since update 47 you can now pair Meta Quest Pro controllers with the Meta Quest 2 but is it worth the expensive upgrade?

Check out the Meta Quest Pro controllers here;
https://www.meta.com/gb/quest/accessories/quest-touch-pro-controllers-and-charging-dock

Check out the VR Cover controller grips here;
https://bit.ly/3okrLmq

Let me know what you think of using the Quest Pro controllers with the Quest 2 in the comments below...

Thanks for watching []-) 

VR HEADSETS:
Meta Quest Pro: https://bit.ly/3g9OyTc
Meta Quest 2: https://bit.ly/3VoOfnP
Pico 4: https://amzn.to/3EO0yEa
Valve Index: http://bit.ly/2v8hZhi

VR ACCESSORIES:
VR Cover: https://bit.ly/3okrLmq
Widmo Prescription Lenses: http://bit.ly/2W0BTGf
ProTube: http://bit.ly/2sujHb3

FOLLOW ME: 
Subscribe: http://bit.ly/2VeBqfJ
Memberships: http://bit.ly/2MVWxRl
Discord: https://discord.gg/NN9TGrv
Twitter: https://twitter.com/vr_oasis
Instagram: https://instagram.com/virtualrealityoasis
Facebook: https://facebook.com/virtualrealityoasis
Website: http://virtualrealityoasis.com/
Email: contact@virtualrealityoasis.com

#Quest2 #QuestProControllers #VR


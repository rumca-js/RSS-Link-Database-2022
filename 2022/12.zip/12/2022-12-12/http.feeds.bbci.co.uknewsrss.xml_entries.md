# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Ukraine 'keeping Russian missiles as evidence'
 - [https://www.bbc.co.uk/news/world-europe-63951794?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63951794?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 23:37:32+00:00

Prosecutors want the collection of more than 1,000 munitions to be used in any future court action.

## Buy now, pay later: Things you need to know about the loan schemes
 - [https://www.bbc.co.uk/news/business-63910427?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63910427?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 23:31:53+00:00

With Christmas fast approaching here's what you need to know before borrowing money.

## Russia's Putin scraps trademark year-end news conference
 - [https://www.bbc.co.uk/news/world-europe-63947946?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63947946?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 23:24:37+00:00

No reason is given, but there is growing unease among Russians over President Putin's invasion of Ukraine.

## Train strikes: Widespread delays expected as latest walkouts loom
 - [https://www.bbc.co.uk/news/business-63951354?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63951354?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 23:10:16+00:00

About 40,000 rail workers will start walking out on Tuesday in a row about jobs and pay.

## Nurses' strike: Union accuses minister of belligerence after talks fail
 - [https://www.bbc.co.uk/news/uk-politics-63952291?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63952291?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 22:40:18+00:00

Strikes in England, Wales and Northern Ireland are set to go ahead on Thursday after talks fail.

## Manchester United: Harry Maguire can be 'great player for us', says manager Erik ten Hag
 - [https://www.bbc.co.uk/sport/football/63948121?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63948121?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 22:33:44+00:00

Harry Maguire can be a "great player" for Manchester United if he can reproduce his England form with his club, says United manager Erik ten Hag.

## Sunderland 1-2 West Bromwich Albion: Baggies move out of drop zone
 - [https://www.bbc.co.uk/sport/football/63854969?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63854969?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 22:28:36+00:00

West Bromwich Albion produce a superb second-half comeback to beat Sunderland in the Championship.

## UK braced for more disruption from snow and ice
 - [https://www.bbc.co.uk/news/uk-63950210?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63950210?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 22:09:49+00:00

Forecasters say the freezing conditions will bring more problems for travellers on Tuesday.

## Cwmbran: Man with broken hip taken to hospital tied to plank
 - [https://www.bbc.co.uk/news/uk-wales-63948640?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-63948640?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 21:44:35+00:00

Melvyn Ryan's granddaughter, Nicole Lea, says she was told no ambulances were available.

## Lockerbie bombing suspect will not face death penalty
 - [https://www.bbc.co.uk/news/world-us-canada-63946772?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63946772?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 21:42:19+00:00

Abu Agila Masud is the first person charged on US soil in connection with the 1988 airline attack.

## World Cup 2022: ‘Emotion drives Argentina but it won’t destroy us’ - Pablo Zabaleta
 - [https://www.bbc.co.uk/sport/football/63941787?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63941787?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 21:06:58+00:00

Former Argentina defender Pablo Zabaleta says emotion is always a big part of how they play, but it feels like it is playing a bigger part than ever at this World Cup.

## US immigration: 'They'd rather die than return to Nicaragua'
 - [https://www.bbc.co.uk/news/world-us-canada-61735603?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-61735603?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 20:54:11+00:00

A record number of Nicaraguans are heading to the US as conditions worsen at home.

## Women's FA Cup: Holders Chelsea to host newly promoted Liverpool in fourth round
 - [https://www.bbc.co.uk/sport/football/63951775?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63951775?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 20:21:11+00:00

Holders Chelsea are drawn at home to newly promoted Liverpool in the fourth round of the Women's FA Cup.

## Homes for Ukraine: Sponsorship ends for thousands of Ukrainians
 - [https://www.bbc.co.uk/news/uk-63949576?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63949576?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 18:35:53+00:00

BBC analysis finds 51,000 Ukrainians have reached the end of their six-month sponsorship in the UK.

## Jersey explosion: Seven victims named by police
 - [https://www.bbc.co.uk/news/world-europe-jersey-63941232?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-jersey-63941232?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 18:31:58+00:00

Seven of the nine people missing since the explosion have been named by police.

## Unsung Hero award: Eight finalists named for honour at Sports Personality show
 - [https://www.bbc.co.uk/sport/sports-personality/63875454?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/sports-personality/63875454?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 18:30:22+00:00

Eight finalists are named for the 2022 BBC Sports Personality Unsung Hero of the Year award.

## Megan Newborough: Man who strangled girlfriend convicted of murder
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-63943464?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-63943464?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 18:12:03+00:00

Ross McCullam admitted Megan Newborough's manslaughter but had denied murder.

## World Cup 2022: England crash out but here is why fans should be excited for the future
 - [https://www.bbc.co.uk/sport/av/football/63951416?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63951416?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 17:52:16+00:00

There may be an air of disappointment after England's World Cup exit but here is why fans of the Three Lions have reason to feel optimistic.

## NFL: Brock Purdy, Dawson Knox & Terrace Marshall feature in best plays
 - [https://www.bbc.co.uk/sport/av/american-football/63945003?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/american-football/63945003?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 17:30:45+00:00

Watch as Dawson Knox of the Buffalo Bills scores an acrobatic touchdown in this week's NFL best plays.

## Strike daily: How will walkouts on Tuesday 13 December affect you?
 - [https://www.bbc.co.uk/news/uk-63942006?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63942006?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 17:24:04+00:00

Zoe Conway sets out what you should know about the rail strike and other strike action this week.

## World Cup 2022: On board a floating hotel for fans in Qatar
 - [https://www.bbc.co.uk/sport/av/football/63950918?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63950918?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 17:15:24+00:00

BBC Sport's Nesta McGregor takes a look at a cruise ship where football fans can stay for the 2022 World Cup in Qatar.

## Train strikes: RMT members reject latest Network Rail pay offer
 - [https://www.bbc.co.uk/news/business-63942172?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63942172?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 16:33:46+00:00

Walkouts will resume on Tuesday after RMT union members rejected what it called a "substandard" deal.

## Viktor Bout: Russia's released arms dealer joins ultranationalist party
 - [https://www.bbc.co.uk/news/world-europe-63947938?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63947938?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 16:33:03+00:00

Viktor Bout, known as the "merchant of death", was last week exchanged in a high-profile US prisoner swap.

## World Cup 2022: Argentina v Croatia - Lionel Messi a 'special advantage' in semi-final
 - [https://www.bbc.co.uk/sport/football/63868610?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63868610?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 16:32:22+00:00

Lionel Messi's presence will give Argentina a "special advantage" against Croatia in their World Cup semi-final, says defender Nicolas Tagliafico.

## Victor Lewis-Smith: Journalist and satirist dies aged 65
 - [https://www.bbc.co.uk/news/uk-63943475?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63943475?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 16:00:10+00:00

Mr Lewis-Smith's surreal style of comedy influenced comedians like Sacha Baron Cohen.

## World Cup 2022: Argentina v Croatia - Lionel Messi and Luka Modric battle for last final
 - [https://www.bbc.co.uk/sport/football/63934409?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63934409?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 15:59:24+00:00

Argentina's Lionel Messi and Luka Modric of Croatia have a lot in common - but only one will get a final chance to win a World Cup.

## JK Rowling funds women-only rape help centre in Edinburgh
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-63943766?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-63943766?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 15:43:46+00:00

The author says Beira's Place in Edinburgh will fill "an unmet need" from female survivors of abuse.

## Adventurer attempts Antarctic row following heart surgery
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-63944082?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-63944082?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 15:23:57+00:00

The grandson of the 14th Duke of Hamilton is planning to row 950 miles in Antarctica in a team of six.

## My Dad Wrote A Porno: Hit podcast series comes to an end
 - [https://www.bbc.co.uk/news/entertainment-arts-63945533?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63945533?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 15:22:12+00:00

The hosts of the podcast, downloaded more than 430m times, hint there's something else to come.

## Premiership Rugby to 'relaunch' for 2024-25 after demise of Wasps & Worcester
 - [https://www.bbc.co.uk/sport/rugby-union/63946473?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63946473?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 15:00:04+00:00

Premiership Rugby is to "relaunch" for the 2024-25 season, as the league looks to recover from a turbulent period.

## World Cup 2022: The moment Morocco made football history
 - [https://www.bbc.co.uk/sport/av/africa/63947272?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/africa/63947272?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 14:34:41+00:00

How Morocco fans celebrated as their national team became the first African and Arab country to reach a World Cup semi-final.

## Golden Globes 2023: Banshees of Inisherin leads nominations
 - [https://www.bbc.co.uk/news/entertainment-arts-63947647?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63947647?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 14:26:31+00:00

The dark comedy about feuding friends in 1920s Ireland leads the pack going into next year's awards.

## Lockerbie bombing suspect due to appear in US court
 - [https://www.bbc.co.uk/news/uk-scotland-63946843?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-63946843?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 14:07:21+00:00

Abi Agila Masud was allegedly a member of the Libyan intelligence services at the time of the atrocity.

## England's Rugby World Cup performance review not to be made public
 - [https://www.bbc.co.uk/sport/rugby-union/63942309?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63942309?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 13:33:35+00:00

A review into the England's performance at the recent Rugby World Cup will not be made public by the Rugby Football Union.

## Yan Bingtao: Former Masters champion suspended as part of a match-fixing investigation
 - [https://www.bbc.co.uk/sport/snooker/63945840?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/snooker/63945840?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 13:31:55+00:00

Former Masters champion Yan Bingtao is suspended from the World Snooker Tour as part of an ongoing investigation into match-fixing.

## China to de-activate national Covid tracking app
 - [https://www.bbc.co.uk/news/world-asia-china-63941512?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-63941512?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 13:30:47+00:00

It's a further sign that Beijing is moving away from its controversial zero-Covid strategy.

## Harry and Meghan on Netflix: Duke speaks of 'lies' in new trailer
 - [https://www.bbc.co.uk/news/uk-63945810?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63945810?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 13:17:12+00:00

The latest trailer for Harry and Meghan's series suggests they will reveal why they left royal duties.

## Queensland shooting: Two police officers, and member of public, killed at remote property
 - [https://www.bbc.co.uk/news/world-australia-63943292?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-63943292?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 12:26:07+00:00

The officers were responding to reports of a missing person in Wieambilla, 270km from Brisbane.

## Ukraine war: Odesa port reopens after energy network hit
 - [https://www.bbc.co.uk/news/world-europe-63943162?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63943162?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 12:16:16+00:00

The Black Sea port of Odesa has resumed operations after Russian strikes against the city on Saturday.

## World Cup 2022: Dave the cat coming home with England team
 - [https://www.bbc.co.uk/news/newsbeat-63943662?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-63943662?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 11:53:03+00:00

The Three Lions couldn't bring home the World Cup, but they won't be returning empty-handed.

## World Cup 2022: Alan Shearer says England have bright future ahead after France quarter-final defeat
 - [https://www.bbc.co.uk/sport/av/football/63945000?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63945000?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 11:44:10+00:00

BBC Sport pundit Alan Shearer says England have a bright future ahead after their 2-1 quarter-final defeat by France in the World Cup.

## David Rudisha survives plane crash in Kenya
 - [https://www.bbc.co.uk/sport/africa/63943060?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/africa/63943060?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 11:42:22+00:00

Former double Olympic 800m champion David Rudisha avoids injury after a plane he is travelling in crash-lands in Kenya.

## Pakistan v England: Ben Stokes says tourists' victory is not 'just another series win'
 - [https://www.bbc.co.uk/sport/cricket/63943613?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63943613?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 11:37:30+00:00

England captain Ben Stokes says his side know their victory in Pakistan is not "just another series win".

## Solihull: Three children die in icy lake tragedy
 - [https://www.bbc.co.uk/news/uk-england-63944005?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-63944005?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 11:26:56+00:00

Three boys aged eight, 10 and 11 have died after falling into an icy lake near Solihull on Sunday

## National Grid: Coal plants put on standby to supply electricity
 - [https://www.bbc.co.uk/news/business-63940390?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63940390?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 11:21:38+00:00

National Grid puts coal-fired units on standby and will run a test to pay people to cut peak-time use.

## In pictures: Snow blankets many parts of the UK
 - [https://www.bbc.co.uk/news/in-pictures-63942122?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-63942122?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 11:12:09+00:00

Wintry scenes from across the country as the Met Office issues warnings of ice, fog and snow.

## Will Croatia stop Messi? Sutton's World Cup semi-final predictions
 - [https://www.bbc.co.uk/sport/football/63927739?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63927739?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 11:02:08+00:00

BBC Sport's football expert Chris Sutton predicts the scores for the two World Cup semi-finals in Qatar.

## Asda home delivery driver rescues Queensferry man, 90
 - [https://www.bbc.co.uk/news/uk-wales-63942582?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-63942582?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 11:01:49+00:00

Delivery driver hears distress call and rushes to rescue man who slips and injures himself.

## EU corruption charges 'very very worrisome', says foreign policy chief
 - [https://www.bbc.co.uk/news/world-europe-63941509?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63941509?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 10:45:44+00:00

Watchdogs say it could be one of the biggest corruption scandals in European Parliament history.

## Pakistan v England: Tourists win thriller in Multan to seal series
 - [https://www.bbc.co.uk/sport/cricket/63936216?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63936216?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 09:21:59+00:00

England pull off another sensational victory in Pakistan, winning the second Test by 26 runs to seal a historic series triumph.

## Dozens spend night in pub amid heavy snowfall
 - [https://www.bbc.co.uk/news/uk-england-63941122?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-63941122?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 09:11:27+00:00

The Bear Inn near Burwash threw open its doors to those stranded and needing shelter for the night.

## Jersey explosion: Search enters third day after flats blast
 - [https://www.bbc.co.uk/news/world-europe-jersey-63940492?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-jersey-63940492?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 08:17:29+00:00

A search and recovery operation enters its third day after a huge explosion in Jersey.

## Children who fell into icy lake near Birmingham remain critical
 - [https://www.bbc.co.uk/news/uk-england-birmingham-63941050?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-63941050?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 08:08:12+00:00

Police have not confirmed if anyone else is missing, after initial reports six people were seen.

## UK economy shrinks between August and October
 - [https://www.bbc.co.uk/news/business-63891327?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63891327?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 07:19:32+00:00

The economy contracted by 0.3% over the three month period despite a rebound in October.

## Quiz: Can you name every World Cup semi-final scorer this century?
 - [https://www.bbc.co.uk/sport/football/63903288?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63903288?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 07:05:35+00:00

Can you name the 21 players to score in World Cup semi-finals since 2002?

## NFL week 14: Eagles make the play-offs as rookie San Francisco 49ers QB beats Tom Brady
 - [https://www.bbc.co.uk/sport/american-football/63939620?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/american-football/63939620?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 06:57:52+00:00

The Philadelphia Eagles become the first team to make this season's NFL play-offs as Tom Brady suffers a horror homecoming at San Francisco.

## Families welcome Lockerbie bomb suspect's detention
 - [https://www.bbc.co.uk/news/uk-scotland-63937640?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-63937640?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 06:38:28+00:00

Abu Agila Masud is in US custody and faces charges alleging he played a key role in the 1988 bombing.

## Iran protests: Second execution carried out
 - [https://www.bbc.co.uk/news/world-middle-east-63939428?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63939428?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 06:36:14+00:00

It comes days after Iran hanged the first person over the protests, drawing widespread condemnation.

## 'You shouldn't be scared to breathe in the air'
 - [https://www.bbc.co.uk/news/uk-england-london-63886446?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-63886446?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 06:16:46+00:00

Three people who live in a damp-ridden tower block have spoken of their health concerns about mould.

## Heineken Champions Cup: Five things we learned from opening weekend
 - [https://www.bbc.co.uk/sport/rugby-union/63938350?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63938350?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 06:07:26+00:00

BBC Sport takes a look at five things we have learned after a thrilling opening weekend of Champions Cup action.

## Ukraine war: The Russians locked up for refusing to fight
 - [https://www.bbc.co.uk/news/world-europe-63916810?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63916810?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 06:00:38+00:00

Russian troops have reportedly been locked up for refusing to fight in the invasion of Ukraine.

## UK weather: Warning of ice danger as cold spell continues
 - [https://www.bbc.co.uk/news/uk-63939132?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63939132?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 05:32:04+00:00

People are warned to stay away from open water as ice, snow and freezing fog causes disruption.

## West Indies v England: Danni Wyatt leads tourists to comfortable eight-wicket win in first T20
 - [https://www.bbc.co.uk/sport/cricket/63938061?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63938061?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 04:58:24+00:00

Danni Wyatt's unbeaten 59 leads England to a comfortable eight-wicket win in the first T20 in Antigua.

## Italy shooting: Three women shot dead in Rome cafe
 - [https://www.bbc.co.uk/news/world-europe-63939426?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63939426?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 03:22:42+00:00

A friend of Italian Prime Minister Giorgia Meloni is among three women killed in Sunday's attack.

## Twitter's paid blue tick re-launches after pause
 - [https://www.bbc.co.uk/news/technology-63938566?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63938566?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 03:21:29+00:00

Twitter will once again offer a blue tick badge and additional features for a monthly fee.

## One of Central America's most active volcanoes erupts again
 - [https://www.bbc.co.uk/news/world-latin-america-63939229?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-63939229?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 03:05:20+00:00

Guatemala's Fuego forces authorities to close the country's largest airport and a major highway.

## Ministers to hold emergency Cobra meeting amid wave of strikes
 - [https://www.bbc.co.uk/news/uk-63939396?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63939396?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 02:11:22+00:00

The government will discuss contingency plans, including using the military to cover border staff.

## Zimbabwe power outages hit businesses and families
 - [https://www.bbc.co.uk/news/world-africa-63934919?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-63934919?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 00:42:35+00:00

Zimbabwe is only generating one third of its energy needs, hitting businesses and families hard.

## Would you switch your dog to eating lab-grown meat?
 - [https://www.bbc.co.uk/news/business-63565576?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63565576?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 00:27:53+00:00

As environmental and ethical concerns grow over pet food, some say cultivated meat is the solution.

## The secret diaries of women protesting in Iran
 - [https://www.bbc.co.uk/news/world-middle-east-63920617?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63920617?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 00:09:04+00:00

Hidden diaries sent to the BBC show the everyday risks and dangers that women face, as they continue to protest in Iran.

## K-pop: The rise of the virtual girl bands
 - [https://www.bbc.co.uk/news/world-asia-63827838?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63827838?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 00:02:47+00:00

They may sing and dance like other musicians but they are made with artificial intelligence.

## Newspaper headlines: 'Lake horror' and troops to act as 'strike breakers'
 - [https://www.bbc.co.uk/news/blogs-the-papers-63939008?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-63939008?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-12 00:02:32+00:00

Children hospitalised after falling in a lake and troops to be used in strikes feature on front pages.


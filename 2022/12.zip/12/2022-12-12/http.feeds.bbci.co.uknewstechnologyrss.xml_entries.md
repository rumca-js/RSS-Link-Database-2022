# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## December 2024 set as date for universal phone charger in EU
 - [https://www.bbc.co.uk/news/technology-63907702?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63907702?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-12-12 13:13:45+00:00

New portable electronic devices sold in the EU will have to use a USB Type-C charger by autumn 2024.

## S Korea says crypto-fugitive Do Kwon is in Serbia
 - [https://www.bbc.co.uk/news/business-63940181?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63940181?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-12-12 07:47:34+00:00

Mr Kwon was charged with fraud and breaches of capital markets law after the implosion of the token.


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## YOU WERE RIGHT | Matt Taibbi Reveals SHOCKING Twitter Files
 - [https://www.youtube.com/watch?v=SkGiNYIUHao](https://www.youtube.com/watch?v=SkGiNYIUHao)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-12-13 00:00:00+00:00

Yesterday I had the pleasure to speak with Matt Taibbi, who has been at the forefront of releasing The Twitter Files. He breaks down exactly what was happening within Twitter before Elon Musk purchased it on October 27, 2022. #twitter #elonmusk #twitterfiles 

Watch Full Interview Here: https://bit.ly/sfwrb-44-twitter-matt-taibbi
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/

## WE KNEW IT
 - [https://www.youtube.com/watch?v=V7VZGTWkUaA](https://www.youtube.com/watch?v=V7VZGTWkUaA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-12-12 00:00:00+00:00

The Twitter Files – the unprecedented revelations of an enemy of the State, or the orchestrated distractions of a billionaire with extensive ties to government? Or worse still, the new Klaus Schwab? …I don’t like to pry.  
#twitter #elonmusk #klausschwab #worldeconomicforum 

References
https://finance.yahoo.com/news/latest-twitter-files-allege-blacklisting-032210220.html
https://reclaimthenet.org/vijaya-gadde-hunter-biden/
https://www.grid.news/story/technology/2022/04/30/elon-musk-hates-the-government-his-companies-love-it/
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/


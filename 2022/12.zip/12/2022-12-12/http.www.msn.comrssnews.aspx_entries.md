# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Trump’s Special Master Suit Is Dead—Now the Real Case Begins
 - [http://www.msn.com/en-us/news/us/trump-s-special-master-suit-is-dead-now-the-real-case-begins/ar-AA15cuW5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/trump-s-special-master-suit-is-dead-now-the-real-case-begins/ar-AA15cuW5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 23:45:37.784780+00:00



## Leaked documents indicate over 300 members of far-right paramilitary Oath Keepers may be current or former DHS employees, Project on Government Oversight reports
 - [http://www.msn.com/en-us/news/us/leaked-documents-indicate-over-300-members-of-far-right-paramilitary-oath-keepers-may-be-current-or-former-dhs-employees-project-on-government-oversight-reports/ar-AA15co6u?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/leaked-documents-indicate-over-300-members-of-far-right-paramilitary-oath-keepers-may-be-current-or-former-dhs-employees-project-on-government-oversight-reports/ar-AA15co6u?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 23:45:37.777557+00:00



## GOP plots swing state shake-up to prevent 2024 defeats
 - [http://www.msn.com/en-us/news/politics/gop-plots-swing-state-shake-up-to-prevent-2024-defeats/ar-AA15cjm1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-plots-swing-state-shake-up-to-prevent-2024-defeats/ar-AA15cjm1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 23:45:37.770401+00:00



## ChatGPT Is a Stunning AI, but Human Jobs Are Safe (for Now)
 - [http://www.msn.com/en-us/news/technology/chatgpt-is-a-stunning-ai-but-human-jobs-are-safe-for-now/ar-AA151Jtr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/chatgpt-is-a-stunning-ai-but-human-jobs-are-safe-for-now/ar-AA151Jtr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 23:45:37.763159+00:00



## Ukraine Latest: Zelenskiy Says Lull In Attacks Will Be Fleeting
 - [http://www.msn.com/en-us/news/world/ukraine-latest-zelenskiy-says-lull-in-attacks-will-be-fleeting/ar-AA15aDqZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-latest-zelenskiy-says-lull-in-attacks-will-be-fleeting/ar-AA15aDqZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 23:45:37.755009+00:00



## 'GMA 3' co-anchors to remain off-air amid reports of romantic relationship
 - [http://www.msn.com/en-us/news/us/gma-3-co-anchors-to-remain-off-air-amid-reports-of-romantic-relationship/ar-AA15bWbN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/gma-3-co-anchors-to-remain-off-air-amid-reports-of-romantic-relationship/ar-AA15bWbN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 23:45:37.747805+00:00



## US catching up to China and Russia with latest hypersonic missile test
 - [http://www.msn.com/en-us/news/world/us-catching-up-to-china-and-russia-with-latest-hypersonic-missile-test/ar-AA15bVVp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-catching-up-to-china-and-russia-with-latest-hypersonic-missile-test/ar-AA15bVVp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 23:45:37.739191+00:00



## Biden establishes government task force to combat antisemitism
 - [http://www.msn.com/en-us/news/politics/biden-establishes-government-task-force-to-combat-antisemitism/ar-AA15cqZN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-establishes-government-task-force-to-combat-antisemitism/ar-AA15cqZN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 23:45:37.729861+00:00



## Police release details of Meath murder victim
 - [http://www.msn.com/en-us/news/world/police-release-details-of-meath-murder-victim/ar-AA15csj0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/police-release-details-of-meath-murder-victim/ar-AA15csj0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 22:45:36.946037+00:00



## White House says high-level talks on Paul Whelan to take place this week
 - [http://www.msn.com/en-us/news/politics/white-house-says-high-level-talks-on-paul-whelan-to-take-place-this-week/ar-AA15clDj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/white-house-says-high-level-talks-on-paul-whelan-to-take-place-this-week/ar-AA15clDj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 22:45:36.938874+00:00



## Comedian Mark Curry accuses Colorado hotel staffer of racially profiling him
 - [http://www.msn.com/en-us/news/us/comedian-mark-curry-accuses-colorado-hotel-staffer-of-racially-profiling-him/ar-AA15cnCr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/comedian-mark-curry-accuses-colorado-hotel-staffer-of-racially-profiling-him/ar-AA15cnCr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 22:45:36.931666+00:00



## NASA Reveals Secret Messages Hidden Inside Orion Spacecraft
 - [http://www.msn.com/en-us/news/technology/nasa-reveals-secret-messages-hidden-inside-orion-spacecraft/ar-AA154nZQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/nasa-reveals-secret-messages-hidden-inside-orion-spacecraft/ar-AA154nZQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 22:45:36.923673+00:00



## GOP signals investigations, possible subpoenas on COVID origin, domestic extremism monitoring: Rep. Turner
 - [http://www.msn.com/en-us/news/politics/gop-signals-investigations-possible-subpoenas-on-covid-origin-domestic-extremism-monitoring-rep-turner/ar-AA15ciSY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-signals-investigations-possible-subpoenas-on-covid-origin-domestic-extremism-monitoring-rep-turner/ar-AA15ciSY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 22:45:36.916430+00:00



## Diplomat who brought Griner home tells Paul Whelan: 'We haven't forgotten you'
 - [http://www.msn.com/en-us/news/politics/diplomat-who-brought-griner-home-tells-paul-whelan-we-haven-t-forgotten-you/ar-AA15bxtZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/diplomat-who-brought-griner-home-tells-paul-whelan-we-haven-t-forgotten-you/ar-AA15bxtZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 22:45:36.908809+00:00



## Senators say Bankman-Fried is refusing subpoena to testify about FTX collapse
 - [http://www.msn.com/en-us/news/politics/senators-say-bankman-fried-is-refusing-subpoena-to-testify-about-ftx-collapse/ar-AA15cuFU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senators-say-bankman-fried-is-refusing-subpoena-to-testify-about-ftx-collapse/ar-AA15cuFU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 22:45:36.900812+00:00



## Congress eyes one week of funding to avoid gov't shutdown
 - [http://www.msn.com/en-us/news/politics/congress-eyes-one-week-of-funding-to-avoid-gov-t-shutdown/ar-AA15ciZ8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/congress-eyes-one-week-of-funding-to-avoid-gov-t-shutdown/ar-AA15ciZ8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 22:45:36.893000+00:00



## Kushner's Financial Link to Qatar Is a 'Ticking Time Bomb': Biographer
 - [http://www.msn.com/en-us/news/world/kushner-s-financial-link-to-qatar-is-a-ticking-time-bomb-biographer/ar-AA15cu5T?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/kushner-s-financial-link-to-qatar-is-a-ticking-time-bomb-biographer/ar-AA15cu5T?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 21:45:39.785274+00:00



## Keystone Pipeline oil spill investigators search for cause of rupture
 - [http://www.msn.com/en-us/news/us/keystone-pipeline-oil-spill-investigators-search-for-cause-of-rupture/ar-AA15aA4p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/keystone-pipeline-oil-spill-investigators-search-for-cause-of-rupture/ar-AA15aA4p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 21:45:39.778004+00:00



## DOJ special counsel probing Trump subpoenas Georgia secretary of state
 - [http://www.msn.com/en-us/news/politics/doj-special-counsel-probing-trump-subpoenas-georgia-secretary-of-state/ar-AA15cg94?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/doj-special-counsel-probing-trump-subpoenas-georgia-secretary-of-state/ar-AA15cg94?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 21:45:39.770795+00:00



## A US Air Force bomber successfully launched a fully-operational hypersonic missile in a milestone weapon test
 - [http://www.msn.com/en-us/news/world/a-us-air-force-bomber-successfully-launched-a-fully-operational-hypersonic-missile-in-a-milestone-weapon-test/ar-AA15cg9c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-us-air-force-bomber-successfully-launched-a-fully-operational-hypersonic-missile-in-a-milestone-weapon-test/ar-AA15cg9c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 21:45:39.763554+00:00



## Biden officials meet with Paul Whelan's family to discuss efforts on securing his release from Russia
 - [http://www.msn.com/en-us/news/world/biden-officials-meet-with-paul-whelan-s-family-to-discuss-efforts-on-securing-his-release-from-russia/ar-AA15cues?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/biden-officials-meet-with-paul-whelan-s-family-to-discuss-efforts-on-securing-his-release-from-russia/ar-AA15cues?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 21:45:39.756331+00:00



## Giuliani avoids jail in dispute over payments to ex-wife
 - [http://www.msn.com/en-us/news/politics/giuliani-avoids-jail-in-dispute-over-payments-to-ex-wife/ar-AA15c8uC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/giuliani-avoids-jail-in-dispute-over-payments-to-ex-wife/ar-AA15c8uC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 21:45:39.749244+00:00



## El Paso official says illegal border crossing numbers 'are unsustainable’ days before Title 42 expires
 - [http://www.msn.com/en-us/news/us/el-paso-official-says-illegal-border-crossing-numbers-are-unsustainable-days-before-title-42-expires/ar-AA15cl2c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/el-paso-official-says-illegal-border-crossing-numbers-are-unsustainable-days-before-title-42-expires/ar-AA15cl2c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 21:45:39.741977+00:00



## Schumer says Senate likely headed for short-term funding bill to stave off shutdown
 - [http://www.msn.com/en-us/news/politics/schumer-says-senate-likely-headed-for-short-term-funding-bill-to-stave-off-shutdown/ar-AA15crYl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/schumer-says-senate-likely-headed-for-short-term-funding-bill-to-stave-off-shutdown/ar-AA15crYl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 21:45:39.734530+00:00



## Cop Who Killed Atatiana Jefferson Recounts Moment He Pulled the Trigger
 - [http://www.msn.com/en-us/news/us/cop-who-killed-atatiana-jefferson-recounts-moment-he-pulled-the-trigger/ar-AA15chGS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/cop-who-killed-atatiana-jefferson-recounts-moment-he-pulled-the-trigger/ar-AA15chGS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 20:45:33.153510+00:00



## A sign of moderates running scared: What everyone is getting wrong about Sinema’s party switch
 - [http://www.msn.com/en-us/news/politics/a-sign-of-moderates-running-scared-what-everyone-is-getting-wrong-about-sinema-s-party-switch/ar-AA15chHc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/a-sign-of-moderates-running-scared-what-everyone-is-getting-wrong-about-sinema-s-party-switch/ar-AA15chHc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 20:45:33.144862+00:00



## Twitter users push to boycott Tesla after Elon Musk tweets his pronouns are ‘Prosecute/Fauci’
 - [http://www.msn.com/en-us/news/technology/twitter-users-push-to-boycott-tesla-after-elon-musk-tweets-his-pronouns-are-prosecute-fauci/ar-AA15c80e?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/twitter-users-push-to-boycott-tesla-after-elon-musk-tweets-his-pronouns-are-prosecute-fauci/ar-AA15c80e?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 20:45:33.137632+00:00



## Kevin McCarthy's oversight agenda will be 'a recurring skit on SNL' if he makes MAGA cheerleaders Marjorie Taylor Greene and Lauren Boebert investigators: GOP strategists
 - [http://www.msn.com/en-us/news/politics/kevin-mccarthy-s-oversight-agenda-will-be-a-recurring-skit-on-snl-if-he-makes-maga-cheerleaders-marjorie-taylor-greene-and-lauren-boebert-investigators-gop-strategists/ar-AA15chLz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kevin-mccarthy-s-oversight-agenda-will-be-a-recurring-skit-on-snl-if-he-makes-maga-cheerleaders-marjorie-taylor-greene-and-lauren-boebert-investigators-gop-strategists/ar-AA15chLz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 20:45:33.129998+00:00



## Richmond's last Confederate statue removed; dispute over relocation continues
 - [http://www.msn.com/en-us/news/us/richmond-s-last-confederate-statue-removed-dispute-over-relocation-continues/ar-AA15c6hy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/richmond-s-last-confederate-statue-removed-dispute-over-relocation-continues/ar-AA15c6hy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 20:45:33.121345+00:00



## Judge denies Pablo Lyle new trial in Miami road rage death
 - [http://www.msn.com/en-us/news/crime/judge-denies-pablo-lyle-new-trial-in-miami-road-rage-death/ar-AA15c6ky?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/judge-denies-pablo-lyle-new-trial-in-miami-road-rage-death/ar-AA15c6ky?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 20:45:33.114165+00:00



## One (Tiny) Step Closer to Fusion Energy
 - [http://www.msn.com/en-us/news/technology/one-tiny-step-closer-to-fusion-energy/ar-AA15c6nd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/one-tiny-step-closer-to-fusion-energy/ar-AA15c6nd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 20:45:33.105867+00:00



## Oklahoma takes 'momentous' step to allow taxpayer-funded religious schools
 - [http://www.msn.com/en-us/news/politics/oklahoma-takes-momentous-step-to-allow-taxpayer-funded-religious-schools/ar-AA15chWK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/oklahoma-takes-momentous-step-to-allow-taxpayer-funded-religious-schools/ar-AA15chWK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 20:45:33.098116+00:00



## Kyrsten Sinema is no conservative hero
 - [http://www.msn.com/en-us/news/politics/kyrsten-sinema-is-no-conservative-hero/ar-AA15bY4h?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kyrsten-sinema-is-no-conservative-hero/ar-AA15bY4h?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 19:45:27.112170+00:00



## US hits Zimbabwe president's son with sanctions
 - [http://www.msn.com/en-us/news/world/us-hits-zimbabwe-president-s-son-with-sanctions/ar-AA15bY3x?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-hits-zimbabwe-president-s-son-with-sanctions/ar-AA15bY3x?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 19:45:27.104133+00:00



## Tensions at Salesforce Rose Ahead of Co-CEO’s Departure
 - [http://www.msn.com/en-us/news/technology/tensions-at-salesforce-rose-ahead-of-co-ceo-s-departure/vi-AA15ceVI?srcref=rss](http://www.msn.com/en-us/news/technology/tensions-at-salesforce-rose-ahead-of-co-ceo-s-departure/vi-AA15ceVI?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 19:45:27.097028+00:00



## Attorneys for Colorado Black man beaten by police demand investigation
 - [http://www.msn.com/en-us/news/politics/attorneys-for-colorado-black-man-beaten-by-police-demand-investigation/ar-AA15c7Ih?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/attorneys-for-colorado-black-man-beaten-by-police-demand-investigation/ar-AA15c7Ih?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 19:45:27.088988+00:00



## NASA Completes Historic Trip Around the Moon: What's Next for Artemis?
 - [http://www.msn.com/en-us/news/technology/nasa-completes-historic-trip-around-the-moon-what-s-next-for-artemis/ar-AA11bzN0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/nasa-completes-historic-trip-around-the-moon-what-s-next-for-artemis/ar-AA11bzN0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 19:45:27.081746+00:00



## Md. Authorities Discover Decomposing Body of Pregnant Woman While Arresting Man Accused of Separate Murder
 - [http://www.msn.com/en-us/news/crime/md-authorities-discover-decomposing-body-of-pregnant-woman-while-arresting-man-accused-of-separate-murder/ar-AA15bY96?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/md-authorities-discover-decomposing-body-of-pregnant-woman-while-arresting-man-accused-of-separate-murder/ar-AA15bY96?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 19:45:27.074426+00:00



## Zelenskyy poked fun at Putin's preposterously long table during an interview with David Letterman
 - [http://www.msn.com/en-us/news/world/zelenskyy-poked-fun-at-putin-s-preposterously-long-table-during-an-interview-with-david-letterman/ar-AA15cf5e?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/zelenskyy-poked-fun-at-putin-s-preposterously-long-table-during-an-interview-with-david-letterman/ar-AA15cf5e?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 19:45:27.066576+00:00



## Elon Musk draws backlash, applause for tweet calling for Fauci to be prosecuted
 - [http://www.msn.com/en-us/news/politics/elon-musk-draws-backlash-applause-for-tweet-calling-for-fauci-to-be-prosecuted/ar-AA15c4Tl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/elon-musk-draws-backlash-applause-for-tweet-calling-for-fauci-to-be-prosecuted/ar-AA15c4Tl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 19:45:27.057854+00:00



## Brace for All-Out Attacks on Russian Soil, Kremlin Official Warns
 - [http://www.msn.com/en-us/news/world/brace-for-all-out-attacks-on-russian-soil-kremlin-official-warns/ar-AA15c0gL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/brace-for-all-out-attacks-on-russian-soil-kremlin-official-warns/ar-AA15c0gL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 18:45:24.939394+00:00



## Ga. Grandmother, 77, Is Stabbed to Death While Confronting Man Trying to Steal Her Car: Police
 - [http://www.msn.com/en-us/news/crime/ga-grandmother-77-is-stabbed-to-death-while-confronting-man-trying-to-steal-her-car-police/ar-AA15bXsY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/ga-grandmother-77-is-stabbed-to-death-while-confronting-man-trying-to-steal-her-car-police/ar-AA15bXsY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 18:45:24.932156+00:00



## 'Slap in the face': White House condemns Rep. Marjorie Taylor Greene's Jan. 6 comments
 - [http://www.msn.com/en-us/news/politics/slap-in-the-face-white-house-condemns-rep-marjorie-taylor-greene-s-jan-6-comments/ar-AA15c7b0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/slap-in-the-face-white-house-condemns-rep-marjorie-taylor-greene-s-jan-6-comments/ar-AA15c7b0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 18:45:24.925032+00:00



## Yoel Roth's ‘Gay Data’ dissertation ‘mistakenly’ blocked from UPenn website after Elon Musk’s tweet
 - [http://www.msn.com/en-us/news/technology/yoel-roth-s-gay-data-dissertation-mistakenly-blocked-from-upenn-website-after-elon-musk-s-tweet/ar-AA15bNTq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/yoel-roth-s-gay-data-dissertation-mistakenly-blocked-from-upenn-website-after-elon-musk-s-tweet/ar-AA15bNTq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 18:45:24.917753+00:00



## New 'Harry & Meghan' Trailer Claims People Were 'Happy to Lie' for William
 - [http://www.msn.com/en-us/news/technology/new-harry-meghan-trailer-claims-people-were-happy-to-lie-for-william/ar-AA15c9wZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/new-harry-meghan-trailer-claims-people-were-happy-to-lie-for-william/ar-AA15c9wZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 18:45:24.910522+00:00



## Bidens spread holiday cheer at Toys for Tots event
 - [http://www.msn.com/en-us/news/politics/bidens-spread-holiday-cheer-at-toys-for-tots-event/ar-AA15c4WB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/bidens-spread-holiday-cheer-at-toys-for-tots-event/ar-AA15c4WB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 18:45:24.903130+00:00



## Lula’s Win Certified by Court, Ending Challenges to Vote
 - [http://www.msn.com/en-us/news/world/lula-s-win-certified-by-court-ending-challenges-to-vote/ar-AA15c4WL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/lula-s-win-certified-by-court-ending-challenges-to-vote/ar-AA15c4WL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 18:45:24.894505+00:00



## Marjorie Taylor Greene says if she ran Jan. 6 Capitol attack, 'We would have won'
 - [http://www.msn.com/en-us/news/politics/marjorie-taylor-greene-says-if-she-ran-jan-6-capitol-attack-we-would-have-won/ar-AA15bOLA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/marjorie-taylor-greene-says-if-she-ran-jan-6-capitol-attack-we-would-have-won/ar-AA15bOLA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 18:45:24.887102+00:00



## B-21 Raider shock effect: New US bomber arrives at just the right time
 - [http://www.msn.com/en-us/news/world/b-21-raider-shock-effect-new-us-bomber-arrives-at-just-the-right-time/ar-AA15bYUX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/b-21-raider-shock-effect-new-us-bomber-arrives-at-just-the-right-time/ar-AA15bYUX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 17:45:22.868335+00:00



## The best animal stories of 2022
 - [http://www.msn.com/en-us/news/us/the-best-animal-stories-of-2022/ar-AA15bGf4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-best-animal-stories-of-2022/ar-AA15bGf4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 17:45:22.861048+00:00



## Last publicly owned Confederate memorial in Richmond comes down
 - [http://www.msn.com/en-us/news/us/last-publicly-owned-confederate-memorial-in-richmond-comes-down/ar-AA15bKMA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/last-publicly-owned-confederate-memorial-in-richmond-comes-down/ar-AA15bKMA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 17:45:22.853225+00:00



## A 15-Year-Old Missouri Girl Is Missing, and Her Family Thinks She's Being Held Against Her Will
 - [http://www.msn.com/en-us/news/crime/a-15-year-old-missouri-girl-is-missing-and-her-family-thinks-she-s-being-held-against-her-will/ar-AA15bGlg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/a-15-year-old-missouri-girl-is-missing-and-her-family-thinks-she-s-being-held-against-her-will/ar-AA15bGlg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 17:45:22.846031+00:00



## American college student reported missing while studying abroad in France
 - [http://www.msn.com/en-us/news/world/american-college-student-reported-missing-while-studying-abroad-in-france/ar-AA15bbYI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/american-college-student-reported-missing-while-studying-abroad-in-france/ar-AA15bbYI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 17:45:22.838630+00:00



## Soccer journalist Grant Wahl's body returned to US
 - [http://www.msn.com/en-us/news/us/soccer-journalist-grant-wahl-s-body-returned-to-us/ar-AA15bUe3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/soccer-journalist-grant-wahl-s-body-returned-to-us/ar-AA15bUe3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 17:45:22.831343+00:00



## How My Family and Others Struggle Financially to Care for Aging Relatives
 - [http://www.msn.com/en-us/news/technology/how-my-family-and-others-struggle-financially-to-care-for-aging-relatives/ar-AA15bs8G?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-my-family-and-others-struggle-financially-to-care-for-aging-relatives/ar-AA15bs8G?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 17:45:22.824004+00:00



## Ex-cop takes the stand in murder trial of Black woman
 - [http://www.msn.com/en-us/news/crime/ex-cop-takes-the-stand-in-murder-trial-of-black-woman/ar-AA15bG7h?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/ex-cop-takes-the-stand-in-murder-trial-of-black-woman/ar-AA15bG7h?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 17:45:22.816738+00:00



## RMT members reject latest Network Rail pay offer
 - [http://www.msn.com/en-us/news/world/rmt-members-reject-latest-network-rail-pay-offer/ar-AA15bRhz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/rmt-members-reject-latest-network-rail-pay-offer/ar-AA15bRhz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 16:45:24.676208+00:00



## Marjorie Taylor Greene says Jan. 6 Capitol attack 'would've been armed' if she ran it
 - [http://www.msn.com/en-us/news/politics/marjorie-taylor-greene-says-jan-6-capitol-attack-would-ve-been-armed-if-she-ran-it/ar-AA15bOLA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/marjorie-taylor-greene-says-jan-6-capitol-attack-would-ve-been-armed-if-she-ran-it/ar-AA15bOLA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 16:45:24.668996+00:00



## Retired Lt. General Predicts When Russia Will Lose Crimea
 - [http://www.msn.com/en-us/news/world/retired-lt-general-predicts-when-russia-will-lose-crimea/ar-AA15bOXw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/retired-lt-general-predicts-when-russia-will-lose-crimea/ar-AA15bOXw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 16:45:24.661800+00:00



## Richmond, former capital of the Confederacy, removes its last public Confederate monument
 - [http://www.msn.com/en-us/news/us/richmond-former-capital-of-the-confederacy-removes-its-last-public-confederate-monument/ar-AA15bMu3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/richmond-former-capital-of-the-confederacy-removes-its-last-public-confederate-monument/ar-AA15bMu3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 16:45:24.654480+00:00



## Is Amazon the Cheapest Place to Buy Household Products? We Do the Math
 - [http://www.msn.com/en-us/news/technology/is-amazon-the-cheapest-place-to-buy-household-products-we-do-the-math/ar-AA14DM96?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/is-amazon-the-cheapest-place-to-buy-household-products-we-do-the-math/ar-AA14DM96?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 16:45:24.647236+00:00



## College Student Goes Missing While Studying Abroad in France, Family Says They 'Fear the Worst'
 - [http://www.msn.com/en-us/news/crime/college-student-goes-missing-while-studying-abroad-in-france-family-says-they-fear-the-worst/ar-AA15bTGN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/college-student-goes-missing-while-studying-abroad-in-france-family-says-they-fear-the-worst/ar-AA15bTGN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 16:45:24.639933+00:00



## Libyan accused in Lockerbie bombing to appear in US court
 - [http://www.msn.com/en-us/news/world/libyan-accused-in-lockerbie-bombing-to-appear-in-us-court/ar-AA15bAD7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/libyan-accused-in-lockerbie-bombing-to-appear-in-us-court/ar-AA15bAD7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 16:45:24.632169+00:00



## Putin canceled his annual press conference, ducking a likely barrage of questions about failures in Ukraine
 - [http://www.msn.com/en-us/news/world/putin-canceled-his-annual-press-conference-ducking-a-likely-barrage-of-questions-about-failures-in-ukraine/ar-AA15bKei?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-canceled-his-annual-press-conference-ducking-a-likely-barrage-of-questions-about-failures-in-ukraine/ar-AA15bKei?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 16:45:24.623965+00:00



## Man Suspected of Murdering Migos Rapper Takeoff Granted Money From Judge [UPDATED]
 - [http://www.msn.com/en-us/news/crime/man-suspected-of-murdering-migos-rapper-takeoff-granted-money-from-judge-updated/ar-AA153ntr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/man-suspected-of-murdering-migos-rapper-takeoff-granted-money-from-judge-updated/ar-AA153ntr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 15:45:15.088987+00:00



## Recall the progressive prosecutor movement?
 - [http://www.msn.com/en-us/news/politics/recall-the-progressive-prosecutor-movement/ar-AA15baDI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/recall-the-progressive-prosecutor-movement/ar-AA15baDI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 15:45:15.081817+00:00



## Zoom Games: How to Play Poker, Trivia and More During Your Next Meeting
 - [http://www.msn.com/en-us/news/technology/zoom-games-how-to-play-poker-trivia-and-more-during-your-next-meeting/ar-AA15btcH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/zoom-games-how-to-play-poker-trivia-and-more-during-your-next-meeting/ar-AA15btcH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 15:45:15.074596+00:00



## 5 comics who were arrested onstage
 - [http://www.msn.com/en-us/news/crime/5-comics-who-were-arrested-onstage/ar-AA15bzV2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/5-comics-who-were-arrested-onstage/ar-AA15bzV2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 15:45:15.067342+00:00



## High court won't hear Title IX case involving Michigan State
 - [http://www.msn.com/en-us/news/politics/high-court-won-t-hear-title-ix-case-involving-michigan-state/ar-AA15bt6Z?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/high-court-won-t-hear-title-ix-case-involving-michigan-state/ar-AA15bt6Z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 15:45:15.059419+00:00



## Judge Tosses Trump’s Battle Against Mar-a-Lago Raid
 - [http://www.msn.com/en-us/news/politics/judge-tosses-trump-s-battle-against-mar-a-lago-raid/ar-AA15bg3i?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/judge-tosses-trump-s-battle-against-mar-a-lago-raid/ar-AA15bg3i?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 15:45:15.052217+00:00



## A Lockerbie bombing suspect is in U.S. custody. Here's what to know.
 - [http://www.msn.com/en-us/news/world/a-lockerbie-bombing-suspect-is-in-u-s-custody-here-s-what-to-know/ar-AA15bD7u?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-lockerbie-bombing-suspect-is-in-u-s-custody-here-s-what-to-know/ar-AA15bD7u?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 15:45:15.043547+00:00



## Russia Loses 24 Tanks in a Day As 100,000 Death Toll Nears: Ukraine
 - [http://www.msn.com/en-us/news/world/russia-loses-24-tanks-in-a-day-as-100-000-death-toll-nears-ukraine/ar-AA15bJna?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-loses-24-tanks-in-a-day-as-100-000-death-toll-nears-ukraine/ar-AA15bJna?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 15:45:15.035952+00:00



## Five things Democrats are racing to complete before they lose power in January
 - [http://www.msn.com/en-us/news/politics/five-things-democrats-are-racing-to-complete-before-they-lose-power-in-january/ar-AA15bsxn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/five-things-democrats-are-racing-to-complete-before-they-lose-power-in-january/ar-AA15bsxn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 14:45:14.304094+00:00



## Trump says he 'turned down a deal' with Russia to exchange Viktor Bout for Paul Whelan
 - [http://www.msn.com/en-us/news/politics/trump-says-he-turned-down-a-deal-with-russia-to-exchange-viktor-bout-for-paul-whelan/ar-AA15bnml?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-says-he-turned-down-a-deal-with-russia-to-exchange-viktor-bout-for-paul-whelan/ar-AA15bnml?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 14:45:14.295825+00:00



## Ukraine’s ‘Dunkirk’ moment: Small NGOs need help to avert a humanitarian disaster
 - [http://www.msn.com/en-us/news/world/ukraine-s-dunkirk-moment-small-ngos-need-help-to-avert-a-humanitarian-disaster/ar-AA15bwDh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-s-dunkirk-moment-small-ngos-need-help-to-avert-a-humanitarian-disaster/ar-AA15bwDh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 14:45:14.287835+00:00



## AMD Radeon RX 7900 XT and 7900 XTX Review: Faster, but Is It Enough?
 - [http://www.msn.com/en-us/news/technology/amd-radeon-rx-7900-xt-and-7900-xtx-review-faster-but-is-it-enough/ar-AA15bnoq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/amd-radeon-rx-7900-xt-and-7900-xtx-review-faster-but-is-it-enough/ar-AA15bnoq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 14:45:14.280644+00:00



## Elon Musk booed during surprise appearance at Dave Chappelle's show
 - [http://www.msn.com/en-us/news/technology/elon-musk-booed-during-surprise-appearance-at-dave-chappelle-s-show/ar-AA15bwKI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-booed-during-surprise-appearance-at-dave-chappelle-s-show/ar-AA15bwKI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 14:45:14.273443+00:00



## 4 Maine college students killed in crash after car strikes tree, erupts in flames
 - [http://www.msn.com/en-us/news/crime/4-maine-college-students-killed-in-crash-after-car-strikes-tree-erupts-in-flames/ar-AA15a8rS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/4-maine-college-students-killed-in-crash-after-car-strikes-tree-erupts-in-flames/ar-AA15a8rS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 14:45:14.265304+00:00



## Iran Executes Second Prisoner Majidreza Rahnavard in Mashhad Over Amini Protests
 - [http://www.msn.com/en-us/news/world/iran-executes-second-prisoner-majidreza-rahnavard-in-mashhad-over-amini-protests/ar-AA15bny3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/iran-executes-second-prisoner-majidreza-rahnavard-in-mashhad-over-amini-protests/ar-AA15bny3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 14:45:14.258003+00:00



## Slain teen 'loved life,' mom says before killer's execution
 - [http://www.msn.com/en-us/news/crime/slain-teen-loved-life-mom-says-before-killer-s-execution/ar-AA15bl7D?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/slain-teen-loved-life-mom-says-before-killer-s-execution/ar-AA15bl7D?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 14:45:14.249946+00:00



## Rethinking Bonds in Portfolios
 - [http://www.msn.com/en-us/money/topstocks/rethinking-bonds-in-portfolios/vi-AA15bkhB?srcref=rss](http://www.msn.com/en-us/money/topstocks/rethinking-bonds-in-portfolios/vi-AA15bkhB?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 13:45:12.435914+00:00



## Hearings set for bill to ban certain guns in Illinois
 - [http://www.msn.com/en-us/news/us/hearings-set-for-bill-to-ban-certain-guns-in-illinois/ar-AA15bduC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/hearings-set-for-bill-to-ban-certain-guns-in-illinois/ar-AA15bduC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 13:45:12.428548+00:00



## Ukraine PM urges more military aid to counter Russia attacks
 - [http://www.msn.com/en-us/news/world/ukraine-pm-urges-more-military-aid-to-counter-russia-attacks/ar-AA15b9TT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-pm-urges-more-military-aid-to-counter-russia-attacks/ar-AA15b9TT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 13:45:12.421096+00:00



## A brutal Russian paramilitary group active in Ukraine called for border intelligence on nearby NATO states: report
 - [http://www.msn.com/en-us/news/world/a-brutal-russian-paramilitary-group-active-in-ukraine-called-for-border-intelligence-on-nearby-nato-states-report/ar-AA15brQa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-brutal-russian-paramilitary-group-active-in-ukraine-called-for-border-intelligence-on-nearby-nato-states-report/ar-AA15brQa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 13:45:12.413732+00:00



## Young voters’ support for Democrats slipped in midterms: survey
 - [http://www.msn.com/en-us/news/politics/young-voters-support-for-democrats-slipped-in-midterms-survey/ar-AA15bkoq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/young-voters-support-for-democrats-slipped-in-midterms-survey/ar-AA15bkoq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 13:45:12.405493+00:00



## EU sets Xmas 2024 deadline for common phone charger
 - [http://www.msn.com/en-us/news/world/eu-sets-xmas-2024-deadline-for-common-phone-charger/ar-AA15beW1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/eu-sets-xmas-2024-deadline-for-common-phone-charger/ar-AA15beW1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 13:45:12.398052+00:00



## Texas Republicans propose a Florida-style election police force as it tees up more changes to voting laws
 - [http://www.msn.com/en-us/news/politics/texas-republicans-propose-a-florida-style-election-police-force-as-it-tees-up-more-changes-to-voting-laws/ar-AA15btOx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/texas-republicans-propose-a-florida-style-election-police-force-as-it-tees-up-more-changes-to-voting-laws/ar-AA15btOx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 13:45:12.390522+00:00



## Why China’s Leaders Fear Anniversaries
 - [http://www.msn.com/en-us/news/world/why-china-s-leaders-fear-anniversaries/ar-AA15bchH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/why-china-s-leaders-fear-anniversaries/ar-AA15bchH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 12:45:11.113941+00:00



## Why the protests in Iran are so hard to understand
 - [http://www.msn.com/en-us/news/world/why-the-protests-in-iran-are-so-hard-to-understand/ar-AA15aNsC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/why-the-protests-in-iran-are-so-hard-to-understand/ar-AA15aNsC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 12:45:11.106668+00:00



## House Oversight Committee to host Club Q shooting survivors in hearing on anti-LGBTQ threats
 - [http://www.msn.com/en-us/news/us/house-oversight-committee-to-host-club-q-shooting-survivors-in-hearing-on-anti-lgbtq-threats/ar-AA15aAEu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/house-oversight-committee-to-host-club-q-shooting-survivors-in-hearing-on-anti-lgbtq-threats/ar-AA15aAEu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 12:45:11.098787+00:00



## Kyrsten Sinema's switch to independent described as 'gut punch' to Democrats: ‘No wiggle room’
 - [http://www.msn.com/en-us/news/politics/kyrsten-sinema-s-switch-to-independent-described-as-gut-punch-to-democrats-no-wiggle-room/ar-AA15aAEI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kyrsten-sinema-s-switch-to-independent-described-as-gut-punch-to-democrats-no-wiggle-room/ar-AA15aAEI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 12:45:11.091414+00:00



## Debate rages over wisdom of trading ‘Merchant of Death’ for Brittney Griner’s freedom
 - [http://www.msn.com/en-us/news/world/debate-rages-over-wisdom-of-trading-merchant-of-death-for-brittney-griner-s-freedom/ar-AA15b5An?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/debate-rages-over-wisdom-of-trading-merchant-of-death-for-brittney-griner-s-freedom/ar-AA15b5An?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 12:45:11.083905+00:00



## Keystone Pipeline oil spill investigators search for cause of Kansas rupture
 - [http://www.msn.com/en-us/news/us/keystone-pipeline-oil-spill-investigators-search-for-cause-of-kansas-rupture/ar-AA15aA4p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/keystone-pipeline-oil-spill-investigators-search-for-cause-of-kansas-rupture/ar-AA15aA4p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 12:45:11.075710+00:00



## Undiagnosed cancer could be the next health crisis — and we aren’t ready
 - [http://www.msn.com/en-us/health/other/undiagnosed-cancer-could-be-the-next-health-crisis-and-we-aren-t-ready/ar-AA15bcII?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/other/undiagnosed-cancer-could-be-the-next-health-crisis-and-we-aren-t-ready/ar-AA15bcII?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 12:45:11.067713+00:00



## Indiana Lt Gov Crouch joins US Sen Braun in governor's race
 - [http://www.msn.com/en-us/news/politics/indiana-lt-gov-crouch-joins-us-sen-braun-in-governor-s-race/ar-AA15bexS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/indiana-lt-gov-crouch-joins-us-sen-braun-in-governor-s-race/ar-AA15bexS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 12:45:11.060442+00:00



## What Will a State of Emergency Do for L.A.'s Homeless Crisis?
 - [http://www.msn.com/en-us/news/us/what-will-a-state-of-emergency-do-for-l-a-s-homeless-crisis/ar-AA15aSQq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-will-a-state-of-emergency-do-for-l-a-s-homeless-crisis/ar-AA15aSQq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 11:48:15.386597+00:00



## The Hill’s Morning Report — Congress is running out of time for big fiscal deal
 - [http://www.msn.com/en-us/news/politics/the-hill-s-morning-report-congress-is-running-out-of-time-for-big-fiscal-deal/ar-AA15aLhi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-hill-s-morning-report-congress-is-running-out-of-time-for-big-fiscal-deal/ar-AA15aLhi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 11:48:15.378120+00:00



## The biggest missed opportunity of the lame-duck Congress so far
 - [http://www.msn.com/en-us/news/politics/the-biggest-missed-opportunity-of-the-lame-duck-congress-so-far/ar-AA15aXUV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-biggest-missed-opportunity-of-the-lame-duck-congress-so-far/ar-AA15aXUV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 11:48:15.366657+00:00



## Russia Complains of Ukraine Military's 'Aggressive Behavior'
 - [http://www.msn.com/en-us/news/world/russia-complains-of-ukraine-military-s-aggressive-behavior/ar-AA15b6P7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-complains-of-ukraine-military-s-aggressive-behavior/ar-AA15b6P7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 11:34:19.286435+00:00



## Inside Google’s Quest to Digitize Troops’ Tissue Samples
 - [http://www.msn.com/en-us/news/us/inside-google-s-quest-to-digitize-troops-tissue-samples/ar-AA15aVA7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/inside-google-s-quest-to-digitize-troops-tissue-samples/ar-AA15aVA7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 11:34:19.278729+00:00



## The Eureka Theory of History Is Wrong
 - [http://www.msn.com/en-us/news/us/the-eureka-theory-of-history-is-wrong/ar-AA15b9cN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-eureka-theory-of-history-is-wrong/ar-AA15b9cN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 11:34:19.270302+00:00



## Slim majorities mean legislators have a bipartisan climate mandate
 - [http://www.msn.com/en-us/news/politics/slim-majorities-mean-legislators-have-a-bipartisan-climate-mandate/ar-AA15aNaS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/slim-majorities-mean-legislators-have-a-bipartisan-climate-mandate/ar-AA15aNaS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 11:34:19.262980+00:00



## Behind-the-scenes hunt builds for McCarthy Speaker alternative
 - [http://www.msn.com/en-us/news/politics/behind-the-scenes-hunt-builds-for-mccarthy-speaker-alternative/ar-AA15b0fb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/behind-the-scenes-hunt-builds-for-mccarthy-speaker-alternative/ar-AA15b0fb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 11:34:19.255788+00:00



## Melania Trump shares Christmas 'magic,' message of 'hope and compassion' at foster care holiday celebration
 - [http://www.msn.com/en-us/news/us/melania-trump-shares-christmas-magic-message-of-hope-and-compassion-at-foster-care-holiday-celebration/ar-AA15b2xo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/melania-trump-shares-christmas-magic-message-of-hope-and-compassion-at-foster-care-holiday-celebration/ar-AA15b2xo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 11:34:19.248623+00:00



## Letters to the Editor: Why Herschel Walker's loss to Sen. Raphael Warnock wasn't about character
 - [http://www.msn.com/en-us/news/politics/letters-to-the-editor-why-herschel-walker-s-loss-to-sen-raphael-warnock-wasn-t-about-character/ar-AA15b0ly?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/letters-to-the-editor-why-herschel-walker-s-loss-to-sen-raphael-warnock-wasn-t-about-character/ar-AA15b0ly?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 11:34:19.240766+00:00



## Elon Musk hits back at former NASA astronaut Scott Kelly, who accused the billionaire of mocking the LGBTQ community by misusing gender pronouns
 - [http://www.msn.com/en-us/news/politics/elon-musk-hits-back-at-former-nasa-astronaut-scott-kelly-who-accused-the-billionaire-of-mocking-the-lgbtq-community-by-misusing-gender-pronouns/ar-AA15b9cG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/elon-musk-hits-back-at-former-nasa-astronaut-scott-kelly-who-accused-the-billionaire-of-mocking-the-lgbtq-community-by-misusing-gender-pronouns/ar-AA15b9cG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 11:34:19.233355+00:00



## How Dutch farmers became the center of a global right-wing culture war
 - [http://www.msn.com/en-us/news/world/how-dutch-farmers-became-the-center-of-a-global-right-wing-culture-war/ar-AA15b237?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/how-dutch-farmers-became-the-center-of-a-global-right-wing-culture-war/ar-AA15b237?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 10:48:52.530443+00:00



## An Exodus Unlike Any Other: Why Half the People in This Community Moved Away After Hurricane Katrina
 - [http://www.msn.com/en-us/news/us/an-exodus-unlike-any-other-why-half-the-people-in-this-community-moved-away-after-hurricane-katrina/ar-AA15aRTV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/an-exodus-unlike-any-other-why-half-the-people-in-this-community-moved-away-after-hurricane-katrina/ar-AA15aRTV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 10:34:17.044796+00:00



## The End of the New Peace
 - [http://www.msn.com/en-us/news/world/the-end-of-the-new-peace/ar-AA15aKy6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-end-of-the-new-peace/ar-AA15aKy6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 10:34:17.037650+00:00



## Barrett 'identified the real issue' in LGBT weddings case: Supreme Court lawyer
 - [http://www.msn.com/en-us/news/us/barrett-identified-the-real-issue-in-lgbt-weddings-case-supreme-court-lawyer/ar-AA15b1SP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/barrett-identified-the-real-issue-in-lgbt-weddings-case-supreme-court-lawyer/ar-AA15b1SP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 10:34:17.030506+00:00



## This week: Congress faces government funding deadline
 - [http://www.msn.com/en-us/news/politics/this-week-congress-faces-government-funding-deadline/ar-AA15aIaf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/this-week-congress-faces-government-funding-deadline/ar-AA15aIaf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 10:34:17.023274+00:00



## It’s Going to Be a Grim Winter for Ukraine
 - [http://www.msn.com/en-us/news/world/it-s-going-to-be-a-grim-winter-for-ukraine/ar-AA15b1Kp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/it-s-going-to-be-a-grim-winter-for-ukraine/ar-AA15b1Kp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 10:34:17.015368+00:00



## It took a full year, multiple calls to the dealership, and an angry tweet at Ford's CEO, to finally get my all-electric pickup truck delivered
 - [http://www.msn.com/en-us/news/technology/it-took-a-full-year-multiple-calls-to-the-dealership-and-an-angry-tweet-at-ford-s-ceo-to-finally-get-my-all-electric-pickup-truck-delivered/ar-AA15aUGo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/it-took-a-full-year-multiple-calls-to-the-dealership-and-an-angry-tweet-at-ford-s-ceo-to-finally-get-my-all-electric-pickup-truck-delivered/ar-AA15aUGo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 10:34:17.008235+00:00



## Deliveroo drivers banned from High Street - council
 - [http://www.msn.com/en-us/news/world/deliveroo-drivers-banned-from-high-street-council/ar-AA15aG8x?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/deliveroo-drivers-banned-from-high-street-council/ar-AA15aG8x?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 10:34:17.000823+00:00



## John M. Crisp: Who gets to decide when and how we die?
 - [http://www.msn.com/en-us/news/us/john-m-crisp-who-gets-to-decide-when-and-how-we-die/ar-AA15aFCE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/john-m-crisp-who-gets-to-decide-when-and-how-we-die/ar-AA15aFCE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 09:48:48.092135+00:00



## A Fusion Energy Breakthrough? Major Announcement Expected From US Scientists
 - [http://www.msn.com/en-us/news/technology/a-fusion-energy-breakthrough-major-announcement-expected-from-us-scientists/ar-AA159Sxa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/a-fusion-energy-breakthrough-major-announcement-expected-from-us-scientists/ar-AA159Sxa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 09:48:48.083716+00:00



## Trump who? GOP senators rave over a potential Tim Scott presidential run.
 - [http://www.msn.com/en-us/news/politics/trump-who-gop-senators-rave-over-a-potential-tim-scott-presidential-run/ar-AA15aWpV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-who-gop-senators-rave-over-a-potential-tim-scott-presidential-run/ar-AA15aWpV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 09:48:48.075525+00:00



## Wordle Today #541 Hints and Answer for Monday, December 12 Game
 - [http://www.msn.com/en-us/news/technology/wordle-today-541-hints-and-answer-for-monday-december-12-game/ar-AA15aMd6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/wordle-today-541-hints-and-answer-for-monday-december-12-game/ar-AA15aMd6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 09:28:54.183967+00:00



## Ukraine Latest: G-7 to Hold Conference Call on Ukraine Support
 - [http://www.msn.com/en-us/news/world/ukraine-latest-g-7-to-hold-conference-call-on-ukraine-support/ar-AA15aDqZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-latest-g-7-to-hold-conference-call-on-ukraine-support/ar-AA15aDqZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 09:28:54.176822+00:00



## 6 books that help kids and YAs cope with tragedy
 - [http://www.msn.com/en-us/news/world/6-books-that-help-kids-and-yas-cope-with-tragedy/ar-AA15aQro?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/6-books-that-help-kids-and-yas-cope-with-tragedy/ar-AA15aQro?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 09:28:54.168160+00:00



## Putin's old EU ally Viktor Orban is once again aggravating Brussels
 - [http://www.msn.com/en-us/news/world/putin-s-old-eu-ally-viktor-orban-is-once-again-aggravating-brussels/ar-AA15arFO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-s-old-eu-ally-viktor-orban-is-once-again-aggravating-brussels/ar-AA15arFO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 08:47:32.927614+00:00



## Dogs gifted by North's Kim resettle in South Korean zoo
 - [http://www.msn.com/en-us/news/world/dogs-gifted-by-north-s-kim-resettle-in-south-korean-zoo/ar-AA15avN0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/dogs-gifted-by-north-s-kim-resettle-in-south-korean-zoo/ar-AA15avN0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 08:47:32.901834+00:00



## Over 82,000 Ukrainians Refugees 'Paroled' Into U.S.: Immigration
 - [http://www.msn.com/en-us/news/world/over-82-000-ukrainians-refugees-paroled-into-u-s-immigration/ar-AA15aCAf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/over-82-000-ukrainians-refugees-paroled-into-u-s-immigration/ar-AA15aCAf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 08:08:19.106819+00:00



## Box covering statue of Christopher Columbus in Philly is removed after judge ruled against mayor
 - [http://www.msn.com/en-us/news/us/box-covering-statue-of-christopher-columbus-in-philly-is-removed-after-judge-ruled-against-mayor/ar-AA15aEPr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/box-covering-statue-of-christopher-columbus-in-philly-is-removed-after-judge-ruled-against-mayor/ar-AA15aEPr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 08:08:19.094829+00:00



## Dog therapy for kids facing the trauma of the war in Ukraine
 - [http://www.msn.com/en-us/news/world/dog-therapy-for-kids-facing-the-trauma-of-the-war-in-ukraine/ar-AA15aCx0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/dog-therapy-for-kids-facing-the-trauma-of-the-war-in-ukraine/ar-AA15aCx0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 07:49:34.258751+00:00



## China’s Rapid Covid Reversal Sparks Whiplash as Cases Surge
 - [http://www.msn.com/en-us/news/world/china-s-rapid-covid-reversal-sparks-whiplash-as-cases-surge/ar-AA159VdA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-s-rapid-covid-reversal-sparks-whiplash-as-cases-surge/ar-AA159VdA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 07:39:13.149811+00:00



## WATCH: Hugo Gurdon calls out 'extreme irony' of Sanders bashing Sinema
 - [http://www.msn.com/en-us/news/politics/watch-hugo-gurdon-calls-out-extreme-irony-of-sanders-bashing-sinema/ar-AA15al1s?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/watch-hugo-gurdon-calls-out-extreme-irony-of-sanders-bashing-sinema/ar-AA15al1s?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 07:27:57.306866+00:00



## Retention issues? Political strategists weigh in on recent departures from the Democratic Party
 - [http://www.msn.com/en-us/news/politics/retention-issues-political-strategists-weigh-in-on-recent-departures-from-the-democratic-party/ar-AA15aLHb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/retention-issues-political-strategists-weigh-in-on-recent-departures-from-the-democratic-party/ar-AA15aLHb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 07:27:57.299182+00:00



## Fallout from LA racism scandal keeps shaking City Council
 - [http://www.msn.com/en-us/news/us/fallout-from-la-racism-scandal-keeps-shaking-city-council/ar-AA15aBO3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/fallout-from-la-racism-scandal-keeps-shaking-city-council/ar-AA15aBO3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 07:03:49.018606+00:00



## Putin's old EU ally Orban is once again aggravating Brussels with knockbacks
 - [http://www.msn.com/en-us/news/world/putin-s-old-eu-ally-orban-is-once-again-aggravating-brussels-with-knockbacks/ar-AA15arFO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-s-old-eu-ally-orban-is-once-again-aggravating-brussels-with-knockbacks/ar-AA15arFO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 07:03:48.830682+00:00



## Young voters' enthusiasm for Democrats waned during midterms
 - [http://www.msn.com/en-us/news/politics/young-voters-enthusiasm-for-democrats-waned-during-midterms/ar-AA15aB6c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/young-voters-enthusiasm-for-democrats-waned-during-midterms/ar-AA15aB6c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 06:03:45.937548+00:00



## Iranian protesters need our support
 - [http://www.msn.com/en-us/news/world/iranian-protesters-need-our-support/ar-AA15awfe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/iranian-protesters-need-our-support/ar-AA15awfe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 06:03:45.929678+00:00



## Can you spot what's wrong with this advent calendar?
 - [http://www.msn.com/en-us/news/technology/can-you-spot-what-s-wrong-with-this-advent-calendar/ar-AA15apep?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/can-you-spot-what-s-wrong-with-this-advent-calendar/ar-AA15apep?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 06:03:45.921080+00:00



## Karen Bass, vowing unity, takes oath as L.A.'s mayor
 - [http://www.msn.com/en-us/news/us/karen-bass-vowing-unity-takes-oath-as-l-a-s-mayor/ar-AA15awdQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/karen-bass-vowing-unity-takes-oath-as-l-a-s-mayor/ar-AA15awdQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 06:03:45.732399+00:00



## G-7 Leaders to Meet Virtually After Biden Call With Zelenskiy
 - [http://www.msn.com/en-us/news/world/g-7-leaders-to-meet-virtually-after-biden-call-with-zelenskiy/ar-AA15ai29?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/g-7-leaders-to-meet-virtually-after-biden-call-with-zelenskiy/ar-AA15ai29?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 05:03:43.869997+00:00



## Taylor Greene says Jan. 6 Capitol attack ‘would’ve been armed’ if she planned it
 - [http://www.msn.com/en-us/news/politics/taylor-greene-says-jan-6-capitol-attack-would-ve-been-armed-if-she-planned-it/ar-AA15aigM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/taylor-greene-says-jan-6-capitol-attack-would-ve-been-armed-if-she-planned-it/ar-AA15aigM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 05:03:43.862489+00:00



## Hundreds of migrants wait to cross Rio Grande to Texas after CBP sent 20 buses back to Mexico
 - [http://www.msn.com/en-us/news/us/hundreds-of-migrants-wait-to-cross-rio-grande-to-texas-after-cbp-sent-20-buses-back-to-mexico/ar-AA15aw0c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/hundreds-of-migrants-wait-to-cross-rio-grande-to-texas-after-cbp-sent-20-buses-back-to-mexico/ar-AA15aw0c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 05:03:43.853746+00:00



## Second Iranian detainee executed over alleged protest crime
 - [http://www.msn.com/en-us/news/world/second-iranian-detainee-executed-over-alleged-protest-crime/ar-AA15aozO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/second-iranian-detainee-executed-over-alleged-protest-crime/ar-AA15aozO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 05:03:43.846258+00:00



## In Kansas, crews contain largest-yet breach of Keystone Pipeline
 - [http://www.msn.com/en-us/news/us/in-kansas-crews-contain-largest-yet-breach-of-keystone-pipeline/ar-AA15aoCT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/in-kansas-crews-contain-largest-yet-breach-of-keystone-pipeline/ar-AA15aoCT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 05:03:43.657640+00:00



## Donald Trump Says He Turned Down Russian Swap Deal for Paul Whelan
 - [http://www.msn.com/en-us/news/politics/donald-trump-says-he-turned-down-russian-swap-deal-for-paul-whelan/ar-AA15ao1t?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/donald-trump-says-he-turned-down-russian-swap-deal-for-paul-whelan/ar-AA15ao1t?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 04:03:41.531038+00:00



## Donald Trump Says He 'Turned Down Deal' of Paul Whelan for Viktor Bout
 - [http://www.msn.com/en-us/news/world/donald-trump-says-he-turned-down-deal-of-paul-whelan-for-viktor-bout/ar-AA15ahzB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/donald-trump-says-he-turned-down-deal-of-paul-whelan-for-viktor-bout/ar-AA15ahzB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 04:03:41.521826+00:00



## Ukraine strikes hotel housing dozens of Russian soldiers
 - [http://www.msn.com/en-us/news/world/ukraine-strikes-hotel-housing-dozens-of-russian-soldiers/ar-AA15ahOm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-strikes-hotel-housing-dozens-of-russian-soldiers/ar-AA15ahOm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 04:03:41.514314+00:00



## Liberalism is designed to 'destroy the nuclear family:' Mark Levin
 - [http://www.msn.com/en-us/news/world/liberalism-is-designed-to-destroy-the-nuclear-family-mark-levin/ar-AA15am5H?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/liberalism-is-designed-to-destroy-the-nuclear-family-mark-levin/ar-AA15am5H?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 04:03:41.506757+00:00



## That Viral Dance From Netflix Megahit 'Wednesday' Is Taking Over TikTok
 - [http://www.msn.com/en-us/news/technology/that-viral-dance-from-netflix-megahit-wednesday-is-taking-over-tiktok/ar-AA14ZcTx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/that-viral-dance-from-netflix-megahit-wednesday-is-taking-over-tiktok/ar-AA14ZcTx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 04:03:41.499241+00:00



## Group of Seven Leaders to Hold Virtual Meeting on Monday
 - [http://www.msn.com/en-us/news/world/group-of-seven-leaders-to-hold-virtual-meeting-on-monday/ar-AA15ai29?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/group-of-seven-leaders-to-hold-virtual-meeting-on-monday/ar-AA15ai29?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 04:03:41.491578+00:00



## Trump, Kanye West, and Nick Fuentes pushing antisemitism to the forefront of the GOP could pull the Christian nationalist movement apart
 - [http://www.msn.com/en-us/news/world/trump-kanye-west-and-nick-fuentes-pushing-antisemitism-to-the-forefront-of-the-gop-could-pull-the-christian-nationalist-movement-apart/ar-AA15aond?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/trump-kanye-west-and-nick-fuentes-pushing-antisemitism-to-the-forefront-of-the-gop-could-pull-the-christian-nationalist-movement-apart/ar-AA15aond?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 04:03:41.303679+00:00



## Sources describe Paul Whelan for Viktor Bout trade deal Trump says he turned down
 - [http://www.msn.com/en-us/news/politics/sources-describe-paul-whelan-for-viktor-bout-trade-deal-trump-says-he-turned-down/ar-AA15alpn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/sources-describe-paul-whelan-for-viktor-bout-trade-deal-trump-says-he-turned-down/ar-AA15alpn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 03:03:37.033887+00:00



## Bout says Griner ‘wanted to shake my hand’ on airport tarmac
 - [http://www.msn.com/en-us/news/politics/bout-says-griner-wanted-to-shake-my-hand-on-airport-tarmac/ar-AA159Sh1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/bout-says-griner-wanted-to-shake-my-hand-on-airport-tarmac/ar-AA159Sh1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 03:03:37.026293+00:00



## Rep. Bacon 'guarantees' McCarthy has more support for speaker now than in November, urges GOP to be a 'team'
 - [http://www.msn.com/en-us/news/politics/rep-bacon-guarantees-mccarthy-has-more-support-for-speaker-now-than-in-november-urges-gop-to-be-a-team/ar-AA159VaZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-bacon-guarantees-mccarthy-has-more-support-for-speaker-now-than-in-november-urges-gop-to-be-a-team/ar-AA159VaZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 03:03:36.836544+00:00



## Signs of life for omnibus deal as negotiators make headway
 - [http://www.msn.com/en-us/news/politics/signs-of-life-for-omnibus-deal-as-negotiators-make-headway/ar-AA15agdh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/signs-of-life-for-omnibus-deal-as-negotiators-make-headway/ar-AA15agdh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 02:03:33.596191+00:00



## 12 Steps Everyone Should Follow When Loading Their Dishwasher
 - [http://www.msn.com/en-us/news/technology/12-steps-everyone-should-follow-when-loading-their-dishwasher/ar-AAYN2Hh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/12-steps-everyone-should-follow-when-loading-their-dishwasher/ar-AAYN2Hh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 02:03:33.587845+00:00



## Harris swears in Bass as first Black female mayor of Los Angeles
 - [http://www.msn.com/en-us/news/politics/harris-swears-in-bass-as-first-black-female-mayor-of-los-angeles/ar-AA15agj0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/harris-swears-in-bass-as-first-black-female-mayor-of-los-angeles/ar-AA15agj0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 02:03:33.579881+00:00



## Jamie Dimon says Dems should find debt ceiling fix before House GOP takeover
 - [http://www.msn.com/en-us/news/politics/jamie-dimon-says-dems-should-find-debt-ceiling-fix-before-house-gop-takeover/ar-AA159ROU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jamie-dimon-says-dems-should-find-debt-ceiling-fix-before-house-gop-takeover/ar-AA159ROU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 02:03:33.571355+00:00



## NASA chief: SpaceX leader says Elon Musk’s Twitter drama is ‘nothing to worry about’
 - [http://www.msn.com/en-us/news/technology/nasa-chief-spacex-leader-says-elon-musk-s-twitter-drama-is-nothing-to-worry-about/ar-AA159RLN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/nasa-chief-spacex-leader-says-elon-musk-s-twitter-drama-is-nothing-to-worry-about/ar-AA159RLN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 02:03:33.563530+00:00



## This ‘Sneaky’ DeSantis Power Grab Might Be His Cruelest Yet
 - [http://www.msn.com/en-us/news/us/this-sneaky-desantis-power-grab-might-be-his-cruelest-yet/ar-AA15aeP0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/this-sneaky-desantis-power-grab-might-be-his-cruelest-yet/ar-AA15aeP0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 02:03:33.556047+00:00



## Protests over Peru's political crisis continue around nation
 - [http://www.msn.com/en-us/news/world/protests-over-peru-s-political-crisis-continue-around-nation/ar-AA15aeYJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/protests-over-peru-s-political-crisis-continue-around-nation/ar-AA15aeYJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 02:03:33.548352+00:00



## American student goes missing while studying abroad in France
 - [http://www.msn.com/en-us/news/crime/american-student-goes-missing-while-studying-abroad-in-france/ar-AA15af2s?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/american-student-goes-missing-while-studying-abroad-in-france/ar-AA15af2s?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 02:03:33.410317+00:00



## Jan. 6 Panel Members Say Criminal Referrals Would Be Important Marker
 - [http://www.msn.com/en-us/news/politics/jan-6-panel-members-say-criminal-referrals-would-be-important-marker/ar-AA15aevn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jan-6-panel-members-say-criminal-referrals-would-be-important-marker/ar-AA15aevn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 01:03:29.062786+00:00



## Was Santa Actually a Badass Who Beat Up a Priest?
 - [http://www.msn.com/en-us/news/world/was-santa-actually-a-badass-who-beat-up-a-priest/ar-AA15a6sh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/was-santa-actually-a-badass-who-beat-up-a-priest/ar-AA15a6sh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 01:03:29.055302+00:00



## Democrat Bass takes charge as LA mayor amid homeless crisis
 - [http://www.msn.com/en-us/news/politics/democrat-bass-takes-charge-as-la-mayor-amid-homeless-crisis/ar-AA159K8D?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/democrat-bass-takes-charge-as-la-mayor-amid-homeless-crisis/ar-AA159K8D?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 01:03:29.047343+00:00



## Russian forces retreating from Kherson left behind booby traps — including a grenade in a washing machine and a street sign that directed people into a minefield
 - [http://www.msn.com/en-us/news/world/russian-forces-retreating-from-kherson-left-behind-booby-traps-including-a-grenade-in-a-washing-machine-and-a-street-sign-that-directed-people-into-a-minefield/ar-AA15a9zT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-forces-retreating-from-kherson-left-behind-booby-traps-including-a-grenade-in-a-washing-machine-and-a-street-sign-that-directed-people-into-a-minefield/ar-AA15a9zT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 01:03:29.039810+00:00



## Trump says he turned down deal to release Paul Whelan
 - [http://www.msn.com/en-us/news/politics/trump-says-he-turned-down-deal-to-release-paul-whelan/ar-AA159Q36?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-says-he-turned-down-deal-to-release-paul-whelan/ar-AA159Q36?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 01:03:28.852054+00:00



## Former Diplomat Knocks 'Old School' Putin and His Perceived 'Path to Glory'
 - [http://www.msn.com/en-us/news/world/former-diplomat-knocks-old-school-putin-and-his-perceived-path-to-glory/ar-AA15a8VR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/former-diplomat-knocks-old-school-putin-and-his-perceived-path-to-glory/ar-AA15a8VR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 00:03:47.151561+00:00



## Historic moon mission concludes with ‘picture perfect splashdown’ of Orion capsule into the Pacific
 - [http://www.msn.com/en-us/news/technology/historic-moon-mission-concludes-with-picture-perfect-splashdown-of-orion-capsule-into-the-pacific/ar-AA15absL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/historic-moon-mission-concludes-with-picture-perfect-splashdown-of-orion-capsule-into-the-pacific/ar-AA15absL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 00:03:47.143570+00:00



## How did Advent calendars become a beloved holiday tradition?
 - [http://www.msn.com/en-us/news/politics/how-did-advent-calendars-become-a-beloved-holiday-tradition/ar-AA159PCE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/how-did-advent-calendars-become-a-beloved-holiday-tradition/ar-AA159PCE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 00:03:47.135882+00:00



## Despite GOP criticism of the prisoner swap that freed Brittney Griner, Fiona Hill said Trump was 'not particularly interested' in freeing Paul Whelan
 - [http://www.msn.com/en-us/news/politics/despite-gop-criticism-of-the-prisoner-swap-that-freed-brittney-griner-fiona-hill-said-trump-was-not-particularly-interested-in-freeing-paul-whelan/ar-AA159TYZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/despite-gop-criticism-of-the-prisoner-swap-that-freed-brittney-griner-fiona-hill-said-trump-was-not-particularly-interested-in-freeing-paul-whelan/ar-AA159TYZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 00:03:47.128406+00:00



## Free for a month, Kherson toils to clear Russian traps
 - [http://www.msn.com/en-us/news/world/free-for-a-month-kherson-toils-to-clear-russian-traps/ar-AA159U4c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/free-for-a-month-kherson-toils-to-clear-russian-traps/ar-AA159U4c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 00:03:47.120847+00:00



## King Charles and Queen Consort Camilla release Christmas card
 - [http://www.msn.com/en-us/news/world/king-charles-and-queen-consort-camilla-release-christmas-card/ar-AA15a1x6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/king-charles-and-queen-consort-camilla-release-christmas-card/ar-AA15a1x6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-12 00:03:47.113246+00:00




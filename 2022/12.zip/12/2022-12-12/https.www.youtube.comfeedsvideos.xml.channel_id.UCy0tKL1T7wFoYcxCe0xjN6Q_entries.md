# Source:Technology Connections, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0tKL1T7wFoYcxCe0xjN6Q, language:en-US

## The decorative lamp that's built wrong on purpose
 - [https://www.youtube.com/watch?v=nyYjnV99wfM](https://www.youtube.com/watch?v=nyYjnV99wfM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0tKL1T7wFoYcxCe0xjN6Q
 - date published: 2022-12-12 17:36:12+00:00

It's a festive flickery flicker fest!

Links 'n' stuff:
Technology Connextras (my second channel where stuff goes sometimes)
https://www.youtube.com/@TechnologyConnextras

Technology Connections on Mastodon:
https://mas.to/@TechConnectify

Technology Connections on Twitter (...for now):
https://twitter.com/TechConnectify

The TC Subreddit
https://www.reddit.com/r/technologyconnections

This channel is supported through viewer contributions on Patreon. Thanks to the generous support of people like you, Technology Connections has remained independent and possible. If you'd like to join the amazing people who've pledged their support, check out the link below. Thank you for your consideration!
https://www.patreon.com/technologyconnections


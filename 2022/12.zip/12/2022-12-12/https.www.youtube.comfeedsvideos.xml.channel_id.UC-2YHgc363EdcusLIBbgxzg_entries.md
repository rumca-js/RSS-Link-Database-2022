# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## They Thought It Was Hail. It Was Something WAY Weirder.
 - [https://www.youtube.com/watch?v=NfM-EJMFE48](https://www.youtube.com/watch?v=NfM-EJMFE48)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-12-12 14:52:28+00:00

For 18 FREE meals with HelloFresh plus free shipping, use code JOESCOTT18 at https://bit.ly/3TIKVSt!
Over a period of 6 weeks in 1994, the small town of Oakville, Washington was hit with a bizarre string of storms that rained weird gelatinous blobs all over the town. It was all just a funny sidenote - and then people started getting sick. This is the weird and still unsolved mystery of the Oakville Blobs.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPGzF
Apple Podcasts 👉 https://apple.co/3j94kfq
Google Podcasts 👉 https://bit.ly/3qZCo1V

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS -
https://web.archive.org/web/20201111203332/https://factslegend.org/raining-blobs-mystery-or-hoax/
https://www.frontiersin.org/articles/10.3389/fmicb.2019.00044/full
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4435039/
https://gizmodo.com/the-enduring-myth-of-star-jelly-1693997962
https://www.straightdope.com/21341699/did-mrs-sybil-christian-of-frisco-texas-find-blobs-from-space-on-her-lawn
https://en.wikipedia.org/wiki/Operation_Sea-Spray
https://www.newspapers.com/image/535761258/?fcfToken=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVlLXZpZXctaWQiOjUzNTc2MTI1OCwiaWF0IjoxNjY4MDkzMzAzLCJleHAiOjE2NjgxNzk3MDN9.ZMksMAPu8Q297TIojPaDexHOSDv46mQOdRYjQ634
https://www.mentalfloss.com/posts/oakville-blobs-mystery
https://www.sciencefocus.com/science/what-were-the-oakville-blobs/
https://www.reddit.com/r/UnresolvedMysteries/comments/2syjxi/the_oakville_blobs_of_oakville_wa_usa/

TIMESTAMPS:
0:00 - Intro
1:15 - Oakville Blobs: A Strange Rain
3:37 - Missing Samples
4:05 - Star Jelly
4:54 - Jellyfish
5:29 - Human Waste
6:32 - Secret Military Experiments
7:59 - Fact Vs Fiction
9:51 - Sponsor - Hello Fresh


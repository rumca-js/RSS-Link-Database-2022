# Source:ComputerWorld, URL:https://www.computerworld.com/index.rss, language:en-US

## 5 things Elon Musk could learn from Microsoft CEO Satya Nadella
 - [https://www.computerworld.com/article/3682893/5-things-elon-musk-could-learn-from-microsoft-ceo-satya-nadella.html#tk.rss_all](https://www.computerworld.com/article/3682893/5-things-elon-musk-could-learn-from-microsoft-ceo-satya-nadella.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-12-12 11:00:00+00:00

<article>
	<section class="page">
<p>Back in April, two days after Elon Musk announced his plan to buy Twitter, <a href="https://www.businessinsider.com/elon-musk-private-texts-show-he-spoke-with-microsoft-ceo-2022-9" rel="noopener nofollow" target="_blank">Musk had a private phone call with Microsoft CEO Satya Nadella</a>. One might have expected Musk to ask Nadella for advice on how to turn around the flailing Twitter — after all, Nadella had engineered perhaps the most successful tech turnaround in history.</p><p>In 2014 he took the helm of a directionless Microsoft riven by discord and stagnation and whose stock price had dropped by more than half during what is generally called Microsoft’s lost decade. Today, thanks to Nadella’s guidance, <a href="https://www.investopedia.com/biggest-companies-in-the-world-by-market-cap-5212784" rel="noopener nofollow" target="_blank">Microsoft has the third-biggest market cap in the world</a> and, as a leader in multiple cutting-edge technologies, is well-placed for the future.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3682893/5-things-elon-musk-could-learn-from-microsoft-ceo-satya-nadella.html#jump">To read this article in full, please click here</a></p></section></article>


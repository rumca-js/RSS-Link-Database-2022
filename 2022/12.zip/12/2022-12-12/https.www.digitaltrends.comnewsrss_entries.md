# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## Returnal might be the first PC game to recommend this much RAM
 - [https://www.digitaltrends.com/computing/returnal-might-be-first-pc-game-to-recommend-32gb/](https://www.digitaltrends.com/computing/returnal-might-be-first-pc-game-to-recommend-32gb/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2022-12-12 19:45:05.377865+00:00

Sony's Returnal is coming to the PC soon, and of all the system requirements, the amount of recommended RAM raises some questions.


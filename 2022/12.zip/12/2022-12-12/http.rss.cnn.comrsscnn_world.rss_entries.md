# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## The latest on the Lockerbie bombing suspect in US custody
 - [https://www.cnn.com/world/live-news/lockerbie-bombing-suspect-masud-custody/index.html](https://www.cnn.com/world/live-news/lockerbie-bombing-suspect-masud-custody/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-12-12 23:49:12+00:00



## Two sisters just reunited with the mystery woman who gave them $100 on a plane 23 years ago
 - [https://www.cnn.com/travel/article/refugee-sisters-tracy-airplane-reunion-cnnheroes-cec/index.html](https://www.cnn.com/travel/article/refugee-sisters-tracy-airplane-reunion-cnnheroes-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-12-12 22:53:15+00:00

Ayda Zugay clasps her hands together, trying to keep her nerves in check.

## Survivor found 'gasping for life' among bodies dumped on Zambian roadside
 - [https://www.cnn.com/2022/12/12/africa/ethiopians-found-dead-zambia-intl/index.html](https://www.cnn.com/2022/12/12/africa/ethiopians-found-dead-zambia-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-12-12 15:12:27+00:00

Zambia's police service says it is investigating the deaths of 27 men, all believed to be Ethiopian nationals, whose bodies were found on Sunday "dumped" by the roadside near the capital, Lusaka.

## Kosovo calls for NATO intervention after weekend of violence amid rising ethnic tensions
 - [https://www.cnn.com/2022/12/12/europe/kosovo-serbia-nato-violence-protests-intl-hnk/index.html](https://www.cnn.com/2022/12/12/europe/kosovo-serbia-nato-violence-protests-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-12-12 06:22:11+00:00

Kosovo's Prime Minister urged NATO peacekeeping troops to intervene after minority Serb protesters blocked roads and unknown gunmen exchanged fire with police over the weekend amid rising ethnic tensions in the country's restive north.

## China to abolish its Covid-19 trace tracking service, the 'Mobile Itinerary card,' on Tuesday, officials say
 - [https://www.cnn.com/2022/12/11/asia/china-ending-covid-tracking-service/index.html](https://www.cnn.com/2022/12/11/asia/china-ending-covid-tracking-service/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-12-12 01:48:51+00:00

China will abolish its Covid-19 trace tracking service, the "Mobile Itinerary card," on Tuesday, officials say.


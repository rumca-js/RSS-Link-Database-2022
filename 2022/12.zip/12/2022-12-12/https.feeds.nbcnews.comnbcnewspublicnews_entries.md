## Karen Bass, vowing unity, takes oath as L.A.'s mayor
 - [https://www.nbcnews.com/news/us-news/karen-bass-promising-pursue-unity-takes-oath-ls-mayor-rcna61204](https://www.nbcnews.com/news/us-news/karen-bass-promising-pursue-unity-takes-oath-ls-mayor-rcna61204)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/news
 - date published: 2022-12-12 05:28:16+00:00

Former U.S. Rep. Karen Bass vowed Sunday night to pursue unity as she took oath as the 43rd mayor of  Los Angeles.

## Crews in Kansas contain the largest-yet breach of the Keystone Pipeline
 - [https://www.nbcnews.com/news/us-news/kansas-crews-contain-largest-yet-breach-keystone-pipeline-rcna61196](https://www.nbcnews.com/news/us-news/kansas-crews-contain-largest-yet-breach-keystone-pipeline-rcna61196)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/news
 - date published: 2022-12-12 04:21:47+00:00

The operator of the Keystone Pipeline System, which carries a form of crude oil from Canada to multiple states for refining, said over the weekend that its

## NASA chief: SpaceX leader says Elon Musk’s Twitter drama is ‘nothing to worry about’
 - [https://www.nbcnews.com/politics/politics-news/spacex-leader-reassured-nasa-chief-elson-musk-rcna61189](https://www.nbcnews.com/politics/politics-news/spacex-leader-reassured-nasa-chief-elson-musk-rcna61189)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/news
 - date published: 2022-12-12 00:56:31+00:00

NASA Administrator Bill Nelson received assurances from the head of SpaceX that Elon Musk's Twitter drama is "nothing to worry about."


# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Clojure is a trinity of language, REPL, and structural editor
 - [https://blog.jakubholy.net/2022/trinity-of-clojure/](https://blog.jakubholy.net/2022/trinity-of-clojure/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 23:39:21+00:00

<p>Article URL: <a href="https://blog.jakubholy.net/2022/trinity-of-clojure/">https://blog.jakubholy.net/2022/trinity-of-clojure/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33962090">https://news.ycombinator.com/item?id=33962090</a></p>
<p>Points: 25</p>
<p># Comments: 8</p>

## SBF Arrested by Bahamian Authorities
 - [https://twitter.com/tier10k/status/1602446984090107905](https://twitter.com/tier10k/status/1602446984090107905)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 23:38:53+00:00

<p>Article URL: <a href="https://twitter.com/tier10k/status/1602446984090107905">https://twitter.com/tier10k/status/1602446984090107905</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33962083">https://news.ycombinator.com/item?id=33962083</a></p>
<p>Points: 265</p>
<p># Comments: 40</p>

## Building Games with DragonRuby – A free book on Ruby game dev
 - [https://book.dragonriders.community/](https://book.dragonriders.community/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 23:34:58+00:00

<p>Article URL: <a href="https://book.dragonriders.community/">https://book.dragonriders.community/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33962042">https://news.ycombinator.com/item?id=33962042</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Why hasn’t technology disrupted higher education already?
 - [https://www.slowboring.com/p/why-hasnt-technology-disrupted-higher](https://www.slowboring.com/p/why-hasnt-technology-disrupted-higher)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 23:13:51+00:00

<p>Article URL: <a href="https://www.slowboring.com/p/why-hasnt-technology-disrupted-higher">https://www.slowboring.com/p/why-hasnt-technology-disrupted-higher</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33961847">https://news.ycombinator.com/item?id=33961847</a></p>
<p>Points: 35</p>
<p># Comments: 17</p>

## The scourge of job title inflation
 - [https://www.economist.com/business/2022/12/08/the-scourge-of-job-title-inflation](https://www.economist.com/business/2022/12/08/the-scourge-of-job-title-inflation)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 23:07:12+00:00

<p>Article URL: <a href="https://www.economist.com/business/2022/12/08/the-scourge-of-job-title-inflation">https://www.economist.com/business/2022/12/08/the-scourge-of-job-title-inflation</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33961785">https://news.ycombinator.com/item?id=33961785</a></p>
<p>Points: 21</p>
<p># Comments: 25</p>

## The obvious answer to homelessness and why everyone's ignoring it
 - [https://www.theatlantic.com/magazine/archive/2023/01/homelessness-affordable-housing-crisis-democrats-causes/672224/](https://www.theatlantic.com/magazine/archive/2023/01/homelessness-affordable-housing-crisis-democrats-causes/672224/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 22:44:48+00:00

<p>Article URL: <a href="https://www.theatlantic.com/magazine/archive/2023/01/homelessness-affordable-housing-crisis-democrats-causes/672224/">https://www.theatlantic.com/magazine/archive/2023/01/homelessness-affordable-housing-crisis-democrats-causes/672224/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33961543">https://news.ycombinator.com/item?id=33961543</a></p>
<p>Points: 12</p>
<p># Comments: 2</p>

## Pluralsight lays off 400 Employees – 20% Workforce
 - [https://layoffstracker.com/pluralsight-lays-off-400-employees-20-workforce/](https://layoffstracker.com/pluralsight-lays-off-400-employees-20-workforce/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 22:33:44+00:00

<p>Article URL: <a href="https://layoffstracker.com/pluralsight-lays-off-400-employees-20-workforce/">https://layoffstracker.com/pluralsight-lays-off-400-employees-20-workforce/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33961410">https://news.ycombinator.com/item?id=33961410</a></p>
<p>Points: 33</p>
<p># Comments: 14</p>

## Perhaps It Is a Bad Thing That the Leading AI Companies Cannot Control Their AIs
 - [https://astralcodexten.substack.com/p/perhaps-it-is-a-bad-thing-that-the](https://astralcodexten.substack.com/p/perhaps-it-is-a-bad-thing-that-the)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 22:30:52+00:00

<p>Article URL: <a href="https://astralcodexten.substack.com/p/perhaps-it-is-a-bad-thing-that-the">https://astralcodexten.substack.com/p/perhaps-it-is-a-bad-thing-that-the</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33961373">https://news.ycombinator.com/item?id=33961373</a></p>
<p>Points: 36</p>
<p># Comments: 4</p>

## A Canaanite’s wish to eradicate lice on an inscribed ivory comb from Lachish [pdf]
 - [https://jjar.huji.ac.il/sites/default/files/jjar/files/jjar2_art4_lachish_p76-119_2022-10-12_01.pdf](https://jjar.huji.ac.il/sites/default/files/jjar/files/jjar2_art4_lachish_p76-119_2022-10-12_01.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 22:12:08+00:00

<p>Article URL: <a href="https://jjar.huji.ac.il/sites/default/files/jjar/files/jjar2_art4_lachish_p76-119_2022-10-12_01.pdf">https://jjar.huji.ac.il/sites/default/files/jjar/files/jjar2_art4_lachish_p76-119_2022-10-12_01.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33961168">https://news.ycombinator.com/item?id=33961168</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Btrfs in Linux 6.2 brings Performance Improvements, better RAID 5/6 Reliability
 - [https://www.phoronix.com/news/Linux-6.2-Btrfs-EXT4](https://www.phoronix.com/news/Linux-6.2-Btrfs-EXT4)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 22:06:25+00:00

<p>Article URL: <a href="https://www.phoronix.com/news/Linux-6.2-Btrfs-EXT4">https://www.phoronix.com/news/Linux-6.2-Btrfs-EXT4</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33961106">https://news.ycombinator.com/item?id=33961106</a></p>
<p>Points: 20</p>
<p># Comments: 2</p>

## Research Links Aspartame to Anxiety
 - [https://news.fsu.edu/news/university-news/2022/12/08/fsu-research-links-common-sweetener-with-anxiety/](https://news.fsu.edu/news/university-news/2022/12/08/fsu-research-links-common-sweetener-with-anxiety/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 20:57:21+00:00

<p>Article URL: <a href="https://news.fsu.edu/news/university-news/2022/12/08/fsu-research-links-common-sweetener-with-anxiety/">https://news.fsu.edu/news/university-news/2022/12/08/fsu-research-links-common-sweetener-with-anxiety/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33960158">https://news.ycombinator.com/item?id=33960158</a></p>
<p>Points: 25</p>
<p># Comments: 14</p>

## ‘Gas Station Heroin’ Is Causing Intense Withdrawals. It’s Legal in Most States
 - [https://www.vice.com/en/article/88q3va/tianeptine-gas-station-heroin-legal-in-most-states](https://www.vice.com/en/article/88q3va/tianeptine-gas-station-heroin-legal-in-most-states)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 20:56:25+00:00

<p>Article URL: <a href="https://www.vice.com/en/article/88q3va/tianeptine-gas-station-heroin-legal-in-most-states">https://www.vice.com/en/article/88q3va/tianeptine-gas-station-heroin-legal-in-most-states</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33960148">https://news.ycombinator.com/item?id=33960148</a></p>
<p>Points: 30</p>
<p># Comments: 22</p>

## A Recession Looms over the Posh World of Influencers
 - [https://www.wired.com/story/recession-influencer-backlash/](https://www.wired.com/story/recession-influencer-backlash/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 20:47:16+00:00

<p>Article URL: <a href="https://www.wired.com/story/recession-influencer-backlash/">https://www.wired.com/story/recession-influencer-backlash/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33960046">https://news.ycombinator.com/item?id=33960046</a></p>
<p>Points: 15</p>
<p># Comments: 7</p>

## The Terminal for the 21st Century
 - [https://www.warp.dev](https://www.warp.dev)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 20:44:28+00:00

<p>Article URL: <a href="https://www.warp.dev">https://www.warp.dev</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33960005">https://news.ycombinator.com/item?id=33960005</a></p>
<p>Points: 8</p>
<p># Comments: 20</p>

## Links mentioning Mastodon flagged as sensitive on Twitter
 - [https://mastodon.online/@joshuatopolsky/109501217476449536](https://mastodon.online/@joshuatopolsky/109501217476449536)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 20:37:33+00:00

<p>Article URL: <a href="https://mastodon.online/@joshuatopolsky/109501217476449536">https://mastodon.online/@joshuatopolsky/109501217476449536</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33959920">https://news.ycombinator.com/item?id=33959920</a></p>
<p>Points: 73</p>
<p># Comments: 19</p>

## More phony copyright claims for YouTube creators
 - [https://larryjordan.com/articles/for-youtube-ads-matter-more-than-video-quality-or-communication/](https://larryjordan.com/articles/for-youtube-ads-matter-more-than-video-quality-or-communication/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 20:18:18+00:00

<p>Article URL: <a href="https://larryjordan.com/articles/for-youtube-ads-matter-more-than-video-quality-or-communication/">https://larryjordan.com/articles/for-youtube-ads-matter-more-than-video-quality-or-communication/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33959664">https://news.ycombinator.com/item?id=33959664</a></p>
<p>Points: 33</p>
<p># Comments: 17</p>

## Data Visualization Framework for React, Angular, Svelte, TypeScript, JavaScript
 - [https://unovis.dev/](https://unovis.dev/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 20:13:27+00:00

<p>Article URL: <a href="https://unovis.dev/">https://unovis.dev/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33959591">https://news.ycombinator.com/item?id=33959591</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Geoff Dyer: The essayist on not having a career James Surowiecki
 - [https://yalereview.org/article/surowiecki-geoff-dyer](https://yalereview.org/article/surowiecki-geoff-dyer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 19:28:32+00:00

<p>Article URL: <a href="https://yalereview.org/article/surowiecki-geoff-dyer">https://yalereview.org/article/surowiecki-geoff-dyer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33959016">https://news.ycombinator.com/item?id=33959016</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## 1955 Union Pacific EMD E9 – The Last of the Classic Diesel Streamliners (2012)
 - [https://www.curbsideclassic.com/trackside-classic/trackside-classic-1955-union-pacific-emd-e9-the-last-of-the-classic-diesel-streamliners/](https://www.curbsideclassic.com/trackside-classic/trackside-classic-1955-union-pacific-emd-e9-the-last-of-the-classic-diesel-streamliners/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 19:02:19+00:00

<p>Article URL: <a href="https://www.curbsideclassic.com/trackside-classic/trackside-classic-1955-union-pacific-emd-e9-the-last-of-the-classic-diesel-streamliners/">https://www.curbsideclassic.com/trackside-classic/trackside-classic-1955-union-pacific-emd-e9-the-last-of-the-classic-diesel-streamliners/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33958696">https://news.ycombinator.com/item?id=33958696</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Controlled fusion net energy gain
 - [https://www.sciencemediacentre.org/expert-reaction-to-fusion-announcement-from-the-lawrence-livermore-national-laboratory/](https://www.sciencemediacentre.org/expert-reaction-to-fusion-announcement-from-the-lawrence-livermore-national-laboratory/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 19:01:11+00:00

<p>Article URL: <a href="https://www.sciencemediacentre.org/expert-reaction-to-fusion-announcement-from-the-lawrence-livermore-national-laboratory/">https://www.sciencemediacentre.org/expert-reaction-to-fusion-announcement-from-the-lawrence-livermore-national-laboratory/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33958678">https://news.ycombinator.com/item?id=33958678</a></p>
<p>Points: 31</p>
<p># Comments: 2</p>

## The silent struggles of workers with ADHD
 - [https://www.bbc.com/worklife/article/20221209-the-silent-struggles-of-workers-with-adhd](https://www.bbc.com/worklife/article/20221209-the-silent-struggles-of-workers-with-adhd)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 18:32:29+00:00

<p>Article URL: <a href="https://www.bbc.com/worklife/article/20221209-the-silent-struggles-of-workers-with-adhd">https://www.bbc.com/worklife/article/20221209-the-silent-struggles-of-workers-with-adhd</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33958290">https://news.ycombinator.com/item?id=33958290</a></p>
<p>Points: 34</p>
<p># Comments: 12</p>

## $71 Coat Makes Wearers Invisible to AI Security Cameras
 - [https://petapixel.com/2022/12/12/71-coat-makes-wearers-invisible-to-ai-security-cameras/](https://petapixel.com/2022/12/12/71-coat-makes-wearers-invisible-to-ai-security-cameras/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 18:04:40+00:00

<p>Article URL: <a href="https://petapixel.com/2022/12/12/71-coat-makes-wearers-invisible-to-ai-security-cameras/">https://petapixel.com/2022/12/12/71-coat-makes-wearers-invisible-to-ai-security-cameras/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33957900">https://news.ycombinator.com/item?id=33957900</a></p>
<p>Points: 49</p>
<p># Comments: 26</p>

## SBF scheduled to testify tomorrow at US House hearing on FTX collapse
 - [https://techcrunch.com/2022/12/12/sbf-scheduled-to-testify-tomorrow-at-us-house-hearing-on-ftx-collapse/](https://techcrunch.com/2022/12/12/sbf-scheduled-to-testify-tomorrow-at-us-house-hearing-on-ftx-collapse/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 17:35:14+00:00

<p>Article URL: <a href="https://techcrunch.com/2022/12/12/sbf-scheduled-to-testify-tomorrow-at-us-house-hearing-on-ftx-collapse/">https://techcrunch.com/2022/12/12/sbf-scheduled-to-testify-tomorrow-at-us-house-hearing-on-ftx-collapse/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33957542">https://news.ycombinator.com/item?id=33957542</a></p>
<p>Points: 23</p>
<p># Comments: 7</p>

## The school that grants your PhD thinks it’s too good to hire you
 - [https://bigthink.com/thinking/school-phd-too-good-for-you-academic-arrogance/](https://bigthink.com/thinking/school-phd-too-good-for-you-academic-arrogance/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 17:31:20+00:00

<p>Article URL: <a href="https://bigthink.com/thinking/school-phd-too-good-for-you-academic-arrogance/">https://bigthink.com/thinking/school-phd-too-good-for-you-academic-arrogance/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33957488">https://news.ycombinator.com/item?id=33957488</a></p>
<p>Points: 32</p>
<p># Comments: 35</p>

## Substack is now powered by Ghost
 - [https://twitter.com/johnonolan/status/1602330377812643850](https://twitter.com/johnonolan/status/1602330377812643850)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 16:12:46+00:00

<p>Article URL: <a href="https://twitter.com/johnonolan/status/1602330377812643850">https://twitter.com/johnonolan/status/1602330377812643850</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33956300">https://news.ycombinator.com/item?id=33956300</a></p>
<p>Points: 32</p>
<p># Comments: 5</p>

## Globalization Is Dead and No One Is Listening
 - [https://interconnected.blog/globalization-is-dead-and-no-one-is-listening/](https://interconnected.blog/globalization-is-dead-and-no-one-is-listening/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 15:52:04+00:00

<p>Article URL: <a href="https://interconnected.blog/globalization-is-dead-and-no-one-is-listening/">https://interconnected.blog/globalization-is-dead-and-no-one-is-listening/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955985">https://news.ycombinator.com/item?id=33955985</a></p>
<p>Points: 64</p>
<p># Comments: 41</p>

## Database Drivers: Naughty or Nice?
 - [https://www.prequel.co/blog/database-drivers-naughty-or-nice](https://www.prequel.co/blog/database-drivers-naughty-or-nice)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 15:51:57+00:00

<p>Article URL: <a href="https://www.prequel.co/blog/database-drivers-naughty-or-nice">https://www.prequel.co/blog/database-drivers-naughty-or-nice</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955983">https://news.ycombinator.com/item?id=33955983</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Goodbye Spotify
 - [https://om.co/2022/12/01/goodbye-spotify/](https://om.co/2022/12/01/goodbye-spotify/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 15:48:11+00:00

<p>Article URL: <a href="https://om.co/2022/12/01/goodbye-spotify/">https://om.co/2022/12/01/goodbye-spotify/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955929">https://news.ycombinator.com/item?id=33955929</a></p>
<p>Points: 37</p>
<p># Comments: 37</p>

## THC and CBD improve wound healing, may be valuable as skin rejuvenators, study
 - [https://www.mdpi.com/2073-4409/11/23/3939](https://www.mdpi.com/2073-4409/11/23/3939)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 15:40:24+00:00

<p>Article URL: <a href="https://www.mdpi.com/2073-4409/11/23/3939">https://www.mdpi.com/2073-4409/11/23/3939</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955820">https://news.ycombinator.com/item?id=33955820</a></p>
<p>Points: 61</p>
<p># Comments: 72</p>

## The next step in ecommerce? Replatform with APIs and micro front ends
 - [https://stackoverflow.blog/2022/12/12/the-next-step-in-ecommerce-replatform-with-apis-and-micro-frontends/](https://stackoverflow.blog/2022/12/12/the-next-step-in-ecommerce-replatform-with-apis-and-micro-frontends/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 15:33:24+00:00

<p>Article URL: <a href="https://stackoverflow.blog/2022/12/12/the-next-step-in-ecommerce-replatform-with-apis-and-micro-frontends/">https://stackoverflow.blog/2022/12/12/the-next-step-in-ecommerce-replatform-with-apis-and-micro-frontends/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955713">https://news.ycombinator.com/item?id=33955713</a></p>
<p>Points: 15</p>
<p># Comments: 7</p>

## Writing at Work
 - [https://lcamtuf.substack.com/p/writing-at-work](https://lcamtuf.substack.com/p/writing-at-work)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 15:26:55+00:00

<p>Article URL: <a href="https://lcamtuf.substack.com/p/writing-at-work">https://lcamtuf.substack.com/p/writing-at-work</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955630">https://news.ycombinator.com/item?id=33955630</a></p>
<p>Points: 23</p>
<p># Comments: 4</p>

## DARPA: Neural Evidence Aggregation Tool
 - [https://www.darpa.mil/news-events/2022-03-02](https://www.darpa.mil/news-events/2022-03-02)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 15:22:28+00:00

<p>Article URL: <a href="https://www.darpa.mil/news-events/2022-03-02">https://www.darpa.mil/news-events/2022-03-02</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955563">https://news.ycombinator.com/item?id=33955563</a></p>
<p>Points: 14</p>
<p># Comments: 5</p>

## Sildenafil as a candidate drug for Alzheimer’s disease
 - [https://www.nature.com/articles/s43587-021-00138-z](https://www.nature.com/articles/s43587-021-00138-z)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 14:56:41+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s43587-021-00138-z">https://www.nature.com/articles/s43587-021-00138-z</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955270">https://news.ycombinator.com/item?id=33955270</a></p>
<p>Points: 22</p>
<p># Comments: 4</p>

## The Zig programming language has been ported to SerenityOS
 - [https://twitter.com/awesomekling/status/1602315728320880640](https://twitter.com/awesomekling/status/1602315728320880640)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 14:55:48+00:00

<p>Article URL: <a href="https://twitter.com/awesomekling/status/1602315728320880640">https://twitter.com/awesomekling/status/1602315728320880640</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955257">https://news.ycombinator.com/item?id=33955257</a></p>
<p>Points: 22</p>
<p># Comments: 1</p>

## Ask a DNA Expert: What Would It Take to Bring Back the Dinosaurs?
 - [https://thewalrus.ca/bring-back-dinosaurs/](https://thewalrus.ca/bring-back-dinosaurs/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 14:40:00+00:00

<p>Article URL: <a href="https://thewalrus.ca/bring-back-dinosaurs/">https://thewalrus.ca/bring-back-dinosaurs/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955066">https://news.ycombinator.com/item?id=33955066</a></p>
<p>Points: 18</p>
<p># Comments: 12</p>

## U.S. to announce major breakthrough in zero-carbon nuclear fusion energy
 - [https://www.cbsnews.com/news/nuclear-fusion-energy-breakthrough-us-expected-announcement-zero-carbon-power/](https://www.cbsnews.com/news/nuclear-fusion-energy-breakthrough-us-expected-announcement-zero-carbon-power/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 14:36:53+00:00

<p>Article URL: <a href="https://www.cbsnews.com/news/nuclear-fusion-energy-breakthrough-us-expected-announcement-zero-carbon-power/">https://www.cbsnews.com/news/nuclear-fusion-energy-breakthrough-us-expected-announcement-zero-carbon-power/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955031">https://news.ycombinator.com/item?id=33955031</a></p>
<p>Points: 55</p>
<p># Comments: 17</p>

## Medieval ship found in Norway's biggest lake
 - [https://lite.cnn.com/en/article/h_f7e68a3a7d704b1a13bcdea82f4454ad](https://lite.cnn.com/en/article/h_f7e68a3a7d704b1a13bcdea82f4454ad)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 14:36:10+00:00

<p>Article URL: <a href="https://lite.cnn.com/en/article/h_f7e68a3a7d704b1a13bcdea82f4454ad">https://lite.cnn.com/en/article/h_f7e68a3a7d704b1a13bcdea82f4454ad</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955020">https://news.ycombinator.com/item?id=33955020</a></p>
<p>Points: 15</p>
<p># Comments: 2</p>

## Medieval ship found in Norway's biggest lake
 - [https://sciencenorway.no/archaeoloy-medieval-history-ships/shipwreck-discovered-at-the-bottom-of-norways-largest-lake-possibly-700-years-old/2110769](https://sciencenorway.no/archaeoloy-medieval-history-ships/shipwreck-discovered-at-the-bottom-of-norways-largest-lake-possibly-700-years-old/2110769)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 14:36:10+00:00

<p>Article URL: <a href="https://sciencenorway.no/archaeoloy-medieval-history-ships/shipwreck-discovered-at-the-bottom-of-norways-largest-lake-possibly-700-years-old/2110769">https://sciencenorway.no/archaeoloy-medieval-history-ships/shipwreck-discovered-at-the-bottom-of-norways-largest-lake-possibly-700-years-old/2110769</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33955020">https://news.ycombinator.com/item?id=33955020</a></p>
<p>Points: 58</p>
<p># Comments: 22</p>

## OCaml Canvas
 - [https://ocamlpro.github.io/ocaml-canvas/](https://ocamlpro.github.io/ocaml-canvas/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 14:30:38+00:00

<p>Article URL: <a href="https://ocamlpro.github.io/ocaml-canvas/">https://ocamlpro.github.io/ocaml-canvas/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954958">https://news.ycombinator.com/item?id=33954958</a></p>
<p>Points: 45</p>
<p># Comments: 1</p>

## Show HN: Embed a snow effect on your website
 - [https://embed.im/snow/](https://embed.im/snow/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 14:27:10+00:00

<p>Embed a snow effect on your website with one line of code (~1.3kB), and add some Christmas magic to your websites. A quick weekend project :)</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954925">https://news.ycombinator.com/item?id=33954925</a></p>
<p>Points: 28</p>
<p># Comments: 23</p>

## Ask HN: What's your proudest hack?
 - [https://news.ycombinator.com/item?id=33954778](https://news.ycombinator.com/item?id=33954778)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 14:13:45+00:00

<p>I saw this question being asked on here years ago with few but interesting answers. I'd imagine that a lot of you still have some pretty interesting stories to tell about some crafty workarounds.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954778">https://news.ycombinator.com/item?id=33954778</a></p>
<p>Points: 60</p>
<p># Comments: 98</p>

## Forward-Forward Algorithm, an Alternative to Backpropagation for Neural Networks
 - [https://syncedreview.com/2022/12/08/geoffrey-hintons-forward-forward-algorithm-charts-a-new-path-for-neural-networks/](https://syncedreview.com/2022/12/08/geoffrey-hintons-forward-forward-algorithm-charts-a-new-path-for-neural-networks/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 14:05:26+00:00

<p>Article URL: <a href="https://syncedreview.com/2022/12/08/geoffrey-hintons-forward-forward-algorithm-charts-a-new-path-for-neural-networks/">https://syncedreview.com/2022/12/08/geoffrey-hintons-forward-forward-algorithm-charts-a-new-path-for-neural-networks/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954702">https://news.ycombinator.com/item?id=33954702</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## The Hype Around Esports Is Fading as Investors and Sponsors Dry Up
 - [https://www.bloomberg.com/news/articles/2022-12-08/the-hype-around-esports-is-fading-as-investors-and-sponsors-flee](https://www.bloomberg.com/news/articles/2022-12-08/the-hype-around-esports-is-fading-as-investors-and-sponsors-flee)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 14:00:18+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2022-12-08/the-hype-around-esports-is-fading-as-investors-and-sponsors-flee">https://www.bloomberg.com/news/articles/2022-12-08/the-hype-around-esports-is-fading-as-investors-and-sponsors-flee</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954660">https://news.ycombinator.com/item?id=33954660</a></p>
<p>Points: 26</p>
<p># Comments: 27</p>

## “A Solution in Search of a Problem” Is a Low-Rates Phenomenon
 - [https://www.thediff.co/p/a-solution-in-search-of-a-problem](https://www.thediff.co/p/a-solution-in-search-of-a-problem)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 13:57:04+00:00

<p>Article URL: <a href="https://www.thediff.co/p/a-solution-in-search-of-a-problem">https://www.thediff.co/p/a-solution-in-search-of-a-problem</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954636">https://news.ycombinator.com/item?id=33954636</a></p>
<p>Points: 13</p>
<p># Comments: 4</p>

## The Complicated Man Who Made 'Rudolph'
 - [https://animationobsessive.substack.com/p/the-complicated-man-who-made-rudolph](https://animationobsessive.substack.com/p/the-complicated-man-who-made-rudolph)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 13:52:52+00:00

<p>Article URL: <a href="https://animationobsessive.substack.com/p/the-complicated-man-who-made-rudolph">https://animationobsessive.substack.com/p/the-complicated-man-who-made-rudolph</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954595">https://news.ycombinator.com/item?id=33954595</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## Ask HN: (Android) Did you know your carrier can remotely turn settings on?
 - [https://news.ycombinator.com/item?id=33954547](https://news.ycombinator.com/item?id=33954547)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 13:47:16+00:00

<p>My wife is currently in Germany and had cell broadcast warnings disabled on her Android 11 device. Apparently, the local carrier she uses turns them back on remotely. She gets notified of this. "Settings changed by carrier."<p>(1) Were you aware that carriers can remotely override your settings like this?
(2) Any strategies to keep something like this from happening besides rooting the device?
(3) How do you feel about this type of remote control by a third party?<p>I must say I strongly dislike losing control over my own device. It feels dystopian to me.<p>I also couldn't find any mention of this particular power of carriers apart from one lonely Reddit post about someone trying to turn off Amber alerts [1].<p>----------------
EDIT: Additional info for clarity:<p>The settings I am referring to are under "Apps & notifications"/"Wireless emergency alerts". They are about controlling whether to and which alerts one wants to receive on their phone.<p>It's an unlocked Android One device. The carrier seems to be able to remotely change these settings (see the referenced Reddit post as well), which I would never expect. It seems to be because of the SIM the phone uses and the network it connects to. No user-controlled software change like updates.<p>----------------<p>[1] https://old.reddit.com/r/GooglePixel/comments/zebvs4/settings_changed_by_carrier/</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954547">https://news.ycombinator.com/item?id=33954547</a></p>
<p>Points: 15</p>
<p># Comments: 15</p>

## SK Hynix Reveals DDR5 MCR DIMM, Up to DDR5-8000 Speeds for HPC
 - [https://www.anandtech.com/show/18683/sk-hynix-reveals-mcr-dimm-up-to-8gbps-bandwidth-for-hpc](https://www.anandtech.com/show/18683/sk-hynix-reveals-mcr-dimm-up-to-8gbps-bandwidth-for-hpc)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 13:20:37+00:00

<p>Article URL: <a href="https://www.anandtech.com/show/18683/sk-hynix-reveals-mcr-dimm-up-to-8gbps-bandwidth-for-hpc">https://www.anandtech.com/show/18683/sk-hynix-reveals-mcr-dimm-up-to-8gbps-bandwidth-for-hpc</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954352">https://news.ycombinator.com/item?id=33954352</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Being startup employee number one
 - [https://www.getlago.com/blog/being-startup-employee-number-one](https://www.getlago.com/blog/being-startup-employee-number-one)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 13:15:28+00:00

<p>Article URL: <a href="https://www.getlago.com/blog/being-startup-employee-number-one">https://www.getlago.com/blog/being-startup-employee-number-one</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954309">https://news.ycombinator.com/item?id=33954309</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## U.S. Justice Department is split over charging Binance as crypto world falters
 - [https://www.reuters.com/markets/us/us-justice-dept-is-split-over-charging-binance-crypto-world-falters-sources-2022-12-12/](https://www.reuters.com/markets/us/us-justice-dept-is-split-over-charging-binance-crypto-world-falters-sources-2022-12-12/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 13:04:25+00:00

<p>Article URL: <a href="https://www.reuters.com/markets/us/us-justice-dept-is-split-over-charging-binance-crypto-world-falters-sources-2022-12-12/">https://www.reuters.com/markets/us/us-justice-dept-is-split-over-charging-binance-crypto-world-falters-sources-2022-12-12/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954224">https://news.ycombinator.com/item?id=33954224</a></p>
<p>Points: 51</p>
<p># Comments: 23</p>

## What if you delete the “Program Files” folder in Windows? [video]
 - [https://www.youtube.com/watch?v=BVIN_PJu2rs](https://www.youtube.com/watch?v=BVIN_PJu2rs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 12:58:12+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=BVIN_PJu2rs">https://www.youtube.com/watch?v=BVIN_PJu2rs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954176">https://news.ycombinator.com/item?id=33954176</a></p>
<p>Points: 14</p>
<p># Comments: 4</p>

## Show HN: Train your own image generator (Stable Diffusion) for free
 - [https://88stacks.com/](https://88stacks.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 12:52:32+00:00

<p>I've had a blast playing with stable diffusion and I see all the potential it will bring to us. I released a service for training your model, just upload 20-30 images and you can have a model of someone or some object doing anything. You can train one model for free a month in a slower queue or you can train many models on a fast queue and with other features for a fee.  Here is an example of using it for show product placement: <a href="https://app.88stacks.com/image/O6kReClOvrz7" rel="nofollow">https://app.88stacks.com/image/O6kReClOvrz7</a> and here is an example of using it for people: <a href="https://app.88stacks.com/image/nOpdvCwx6kb7" rel="nofollow">https://app.88stacks.com/image/nOpdvCwx6kb7</a>
and an example for using it for styles: <a href="https://app.88stacks.com/image/zyjw6CmEgk2d" rel="nofollow">https://app.88stacks.com/image/zyjw6CmEgk2d</a>
The UI is rough, but I would love feedback on how to improve it for you. <a href="https://88stacks.com" rel="nofollow">https://88stacks.com</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954129">https://news.ycombinator.com/item?id=33954129</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Who Invented the Thumb Drive?
 - [https://spectrum.ieee.org/thumb-drive](https://spectrum.ieee.org/thumb-drive)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 12:36:02+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/thumb-drive">https://spectrum.ieee.org/thumb-drive</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33954020">https://news.ycombinator.com/item?id=33954020</a></p>
<p>Points: 10</p>
<p># Comments: 5</p>

## Laion-5B: A New Era of Open Large-Scale Multi-Modal Datasets
 - [https://laion.ai/blog/laion-5b/](https://laion.ai/blog/laion-5b/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 12:18:46+00:00

<p>Article URL: <a href="https://laion.ai/blog/laion-5b/">https://laion.ai/blog/laion-5b/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33953891">https://news.ycombinator.com/item?id=33953891</a></p>
<p>Points: 25</p>
<p># Comments: 1</p>

## How Type Influences Readability
 - [https://fonts.google.com/knowledge/readability_and_accessibility/how_type_influences_readability](https://fonts.google.com/knowledge/readability_and_accessibility/how_type_influences_readability)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 11:47:37+00:00

<p>Article URL: <a href="https://fonts.google.com/knowledge/readability_and_accessibility/how_type_influences_readability">https://fonts.google.com/knowledge/readability_and_accessibility/how_type_influences_readability</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33953658">https://news.ycombinator.com/item?id=33953658</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## A list of advanced math tricks by Terence Tao
 - [https://mathstodon.xyz/@tao/109451634735720062](https://mathstodon.xyz/@tao/109451634735720062)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 09:03:32+00:00

<p>Article URL: <a href="https://mathstodon.xyz/@tao/109451634735720062">https://mathstodon.xyz/@tao/109451634735720062</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33952515">https://news.ycombinator.com/item?id=33952515</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## US Teases 'Major' Science News Amid Fusion Energy Reports
 - [https://www.voanews.com/a/us-teases-major-science-news-amid-fusion-energy-reports/6872244.html](https://www.voanews.com/a/us-teases-major-science-news-amid-fusion-energy-reports/6872244.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 08:19:14+00:00

<p>Article URL: <a href="https://www.voanews.com/a/us-teases-major-science-news-amid-fusion-energy-reports/6872244.html">https://www.voanews.com/a/us-teases-major-science-news-amid-fusion-energy-reports/6872244.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33952234">https://news.ycombinator.com/item?id=33952234</a></p>
<p>Points: 21</p>
<p># Comments: 16</p>

## Ask HN: Someone is proxy-mirroring my website, can I do anything?
 - [https://news.ycombinator.com/item?id=33952114](https://news.ycombinator.com/item?id=33952114)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 08:00:27+00:00

<p>Hi Hacker News community,<p>I'm trying to deal with a very interesting (to me) case. Someone is proxy-mirroring all content of my website under a different domain name.<p>- Original: <a href="https://www.saashub.com" rel="nofollow">https://www.saashub.com</a><p>- Abuser/Proxy-mirror: <a href="https://sukuns.us.to" rel="nofollow">https://sukuns.us.to</a><p>My ideas of resolution:<p>1) Block them by IP - That doesn't work as they are rotating the IP from which the request is coming.<p>2) Block them by User Agent - They are duplicating the user-agent of the person making the request to sukuns.us.to<p>3) Add some JavaScript to redirect to the original domain-name - They are stripping all JS.<p>4) Use absolute URLs everywhere - they are rewriting everything www.saashub.com to their domain name.<p>i.e. I'm out of ideas. Any suggestions would be highly appreciated.<p>p.s. what is more, Bing is indexing all of SaaSHub's content under sukuns.us.to ¯\_(ツ)_/¯. I've reported a copyright infringement, but I have a feeling that it could take ages to get resolved.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33952114">https://news.ycombinator.com/item?id=33952114</a></p>
<p>Points: 42</p>
<p># Comments: 42</p>

## Ask HN: Is the weaponisation of ChatGPT now inevitable?
 - [https://news.ycombinator.com/item?id=33952087](https://news.ycombinator.com/item?id=33952087)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 07:56:24+00:00

<p>I'm not sure whether its possible to obtain this model from OpenAI or how hard it may be for unscrupulous actors to train their own on the same principles.<p>On the assumption that it is entirely possible, wouldn't the natural consequence -- amongst others -- be weaponisation for unscrupulous purposes? Won't it result in 1000s of blogs mushrooming over night from purported bots-come-experts with some kind of engineered slant? Whole "online communities" for the unsuspecting to join initially made up of nothing but bots "talking" to each other, bots written journal papers / editorials, etc, and so on.<p>What comes next?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33952087">https://news.ycombinator.com/item?id=33952087</a></p>
<p>Points: 31</p>
<p># Comments: 24</p>

## Retro-Printer Module
 - [https://www.retroprinter.com/](https://www.retroprinter.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 07:18:50+00:00

<p>Article URL: <a href="https://www.retroprinter.com/">https://www.retroprinter.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33951870">https://news.ycombinator.com/item?id=33951870</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Linux Desktop Environments System Usage (Gnome, KDE, XFCE, LXQT, Cinnamon, Mate)
 - [https://itvision.altervista.org/linux-desktop-environments-system-usage.html](https://itvision.altervista.org/linux-desktop-environments-system-usage.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 06:50:09+00:00

<p>Article URL: <a href="https://itvision.altervista.org/linux-desktop-environments-system-usage.html">https://itvision.altervista.org/linux-desktop-environments-system-usage.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33951719">https://news.ycombinator.com/item?id=33951719</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Academic Twitter, Just Leave
 - [https://jrhawley.ca/2022/12/10/just-leave](https://jrhawley.ca/2022/12/10/just-leave)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 04:18:42+00:00

<p>Article URL: <a href="https://jrhawley.ca/2022/12/10/just-leave">https://jrhawley.ca/2022/12/10/just-leave</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33950814">https://news.ycombinator.com/item?id=33950814</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Discovering latent knowledge in language models without supervision
 - [https://arxiv.org/abs/2212.03827](https://arxiv.org/abs/2212.03827)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 03:30:51+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2212.03827">https://arxiv.org/abs/2212.03827</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33950542">https://news.ycombinator.com/item?id=33950542</a></p>
<p>Points: 21</p>
<p># Comments: 2</p>

## Splashdown NASA’s Orion Returns to Earth After Historic Moon Mission
 - [https://www.nasa.gov/press-release/splashdown-nasa-s-orion-returns-to-earth-after-historic-moon-mission/](https://www.nasa.gov/press-release/splashdown-nasa-s-orion-returns-to-earth-after-historic-moon-mission/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 03:27:23+00:00

<p>Article URL: <a href="https://www.nasa.gov/press-release/splashdown-nasa-s-orion-returns-to-earth-after-historic-moon-mission/">https://www.nasa.gov/press-release/splashdown-nasa-s-orion-returns-to-earth-after-historic-moon-mission/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33950523">https://news.ycombinator.com/item?id=33950523</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Tipless Marine Propeller Improves Mileage 50%, Reduces Noise (2020)
 - [https://www.mby.com/gear/sharrow-mx-1-tipless-propeller-110120](https://www.mby.com/gear/sharrow-mx-1-tipless-propeller-110120)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 01:47:13+00:00

<p>Article URL: <a href="https://www.mby.com/gear/sharrow-mx-1-tipless-propeller-110120">https://www.mby.com/gear/sharrow-mx-1-tipless-propeller-110120</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33949895">https://news.ycombinator.com/item?id=33949895</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## 100G-LR4 optic cable teardown
 - [https://social.afront.org/@kwf/109492743645650432](https://social.afront.org/@kwf/109492743645650432)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 01:45:33+00:00

<p>Article URL: <a href="https://social.afront.org/@kwf/109492743645650432">https://social.afront.org/@kwf/109492743645650432</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33949885">https://news.ycombinator.com/item?id=33949885</a></p>
<p>Points: 16</p>
<p># Comments: 4</p>

## No one reads the terms of service. Lawmakers want to fix that with 'TLDR' bill
 - [https://www.washingtonpost.com/politics/2022/01/13/no-one-reads-terms-service-lawmakers-want-fix-that-with-new-tldr-bill/](https://www.washingtonpost.com/politics/2022/01/13/no-one-reads-terms-service-lawmakers-want-fix-that-with-new-tldr-bill/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 01:17:27+00:00

<p>Article URL: <a href="https://www.washingtonpost.com/politics/2022/01/13/no-one-reads-terms-service-lawmakers-want-fix-that-with-new-tldr-bill/">https://www.washingtonpost.com/politics/2022/01/13/no-one-reads-terms-service-lawmakers-want-fix-that-with-new-tldr-bill/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33949680">https://news.ycombinator.com/item?id=33949680</a></p>
<p>Points: 16</p>
<p># Comments: 9</p>

## The 6.1 kernel is out
 - [https://lwn.net/Articles/917504/](https://lwn.net/Articles/917504/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 01:09:26+00:00

<p>Article URL: <a href="https://lwn.net/Articles/917504/">https://lwn.net/Articles/917504/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33949611">https://news.ycombinator.com/item?id=33949611</a></p>
<p>Points: 24</p>
<p># Comments: 2</p>

## Are you a nice to have or a must have?
 - [https://www.yannickoswald.com/post/are-you-a-nice-to-have-or-must-have](https://www.yannickoswald.com/post/are-you-a-nice-to-have-or-must-have)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 01:03:14+00:00

<p>Article URL: <a href="https://www.yannickoswald.com/post/are-you-a-nice-to-have-or-must-have">https://www.yannickoswald.com/post/are-you-a-nice-to-have-or-must-have</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33949568">https://news.ycombinator.com/item?id=33949568</a></p>
<p>Points: 7</p>
<p># Comments: 4</p>

## Binance Is Trying to Calm Investors, but Its Finances Remain a Mystery
 - [https://www.wsj.com/articles/binance-is-trying-to-calm-investors-but-its-finances-remain-a-mystery-11670679351](https://www.wsj.com/articles/binance-is-trying-to-calm-investors-but-its-finances-remain-a-mystery-11670679351)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 00:16:19+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/binance-is-trying-to-calm-investors-but-its-finances-remain-a-mystery-11670679351">https://www.wsj.com/articles/binance-is-trying-to-calm-investors-but-its-finances-remain-a-mystery-11670679351</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33949162">https://news.ycombinator.com/item?id=33949162</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Astronomers Just Confirmed the Most Ancient Galaxies Ever Observed
 - [https://singularityhub.com/2022/12/11/astronomers-just-confirmed-the-most-ancient-galaxies-ever-observed/](https://singularityhub.com/2022/12/11/astronomers-just-confirmed-the-most-ancient-galaxies-ever-observed/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-12 00:11:21+00:00

<p>Article URL: <a href="https://singularityhub.com/2022/12/11/astronomers-just-confirmed-the-most-ancient-galaxies-ever-observed/">https://singularityhub.com/2022/12/11/astronomers-just-confirmed-the-most-ancient-galaxies-ever-observed/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33949131">https://news.ycombinator.com/item?id=33949131</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>


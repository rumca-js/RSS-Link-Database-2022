# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Late Night Talking | @HarryStyles | funk cover ft. @SuzyJonesMusic & @TalWilkenfeld
 - [https://www.youtube.com/watch?v=VXpUFQ-bT9U](https://www.youtube.com/watch?v=VXpUFQ-bT9U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-12-12 00:00:00+00:00

Get tickets to see us on tour!  https://www.scarypocketsfunk.com

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Harry Styles' "Late Night Talking" by Scary Pockets & Suzy Jones.

MUSICIAN CREDITS
Lead vocal: Suzy Jones
Drums: Tamir Barzilay
Bass: Tal Wilkenfeld
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engineer: Travis Pavur
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Ricky Chavez
Camera Operators: Sammy Rothman, Alejandro Echevarria, Merlin Showalter
Editor: Adam Kritaberg

Recorded Live at Valentine Studios in Los Angeles, CA.

#ScaryPockets #Funk #HarryStyles #suzyjones


# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## These Algorithms Are Hunting for an EV Battery Mother Lode
 - [https://www.wired.com/story/these-mining-algorithms-are-hunting-for-an-ev-battery-mother-lode/](https://www.wired.com/story/these-mining-algorithms-are-hunting-for-an-ev-battery-mother-lode/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2022-12-12 13:00:00+00:00

AI trained on reams of geological data can indicate where to dig in search of metals crucial to electric cars and other green technology.

## Why Are People in the US Becoming Radicalized?
 - [https://www.wired.com/story/radicalization-extremism-us-uncertainty-social-media/](https://www.wired.com/story/radicalization-extremism-us-uncertainty-social-media/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2022-12-12 12:00:00+00:00

A confluence of factors is leading people in the nation to gravitate toward extremist views.


# Source:Brad Colbow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A, language:en-US

## Ranking the Best Drawing Tech of 2022
 - [https://www.youtube.com/watch?v=Tnrk3wmKniU](https://www.youtube.com/watch?v=Tnrk3wmKniU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A
 - date published: 2022-12-12 15:28:09+00:00

Check out http://www.squarespace.com for a free trial or go to  http://www.squarespace.com/bradcolbow to save 10% off your first purchase of a website or domain.
And thank you Squarespace for sponsoring this video.

00:00 Intro
00:35 Huion Inspiroy Giano
01:36 P-Pen Deco LW
02:23 iPad 10th Gen
03:51 Galaxy Book2 Pro 360
04:37 Wacom Cintiq Pro 27
06:01 XP-Pen Artist 16
06:27 XP-Pen Artist 10
07:21 iPad Pro
09:07 Squarespace
10:06 Surface Pro 9
11:09 Galaxy Tab S6 Lite
12:35 Huion Kamvas Pro 13.5 (2.5k)
13:24 iPad Air
15:00 Galaxy Tab S8 Ultra

Discounts for my Courses (US) https://bradcolbow.channel
Discounts for my Courses (worldwide) http://brad.site/learn/
Email Newsletter: http://brad.site/signup/

-----------------------------------------------------

Twitter: 
https://twitter.com/bradcolbow

Instagram:
https://www.instagram.com/bcolbow/

Drawing Tech Top 10 lists:
http://brad.site/

My Drawing and video gear: 
http://brad.site/mygear/


# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Gen. Mirosław Hermaszewski nie żyje. Polski kosmonauta zmarł w Warszawie w wieku 81 lat
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29253993,gen-miroslaw-hermaszewski-nie-zyje-polski-astronauta-zmarl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29253993,gen-miroslaw-hermaszewski-nie-zyje-polski-astronauta-zmarl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 19:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ad/e6/1b/z29254061M,Gen--Miroslaw-Hermaszewski.jpg" vspace="2" />Nie żyje gen. Mirosław Hermaszewski. Pierwszy i jedyny Polak, który odbył lot w kosmos, zmarł w Warszawie w wieku 81 lat. Informację o śmierci generała potwierdził europoseł Ryszard Czarnecki - prywatnie zięć Hermaszewskiego.

## Prokuratura zdecydowała ws. abp. Jędraszewskiego. Chodzi o sprawę księdza, który molestował pacjentkę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29253490,prokuratura-zdecydowala-ws-abp-jedraszewskiego-chodzi-sprawe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29253490,prokuratura-zdecydowala-ws-abp-jedraszewskiego-chodzi-sprawe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 16:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/aa/d6/1b/z29188522M,Abp-Marek-Jedraszewski.jpg" vspace="2" />Prokuratura Okręgowa w Krakowie uznała, że abp Marek Jędraszewski nie tuszował przestępstw seksualnych księdza - podaje Onet. Chodzi o sprawę duchownego, który miał molestować umierającą pacjentkę w jednym z małopolskich szpitali.

## "Brygida" i śnieg zostają w Polsce. IMGW ostrzega: Będą zawieje i zamiecie śnieżne
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29252935,brygida-i-snieg-zostaja-w-polsce-imgw-ostrzega-beda-zawieje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29252935,brygida-i-snieg-zostaja-w-polsce-imgw-ostrzega-beda-zawieje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 15:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c8/e5/1b/z29253064M,IMGW-wydal-ostrzezenia-dla-polnocy-Polski-.jpg" vspace="2" />Pomorze, Warmia, Mazury i Podlasie - tam zima w ciągu najbliższych godzin będzie najbardziej odczuwalna. Instytut Meteorologii i Gospodarki Wodnej przestrzega mieszkańców północnych województw Polski przed niebezpieczeństwem i utrudnieniami, jakie przyniosła ze sobą "Brygida". Ten niż spowodował intensywne opady śniegu, spadek temperatury, słowem - nadejście zimy.

## Zaginięcie Iwony Wieczorek. B. policjant: Dziwię się, że policja uparła się tylko na "pana ręcznika"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29252936,zaginiecie-iwony-wieczorek-b-policjant-dziwie-sie-ze-policja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29252936,zaginiecie-iwony-wieczorek-b-policjant-dziwie-sie-ze-policja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 15:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/51/e4/1b/z29249361M,Zaginiecie-Iwony-Wieczorek--Na-policje-zglosil-sie.jpg" vspace="2" />- Dziwię się, że policja, organy ścigania uparły się tylko na niego (człowieka z ręcznikiem - red.), skoro wiele innych osób szło w tym samym czasie nie tylko za Iwoną, ale także z przeciwnej strony - mówi w "Fakcie" Marek Siewert, były analityk Komendy Głównej Policji.

## Kielce. Zapłakana 6-latka w piżamie boso chodziła po śniegu. Wyszła na poszukiwania mamy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29251804,kielce-szesciolatka-boso-i-w-pizamie-blakala-sie-po-osiedlu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29251804,kielce-szesciolatka-boso-i-w-pizamie-blakala-sie-po-osiedlu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 13:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/95/e5/1b/z29252501M,Osniezone-zabawki--zdjecie-ilustrujace-.jpg" vspace="2" />Zapłakaną, błąkającą się boso po zaśnieżonym osiedlu sześciolatkę zauważył jeden z kieleckich policjantów. Dziewczynka była w samej piżamie. Funkcjonariusz zaopiekował się nią i wezwał na miejsce służby medyczne. Matka dziewczynki oraz jej partner byli nietrzeźwi. Sprawa trafi do sądu rodzinnego.

## Bielsko-Biała. Policja zatrzymała zaśnieżony samochód. Kierująca ledwo stała, wydmuchała 5 promili
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29251773,bielsko-biala-policja-zatrzymala-zasniezony-samochod-kierujaca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29251773,bielsko-biala-policja-zatrzymala-zasniezony-samochod-kierujaca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 12:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/01/cc/1b/z29150209M,Kontrola-trzezwosci-kierowcow.jpg" vspace="2" />Bielscy policjanci zatrzymali 37-latkę, która wsiadła za kierownicę osobowego fiata, mając w organizmie 5 promili alkoholu. Mieszkanka Bielska-Białej straciła prawo jazdy. Grożą jej 2 lata za kratami, wysoka grzywna i zakaz prowadzenia pojazdów.

## Wielka Brytania. Uczniowie z Polski utknęli na lotnisku. "Zero hotelu, zero niczego"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29251386,wielka-brytania-uczniowie-z-polski-utkneli-na-lotnisku-powodem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29251386,wielka-brytania-uczniowie-z-polski-utkneli-na-lotnisku-powodem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 10:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8b/e5/1b/z29251467M,Uczniowie-utkneli-pod-Londynem--zdj--ilustracyjne-.jpg" vspace="2" />Polscy uczniowie z warszawskiego liceum utknęli na lotnisku Stansted pod Londynem. Ich lot został odwołany z powodu złych warunków atmosferycznych.

## Alert RCB o wietrze i zamieciach dla Pomorza i Mazur. "Zostań w domu, jeśli możesz"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29251027,alert-rcb-o-wietrze-i-zamieciach-dla-pomorza-i-mazur-zostan.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29251027,alert-rcb-o-wietrze-i-zamieciach-dla-pomorza-i-mazur-zostan.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 10:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ff/e5/1b/z29251327M,Intensywne-opady-sniegu-w-Polsce.jpg" vspace="2" />Rządowe Centrum Bezpieczeństwa wysłało alert o silnym wietrze, zawiejach i zamieciach śnieżnych do mieszkańców powiatów w części województwa pomorskiego i warmińsko-mazurskiego.

## Atak zimy. Kto odpowiada za odśnieżanie dachu? Jakie grożą kary za zaniechanie?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250524,atak-zimy-kto-odpowiada-za-odsniezanie-dachu-jakie-groza-kary.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250524,atak-zimy-kto-odpowiada-za-odsniezanie-dachu-jakie-groza-kary.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 10:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/12/e5/1b/z29251346M,Odsniezanie-dachu--zdj--ilustracyjne-.jpg" vspace="2" />Atak zimy w Polsce zmusił do odśnieżania dróg, chodników oraz dachów. Śnieg zalegający na powierzchni budynku może negatywnie wpłynąć na jego konstrukcję, a także zagraża przechodniom. Kto jest za to odpowiedzialny? Wyłącznie właściciele nieruchomości i zarządcy.

## Odśnieżanie chodnika. Na kim spoczywa ten obowiązek? Co grozi za jego niedopełnienie?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250450,odsniezanie-chodnika-na-kim-spoczywa-ten-obowiazek-co-grozi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250450,odsniezanie-chodnika-na-kim-spoczywa-ten-obowiazek-co-grozi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 10:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/86/e5/1b/z29250950M,Obowiazek-odsniezania.jpg" vspace="2" />Kto powinien odśnieżać chodniki? Zasady oczyszczania chodnika ze śniegu znów, wraz z pojawieniem się intensywnych opadów, budzą wątpliwości. Wiadomo, że za odśnieżanie dróg odpowiada właściciel lub zarządca drogi. Natomiast odśnieżanie chodników nie jest kwestią tak jednoznaczną, ale regulują ją przepisy. Do kogo należy ten obowiązek? Jakie kary mogą spotkać osoby, które się z niego nie wywiązują? Wyjaśniamy w tekście.

## Sondaż: ćwiczenia wojskowe dla zwykłych obywateli i powrót poboru. Zaskakujący wynik
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250819,sondaz-cwiczenia-wojskowe-dla-zwyklych-obywateli-i-powrot.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250819,sondaz-cwiczenia-wojskowe-dla-zwyklych-obywateli-i-powrot.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 09:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9b/e5/1b/z29250971M,Cwiczenia-wojskowe---zdjecie-ilustracyjne.jpg" vspace="2" />54,8 proc. ankietowanych jest zdania, że należy przeprowadzić i powołać na ćwiczenia wojskowe osoby, które przeszły kwalifikację wojskową i mają kategorię "A", ale w wojsku nie były - wynika z sondażu United Surveys dla Wirtualnej Polski.

## Kiedy powstanie komisja badająca wpływy Rosji? Antoni Macierewicz podał termin
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250401,kiedy-powstanie-komisja-badajaca-wplywy-rosji-antoni-macierewicz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250401,kiedy-powstanie-komisja-badajaca-wplywy-rosji-antoni-macierewicz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 08:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bc/e5/1b/z29250492M,Antoni-Macierewicz.jpg" vspace="2" />Były szef MON Antoni Macierewicz powiedział na antenie Programu 1. Polskiego Radia, że w tym lub w przyszłym tygodniu powinna powstać komisja badająca ewentualne wpływy rosyjskie na bezpieczeństwo wewnętrzne Polski od 2007 roku. Poseł Prawa i Sprawiedliwości podkreślił, że konieczne jest ustalenie faktów, a materiału jest bardzo dużo.

## Próbna matura 2023 w nowej formule ruszyła. W poniedziałek język polski. Co dalej? [HARMONOGRAM]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250371,probna-matura-2023-w-nowej-formule-ruszyla-w-poniedzialek-jezyk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250371,probna-matura-2023-w-nowej-formule-ruszyla-w-poniedzialek-jezyk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 08:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9c/d9/1b/z29203356M,Matura--zdjecie-ilustracyjne-.jpg" vspace="2" />Matura próbna 2023 ruszyła. Egzaminy skończą się tuż przed przerwą świąteczną. Licealiści zmierzą się z nowościami egzaminacyjnymi, które przygotowało dla nich Ministerstwo Edukacji i Nauki.

## Orlenowska Polska Press wręczyła nagrody. Wśród laureatów m.in. Glapiński, Kowalczyk i Błaszczak
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250424,orlenowska-polska-press-wreczyla-nagrody-wsrod-laureatow-m-in.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250424,orlenowska-polska-press-wreczyla-nagrody-wsrod-laureatow-m-in.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 08:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8a/e5/1b/z29250442M,Prezes-NBP-Adam-Glapinski.jpg" vspace="2" />Adam Glapiński, Henryk Kowalczyk i Mariusz Błaszczak - to m.in. oni odebrali w niedzielę nagrodę Giganci Polska Press. Grupa, której właścicielem jest Orlen, przyznała wyróżnienia w siedmiu kategoriach podczas uroczystej gali. Odczytano również list prezesa PiS Jarosława Kaczyńskiego.

## Pogoda. Kiedy przestanie padać śnieg? Przed nami duże ochłodzenie, będzie nawet -20 st. C
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250265,pogoda-zima-w-odwrocie-nic-bardziej-mylnego-przed-nami-wyrazne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250265,pogoda-zima-w-odwrocie-nic-bardziej-mylnego-przed-nami-wyrazne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 08:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/70/e5/1b/z29250416M,Przed-nami-wyrazne-ochlodzenie.jpg" vspace="2" />Prognozy IMGW wskazują, że w poniedziałek 12 grudnia wciąż będzie padał śnieg. Od wtorku w całej Polsce czeka nas z kolei wyraźne ochłodzenie. Wszystko za sprawą mroźnego arktycznego powietrza z północy. W niektórych miejscach w kraju prognozowane jest nawet -20 st. C. Kiedy przestanie padać śnieg?

## Damian Ratka gościem Porannej Rozmowy Gazeta.pl
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250017,damian-ratka-gosciem-porannej-rozmowy-gazeta-pl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250017,damian-ratka-gosciem-porannej-rozmowy-gazeta-pl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 07:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1d/e5/1b/z29250333M,Damian-Ratka-gosciem-Porannej-Rozmowy-Gazeta-pl.jpg" vspace="2" />W poniedziałek gościem Porannej Rozmowy Gazeta.pl będzie redaktor portalu Defence24.pl Damian Ratka. Z dziennikarzem porozmawiamy o wojnie w Ukrainie, ćwiczeniach służby wojskowej oraz o uzbrojeniu polskiej armii. Program poprowadzi Karolina Hytrek-Prosiecka.

## Łódzkie. Autobus wpadł w poślizg i zsunął się do rowu. Wewnątrz były 22 osoby
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250269,lodzkie-autobus-wpadl-w-poslizg-i-zsunal-do-rowu-wewnatrz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250269,lodzkie-autobus-wpadl-w-poslizg-i-zsunal-do-rowu-wewnatrz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 07:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/00/e5/1b/z29250304M,Autobus-wpadl-w-poslizg-i-zsunal-do-rowu--Wewnatrz.jpg" vspace="2" />W niedzielę na trasie dk 91 pomiędzy Zgierzem a Ozorkowem autobus komunikacji miejskiej wpadł do przydrożnego rowu. Wewnątrz pojazdu były 22 osoby. Przyczyną zdarzenia było najprawdopodobniej niedostosowanie prędkości do warunków pogodowych panujących na drodze.

## Atak zimy. Ostrzeżenia przed zawiejami i zamieciami śnieżnymi. Niebezpiecznie na drogach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250218,atak-zimy-ostrzezenia-przed-zawiejami-i-zamieciami-snieznymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29250218,atak-zimy-ostrzezenia-przed-zawiejami-i-zamieciami-snieznymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-12 05:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/71/e4/1b/z29248625M.jpg" vspace="2" />IMGW wydał ostrzeżenia drugiego stopnia przed intensywnym śniegiem i zamieciami na Pomorzu oraz Warmii i Mazurach. W tych regionach od rana pracują pługi i solarki. Na lokalnych drogach jest jednak niebezpiecznie.


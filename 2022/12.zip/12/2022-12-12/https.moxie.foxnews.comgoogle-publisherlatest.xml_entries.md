# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Pistons' Cade Cunningham opts for shin surgery, ending his 2022-23 season: report
 - [https://www.foxnews.com/sports/pistons-cade-cunningham-opts-for-shin-surgery-ending-2022-23-season-report](https://www.foxnews.com/sports/pistons-cade-cunningham-opts-for-shin-surgery-ending-2022-23-season-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 23:55:08+00:00

The Detroit Pistons' 2021 first overall pick, Cade Cunningham, has reportedly opted for surgery to repair his left shin and will be out for the remainder of the 2022-2023 NBA season.

## Cardinals' J.J. Watt has some beef with Chipotle: 'We want big burritos back'
 - [https://www.foxnews.com/sports/cardinals-j-j-watt-beef-chipotle-we-want-big-burritos-back](https://www.foxnews.com/sports/cardinals-j-j-watt-beef-chipotle-we-want-big-burritos-back)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 23:52:35+00:00

Arizona Cardinals defensive end J.J. Watt wants to have an 'open dialogue' about a very serious issue: Chipotle's burrito size. He thinks they've been a bit too small lately.

## John Fetterman, James Webb Space Telescope named 'Most Stylish' in 2022 by NYT: ‘Have got to be kidding me’
 - [https://www.foxnews.com/media/john-fetterman-james-webb-space-telescope-named-stylish-2022-nyt-kidding](https://www.foxnews.com/media/john-fetterman-james-webb-space-telescope-named-stylish-2022-nyt-kidding)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 23:49:23+00:00

The New York Times listed Pennsylvania Senator-elect John Fetterman, D., and the James Webb Space Telescope among the “most stylish” people and things in 2022.

## Milking the Clock — In Football, Futball, and Congress
 - [https://www.foxnews.com/politics/milking-clock-football-futball-congress](https://www.foxnews.com/politics/milking-clock-football-futball-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 23:48:21+00:00

Los Angeles Rams quarterback Baker Mayfield may not know a lot about how to avert a government shutdown; but Mayfield knows this: you play until the end of the game.

## Pro Bowl wide receiver T.Y. Hilton, Cowboys agree to one-year deal
 - [https://www.foxnews.com/sports/former-colts-wide-receiver-t-y-hilton-cowboys-agree-one-year-deal](https://www.foxnews.com/sports/former-colts-wide-receiver-t-y-hilton-cowboys-agree-one-year-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 23:47:40+00:00

The Dallas Cowboys agreed to a one-year deal with longtime Indianapolis Colts wide receiver T.Y. Hilton on Monday.

## Ukraine deploys therapy dog services for kids experiencing war trauma to reduce stress, anxiety
 - [https://www.foxnews.com/lifestyle/ukraine-deploys-therapy-dog-services-kids-experiencing-war-trauma-reduce-stress-anxiety](https://www.foxnews.com/lifestyle/ukraine-deploys-therapy-dog-services-kids-experiencing-war-trauma-reduce-stress-anxiety)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 23:44:31+00:00

The Center for Social and Psychological Rehabilitation in Boyarka, Ukraine, brought in an eight-year-old dog to work with traumatized kids. Verywell Mind editor-in-chief Amy Morin weighs in on the benefits of pet therapy.

## Greg Gutfeld: The 'Twitter files' reveal a stunning lack of ideological diversity
 - [https://www.foxnews.com/media/greg-gutfeld-twitter-files-reveal-stunning-lack-ideological-diversity](https://www.foxnews.com/media/greg-gutfeld-twitter-files-reveal-stunning-lack-ideological-diversity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 23:31:07+00:00

'The Five' co-hosts discuss the fifth installment of the 'Twitter files' and reflect on what the first four revealed about censorship and blacklisting.

## Why the Lockerbie suspect's prosecution was 'very personal' to Bill Barr
 - [https://www.foxnews.com/media/why-lockerbie-suspects-prosecution-very-personal-bill-barr](https://www.foxnews.com/media/why-lockerbie-suspects-prosecution-very-personal-bill-barr)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 23:30:49+00:00

Suspect Abu Agila Mohammad Mas’ud Kheir Al-Marimi was in court on Monday in connection with the 1988 Lockerbie, Scotland Pan Am airline bombing terror attack.

## Biden invites anti-police nonbinary drag queen to White House: 'F--- the police'
 - [https://www.foxnews.com/politics/biden-invites-anti-police-nonbinary-drag-queen-white-house-f-police](https://www.foxnews.com/politics/biden-invites-anti-police-nonbinary-drag-queen-white-house-f-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 23:15:02+00:00

President Biden extended an invitation to drag queen Marti Cummings to attend a White House event where he will sign the Respect for Marriage Act.

## GOP plots swing state shake-up to prevent 2024 defeats
 - [https://www.foxnews.com/politics/gop-plots-swing-state-shake-up-prevent-2024-defeats](https://www.foxnews.com/politics/gop-plots-swing-state-shake-up-prevent-2024-defeats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 23:10:24+00:00

Swing state Republicans are plotting an overhaul of their state parties' leadership structure to ensure the GOP is more competitive in 2024 and beyond.

## Decorated Marine heading to Congress warns US military is facing obstacles that are 'unsustainable'
 - [https://www.foxnews.com/media/decorated-marine-heading-congress-warns-us-military-facing-obstacles-unsustainable](https://www.foxnews.com/media/decorated-marine-heading-congress-warns-us-military-facing-obstacles-unsustainable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 22:59:28+00:00

Georgia Rep.-elect Dr. Rich McCormick joins "The Brian Kilmeade Show" to discuss the COVID vaccine mandate fallout and how "wokeness" is impacting recruitment and morale.

## Biden admin declines to call Viktor Bout a terrorist, says it remains ‘vigilant’ against threat to Americans
 - [https://www.foxnews.com/us/biden-admin-viktor-bout-terrorist-threat-americans](https://www.foxnews.com/us/biden-admin-viktor-bout-terrorist-threat-americans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 22:58:11+00:00

National Security Advisor Jake Sullivan declined to call Viktor Bout a terrorist despite his conviction for conspiring to kill Americans.

## Lockerbie bombing suspect appears in US court
 - [https://www.foxnews.com/us/lockerbie-bombing-suspect-appear-us-court](https://www.foxnews.com/us/lockerbie-bombing-suspect-appear-us-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 22:53:52+00:00

The Libyan intelligence officer charged in the 1988 bombing in Lockerbie, Scotland, was set to make his first appearance in federal court on Monday.

## Theft of delivered packages: How to steer clear of thieves this holiday season
 - [https://www.foxnews.com/lifestyle/theft-delievered-packages-steer-clear-thieves-holiday-season](https://www.foxnews.com/lifestyle/theft-delievered-packages-steer-clear-thieves-holiday-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 22:52:46+00:00

Online shopping is an easy way to buy for loved ones this holiday season — but package thieves are looking out for these gifts, too. Here are tips on how to prevent it from happening.

## Brittney Griner trade fiasco just latest example of American enemies using woke culture against us: commentary
 - [https://www.foxnews.com/sports/brittney-griner-trade-fiasco-latest-example-american-enemies-using-woke-culture-against-us-commentary](https://www.foxnews.com/sports/brittney-griner-trade-fiasco-latest-example-american-enemies-using-woke-culture-against-us-commentary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 22:42:23+00:00

Russian media mocked the U.S. decision to trade convicted arms dealer Viktor Bout for WNBA superstar Brittney Griner in a prisoner swap last week.

## Philadelphia must remove box covering Christopher Columbus statue, judge rules
 - [https://www.foxnews.com/media/philadelphia-remove-box-covering-christopher-columbus-statue-judge-rules](https://www.foxnews.com/media/philadelphia-remove-box-covering-christopher-columbus-statue-judge-rules)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 22:30:10+00:00

The Christopher Columbus statue will now stand freely in Marconi Plaza, Philadelphia after a judge ruled that the statue should not be boxed or removed.

## Braves land All-Star catcher Sean Murphy in three-team trade
 - [https://www.foxnews.com/sports/braves-land-all-star-catcher-sean-murphy-three-way-trade](https://www.foxnews.com/sports/braves-land-all-star-catcher-sean-murphy-three-way-trade)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 22:22:20+00:00

The Oakland Athletics continue to revamp their entire roster, as they traded away catcher Sean Murphy to the Atlanta Braves in a three-team trade that includes the Milwaukee Brewers.

## Texas crime victims liaison arrested after allegedly using county-issued car in human smuggling scheme
 - [https://www.foxnews.com/us/texas-crime-victims-liaison-arrested-allegedly-using-county-vehicle-human-smuggling](https://www.foxnews.com/us/texas-crime-victims-liaison-arrested-allegedly-using-county-vehicle-human-smuggling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 22:15:04+00:00

A Texas woman employed by a district attorney's office was arrested and fired after a work vehicle was used in a human smuggling scheme, authorities said.

## GOP signals investigations, possible subpoenas on COVID origin, domestic extremism monitoring: Rep. Turner
 - [https://www.foxnews.com/politics/gop-signals-investigations-possible-subpoenas-covid-origin-domestic-extremism-monitoring-rep-turner](https://www.foxnews.com/politics/gop-signals-investigations-possible-subpoenas-covid-origin-domestic-extremism-monitoring-rep-turner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 22:11:02+00:00

Ranking Member Rep. Mike Turner told Fox News Digital that there was "unanimous" bipartisan support for two "resolutions of inquiry" that were voted on in committee last week.

## Rams' Baker Mayfield recalls wild journey to Los Angeles: report
 - [https://www.foxnews.com/sports/rams-baker-mayfield-recalls-wild-journey-los-angles-report](https://www.foxnews.com/sports/rams-baker-mayfield-recalls-wild-journey-los-angles-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 22:01:44+00:00

Los Angeles Rams quarterback Baker Mayfield recalled the hectic 48 hours that led up to Thursday night's thrilling victory over the Las Vegas Raiders in an interview with Peter King.

## Biden directed offstage by child after Toys for Tots remarks
 - [https://www.foxnews.com/politics/biden-directed-stage-child-toys-tots-remarks](https://www.foxnews.com/politics/biden-directed-stage-child-toys-tots-remarks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:57:46+00:00

President Biden appeared confused Monday after his speech with Toys for Tots in Arlington, Virginia, and had to be led offstage by a young girl who took his hand.

## Jamie Lee Curtis calls 22-year sobriety a 'legacy': 'Will be the single greatest thing I do'
 - [https://www.foxnews.com/entertainment/jamie-lee-curtis-calls-22-year-sobriety-legacy-single-greatest-thing-i-do](https://www.foxnews.com/entertainment/jamie-lee-curtis-calls-22-year-sobriety-legacy-single-greatest-thing-i-do)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:55:39+00:00

Jamie Lee Curtis opened up about her sobriety "legacy" during a recent conversation with actor Colin Farrell. The "Halloween Ends" actress became sober in 1999.

## White House says bringing Marine veteran Paul Whelan home is 'as high a priority as the president has'
 - [https://www.foxnews.com/politics/white-house-bringing-marine-veteran-paul-whelan-home-high-priority-president](https://www.foxnews.com/politics/white-house-bringing-marine-veteran-paul-whelan-home-high-priority-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:40:38+00:00

The White House said the Biden administration is “bound and determined” to bring Marine veteran Paul Whelan home to the United States; it is “as high a priority as the president has.”

## Pennsylvania school board member to resign over statement rejecting 'cis White male' for president
 - [https://www.foxnews.com/us/pennsylvania-school-board-member-resign-over-rejecting-cis-white-male-president](https://www.foxnews.com/us/pennsylvania-school-board-member-resign-over-rejecting-cis-white-male-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:38:32+00:00

A Pennsylvania school board member who said she would not vote for the "only cis White male" on the board to service as president, announced she will resign from position.

## PBS' 'Washington Week in Review' is more like 'Democrat Week in Review' and you're paying for it
 - [https://www.foxnews.com/opinion/pbs-washington-week-review-democrat-week-review-paying](https://www.foxnews.com/opinion/pbs-washington-week-review-democrat-week-review-paying)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:37:54+00:00

The gushing over Democrats is on full display in PBS' 'Washington Week in Review' The unanimous agreement from the host and participants in the program is always slanted to Democrats.

## Kit Harington talks about Jon Snow in 'Game of Thrones' sequel series: 'He’s not OK'
 - [https://www.foxnews.com/entertainment/kit-harington-talks-about-jon-snow-game-thrones-sequel-series](https://www.foxnews.com/entertainment/kit-harington-talks-about-jon-snow-game-thrones-sequel-series)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:31:21+00:00

Former “Game of Thrones” actor Kit Harington spoke about the state of mind of his character Jon Snow in the future HBO sequel series dubbed “Snow.”

## Former Loudoun County superintendent, school official, indicted by grand jury over handling of sexual assaults
 - [https://www.foxnews.com/media/loudoun-county-public-schools-superintendent-school-official-indicted-special-grand-jury](https://www.foxnews.com/media/loudoun-county-public-schools-superintendent-school-official-indicted-special-grand-jury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:30:04+00:00

A judge ordered the indictments against two Loudoun County Public School officials on Monday after a special grand jury investigation into the district.

## El Paso official says illegal border crossing numbers 'are unsustainable’ days before Title 42 expires
 - [https://www.foxnews.com/us/el-paso-illegal-border-crossing-unsustainable-title-42](https://www.foxnews.com/us/el-paso-illegal-border-crossing-unsustainable-title-42)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:20:39+00:00

Officials in El Paso, Texas said the number of migrants coming into the city in recent days has surged.

## Grant Wahl's body returned to US after tragic death at World Cup
 - [https://www.foxnews.com/sports/grant-wahls-body-returned-to-us-tragic-death-world-cup](https://www.foxnews.com/sports/grant-wahls-body-returned-to-us-tragic-death-world-cup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:19:40+00:00

Department of State spokesperson Ned Price confirmed that soccer journalist Grant Wahl's body has been returned to the U.S. He died while covering the World Cup.

## Tom Brady reportedly ends disastrous night in San Francisco without a shower: ‘F--- that. I’m going home’
 - [https://www.foxnews.com/sports/tom-brady-reportedly-ends-disastrous-night-san-francisco-shower-f-that-im-going-home](https://www.foxnews.com/sports/tom-brady-reportedly-ends-disastrous-night-san-francisco-shower-f-that-im-going-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:13:02+00:00

Tom Brady's frustrations reached a boiling point on Sunday after the Tampa Bay Buccaneers 35-7 loss to the San Francisco 49ers.

## 2 in 5 Americans, nearly half of Christians, believe 'we are living in the end times': poll
 - [https://www.foxnews.com/us/2-5-americans-nearly-half-christians-believe-we-are-living-end-times-poll](https://www.foxnews.com/us/2-5-americans-nearly-half-christians-believe-we-are-living-end-times-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:11:30+00:00

Nearly two in five Americans across the religious spectrum said they believe they are living in the end times, according to a new study from Pew Research about climate change.

## 'The White Lotus' season 3: What to know
 - [https://www.foxnews.com/entertainment/the-white-lotus-season-3-what-know](https://www.foxnews.com/entertainment/the-white-lotus-season-3-what-know)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:07:16+00:00

The final episode of season two of "The White Lotus" aired Sunday on HBO. Fox News Digital gives the known details on a season three of the satirical drama.

## Democrats could have been Twitter censorship targets, too. Why don’t they get that?
 - [https://www.foxnews.com/opinion/democrats-could-twitter-censorship-targets](https://www.foxnews.com/opinion/democrats-could-twitter-censorship-targets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:01:45+00:00

As Elon Musk continues to release the 'Twitter Files' the obvious question is about Democrats. Were they also targeted by the tech giant? Could some Democrats have also been censored?

## Pete Buttigieg ripped for using taxpayer-funded private jets amid calls to cut emissions: 'Walk the walk, man'
 - [https://www.foxnews.com/media/pete-buttigieg-ripped-for-using-taxpayer-funded-private-jets-amid-calls-to-cut-emissions-walk-the-walk-man](https://www.foxnews.com/media/pete-buttigieg-ripped-for-using-taxpayer-funded-private-jets-amid-calls-to-cut-emissions-walk-the-walk-man)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 21:00:18+00:00

The 'Outnumbered' reacts to flight data revealing Biden Transportation Secretary Pete Buttigieg used taxpayer dollars for private jet travel despite previous climate change concerns.

## Washington Post admits 'editing error' on piece questioning Argentina soccer team for lack of Black players
 - [https://www.foxnews.com/media/washington-post-admits-editing-error-piece-questioning-argentina-soccer-teams-lack-black-players](https://www.foxnews.com/media/washington-post-admits-editing-error-piece-questioning-argentina-soccer-teams-lack-black-players)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 20:54:23+00:00

An opinion writer for the Washington Post was blasted by social media users for questioning why there weren't more Black players on Argentina's World Cup roster.

## Prince Harry claims people were ‘happy to lie to protect’ Prince William in new Netflix trailer
 - [https://www.foxnews.com/entertainment/prince-harry-claims-people-were-happy-to-lie-protect-prince-william-new-netflix-trailer](https://www.foxnews.com/entertainment/prince-harry-claims-people-were-happy-to-lie-protect-prince-william-new-netflix-trailer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 20:46:04+00:00

Prince Harry's older brother Prince William, the Prince of Wales, is heir to the throne. The Duke and Duchess of Sussex stepped back from royal duties in 2020.

## Senate tees up one-week funding bill to avert government shutdown
 - [https://www.foxnews.com/politics/senate-tees-up-one-week-funding-bill-avert-government-shutdown](https://www.foxnews.com/politics/senate-tees-up-one-week-funding-bill-avert-government-shutdown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 20:30:37+00:00

Congressional lawmakers are rushing to avert a government shutdown, but Democrats and Republicans remain divided over how long to keep the government funded.

## Idaho murder victims' hands bagged at scene to preserve possible evidence: coroner
 - [https://www.foxnews.com/us/idaho-murder-victims-hands-bagged-scene-preserve-possible-evidence-coroner](https://www.foxnews.com/us/idaho-murder-victims-hands-bagged-scene-preserve-possible-evidence-coroner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 20:05:08+00:00

Idaho investigators bagged the hands of four students killed in their home off the University of Idaho campus on Nov. 13 in an effort to preserve evidence.

## Twitter users push to boycott Tesla after Elon Musk tweets his pronouns are ‘Prosecute/Fauci’
 - [https://www.foxnews.com/media/boycott-tesla-trending-twitter-elon-musk-prosecute-fauci-pronouns](https://www.foxnews.com/media/boycott-tesla-trending-twitter-elon-musk-prosecute-fauci-pronouns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 20:00:01+00:00

"Boycott Tesla" was trending on Twitter Monday after Elon Musk, who owns Twitter and is CEO of Tesla, tweeted, "My pronouns are Prosecute/Fauci."

## Biden administration 'delusional' and in ‘state of denial' of massive groups crossing the border, Ron Johnson
 - [https://www.foxnews.com/media/biden-administration-delusional-state-denial-massive-groups-crossing-border-ron-johnson](https://www.foxnews.com/media/biden-administration-delusional-state-denial-massive-groups-crossing-border-ron-johnson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 19:59:46+00:00

Sen. Ron Johnson, R-Wisc., rips the Biden administration for being “delusional” and in a “state of denial” for rejecting the notion that migrants are flooding the U.S. border.

## Daniel Craig on his character's gay relationship in 'Knives Out' sequel: 'It's normal'
 - [https://www.foxnews.com/entertainment/daniel-craig-characters-gay-relationship-knives-out-sequel-its-normal](https://www.foxnews.com/entertainment/daniel-craig-characters-gay-relationship-knives-out-sequel-its-normal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 19:58:11+00:00

Daniel Craig is returning as his character Benoit Blanc in the new "Glass Onion: A Knives Out Mystery" movie, and is talking about his character's sexuality in reference to his own personal life.

## Texas attorney general sues Biden admin over state’s ability to work with faith-based organizations
 - [https://www.foxnews.com/politics/texas-attorney-general-sues-biden-administration-states-ability-work-faith-based-organizations](https://www.foxnews.com/politics/texas-attorney-general-sues-biden-administration-states-ability-work-faith-based-organizations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 19:45:50+00:00

Texas is filing a lawsuit against the Biden administration to ensure that the state is not compelled to discriminate against faith-based adoption and foster-care services.

## NH hiker who fell to his death off mountain cliff while taking pictures with wife ID’d as Joseph Eggleston
 - [https://www.foxnews.com/us/nh-hiker-fell-to-death-off-mountain-cliff-taking-pictures-wife-idd-joseph-eggleston](https://www.foxnews.com/us/nh-hiker-fell-to-death-off-mountain-cliff-taking-pictures-wife-idd-joseph-eggleston)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 19:42:23+00:00

Joseph "Eggy" Eggleston, 53, was identified as the hiker who fell 300 feet to his death from the summit of Mt. Willard in Crawford Notch near Hart's Location, New Hampshire.

## Fallout from LA racism scandal keeps shaking City Council
 - [https://www.foxnews.com/us/fallout-la-racism-scandal-keeps-shaking-city-council](https://www.foxnews.com/us/fallout-la-racism-scandal-keeps-shaking-city-council)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 19:34:01+00:00

Public trust in the Los Angeles city government has been lost after city council members were entangled in a scandal involving racist comments.

## Air Force successfully tests hypersonic missile that travels five times the speed of sound
 - [https://www.foxnews.com/us/air-force-successfully-launches-first-operational-hypersonic-missile-prototype](https://www.foxnews.com/us/air-force-successfully-launches-first-operational-hypersonic-missile-prototype)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 19:17:20+00:00

The first All-Up-Round AGM-183A Air-launched Rapid Response Weapon was released by a B-52H Stratofortress off the Southern California coast last week.

## Piers Morgan's viral reaction to new ‘Harry & Meghan’ Netflix trailer: ‘Two poisonous rats’
 - [https://www.foxnews.com/media/piers-morgans-viral-reaction-new-harry-meghan-netflix-trailer-two-poisonous-rats](https://www.foxnews.com/media/piers-morgans-viral-reaction-new-harry-meghan-netflix-trailer-two-poisonous-rats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 19:10:18+00:00

Piers Morgan ripped Harry and Meghan on Twitter, calling them “poisonous rats” who threaten the "Monarchy" after another episode of their Netflix series dropped.

## Man vanishes in Massachusetts after getting locked out of vehicle, police say
 - [https://www.foxnews.com/us/man-vanishes-massachusetts-getting-locked-vehicle-police-say](https://www.foxnews.com/us/man-vanishes-massachusetts-getting-locked-vehicle-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 19:09:36+00:00

Michael Gray, a 31-year-old from Maine, has vanished in the Boston area after getting locked out of his vehicle on Saturday night, Peabody Police say.

## Brock Purdy gets big support from 49ers teammate: 'We've got a quarterback'
 - [https://www.foxnews.com/sports/brock-purdy-gets-big-support-49ers-teammate-weve-got-quarterback](https://www.foxnews.com/sports/brock-purdy-gets-big-support-49ers-teammate-weve-got-quarterback)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 19:08:18+00:00

Brock Purdy got a big vote of confidence from teammate Nick Bosa after the San Francisco 49ers topped the Tampa Bay Buccaneers on Sunday, 35-7.

## Jets praise Mike White's gritty performance in loss to Bills: 'He's a f---ing soldier'
 - [https://www.foxnews.com/sports/jets-praise-mike-whites-gritty-performance-loss-bills-hes-f-ing-soldier](https://www.foxnews.com/sports/jets-praise-mike-whites-gritty-performance-loss-bills-hes-f-ing-soldier)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 19:05:55+00:00

New York Jets quarterback Mike White received a massive vote of confidence from his teammates following his gritty performance in Sunday's loss to the Buffalo Bills.

## New York City 'baby face killer' sought after gruesome apartment deadly stabbing of 16-year-old girl
 - [https://www.foxnews.com/us/new-york-city-baby-face-killer-sought-gruesome-apartment-deadly-stabbing-16-year-old-girl](https://www.foxnews.com/us/new-york-city-baby-face-killer-sought-gruesome-apartment-deadly-stabbing-16-year-old-girl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:53:34+00:00

The NYPD is seeking 18-year-old Zyaire Crumbley, nicknamed the "baby face" killer for his mugshot, for the murder of a 16-year-old found stabbed in the neck at a Harlem apartment.

## Ken DeLand, American college student missing in France, interned for New York senator: 'A positive energy'
 - [https://www.foxnews.com/world/ken-deland-american-college-student-missing-france-interned-new-york-senator-positive-energy](https://www.foxnews.com/world/ken-deland-american-college-student-missing-france-interned-new-york-senator-positive-energy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:44:57+00:00

Ken DeLand, an American college student missing while on study abroad in France, previously interned for Republican New York state Sen. Pam Helming from 2019 to 2020.

## Selena Gomez leaves cryptic response to video about how 'skinny' she was during Justin Bieber fling
 - [https://www.foxnews.com/entertainment/selena-gomez-leaves-cryptic-response-video-skinny-during-justin-bieber-fling](https://www.foxnews.com/entertainment/selena-gomez-leaves-cryptic-response-video-skinny-during-justin-bieber-fling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:32:26+00:00

"Wizards of Waverly Place" star Selena Gomez responded to a TikTok video alleging she was skinnier during her relationship with Justin Bieber.

## Dolphins' Mike McDaniel appears to laugh off brutal roughing the passer penalty
 - [https://www.foxnews.com/sports/dolphins-mike-mcdaniel-appears-laugh-off-brutal-roughing-passer-penalty](https://www.foxnews.com/sports/dolphins-mike-mcdaniel-appears-laugh-off-brutal-roughing-passer-penalty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:26:10+00:00

Miami Dolphins coach Mike McDaniel appeared to laugh off the roughing the passer penalty called on Jalen Phillips for his hit on Justin Herbert on Sunday night

## Human rights commissioner in MA quits after mocking God, blasting 'trash' Christians amid Christmas tree spat
 - [https://www.foxnews.com/us/human-rights-commissioner-ma-quits-mocking-god-blasting-trash-christians-christmas-tree-spat](https://www.foxnews.com/us/human-rights-commissioner-ma-quits-mocking-god-blasting-trash-christians-christmas-tree-spat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:25:38+00:00

A member of the Human Rights Commission in Dedham, Massachusetts, resigned after making a vitriolic post on Facebook against God and Christians amid a spat over a Christmas tree.

## Yoel Roth's ‘Gay Data’ dissertation ‘mistakenly’ blocked from UPenn website after Elon Musk’s tweet
 - [https://www.foxnews.com/politics/yoel-roths-gay-data-dissertation-mistakenly-blocked-upenn-website-elon-musks-tweet](https://www.foxnews.com/politics/yoel-roths-gay-data-dissertation-mistakenly-blocked-upenn-website-elon-musks-tweet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:21:52+00:00

The University of Pennsylvania temporarily blocked a doctoral dissertation about Grindr from ex-Twitter head Yoel Roth after Twitter CEO Elon Musk criticized it.

## Twitter Files Part 5 reveals aftermath of unprecedented Trump ban
 - [https://www.foxnews.com/media/twitter-files-part-5-reveals-aftermath-unprecedented-trump-ban](https://www.foxnews.com/media/twitter-files-part-5-reveals-aftermath-unprecedented-trump-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:21:08+00:00

Journalist Bari Weiss elaborated on continued efforts by Twitter to remove Donald Trump on Jan. 8, 2021, in the latest installment of Elon Musk's "Twitter Files."

## White House condemns Marjorie Taylor Greene's 'violent' remarks on Capitol riot organization
 - [https://www.foxnews.com/politics/white-house-condemns-marjorie-taylor-greenes-violent-remarks-capitol-riot-organization](https://www.foxnews.com/politics/white-house-condemns-marjorie-taylor-greenes-violent-remarks-capitol-riot-organization)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:16:40+00:00

The White House condemned Rep. Marjorie Taylor Greene for inflammatory remarks she made over the weekend about the Jan. 6 Capitol riot.

## Pennsylvania’s McCormick taking steps that hint at potential 2024 Senate campaign
 - [https://www.foxnews.com/politics/pennsylvanias-mccormick-taking-steps-hint-potential-2024-senate-campaign](https://www.foxnews.com/politics/pennsylvanias-mccormick-taking-steps-hint-potential-2024-senate-campaign)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:12:35+00:00

Dave McCormick, the GOP candidate who came within a thousand votes of winning the 2022 Senate nomination in the crucial northeastern battleground state, is mulling another bid in 2024.

## 'Top Gun,' 'The Crown,' and 'Yellowstone' land Golden Globe nominations
 - [https://www.foxnews.com/entertainment/top-gun-the-crown-yellowstone-land-golden-globe-nominations](https://www.foxnews.com/entertainment/top-gun-the-crown-yellowstone-land-golden-globe-nominations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:04:02+00:00

The 2023 Golden Globes will take place in January and several nominations were given out in December to Netflix films and shows like "The Crown," and "Glass Onion: A Knives Out Mystery."

## Rob Gronkowski spikes Cowboys' Super Bowl chances: 'They’re pretenders every year'
 - [https://www.foxnews.com/sports/rob-gronkowski-spikes-cowboys-super-bowl-chances-theyre-pretenders-every-year](https://www.foxnews.com/sports/rob-gronkowski-spikes-cowboys-super-bowl-chances-theyre-pretenders-every-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:01:51+00:00

Rob Gronkowski suggested he's not in love with the Dallas Cowboys' chances of making the Super Bowl right before their narrow victory over the Houston Texans.

## Fake Android app sparks personal privacy warning
 - [https://www.foxnews.com/tech/fake-android-app-sparks-personal-privacy-warning](https://www.foxnews.com/tech/fake-android-app-sparks-personal-privacy-warning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 18:00:16+00:00

Kurt "CyberGuy" Knutsson shows how a seemingly harmless messaging service for Android users actually contained malware. Here's what to know about avoiding it.

## Fort Stewart suspect in custody after soldier killed in shooting at Georgia Army post
 - [https://www.foxnews.com/us/fort-stewart-suspect-custody-shooting-georgia-army-post](https://www.foxnews.com/us/fort-stewart-suspect-custody-shooting-georgia-army-post)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 17:45:02+00:00

Fort Stewart in Georgia confirmed that one soldier was shot and killed Monday morning, and a suspect was taken into custody. The investigation was ongoing.

## Maryland suspect in 2 shootings wounded by officer
 - [https://www.foxnews.com/us/maryland-suspect-2-shootings-wounded-officer](https://www.foxnews.com/us/maryland-suspect-2-shootings-wounded-officer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 17:29:21+00:00

A Maryland suspect in two shootings was wounded by a police officer before being taken into custody. The state police’s homicide unit is investigating the officer-involved shooting.

## 13 Tennessee inmates to receive Lipscomb University degrees
 - [https://www.foxnews.com/us/13-tennessee-inmates-receive-lipscomb-university-degrees](https://www.foxnews.com/us/13-tennessee-inmates-receive-lipscomb-university-degrees)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 17:28:50+00:00

13 Tennessee inmates will receive Lipscomb University degrees during graduation on Thursday. The inmates were taught by university professors and studied with students face-to-face.

## Pelosi's daughter who directed documentary denies political bias, blames 'misogyny' for threats against mother
 - [https://www.foxnews.com/media/pelosis-daughter-who-directed-documentary-denies-political-bias-blames-misogyny-for-threats-against-mother](https://www.foxnews.com/media/pelosis-daughter-who-directed-documentary-denies-political-bias-blames-misogyny-for-threats-against-mother)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 17:28:15+00:00

Nancy Pelosi's daughter Alexandra Pelosi denied she was a political person to CBS while discussing the documentary on her mother that she filmed for HBO.

## 1 killed, 2 others shot in home invasion near Philadelphia's Temple University
 - [https://www.foxnews.com/us/1-killed-2-others-shot-home-invasion-philadelphia-temple-university](https://www.foxnews.com/us/1-killed-2-others-shot-home-invasion-philadelphia-temple-university)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 17:26:46+00:00

One man was killed and two others were wounded during a home invasion near Philadelphia's Temple University on Sunday, police said.

## Dogs gifted by North Korean leader Kim Jong Un end up in South Korean zoo
 - [https://www.foxnews.com/world/dogs-gifted-north-korean-leader-kim-jong-un-south-korean-zoo](https://www.foxnews.com/world/dogs-gifted-north-korean-leader-kim-jong-un-south-korean-zoo)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 17:20:26+00:00

Kim Jung Un gave a pair of dogs to South Korea's former President, Moon Jae-in, in 2018. The country's new president gave them up, and they are now being sent to a zoo in the country.

## Burlington, Vermont, reeling from highest number of homicides in decades after defunding police
 - [https://www.foxnews.com/us/vermonts-largest-city-pays-bloody-price-cutting-police-force](https://www.foxnews.com/us/vermonts-largest-city-pays-bloody-price-cutting-police-force)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 17:13:36+00:00

Homicides in Burlington, Vermont, are at levels not seen since 1960 after the city was defunded in 2020. Homicides across Vermont have also skyrocketed this year.

## NYC man arrested after slapping cop’s hand during dispute with protesters at public library’s Drag Story Hour
 - [https://www.foxnews.com/us/nyc-man-arrested-slapping-cops-hand-dispute-protesters-public-librarys-drag-story-hour](https://www.foxnews.com/us/nyc-man-arrested-slapping-cops-hand-dispute-protesters-public-librarys-drag-story-hour)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 17:12:47+00:00

Chase Catapano was arrested after slapping a police officer's hand during a verbal dispute with anti-Drag Story Hour protesters at a Manhattan public library.

## Val Kilmer praises 'Top Gun: Maverick' cast as film earns Golden Globe nomination
 - [https://www.foxnews.com/entertainment/val-kilmer-praises-top-gun-maverick-cast-film-earns-golden-globe-nomination](https://www.foxnews.com/entertainment/val-kilmer-praises-top-gun-maverick-cast-film-earns-golden-globe-nomination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 17:10:56+00:00

Val Kilmer gushed about the "perfect" "Top Gun: Maverick" cast as the film earned a Golden Globe nomination for best motion picture. Kilmer returned in his role of Iceman.

## Mississippi State's Mike Leach in critical condition as report sheds light on health issue
 - [https://www.foxnews.com/sports/mississippi-states-mike-leach-critical-condition-report-sheds-light-health-issue](https://www.foxnews.com/sports/mississippi-states-mike-leach-critical-condition-report-sheds-light-health-issue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 17:07:18+00:00

Mississippi State University offered an update on football coach Mike Leach following his hospitalization for a "personal health issue."

## Former Maryland prosecutor pleads guilty to making false statements to obtain ex-partners' records
 - [https://www.foxnews.com/us/former-maryland-prosecutor-pleads-guilty-making-false-statements-obtain-ex-partners-records](https://www.foxnews.com/us/former-maryland-prosecutor-pleads-guilty-making-false-statements-obtain-ex-partners-records)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 17:07:07+00:00

A former Maryland prosecutor has pleaded guilty to making false statements to obtain ex-partners' records to stalk them. He faces a maximum sentence of 15 years in prison.

## T'Wolves star Rudy Gobert likes Elon Musk's 'Prosecute/Fauci' tweet
 - [https://www.foxnews.com/sports/twolves-star-rudy-gobert-likes-elon-musks-prosecute-fauci-tweet](https://www.foxnews.com/sports/twolves-star-rudy-gobert-likes-elon-musks-prosecute-fauci-tweet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 16:29:14+00:00

Minnesota Timberwolves center Rudy Gobert appeard to back Elon Musk's criticisms of outgoing National Institute of Allergy and Infectious Diseases director Dr. Anthon Fauci.

## FBI speaks on Lockerbie suspect before Pan Am flight 103 alleged bombmaker makes first court appearance
 - [https://www.foxnews.com/world/fbi-speaks-lockerbie-suspect-pan-am-flight-103-alleged-bombmaker-makes-first-court-appearance](https://www.foxnews.com/world/fbi-speaks-lockerbie-suspect-pan-am-flight-103-alleged-bombmaker-makes-first-court-appearance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 16:27:34+00:00

The FBI is expected to make an announcement ahead of the first court appearance for the accused Pan Am flight 103 bombmaker charged in the 1988 Lockerbie, Scotland, plane explosion.

## Ratcliffe: No 'coincidence' Jim Baker got top Twitter job after pushing Russian collusion narrative
 - [https://www.foxnews.com/politics/ratcliffe-no-coincidence-jim-baker-got-top-twitter-job-pushing-russian-collusion-narrative](https://www.foxnews.com/politics/ratcliffe-no-coincidence-jim-baker-got-top-twitter-job-pushing-russian-collusion-narrative)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 16:22:22+00:00

Former Director of National Intelligence John Ratcliffe said it’s no coincidence ex-FBI general counsel Jim Baker got a top Twitter job after being a key figure in the Trump-Russia probe.

## Chicago bloody weekend leaves 20 shot, including 14-year-old boy struck multiple times
 - [https://www.foxnews.com/us/chicago-bloody-weekend-shot-boy-struck-multiple-times](https://www.foxnews.com/us/chicago-bloody-weekend-shot-boy-struck-multiple-times)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 16:21:33+00:00

Gun violence that erupted in Chicago over the weekend wounded 20 people, including a 14-year-old boy, and killed at least six others, police said Monday morning.

## Brooke Shields, 57, rocks racy red top to JingleBall as she matches with daughters: 'A Cool Mom'
 - [https://www.foxnews.com/entertainment/brooke-shields-57-rocks-racy-red-top-jingleball-matches-daughters-cool-mom](https://www.foxnews.com/entertainment/brooke-shields-57-rocks-racy-red-top-jingleball-matches-daughters-cool-mom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 16:20:56+00:00

Brooke Shields was joined by her daughters, Rowan and Grier, for her appearance at the iHeartRadio JingleBall on Friday. The trio matched in red and black outfits.

## Crews find 4th body at explosion site in San Antonio
 - [https://www.foxnews.com/us/crews-find-4th-body-explosion-site-san-antonio](https://www.foxnews.com/us/crews-find-4th-body-explosion-site-san-antonio)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 16:17:24+00:00

The fourth body has been found after an explosion at a K-Bar Services site in San Antonio, Texas. Investigators are still looking into the cause of the blast.

## 3 fatally shot following Chicago bar fight, another woman was critically injured
 - [https://www.foxnews.com/us/3-fatally-shot-following-chicago-bar-fight-another-woman-critically-injured](https://www.foxnews.com/us/3-fatally-shot-following-chicago-bar-fight-another-woman-critically-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 16:17:12+00:00

A shooting following a bar fight in Chicago killed three people and injured another woman. The shooter fled the scene in a dark-colored SUV.

## 77-year-old Georgia woman found stabbed to death in gated neighborhood
 - [https://www.foxnews.com/us/77-year-old-georgia-woman-found-fatally-stabbed-gated-neighborhood](https://www.foxnews.com/us/77-year-old-georgia-woman-found-fatally-stabbed-gated-neighborhood)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 16:14:17+00:00

A woman was found fatally stabbed in her Atlanta neighborhood. The victims SUV was stolen from the home and security footage caught the suspect on camera. No arrests have been made.

## Ken DeLand: Dad of American college student missing in France warns other parents over studying abroad
 - [https://www.foxnews.com/world/ken-deland-dad-of-american-college-student-missing-in-france-warns-other-parents-over-studying-abroad](https://www.foxnews.com/world/ken-deland-dad-of-american-college-student-missing-in-france-warns-other-parents-over-studying-abroad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 16:07:24+00:00

The father of Ken DeLand, an upstate New York college student missing in France, warned other parents to be wary of privacy rules before their adult kids study abroad.

## Are smart Christmas lights worth the money?
 - [https://www.foxnews.com/tech/smart-christmas-lights-worth-money](https://www.foxnews.com/tech/smart-christmas-lights-worth-money)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 16:00:21+00:00

Kurt "CyberGuy" Knutsson gives advice on the best way to light up your house and Christmas tree with smart lights, LED lights, and smart plugs.

## Piers Morgan calls out lack of convictions in Lockerbie bombing attack: 'Complete disgrace'
 - [https://www.foxnews.com/media/piers-morgan-calls-lack-convictions-lockerbie-bombing-attack-complete-disgrace](https://www.foxnews.com/media/piers-morgan-calls-lack-convictions-lockerbie-bombing-attack-complete-disgrace)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 15:30:19+00:00

Fox Nation host Piers Morgan called it an 'abomination' that only two people have been brought to justice in the Lockerbie bombing that killed hundreds in 1988

## Texas men's basketball coach Chris Beard arrested on assault charge
 - [https://www.foxnews.com/sports/texas-mens-basketball-coach-chris-beard-arrested-assault-charge](https://www.foxnews.com/sports/texas-mens-basketball-coach-chris-beard-arrested-assault-charge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 15:28:52+00:00

Chris Beard, head coach of the Longhorns men's basketball team, was arrested Monday morning for assault on a family member, police records show.

## IAEA chief to make trip to South Korea amid concerns of North Korean nuclear test
 - [https://www.foxnews.com/world/iaea-chief-make-trip-south-korea-amid-concerns-north-korean-nuclear-test](https://www.foxnews.com/world/iaea-chief-make-trip-south-korea-amid-concerns-north-korean-nuclear-test)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 15:23:20+00:00

International Atomic Energy Agency Director General Rafael Grossi will make a trip to South Korea amid concerns that North Korea could soon hold a nuclear test.

## FDA warns that LASIK surgery patients need to be better informed of risks before eye procedure
 - [https://www.foxnews.com/health/fda-warns-lasik-surgery-patients-need-better-informed-risks-eye-procedure](https://www.foxnews.com/health/fda-warns-lasik-surgery-patients-need-better-informed-risks-eye-procedure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 15:23:04+00:00

The FDA released draft guidance on LASIK surgery, noting that patients considering the eye surgery should get a "decision checklist" describing the procedure, plus a list of potential side effects.

## Massachusetts library will display Christmas trees after controversy turned 'neighbor against neighbor'
 - [https://www.foxnews.com/us/massachusetts-library-will-display-christmas-trees-controversy-turned-neighbor-against-neighbor](https://www.foxnews.com/us/massachusetts-library-will-display-christmas-trees-controversy-turned-neighbor-against-neighbor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 15:18:14+00:00

Dedham, Massachusetts, town officials are calling on residents to stop "bullying" their neighbors over a local public library's decision to not display a Christmas tree this year.

## Elon Musk teases new Fauci revelations in future Twitter files installment
 - [https://www.foxnews.com/media/elon-musk-teases-new-fauci-revelations-future-twitter-files-installment](https://www.foxnews.com/media/elon-musk-teases-new-fauci-revelations-future-twitter-files-installment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 14:57:38+00:00

Elon Musk teased the prospect of new information on NIAID director Dr. Anthony Fauci getting released in a future installment of the "Twitter files."

## Hotel in Afghanistan's capitol attacked, 21 reported dead
 - [https://www.foxnews.com/world/hotel-afghanistans-capitol-attacked-21-reported-dead](https://www.foxnews.com/world/hotel-afghanistans-capitol-attacked-21-reported-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 14:53:47+00:00

A hotel was attacked in Kabul, Afghanistan, on Monday. Two of the residents were injured and the hospital in Kabul has reported 21 casualties.

## Georgia city's longtime mayor and wife killed in DUI car crash
 - [https://www.foxnews.com/us/georgia-citys-longtime-mayor-wife-killed-dui-car-crash](https://www.foxnews.com/us/georgia-citys-longtime-mayor-wife-killed-dui-car-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 14:53:08+00:00

The driver of a pickup truck lost control and swerved into oncoming traffic, killing Georgia city's mayor and his wife. Officers charged the driver with driving under the influence.

## 2 Australian police officers, bystander fatally shot in Queensland ambush
 - [https://www.foxnews.com/world/2-australian-police-officers-bystander-fatally-shot-queensland-ambush](https://www.foxnews.com/world/2-australian-police-officers-bystander-fatally-shot-queensland-ambush)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 14:41:13+00:00

Two gunman opened fire on police killing two officers and a bystander in Queensland, Australia. The two gunman remain on the run and have been tracking police.

## Kansas man charged in 1980 fatal shooting of nursing student
 - [https://www.foxnews.com/us/kansas-man-charged-1980-fatal-shooting-nursing-student](https://www.foxnews.com/us/kansas-man-charged-1980-fatal-shooting-nursing-student)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 14:38:03+00:00

A Kansas man has been charged in the 1980 fatal shooting of a nursing student. Steven Hanks was charged of second-degree murder and jailed on a $500,000 bond with no attorney.

## 3 bald eagles die, 10 sickened in Minnesota after likely eating euthanized animals dumped at landfill
 - [https://www.foxnews.com/us/bald-eagles-die-sickened-minnesota-likely-eating-euthanized-animals-dumped-landfill](https://www.foxnews.com/us/bald-eagles-die-sickened-minnesota-likely-eating-euthanized-animals-dumped-landfill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 14:35:57+00:00

Ten bald eagles likely poisoned after scavenging on the carcasses of euthanized animals are expected to recover, the University of Minnesota Raptor Center said.

## How to find your lost iPhone
 - [https://www.foxnews.com/tech/how-find-your-lost-iphone](https://www.foxnews.com/tech/how-find-your-lost-iphone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 14:29:30+00:00

Kurt "CyberGuy" Knutsson gives a step-by-step "Find my iPhone" settings setup that you can do on your iPhone so you aren't scrambling when you lose your device.

## Maryland police find pregnant woman dead in apartment of shooting suspect
 - [https://www.foxnews.com/us/maryland-police-find-pregnant-woman-dead-apartment-shooting-suspect](https://www.foxnews.com/us/maryland-police-find-pregnant-woman-dead-apartment-shooting-suspect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 14:28:43+00:00

Maryland police found a dead woman in the apartment of a shooting suspect. Police entered Torrey Moore's apartment with a search warrant, found the body and took him into custody.

## Michael Jordan remembers Paul Silas as 'incredible leader and motivator' in touching statement
 - [https://www.foxnews.com/sports/michael-jordan-remembers-paul-silas-incredible-leader-motivator-touching-statement](https://www.foxnews.com/sports/michael-jordan-remembers-paul-silas-incredible-leader-motivator-touching-statement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 14:22:36+00:00

Michael Jordan, the NBA legend and current chairman of the Charlotte Hornets, released a heartwarming statement on Paul Silas following his death.

## 13 bald eagles poisoned after eating the carcasses of euthanized animals in Minnesota landfill, 3 have died
 - [https://www.foxnews.com/us/13-bald-eagles-poisoned-eating-carcasses-euthanized-animals-minnesota-landfill-3-died](https://www.foxnews.com/us/13-bald-eagles-poisoned-eating-carcasses-euthanized-animals-minnesota-landfill-3-died)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 14:20:54+00:00

Nearly 13 bald eagles where poisoned after eating the carcasses of euthanized animals at a landfill in Minnesota. The landfill workers didn't dispose of the carcasses correctly.

## Trump says he 'turned down a deal' with Russia to exchange Viktor Bout for Paul Whelan
 - [https://www.foxnews.com/politics/trump-says-he-turned-down-deal-russia-exchange-viktor-bout-paul-whelan](https://www.foxnews.com/politics/trump-says-he-turned-down-deal-russia-exchange-viktor-bout-paul-whelan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 13:57:45+00:00

Former President Donald Trump has written on his Truth Social account that he turned down a deal with Russia to swap Viktor Bout for captive American Paul Whelan.

## South Dakota State Patrol identifies 2 people who died after a pickup truck collided with a train
 - [https://www.foxnews.com/us/south-dakota-state-patrol-identifies-2-people-died-after-pickup-truck-collided-train](https://www.foxnews.com/us/south-dakota-state-patrol-identifies-2-people-died-after-pickup-truck-collided-train)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 13:55:47+00:00

Two people who died when a pickup truck collided with a train in South Dakota have been identified. The driver of the truck sustained life-threatening injuries.

## Mike Leach's epic rants and clever quips remembered as Mississippi State coach battles health issue
 - [https://www.foxnews.com/sports/mike-leachs-epic-rants-clever-quips-remembered-mississippi-state-coach-battles-health-issue](https://www.foxnews.com/sports/mike-leachs-epic-rants-clever-quips-remembered-mississippi-state-coach-battles-health-issue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 13:53:23+00:00

Mississippi State football coach Mike Leach's epic rants were remembered as the college football world prayed for his health amid his transfer to a hospital on Sunday.

## Second World Cup journalist 'died suddenly' after Grant Wahl passes away: report
 - [https://www.foxnews.com/sports/second-world-cup-journalist-died-suddenly-grant-wahl-passes-away-report](https://www.foxnews.com/sports/second-world-cup-journalist-died-suddenly-grant-wahl-passes-away-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 13:36:00+00:00

Khalid al-Misslam, a Qatari, was a photojournalist for Al Kass TV reportedly "died suddenly" when he was covering the World Cup just hours after Grant Wahl died.

## NY Times ridiculed for using shotgun shell photo to promote article attacking AR-15s: ‘This is hysterical’
 - [https://www.foxnews.com/media/ny-times-ridiculed-using-shotgun-shell-photo-promote-article-attacking-ar-15s-hysterical](https://www.foxnews.com/media/ny-times-ridiculed-using-shotgun-shell-photo-promote-article-attacking-ar-15s-hysterical)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 13:00:35+00:00

The New York Times was ridiculed over the weekend by social media users for using a photo of shotgun shells in an opinion piece attacking the AR-15 as part of “toxic gun culture.”

## A Christmas prayer for Oklahoma and our nation
 - [https://www.foxnews.com/opinion/a-prayer-for-oklahoma-and-our-nation](https://www.foxnews.com/opinion/a-prayer-for-oklahoma-and-our-nation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 13:00:29+00:00

Please help our family to not get lost this December in the packages and prices, yet forget the reason we have so much to celebrate this Christmas.

## Broncos' Jerry Jeudy screams at official, bumps into him during outburst
 - [https://www.foxnews.com/sports/broncos-jerry-jeudy-screams-official-bumps-outburst](https://www.foxnews.com/sports/broncos-jerry-jeudy-screams-official-bumps-outburst)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 12:56:02+00:00

Jerry Jeudy had three touchdowns in the Denver Broncos' close loss to the Kansas City Chiefs but his day nearly ended early due to an outburst in the second quarter.

## Mike Leach's health issue sparks outpouring of prayers for Mississippi State coach
 - [https://www.foxnews.com/sports/mike-leachs-health-issue-sparks-outpouring-prayers-mississippi-state-coach](https://www.foxnews.com/sports/mike-leachs-health-issue-sparks-outpouring-prayers-mississippi-state-coach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 12:18:50+00:00

The college football world sent their thoughts and prayers for Mississippi State head coach Mike Leach on Sunday as the school said he was hospitalized with a "personal health issue."

## Kyrsten Sinema's switch to independent described as 'gut punch' to Democrats: ‘No wiggle room’
 - [https://www.foxnews.com/media/kyrsten-sinema-becoming-independent-described-gut-punch-democrats](https://www.foxnews.com/media/kyrsten-sinema-becoming-independent-described-gut-punch-democrats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 12:00:19+00:00

Lawmakers and political pundits react on Sunday to the surprising news that Arizona Sen. Kyrsten Sinema is leaving the Democratic Party to become an independent.

## NFL legend Jerry Rice has stern message for 49ers coaches after Deebo Samuel injury
 - [https://www.foxnews.com/sports/nfl-legend-jerry-rice-has-stern-message-for-49ers-coaches-after-deebo-samuel-injury](https://www.foxnews.com/sports/nfl-legend-jerry-rice-has-stern-message-for-49ers-coaches-after-deebo-samuel-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 11:46:37+00:00

NFL legend Jerry Rice had criticism for the San Francisco 49ers' coaching staff after Deebo Samuel went down with an injury on Sunday night.

## Christmas tree quiz! See how well you know these famous Christmas trees and more
 - [https://www.foxnews.com/lifestyle/christmas-tree-quiz-see-well-know-famous-christmas-trees](https://www.foxnews.com/lifestyle/christmas-tree-quiz-see-well-know-famous-christmas-trees)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 11:45:27+00:00

The 2022 holiday season is here. Get in the holiday spirit by taking this lifestyle quiz featuring fun facts about some of the world's most famous Christmas trees.

## Brittney Griner dunks in first workout since Russia arrest, WNBA future unclear, agent says
 - [https://www.foxnews.com/sports/brittney-griner-dunks-first-workout-russia-arrest-wnba-future-unclear-agent-says](https://www.foxnews.com/sports/brittney-griner-dunks-first-workout-russia-arrest-wnba-future-unclear-agent-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 11:44:10+00:00

Brittney Griner was back in the U.S. and resting up as she was returned in a 1-for-1 prisoner swap with Russian arms dealer Viktor Bout and her agent shed some light on her doings.

## Steelers' Mike Tomlin unclear on sequence that led to Kenny Pickett being removed from game
 - [https://www.foxnews.com/sports/steelers-mike-tomlin-unclear-sequence-led-kenny-pickett-being-removed-game](https://www.foxnews.com/sports/steelers-mike-tomlin-unclear-sequence-led-kenny-pickett-being-removed-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 11:40:00+00:00

Pittsburgh Steelers quarterback Kenny Pickett was whipped down to the ground against the Baltimore Ravens and later left the game as he entered concussion protocol.

## Dems' growing defection problem, Buttigieg flies private while pushing green agenda and more top headlines
 - [https://www.foxnews.com/us/kyrsten-sinema-latest-democrat-to-exit-party-despite-midterm-wins](https://www.foxnews.com/us/kyrsten-sinema-latest-democrat-to-exit-party-despite-midterm-wins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 11:33:53+00:00

JUMPING SHIP - Democrats appear to have a defection problem despite midterm success

## Bible verse of the day: God uses our troubles 'to pave the way for something greater'
 - [https://www.foxnews.com/lifestyle/bible-verse-day-god-uses-troubles-pave-way-something-greater](https://www.foxnews.com/lifestyle/bible-verse-day-god-uses-troubles-pave-way-something-greater)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 11:00:29+00:00

Jeremiah 29:11 in the Old Testament is described here; Rabbi Pinchas Taylor of Plantation, Florida, explains the meaning of the Bible verse: God will use our trials to lead us into more blessings.

## My husband Frank Perdue had an 'ethical will.' Here's why you need one, too.
 - [https://www.foxnews.com/opinion/husband-frank-perdue-ethical-will-you-need-one](https://www.foxnews.com/opinion/husband-frank-perdue-ethical-will-you-need-one)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 11:00:07+00:00

Many people knew and admired Frank Perdue the businessman. But what impressed me, his wife, most about him was how he was, to the core, a family man.

## Melania Trump shares Christmas 'magic,' message of 'hope and compassion' at foster care holiday celebration
 - [https://www.foxnews.com/media/melania-trump-shares-christmas-magic-message-hope-compassion-foster-care-holiday-celebration](https://www.foxnews.com/media/melania-trump-shares-christmas-magic-message-hope-compassion-foster-care-holiday-celebration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 11:00:05+00:00

As a 'Fostering the Future' initiative, former President Donald Trump and First Lady Melania Trump spread Christmas cheer to foster families with a special holiday celebration.

## Idaho victim’s family raising funds for reward money as campus murder mystery enters week 4 with no arrests
 - [https://www.foxnews.com/us/idaho-victims-family-raising-funds-reward-money-campus-murder-mystery-enters-week-4-no-arrests](https://www.foxnews.com/us/idaho-victims-family-raising-funds-reward-money-campus-murder-mystery-enters-week-4-no-arrests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 10:27:13+00:00

Kaylee Goncalves' family is looking to raise money to offer as a reward for information that leads to an arrest in the University of Idaho quadruple homicide.

## Kirk Cameron pushes public libraries for story-hour reading slot: 'Prepared to assert my rights in court'
 - [https://www.foxnews.com/lifestyle/kirk-cameron-pushes-public-libraries-story-hour-reading-assert-rights-court](https://www.foxnews.com/lifestyle/kirk-cameron-pushes-public-libraries-story-hour-reading-assert-rights-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 10:00:58+00:00

Kirk Cameron, actor and writer, told Fox News Digital he is pushing back on public library rejections of his proposed story-hour reading connected to "As You Grow," a new children's book.

## Twitter users applaud Elon Musk getting 'political' to save the 'future of civilization:' ‘Must be done’
 - [https://www.foxnews.com/media/twitter-users-applaud-elon-musk-getting-political-save-future-civilization](https://www.foxnews.com/media/twitter-users-applaud-elon-musk-getting-political-save-future-civilization)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 10:00:26+00:00

Elon Musk has faced increasing criticism as he has waded into the political battle over free speech, but he declared on Twitter why the battle is so essential for humanity.

## Iran executed second detainee over anti-theocracy protest
 - [https://www.foxnews.com/world/iran-executed-second-detainee-over-anti-theocracy-protest](https://www.foxnews.com/world/iran-executed-second-detainee-over-anti-theocracy-protest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 09:55:57+00:00

Iran executed a second prisoner who was detained during protests against the country's theocracy. The hanging came quickly after his alleged stabbings.

## Ken DeLand missing: American college student disappears in France while studying abroad
 - [https://www.foxnews.com/world/ken-deland-missing-american-college-student-disappears-france-studying-abroad](https://www.foxnews.com/world/ken-deland-missing-american-college-student-disappears-france-studying-abroad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 09:18:13+00:00

An American college student has been reported missing while studying abroad in France. He last made contact with his family on Whatsapp on November 27.

## Are Putin and Zelenskyy near to ending Russia-Ukraine war?
 - [https://www.foxnews.com/opinion/putin-zelenskyy-near-ending-russia-ukraine-war](https://www.foxnews.com/opinion/putin-zelenskyy-near-ending-russia-ukraine-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 09:00:30+00:00

It makes sense that the Russia-Ukraine conflict can't continue indefinitely and must come to an end. What are the motivations for the 3 key stakeholders — Moscow, Kyiv and Washington?

## COVID-related hospitalizations increasing among US seniors
 - [https://www.foxnews.com/health/covid-related-hospitalizations-increasing-among-us-seniors](https://www.foxnews.com/health/covid-related-hospitalizations-increasing-among-us-seniors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 08:14:12+00:00

U.S. hospitals are seeing a rise in COVID-19-related admissions, and the older population is accounting for a growing percentage of national deaths.

## Pete Buttigieg often flies on taxpayer-funded private jets, flight data show
 - [https://www.foxnews.com/politics/pete-buttigieg-flies-taxpayer-funded-private-jets-flight-data-show](https://www.foxnews.com/politics/pete-buttigieg-flies-taxpayer-funded-private-jets-flight-data-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 07:00:59+00:00

Biden Transportation Secretary Pete Buttigieg has used taxpayer-funded private jets at least 18 times since taking office, a practice that resulted in a Trump administration resignation.

## Progressive teachers vs conservative families: School choice can help level the playing field
 - [https://www.foxnews.com/opinion/progressive-teachers-conservative-families-school-choice-level-playing-field](https://www.foxnews.com/opinion/progressive-teachers-conservative-families-school-choice-level-playing-field)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 07:00:54+00:00

There is a growing disconnect between the values and priorities of America’s public education system and the families that system is supposed to serve. Rural Texas is a good example.

## Tech guru slams Twitter shadow banning as ‘one step away from George Orwell's Thought Police’
 - [https://www.foxnews.com/media/tech-guru-slams-twitter-shadow-banning-as-one-step-away-from-george-orwells-thought-police](https://www.foxnews.com/media/tech-guru-slams-twitter-shadow-banning-as-one-step-away-from-george-orwells-thought-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 07:00:41+00:00

Datagrade CEO Joe Toscano feels the shadow banning exposed by Elon Musk's so-called "Twitter Files" is “one step away” from George Orwell's Thought Police from “1984.”

## Like Celine Dion, Pennsylvania man is fighting Stiff Person Syndrome 'with everything I have’
 - [https://www.foxnews.com/lifestyle/celine-dion-pennsylvania-man-fighting-stiff-person-syndrome-everything-have](https://www.foxnews.com/lifestyle/celine-dion-pennsylvania-man-fighting-stiff-person-syndrome-everything-have)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 07:00:18+00:00

Celine Dion recently announced she has SPS, or Stiff Person Syndrome. A Pennsylvania resident told Fox News Digital that he, too, suffers from the rare disease — and revealed details.

## Oregon police worry gun permit requirement, magazine limits may include officers
 - [https://www.foxnews.com/us/oregon-police-worry-gun-permit-requirement-magazine-limits-include-officers](https://www.foxnews.com/us/oregon-police-worry-gun-permit-requirement-magazine-limits-include-officers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 07:00:17+00:00

Police don't know if they will need a permit to buy service weapons under Oregon's gun control law or whether the magazine limit will bar them from carrying off duty.

## Retention issues? Political strategists weigh in on recent departures from the Democratic Party
 - [https://www.foxnews.com/politics/retention-issues-political-strategists-weigh-recent-departures-democratic-party](https://www.foxnews.com/politics/retention-issues-political-strategists-weigh-recent-departures-democratic-party)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 07:00:04+00:00

Despite a great deal of success in the 2022 midterm cycle, at least three elected Democrats recently announced they were leaving the Democratic Party.

## Turkey's pending Syria invasion motivated by politics, not security concerns, experts say
 - [https://www.foxnews.com/world/turkeys-pending-syria-invasion-motivated-politics-security-concerns-experts-say](https://www.foxnews.com/world/turkeys-pending-syria-invasion-motivated-politics-security-concerns-experts-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 07:00:04+00:00

Turkish President Recep Tayyip Erdogan has recently indicated a willingness to improve relations with Syria, which possibly could be a result of Russian encouragement.

## Meghan Markle, Harry's doc filled with ‘inconsistencies’: 'Nothing in their story stands up,' expert says
 - [https://www.foxnews.com/entertainment/meghan-markle-harry-doc-filled-inconsistencies-nothing-in-their-story-stands-up-expert](https://www.foxnews.com/entertainment/meghan-markle-harry-doc-filled-inconsistencies-nothing-in-their-story-stands-up-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 07:00:01+00:00

Prince Harry and Meghan Markle's docuseries debuted Friday, and royal expert Neil Sean says their stories have "so many inconsistencies," including how the Sussexes first met.

## Florida firefighters save eagle speared by lightning rod atop elementary school's radio tower
 - [https://www.foxnews.com/us/florida-firefighters-save-eagle-speared-lightning-rod-atop-elementary-schools-radio-tower](https://www.foxnews.com/us/florida-firefighters-save-eagle-speared-lightning-rod-atop-elementary-schools-radio-tower)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 05:16:22+00:00

The MacClenny Fire Rescue Department rescued an eagle that was impaled by a lightning rod atop a radio tower at a Florida elementary school.

## Texas sees over 2,500 migrants cross the border in mere 24-hour span
 - [https://www.foxnews.com/us/texas-sees-over-2500-migrants-cross-border-mere-24-hour-span](https://www.foxnews.com/us/texas-sees-over-2500-migrants-cross-border-mere-24-hour-span)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 05:12:14+00:00

Hundreds of migrants crossed illegally into Texas, through the southern border. A massive line of migrants was seen waiting to be taken into custody.

## On this day in history, Dec. 12, 1901, Guglielmo Marconi sends first transatlantic radio message
 - [https://www.foxnews.com/lifestyle/this-day-history-dec-12-1901-guglielmo-marconi-sends-first-transatlantic-radio-message](https://www.foxnews.com/lifestyle/this-day-history-dec-12-1901-guglielmo-marconi-sends-first-transatlantic-radio-message)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 05:02:55+00:00

Guglielmo Marconi sent the first transatlantic radio transmission on Dec. 12, 1901, ushering in an era of communications. His invention helped save 700 Titanic passengers.

## Minnesota pastor faces criminal sexual conduct charges for relationship with teen
 - [https://www.foxnews.com/us/minnesota-pastor-faces-criminal-sexual-conduct-charges-relationship-teen](https://www.foxnews.com/us/minnesota-pastor-faces-criminal-sexual-conduct-charges-relationship-teen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 04:54:12+00:00

A 36-year-old Minnesota pastor is facing multiple counts of criminal sexual conduct with a female teenager. He was booked in Dodge County jail.

## Justin Herbert flourishes in the spotlight, leads Chargers to crucial win over Dolphins
 - [https://www.foxnews.com/sports/justin-herbert-flourishes-spotlight-leads-chargers-crucial-win-dolphins](https://www.foxnews.com/sports/justin-herbert-flourishes-spotlight-leads-chargers-crucial-win-dolphins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 04:43:08+00:00

Justin Herbert and the Los Angeles Chargers picked up a crucial win over the Miami Dolphins 23-17 on Sunday night behind 367 passing yards and a touchdown.

## NFL fans upset as Dolphins flagged for roughing the passer on Justin Herbert hit
 - [https://www.foxnews.com/sports/nfl-fans-upset-dolphins-flagged-roughing-passer-justin-herbert-hit](https://www.foxnews.com/sports/nfl-fans-upset-dolphins-flagged-roughing-passer-justin-herbert-hit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 03:46:04+00:00

NFL fans watching the Los Angeles Chargers and Miami Dolphins game on Sunday were upset with a roughing the passer call on a Justin Herbert tackle.

## Liberalism is designed to 'destroy the nuclear family:' Mark Levin
 - [https://www.foxnews.com/media/liberalism-designed-destroy-nuclear-family-mark-levin](https://www.foxnews.com/media/liberalism-designed-destroy-nuclear-family-mark-levin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 03:25:34+00:00

Mark Levin had a monologue exploring the disturbing parallels between what the Communist Manifesto was proposing more than a century ago and what is enforced now.

## Hawks' AJ Griffin delivers buzzer-beater with 0.5 seconds left to stun Bulls
 - [https://www.foxnews.com/sports/hawks-aj-griffin-delivers-buzzer-beater-0-5-seconds-left-stun-bulls](https://www.foxnews.com/sports/hawks-aj-griffin-delivers-buzzer-beater-0-5-seconds-left-stun-bulls)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 03:02:13+00:00

AJ Griffin delivered a stunning buzzer-beater to give the Atlanta Hawks a 123-122 win in overtime in one of the wildest games of the NBA season.

## Dolphins' Tyreek Hill scores touchdown on chaotic fumble recovery vs. Chargers
 - [https://www.foxnews.com/sports/dolphins-tyreek-hill-scores-touchdown-chaotic-fumble-recovery-vs-chargers](https://www.foxnews.com/sports/dolphins-tyreek-hill-scores-touchdown-chaotic-fumble-recovery-vs-chargers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 02:49:33+00:00

Miami Dolphins wide receiver Tyreek Hill made the most of being in the right place at the right time against the Los Angeles Chargers on Sunday.

## 49ers' Dre Greenlaw gets Tom Brady to autograph ball after interception: 'You’re the greatest ever'
 - [https://www.foxnews.com/sports/49ers-dre-greenlaw-gets-tom-brady-autograph-ball-interception-greatest-ever](https://www.foxnews.com/sports/49ers-dre-greenlaw-gets-tom-brady-autograph-ball-interception-greatest-ever)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 02:43:20+00:00

San Francisco 49ers linebacker Dre Greenlaw had a moment he will never forget: he intercepted a ball from Tom Brady and then got him to autograph it.

## Rep. Bacon 'guarantees' McCarthy has more support for speaker now than in November, urges GOP to be a 'team'
 - [https://www.foxnews.com/media/rep-bacon-guarantees-mccarthy-more-support-speaker-now-november-urges-gop-team](https://www.foxnews.com/media/rep-bacon-guarantees-mccarthy-more-support-speaker-now-november-urges-gop-team)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 02:28:22+00:00

Rep. Don Bacon joined “Sunday Night in America" to call on GOP lawmakers "holding out" on their support for Minority Leader Kevin McCarthy's bid for speaker to come together as a "team."

## 49ers' Deebo Samuel likely suffered high-ankle sprain vs. Bucs, Kyle Shanahan says
 - [https://www.foxnews.com/sports/49ers-deebo-samuel-likely-suffered-high-ankle-sprain-vs-bucs-kyle-shanahan-says](https://www.foxnews.com/sports/49ers-deebo-samuel-likely-suffered-high-ankle-sprain-vs-bucs-kyle-shanahan-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 02:20:17+00:00

Deebo Samuel may have avoided the worst when he suffered an ankle injury in Sunday's win over the Tampa Bay Buccaneers, but he's expected to miss some time.

## 49ers' Brock Purdy talks playing against Tom Brady after win: 'It’s literally a dream come true'
 - [https://www.foxnews.com/sports/49ers-brock-purdy-talks-playing-against-tom-brady-win-literally-dream-come-true](https://www.foxnews.com/sports/49ers-brock-purdy-talks-playing-against-tom-brady-win-literally-dream-come-true)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 02:07:35+00:00

Brock Purdy scored three touchdowns in San Francisco's 35-7 win over the Tampa Bay Buccaneers. He talked about the victory after the game.

## Los Angeles mayor to declare homeless state of emergency
 - [https://www.foxnews.com/us/los-angeles-mayor-declare-homeless-state-emergency](https://www.foxnews.com/us/los-angeles-mayor-declare-homeless-state-emergency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 01:57:49+00:00

Newly sworn in Los Angeles Mayor Karen Bass announced plans to declare a state of emergency on the homeless crisis in the city, where over 40,000 people sleep on the streets.

## Panthers' Terrace Marshall Jr. makes incredible leg catch as Carolina uses lucky breaks to pick up win
 - [https://www.foxnews.com/sports/panthers-terrace-marshall-jr-makes-incredible-leg-catch-carolina-uses-lucky-breaks-pick-up-win](https://www.foxnews.com/sports/panthers-terrace-marshall-jr-makes-incredible-leg-catch-carolina-uses-lucky-breaks-pick-up-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 01:11:30+00:00

Carolina Panthers absolutely needed a victory on Sunday and it came against the Seattle Seahawks. The Panthers defeated the Seahawks, 30-24.

## Pennsylvania school board member refuses to vote for 'cis White male' for president: 'wrong message'
 - [https://www.foxnews.com/us/pennsylvania-school-board-member-refuses-vote-for-cis-white-male-wrong-message](https://www.foxnews.com/us/pennsylvania-school-board-member-refuses-vote-for-cis-white-male-wrong-message)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 01:05:52+00:00

A Pennsylvania school board member refused to give her vote to the only white cis male on the board, for president, saying it sends the wrong message to the community.

## 49ers' Brock Purdy breaks out in win over Bucs, hits historic milestone in beating Tom Brady
 - [https://www.foxnews.com/sports/49ers-brock-purdy-breaks-out-win-over-bucs-hits-historic-milestone-beating-tom-brady](https://www.foxnews.com/sports/49ers-brock-purdy-breaks-out-win-over-bucs-hits-historic-milestone-beating-tom-brady)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 00:57:57+00:00

Brock Purdy and the San Francisco 49ers exploded for 28 points in the first half and didn't look back against the Tampa Bay Buccaneers on Sunday.

## Chiefs stave off Broncos rally for win, pick up 14th straight win over Denver
 - [https://www.foxnews.com/sports/chiefs-stave-off-broncos-rally-for-win-pick-up-14th-straight-win-denver](https://www.foxnews.com/sports/chiefs-stave-off-broncos-rally-for-win-pick-up-14th-straight-win-denver)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 00:41:52+00:00

Patrick Mahomes and the Kansas City Chiefs needed to buckle down to avoid the Denver Broncos' comeback attempt — and they did just that Sunday.

## Jaguars snap ugly losing streak to Titans behind Trevor Lawrence's 4 touchdowns
 - [https://www.foxnews.com/sports/jaguars-snap-ugly-losing-streak-titans-trevor-lawrences-4-touchdowns](https://www.foxnews.com/sports/jaguars-snap-ugly-losing-streak-titans-trevor-lawrences-4-touchdowns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 00:30:57+00:00

Trevor Lawrence had three touchdown passes and the Jacksonville Jaguars snapped a losing streak to the Tennessee Titans on Sunday in the AFC South matchup.

## Chevy Chase, Christie Brinkley and Beverly D'Angelo enjoy 'National Lampoon's Vacation' reunion
 - [https://www.foxnews.com/entertainment/chevy-chase-christie-brinkley-beverly-dangelo-national-lampoons-vacation-reunion](https://www.foxnews.com/entertainment/chevy-chase-christie-brinkley-beverly-dangelo-national-lampoons-vacation-reunion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 00:28:37+00:00

"National Lampoon's Vacation" stars Chevy Chase, Beverly D'Angelo and Christie Brinkley reunited at a comic con almost 40 years after the comedy was released.

## Jan. 6 Committee hearings declared 'most important TV of the year' by the New York Times
 - [https://www.foxnews.com/media/jan-6-committee-hearings-declared-most-important-tv-year-new-york-times](https://www.foxnews.com/media/jan-6-committee-hearings-declared-most-important-tv-year-new-york-times)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 00:23:25+00:00

New York Times TV critic called the January 6 Committee hearings some of the best television of this year, praising the hearings as the "show of the summer."

## Bills' Josh Allen guides team to big AFC divisional win vs. Jets
 - [https://www.foxnews.com/sports/buffalo-bills-josh-allen-guides-big-afc-divisional-win-new-york-jets](https://www.foxnews.com/sports/buffalo-bills-josh-allen-guides-big-afc-divisional-win-new-york-jets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-12 00:07:01+00:00

Josh Allen had two touchdowns, including one to Dawson Knox, as the Buffalo Bills defeated the New York Jets, 20-12, on Sunday afternoon.


# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Polska przeciw unijnemu podatkowi dla największych podmiotów gospodarczych
 - [https://www.bankier.pl/wiadomosc/Polska-przeciw-unijnemu-podatkowi-dla-najwiekszych-podmiotow-gospodarczych-8455506.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-przeciw-unijnemu-podatkowi-dla-najwiekszych-podmiotow-gospodarczych-8455506.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 23:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/e/013f0af24d0c28-948-568-0-0-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska, podnosząc zastrzeżenia, zablokowała na posiedzeniu państw członkowskich w Brukseli wprowadzenie 15-procentowego podatku na największe światowe podmioty gospodarcze - przekazało PAP źródło unijne. "Sprawa będzie dalej procedowana w najbliższych dniach" - dodało źródło.</p>

## Węgry odblokowały weto wobec 18 mld euro wsparcia UE dla Ukrainy
 - [https://www.bankier.pl/wiadomosc/Wegry-odblokowaly-weto-wobec-18-mld-euro-wsparcia-UE-dla-Ukrainy-8455504.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wegry-odblokowaly-weto-wobec-18-mld-euro-wsparcia-UE-dla-Ukrainy-8455504.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 23:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/a7e847f30e83da-948-568-8-39-1764-1058.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Węgry w poniedziałek wieczorem odblokowały weto wobec 18 mld euro wsparcia makrofinansowego UE dla Ukrainy – przekazało PAP źródło unijne.</p>

## G7 zapowiada pociągnięcie Putina do odpowiedzialności za inwazję na Ukrainę
 - [https://www.bankier.pl/wiadomosc/G7-zapowiada-pociagniecie-Putina-do-odpowiedzialnosci-za-inwazje-na-Ukraine-8455500.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/G7-zapowiada-pociagniecie-Putina-do-odpowiedzialnosci-za-inwazje-na-Ukraine-8455500.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 22:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/5/0f5eb4bc12b321-948-568-0-202-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W komunikacie wydanym w poniedziałek na zakończenie wirtualnego szczytu G7 z udziałem prezydenta Ukrainy Wołodymyra Zełenskiego przywódcy państw grupy ogłosili, że pociągną rosyjskiego dyktatora Władimira Putina do odpowiedzialności za inwazję na Ukrainę.</p>

## Wall Street w górę w oczekiwaniu na Fed i inflację
 - [https://www.bankier.pl/wiadomosc/Wall-Street-w-gore-w-oczekiwaniu-na-Fed-i-inflacje-8455484.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wall-Street-w-gore-w-oczekiwaniu-na-Fed-i-inflacje-8455484.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 21:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/1/a85a55b37625ef-948-568-15-100-1985-1190.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poniedziałkowa sesja za Atlantykiem przyniosła solidne
wzrosty głównych giełdowych indeksów.</p>

## Zmarł Mirosław Hermaszewski - pierwszy polski astronauta
 - [https://www.bankier.pl/wiadomosc/Zmarl-Miroslaw-Hermaszewski-pierwszy-polski-astronauta-8455434.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zmarl-Miroslaw-Hermaszewski-pierwszy-polski-astronauta-8455434.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 19:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/9/d6eded9bd1c2b6-948-568-0-221-1303-781-GR.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zmarł Mirosław Hermaszewski - pierwszy polski astronauta - podał Ryszard Czarnecki, zięć generała. Miał 81 lat.</p>

## Zełenski: Wojna na Ukrainie skończy się, gdy umrze Władimir Putin
 - [https://www.bankier.pl/wiadomosc/Zelenski-Wojna-na-Ukrainie-skonczy-sie-gdy-umrze-Wladimir-Putin-8455412.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zelenski-Wojna-na-Ukrainie-skonczy-sie-gdy-umrze-Wladimir-Putin-8455412.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 18:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/9/cea22616a907df-948-568-0-55-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wierzę, że wojna skończy się wówczas, gdy umrze Władimir Putin - powiedział w poniedziałek prezydent Ukrainy Wołodymyr Zełenski w wywiadzie udzielonym Davidowi Lettermanowi, znanemu amerykańskiemu prezenterowi telewizyjnemu.</p>

## "Rosjanie zaczynają wcielać kobiety do wojska"
 - [https://www.bankier.pl/wiadomosc/Rosjanie-zaczynaja-wcielac-kobiety-do-wojska-8455389.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosjanie-zaczynaja-wcielac-kobiety-do-wojska-8455389.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 17:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/f3bd0d6a44704e-948-568-57-0-1799-1079.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />1. Korpus Armii Rosyjskiej mobilizuje kobiety w celu uzupełnienia strat; pierwszych 28 kobiet zostało powołanych do wojska w Donbasie i wysłanych na szkolenie - poinformował w poniedziałek Sztab Generalny Sił Zbrojnych Ukrainy.</p>

## 2 mld euro od UE dla Ukrainy. "Jest polityczna zgoda na kolejny pakiet wsparcia"
 - [https://www.bankier.pl/wiadomosc/2-mld-euro-od-UE-dla-Ukrainy-Jest-polityczna-zgoda-na-kolejny-pakiet-wsparcia-8455387.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/2-mld-euro-od-UE-dla-Ukrainy-Jest-polityczna-zgoda-na-kolejny-pakiet-wsparcia-8455387.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 17:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/c/9e47ab560ed6c6-948-568-0-123-1768-1060.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Udało się uzyskać zgodę polityczną na kolejny pakiet wsparcia obrony Ukrainy z Europejskiego Instrumentu na rzecz Pokoju - 2 mld euro - powiedział w poniedziałek w Brukseli Paweł Jabłoński, wiceminister spraw zagranicznych po spotkaniu unijnych szefów dyplomacji.</p>

## Wzrosty na GPW u progu tygodnia z bankami centralnymi. Kurs Biomass Energy windą do góry
 - [https://www.bankier.pl/wiadomosc/Wzrosty-na-GPW-u-progu-tygodnia-z-bankami-centralnymi-Kurs-Biomass-Energy-winda-do-gory-8455335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wzrosty-na-GPW-u-progu-tygodnia-z-bankami-centralnymi-Kurs-Biomass-Energy-winda-do-gory-8455335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 17:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/0/62d855390f6cf3-945-560-540-540-3960-2375.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ostatni ważny dla inwestorów tydzień w roku rozpoczął się na
GPW od wzrostów. Ich skala na WIG20 uplasowała go w czołówce europejskich indeksów.
Popyt operował jednak przy niskich obrotach, co nie dziwi przed serią
zaplanowanych na ten tydzień danych makro i decyzji najważniejszych banków
centralnych.</p>

## Nestle zainwestuje 40 mln franków szwajcarskich w fabrykę na Ukrainie
 - [https://www.bankier.pl/wiadomosc/Nestle-zainwestuje-40-mln-frankow-szwajcarskich-w-fabryke-na-Ukrainie-8455323.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nestle-zainwestuje-40-mln-frankow-szwajcarskich-w-fabryke-na-Ukrainie-8455323.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 16:16:00+00:00

<p>Szwajcarski koncern spożywczy Nestle poinformował w poniedziałek, że zainwestuje 40 mln franków szwajcarskich w nową fabrykę na Ukrainie. "Chcemy zapewnić nowe miejsca pracy i służyć potrzebom Ukraińców i wszystkich obywateli Europy" - powiedział szef firmy na Wschodnią Europę Alessandro Zanelli.</p>

## Chiny luzują restrykcje covidowe. W szpitalach panuje chaos
 - [https://www.bankier.pl/wiadomosc/Chiny-luzuja-restrykcje-covidowe-W-szpitalach-panuje-chaos-8455304.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chiny-luzuja-restrykcje-covidowe-W-szpitalach-panuje-chaos-8455304.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 15:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/0/7cf39ea95a8931-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po rozluźnieniu surowych środków zapobiegania pandemii Covid-19 w Chinach szpitale w niektórych miastach mierzą się już z falą pacjentów z gorączką i z niedoborem pracowników medycznych – podał w poniedziałek chiński portal Caixin.</p>

## Wiceminister zdrowia: W Polsce nie istnieje ryzyko systemowego braku leków
 - [https://www.bankier.pl/wiadomosc/Wiceminister-zdrowia-W-Polsce-nie-istnieje-ryzyko-systemowego-braku-lekow-8455257.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiceminister-zdrowia-W-Polsce-nie-istnieje-ryzyko-systemowego-braku-lekow-8455257.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 14:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/9/425bcad0b06035-945-560-0-47-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sytuacja dostępności leków jest na bieżąco monitorowana przez Ministra Zdrowia oraz jednostki mu podległe i nie istnieje ryzyko systemowego braku leków w Polsce - przekazał w odpowiedzi do RPO wiceminister zdrowia Maciej Miłkowski.</p>

## Zakupy w sieci. Liczba użytkowników lidera spadła, konkurencja rośnie
 - [https://www.bankier.pl/wiadomosc/Liczba-uzytkownikow-allegro-pl-i-aplikacji-Allegro-spadla-w-XI-do-21-05-mln-z-21-3-mln-w-X-8455244.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Liczba-uzytkownikow-allegro-pl-i-aplikacji-Allegro-spadla-w-XI-do-21-05-mln-z-21-3-mln-w-X-8455244.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 14:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/579ba5370cd78d-948-568-0-34-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Liczba użytkowników allegro.pl i aplikacji Allegro 
spadła w listopadzie do 21 048 822 z 21 267 846 w październiku - wynika z
 danych Mediapanel Gemius Polska przygotowanych dla PAP Biznes.</p>

## Drogi gaz uderza w małe i średnie firmy. Rząd ma gotowy pakiet wsparcia, ale potrzebuje akceptu UE
 - [https://www.bankier.pl/wiadomosc/Drogi-gaz-uderza-w-male-i-srednie-firmy-Rzad-ma-gotowy-pakiet-wsparcia-ale-potrzebuje-akceptu-UE-8455215.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Drogi-gaz-uderza-w-male-i-srednie-firmy-Rzad-ma-gotowy-pakiet-wsparcia-ale-potrzebuje-akceptu-UE-8455215.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 14:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/f4725943fbbd7a-948-568-0-190-3464-2078.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będziemy w UE zabiegać o możliwość wsparcia małych i średnich firm wykorzystujących gaz - poinformowała minister klimatu i środowiska Anna Moskwa. Dodała, że będzie to wymagało długich rozmów. Zapewniła, że jest przygotowywany pakiet wsparcia, który mógłby być potencjalnie notyfikowany.</p>

## Belgia zamroziła najwięcej rosyjskich aktywów ze wszystkich państw UE
 - [https://www.bankier.pl/wiadomosc/Belgia-zamrozila-najwiecej-rosyjskich-aktywow-ze-wszystkich-panstw-UE-8455207.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Belgia-zamrozila-najwiecej-rosyjskich-aktywow-ze-wszystkich-panstw-UE-8455207.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 14:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/2/3e6483cd009bd6-948-568-0-312-1563-937.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Belgia zablokowała dotychczas 3,5 mld euro aktywów rosyjskich oligarchów i podmiotów z listy sankcyjnej, najwięcej ze wszystkich krajów Unii Europejskiej - wynika z informacji tamtejszych mediów. Łącznie 27 państw członkowskich zamroziło już 18,9 mld euro rosyjskich środków.</p>

## Państwowy dług publiczny na koniec III kw. wzrósł. Resort finansów podał dane
 - [https://www.bankier.pl/wiadomosc/Panstwowy-dlug-publiczny-na-koniec-III-kw-wzrosl-Resort-finansow-podal-dane-8455205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Panstwowy-dlug-publiczny-na-koniec-III-kw-wzrosl-Resort-finansow-podal-dane-8455205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 14:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/4f04b21fb9b64b-948-568-0-175-2606-1563.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Państwowy dług publiczny (PDP) na koniec III kw. 2022
 r. wyniósł 1.181.198,9 mln zł, co oznacza wzrost o 5.860,8 mln zł (+0,5
 proc.) w ujęciu kwartał do kwartału - podało Ministerstwo Finansów w 
komunikacie. W porównaniu z końcem 2021 r. PDP wzrósł o 32.619,9 mln zł 
(+2,8 proc.).</p>

## Prezydent Duda: Liczba uchodźców z Ukrainy wzrasta
 - [https://www.bankier.pl/wiadomosc/Prezydent-Duda-Liczba-uchodzcow-z-Ukrainy-wzrasta-8455203.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezydent-Duda-Liczba-uchodzcow-z-Ukrainy-wzrasta-8455203.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 14:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/3/9fd9a6f616ea43-948-568-13-22-1759-1055.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Liczba uchodźców z Ukrainy w Polsce wzrosła, obecnie jest ich ok. 3 mln; może to oznaczać wzrost liczby uchodźców także w Niemczech - powiedział w Berlinie prezydent Andrzej Duda. Z prezydentem RFN powinniśmy się zwracać do UE o specjalne wsparcie finansowe na pomoc uciekającym przed wojną - dodał.</p>

## Kolejne „ósemki” na lokatach. Ten bank wprowadza też depozyt walutowy
 - [https://www.bankier.pl/wiadomosc/PKO-BP-kolejne-podwyzki-na-lokatach-i-8-proc-8455182.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKO-BP-kolejne-podwyzki-na-lokatach-i-8-proc-8455182.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 13:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/e/1b58c04d71de36-948-567-0-27-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PKO Bank Polski zmodyfikował
ofertę depozytów. Dla nowych klientów wprowadził lokatę 3M na 8 proc. w skali roku.
"Ósemka" pojawiła się też w sześciomiesięcznej lokacie dostępnej w ramach Wyspecjalizowanego
Programu Inwestycyjnego „Autolokacja III”. Ponadto bank wprowadził nowy depozyt walutowy.</p>

## Mandat za nieodśnieżony samochód. Zimowe lenistwo słono kosztuje
 - [https://www.bankier.pl/wiadomosc/Mandat-za-nieodsniezony-samochod-Zimowe-lenistwo-slono-kosztuje-8455160.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mandat-za-nieodsniezony-samochod-Zimowe-lenistwo-slono-kosztuje-8455160.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 13:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/e/5a1c955f6fdf6b-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mazowieccy policjanci przypominają o obowiązku dokładnego odśnieżania samochodów przed jazdą. Warstwa lodu na szybach ogranicza widoczność, natomiast spadający śnieg, w wyniku poruszania się pojazdu, utrudnia jazdę innym kierowcom – podkreślają mundurowi.</p>

## Chiny ogłosiły koniec ogólnokrajowej covidowej aplikacji śledzącej
 - [https://www.bankier.pl/wiadomosc/Chiny-oglosily-koniec-ogolnokrajowej-covidowej-aplikacji-sledzacej-8455128.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chiny-oglosily-koniec-ogolnokrajowej-covidowej-aplikacji-sledzacej-8455128.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 13:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/d439fb91f0cf3f-948-568-15-140-1985-1190.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władze Chin ogłosiły w poniedziałek wstrzymanie działania ogólnokrajowej aplikacji śledzącej, której dotąd wymagano od podróżnych i przy wejściu do niektórych miejsc publicznych. Dla wielu jest to symbol łagodzenia surowych środków walki z pandemią Covid-19.</p>

## Kreml odwołał doroczną wielką konferencję prasową Putina
 - [https://www.bankier.pl/wiadomosc/Kreml-odwolal-doroczna-wielka-konferencje-prasowa-Putina-8455117.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kreml-odwolal-doroczna-wielka-konferencje-prasowa-Putina-8455117.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 12:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/9/3c3231d1978534-948-568-0-48-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W tym roku nie odbędzie się doroczna grudniowa konferencja prasowa prezydenta Rosji Władimira Putina – informują w poniedziałek media niezależne, powołując się na rzecznika Kremla. Pod znakiem zapytania stoi także organizacja tzw. gorącej linii z udziałem obywateli. Według mediów zależy to m.in. od sytuacji na froncie wojny na Ukrainie.</p>

## "Rynki szykują się na recesję, banki centralne będą kończyć cykl zacieśniania"
 - [https://www.bankier.pl/wiadomosc/Rynki-szykuja-sie-na-recesje-banki-centralne-beda-konczyc-cykl-zaciesniania-8455116.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rynki-szykuja-sie-na-recesje-banki-centralne-beda-konczyc-cykl-zaciesniania-8455116.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 12:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/1/48d06aa0abc905-948-568-0-354-4437-2662.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rok 2023 r. może upłynąć pod znakiem recesji w głównych światowych gospodarkach, choć nie jest jeszcze ostatecznie przesądzone w których - uważają uczestnicy XXIX debaty PAP Biznes „Strategie rynkowe TFI”. Główne banki centralne powoli kończą cykl zacieśniania polityki, choć mierzą się z różną sytuacją inflacyjną.</p>

## Grecja zamroziła majątek wiceszefowej PE w związku ze skandalem korupcyjnym
 - [https://www.bankier.pl/wiadomosc/Grecja-zamrozila-majatek-wiceszefowej-PE-w-zwiazku-ze-skandalem-korupcyjnym-8455098.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Grecja-zamrozila-majatek-wiceszefowej-PE-w-zwiazku-ze-skandalem-korupcyjnym-8455098.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 12:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/2/44163b37502b6e-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grecja zamroziła majątek wiceszefowej Parlamentu Europejskiego Evy Kaili w związku ze skandalem korupcyjnym – poinformowała w poniedziałek agencja Reutera.</p>

## "Czyste powietrze" cieszy się popularnością. Rząd zapowiada zmiany w programie
 - [https://www.bankier.pl/wiadomosc/Czyste-powietrze-cieszy-sie-popularnoscia-Rzad-zapowiada-zmiany-w-programie-8455080.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czyste-powietrze-cieszy-sie-popularnoscia-Rzad-zapowiada-zmiany-w-programie-8455080.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 12:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/e/f7d2054ba0cb3b-945-560-0-31-960-575.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ramach programu antysmogowego "Czyste powietrze" złożono ponad 530 tys. wniosków na kwotę prawie 10 mld zł; z tego podpisanych umów mamy 460 tys. na kwotę 8 mld zł - poinformowała w poniedziałek minister klimatu i środowiska Anna Moskwa. Przygotowujemy zmiany w "Czystym powietrzu" - zapowiedziała.</p>

## Rewolucja na Twitterze. Musk zwiększa limit znaków
 - [https://www.bankier.pl/wiadomosc/Rewolucja-na-Twitterze-Musk-zwieksza-limit-znakow-8455032.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rewolucja-na-Twitterze-Musk-zwieksza-limit-znakow-8455032.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 11:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/e32e4f37e3ee83-948-568-0-4-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od przejęcia Twittera przez Elona Muska niemal każdego dnia dochodzi do większych, lub mniejszych zmian w funkcjonowaniu firmy czy platformy. Tym razem to jednak działo dużego kalibru, a konkretniej 4000 znaków.</p>

## Wypłaty z KPO coraz bliżej. Komisja Europejska podpisała uzgodnienia operacyjne
 - [https://www.bankier.pl/wiadomosc/Media-Komisja-Europejska-podpisala-uzgodnienia-operacyjne-dla-polskiego-KPO-8455048.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-Komisja-Europejska-podpisala-uzgodnienia-operacyjne-dla-polskiego-KPO-8455048.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 11:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/1/712d4b3458ed4b-948-568-15-52-2985-1790.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Europejska podpisała uzgodnienia operacyjne dotyczące Krajowego Planu Odbudowy (KPO) Polski. Jest to kolejny krok na drodze do wypłaty środków z Funduszu Odbudowy i Odporności (RRF). Jako pierwsza informację tę podała korespondentka Polskiego Radia w Brukseli. PAP potwierdziła ją równolegle w swoich źródłach.</p>

## Szefowa KE: Tej zimy jesteśmy bezpieczni, energetyczny szantaż Rosji się nie powiódł
 - [https://www.bankier.pl/wiadomosc/Szefowa-KE-Tej-zimy-jestesmy-bezpieczni-energetyczny-szantaz-Rosji-sie-nie-powiodl-8455041.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szefowa-KE-Tej-zimy-jestesmy-bezpieczni-energetyczny-szantaz-Rosji-sie-nie-powiodl-8455041.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 11:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/8/6e5729c2fa2b29-948-568-0-0-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tej zimy jesteśmy bezpieczni; energetyczny szantaż Rosji się nie powiódł - powiedziała w poniedziałek na konferencji prasowej w Brukseli przewodnicząca Komisji Europejskiej Ursula von der Leyen. Ostrzegła jednak, że następna zima może być większym wyzwaniem.</p>

## KNF nałożyła kary na byłego członka rady nadzorczej oraz na byłego członka zarządu GetBack
 - [https://www.bankier.pl/wiadomosc/KNF-nalozyla-kary-na-bylego-czlonka-rady-nadzorczej-oraz-na-bylego-czlonka-zarzadu-GetBack-8455038.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KNF-nalozyla-kary-na-bylego-czlonka-rady-nadzorczej-oraz-na-bylego-czlonka-zarzadu-GetBack-8455038.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 11:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/391a173190368c-945-567-390-610-3433-2060.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Nadzoru Finansowego nałożyła na Alicję Kornasiewicz – byłego członka rady nadzorczej GetBack kary pieniężne w łącznej wysokości 115 tys. zł – poinformowała KNF w komunikacie. Komisja Nadzoru Finansowego wydała także decyzję nakładającą na Annę Paczuską – byłego członka zarządu GetBack kary pieniężne w wysokości 3,35 mln zł.</p>

## W związku z groźbami minister zdrowia otrzymał większą ochronę. "Sytuacja absolutnie niebezpieczna"
 - [https://www.bankier.pl/wiadomosc/W-zwiazku-z-grozbami-minister-zdrowia-otrzymal-wieksza-ochrone-Sytuacja-absolutnie-niebezpieczna-8455030.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-zwiazku-z-grozbami-minister-zdrowia-otrzymal-wieksza-ochrone-Sytuacja-absolutnie-niebezpieczna-8455030.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 11:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/e/fff7cba81adc76-948-568-0-22-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W związku z groźbami moja ochrona została wzmocniona – przekazał w poniedziałek w Radiu Plus szef resoru zdrowia Adam Niedzielski.</p>

## KNF zażądała zawieszenia obrotu akcjami Global Hydrogen
 - [https://www.bankier.pl/wiadomosc/KNF-zazadala-zawieszenia-obrotu-akcjami-Global-Hydrogen-8455004.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KNF-zazadala-zawieszenia-obrotu-akcjami-Global-Hydrogen-8455004.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 10:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/3afcc88d8ad10e-945-560-15-217-2975-1784.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Nadzoru Finansowego skierowała do Giełdy Papierów Wartościowych żądanie zawieszenia obrotu akcjami spółki Global Hydrogen – poinformowała KNF w komunikacie.</p>

## W Berlinie doszło do spotkania prezydentów Dudy i Steinmeiera
 - [https://www.bankier.pl/wiadomosc/Prezydent-Duda-przybyl-do-Berlina-W-planie-wizyty-m-in-rozmowy-z-prezydentem-Niemiec-8454977.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezydent-Duda-przybyl-do-Berlina-W-planie-wizyty-m-in-rozmowy-z-prezydentem-Niemiec-8454977.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 10:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/2941633fd8e079-945-567-13-29-1073-644.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent RP Andrzej Duda przybył w poniedziałek do Berlina z roboczą wizytą; spotka się z prezydentem Niemiec Frankiem-Walterem Steinmeierem. Przywódcy będą rozmawiać o bezpieczeństwie i grożącym Ukrainie kryzysie humanitarnym; omówią także kwestie dwustronne.</p>

## Microsoft kupuje udziały w londyńskiej giełdzie
 - [https://www.bankier.pl/wiadomosc/Microsoft-kupuje-udzialy-w-londynskiej-gieldzie-8454940.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Microsoft-kupuje-udzialy-w-londynskiej-gieldzie-8454940.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 09:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/0/052efc595022c8-948-568-0-51-1703-1021.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Technologiczny gigant z Redmond ogłosił strategiczne partnerstwo z Londyńską Giełdą w zakresie analizy danych i rozwiązań chmurowych. Współpraca przewiduje także wejście Microsoftu do akcjonariatu London Stock Exchange.</p>

## Kurs euro bez większych zmian. Dolar poniżej 4,45 zł
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-8454894.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-8454894.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 08:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/d/d309eb63dfe50f-948-568-428-546-2828-1696.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs euro utrzymał się poniżej 4,70 zł, a notowania
dolara amerykańskiego pozostały w pobliżu 4,45 zł.</p>

## Mercedes Benz zainwestuje ponad 1 mld euro w fabrykę w Jaworze. Z taśm zjadą elektryczne samochody dostawcze
 - [https://www.bankier.pl/wiadomosc/Mercedes-Benz-zainwestuje-ponad-1-mld-euro-w-fabryke-w-Jaworze-Z-tasm-zjada-elektryczne-samochody-dostawcze-8454892.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mercedes-Benz-zainwestuje-ponad-1-mld-euro-w-fabryke-w-Jaworze-Z-tasm-zjada-elektryczne-samochody-dostawcze-8454892.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 08:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/1/c13e3174d42b18-948-568-74-119-1917-1150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mercedes Benz zainwestuje ponad 1 mld euro w fabrykę w Jaworze i będzie produkował elektryczne samochody dostawcze - poinformowali przedstawiciele spółki podczas briefingu prasowego.</p>

## Xiaomi pokazało nowe modele. Cena przekracza 4000 zł
 - [https://www.bankier.pl/wiadomosc/Xiaomi-pokazalo-nowe-modele-Cena-przekracza-4000-zl-8454884.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Xiaomi-pokazalo-nowe-modele-Cena-przekracza-4000-zl-8454884.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 08:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/3c7960473b4114-751-451-103-19-751-451.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chiński gigant technologiczny oficjalnie zaprezentował nowego modele smartfonów: Xiaomi 13 i Xiaomi 13 Pro. Flagowiec na rynku producenta kosztuje w granicach od 2550 zł do 3190 zł w tańszej wersji. Bardziej rozbudowana wersja "Pro" to cena rzędu 3190 zł do 4015 zł.</p>

## Inflacja w Czechach znów wyraźnie przyspieszyła
 - [https://www.bankier.pl/wiadomosc/Inflacja-w-Czechach-znow-wyraznie-przyspieszyla-8454856.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-w-Czechach-znow-wyraznie-przyspieszyla-8454856.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 08:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/1c109bfdc79143-948-568-265-53-3986-2391.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Raptem miesiąc Czesi mogli się cieszyć z wyraźnie 
hamującej inflacji. W listopadzie tempo wzrostu cen konsumpcyjnych znów 
wyraźnie przyspieszyło. Porównywalność danych nadal zaburzają tymczasowe
 rozwiązania wprowadzane przez władze.</p>

## Francuzi wchodzą do Hollywood. Brad Pitt sprzedaje studio
 - [https://www.bankier.pl/wiadomosc/Francuzi-wchodza-do-Hollywood-Brad-Pitt-sprzedaje-studio-8454828.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Francuzi-wchodza-do-Hollywood-Brad-Pitt-sprzedaje-studio-8454828.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 07:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/1/cb0e00fbc641fe-948-568-0-0-3472-2083.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brad Pitt jeden z najsłynniejszych aktorów świata zdecydował się na sprzedaż 60 proc. udziałów w Plan B Entertainment. Kupcem okazali się Francuzi, a wartość transakcji jest liczona w setkach milionów dolarów.</p>

## Disney+ idzie śladami Netfliksa. Platforma wprowadza tańszy pakiet z reklamami
 - [https://www.bankier.pl/wiadomosc/Disney-wprowadza-tanszy-pakiet-z-reklamami-8454835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Disney-wprowadza-tanszy-pakiet-z-reklamami-8454835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 07:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/6d0c0fac30834b-948-568-0-0-3600-2159.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Disney+ podobnie jak Netflix wprowadza nowy abonament z reklamami. Subskrypcja będzie tańsza od standardowego pakietu. Jednocześnie amerykański gigant podwyższa ceny za obie wersje dostępu do platformy streamingowej.</p>

## Tylko Inspekcja Weterynaryjna odbierze zaniedbane zwierzę? PiS zapowiada zmiany w prawie
 - [https://www.bankier.pl/wiadomosc/Tylko-Inspekcja-Weterynaryjna-odbierze-zaniedbane-zwierze-PiS-zapowiada-zmiany-w-prawie-8454809.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tylko-Inspekcja-Weterynaryjna-odbierze-zaniedbane-zwierze-PiS-zapowiada-zmiany-w-prawie-8454809.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 07:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/c/8ef19656e1d711-948-568-0-208-3976-2385.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PiS tak zmieni przepisy, aby organizacje prozwierzęce
 nie mogły wchodzić na teren rolników i odbierać zaniedbanych zwierząt. 
Zupełnie inne zdanie na ten temat mają organizacje prozwierzęce, które 
alarmują: PiS po 25. latach chce zniszczyć ochronę zwierząt w Polsce.</p>

## Kluczowy naftociąg w USA wciąż zamknięty. Ceny ropy idą w górę
 - [https://www.bankier.pl/wiadomosc/Kluczowy-naftociag-w-USA-wciaz-zamkniety-Ceny-ropy-ida-w-gore-8454816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kluczowy-naftociag-w-USA-wciaz-zamkniety-Ceny-ropy-ida-w-gore-8454816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 07:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/18ff901258ec53-948-568-0-331-1920-1152.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną w poniedziałek. Kluczowy ropociąg w Stanach Zjednoczonych pozostaje zamknięty, co wpływa na ograniczenie dostaw paliw. Inwestorzy analizują też najnowsze informacje dotyczące Covid-19 w Chinach - informują maklerzy.</p>

## Frankowcy będą mieli łatwiej, a stolica od nich odpocznie
 - [https://www.bankier.pl/wiadomosc/Frankowcy-beda-mieli-latwiej-a-stolica-od-nich-odpocznie-8454782.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Frankowcy-beda-mieli-latwiej-a-stolica-od-nich-odpocznie-8454782.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 05:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/0/d6371a9a2d9a5b-948-567-0-60-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pozew w sprawie kredytu walutowego będzie można złożyć tylko w sądzie właściwym dla miejsca zamieszkania konsumenta. Dzięki temu frankowicze na wyrok poczekają znacznie krócej – informuje poniedziałkowy "Dziennik Gazeta Prawna".</p>

## Przyspieszenie z KPO? PiS chce rozwiązać problem nawet z pominięciem Ziobry
 - [https://www.bankier.pl/wiadomosc/Przyspieszenie-z-KPO-PiS-chce-rozwiazac-problem-nawet-z-pominieciem-Ziobry-8454781.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przyspieszenie-z-KPO-PiS-chce-rozwiazac-problem-nawet-z-pominieciem-Ziobry-8454781.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 05:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/6988ccb54e1206-948-568-0-373-3048-1828.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PiS poważnie rozważa przyjęcie jeszcze w tym roku – nawet bez Zbigniewa Ziobry – nowej ustawy, która pozwoliłaby odblokować unijne fundusze. Mogłaby ją poprzeć część opozycji – informuje poniedziałkowa "Rzeczpospolita".</p>

## Premier zapowiada utrzymanie trzynastek i czternastek. Pod jednym warunkiem
 - [https://www.bankier.pl/wiadomosc/Premier-zapowiada-utrzymanie-trzynastek-i-czternastek-Pod-jednym-warunkiem-8454779.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-zapowiada-utrzymanie-trzynastek-i-czternastek-Pod-jednym-warunkiem-8454779.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 05:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/e/38e26583fb6452-948-568-0-112-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeśli będziemy nadal rządzić, trzynastka i czternastka będą utrzymane. Chcemy czternastkę na stałe wpisać do ustawy – powiedział premier Mateusz Morawiecki w poniedziałkowym "Super Expressie”.</p>

## Codzienność polskich startupów coraz mniej różowa
 - [https://www.bankier.pl/wiadomosc/Codziennosc-polskich-startupow-coraz-mniej-rozowa-8454741.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Codziennosc-polskich-startupow-coraz-mniej-rozowa-8454741.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/a/99b3b8bcda327e-948-568-0-293-1448-868.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />O ile pandemia była impulsem do szybszego rozwoju sektora startupów, to obecne kryzysy, czyli wojna w Ukrainie oraz załamanie gospodarcze, mają negatywny wpływ na nastroje w młodych firmach technologicznych – wynika z raportu „Polskie startupy” opublikowanego właśnie przez Fundację Startup Poland.</p>

## Korekta stawek w aktach notarialnych widoczna, ale niewyraźnie. „Tanieją” jedynie duże mieszkania
 - [https://www.bankier.pl/wiadomosc/Ceny-transakcyjne-mieszkan-III-kw-2022-r-Raport-8454274.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-transakcyjne-mieszkan-III-kw-2022-r-Raport-8454274.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/0377c633e48b57-948-568-0-74-1982-1189.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po trzymiesięcznej przerwie, III kw. 2022 r. przyniósł powrót obniżek średnich stawek transakcyjnych na rynku sprzedaży mieszkań – wynika z danych Bankier.pl udostępnionych przez serwis Cenatorium. Korekta była jednak widoczna wyłącznie w przypadku dużych, co najmniej 60-metrowych mieszkań.</p>

## Wysyp "lokat na 8 proc.". Czas przeprosić się z matematyką, bo tylko ona da naprawdę zarobić. Podpowiadamy, jak odróżnić marketing od dobrej oferty
 - [https://www.bankier.pl/wiadomosc/Wysyp-lokat-na-8-proc-Jak-obliczyc-zysk-i-wybrac-najlepsza-8453347.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wysyp-lokat-na-8-proc-Jak-obliczyc-zysk-i-wybrac-najlepsza-8453347.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/7/11b8ba399c739f-948-568-0-0-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie każda lokata na taką samą stawkę będzie tak samo opłacalna. Wszystko zależy od okresu depozytu, wpłaconej kwoty, warunków dodatkowych czy kapitalizacji. Podpowiadamy, jak nie dać się zwieść marketingowym sloganom i na co zwrócić uwagę, wpłacając swoje oszczędności do banku. </p>

## Inflacja w sklepach nadal znacznie przebija tę oficjalną. Zdrożały wszystkie z 12 kategorii produktów
 - [https://www.bankier.pl/wiadomosc/Inflacja-w-sklepach-nadal-znacznie-przebija-te-oficjalna-Zdrozaly-wszystkie-z-12-kategorii-produktow-8454766.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-w-sklepach-nadal-znacznie-przebija-te-oficjalna-Zdrozaly-wszystkie-z-12-kategorii-produktow-8454766.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-12 04:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/b/c8e70af0b05e66-948-567-0-35-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W listopadzie br. codzienne zakupy były droższe średnio o 25,8 proc. rdr - wynika z przekazanego PAP najnowszego "Indeksu cen w sklepach detalicznych". Zdrożały wszystkie z 12 analizowanych kategorii produktów, a ich średnie wzrosty znowu są dwucyfrowe.</p>


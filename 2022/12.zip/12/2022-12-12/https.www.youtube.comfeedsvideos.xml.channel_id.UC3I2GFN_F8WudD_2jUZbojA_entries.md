# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Pan Amerikan Native Front - Battle of the Wabash (Live on KEXP)
 - [https://www.youtube.com/watch?v=yUnIfmyHM-U](https://www.youtube.com/watch?v=yUnIfmyHM-U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-12 00:00:00+00:00

http://KEXP.ORG presents Pan-Amerikan Native Front performing “Battle of the Wabash” live in the KEXP studio. Recorded October 27, 2022.

Kurator of War - Guitar / Vocals
Necroboar - Guitar / Vocals
Belgor - Drums
P.O. - Bass

Host: Tanner Ellison
Audio Engineers: Julian Martlew & Kevin Suggs
Audio Mixer: Kevin Suggs
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://pan-amerikannativefront.bandcamp.com
http://kexp.org

## Pan Amerikan Native Front - Blazing Winds of the Three Fires (Live on KEXP)
 - [https://www.youtube.com/watch?v=VFXg02jz6TE](https://www.youtube.com/watch?v=VFXg02jz6TE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-12 00:00:00+00:00

http://KEXP.ORG presents Pan-Amerikan Native Front performing “Blazing Winds of the Three Fires” live in the KEXP studio. Recorded October 27, 2022.

Kurator of War - Guitar / Vocals
Necroboar - Guitar / Vocals
Belgor - Drums
P.O. - Bass

Host: Tanner Ellison
Audio Engineers: Julian Martlew & Kevin Suggs
Audio Mixer: Kevin Suggs
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://pan-amerikannativefront.bandcamp.com
http://kexp.org

## Pan Amerikan Native Front - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=fvDYsTa-RXw](https://www.youtube.com/watch?v=fvDYsTa-RXw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-12 00:00:00+00:00

http://KEXP.ORG presents Pan-Amerikan Native Front performing live in the KEXP studio. Recorded October 27, 2022.

Songs:
Battle of the Wabash
Blazing Winds of the Three Fires
Manitouwut
Indigenous Blood Revival

Kurator of War - Guitar / Vocals
Necroboar - Guitar / Vocals
Belgor - Drums
P.O. - Bass

Host: Tanner Ellison
Audio Engineers: Julian Martlew & Kevin Suggs
Audio Mixer: Kevin Suggs
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://pan-amerikannativefront.bandcamp.com
http://kexp.org

## Pan Amerikan Native Front - Indigenous Blood Revival (Live on KEXP)
 - [https://www.youtube.com/watch?v=v7KbuWiK1f0](https://www.youtube.com/watch?v=v7KbuWiK1f0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-12 00:00:00+00:00

http://KEXP.ORG presents Pan-Amerikan Native Front performing “Indigenous Blood Revival” live in the KEXP studio. Recorded October 27, 2022.

Kurator of War - Guitar / Vocals
Necroboar - Guitar / Vocals
Belgor - Drums
P.O. - Bass

Host: Tanner Ellison
Audio Engineers: Julian Martlew & Kevin Suggs
Audio Mixer: Kevin Suggs
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://pan-amerikannativefront.bandcamp.com
http://kexp.org

## Pan Amerikan Native Front - Manitouwut (Live on KEXP)
 - [https://www.youtube.com/watch?v=N3SVYTFIEKc](https://www.youtube.com/watch?v=N3SVYTFIEKc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-12 00:00:00+00:00

http://KEXP.ORG presents Pan-Amerikan Native Front performing “Manitouwut” live in the KEXP studio. Recorded October 27, 2022.

Kurator of War - Guitar / Vocals
Necroboar - Guitar / Vocals
Belgor - Drums
P.O. - Bass

Host: Tanner Ellison
Audio Engineers: Julian Martlew & Kevin Suggs
Audio Mixer: Kevin Suggs
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://pan-amerikannativefront.bandcamp.com
http://kexp.org


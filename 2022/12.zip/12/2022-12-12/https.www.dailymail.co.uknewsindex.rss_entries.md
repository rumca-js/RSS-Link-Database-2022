# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Father Greg Williams fly from Yeppoon, Queensland, to Melbourne to surprise son Ross Williams
 - [https://www.dailymail.co.uk/news/article-11530351/Father-Greg-Williams-fly-Yeppoon-Queensland-Melbourne-surprise-son-Ross-Williams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530351/Father-Greg-Williams-fly-Yeppoon-Queensland-Melbourne-surprise-son-Ross-Williams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 23:55:25+00:00

Father Greg Williams and son Ross were reunited last Sunday after spending eight years apart. Sister Milly arranged for their dad to fly down from central Queensland to Melbourne for the surprise visit.

## Wieambilla shooting: Police officer just eight weeks into service caught in firefight
 - [https://www.dailymail.co.uk/news/article-11530513/Wieambilla-shooting-Police-officer-just-eight-weeks-service-caught-firefight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530513/Wieambilla-shooting-Police-officer-just-eight-weeks-service-caught-firefight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 23:38:06+00:00

The woman officer was just eight weeks into her service when she was caught up in the shooting  near Wieambilla, three hours west of Brisbane, at 5pm on Monday.

## Police warning not to walk on frozen lakes as TikToks show people skating and playing ICE HOCKEY
 - [https://www.dailymail.co.uk/news/article-11529805/Police-warning-not-walk-frozen-lakes-TikToks-people-skating-playing-ICE-HOCKEY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529805/Police-warning-not-walk-frozen-lakes-TikToks-people-skating-playing-ICE-HOCKEY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 23:35:25+00:00

The fun lovers have been branded 'stupid' by people on social media as they put their lives at risk a day after three children tragically died after fallen through ice on a frozen lake in Solihull yesterday.

## Manchin leaves the door open to leaving the Democrats after Sinema defected
 - [https://www.dailymail.co.uk/news/article-11530825/Manchin-leaves-door-open-leaving-Democrats-Sinema-defected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530825/Manchin-leaves-door-open-leaving-Democrats-Sinema-defected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 23:33:47+00:00

Sen. Joe Manchin said Monday that he has no intention of leaving the Democratic Party - like fellow moderate Sen. Kyrsten Sinema did last week - but he hinted that could change.

## Tory Lanez's defense say Megan Thee Stallion shooting was sparked by her 'jealousy' of Kylie Jenner
 - [https://www.dailymail.co.uk/news/article-11530663/Tory-Lanezs-defense-say-Megan-Thee-Stallion-shooting-sparked-jealousy-Kylie-Jenner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530663/Tory-Lanezs-defense-say-Megan-Thee-Stallion-shooting-sparked-jealousy-Kylie-Jenner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 23:32:52+00:00

Tory Lanez's alleged shooting of fellow hip-hop star Megan Thee Stallion was sparked by her jealousy of Kylie Jenner, his defense team told a Los Angeles criminal court on the first day of trial.

## Girl, 10, nearly loses foot in Florida shark attack after she was bit four times while swimming
 - [https://www.dailymail.co.uk/news/article-11530603/Girl-10-nearly-loses-foot-Florida-shark-attack-bit-four-times-swimming.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530603/Girl-10-nearly-loses-foot-Florida-shark-attack-bit-four-times-swimming.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 23:29:54+00:00

Jasmine Carney, 10, nearly lost her foot after she was bit by a shark four times while she was swimming in the waters off a Florida beach. She said the shark 'wasn't letting go'

## Chinese and Indian troops fight on the border, leaving numerous soldiers on both sides wounded
 - [https://www.dailymail.co.uk/news/article-11530583/Chinese-Indian-troops-fight-border-leaving-numerous-soldiers-sides-wounded.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530583/Chinese-Indian-troops-fight-border-leaving-numerous-soldiers-sides-wounded.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 23:29:35+00:00

Indian and Chinese troops engaged in a fresh 'face-off' on their disputed Himalayan border last week, leaving several injured on both sides, sources said Monday.

## Chilling moment cold-blooded killers calmly execute wounded cops near Chinchilla, Queensland
 - [https://www.dailymail.co.uk/news/brisbane/article-11530727/Chilling-moment-cold-blooded-killers-calmly-execute-wounded-cops-near-Chinchilla-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/brisbane/article-11530727/Chilling-moment-cold-blooded-killers-calmly-execute-wounded-cops-near-Chinchilla-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 23:25:02+00:00

Matthew Arnold, 26, and Rachel McCrow, 29, were killed execution style after being wounded in an ambush in rural Queensland on Monday evening.

## GOP senators slam Peter Daszak for 'playing in a bat cave' in Thailand
 - [https://www.dailymail.co.uk/news/article-11530565/GOP-senators-slam-Peter-Daszak-playing-bat-cave-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530565/GOP-senators-slam-Peter-Daszak-playing-bat-cave-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 23:19:32+00:00

Daszak, whose EcoHealth Alliance has received millions in federal funding  for bat coronavirus research, posted the new images from Thailand in recent days.

## Mansion once owned by Evelyn Waugh where tenants pay just £250 a year goes on sale for £2.5million
 - [https://www.dailymail.co.uk/news/article-11530791/Mansion-owned-Evelyn-Waugh-tenants-pay-just-250-year-goes-sale-2-5million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530791/Mansion-owned-Evelyn-Waugh-tenants-pay-just-250-year-goes-sale-2-5million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 23:02:35+00:00

Prospective buyers are unable to view Piers Court because the current tenants are refusing to leave and will not let estate agents or buyers in.

## Karine Jean-Pierre slams attacks on Dr Fauci as 'disgusting' and 'devoid of reality'
 - [https://www.dailymail.co.uk/news/article-11530677/Karine-Jean-Pierre-slams-attacks-Dr-Fauci-disgusting-devoid-reality.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530677/Karine-Jean-Pierre-slams-attacks-Dr-Fauci-disgusting-devoid-reality.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:45:48+00:00

The White House defended President Joe Biden's top medical adviser on Monday, slamming attacks on Dr. Tony Fauci as 'dangerous' and 'divorced from reality.'

## Banker in vile web chat with 'girl, 12' is spared prison
 - [https://www.dailymail.co.uk/news/article-11530849/Banker-vile-web-chat-girl-12-spared-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530849/Banker-vile-web-chat-girl-12-spared-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:45:18+00:00

Liverpool Crown Court heard Andrew Teale, a married father, had quickly turned an online chat from theme parks to threesomes before performing a sex act over Skype

## Wieambilla shooting: Reason cops were at bush property
 - [https://www.dailymail.co.uk/news/article-11530661/Wieambilla-shooting-Reason-cops-bush-property.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530661/Wieambilla-shooting-Reason-cops-bush-property.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:40:12+00:00

Four Queensland Police officers had gone to the property at Wieambilla, three hours west of Brisbane, at about 4.30pm on Monday. Two young constables were fatally shot.

## White House will hold talks with Russia this week about bringing Paul Whelan home
 - [https://www.dailymail.co.uk/news/article-11530739/White-House-hold-talks-Russia-week-bringing-Paul-Whelan-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530739/White-House-hold-talks-Russia-week-bringing-Paul-Whelan-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:39:16+00:00

Biden administration officials are set to have an 'engagement' with Russians this week amid the push to free former U.S. Marine Paul Whelan, who got left out of the Griner-Bout prisoner swap.

## Tributes flow for Alan Dare killed in remote bush property mass shooting, Wieambilla, Queensland
 - [https://www.dailymail.co.uk/news/article-11530829/Tributes-flow-Alan-Dare-killed-remote-bush-property-mass-shooting-Wieambilla-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530829/Tributes-flow-Alan-Dare-killed-remote-bush-property-mass-shooting-Wieambilla-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:39:10+00:00

Alan Dare was one of three people killed,  at a remote property in Wieambilla, three hours west of Brisbane, at about 4.30pm on Monday.

## Melissa Caddick case: Christian Dior ordered to hand over cash held in fraudster's name
 - [https://www.dailymail.co.uk/news/article-11530813/Mellissa-Caddick-case-Christian-Dior-ordered-hand-cash-held-fraudsters-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530813/Mellissa-Caddick-case-Christian-Dior-ordered-hand-cash-held-fraudsters-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:37:38+00:00

The expensive lifestyle of the unlicensed financial adviser has been under intense scrutiny since she disappeared without a trace two years ago in the midst of an investigation into her business.

## Senate scrambles to avoid a shutdown by trying to pass a ONE-WEEK funding bill
 - [https://www.dailymail.co.uk/news/article-11530871/Senate-scrambles-avoid-shutdown-trying-pass-ONE-WEEK-funding-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530871/Senate-scrambles-avoid-shutdown-trying-pass-ONE-WEEK-funding-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:36:30+00:00

Schumer announced Monday he will bring a week-long spending bill to the floor to stop a shutdown.

## Police are accused of 'aligning' themselves with Bruce Lehrmann's defence
 - [https://www.dailymail.co.uk/news/article-11530419/Police-accused-aligning-Bruce-Lehrmanns-defence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530419/Police-accused-aligning-Bruce-Lehrmanns-defence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:36:19+00:00

The ACT DPP Shane Drumgold has already raised concerns about 'political and police conduct' in the case of the former Liberal staffer.

## Netflix paid just £5million in UK tax last year after earning £1.3billion in Britain
 - [https://www.dailymail.co.uk/news/article-11530845/Netflix-paid-just-5million-UK-tax-year-earning-1-3billion-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530845/Netflix-paid-just-5million-UK-tax-year-earning-1-3billion-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:35:40+00:00

Netflix paid a mere £5 million in UK corporation tax last year, despite earning more than £1.3 billion. The giant used a legal accounting loophole to avoid an estimated £49 million in UK taxes.

## Biden pretends to get on a child-sized bike six months after fall
 - [https://www.dailymail.co.uk/news/article-11530501/Biden-pretends-child-sized-bike-six-months-fall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530501/Biden-pretends-child-sized-bike-six-months-fall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:34:19+00:00

President Joe Biden tried out a child's sized-bike on Monday, six months after he fell off the adult version.  He climbed on board and joked around with kids at Toys for Tots event.

## Megyn Kelly slams Harry and Meghan's new $100M Netflix documentary as 'insufferable'
 - [https://www.dailymail.co.uk/news/article-11530379/Megyn-Kelly-slams-Harry-Meghans-new-100M-Netflix-documentary-insufferable.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530379/Megyn-Kelly-slams-Harry-Meghans-new-100M-Netflix-documentary-insufferable.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:32:29+00:00

Megyn Kelly branded the new Harry and Meghan Netflix documentary 'insufferable' and speculated that Harry needs a psychotherapist, not a 'whiny, woke annoying wife.'

## Andrew Bolt unloads on Sky News colleague Chris Smith over drunken Christmas party scandal
 - [https://www.dailymail.co.uk/news/article-11530657/Andrew-Bolt-unloads-Sky-News-colleague-Chris-Smith-drunken-Christmas-party-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530657/Andrew-Bolt-unloads-Sky-News-colleague-Chris-Smith-drunken-Christmas-party-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:32:19+00:00

Bolt called for the suspended broadcaster to be sacked for his behaviour after Sky's Christmas party in a segment that lasted more than three minutes on Monday night.

## Woman had to strap granddad to WOODEN PLANK and drive him to hospital as 'no ambulances' available
 - [https://www.dailymail.co.uk/news/article-11530749/Woman-strap-granddad-WOODEN-PLANK-drive-hospital-no-ambulances-available.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530749/Woman-strap-granddad-WOODEN-PLANK-drive-hospital-no-ambulances-available.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:25:35+00:00

Devoted granddaughter Nicole Lea, 27, found 89-year-old Melvyn Ryan lying on the floor of his home in Cwmbran, South Wales, early on Friday morning, December 9.

## Man to be charged with murder after victim is found with gunshot wounds in a suburban street
 - [https://www.dailymail.co.uk/news/article-11530667/Man-charged-murder-victim-gunshot-wounds-suburban-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530667/Man-charged-murder-victim-gunshot-wounds-suburban-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:21:43+00:00

A man is in custody after another man was found with gunshot wounds on an Adelaide road. The 41-year-old man was rushed to Flinders Medical Centre in a critical condition but died a short time later.

## Home Office is in talks to hire 820-chalet holiday camp on south coast to house migrants
 - [https://www.dailymail.co.uk/news/article-11530635/Home-Office-talks-hire-820-chalet-holiday-camp-south-coast-house-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530635/Home-Office-talks-hire-820-chalet-holiday-camp-south-coast-house-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:19:45+00:00

Channel migrants could be put up at a Pontins holiday camp at Camber Sands in East Sussex in a bid to cut taxpayers' £6million-a-day hotel bill for small boat arrivals.

## City of Richmond removes AP Hill statue - last city-owned Confederate statue standing in the state
 - [https://www.dailymail.co.uk/news/article-11530281/City-Richmond-removes-AP-Hill-statue-city-owned-Confederate-statue-standing-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530281/City-Richmond-removes-AP-Hill-statue-city-owned-Confederate-statue-standing-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:18:55+00:00

The last city-owned Confederate statue in Virginia was removed from the center of a busy intersection on Monday morning.

## Collapsed crypto firm FTX splurged $5BN on investments that may now be worth 'only a fraction'
 - [https://www.dailymail.co.uk/news/article-11530421/Collapsed-crypto-firm-FTX-splurged-5BN-investments-worth-fraction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530421/Collapsed-crypto-firm-FTX-splurged-5BN-investments-worth-fraction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:13:09+00:00

FTX went on a $5 billion 'spending binge' in the year before its collapse, buying up businesses and investments that are likely now worth 'only a fraction' of that amount, its new CEO has told lawmakers.

## Urgent recall is issued for popular wooden baby rattle
 - [https://www.dailymail.co.uk/news/article-11530601/Urgent-recall-issued-popular-wooden-baby-rattle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530601/Urgent-recall-issued-popular-wooden-baby-rattle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:11:59+00:00

The ACCC said on Monday consumers should immediately stop using the rattle, have it destroyed and arrange a refund. The toy had been available for sale online from February 10 to December 1, 2022.

## Army drivers may not go to emergencies during ambulance crews walkout
 - [https://www.dailymail.co.uk/news/article-11530687/Army-drivers-not-emergencies-ambulance-crews-walkout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530687/Army-drivers-not-emergencies-ambulance-crews-walkout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 22:06:17+00:00

RCN's two days of action on December 15 and 20 are expected to result in up to 15,000 operations being cancelled, while health officials may block-book taxis to ferry patients to hospital

## Biden eyes plans to push millions into a dozen overseas minerals projects
 - [https://www.dailymail.co.uk/news/article-11530383/Biden-eyes-plans-push-millions-dozen-overseas-minerals-projects.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530383/Biden-eyes-plans-push-millions-dozen-overseas-minerals-projects.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 21:55:07+00:00

President Biden is eyeing up at least a dozen overseas mining projects in a bid to shore up the resources needed to produce renewable energy.

## Magnitude 2.1 earthquake shakes South Australia early this morning
 - [https://www.dailymail.co.uk/news/article-11530711/Magnitude-2-1-earthquake-shakes-South-Australia-early-morning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530711/Magnitude-2-1-earthquake-shakes-South-Australia-early-morning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 21:54:41+00:00

A magnitude 2.1 earthquake struck South Australia this morning, with many residents waking up to the early morning tremor.

## Two coyotes lie in wait and then kill two pet Chihuahuas in California family's backyard
 - [https://www.dailymail.co.uk/news/article-11530123/Two-coyotes-lie-wait-kill-two-pet-Chihuahuas-California-familys-backyard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530123/Two-coyotes-lie-wait-kill-two-pet-Chihuahuas-California-familys-backyard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 21:45:23+00:00

Two wild coyotes lie in wait before they pounce and kill two pet Chihuahuas- Salem and Gizmo- at a California home on Sunday. The third Chihuahua, Ella, escaped with a puncture wound.

## Gavin Newsom goes to the border: California Governor visits the region to discuss immigration reform
 - [https://www.dailymail.co.uk/news/article-11530329/Gavin-Newsom-goes-border-California-Governor-visits-region-discuss-immigration-reform.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530329/Gavin-Newsom-goes-border-California-Governor-visits-region-discuss-immigration-reform.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 21:38:50+00:00

The visit would have sparked 2024 rumors if the popular Democratic leader hadn't recently ruled out a presidential campaign in the next election cycle - particularly if President Joe Biden is running.

## Bodycam footage shows moment Samuel Rappylee Bateman is arrested in Arizona
 - [https://www.dailymail.co.uk/news/article-11529771/Bodycam-footage-shows-moment-Samuel-Rappylee-Bateman-arrested-Arizona.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529771/Bodycam-footage-shows-moment-Samuel-Rappylee-Bateman-arrested-Arizona.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 21:32:37+00:00

Footage of Samuel Rappylee Bateman's August arrest obtained DailyMail.com, was captured by Coconino County Sheriff's deputies during a traffic stop in Flagstaff, Arizona.

## Justin Bieber, Madonna, Steph Curry, Kevin Hart and Serena Williams sued for NFT endorsements
 - [https://www.dailymail.co.uk/news/article-11530019/Justin-Bieber-Madonna-Steph-Curry-Kevin-Hart-Serena-Williams-sued-NFT-endorsements.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530019/Justin-Bieber-Madonna-Steph-Curry-Kevin-Hart-Serena-Williams-sued-NFT-endorsements.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 21:20:08+00:00

Several celebrities are named in a lawsuit filed against Yugo Labs, the company behind NFT series Bored Ape Yacht Club, that alleges it engaged in a conspiracy to defraud potential investors

## JK Rowling says: 'I do not consider myself cancelled'
 - [https://www.dailymail.co.uk/news/article-11530081/JK-Rowling-says-not-consider-cancelled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530081/JK-Rowling-says-not-consider-cancelled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 21:18:00+00:00

In an interview for Letters from Suzanne, the author said: 'The only time I've ever made reference to being cancelled, my book sales went up. Why am I even laughing?'

## Netflix trailer wrongly suggests Meghan and Harry's 'security was pulled' before Megxit
 - [https://www.dailymail.co.uk/news/article-11529513/Netflix-trailer-wrongly-suggests-Meghan-Harrys-security-pulled-Megxit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529513/Netflix-trailer-wrongly-suggests-Meghan-Harrys-security-pulled-Megxit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 21:12:23+00:00

The 90-second clip - released today - implies the couple's decision to leave the UK for America was taken due to a pressing concern for their safety.

## Massachusetts library to display Christmas tree after being accused a 'war on Christians'
 - [https://www.dailymail.co.uk/news/article-11530203/Massachusetts-library-display-Christmas-tree-accused-war-Christians.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530203/Massachusetts-library-display-Christmas-tree-accused-war-Christians.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 21:11:44+00:00

The Dedham library in Massachusetts will display their annual Christmas tree after some complained the holiday symbol made them uncomfortable.

## American student missing in France 'was having a hard time making friends'
 - [https://www.dailymail.co.uk/news/article-11530305/American-student-missing-France-having-hard-time-making-friends.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530305/American-student-missing-France-having-hard-time-making-friends.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 21:07:34+00:00

Kenneth DeLand, 22, has not been seen since December 3, when he was spotted shopping in a store in Montelimar. He has been studying in Grenoble, a University in France.

## Teenager is RESCUED from Adelaide Zoo's panda enclosure
 - [https://www.dailymail.co.uk/news/article-11530385/Teenager-RESCUED-Adelaide-Zoos-panda-enclosure.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530385/Teenager-RESCUED-Adelaide-Zoos-panda-enclosure.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 20:49:14+00:00

Student's dramatic rescue from panda enclosure at Adelaide Zoo

## Free riders: Washington DC leads pack with a fare-free bus rides next summer
 - [https://www.dailymail.co.uk/news/article-11529431/Free-riders-Washington-DC-leads-pack-fare-free-bus-rides-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529431/Free-riders-Washington-DC-leads-pack-fare-free-bus-rides-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 20:37:30+00:00

During the pandemic, cities from LA to Missouri and NYC stopped collecting bus fares to cut human contact and ensure residents could reach jobs and services at hospitals, grocery stores and offices.

## Los Angeles Mayor Karen Bass officially declares emergency over homeless crisis hours into office
 - [https://www.dailymail.co.uk/news/article-11530147/Los-Angeles-Mayor-Karen-Bass-officially-declares-emergency-homeless-crisis-hours-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530147/Los-Angeles-Mayor-Karen-Bass-officially-declares-emergency-homeless-crisis-hours-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 20:37:03+00:00

After less than 24 hours in office, Los Angeles Mayor Karen Bass has declared a state of emergency over the homeless crisis in the Southern California city.

## Sam Bankman-Fried's ex-girlfriend and Alameda CEO Caroline Ellison lawyers up
 - [https://www.dailymail.co.uk/news/article-11530129/Sam-Bankman-Frieds-ex-girlfriend-Alameda-CEO-Caroline-Ellison-lawyers-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530129/Sam-Bankman-Frieds-ex-girlfriend-Alameda-CEO-Caroline-Ellison-lawyers-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 20:30:23+00:00

Sam Bankman-Fried's ex-girlfriend has hired a legal team which includes a former top SEC official and a lawyer who investigated the Bernie Madoff Ponzi scheme.

## Moment bystanders work together to move bus that got stuck during heavy snowfall in London [Video]
 - [https://www.dailymail.co.uk/news/article-11530287/Moment-bystanders-work-bus-got-stuck-heavy-snowfall-London-Video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530287/Moment-bystanders-work-bus-got-stuck-heavy-snowfall-London-Video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 20:29:51+00:00

Footage shows dozens of people on Rookwood Road in Stamford Hill, pushing the front and back of the bus in an attempt to straighten it and stop it blocking the whole street.

## Police launch urgent appeal to find missing schoolgirl, 15, who vanished from Essex three weeks ago
 - [https://www.dailymail.co.uk/news/article-11530293/Police-launch-urgent-appeal-missing-schoolgirl-15-vanished-Essex-three-weeks-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530293/Police-launch-urgent-appeal-missing-schoolgirl-15-vanished-Essex-three-weeks-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 20:20:39+00:00

Kimberley (pictured) was last seen on November 19 in Harlow and officers are concerned about her whereabouts. The Metropolitan Police are appealing for information from the public.

## American households lost about $6.8T in wealth in the first nine months of 2022
 - [https://www.dailymail.co.uk/news/article-11530031/American-households-lost-6-8T-wealth-nine-months-2022.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530031/American-households-lost-6-8T-wealth-nine-months-2022.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 20:19:39+00:00

American households lost more than $6.8 billion in aggregate net worth in the first nine months of 2022, due largely to steep declines in the stock market, according to new Federal Reserve data.

## Police launch a desperate search for missing 12-year-old boy
 - [https://www.dailymail.co.uk/news/article-11530289/Police-launch-desperate-search-missing-12-year-old-boy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530289/Police-launch-desperate-search-missing-12-year-old-boy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 19:56:28+00:00

An urgent search is underway for a  12-year-old boy who went missing in Perth's City of Swan four days ago.

## Famous Chicago homeless person 'The Walking Man', 75, dies seven months after thug doused him in gas
 - [https://www.dailymail.co.uk/news/article-11529775/Famous-Chicago-homeless-person-Walking-Man-75-dies-seven-months-thug-doused-gas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529775/Famous-Chicago-homeless-person-Walking-Man-75-dies-seven-months-thug-doused-gas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 19:54:08+00:00

Joseph Kormelis, 75, known as 'The Walkign Man' of Chicago, died on Sunday at 4.08pm, the Cook County Medical Examiner's Office revealed.

## Crufts-winning dog breeder, 69, is facing jail after pet Belgian Malinois mauled visitor's leg
 - [https://www.dailymail.co.uk/news/article-11530193/Crufts-winning-dog-breeder-69-facing-jail-pet-Belgian-Malinois-mauled-visitors-leg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530193/Crufts-winning-dog-breeder-69-facing-jail-pet-Belgian-Malinois-mauled-visitors-leg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 19:54:00+00:00

Margaret Peacock, 69, of Farnborough, Hampshire, (pictured) was convicted of being in charge of a dangerously out of control Belgian Malinois dog 'Mako', which mauled the leg of Natasha Turner, 33.

## Comer calls out Democrats for 'hyper-partisan' investigations into Trump
 - [https://www.dailymail.co.uk/news/article-11529877/Comer-calls-Democrats-hyper-partisan-investigations-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529877/Comer-calls-Democrats-hyper-partisan-investigations-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 19:39:36+00:00

The incoming chairman of the House Oversight Committee, Rep. James Comer, accused  Democrats of 'hypocrisy' for continuing to investigate former President Donald Trump.

## Joanna Gosling who broke down over deaths of three young boys in frozen lake has three daughters
 - [https://www.dailymail.co.uk/news/article-11530233/Joanna-Gosling-broke-deaths-three-young-boys-frozen-lake-three-daughters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530233/Joanna-Gosling-broke-deaths-three-young-boys-frozen-lake-three-daughters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 19:36:46+00:00

As Ms Gosling delivered the news of the deaths live on air today, she appeared visibly upset and after taking a pause said 'I'm so sorry, this is terrible news obviously.'

## Veteran Milwaukee mail-carrier, 48, is shot dead while delivering letters
 - [https://www.dailymail.co.uk/news/article-11529617/Veteran-Milwaukee-mail-carrier-48-shot-dead-delivering-letters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529617/Veteran-Milwaukee-mail-carrier-48-shot-dead-delivering-letters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 19:29:08+00:00

USPS letter carrier of 18 years Aundre Cross (left), 44, was shot dead last Friday as he delivered mail on the north side of Milwaukee.

## Twitter files PART FIVE: Trump was banned even though employees said he did NOT violate policy
 - [https://www.dailymail.co.uk/news/article-11530029/Twitter-files-FIVE-Trump-banned-employees-said-did-NOT-violate-policy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530029/Twitter-files-FIVE-Trump-banned-employees-said-did-NOT-violate-policy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 19:29:03+00:00

Part five of the Twitter Files dropped Monday afternoon detailing the social media platform's decision to indefinitely ban Donald Trump two days after the January 6 Capitol attack.

## Biden shuts down suggestions he is sending U.S. troops to Ukraine
 - [https://www.dailymail.co.uk/news/article-11529351/Biden-shuts-suggestions-sending-U-S-troops-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529351/Biden-shuts-suggestions-sending-U-S-troops-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 19:24:23+00:00

President Joe Biden on Monday shot down a report he was considering sending U.S. troops to the Ukraine and said he was sending 'billions' in materials to the embattled nation.

## White House goes to war with Marjorie Taylor Greene over saying she would have 'won' January 6
 - [https://www.dailymail.co.uk/news/article-11529845/White-House-Marjorie-Taylor-Greene-January-6.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529845/White-House-Marjorie-Taylor-Greene-January-6.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 19:21:30+00:00

Rep. Marjorie Taylor Greene responded to the White House on Monday in her own statement claiming, 'The White House needs to learn how sarcasm works.'

## GMA lovers Amy Robach and T.J. Holmes will remain off-air until ABC completes 'internal review'
 - [https://www.dailymail.co.uk/news/article-11530121/GMA-lovers-Amy-Robach-T-J-Holmes-remain-air-ABC-completes-internal-review.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530121/GMA-lovers-Amy-Robach-T-J-Holmes-remain-air-ABC-completes-internal-review.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 19:18:07+00:00

ABC News boss Kim Goodwin is said to have told staff today in a memo that she is aware Robach and Holmes' affair had become a 'distraction'.

## Army intelligence corporal is cleared of sexually assaulting female colleague by slapping her bottom
 - [https://www.dailymail.co.uk/news/article-11530071/Army-intelligence-corporal-cleared-sexually-assaulting-female-colleague-slapping-bottom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11530071/Army-intelligence-corporal-cleared-sexually-assaulting-female-colleague-slapping-bottom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 19:08:36+00:00

Corporal Wayne Parker, 39, said he was 'pretty inebriated' when he smacked the woman's backside as she bent over a pool table at a St Patrick's day celebration, a court martial heard.

## Idaho murder victim's mom says she plans to raise money for reward to help catch daughter's killer
 - [https://www.dailymail.co.uk/news/article-11529655/Idaho-murder-victims-mom-says-plans-raise-money-reward-help-catch-daughters-killer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529655/Idaho-murder-victims-mom-says-plans-raise-money-reward-help-catch-daughters-killer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 18:46:16+00:00

The mother of one of the murdered University of Idaho students says she is looking to raise money to offer a reward for any information leading to a break in the case.

## EXCLUSIVE Royal insiders' fury over Harry and Meghan's claims of 'institutional gaslighting'
 - [https://www.dailymail.co.uk/news/article-11529863/EXCLUSIVE-Royal-insiders-fury-Harry-Meghans-claims-institutional-gaslighting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529863/EXCLUSIVE-Royal-insiders-fury-Harry-Meghans-claims-institutional-gaslighting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 18:38:46+00:00

In a new trailer for the second part of their lucrative tell-all Netflix documentary, the Duke and Duchess of Sussex talk about 'institutional gaslighting'.

## Suspended NBC correspondent Miguel Almaguer returns after retracted segment on Paul Pelosi attack
 - [https://www.dailymail.co.uk/news/article-11529627/Suspended-NBC-correspondent-Miguel-Almaguer-returns-retracted-segment-Paul-Pelosi-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529627/Suspended-NBC-correspondent-Miguel-Almaguer-returns-retracted-segment-Paul-Pelosi-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 18:31:57+00:00

NBC News correspondent Miguel Almaguer, who was tanked off the network's airwaves last month after reporting on Paul Pelosi, returned on Monday to deliver a weather update on the Today show.

## Is Hollywood finally listening? Top Gun and Yellowstone nominated for Golden Globes
 - [https://www.dailymail.co.uk/news/article-11529439/Is-Hollywood-finally-listening-Gun-Yellowstone-nominated-Golden-Globes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529439/Is-Hollywood-finally-listening-Gun-Yellowstone-nominated-Golden-Globes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 18:18:44+00:00

Kevin Costner has been nominated for Best Actor in a Drama series for his role as John Dutton in Yellowstone, the nostalgic, anti-woke, pro-America drama on Peacock.

## Hunter Biden's laptop: Voters lacked 'critical' information in 2020 election, survey shows
 - [https://www.dailymail.co.uk/news/article-11529381/Hunter-Bidens-laptop-Voters-lacked-critical-information-2020-election-survey-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529381/Hunter-Bidens-laptop-Voters-lacked-critical-information-2020-election-survey-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 18:18:20+00:00

Respondents said the FBI and the intelligence community deliberately misled the public by urging Facebook and Twitter to stop spreading such stories, which it deemed foreign 'disinformation'.

## Father and son convicted in lottery scam where they collected more than $20M
 - [https://www.dailymail.co.uk/news/article-11529647/Father-son-convicted-lottery-scam-collected-20M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529647/Father-son-convicted-lottery-scam-collected-20M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 18:15:57+00:00

Ali Jaafar, 63, and Yousef Jaafar, 29, in a lottery scheme in which the father and son cashed winning lottery tickets on behalf of the ticket holders to avoid taxes and receive tax refunds.

## Nurse Lucy Letby 'used plunger on end of a syringe to force milk and air into baby', trial hears
 - [https://www.dailymail.co.uk/news/article-11529915/Nurse-Lucy-Letby-used-plunger-end-syringe-force-milk-air-baby-trial-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529915/Nurse-Lucy-Letby-used-plunger-end-syringe-force-milk-air-baby-trial-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 18:09:16+00:00

Neonatal nurse Lucy Letby used the plunger on the end of a syringe to force milk and air into one of the babies she allegedly tried to murder, a medical expert told a jury today.

## Retired Moscow police captain says Idaho campus killer may have been motivated by revenge
 - [https://www.dailymail.co.uk/news/article-11529211/Retired-Moscow-police-captain-says-Idaho-campus-killer-motivated-revenge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529211/Retired-Moscow-police-captain-says-Idaho-campus-killer-motivated-revenge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 18:07:28+00:00

Former Moscow Police Captain Paul Kwaitkowski, 64, spoke amid mounting pressure for authorities to make a breakthrough in the murder investigation which is yet to zero in on a suspect one month later.

## Prominent DeSantis donor in suspected suicide was 'under investigation for sexual misconduct'
 - [https://www.dailymail.co.uk/news/article-11529615/Prominent-DeSantis-donor-suspected-suicide-investigation-sexual-misconduct.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529615/Prominent-DeSantis-donor-suspected-suicide-investigation-sexual-misconduct.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:41:11+00:00

A prominent donor to Florida governor Ron DeSantis died in a suspected suicide amid a police probe into allegations of sexual misconduct, it has emerged.

## Landing gear on MH370 was DOWN, experts claim
 - [https://www.dailymail.co.uk/news/article-11529681/Landing-gear-MH370-experts-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529681/Landing-gear-MH370-experts-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:40:00+00:00

Last month, a landing gear door was found in the possession of a Madagascan fisherman. According to experts, it is the first piece of evidence to be found to suggest a deliberate act.

## Paddy 'the Bady' Pimblett is the 'kid next door' with the iconic fringe who is taking UFC by storm
 - [https://www.dailymail.co.uk/news/article-11528571/Paddy-Bady-Pimblett-kid-door-iconic-fringe-taking-UFC-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528571/Paddy-Bady-Pimblett-kid-door-iconic-fringe-taking-UFC-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:38:51+00:00

Dubbed the new Conor McGregor, 'Paddy the Baddy' made headlines at the weekend by picking up his fourth consecutive win in the ring, this time over American Jared Gordon in Las Vegas.

## Supreme Court takes up ANOTHER case challenging Biden's massive student loans forgiveness plan
 - [https://www.dailymail.co.uk/news/article-11529797/Supreme-Court-takes-case-challenging-Bidens-massive-student-loans-forgiveness-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529797/Supreme-Court-takes-case-challenging-Bidens-massive-student-loans-forgiveness-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:38:43+00:00

The Supreme Court  has agreed to hear arguments on a second case challenging President Biden's student loan forgiveness program after it was blocked in a lower court.

## American 'shopping' tourists are flocking to Europe to snap up luxury bargains from designer brands
 - [https://www.dailymail.co.uk/news/article-11529427/American-shopping-tourists-flocking-Europe-snap-luxury-bargains-designer-brands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529427/American-shopping-tourists-flocking-Europe-snap-luxury-bargains-designer-brands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:38:33+00:00

In the week of Black Friday, spending by US holidaymakers in Europe rose by 40 per cent compared with 2019, the last shopping season unaffected by the Covid pandemic.

## Businessman wanted over charges of helping Oleg Deripaska evade sanctions faces extradition hearing
 - [https://www.dailymail.co.uk/news/article-11529379/Businessman-wanted-charges-helping-Oleg-Deripaska-evade-sanctions-faces-extradition-hearing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529379/Businessman-wanted-charges-helping-Oleg-Deripaska-evade-sanctions-faces-extradition-hearing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:36:52+00:00

Graham Bonham-Carter, 62, faces charges of wire fraud for allegedly funding American properties bought by Oleg Deripaska and attempting to expatriate his artwork in the US.

## Democrats LOST support with U.S. voters under 30 in dire sign for Biden's party leading into 2024
 - [https://www.dailymail.co.uk/news/article-11529185/Democrats-LOST-support-U-S-voters-30-dire-sign-Bidens-party-leading-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529185/Democrats-LOST-support-U-S-voters-30-dire-sign-Bidens-party-leading-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:36:04+00:00

Voters under 30 went 53 percent for Democratic House candidates compared with only 41 percent for Republican candidates nationwide, according to AP VoteCast.

## Ron Johnson: Senate Democrats will do nothing to preserve free speech
 - [https://www.dailymail.co.uk/news/article-11529281/Ron-Johnson-Senate-Democrats-preserve-free-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529281/Ron-Johnson-Senate-Democrats-preserve-free-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:26:31+00:00

Senator Ron Johnson said he hasn't seen any evidence that Democrats will try to stop censorship as Republicans call for more protections for free speech online following Twitter Files revelations.

## Indian lecturer was discriminated against by University of Portsmouth, tribunal rules
 - [https://www.dailymail.co.uk/news/article-11529605/Indian-lecturer-discriminated-against-University-Portsmouth-tribunal-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529605/Indian-lecturer-discriminated-against-University-Portsmouth-tribunal-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:25:39+00:00

A damning judgement found Dr Kajal Sharma was discriminated against by bosses at Portsmouth University when she failed in her application to carry on in her role in the Business and Law faculty.

## Lockerbie suspect is seen in new mugshot as families of the 207 victims praise his arrest
 - [https://www.dailymail.co.uk/news/article-11529559/Lockerbie-suspect-seen-new-mugshot-families-207-victims-praise-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529559/Lockerbie-suspect-seen-new-mugshot-families-207-victims-praise-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:24:28+00:00

The first image of the suspected Lockerbie bombmaker in US custody has emerged, as families of the 207 victims killed in the 1988 attack over Scotland praised his arrest  as a step toward justice.

## Al Roker returns to NBC's Today Show as he delivers emotional message from home
 - [https://www.dailymail.co.uk/news/article-11529241/Al-Roker-returns-NBCs-Today-delivers-emotional-message-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529241/Al-Roker-returns-NBCs-Today-delivers-emotional-message-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:23:30+00:00

Al Roker, 68, appeared upbeat upon his virtual return to NBC's Today Show on Monday morning after a heath scare

## 'Sadistic' lab technician, 30, who strangled co-worker girlfriend, 23, is found guilty of her murder
 - [https://www.dailymail.co.uk/news/article-11529759/Lab-worker-guilty-murdering-work-colleague-parents-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529759/Lab-worker-guilty-murdering-work-colleague-parents-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:23:11+00:00

Lab technician Ross McCullam has been convicted at Leicester Crown Court of murdering work colleague Megan Newborough at his parents' home in Coalville, Leicestershire.

## Buttigieg has taken 18 flights on taxpayer-funded private jets since taking office
 - [https://www.dailymail.co.uk/news/article-11529437/Buttigieg-taken-18-flights-taxpayer-funded-private-jets-taking-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529437/Buttigieg-taken-18-flights-taxpayer-funded-private-jets-taking-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 17:14:26+00:00

Transportation Secretary Pete Buttigieg has taken at least 18 flights on taxpayer-funded private jets since taking office, despite calls to cut emissions.

## Icy roads in Utah cause bus to crash injuring 22 people
 - [https://www.dailymail.co.uk/news/article-11529225/More-15-million-Americans-14-states-winter-weather-alerts-multi-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529225/More-15-million-Americans-14-states-winter-weather-alerts-multi-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 16:40:24+00:00

About 22 people have been hospitalized after a bus driver transporting 30 people lost control and  crashed in Tremonton, Utah on Monday morning.

## Largest migrant caravan in HISTORY illegally crosses the Rio Grande into  El Paso
 - [https://www.dailymail.co.uk/news/article-11529519/Largest-migrant-caravan-HISTORY-illegally-crosses-Rio-Grande-El-Paso.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529519/Largest-migrant-caravan-HISTORY-illegally-crosses-Rio-Grande-El-Paso.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 16:40:05+00:00

Possibly the largest single group of migrants illegally crossed into the U.S. Sunday night as Border Patrol braces for increased activity along the border with just nine days left until Title 42 ends.

## Mystery over two versions of Harry and Meghan Netflix trailer
 - [https://www.dailymail.co.uk/news/article-11529141/Mystery-two-versions-Harry-Meghan-Netflix-trailer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529141/Mystery-two-versions-Harry-Meghan-Netflix-trailer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 16:38:49+00:00

Netflix has issued two trailers for the second part of Harry & Meghan, fuelling speculation over who the Duke is accusing of 'lying to protect my brother'

## Pennsylvania school board treasurer can't vote for a 'cis white male' candidate for president
 - [https://www.dailymail.co.uk/news/article-11529085/Pennsylvania-school-board-treasurer-vote-cis-white-male-candidate-president.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529085/Pennsylvania-school-board-treasurer-vote-cis-white-male-candidate-president.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 16:38:22+00:00

During a school board meeting in Pennsylvania last week, a member said she would not vote for the 'only cis white male' on the board to serve as the next president.

## Remainer Tony Blair's Institute for Global Change opens EU lobbying arm in Brussels
 - [https://www.dailymail.co.uk/news/article-11529643/Remainer-Tony-Blairs-Institute-Global-Change-opens-EU-lobbying-arm-Brussels.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529643/Remainer-Tony-Blairs-Institute-Global-Change-opens-EU-lobbying-arm-Brussels.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 16:37:10+00:00

Tony Blair's Institute for Global Change, a non-profit that posted just over £66million in revenues last year, plans 'to develop, build and nurture strategic partnerships' with Eurocrats.

## San Francisco drug users are filmed lifting up manhole in crime-ridden city to recover narcotics
 - [https://www.dailymail.co.uk/news/article-11529071/San-Francisco-drug-users-filmed-lifting-manhole-crime-ridden-city-recover-narcotics.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529071/San-Francisco-drug-users-filmed-lifting-manhole-crime-ridden-city-recover-narcotics.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 16:36:47+00:00

A San Francisco resident recorded a group of drug-users gathered indiscreetly around an open manhole appearing to collect hidden drugs.

## NHS: Rogue ambulance drivers may even refuse 'life and limb care' on strike days, union warns
 - [https://www.dailymail.co.uk/health/article-11528851/NHS-Rogue-ambulance-drivers-refuse-life-limb-care-strike-days-union-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11528851/NHS-Rogue-ambulance-drivers-refuse-life-limb-care-strike-days-union-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 16:31:29+00:00

The armed forces are set to be drafted in to deal with the strikes that will see tens of thousands of paramedics walk out on December 21 and 28. No10 warned of 'serious disruption' on the days.

## Female Met Police officer, 30, with 'fiery temper'  avoids jail for assaulting man after he bit her
 - [https://www.dailymail.co.uk/news/article-11529495/Female-Met-Police-officer-30-fiery-temper-avoids-jail-assaulting-man-bit-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529495/Female-Met-Police-officer-30-fiery-temper-avoids-jail-assaulting-man-bit-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 16:27:57+00:00

PC Claudia Pastina, 30, was attending a police call when she confronted Augustine Amatta at an address in Brixton, southwest London, on February 19 last year.

## Russian is fined £400 for DREAMING about Zelensky
 - [https://www.dailymail.co.uk/news/article-11529455/Russian-fined-400-DREAMING-Zelensky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529455/Russian-fined-400-DREAMING-Zelensky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 16:20:25+00:00

Ivan Losev, 26, stood trial last week in the Siberian city of Chita in Russia's Zabaykalsky region and was found guilty under draconian laws that prohibit criticism of Putin's disastrous invasion.

## Boris Johnson calls for the UK to supply Ukraine with longer-range weapons
 - [https://www.dailymail.co.uk/news/article-11529623/Boris-Johnson-calls-UK-supply-Ukraine-longer-range-weapons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529623/Boris-Johnson-calls-UK-supply-Ukraine-longer-range-weapons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 16:18:38+00:00

Boris Johnson told the Commons it was not enough to tackle missiles and drones when they were in the air, and Kiev's forces need to hit launch sites further away.

## Bosses let workers leave early and schools tell parents to pick children up by 2pm
 - [https://www.dailymail.co.uk/news/article-11529317/Bosses-let-workers-leave-early-schools-tell-parents-pick-children-2pm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529317/Bosses-let-workers-leave-early-schools-tell-parents-pick-children-2pm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 15:54:03+00:00

After this morning's snow-fueled travel chaos, workers and parents turned their attention to the topic of trying to get home this afternoon.

## Sinister moment woman is led to a deserted area by stranger who assaulted her
 - [https://www.dailymail.co.uk/news/article-11529375/Sinister-moment-woman-led-deserted-area-stranger-assaulted-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529375/Sinister-moment-woman-led-deserted-area-stranger-assaulted-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 15:52:44+00:00

The victim had been out drinking in Newcastle city centre in March when she met Matthew Stevens (pictured), who was out separately with a friend.

## Judge REJECTS Trump's bid to have a special master look over documents seized from Mar-a-Lago
 - [https://www.dailymail.co.uk/news/article-11529469/trump-special-master-judge-aileen-cannon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529469/trump-special-master-judge-aileen-cannon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 15:41:56+00:00

Florida-based U.S. District Judge Aileen Cannon threw out the former president's lawsuit after she made an earlier controversial ruling that sided with Trump.

## Yellen admits risk of a US recession and it will take a year to achieve 'much lower inflation'
 - [https://www.dailymail.co.uk/news/article-11529235/Yellen-admits-risk-recession-year-achieve-lower-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529235/Yellen-admits-risk-recession-year-achieve-lower-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 15:41:17+00:00

'I believe by the end of next year you will see much lower inflation if there's not … an unanticipated shock,' Yellen told CBS 60 Minutes

## Bakhmut begins to resemble First World War horror of Passchendaele
 - [https://www.dailymail.co.uk/news/article-11528981/Bakhmut-begins-resemble-World-War-horror-Passchendaele.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528981/Bakhmut-begins-resemble-World-War-horror-Passchendaele.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 15:40:45+00:00

War, as they say, never changes - as the horror slowly developing around the Ukrainian city of Bakhmut proves when compared to the Battle of Passchendaele more than 100 years ago.

## Final January 6 report will include summary of Trump's 'culpability' in the riot
 - [https://www.dailymail.co.uk/news/article-11529181/Final-January-6-report-include-summary-Trumps-culpability-riot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529181/Final-January-6-report-include-summary-Trumps-culpability-riot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 15:38:56+00:00

Members of the January 6 committee have been reviewing drafts of a final report which will focus on the role of former President Donald Trump leading up to the Capitol riot.

## Amazon 'linked with purchase of Man United' after Glazers said they would consider sale
 - [https://www.dailymail.co.uk/sport/football/article-11529125/Amazon-linked-potential-purchase-Man-United-Glazers-said-consider-sale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-11529125/Amazon-linked-potential-purchase-Man-United-Glazers-said-consider-sale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 15:36:42+00:00

United's controversial owners announced last month that they would consider selling the club in a sensational statement that raised hopes among the Old Trafford fanbase.

## Worshippers are 'terrified' after PIG'S HEAD left on roof of mosque in 'hate crime'
 - [https://www.dailymail.co.uk/news/article-11529353/Worshippers-terrified-PIGS-HEAD-left-roof-mosque-hate-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529353/Worshippers-terrified-PIGS-HEAD-left-roof-mosque-hate-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 15:36:09+00:00

People discovered the animal's head as they left a gathering at Heatons Muslims Community Trust (HMCT) building on Battersea Road in Heaton Mersey, Stockport at around 9.15pm on Friday.

## TV scientist accused of FAKING data in a major dinosaur study
 - [https://www.dailymail.co.uk/sciencetech/article-11528463/TV-scientist-accused-FAKING-data-major-dinosaur-study.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-11528463/TV-scientist-accused-FAKING-data-major-dinosaur-study.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 15:34:05+00:00

Robert DePalma published a study in December 2021 that said the dinosaurs went extinct in the springtime - but a former colleague has alleged that it's based on fake data.

## Doting couple who were together for 72 years after falling in love at age 15 share a coffin
 - [https://www.dailymail.co.uk/news/article-11528971/Doting-couple-72-years-falling-love-age-15-share-coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528971/Doting-couple-72-years-falling-love-age-15-share-coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 15:14:26+00:00

Alan and June King were just 15 when they met at work and fell in love, and they remained smitten for more than seven decades.

## Putin SCRAPS his annual live TV press conference
 - [https://www.dailymail.co.uk/news/article-11529239/Putin-SCRAPS-annual-live-TV-press-conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529239/Putin-SCRAPS-annual-live-TV-press-conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 15:11:11+00:00

Russian President Vladimir Putin, who has been in power since 2000, has held a press conference in December most years of his rule. Last year, he spoke for more than four hours.

## Chris Smith shame files, as his wife is spotted after he behaves badly at a Sky Christmas party
 - [https://www.dailymail.co.uk/news/article-11527357/Chris-Smith-shame-files-wife-spotted-behaves-badly-Sky-Christmas-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527357/Chris-Smith-shame-files-wife-spotted-behaves-badly-Sky-Christmas-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 14:58:14+00:00

Chris Smith is a serial fondler who has landed in the middle of three media sex scandals. On Saturday, he was drunk and sleazy towards female co-workers. Now, his wife is picking up the pieces.

## Dems and GOP struggle on government funding deal ahead of Friday deadline
 - [https://www.dailymail.co.uk/news/article-11529051/Dems-GOP-struggle-government-funding-deal-ahead-Friday-deadline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529051/Dems-GOP-struggle-government-funding-deal-ahead-Friday-deadline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 14:57:02+00:00

Lawmakers on Capitol Hill are struggling to reach a deal to fund the government as the clock ticks towards Friday's midnight deadline to stop a shutdown.

## Prince Harry and Meghan Markle share adorable footage of Lilibet wobbling across the grass
 - [https://www.dailymail.co.uk/femail/article-11529095/Prince-Harry-Meghan-Markle-share-adorable-footage-Lilibet-wobbling-grass.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11529095/Prince-Harry-Meghan-Markle-share-adorable-footage-Lilibet-wobbling-grass.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 14:56:07+00:00

The Duke and Duchess of Sussex have shared new images of their daughter Lilibet to promote the second half of their explosive Netflix docuseries, which will be released on Thursday.

## GP crisis blamed for exacerbating Strep A outbreak in Britain
 - [https://www.dailymail.co.uk/health/strep-a/article-11528227/GP-crisis-blamed-exacerbating-Strep-outbreak-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/strep-a/article-11528227/GP-crisis-blamed-exacerbating-Strep-outbreak-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 14:51:52+00:00

EXCLUSIVE: Officials have blamed Covid restrictions for interrupting the spread of Strep A bacteria and viruses, leaving more children susceptible to catching it and becoming poorly.

## Crippling strikes threaten 'virtual Christmas': Staff are already WFH due to travel chaos
 - [https://www.dailymail.co.uk/news/article-11528441/Crippling-strikes-threaten-virtual-Christmas-Staff-WFH-travel-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528441/Crippling-strikes-threaten-virtual-Christmas-Staff-WFH-travel-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 14:38:30+00:00

Britons had to sacrifice seeing loved ones over the holiday period in 2020 and 2021 due to the Covid pandemic - but now face having to do the same due to union barons shutting down critical services.

## Police shot at Wieambilla near Chinchilla in Western Downs QLD as suspects shot in firefight
 - [https://www.dailymail.co.uk/news/article-11529131/Police-shot-Wieambilla-near-Chinchilla-Western-Downs-QLD-suspects-shot-firefight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529131/Police-shot-Wieambilla-near-Chinchilla-Western-Downs-QLD-suspects-shot-firefight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 14:37:45+00:00

Three suspects have been shot dead by specialist tactical police in a firefight at a rural Queensland town following the deaths of two police officers and a neighbour.

## Operation Northrop: Inside the NSW Police Christmas crackdown on dial-a-dealer cocaine networks
 - [https://www.dailymail.co.uk/news/article-11526975/Operation-Northrop-Inside-NSW-Police-Christmas-crackdown-dial-dealer-cocaine-networks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11526975/Operation-Northrop-Inside-NSW-Police-Christmas-crackdown-dial-dealer-cocaine-networks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 14:37:19+00:00

Daily Mail Australia can exclusively reveal that the NSW Police Force has charged 187 Sydney residents and seized more than $250,000 cash and 633g of cocaine as part of huge pre-Christmas sting.

## Republicans sound alarm on flight safety over Biden plan to send Air Marshals to border
 - [https://www.dailymail.co.uk/news/article-11528969/Republicans-sound-alarm-flight-safety-Biden-plan-send-Air-Marshals-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528969/Republicans-sound-alarm-flight-safety-Biden-plan-send-Air-Marshals-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 14:35:40+00:00

'It is imperative that we have every Federal Air Marshal tending to their actual job rather than assisting in a problem your administration created and continues to ignore,' the letter states.

## Passengers are forced to bunk up at Logan Airport after dozens of flights are canceled in snow storm
 - [https://www.dailymail.co.uk/news/article-11528881/Passengers-forced-bunk-Logan-Airport-dozens-flights-canceled-snow-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528881/Passengers-forced-bunk-Logan-Airport-dozens-flights-canceled-snow-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 14:13:10+00:00

Passengers, some who had been stuck at the airport for over 12 hours, said all hotels were booked and flight crews put out cots on the airport floor in Boston.

## BBC's Joanna Gosling overwhelmed with emotion as she announces deaths of 3 boys who fell in lake
 - [https://www.dailymail.co.uk/news/article-11528987/BBCs-Joanna-Gosling-overwhelmed-emotion-announces-deaths-3-boys-fell-lake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528987/BBCs-Joanna-Gosling-overwhelmed-emotion-announces-deaths-3-boys-fell-lake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 13:39:36+00:00

BBC news reader Joanna Gosling appeared to be overwhelmed with emotion as she announced the tragic deaths of three young boys who fell into a frozen lake.

## JK Rowling will launch women-only service for victims of sexual violence in Scotland
 - [https://www.dailymail.co.uk/news/article-11529087/JK-Rowling-launch-women-service-victims-sexual-violence-Scotland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11529087/JK-Rowling-launch-women-service-victims-sexual-violence-Scotland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 13:36:07+00:00

JK Rowling has announced she will fund a new women-only service for victims of sexual violence.

## GOLDEN GLOBES LIVE BLOG: Nominations announced as awards show returns to NBC
 - [https://www.dailymail.co.uk/news/live/article-11528935/GOLDEN-GLOBES-LIVE-BLOG-Nominations-announced-awards-returns-air.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11528935/GOLDEN-GLOBES-LIVE-BLOG-Nominations-announced-awards-returns-air.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 13:35:16+00:00

GOLDEN GLOBES LIVE BLOG: Click for all the latest updates on the nominations for the 80th annual Golden Globe Awards.

## Prince Harry and Meghan Markle share even MORE previously unseen pictures of their family life
 - [https://www.dailymail.co.uk/femail/article-11528861/Prince-Harry-Meghan-Markle-share-previously-unseen-pictures-family-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11528861/Prince-Harry-Meghan-Markle-share-previously-unseen-pictures-family-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 13:28:59+00:00

Prince Harry and Meghan Markle have shared even more private moments from their life in Montecito, UK and the UK with the public in a new trailer for the second part of their Netflix docuseries.

## Zelensky thanks Biden for 'unprecedented' support as US tops $60 BILLION in aid
 - [https://www.dailymail.co.uk/news/article-11528961/Zelensky-thanks-Biden-unprecedented-support-tops-60-BILLION-aid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528961/Zelensky-thanks-Biden-unprecedented-support-tops-60-BILLION-aid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 13:26:17+00:00

Ukrainian President Volodymyr Zelensky expressed gratitude during a call with President Joe Biden on Sunday as the U.S. Congress considers yet another request to send billions to Ukraine.

## The beauty queen Met PC living 'lavish lifestyle' thanks to Albanian drug lord husband
 - [https://www.dailymail.co.uk/news/article-11528739/The-beauty-queen-Met-PC-living-lavish-lifestyle-thanks-Albanian-drug-lord-husband.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528739/The-beauty-queen-Met-PC-living-lavish-lifestyle-thanks-Albanian-drug-lord-husband.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 13:17:35+00:00

A beauty queen Metropolitan police officer was able to live a life peppered with luxury trappings because she was married to a drug dealer, it can now be revealed.

## Snaps reveal inside Prince Harry and Meghan Markle's star-studded reception
 - [https://www.dailymail.co.uk/femail/article-11528537/Snaps-reveal-inside-Prince-Harry-Meghan-Markles-star-studded-reception.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11528537/Snaps-reveal-inside-Prince-Harry-Meghan-Markles-star-studded-reception.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 13:15:58+00:00

FEMAIL reveals the stars who can be spotted in Meghan Markle and Prince Harry's newly released photographs from their 2018 reception at Frogmore House.

## Scientists to analyse genetic material from 1475 letter written by Vlad the Impaler
 - [https://www.dailymail.co.uk/news/article-11528797/Scientists-analyse-genetic-material-1475-letter-written-Vlad-Impaler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528797/Scientists-analyse-genetic-material-1475-letter-written-Vlad-Impaler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 13:15:00+00:00

More than 500 years after Vlad Dracula's death, scientists have taken 'historical biomolecules' from missives he wrote. They hope this will give them a picture of how he lived at the time.

## Inside Lilibet's first birthday? Prince Harry and Meghan Markle share snaps of family at Frogmore
 - [https://www.dailymail.co.uk/femail/article-11528865/Inside-Lilibets-birthday-Prince-Harry-Meghan-Markle-share-snaps-family-Frogmore.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11528865/Inside-Lilibets-birthday-Prince-Harry-Meghan-Markle-share-snaps-family-Frogmore.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 13:07:20+00:00

In the new trailer for the second part of their Netflix series, the Duke and Duchess shared a number of photos of their family taken at Frogmore Cottage this summer.

## The suburbs by the beach and near the city where house prices plunged the most in 2022
 - [https://www.dailymail.co.uk/news/article-11527771/The-suburbs-beach-near-city-house-prices-plunged-2022.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527771/The-suburbs-beach-near-city-house-prices-plunged-2022.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 13:02:45+00:00

Upmarket postcodes in Sydney from the northern beaches to the inner-city suffered the sharpest price drops in 2022 as interest rates rose. Byron Bay and flood-hit Lismore also had steep declines.

## Postal workers 'are told to bin leaflets due to backlog' as parcels and letters pile up outdoors
 - [https://www.dailymail.co.uk/news/article-11528759/Postal-workers-told-bin-leaflets-backlog-parcels-letters-pile-outdoors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528759/Postal-workers-told-bin-leaflets-backlog-parcels-letters-pile-outdoors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 13:00:06+00:00

A Royal Mail worker of long service said they have never witnessed a backlog of deliveries like this before. The heaps of packages have allegedly attracted rats and other animals including a fox.

## Stephen Bear arrives at court with cane and cigar for week two of trial for 'sharing sex tape'
 - [https://www.dailymail.co.uk/news/article-11528613/Stephen-Bear-arrives-court-cane-cigar-week-two-trial-sharing-sex-tape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528613/Stephen-Bear-arrives-court-cane-cigar-week-two-trial-sharing-sex-tape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:56:53+00:00

Reality TV star Stephen Bear arrived at court while smoking a cigar this morning, where he is on trial for allegedly sharing a sex tape of his former co-star.

## Kate's go-to evening look! Princess of Wales's love affair with sequins (and Jenny Packham gowns)
 - [https://www.dailymail.co.uk/femail/article-11528563/Kates-evening-look-Princess-Waless-love-affair-sequins-Jenny-Packham-gowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11528563/Kates-evening-look-Princess-Waless-love-affair-sequins-Jenny-Packham-gowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:46:43+00:00

After the Princess of Wales recorded a message ahead of her carol service at Westminster Abbey in a red sequined dress, FEMAIL takes her best shimmering looks.

## Strep A: Disabled girl with symptoms left without antibiotics because pharmacies are 'out of stock'
 - [https://www.dailymail.co.uk/health/article-11528491/Strep-Disabled-girl-symptoms-left-without-antibiotics-pharmacies-stock.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11528491/Strep-Disabled-girl-symptoms-left-without-antibiotics-pharmacies-stock.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:46:27+00:00

Betsy Curtis, from Northumberland, who has Down's syndrome, was prescribed the drugs last Wednesday after suffering tell-tale signs of the bacterial infection for a week.

## Harry and Meghan fire MORE attacks on royal family in explosive new trailer
 - [https://www.dailymail.co.uk/news/article-11528841/Harry-Meghan-fire-attacks-royal-family-explosive-new-trailer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528841/Harry-Meghan-fire-attacks-royal-family-explosive-new-trailer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:42:19+00:00

The Duke of Sussex also accused the Royal Family of 'lying to protect my brother' - in a sign the next three episodes of the show could be the most incendiary yet.

## Mother tells children Christmas 'is cancelled' as she's hit with £8,317 vet bill
 - [https://www.dailymail.co.uk/news/article-11528829/Mother-tells-children-Christmas-cancelled-shes-hit-8-317-vet-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528829/Mother-tells-children-Christmas-cancelled-shes-hit-8-317-vet-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:40:16+00:00

Joely Eaton, 29, from Sale, Manchester took the difficult decision to amputate her beloved dog Buddy's leg after he was diagnosed with osteosarcoma, a type of bone cancer.

## Fears grow for American college student, 22, who disappeared studying in France eight days ago
 - [https://www.dailymail.co.uk/news/article-11528799/Fears-grow-American-college-student-22-disappeared-studying-France-eight-days-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528799/Fears-grow-American-college-student-22-disappeared-studying-France-eight-days-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:40:07+00:00

The parents of a 22-year-old American student missing in France say they are 'extremely concerned' for their son's wellbeing more than eight days after he disappeared

## Sister of fondue chef accuses him of emptying £1.2million from their father's bank account
 - [https://www.dailymail.co.uk/news/article-11528805/Sister-fondue-chef-accuses-emptying-1-2million-fathers-bank-account.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528805/Sister-fondue-chef-accuses-emptying-1-2million-fathers-bank-account.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:39:58+00:00

Tom Isenschmid, a London chef, is facing claims from his sister Charlotte Isenschmid that he emptied £1.2million out of their dad's bank accounts prior to his death.

## Britain's December strikes: Who is striking, why, and for how long?
 - [https://www.dailymail.co.uk/news/article-11528237/Britains-December-strikes-striking-long.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528237/Britains-December-strikes-striking-long.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:39:05+00:00

Royal Mail staff, nurses, paramedics, rail workers and Border Force officials will all stage walkouts over jobs, pay and conditions this month as Brits prepare for mayhem over Christmas.

## Putin enemy Alexei Navalny forced to share prison cell with 'homeless tramp' with hygiene problems
 - [https://www.dailymail.co.uk/news/article-11528761/Putin-enemy-Alexei-Navalny-forced-share-prison-cell-homeless-tramp-hygiene-problems.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528761/Putin-enemy-Alexei-Navalny-forced-share-prison-cell-homeless-tramp-hygiene-problems.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:23:42+00:00

Vladimir Putin is said to take an active interest in humiliating Alexei Navalny, the jailed anti-corruption campaigner and opposition leader who wants to oust him from the Kremlin.

## Your employment rights explained as weather causes chaos
 - [https://www.dailymail.co.uk/news/article-11528585/Your-employment-rights-explained-weather-causes-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528585/Your-employment-rights-explained-weather-causes-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:23:19+00:00

There are no minimum or maximum temperatures regarding getting to work, according to the Health, Safety and Welfare Regulations 1992 - but office temperatures should be reasonable and safe.

## Even Keir Starmer says nurse strikes are unaffordable
 - [https://www.dailymail.co.uk/health/article-11528259/Even-Keir-Starmer-says-nurse-strikes-unaffordable.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11528259/Even-Keir-Starmer-says-nurse-strikes-unaffordable.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:23:07+00:00

Demands from the Royal College of Nursing for a 19 per cent pay rise for NHS nurses have been decaled unaffordable by Labour Leader Keir Starmer, as nurses prepare to strike later this week.

## James Cleverly says Britain must be a 'salesman' as he plans for new partnerships across world
 - [https://www.dailymail.co.uk/news/article-11528685/James-Cleverly-says-Britain-salesman-plans-new-partnerships-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528685/James-Cleverly-says-Britain-salesman-plans-new-partnerships-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:18:22+00:00

In his first major speech as Foreign Secretary, Mr Cleverly told an audience of international diplomats that Britain could not afford to 'hang on to the comfort blanket' of its existing allies.

## Russian soldiers are beaten and locked in basements for refusing to fight in Ukraine
 - [https://www.dailymail.co.uk/news/article-11528485/Russian-soldiers-beaten-locked-basements-refusing-fight-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528485/Russian-soldiers-beaten-locked-basements-refusing-fight-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:15:00+00:00

Relatives of refusenik soldiers say they are being thrown in hell-hole basements for days on end with no food, water or bathroom facilities in order to try and force them back into combat.

## Referee Wilton Sampaio who infuriated England fans vs France 'kept on for World Cup final'
 - [https://www.dailymail.co.uk/sport/football/article-11528467/Wilton-Sampaio-infuriated-England-fans-kept-World-Cup-final.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-11528467/Wilton-Sampaio-infuriated-England-fans-kept-World-Cup-final.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 12:03:08+00:00

FIFA's decision means Sampaio could remarkably even take charge of the final this Sunday, despite a host of controversial decisions in England's 2-1 loss to France on Saturday night.

## Up to 40 people enjoyed hot food, log fires and a place to bed down after ditching their cars
 - [https://www.dailymail.co.uk/news/article-11528691/Up-40-people-enjoyed-hot-food-log-fires-place-bed-ditching-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528691/Up-40-people-enjoyed-hot-food-log-fires-place-bed-ditching-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 11:47:51+00:00

An inn in East Sussex threw its doors open overnight to forty people stranded in heavy snowfall trapped in the wintry weather.

## LadBaby joins forces with Martin Lewis as they attempt fifth Christmas No 1
 - [https://www.dailymail.co.uk/tvshowbiz/article-11528743/LadBaby-joins-forces-Martin-Lewis-attempt-fifth-Christmas-No-1.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11528743/LadBaby-joins-forces-Martin-Lewis-attempt-fifth-Christmas-No-1.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 11:42:42+00:00

The duo, Mark and Roxanne Hoyle, revealed their brand new charity  song Food Aid, a rework of the Band Aid classic, in a surprise Instagram video on Sunday.

## Elon Musk met with chorus of boos as he is brought on stage at Dave Chappelle gig
 - [https://www.dailymail.co.uk/news/article-11528559/Elon-Musk-met-chorus-boos-brought-stage-Dave-Chappelle-gig.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528559/Elon-Musk-met-chorus-boos-brought-stage-Dave-Chappelle-gig.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 11:42:04+00:00

The billionaire businessman appeared shellshocked at the hostile reception in Twitter's headquarter city and remained mostly silent on stage.

## Enormous 100ft-wide sinkhole opens up near Russian ski resort at mine [VIDEO]
 - [https://www.dailymail.co.uk/news/article-11528587/Enormous-100ft-wide-sinkhole-opens-near-Russian-ski-resort-VIDEO.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528587/Enormous-100ft-wide-sinkhole-opens-near-Russian-ski-resort-VIDEO.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 11:29:36+00:00

The huge collapse came at the Sheregesh mine in Sibera's Kemerovo region, near to a popular ski resort. Residents of a total of four homes had been earlier moved from the site amid fears of a collapse.

## Eco-mob cause MORE misery for drivers on day of snow chaos: Just Stop Oil block road in London
 - [https://www.dailymail.co.uk/news/article-11528561/Eco-mob-cause-misery-drivers-day-snow-chaos-Just-Stop-Oil-block-road-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528561/Eco-mob-cause-misery-drivers-day-snow-chaos-Just-Stop-Oil-block-road-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 11:27:18+00:00

Snow has not deterred eco-protesters Just Stop Oil as members march through London amid freezing temperatures 'to demand the government halts all new fossil fuel licences and consents'.

## Two former Denver Broncos stars will donate brains to science after death to aid head hits research
 - [https://www.dailymail.co.uk/news/article-11528461/Two-former-Denver-Broncos-stars-donate-brains-science-death-aid-head-hits-research.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528461/Two-former-Denver-Broncos-stars-donate-brains-science-death-aid-head-hits-research.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 11:24:35+00:00

A pair of ex-Denver Broncos football players have said they are willing to donate their brains to science in aid of research into a degenerative brain disease linked to repeated blows to the head

## Ukrainian forces destroy Russian T-73 in tank duel
 - [https://www.dailymail.co.uk/news/article-11528565/Ukrainian-forces-destroy-Russian-T-73-tank-duel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528565/Ukrainian-forces-destroy-Russian-T-73-tank-duel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 11:20:55+00:00

The footage, captured on a drone overlooking an unknown battlefield, shows the Ukrainian tank rolling down a road strewn with wreckage, before suddenly firing a round - landing a hit on a Russian tank.

## 'Low on petrol, can't heat my car and I have a child': 'Scared' mother stuck on snowy M25's ordeal
 - [https://www.dailymail.co.uk/news/article-11528195/Low-petrol-heat-car-child-Scared-mother-stuck-snowy-M25s-ordeal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528195/Low-petrol-heat-car-child-Scared-mother-stuck-snowy-M25s-ordeal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 11:12:41+00:00

Motorists stranded on the M25 and M11 in snowy conditions overnight were left in their freezing cars for hours - with one mother scared for her child as petrol ran out.

## Cambridge University agrees to hand colonial-era African artefacts back to Uganda
 - [https://www.dailymail.co.uk/news/article-11528469/Cambridge-University-agrees-hand-colonial-era-African-artefacts-Uganda.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528469/Cambridge-University-agrees-hand-colonial-era-African-artefacts-Uganda.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 10:54:20+00:00

The University of Cambridge Museum of Archaeology and Anthropology (MAA) is in talks with the Uganda Museum about repatriating the objects to the east African nation in 2023.

## Two schoolgirls are spotted playing on frozen lake in Wimbledon
 - [https://www.dailymail.co.uk/news/article-11528487/Two-schoolgirls-spotted-playing-frozen-lake-Wimbledon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528487/Two-schoolgirls-spotted-playing-frozen-lake-Wimbledon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 10:42:53+00:00

Two schoolgirls were this morning seen risking their lives standing on a frozen pond in London the day after six youngsters plunged into icy waters doing the same thing in Solihull.

## Double amputee, eight, is stranded without his wheelchair for five hours at Gatwick
 - [https://www.dailymail.co.uk/news/article-11528483/Double-amputee-eight-stranded-without-wheelchair-five-hours-Gatwick.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528483/Double-amputee-eight-stranded-without-wheelchair-five-hours-Gatwick.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 10:42:16+00:00

A young double amputee was left stranded at Gatwick Airport without his wheelchair for more than five hours after flights were delayed due to the adverse weather.

## Commuters have SNOWBALL fights at train stations as nation is transformed into winter wonderland
 - [https://www.dailymail.co.uk/news/article-11528367/Commuters-SNOWBALL-fights-train-stations-nation-transformed-winter-wonderland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528367/Commuters-SNOWBALL-fights-train-stations-nation-transformed-winter-wonderland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 10:30:53+00:00

Iconic landmarks across the country were blanketed in white overnight and people took full advantage of the rare conditions.

## Around 1,000 migrants line the Rio Grande waiting to cross into US as Title 42 is set to lapse
 - [https://www.dailymail.co.uk/news/article-11528347/Around-1-000-migrants-line-Rio-Grande-waiting-cross-Title-42-set-lapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528347/Around-1-000-migrants-line-Rio-Grande-waiting-cross-Title-42-set-lapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 10:30:46+00:00

The group, mostly from Cuba, Venezuela and Nicaragua, is hoping to cross into the country when Title 42 is set to lapse next week which expanded the expulsion of migrants due to Covid.

## Mother reveals Elf on a Shelf danger after toy's face was 'cremated' on a red-hot lightbulb
 - [https://www.dailymail.co.uk/news/article-11528373/Mother-reveals-Elf-Shelf-danger-toys-face-cremated-red-hot-lightbulb.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528373/Mother-reveals-Elf-Shelf-danger-toys-face-cremated-red-hot-lightbulb.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 10:30:40+00:00

Max Oliver (pictured) had just introduced the mischievous-looking elf to her son Charlie, then five, but within 15 minutes there was a burning smell.

## UK snow live: School closures, weather forecast and travel updates
 - [https://www.dailymail.co.uk/news/live/article-11528425/UK-snow-live-School-closures-London-weather-forecast-travel-updates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11528425/UK-snow-live-School-closures-London-weather-forecast-travel-updates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 10:29:46+00:00

MAILONLINE LIVEBLOG: Snow has hit the UK causing travel delays, road closures and forcing schools to shut, as the Met Office warns that ice and freezing fog will descend on the country.

## Alex Scott gets dressing down from BBC bosses after promoting Reiss outfit
 - [https://www.dailymail.co.uk/news/article-11528413/Alex-Scott-gets-dressing-BBC-bosses-promoting-Reiss-outfit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528413/Alex-Scott-gets-dressing-BBC-bosses-promoting-Reiss-outfit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 10:26:51+00:00

The former England footballer, 38, is a brand ambassador for Reiss and last week posted an image of herself working in a studio in Qatar, whilst tagging the firm in the shot.

## WORLD CUP AGENDA: BBC blazers dress down Alex Scott over endorsement for Reiss
 - [https://www.dailymail.co.uk/sport/fifa-world-cup/article-11526727/WORLD-CUP-AGENDA-BBC-blazers-dress-Alex-Scott-endorsement-Reiss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/fifa-world-cup/article-11526727/WORLD-CUP-AGENDA-BBC-blazers-dress-Alex-Scott-endorsement-Reiss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 10:03:03+00:00

MIKE KEEGAN IN QATAR: Alex Scott has been warned by BBC bosses after promoting a fashion brand on social media while working for the broadcaster in Qatar on the World Cup.

## Controlling builder who dragged girlfriend by hair and smashed her head against the pavement jailed
 - [https://www.dailymail.co.uk/news/article-11528327/Controlling-builder-dragged-girlfriend-hair-smashed-head-against-pavement-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528327/Controlling-builder-dragged-girlfriend-hair-smashed-head-against-pavement-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 09:40:40+00:00

Ashley Barker (right), 33, chased after Bethany Evans after she jumped out of a taxi - then pushed her over a wall before grabbing her blonde hair and smashing her head against the pavement.

## Man, 24, is stabbed 'in the neck' at Hyde Park's Winter Wonderland - as police hunt attacker
 - [https://www.dailymail.co.uk/news/article-11528355/Man-24-stabbed-neck-Hyde-Parks-Winter-Wonderland-police-hunt-attacker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528355/Man-24-stabbed-neck-Hyde-Parks-Winter-Wonderland-police-hunt-attacker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 09:35:00+00:00

A 24-year-old man has been rushed to hospital after being 'stabbed in the neck' at London's Winter Wonderland. The Met Police were called out to the scene in Hyde Park  before 9.30pm on Sunday.

## Second Russian shopping mall is destroyed by mystery fire
 - [https://www.dailymail.co.uk/news/article-11528207/Second-Russian-shopping-mall-destroyed-mystery-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528207/Second-Russian-shopping-mall-destroyed-mystery-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 09:26:30+00:00

The StroyPark Mall in Balashikha, to the east of Moscow, was filmed in flames early Monday morning after a fire broke out inside a shop selling construction supplies, local officials said.

## Police shot at Wieambilla near Chinchilla in Western Downs QLD as emergency situation declared
 - [https://www.dailymail.co.uk/news/article-11528283/Police-shot-Wieambilla-near-Chinchilla-Western-Downs-QLD-emergency-situation-declared.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528283/Police-shot-Wieambilla-near-Chinchilla-Western-Downs-QLD-emergency-situation-declared.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 09:26:22+00:00

Multiple police officers have been shot and an emergency situation has been declared after a man opened fire as police approached his Queensland property.

## Second journalist Khalid al-Misslam 'dies suddenly' at Qatar World Cup
 - [https://www.dailymail.co.uk/news/article-11528377/Second-journalist-Khalid-al-Misslam-dies-suddenly-Qatar-World-Cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528377/Second-journalist-Khalid-al-Misslam-dies-suddenly-Qatar-World-Cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 09:26:16+00:00

Khalid al-Misslam, a Qatari photojournalist working for Al Kass TV, died on Sunday, according to Gulf News. It comes 48 hours after US journalist Grant Wahl died from a reported 'heart attack'.

## How driving in the snow could land you 10 FINES costing up to £30,000 - and what to do to avoid them
 - [https://www.dailymail.co.uk/news/article-11528245/How-driving-snow-land-10-FINES-costing-30-000-avoid-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528245/How-driving-snow-land-10-FINES-costing-30-000-avoid-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 09:20:08+00:00

Drivers are facing treacherous conditions on the roads in the UK after heavy snow, they also could be hit with potential fines amounting up to £30,000 if they are not prepared.

## Cars crash into each other in slow motion pile up in the snow
 - [https://www.dailymail.co.uk/news/article-11528209/Cars-crash-slow-motion-pile-snow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528209/Cars-crash-slow-motion-pile-snow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 09:19:11+00:00

The crashes were caught on camera in Cheltenham, Gloucestershire and shared on social media in a video viewed more than 700,000 times.

## Channel migrants are to be housed in holiday camps
 - [https://www.dailymail.co.uk/news/article-11528267/Channel-migrants-housed-holiday-camps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528267/Channel-migrants-housed-holiday-camps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 09:16:05+00:00

Plans to house people in holiday parks as well as old student halls are expected to be announced soon by the government - and could be put into action as early as January.

## Ryanair mocks England's World Cup exit with cheeky 'they're coming home' tweet
 - [https://www.dailymail.co.uk/news/article-11528215/Ryanair-mocks-Englands-World-Cup-exit-cheeky-theyre-coming-home-tweet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528215/Ryanair-mocks-Englands-World-Cup-exit-cheeky-theyre-coming-home-tweet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 09:10:17+00:00

After the 2-1 loss on Saturday, the Irish budget airline mockingly echoed England's World Cup mantra on Twitter by saying 'they're coming home' above an image of an airport departures sign.

## Rightmove: Asking prices fall £8,000 in biggest slip for four years
 - [https://www.dailymail.co.uk/money/mortgageshome/article-11521015/Rightmove-Asking-prices-fall-8-000-biggest-slip-four-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mortgageshome/article-11521015/Rightmove-Asking-prices-fall-8-000-biggest-slip-four-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 08:43:56+00:00

Property portal said sellers had 'adjusted their expectations' in a cooling market and reduced their asking prices, as buyers exercised caution amid rising mortgage rates.

## Elderton Homes goes into administration as construction industry struggles
 - [https://www.dailymail.co.uk/news/article-11528097/Elderton-Homes-goes-administration-construction-industry-struggles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528097/Elderton-Homes-goes-administration-construction-industry-struggles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 08:04:52+00:00

Elderton Homes based in NSW announced on Monday it had appointed administrators to manage its operations going forward.

## Why have I been kicked off the Warm Home Discount scheme?
 - [https://www.dailymail.co.uk/money/pensions/article-11517965/Why-kicked-Warm-Home-Discount-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/pensions/article-11517965/Why-kicked-Warm-Home-Discount-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 07:49:47+00:00

For the last two or three years I have received the h Warm Home Discount. I have been told that this year I'm not entitled to it. Bearing in mind I receive a total of £8,500 in pension, why am I being penalised?

## Box covering statue of Christopher Columbus in Philly is removed after judge ruled against mayor
 - [https://www.dailymail.co.uk/news/article-11527919/Box-covering-statue-Christopher-Columbus-Philly-removed-judge-ruled-against-mayor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527919/Box-covering-statue-Christopher-Columbus-Philly-removed-judge-ruled-against-mayor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 07:24:15+00:00

In her ruling, Judge Mary Hannah Leavitt said the city had a 'fiduciary duty' to preserve the statue and that the monument was not considered as city property. Mayor Jim Kenny said he was 'disappointed.'

## Adelaide gang rape: Boy, 16, becomes seventh charged over alleged Hindley Street car park horror
 - [https://www.dailymail.co.uk/news/article-11528035/Adelaide-gang-rape-Boy-16-seventh-charged-alleged-Hindley-Street-car-park-horror.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528035/Adelaide-gang-rape-Boy-16-seventh-charged-alleged-Hindley-Street-car-park-horror.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 07:23:58+00:00

The 16-year-old boy from Alberton was charged him with two counts of rape. The teenager was refused bail and will appear in the Adelaide Youth Court on Monday.

## Economy defies expectations by GROWING 0.5% in October
 - [https://www.dailymail.co.uk/news/article-11528099/Economy-defies-expectations-GROWING-0-5-October.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528099/Economy-defies-expectations-GROWING-0-5-October.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 07:20:46+00:00

UK plc grew by 0.5 per cent in a bounceback after a fall in activity the previous month - which included a bank holiday for the Queen's funeral.

## Elon Musk invites Stanford epidemiologist Twitter help doctor discover why firm suppressed account
 - [https://www.dailymail.co.uk/news/article-11528005/Elon-Musk-invites-Stanford-epidemiologist-Twitter-help-doctor-discover-firm-suppressed-account.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528005/Elon-Musk-invites-Stanford-epidemiologist-Twitter-help-doctor-discover-firm-suppressed-account.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 07:11:49+00:00

Dr. Jay Bhattacharya has met with Twitter CEO Elon Musk to at San Francisco's Twitter HQ to discuss what led to his being blacklisted on the site. Bhattacharya is a tenured professor at Stanford University.

## Grant Wahl's brother says he'll be repatriated Monday after dying during Qatar World Cup
 - [https://www.dailymail.co.uk/news/article-11527961/Grant-Wahls-brother-says-hell-repatriated-Monday-dying-Qatar-World-Cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527961/Grant-Wahls-brother-says-hell-repatriated-Monday-dying-Qatar-World-Cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 07:08:06+00:00

Eric Wahl (right), the brother of American journalist Grant Wahl (left) who died while covering the world cup on Friday evening, said the body would return to the United States on Monday.

## Adelaide Zoo panda enclosure for Wang Wang and Fu Ni locked down after boy went in to get phone
 - [https://www.dailymail.co.uk/news/article-11527963/Adelaide-Zoo-panda-enclosure-Wang-Wang-Fu-Ni-locked-boy-went-phone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527963/Adelaide-Zoo-panda-enclosure-Wang-Wang-Fu-Ni-locked-boy-went-phone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 07:00:16+00:00

Adelaide Zoo was forced to lock down the panda exhibit early on Monday afternoon when they realised the teenager had jumped into the enclosure to get the  phone he dropped while filming.

## Ministers will hold emergency Cobra meeting today to discuss Christmas strike chaos
 - [https://www.dailymail.co.uk/news/article-11528055/Ministers-hold-emergency-Cobra-meeting-today-discuss-Christmas-strike-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11528055/Ministers-hold-emergency-Cobra-meeting-today-discuss-Christmas-strike-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 06:58:59+00:00

The Army is being sent in ahead of a wave of strikes over the coming weeks as Royal Mail staff, nurses, paramedics, rail employees and Border Force officials all stage walkouts.

## Weather forecast: Travel chaos as -15C Arctic freeze grinds UK to a halt
 - [https://www.dailymail.co.uk/news/article-11527999/Weather-forecast-Travel-chaos-15C-Arctic-freeze-grinds-UK-halt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527999/Weather-forecast-Travel-chaos-15C-Arctic-freeze-grinds-UK-halt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 06:57:55+00:00

Drivers were stuck on the M25 overnight as snow and ice caused havoc. More travel disruption is expected after the Met Office forecast 10cm more of snow to fall today

## Railwayman, 59, plunges 300ft to his death while taking photos with wife during Saturday hike
 - [https://www.dailymail.co.uk/news/article-11527761/Railwayman-59-plunges-300ft-death-taking-photos-wife-Saturday-hike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527761/Railwayman-59-plunges-300ft-death-taking-photos-wife-Saturday-hike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 06:57:53+00:00

Joe 'Eggy' Eggleston, 59, was hiking Mount Willard in Crawford Notch with his wife, Kelly, Saturday morning when he fell 300 feet to his death. His body was discovered about three hours later, right.

## California huge bowling ball snow storm brought SEVEN inches of snow blizzards far east as Minnesota
 - [https://www.dailymail.co.uk/news/article-11527843/California-huge-bowling-ball-snow-storm-brought-SEVEN-inches-snow-blizzards-far-east-Minnesota.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527843/California-huge-bowling-ball-snow-storm-brought-SEVEN-inches-snow-blizzards-far-east-Minnesota.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 06:54:09+00:00

A winter storm is moving across the entire country over the coming days from  the West to the Northern Plains and then into the Northeast after the jet stream moved further south than is normal.

## Virologist who funded Wuhan lab shares videos of himself in cave filled with 2.5m bats
 - [https://www.dailymail.co.uk/news/article-11527795/Virologist-funded-Wuhan-lab-shares-videos-cave-filled-2-5m-bats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527795/Virologist-funded-Wuhan-lab-shares-videos-cave-filled-2-5m-bats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 06:45:40+00:00

Virologist Dr. Peter Daszak, who has been associated with the Wuhan Institute of Virology' posted videos of himself and his research team standing in the midst of swarms of bats in Thailand this week.

## Trump claims he turned down deal that would have freed Paul Whelan in return for 'Merchant of Death'
 - [https://www.dailymail.co.uk/news/article-11527875/Trump-claims-turned-deal-freed-Paul-Whelan-return-Merchant-Death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527875/Trump-claims-turned-deal-freed-Paul-Whelan-return-Merchant-Death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 06:36:04+00:00

Trump took to his Truth Social over the weekend to slam the Biden administration's decision to free Viktor Bout, top, for WNBA star Brittney Griner, bottom..

## Major change to the NSW rental market will save tenants money from this weekend
 - [https://www.dailymail.co.uk/news/article-11527953/Major-change-NSW-rental-market-save-tenants-money-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527953/Major-change-NSW-rental-market-save-tenants-money-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 05:54:14+00:00

A controversial practice used to rent-out properties will be banned in NSW by this weekend, but there is one catch. Victoria, Queensland and Tasmania each have their own version of the regulation.

## 3 bald eagles die & 10 others sickened in Minnesota after eating euthanized animals
 - [https://www.dailymail.co.uk/news/article-11527713/3-bald-eagles-die-10-sickened-Minnesota-eating-euthanized-animals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527713/3-bald-eagles-die-10-sickened-Minnesota-eating-euthanized-animals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 05:51:38+00:00

University of Minnesota Raptor Center's executive director Victoria Hall said she is optimistic those birds will recover after they were found on the ground motionless and face down in the snow in Minneapolis

## Chilling moment a killer calmly plays with her phone after crushing her 'boyfriend'  with her car
 - [https://www.dailymail.co.uk/news/article-11527831/Chilling-moment-killer-calmly-plays-phone-crushing-boyfriend-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527831/Chilling-moment-killer-calmly-plays-phone-crushing-boyfriend-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 05:47:56+00:00

Jackline Sabana Musa drove her black Toyota Kluger into Payman Thagipur, 31, in the garage  of his apartment building in Sydney's west in June 2020. She has been found guilty of murder.

## Lynn Cannon allegedly killed by ex-husband Paul in Lansdale, Perth as partner vows to 'honour' her
 - [https://www.dailymail.co.uk/news/article-11527691/Lynn-Cannon-allegedly-killed-ex-husband-Paul-Lansdale-Perth-partner-vows-honour-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527691/Lynn-Cannon-allegedly-killed-ex-husband-Paul-Lansdale-Perth-partner-vows-honour-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 05:26:22+00:00

The grieving partner of a fatal alleged domestic violence attack has vowed to honour his late partner 'until I take my last step on this planet' as her ex-husband is charged with murdering her.

## Talarm: Woman, 82, is found alive after being stuck beneath tractor for three days
 - [https://www.dailymail.co.uk/news/article-11527873/Talarm-Woman-82-alive-stuck-beneath-tractor-three-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527873/Talarm-Woman-82-alive-stuck-beneath-tractor-three-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 04:59:24+00:00

The woman was found on a property in Talarm, west of Macksville, on the NSW north coast, on Sunday evening and suffered serious leg injuries.

## Yaraka Hotel emus: Birds banned from Queensland pub return to the town after missing for months
 - [https://www.dailymail.co.uk/news/article-11527737/Yaraka-Hotel-emus-Birds-banned-Queensland-pub-return-town-missing-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527737/Yaraka-Hotel-emus-Birds-banned-Queensland-pub-return-town-missing-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 04:53:06+00:00

The animals, Kevin and Carol, once terrorised the Yaraka Hotel in Yaraka, in south-west Queensland, stealing customers' food, drinks and even car keys.

## Australia Post releases dog attack videos as statistics show incidents have risen drastically
 - [https://www.dailymail.co.uk/news/article-11527573/Australia-Post-releases-dog-attack-videos-statistics-incidents-risen-drastically.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527573/Australia-Post-releases-dog-attack-videos-statistics-incidents-risen-drastically.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 04:37:05+00:00

Australia Post has shared the footage of canines biting at the heels of posties, jumping up on their bikes or running after them as they drive away.

## Townsville had more break-ins over Christmas than any Australian town. Where does your city come?
 - [https://www.dailymail.co.uk/news/article-11527241/The-Australian-city-robbed-Christmas-does-town-come.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527241/The-Australian-city-robbed-Christmas-does-town-come.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 04:28:02+00:00

The Australian city robbed more than any other over the Christmas period has been revealed, while Queensland emerged as the worst state for festive season burglaries.

## ChatGPT AI bot diagnoses patient in seconds in Sydney doctor Prithvi Santana's TikTok video
 - [https://www.dailymail.co.uk/news/article-11527207/ChatGPT-AI-bot-diagnoses-patient-seconds-Sydney-doctor-Prithvi-Santanas-TikTok-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527207/ChatGPT-AI-bot-diagnoses-patient-seconds-Sydney-doctor-Prithvi-Santanas-TikTok-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 04:14:19+00:00

A doctor is now 'nervous' about the future of medicine after experimenting with AI. The AI, ChatGPT, was able to list life threats, procedures and a diagnosis for a fake patient.

## New front in war over ownership of a Oscar the Cavoodle
 - [https://www.dailymail.co.uk/news/article-11527581/New-war-ownership-Oscar-Cavoodle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527581/New-war-ownership-Oscar-Cavoodle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 04:08:53+00:00

The scathing assessment from Gina Edwards' barrister, Sue Chrysanthou SC, came on the first day of a hotly-contested legal battle centred on Oscar, a celebrity Cavoodle.

## Notorious vegan activist Tash Peterson holds vigil for dead animals in raw meat section
 - [https://www.dailymail.co.uk/news/article-11527135/Notorious-vegan-activist-Tash-Peterson-holds-vigil-dead-animals-raw-meat-section.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527135/Notorious-vegan-activist-Tash-Peterson-holds-vigil-dead-animals-raw-meat-section.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 04:00:45+00:00

Tash Peterson wore a pig onesie as she carried a jar of roses into Coles at Kardinya, south-west Perth, last Tuesday.

## Abdel Ghadia, aka Slimy, is jailed after spending $700k deposited in bank account
 - [https://www.dailymail.co.uk/news/article-11527789/Abdel-Ghadia-aka-Slimy-jailed-spending-700k-deposited-bank-account.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527789/Abdel-Ghadia-aka-Slimy-jailed-spending-700k-deposited-bank-account.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 03:59:37+00:00

A rapper has been sentenced to 18 months jail for spending over $700,000 in cash that was accidentally deposited into his bank account.

## Hundreds of migrants wait to cross Rio Grande to Texas after CBP sent 20 buses back to Mexico
 - [https://www.dailymail.co.uk/news/article-11527583/Hundreds-migrants-wait-cross-Rio-Grande-Texas-CBP-sent-20-buses-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527583/Hundreds-migrants-wait-cross-Rio-Grande-Texas-CBP-sent-20-buses-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 03:57:52+00:00

Hundreds of migrants were filmed crossing illegally into El Paso, Texas from Ciudad Juárez, Mexico on Sunday night. It had been a busy weekend for CBP officials with ten days before Title 42 ends.

## Global economic slowdown to hit Australia in 2023, Barefoot Investor warns
 - [https://www.dailymail.co.uk/news/article-11526845/Global-economic-slowdown-hit-Australia-2023-Barefoot-Investor-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11526845/Global-economic-slowdown-hit-Australia-2023-Barefoot-Investor-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 03:47:51+00:00

Barefoot Investor Scott Pape sounded the alarm saying more pain was on the way for residents already grappling with an energy crisis, cost of living pressures and rising interest rates.

## Lionel Allan killed in alleged hit-and-run in Auckland was a child actor, deported from Australia
 - [https://www.dailymail.co.uk/news/article-11527081/Lionel-Allan-killed-alleged-hit-run-Auckland-child-actor-deported-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527081/Lionel-Allan-killed-alleged-hit-run-Auckland-child-actor-deported-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 03:13:44+00:00

Lionel 'Doeboy' Allan, 39, died after he was struck while walking along The Concourse in Henderson, Auckland on the night of September 30.

## Covid-19 pandemic: Major changes are coming to how Australia handles Covid
 - [https://www.dailymail.co.uk/news/article-11527603/Covid-19-pandemic-Major-changes-coming-Australia-handles-Covid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527603/Covid-19-pandemic-Major-changes-coming-Australia-handles-Covid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 02:55:27+00:00

Health Minister Mark Butler has released the national Covid health management plan on Monday, with changes to the way the country's health services deal with the virus.

## Georgia divorce lawyer is shot dead 'by estranged husband of one of his female clients'
 - [https://www.dailymail.co.uk/news/article-11527477/Georgia-divorce-lawyer-shot-estranged-husband-one-female-clients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527477/Georgia-divorce-lawyer-shot-estranged-husband-one-female-clients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 02:51:26+00:00

Doug Lewis was alone in his offices in Lawrenceville, Georgia on Wednesday evening when police say Allen Tayeh walked in and shot him dead before setting his law office on fire.

## Mitt Romney says Trump is 'the kiss of death' for GOP candidates in wake of Hershel Walker's defeat
 - [https://www.dailymail.co.uk/news/article-11527361/Mitt-Romney-says-Trump-kiss-death-GOP-candidates-wake-Hershel-Walkers-defeat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527361/Mitt-Romney-says-Trump-kiss-death-GOP-candidates-wake-Hershel-Walkers-defeat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 02:49:19+00:00

Mitt Romney said former President Donald Trump's endorsement was fatal to GOP candidate campaigns while discussing the defeat of Trump-backed Herschel Walked in Georgia's senate runoff

## Victorian Socialist Nahui Jimenez calls for police to be defunded and wants 'racist' laws abolished
 - [https://www.dailymail.co.uk/news/article-11526991/Victorian-Socialist-Nahui-Jimenez-calls-police-defunded-wants-racist-laws-abolished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11526991/Victorian-Socialist-Nahui-Jimenez-calls-police-defunded-wants-racist-laws-abolished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 02:49:08+00:00

A Victorian Socialists party member has called for police to be defunded after  the state recorded the highest police funding in the country, claiming officers harassed people of colour.

## Melbourne family in Oakleigh South furious after bus stop was moved directly in front of their home
 - [https://www.dailymail.co.uk/news/article-11526921/Melbourne-family-Oakleigh-South-furious-bus-stop-moved-directly-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11526921/Melbourne-family-Oakleigh-South-furious-bus-stop-moved-directly-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 02:40:25+00:00

Hoa Tran, her partner Nam Nguyen, and their two children, have lived in their home in Oakleigh South, in Melbourne's south-east, for seven years but now say they can't get into their driveway.

## Las Vegas woman shoots and kills carjacker with his own gun
 - [https://www.dailymail.co.uk/news/article-11527339/Las-Vegas-woman-shoots-kills-carjacker-gun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527339/Las-Vegas-woman-shoots-kills-carjacker-gun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 02:34:42+00:00

Jaylin Morrison, 18, has now been taken into custody in connection with the homicide. It's believed he was involved in trying to steal the parked car of two women waiting to go to a party.

## Experts warn of World Cup 'camel flu' - which kills up to a THIRD of everyone it strikes
 - [https://www.dailymail.co.uk/news/article-11527577/Experts-warn-World-Cup-camel-flu-kills-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527577/Experts-warn-World-Cup-camel-flu-kills-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 02:29:48+00:00

Football fans returning from Qatar are being advised to watch out for the signs of camel flu - a potentially lethal respiratory illness.

## Ex-Navy SEAL who transitioned from male to female says he's now transitioning BACK
 - [https://www.dailymail.co.uk/news/article-11527307/Ex-Navy-SEAL-transitioned-male-female-says-hes-transitioning-BACK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527307/Ex-Navy-SEAL-transitioned-male-female-says-hes-transitioning-BACK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 02:01:06+00:00

Kristin Beck, 55, the first openly transgender Navy SEAL is transitioning back to a man and their previous name, Chris. Beck served in the military for 20 years and was awarded a Purple Heart.

## Aussie holiday-makers in Ballarat go wild over dog enclosures at caravan parks
 - [https://www.dailymail.co.uk/news/article-11527167/Aussie-holiday-makers-Ballarat-wild-dog-enclosures-caravan-parks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527167/Aussie-holiday-makers-Ballarat-wild-dog-enclosures-caravan-parks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 01:57:25+00:00

Travelling Aussies have reveled in the inclusion of fenced-off enclosures for their dogs at caravan parks.

## Tradie left with no ute and Christmas bill after youths from juvenile detention allegedly stole it
 - [https://www.dailymail.co.uk/news/article-11526865/being-released-juvenile-detention.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11526865/being-released-juvenile-detention.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 01:56:06+00:00

A shattered tradie from far north Queensland faces a hefty bill in the lead up to Christmas after his ute was allegedly stolen from his home and written off in a crash several days later.

## Fallout from Chris Smith's Sky News Christmas party scandal as wife Susie Burrell walks out
 - [https://www.dailymail.co.uk/news/article-11527023/Fallout-Chris-Smiths-Sky-News-Christmas-party-scandal-wife-Susie-Burrell-walks-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527023/Fallout-Chris-Smiths-Sky-News-Christmas-party-scandal-wife-Susie-Burrell-walks-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 01:52:42+00:00

The veteran broadcaster 's future in television and radio is hanging by a thread after he was pulled off air by Sky News and 2GB as the networks investigate allegations of misconduct.

## Brittany Higgins, Bruce Lehrmann case: Cops now facing a SECOND probe
 - [https://www.dailymail.co.uk/news/article-11527517/Brittany-Higgins-Bruce-Lehrmann-case-Cops-facing-SECOND-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527517/Brittany-Higgins-Bruce-Lehrmann-case-Cops-facing-SECOND-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 01:52:16+00:00

ACT attorney-general Shane Rattenbury said he's concerned about conduct through the trial and could launch an inquiry, days after a major law enforcement integrity body announced a probe.

## TikTok shows Cloncurry mum saving son from snake with a baby in her arms at their outback home
 - [https://www.dailymail.co.uk/news/article-11526823/TikTok-shows-Cloncurry-mum-saving-son-snake-baby-arms-outback-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11526823/TikTok-shows-Cloncurry-mum-saving-son-snake-baby-arms-outback-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 01:24:39+00:00

CCTV footage has caught an Aussie mum stepping into action to protect her young son from a massive snake in outback Queensland - even as she clutches her other young child in her arms.

## Environment Agency staff are next to walk out as they plan strikes over pay dispute
 - [https://www.dailymail.co.uk/news/article-11527439/Environment-Agency-staff-walk-plan-strikes-pay-dispute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527439/Environment-Agency-staff-walk-plan-strikes-pay-dispute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 01:22:17+00:00

Environment Agency workers in England are to take industrial action in the coming weeks, including stopping attending incidents such as floods, water pollution, spills, waste fires and fly-tipping.

## Baby milk should be supplied in plain packaging because marketing can exploit parents, WHO warns
 - [https://www.dailymail.co.uk/news/article-11527385/Baby-milk-supplied-plain-packaging-marketing-exploit-parents-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527385/Baby-milk-supplied-plain-packaging-marketing-exploit-parents-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 01:21:51+00:00

Formula milk should be sold in plain packaging to stop parents being exploited by marketing, the World Health Organisation has said.

## One-armed college basketball player, 19, scores 5 points for Northwestern State
 - [https://www.dailymail.co.uk/news/article-11527049/One-armed-college-basketball-player-19-scores-5-points-Northwestern-State.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527049/One-armed-college-basketball-player-19-scores-5-points-Northwestern-State.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 01:01:26+00:00

Hansel Emmanuel came on in the second half to register his first college basketball points in a 91-73 win for the Demons over Louisiana-Monroe on Saturday night. He was two-of-three from the field.

## Dan Andrews snubs ABC' star Virginia Trioli after fiery interview
 - [https://www.dailymail.co.uk/news/article-11526733/Dan-Andrews-snubs-ABC-star-Virginia-Trioli-fiery-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11526733/Dan-Andrews-snubs-ABC-star-Virginia-Trioli-fiery-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 01:01:12+00:00

Leading ABC broadcaster Virginia Trioli appears to have paid for her ambush of the Victorian premier with his decision to pick her lower-rating colleague for his first post-election interview.

## Met Police ends bid to fire officer over child abuse video as bosses accept appeal court ruling
 - [https://www.dailymail.co.uk/news/article-11527447/Met-Police-ends-bid-fire-officer-child-abuse-video-bosses-accept-appeal-court-ruling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527447/Met-Police-ends-bid-fire-officer-child-abuse-video-bosses-accept-appeal-court-ruling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 01:00:43+00:00

Scotland Yard last night finally gave up a three-year legal fight to sack a female black superintendent convicted of possessing child abuse images.

## Mystery deepens around mum whose body was found after she went for a midnight bushwalk
 - [https://www.dailymail.co.uk/news/article-11526989/Mystery-deepens-mum-body-went-midnight-bushwalk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11526989/Mystery-deepens-mum-body-went-midnight-bushwalk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:59:36+00:00

Esther Wallace, 47, was reported missing on 11 days ago after she went hiking with her partner at Federal Falls in Mount Canobolas, central-west NSW, at 1.30am. Her body was found on Sunday.

## Virginia Tech soccer player CAN sue school for benching her after she refused to take the knee
 - [https://www.dailymail.co.uk/news/article-11527223/Virginia-Tech-soccer-player-sue-school-benching-refused-knee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527223/Virginia-Tech-soccer-player-sue-school-benching-refused-knee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:54:56+00:00

Thomas Cullen, a federal judge, ruled that Kiersten Hening may move forward with her First Amendment suit against Coach Charles 'Chugger' Adair for allegedly violating her First Amendment rights.

## Vladimir Putin can't be trusted in peace talks over Ukraine and could use them to buy time
 - [https://www.dailymail.co.uk/news/article-11527401/Vladimir-Putin-trusted-peace-talks-Ukraine-use-buy-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527401/Vladimir-Putin-trusted-peace-talks-Ukraine-use-buy-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:48:16+00:00

Vladimir Putin could use peace talks with Ukraine to buy time to rearm and cannot be trusted to enter negotiations in good faith, the Foreign Secretary James Cleverly (pictured) warned yesterday.

## MPs urge Rishi Sunak to stand firm over Brexit Bill amid rumours it will go on ice
 - [https://www.dailymail.co.uk/news/article-11527383/MPs-urge-Rish-Sunak-stand-firm-Brexit-Bill-amid-rumours-ice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527383/MPs-urge-Rish-Sunak-stand-firm-Brexit-Bill-amid-rumours-ice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:41:20+00:00

Eurosceptic Tory MPs last night urged Rishi Sunak to proceed with the Brexit Bill after reports he has put it on ice in a bid to improve relations with the EU.

## Agency doctors can cost NHS up to £5,200 for just ONE shift, figures reveal
 - [https://www.dailymail.co.uk/news/article-11527235/Agency-doctors-cost-NHS-5-200-just-ONE-shift-figures-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527235/Agency-doctors-cost-NHS-5-200-just-ONE-shift-figures-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:41:17+00:00

NHS trusts have shelled out as much as £5,200 for a single agency doctor shift, in a sign of how desperate the staffing crisis in the health service has become.

## Labour wouldn't meet nurses' 19% pay demand
 - [https://www.dailymail.co.uk/news/article-11527209/Labour-wouldnt-meet-nurses-19-pay-demand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527209/Labour-wouldnt-meet-nurses-19-pay-demand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:38:30+00:00

Labour would not meet nurses' pay demands, the party's health spokesman said yesterday as he warned the NHS had to 'reform or die'.

## Social media bosses might face jail for 'failing' to protect children under proposed new rules
 - [https://www.dailymail.co.uk/news/article-11527319/Social-media-bosses-face-jail-failing-protect-children-proposed-new-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527319/Social-media-bosses-face-jail-failing-protect-children-proposed-new-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:37:30+00:00

Backbench Conservative MPs are pushing to toughen up the Online Safety Bill in order to make tech executives 'sit up and take notice'.

## Fashionable Malia Obama dons blue scarf and jeans - with matching smoothie - on lazy Saturday in LA
 - [https://www.dailymail.co.uk/news/article-11527001/Fashionable-Malia-Obama-dons-blue-scarf-jeans-matching-smoothie-lazy-Saturday-LA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527001/Fashionable-Malia-Obama-dons-blue-scarf-jeans-matching-smoothie-lazy-Saturday-LA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:36:51+00:00

Malia Obama, 24, was seen walking with friends in Los Angeles on Saturday after making a trip to pick up smoothies at Sun Life Organics. Malia ordered a blue Blue Majik, which matched her outfit.

## Taxpayers foot £150m bill for woke staff training, think-tank says
 - [https://www.dailymail.co.uk/news/article-11527329/Taxpayers-foot-150m-bill-woke-staff-training-think-tank-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527329/Taxpayers-foot-150m-bill-woke-staff-training-think-tank-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:34:10+00:00

Government bodies also employed more than 7,500 members of staff to deal with issues of 'equality, diversity, and inclusivity', costing the taxpayer a further £340million a year.

## Asylum-seekers housing crisis could take up majority of our foreign aid budget, minister says
 - [https://www.dailymail.co.uk/news/article-11527317/Asylum-seekers-housing-crisis-majority-foreign-aid-budget-minister-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527317/Asylum-seekers-housing-crisis-majority-foreign-aid-budget-minister-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:29:43+00:00

International development minister Andrew Mitchell (pictured) said he was  forced to 'pause' decisions on aid funding because Home Office demands on his budget were 'effectively out of control'.

## Heart sculpture tribute to mark anniversary of Hillcrest Primary School jumping castle tragedy
 - [https://www.dailymail.co.uk/news/article-11526941/Heart-sculpture-tribute-mark-anniversary-Hillcrest-Primary-School-jumping-castle-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11526941/Heart-sculpture-tribute-mark-anniversary-Hillcrest-Primary-School-jumping-castle-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:01:58+00:00

A metal heart sculpture will be placed in Market Square in Devonport on Thursday to acknowledge the tragedy, which occurred on December 15, 2021 at nearby Hillcrest Primary School.

## New Zealand man's 1993 Toyota Corolla hits two million kilometre milestone
 - [https://www.dailymail.co.uk/news/article-11526821/New-Zealand-mans-1993-Toyota-Corolla-hits-two-million-kilometre-milestone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11526821/New-Zealand-mans-1993-Toyota-Corolla-hits-two-million-kilometre-milestone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:01:27+00:00

A New Zealand man's 1993 Toyota Corolla has clocked more than two million kilometres - and the car is still running to this day.

## Florida woman, 38, is arrested after young child is found in home surrounded by 300 RATS
 - [https://www.dailymail.co.uk/news/article-11527025/Florida-woman-38-arrested-young-child-home-surrounded-300-RATS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11527025/Florida-woman-38-arrested-young-child-home-surrounded-300-RATS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-12 00:00:30+00:00

Shannon Marie Morgan, 38, was arrested Wednesday night after Citrus County sheriff's deputies found a young child in her home living in deplorable conditions.


# Source:Jeff Kaufmann, URL:https://www.jefftk.com/news.rss, language:en-US

## Green Line Extension Opening Dates
 - [https://www.jefftk.com/p/green-line-extension-opening-dates](https://www.jefftk.com/p/green-line-extension-opening-dates)
 - RSS feed: https://www.jefftk.com/news.rss
 - date published: 2022-12-12 08:00:00+00:00

<p><span>

Talk of extending the Green Line from Lechmere to Ball Square and
Tufts goes back </span>

<a href="https://www.jefftk.com/p/mbta-extensions-planned-and-actual">a very
long way</a>, but it's finally open!



<p>

<a href="https://www.jefftk.com/ball-square-green-line-receipt-big.jpg"><img class="mobile-fullwidth" height="486" src="https://www.jefftk.com/ball-square-green-line-receipt.jpg" width="550" /><div class="image-vertical-spacer"></div></a>

</p>

<p>

In celebration, I wanted to go back and collect the completion dates
we've been given over the years:

</p>

<p>

</p>

<ul>
<li><p><a href="https://archives.lib.state.ma.us/handle/2452/841807">1990-12-19</a>:
2010

</p></li>
<li><p><a href="https://archives.federalregister.gov/issue_slice/1994/10/4/50495-50499.pdf#page=2">1994-10-04</a>:
2011-12-31

</p></li>
<li><p><!--<a
href="https://www.bizjournals.com/boston/stories/2006/11/27/daily31.html">2006-11-17</a>--><!--<a
href="https://www.govinfo.gov/content/pkg/FR-2008-07-31/html/E8-17595.htm">2008-07-31</a>--><a href="https://www.epa.gov/sites/default/files/2017-10/documents/ma-310-cmr-7-36.pdf">2006-11-17</a>:
2014-12-31

</p></li>
<li><p><a href="https://www.newspapers.com/clip/87456626/the-boston-globe/">2010-07-10</a>:
2015-10

</p></li>
<li><p><a href="https://www.newspapers.com/clip/87455079/the-boston-globe/">2011-08-02</a>:
2018 (Fall) to 2020

</p></li>
<li><p><a href="https://patch.com/massachusetts/somerville/construction-firm-hired-for-green-line-extension">2013-07-29</a>:
2019 or 2020.

</p></li>
<li><p><a href="https://web.archive.org/web/20161209145509/https://www.bostonglobe.com/metro/2016/12/07/new-green-line-stations-opening-delayed/S9Gc1c6PtbiSz7Wj3FVKkM/story.html">2016-12-08</a>: 2021

</p></li>
<li><p><a href="https://cdn.mbta.com/sites/default/files/2021-06/2021-06-21-fmcb-14-green-line-extension-update.pdf">2021-06-21</a>: 2022-05

</p></li>
<li><p><a href="https://www.wbur.org/news/2022/02/24/mbta-somerville-green-line-open">2022-02-24</a>:
2022 (Late Summer)

</p></li>
<li><p><a href="https://www.mbta.com/news/2022-08-05/building-better-t-glx-medford-branch-open-late-november-2022-shuttle-buses-replace">2022-08-05</a>:
2022-11 (Late in the month)

</p></li>
<li><p><a href="https://www.boston.com/news/local-news/2022/11/17/mbta-green-line-extension-medford-opening">2022-11-17</a>: 2022-12-12

</p></li>
</ul>



<p>

(Thanks to u/Master_Dogs on reddit for <a href="https://www.reddit.com/r/Somerville/comments/yxsfke/comment/iwqsbji/?utm_source=reddit&amp;utm_medium=web2x&amp;context=3">helping
me compile these</a>.)


  </p>

<p><i>Comment via: <a href="https://www.facebook.com/jefftk/posts/pfbid0TQjget7zKuHEaFxTPoSEmWDNDGf3tQKd7pmx5m6Wd2xKQScDzMvdU13sJ3ua2We5l">facebook</a>, <a href="https://lesswrong.com/posts/jAjjJrmrc8i4b8fog">lesswrong</a>, <a href="https://mastodon.mit.edu/@jefftk/109501221578056483">mastodon</a></i></p>


# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Kuba Sienkiewicz odebrał kartę mobilizacyjną. "Nie grałem jeszcze nigdy w orkiestrze wojskowej"
 - [https://tvn24.pl/najnowsze/kuba-sienkiewicz-dostal-karte-mobilizacyjna-lider-elektrycznych-gitar-komentuje-6541278?source=rss](https://tvn24.pl/najnowsze/kuba-sienkiewicz-dostal-karte-mobilizacyjna-lider-elektrycznych-gitar-komentuje-6541278?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2022-12-19 10:36:26+00:00

<img alt="Kuba Sienkiewicz odebrał kartę mobilizacyjną. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nqkoz2-kuba-sienkiewicz-dostal-karte-mobilizacyjna-6541133/alternates/LANDSCAPE_1280" />
    Lider Elektrycznych Gitar Kuba Sienkiewicz poinformował, że otrzymał kartę mobilizacyjną. "Biorą już rocznik 61. Cieszę się z tego. To jest bardzo dobry rocznik. O dużej wartości bojowej" - skomentował. Według planów powołania na ćwiczenia wojskowe w przyszłym roku, powołani mogą być także ci, którzy nie przeszli przeszkolenia wojskowego, ale posiadają określoną specjalizację.

## Rosyjsko-chińskie manewry. Moskwa wysyła cztery okręty
 - [https://tvn24.pl/swiat/rosja-i-chiny-przeprowadza-manewry-na-morzu-wschodniochinskim-6540694?source=rss](https://tvn24.pl/swiat/rosja-i-chiny-przeprowadza-manewry-na-morzu-wschodniochinskim-6540694?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2022-12-19 08:38:18+00:00

<img alt="Rosyjsko-chińskie manewry. Moskwa wysyła cztery okręty" src="https://tvn24.pl/najnowsze/cdn-zdjecie54fb5f842b42d5d68ce8845d91d880e4-krazownik-wariag-to-okret-flagowy-floty-pacyfiku-3711023/alternates/LANDSCAPE_1280" />
    Rosja i Chiny przeprowadzą wspólne ćwiczenia morskie, które rozpoczną się w tym tygodniu, a zakończą przed końcem roku - przekazała agencja Interfax, powołując się na rosyjski resort obrony. W manewrach mają wziąć udział cztery rosyjskie okręty i sześć chińskich.


# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Raffaella - studio session at The Current (music + interview)
 - [https://www.youtube.com/watch?v=awqDzDhjZaA](https://www.youtube.com/watch?v=awqDzDhjZaA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-12-20 00:00:00+00:00

During a visit to The Current, new-to-Minneapolis singer Raffaella performed music from her recent EP, Live, Raff, Love (Act 1). Stripped down to just guitar, bass, and drums, the three-song performance gives listeners a rock ‘n’ roll feel to Raffaella's spirited pop music.

00:00 Buick
03:22 Blonde
06:21 Lipstick
09:58 Interview

Guest: Raffaella
Video: Evan Clark
Audio: Derek Ramirez
Host and Producer: Diane

Band members:
Raffaella - voice
Sara L'Abriola - guitar
Megan Mahoney - bass
Joey Hayes - Drums

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

This activity is made possible in part by the Minnesota Legacy Amendment's Arts & Cultural Heritage Fund.

#raffaella #liverafflove #minnesotamusic #minneapolismusic #rafflalala #thelocalshow #blonde #buick #lipstick #popmusic #meganmahoney #hank #saralabriola

## Michaela Anne – three-song performance (live for The Current)
 - [https://www.youtube.com/watch?v=4EZOGmA2oSE](https://www.youtube.com/watch?v=4EZOGmA2oSE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-12-19 00:00:00+00:00

Touring in support of her latest album, "Oh To Be That Free," Nashville-based singer-songwriter Michaela Anne stopped at the Radio Heartland studio at The Current to perform a set of songs from the album. Watch that three-song set above.

Songs Performed
00:00:00 Oh To Be That Free Again
00:03:18 I’m Only Human
00:06:22 Chasing Days

Credits
Guest - @MichaelaAnneMusic 
Producer - Mike Pengra
Video Director - Evan Clark
Audio - Cameron Wiley
Graphics - Natalia Toledo
Digital Producer - Luke Taylor 

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

#michaelaannemusic #yeprocrecords


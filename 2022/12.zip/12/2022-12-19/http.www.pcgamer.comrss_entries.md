# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## After 3 years of work, modders have remastered the first Star Wars FPS
 - [https://www.pcgamer.com/after-3-years-of-work-modders-have-remastered-the-first-star-wars-fps](https://www.pcgamer.com/after-3-years-of-work-modders-have-remastered-the-first-star-wars-fps)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 22:40:32+00:00

Making a source port of Dark Forces was no blue milk run.

## Epic slammed with half-a-billion dollar FTC fine in landmark ruling over Fortnite's failure to protect childrens' privacy
 - [https://www.pcgamer.com/Epic-slammed-with-half-a-billion-dollar-FTC-fine-in-landmark-ruling-over-Fortnites-failure-to-protect-childrens-privacy](https://www.pcgamer.com/Epic-slammed-with-half-a-billion-dollar-FTC-fine-in-landmark-ruling-over-Fortnites-failure-to-protect-childrens-privacy)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 18:16:40+00:00

'No developer creates a game with the intention of ending up here', says Epic.

## How to get warp discs and farm warp crystals in High on Life
 - [https://www.pcgamer.com/high-on-life-warp-discs-crystal-farm](https://www.pcgamer.com/high-on-life-warp-discs-crystal-farm)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 17:29:20+00:00

Buy yourself some little easter eggs.

## Where to find the Valor vendor in WoW: Dragonflight
 - [https://www.pcgamer.com/world-of-warcraft-dragonflight-valor-vendor](https://www.pcgamer.com/world-of-warcraft-dragonflight-valor-vendor)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 16:32:27+00:00

And how to upgrade your Mythic+ gear.

## How to watch the full Demon Wind movie in High on Life
 - [https://www.pcgamer.com/high-on-life-demon-wind](https://www.pcgamer.com/high-on-life-demon-wind)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 15:31:31+00:00

Tammy and the T-Rex not enough?

## New hotfix for The Witcher 3 next-gen update 'should improve overall stability and performance'
 - [https://www.pcgamer.com/the-witcher-3-next-gen-update-hotfix](https://www.pcgamer.com/the-witcher-3-next-gen-update-hotfix)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 15:27:07+00:00

Try this patch if you're struggling with performance issues or crashing in The Witcher 3 post next-gen update.

## Where to find the safe code in Crisis Core Reunion
 - [https://www.pcgamer.com/crisis-core-final-fantasy-7-reunion-safe-code](https://www.pcgamer.com/crisis-core-final-fantasy-7-reunion-safe-code)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 14:40:14+00:00

How to solve the Fourth Wonder of Nibelheim.

## NVIDIA is canning GameStream after nine years and users are pissed
 - [https://www.pcgamer.com/nvidia-is-canning-gamestream-after-nine-years-and-users-are-pissed](https://www.pcgamer.com/nvidia-is-canning-gamestream-after-nine-years-and-users-are-pissed)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 12:49:25+00:00

The functionality will be removed from all Shield TV devices early next year.

## Valve is paying a whole lot of developers to keep the Steam Deck's open-source software going
 - [https://www.pcgamer.com/valve-is-paying-a-whole-lot-of-developers-to-keep-the-steam-decks-open-source-software-going](https://www.pcgamer.com/valve-is-paying-a-whole-lot-of-developers-to-keep-the-steam-decks-open-source-software-going)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 12:44:09+00:00

More like Black Mesa graphics drivers.

## ROCCAT's new gaming accessories merge power with beauty
 - [https://www.pcgamer.com/roccats-new-gaming-accessories-merge-power-with-beauty](https://www.pcgamer.com/roccats-new-gaming-accessories-merge-power-with-beauty)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 11:42:32+00:00

Translucent light-emitting surfaces and powerful internals make this hardware a must for the discerning gamer.

## In a tornado of turn-based tactics, Hard West 2 went unfairly overlooked
 - [https://www.pcgamer.com/in-a-tornado-of-turn-based-tactics-hard-west-2-went-unfairly-overlooked](https://www.pcgamer.com/in-a-tornado-of-turn-based-tactics-hard-west-2-went-unfairly-overlooked)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 10:00:53+00:00

Cowboys versus zombies is a real good time.

## Best Strategy Game 2022: Total War: Warhammer 3
 - [https://www.pcgamer.com/best-strategy-game-2022-total-war-warhammer-3](https://www.pcgamer.com/best-strategy-game-2022-total-war-warhammer-3)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 10:00:40+00:00

Immortal Empires makes this the biggest, most exciting strategy release of the year.

## Best Ongoing Game 2022: Guild Wars 2
 - [https://www.pcgamer.com/best-ongoing-game-2022-guild-wars-2](https://www.pcgamer.com/best-ongoing-game-2022-guild-wars-2)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 10:00:30+00:00

A new expansion and an old return.

## PC Gamer's Game of the Year Awards 2022
 - [https://www.pcgamer.com/game-of-the-year-awards-2022](https://www.pcgamer.com/game-of-the-year-awards-2022)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 10:00:04+00:00

We reveal PC gaming's brightest stars of the last 12 months.

## Two Point Campus takes me back to cosy, nerdy days spent with my sister
 - [https://www.pcgamer.com/two-point-campus-takes-me-back-to-cosy-nerdy-days-spent-with-my-sister](https://www.pcgamer.com/two-point-campus-takes-me-back-to-cosy-nerdy-days-spent-with-my-sister)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 10:00:02+00:00

Those memories of playing Theme Hospital on a tiny CRT will never die.

## Today's Wordle 548 answer and hint for Monday, December 19
 - [https://www.pcgamer.com/wordle-548-answer-december-19](https://www.pcgamer.com/wordle-548-answer-december-19)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 08:05:46+00:00

Wordle today: The solution and a hint for the #548 puzzle.

## Who should Henry Cavill play in Amazon's Warhammer 40,000?
 - [https://www.pcgamer.com/who-should-henry-cavill-play-in-amazons-warhammer-40000](https://www.pcgamer.com/who-should-henry-cavill-play-in-amazons-warhammer-40000)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 06:59:24+00:00

It's a setting with a surfeit of large lads to choose from.

## You can buy a portable quantum computer for under $9K
 - [https://www.pcgamer.com/you-can-buy-a-portable-quantum-computer-for-under-dollar9k](https://www.pcgamer.com/you-can-buy-a-portable-quantum-computer-for-under-dollar9k)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 04:50:36+00:00

Baby's first qubits.

## Duke Nukem Forever Restoration mod releasing first slice this month
 - [https://www.pcgamer.com/duke-nukem-forever-restoration-mod-releasing-first-slice-this-month](https://www.pcgamer.com/duke-nukem-forever-restoration-mod-releasing-first-slice-this-month)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 01:01:49+00:00

Who wants some? Well, us.

## Five new Steam games you probably missed (December 19, 2022)
 - [https://www.pcgamer.com/five-new-steam-games-you-probably-missed-december-19-2022](https://www.pcgamer.com/five-new-steam-games-you-probably-missed-december-19-2022)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-12-19 00:54:53+00:00

Sorting through every new game on Steam so you don't have to.


# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## Microsoft Teams Premium uses AI to automatically recap your meetings
 - [https://www.digitaltrends.com/computing/microsoft-launches-teams-premium-preview/](https://www.digitaltrends.com/computing/microsoft-launches-teams-premium-preview/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2022-12-19 21:40:43.165666+00:00

Microsoft has just made Teams Premium available for a short trial run, offering a range of new features.


# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Bee Weak-ly News Update 12/16/22: Elon Musk Raises Cash, SBF Arrested, and James Cameron Gets Covid
 - [https://www.youtube.com/watch?v=3GJZDN5Grqg](https://www.youtube.com/watch?v=3GJZDN5Grqg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-12-19 21:55:03+00:00

The Babylon Bee’s Adam Yenser brings you the news you need to know like Elon Musk having a yard sale, Sam Bankman-Fried getting arrested, and James Cameron having to miss the premiere of Avatar 2.

Watch the full episode: https://www.youtube.com/watch?v=zgQDv5PtDMA&amp;t=396s

Check out Adam Yenser's New DryBar Comedy Special: https://www.drybarcomedy.com/adamy

Subscribe to our new podcast channel: https://www.youtube.com/@TheBabylonBeePodcast

Follow The Babylon Bee Podcast: https://www.youtube.com/thebabylonbeepodcast
Instagram: https://www.instagram.com/thebabylonbeepodcast/
Twitter: https://twitter.com/babylonbeepod
Facebook: https://www.facebook.com/TheBabylonBeePodcast/

## Meet Kamala Harris's 6-Year-Old Speechwriter
 - [https://www.youtube.com/watch?v=po3PsDntkVE](https://www.youtube.com/watch?v=po3PsDntkVE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-12-19 20:08:07+00:00

Have you ever wondered how Kamala Harris comes up with her brilliant insights? Meet Oliver Bartholomew, the vice president's 6-year-old speechwriter. He writes words good.

Watch the full video: https://youtu.be/T3_nN0ERPL4

#shorts #short


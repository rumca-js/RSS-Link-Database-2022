# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Idaho murders: Police should have released Hyundai information 'immediately,' former Det. Ted Williams says
 - [https://www.foxnews.com/us/idaho-murders-police-should-released-hyundai-information-immediately-former-det-ted-williams-says](https://www.foxnews.com/us/idaho-murders-police-should-released-hyundai-information-immediately-former-det-ted-williams-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 23:52:19+00:00

Fox News contributor and former D.C. Det. Ted Williams believes Idaho police should have released information about a white Hyundai spotted near the crime scene sooner.

## Harvey Weinstein found guilty in LA rape trial
 - [https://www.foxnews.com/entertainment/harvey-weinstein-found-guilty-rape-trial](https://www.foxnews.com/entertainment/harvey-weinstein-found-guilty-rape-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 23:50:57+00:00

Jurors reached verdict in Harvey Weinstein LA sexual assault trial Monday. The convicted rapist is already serving a 23-year sentence in New York.

## Biden administration appoints Kennedy as special envoy for Northern Ireland: 'knifed Britain in the back'
 - [https://www.foxnews.com/world/biden-administration-appoints-kennedy-special-envoy-northern-ireland-knifed-britain-back](https://www.foxnews.com/world/biden-administration-appoints-kennedy-special-envoy-northern-ireland-knifed-britain-back)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 23:32:53+00:00

The Biden administration appointed Joseph Kennedy III as a special envoy of Northern Ireland as trade agreements in the region are under negotiation between Britain and the EU.

## Running 1 mile a day is gaining popularity online: How it can improve your health
 - [https://www.foxnews.com/lifestyle/running-1-mile-day-gaining-popularity-online-how-can-improve-health](https://www.foxnews.com/lifestyle/running-1-mile-day-gaining-popularity-online-how-can-improve-health)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 23:31:09+00:00

Content creators and social media users are challenging their cardiovascular fitness by running a mile per day for 30 days. Here's what new runners should know.

## Florida teen allegedly stabbed, beat mother with frying pan over keeping his room clean
 - [https://www.foxnews.com/us/florida-teen-stabbed-beat-mother-room-clean](https://www.foxnews.com/us/florida-teen-stabbed-beat-mother-room-clean)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 23:22:45+00:00

A Florida teenager severely beat this mother after she kept telling him to clean his room, authorities said.

## January 6 Committee holds final meeting Monday, takes action against Trump, allies
 - [https://www.foxnews.com/live-news/january-6-committee-holds-final-meeting-monday-expected-action-against-trump-allies](https://www.foxnews.com/live-news/january-6-committee-holds-final-meeting-monday-expected-action-against-trump-allies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 23:15:51+00:00

The House Jan. 6 committee held what's expected to be its final meeting Monday. The panel issued criminal referrals to the Justice Department against former President Trump.

## TCU star Max Duggan declares for NFL Draft ahead of College Football Playoff
 - [https://www.foxnews.com/sports/tcu-star-max-duggan-declares-nfl-draft-ahead-college-football-playoff](https://www.foxnews.com/sports/tcu-star-max-duggan-declares-nfl-draft-ahead-college-football-playoff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 23:13:38+00:00

TCU quarterback Max Duggan declared for the 2023 NFL Draft on Monday, less than two weeks from TCU's College Football Playoff game against Michigan on Dec. 31.

## The 6 biggest lies from Mayorkas and DHS about Team Biden's post-Title 42 plans
 - [https://www.foxnews.com/opinion/6-biggest-lies-mayorkas-dhs-about-team-bidens-post-title-42-plans](https://www.foxnews.com/opinion/6-biggest-lies-mayorkas-dhs-about-team-bidens-post-title-42-plans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 23:09:09+00:00

If you read the Department of Homeland Security's 'Update on the Southwest Border Security and Preparedness Ahead of Court-Ordered Lifting of Title 42' you'll find lots of falsehoods.

## Fox News Poll: 37% say 2022 was good to them, highest since 2019
 - [https://www.foxnews.com/politics/fox-news-poll-37-2022-good-highest-since-2019](https://www.foxnews.com/politics/fox-news-poll-37-2022-good-highest-since-2019)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 23:00:42+00:00

A new Fox News poll said a little more than a third of all voters said 2022 was a good year from them, up from the 2020 COVID lows but still a reflection of higher inflation.

## Jan 6 committee hearing's conclusion panned: A 'group of actors who refuse to leave the stage'
 - [https://www.foxnews.com/media/jan-6-committee-hearing-conclusion-panned-group-actors-who-refuse-leave-stage](https://www.foxnews.com/media/jan-6-committee-hearing-conclusion-panned-group-actors-who-refuse-leave-stage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 23:00:24+00:00

The House Select Committee investigating the January 6, 2021 attack on the United States Capitol held its final hearing of this session on Monday afternoon.

## Supreme Court temporarily pauses lifting Title 42 border restrictions
 - [https://www.foxnews.com/politics/supreme-court-temporarily-pauses-lifting-title-42-border-restrictions](https://www.foxnews.com/politics/supreme-court-temporarily-pauses-lifting-title-42-border-restrictions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 22:52:38+00:00

The U.S. Supreme Court has temporarily blocked the Biden administration from ending Title 42, the pandemic-era immigration policy that expelled migrants at the border out of health concerns.

## Netanyahu shreds New York Times for 'demonizing Israel for decades' after scathing editorial
 - [https://www.foxnews.com/media/netanyahu-shreds-new-york-times-demonizing-israel-decades-after-scathing-editorial](https://www.foxnews.com/media/netanyahu-shreds-new-york-times-demonizing-israel-decades-after-scathing-editorial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 22:45:36+00:00

Israel's incoming PM Benjamin Netanyahu called out the New York Times for demonizing Israel for decades after the paper warned his new cabinet would undermine democracy.

## Jan. 6 Committee criminal referrals of Trump are political 'theater,' DOJ likely to 'ignore' say legal experts
 - [https://www.foxnews.com/politics/jan-6-committee-criminal-referrals-trump-political-theater-doj-likely-ignore-say-legal-experts](https://www.foxnews.com/politics/jan-6-committee-criminal-referrals-trump-political-theater-doj-likely-ignore-say-legal-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 22:41:18+00:00

Legal expert says that DOJ is likely to "ignore" the committee's criminal referrals of former President Trump and could have a counterproductive effect.

## White House unable to describe what Kamala Harris is doing on immigration
 - [https://www.foxnews.com/politics/white-house-unable-describe-kamala-harris-immigration](https://www.foxnews.com/politics/white-house-unable-describe-kamala-harris-immigration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 22:34:53+00:00

White House Press Secretary Karine Jean-Pierre said Monday that she does not "have anything to lay out" on Vice President Kamala Harris' role to address the border crisis.

## Massachusetts police identify man accused of breaking into station with chainsaw, dangling children out window
 - [https://www.foxnews.com/us/massachusetts-police-identify-man-accused-breaking-station-chainsaw-dangling-children-window](https://www.foxnews.com/us/massachusetts-police-identify-man-accused-breaking-station-chainsaw-dangling-children-window)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 22:29:17+00:00

Brien Buckley, 35, was arrested on Sunday after allegedly breaking into the Cohasset police station with a chainsaw then barricading himself in his home with two children.

## World vaccination rates have reached their lowest point in years. Could COVID be to blame?
 - [https://www.foxnews.com/media/world-vaccination-rates-reached-lowest-point-years-covid-blame](https://www.foxnews.com/media/world-vaccination-rates-reached-lowest-point-years-covid-blame)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 22:08:58+00:00

CDC and WHO data indicate declines in childhood vaccine coverage in several nations across the world, including measles, diphtheria-tetanus-pertussis (DTP3) and more.

## Ring doorbell ‘swatting’ and livestream scheme leads to charges for pair from Wisconsin, North Carolina
 - [https://www.foxnews.com/us/ring-doorbell-swatting-livestream-scheme-wisconsin-north-carolina](https://www.foxnews.com/us/ring-doorbell-swatting-livestream-scheme-wisconsin-north-carolina)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 22:07:47+00:00

Two people are charged with swatting several homes and live-streaming the police response on social media.

## World Series champ Tom Browning dead at 62
 - [https://www.foxnews.com/sports/world-series-champ-tom-browning-dead](https://www.foxnews.com/sports/world-series-champ-tom-browning-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 21:50:40+00:00

Tom Browning, a former star pitcher for the Cincinnati Reds who won a World Series in 1990 with the team, died Monday after officers found him unresponsive in his Kentucky home.

## Jan. 6 Committee releases 154-page executive summary detailing Trump's 'unlawful' conduct, criminal referrals
 - [https://www.foxnews.com/politics/jan-6-committee-releases-executive-summary-detailing-trumps-unlawful-conduct](https://www.foxnews.com/politics/jan-6-committee-releases-executive-summary-detailing-trumps-unlawful-conduct)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 21:42:13+00:00

The Jan. 6 House committee unveiled Monday an introductory report detailing its impetus for referring criminal charges against former President Donald Trump to the DOJ.

## White House insists end of Title 42 doesn’t mean border is open, says doubters do the work of 'the smugglers'
 - [https://www.foxnews.com/politics/white-house-insists-end-title-42-doesnt-mean-border-open-dodge-doubters-smugglers](https://www.foxnews.com/politics/white-house-insists-end-title-42-doesnt-mean-border-open-dodge-doubters-smugglers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 21:37:27+00:00

Title 42 is set to expire on Wednesday, but the White House told reporters on Monday that this will not signal that borders will be open.

## Drag queen starring in Christmas play wants to ‘kick down’ traditional values: ‘f--- family’
 - [https://www.foxnews.com/media/drag-queen-staring-christmas-play-wants-kick-down-traditional-values-f-family](https://www.foxnews.com/media/drag-queen-staring-christmas-play-wants-kick-down-traditional-values-f-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 21:30:39+00:00

A prominent drag queen starring in the "adult-only" sequel of the Dr. Seuss Christmas classic, The Grinch, said she welcomes "any opportunity that we have to kick down traditional family values."

## Chicago police searching for missing Northwestern student last seen on FaceTime with his father
 - [https://www.foxnews.com/us/chicago-police-searching-missing-northwestern-student-facetime](https://www.foxnews.com/us/chicago-police-searching-missing-northwestern-student-facetime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 21:24:58+00:00

Chicago police are searching 25-year-old Peter Salvino, a Northwestern University doctoral student who was last seen over FaceTime around 12:15 a.m. on Sunday.

## Texas, Arizona and 17 other states ask SCOTUS for stay in eliminating Title 42 border protocol
 - [https://www.foxnews.com/us/texas-arizona-states-ask-scotus-stay-eliminating-title-border-protocol](https://www.foxnews.com/us/texas-arizona-states-ask-scotus-stay-eliminating-title-border-protocol)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 21:17:31+00:00

Nineteen states requested the Supreme Court of the United States put Title 42 on hold for a review of the U.S. District Court's decision to allow the measure to expire on Dec. 21.

## Here's how much range electric vehicles lose in the cold
 - [https://www.foxnews.com/auto/how-much-range-electric-vehicles-lose-cold](https://www.foxnews.com/auto/how-much-range-electric-vehicles-lose-cold)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 21:09:47+00:00

A new report from Recurrent found that the amount of range electric vehicles lose in the cold varies dramatically from model to model and can be improved.

## Australian, Taiwan authorities foil alleged plot to smuggle meth into Australia using 3D printers
 - [https://www.foxnews.com/world/australian-taiwan-smuggle-meth-australia-3d-printers](https://www.foxnews.com/world/australian-taiwan-smuggle-meth-australia-3d-printers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 21:08:05+00:00

Authorities foiled a plot by an international crime syndicate to smuggle methamphetamine hidden inside 3D printers into Australia.

## Martin Scorsese flipped a desk in frustration with Harvey Weinstein during 'Gangs of New York': Report
 - [https://www.foxnews.com/media/martin-scorsese-flipped-desk-frustration-harvey-weinstein-gangs-of-new-york-report](https://www.foxnews.com/media/martin-scorsese-flipped-desk-frustration-harvey-weinstein-gangs-of-new-york-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 21:00:42+00:00

Martin Scorsese's dislike for Harvey Weinstein came to light when the two men worked together on the 2002 film "Gangs of New York" alongside Leonardo DiCaprio.

## Meghan Markle, Prince Harry's new doc slammed by experts: They're 'only given a platform' due to prince's DNA
 - [https://www.foxnews.com/entertainment/meghan-markle-prince-harrys-new-doc-slammed-experts-theyre-only-given-platform-due-princes-dna](https://www.foxnews.com/entertainment/meghan-markle-prince-harrys-new-doc-slammed-experts-theyre-only-given-platform-due-princes-dna)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:49:36+00:00

Prince Harry and Meghan Markle's upcoming Netflix documentary about "inspiring leaders" was criticized by royal experts in a new interview with Fox News Digital.

## Idaho murders: Lawyer for victim's family says police may be in 'over their heads'
 - [https://www.foxnews.com/us/idaho-murders-lawyer-victims-family-says-police-over-their-heads](https://www.foxnews.com/us/idaho-murders-lawyer-victims-family-says-police-over-their-heads)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:45:20+00:00

An attorney representing the family of slain University of Idaho student Kaylee Goncalves said Moscow police may be 'in over their heads.'

## NYC 'Bling Bishop' accused of defrauding parishioner of retirement money to fund luxury lifestyle: indictment
 - [https://www.foxnews.com/us/nyc-bling-bishop-accused-defrauding-parishioner-retirement-money-fund-luxury-lifestyle-indictment](https://www.foxnews.com/us/nyc-bling-bishop-accused-defrauding-parishioner-retirement-money-fund-luxury-lifestyle-indictment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:39:54+00:00

Brooklyn Bishop Lamor Miller-Whitehead is accused of extorting a businessman, defrauding a parishioner out of retirement funds and lying to the FBI.

## Putin lands in Belarus to pressure ally to join the offensive in Ukraine war
 - [https://www.foxnews.com/world/putin-lands-belarus-pressure-ally-join-offensive-ukraine-war](https://www.foxnews.com/world/putin-lands-belarus-pressure-ally-join-offensive-ukraine-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:30:45+00:00

Russia President Vladimir Putin has landed in Belarus to talk military cooperation. He plans to pressure his ex-Soviet alley to join the offensive against Ukraine.

## Georgia man on the run after allegedly shooting ex-girlfriend, her boyfriend; considered 'armed and dangerous'
 - [https://www.foxnews.com/us/georgia-man-on-the-run-shooting-ex-girlfriend-boyfriend-considered-armed-and-dangerous](https://www.foxnews.com/us/georgia-man-on-the-run-shooting-ex-girlfriend-boyfriend-considered-armed-and-dangerous)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:23:02+00:00

Abdul Batin Rashid, 48, is on the loose after he allegedly shot his ex-girlfriend and her boyfriend inside a home in Johns Creek, Georgia, early Monday, police said.

## Republicans, Democrats warn end of Title 42 will bring immigration disaster
 - [https://www.foxnews.com/politics/republicans-democrats-warn-end-title-42-will-bring-immigration-disaster](https://www.foxnews.com/politics/republicans-democrats-warn-end-title-42-will-bring-immigration-disaster)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:18:35+00:00

Republicans and some Democrats in Congress are calling on President Biden to extend Title 42 to prevent a further immigration crisis at the U.S.-Mexico border.

## South Carolina restaurant owner forgives man who returns Santa statue he drunkenly stole: 'Wasn't thinking'
 - [https://www.foxnews.com/us/south-carolina-restaurant-owner-forgives-man-returns-santa-statue-he-drunkenly-stole-wasnt-thinking](https://www.foxnews.com/us/south-carolina-restaurant-owner-forgives-man-returns-santa-statue-he-drunkenly-stole-wasnt-thinking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:11:21+00:00

The owner of a restaurant in Greenville, South Carolina, said she would not press charges against a man who returned a Santa statue he stole after getting drunk the night before.

## Brad Pitt, Ben Affleck and Chris Martin are among exes that Gwyneth Paltrow says she is still friends with
 - [https://www.foxnews.com/entertainment/brad-pitt-ben-affleck-chris-martin-among-exes-gwyneth-paltrow-still-friends](https://www.foxnews.com/entertainment/brad-pitt-ben-affleck-chris-martin-among-exes-gwyneth-paltrow-still-friends)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:08:58+00:00

Gwyneth Paltrow revealed on Instagram that she is friendly with her exes, which include Brad Pitt, Ben Affleck and Chris Martin. The Goop founder is now married to Brad Falchuk.

## CNN, MSNBC close 2022 with continued struggles at critical primetime hour
 - [https://www.foxnews.com/media/cnn-msnbc-close-2022-continued-struggles-critical-primetime-hour](https://www.foxnews.com/media/cnn-msnbc-close-2022-continued-struggles-critical-primetime-hour)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:05:59+00:00

Both CNN and MSNBC are closing 2022 in states of uncertainty in their 9 p.m. ET time slots, one of the most critical hours of primetime television.

## Madalina Cojocari: FBI expanding search for missing 11-year-old girl in North Carolina
 - [https://www.foxnews.com/us/madalina-cojocari-fbi-expanding-search-missing-girl-north-carolina](https://www.foxnews.com/us/madalina-cojocari-fbi-expanding-search-missing-girl-north-carolina)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:05:37+00:00

Madalina Cojocari, 11, was last seen at her home in Cornelius, North Carolina, on the evening of Nov. 23, but authorities say she was not reported missing until Dec. 15.

## Border officials make desperate pleas to Biden admin as Title 42 nears end: 'Don't see any hope right now'
 - [https://www.foxnews.com/media/border-officials-make-desperate-pleas-to-biden-admin-as-title-42-nears-end-dont-see-any-hope-right-now](https://www.foxnews.com/media/border-officials-make-desperate-pleas-to-biden-admin-as-title-42-nears-end-dont-see-any-hope-right-now)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:00:55+00:00

Arizona Sheriff Mark Dannels and Texas DPS Lt. Chris Olivarez joined "The Faulkner Focus" to share their concerns with the December 21st expiration of Title 42.

## Elf in Louisiana family's home goes missing: Dog looks guilty, kids are crying
 - [https://www.foxnews.com/lifestyle/elf-louisiana-family-home-missing-dog-guilty-kids-crying](https://www.foxnews.com/lifestyle/elf-louisiana-family-home-missing-dog-guilty-kids-crying)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 20:00:50+00:00

A Louisiana family's beloved "Elf on the Shelf'" went missing after the four-year-old dog ate it off the kitchen counter. Kids were devastated (a new elf eventually showed up) — and dog was fine.

## Former NY teacher accused of injecting teen with COVID-19 vaccine without parental consent avoids jail time
 - [https://www.foxnews.com/us/former-ny-teacher-accused-injecting-teen-covid-19-vaccine-without-parental-consent-avoids-jail-time](https://www.foxnews.com/us/former-ny-teacher-accused-injecting-teen-covid-19-vaccine-without-parental-consent-avoids-jail-time)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 19:21:30+00:00

Laura Russo, a former New York high school teacher accused of injecting a teenager with a coronavirus vaccine dose at her home in Long Island, has been sentenced.

## Idaho murders: FBI adds agents to unsolved slayings as 10K tips flood in, police say
 - [https://www.foxnews.com/us/idaho-murders-more-fbi-agents-investigating-unsolved-slayings-10k-tips-flood-police-say](https://www.foxnews.com/us/idaho-murders-more-fbi-agents-investigating-unsolved-slayings-10k-tips-flood-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 19:12:09+00:00

The FBI has assigned additional FBI agents to investigate the unsolved, Nov. 13 murders of four students in their home near the University of Idaho campus, according to Moscow police.

## Trump referred to DOJ for criminal prosecution by January 6 Committee
 - [https://www.foxnews.com/politics/trump-referred-doj-criminal-prosecution-january-6-committee](https://www.foxnews.com/politics/trump-referred-doj-criminal-prosecution-january-6-committee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 19:11:26+00:00

The House Select Committee to Investigate January 6 announced it is referring Trump to DOJ, recommending the former president be criminally prosecuted over his role in the Capitol riot.

## 2 endangered Javan rhino calves spotted in Indonesia
 - [https://www.foxnews.com/world/2-endangered-javan-rhino-calves-spotted-indonesia](https://www.foxnews.com/world/2-endangered-javan-rhino-calves-spotted-indonesia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 19:06:24+00:00

Indonesia has spotted two calves of the Javan rhinoceros species, one of the most endangered creatures in the world. There are now 77 Javan rhinos in the area.

## How to track sleep on your Apple Watch
 - [https://www.foxnews.com/tech/how-track-sleep-your-apple-watch](https://www.foxnews.com/tech/how-track-sleep-your-apple-watch)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 19:02:57+00:00

Kurt "The CyberGuy" Knutsson shares a feature of Apple's Apple Watch: the Sleep app, which can track your sleep schedule to better meet your bedtime goals.

## TikTokker points out glaring mistake in 'How the Grinch Stole Christmas'
 - [https://www.foxnews.com/media/tiktokker-points-glaring-mistake-grinch-stole-christmas](https://www.foxnews.com/media/tiktokker-points-glaring-mistake-grinch-stole-christmas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 19:00:26+00:00

A eagle-eyed TikTokker spotted a mistake in the iconic Christmas film "How the Grinch Stole Christmas," having to do with the color of Jim Carey's eyes.

## Ray Liotta's fiancée celebrates the late actor on his 68th birthday
 - [https://www.foxnews.com/entertainment/ray-liottas-fiancee-celebrates-late-actor-68th-birthday](https://www.foxnews.com/entertainment/ray-liottas-fiancee-celebrates-late-actor-68th-birthday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 18:58:57+00:00

Ray Liotta's fiancée Jacy Nittolo shared a tribute to the "Goodfellas" actor on what would have been his 68th birthday. Liotta passed away in May.

## Commanders make adjustments to heavily criticized Sean Taylor memorial
 - [https://www.foxnews.com/sports/commanders-make-adjustments-heavily-criticized-sean-taylor-memorial](https://www.foxnews.com/sports/commanders-make-adjustments-heavily-criticized-sean-taylor-memorial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 18:55:31+00:00

The Washington Commanders have made changes to two-time Pro Bowler Sean Taylor's memorial after facing significant criticism online last month.

## 3 French soccer players subjected to racial abuse after World Cup loss
 - [https://www.foxnews.com/sports/3-french-soccer-players-subjected-racial-abuse-world-cup-loss](https://www.foxnews.com/sports/3-french-soccer-players-subjected-racial-abuse-world-cup-loss)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 18:55:13+00:00

Three French players were the subject of racial abuse online following their loss to Argentina in the World Cup final in penalties.

## Ex-NFL great Willie McGinest arrested for felony assault, police say
 - [https://www.foxnews.com/sports/ex-nfl-great-willie-mcginest-arrested-felony-assault-police-say](https://www.foxnews.com/sports/ex-nfl-great-willie-mcginest-arrested-felony-assault-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 18:53:30+00:00

Former NFL great Willie McGinest was arrested Monday morning in connection with a felony assault, the Los Angeles County Sheriff’s Office in West Hollywood said.

## On-demand cocktails: How party hosts are bringing the bar home for the holidays
 - [https://www.foxnews.com/lifestyle/on-demand-cocktails-party-hosts-bringing-bar-home-holidays](https://www.foxnews.com/lifestyle/on-demand-cocktails-party-hosts-bringing-bar-home-holidays)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 18:21:01+00:00

Bartesian founder and CEO Ryan Close joined "Fox & Friends" on Monday to demonstrate how his drink maker concocts classic cocktails with the click of a button — and why it makes a great holiday gift.

## In AZ, suspected DUI crash kills a sheriff’s 22-year-old son, 1-year-old granddaughter
 - [https://www.foxnews.com/us/az-suspected-dui-crash-kills-sheriffs-22-year-old-son-1-year-old-granddaughter](https://www.foxnews.com/us/az-suspected-dui-crash-kills-sheriffs-22-year-old-son-1-year-old-granddaughter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 18:14:01+00:00

A suspected DUI crash in Arizona has killed the son and granddaughter of a Pinal County sheriff. The driver of the truck was arrested under suspicion of driving under the influence.

## CNN's Don Lemon has testy exchange with Texas Republican over border crisis: 'You said a lot of things'
 - [https://www.foxnews.com/media/cnns-don-lemon-testy-exchange-texas-republican-over-border-crisis-you-said-lot-things](https://www.foxnews.com/media/cnns-don-lemon-testy-exchange-texas-republican-over-border-crisis-you-said-lot-things)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 18:08:33+00:00

CNN's Don Lemon and Kaitlan Collins clashed with former GOP congressman Will Hurd over President Biden's border policies on Wednesday ahead of Title 42's end.

## Woman snorkeling in Hawaii likely eaten by 'aggressive' shark with 'something red' around gills: officials
 - [https://www.foxnews.com/us/woman-snorkeling-hawaii-likely-eaten-by-aggressive-shark-with-something-red-around-gills-officials](https://www.foxnews.com/us/woman-snorkeling-hawaii-likely-eaten-by-aggressive-shark-with-something-red-around-gills-officials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 18:07:54+00:00

Investigators say they have determined what happened to a woman who went missing off the south shore of Maui while snorkeling with her husband earlier this month.

## Sol Ruca is using her past as star gymnast to forge her own WWE path: 'This is exactly what I should be doing'
 - [https://www.foxnews.com/sports/sol-ruca-using-her-past-star-gymnast-forge-her-own-wwe-path-exactly-what-should-doing](https://www.foxnews.com/sports/sol-ruca-using-her-past-star-gymnast-forge-her-own-wwe-path-exactly-what-should-doing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 18:05:17+00:00

Sol Ruca went from competing in acrobatics and tumbling for the Oregon Ducks to learning the ropes in the WWE ring as she represents a new wave of talent entering the company.

## Sweden's top court rejects extradition request for journalist wanted by Turkey
 - [https://www.foxnews.com/world/swedens-top-court-rejects-extradition-request-for-journalist-wanted-by-turkey](https://www.foxnews.com/world/swedens-top-court-rejects-extradition-request-for-journalist-wanted-by-turkey)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:57:00+00:00

The top court in Sweden has denied an extradition request for Bulent Kenes, a journalist who is wanted by Turkey. He is accused of being involved in a coup attempt in Turkey.

## Explosion in northern Iraq kills 9 policemen, 3 others injured
 - [https://www.foxnews.com/us/explosion-in-northern-iraq-kills-9-policemen-3-others-injured](https://www.foxnews.com/us/explosion-in-northern-iraq-kills-9-policemen-3-others-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:51:49+00:00

An explosion in northern Iraq killed nine and injured three members of the police force. It has been confirmed that the explosive device was a bomb. No one has claimed responsibility.

## 'Shipwreck skeleton' found in North Carolina’s Outer Banks sparks social media debate
 - [https://www.foxnews.com/us/shipwreck-skeleton-found-north-carolinas-outer-banks-sparks-social-media-debate](https://www.foxnews.com/us/shipwreck-skeleton-found-north-carolinas-outer-banks-sparks-social-media-debate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:49:57+00:00

A shipwreck was found in North Carolina’s Outer Banks, which sparked a social media debate about the ship’s history. The boat is believed to have been wrecked in 1890.

## Executive director of UN World Food Program to step down
 - [https://www.foxnews.com/world/executive-director-un-world-food-program-step-down](https://www.foxnews.com/world/executive-director-un-world-food-program-step-down)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:47:55+00:00

David Beasley, the executive director of the United Nations World Food Program who helped the organization win a Nobel Peace Prize, has announced plans to step down.

## Raiders' last-minute touchdown before Patriots' disastrous end draws ire toward officiating
 - [https://www.foxnews.com/sports/raiders-last-minute-touchdown-patriots-disastrous-end-draws-ire-officiating](https://www.foxnews.com/sports/raiders-last-minute-touchdown-patriots-disastrous-end-draws-ire-officiating)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:42:21+00:00

The Las Vegas Raiders tied the game on a touchdown pass from Derek Carr to Keelan Cole. But should it have counted? NFL fans debated before the rest of the debacle.

## Warning signs of suicide: What to know about prevention, red flags and how to deal with the issue
 - [https://www.foxnews.com/lifestyle/warning-signs-suicide-what-know-prevention-red-flags-deal](https://www.foxnews.com/lifestyle/warning-signs-suicide-what-know-prevention-red-flags-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:19:40+00:00

University of Memphis distinguished professor of psychology Dr. David Rudd and Verywell Mind editor-in-chief Amy Morin weigh in on how to keep an eye out for potential suicide threats and how to act.

## US airstrikes in Somalia kill 15 al-Shabab fighters
 - [https://www.foxnews.com/world/us-airstrikes-somalia-kill-15-al-shabab-fighters](https://www.foxnews.com/world/us-airstrikes-somalia-kill-15-al-shabab-fighters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:09:20+00:00

Two U.S. military airstrikes in Somalia killed a total of 15 fighters from the al-Shabab terrorist group on December 14 and 17, according to U.S. Africa Command.

## Kurdish-led group, US forces arrest Islamic State group militant that has staged attacks in Syria
 - [https://www.foxnews.com/world/kurdish-led-group-us-forces-arrest-islamic-state-group-militant-staged-attacks-syria](https://www.foxnews.com/world/kurdish-led-group-us-forces-arrest-islamic-state-group-militant-staged-attacks-syria)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:08:44+00:00

A U.S. military group teamed up with a Kurdish-led group to arrest an Islamic State group militant who staged attacks in Syria. Some 900 U.S. troops are supporting Kurdish-led forces.

## Head of Iowa Democratic Party won't seek reelection, will remain a state representative
 - [https://www.foxnews.com/us/head-iowa-democratic-party-seek-reelection-remain-state-representative](https://www.foxnews.com/us/head-iowa-democratic-party-seek-reelection-remain-state-representative)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:06:20+00:00

Ross Wilburn, the head of Iowa's Democratic Party, is not seeking reelection as the party's chairman in January. Wilburn is the party's first Black chairman.

## 'The Chosen' star Jonathan Roumie and creator Dallas Jenkins on how faith turned their lives around
 - [https://www.foxnews.com/entertainment/the-chosen-star-jonathan-roumie-creator-dallas-jenkins-how-faith-turned-lives-around](https://www.foxnews.com/entertainment/the-chosen-star-jonathan-roumie-creator-dallas-jenkins-how-faith-turned-lives-around)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:00:58+00:00

Jonathan Roumie, who stars as Jesus in "The Chosen," and the series creator, Dallas Jenkins, share their stories of how turning to God transformed their lives.

## As Walmart CEO warns of crime wave's impact on retail, reports show how thieves brazenly rip off stores
 - [https://www.foxnews.com/us/as-walmart-ceo-warns-crime-waves-impact-retail-reports-show-how-thieves-brazenly-rip-off-stores](https://www.foxnews.com/us/as-walmart-ceo-warns-crime-waves-impact-retail-reports-show-how-thieves-brazenly-rip-off-stores)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:00:53+00:00

Walmart has been battered by theft and crime incidents this year, as many businesses across the country have, ahead of the company going into the busy holiday shopping season.

## Worried about your kid freaking out during a Santa visit? Check out these tips to avoid a full-blown meltdown
 - [https://www.foxnews.com/lifestyle/worried-kid-freaking-santa-visit-check-these-tips-avoid-full-blown-meltdown](https://www.foxnews.com/lifestyle/worried-kid-freaking-santa-visit-check-these-tips-avoid-full-blown-meltdown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:00:29+00:00

Staff, including professional photographers, from Santaland at Galleria Dallas advise parents on creating the best Santa experience for their kids this Christmas

## Biden political appointees to HIV council have 'woke' pasts tied to drag queen story hour, Planned Parenthood
 - [https://www.foxnews.com/politics/biden-political-appointees-hiv-council-woke-pasts-tied-drag-queen-story-hour-planned-parenthood](https://www.foxnews.com/politics/biden-political-appointees-hiv-council-woke-pasts-tied-drag-queen-story-hour-planned-parenthood)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:00:24+00:00

Members of President Biden's Advisory Council on HIV/AIDS worked for prominent progressive advocacy groups and on "woke" issues such as "queer liberation" and "health equity."

## I am a Gen Z Republican and my time in the trenches taught me this about 2024
 - [https://www.foxnews.com/opinion/i-am-gen-z-republican-my-time-trenches-taught-me-about-2024](https://www.foxnews.com/opinion/i-am-gen-z-republican-my-time-trenches-taught-me-about-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 17:00:06+00:00

I am a Gen Z Republican and my time in the trenches taught me why the party failed during midterms on issues that Gen Z cares about. GOP must change in 2024.

## Virginia fatal crash between bus and truck leaves 3 dead
 - [https://www.foxnews.com/us/virginia-fatal-crash-between-bus-truck-leaves-3-dead](https://www.foxnews.com/us/virginia-fatal-crash-between-bus-truck-leaves-3-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 16:17:24+00:00

Three people found dead after a car crash between a bus and a truck in Virginia. The passenger bus allegedly merged into the tractor trailer’s path resulting in the vehicles colliding.

## Father of JonBenét Ramsey believes cold case can be solved in his lifetime as he pushes for new DNA testing
 - [https://www.foxnews.com/us/father-jonbenet-ramsey-believes-cold-case-solved-lifetime-pushes-new-dna-testing](https://www.foxnews.com/us/father-jonbenet-ramsey-believes-cold-case-solved-lifetime-pushes-new-dna-testing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 16:10:54+00:00

John Ramsey, father of JonBenét Ramsey is asking Boulder, Colorado, police to hand over evidence in his daughter's murder case to an independent agency.

## Biden admin pushes consumers toward LED light bulbs with new energy efficiency standard
 - [https://www.foxnews.com/politics/biden-admin-pushes-consumers-toward-led-light-bulbs-with-new-energy-efficiency-standard](https://www.foxnews.com/politics/biden-admin-pushes-consumers-toward-led-light-bulbs-with-new-energy-efficiency-standard)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 16:05:46+00:00

The Biden administration released a rule Monday aimed at moving consumers away from compact fluorescent bulbs and toward more energy efficient LED bulbs.

## Pope Francis wrote a letter of resignation in 2013 in case of health impairments
 - [https://www.foxnews.com/world/pope-francis-wrote-letter-resignation-2013-case-health-impairments](https://www.foxnews.com/world/pope-francis-wrote-letter-resignation-2013-case-health-impairments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 16:05:10+00:00

In 2013, Pope Francis wrote a resignation letter in case he faced any health issues that would have hindered him from fulfilling his responsibilities as a pope.

## Accused NYC burglar all smiles after breaking into Robert De Niro's home while actor, daughter inside: reports
 - [https://www.foxnews.com/entertainment/accused-nyc-burglar-all-smiles-breaking-robert-de-niros-home-actor-daughter-inside-reports](https://www.foxnews.com/entertainment/accused-nyc-burglar-all-smiles-breaking-robert-de-niros-home-actor-daughter-inside-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 16:02:22+00:00

A reported repeat offender was allegedly caught trying to use actor Robert De Niro’s iPad and "stealing Christmas presents" after breaking into his Upper East Side home.

## Robert De Niro's NYC townhouse burglarized while actor, daughter inside, report says
 - [https://www.foxnews.com/entertainment/robert-de-niros-nyc-townhouse-burglarized-actor-daughter-inside-report-says](https://www.foxnews.com/entertainment/robert-de-niros-nyc-townhouse-burglarized-actor-daughter-inside-report-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 16:02:22+00:00

A reported repeat offender was allegedly caught trying to use actor Robert De Niro’s iPad and "stealing Christmas presents" after breaking into his Upper East Side home.

## Grand Canyon National Park: A deeper look at a world-famous landmark
 - [https://www.foxnews.com/lifestyle/grand-canyon-national-park-deeper-look-world-famous-landmark](https://www.foxnews.com/lifestyle/grand-canyon-national-park-deeper-look-world-famous-landmark)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 15:56:13+00:00

More than a site to observe, the Grand Canyon has a rich cultural landscape that has been lived in and seen by many groups of people. It's one of the largest tourist attractions in the U.S.

## San Francisco police secretly stake out retail stores, pharmacies to curb rampant shoplifting
 - [https://www.foxnews.com/us/san-francisco-police-secretly-stake-out-retail-stores-pharmacies-curb-rampant-shoplifting](https://www.foxnews.com/us/san-francisco-police-secretly-stake-out-retail-stores-pharmacies-curb-rampant-shoplifting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 15:54:52+00:00

The San Francisco Police Department confirmed deploying officers to retail stores to arrest suspected shoplifters. Retail crimes have plagued the California city in recent years.

## Chicago suspect wanted after shooting teen in face on CTA Red Line train, police say
 - [https://www.foxnews.com/us/chicago-suspect-wanted-shooting-teen-face-cta-red-line-train-police](https://www.foxnews.com/us/chicago-suspect-wanted-shooting-teen-face-cta-red-line-train-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 15:54:45+00:00

Chicago police are searching for a suspect who shot a teen in an ear and an eye while aboard a CTA Red Line train in the city's Chinatown neighborhood early Sunday.

## Patriots' Bill Belichick reveals why Mac Jones wasn't able to throw Hail Mary on final play vs Raiders
 - [https://www.foxnews.com/sports/patriots-bill-belichick-reveals-why-mac-jones-wasnt-able-throw-hail-mary-final-play-raiders](https://www.foxnews.com/sports/patriots-bill-belichick-reveals-why-mac-jones-wasnt-able-throw-hail-mary-final-play-raiders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 15:54:22+00:00

Patriots head coach Bill Belichick was asked why a Hail Mary wasn't called on the final play that led to a miracle Raiders touchdown. His answer threw Mac Jones under the bus.

## Patriots' leads to Raiders win and NFL fans are left stunned: 'I can't stop laughing'
 - [https://www.foxnews.com/sports/patriots-leads-to-raiders-win-nfl-fans-are-left-stunned-cant-stop-laughing](https://www.foxnews.com/sports/patriots-leads-to-raiders-win-nfl-fans-are-left-stunned-cant-stop-laughing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 15:14:50+00:00

The New England Patriots completely fumbled the ending of their game against the Las Vegas Raiders and instead of going into overtime, they gave the game away.

## Amber Heard to settle defamation case with Johnny Depp for $1M
 - [https://www.foxnews.com/entertainment/amber-heard-settles-defamation-case-johnny-depp-1m](https://www.foxnews.com/entertainment/amber-heard-settles-defamation-case-johnny-depp-1m)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 15:07:48+00:00

Amber Heard and Johnny Depp settle blockbuster defamation case after years sparring in court over allegations that of domestic violence, according to a source.

## 'Woke' London museum to change name of Christmas exhibit to 'Winter Festival'
 - [https://www.foxnews.com/world/woke-london-museum-change-name-christmas-exhibit-winter-festival](https://www.foxnews.com/world/woke-london-museum-change-name-christmas-exhibit-winter-festival)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 15:06:30+00:00

The Museum of the Home, a well-known London museum, is changing the name of its Christmas exhibit to the "Winter Festival" in an attempt to be more inclusive.

## Pope Francis reveals he has written a resignation letter in case of health issues
 - [https://www.foxnews.com/world/pope-francis-reveals-he-has-written-resignation-letter-potential-health-issues](https://www.foxnews.com/world/pope-francis-reveals-he-has-written-resignation-letter-potential-health-issues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 15:05:02+00:00

Pope Francis said in an interview he wrote a resignation letter and gave it to the Vatican secretary of state in case health issues prevent him from carrying out his role.

## CNN investigative reporter Drew Griffin dies at 60 after fight with cancer
 - [https://www.foxnews.com/media/cnn-investigative-reporter-drew-griffin-dies-60-fight-cancer](https://www.foxnews.com/media/cnn-investigative-reporter-drew-griffin-dies-60-fight-cancer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 15:01:41+00:00

CNN announced on Monday that award-winning investigative reporter Drew Griffin died at age 60 after a long battle with cancer.

## 'Punisher' writer's comic book about vigilante border agent pulled from Kickstarter after woke backlash
 - [https://www.foxnews.com/media/punisher-writer-comic-book-vigilante-border-agent-pulled-kickstarter-woke-backlash](https://www.foxnews.com/media/punisher-writer-comic-book-vigilante-border-agent-pulled-kickstarter-woke-backlash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 15:01:16+00:00

Mike Baron, author of 'Private American,' defended his comic book that continues to take heat from left-wing ideologues Monday on 'Fox & Friends First.'

## Defense bill not perfect, but should result in stronger, more effective US military
 - [https://www.foxnews.com/opinion/defense-bill-not-perfect-but-should-result-in-stronger-more-effective-us-military](https://www.foxnews.com/opinion/defense-bill-not-perfect-but-should-result-in-stronger-more-effective-us-military)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 15:00:31+00:00

The foremost achievement of the bill, passed by both chambers of Congress, is a higher top line for defense spending: $858 billion for military and national security programs

## Rhode Island workers remove tents from outside of State House
 - [https://www.foxnews.com/us/rhode-island-workers-remove-tents-outside-state-house](https://www.foxnews.com/us/rhode-island-workers-remove-tents-outside-state-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 14:51:06+00:00

Tents were removed from outside the Rhode Island State House after a judge agreed with Gov. Dan McKee on the issue. The tents were a part of a protest aimed at Rhode Island housing.

## Kyiv, Ukraine struck by wave of self-exploding drones in early morning attack
 - [https://www.foxnews.com/world/kyiv-ukraine-struck-wave-self-exploding-drones-early-morning-attack](https://www.foxnews.com/world/kyiv-ukraine-struck-wave-self-exploding-drones-early-morning-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 14:40:23+00:00

Russia struck Kyiv with a wave of self-detonating drones on Monday, as residents were celebrating St. Nicholas Day, the first day of Ukraine's Christmas season.

## Arctic blast to bring life-threatening cold to much of US ahead of Christmas, forecasters warn
 - [https://www.foxnews.com/us/arctic-blast-bring-life-threatening-cold-us-ahead-christmas-forecasters-warn](https://www.foxnews.com/us/arctic-blast-bring-life-threatening-cold-us-ahead-christmas-forecasters-warn)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 14:40:03+00:00

An arctic air mass blowing south out of Canada is expected to blast large swaths of the U.S. with dangerously cold temperatures in the days leading up to Christmas.

## Arkansas police recruit dies of natural causes on 1st day of training
 - [https://www.foxnews.com/us/arkansas-police-recruit-dies-natural-causes-1st-day-training](https://www.foxnews.com/us/arkansas-police-recruit-dies-natural-causes-1st-day-training)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 14:30:35+00:00

An Arkansas police recruit dies of natural causes on his first day of training. Authorities said his death caused by sickle cell trait from heat distress and physical exertion.

## Colbert taunts new CNN CEO Chris Licht for taking difficult job: 'Told you so'
 - [https://www.foxnews.com/media/colbert-taunts-new-cnn-ceo-chris-licht-taking-difficult-job-told-you-so](https://www.foxnews.com/media/colbert-taunts-new-cnn-ceo-chris-licht-taking-difficult-job-told-you-so)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 14:29:55+00:00

"Late Show" host Stephen Colbert taunted new CNN boss Chris Licht, a former producer for his late-night show, and told him he shouldn't have taken the job.

## 3.6 magnitude earthquake takes thousands of Californians by surprise
 - [https://www.foxnews.com/us/3-6-magnitude-earthquake-takes-thousands-californians-surprise](https://www.foxnews.com/us/3-6-magnitude-earthquake-takes-thousands-californians-surprise)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 14:13:00+00:00

Thousands of Californians were woken up in the middle of the night when a magnitude 3.6 earthquake struck the San Fancisco Bay Area on Saturday.

## Man convicted in the killing of 8 members of Ohio family faces life in prison without parole
 - [https://www.foxnews.com/us/man-convicted-killing-8-members-ohio-family-faces-life-prison-without-parole](https://www.foxnews.com/us/man-convicted-killing-8-members-ohio-family-faces-life-prison-without-parole)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 14:02:33+00:00

A man who was convicted in the killing of eight people from another Ohio family is facing life without parole. The man is set to be sentenced on Dec. 19.

## Atlanta shootout leaves 2 minors fatally shot, 3 wounded at apartment
 - [https://www.foxnews.com/us/atlanta-shootout-leaves-2-minors-fatally-shot-3-wounded-apartment](https://www.foxnews.com/us/atlanta-shootout-leaves-2-minors-fatally-shot-3-wounded-apartment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 14:01:23+00:00

A shootout at an Atlanta apartment leaves two minors killed and three wounded on Saturday. The shooting was prompted by a social media dispute, police said.

## '1923' cast prepared for Harrison Ford, Helen Mirren-led show with cowboy camp and learned ‘ranch life’
 - [https://www.foxnews.com/entertainment/1923-cast-prepared-harrison-ford-helen-mirren-starring-show-cowboy-camp-learned-ranch-life](https://www.foxnews.com/entertainment/1923-cast-prepared-harrison-ford-helen-mirren-starring-show-cowboy-camp-learned-ranch-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 14:00:38+00:00

The cast of "1923" attended a two-week cowboy camp set up by creator Taylor Sheridan. The prequel series to "Yellowstone" stars Harrison Ford and Helen Mirren.

## Louisiana man fatally shot while fleeing motel after altercation about stolen drugs
 - [https://www.foxnews.com/us/louisiana-man-fatally-shot-while-fleeing-motel-altercation-stolen-drugs](https://www.foxnews.com/us/louisiana-man-fatally-shot-while-fleeing-motel-altercation-stolen-drugs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 13:41:40+00:00

A man was fatally shot while fleeing a motel after an argument about stolen drugs. Maurice Mallory was arrested Friday for the killing at a FairBridge Inn Express in Baton Rouge.

## Russia taking part in joint naval drills with China
 - [https://www.foxnews.com/world/russia-taking-part-joint-naval-drills-china](https://www.foxnews.com/world/russia-taking-part-joint-naval-drills-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 13:40:40+00:00

The navies of China and Russia will hold joint naval drills in the East China Sea. Several warships and a submarine will be deployed by the Chinese military.

## 1,004 horsepower COPO Chevrolet Camaro is the most powerful muscle car ever
 - [https://www.foxnews.com/auto/horsepower-copo-chevrolet-camaro-most-powerful-muscle-car](https://www.foxnews.com/auto/horsepower-copo-chevrolet-camaro-most-powerful-muscle-car)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 13:38:44+00:00

The 2023 Chevrolet COPO Camaro will be available with a 632 cubic-inch V8 that is rated at 1,004 horsepower and the most powerful naturally aspirated factory V8.

## Eric Adams warns of NYC service cuts to prioritize migrants as Title 42 expires: 'This can't continue'
 - [https://www.foxnews.com/us/eric-adams-warns-nyc-service-cuts-prioritize-migrants-title-42-expires-cant-continue](https://www.foxnews.com/us/eric-adams-warns-nyc-service-cuts-prioritize-migrants-title-42-expires-cant-continue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 13:33:26+00:00

Mayor Eric Adams issued a statement before Title 42 expires, saying New York City expects an additional 1,000 migrants per week and is in "urgent need" to avoid cutting services.

## Colts star's season likely over after suffering injury in loss to Vikings: report
 - [https://www.foxnews.com/sports/colts-jonathan-taylor-suffered-injury-likely-ends-season-report](https://www.foxnews.com/sports/colts-jonathan-taylor-suffered-injury-likely-ends-season-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 13:26:04+00:00

Indianapolis Colts star running back Jonathan Taylor suffered a high-ankle sprain in the loss to the Minnesota Vikings, which likely ends his 2022-23 season.

## Media outlets bury FTX-Democrat campaign financing angle
 - [https://www.foxnews.com/opinion/media-outlets-bury-ftx-democrat-campaign-financing-angle](https://www.foxnews.com/opinion/media-outlets-bury-ftx-democrat-campaign-financing-angle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 13:00:04+00:00

Our largest national media outlets are going to bury the point that FTX CEO Sam Bankman-Fried was the second-largest donor to the Democratic Party in the 2022 election cycle.

## College basketball player shot dead at NJ nature preserve, authorities investigating
 - [https://www.foxnews.com/sports/college-basketball-player-shot-dead-nj-nature-preserve-authorities-investigating](https://www.foxnews.com/sports/college-basketball-player-shot-dead-nj-nature-preserve-authorities-investigating)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 12:36:49+00:00

Phil Urban, a 20-year-old college basketball player for Post University in Connecticut, was shot dead in a Mercedes at Hopewell Valley Nature Preserve in New Jersey on Saturday.

## Topless Argentina fan could face jail time after celebrating World Cup victory
 - [https://www.foxnews.com/sports/topless-argentina-fan-could-face-jail-time-celebrating-world-cup-victory](https://www.foxnews.com/sports/topless-argentina-fan-could-face-jail-time-celebrating-world-cup-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 12:19:28+00:00

One Argentinian fan took their country's World Cup win over France on Sunday a bit too far, as she was caught by TV camera topless in celebration of the victory.

## Electric Ford F-150 Lighting starting price increased to nearly $58K
 - [https://www.foxnews.com/auto/electric-ford-f-150-lighting-price-increased](https://www.foxnews.com/auto/electric-ford-f-150-lighting-price-increased)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 12:10:35+00:00

The base price of the F-150 Lightning has increased to $57,869, which is up from $41,699 when it went on sale as the brand's first full-size electric pickup earlier this year.

## Hanukkah quiz: See how much you know about the Jewish holiday
 - [https://www.foxnews.com/lifestyle/hanukkah-quiz-see-much-you-know-jewish-holiday](https://www.foxnews.com/lifestyle/hanukkah-quiz-see-much-you-know-jewish-holiday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 12:00:36+00:00

The holiday season is here — so celebrate Hanukkah by taking this lifestyle quiz that features interesting, engaging facts about the wintertime Jewish holiday.

## Twitter's 'Thursday Night Massacre' of journalist bans mocked on social media: 'Comedic gold'
 - [https://www.foxnews.com/media/twitters-thursday-night-massacre-journalist-bans-mocked-social-media](https://www.foxnews.com/media/twitters-thursday-night-massacre-journalist-bans-mocked-social-media)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 12:00:18+00:00

Twitter users spent the weekend making fun of a Wikipedia page dedicated to multiple journalists being temporarily suspended from the social media site on Thursday.

## Americans grade Biden, nearly 50% of workers looking to quit and more top headlines
 - [https://www.foxnews.com/us/joe-biden-report-card-climate-change-economy-immigration](https://www.foxnews.com/us/joe-biden-report-card-climate-change-economy-immigration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 11:52:12+00:00

MISSING THE MARK - Americans grade Biden on the biggest issues impacting the country - and they don't hold back

## Nuggets' Nikola Jokic puts up Wilt Chamberlain-like numbers in win over Hornets
 - [https://www.foxnews.com/sports/nuggets-nikola-jokic-puts-up-wilt-chamberlain-like-numbers-win-hornets](https://www.foxnews.com/sports/nuggets-nikola-jokic-puts-up-wilt-chamberlain-like-numbers-win-hornets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 11:01:54+00:00

Denver Nuggets superstar Nikola Jokic entered a stratosphere only occupied by some of the NBA's greatest legends with his performance against the Charlotte Hornets.

## January 6 Committee holds final hearing, expected to take action against Trump, allies
 - [https://www.foxnews.com/politics/january-6-committee-holds-final-hearing-expected-take-action-trump-allies](https://www.foxnews.com/politics/january-6-committee-holds-final-hearing-expected-take-action-trump-allies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 11:00:52+00:00

The House Jan. 6 committee will hold its final congressional hearing on Monday, when the panel is expected to take action against former President Donald Trump and his allies.

## January 6 Committee holds final meeting, expected to take action against Trump, allies
 - [https://www.foxnews.com/politics/january-6-committee-holds-final-meeting-expected-take-action-trump-allies](https://www.foxnews.com/politics/january-6-committee-holds-final-meeting-expected-take-action-trump-allies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 11:00:52+00:00

The House Jan. 6 committee will hold its final meeting on Monday, when the panel is expected to take action against former President Donald Trump and his allies.

## As protests increase, Iran may soon confront the power of sports
 - [https://www.foxnews.com/opinion/protests-increase-iran-may-soon-confront-power-sports](https://www.foxnews.com/opinion/protests-increase-iran-may-soon-confront-power-sports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 11:00:24+00:00

Soccer fans and stars in Iran have been keeping the protests against the regime alive over the past few months, and Ayatollah Khameini’s mullahs may spark fury they can’t control.

## Bible verse of the day: We must trust in God, not 'the things of this world,' says faith leader
 - [https://www.foxnews.com/lifestyle/bible-verse-day-we-trust-god-not-confidence-things-world-faith-leader](https://www.foxnews.com/lifestyle/bible-verse-day-we-trust-god-not-confidence-things-world-faith-leader)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 11:00:14+00:00

The Old Testament prophet Zephaniah tried to tell the people of Judah of God's judgment and his love. A South Carolina pastor offers prayer, says following the world leads to heartbreak.

## Kirk Cameron declares a 'win' over two public libraries that denied him story hours but now have 'caved'
 - [https://www.foxnews.com/lifestyle/kirk-cameron-win-two-public-libraries-denied-story-hours-now-caved](https://www.foxnews.com/lifestyle/kirk-cameron-win-two-public-libraries-denied-story-hours-now-caved)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 10:45:26+00:00

Kirk Cameron, author of a new faith-based kids' book, is declaring a "win" over two public libraries that previously denied him a story slot but now have "caved," Fox News Digital exclusively reports.

## NY Times Sunday crossword puzzles readers with swastika shape on Hanukkah: ‘How did this get approved’
 - [https://www.foxnews.com/media/ny-times-sunday-crossword-puzzles-readers-swastika-shape-hanukkah-get-approved](https://www.foxnews.com/media/ny-times-sunday-crossword-puzzles-readers-swastika-shape-hanukkah-get-approved)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 10:00:54+00:00

The New York Times is facing criticism for publishing a crossword puzzle that looks similar to the Nazi Swastika on the first day of Hanukkah.

## Putin's fashion faux pas: Russian military uniforms unsuitable for combat in brutal winter fight
 - [https://www.foxnews.com/opinion/putins-fashion-faux-pas-russian-military-uniforms-unsuitable-combat-brutal-winter-fight](https://www.foxnews.com/opinion/putins-fashion-faux-pas-russian-military-uniforms-unsuitable-combat-brutal-winter-fight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 09:00:06+00:00

Odd decisions by the post-Soviet military leadership and Putin with regard to Russian military uniforms have resulted in deaths of Russian soldiers in Ukraine from hyperthermia.

## Georgia man put behind bars on charges he held woman captive for months, raped her
 - [https://www.foxnews.com/us/georgia-man-behind-bars-charges-held-woman-captive-months-raped](https://www.foxnews.com/us/georgia-man-behind-bars-charges-held-woman-captive-months-raped)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 08:17:46+00:00

A Georgia man was arrested and booked into jail after allegedly kidnapping a woman and holding her captive while he raped her, beat her and forced her to perform work.

## 'Titanic' movie 25th anniversary: Kate Winslet, Leonardo DiCaprio and more of the cast then and now
 - [https://www.foxnews.com/entertainment/titanic-movie-25th-anniversary-kate-winslet-leonardo-dicaprio-more-cast-then-now](https://www.foxnews.com/entertainment/titanic-movie-25th-anniversary-kate-winslet-leonardo-dicaprio-more-cast-then-now)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 07:00:56+00:00

James Cameron's epic love story "Titanic" is celebrating the 25th anniversary of its release. Here is a look at where the film's stars are now and what they have been up to since.

## Abduction survivor Elizabeth Smart shares safety advice, what 'red flags' family and friends should look for
 - [https://www.foxnews.com/media/abduction-survivor-elizabeth-smart-shares-safety-advice-red-flags-family-friends-look](https://www.foxnews.com/media/abduction-survivor-elizabeth-smart-shares-safety-advice-red-flags-family-friends-look)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 07:00:45+00:00

Elizabeth Smart, who survived a 9-month kidnapping when she was 14, offers advice on staying safe and how family and friends can identify and address "red flags."

## Climate extremists think your kids are a ‘high-cost luxury’ and bad for Mother Earth
 - [https://www.foxnews.com/opinion/your-kids-bad-environment-leftist-environmentalists-would-have-us-believe](https://www.foxnews.com/opinion/your-kids-bad-environment-leftist-environmentalists-would-have-us-believe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 07:00:39+00:00

Climate extremists think your kids are a ‘high-cost luxury’ but they get vacations or car and plane rides. They can be hypocrites while targeting parents.

## RNC chair Ronna McDaniel says her support is 'pretty solid' as she faces challengers in re-election bid
 - [https://www.foxnews.com/politics/rnc-chair-ronna-mcdaniel-says-supports-pretty-solid-she-faces-challengers-re-election-bid](https://www.foxnews.com/politics/rnc-chair-ronna-mcdaniel-says-supports-pretty-solid-she-faces-challengers-re-election-bid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 07:00:29+00:00

As Republican National Committee chair Ronna McDaniel seeks another two-year term steering the GOP’s national committee, her rivals question her advertised support for re-election

## Border Patrol union president says agents feel 'completely defeated' ahead of Title 42's end
 - [https://www.foxnews.com/politics/border-patrol-union-president-agents-feel-completely-defeated-ahead-title-42-end](https://www.foxnews.com/politics/border-patrol-union-president-agents-feel-completely-defeated-ahead-title-42-end)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 07:00:28+00:00

The president of the National Border Patrol Council is warning of low morale among his fellow agents as the men and women on the front lines face a new migrant wave.

## Biden's midterm report card: Americans grade him on economy, immigration, foreign relations and climate change
 - [https://www.foxnews.com/politics/bidens-midterm-report-card-americans-grade-economy-immigration-foreign-relations-climate-change](https://www.foxnews.com/politics/bidens-midterm-report-card-americans-grade-economy-immigration-foreign-relations-climate-change)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 07:00:26+00:00

Americans graded President Biden on his 2022 performance across several subjects, including the economy, immigration, foreign relations and climate change.

## 'Sad cat’ named Ellie surrendered by owner because animal 'wanted to cuddle,' then goes viral
 - [https://www.foxnews.com/lifestyle/sad-cat-named-ellie-surrendered-owner-animal-wanted-cuddle-goes-viral](https://www.foxnews.com/lifestyle/sad-cat-named-ellie-surrendered-owner-animal-wanted-cuddle-goes-viral)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 07:00:08+00:00

A tweet featuring Ellie, a black-and-white cat living in Virginia, went viral after it revealed an owner surrendered Ellie for being too cuddly. Ellie is now set to be adopted.

## Jamaica reimposes 'state of emergency,' tourism industry threatened by high crime rate
 - [https://www.foxnews.com/world/jamaicas-state-emergency-threatens-tourism-industry-local-authorities-struggle-high-crime-rate](https://www.foxnews.com/world/jamaicas-state-emergency-threatens-tourism-industry-local-authorities-struggle-high-crime-rate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 07:00:03+00:00

The U.S. State Department issued a travel advisory in October telling Americans to "reconsider travel" to Jamaica due to the high rate of violent crime in the country.

## Rapper Drake reportedly lost $1 million on World Cup bet
 - [https://www.foxnews.com/sports/rapper-drake-reportedly-lost-1-million-world-cup-bet](https://www.foxnews.com/sports/rapper-drake-reportedly-lost-1-million-world-cup-bet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 06:07:11+00:00

Musician Drake reportedly had some poor luck over the weekend when it came to his pick for the World Cup. He reportedly lost $1 million thanks to a technicality.

## Two Florida women arrested after allegedly running 'traveling drug roadshow'
 - [https://www.foxnews.com/us/two-florida-women-arrested-after-allegedly-running-traveling-drug-roadshow](https://www.foxnews.com/us/two-florida-women-arrested-after-allegedly-running-traveling-drug-roadshow)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 05:32:04+00:00

Two Florida women will face years behind bars after attempting to sell illegal drugs in South Florida, according to authorities. They were arrested on drug charges Friday.

## On this day in history, Dec. 19, 1843, Charles Dickens publishes 'A Christmas Carol'
 - [https://www.foxnews.com/lifestyle/this-day-history-dec-19-1843-charles-dickens-publishes-christmas-carol](https://www.foxnews.com/lifestyle/this-day-history-dec-19-1843-charles-dickens-publishes-christmas-carol)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 05:02:47+00:00

Charles Dickens published perhaps his most famous story, "A Christmas Carol," on this day in history, Dec. 19, 1843. It has become one of the most familiar holiday tales in the world.

## Giants-Commanders game ends with controversial no call in end zone: 'It's clearly a foul'
 - [https://www.foxnews.com/sports/giants-commanders-game-ends-controversial-no-call-end-zone-clearly-foul](https://www.foxnews.com/sports/giants-commanders-game-ends-controversial-no-call-end-zone-clearly-foul)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 05:01:13+00:00

The New York Giants and Washington Commanders' game came down to the very end but it was the final pass play that had the NFL world talking.

## CDC investigating multistate outbreak of norovirus stemming from raw Texas oysters
 - [https://www.foxnews.com/health/cdc-investigating-multistate-outbreak-norovirus-stemming-raw-texas-oysters](https://www.foxnews.com/health/cdc-investigating-multistate-outbreak-norovirus-stemming-raw-texas-oysters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 04:53:06+00:00

The CDC is investigating an outbreak across multiple states linking raw oysters harvested in Galveston, Texas, to norovirus. The FDA confirmed the oysters are potentially contaminated.

## Giants stop Commanders' last-minute drive to increase playoff chances, Washington's postseason hopes shrink
 - [https://www.foxnews.com/sports/giants-stop-commanders-last-minute-drive-increase-playoff-chances-washingtons-postseason-hopes-shrink](https://www.foxnews.com/sports/giants-stop-commanders-last-minute-drive-increase-playoff-chances-washingtons-postseason-hopes-shrink)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 04:46:49+00:00

The New York Giants' chances of making the playoffs skyrocketed with their thrilling 20-12 victory over the Washington Commanders on Sunday.

## Ex-Patriots quarterback calls team 'one of the dumbest' he's ever seen after disastrous loss to Raiders
 - [https://www.foxnews.com/sports/ex-patriots-quarterback-calls-team-one-dumbest-hes-ever-seen-disastrous-loss-raiders](https://www.foxnews.com/sports/ex-patriots-quarterback-calls-team-one-dumbest-hes-ever-seen-disastrous-loss-raiders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 03:50:21+00:00

Former New England Patriots quarterback Scott Zolak was on the call for the team's costly flub on Sunday and appeared to speak for all Pats fans while he summed up the game.

## Brittany Mahomes rips NFL refs after Chiefs star gets whipped down on sack: 'The inconsistency is BS'
 - [https://www.foxnews.com/sports/brittany-mahomes-rips-nfl-refs-chiefs-star-gets-whipped-down-sack-inconsistency-bs](https://www.foxnews.com/sports/brittany-mahomes-rips-nfl-refs-chiefs-star-gets-whipped-down-sack-inconsistency-bs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 03:23:00+00:00

Brittany Mahomes, the wife of superstar quarterback Patrick Mahomes, took issue with the NFL referees in the Kansas City Chiefs' game against the Houston Texans.

## Brittany Mahomes rips refs NFL refs after Chiefs star gets whipped down on sack: 'The inconsistency is BS'
 - [https://www.foxnews.com/sports/brittany-mahomes-rips-refs-nfl-refs-chiefs-star-gets-whipped-down-sack-inconsistency-bs](https://www.foxnews.com/sports/brittany-mahomes-rips-refs-nfl-refs-chiefs-star-gets-whipped-down-sack-inconsistency-bs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 03:23:00+00:00

Brittany Mahomes, the wife of superstar quarterback Patrick Mahomes, took issue with the NFL referees in the Kansas City Chiefs' game against the Houston Texans.

## El Paso mayor nearly walks out with microphone during press conference on border crisis
 - [https://www.foxnews.com/us/el-paso-mayor-nearly-walks-out-microphone-during-press-conference-border-crisis](https://www.foxnews.com/us/el-paso-mayor-nearly-walks-out-microphone-during-press-conference-border-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 03:09:07+00:00

El Paso, Texas mayor Oscar Leeser nearly walked out with a microphone during a press conference on Thursday after being challenged about declaring a state of emergency.

## Prince William attends exes wedding solo amid Prince Harry and Meghan Markle Netflix drama
 - [https://www.foxnews.com/entertainment/prince-william-attends-exes-wedding-solo-amid-prince-harry-meghan-markle-netflix-drama](https://www.foxnews.com/entertainment/prince-william-attends-exes-wedding-solo-amid-prince-harry-meghan-markle-netflix-drama)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 02:59:16+00:00

Prince William attended the soiree solo for his ex-girlfriend Rose Farquhar amid claims he screamed at brother Prince Harry in new Meghan Markle Netflix doc.

## Maryland sheriff's deputy in critical condition after being shot during high-speed chase
 - [https://www.foxnews.com/us/maryland-sheriffs-deputy-critical-condition-being-shot-during-high-speed-chase](https://www.foxnews.com/us/maryland-sheriffs-deputy-critical-condition-being-shot-during-high-speed-chase)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 02:47:21+00:00

A sheriff's deputy was shot and critically wounded during a high-speed chase through Calvert County, Maryland, on Saturday evening, law enforcement officials said.

## Rep. Nancy Mace on FBI's alleged censorship coordination with Twitter: 'I want to see heads roll'
 - [https://www.foxnews.com/media/rep-nancy-mace-fbis-alleged-censorship-coordination-twitter-see-heads-roll](https://www.foxnews.com/media/rep-nancy-mace-fbis-alleged-censorship-coordination-twitter-see-heads-roll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 02:23:15+00:00

Rep. Nancy Mace weighs in on the sixth installment of the Twitter files that alleged the FBI coordinated with Twitter executives to censor users.

## Massachusetts man arrested after allegedly trying to break into police station with chainsaw
 - [https://www.foxnews.com/us/massachusetts-man-arrested-allegedly-break-police-station-chainsaw](https://www.foxnews.com/us/massachusetts-man-arrested-allegedly-break-police-station-chainsaw)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 02:12:22+00:00

A chainsaw-wielding man was arrested on Sunday evening after allegedly trying to break into the Cohasset police station and cut through a security door.

## Patriots' Jakobi Meyers, Rhamondre Stevenson take 'full responsibility' for Raiders' miraculous walk-off win
 - [https://www.foxnews.com/sports/patriots-jakobi-meyers-rhamondre-stevenson-take-full-responsibility-raiders-miraculous-walk-off-win](https://www.foxnews.com/sports/patriots-jakobi-meyers-rhamondre-stevenson-take-full-responsibility-raiders-miraculous-walk-off-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 02:04:51+00:00

The New England Patriots were just a kneel away from going to overtime, but they tried to pull out a miracle in Vegas. Oh, was there a miracle.

## Tom Cruise jumps from helicopter to thank fans for 'Top Gun: Maverick' success
 - [https://www.foxnews.com/entertainment/tom-cruise-jumps-helicopter-thank-fans-top-gun-maverick-success](https://www.foxnews.com/entertainment/tom-cruise-jumps-helicopter-thank-fans-top-gun-maverick-success)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 01:58:38+00:00

Tom Cruise thanked supporters for watching "Top Gun: Maverick" in theaters as he jumped out of a helicopter while filming "Mission: Impossible" in South Africa.

## Massachusetts building's facade crumbles after car crashes into it
 - [https://www.foxnews.com/us/massachusetts-buildings-facade-crumbles-car-crash](https://www.foxnews.com/us/massachusetts-buildings-facade-crumbles-car-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 01:56:04+00:00

Boston, Massachusets police, fire and EMS crews responded to a motor vehicle crash on Sunday after a vehicle slammed into the front of a building, taking down the front facade.

## Bengals take advantage of Tom Brady's turnovers to complete comeback from 17-0 deficit
 - [https://www.foxnews.com/sports/bengals-take-advantage-tom-bradys-turnovers-complete-comeback-17-0-deficit](https://www.foxnews.com/sports/bengals-take-advantage-tom-bradys-turnovers-complete-comeback-17-0-deficit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 01:31:03+00:00

After trailing 17-0, Tom Brady turned the ball over four times and the Cincinnati Bengals were able to take advantage and fight back to a 34-23 win.

## JJ Watt makes $900,000 in incentives after impressive first half vs. Broncos
 - [https://www.foxnews.com/sports/jj-watt-makes-900000-incentives-impressive-first-half-broncos](https://www.foxnews.com/sports/jj-watt-makes-900000-incentives-impressive-first-half-broncos)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 01:25:36+00:00

J.J. Watt turned back the clock with three sacks in the first half on Sunday, but his impressive performance also netted him almost $1 million in incentives.

## Elon Musk asks 'should I step down as head of Twitter?' in poll, promises to 'abide by the results'
 - [https://www.foxnews.com/media/elon-musk-should-step-down-head-twitter-poll-promises-abide-results](https://www.foxnews.com/media/elon-musk-should-step-down-head-twitter-poll-promises-abide-results)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 01:25:00+00:00

Twitter CEO Elon Musk posted a poll Sunday asking whether he should resign as head of the social media company and promised to abide by the results.

## Justin Herbert's dart sets up game-winning field goal as Chargers top Titans
 - [https://www.foxnews.com/sports/justin-herberts-dart-sets-up-game-winning-field-goal-chargers-top-titans](https://www.foxnews.com/sports/justin-herberts-dart-sets-up-game-winning-field-goal-chargers-top-titans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 01:21:06+00:00

Justin Herbert's pass to Mike Williams set up Cameron Dicker's 43-yard field goal to help the Los Angeles Chargers defeat the Tennessee Titans, 17-14.

## Florida mother of 'Baby June' arrested for murder four years after allegedly leaving newborn infant in inlet
 - [https://www.foxnews.com/us/florida-mother-baby-june-arrested-murder-four-years-allegedly-leaving-newborn-infant-inlet](https://www.foxnews.com/us/florida-mother-baby-june-arrested-murder-four-years-allegedly-leaving-newborn-infant-inlet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 00:59:56+00:00

Arya Singh, 29, was arrested this week and charged with one count of first-degree murder after allegedly leaving her newborn baby in an inlet four years ago.

## New England ex-mob boss 'Cadillac Frank' Salemme dies in prison at 89
 - [https://www.foxnews.com/us/new-england-ex-mob-boss-cadillac-frank-salemme-dies-prison-89](https://www.foxnews.com/us/new-england-ex-mob-boss-cadillac-frank-salemme-dies-prison-89)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 00:53:42+00:00

Francis "Cadillac Frank" Salemme, the once-feared Mafia boss of New England, died Tuesday at the age of 89, according to Bureau of Prisons records.

## Raiders stun Patriots with improbable walk-off defensive touchdown
 - [https://www.foxnews.com/sports/raiders-stun-patriots-improbable-walk-off-defensive-touchdown](https://www.foxnews.com/sports/raiders-stun-patriots-improbable-walk-off-defensive-touchdown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 00:47:57+00:00

All the Patriots had to do was take a knee and send the game into overtime. Instead, they went for a prayer, but it was the Raiders who pulled out the miracle.

## Ex-NBA great Amar'e Stoudemire breaks silence on arrest: 'I could never see myself assaulting any person'
 - [https://www.foxnews.com/sports/ex-nba-great-amare-stoudemire-breaks-silence-arrest-could-never-see-myself-assaulting-any-person](https://www.foxnews.com/sports/ex-nba-great-amare-stoudemire-breaks-silence-arrest-could-never-see-myself-assaulting-any-person)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 00:44:45+00:00

Former NBA superstar Amar’e Stoudemire spoke out Sunday night about his arrest on a misdemeanor battery charge in Florida allegedly in an incident involving his daughter.

## Harrison Ford talks 'Yellowstone' prequel '1923' and his creative desires: 'I don't want to reinvent myself'
 - [https://www.foxnews.com/entertainment/harrison-ford-talks-yellowstone-prequel-1923-creative-desires-i-dont-want-reinvent-myself](https://www.foxnews.com/entertainment/harrison-ford-talks-yellowstone-prequel-1923-creative-desires-i-dont-want-reinvent-myself)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 00:43:28+00:00

"Star Wars" actor Harrison Ford admitted he "just wants to work" and is excited about his role with the Dutton family farm in the '1923' country series.

## Brett Rypien battles through several sacks to lift Broncos to win
 - [https://www.foxnews.com/sports/brett-rypien-battles-through-several-sacks-lift-broncos-win](https://www.foxnews.com/sports/brett-rypien-battles-through-several-sacks-lift-broncos-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 00:42:38+00:00

Backup Denver Broncos quarterback Brett Rypien was sacked seven times but still managed to lead the team to a 24-15 victory over the Arizona Cardinals.

## Texas Border Patrol facility overwhelmed with illegal immigrants as Title 42 expiration looms
 - [https://www.foxnews.com/politics/texas-border-patrol-facility-overwhelmed-migrants-title-42-expiration-looms](https://www.foxnews.com/politics/texas-border-patrol-facility-overwhelmed-migrants-title-42-expiration-looms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 00:31:04+00:00

A Border Patrol facility in El Paso, Texas, was overwhelmed with an influx of migrants over the weekend, with video footage showing thousands in federal custody.

## Twitter Files 'supplemental' shows even Trust and Safety chief not ‘comfortable’ with FBI ‘demanding’ answers
 - [https://www.foxnews.com/media/twitter-files-supplemental-shows-trust-safety-chief-fbi-demanding-answers](https://www.foxnews.com/media/twitter-files-supplemental-shows-trust-safety-chief-fbi-demanding-answers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-19 00:11:30+00:00

Substack writer Matt Taibbi revealed FBI agents pressuring Twitter employees for more answers on "foreign influence" using mainstream media articles as sources.


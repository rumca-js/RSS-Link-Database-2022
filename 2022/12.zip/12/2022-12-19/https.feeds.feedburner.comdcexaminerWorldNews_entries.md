# Source:Washington Examiner - world, URL:https://feeds.feedburner.com/dcexaminer/WorldNews, language:en-US

## 'Earth's ultimate adios': Planet spiraling toward sun may give glimpse into Earth's end
 - [https://www.washingtonexaminer.com/news/planet-spiraling-towards-sun-earths-end](https://www.washingtonexaminer.com/news/planet-spiraling-towards-sun-earths-end)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/WorldNews
 - date published: 2022-12-19 22:04:53+00:00

A distant planet spiraling into its sun may give humanity a glimpse of the Earth's ultimate end, astronomers found.


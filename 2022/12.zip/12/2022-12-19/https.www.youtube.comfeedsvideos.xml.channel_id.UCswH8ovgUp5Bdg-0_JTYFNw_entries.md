# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## WE SAW THIS COMING
 - [https://www.youtube.com/watch?v=k5N6qvBQ-Ms](https://www.youtube.com/watch?v=k5N6qvBQ-Ms)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-12-20 00:00:00+00:00

Whatever happened to the Nord Stream pipeline eh? Remember when bloody Putin blew up his own extremely profitable pipeline? Well, in an extraordinary coincidence, the US has now struck a deal to double its own gas exports to the UK. Almost as if that was the intention all along. Where’s my tin foil hat?  #ukraine #russia #war 

References
https://www.standard.co.uk/business/business-news/us-to-double-gas-exports-to-uk-under-plans-to-clamp-down-on-skyhigh-prices-b1045344.html
https://consortiumnews.com/2022/09/28/the-timing-of-the-pipeline-attack/
https://fair.org/home/us-medias-intellectual-no-fly-zone-on-us-culpability-in-nord-stream-attack/
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/

## THE END
 - [https://www.youtube.com/watch?v=h3mj5_TNfrc](https://www.youtube.com/watch?v=h3mj5_TNfrc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-12-19 00:00:00+00:00

The American war industry is looking forward to “multiyear authority” in Ukraine. Does that sound like they want peace or don’t want peace? #war #nuke #ukraine 

References
https://theintercept.com/2022/11/30/ukraine-war-weapons-ndaa/
https://www.axios.com/2021/01/21/media-trust-crisis
https://jacobin.com/2022/12/military-industrial-complex-budget-congress-arms-industry-war
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/


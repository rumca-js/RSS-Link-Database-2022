# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## In pictures: France receive heroes' welcome in Paris after World Cup heartbreak
 - [https://www.bbc.co.uk/news/world-europe-64034720?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64034720?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 23:51:31+00:00

The French national team are met by thousands in Paris after losing to Argentina on Sunday.

## Newspaper headlines: 'Ambulance strike threatens lives' and 'call a taxi'
 - [https://www.bbc.co.uk/news/blogs-the-papers-64034598?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-64034598?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 23:34:53+00:00

Strikes by ambulance service workers and nurses dominate the front pages on Tuesday.

## Terry Hall of The Specials dies aged 63
 - [https://www.bbc.co.uk/news/entertainment-arts-64029430?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64029430?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 23:02:14+00:00

His distinctively dour voice can be heard on hits like Ghost Town, Gangsters and Too Much, Too Young.

## Merthyr Tydfil: Toy beads warning after boy, 4, nearly died
 - [https://www.bbc.co.uk/news/uk-wales-64028132?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-64028132?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 22:58:14+00:00

Jude was in hospital for weeks after swallowing the popular mini magnets in August.

## Bob Stewart MP tells human rights activist to 'go back to Bahrain'
 - [https://www.bbc.co.uk/news/uk-politics-64033838?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64033838?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 22:35:22+00:00

Human rights activist Sayed Ahmed Alwadaei has complained to the Tory Party over the incident.

## Low-deposit mortgage scheme extended for a year
 - [https://www.bbc.co.uk/news/business-64031563?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64031563?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 22:32:24+00:00

The scheme offers government backing to encourage lenders to offer low-deposit mortgages to buyers.

## Capitol riot committee asks that Trump faces insurrection charges
 - [https://www.bbc.co.uk/news/world-us-canada-64034559?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64034559?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 22:13:20+00:00

The committee airs critical testimony by a Trump loyalist and criticises his daughter, Ivanka Trump.

## Lionesses: 'The world around me has changed', says England boss Sarina Wiegman on Euros triumph
 - [https://www.bbc.co.uk/sport/av/football/64027896?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64027896?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 22:10:00+00:00

England manager Sarina Wiegman tells BBC Sport about the impact of the Lionesses winning the Euros.

## Man armed with knife shot dead by police
 - [https://www.bbc.co.uk/news/uk-england-cumbria-64033817?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cumbria-64033817?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 21:29:19+00:00

Police were called to reports of an armed man threatening people at a home in Carlisle.

## Ukraine to boost Belarus border defences as Putin meets Lukashenko
 - [https://www.bbc.co.uk/news/world-europe-64030975?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64030975?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 20:18:43+00:00

Kyiv fears a fresh Russian assault is on the horizon after President Putin travelled to Minsk.

## Man guilty of murder and rape in oldest double jeopardy case
 - [https://www.bbc.co.uk/news/uk-england-london-64029555?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-64029555?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 19:52:11+00:00

Dennis McGrory is convicted after he raped, stabbed and strangled a teenager in Islington in 1975.

## NHS trust apologises as man kept in hospital for more than a year
 - [https://www.bbc.co.uk/news/uk-england-manchester-64029162?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-64029162?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 18:38:48+00:00

The man tried to "escape" on one occasion and broke his arm in the process, a court hears.

## 'Doddie Weir was incredible - he'll be truly missed'
 - [https://www.bbc.co.uk/news/uk-scotland-64033790?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-64033790?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 18:12:47+00:00

Sports fans pay their tributes to the Scottish rugby legend who died from motor neurone disease.

## Alcohol duty to be frozen for further six months
 - [https://www.bbc.co.uk/news/business-64027190?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64027190?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 17:44:08+00:00

Alcohol prices will be frozen until August 2023, when a new system for alcohol taxes is introduced.

## Student, 23, charged after eggs thrown at King Charles in York
 - [https://www.bbc.co.uk/news/uk-64032088?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64032088?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 17:32:11+00:00

The 23-year-old man will appear in court next year after being charged with a public order offence.

## Lionel Messi named BBC Sports Personality's World Sport Star of the Year
 - [https://www.bbc.co.uk/sport/sports-personality/64027088?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/sports-personality/64027088?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 17:30:27+00:00

Lionel Messi is named BBC Sports Personality's World Sport Star of the Year after inspiring Argentina to World Cup glory.

## World Cup 2022: Alternative angles as Messi's Argentina lift the World Cup trophy
 - [https://www.bbc.co.uk/sport/av/football/64033048?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64033048?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 17:23:26+00:00

Take a look at how the most dramatic World Cup final played out, with alternative angles, behind the scenes content and unseen shots.

## Will Elon Musk's ultimatum cost him Twitter?
 - [https://www.bbc.co.uk/news/technology-64003232?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64003232?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 17:15:34+00:00

The BBC's technology editor Zoe Kleinman looks at the future of Musk and Twitter.

## Who is striking? How Tuesday 20 December’s walkouts will affect you
 - [https://www.bbc.co.uk/news/uk-63999154?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63999154?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 17:14:20+00:00

More cancelled appointments and medical disruption as nurses strike again - by the BBC’s Zoe Conway.

## COP15: Five key takeaways from the UN biodiversity summit
 - [https://www.bbc.co.uk/news/science-environment-64030656?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-64030656?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 17:10:06+00:00

Memorable moments from the Montreal meeting that brought a historic deal.

## Care workers paid £8,000 less than NHS equivalents in England - study
 - [https://www.bbc.co.uk/news/uk-64025830?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64025830?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 17:05:25+00:00

Social care workers earn about £8,000 a year less than NHS staff, a study suggests - with some relying on food parcels.

## World Cup 2022: Why norms LGBTQ+ football fans took for granted have been shaken
 - [https://www.bbc.co.uk/sport/football/63993302?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63993302?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 17:02:50+00:00

Many LGBTQ+ fans and allies feel let down by the authorities after experiencing discrimination at the World Cup in Qatar - and the BBC's Jack Murley believes that will be the tournament's true legacy.

## Rwanda migrant plan is lawful, High Court rules
 - [https://www.bbc.co.uk/news/uk-64024461?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64024461?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 16:44:18+00:00

The government's plan to deport asylum seekers to Rwanda has been deemed lawful by the High Court.

## Iran protests: Family finds signs of torture on man's exhumed body
 - [https://www.bbc.co.uk/news/world-middle-east-64025754?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-64025754?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 16:39:11+00:00

The 23-year-old's relatives say they found severe injuries and stitching when they exhumed his body.

## Frank Salemme: Former mafia boss dies in prison at 89
 - [https://www.bbc.co.uk/news/world-us-canada-63991453?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63991453?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 16:36:25+00:00

Frank Salemme was serving a life sentence for killing a Boston nightclub owner in 1993.

## Brixton Academy: Security contractor dies after Asake concert crush
 - [https://www.bbc.co.uk/news/uk-england-london-64019806?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-64019806?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 16:29:59+00:00

Asake's gig at London's Brixton O2 Academy was abandoned after people were seriously hurt.

## Amber Heard settles defamation case against Johnny Depp
 - [https://www.bbc.co.uk/news/world-us-canada-64031252?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64031252?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 15:58:16+00:00

It comes after a jury found Ms Heard had defamed her ex-husband in a Washington Post article.

## World Cup 2022: Five trends from Qatar - upsets, injury time & penalties
 - [https://www.bbc.co.uk/sport/football/64027504?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64027504?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 15:52:05+00:00

Argentina defeat France on penalties to win the World Cup in a tournament that saw more goals and shocks, record numbers of teenagers - and veterans - making starts.

## Government to sue Mone-linked PPE firm for £122m
 - [https://www.bbc.co.uk/news/uk-politics-64029040?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64029040?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 15:39:43+00:00

PPE Medpro won contracts to supply PPE after being recommended by then Tory peer Baroness Mone.

## This year's Christmas Number One: Your very quick guide
 - [https://www.bbc.co.uk/news/entertainment-arts-64002002?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64002002?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 15:02:35+00:00

When's it announced, who's in the running, and what's the biggest Christmas song of all time?

## Alexis Mac Allister: Brighton hope to keep Argentina midfielder for as long as possible
 - [https://www.bbc.co.uk/sport/football/64024704?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64024704?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 14:02:50+00:00

Brighton hope "it won't be a problem for a couple of years" when it comes to keeping hold of Alexis Mac Allister, says chief executive Paul Barber.

## Jeremy Clarkson says he is 'horrified' over Meghan column
 - [https://www.bbc.co.uk/news/entertainment-arts-64029690?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64029690?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 13:36:30+00:00

The broadcaster had written in the Sun on Friday that he "hated" the Duchess of Sussex.

## World Cup 2022: Argentina's victory over France watched by peak of 14.9m people on BBC One
 - [https://www.bbc.co.uk/sport/football/64026863?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64026863?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 13:35:57+00:00

Argentina's victory over France in the World Cup final was watched by a peak of 14.9m people on BBC One.

## Pakistan v England: Rehan Ahmed takes five wickets to leave tourists on brink of win
 - [https://www.bbc.co.uk/sport/cricket/64019457?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64019457?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 12:41:11+00:00

Rehan Ahmed's stunning five-wicket haul leaves England on the verge of victory in the third Test against Pakistan and a historic clean sweep.

## Train strikes: Rail passengers told to avoid Christmas Eve travel
 - [https://www.bbc.co.uk/news/business-64027186?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64027186?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 12:26:05+00:00

Network Rail advises people to travel only if "absolutely necessary" due to strike action by the RMT.

## Steve Borthwick: England appoint Leicester coach to replace Eddie Jones
 - [https://www.bbc.co.uk/sport/rugby-union/63892834?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63892834?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 12:16:40+00:00

England appoint Leicester's Steve Borthwick as new head coach of the men's national team, nine months before the World Cup begins in France.

## Matt Dawson column: Steve Borthwick's England to-do list
 - [https://www.bbc.co.uk/sport/rugby-union/63985770?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63985770?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 12:01:05+00:00

The Farrell question. A new captain. A fresh identity. Matt Dawson runs through new England coach Steve Borthwick's in-tray.

## Jeremy Clarkson and Meghan Markle: The Sun column gets 6,000 official complaints
 - [https://www.bbc.co.uk/news/entertainment-arts-64025074?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64025074?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 11:42:22+00:00

In a column for The Sun newspaper, Clarkson wrote he wants the Duchess of Sussex to be paraded naked.

## World Cup 2022: An explosion of joy as Argentina wins
 - [https://www.bbc.co.uk/news/world-latin-america-64026174?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-64026174?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 11:31:59+00:00

Argentines are giddy with joy as they celebrate their football team's victory in the World Cup.

## Ukraine war: Overnight strikes hit Kyiv as Putin visits Belarus
 - [https://www.bbc.co.uk/news/world-europe-64024992?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64024992?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 11:16:44+00:00

The unusual night attack causes blackouts across the city, but no one is killed, Kyiv officials say.

## Mother of ill child grills health secretary on NHS plans
 - [https://www.bbc.co.uk/news/health-64024306?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-64024306?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 10:55:47+00:00

Steve Barclay is told by the mother that she is scared for "the length" of her daughter's life.

## BAE Systems to recruit 2,600 apprentices and graduates
 - [https://www.bbc.co.uk/news/uk-england-lancashire-64024647?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lancashire-64024647?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 10:44:37+00:00

The majority of the roles will be based in Samlesbury and Warton in Lancashire and Barrow in Cumbria.

## ANC conference: South Africa's President Cyril Ramaphosa defies scandal to win party vote
 - [https://www.bbc.co.uk/news/world-africa-64004037?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-64004037?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 09:45:31+00:00

South Africa's Cyril Ramaphosa wins leadership of governing ANC, despite corruption allegations.

## Solihull: Boys who fell into lake died from drowning
 - [https://www.bbc.co.uk/news/uk-england-birmingham-64024148?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-64024148?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 09:43:59+00:00

The boys were in the water more than 20 minutes after the first 999 calls, the inquest hears.

## World Cup 2022: Argentina celebrate on open-top bus in Qatar
 - [https://www.bbc.co.uk/sport/av/football/64025771?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64025771?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 09:39:43+00:00

The Argentina team celebrate their World Cup triumph on an open-top bus in Qatar after a thrilling final against France.

## Ariana Grande, 1D and The Weeknd songwriter reveals his secrets
 - [https://www.bbc.co.uk/news/newsbeat-63574532?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-63574532?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 09:38:19+00:00

Savan Kotecha writes songs for some of the world's biggest artists - he tells Newsbeat how he does it.

## World Cup 2022: How the world reacted to Argentina's win
 - [https://www.bbc.co.uk/sport/football/64024082?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64024082?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 09:37:40+00:00

One newspaper suggests a destiny has been fulfilled for Lionel Messi, while another says it is "spring once again in Argentina" - BBC Sport looks at how the world reacted to the World Cup final.

## Gary Neville in Qatar/UK workers' rights row
 - [https://www.bbc.co.uk/news/uk-politics-64024827?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64024827?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 09:34:14+00:00

The football pundit is attacked by Tory MPs after comparing the UK government's record to Qatar.

## Vaughan shooting: Five killed by gunman in Canada apartment block
 - [https://www.bbc.co.uk/news/world-us-canada-64024023?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64024023?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 08:55:06+00:00

The gunman was shot dead by police who found victims scattered in several flats of the block.

## Turbulence injures dozens on Hawaiian Airlines flight
 - [https://www.bbc.co.uk/news/world-us-canada-64024021?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64024021?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 07:29:07+00:00

Eleven people are in hospital in a serious condition due to injuries sustained on the flight.

## World Cup 2022: Great images from Qatar and the story behind the photos
 - [https://www.bbc.co.uk/sport/football/63802161?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63802161?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 06:57:44+00:00

A selection of great World Cup photographs taken in Qatar - and the story behind them by the person who captured it.

## World Cup 2022: Choose your best tournament XI
 - [https://www.bbc.co.uk/sport/football/64019356?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64019356?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 06:57:34+00:00

Who caught your eye the most at the 2022 World Cup? We reveal the XI with the best average ratings, who the stats say was best and ask you to choose your team of the tournament.

## Cost of living: 'We sold nearly everything just to pay bills'
 - [https://www.bbc.co.uk/news/uk-england-shropshire-63975351?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-shropshire-63975351?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 06:21:13+00:00

Leah Callaghan worries about how she will keep her house warm for her daughter this Christmas.

## Felixstowe: The ferry disaster that killed six men 40 years ago
 - [https://www.bbc.co.uk/news/uk-england-suffolk-63944202?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-suffolk-63944202?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 06:06:09+00:00

Four decades since the tragedy, the names of those who died are expected to be added to a memorial.

## Ukraine war: How pathologists identify victims of Russia's invasion
 - [https://www.bbc.co.uk/news/world-europe-63987512?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63987512?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 06:00:32+00:00

Scientists are finding and naming family members killed by Russian troops, one mouth swab at a time.

## Ambulance strike cover must be sufficient, says health secretary
 - [https://www.bbc.co.uk/news/uk-64023113?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64023113?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 04:45:27+00:00

Health secretary said there is still a lack of clarity for patients, ahead of this week's walkout.

## Thailand navy ship sinks stranding more than 100 sailors
 - [https://www.bbc.co.uk/news/world-asia-64023249?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-64023249?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 04:19:33+00:00

The HTMAS Sukhotai sunk on Sunday after taking on water during a storm in the Gulf of Thailand

## BBC Young Reporter: 'Why don't more teachers look like me?'
 - [https://www.bbc.co.uk/news/education-63946894?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-63946894?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 02:23:34+00:00

BBC Young Reporter winner David investigates why there are so few black and minority ethnic teachers.

## Glass Onion: Daniel Craig's Knives Out sequel continues Whodunit craze
 - [https://www.bbc.co.uk/news/entertainment-arts-62645614?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62645614?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 02:22:06+00:00

Glass Onion is the latest in a string of film and TV series which reflect a resurgence of the genre.

## Netherlands slavery: Saying sorry leaves Dutch divided
 - [https://www.bbc.co.uk/news/world-europe-63993283?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63993283?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 02:21:17+00:00

The Netherlands government is expected to apologise for slavery with a speech by the prime minister.

## Manchester Arena attack: Martyn's Law for venue security to cover all of UK
 - [https://www.bbc.co.uk/news/uk-england-manchester-64018123?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-64018123?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 02:16:04+00:00

The new rules will require venues and local authorities to have action plans against terror attacks.

## UK schools must teach about antisemitism, says government adviser
 - [https://www.bbc.co.uk/news/uk-64012628?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64012628?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 02:14:27+00:00

"It is not enough to teach about the Holocaust," says a report on anti-Jewish hatred.

## The Papers: Messi ‘the greatest’ and strikes to ‘wreak havoc’
 - [https://www.bbc.co.uk/news/blogs-the-papers-64021686?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-64021686?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 01:55:03+00:00

The front pages cover Argentina's World Cup win and this week's strikes involving ambulance and border staff.

## Doddie Weir's life to be celebrated at Melrose memorial service
 - [https://www.bbc.co.uk/news/uk-scotland-south-scotland-64019785?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-south-scotland-64019785?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 01:08:39+00:00

The former Scotland rugby international died last month, six years after being diagnosed with motor neurone disease.

## 'I quit my job rather than go back to the office'
 - [https://www.bbc.co.uk/news/business-63944632?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63944632?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 00:30:14+00:00

Is there a growing divide between employers who want staff back in the office and employees who want to work from home?

## Etsy boss: It's not about getting loo roll quick
 - [https://www.bbc.co.uk/news/business-63984098?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63984098?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 00:17:58+00:00

People are prepared to wait longer for handmade items, says the chief of the e-commerce firm.

## COP15: Summit on 'pact with nature' enters final stretch
 - [https://www.bbc.co.uk/news/science-environment-64019324?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-64019324?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 00:12:05+00:00

Decision day looms for sealing a global deal to stop the destruction of nature.

## More than 130 bus operators to offer £2 tickets
 - [https://www.bbc.co.uk/news/business-your-money-64021415?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-your-money-64021415?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-19 00:04:24+00:00

The government-funded scheme will cap fares in England outside London from 1 January to 31 March.


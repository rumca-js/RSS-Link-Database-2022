# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## I was wrong (and so was everyone)
 - [https://www.youtube.com/watch?v=Wif1EAgEQKI](https://www.youtube.com/watch?v=Wif1EAgEQKI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-12-19 16:00:27+00:00

Did 18th century firefighters really let buildings burn? Sources below. ■ AD: 👨‍💻 NordVPN's best deal is here: https://nordvpn.com/tomscott - with a 30-day money-back guarantee.

Here's the full, thoroughly referenced report: https://www.tomscott.com/corrections/firemarks/

Thanks to historical consultant Paul J Sillitoe: http://www.linkedin.com/in/paul-sillitoe-avi-consultants

Thanks to Afonso Noronha for the email sparking this whole discussion! All the corrections on this channel can be found here: https://www.tomscott.com/corrections/

The original video, now deprecated and unlisted: https://www.youtube.com/watch?v=sehyLDPeB6M

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


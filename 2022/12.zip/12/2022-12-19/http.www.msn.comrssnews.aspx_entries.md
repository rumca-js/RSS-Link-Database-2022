# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Most people don't know how bad the border crisis is
 - [http://www.msn.com/en-us/news/us/most-people-don-t-know-how-bad-the-border-crisis-is/ar-AA15sZ0P?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/most-people-don-t-know-how-bad-the-border-crisis-is/ar-AA15sZ0P?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 23:43:43.477657+00:00



## Marijuana Banking Bill Excluded From Year-End Spending Bill
 - [http://www.msn.com/en-us/news/politics/marijuana-banking-bill-excluded-from-year-end-spending-bill/ar-AA15scR7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/marijuana-banking-bill-excluded-from-year-end-spending-bill/ar-AA15scR7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 23:43:43.469796+00:00



## Supreme Court temporarily blocks the end of Trump-era immigration policy
 - [http://www.msn.com/en-us/news/politics/supreme-court-temporarily-blocks-the-end-of-trump-era-immigration-policy/ar-AA15t43z?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/supreme-court-temporarily-blocks-the-end-of-trump-era-immigration-policy/ar-AA15t43z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 23:43:43.462269+00:00



## Supreme Court Puts Expiration of Title 42 Immigration Policy on Hold
 - [http://www.msn.com/en-us/news/politics/supreme-court-puts-expiration-of-title-42-immigration-policy-on-hold/ar-AA15t41O?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/supreme-court-puts-expiration-of-title-42-immigration-policy-on-hold/ar-AA15t41O?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 23:43:43.454290+00:00



## This May Be NASA Insight Lander's Final Image From Mars
 - [http://www.msn.com/en-us/news/technology/this-may-be-nasa-insight-lander-s-final-image-from-mars/ar-AA15sYPg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/this-may-be-nasa-insight-lander-s-final-image-from-mars/ar-AA15sYPg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 23:43:43.445421+00:00



## FBI issues alert on 'explosion' in child 'sextortion' schemes
 - [http://www.msn.com/en-us/news/us/fbi-issues-alert-on-explosion-in-child-sextortion-schemes/ar-AA15sB6p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/fbi-issues-alert-on-explosion-in-child-sextortion-schemes/ar-AA15sB6p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 23:43:43.437336+00:00



## Hillicon Valley — FTC issues ‘Epic’ kids’ privacy fine
 - [http://www.msn.com/en-us/news/politics/hillicon-valley-ftc-issues-epic-kids-privacy-fine/ar-AA15sUA9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/hillicon-valley-ftc-issues-epic-kids-privacy-fine/ar-AA15sUA9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 23:43:43.429123+00:00



## Trump referral: What laws the Jan. 6 panel says were broken
 - [http://www.msn.com/en-us/news/politics/trump-referral-what-laws-the-jan-6-panel-says-were-broken/ar-AA15t46y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-referral-what-laws-the-jan-6-panel-says-were-broken/ar-AA15t46y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 23:43:43.090771+00:00



## Lukashenko Calls Himself, Putin Most 'Harmful and Toxic People' on Earth
 - [http://www.msn.com/en-us/news/world/lukashenko-calls-himself-putin-most-harmful-and-toxic-people-on-earth/ar-AA15sd77?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/lukashenko-calls-himself-putin-most-harmful-and-toxic-people-on-earth/ar-AA15sd77?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 22:42:26.068399+00:00



## Donald Trump's docket: The latest on key cases and investigations as Trump runs for the White House in 2024
 - [http://www.msn.com/en-us/news/politics/donald-trump-s-docket-the-latest-on-key-cases-and-investigations-as-trump-runs-for-the-white-house-in-2024/ar-AA109cBG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/donald-trump-s-docket-the-latest-on-key-cases-and-investigations-as-trump-runs-for-the-white-house-in-2024/ar-AA109cBG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 22:42:26.060874+00:00



## Chief Justice temporarily blocks end of Trump-era immigration policy
 - [http://www.msn.com/en-us/news/politics/chief-justice-temporarily-blocks-end-of-trump-era-immigration-policy/ar-AA15suRr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/chief-justice-temporarily-blocks-end-of-trump-era-immigration-policy/ar-AA15suRr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 22:42:26.052314+00:00



## Los Angeles mourns the death of cougar P-22 with memorials planned
 - [http://www.msn.com/en-us/news/us/los-angeles-mourns-the-death-of-cougar-p-22-with-memorials-planned/ar-AA15svCU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/los-angeles-mourns-the-death-of-cougar-p-22-with-memorials-planned/ar-AA15svCU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 22:42:26.044789+00:00



## Joe Biden Holds Private Memorial for First Wife and Baby Daughter, 50 Years After Their Tragic Deaths
 - [http://www.msn.com/en-us/news/us/joe-biden-holds-private-memorial-for-first-wife-and-baby-daughter-50-years-after-their-tragic-deaths/ar-AA15sHyd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/joe-biden-holds-private-memorial-for-first-wife-and-baby-daughter-50-years-after-their-tragic-deaths/ar-AA15sHyd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 22:42:26.036286+00:00



## Children's medicine shortage hits as flu season starts fast
 - [http://www.msn.com/en-us/health/health-news/children-s-medicine-shortage-hits-as-flu-season-starts-fast/ar-AA15svGg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/health-news/children-s-medicine-shortage-hits-as-flu-season-starts-fast/ar-AA15svGg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 22:42:26.028533+00:00



## Roberts grants temporary stay after 19 states appeal to keep Title 42 in place
 - [http://www.msn.com/en-us/news/politics/roberts-grants-temporary-stay-after-19-states-appeal-to-keep-title-42-in-place/ar-AA15sKFr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/roberts-grants-temporary-stay-after-19-states-appeal-to-keep-title-42-in-place/ar-AA15sKFr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 22:42:25.790557+00:00



## GOP states ask the Supreme Court to maintain Trump-era immigration policy
 - [http://www.msn.com/en-us/news/politics/gop-states-ask-the-supreme-court-to-maintain-trump-era-immigration-policy/ar-AA15suRr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-states-ask-the-supreme-court-to-maintain-trump-era-immigration-policy/ar-AA15suRr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 21:41:08.542348+00:00



## Did the FBI catch and kill the Hunter Biden laptop story?
 - [http://www.msn.com/en-us/news/politics/did-the-fbi-catch-and-kill-the-hunter-biden-laptop-story/ar-AA15sAYR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/did-the-fbi-catch-and-kill-the-hunter-biden-laptop-story/ar-AA15sAYR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 21:41:08.534951+00:00



## George Santos Revelations Spark Outrage at Dems: 'Political Malpractice'
 - [http://www.msn.com/en-us/news/politics/george-santos-revelations-spark-outrage-at-dems-political-malpractice/ar-AA15sH2K?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/george-santos-revelations-spark-outrage-at-dems-political-malpractice/ar-AA15sH2K?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 21:41:08.527422+00:00



## Australian, Taiwan authorities foil alleged plot to smuggle meth into Australia using 3D printers
 - [http://www.msn.com/en-us/news/world/australian-taiwan-authorities-foil-alleged-plot-to-smuggle-meth-into-australia-using-3d-printers/ar-AA15sKe7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/australian-taiwan-authorities-foil-alleged-plot-to-smuggle-meth-into-australia-using-3d-printers/ar-AA15sKe7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 21:41:08.520015+00:00



## From nothing to millions — incoming Republican Rep. George Santos' congressional financial disclosures raise more questions about his truthfulness
 - [http://www.msn.com/en-us/news/politics/from-nothing-to-millions-incoming-republican-rep-george-santos-congressional-financial-disclosures-raise-more-questions-about-his-truthfulness/ar-AA15scOz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/from-nothing-to-millions-incoming-republican-rep-george-santos-congressional-financial-disclosures-raise-more-questions-about-his-truthfulness/ar-AA15scOz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 21:41:08.512012+00:00



## Marijuana Banking Bill Excluded From Year-End Spending Measure
 - [http://www.msn.com/en-us/news/politics/marijuana-banking-bill-excluded-from-year-end-spending-measure/ar-AA15scR7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/marijuana-banking-bill-excluded-from-year-end-spending-measure/ar-AA15scR7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 21:41:08.503805+00:00



## Hogan: Trump at 'lowest point ever' on day of Jan. 6 report
 - [http://www.msn.com/en-us/news/politics/hogan-trump-at-lowest-point-ever-on-day-of-jan-6-report/ar-AA15sOnC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/hogan-trump-at-lowest-point-ever-on-day-of-jan-6-report/ar-AA15sOnC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 21:41:08.495033+00:00



## Jill Biden says husband gives her handwritten poem every year
 - [http://www.msn.com/en-us/news/politics/jill-biden-says-husband-gives-her-handwritten-poem-every-year/ar-AA15sDgk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jill-biden-says-husband-gives-her-handwritten-poem-every-year/ar-AA15sDgk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 21:41:08.156627+00:00



## How to Read Your Free Credit Report
 - [http://www.msn.com/en-us/news/technology/how-to-read-your-free-credit-report/ar-AA15sCoE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-to-read-your-free-credit-report/ar-AA15sCoE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 20:39:58.795154+00:00



## What the January 6 committee’s criminal referral means for Trump
 - [http://www.msn.com/en-us/news/politics/what-the-january-6-committee-s-criminal-referral-means-for-trump/ar-AA15oTj0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/what-the-january-6-committee-s-criminal-referral-means-for-trump/ar-AA15oTj0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 20:39:58.786859+00:00



## Stimulus update: Deadline revealed to apply for direct $500 cash payments
 - [http://www.msn.com/en-us/news/world/stimulus-update-deadline-revealed-to-apply-for-direct-500-cash-payments/ar-AA15suEV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/stimulus-update-deadline-revealed-to-apply-for-direct-500-cash-payments/ar-AA15suEV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 20:39:58.778615+00:00



## Elon Musk was spotted with a sanctioned, pro-Putin Russian TV presenter at the World Cup final in Qatar
 - [http://www.msn.com/en-us/news/world/elon-musk-was-spotted-with-a-sanctioned-pro-putin-russian-tv-presenter-at-the-world-cup-final-in-qatar/ar-AA15syNw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/elon-musk-was-spotted-with-a-sanctioned-pro-putin-russian-tv-presenter-at-the-world-cup-final-in-qatar/ar-AA15syNw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 20:39:58.771000+00:00



## Chicago high school students set to walk out of class over gun violence
 - [http://www.msn.com/en-us/news/us/chicago-high-school-students-set-to-walk-out-of-class-over-gun-violence/ar-AA15sczJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/chicago-high-school-students-set-to-walk-out-of-class-over-gun-violence/ar-AA15sczJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 20:39:58.763369+00:00



## Jan. 6 chair ‘convinced’ DOJ will charge Trump
 - [http://www.msn.com/en-us/news/politics/jan-6-chair-convinced-doj-will-charge-trump/ar-AA15suCk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jan-6-chair-convinced-doj-will-charge-trump/ar-AA15suCk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 20:39:58.755755+00:00



## Republicans, Democrats warn end of Title 42 will bring immigration disaster
 - [http://www.msn.com/en-us/news/politics/republicans-democrats-warn-end-of-title-42-will-bring-immigration-disaster/ar-AA15sLxv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-democrats-warn-end-of-title-42-will-bring-immigration-disaster/ar-AA15sLxv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 20:39:58.746830+00:00



## Ohio attorney general revisits comments on girl's abortion
 - [http://www.msn.com/en-us/news/politics/ohio-attorney-general-revisits-comments-on-girl-s-abortion/ar-AA15shtJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ohio-attorney-general-revisits-comments-on-girl-s-abortion/ar-AA15shtJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 20:39:58.508743+00:00



## Oppositionist Warns Belarus 'Not For Sale' As Putin, Lukashenko Shake Hands
 - [http://www.msn.com/en-us/news/world/oppositionist-warns-belarus-not-for-sale-as-putin-lukashenko-shake-hands/ar-AA15s5mf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/oppositionist-warns-belarus-not-for-sale-as-putin-lukashenko-shake-hands/ar-AA15s5mf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:40.624831+00:00



## Trump referred to DOJ for criminal prosecution by January 6 Committee
 - [http://www.msn.com/en-us/news/politics/trump-referred-to-doj-for-criminal-prosecution-by-january-6-committee/ar-AA15saFH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-referred-to-doj-for-criminal-prosecution-by-january-6-committee/ar-AA15saFH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:40.526978+00:00



## Mother and stepfather of missing 11-year-old North Carolina girl arrested
 - [http://www.msn.com/en-us/news/crime/mother-and-stepfather-of-missing-11-year-old-north-carolina-girl-arrested/ar-AA15sy0W?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/mother-and-stepfather-of-missing-11-year-old-north-carolina-girl-arrested/ar-AA15sy0W?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:40.432176+00:00



## Jake Tapper’s daughter, 15, pens op-ed about ‘almost dying’ after misdiagnosis
 - [http://www.msn.com/en-us/health/other/jake-tapper-s-daughter-15-pens-op-ed-about-almost-dying-after-misdiagnosis/ar-AA15rPGO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/other/jake-tapper-s-daughter-15-pens-op-ed-about-almost-dying-after-misdiagnosis/ar-AA15rPGO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:39.906515+00:00



## Ex-Rep. Joe Kennedy III named envoy to Northern Ireland
 - [http://www.msn.com/en-us/news/politics/ex-rep-joe-kennedy-iii-named-envoy-to-northern-ireland/ar-AA15sDIW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ex-rep-joe-kennedy-iii-named-envoy-to-northern-ireland/ar-AA15sDIW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:39.739739+00:00



## Paraguay’s Cartes Tightens Grip on Ruling Party in Primary Elections
 - [http://www.msn.com/en-us/news/world/paraguay-s-cartes-tightens-grip-on-ruling-party-in-primary-elections/ar-AA15soPT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/paraguay-s-cartes-tightens-grip-on-ruling-party-in-primary-elections/ar-AA15soPT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:39.656468+00:00



## The Jan. 6 Panel's Christmas Gift: a Criminal Referral for Trump
 - [http://www.msn.com/en-us/news/politics/the-jan-6-panel-s-christmas-gift-a-criminal-referral-for-trump/ar-AA15sqA3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-jan-6-panel-s-christmas-gift-a-criminal-referral-for-trump/ar-AA15sqA3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:39.570681+00:00



## Jan. 6 committee unanimously votes to send historic criminal referral of Trump over Capitol riot
 - [http://www.msn.com/en-us/news/politics/jan-6-committee-unanimously-votes-to-send-historic-criminal-referral-of-trump-over-capitol-riot/ar-AA15szNk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jan-6-committee-unanimously-votes-to-send-historic-criminal-referral-of-trump-over-capitol-riot/ar-AA15szNk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:39.486006+00:00



## House Jan. 6 committee recommends criminal charges against Trump
 - [http://www.msn.com/en-us/news/politics/house-jan-6-committee-recommends-criminal-charges-against-trump/ar-AA15sy8e?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-jan-6-committee-recommends-criminal-charges-against-trump/ar-AA15sy8e?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:39.402024+00:00



## Live coverage: Jan. 6 committee refers Trump for 4 criminal violations
 - [http://www.msn.com/en-us/news/politics/live-coverage-jan-6-committee-refers-trump-for-4-criminal-violations/ar-AA15rXdw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/live-coverage-jan-6-committee-refers-trump-for-4-criminal-violations/ar-AA15rXdw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:39.315565+00:00



## Jan. 6 committee condemns Trump as 'central cause' of insurrection in sweeping report
 - [http://www.msn.com/en-us/news/politics/jan-6-committee-condemns-trump-as-central-cause-of-insurrection-in-sweeping-report/ar-AA15ssDw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jan-6-committee-condemns-trump-as-central-cause-of-insurrection-in-sweeping-report/ar-AA15ssDw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:39.229607+00:00



## Jan. 6 Committee Recommends Criminal Charges Against Donald Trump
 - [http://www.msn.com/en-us/news/politics/jan-6-committee-recommends-criminal-charges-against-donald-trump/ar-AA15ssFo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jan-6-committee-recommends-criminal-charges-against-donald-trump/ar-AA15ssFo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 19:38:38.809954+00:00



## Richard Johnson: Kayne West was the worst boss, ex-bodyguard spills in new documentary
 - [http://www.msn.com/en-us/news/us/richard-johnson-kayne-west-was-the-worst-boss-ex-bodyguard-spills-in-new-documentary/ar-AA15syZB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/richard-johnson-kayne-west-was-the-worst-boss-ex-bodyguard-spills-in-new-documentary/ar-AA15syZB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 18:37:14.405638+00:00



## USDA reportedly under scrutiny in animal welfare investigation into Musk’s Neuralink
 - [http://www.msn.com/en-us/news/us/usda-reportedly-under-scrutiny-in-animal-welfare-investigation-into-musk-s-neuralink/ar-AA15ssbd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/usda-reportedly-under-scrutiny-in-animal-welfare-investigation-into-musk-s-neuralink/ar-AA15ssbd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 18:37:14.398191+00:00



## R. Kelly manager gets a year in prison for theater threat
 - [http://www.msn.com/en-us/news/crime/r-kelly-manager-gets-a-year-in-prison-for-theater-threat/ar-AA15sahz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/r-kelly-manager-gets-a-year-in-prison-for-theater-threat/ar-AA15sahz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 18:37:14.389903+00:00



## CNN's Don Lemon has testy exchange with Texas Republican over border crisis: 'You said a lot of things'
 - [http://www.msn.com/en-us/news/politics/cnn-s-don-lemon-has-testy-exchange-with-texas-republican-over-border-crisis-you-said-a-lot-of-things/ar-AA15syT9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/cnn-s-don-lemon-has-testy-exchange-with-texas-republican-over-border-crisis-you-said-a-lot-of-things/ar-AA15syT9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 18:37:14.382173+00:00



## Trump aide follows him on golf course with a printer to boost ego with "uplifting articles": report
 - [http://www.msn.com/en-us/news/politics/trump-aide-follows-him-on-golf-course-with-a-printer-to-boost-ego-with-uplifting-articles-report/ar-AA15sxdg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-aide-follows-him-on-golf-course-with-a-printer-to-boost-ego-with-uplifting-articles-report/ar-AA15sxdg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 18:37:14.374602+00:00



## Long Island Cat Missing for 10 Years to Be Reunited with Owners: 'What a Christmas Present'
 - [http://www.msn.com/en-us/news/us/long-island-cat-missing-for-10-years-to-be-reunited-with-owners-what-a-christmas-present/ar-AA15rVcG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/long-island-cat-missing-for-10-years-to-be-reunited-with-owners-what-a-christmas-present/ar-AA15rVcG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 18:37:14.367461+00:00



## Ohio man sentenced to life behind bars for his role in family massacre of 8
 - [http://www.msn.com/en-us/news/crime/ohio-man-sentenced-to-life-behind-bars-for-his-role-in-family-massacre-of-8/ar-AA15sxdy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/ohio-man-sentenced-to-life-behind-bars-for-his-role-in-family-massacre-of-8/ar-AA15sxdy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 18:37:14.360198+00:00



## Live coverage: Jan. 6 committee recaps its findings in final meeting
 - [http://www.msn.com/en-us/news/politics/live-coverage-jan-6-committee-recaps-its-findings-in-final-meeting/ar-AA15rXdw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/live-coverage-jan-6-committee-recaps-its-findings-in-final-meeting/ar-AA15rXdw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 18:37:14.121000+00:00



## Putin arrives in Belarus for meeting with Lukashenko as war rages
 - [http://www.msn.com/en-us/news/world/putin-arrives-in-belarus-for-meeting-with-lukashenko-as-war-rages/ar-AA15sttP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-arrives-in-belarus-for-meeting-with-lukashenko-as-war-rages/ar-AA15sttP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 17:35:56.899261+00:00



## Locals Pissed the Feds Wants to Bring Wild Grizzlies Back
 - [http://www.msn.com/en-us/news/us/locals-pissed-the-feds-wants-to-bring-wild-grizzlies-back/ar-AA15s4IK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/locals-pissed-the-feds-wants-to-bring-wild-grizzlies-back/ar-AA15s4IK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 17:35:56.555810+00:00



## Meta says it's committed to the metaverse and will continue to invest 20% of its spending in it
 - [http://www.msn.com/en-us/news/technology/meta-says-it-s-committed-to-the-metaverse-and-will-continue-to-invest-20-of-its-spending-in-it/ar-AA15skXw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/meta-says-it-s-committed-to-the-metaverse-and-will-continue-to-invest-20-of-its-spending-in-it/ar-AA15skXw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 17:35:56.515348+00:00



## Amber Heard announces decision to settle Johnny Depp defamation case
 - [http://www.msn.com/en-us/news/crime/amber-heard-announces-decision-to-settle-johnny-depp-defamation-case/ar-AA15rOZX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/amber-heard-announces-decision-to-settle-johnny-depp-defamation-case/ar-AA15rOZX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 17:35:56.507773+00:00



## Mystery Nevada fossil site could be ancient maternity ward
 - [http://www.msn.com/en-us/news/us/mystery-nevada-fossil-site-could-be-ancient-maternity-ward/ar-AA15sp0O?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/mystery-nevada-fossil-site-could-be-ancient-maternity-ward/ar-AA15sp0O?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 17:35:56.500208+00:00



## Protesters swarm NYC library hosting Drag Story Hour for kids
 - [http://www.msn.com/en-us/news/us/protesters-swarm-nyc-library-hosting-drag-story-hour-for-kids/ar-AA15srat?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/protesters-swarm-nyc-library-hosting-drag-story-hour-for-kids/ar-AA15srat?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 17:35:56.491845+00:00



## John Bolton calls Trump political philosophy ‘performance art’
 - [http://www.msn.com/en-us/news/politics/john-bolton-calls-trump-political-philosophy-performance-art/ar-AA15stho?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/john-bolton-calls-trump-political-philosophy-performance-art/ar-AA15stho?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 17:35:56.483156+00:00



## US airstrikes in Somalia kill 15 al-Shabab fighters
 - [http://www.msn.com/en-us/news/world/us-airstrikes-in-somalia-kill-15-al-shabab-fighters/ar-AA15srkr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-airstrikes-in-somalia-kill-15-al-shabab-fighters/ar-AA15srkr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 17:35:56.475579+00:00



## Supreme Court sets February date for arguments on Biden's student debt relief
 - [http://www.msn.com/en-us/news/politics/supreme-court-sets-february-date-for-arguments-on-biden-s-student-debt-relief/ar-AA15spk5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/supreme-court-sets-february-date-for-arguments-on-biden-s-student-debt-relief/ar-AA15spk5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 17:35:56.468018+00:00



## 5 killed, 1 injured in mass shooting near Toronto, police say
 - [http://www.msn.com/en-us/news/crime/5-killed-1-injured-in-mass-shooting-near-toronto-police-say/ar-AA15rBhM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/5-killed-1-injured-in-mass-shooting-near-toronto-police-say/ar-AA15rBhM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 17:35:56.229708+00:00



## Incoming GOP congressman reportedly lied about his employment history, where he went to college, losing four employees in the Pulse nightclub shooting, and possibly his residence
 - [http://www.msn.com/en-us/news/us/incoming-gop-congressman-reportedly-lied-about-his-employment-history-where-he-went-to-college-losing-four-employees-in-the-pulse-nightclub-shooting-and-possibly-his-residence/ar-AA15s46f?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/incoming-gop-congressman-reportedly-lied-about-his-employment-history-where-he-went-to-college-losing-four-employees-in-the-pulse-nightclub-shooting-and-possibly-his-residence/ar-AA15s46f?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 16:34:35.307406+00:00



## SEE IT: Amber Heard announces settlement in court battle with ex-lover Johnny Depp
 - [http://www.msn.com/en-us/news/crime/see-it-amber-heard-announces-settlement-in-court-battle-with-ex-lover-johnny-depp/ar-AA15seQk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/see-it-amber-heard-announces-settlement-in-court-battle-with-ex-lover-johnny-depp/ar-AA15seQk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 16:34:35.298920+00:00



## The world has a new plan to save nature. Here’s how it works — and how it could fail.
 - [http://www.msn.com/en-us/news/world/the-world-has-a-new-plan-to-save-nature-here-s-how-it-works-and-how-it-could-fail/ar-AA15rUjj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-world-has-a-new-plan-to-save-nature-here-s-how-it-works-and-how-it-could-fail/ar-AA15rUjj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 16:34:35.291529+00:00



## Warnock denies he's an 'election denier,' claims voter suppression 'still an issue' in Georgia
 - [http://www.msn.com/en-us/news/world/warnock-denies-he-s-an-election-denier-claims-voter-suppression-still-an-issue-in-georgia/ar-AA15smb1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/warnock-denies-he-s-an-election-denier-claims-voter-suppression-still-an-issue-in-georgia/ar-AA15smb1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 16:34:35.284443+00:00



## Jan. 6 Committee to Vote on Criminal Referrals Against Trump in Final Meeting
 - [http://www.msn.com/en-us/news/politics/jan-6-committee-to-vote-on-criminal-referrals-against-trump-in-final-meeting/ar-AA15sk2i?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jan-6-committee-to-vote-on-criminal-referrals-against-trump-in-final-meeting/ar-AA15sk2i?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 16:34:35.276229+00:00



## Woman Allegedly Breaks Into Robert De Niro's NYC Home, Tries to Steal Christmas Gifts from Under His Tree
 - [http://www.msn.com/en-us/news/us/woman-allegedly-breaks-into-robert-de-niro-s-nyc-home-tries-to-steal-christmas-gifts-from-under-his-tree/ar-AA15sk8O?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/woman-allegedly-breaks-into-robert-de-niro-s-nyc-home-tries-to-steal-christmas-gifts-from-under-his-tree/ar-AA15sk8O?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 16:34:35.267692+00:00



## Amber Heard settles defamation case against Johnny Depp
 - [http://www.msn.com/en-us/news/crime/amber-heard-settles-defamation-case-against-johnny-depp/ar-AA15rikG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/amber-heard-settles-defamation-case-against-johnny-depp/ar-AA15rikG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 16:34:35.259876+00:00



## Harry, Meghan to debut new Netflix documentary focused on leaders
 - [http://www.msn.com/en-us/news/politics/harry-meghan-to-debut-new-netflix-documentary-focused-on-leaders/ar-AA15soCZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/harry-meghan-to-debut-new-netflix-documentary-focused-on-leaders/ar-AA15soCZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 16:34:34.920298+00:00



## Amber Heard settles defamation case against Johnny Depp
 - [http://www.msn.com/en-us/news/us/amber-heard-settles-defamation-case-against-johnny-depp/ar-AA15rikG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/amber-heard-settles-defamation-case-against-johnny-depp/ar-AA15rikG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 15:31:35.728581+00:00



## Meta Accused of 'Abusive Practices' by EU Over Facebook Marketplace
 - [http://www.msn.com/en-us/news/technology/meta-accused-of-abusive-practices-by-eu-over-facebook-marketplace/ar-AA15s7nI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/meta-accused-of-abusive-practices-by-eu-over-facebook-marketplace/ar-AA15s7nI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 15:31:35.721335+00:00



## 'Punisher' writer's comic book about vigilante border agent pulled from Kickstarter after woke backlash
 - [http://www.msn.com/en-us/news/us/punisher-writer-s-comic-book-about-vigilante-border-agent-pulled-from-kickstarter-after-woke-backlash/ar-AA15sbdQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/punisher-writer-s-comic-book-about-vigilante-border-agent-pulled-from-kickstarter-after-woke-backlash/ar-AA15sbdQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 15:31:35.714089+00:00



## The New York Times Speaks Out on Claims Its Crossword Resembles Swastika
 - [http://www.msn.com/en-us/news/world/the-new-york-times-speaks-out-on-claims-its-crossword-resembles-swastika/ar-AA15sj80?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-new-york-times-speaks-out-on-claims-its-crossword-resembles-swastika/ar-AA15sj80?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 15:31:35.706099+00:00



## How Trump has responded to the Jan. 6 committee
 - [http://www.msn.com/en-us/news/politics/how-trump-has-responded-to-the-jan-6-committee/ar-AA15rLvP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/how-trump-has-responded-to-the-jan-6-committee/ar-AA15rLvP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 15:31:35.698126+00:00



## These are the fast-growing cities in the nation: study
 - [http://www.msn.com/en-us/news/us/these-are-the-fast-growing-cities-in-the-nation-study/ar-AA15s3az?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/these-are-the-fast-growing-cities-in-the-nation-study/ar-AA15s3az?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 15:31:35.689843+00:00



## Fortnite penalised over child privacy claims
 - [http://www.msn.com/en-us/news/technology/fortnite-penalised-over-child-privacy-claims/ar-AA15sjbJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/fortnite-penalised-over-child-privacy-claims/ar-AA15sjbJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 15:31:35.682571+00:00



## UN chief calls for credible climate action, convenes summit
 - [http://www.msn.com/en-us/news/world/un-chief-calls-for-credible-climate-action-convenes-summit/ar-AA15sdZp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/un-chief-calls-for-credible-climate-action-convenes-summit/ar-AA15sdZp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 15:31:35.675086+00:00



## The Internet Starts at Kmart
 - [http://www.msn.com/en-us/news/technology/the-internet-starts-at-kmart/ar-AA15rTIe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/the-internet-starts-at-kmart/ar-AA15rTIe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 14:55:52.656699+00:00



## Coal for Christmas: Three signs Manchin could deliver Democrats a big blow before 2024
 - [http://www.msn.com/en-us/news/politics/coal-for-christmas-three-signs-manchin-could-deliver-democrats-a-big-blow-before-2024/ar-AA15s8xO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/coal-for-christmas-three-signs-manchin-could-deliver-democrats-a-big-blow-before-2024/ar-AA15s8xO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 14:55:52.648281+00:00



## I'm a lawyer who's helping laid-off Amazon and Facebook employees deal with visa issues. Here's how I advocate for them.
 - [http://www.msn.com/en-us/news/technology/i-m-a-lawyer-who-s-helping-laid-off-amazon-and-facebook-employees-deal-with-visa-issues-here-s-how-i-advocate-for-them/ar-AA15sb3g?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/i-m-a-lawyer-who-s-helping-laid-off-amazon-and-facebook-employees-deal-with-visa-issues-here-s-how-i-advocate-for-them/ar-AA15sb3g?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 14:55:52.640878+00:00



## All the Holes in This Congressman-Elect’s Résumé
 - [http://www.msn.com/en-us/news/politics/all-the-holes-in-this-congressman-elect-s-résumé/ar-AA15rSsl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/all-the-holes-in-this-congressman-elect-s-résumé/ar-AA15rSsl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 14:55:52.633575+00:00



## Italy court weighs handover in EU Parliament corruption case
 - [http://www.msn.com/en-us/news/world/italy-court-weighs-handover-in-eu-parliament-corruption-case/ar-AA15s2ud?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/italy-court-weighs-handover-in-eu-parliament-corruption-case/ar-AA15s2ud?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 14:55:52.625378+00:00



## Biden eyes 25 percent reduction in homelessness in three years
 - [http://www.msn.com/en-us/news/politics/biden-eyes-25-percent-reduction-in-homelessness-in-three-years/ar-AA15s0aD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-eyes-25-percent-reduction-in-homelessness-in-three-years/ar-AA15s0aD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 14:55:52.618176+00:00



## Trump World is imploding — which could be the start of Trump's big comeback
 - [http://www.msn.com/en-us/news/politics/trump-world-is-imploding-which-could-be-the-start-of-trump-s-big-comeback/ar-AA15s0aG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-world-is-imploding-which-could-be-the-start-of-trump-s-big-comeback/ar-AA15s0aG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 14:55:52.610953+00:00



## Chainsaw-wielding man storms police station, holds 2 children hostage, police say
 - [http://www.msn.com/en-us/news/crime/chainsaw-wielding-man-storms-police-station-holds-2-children-hostage-police-say/ar-AA15rSh5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/chainsaw-wielding-man-storms-police-station-holds-2-children-hostage-police-say/ar-AA15rSh5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 14:55:52.272877+00:00



## Kari Lake Asks Supporters to Pray for Her Attorneys as They Face Sanctions
 - [http://www.msn.com/en-us/news/politics/kari-lake-asks-supporters-to-pray-for-her-attorneys-as-they-face-sanctions/ar-AA15rTeZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kari-lake-asks-supporters-to-pray-for-her-attorneys-as-they-face-sanctions/ar-AA15rTeZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 13:53:26.555026+00:00



## Editorial: Lenient all-civilian LAPD discipline panels let bad cops off the hook
 - [http://www.msn.com/en-us/news/crime/editorial-lenient-all-civilian-lapd-discipline-panels-let-bad-cops-off-the-hook/ar-AA15rnac?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/editorial-lenient-all-civilian-lapd-discipline-panels-let-bad-cops-off-the-hook/ar-AA15rnac?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 13:53:26.547408+00:00



## Russia-Ukraine live updates: Ukraine shoots down 30 Russian drones, officials say
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-ukraine-shoots-down-30-russian-drones-officials-say/ar-AA11dhnl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-ukraine-shoots-down-30-russian-drones-officials-say/ar-AA11dhnl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 13:53:26.539445+00:00



## Activision Blizzard's President To Join Bored Ape Yacht Club as CEO
 - [http://www.msn.com/en-us/news/technology/activision-blizzard-s-president-to-join-bored-ape-yacht-club-as-ceo/ar-AA15rLRa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/activision-blizzard-s-president-to-join-bored-ape-yacht-club-as-ceo/ar-AA15rLRa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 13:53:26.531415+00:00



## Russian military releases propaganda pop song fantasizing about its nukes wiping out NATO and the US
 - [http://www.msn.com/en-us/news/world/russian-military-releases-propaganda-pop-song-fantasizing-about-its-nukes-wiping-out-nato-and-the-us/ar-AA15rQZX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-military-releases-propaganda-pop-song-fantasizing-about-its-nukes-wiping-out-nato-and-the-us/ar-AA15rQZX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 13:53:26.523775+00:00



## Russian drones strike Kyiv in overnight attack
 - [http://www.msn.com/en-us/news/world/russian-drones-strike-kyiv-in-overnight-attack/ar-AA15s1eT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-drones-strike-kyiv-in-overnight-attack/ar-AA15s1eT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 13:53:26.516148+00:00



## Ukraine Latest: Putin Lands in Minsk After More Drones Hit Kyiv
 - [http://www.msn.com/en-us/news/world/ukraine-latest-putin-lands-in-minsk-after-more-drones-hit-kyiv/ar-AA15re51?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-latest-putin-lands-in-minsk-after-more-drones-hit-kyiv/ar-AA15re51?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 13:53:26.508238+00:00



## Musk’s Twitter poll says he should resign as head of Twitter
 - [http://www.msn.com/en-us/news/technology/musk-s-twitter-poll-says-he-should-resign-as-head-of-twitter/ar-AA15rRm6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/musk-s-twitter-poll-says-he-should-resign-as-head-of-twitter/ar-AA15rRm6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 13:53:26.500590+00:00



## Jan. 6 committee caps off 18-month investigation with final public meeting
 - [http://www.msn.com/en-us/news/politics/jan-6-committee-caps-off-18-month-investigation-with-final-public-meeting/ar-AA15rhFs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jan-6-committee-caps-off-18-month-investigation-with-final-public-meeting/ar-AA15rhFs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 12:52:16.025006+00:00



## ‘Christmas Mubarak’: For many South Asian Americans, the holiday is a cultural celebration
 - [http://www.msn.com/en-us/news/us/christmas-mubarak-for-many-south-asian-americans-the-holiday-is-a-cultural-celebration/ar-AA15rFiz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/christmas-mubarak-for-many-south-asian-americans-the-holiday-is-a-cultural-celebration/ar-AA15rFiz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 12:52:16.017717+00:00



## Twitter's 'Thursday Night Massacre' of journalist bans mocked on social media: 'Comedic gold'
 - [http://www.msn.com/en-us/news/technology/twitter-s-thursday-night-massacre-of-journalist-bans-mocked-on-social-media-comedic-gold/ar-AA15rmy2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/twitter-s-thursday-night-massacre-of-journalist-bans-mocked-on-social-media-comedic-gold/ar-AA15rmy2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 12:52:16.010476+00:00



## An aide regularly instructs Trump allies to call him and praise him to boost his spirits, report says
 - [http://www.msn.com/en-us/news/politics/an-aide-regularly-instructs-trump-allies-to-call-him-and-praise-him-to-boost-his-spirits-report-says/ar-AA15rFIc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/an-aide-regularly-instructs-trump-allies-to-call-him-and-praise-him-to-boost-his-spirits-report-says/ar-AA15rFIc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 12:52:16.003204+00:00



## 5 People Dead in 'Horrendous' Condo Shooting Near Toronto
 - [http://www.msn.com/en-us/news/crime/5-people-dead-in-horrendous-condo-shooting-near-toronto/ar-AA15rxNv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/5-people-dead-in-horrendous-condo-shooting-near-toronto/ar-AA15rxNv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 12:52:15.996019+00:00



## Russia Sets Up 'Dragon's Teeth' in Melitopol Amid Street Battle Fears—ISW
 - [http://www.msn.com/en-us/news/world/russia-sets-up-dragon-s-teeth-in-melitopol-amid-street-battle-fears-isw/ar-AA15rNEk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-sets-up-dragon-s-teeth-in-melitopol-amid-street-battle-fears-isw/ar-AA15rNEk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 12:52:15.988115+00:00



## Major overnight drone attack hits Kyiv as Putin heads to neighboring Belarus
 - [http://www.msn.com/en-us/news/world/major-overnight-drone-attack-hits-kyiv-as-putin-heads-to-neighboring-belarus/ar-AA15rCEV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/major-overnight-drone-attack-hits-kyiv-as-putin-heads-to-neighboring-belarus/ar-AA15rCEV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 12:52:15.979576+00:00



## Charitable giving should not be a luxury good
 - [http://www.msn.com/en-us/news/politics/charitable-giving-should-not-be-a-luxury-good/ar-AA15rHZX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/charitable-giving-should-not-be-a-luxury-good/ar-AA15rHZX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 12:52:15.971754+00:00



## 4D chess or folly? Musk stunts raise speculation about Twitter's prospects
 - [http://www.msn.com/en-us/news/technology/4d-chess-or-folly-musk-stunts-raise-speculation-about-twitter-s-prospects/ar-AA15rzT2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/4d-chess-or-folly-musk-stunts-raise-speculation-about-twitter-s-prospects/ar-AA15rzT2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:51:04.064803+00:00



## Nicholas Goldberg: The hijab is rallying protesters in Iran, but the unrest is about so much more.
 - [http://www.msn.com/en-us/news/world/nicholas-goldberg-the-hijab-is-rallying-protesters-in-iran-but-the-unrest-is-about-so-much-more/ar-AA15rJ2N?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/nicholas-goldberg-the-hijab-is-rallying-protesters-in-iran-but-the-unrest-is-about-so-much-more/ar-AA15rJ2N?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:51:04.056854+00:00



## January 6 Committee holds final meeting, expected to take action against Trump, allies
 - [http://www.msn.com/en-us/news/politics/january-6-committee-holds-final-meeting-expected-to-take-action-against-trump-allies/ar-AA15rBwa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/january-6-committee-holds-final-meeting-expected-to-take-action-against-trump-allies/ar-AA15rBwa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:51:04.048841+00:00



## The very serious science of humor
 - [http://www.msn.com/en-us/news/technology/the-very-serious-science-of-humor/ar-AA15rA6q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/the-very-serious-science-of-humor/ar-AA15rA6q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:51:04.040878+00:00



## Elon Musk asked his Twitter followers if he should step down as the company's CEO. 57.5% voted 'yes.'
 - [http://www.msn.com/en-us/news/technology/elon-musk-asked-his-twitter-followers-if-he-should-step-down-as-the-company-s-ceo-57-5-voted-yes/ar-AA15rBNV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-asked-his-twitter-followers-if-he-should-step-down-as-the-company-s-ceo-57-5-voted-yes/ar-AA15rBNV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:51:04.032922+00:00



## The Hill’s Morning Report — Jan. 6 panel to dominate this week
 - [http://www.msn.com/en-us/news/politics/the-hill-s-morning-report-jan-6-panel-to-dominate-this-week/ar-AA15rERR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-hill-s-morning-report-jan-6-panel-to-dominate-this-week/ar-AA15rERR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:51:04.024844+00:00



## Twitter users vote for Elon Musk to step down as CEO in poll he launched
 - [http://www.msn.com/en-us/news/technology/twitter-users-vote-for-elon-musk-to-step-down-as-ceo-in-poll-he-launched/ar-AA15rJjy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/twitter-users-vote-for-elon-musk-to-step-down-as-ceo-in-poll-he-launched/ar-AA15rJjy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:51:04.015471+00:00



## Twitter users tell Elon Musk to step down in poll results
 - [http://www.msn.com/en-us/news/technology/twitter-users-tell-elon-musk-to-step-down-in-poll-results/ar-AA15rxgS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/twitter-users-tell-elon-musk-to-step-down-in-poll-results/ar-AA15rxgS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:51:04.007388+00:00



## Germany's Merkel offers her thoughts on Wagner's Ring cycle
 - [http://www.msn.com/en-us/news/world/germany-s-merkel-offers-her-thoughts-on-wagner-s-ring-cycle/ar-AA15qMHK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/germany-s-merkel-offers-her-thoughts-on-wagner-s-ring-cycle/ar-AA15qMHK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:26:45.419054+00:00



## Unfinished Trump business dominates end-of-year sprint: The Note
 - [http://www.msn.com/en-us/news/politics/unfinished-trump-business-dominates-end-of-year-sprint-the-note/ar-AA15rGtY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/unfinished-trump-business-dominates-end-of-year-sprint-the-note/ar-AA15rGtY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:26:45.410428+00:00



## Energy and Commerce agenda: More support for fossil fuels
 - [http://www.msn.com/en-us/news/politics/energy-and-commerce-agenda-more-support-for-fossil-fuels/ar-AA15rISk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/energy-and-commerce-agenda-more-support-for-fossil-fuels/ar-AA15rISk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:26:45.403149+00:00



## Bobby Rush’s retirement is a chance to return to ‘first love’: social justice
 - [http://www.msn.com/en-us/news/politics/bobby-rush-s-retirement-is-a-chance-to-return-to-first-love-social-justice/ar-AA15qHc4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/bobby-rush-s-retirement-is-a-chance-to-return-to-first-love-social-justice/ar-AA15qHc4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:26:45.395735+00:00



## January 6 Committee holds final hearing, expected to take action against Trump, allies
 - [http://www.msn.com/en-us/news/politics/january-6-committee-holds-final-hearing-expected-to-take-action-against-trump-allies/ar-AA15rBwa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/january-6-committee-holds-final-hearing-expected-to-take-action-against-trump-allies/ar-AA15rBwa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:26:45.388284+00:00



## More than two dozen sailors missing after Thai warship sinks
 - [http://www.msn.com/en-us/news/world/more-than-two-dozen-sailors-missing-after-thai-warship-sinks/ar-AA15rDFu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/more-than-two-dozen-sailors-missing-after-thai-warship-sinks/ar-AA15rDFu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:15:39.907767+00:00



## John M. Crisp: An old-school English teacher encounters ChatGPT
 - [http://www.msn.com/en-us/news/us/john-m-crisp-an-old-school-english-teacher-encounters-chatgpt/ar-AA15rwSx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/john-m-crisp-an-old-school-english-teacher-encounters-chatgpt/ar-AA15rwSx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:15:39.899246+00:00



## Rwanda migrant plan is lawful, High Court rules
 - [http://www.msn.com/en-us/news/world/rwanda-migrant-plan-is-lawful-high-court-rules/ar-AA15rzuu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/rwanda-migrant-plan-is-lawful-high-court-rules/ar-AA15rzuu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:15:39.890733+00:00



## Criminal referral for Trump is coming — but it's the Jan. 6 evidence that matters
 - [http://www.msn.com/en-us/news/politics/criminal-referral-for-trump-is-coming-but-it-s-the-jan-6-evidence-that-matters/ar-AA15rDP0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/criminal-referral-for-trump-is-coming-but-it-s-the-jan-6-evidence-that-matters/ar-AA15rDP0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 11:15:39.881961+00:00



## Why Chicago, the U.S.'s Busiest Railroad Hub, Is So Vulnerable to Strikes
 - [http://www.msn.com/en-us/autos/other/why-chicago-the-u-s-s-busiest-railroad-hub-is-so-vulnerable-to-strikes/vi-AA15rwJl?srcref=rss](http://www.msn.com/en-us/autos/other/why-chicago-the-u-s-s-busiest-railroad-hub-is-so-vulnerable-to-strikes/vi-AA15rwJl?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:54:04.988992+00:00



## Anwar Cements Malaysia Power With Early Confidence Vote Win
 - [http://www.msn.com/en-us/news/world/anwar-cements-malaysia-power-with-early-confidence-vote-win/ar-AA15rDEz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/anwar-cements-malaysia-power-with-early-confidence-vote-win/ar-AA15rDEz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:54:04.977956+00:00



## Russia, China to hold joint naval drills
 - [http://www.msn.com/en-us/news/world/russia-china-to-hold-joint-naval-drills/ar-AA15rDzu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-china-to-hold-joint-naval-drills/ar-AA15rDzu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:54:04.775510+00:00



## Virginia Tech soccer player who refused to kneel for BLM scores legal victory
 - [http://www.msn.com/en-us/news/us/virginia-tech-soccer-player-who-refused-to-kneel-for-blm-scores-legal-victory/ar-AA15rq0G?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/virginia-tech-soccer-player-who-refused-to-kneel-for-blm-scores-legal-victory/ar-AA15rq0G?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:42:58.774495+00:00



## This week: Jan. 6 committee’s closing act; final dash for government funding
 - [http://www.msn.com/en-us/news/politics/this-week-jan-6-committee-s-closing-act-final-dash-for-government-funding/ar-AA15rpY5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/this-week-jan-6-committee-s-closing-act-final-dash-for-government-funding/ar-AA15rpY5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:42:58.766215+00:00



## What to expect from the Jan. 6 committee's final public meeting
 - [http://www.msn.com/en-us/news/politics/what-to-expect-from-the-jan-6-committee-s-final-public-meeting/ar-AA15rpTM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/what-to-expect-from-the-jan-6-committee-s-final-public-meeting/ar-AA15rpTM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:42:58.757394+00:00



## Sailors Missing After Thai Navy Warship Sinks
 - [http://www.msn.com/en-us/news/world/sailors-missing-after-thai-navy-warship-sinks/ar-AA15rq78?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/sailors-missing-after-thai-navy-warship-sinks/ar-AA15rq78?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:42:58.749856+00:00



## At Hanukkah reception, Biden to condemn rising antisemitism
 - [http://www.msn.com/en-us/news/politics/at-hanukkah-reception-biden-to-condemn-rising-antisemitism/ar-AA15rAXw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/at-hanukkah-reception-biden-to-condemn-rising-antisemitism/ar-AA15rAXw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:42:58.737990+00:00



## Meghan Markle Critic Slammed For 'Vile & Depraved' Post-Netflix Column
 - [http://www.msn.com/en-us/news/world/meghan-markle-critic-slammed-for-vile-depraved-post-netflix-column/ar-AA15rtO3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/meghan-markle-critic-slammed-for-vile-depraved-post-netflix-column/ar-AA15rtO3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:27:36.700110+00:00



## Democrats scramble in one-week primary for open Virginia seat
 - [http://www.msn.com/en-us/news/politics/democrats-scramble-in-one-week-primary-for-open-virginia-seat/ar-AA15rwpO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/democrats-scramble-in-one-week-primary-for-open-virginia-seat/ar-AA15rwpO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:27:36.692412+00:00



## NY Times Sunday crossword puzzles readers with swastika shape on Hanukkah: ‘How did this get approved’
 - [http://www.msn.com/en-us/news/world/ny-times-sunday-crossword-puzzles-readers-with-swastika-shape-on-hanukkah-how-did-this-get-approved/ar-AA15rkpP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ny-times-sunday-crossword-puzzles-readers-with-swastika-shape-on-hanukkah-how-did-this-get-approved/ar-AA15rkpP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:27:36.683750+00:00



## South African president reelected leader of ruling ANC party
 - [http://www.msn.com/en-us/news/world/south-african-president-reelected-leader-of-ruling-anc-party/ar-AA15rspK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/south-african-president-reelected-leader-of-ruling-anc-party/ar-AA15rspK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:27:36.675857+00:00



## Historic deal to protect lands and oceans reached at U.N. biodiversity conference
 - [http://www.msn.com/en-us/news/world/historic-deal-to-protect-lands-and-oceans-reached-at-u-n-biodiversity-conference/ar-AA15rkiy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/historic-deal-to-protect-lands-and-oceans-reached-at-u-n-biodiversity-conference/ar-AA15rkiy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:14:11.174676+00:00



## US homeless numbers stay about the same as before pandemic
 - [http://www.msn.com/en-us/news/politics/us-homeless-numbers-stay-about-the-same-as-before-pandemic/ar-AA15rAEM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/us-homeless-numbers-stay-about-the-same-as-before-pandemic/ar-AA15rAEM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:14:10.831794+00:00



## Donald Trump Frets Over Imminent Release of Tax Returns: 'Illegal'
 - [http://www.msn.com/en-us/news/politics/donald-trump-frets-over-imminent-release-of-tax-returns-illegal/ar-AA15rpsV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/donald-trump-frets-over-imminent-release-of-tax-returns-illegal/ar-AA15rpsV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:14:10.759625+00:00



## Lebanon killing: Soldier Seán Rooney repatriated to Ireland
 - [http://www.msn.com/en-us/news/world/lebanon-killing-soldier-seán-rooney-repatriated-to-ireland/ar-AA15rsbv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/lebanon-killing-soldier-seán-rooney-repatriated-to-ireland/ar-AA15rsbv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:14:10.750257+00:00



## Did This Beloved High School Dean Moonlight as a Drug Kingpin?
 - [http://www.msn.com/en-us/news/crime/did-this-beloved-high-school-dean-moonlight-as-a-drug-kingpin/ar-AA15rpoz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/did-this-beloved-high-school-dean-moonlight-as-a-drug-kingpin/ar-AA15rpoz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 10:14:10.512727+00:00



## Today's Wordle #548 Clues, Tips and Answer for Monday, December 19 Game
 - [http://www.msn.com/en-us/news/technology/today-s-wordle-548-clues-tips-and-answer-for-monday-december-19-game/ar-AA15rvGn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/today-s-wordle-548-clues-tips-and-answer-for-monday-december-19-game/ar-AA15rvGn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 09:40:55.945001+00:00



## Russia-Ukraine live updates: Russian drones strike Ukrainian capital
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-russian-drones-strike-ukrainian-capital/ar-AA11dhnl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-russian-drones-strike-ukrainian-capital/ar-AA11dhnl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 09:40:55.937809+00:00



## COP15 Adopts Biodiversity Plan to Protect 30% of Land and Water by 2030
 - [http://www.msn.com/en-us/news/world/cop15-adopts-biodiversity-plan-to-protect-30-of-land-and-water-by-2030/ar-AA15rcAs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/cop15-adopts-biodiversity-plan-to-protect-30-of-land-and-water-by-2030/ar-AA15rcAs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 09:40:55.930778+00:00



## Five killed in 'horrendous' Toronto shooting
 - [http://www.msn.com/en-us/news/world/five-killed-in-horrendous-toronto-shooting/ar-AA15rr84?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/five-killed-in-horrendous-toronto-shooting/ar-AA15rr84?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 09:40:55.923019+00:00



## Jerry Zezima: All aboard the Polar Express
 - [http://www.msn.com/en-us/news/us/jerry-zezima-all-aboard-the-polar-express/ar-AA15rjJG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jerry-zezima-all-aboard-the-polar-express/ar-AA15rjJG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 09:40:55.914865+00:00



## Zelensky Uses World Cup Analogy in War Comparison: Red Card or Red Button?
 - [http://www.msn.com/en-us/news/world/zelensky-uses-world-cup-analogy-in-war-comparison-red-card-or-red-button/ar-AA15ro8W?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/zelensky-uses-world-cup-analogy-in-war-comparison-red-card-or-red-button/ar-AA15ro8W?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 08:40:47.908516+00:00



## Elon Musk's 'stalker' is an Uber Eats worker who thinks Tesla boss is stalking HIM
 - [http://www.msn.com/en-us/news/technology/elon-musk-s-stalker-is-an-uber-eats-worker-who-thinks-tesla-boss-is-stalking-him/ar-AA15ro4m?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-s-stalker-is-an-uber-eats-worker-who-thinks-tesla-boss-is-stalking-him/ar-AA15ro4m?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 08:40:47.901242+00:00



## Lawmakers are donating Bankman-Fried’s campaign contributions — who and where
 - [http://www.msn.com/en-us/news/politics/lawmakers-are-donating-bankman-fried-s-campaign-contributions-who-and-where/ar-AA15rf78?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lawmakers-are-donating-bankman-fried-s-campaign-contributions-who-and-where/ar-AA15rf78?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 08:40:47.893044+00:00



## Pakistani Taliban overpower guards, seize police center
 - [http://www.msn.com/en-us/news/world/pakistani-taliban-overpower-guards-seize-police-center/ar-AA15rnUe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/pakistani-taliban-overpower-guards-seize-police-center/ar-AA15rnUe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 08:40:47.884769+00:00



## World Cup Celebrations Erupt After Argentina Beats France
 - [http://www.msn.com/en-us/sports/soccer/world-cup-celebrations-erupt-after-argentina-beats-france/vi-AA15qzMg?srcref=rss](http://www.msn.com/en-us/sports/soccer/world-cup-celebrations-erupt-after-argentina-beats-france/vi-AA15qzMg?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 07:40:36.777301+00:00



## Ukraine Latest: Russian Drone Attacks Target Capital, Kyiv Says
 - [http://www.msn.com/en-us/news/world/ukraine-latest-russian-drone-attacks-target-capital-kyiv-says/ar-AA15re51?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-latest-russian-drone-attacks-target-capital-kyiv-says/ar-AA15re51?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 07:40:36.769156+00:00



## Ex-Mafia Don ‘Cadillac Frank’ Salemme Dies Behind Bars at 89
 - [http://www.msn.com/en-us/news/crime/ex-mafia-don-cadillac-frank-salemme-dies-behind-bars-at-89/ar-AA15rfUG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/ex-mafia-don-cadillac-frank-salemme-dies-behind-bars-at-89/ar-AA15rfUG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 07:40:36.761125+00:00



## RNC chair Ronna McDaniel says her support is 'pretty solid' as she faces challengers in re-election bid
 - [http://www.msn.com/en-us/news/politics/rnc-chair-ronna-mcdaniel-says-her-support-is-pretty-solid-as-she-faces-challengers-in-re-election-bid/ar-AA15qWzG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rnc-chair-ronna-mcdaniel-says-her-support-is-pretty-solid-as-she-faces-challengers-in-re-election-bid/ar-AA15qWzG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 07:40:36.753057+00:00



## Court to rule on UK plan to send asylum-seekers to Rwanda
 - [http://www.msn.com/en-us/news/world/court-to-rule-on-uk-plan-to-send-asylum-seekers-to-rwanda/ar-AA15rea9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/court-to-rule-on-uk-plan-to-send-asylum-seekers-to-rwanda/ar-AA15rea9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 07:40:36.745619+00:00



## Hawaiian Airlines Turbulence Injures More Than a Dozen People
 - [http://www.msn.com/en-us/news/world/hawaiian-airlines-turbulence-injures-more-than-a-dozen-people/vi-AA15qVUW?srcref=rss](http://www.msn.com/en-us/news/world/hawaiian-airlines-turbulence-injures-more-than-a-dozen-people/vi-AA15qVUW?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 06:40:28.419190+00:00



## Twitter announces, then quickly retracts ban on promoting other social media
 - [http://www.msn.com/en-us/news/technology/twitter-announces-then-quickly-retracts-ban-on-promoting-other-social-media/ar-AA15qjms?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/twitter-announces-then-quickly-retracts-ban-on-promoting-other-social-media/ar-AA15qjms?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 06:40:28.410479+00:00



## Man to be sentenced in murders of 8 from another Ohio family
 - [http://www.msn.com/en-us/news/crime/man-to-be-sentenced-in-murders-of-8-from-another-ohio-family/ar-AA15rdv3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/man-to-be-sentenced-in-murders-of-8-from-another-ohio-family/ar-AA15rdv3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 06:40:28.402010+00:00



## Trump's campaign rollout has been terrible and his hold on the GOP is weakening, outgoing Republican senator says
 - [http://www.msn.com/en-us/news/politics/trump-s-campaign-rollout-has-been-terrible-and-his-hold-on-the-gop-is-weakening-outgoing-republican-senator-says/ar-AA15r0kO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-s-campaign-rollout-has-been-terrible-and-his-hold-on-the-gop-is-weakening-outgoing-republican-senator-says/ar-AA15r0kO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 05:40:18.552409+00:00



## US border cities strained ahead of expected migrant surge
 - [http://www.msn.com/en-us/news/us/us-border-cities-strained-ahead-of-expected-migrant-surge/ar-AA15r3rN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/us-border-cities-strained-ahead-of-expected-migrant-surge/ar-AA15r3rN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 05:40:18.544311+00:00



## Jan. 6 panel pushes Trump's prosecution in forceful finish
 - [http://www.msn.com/en-us/news/politics/jan-6-panel-pushes-trump-s-prosecution-in-forceful-finish/ar-AA15r5um?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jan-6-panel-pushes-trump-s-prosecution-in-forceful-finish/ar-AA15r5um?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 05:40:18.535292+00:00



## Young conservatives send mixed messages on Trump at MAGA gathering
 - [http://www.msn.com/en-us/news/politics/young-conservatives-send-mixed-messages-on-trump-at-maga-gathering/ar-AA15qKm6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/young-conservatives-send-mixed-messages-on-trump-at-maga-gathering/ar-AA15qKm6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 04:40:11.500707+00:00



## Thai navy ship sinks, rescue underway for sailors in water
 - [http://www.msn.com/en-us/news/us/thai-navy-ship-sinks-rescue-underway-for-sailors-in-water/ar-AA15qPgo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/thai-navy-ship-sinks-rescue-underway-for-sailors-in-water/ar-AA15qPgo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 04:40:11.492626+00:00



## Peru’s Boluarte to Reshuffle Cabinet Ahead of Election Debate
 - [http://www.msn.com/en-us/news/world/peru-s-boluarte-to-reshuffle-cabinet-ahead-of-election-debate/ar-AA15qr1i?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/peru-s-boluarte-to-reshuffle-cabinet-ahead-of-election-debate/ar-AA15qr1i?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 04:40:11.485089+00:00



## Elon Musk polls Twitter users about whether he should step down
 - [http://www.msn.com/en-us/news/technology/elon-musk-polls-twitter-users-about-whether-he-should-step-down/ar-AA15qPuL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-polls-twitter-users-about-whether-he-should-step-down/ar-AA15qPuL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 04:40:11.477516+00:00



## Rep. Ro Khanna says balancing regulation and ethics online is key to ensuring technology remains a force for good: 'We need technology to democratize voice in America'
 - [http://www.msn.com/en-us/news/politics/rep-ro-khanna-says-balancing-regulation-and-ethics-online-is-key-to-ensuring-technology-remains-a-force-for-good-we-need-technology-to-democratize-voice-in-america/ar-AA15qz3s?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-ro-khanna-says-balancing-regulation-and-ethics-online-is-key-to-ensuring-technology-remains-a-force-for-good-we-need-technology-to-democratize-voice-in-america/ar-AA15qz3s?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 04:40:11.469190+00:00



## Musk lashes out at Schiff in now-deleted tweet: ‘Your brain is too small’
 - [http://www.msn.com/en-us/news/politics/musk-lashes-out-at-schiff-in-now-deleted-tweet-your-brain-is-too-small/ar-AA15r0ce?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/musk-lashes-out-at-schiff-in-now-deleted-tweet-your-brain-is-too-small/ar-AA15r0ce?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 04:40:11.461157+00:00



## Saying sorry for slavery leaves Dutch divided
 - [http://www.msn.com/en-us/news/world/saying-sorry-for-slavery-leaves-dutch-divided/ar-AA15qT7h?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/saying-sorry-for-slavery-leaves-dutch-divided/ar-AA15qT7h?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 03:40:01.639304+00:00



## Rep. Nancy Mace on FBI's alleged censorship coordination with Twitter: 'I want to see heads roll'
 - [http://www.msn.com/en-us/news/politics/rep-nancy-mace-on-fbi-s-alleged-censorship-coordination-with-twitter-i-want-to-see-heads-roll/ar-AA15qLtD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-nancy-mace-on-fbi-s-alleged-censorship-coordination-with-twitter-i-want-to-see-heads-roll/ar-AA15qLtD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 03:40:01.629754+00:00



## Biden marks 50th anniversary of car crash that killed first wife, baby daughter
 - [http://www.msn.com/en-us/news/us/biden-marks-50th-anniversary-of-car-crash-that-killed-first-wife-baby-daughter/ar-AA15qEyX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/biden-marks-50th-anniversary-of-car-crash-that-killed-first-wife-baby-daughter/ar-AA15qEyX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 03:40:01.604193+00:00



## 20 People Hospitalized, 11 With Serious Injuries, After Hawaiian Flight Hits Turbulence
 - [http://www.msn.com/en-us/news/us/20-people-hospitalized-11-with-serious-injuries-after-hawaiian-flight-hits-turbulence/ar-AA15qmmZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/20-people-hospitalized-11-with-serious-injuries-after-hawaiian-flight-hits-turbulence/ar-AA15qmmZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 03:40:01.596437+00:00



## NY mayor asks federal government for help ahead of influx of asylum-seekers
 - [http://www.msn.com/en-us/news/us/ny-mayor-asks-federal-government-for-help-ahead-of-influx-of-asylum-seekers/ar-AA15qDmM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/ny-mayor-asks-federal-government-for-help-ahead-of-influx-of-asylum-seekers/ar-AA15qDmM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 03:40:01.587839+00:00



## UN human rights chief calls on Musk to respect free speech
 - [http://www.msn.com/en-us/news/politics/un-human-rights-chief-calls-on-musk-to-respect-free-speech/ar-AA15qP6Z?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/un-human-rights-chief-calls-on-musk-to-respect-free-speech/ar-AA15qP6Z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 03:40:01.578309+00:00



## Elon Musk Launches 'Should I Step Down as Head of Twitter?' Poll
 - [http://www.msn.com/en-us/news/politics/elon-musk-launches-should-i-step-down-as-head-of-twitter-poll/ar-AA15qO3l?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/elon-musk-launches-should-i-step-down-as-head-of-twitter-poll/ar-AA15qO3l?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 02:39:50.335522+00:00



## Elon Musk polls users about stepping down as head of Twitter
 - [http://www.msn.com/en-us/news/politics/elon-musk-polls-users-about-stepping-down-as-head-of-twitter/ar-AA15qLbD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/elon-musk-polls-users-about-stepping-down-as-head-of-twitter/ar-AA15qLbD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 02:39:50.325904+00:00



## North Korea says rocket launch was test of 1st spy satellite
 - [http://www.msn.com/en-us/news/world/north-korea-says-rocket-launch-was-test-of-1st-spy-satellite/ar-AA15qBxy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/north-korea-says-rocket-launch-was-test-of-1st-spy-satellite/ar-AA15qBxy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 02:39:50.318838+00:00



## Trump is accused of using copyrighted images in his NFT collection
 - [http://www.msn.com/en-us/news/politics/trump-is-accused-of-using-copyrighted-images-in-his-nft-collection/ar-AA15qSX7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-is-accused-of-using-copyrighted-images-in-his-nft-collection/ar-AA15qSX7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 02:39:50.311049+00:00



## Nixon's Watergate lawyer says Trump's 2024 bid is 'a defense of sorts' against Jan 6 indictment but it won't matter because the committee has an 'overwhelming case'
 - [http://www.msn.com/en-us/news/politics/nixon-s-watergate-lawyer-says-trump-s-2024-bid-is-a-defense-of-sorts-against-jan-6-indictment-but-it-won-t-matter-because-the-committee-has-an-overwhelming-case/ar-AA15qmdF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/nixon-s-watergate-lawyer-says-trump-s-2024-bid-is-a-defense-of-sorts-against-jan-6-indictment-but-it-won-t-matter-because-the-committee-has-an-overwhelming-case/ar-AA15qmdF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 02:39:50.301738+00:00



## Members of Republican base hint that they are ready for a new generation of leader to run in 2024
 - [http://www.msn.com/en-us/news/politics/members-of-republican-base-hint-that-they-are-ready-for-a-new-generation-of-leader-to-run-in-2024/ar-AA15qlIz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/members-of-republican-base-hint-that-they-are-ready-for-a-new-generation-of-leader-to-run-in-2024/ar-AA15qlIz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 01:39:41.915329+00:00



## Why your cat is obsessed with destroying your Christmas tree — and how to make them stop
 - [http://www.msn.com/en-us/news/technology/why-your-cat-is-obsessed-with-destroying-your-christmas-tree-and-how-to-make-them-stop/ar-AA15qNJ6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/why-your-cat-is-obsessed-with-destroying-your-christmas-tree-and-how-to-make-them-stop/ar-AA15qNJ6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 01:39:41.906232+00:00



## Texas Border Patrol facility overwhelmed with illegal immigrants as Title 42 expiration looms
 - [http://www.msn.com/en-us/news/us/texas-border-patrol-facility-overwhelmed-with-illegal-immigrants-as-title-42-expiration-looms/ar-AA15qrUx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/texas-border-patrol-facility-overwhelmed-with-illegal-immigrants-as-title-42-expiration-looms/ar-AA15qrUx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 01:39:41.898617+00:00



## McDaniel faces furious campaign from right in race for RNC chair
 - [http://www.msn.com/en-us/news/politics/mcdaniel-faces-furious-campaign-from-right-in-race-for-rnc-chair/ar-AA15qewB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mcdaniel-faces-furious-campaign-from-right-in-race-for-rnc-chair/ar-AA15qewB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 01:39:41.889375+00:00



## Man mistakenly released from jail charged after allegedly killing man at gas station
 - [http://www.msn.com/en-us/news/crime/man-mistakenly-released-from-jail-charged-after-allegedly-killing-man-at-gas-station/ar-AA15qL05?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/man-mistakenly-released-from-jail-charged-after-allegedly-killing-man-at-gas-station/ar-AA15qL05?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 01:39:41.881560+00:00



## Musk Dares Public to Vote Him Out as Twitter Head in Poll
 - [http://www.msn.com/en-us/news/technology/musk-dares-public-to-vote-him-out-as-twitter-head-in-poll/ar-AA15qJsX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/musk-dares-public-to-vote-him-out-as-twitter-head-in-poll/ar-AA15qJsX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 01:39:41.873124+00:00



## Nobel Prize-winning UN World Food Program head to step down
 - [http://www.msn.com/en-us/news/world/nobel-prize-winning-un-world-food-program-head-to-step-down/ar-AA15qDvP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/nobel-prize-winning-un-world-food-program-head-to-step-down/ar-AA15qDvP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 00:39:06.867278+00:00



## Scientists Now Know Why Coyotes Unexpectedly Killed a Human in 2009
 - [http://www.msn.com/en-us/news/technology/scientists-now-know-why-coyotes-unexpectedly-killed-a-human-in-2009/ar-AA15cx9v?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/scientists-now-know-why-coyotes-unexpectedly-killed-a-human-in-2009/ar-AA15cx9v?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 00:39:06.859348+00:00



## Amazon helped rescue the Ukrainian government and economy using suitcase-sized hard drives brought in over the Polish border: 'You can't take out the cloud with a cruise missile'
 - [http://www.msn.com/en-us/news/world/amazon-helped-rescue-the-ukrainian-government-and-economy-using-suitcase-sized-hard-drives-brought-in-over-the-polish-border-you-can-t-take-out-the-cloud-with-a-cruise-missile/ar-AA15qpvq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/amazon-helped-rescue-the-ukrainian-government-and-economy-using-suitcase-sized-hard-drives-brought-in-over-the-polish-border-you-can-t-take-out-the-cloud-with-a-cruise-missile/ar-AA15qpvq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 00:39:06.850653+00:00



## Cops in Stand-Off With Chainsaw-Wielding Man Who Attacked Mass. Police Station
 - [http://www.msn.com/en-us/news/crime/cops-in-stand-off-with-chainsaw-wielding-man-who-attacked-mass-police-station/ar-AA15qtK9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/cops-in-stand-off-with-chainsaw-wielding-man-who-attacked-mass-police-station/ar-AA15qtK9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 00:39:06.842986+00:00



## Elon Musk posts Twitter poll asking users if he should remain CEO
 - [http://www.msn.com/en-us/news/technology/elon-musk-posts-twitter-poll-asking-users-if-he-should-remain-ceo/ar-AA15qBaD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-posts-twitter-poll-asking-users-if-he-should-remain-ceo/ar-AA15qBaD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 00:39:06.834785+00:00



## FTX’s Bankman-Fried to agree to extradition to US: reports
 - [http://www.msn.com/en-us/news/politics/ftx-s-bankman-fried-to-agree-to-extradition-to-us-reports/ar-AA15qtPH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ftx-s-bankman-fried-to-agree-to-extradition-to-us-reports/ar-AA15qtPH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-19 00:39:06.824580+00:00




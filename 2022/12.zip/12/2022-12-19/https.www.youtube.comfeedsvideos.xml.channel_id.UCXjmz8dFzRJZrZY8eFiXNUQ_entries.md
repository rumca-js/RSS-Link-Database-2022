# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## Why Don’t We Care More About Hawkeye?
 - [https://www.youtube.com/watch?v=U6kaYBte4i0](https://www.youtube.com/watch?v=U6kaYBte4i0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2022-12-19 18:00:17+00:00

The MCU version of Hawkeye never really rose to the same level as the rest of the Avengers did.  Clint Barton, aka Hawkeye, has been around for over 60 years with some truly amazing comic runs.  So why do the creative's at Marvel refuse to treat Hawkeye with the same level of respect as the rest of The Avengers.  It wasn't until his Disney+ show that they tried to adapt his best running comic series, but even then, they couldn't get Hawkeye right. 

#hawkeye  #theavengers  #nerdstalgic  

Written by Dave Baker
Edited by Brian Nappi


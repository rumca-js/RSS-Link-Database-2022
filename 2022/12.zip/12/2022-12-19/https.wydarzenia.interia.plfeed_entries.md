# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Putin zapewnia, że Rosja nie chce wchłonąć żadnego kraju. Rzecznik Departamentu Stanu USA: Szczyt ironii
 - [https://wydarzenia.interia.pl/news-putin-zapewnia-ze-rosja-nie-chce-wchlonac-zadnego-kraju-rzec,nId,6483016](https://wydarzenia.interia.pl/news-putin-zapewnia-ze-rosja-nie-chce-wchlonac-zadnego-kraju-rzec,nId,6483016)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 22:30:57+00:00

<p><a href="https://wydarzenia.interia.pl/news-putin-zapewnia-ze-rosja-nie-chce-wchlonac-zadnego-kraju-rzec,nId,6483016"><img align="left" alt="Putin zapewnia, że Rosja nie chce wchłonąć żadnego kraju. Rzecznik Departamentu Stanu USA: Szczyt ironii" src="https://i.iplsc.com/putin-zapewnia-ze-rosja-nie-chce-wchlonac-zadnego-kraju-rzec/000GIH8H7HW4V1GB-C321.jpg" /></a>- Słowa Władimira Putina, który oznajmił w Mińsku, odnosząc się do Białorusi, że Rosja nie chce wchłonąć żadnego kraju, to &quot;szczyt ironii&quot;, zważywszy, że właśnie usiłuje wchłonąć Ukrainę - ocenił rzecznik Departamentu Stanu USA Ned Price.</p><br clear="all" />

## Policjanci w domu Jacka Kurskiego. "Paczka z nieznaną zawartością"
 - [https://wydarzenia.interia.pl/kraj/news-policjanci-w-domu-jacka-kurskiego-paczka-z-nieznana-zawartos,nId,6483011](https://wydarzenia.interia.pl/kraj/news-policjanci-w-domu-jacka-kurskiego-paczka-z-nieznana-zawartos,nId,6483011)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 21:57:44+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-policjanci-w-domu-jacka-kurskiego-paczka-z-nieznana-zawartos,nId,6483011"><img align="left" alt="Policjanci w domu Jacka Kurskiego. &quot;Paczka z nieznaną zawartością&quot; " src="https://i.iplsc.com/policjanci-w-domu-jacka-kurskiego-paczka-z-nieznana-zawartos/000GIH53TYBRW8FH-C321.jpg" /></a>W poniedziałek w domu Jacka i Joanny Kurskich pod Warszawą pojawili się policjanci. Funkcjonariusze interweniowali ws. tajemniczej paczki z nieznaną zawartością. Ponieważ istniało podejrzenie, że pakunek może zawierać niebezpieczne materiały na miejsce wezwano pirotechników, a domowników ewakuowano.</p><br clear="all" />

## USA. Włamywaczka w domu Roberta De Niro. Chciała ukraść prezenty
 - [https://wydarzenia.interia.pl/zagranica/news-usa-wlamywaczka-w-domu-roberta-de-niro-chciala-ukrasc-prezen,nId,6482993](https://wydarzenia.interia.pl/zagranica/news-usa-wlamywaczka-w-domu-roberta-de-niro-chciala-ukrasc-prezen,nId,6482993)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 21:07:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-wlamywaczka-w-domu-roberta-de-niro-chciala-ukrasc-prezen,nId,6482993"><img align="left" alt="USA. Włamywaczka w domu Roberta De Niro. Chciała ukraść prezenty" src="https://i.iplsc.com/usa-wlamywaczka-w-domu-roberta-de-niro-chciala-ukrasc-prezen/000GIGZIII2PHB5Q-C321.jpg" /></a>Policjanci z Nowego Jorku aresztowali na gorącym uczynku kobietę, która włamała się do domu słynnego aktora Roberta De Niro. 30-latka, która jest seryjną włamywaczką, chciała ukraść prezenty świąteczne. </p><br clear="all" />

## Zgoda na ekstradycję do Belgii żony Antonio Panzeriego
 - [https://wydarzenia.interia.pl/zagranica/news-zgoda-na-ekstradycje-do-belgii-zony-antonio-panzeriego,nId,6482987](https://wydarzenia.interia.pl/zagranica/news-zgoda-na-ekstradycje-do-belgii-zony-antonio-panzeriego,nId,6482987)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 20:56:57+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zgoda-na-ekstradycje-do-belgii-zony-antonio-panzeriego,nId,6482987"><img align="left" alt="Zgoda na ekstradycję do Belgii żony Antonio Panzeriego" src="https://i.iplsc.com/zgoda-na-ekstradycje-do-belgii-zony-antonio-panzeriego/000GIGXYOWK4TTQ6-C321.jpg" /></a>Sąd w Brescii na północy Włoch wyraził zgodę na ekstradycję do Belgii żony aresztowanego w Brukseli pod zarzutem korupcji byłego włoskiego eurodeputowanego Antonio Panzeriego - podała w poniedziałek Ansa. Maria Dolores Colleoni i jej córka do tej pory przebywały w areszcie domowym w Lombardii.</p><br clear="all" />

## Chciał ukraść kozę. Został postrzelony przez 79-letniego właściciela
 - [https://wydarzenia.interia.pl/zagranica/news-chcial-ukrasc-koze-zostal-postrzelony-przez-79-letniego-wlas,nId,6482955](https://wydarzenia.interia.pl/zagranica/news-chcial-ukrasc-koze-zostal-postrzelony-przez-79-letniego-wlas,nId,6482955)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 20:44:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chcial-ukrasc-koze-zostal-postrzelony-przez-79-letniego-wlas,nId,6482955"><img align="left" alt="Chciał ukraść kozę. Został postrzelony przez 79-letniego właściciela" src="https://i.iplsc.com/chcial-ukrasc-koze-zostal-postrzelony-przez-79-letniego-wlas/000GIGUVU3U41QMW-C321.jpg" /></a>Mężczyzna z USA został postrzelony, kiedy próbował ukraść kozę. Właściciel posesji ruszył po broń, żeby odstraszyć intruza, ta w trakcie szarpaniny wystrzeliła. </p><br clear="all" />

## Szturm na Kapitol. Rekomendują postawienie Trumpowi zarzutów
 - [https://wydarzenia.interia.pl/zagranica/news-szturm-na-kapitol-rekomenduja-postawienie-trumpowi-zarzutow,nId,6482958](https://wydarzenia.interia.pl/zagranica/news-szturm-na-kapitol-rekomenduja-postawienie-trumpowi-zarzutow,nId,6482958)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 20:39:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szturm-na-kapitol-rekomenduja-postawienie-trumpowi-zarzutow,nId,6482958"><img align="left" alt="Szturm na Kapitol. Rekomendują postawienie Trumpowi zarzutów" src="https://i.iplsc.com/szturm-na-kapitol-rekomenduja-postawienie-trumpowi-zarzutow/000GIGTS752U57J5-C321.jpg" /></a>Komisja Izby Reprezentantów zajmująca się szturmem na Kapitol zarekomendowała prokuraturze postawienie zarzutów byłemu prezydentowi USA Donaldowi Trumpowi. W środę 21 grudnia ma natomiast zostać opublikowany raport w sprawie zamieszek, do których doszło po wyborach prezydenckich w styczniu 2021 roku.</p><br clear="all" />

## Zwęglone zwłoki w spalonym samochodzie. Akcja w Krzeszycach
 - [https://wydarzenia.interia.pl/lubuskie/news-zweglone-zwloki-w-spalonym-samochodzie-akcja-w-krzeszycach,nId,6482980](https://wydarzenia.interia.pl/lubuskie/news-zweglone-zwloki-w-spalonym-samochodzie-akcja-w-krzeszycach,nId,6482980)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 20:34:09+00:00

<p><a href="https://wydarzenia.interia.pl/lubuskie/news-zweglone-zwloki-w-spalonym-samochodzie-akcja-w-krzeszycach,nId,6482980"><img align="left" alt="Zwęglone zwłoki w spalonym samochodzie. Akcja w Krzeszycach" src="https://i.iplsc.com/zweglone-zwloki-w-spalonym-samochodzie-akcja-w-krzeszycach/000D5EFR2LTDCL3J-C321.jpg" /></a>Makabryczne odkrycie w Krzeszycach. Jak wynika z informacji służb, strażacy jadący do pożaru samochodu osobowego na fotelu pasażer znaleźli... zwęglone zwłoki. - Na razie nie znamy tożsamości i płci tej osoby - przekazała Klaudia Biernacka z Komendy Powiatowej Policji w Sulęcinie.</p><br clear="all" />

## Tragiczny pożar w Kleczanowie. Nie żyje 55-latka
 - [https://wydarzenia.interia.pl/swietokrzyskie/news-tragiczny-pozar-w-kleczanowie-nie-zyje-55-latka,nId,6482975](https://wydarzenia.interia.pl/swietokrzyskie/news-tragiczny-pozar-w-kleczanowie-nie-zyje-55-latka,nId,6482975)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 20:16:59+00:00

<p><a href="https://wydarzenia.interia.pl/swietokrzyskie/news-tragiczny-pozar-w-kleczanowie-nie-zyje-55-latka,nId,6482975"><img align="left" alt="Tragiczny pożar w Kleczanowie. Nie żyje 55-latka" src="https://i.iplsc.com/tragiczny-pozar-w-kleczanowie-nie-zyje-55-latka/000E5G7U2EV7FIB3-C321.jpg" /></a>W Kleczanowie (woj. świętokrzyskie) doszło do pożaru domu jednorodzinnego. W wyniku zdarzenia zginęła 55-latka, z kolei 69-letni mężczyzna został zabrany do szpitala. Sprawę wyjaśnia prokuratura.</p><br clear="all" />

## Krew na dłoni Brauna. Przepychanki podczas rozprawy dr. Martyki
 - [https://wydarzenia.interia.pl/kraj/news-krew-na-dloni-brauna-przepychanki-podczas-rozprawy-dr-martyk,nId,6482913](https://wydarzenia.interia.pl/kraj/news-krew-na-dloni-brauna-przepychanki-podczas-rozprawy-dr-martyk,nId,6482913)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 19:41:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-krew-na-dloni-brauna-przepychanki-podczas-rozprawy-dr-martyk,nId,6482913"><img align="left" alt="Krew na dłoni Brauna. Przepychanki podczas rozprawy dr. Martyki" src="https://i.iplsc.com/krew-na-dloni-brauna-przepychanki-podczas-rozprawy-dr-martyk/000GIGOVANE38WTG-C321.jpg" /></a>Sąd Lekarski przy Okręgowej Izbie Lekarskiej w Krakowie wydał w poniedziałek wyrok w sprawie dyscyplinarnej dr. Zbigniewa Martyki. Za krytykę obostrzeń i strategii przyjętej przez rząd w walce z pandemią COVID-19 lekarz został zawieszony na rok w prawie wykonywania zawodu. Wokół rozprawy pojawiło się sporo kontrowersji. Dr Paweł Grzesiowski, który był biegłym w sprawie poinformował, że w związku z wydaniem wyroku jest &quot;zastraszany i pomawiany&quot;. - Działanie dr. Pawła Basiukiewicza otworzyło śluzę i spowodowało wylanie rzeki szamba przeciwko...</p><br clear="all" />

## Miedwiediew pogratulował Argentynie. Zwrócił się też do Wielkiej Brytanii
 - [https://wydarzenia.interia.pl/zagranica/news-miedwiediew-pogratulowal-argentynie-zwrocil-sie-tez-do-wielk,nId,6482932](https://wydarzenia.interia.pl/zagranica/news-miedwiediew-pogratulowal-argentynie-zwrocil-sie-tez-do-wielk,nId,6482932)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 19:19:56+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-miedwiediew-pogratulowal-argentynie-zwrocil-sie-tez-do-wielk,nId,6482932"><img align="left" alt="Miedwiediew pogratulował Argentynie. Zwrócił się też do Wielkiej Brytanii" src="https://i.iplsc.com/miedwiediew-pogratulowal-argentynie-zwrocil-sie-tez-do-wielk/000GIGEQ9WSA4NWN-C321.jpg" /></a>Reprezentacja Argentyny wygrała mundial w Katarze. Wielki sukces &quot;Albicelestes&quot; został dostrzeżony również w Moskwie. Były prezydent i premier Federacji Rosyjskiej Dmitrij Miedwiediew pogratulował Argentynie mistrzostwa świata. Przy okazji zwrócił się również z pewnym żądaniem do Wielkiej Brytanii.</p><br clear="all" />

## Mydło wycofane ze sprzedaży. Może być niebezpieczne dla zdrowia
 - [https://wydarzenia.interia.pl/zagranica/news-mydlo-wycofane-ze-sprzedazy-moze-byc-niebezpieczne-dla-zdrow,nId,6482907](https://wydarzenia.interia.pl/zagranica/news-mydlo-wycofane-ze-sprzedazy-moze-byc-niebezpieczne-dla-zdrow,nId,6482907)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 18:31:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-mydlo-wycofane-ze-sprzedazy-moze-byc-niebezpieczne-dla-zdrow,nId,6482907"><img align="left" alt="Mydło wycofane ze sprzedaży. Może być niebezpieczne dla zdrowia" src="https://i.iplsc.com/mydlo-wycofane-ze-sprzedazy-moze-byc-niebezpieczne-dla-zdrow/000GIG9LJI1M3JFK-C321.jpg" /></a>Europejski system szybkiego ostrzegania RAPEX poinformował o wykryciu niebezpiecznych bakterii w mydle lekarskim &quot;Ahrenshof&quot;. W związku z tym produkt został wycofany ze sprzedaży.</p><br clear="all" />

## Burza wokół krzyżówki w "NYT". Media: To swastyka
 - [https://wydarzenia.interia.pl/zagranica/news-burza-wokol-krzyzowki-w-nyt-media-to-swastyka,nId,6482925](https://wydarzenia.interia.pl/zagranica/news-burza-wokol-krzyzowki-w-nyt-media-to-swastyka,nId,6482925)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 18:22:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-burza-wokol-krzyzowki-w-nyt-media-to-swastyka,nId,6482925"><img align="left" alt="Burza wokół krzyżówki w &quot;NYT&quot;. Media: To swastyka" src="https://i.iplsc.com/burza-wokol-krzyzowki-w-nyt-media-to-swastyka/000GIGBJIKCWNHGV-C321.jpg" /></a>Jak informuje &quot;Jerusalem Post&quot;, w amerykańskim dzienniku &quot;The New York Times&quot; ukazała się krzyżówka w kształcie swastyki. I to w pierwszy dzień żydowskiego święta Chanuki.</p><br clear="all" />

## Pogoda coraz bardziej niebezpieczna. Drogi i chodniki jak lodowisko
 - [https://wydarzenia.interia.pl/kraj/news-pogoda-coraz-bardziej-niebezpieczna-drogi-i-chodniki-jak-lod,nId,6482896](https://wydarzenia.interia.pl/kraj/news-pogoda-coraz-bardziej-niebezpieczna-drogi-i-chodniki-jak-lod,nId,6482896)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 17:56:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogoda-coraz-bardziej-niebezpieczna-drogi-i-chodniki-jak-lod,nId,6482896"><img align="left" alt="Pogoda coraz bardziej niebezpieczna. Drogi i chodniki jak lodowisko" src="https://i.iplsc.com/pogoda-coraz-bardziej-niebezpieczna-drogi-i-chodniki-jak-lod/000GIG3JN87ECHI3-C321.jpg" /></a>Pogoda w najbliższym czasie może sprawić problemy pieszym oraz kierowcom. Ostrzeżenia pierwszego i drugiego stopnia w związku z marznącym deszczem powodującym gołoledź wydało IMGW. Trudne warunki utrzymują się na drogach w całym kraju. </p><br clear="all" />

## Białoruś. Putin przyleciał do Mińska. Rozmawiał z Łukaszenką
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialorus-putin-przylecial-do-minska-rozmawial-z-lukaszenka,nId,6482623](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialorus-putin-przylecial-do-minska-rozmawial-z-lukaszenka,nId,6482623)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 17:43:55+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialorus-putin-przylecial-do-minska-rozmawial-z-lukaszenka,nId,6482623"><img align="left" alt="Białoruś. Putin przyleciał do Mińska. Rozmawiał z Łukaszenką" src="https://i.iplsc.com/bialorus-putin-przylecial-do-minska-rozmawial-z-lukaszenka/000GIELRVSB72N70-C321.jpg" /></a>Prezydent Rosji Władimir Putin spotkał się w Mińsku z białoruskim przywódcą Alaksandrem Łukaszenką. Rozmowy w stolicy Białorusi dotyczyły gospodarki i bezpieczeństwa. Odbyły się też konsultacje ministerstw obrony obu państw. Wcześniej media spekulowały, że celem wizyty jest próba namówienia Białorusi do przyłączenia się do wojny z Ukrainą. </p><br clear="all" />

## Putin rozmawiał z Łukaszenką. Białoruś z nową bronią
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-rozmawial-z-lukaszenka-bialorus-z-nowa-bronia,nId,6482623](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-rozmawial-z-lukaszenka-bialorus-z-nowa-bronia,nId,6482623)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 17:43:55+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-rozmawial-z-lukaszenka-bialorus-z-nowa-bronia,nId,6482623"><img align="left" alt="Putin rozmawiał z Łukaszenką. Białoruś z nową bronią" src="https://i.iplsc.com/putin-rozmawial-z-lukaszenka-bialorus-z-nowa-bronia/000GIELRVSB72N70-C321.jpg" /></a>Prezydent Rosji Władimir Putin spotkał się w Mińsku z białoruskim przywódcą Alaksandrem Łukaszenką. Rozmowy w stolicy Białorusi dotyczyły gospodarki i bezpieczeństwa. Odbyły się też konsultacje ministerstw obrony obu państw. Wcześniej media spekulowały, że celem wizyty jest próba namówienia Białorusi do przyłączenia się do wojny z Ukrainą. Jak poinformował Łukaszenka, białoruska armia otrzymała od Rosji systemy rakietowe S-400 i Iskander.</p><br clear="all" />

## Sprawa Jarosława Szymczyka. Ukraińcy wydali komunikat
 - [https://wydarzenia.interia.pl/kraj/news-sprawa-jaroslawa-szymczyka-ukraincy-wydali-komunikat,nId,6482726](https://wydarzenia.interia.pl/kraj/news-sprawa-jaroslawa-szymczyka-ukraincy-wydali-komunikat,nId,6482726)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 16:30:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sprawa-jaroslawa-szymczyka-ukraincy-wydali-komunikat,nId,6482726"><img align="left" alt="Sprawa Jarosława Szymczyka. Ukraińcy wydali komunikat" src="https://i.iplsc.com/sprawa-jaroslawa-szymczyka-ukraincy-wydali-komunikat/000G87D762U532YS-C321.jpg" /></a>Strona ukraińska wydała oświadczenie ws. wypadku z udziałem Komendanta Głównego Policji Jarosława Szymczyka, do którego doszło w budynku KGP w Warszawie. Według Ukraińców Szymczyk otrzymał prezent, którego celem &quot;nie było skrzywdzenie zwierzchnika polskiej policji&quot;.</p><br clear="all" />

## Sprawa wybuchu w Komendzie Głównej Policji. Komunikat ukraińskich służb o prezencie dla gen. Jarosława Szymczyka
 - [https://wydarzenia.interia.pl/kraj/news-sprawa-wybuchu-w-komendzie-glownej-policji-komunikat-ukrains,nId,6482726](https://wydarzenia.interia.pl/kraj/news-sprawa-wybuchu-w-komendzie-glownej-policji-komunikat-ukrains,nId,6482726)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 16:30:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sprawa-wybuchu-w-komendzie-glownej-policji-komunikat-ukrains,nId,6482726"><img align="left" alt="Sprawa wybuchu w Komendzie Głównej Policji. Komunikat ukraińskich służb o prezencie dla gen. Jarosława Szymczyka" src="https://i.iplsc.com/sprawa-wybuchu-w-komendzie-glownej-policji-komunikat-ukrains/000GIFSQTB198BXQ-C321.jpg" /></a>Strona ukraińska wydała oświadczenie ws. wypadku z udziałem Komendanta Głównego Policji Jarosława Szymczyka, do którego doszło w budynku KGP w Warszawie. Według Ukraińców Szymczyk otrzymał prezent, którego celem &quot;nie było skrzywdzenie zwierzchnika polskiej policji&quot;.</p><br clear="all" />

## Sprawa wybuchu w Komendzie Głównej Policji. Ukraińskie służby wydały komunikat o prezencie dla gen. Jarosława Szymczyka
 - [https://wydarzenia.interia.pl/kraj/news-sprawa-wybuchu-w-komendzie-glownej-policji-ukrainskie-sluzby,nId,6482726](https://wydarzenia.interia.pl/kraj/news-sprawa-wybuchu-w-komendzie-glownej-policji-ukrainskie-sluzby,nId,6482726)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 16:30:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sprawa-wybuchu-w-komendzie-glownej-policji-ukrainskie-sluzby,nId,6482726"><img align="left" alt="Sprawa wybuchu w Komendzie Głównej Policji. Ukraińskie służby wydały komunikat o prezencie dla gen. Jarosława Szymczyka" src="https://i.iplsc.com/sprawa-wybuchu-w-komendzie-glownej-policji-ukrainskie-sluzby/000GIFSQTB198BXQ-C321.jpg" /></a>Strona ukraińska wydała oświadczenie ws. wypadku z udziałem Komendanta Głównego Policji Jarosława Szymczyka, do którego doszło w budynku KGP w Warszawie. Według Ukraińców Szymczyk otrzymał prezent, którego celem &quot;nie było skrzywdzenie zwierzchnika polskiej policji&quot;.</p><br clear="all" />

## Norwegia. Król Harald trafił do szpitala
 - [https://wydarzenia.interia.pl/zagranica/news-norwegia-krol-harald-trafil-do-szpitala,nId,6482670](https://wydarzenia.interia.pl/zagranica/news-norwegia-krol-harald-trafil-do-szpitala,nId,6482670)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 16:05:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-norwegia-krol-harald-trafil-do-szpitala,nId,6482670"><img align="left" alt="Norwegia. Król Harald trafił do szpitala" src="https://i.iplsc.com/norwegia-krol-harald-trafil-do-szpitala/000GIFFO35FPBD11-C321.jpg" /></a>Król Norwegii Harald V trafił do szpitala w Oslo. Przyczyną hospitalizacji 85-letniego monarchy jest infekcja. Według norweskich mediów stan króla jest stabilny.</p><br clear="all" />

## Węgry. Sklepy wprowadzają limity. Dotyczą ośmiu produktów z rządowej listy
 - [https://wydarzenia.interia.pl/zagranica/news-wegry-sklepy-wprowadzaja-limity-dotycza-osmiu-produktow-z-rz,nId,6482478](https://wydarzenia.interia.pl/zagranica/news-wegry-sklepy-wprowadzaja-limity-dotycza-osmiu-produktow-z-rz,nId,6482478)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 16:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wegry-sklepy-wprowadzaja-limity-dotycza-osmiu-produktow-z-rz,nId,6482478"><img align="left" alt="Węgry. Sklepy wprowadzają limity. Dotyczą ośmiu produktów z rządowej listy" src="https://i.iplsc.com/wegry-sklepy-wprowadzaja-limity-dotycza-osmiu-produktow-z-rz/000GIFHBWIURB753-C321.jpg" /></a>Sklepy na Węgrzech wprowadziły limity ilościowe na zakup konkretnych produktów. Na liście znajduje się m.in. mąka, mleko, jaja czy ziemniaki. Jak mówi dr Dominik Hejj, politolog specjalizujący się w tematach węgierskich, produktów z listy brakuje od dłuższego czasu. - Węgrzy boją się, że maksymalne ceny nie zostaną utrzymane, mimo rządowych obietnic. Tak, jak stało się z cenami paliw - wyjaśnia. Dodaje, że na grupach zrzeszających Polaków mieszkających na Węgrzech pojawiają się prośby o przywiezienie z kraju konkretnych artykułów spożywczych. </p><br clear="all" />

## Kraj na celowniku Rosji. "Plan ataku na Mołdawię w 2023 roku"
 - [https://wydarzenia.interia.pl/zagranica/news-kraj-na-celowniku-rosji-plan-ataku-na-moldawie-w-2023-roku,nId,6482690](https://wydarzenia.interia.pl/zagranica/news-kraj-na-celowniku-rosji-plan-ataku-na-moldawie-w-2023-roku,nId,6482690)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 15:57:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kraj-na-celowniku-rosji-plan-ataku-na-moldawie-w-2023-roku,nId,6482690"><img align="left" alt="Kraj na celowniku Rosji. &quot;Plan ataku na Mołdawię w 2023 roku&quot;" src="https://i.iplsc.com/kraj-na-celowniku-rosji-plan-ataku-na-moldawie-w-2023-roku/000GIFJILHNVHP8W-C321.jpg" /></a>Rosyjskie wojsko ma plan ataku na Mołdawię - poinformował szef Służby Wywiadu i Bezpieczeństwa (SIS) tego kraju Alexandru Musteata. Według przekazywanych przez niego informacji, do agresji miałoby dojść w na początku 2023 roku.</p><br clear="all" />

## Białoruś. Zlekceważył zakaz Łukaszenki, zapadł wyrok
 - [https://wydarzenia.interia.pl/zagranica/news-bialorus-zlekcewazyl-zakaz-lukaszenki-zapadl-wyrok,nId,6482694](https://wydarzenia.interia.pl/zagranica/news-bialorus-zlekcewazyl-zakaz-lukaszenki-zapadl-wyrok,nId,6482694)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 15:55:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bialorus-zlekcewazyl-zakaz-lukaszenki-zapadl-wyrok,nId,6482694"><img align="left" alt="Białoruś. Zlekceważył zakaz Łukaszenki, zapadł wyrok" src="https://i.iplsc.com/bialorus-zlekcewazyl-zakaz-lukaszenki-zapadl-wyrok/000DTRG3TEH9TCBK-C321.jpg" /></a>Jak informują białoruskie media, w Mohylewie zapadł wyrok w sprawie podnoszenia cen towarów. Właściciel dopuścił się tego czynu pomimo zakazu Alaksandra Łukaszenki, który chciał w ten sposób &quot;zdusić inflację&quot;. To pierwsze takie orzeczenie sądu na Białorusi.</p><br clear="all" />

## Jest unijne porozumienie ws. limitu cen gazu
 - [https://wydarzenia.interia.pl/zagranica/news-jest-unijne-porozumienie-ws-limitu-cen-gazu,nId,6482691](https://wydarzenia.interia.pl/zagranica/news-jest-unijne-porozumienie-ws-limitu-cen-gazu,nId,6482691)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 15:50:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-jest-unijne-porozumienie-ws-limitu-cen-gazu,nId,6482691"><img align="left" alt="Jest unijne porozumienie ws. limitu cen gazu" src="https://i.iplsc.com/jest-unijne-porozumienie-ws-limitu-cen-gazu/000EX4IUY9C000YX-C321.jpg" /></a>Państwa unijne porozumiały się w sprawie limitu cen rosyjskiego gazu. W ramach nowych ustaleń referencyjne stawki za ten surowiec wyniosą do ​​188 euro za megawatogodzinę.</p><br clear="all" />

## Wybuch paczki w Siecieborzycach. Ciężko ranne 31-latka i jej córka
 - [https://wydarzenia.interia.pl/lubuskie/news-wybuch-paczki-w-siecieborzycach-ciezko-ranne-31-latka-i-jej-,nId,6482620](https://wydarzenia.interia.pl/lubuskie/news-wybuch-paczki-w-siecieborzycach-ciezko-ranne-31-latka-i-jej-,nId,6482620)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 15:09:44+00:00

<p><a href="https://wydarzenia.interia.pl/lubuskie/news-wybuch-paczki-w-siecieborzycach-ciezko-ranne-31-latka-i-jej-,nId,6482620"><img align="left" alt="Wybuch paczki w Siecieborzycach. Ciężko ranne 31-latka i jej córka" src="https://i.iplsc.com/wybuch-paczki-w-siecieborzycach-ciezko-ranne-31-latka-i-jej/000GIFC2CCSXANGC-C321.jpg" /></a>Kobieta i jej siedmioletnia córka są w ciężkim stanie po tym, jak w poniedziałek rano eksplodowała paczka pozostawiona na posesji przed ich domem. 31-latka przeszła już operację, a dziewczyna czeka na zabieg. Do szpitala trafiły także dwie inne osoby. Śledczy badają okoliczności tego, co się stało w miejscowości Siecieborzyce w woj. lubuskim. </p><br clear="all" />

## Pożar w Komendzie Wojewódzkiej Policji we Wrocławiu. Ewakuacja
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-pozar-w-komendzie-wojewodzkiej-policji-we-wroclawiu-ewakuacj,nId,6482625](https://wydarzenia.interia.pl/dolnoslaskie/news-pozar-w-komendzie-wojewodzkiej-policji-we-wroclawiu-ewakuacj,nId,6482625)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 14:35:25+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-pozar-w-komendzie-wojewodzkiej-policji-we-wroclawiu-ewakuacj,nId,6482625"><img align="left" alt="Pożar w Komendzie Wojewódzkiej Policji we Wrocławiu. Ewakuacja" src="https://i.iplsc.com/pozar-w-komendzie-wojewodzkiej-policji-we-wroclawiu-ewakuacj/000GDJY75Q92KQ0P-C321.jpg" /></a>W gmachu Komendy Wojewódzkiej Policji we Wrocławiu wybuchł pożar. Jak informują służby, konieczna była ewakuacja pracowników. Ogień został zlokalizowany. Trwa oddymianie budynku.</p><br clear="all" />

## Ferrari przecięte na pół. Sceny z amerykańskiej autostrady dają do myślenia
 - [https://wydarzenia.interia.pl/zagranica/news-ferrari-przeciete-na-pol-sceny-z-amerykanskiej-autostrady-da,nId,6482622](https://wydarzenia.interia.pl/zagranica/news-ferrari-przeciete-na-pol-sceny-z-amerykanskiej-autostrady-da,nId,6482622)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 14:32:49+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ferrari-przeciete-na-pol-sceny-z-amerykanskiej-autostrady-da,nId,6482622"><img align="left" alt="Ferrari przecięte na pół. Sceny z amerykańskiej autostrady dają do myślenia" src="https://i.iplsc.com/ferrari-przeciete-na-pol-sceny-z-amerykanskiej-autostrady-da/000GIFDDRBAHKGLN-C321.jpg" /></a>Wypadek z udziałem trzech samochodów na trasie w południowej Kalifornii pozostawił ogromne zniszczenia. W sieci pojawiły się nagrania uczestniczących w zdarzeniu samochodów, w tym czerwonego ferrari, które zostało przecięte na pół. W wypadku zginął 71-latek.</p><br clear="all" />

## Nietypowa akcja w Ledze. Strażacy ratowali krowę
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-nietypowa-akcja-w-ledze-strazacy-ratowali-krowe,nId,6482615](https://wydarzenia.interia.pl/warminsko-mazurskie/news-nietypowa-akcja-w-ledze-strazacy-ratowali-krowe,nId,6482615)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 14:28:44+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-nietypowa-akcja-w-ledze-strazacy-ratowali-krowe,nId,6482615"><img align="left" alt="Nietypowa akcja w Ledze. Strażacy ratowali krowę" src="https://i.iplsc.com/nietypowa-akcja-w-ledze-strazacy-ratowali-krowe/000GIEFGIB04KIW0-C321.jpg" /></a>Nietypowa akcja straży pożarnej w miejscowości Lega (woj. warmińsko-mazurskie). Jak informują służby, strażacy dostali zgłoszenie o krowie, która utknęła w bagnie na pastwisku. By uratować zwierzę, potrzebne były specjalne skafandry.</p><br clear="all" />

## Posłowie wylatali 11,2 mln zł. "Czepiacie się. Trochę szacunku do naszej pracy"
 - [https://wydarzenia.interia.pl/kraj/news-poslowie-wylatali-11-2-mln-zl-czepiacie-sie-troche-szacunku-,nId,6482581](https://wydarzenia.interia.pl/kraj/news-poslowie-wylatali-11-2-mln-zl-czepiacie-sie-troche-szacunku-,nId,6482581)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 14:28:44+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-poslowie-wylatali-11-2-mln-zl-czepiacie-sie-troche-szacunku-,nId,6482581"><img align="left" alt="Posłowie wylatali 11,2 mln zł. &quot;Czepiacie się. Trochę szacunku do naszej pracy&quot;" src="https://i.iplsc.com/poslowie-wylatali-11-2-mln-zl-czepiacie-sie-troche-szacunku/000GIE7RIHVY8AR1-C321.jpg" /></a>Blisko 11,2 mln zł kosztowały podatników podróże lotnicze posłów w tej kadencji Sejmu. Tylko na trasach krajowych parlamentarzyści odbyli 18 551 lotów. Rekordzistą jest Grzegorz Napieralski, który zbliża się do granicy 300 lotów w tej kadencji. 15 parlamentarzystów ma na koncie ponad 200 lotów. - Nie latam dla żartów. Trochę pokory i szacunku do naszej pracy. Niech sobie pan jeździ sześć godzin w każdą stronę. Czepiacie się wszystkiego, co można. To taki temat, że aż mi się niedobrze robi - mówi Interii poseł PiS Jerzy Materna z Zielonej...</p><br clear="all" />

## Białoruś pomoże Rosji? Rzecznik Kremla o wojnie w Ukrainie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialorus-pomoze-rosji-rzecznik-kremla-o-wojnie-w-ukrainie,nId,6482538](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialorus-pomoze-rosji-rzecznik-kremla-o-wojnie-w-ukrainie,nId,6482538)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 13:40:33+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialorus-pomoze-rosji-rzecznik-kremla-o-wojnie-w-ukrainie,nId,6482538"><img align="left" alt="Białoruś pomoże Rosji? Rzecznik Kremla o wojnie w Ukrainie" src="https://i.iplsc.com/bialorus-pomoze-rosji-rzecznik-kremla-o-wojnie-w-ukrainie/000G1U4PN3I8PU55-C321.jpg" /></a>W poniedziałek Władimir Putin ma spotkać się z Alaksandrem Łukaszenką. Instytut Badań nad Wojną (ISW) stwierdza w najnowszym raporcie, że spotkanie dyktatorów jest &quot;prawdopodobnie elementem wysiłków w ramach demonstrowania proaktywności&quot;. Co więcej, dodają, że może to być również &quot;próba przygotowania informacyjnego do nowej fazy wojny&quot;. Rzecznik prezydenta Rosji Dmitrij Pieskow zaprzeczył tym doniesieniom.</p><br clear="all" />

## Ciało sześciolatka ukryte pod podłogą domu. Matka i jej partner w areszcie
 - [https://wydarzenia.interia.pl/zagranica/news-cialo-szesciolatka-ukryte-pod-podloga-domu-matka-i-jej-partn,nId,6482578](https://wydarzenia.interia.pl/zagranica/news-cialo-szesciolatka-ukryte-pod-podloga-domu-matka-i-jej-partn,nId,6482578)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 13:38:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-cialo-szesciolatka-ukryte-pod-podloga-domu-matka-i-jej-partn,nId,6482578"><img align="left" alt="Ciało sześciolatka ukryte pod podłogą domu. Matka i jej partner w areszcie" src="https://i.iplsc.com/cialo-szesciolatka-ukryte-pod-podloga-domu-matka-i-jej-partn/000GIE54F6LGI7J2-C321.jpg" /></a>W niewielkim miasteczku Moro w Arkansas w USA policja odkryła ciało sześcioletniego chłopca zakopane pod podłogą domu. Pod opieką lekarzy jest siostra chłopca, u której zaobserwowano liczne obrażenia. Matka dzieci i jej partner trafili do aresztu.</p><br clear="all" />

## Jest projekt ustawy dla aplikacji mObywatel. "Rewolucja. Państwo w komórce"
 - [https://wydarzenia.interia.pl/kraj/news-jest-projekt-ustawy-dla-aplikacji-mobywatel-rewolucja-panstw,nId,6482570](https://wydarzenia.interia.pl/kraj/news-jest-projekt-ustawy-dla-aplikacji-mobywatel-rewolucja-panstw,nId,6482570)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 13:33:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jest-projekt-ustawy-dla-aplikacji-mobywatel-rewolucja-panstw,nId,6482570"><img align="left" alt="Jest projekt ustawy dla aplikacji mObywatel. &quot;Rewolucja. Państwo w komórce&quot;" src="https://i.iplsc.com/jest-projekt-ustawy-dla-aplikacji-mobywatel-rewolucja-panstw/000GIE20CABT6C98-C321.jpg" /></a>To będzie naprawdę prawdziwa rewolucja cyfrowa, państwo w komórce, w aplikacjach mobilnych - mówił w poniedziałek rzecznik rządu Piotr Müller. Jego słowa dotyczą aplikacji mObywatel, której projekt ustawy wyszedł z Komitetu Cyfryzacji Rady Ministrów. - Niedługo stanie się przedmiotem prac rządu, a później też parlamentu - zapowiedział.</p><br clear="all" />

## Rafineria Gdańska pod ochroną. MAP wskazuje datę
 - [https://wydarzenia.interia.pl/kraj/news-rafineria-gdanska-pod-ochrona-map-wskazuje-date,nId,6482560](https://wydarzenia.interia.pl/kraj/news-rafineria-gdanska-pod-ochrona-map-wskazuje-date,nId,6482560)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 13:20:29+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rafineria-gdanska-pod-ochrona-map-wskazuje-date,nId,6482560"><img align="left" alt="Rafineria Gdańska pod ochroną. MAP wskazuje datę" src="https://i.iplsc.com/rafineria-gdanska-pod-ochrona-map-wskazuje-date/000GIE3MKY5SKHRB-C321.jpg" /></a>Jak informuje Ministerstwo Aktywów Państwowych, z dniem 1 stycznia 2023 roku Rafineria Gdańska znajdzie się w wykazie podmiotów podlegających ochronie. Chodzi o niejasności związane z fuzją Lotosu i Orlenu.</p><br clear="all" />

## Polska 2050 zawiadamia prokuraturę i NIK. Chodzi o sprzedaż udziałów Lotosu
 - [https://wydarzenia.interia.pl/galerie/kraj/news-polska-2050-zawiadamia-prokurature-i-nik-chodzi-o-sprzedaz-u,nId,6482525](https://wydarzenia.interia.pl/galerie/kraj/news-polska-2050-zawiadamia-prokurature-i-nik-chodzi-o-sprzedaz-u,nId,6482525)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 12:56:16+00:00

<p><a href="https://wydarzenia.interia.pl/galerie/kraj/news-polska-2050-zawiadamia-prokurature-i-nik-chodzi-o-sprzedaz-u,nId,6482525"><img align="left" alt="Polska 2050 zawiadamia prokuraturę i NIK. Chodzi o sprzedaż udziałów Lotosu" src="https://i.iplsc.com/polska-2050-zawiadamia-prokurature-i-nik-chodzi-o-sprzedaz-u/000GIDXSDCNBJR90-C321.jpg" /></a>Polska 2050 złożyła do prokuratury zawiadomienie o możliwości popełnienia przestępstwa przy okazji sprzedaży udziałów Lotosu saudyjskiemu koncernowi naftowemu Saudi Aramco - poinformowali Michał Kobosko i poseł Mirosław Suchoń. Przedstawiciele ugrupowania Szymona Hołowni, że formacja złoży również wniosek o kontrolę NIK w tej sprawie: &quot;Mamy nadzieję, że prezes Marian Banaś podejmie w tej sprawie niezwłoczną decyzję&quot;.</p><br clear="all" />

## Ich auto stoczyło się z przepaści. Telefon uratował im życie
 - [https://wydarzenia.interia.pl/zagranica/news-ich-auto-stoczylo-sie-z-przepasci-telefon-uratowal-im-zycie,nId,6482521](https://wydarzenia.interia.pl/zagranica/news-ich-auto-stoczylo-sie-z-przepasci-telefon-uratowal-im-zycie,nId,6482521)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 12:51:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ich-auto-stoczylo-sie-z-przepasci-telefon-uratowal-im-zycie,nId,6482521"><img align="left" alt="Ich auto stoczyło się z przepaści. Telefon uratował im życie " src="https://i.iplsc.com/ich-auto-stoczylo-sie-z-przepasci-telefon-uratowal-im-zycie/000GIDVDWWUJ41QO-C321.jpg" /></a>Młoda para z Kalifornii może mówić o cudzie. Auto, którym podróżowali po krętej drodze, stoczyło się z wysokości 90 metrów, ulegając niemal całkowitemu zmiażdżeniu. Para szczęśliwie przeżyła, jednak utknęła na dnie kanionu. Wtedy z pomocą przyszedł im telefon, który choć był zniszczony, wysłał powiadomienie SOS.</p><br clear="all" />

## Sprawa Jarosława Szymczyka. Mariusz Kamiński zabiera głos
 - [https://wydarzenia.interia.pl/kraj/news-sprawa-jaroslawa-szymczyka-mariusz-kaminski-zabiera-glos,nId,6482519](https://wydarzenia.interia.pl/kraj/news-sprawa-jaroslawa-szymczyka-mariusz-kaminski-zabiera-glos,nId,6482519)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 12:50:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sprawa-jaroslawa-szymczyka-mariusz-kaminski-zabiera-glos,nId,6482519"><img align="left" alt="Sprawa Jarosława Szymczyka. Mariusz Kamiński zabiera głos" src="https://i.iplsc.com/sprawa-jaroslawa-szymczyka-mariusz-kaminski-zabiera-glos/000GDJY4YCVFG1QO-C321.jpg" /></a>Od kilku dni pojawiają się pytania o ewentualną dymisję komendanta głównego policji Jarosława Szymczyka. Głos w sprawie zabrał minister Mariusz Kamiński.&quot;Ucinając spekulacje medialne, wykluczam dymisję Komendanta Głównego &quot; - napisał minister spraw wewnętrznych i administracji.</p><br clear="all" />

## Francja: Dmitrij Zelenow nie żyje. Kolejna tajemnicza śmierć rosyjskiego oligarchy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-francja-dmitrij-zelenow-nie-zyje-kolejna-tajemnicza-smierc-r,nId,6482473](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-francja-dmitrij-zelenow-nie-zyje-kolejna-tajemnicza-smierc-r,nId,6482473)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 12:34:58+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-francja-dmitrij-zelenow-nie-zyje-kolejna-tajemnicza-smierc-r,nId,6482473"><img align="left" alt="Francja: Dmitrij Zelenow nie żyje. Kolejna tajemnicza śmierć rosyjskiego oligarchy " src="https://i.iplsc.com/francja-dmitrij-zelenow-nie-zyje-kolejna-tajemnicza-smierc-r/000GIDOALL5W79OP-C321.jpg" /></a>Dmitrij Zelenow, właściciel największego rosyjskiego koncernu deweloperskiego Don-Stroj zmarł we Francji - przekazały lokalne media. Zelenow to kolejny rosyjski oligarcha, który zmarł w tajemniczych okolicznościach po rozpoczęciu wojny w Ukrainie.</p><br clear="all" />

## Zima trzyma, co z węglem? Wiceminister o dostawach do gmin
 - [https://wydarzenia.interia.pl/kraj/news-zima-trzyma-co-z-weglem-wiceminister-o-dostawach-do-gmin,nId,6482489](https://wydarzenia.interia.pl/kraj/news-zima-trzyma-co-z-weglem-wiceminister-o-dostawach-do-gmin,nId,6482489)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 12:22:05+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zima-trzyma-co-z-weglem-wiceminister-o-dostawach-do-gmin,nId,6482489"><img align="left" alt="Zima trzyma, co z węglem? Wiceminister o dostawach do gmin" src="https://i.iplsc.com/zima-trzyma-co-z-weglem-wiceminister-o-dostawach-do-gmin/000GIDQPVLD113CI-C321.jpg" /></a>Ponad dwa tysiące gmin otrzymało już pierwsze dostawy węgla - poinformował wiceminister aktywów państwowych Karol Rabenda. Jak podkreślił, &quot;dostarczono już dwie trzecie z 900 tys. ton zakontraktowanego surowca&quot;.</p><br clear="all" />

## Utrudnienia na DK8. Ciężarówki blokują trasę, nie mogą wjechać na wzniesienia
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-utrudnienia-na-dk8-ciezarowki-blokuja-trase-nie-moga-wjechac,nId,6482482](https://wydarzenia.interia.pl/dolnoslaskie/news-utrudnienia-na-dk8-ciezarowki-blokuja-trase-nie-moga-wjechac,nId,6482482)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 12:13:02+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-utrudnienia-na-dk8-ciezarowki-blokuja-trase-nie-moga-wjechac,nId,6482482"><img align="left" alt="Utrudnienia na DK8. Ciężarówki blokują trasę, nie mogą wjechać na wzniesienia" src="https://i.iplsc.com/utrudnienia-na-dk8-ciezarowki-blokuja-trase-nie-moga-wjechac/000GIDNG5V3RJHSK-C321.jpg" /></a>Ze względu na złe warunki pogodowe pojazdy ciężarowe na drodze krajowej nr 8 między Przerzeczynem a Ząbkowicami Śląskimi nie mogą podjechać na wzniesienia. Samochody stają w poprzek drogi i blokują ruch. Jak przekazał dyżurny wrocławskiego oddziału GDDKiA, pomimo działania piaskarek i pługów, droga jest nieprzejezdna.</p><br clear="all" />

## Kujawsko-pomorskie: 52-latek ukradł datki z kościelnej skarbonki
 - [https://wydarzenia.interia.pl/kraj/news-kujawsko-pomorskie-52-latek-ukradl-datki-z-koscielnej-skarbo,nId,6482421](https://wydarzenia.interia.pl/kraj/news-kujawsko-pomorskie-52-latek-ukradl-datki-z-koscielnej-skarbo,nId,6482421)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 11:53:57+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kujawsko-pomorskie-52-latek-ukradl-datki-z-koscielnej-skarbo,nId,6482421"><img align="left" alt="Kujawsko-pomorskie: 52-latek ukradł datki z kościelnej skarbonki" src="https://i.iplsc.com/kujawsko-pomorskie-52-latek-ukradl-datki-z-koscielnej-skarbo/000GID84HNS30T5A-C321.jpg" /></a>Z kościoła w Nakle nad Notecią (woj. kujawsko-pomorskie) skradziono datki ze skarbonki. Pieniądze odnaleziono w mieszkaniu 52-letniego złodzieja. Sprawca trafił do aresztu, grozi mu do 10 lat pozbawienia wolności.  </p><br clear="all" />

## Agent Putina zdemaskowany. To syn byłego rosyjskiego szpiega
 - [https://wydarzenia.interia.pl/zagranica/news-agent-putina-zdemaskowany-to-syn-bylego-rosyjskiego-szpiega,nId,6482446](https://wydarzenia.interia.pl/zagranica/news-agent-putina-zdemaskowany-to-syn-bylego-rosyjskiego-szpiega,nId,6482446)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 11:49:57+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-agent-putina-zdemaskowany-to-syn-bylego-rosyjskiego-szpiega,nId,6482446"><img align="left" alt="Agent Putina zdemaskowany. To syn byłego rosyjskiego szpiega" src="https://i.iplsc.com/agent-putina-zdemaskowany-to-syn-bylego-rosyjskiego-szpiega/000GIDEW2YOLUKAN-C321.jpg" /></a>Syn byłego rosyjskiego dyplomaty i szpiega został zdemaskowany przez austriacki kontrwywiad. To 39-letni obywatel Grecji rosyjskiego pochodzenia, który pracował dla rosyjskiego wywiadu GRU. Część zebranych informacji miała związek z działaniami Rosji na Ukrainie, a mężczyzna miał zarobić miliony - informuje portal dziennika &quot;Kronen Zeitung&quot;.</p><br clear="all" />

## Kadyrow szuka wsparcia na świecie. Wezwał na pomoc muzułmanów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kadyrow-szuka-wsparcia-na-swiecie-wezwal-na-pomoc-muzulmanow,nId,6482461](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kadyrow-szuka-wsparcia-na-swiecie-wezwal-na-pomoc-muzulmanow,nId,6482461)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 11:49:40+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kadyrow-szuka-wsparcia-na-swiecie-wezwal-na-pomoc-muzulmanow,nId,6482461"><img align="left" alt="Kadyrow szuka wsparcia na świecie. Wezwał na pomoc muzułmanów" src="https://i.iplsc.com/kadyrow-szuka-wsparcia-na-swiecie-wezwal-na-pomoc-muzulmanow/000GIDJ8RWBVIWY6-C321.jpg" /></a>Przywódca Czeczenii Ramzan Kadyrow opublikował na Telegramie nowy apel. Odezwa skierowana jest do muzułmanów, a napisana w języku chińskim. &quot;Wzywam cały islamski świat do zjednoczenia się przeciwko naszemu wspólnemu wrogowi&quot; - pisze. A mówi o USA i Europie.</p><br clear="all" />

## "Diler gwiazd" winny. Sąd Okręgowy odrzucił apelację
 - [https://wydarzenia.interia.pl/kraj/news-diler-gwiazd-winny-sad-okregowy-odrzucil-apelacje,nId,6482457](https://wydarzenia.interia.pl/kraj/news-diler-gwiazd-winny-sad-okregowy-odrzucil-apelacje,nId,6482457)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 11:45:14+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-diler-gwiazd-winny-sad-okregowy-odrzucil-apelacje,nId,6482457"><img align="left" alt="&quot;Diler gwiazd&quot; winny. Sąd Okręgowy odrzucił apelację" src="https://i.iplsc.com/diler-gwiazd-winny-sad-okregowy-odrzucil-apelacje/000GIDI3GUX756EI-C321.jpg" /></a>Sąd Okręgowy Warszawa-Praga utrzymał w poniedziałek w mocy wyrok sądu pierwszej instancji w procesie odwoławczym Cezarego P., zwanego dilerem gwiazd. Oskarżony został skazany na sześć lat więzienia.</p><br clear="all" />

## Holandia: Ludzie zjeżdżali ze wzniesień, ponad 500 wypadków. Są nagrania
 - [https://wydarzenia.interia.pl/zagranica/news-holandia-ludzie-zjezdzali-ze-wzniesien-ponad-500-wypadkow-sa,nId,6482416](https://wydarzenia.interia.pl/zagranica/news-holandia-ludzie-zjezdzali-ze-wzniesien-ponad-500-wypadkow-sa,nId,6482416)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 11:18:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-holandia-ludzie-zjezdzali-ze-wzniesien-ponad-500-wypadkow-sa,nId,6482416"><img align="left" alt="Holandia: Ludzie zjeżdżali ze wzniesień, ponad 500 wypadków. Są nagrania" src="https://i.iplsc.com/holandia-ludzie-zjezdzali-ze-wzniesien-ponad-500-wypadkow-sa/000GIDE5Q0S2SV3P-C321.jpg" /></a>Zima daje się we znaki również w Holandii. Z powodu gołoledzi w nocy z niedzieli na poniedziałek w Niderlandach doszło do przeszło 500 wypadków drogowych - informuje zarządzająca drogami agencja Rijkswaterstaat (RWS). 26-letnia kobieta zginęła na miejscu w wypadku, do którego doszło w Nijverdal na północy kraju.</p><br clear="all" />

## Ołeksij Daniłow przewiduje "błyskawiczną zmianę" w Czeczenii po śmierci Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-oleksij-danilow-przewiduje-blyskawiczna-zmiane-w-czeczenii-p,nId,6482357](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-oleksij-danilow-przewiduje-blyskawiczna-zmiane-w-czeczenii-p,nId,6482357)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 10:37:17+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-oleksij-danilow-przewiduje-blyskawiczna-zmiane-w-czeczenii-p,nId,6482357"><img align="left" alt="Ołeksij Daniłow przewiduje &quot;błyskawiczną zmianę&quot; w Czeczenii po śmierci Putina" src="https://i.iplsc.com/oleksij-danilow-przewiduje-blyskawiczna-zmiane-w-czeczenii-p/000GICTQ9Q1VFESQ-C321.jpg" /></a>Gdy tylko zabraknie Władimira Putina, Czeczenia bardzo szybko odłączy się od Rosji i zostanie niezależnym państwem - ocenił sekretarz Rady Bezpieczeństwa Narodowego i Obrony (RBNiO) Ukrainy Ołeksij Daniłow. Jak dodał, Putin boi się przywódcy Czeczenii, Ramzana Kayrowa. - Ten człowiek może mu bowiem przysporzyć ogromnych problemów - uważa Daniłow. </p><br clear="all" />

## Awarie wozów bojowych Puma. Niemiecka prasa: "Kompromitacja", "totalna porażka"
 - [https://wydarzenia.interia.pl/zagranica/news-awarie-wozow-bojowych-puma-niemiecka-prasa-kompromitacja-tot,nId,6482370](https://wydarzenia.interia.pl/zagranica/news-awarie-wozow-bojowych-puma-niemiecka-prasa-kompromitacja-tot,nId,6482370)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 10:24:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-awarie-wozow-bojowych-puma-niemiecka-prasa-kompromitacja-tot,nId,6482370"><img align="left" alt="Awarie wozów bojowych Puma. Niemiecka prasa: &quot;Kompromitacja&quot;, &quot;totalna porażka&quot;" src="https://i.iplsc.com/awarie-wozow-bojowych-puma-niemiecka-prasa-kompromitacja-tot/000GICVIO2BD0UAW-C321.jpg" /></a>Na światło dzienne wyszły awarie 18 wozów bojowych piechoty Puma. Niemiecka prasa w mocnych słowach ocenia tę sytuację. &quot;Kompromitacja&quot;, &quot;porażka&quot;, &quot;śmiech grzęźnie w gardle&quot; - piszą zachodnie media. </p><br clear="all" />

## Przemysław Czarnek: Prześladowanie chrześcijan po wygranej opozycji
 - [https://wydarzenia.interia.pl/kraj/news-przemyslaw-czarnek-przesladowanie-chrzescijan-po-wygranej-op,nId,6482382](https://wydarzenia.interia.pl/kraj/news-przemyslaw-czarnek-przesladowanie-chrzescijan-po-wygranej-op,nId,6482382)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 10:24:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-przemyslaw-czarnek-przesladowanie-chrzescijan-po-wygranej-op,nId,6482382"><img align="left" alt="Przemysław Czarnek: Prześladowanie chrześcijan po wygranej opozycji" src="https://i.iplsc.com/przemyslaw-czarnek-przesladowanie-chrzescijan-po-wygranej-op/000FZI881GA4O3DN-C321.jpg" /></a>- Zwycięstwo opozycji w przyszłorocznych wyborach będzie oznaczało prześladowanie chrześcijan na dużą skalę - uważa minister edukacji i nauki Przemysław Czarnek. Zdaniem ministra &quot;lewactwo europejskie może wynarodowić narody europejskie, w tym Polskę, tylko wówczas, kiedy odetnie ich od korzeni chrześcijańskich&quot;. - De facto opozycja, walcząc z Kościołem, walczy z narodem polskim, walczy z polskością, bo nie ma polskości bez chrześcijaństwa - twierdzi Czarnek. </p><br clear="all" />

## Śmierć miliarderów i zagadkowa postać w okolicy. Syn ofiar ogłosił nagrodę
 - [https://wydarzenia.interia.pl/zagranica/news-smierc-miliarderow-i-zagadkowa-postac-w-okolicy-syn-ofiar-og,nId,6482385](https://wydarzenia.interia.pl/zagranica/news-smierc-miliarderow-i-zagadkowa-postac-w-okolicy-syn-ofiar-og,nId,6482385)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 10:14:04+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-smierc-miliarderow-i-zagadkowa-postac-w-okolicy-syn-ofiar-og,nId,6482385"><img align="left" alt="Śmierć miliarderów i zagadkowa postać w okolicy. Syn ofiar ogłosił nagrodę" src="https://i.iplsc.com/smierc-miliarderow-i-zagadkowa-postac-w-okolicy-syn-ofiar-og/000GID2M1IHW62QN-C321.jpg" /></a>Pięć lat i żadnych wyników śledztwa. Śmierć kanadyjskich miliarderów Barry’ego i Honey Shermanów pozostaje zagadką. W sprawie nie udało się odpowiedzieć nie tylko na pytanie, jak doszło do morderstwa pary, ale i kim jest osoba, którą uwieczniono na tajemniczym nagraniu. Teraz syn małżeństwa obiecał 35 mln dolarów dla osoby, która pomoże w rozwiązaniu zagadki.</p><br clear="all" />

## Solidarna Polska kontra Polskie Radio. Ziobryści zarzucają "antypaństwowe praktyki"
 - [https://wydarzenia.interia.pl/kraj/news-solidarna-polska-kontra-polskie-radio-ziobrysci-zarzucaja-an,nId,6482339](https://wydarzenia.interia.pl/kraj/news-solidarna-polska-kontra-polskie-radio-ziobrysci-zarzucaja-an,nId,6482339)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 10:03:03+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-solidarna-polska-kontra-polskie-radio-ziobrysci-zarzucaja-an,nId,6482339"><img align="left" alt="Solidarna Polska kontra Polskie Radio. Ziobryści zarzucają &quot;antypaństwowe praktyki&quot;" src="https://i.iplsc.com/solidarna-polska-kontra-polskie-radio-ziobrysci-zarzucaja-an/000GICSFB2CKWR8Q-C321.jpg" /></a>Polityka zamkniętych drzwi, brak pluralizmu, niebezpieczne i antypaństwowe praktyki - to lista zarzutów, które Jacek Ozdoba, rzecznik prasowy Solidarnej Polski stawia kierownictwu Polskiego Radia. Ziobrysta zwrócił się ze swoją skargą bezpośrednio do Macieja Świrskiego, przewodniczącego Krajowej Rady Radiofonii i Telewizji. Domaga się &quot;podjęcia kroków prawnych&quot;.</p><br clear="all" />

## Zastępca burmistrza Cieszyna znieważył premiera. Sąd wydał wyrok
 - [https://wydarzenia.interia.pl/kraj/news-zastepca-burmistrza-cieszyna-zniewazyl-premiera-sad-wydal-wy,nId,6482366](https://wydarzenia.interia.pl/kraj/news-zastepca-burmistrza-cieszyna-zniewazyl-premiera-sad-wydal-wy,nId,6482366)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 10:01:07+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zastepca-burmistrza-cieszyna-zniewazyl-premiera-sad-wydal-wy,nId,6482366"><img align="left" alt="Zastępca burmistrza Cieszyna znieważył premiera. Sąd wydał wyrok" src="https://i.iplsc.com/zastepca-burmistrza-cieszyna-zniewazyl-premiera-sad-wydal-wy/000GICWEC13FW8GM-C321.jpg" /></a>Cieszyński sąd rejonowy uznał, że drugi zastępca burmistrza Cieszyna Przemysław Major, znieważył publicznie premiera Mateusza Morawieckiego i pomówił instytucje państwowe, w tym Straż Graniczną, MON i MSWiA.</p><br clear="all" />

## Zachodniopomorskie: Na widok policji nagle zmienił kierunek jazdy. 40-latek zatrzymany
 - [https://wydarzenia.interia.pl/kraj/news-zachodniopomorskie-na-widok-policji-nagle-zmienil-kierunek-j,nId,6482341](https://wydarzenia.interia.pl/kraj/news-zachodniopomorskie-na-widok-policji-nagle-zmienil-kierunek-j,nId,6482341)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 09:44:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zachodniopomorskie-na-widok-policji-nagle-zmienil-kierunek-j,nId,6482341"><img align="left" alt="Zachodniopomorskie: Na widok policji nagle zmienił kierunek jazdy. 40-latek zatrzymany" src="https://i.iplsc.com/zachodniopomorskie-na-widok-policji-nagle-zmienil-kierunek-j/000GICV22OABQRLQ-C321.jpg" /></a>W Morzyczynie w województwie zachodniopomorskim podczas nocnego patrolu kierowca Fiata na widok funkcjonariuszy niespodziewanie zmienił kierunek jazdy. Jak się okazało, 40-letni kierowca prowadził auto pod wpływem narkotyków - przekazała mł. asp. Justyna Siwarska z Komendy Powiatowej Policji w Stargardzie.</p><br clear="all" />

## Janusz Kowalski: Prawdziwa informacja na temat KPO jest ukrywana
 - [https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-prawdziwa-informacja-na-temat-kpo-jest-ukryw,nId,6482326](https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-prawdziwa-informacja-na-temat-kpo-jest-ukryw,nId,6482326)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 09:37:03+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-prawdziwa-informacja-na-temat-kpo-jest-ukryw,nId,6482326"><img align="left" alt="Janusz Kowalski: Prawdziwa informacja na temat KPO jest ukrywana" src="https://i.iplsc.com/janusz-kowalski-prawdziwa-informacja-na-temat-kpo-jest-ukryw/000GICRZ28Y5TO12-C321.jpg" /></a>- Solidarna Polska nie chce pożyczać 112 miliardów zł, za które musimy zapłacić co najmniej 300-500 miliardów zł do 2058 roku - mówi o KPO wiceminister rolnictwa i rozwoju wsi. Janusz Kowalski przekonuje też w rozmowie z Interią, że aktualny minister sprawiedliwości byłby znakomitym premierem oraz że to on powinien odpowiadać za relacje z UE. Przy okazji Kowalski przed świętami znalazł kilka ciepłych słów dla opozycji. - Kiedy przedstawiłem agendę swoich działań dotyczących inwestycji OZE na obszarach wiejskich oraz plan zmiany przepisów...</p><br clear="all" />

## Kolejna ankieta Elona Muska na Twitterze. Pyta, czy powinien rządzić platformą
 - [https://wydarzenia.interia.pl/zagranica/news-kolejna-ankieta-elona-muska-na-twitterze-pyta-czy-powinien-r,nId,6482322](https://wydarzenia.interia.pl/zagranica/news-kolejna-ankieta-elona-muska-na-twitterze-pyta-czy-powinien-r,nId,6482322)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 09:14:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kolejna-ankieta-elona-muska-na-twitterze-pyta-czy-powinien-r,nId,6482322"><img align="left" alt="Kolejna ankieta Elona Muska na Twitterze. Pyta, czy powinien rządzić platformą" src="https://i.iplsc.com/kolejna-ankieta-elona-muska-na-twitterze-pyta-czy-powinien-r/0007HNZRDQO977EI-C321.jpg" /></a>Elon Musk ogłosił ankietę, w której użytkownicy Twittera mogą wypowiedzieć się, czy chcą by dalej kierował platformą czy nie. Jak dodał, zastosuje się do wyników. To nie pierwsza ankieta, którą przeprowadził nowy właściciel Twittera. Wcześniej pytał użytkowników o przywrócenie kont dziennikarzy, których zablokował oraz byłego prezydenta USA Donalda Trumpa.</p><br clear="all" />

## Grupa Orlen wspiera sportowców. "Sponsoring to ważny element"
 - [https://wydarzenia.interia.pl/kraj/news-grupa-orlen-wspiera-sportowcow-sponsoring-to-wazny-element,nId,6482312](https://wydarzenia.interia.pl/kraj/news-grupa-orlen-wspiera-sportowcow-sponsoring-to-wazny-element,nId,6482312)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 09:01:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-grupa-orlen-wspiera-sportowcow-sponsoring-to-wazny-element,nId,6482312"><img align="left" alt="Grupa Orlen wspiera sportowców. &quot;Sponsoring to ważny element&quot;" src="https://i.iplsc.com/grupa-orlen-wspiera-sportowcow-sponsoring-to-wazny-element/000F6L7VUOSYGCF2-C321.jpg" /></a>Ponad 90 indywidualnych zawodników, 70 klubów sportowych, 11 związków, dwa komitety i wzrost nakładów finansowych w porównaniu z 2015 r. o 180 proc. - takie liczby podaje PKN Orlen, informując o poziomie zaangażowania grupy w sponsoring.</p><br clear="all" />

## Ponad 500 tys. ton zboża skradzionego z Ukrainy trafiło do jednego kraju
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ponad-500-tys-ton-zboza-skradzionego-z-ukrainy-trafilo-do-je,nId,6482271](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ponad-500-tys-ton-zboza-skradzionego-z-ukrainy-trafilo-do-je,nId,6482271)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 08:59:03+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ponad-500-tys-ton-zboza-skradzionego-z-ukrainy-trafilo-do-je,nId,6482271"><img align="left" alt="Ponad 500 tys. ton zboża skradzionego z Ukrainy trafiło do jednego kraju" src="https://i.iplsc.com/ponad-500-tys-ton-zboza-skradzionego-z-ukrainy-trafilo-do-je/000GIC7DI6EH7LGG-C321.jpg" /></a>Syria importowała ponad 500 tys. ton pszenicy z Sewastopola - przekazała w poniedziałek agencja Reurtera. Do przewozu skradzionego zboża z Ukrainy wykorzystywane są m.in. syryjskie statki, objęte zagranicznymi sankcjami. Jeszcze w styczniu, minister gospodarki Syrii przekazywał, że większość zboża, które w 2022 roku trafi do jego kraju, zostanie sprowadzone z Rosji.  </p><br clear="all" />

## "Trenuj z wojskiem". Błaszczak: Przeszkolić jak najwięcej osób
 - [https://wydarzenia.interia.pl/kraj/news-trenuj-z-wojskiem-blaszczak-przeszkolic-jak-najwiecej-osob,nId,6482282](https://wydarzenia.interia.pl/kraj/news-trenuj-z-wojskiem-blaszczak-przeszkolic-jak-najwiecej-osob,nId,6482282)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 08:42:44+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-trenuj-z-wojskiem-blaszczak-przeszkolic-jak-najwiecej-osob,nId,6482282"><img align="left" alt="&quot;Trenuj z wojskiem&quot;. Błaszczak: Przeszkolić jak najwięcej osób" src="https://i.iplsc.com/trenuj-z-wojskiem-blaszczak-przeszkolic-jak-najwiecej-osob/000GIC89C6TP125M-C321.jpg" /></a>- Chcemy przeszkolić jak najwięcej osób w zakresie podstawowych umiejętności - mówił wicepremier, szef MON Mariusz Błaszczak podczas inauguracji drugiej edycji projektu &quot;Trenuj z wojskiem w ferie&quot;. Jak zaznaczył Błaszczak, szkolenia będą bezpłatne i będą trwały osiem godzin w soboty. Szef MON podał również, kto będzie mógł wziąć w nich udział.</p><br clear="all" />

## Śnieg utrzyma się do świąt? Synoptycy pokazali mapę
 - [https://wydarzenia.interia.pl/kraj/news-snieg-utrzyma-sie-do-swiat-synoptycy-pokazali-mape,nId,6482288](https://wydarzenia.interia.pl/kraj/news-snieg-utrzyma-sie-do-swiat-synoptycy-pokazali-mape,nId,6482288)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 08:42:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-snieg-utrzyma-sie-do-swiat-synoptycy-pokazali-mape,nId,6482288"><img align="left" alt="Śnieg utrzyma się do świąt? Synoptycy pokazali mapę" src="https://i.iplsc.com/snieg-utrzyma-sie-do-swiat-synoptycy-pokazali-mape/000GICLEY4NWONBK-C321.jpg" /></a>Centrum Modelowania Meteorologicznego IMGW pokazało animację, która jest jednoznaczną odpowiedzią na pytanie o białe święta. Nadchodząca do Polski odwilż spowoduje, że śnieg zniknie z wielu regionów, jednak są miejsca, gdzie utrzyma się on do 26 grudnia. To głównie południowe i wschodnie krańce naszego kraju. </p><br clear="all" />

## Putin spotka się z Łukaszenką. O czym mogą rozmawiać?
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-spotka-sie-z-lukaszenka-o-czym-moga-rozmawiac,nId,6482258](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-spotka-sie-z-lukaszenka-o-czym-moga-rozmawiac,nId,6482258)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 08:20:01+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-spotka-sie-z-lukaszenka-o-czym-moga-rozmawiac,nId,6482258"><img align="left" alt="Putin spotka się z Łukaszenką. O czym mogą rozmawiać?" src="https://i.iplsc.com/putin-spotka-sie-z-lukaszenka-o-czym-moga-rozmawiac/000G7PUB26RBCOHD-C321.jpg" /></a>Władimir Putin ma spotkać się w Mińsku z Alaksandrem Łukaszenką, a jak ocenił ukraiński generał, rozmowa może dotyczyć &quot;zwiększenia zaangażowania sił białoruskich w ramach wojny&quot;. Jednak jak zaznacza amerykański Instytut Badań nad Wojną (ISW) zdolność rosyjskiej armii, nawet wzmocnionej przez elementy sił białoruskich, do przygotowania i przeprowadzenia w najbliższych miesiącach na Ukrainie skutecznej ofensywy z użyciem sił zmechanizowanych jest wątpliwa. </p><br clear="all" />

## Chór Ratyzbońskie Słowiki przyjął dziewczyny. "Dzieje się historia"
 - [https://wydarzenia.interia.pl/zagranica/news-chor-ratyzbonskie-slowiki-przyjal-dziewczyny-dzieje-sie-hist,nId,6482239](https://wydarzenia.interia.pl/zagranica/news-chor-ratyzbonskie-slowiki-przyjal-dziewczyny-dzieje-sie-hist,nId,6482239)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 08:16:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chor-ratyzbonskie-slowiki-przyjal-dziewczyny-dzieje-sie-hist,nId,6482239"><img align="left" alt="Chór Ratyzbońskie Słowiki przyjął dziewczyny. &quot;Dzieje się historia&quot;" src="https://i.iplsc.com/chor-ratyzbonskie-slowiki-przyjal-dziewczyny-dzieje-sie-hist/000GIBSWQLPT2TV1-C321.jpg" /></a>Ratyzbońskie Słowiki mają po raz pierwszy od tysiąca lat chór dziewczęcy, który właśnie zadebiutował. We wrześniu szkoła zerwała z tysiącletnią tradycją i otworzyła swoje podwoje dla dziewcząt, tworząc osobny chór.</p><br clear="all" />

## Tajlandia: 31 osób zginęło w katastrofie okrętu. Opublikowano nagrania
 - [https://wydarzenia.interia.pl/zagranica/news-tajlandia-31-osob-zginelo-w-katastrofie-okretu-opublikowano-,nId,6482259](https://wydarzenia.interia.pl/zagranica/news-tajlandia-31-osob-zginelo-w-katastrofie-okretu-opublikowano-,nId,6482259)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 08:04:42+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tajlandia-31-osob-zginelo-w-katastrofie-okretu-opublikowano-,nId,6482259"><img align="left" alt="Tajlandia: 31 osób zginęło w katastrofie okrętu. Opublikowano nagrania" src="https://i.iplsc.com/tajlandia-31-osob-zginelo-w-katastrofie-okretu-opublikowano/000GIC36AYXR5FN2-C321.jpg" /></a>Co najmniej 31 tajlandzkich marynarzy zginęło wskutek zatonięcia okrętu przy zachodnim wybrzeżu Tajlandii - poinformował rzecznik marynarki wojennej tego kraju. Przedstawiciel armii przekazał, że w historii sił zbrojnych Tajlandii nigdy nie doszło do takiej tragedii na morzu. W mediach społecznościowych pojawiły się nagrania, pokazujący skalę katastrofy.</p><br clear="all" />

## Lubelskie: Zakaz wstępu do lasu. Powodem okiść i szadź
 - [https://wydarzenia.interia.pl/lubelskie/news-lubelskie-zakaz-wstepu-do-lasu-powodem-okisc-i-szadz,nId,6482266](https://wydarzenia.interia.pl/lubelskie/news-lubelskie-zakaz-wstepu-do-lasu-powodem-okisc-i-szadz,nId,6482266)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 07:59:16+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-lubelskie-zakaz-wstepu-do-lasu-powodem-okisc-i-szadz,nId,6482266"><img align="left" alt="Lubelskie: Zakaz wstępu do lasu. Powodem okiść i szadź" src="https://i.iplsc.com/lubelskie-zakaz-wstepu-do-lasu-powodem-okisc-i-szadz/000GIC4FQLS8R7Q2-C321.jpg" /></a>Nadleśnictwo Lubartów (województwo lubelskie) zakazało okresowego wstępu do lasów. Jak przekazano w komunikacie, powodem zakazu są zjawiska wywołane pogodą - szadź i okiść.</p><br clear="all" />

## Morawski: Polacy powinni bardziej odczuć skutki kryzysu energetycznego
 - [https://wydarzenia.interia.pl/raporty/raport-kryzys-energetyczny/aktualnosci/news-morawski-polacy-powinni-bardziej-odczuc-skutki-kryzysu-energ,nId,6477344](https://wydarzenia.interia.pl/raporty/raport-kryzys-energetyczny/aktualnosci/news-morawski-polacy-powinni-bardziej-odczuc-skutki-kryzysu-energ,nId,6477344)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 07:49:36+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-kryzys-energetyczny/aktualnosci/news-morawski-polacy-powinni-bardziej-odczuc-skutki-kryzysu-energ,nId,6477344"><img align="left" alt="Morawski: Polacy powinni bardziej odczuć skutki kryzysu energetycznego" src="https://i.iplsc.com/morawski-polacy-powinni-bardziej-odczuc-skutki-kryzysu-energ/000GHZGY24CEXL4R-C321.jpg" /></a>- Ten kryzys przychodzi do nas zewnątrz i nie jesteśmy w stanie się przed nim w 100 proc. ochronić. Jeśli ochronimy przed nim jedną część gospodarki, to przeniesie się do innej części - mówi w rozmowie z Interią Ignacy Morawski. - Inflacja jest problemem, który z politycznego punktu widzenia jest niemożliwy do rozwiązania w krótkim czasie. Trzeba by nadepnąć na hamulec tak mocno, że żaden polityk tego teraz nie zrobi - dodaje główny ekonomista &quot;Pulsu Biznesu&quot; i dyrektor centrum analiz SpotData. Jego zdaniem zamrażanie cen energii na dłuższą...</p><br clear="all" />

## Prognoza pogody: Gołoledź i zamiecie śnieżne. Od zachodu potężny wyż
 - [https://wydarzenia.interia.pl/kraj/news-prognoza-pogody-gololedz-i-zamiecie-sniezne-od-zachodu-potez,nId,6482235](https://wydarzenia.interia.pl/kraj/news-prognoza-pogody-gololedz-i-zamiecie-sniezne-od-zachodu-potez,nId,6482235)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 07:21:15+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prognoza-pogody-gololedz-i-zamiecie-sniezne-od-zachodu-potez,nId,6482235"><img align="left" alt="Prognoza pogody: Gołoledź i zamiecie śnieżne. Od zachodu potężny wyż" src="https://i.iplsc.com/prognoza-pogody-gololedz-i-zamiecie-sniezne-od-zachodu-potez/000E2RAQVQ0T6B5Q-C321.jpg" /></a>Gołoledź i zamiecie śnieżne - takie warunki pogodowe czekają mieszkańców zachodniej części kraju. Instytut Meteorologii i Gospodarki Wodnej (IMGW) wydał kolejną serię pogodowych ostrzeżeń. Na wschodzie w poniedziałek utrzyma się dotychczasowa zimowa i mroźna aura. Od zachodu do kraju wchodzi potężny i rozległy niż z ciepłym frontem i wilgotnym powietrzem polarno-morskim.</p><br clear="all" />

## Angela Merkel w podcaście o morderstwach. "Na nowo uzyskałam wolność"
 - [https://wydarzenia.interia.pl/zagranica/news-angela-merkel-w-podcascie-o-morderstwach-na-nowo-uzyskalam-w,nId,6482242](https://wydarzenia.interia.pl/zagranica/news-angela-merkel-w-podcascie-o-morderstwach-na-nowo-uzyskalam-w,nId,6482242)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 07:16:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-angela-merkel-w-podcascie-o-morderstwach-na-nowo-uzyskalam-w,nId,6482242"><img align="left" alt="Angela Merkel w podcaście o morderstwach. &quot;Na nowo uzyskałam wolność&quot;" src="https://i.iplsc.com/angela-merkel-w-podcascie-o-morderstwach-na-nowo-uzyskalam-w/0007917G38WY2DQK-C321.jpg" /></a>Była kanclerz Niemiec Angela Merkel wzięła udział w podcaście o morderstwach. Jak stwierdziła emerytowana szefowa rządu, &quot;na nowo uzyskana wolność&quot; pozwala jej obecnie &quot;pójść czasem w całkiem innym kierunku&quot;. Podczas rozmowy Merkel porównywała politykę z operą autorstwa Richarda Wagnera, którego twórczości jest znaną wielbicielką.</p><br clear="all" />

## Ukraińskie dzieci piszą listy do św. Mikołaja. "Każdy wygląda tak samo"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainskie-dzieci-pisza-listy-do-sw-mikolaja-kazdy-wyglada-t,nId,6482241](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainskie-dzieci-pisza-listy-do-sw-mikolaja-kazdy-wyglada-t,nId,6482241)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 07:05:25+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainskie-dzieci-pisza-listy-do-sw-mikolaja-kazdy-wyglada-t,nId,6482241"><img align="left" alt="Ukraińskie dzieci piszą listy do św. Mikołaja. &quot;Każdy wygląda tak samo&quot;" src="https://i.iplsc.com/ukrainskie-dzieci-pisza-listy-do-sw-mikolaja-kazdy-wyglada-t/000GIBR73JIY9HMN-C321.jpg" /></a>Zgodnie z kalendarzem juliańskim w poniedziałek w Ukrainie obchodzony jest dzień św. Mikołaja. W związku ze świętem ukraińskie dzieci ślą do Świętego listy. - U prawie każdego dziecka pierwszy punkt listu wygląda tak samo - mówi jedna z mam. A co z konkurencją Mikołaja, rosyjskim Dziadkiem Mrozem? - W tym roku jest tylko św. Mikołaj - mówi inna mama.</p><br clear="all" />

## Uczą się na potęgę, do matury mogą nie zdążyć. "Nie zmienia się zasad w ciągu gry"
 - [https://wydarzenia.interia.pl/kraj/news-ucza-sie-na-potege-do-matury-moga-nie-zdazyc-nie-zmienia-sie,nId,6477293](https://wydarzenia.interia.pl/kraj/news-ucza-sie-na-potege-do-matury-moga-nie-zdazyc-nie-zmienia-sie,nId,6477293)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 06:26:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ucza-sie-na-potege-do-matury-moga-nie-zdazyc-nie-zmienia-sie,nId,6477293"><img align="left" alt="Uczą się na potęgę, do matury mogą nie zdążyć. &quot;Nie zmienia się zasad w ciągu gry&quot;" src="https://i.iplsc.com/ucza-sie-na-potege-do-matury-moga-nie-zdazyc-nie-zmienia-sie/000GHY7EBAK1DT1P-C321.jpg" /></a>Córka Anny chciałaby pójść na studia psychologiczne, ewentualnie kryminologię. Marzy jej się praca w charakterze policyjnego psychologa. Czy to się uda? W dużej mierze zależy to od tego, jak napisze maturę. Egzamin w nowej formie będzie trudniejszy. - Przez łzy mówi, że nie daje rady, że przerasta ją to wszystko. Jest pod opieką psychiatry. Nie widzi już swojej przyszłości tak, jak parę lat temu - mówi Anna. W jej odczuciu przyszłoroczni maturzyści to rocznik poszkodowany, który został potraktowany niesprawiedliwie. Inna mama maturzysty...</p><br clear="all" />

## Wojna. Drony ponownie zaatakowały Kijów. Trudna noc
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-drony-ponownie-zaatakowaly-kijow-trudna-noc,nId,6482213](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-drony-ponownie-zaatakowaly-kijow-trudna-noc,nId,6482213)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 05:57:08+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-drony-ponownie-zaatakowaly-kijow-trudna-noc,nId,6482213"><img align="left" alt="Wojna. Drony ponownie zaatakowały Kijów. Trudna noc " src="https://i.iplsc.com/wojna-drony-ponownie-zaatakowaly-kijow-trudna-noc/000GIBOYKL9GJC3H-C321.jpg" /></a>Rosyjskie drony irańskiej produkcji ponownie zaatakowały Kijów i jego okolice - przekazały lokalne władze obwodowe. W stolicy kraju rozległ się alarm przeciwlotniczy, zaś obrona powietrzna zestrzeliła kilkanaście maszyn. Podano pierwsze informacje o rannych</p><br clear="all" />

## USA: Kilkanaście osób ciężko rannych wskutek silnych turbulencji
 - [https://wydarzenia.interia.pl/zagranica/news-usa-kilkanascie-osob-ciezko-rannych-wskutek-silnych-turbulen,nId,6482208](https://wydarzenia.interia.pl/zagranica/news-usa-kilkanascie-osob-ciezko-rannych-wskutek-silnych-turbulen,nId,6482208)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 05:28:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-kilkanascie-osob-ciezko-rannych-wskutek-silnych-turbulen,nId,6482208"><img align="left" alt="USA: Kilkanaście osób ciężko rannych wskutek silnych turbulencji" src="https://i.iplsc.com/usa-kilkanascie-osob-ciezko-rannych-wskutek-silnych-turbulen/000GIBMK48WUKARY-C321.jpg" /></a>11 osób zostało ciężko rannych po tym, jak samolot lecący z Phoenix w Arizonie do Honolulu na Hawajach wpadł w silne turbulencje na krótko przed lądowaniem. Według lokalnych władz pomocy medycznej wymagało 36 pasażerów, z czego 20 z nich przewieziono do szpitala.</p><br clear="all" />

## Interfax: Rosyjscy żołnierze będą ćwiczyć na Białorusi
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-interfax-rosyjscy-zolnierze-beda-cwiczyc-na-bialorusi,nId,6482207](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-interfax-rosyjscy-zolnierze-beda-cwiczyc-na-bialorusi,nId,6482207)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 05:27:32+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-interfax-rosyjscy-zolnierze-beda-cwiczyc-na-bialorusi,nId,6482207"><img align="left" alt="Interfax: Rosyjscy żołnierze będą ćwiczyć na Białorusi" src="https://i.iplsc.com/interfax-rosyjscy-zolnierze-beda-cwiczyc-na-bialorusi/000GIBKXP5LL76B4-C321.jpg" /></a>Rosyjscy żołnierze rozpoczną ćwiczenia taktyczne na poziomie batalionów - poinformowała rosyjska agencja Interfax, powołując się na Ministerstwo Obrony Rosji. Chodzi o rosyjskich bojowników przerzuconych do sąsiedniego kraju w październiku.</p><br clear="all" />

## Wojna w Ukrainie. 299. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190538](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190538)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 04:32:20+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190538"><img align="left" alt="Wojna w Ukrainie. 299. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo/000GIBJPCG9X198C-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 299. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190631](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190631)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 04:32:20+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190631"><img align="left" alt="Wojna w Ukrainie. 299. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo/000GIBJPCG9X198C-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 299. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190731](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190731)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 04:32:20+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190731"><img align="left" alt="Wojna w Ukrainie. 299. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo/000GIBJPCG9X198C-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 299. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190828](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190828)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-19 04:32:20+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo,nzId,3524,akt,190828"><img align="left" alt="Wojna w Ukrainie. 299. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-299-dzien-inwazji-rosji-relacja-na-zywo/000GIBT5V3U1KSB8-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />


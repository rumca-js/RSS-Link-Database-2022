# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Inwestorzy zaniepokojeni recesją. S&P500 w dół czwarty raz z rzędu
 - [https://www.bankier.pl/wiadomosc/Inwestorzy-zaniepokojeni-recesja-8459522.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inwestorzy-zaniepokojeni-recesja-8459522.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 21:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/a6421912c820ee-948-568-185-190-1815-1088.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amerykański rynek akcji powoli zaczyna się oswajać z myślą, że gospodarce USA
nie uda się uniknąć recesji i że Fed podniesie stopy procentowe do poziomów
sprzed Wielkiego Kryzysu Finansowego.</p>

## Ukraińcy zabierają głos ws. prezentu dla generała Szymczyka
 - [https://www.bankier.pl/wiadomosc/Ukraincy-zabieraja-glos-ws-prezentu-dla-generala-Szymczyka-8459516.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraincy-zabieraja-glos-ws-prezentu-dla-generala-Szymczyka-8459516.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 20:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/c/6b9e46dacabd3f-948-568-0-39-1773-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komendant Główny Polskiej Policji Jarosław Szymczyk podczas wizyty na Ukrainie otrzymał symboliczny prezent, związany z oporem narodu ukraińskiego wobec Rosji i nie było intencji, aby mu zaszkodzić - oświadczyła w poniedziałek ukraińska Służba ds. Sytuacji Nadzwyczajnych (DSNS) , którą przytoczył portal Ukrinform.</p>

## Spotkanie Putina i Łukaszenki. Rosja przekazała Białorusi rakiety S-400 i Iskander
 - [https://www.bankier.pl/wiadomosc/Spotkanie-Putina-i-Lukaszenki-Rosja-przekazala-Bialorusi-rakiety-S-400-i-Iskander-8459497.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spotkanie-Putina-i-Lukaszenki-Rosja-przekazala-Bialorusi-rakiety-S-400-i-Iskander-8459497.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 19:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/2c814c6d98a3c1-948-568-9-36-1833-1100.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Białoruś otrzymała od Rosji systemy rakietowe S-400 i Iskander – poinformował Alaksandr Łukaszenka po rozmowach z Władimirem Putinem w Mińsku. Białoruskiego dyktatora przytoczył portal Zierkało.</p>

## Byłej wiceprzewodniczącej PE oskarżonej o korupcję grozi nawet do 15 lat więzienia
 - [https://www.bankier.pl/wiadomosc/Bylej-wiceprzewodniczacej-PE-oskarzonej-o-korupcje-grozi-nawet-do-15-lat-wiezienia-8459439.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bylej-wiceprzewodniczacej-PE-oskarzonej-o-korupcje-grozi-nawet-do-15-lat-wiezienia-8459439.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 17:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/2/44163b37502b6e-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Eva Kaili, grecka eurodeputowana i była wiceprzewodnicząca Parlamentu Europejskiego oskarżona m.in. o korupcję, czeka na wyniki dwóch śledztw, w Belgii i Grecji. W jej kraju grozi jej nawet do 15 lat więzienia – podaje portal Kathimerini.</p>

## Kwalifikacja wojskowa 2023. MON podało, kogo wezwie na komisje lekarskie
 - [https://www.bankier.pl/wiadomosc/Kwalifikacja-wojskowa-2023-MON-podalo-kogo-wezwie-na-komisje-lekarskie-8459414.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kwalifikacja-wojskowa-2023-MON-podalo-kogo-wezwie-na-komisje-lekarskie-8459414.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 16:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/b80e71c304de93-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przyszłoroczna kwalifikacja wojskowa obejmie mężczyzn 19-letnich, mężczyzn w wieku 20-24 lat, którzy nie mają orzeczonej kategorii, oraz kobiety z kwalifikacjami przydatnymi wojsku; kwalifikacja wojskowa w 2023 r. ma się odbywać od kwietnia do końca czerwca – przewiduje projekt rozporządzenia MON.</p>

## Senna sesja na GPW. Kurs XTB na nowym historycznym maksimum
 - [https://www.bankier.pl/wiadomosc/Senna-sesja-na-GPW-Kurs-XTB-na-nowym-historycznym-maksimum-8459404.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Senna-sesja-na-GPW-Kurs-XTB-na-nowym-historycznym-maksimum-8459404.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 16:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/6002bf98f2266b-945-560-25-56-1706-1023.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W czasie poniedziałkowej sesja na GPW indeksy uległy minimalnej zmianie przy bardzo niskich obrotach, które sugerują urlopowy nastrój inwestorów. Niska zmienność nie przeszkodziła jednak wspiąć się kursowi XTB na nowe historyczne maksimum, a koniec mundialu wystraszył część akcjonariuszy STS-u. </p>

## W Portugalii może zabraknąć mięsa. Rozpoczął się strajk inspektorów-weterynarzy
 - [https://www.bankier.pl/wiadomosc/W-Portugalii-moze-zabraknac-miesa-Rozpoczal-sie-strajk-inspektorow-weterynarzy-8459394.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-Portugalii-moze-zabraknac-miesa-Rozpoczal-sie-strajk-inspektorow-weterynarzy-8459394.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 16:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/8/5dd90310d84e50-948-568-0-67-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W poniedziałek w Portugalii rozpoczął się strajk pracowników Generalnej Dyrekcji Żywienia i Weterynarii (DGAV), który może doprowadzić do niedoborów mięsa w sklepach podczas okresu bożonarodzeniowo-noworocznego.</p>

## Kanada chce skonfiskować aktywa objętego sankcjami rosyjskiego oligarchy Romana Abramowicza
 - [https://www.bankier.pl/wiadomosc/Kanada-chce-skonfiskowac-aktywa-objetego-sankcjami-rosyjskiego-oligarchy-Romana-Abramowicza-8459390.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kanada-chce-skonfiskowac-aktywa-objetego-sankcjami-rosyjskiego-oligarchy-Romana-Abramowicza-8459390.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 16:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/e/2a4a6ac8fd6d35-948-568-0-17-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd Kanady poinformował w poniedziałek, że ma zamiar skonfiskować warte 26 mln dolarów kanadyjskich (CAD) aktywa firmy, należącej do objętego sankcjami rosyjskiego oligarchy Romana Abramowicza. Pod koniec lipca weszły w życie przepisy umożliwiające przejmowanie i sprzedaż rosyjskich aktywów w Kanadzie.</p>

## Limit ceny na gaz. Państwa UE doszły do porozumienia
 - [https://www.bankier.pl/wiadomosc/Limit-ceny-na-gaz-Panstwa-UE-doszly-do-porozumienia-8459388.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Limit-ceny-na-gaz-Panstwa-UE-doszly-do-porozumienia-8459388.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 15:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/4/8a285d1426e5a6-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministrowie ds. energii i klimatu krajów Unii Europejskiej uzgodnili w Brukseli górną granicę ceny na gaz - poinformował w poniedziałek na Twitterze rzecznik prezydencji czeskiej w UE. Ma to zaradzić zbyt wysokim cenom energii w UE.</p>

## KE zamierza wyemitować obligacje UE o wartości do 80 mld euro
 - [https://www.bankier.pl/wiadomosc/KE-zamierza-wyemitowac-obligacje-UE-o-wartosci-do-80-mld-euro-8459382.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KE-zamierza-wyemitowac-obligacje-UE-o-wartosci-do-80-mld-euro-8459382.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 15:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/0/4da9c5072edfa6-948-568-0-75-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Europejska ogłosiła w poniedziałek, że zamierza wyemitować długoterminowe obligacje UE o wartości do 80 mld euro w pierwszej połowie 2023 r.</p>

## Morawiecki: Stoimy murem za fuzją Orlenu z Lotosem
 - [https://www.bankier.pl/wiadomosc/Morawiecki-Stoimy-murem-za-fuzja-Orlenu-z-Lotosem-8459379.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Morawiecki-Stoimy-murem-za-fuzja-Orlenu-z-Lotosem-8459379.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 15:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/9/4a0500dee63f0b-937-562-0-0-937-562.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stoimy murem za fuzją Orlenu z Lotosem, która tworzy ogromny podmiot - oświadczył w poniedziałek w Oławie (dolnośląskie) premier Mateusz Morawiecki. Jak dodał, rynek pozytywnie ocenia całą fuzję.</p>

## Premier Holandii: Nie będzie reparacji za udział państwa w niewolnictwie
 - [https://www.bankier.pl/wiadomosc/Premier-Holandii-Nie-bedzie-reparacji-za-udzial-panstwa-w-niewolnictwie-8459374.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-Holandii-Nie-bedzie-reparacji-za-udzial-panstwa-w-niewolnictwie-8459374.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 15:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/6/6cc22ffda259fc-948-568-0-62-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szef rządu Mark Rutte przeprosił w poniedziałek podczas wystąpienia w archiwum narodowym za niewolniczą przeszłość Holandii. Premier nazwał niewolnictwo „zbrodnią przeciwko ludzkości”. Politycy, zarówno koalicji jak i opozycji, mówią o „historycznym momencie”. Premier rozwiał jednocześnie wątpliwości w kwestii ewentualnych żądań odszkodowań, mówiąc, że "Holandia nie wypłaci żadnych reparacji".</p>

## Rosja zaatakuje Mołdawię? "Taki jest plan na początek 2023 roku"
 - [https://www.bankier.pl/wiadomosc/Rosja-zaatakuje-Moldawie-Taki-jest-plan-na-poczatek-2023-roku-8459357.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosja-zaatakuje-Moldawie-Taki-jest-plan-na-poczatek-2023-roku-8459357.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 15:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/8/f29798701089b8-948-568-72-0-1809-1085.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Siły zbrojne Rosji mają plan ataku na Mołdawię, który miałby nastąpić na początku 2023 r. - poinformował w poniedziałek szef Służby Wywiadu i Bezpieczeństwa (SIS) tego kraju Alexandru Musteata.</p>

## Łukaszenka zakazał podnoszenia cen, by zdusić inflację. Nieposłuszny sklepikarz trafił do więzienia
 - [https://www.bankier.pl/wiadomosc/Lukaszenka-zakazal-podnoszenia-cen-by-zdusic-inflacje-Nieposluszny-sklepikarz-trafil-do-wiezienia-8459349.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lukaszenka-zakazal-podnoszenia-cen-by-zdusic-inflacje-Nieposluszny-sklepikarz-trafil-do-wiezienia-8459349.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 15:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/3/e443c3ece2410e-948-568-0-119-3420-2051.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Mohylewie na zachodniej Białorusi zapadł pierwszy wyrok w sprawie podnoszenia cen towarów pomimo obowiązującego zakazu Łukaszenki, który zakazał ich podnoszenia, by "zdusić inflację" - poinformował w poniedziałek niezależny białoruski portal Nasza Niwa.</p>

## Emerytury mundurowe. Deklaracja opozycji ws. przywrócenia świadczenia
 - [https://www.bankier.pl/wiadomosc/Emerytur-mundurowe-Deklaracja-opozycji-ws-przywrocenia-swiadczenia-8459311.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Emerytur-mundurowe-Deklaracja-opozycji-ws-przywrocenia-swiadczenia-8459311.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 14:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/0/baeeae1d3bc0b5-948-568-0-0-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W demokratycznym państwie nie może być odpowiedzialności zbiorowej, system emerytalny nie może być instrumentem wymierzania kary - głosi deklaracja ws. przywrócenia emerytur mundurowych podpisana w poniedziałek przez przedstawicieli prawie wszystkich ugrupowań opozycyjnych.</p>

## Ekonomiści: Wzrost cen energii w 2023 roku przekroczy 30 proc.
 - [https://www.bankier.pl/wiadomosc/Ekonomisci-Wzrost-cen-energii-w-2023-roku-przekroczy-30-proc-8459299.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekonomisci-Wzrost-cen-energii-w-2023-roku-przekroczy-30-proc-8459299.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 14:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/6a354aea207cc0-870-521-130-42-870-521.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przyszły rok przyniesie jedynie niewielki spadek inflacji CPI, a za większą jej część będzie odpowiadać inflacja bazowa - prognozują ekonomiści Polskiego Instytutu Ekonomicznego. W ocenie ekonomistów, inflacja CPI pozostanie powyżej celu NBP przez cały 2024 r.</p>

## Koniec szefowania Muska w Twitterze? Użytkownicy serwisu nie pozostawili mu wyjścia
 - [https://www.bankier.pl/wiadomosc/Koniec-szefowania-Muska-w-Twitterze-Uzytkownicy-serwisu-nie-pozostawili-mu-wyjscia-8459277.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-szefowania-Muska-w-Twitterze-Uzytkownicy-serwisu-nie-pozostawili-mu-wyjscia-8459277.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 14:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/2/c8a5e586853218-948-568-0-97-3892-2335.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Większość użytkowników Twittera, którzy wzięli udział w zorganizowanej przez Elona Muska w tym serwisie sondzie zagłosowała za tym, by zrezygnował z kierowania firmą. Miliarder zapowiedział wcześniej, że postąpi zgodnie z rezultatem głosowania.</p>

## GPW prowadzi zaawansowane prace nad platformą opartą o technologię blockchain
 - [https://www.bankier.pl/wiadomosc/GPW-prowadzi-zaawansowane-prace-nad-platforma-oparta-na-technologii-blockchain-8459256.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/GPW-prowadzi-zaawansowane-prace-nad-platforma-oparta-na-technologii-blockchain-8459256.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 13:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/76933bd4ab210d-948-568-0-0-1697-1018.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Giełda Papierów Wartościowych w Warszawie prowadzi zaawansowane prace nad nowoczesną platformą Private Market opartą na technologii blockchain. „Chętnie podzielimy się naszą technologią z giełdami z regionu Trójmorza” - mówił dr Marek Dietl, prezes zarządu Giełdy Papierów Wartościowych w Warszawie podczas obchodów 140-lecia rumuńskiej giełdy w Bukareszcie.</p>

## Wrogie przejęcie Rafinerii Gdańskiej? Przedstawiciele rządu komentują
 - [https://www.bankier.pl/wiadomosc/Wrogie-przejecie-Rafinerii-Gdanskiej-Przedstawiciele-rzadu-komentuja-8459229.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wrogie-przejecie-Rafinerii-Gdanskiej-Przedstawiciele-rzadu-komentuja-8459229.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 13:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/d/bafeaa7ebd18c7-948-567-0-22-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie ma żadnego ryzyka niekontrolowanego zbycia udziałów w Rafinerii Gdańskiej,  w taki sposób aby to zagroziło polskiemu bezpieczeństwu - oświadczył w poniedziałek na konferencji prasowej rzecznik rządu Piotr Müller.</p>

## Co dalej ze stopami proc. zrobi RPP? Ekonomiści rewidują w dół swoją prognozę
 - [https://www.bankier.pl/wiadomosc/Co-dalej-ze-stopami-proc-zrobi-RPP-Ekonomisci-rewiduja-w-dol-swoja-prognoze-8459219.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Co-dalej-ze-stopami-proc-zrobi-RPP-Ekonomisci-rewiduja-w-dol-swoja-prognoze-8459219.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 13:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/9/286cbd3c897eb3-948-568-0-70-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ekonomiści BNP Paribas rewidują w dół prognozę docelowej stopy referencyjnej NBP i zakładają, że do końca przyszłego roku wynosić ona będzie 6,75 proc. (wcześniej 8 proc.). Eksperci widzą przestrzeń do obniżek stóp dopiero w 2024 r., łącznie o 125 pb. do 5,50 proc. na koniec tego okresu.</p>

## Eksplozja w KGP - będzie dymisja komendanta Szymczyka? Szef MSWiA zabrał głos
 - [https://www.bankier.pl/wiadomosc/Eksplozja-w-KGP-bedzie-dymisja-komendanta-Szymczyka-Szef-MSWiA-zabral-glos-8459210.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Eksplozja-w-KGP-bedzie-dymisja-komendanta-Szymczyka-Szef-MSWiA-zabral-glos-8459210.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 13:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/1/53aed2de2f44c0-948-568-0-60-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ucinając spekulacje medialne, wykluczam dymisję Komendanta Głównego Policji - napisał w poniedziałek na Twitterze szef MSWiA Mariusz Kamiński odnosząc się do niepotwierdzonych informacji o poszukiwaniu przez MSWiA następcy gen. insp. Jarosława Szymczyka.</p>

## Państwo w komórce. Zmiany w aplikacji mObywatel mają być "rewolucją cyfrową"
 - [https://www.bankier.pl/wiadomosc/Panstwo-w-komorce-Zmiany-w-aplikacji-mObywatel-maja-byc-rewolucja-cyfrowa-8459200.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Panstwo-w-komorce-Zmiany-w-aplikacji-mObywatel-maja-byc-rewolucja-cyfrowa-8459200.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 12:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/2/94b27a5ef991db-948-568-412-0-1352-811.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Zakładamy rewolucję w komunikacji na linii 
obywatel-państwo w korzystaniu na co dzień z administracji w naszym 
państwie, czyli zrównujemy dokumenty, które są zawarte w aplikacji 
mObywatel, z dokumentami tradycyjnymi" - powiedział sekretarz stanu w 
KPRM Adam Andruszkiewicz.</p>

## Były minister przemysłu Chin wyrzucony z partii komunistycznej za korupcję
 - [https://www.bankier.pl/wiadomosc/Byly-minister-przemyslu-Chin-wyrzucony-z-partii-komunistycznej-za-korupcje-8459197.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Byly-minister-przemyslu-Chin-wyrzucony-z-partii-komunistycznej-za-korupcje-8459197.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 12:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/0/e69084681e589f-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Były minister przemysłu Chin Xiao Yaqing został zwolniony z pełnienia obowiązków rządowych w związku z zarzutami o korupcję oraz wyrzucony z rządzącej państwem Komunistycznej Partii Chin - poinformowała w poniedziałek chińska instytucja rządowa zajmująca się walką z łapówkarstwem.</p>

## MAP: węgiel dostarczono już do 85 proc. gmin w Polsce
 - [https://www.bankier.pl/wiadomosc/Wegiel-dostarczono-do-85-proc-gmin-Rabenda-MAP-8459175.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wegiel-dostarczono-do-85-proc-gmin-Rabenda-MAP-8459175.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 12:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/6/f946c28b0f4f82-948-568-0-17-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do 85 proc. gmin dostarczono węgiel w ramach programu dystrybucji węgla do samorządów - poinformował wiceminister aktywów państwowych Karol Rabenda.</p>

## Sprzedaż Lotosu. Jest zawiadomienie o możliwości popełnienia przestępstwa
 - [https://www.bankier.pl/wiadomosc/Sprzedaz-Lotosu-Jest-zawiadomienie-o-mozliwosci-popelnienia-przestepstwa-8459176.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sprzedaz-Lotosu-Jest-zawiadomienie-o-mozliwosci-popelnienia-przestepstwa-8459176.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 12:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/0c29e82b510ef4-775-465-30-0-775-465.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska 2050 zawiadamia prokuraturę o możliwości popełnienia przestępstwa przy okazji sprzedaży udziałów w Lotosie firmie Saudi Aramco; chce też, by transakcję zbadała NIK - mówili na poniedziałkowej konferencji Michał Kobosko i poseł Mirosław Suchoń.</p>

## Reuters: Rosja i Chiny przeprowadzą wspólne manewry na morzu
 - [https://www.bankier.pl/wiadomosc/Reuters-Rosja-i-Chiny-przeprowadza-wspolne-manewry-na-morzu-8459167.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Reuters-Rosja-i-Chiny-przeprowadza-wspolne-manewry-na-morzu-8459167.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 12:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/267901bcad747f-948-569-295-105-1566-940.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Siły zbrojne Rosji i Chin wezmą udział we wspólnych manewrach na wodach Morza Wschodniochińskiego, zaplanowanych w dniach 21-27 grudnia; scenariusz ćwiczeń zakłada m.in. przeprowadzenie ostrzałów artyleryjskich i rakietowych - poinformowała w poniedziałek agencja Reutera za resortem obrony w Moskwie.</p>

## Media: Poseł i lider lubuskiej PO dorabia w spółce; złamał przepisy ustawy
 - [https://www.bankier.pl/wiadomosc/Media-Posel-i-lider-lubuskiej-PO-dorabia-w-spolce-zlamal-przepisy-ustawy-8459157.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-Posel-i-lider-lubuskiej-PO-dorabia-w-spolce-zlamal-przepisy-ustawy-8459157.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 12:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/2/d9f83bf957ce39-948-568-0-21-2880-1727.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poseł i lider lubuskiej Platformy Obywatelskiej 
Waldemar Sługocki zasiada w radzie nadzorczej prywatnej spółki Gazstal 
S.A. Nie poinformował o tym Marszałek Sejmu, za co zgodnie z 
obowiązującymi przepisami grozi mu odpowiedzialność regulaminowa - pisze
 "Gazeta Lubuska".</p>

## Lista ostrzeżeń KNF. Są nowe podmioty
 - [https://www.bankier.pl/wiadomosc/Lista-ostrzezen-KNF-Sa-nowe-podmioty-8459141.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lista-ostrzezen-KNF-Sa-nowe-podmioty-8459141.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 11:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/3afcc88d8ad10e-945-560-15-217-2975-1784.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na listę ostrzeżeń publicznych wpisano kolejnych pięć podmiotów Ethereal Group LLC, GCB London, Libellium, Monero Emilia Biegańska oraz Hala Tech - podała w poniedziałek Komisja Nadzoru Finansowego.</p>

## Pierwsze zgony w Chinach na COVID-19 od poluzowania restrykcji
 - [https://www.bankier.pl/wiadomosc/Pierwsze-zgony-w-Chinach-na-COVID-19-od-poluzowania-restrykcji-8459139.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pierwsze-zgony-w-Chinach-na-COVID-19-od-poluzowania-restrykcji-8459139.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 11:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/38f3c079ca2643-948-568-0-70-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Chinach w poniedziałek odnotowano oficjalnie pierwsze od złagodzenia restrykcji zgony powiązane z COVID-19 - poinformowała agencja Reutera. Restrykcje poluzowano 7 grudnia. Media i eksperci zwracają uwagę, że rzeczywistych ofiar epidemii może być więcej.</p>

## Facebook na marketplace naruszył przepisy antymonopolowe? KE bada sprawę
 - [https://www.bankier.pl/wiadomosc/Facebook-na-marketplace-naruszyl-przepisy-antymonopolowe-KE-bada-sprawe-8459136.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Facebook-na-marketplace-naruszyl-przepisy-antymonopolowe-KE-bada-sprawe-8459136.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 11:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/7d0f3017fe3e58-948-568-0-69-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Europejska poinformowała firmę Meta, która jest właścicielem Facebooka, że według wstępnej oceny naruszyła ona unijne przepisy antymonopolowe, zakłócając konkurencję na rynkach ogłoszeń drobnych online. Jeśli zarzuty potwierdzą się w toku dochodzenia, to KE może nałożyć na firmę kary finansowe.</p>

## Szwedzki SN odmówił wydania Turcji przeciwnika politycznego Erdogana
 - [https://www.bankier.pl/wiadomosc/Szwedzki-SN-odmowil-wydania-Turcji-przeciwnika-politycznego-Erdogana-8459114.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szwedzki-SN-odmowil-wydania-Turcji-przeciwnika-politycznego-Erdogana-8459114.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 11:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/ec0a7b57860e32-948-568-0-101-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd Najwyższy Szwecji odmówił w poniedziałek wydania władzom Turcji obywatela tego kraju, dziennikarza, oskarżonego przez administrację tureckiego prezydenta Recepa Tayyipa Erdogana o udział w próbie zamachu stanu w 2016 roku.</p>

## Zastój na rynku zboża. Wysokie ceny nie zachęcają kupujących
 - [https://www.bankier.pl/wiadomosc/Zastoj-na-rynku-zboza-Wysokie-ceny-nie-zachecaja-kupujacych-8459110.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zastoj-na-rynku-zboza-Wysokie-ceny-nie-zachecaja-kupujacych-8459110.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 11:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/55f58ab838612c-948-568-0-62-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na rynku zboża w dalszym ciągu panuje zastój, a wysokie ceny nie zachęcają kupujących - podała Izba Zbożowo-Paszowa w newsletterze.</p>

## Korupcja w PE. "Pieniądze w torbach ze świętym Mikołajem"
 - [https://www.bankier.pl/wiadomosc/Korupcja-w-PE-Pieniadze-w-torbach-ze-swietym-Mikolajem-8459090.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Korupcja-w-PE-Pieniadze-w-torbach-ze-swietym-Mikolajem-8459090.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 10:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/e/eb70ac07f96f39-948-568-0-0-4000-2400.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Były włoski eurodeputowany Antonio Panzeri, aresztowany w Belgii w związku z aferą korupcyjną w Parlamencie Europejskim, przekazywał pieniądze otrzymane z Kataru w torbach z obrazkami Świętego Mikołaja - informuje w poniedziałek włoska prasa, powołując się na ustalenia śledczych z Brukseli.</p>

## Co z emeryturami przed świętami? Prezes ZUS komentuje
 - [https://www.bankier.pl/wiadomosc/Co-z-emeryturami-przed-swietami-Prezes-ZUS-komentuje-8459085.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Co-z-emeryturami-przed-swietami-Prezes-ZUS-komentuje-8459085.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 10:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/3/266f3f146e600c-948-567-0-40-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Emeryci i renciści, którym ZUS wypłaca świadczenia 25. każdego miesiąca, w grudniu otrzymają je przed świętami. Dotyczy to zarówno wypłat przekazywanych przez listonosza, jak i przelewów, które trafiają na rachunki bankowe – poinformowała PAP prezes ZUS prof. Gertruda Uścińska.</p>

## Minister finansów: wiosna powinna przynieść spadek inflacji
 - [https://www.bankier.pl/wiadomosc/Minister-finansow-wiosna-powinna-przyniesc-spadek-inflacji-8459072.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-finansow-wiosna-powinna-przyniesc-spadek-inflacji-8459072.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 10:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/dccc7a1cb4ae4c-948-568-0-0-4096-2457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Początek roku może wiązać się z nieco wyższą inflacją niż w grudniu, ale wiosna, marzec i kolejne wiosenne miesiące, powinny już przynieść spadek inflacji - powiedziała w poniedziałek w Studiu PAP minister finansów Magdalena Rzeczkowska.</p>

## Polacy mają problem ze spłatą długów. Zaległości rosną
 - [https://www.bankier.pl/wiadomosc/Polacy-maja-problem-ze-splata-dlugow-Zaleglosci-rosna-8459068.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-maja-problem-ze-splata-dlugow-Zaleglosci-rosna-8459068.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 09:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/d/d9d4b83b3b31c4-948-568-0-60-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Łączna wartość zaległego zadłużenia konsumentów na koniec października br. wyniosła niemal 77,4 mld zł - wskazują dane zgromadzone w Rejestrze Dłużników BIG InfoMonitor i bazie informacji kredytowych BIK.</p>

## Piwo zaraz po paliwie. Te alkohole kupujemy na stacjach benzynowych
 - [https://www.bankier.pl/wiadomosc/Piwo-zaraz-po-paliwie-Te-alkohole-kupujemy-na-stacjach-benzynowych-8459059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Piwo-zaraz-po-paliwie-Te-alkohole-kupujemy-na-stacjach-benzynowych-8459059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 09:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/4/90f856f5346a6a-948-568-0-79-1986-1191.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Blisko połowę sprzedaży polskich stacji paliwowych, z wyłączeniem samego paliwa, stanowi alkohol – donosi Business Insider. Wśród alkoholu na polskich stacjach paliw króluje piwo.</p>

## Węgierskie sklepy wprowadzają limity na osobę. "1 litr mleka, 1 kg ziemniaków, 1 pudełko jaj"
 - [https://www.bankier.pl/wiadomosc/Wegierskie-sklepy-wprowadzaja-limity-na-osobe-1-litr-mleka-1-kg-ziemniakow-1-pudelko-jaj-8459050.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wegierskie-sklepy-wprowadzaja-limity-na-osobe-1-litr-mleka-1-kg-ziemniakow-1-pudelko-jaj-8459050.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 09:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/b/e045dcfa3437e6-948-568-2-20-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Węgierski Aldi wprowadza limity na sprzedaż 
niektórych produktów. To efekt przedłużenia przez rząd do końca kwietnia
 ograniczeń cen na podstawowe produkty spożywcze. Podobną drogą idą 
mniejsze sklepy.</p>

## Kurs euro bez większych zmian. Dolar powyżej 4,40 zł
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-8459048.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-8459048.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 09:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/a/d39c70ab86b7c0-948-568-2-32-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs euro utrzymał się poniżej 4,70 zł przy dolarze notowanym
blisko najniższych poziomów od pół roku.</p>

## Błaszczak zdradza rozmieszczenie rakiet Patriot w Polsce
 - [https://www.bankier.pl/wiadomosc/Blaszczak-zdradza-rozmieszczenie-rakiet-Patriot-w-Polsce-8459039.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Blaszczak-zdradza-rozmieszczenie-rakiet-Patriot-w-Polsce-8459039.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 08:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/b86d7f139094bb-948-568-0-0-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kolejne wyrzutnie systemu Patriot zostaną rozmieszczone na Lubelszczyźnie, żeby nie doszło do powtórzenia się tragicznego wypadku z Przewodowa - powiedział w poniedziałek wicepremier, szef MON Mariusz Błaszczak.</p>

## Niemcy przymierzają się do zamknięcia sklepów w poniedziałki
 - [https://www.bankier.pl/wiadomosc/Niemcy-przymierzaja-sie-do-zamkniecie-sklepow-w-poniedzialki-8459004.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niemcy-przymierzaja-sie-do-zamkniecie-sklepow-w-poniedzialki-8459004.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 07:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/9/0c8bf18d87233f-948-568-0-90-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Niemczech trwa dyskusja o skróceniu godzin pracy sklepów spożywczych. Powodem ograniczenia czasu otwarcia marketów jest, dający się coraz mocniej we znaki, kryzys energetyczny - podaje serwis Wiadomości Handlowe.</p>

## Rząd szacuje koszty programu "Pierwsze mieszkanie"
 - [https://www.bankier.pl/wiadomosc/Rzad-szacuje-koszty-programu-Pierwsze-mieszkanie-8459001.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-szacuje-koszty-programu-Pierwsze-mieszkanie-8459001.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 07:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/2/fbc732f20f3faf-948-568-0-111-1777-1066.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wydatki z programu "bezpieczny kredyt 2 proc." pojawią się w 2024 roku i wyniosą około 800 mln zł, a w 2027 roku wzrosną do ok. 1,5 mld zł - podał resort rozwoju.</p>

## Opublikowano autopoprawkę do tzw. ustawy wiatrakowej
 - [https://www.bankier.pl/wiadomosc/Opublikowano-autopoprawke-do-tzw-ustawy-wiatrakowej-8458997.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Opublikowano-autopoprawke-do-tzw-ustawy-wiatrakowej-8458997.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 07:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/2afe3c8e5ee9d4-948-568-0-116-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rozwiązania umożliwiające partycypację lokalnej społeczności w korzyściach z lokalizacji na danym terenie elektrowni wiatrowej - przewiduje  autopoprawka do tzw. ustawy wiatrakowej, opublikowana w poniedziałek na stronach sejmowych.</p>

## Musk pyta użytkowników Twittera, czy ma dalej kierować platformą
 - [https://www.bankier.pl/wiadomosc/Musk-przestanie-rzadzic-Twitterem-Pyta-uzytkownikow-8458996.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Musk-przestanie-rzadzic-Twitterem-Pyta-uzytkownikow-8458996.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 07:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/c/a98159aa50e667-948-568-0-52-1764-1058.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amerykański miliarder i właściciel sieci społecznościowej Twitter Elon Musk ogłosił w nocy z niedzieli na poniedziałek ankietę, w której użytkownicy Twittera mogą wypowiedzieć się, czy chcą by dalej kierował platformą czy ustąpił ze stanowiska. Zastosuję się do wyników głosowania - zadeklarował Musk.</p>

## 40 mld złotych... Nawet tyle mogliśmy wydać na pomoc Ukrainie
 - [https://www.bankier.pl/wiadomosc/40-mld-zlotych-Nawet-tyle-moglismy-wydac-na-pomoc-Ukrainie-8458970.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/40-mld-zlotych-Nawet-tyle-moglismy-wydac-na-pomoc-Ukrainie-8458970.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 06:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/7/12a6675e76aa04-786-471-0-206-786-471.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wedle ostrożnych szacunków polskie wsparcie dla Ukraińców i Ukrainy może mieć wartość nawet 40 mld zł. 15,9 mld zł z tego to pomoc publiczna – pisze poniedziałkowa "Rzeczpospolita".</p>

## Polacy chcą pieniędzy z KPO. "Tak" dla ustępstw wobec KE
 - [https://www.bankier.pl/wiadomosc/Polacy-chca-pieniedzy-z-KPO-Tak-dla-ustepstw-wobec-KE-8458968.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-chca-pieniedzy-z-KPO-Tak-dla-ustepstw-wobec-KE-8458968.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 06:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/a/1b70a50a426fba-948-568-9-0-1803-1081.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />66 proc. Polaków za nowelizacją ustawy o SN, która ma otworzyć drogę do wypłaty środków z KPO. Przeciwko jest 19 proc. badanych, a 15 proc., nie ma w tej sprawie zdania – wynika z sondażu United Surveys dla DGP i RMF FM.</p>

## Mniej ofert pracy dla „ścisłowców”, więcej dla pracowników fizycznych
 - [https://www.bankier.pl/wiadomosc/Tych-specjalistow-poszukuja-firmy-8458963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tych-specjalistow-poszukuja-firmy-8458963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 06:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/508365a48ea3af-948-568-0-101-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ubyło wakatów dla przedstawicieli m.in. zawodów ścisłych i usług, za to zwiększyła się liczba
ofert zatrudnienia dla pracowników fizycznych – wynika z najnowszego Barometru
Ofert Pracy przygotowanego przez Katedrę Ekonomii i Finansów WSIiZ w Rzeszowie
oraz Biuro Inwestycji i Cykli Ekonomicznych. Po raz pierwszy jednak w
listopadzie pojawiło się mniej ofert pracy niż przed rokiem. </p>

## ZUS: zawieranych jest coraz więcej umów o dzieło
 - [https://www.bankier.pl/wiadomosc/ZUS-zawieranych-jest-coraz-wiecej-umow-o-dzielo-8458941.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ZUS-zawieranych-jest-coraz-wiecej-umow-o-dzielo-8458941.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 05:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/d/3abb2aa55a8c5c-948-568-9-12-1191-714.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W pierwszych trzech kwartałach 2022 r. zgłoszono około 1,3 mln umów o dzieło, czyli o ok. 6,5 proc. więcej niż w analogicznym okresie poprzedniego roku - wynika z raportu ZUS. Największa grupa wykonawców umów o dzieło to mężczyźni w wieku 30–39 lat.</p>

## Atak rosyjskich dronów na Kijów. Część zestrzelono
 - [https://www.bankier.pl/wiadomosc/Atak-rosyjskich-dronow-na-Kijow-Czesc-zestrzelono-8458938.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Atak-rosyjskich-dronow-na-Kijow-Czesc-zestrzelono-8458938.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 05:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/9/d126cba998a70f-948-568-0-0-1760-1055.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stolica Ukrainy Kijów i okolice zostały w poniedziałek nad ranem ponownie zaatakowane przez wyprodukowane w Iranie rosyjskie drony Shahed - poinformowała na Telegramie administracja wojskowa obwodu kijowskiego. W mieście ogłoszono alarm przeciwlotniczy.</p>

## Długi firm. Blisko 1/3 nie płaci kontrahentom 2 lata przed upadkiem
 - [https://www.bankier.pl/wiadomosc/Dlugi-firm-Blisko-1-3-nie-placi-kontrahentom-2-lata-przed-upadkiem-8458937.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dlugi-firm-Blisko-1-3-nie-placi-kontrahentom-2-lata-przed-upadkiem-8458937.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/3/2748c89cdd5273-945-567-63-179-1361-817.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W III kwartał br. niewypłacalność ogłosiło 26-proc. firm więcej niż w kwartale poprzednim; 31,5 proc. bankrutów nie płaciło kontrahentom na 2 lata przed ogłoszeniem niewypłacalności - wynika z danych Krajowego Rejestru Długów.</p>

## Epoka WIBOR-u właśnie się kończy. Dokładnie prześwietlamy jego następcę - WIRON
 - [https://www.bankier.pl/wiadomosc/Co-to-jest-WIRON-Kiedy-zniknie-WIBOR-8458861.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Co-to-jest-WIRON-Kiedy-zniknie-WIBOR-8458861.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/3/6d24ac1ec43c32-948-568-0-18-2450-1469.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wskaźnik WIBOR jest podstawą wyliczania oprocentowania w setkach tysięcy umów kredytowych. Jego epoka wkrótce się skończy i zastąpi go inny indeks – WIRON. Wyjaśniamy, kiedy to nastąpi i czym różnią się oba mierniki.</p>

## Stan wyjątkowy w El Paso. Spodziewany wzrost fali imigrantów
 - [https://www.bankier.pl/wiadomosc/Stan-wyjatkowy-w-El-Paso-Spodziewany-wzrost-fali-imigrantow-8458926.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stan-wyjatkowy-w-El-Paso-Spodziewany-wzrost-fali-imigrantow-8458926.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-19 00:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/a/95b9bee058c1d2-945-560-0-35-1797-1078.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Oscar Leeser burmistrz El Paso, położonego przy granicy z Meksykiem miasta w Teksasie,  ogłosił w niedzielę stan wyjątkowy. Uzasadniał to obawami, że tamtejsza społeczność nie sprosta bez pomocy przewidywanemu zwiększeniu fali imigrantów napływających przez południową granicę.</p>


# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Shirley Watts nie żyje. Żona perkusisty The Rolling Stones miała 82 lata
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/shirlet-watts-nie-zyje-zona-perkusisty-the-rolling-stones-miala-82-lata/](https://www.polsatnews.pl/wiadomosc/2022-12-19/shirlet-watts-nie-zyje-zona-perkusisty-the-rolling-stones-miala-82-lata/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 21:07:00+00:00

Związana przez ponad pół wieku z legendarnym perkusistą The Rolling Stones Shirley Watts zmarła w wieku 82 lat po krótkiej chorobie. O śmierci jedynej muzy Charliego Wattsa, artystki i miłośniczki koni poinformowali jej najbliżsi.

## USA. Samochód z dwójką młodych ludzi spadł w przepaść. Uratował ich sygnał z telefonu
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/usa-para-spadla-w-przepasc-uratowal-ich-sygnal-z-telefonu/](https://www.polsatnews.pl/wiadomosc/2022-12-19/usa-para-spadla-w-przepasc-uratowal-ich-sygnal-z-telefonu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 20:55:00+00:00

Dwójka młodych ludzi w samochodzie spadła w prawie stumetrową przepaść. Uratowała ich nowa funkcja telefonu, która wykorzystuje satelity do kontaktu ze służbami ratunkowymi. Po trzydziestu minutach dotarła do nich pomoc.

## USA. Kobieta nurkowała razem z mężem. Została zjedzona przez rekina
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/usa-kobieta-ktora-zaginela-podczas-nurkowania-na-hawajach-zostala-zjedzona-przez-rekina/](https://www.polsatnews.pl/wiadomosc/2022-12-19/usa-kobieta-ktora-zaginela-podczas-nurkowania-na-hawajach-zostala-zjedzona-przez-rekina/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 19:32:00+00:00

Amerykanka, która zaginęła u wybrzeży Hawajów, została zaatakowana i zjedzona przez agresywnego rekina - wynika z raportu władz. Kobieta zniknęła podczas nurkowania z mężem. Świadkowie wspominają, że widzieli w wodzie drapieżnika. Ciało ofiary nie zostało jeszcze odnalezione.

## USA. "NYT" zamieścił krzyżówkę w kształcie swastyki. Opublikowano ją w Chanukę
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/usa-nyt-zamiescil-krzyzowke-w-ksztalcie-swastyki-opublikowano-ja-w-chanuke/](https://www.polsatnews.pl/wiadomosc/2022-12-19/usa-nyt-zamiescil-krzyzowke-w-ksztalcie-swastyki-opublikowano-ja-w-chanuke/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 18:52:00+00:00

New York Times opublikował krzyżówkę, która kształtem przypomina swastykę. - Co to ma znaczyć? - napisał w mediach społecznościowych producent filmowy Keith Edwards. The Jerusalem Post przypomniał, że to nie pierwszy incydent w wykonaniu tej gazety.

## RPA: Ogromna fala dotarła do plaży w Durbanie. Nie żyją trzy osoby
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/rpa-ogromna-fala-dotarla-do-plazy-w-durbanie-nie-zyja-trzy-osoby/](https://www.polsatnews.pl/wiadomosc/2022-12-19/rpa-ogromna-fala-dotarla-do-plazy-w-durbanie-nie-zyja-trzy-osoby/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 18:20:00+00:00

Trzech plażowiczów zginęło w wyniku uderzenia dziwacznej fali. Do tragedii doszło na najpopularniejszej plaży w mieście Durban w RPA. Fala zmiotła turystów z molo, a wypoczywający na plaży byli wciągani do wody. Rannych zostało 17 osób.

## Tajlandia. Statek marynarki wojennej zatonął podczas sztormu. 31 marynarzy zaginionych
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/tajlandia-statek-marynarki-wojennej-zatonal-podczas-sztormu-31-marynarzy-zaginionych/](https://www.polsatnews.pl/wiadomosc/2022-12-19/tajlandia-statek-marynarki-wojennej-zatonal-podczas-sztormu-31-marynarzy-zaginionych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 17:03:00+00:00

Okręt wojenny HTMS Sukhothai zatonął podczas sztormu w Zatoce Tajlandzkiej. Służby ratunkowe poszukują 31 zaginionych marynarzy - przekazały media. Na statku przebywało 106 osób.

## Najczęstszy błąd popełniany w toalecie. Możesz od tego zachorować
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/najczestszy-blad-popelniany-w-toalecie-mozesz-od-tego-zachorowac/](https://www.polsatnews.pl/wiadomosc/2022-12-19/najczestszy-blad-popelniany-w-toalecie-mozesz-od-tego-zachorowac/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 15:36:00+00:00

Do tej pory naukowcy wiedzieli, że ubikacje emitują szkodliwe aerozole, ale nie byli w stanie ich pokazać. Najnowsze badanie umożliwiło zarejestrowanie cząsteczek mogących przenosić choroby zakaźne i patogeny zawarte w kale, które unoszą się w toalecie po spuszczeniu wody. Wystarczy, że klapa sedesu pozostanie otwarta.

## Spotkanie Putin-Łukaszenka w Mińsku. "Zachód powinien posłuchać głosu rozsądku"
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/spotkanie-putin-lukaszenka-w-minsku/](https://www.polsatnews.pl/wiadomosc/2022-12-19/spotkanie-putin-lukaszenka-w-minsku/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 15:29:00+00:00

- Mam nadzieję, że wkrótce będzie można przejść do konstruktywnej dyskusji z Europą na temat kwestii bezpieczeństwa i przyszłego ładu światowego - powiedział Aleksander Łukaszenka podczas spotkania z Władimirem Putinem. Białoruski przywódca mówił, że w tej kwestii Zachód powinien posłuchać głosu rozsądku.

## Australia. Chciała 20 mln dolarów za dom. Teraz "straciła szansę" na sprzedaż
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/australia-odmowila-sprzedazy-domy-deweloperzy-oferuja-jej/](https://www.polsatnews.pl/wiadomosc/2022-12-19/australia-odmowila-sprzedazy-domy-deweloperzy-oferuja-jej/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 14:10:00+00:00

Mieszkanka Sydney doprowadza deweloperów w Sydney do białej gorączki! Kobieta blokuje zabudowanie działki, na której znajduje się jej dom. Wokół wyrosły nowoczesne osiedla oraz sklepy. Kobieta zażądała za nieruchomość astronomiczną kwotę 20 mln dolarów.

## Indie: 16-latka przetrzymywana i gwałcona przez swojego przyjaciela i siedmiu innych mężczyzn
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/indie-16-latka-przetrzymywana-i-gwalcona-przez-swojego-przyjaciela-i-siedmiu-innych-mezczyzn/](https://www.polsatnews.pl/wiadomosc/2022-12-19/indie-16-latka-przetrzymywana-i-gwalcona-przez-swojego-przyjaciela-i-siedmiu-innych-mezczyzn/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 14:01:00+00:00

16-latka była więziona w opuszczonym domku blisko plaży w miejscowości Palghar w Indiach. Tam, przez kilkanaście godzin, dochodziło do dramatycznych scen. Nastolatka była wykorzystywana przez swojego przyjaciela i siedmiu innych mężczyzn. Oprawcy zostali zatrzymani. 16-latka przebywa w szpitalu.

## Philip Dybvig. Laureat nagrody Nobla z ekonomii oskarżony o molestowanie
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/usa-noblista-oskarzony-o-molestowanie-seksualne/](https://www.polsatnews.pl/wiadomosc/2022-12-19/usa-noblista-oskarzony-o-molestowanie-seksualne/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 13:24:00+00:00

Philip Dybvig, tegoroczny laureat nagrody Nobla w dziedzinie ekonomii został oskarżony o molestowanie. Takie zarzuty wystosowało kilka studentek z Uniwersytetu Waszyngtońskiego, gdzie wykłada noblista.

## Dmitrij Pieskow o spekulacjach ws. udziału Białorusi w wojnie. "Głupie i bezpodstawne"
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/dmitrij-pieskow-o-spekulacjach-ws-udzialu-bialorusi-w-wojnie-glupie-i-bezpodstawne/](https://www.polsatnews.pl/wiadomosc/2022-12-19/dmitrij-pieskow-o-spekulacjach-ws-udzialu-bialorusi-w-wojnie-glupie-i-bezpodstawne/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 12:39:00+00:00

Na poniedziałkowym briefingu rzecznik Kremla odniósł się do spekulacji o udziale Białorusi w wojnie z Ukrainą. Dmitrij Pieskow stwierdził, że publikacje, według których Putin jedzie do Mińska by wciągnąć Łukaszenkę do wojny są głupie i bezpodstawne.

## Niemcy przeprowadzili ćwiczenia, awarii uległo 18 wozów bojowych
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/niemcy-przeprowadzili-cwiczenia-awarii-uleglo-18-wozow-bojowych/](https://www.polsatnews.pl/wiadomosc/2022-12-19/niemcy-przeprowadzili-cwiczenia-awarii-uleglo-18-wozow-bojowych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 11:35:00+00:00

Podczas manewrów Bundeswehry awarii uległo 18 transporterów opancerzonych Puma co wywołało duże zaniepokojenie polityków oraz prasy. W poniedziałek to jeden z głównych tematów w Niemczech. Prasa pisze o kompromitacji. Rzecznik niemieckiego ministerstwa obrony przyznał, że awaria Pum jest porażką dla resortu.

## Szojgu odwiedza "wysunięte pozycje". Wpadka rosyjskiej propagandy
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/szojgu-odwiedza-wysuniete-pozycje-wpadka-rosyjskiej-propagandy/](https://www.polsatnews.pl/wiadomosc/2022-12-19/szojgu-odwiedza-wysuniete-pozycje-wpadka-rosyjskiej-propagandy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 11:10:00+00:00

Siergiej Szojgu pochwalił się nagraniem, na którym odwiedzał żołnierzy walczących na wysuniętych pozycjach. Film przeanalizowali internauci i ustalili, że rosyjskiemu ministrowi obrony do wysuniętych pozycji na froncie sporo zabrakło.

## Polscy sędziowie zdradzają kulisy finału mundialu w Katarze
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/polscy-sedziowie-zdradzaja-kulisy-finalu-mundialu-w-katarze/](https://www.polsatnews.pl/wiadomosc/2022-12-19/polscy-sedziowie-zdradzaja-kulisy-finalu-mundialu-w-katarze/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 10:17:00+00:00

Polscy sędziowie są na ustach całego świata. Eksperci chwalą Szymona Marciniaka za bezbłędne poprowadzenie finału mistrzostw świata w Katarze. Jego asystenci - Tomasz Listkiewicz i Paweł Sokolnicki - opowiedzieli Polsat News o kulisach starcia Francji z Argentyną. O tym, kto ich najbardziej pochwalił oraz co o pracy sędziów powiedzieli Francuscy piłkarze.

## Skutki rosyjskiego ostrzału. Tak wygląda Ukraina po ataku rakietowym
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/skutki-rosyjskiego-ostrzalu-tak-wyglada-ukraina-po-ataku-rakietowym/](https://www.polsatnews.pl/wiadomosc/2022-12-19/skutki-rosyjskiego-ostrzalu-tak-wyglada-ukraina-po-ataku-rakietowym/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 09:40:00+00:00

Na najnowszych zdjęciach satelitarnych NASA widać ciemną przestrzeń na mapie Europy Wschodniej. Tak wygląda Ukraina po rosyjskim ostrzale sprzed kilku dni. Okupanci, uszkadzając obiekty energetyczne, zmusili broniący się kraj do przymusowych przerw w dostawie prądu.

## Mundial 2022. Kibice Francji nie wytrzymali. Zamieszki po meczu z Argentyną
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/mundial-2022-kibice-francji-nie-wytrzymali-zamieszki-po-meczu-z-argentyna/](https://www.polsatnews.pl/wiadomosc/2022-12-19/mundial-2022-kibice-francji-nie-wytrzymali-zamieszki-po-meczu-z-argentyna/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 09:00:00+00:00

Francja przegrała z Argentyną w finale mistrzostw świata. Sfrustrowani kibice wyszli na ulice, aby dać upust swoim emocjom. W kilku miastach doszło do zamieszek z policją. Płonęły śmietniki. Mundurowi użyli gazu łzawiącego.

## Tak świętowała Argentyna. Niesamowite nagrania z Buenos Aires [WIDEO]
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/tak-swietowala-argentyna-niesamowite-nagrania-z-buenos-aires/](https://www.polsatnews.pl/wiadomosc/2022-12-19/tak-swietowala-argentyna-niesamowite-nagrania-z-buenos-aires/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 07:17:00+00:00

Niedzielny finał mundialu w Katarze przejdzie do historii jako jeden z najlepszych w historii. Argentyna od wczoraj świętuje zwycięstwo nad Francją. Oto, jak świętowali kibice triumf Leo Messiego i spółki.

## USA. Elon Musk przestanie być szefem Twittera? Decyzję oddał w ręce... internautów
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/usa-elon-musk-przestanie-byc-szefem-twittera-decyzje-oddal-w-rece-internautow/](https://www.polsatnews.pl/wiadomosc/2022-12-19/usa-elon-musk-przestanie-byc-szefem-twittera-decyzje-oddal-w-rece-internautow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 06:55:00+00:00

Miliarder Elon Musk po raz kolejny zaskoczył swoim pomysłem. Tym razem zapytał w mediach społecznościowych... czy powinien ustąpić ze stanowiska szefa Twittera. Zapewnił, że postąpi zgodnie z wynikami ankiety. Do tej pory zagłosowało 13,6 mln internautów.

## Hawaje. Potężne turbulencje podczas lotu na Hawaje. 36 osób poszkodowanych
 - [https://www.polsatnews.pl/wiadomosc/2022-12-19/hawaje-potezne-turbulencje-podczas-lotu-na-hawaje-36-osob-poszkodowanych/](https://www.polsatnews.pl/wiadomosc/2022-12-19/hawaje-potezne-turbulencje-podczas-lotu-na-hawaje-36-osob-poszkodowanych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-19 05:31:00+00:00

Co najmniej 36 osób na pokładzie samolotu linii Hawaiian Airlines zostało rannych, a 20 trafiło do szpitala po tym, jak ich samolot napotkał poważne turbulencje podczas lotu z Phoenix do Honolulu – poinformowały władze.


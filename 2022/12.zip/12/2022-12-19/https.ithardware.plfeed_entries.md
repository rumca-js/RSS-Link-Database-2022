# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Epic Games zapłaci ogromną karę za naruszenie prywatności i niechciane płatności
 - [https://ithardware.pl/aktualnosci/epic_games_zaplaci_ogromna_kare_za_naruszenie_prywatnosci_i_niechciane_platnosci-24952.html](https://ithardware.pl/aktualnosci/epic_games_zaplaci_ogromna_kare_za_naruszenie_prywatnosci_i_niechciane_platnosci-24952.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 21:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/24952_1.jpg" />            Epic Games autorzy Fortnite zapłacą sporą karę finansową za wprowadzenie w błąd milion&oacute;w graczy i naruszenie ustawy o ochronie prywatności dzieci w internecie.

Federalna Komisja Handlu (FTC) ogłosiła ugodę, na kt&oacute;rą przystał...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/epic_games_zaplaci_ogromna_kare_za_naruszenie_prywatnosci_i_niechciane_platnosci-24952.html">https://ithardware.pl/aktualnosci/epic_games_zaplaci_ogromna_kare_za_naruszenie_prywatnosci_i_niechciane_platnosci-24952.html</a></p>

## Niemcy uruchamiają pierwszy w Europie zakład recyklingu litu z akumulatorów
 - [https://ithardware.pl/aktualnosci/niemcy_uruchamiaja_pierwszy_w_europie_zaklad_recyklingu_litu_z_akumulatorow-24951.html](https://ithardware.pl/aktualnosci/niemcy_uruchamiaja_pierwszy_w_europie_zaklad_recyklingu_litu_z_akumulatorow-24951.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 20:17:27+00:00

<img src="https://ithardware.pl/artykuly/min/24951_1.jpg" />            Niemiecka firma Accurec znana jest z recyklingu wszelkiego rodzaju baterii, ale dopiero teraz wprowadza na rynek linię, kt&oacute;ra będzie odzyskiwać r&oacute;wnież lit, co jest nowością na rynku europejskim.

Z wycofanych z użytku baterii...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/niemcy_uruchamiaja_pierwszy_w_europie_zaklad_recyklingu_litu_z_akumulatorow-24951.html">https://ithardware.pl/aktualnosci/niemcy_uruchamiaja_pierwszy_w_europie_zaklad_recyklingu_litu_z_akumulatorow-24951.html</a></p>

## Meta pozwana za podżeganie do przemocy i przyczynienie się do zabójstwa profesora
 - [https://ithardware.pl/aktualnosci/meta_pozwana_za_podzeganie_do_przemocy_i_przyczynienie_sie_do_zabojstwa_profesora-24950.html](https://ithardware.pl/aktualnosci/meta_pozwana_za_podzeganie_do_przemocy_i_przyczynienie_sie_do_zabojstwa_profesora-24950.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 19:58:15+00:00

<img src="https://ithardware.pl/artykuly/min/24950_1.jpg" />            Firmę Meta czeka kolejny proces sądowy. Pozew złożono w&nbsp;Sądzie&nbsp;Najwyższym&nbsp;Kenii, choć sprawa dotyczy Etiopii.&nbsp;Kenia jest gł&oacute;wnym ośrodkiem technologicznym w Afryce, a Meta ma tu r&oacute;wnież sw&oacute;j...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/meta_pozwana_za_podzeganie_do_przemocy_i_przyczynienie_sie_do_zabojstwa_profesora-24950.html">https://ithardware.pl/aktualnosci/meta_pozwana_za_podzeganie_do_przemocy_i_przyczynienie_sie_do_zabojstwa_profesora-24950.html</a></p>

## Capcom może przygotowywać kolejny remake Resident Evil
 - [https://ithardware.pl/aktualnosci/capcom_moze_przygotowywac_kolejny_remake_resident_evil-24949.html](https://ithardware.pl/aktualnosci/capcom_moze_przygotowywac_kolejny_remake_resident_evil-24949.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 18:50:00+00:00

<img src="https://ithardware.pl/artykuly/min/24949_1.jpg" />            Capcom odświeżył dwie części Resident Evil, a za jakiś czas zadebiutuje Resident Evil 4 Remake. Na tym jednak plany studia się nie kończą i może ono przygotowywać nowe wydania innych odsłon.

W 2019 roku dostaliśmy Resident Evil 2 Remake,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/capcom_moze_przygotowywac_kolejny_remake_resident_evil-24949.html">https://ithardware.pl/aktualnosci/capcom_moze_przygotowywac_kolejny_remake_resident_evil-24949.html</a></p>

## CD Projekt RED udostępnił hotfix do Wiedźmina 3: Dziki Gon
 - [https://ithardware.pl/aktualnosci/cd_projekt_red_udostepnil_hotfix_do_wiedzmina_3_dziki_gon-24948.html](https://ithardware.pl/aktualnosci/cd_projekt_red_udostepnil_hotfix_do_wiedzmina_3_dziki_gon-24948.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 17:34:09+00:00

<img src="https://ithardware.pl/artykuly/min/24948_1.jpg" />            CD Projekt RED opublikował hotfix do gry Wiedźmin 3: Dziki Gon, kt&oacute;ry ma za zadanie uporać się z problemami trapiącymi grę po wydaniu next-genowej aktualizacji.

Nex-genowy update do Wiedźmina 3: Dziki Gon przyni&oacute;sł więcej szkody...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cd_projekt_red_udostepnil_hotfix_do_wiedzmina_3_dziki_gon-24948.html">https://ithardware.pl/aktualnosci/cd_projekt_red_udostepnil_hotfix_do_wiedzmina_3_dziki_gon-24948.html</a></p>

## TP-Link Tapo C420 – kamera do monitoringu zewnętrznego zasilana bateryjnie
 - [https://ithardware.pl/aktualnosci/tp_link_tapo_c420_kamera_do_monitoringu_zewnetrznego_zasilana_bateryjnie-24947.html](https://ithardware.pl/aktualnosci/tp_link_tapo_c420_kamera_do_monitoringu_zewnetrznego_zasilana_bateryjnie-24947.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 16:21:04+00:00

<img src="https://ithardware.pl/artykuly/min/24947_1.jpg" />            Seria TP-Link Tapo poszerzyła się o nową kamerę do monitoringu zewnętrznego, kt&oacute;ra jest zasilana bateryjnie. Urządzenie rejestruje kolorowy obraz 2K QHD, jest odporny na warunki atmosferyczne (certyfikat IP65).

TP-Link Tapo C420...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tp_link_tapo_c420_kamera_do_monitoringu_zewnetrznego_zasilana_bateryjnie-24947.html">https://ithardware.pl/aktualnosci/tp_link_tapo_c420_kamera_do_monitoringu_zewnetrznego_zasilana_bateryjnie-24947.html</a></p>

## Test Patriot Viper Venom 2x8 GB 5600 MHz CL 40 - możesz zapomnieć o DDR4!
 - [https://ithardware.pl/testyirecenzje/patriot_viper_venom_2x8_gb_5600_mhz_test_recenzja_opinia-24889.html](https://ithardware.pl/testyirecenzje/patriot_viper_venom_2x8_gb_5600_mhz_test_recenzja_opinia-24889.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 14:41:50+00:00

<img src="https://ithardware.pl/artykuly/min/24889_1.jpg" />            Test taniej pamięci DDR5 Patriot Viper Venom

Od momentu wejścia pamięci DDR5 do sprzedaży, gł&oacute;wną przeszkodą dla potencjalnych nabywc&oacute;w przez dłuższy czas był wysoki koszt nowych moduł&oacute;w. Na szczęście na przestrzeni...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/patriot_viper_venom_2x8_gb_5600_mhz_test_recenzja_opinia-24889.html">https://ithardware.pl/testyirecenzje/patriot_viper_venom_2x8_gb_5600_mhz_test_recenzja_opinia-24889.html</a></p>

## Elon Musk zapytał, czy ma zrezygnować z Twittera. Społeczność odpowiedziała "TAK"
 - [https://ithardware.pl/aktualnosci/elon_musk_zapytal_czy_ma_zrezygnowac_z_twittera_spolecznosc_odpowiedziala_tak-24945.html](https://ithardware.pl/aktualnosci/elon_musk_zapytal_czy_ma_zrezygnowac_z_twittera_spolecznosc_odpowiedziala_tak-24945.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 14:00:50+00:00

<img src="https://ithardware.pl/artykuly/min/24945_1.jpg" />            Kadencja Elona Muska na czele Twittera jest&nbsp;pełna kontrowersji i wpływa r&oacute;wnież na inne jego firmy, zwłaszcza Teslę. Elon często pyta społeczności, jaką podjąć decyzję w niekt&oacute;rych kłopotliwych tematach, a tym razem...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/elon_musk_zapytal_czy_ma_zrezygnowac_z_twittera_spolecznosc_odpowiedziala_tak-24945.html">https://ithardware.pl/aktualnosci/elon_musk_zapytal_czy_ma_zrezygnowac_z_twittera_spolecznosc_odpowiedziala_tak-24945.html</a></p>

## Roidmi Eva, czyli wszechstronny robot odkurzająco-mopujący to dobry wybór!
 - [https://ithardware.pl/aktualnosci/roidmi_eva_dobry_robot_za_3000-24891.html](https://ithardware.pl/aktualnosci/roidmi_eva_dobry_robot_za_3000-24891.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 13:26:30+00:00

<img src="https://ithardware.pl/artykuly/min/24891_1.jpg" />            Rynek odkurzaczy automatycznych zmienia się na naszych oczach. W ostatnich latach pojawiły się naprawdę innowacyjne urządzenia i choć zdecydowana większość producent&oacute;w skupiało się w&oacute;wczas na wprowadzaniu coraz to lepszych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/roidmi_eva_dobry_robot_za_3000-24891.html">https://ithardware.pl/aktualnosci/roidmi_eva_dobry_robot_za_3000-24891.html</a></p>

## AMD odpiera zarzuty o wypuszczenie na rynek wadliwych kart graficznych
 - [https://ithardware.pl/aktualnosci/amd_odpiera_zarzuty_o_wypuszczenie_na_rynek_wadliwych_kart_graficznych-24942.html](https://ithardware.pl/aktualnosci/amd_odpiera_zarzuty_o_wypuszczenie_na_rynek_wadliwych_kart_graficznych-24942.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 13:12:01+00:00

<img src="https://ithardware.pl/artykuly/min/24942_1.jpg" />            AMD zaprzecza, że karty graficzne AMD RDNA 3 mają niepoprawnie działającą funkcję wstępnego pobierania shader&oacute;w (Shader prefetch) i wbrew opiniom pojawiającym się w sieci, producent zapewnia, że wszystko jest w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_odpiera_zarzuty_o_wypuszczenie_na_rynek_wadliwych_kart_graficznych-24942.html">https://ithardware.pl/aktualnosci/amd_odpiera_zarzuty_o_wypuszczenie_na_rynek_wadliwych_kart_graficznych-24942.html</a></p>

## NVIDIA wkróce wykastruje Shield TV z kluczowej funkcji. Gracze niezadowoleni
 - [https://ithardware.pl/aktualnosci/nvidia_wkroce_wykastruje_shield_tv_z_kluczowej_funkcji_gracze_niezadowoleni-24941.html](https://ithardware.pl/aktualnosci/nvidia_wkroce_wykastruje_shield_tv_z_kluczowej_funkcji_gracze_niezadowoleni-24941.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 12:32:01+00:00

<img src="https://ithardware.pl/artykuly/min/24941_1.jpg" />            Produkty Shield TV oficjalnie reklamowane jako &bdquo;urządzenia do strumieniowania multimedi&oacute;w&rdquo; wkr&oacute;tce stracą jedną ze swoich podstawowych funkcji.

NVIDIA Shield TV i Shield TV Pro to jedne z najpopularniejszych telewizorowych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_wkroce_wykastruje_shield_tv_z_kluczowej_funkcji_gracze_niezadowoleni-24941.html">https://ithardware.pl/aktualnosci/nvidia_wkroce_wykastruje_shield_tv_z_kluczowej_funkcji_gracze_niezadowoleni-24941.html</a></p>

## Film Death Stranding potwierdzony. Hideo Kojima nie kryje ekscytacji
 - [https://ithardware.pl/aktualnosci/film_death_stranding_potwierdzony_hideo_kojima_nie_kryje_ekscytacji-24939.html](https://ithardware.pl/aktualnosci/film_death_stranding_potwierdzony_hideo_kojima_nie_kryje_ekscytacji-24939.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 12:07:50+00:00

<img src="https://ithardware.pl/artykuly/min/24939_1.jpg" />            Jednym z cel&oacute;w Hideo Kojimy przy tworzeniu studia Kojima Productions było rozszerzenie działalności na inne media niż tylko gry, takie jak filmy i telewizja. Wygląda na to, że ten plan jest już realizowany, ponieważ oficjalnie ogłoszono...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/film_death_stranding_potwierdzony_hideo_kojima_nie_kryje_ekscytacji-24939.html">https://ithardware.pl/aktualnosci/film_death_stranding_potwierdzony_hideo_kojima_nie_kryje_ekscytacji-24939.html</a></p>

## Kto chce 60$ na Steam? No jasne, że każdy. Z tą promocją to możliwe!
 - [https://ithardware.pl/aktualnosci/kto_chce_60_na_steam_no_jasne_ze_kazdy_z_ta_promocja_to_mozliwe-24944.html](https://ithardware.pl/aktualnosci/kto_chce_60_na_steam_no_jasne_ze_kazdy_z_ta_promocja_to_mozliwe-24944.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 11:55:50+00:00

<img src="https://ithardware.pl/artykuly/min/24944_1.jpg" />            Gigabyte wraz z partnerami zorganizowali świetną promocję dla graczy. Kup wybrane laptopy Gigabyte A5, G5, AERO lub AORUS i zgarnij do 60$ do wykorzystania na platformie STEAM!

Gigabyte'a nie trzeba chyba nikomu przedstawiać, ale jeśli...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kto_chce_60_na_steam_no_jasne_ze_kazdy_z_ta_promocja_to_mozliwe-24944.html">https://ithardware.pl/aktualnosci/kto_chce_60_na_steam_no_jasne_ze_kazdy_z_ta_promocja_to_mozliwe-24944.html</a></p>

## Patriot P220 - topowe dyski SSD SATA w przystępnej cenie
 - [https://ithardware.pl/aktualnosci/patriot_p220_topowe_dyski_ssd_sata_w_przystepnej_cenie-24943.html](https://ithardware.pl/aktualnosci/patriot_p220_topowe_dyski_ssd_sata_w_przystepnej_cenie-24943.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 11:28:40+00:00

<img src="https://ithardware.pl/artykuly/min/24943_1.jpg" />            Firma Patriot, jeden z lider&oacute;w rynku pamięci, nośnik&oacute;w danych i gamingowych peryferi&oacute;w, zaprezentowała nową serię 2,5-calowych dysk&oacute;w SSD SATA III o nazwie P220. Nośniki zaprojektowano z myślą o niezawodności do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/patriot_p220_topowe_dyski_ssd_sata_w_przystepnej_cenie-24943.html">https://ithardware.pl/aktualnosci/patriot_p220_topowe_dyski_ssd_sata_w_przystepnej_cenie-24943.html</a></p>

## HTC zwiastuje nowy headset VR. Meta Quest Pro doczeka się rywala
 - [https://ithardware.pl/aktualnosci/htc_zwiastuje_nowy_headset_vr_meta_quest_pro_doczeka_sie_rywala-24938.html](https://ithardware.pl/aktualnosci/htc_zwiastuje_nowy_headset_vr_meta_quest_pro_doczeka_sie_rywala-24938.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 10:25:30+00:00

<img src="https://ithardware.pl/artykuly/min/24938_1.jpg" />            HTC przygotowuje się do wprowadzenia nowego headsetu AR/VR, kt&oacute;ry będzie konkurował z wycenionym na 1500 USD Quest Pro od Meta i być może goglami od Apple, o kt&oacute;rych m&oacute;wi się od dawna.&nbsp;

Globalny szef produktu HTC, Shen...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/htc_zwiastuje_nowy_headset_vr_meta_quest_pro_doczeka_sie_rywala-24938.html">https://ithardware.pl/aktualnosci/htc_zwiastuje_nowy_headset_vr_meta_quest_pro_doczeka_sie_rywala-24938.html</a></p>

## Tak wyglądają Galaxy S23, S23+ i S23 Ultra. Wyciekły zdjęcia atrap nowych flagowców Samsunga
 - [https://ithardware.pl/aktualnosci/tak_wygladaja_galaxy_s23_s23_i_s23_ultra_wyciekly_zdjecia_atrap_nowych_flagowcow_samsunga-24937.html](https://ithardware.pl/aktualnosci/tak_wygladaja_galaxy_s23_s23_i_s23_ultra_wyciekly_zdjecia_atrap_nowych_flagowcow_samsunga-24937.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 09:31:20+00:00

<img src="https://ithardware.pl/artykuly/min/24937_1.jpg" />            Spodziewamy się, że Samsung tradycyjnie zaprezentuje swoje nowe flagowe smartfony z serii Galaxy S23 dopiero za kilka tygodni (zapewne w lutym), ale w ostatnim czasie pojawia się coraz więcej przeciek&oacute;w na ich temat, a najnowsze z nich...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tak_wygladaja_galaxy_s23_s23_i_s23_ultra_wyciekly_zdjecia_atrap_nowych_flagowcow_samsunga-24937.html">https://ithardware.pl/aktualnosci/tak_wygladaja_galaxy_s23_s23_i_s23_ultra_wyciekly_zdjecia_atrap_nowych_flagowcow_samsunga-24937.html</a></p>

## UPDF to świetny zamiennik dla Adobe Acrobat. I ta cena!
 - [https://ithardware.pl/aktualnosci/updf_to_swietny_zamiennik_dla_adobe_acrobat_i_ta_cena-24934.html](https://ithardware.pl/aktualnosci/updf_to_swietny_zamiennik_dla_adobe_acrobat_i_ta_cena-24934.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 08:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/24934_1.png" />            PDF, czyli Portable Document Format to format pliku, kt&oacute;ry odgrywa kluczową rolę w naszym codziennym &ndash; biznesowym lub prywatnym &ndash; życiu. Opracowany już niemal 30 lat temu standard wykorzystywany jest dosłownie wszędzie i choć...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/updf_to_swietny_zamiennik_dla_adobe_acrobat_i_ta_cena-24934.html">https://ithardware.pl/aktualnosci/updf_to_swietny_zamiennik_dla_adobe_acrobat_i_ta_cena-24934.html</a></p>

## Twitter banuje linkowanie do platform konkurencji. Gdzie obiecywana ostoja wolności i swobody?
 - [https://ithardware.pl/aktualnosci/twitter_banuje_linkowanie_do_platfor_konkurencji_gdzie_obiecywana_ostoja_wolnosci_i_swobody-24936.html](https://ithardware.pl/aktualnosci/twitter_banuje_linkowanie_do_platfor_konkurencji_gdzie_obiecywana_ostoja_wolnosci_i_swobody-24936.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 08:05:50+00:00

<img src="https://ithardware.pl/artykuly/min/24936_1.jpg" />            Kiedy duża część os&oacute;b korzystała z Twittera do śledzenia finał&oacute;w mistrzostw świata w piłce nożnej, firma wprowadziła nową politykę zakazującą &bdquo;bezpłatnej promocji&rdquo; konkurencyjnych serwis&oacute;w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/twitter_banuje_linkowanie_do_platfor_konkurencji_gdzie_obiecywana_ostoja_wolnosci_i_swobody-24936.html">https://ithardware.pl/aktualnosci/twitter_banuje_linkowanie_do_platfor_konkurencji_gdzie_obiecywana_ostoja_wolnosci_i_swobody-24936.html</a></p>

## John Carmack odchodzi z Meta. Żali się na zbyt mały wpływ i niefektywność firmy
 - [https://ithardware.pl/aktualnosci/john_carmack_odchodzi_z_meta_zali_sie_na_zbyt_maly_wplyw_i_niefektywnosc_firmy-24933.html](https://ithardware.pl/aktualnosci/john_carmack_odchodzi_z_meta_zali_sie_na_zbyt_maly_wplyw_i_niefektywnosc_firmy-24933.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 07:20:49+00:00

<img src="https://ithardware.pl/artykuly/min/24933_1.jpg" />            John Carmack, jeden z pionier&oacute;w wirtualnej rzeczywistości i legenda branży gier, kt&oacute;ry przeszedł do Meta z firmy Oculus po jej przejęciu za 2 miliardy dolar&oacute;w, opuścił właśnie społecznościowego giganta.&nbsp;

Business...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/john_carmack_odchodzi_z_meta_zali_sie_na_zbyt_maly_wplyw_i_niefektywnosc_firmy-24933.html">https://ithardware.pl/aktualnosci/john_carmack_odchodzi_z_meta_zali_sie_na_zbyt_maly_wplyw_i_niefektywnosc_firmy-24933.html</a></p>

## Konkurs adwentowy z ITHardware! - Dzień #19
 - [https://ithardware.pl/aktualnosci/konkurs_adwentowy_z_ithardware_dzien_19-24816.html](https://ithardware.pl/aktualnosci/konkurs_adwentowy_z_ithardware_dzien_19-24816.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-19 06:00:01+00:00

<img src="https://ithardware.pl/artykuly/min/24816_1.jpg" />            Kolejny dzień, kolejna nagroda. Tym razem macie szanse zgarnąć dysk SSD Lexar NM800 o pojemności 1 TB. Co należy zrobić, by wygrać?

&nbsp;

&nbsp;

Nagroda - dysk SSD Lexar NM800 1 TB

Lexar NM800 to wysokiej klasy dysk SSD M.2 PCIe 4.0...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/konkurs_adwentowy_z_ithardware_dzien_19-24816.html">https://ithardware.pl/aktualnosci/konkurs_adwentowy_z_ithardware_dzien_19-24816.html</a></p>


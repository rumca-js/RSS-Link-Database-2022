# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## Blake Lively  & Justin Trudeau Celebrate Ryan's Life in Storytelling
 - [https://www.youtube.com/watch?v=ap3JGsCAu9A](https://www.youtube.com/watch?v=ap3JGsCAu9A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-12-20 00:00:00+00:00

Who are two people that rule? 

#AmericanCinemathequeAward

## Epic Holiday Wireless Savings
 - [https://www.youtube.com/watch?v=m1iXVbpkmeU](https://www.youtube.com/watch?v=m1iXVbpkmeU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-12-20 00:00:00+00:00

It’s the most wonderful plan of the year. Save more on your wireless with @MintMobile. https://www.mintmobile.com/

Mint Mobile offers premium wireless starting at $15 bucks a month. There's no contract, no crazy fees and no nonsense. On the T-Mobile 5G Network.

## Hugh Jackman Says Surprisingly Nice Things About Ryan
 - [https://www.youtube.com/watch?v=RWxR3rzeFBY](https://www.youtube.com/watch?v=RWxR3rzeFBY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-12-20 00:00:00+00:00

He's getting children to do his evil bidding now. Benjamin Pajak, blink three times if you need us to send help.

#AmericanCinemathequeAward

## Morena Baccarin & Mary Steenburgen Reflect on Ryan
 - [https://www.youtube.com/watch?v=pZOCOfpRvoA](https://www.youtube.com/watch?v=pZOCOfpRvoA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-12-20 00:00:00+00:00

MCU x Parenthood cross-over event, Phase One. 
#AmericanCinemathequeAward

## Nathan Fillion Remembers Ryan
 - [https://www.youtube.com/watch?v=QH1AgFDGcn8](https://www.youtube.com/watch?v=QH1AgFDGcn8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-12-20 00:00:00+00:00

Nathan's stunning good looks makes it easy to forget what a talented actor he is. His acting also does that, too.
#AmericanCinemathequeAward

## Rick Nicita Introduces Ryan at the American Cinematheque Award
 - [https://www.youtube.com/watch?v=W48MqXVUYFI](https://www.youtube.com/watch?v=W48MqXVUYFI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-12-20 00:00:00+00:00

Rick is so good at what he does I had him negotiate the deal both times I sold my soul to the devil.

#AmericanCinemathequeAward

## Rob McElhenney & Dame Helen Mirren Honor Ryan's Memory
 - [https://www.youtube.com/watch?v=Ads5lkWJmyo](https://www.youtube.com/watch?v=Ads5lkWJmyo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-12-20 00:00:00+00:00

They may not be knights, but mythic heroes to me.
#AmericanCinemathequeAward

## Salma Hayek & Octavia Spencer Memorialize Ryan
 - [https://www.youtube.com/watch?v=3u3jmqQK2hY](https://www.youtube.com/watch?v=3u3jmqQK2hY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-12-20 00:00:00+00:00

This is also the cast of my favorite buddy cop drama ever in my mind. 

#AmericanCinemathequeAward

## Shawn Levy Presents Ryan Reynolds with the American Cinematheque Award
 - [https://www.youtube.com/watch?v=kSuuJ6ttmTo](https://www.youtube.com/watch?v=kSuuJ6ttmTo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-12-20 00:00:00+00:00

Shawn's the Canadian wind beneath my wings.

#AmericanCinemathequeAward

## Will Ferrell & Jeff Bridges Toast Ryan
 - [https://www.youtube.com/watch?v=ZzexM_8rx8c](https://www.youtube.com/watch?v=ZzexM_8rx8c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-12-20 00:00:00+00:00

My entire philosophy of life is to abide classily.  
#AmericanCinemathequeAward


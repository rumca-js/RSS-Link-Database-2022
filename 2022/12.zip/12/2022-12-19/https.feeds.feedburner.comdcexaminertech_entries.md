# Source:Washington Examiner - Tech, URL:https://feeds.feedburner.com/dcexaminer/tech, language:en-US

## 4D chess or folly? Musk stunts raise speculation about Twitter's prospects
 - [https://www.washingtonexaminer.com/policy/technology/musk-chaos-twitter-future](https://www.washingtonexaminer.com/policy/technology/musk-chaos-twitter-future)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/tech
 - date published: 2022-12-19 11:00:29+00:00

A string of surprising and controversial decisions by Elon Musk has drummed up tremendous interest in Twitter, but some allies of the billionaire and outside observers are wondering if his unpredictable style might be undermining the platform's long-term prospects.


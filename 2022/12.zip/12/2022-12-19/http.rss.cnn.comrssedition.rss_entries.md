# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Moscow says it shot down 4 US-made missiles over Russia
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-12-19-22/h_10d30afe66ee9dafc9dbed2d37a9aa69](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-12-19-22/h_10d30afe66ee9dafc9dbed2d37a9aa69)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 23:43:03.544845+00:00

• One dead in strikes on Russian region near Ukraine

## 'Simultaneously beautiful and terrifying': Expert explains what happens when you flush
 - [https://www.cnn.com/videos/health/2022/12/19/flush-toilet-no-lid-lbb-cprog-orig.cnn](https://www.cnn.com/videos/health/2022/12/19/flush-toilet-no-lid-lbb-cprog-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 23:39:20+00:00

At the University of Colorado, Boulder, engineers used lasers and cameras to observe the tiny water droplets that fly into the air when we flush our toilets.

## Verdict reached in Harvey Weinstein sexual assault trial
 - [https://www.cnn.com/2022/12/19/us/harvey-weinstein-trial-deliberations-los-angeles-monday/index.html](https://www.cnn.com/2022/12/19/us/harvey-weinstein-trial-deliberations-los-angeles-monday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 23:29:13+00:00



## Mulvaney: This criminal referral should frighten Trump most
 - [https://www.cnn.com/videos/politics/2022/12/19/mick-mulvaney-trump-criminal-referral-house-committee-january-6-lead-vpx.cnn](https://www.cnn.com/videos/politics/2022/12/19/mick-mulvaney-trump-criminal-referral-house-committee-january-6-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 23:07:03+00:00

Mick Mulvaney, former acting chief of staff of President Trump, tells CNN's Jake Tapper why he thinks Trump should be concerned about the Jan. 6 committee's referral for a criminal charge of obstructing an official proceeding.

## Moscow says it shot down 4 US-made missiles over southern Russia
 - [https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-12-19-22/h_10d30afe66ee9dafc9dbed2d37a9aa69](https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-12-19-22/h_10d30afe66ee9dafc9dbed2d37a9aa69)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 22:41:47.614763+00:00



## What the criminal referrals against Trump mean
 - [https://edition.cnn.com/webview/politics/live-news/jan-6-committee-public-meeting/h_ae614c52ad8ef8eced85b7b4a17de066](https://edition.cnn.com/webview/politics/live-news/jan-6-committee-public-meeting/h_ae614c52ad8ef8eced85b7b4a17de066)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 22:41:47.596322+00:00



## First legislative response to Capitol attack nears passage
 - [https://www.cnn.com/2022/12/19/politics/electoral-count-act-legislation/index.html](https://www.cnn.com/2022/12/19/politics/electoral-count-act-legislation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 21:25:49+00:00

Lawmakers reached an agreement to include in must-pass legislation a measure aimed at making it harder to overturn a certified presidential election, marking the first legislative response to the US Capitol insurrection and then-President Donald Trump's relentless pressure campaign to stay in power despite his 2020 loss.

## Ex-Trump insiders react to criminal referral for former president
 - [https://www.cnn.com/videos/politics/2022/12/19/ex-trump-aides-criminal-referral-january-6-committee-vpx.cnn](https://www.cnn.com/videos/politics/2022/12/19/ex-trump-aides-criminal-referral-january-6-committee-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 20:58:17+00:00

Former Trump administration aides Stephanie Grisham, Alyssa Farah Griffin, Olivia Troye and Sarah Matthews discuss the January 6 committee's criminal referral of Donald Trump to the Justice Department.

## Takeaways from Monday's Jan. 6 committee meeting
 - [https://www.cnn.com/collections/jan-6-meeting-intl-121922/](https://www.cnn.com/collections/jan-6-meeting-intl-121922/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 20:40:23+00:00



## What's in the House January 6 committee report summary
 - [https://www.cnn.com/2022/12/19/politics/what-is-in-jan-6-committee-report-summary/index.html](https://www.cnn.com/2022/12/19/politics/what-is-in-jan-6-committee-report-summary/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 20:15:13+00:00

The House select committee investigating the January 6, 2021, attack on the US Capitol has concluded that former President Donald Trump was ultimately responsible for the insurrection, laying out for the public and the Justice Department a trove of evidence for why he should be prosecuted for multiple crimes.

## Hope Hicks describes conversation with Trump in newly released video
 - [https://www.cnn.com/videos/politics/2022/12/19/hope-hicks-trump-video-testimony-house-committee-doj-january-6-meeting-vpx.cnn](https://www.cnn.com/videos/politics/2022/12/19/hope-hicks-trump-video-testimony-house-committee-doj-january-6-meeting-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 20:13:42+00:00

A new video clip played by the House select committee investigating the January 6 insurrection of the US Capitol shows Hope Hicks, who previously served as a top aide to former President Donald Trump, reference Trump's baseless claims of election fraud.

## Former deputy FBI director on how the DOJ is receiving referral
 - [https://www.cnn.com/videos/politics/2022/12/19/andrew-mccabe-donald-trump-criminal-referral-house-committee-doj-january-6-meeting-vpx.cnn](https://www.cnn.com/videos/politics/2022/12/19/andrew-mccabe-donald-trump-criminal-referral-house-committee-doj-january-6-meeting-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 19:47:22+00:00

Former Deputy FBI Director Andrew McCabe explains how the Department of Justice is receiving the criminal referral of former President Donald Trump by the House select committee investigating the January 6 insurrection of the US capitol.

## Takeaways from Monday's Jan. 6 committee meeting
 - [https://www.cnn.com/2022/12/19/politics/takeaways-jan-6-committee-meeting/index.html](https://www.cnn.com/2022/12/19/politics/takeaways-jan-6-committee-meeting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 19:07:29+00:00

The January 6 committee used its final public meeting Monday to summarize its 17-month investigation with a simple closing statement: All roads lead to Donald Trump.

## Reaction to Lionel Messi lifting the World Cup trophy wearing a bisht shows cultural fault lines of Qatar 2022
 - [https://www.cnn.com/2022/12/19/football/lionel-messi-bisht-world-cup-trophy-lift-spt-intl/index.html](https://www.cnn.com/2022/12/19/football/lionel-messi-bisht-world-cup-trophy-lift-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 18:28:17+00:00

• Video: Argentina won the World Cup. See the reaction in Buenos Aires

## Dutch prime minister apologizes for the Netherlands' role in the slave trade
 - [https://www.cnn.com/2022/12/19/europe/dutch-prime-minister-apologizes-slavery-netherlands-intl-scli/index.html](https://www.cnn.com/2022/12/19/europe/dutch-prime-minister-apologizes-slavery-netherlands-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 18:20:57+00:00

Dutch Prime Minister Mark Rutte apologized Monday for the Netherlands' "slavery past," which he said continues to have "negative effects."

## Woman arrested after breaking into Robert De Niro's home in New York City, source says
 - [https://www.cnn.com/2022/12/19/entertainment/robert-deniro-new-york-home-burglar/index.html](https://www.cnn.com/2022/12/19/entertainment/robert-deniro-new-york-home-burglar/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 17:43:58+00:00

Police in New York City arrested a woman who broke into Robert De Niro's home early Monday, according to a law enforcement source.

## Jan. 6 panel expected to announce referral of multiple criminal charges against Trump at final meeting
 - [https://edition.cnn.com/webview/politics/live-news/jan-6-committee-public-meeting/index.html](https://edition.cnn.com/webview/politics/live-news/jan-6-committee-public-meeting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 17:35:17.374733+00:00



## High Court rules UK's Rwanda asylum plan is lawful
 - [https://www.cnn.com/videos/world/2022/12/19/rwanda-uk-deal-judgment-asylum-bashir-pkg-intl-vpx.cnn](https://www.cnn.com/videos/world/2022/12/19/rwanda-uk-deal-judgment-asylum-bashir-pkg-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 17:25:56+00:00

The UK's controversial policy to deport some asylum seekers to Rwanda was deemed lawful by the country's High Court. CNN's Nada Bashir reports.

## Sam Bankman-Fried set to drop extradition fight
 - [https://www.cnn.com/2022/12/19/business/sbf-extradition-bahamas/index.html](https://www.cnn.com/2022/12/19/business/sbf-extradition-bahamas/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 16:38:01+00:00

FTX founder Sam Bankman-Fried Monday morning arrived in court in the Bahamas where he is expected to drop his extradition fight, clearing a significant hurdle to return him to US soil to be prosecuted on multiple charges of fraud and conspiracy.

## Company creates candy that contains 96% real fruit and vegetables
 - [https://www.cnn.com/videos/business/2022/12/19/climate-candy-faves-food-waste-environment-contd-firstmove-vpx.cnn](https://www.cnn.com/videos/business/2022/12/19/climate-candy-faves-food-waste-environment-contd-firstmove-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 16:05:46+00:00

Amy Keller, the CEO of Climate Candy, shares why her company turns unharvested produce and other food waste into edible candy and how it can help protect the planet.

## Homicide is a leading cause of death in kids, and rates are rising, study finds
 - [https://www.cnn.com/2022/12/19/health/homicide-child-death/index.html](https://www.cnn.com/2022/12/19/health/homicide-child-death/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 16:04:24+00:00

Homicide is a leading cause of death for children in the United States, a new study says, and the overall rate has increased an average of 4.3% each year for nearly a decade.

## Elon Musk's poll results are in: He should step down, Twitter voters say
 - [https://www.cnn.com/collections/intl-twitter-1912/](https://www.cnn.com/collections/intl-twitter-1912/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 15:53:44+00:00



## Amber Heard says she has settled defamation lawsuit with Johnny Depp
 - [https://www.cnn.com/2022/12/19/entertainment/johnny-depp-amber-heard/index.html](https://www.cnn.com/2022/12/19/entertainment/johnny-depp-amber-heard/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 15:53:32+00:00

Amber Heard has settled the defamation lawsuit with her ex-husband, Johnny Depp, according to a statement posted on her verified Instagram account.

## More than 190 countries sign landmark agreement to halt the biodiversity crisis
 - [https://www.cnn.com/collections/intl-climate-1912/](https://www.cnn.com/collections/intl-climate-1912/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 15:48:37+00:00



## 'Fortnite' maker Epic Games to pay $520 million in record-breaking FTC settlement
 - [https://www.cnn.com/2022/12/19/tech/fortnite-epic-ftc-settlement/index.html](https://www.cnn.com/2022/12/19/tech/fortnite-epic-ftc-settlement/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 15:47:49+00:00

Epic Games, maker of the hit video game "Fortnite," has agreed to pay a total of $520 million to settle US government allegations that it misled millions of players, including children and teens, into making unintended purchases and that it violated a landmark federal children's privacy law.

## Top Biden adviser's end-of-year memo celebrates president's 'strong jolt of momentum' heading into 2023
 - [https://www.cnn.com/2022/12/19/politics/joe-biden-2023-momentum/index.html](https://www.cnn.com/2022/12/19/politics/joe-biden-2023-momentum/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 15:32:57+00:00

As 2022 comes to a close, President Joe Biden's top adviser Mike Donilon has a rosy outlook on the president's political durability: Biden heads into the new year with a "strong jolt of momentum," he says.

## Tom Cruise thanks fans for supporting 'Top Gun: Maverick' -- while free-falling from a plane
 - [https://www.cnn.com/2022/12/19/entertainment/tom-cruise-skydive-promo-intl-scli/index.html](https://www.cnn.com/2022/12/19/entertainment/tom-cruise-skydive-promo-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 15:32:13+00:00

When it comes to Tom Cruise's daredevil stunts, the sky is literally the limit.

## Five injured after 'severe turbulence' on United Airlines flight into Houston
 - [https://www.cnn.com/travel/article/united-airlines-turbulence-injuries/index.html](https://www.cnn.com/travel/article/united-airlines-turbulence-injuries/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 15:30:09+00:00

Turbulence on a United Airlines flight traveling into Houston Monday morning sent at least five people to the hospital, airport authorities said in an email to CNN.

## World Cup commentator breaks down in tears over Argentina victory
 - [https://www.cnn.com/videos/sports/2022/12/19/argentina-world-cup-win-andres-cantor-reaction-emotional-cnntm-cprog-vpx.cnn](https://www.cnn.com/videos/sports/2022/12/19/argentina-world-cup-win-andres-cantor-reaction-emotional-cnntm-cprog-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 14:54:31+00:00

Andres Cantor, Chief World Cup commentator for Telemundo Deportes, shares what was going through his mind when he broke down in tears after Argentina beat France in a thrilling World Cup final.

## 2 secrets to giving gifts that people will love
 - [https://www.cnn.com/2022/12/19/health/gift-giving-secrets-relationships-wellness/index.html](https://www.cnn.com/2022/12/19/health/gift-giving-secrets-relationships-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 14:38:33+00:00

My family have never been big gift givers, so it might seem ironic that I've discovered two secrets to giving gifts that people will love.

## Doomed exoplanet will eventually spiral right into its host star
 - [https://www.cnn.com/2022/12/19/world/doomed-exoplanet-aging-star-scn/index.html](https://www.cnn.com/2022/12/19/world/doomed-exoplanet-aging-star-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 14:36:45+00:00

Astronomers have come across an exoplanet with a gloomy future, spiraling closer to its host star until eventually it will be obliterated.

## The most beautiful design hotels in the Italian Dolomites
 - [https://www.cnn.com/travel/article/best-design-hotels-in-the-dolomites/index.html](https://www.cnn.com/travel/article/best-design-hotels-in-the-dolomites/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 14:36:01+00:00

Think apple strudel, dumplings and potatoes, ski slopes, forest foraging, mountain views, saunas and uber-chic design hotels.

## See how this principal went viral on TikTok by surprising her students
 - [https://www.cnn.com/videos/us/2022/12/18/school-principal-beth-hoeing-elf-on-the-shelf-cprog-orig-fj.cnn](https://www.cnn.com/videos/us/2022/12/18/school-principal-beth-hoeing-elf-on-the-shelf-cprog-orig-fj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 14:33:03+00:00

This Christmas, Beth Hoeing, the principal of Southwestern Elementary  has surprised her students with her daily "Elf-on-the-Shelf" antics, and gone viral on TikTok in the process.

## 'Freak' wave kills 3 beachgoers and injures 17 in South Africa
 - [https://www.cnn.com/2022/12/19/africa/freak-wave-kills-3-south-africa-intl-scli/index.html](https://www.cnn.com/2022/12/19/africa/freak-wave-kills-3-south-africa-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 14:32:55+00:00

Three beachgoers were killed by a "freak" wave in South Africa's coastal city of Durban on Saturday, according to local emergency medical services (EMS).

## Seeing double: Tiger Woods and son Charlie tee off in perfect symmetry wearing famous Sunday red
 - [https://www.cnn.com/2022/12/19/golf/tiger-charlie-woods-pnc-championship-spt-intl/index.html](https://www.cnn.com/2022/12/19/golf/tiger-charlie-woods-pnc-championship-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 14:14:28+00:00

It might be a rare sighting these days, but golf fans have long grown accustomed to watching Tiger Woods wear red on Sundays.

## Meta faces EU probe over antitrust concerns linked to Facebook Marketplace
 - [https://www.cnn.com/2022/12/19/tech/meta-facebook-marketplace-eu-probe/index.html](https://www.cnn.com/2022/12/19/tech/meta-facebook-marketplace-eu-probe/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 14:09:04+00:00

The European Union is investigating Facebook-parent Meta for possible antitrust violations stemming from the tight link between its core social media service and its online shopping platform, Facebook Marketplace.

## Video shows warship battle strong winds before capsizing
 - [https://www.cnn.com/videos/world/2022/12/19/thailand-royal-navy-warship-sinkage-ovn-contd-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2022/12/19/thailand-royal-navy-warship-sinkage-ovn-contd-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 14:07:12+00:00

A Royal Thai Navy warship sank in severe weather in the Gulf of Thailand, leaving 33 of its crew of 106 sailors missing in stormy seas, Thai authorities said.

## Veteran CNN investigative journalist Drew Griffin dead at 60
 - [https://www.cnn.com/2022/12/19/us/drew-griffin-obit-invs/index.html](https://www.cnn.com/2022/12/19/us/drew-griffin-obit-invs/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 13:08:49+00:00

Drew Griffin, CNN's award-winning Senior Investigative Correspondent, known for getting even the cagiest of interview subjects to engage in a story, died Saturday after a long battle with cancer, his family said. He was 60.

## Why the market is obsessed with unemployment
 - [https://www.cnn.com/2022/12/19/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2022/12/19/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 13:05:53+00:00

As the year comes to a close, it seems that the market's focus on inflation rates are shifting to a new area of concern: Unemployment. While the Federal Reserve has taken steps to fight inflation by curbing economic growth, the full extent of the damage to the employment market is yet to be seen.

## Jan. 6 panel expected to announce referral of multiple criminal charges against Trump
 - [https://www.cnn.com/politics/live-news/jan-6-committee-public-meeting/index.html](https://www.cnn.com/politics/live-news/jan-6-committee-public-meeting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 13:00:26+00:00



## Russian drones attack Kyiv, as Moscow takes another swipe at Ukraine's power grid
 - [https://www.cnn.com/2022/12/19/europe/ukraine-russia-kyiv-drone-strikes-monday-intl/index.html](https://www.cnn.com/2022/12/19/europe/ukraine-russia-kyiv-drone-strikes-monday-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 12:48:34+00:00

At least two people were hurt and key infrastructure has been damaged in a Russian drone assault on the Ukrainian capital Kyiv, the latest attempt by Moscow to ravage Ukraine's power supplies.

## More than 190 countries sign landmark agreement to halt the biodiversity crisis
 - [https://www.cnn.com/2022/12/19/world/cop15-biodiversity-agreement-montreal-climate-scn-intl/index.html](https://www.cnn.com/2022/12/19/world/cop15-biodiversity-agreement-montreal-climate-scn-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 12:46:19+00:00

More than 190 countries have adopted a sweeping agreement to protect nature at the United Nations' biodiversity conference in Montreal.

## 'We don't have to grow the whole animal:' See how lab-grown meat is made
 - [https://www.cnn.com/videos/business-food/2022/12/16/lab-grown-meat-ivy-farm-contd-lon-orig-tp.cnn](https://www.cnn.com/videos/business-food/2022/12/16/lab-grown-meat-ivy-farm-contd-lon-orig-tp.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 12:25:31+00:00

What if you could eat meat without killing or farming animals? Investors in the cultivated meat industry believe this is not only possible but will one day be profitable. CNN visits Ivy Farm Technologies to taste a lab-grown product that their scientists have been developing for years.

## Elon Musk voted out as CEO of Twitter by poll he created
 - [https://www.cnn.com/2022/12/19/tech/elon-musk-twitter-ceo-poll/index.html](https://www.cnn.com/2022/12/19/tech/elon-musk-twitter-ceo-poll/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 12:07:30+00:00

A Twitter poll created by Elon Musk asking whether he should "step down as head of Twitter" ended early Monday morning with most respondents voting in the affirmative.

## Original animatronic 'E.T.' model used in Spielberg classic sells for $2.56 million
 - [https://www.cnn.com/style/article/et-model-auction-intl-scli/index.html](https://www.cnn.com/style/article/et-model-auction-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 11:47:49+00:00

E.T. has a new home.

## What to watch for during the January 6 committee's final session
 - [https://www.cnn.com/collections/intl-jan-6-1912/](https://www.cnn.com/collections/intl-jan-6-1912/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 11:46:18+00:00



## Trial begins for Proud Boys leaders charged with seditious conspiracy
 - [https://www.cnn.com/2022/12/19/politics/proud-boys-seditious-conspiracy-trial/index.html](https://www.cnn.com/2022/12/19/politics/proud-boys-seditious-conspiracy-trial/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 11:02:25+00:00

Leaders of the right-wing extremist Proud Boys will face trial starting Monday for their alleged conspiracy to stop Joe Biden from assuming the presidency, another test for the Justice Department's effort to punish the far-right political movement connected to fierce allies of former President Donald Trump.

## The weird ways destinations tried to get you to visit in 2022
 - [https://www.cnn.com/travel/article/destination-marketing-campaigns-2022/index.html](https://www.cnn.com/travel/article/destination-marketing-campaigns-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 11:01:03+00:00

When they're good, they're iconic. When they're bad -- well, at least you can usually laugh. We're talking destination campaigns -- when travel hotspots make a bid for your hard-earned vacation cash by producing extravagant videos and entire websites to grab your attention.

## UK's controversial plan to deport asylum seekers to Rwanda ruled lawful by court
 - [https://www.cnn.com/2022/12/19/uk/uk-rwanda-policy-ruling-gbr-intl/index.html](https://www.cnn.com/2022/12/19/uk/uk-rwanda-policy-ruling-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 10:58:50+00:00

The UK's controversial policy to deport some asylum seekers to Rwanda was deemed lawful by the country's High Court on Monday.

## Las Vegas Raiders stun New England Patriots on bizarre final play
 - [https://www.cnn.com/2022/12/19/sport/las-vegas-raiders-new-england-patriots-spt-intl/index.html](https://www.cnn.com/2022/12/19/sport/las-vegas-raiders-new-england-patriots-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 10:52:50+00:00

In one of the most bizarre finishes to a NFL game you're ever likely to see, the Las Vegas Raiders beat the New England Patriots 30-24 to keep their slim playoff hopes alive.

## Cyril Ramaphosa re-elected as leader of South Africa's governing African National Congress
 - [https://www.cnn.com/2022/12/19/africa/cyril-ramaphosa-re-election-african-national-congress-intl/index.html](https://www.cnn.com/2022/12/19/africa/cyril-ramaphosa-re-election-african-national-congress-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 10:49:55+00:00

South African President Cyril Ramaphosa has been re-elected leader of the governing African National Congress (ANC) in a party leadership contest, the ANC said on Monday.

## Why do India and China spar at the border?
 - [https://www.cnn.com/videos/world/2022/12/19/india-china-border-dispute-lon-orig-na-mrg.cnn](https://www.cnn.com/videos/world/2022/12/19/india-china-border-dispute-lon-orig-na-mrg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 10:43:16+00:00

Two nuclear powers. One invisible line that separates them, high in the Himalayas. Decades of disputes over it. Here's what you need to know about the contested border between India and China.

## Lab-grown meat could be served up for dinner soon. What does it taste like?
 - [https://www.cnn.com/2022/12/19/business-food/lab-grown-meat-ivy-farm-climate/index.html](https://www.cnn.com/2022/12/19/business-food/lab-grown-meat-ivy-farm-climate/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 10:14:12+00:00

The meatball tastes like meat, an accomplishment in itself.

## China could see nearly a million deaths as it exits zero-Covid, study says
 - [https://www.cnn.com/2022/12/19/china/china-covid-study-one-million-deaths-intl-hnk-mic/index.html](https://www.cnn.com/2022/12/19/china/china-covid-study-one-million-deaths-intl-hnk-mic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 10:06:56+00:00

China's abrupt and under-prepared exit from zero-Covid could lead to nearly 1 million deaths, according to a new study, as the country braces for an unprecedented wave of infections spreading out from its biggest cities to its vast rural areas.

## Zelensky's biggest test yet
 - [https://www.cnn.com/collections/intl-ukraine-1912/](https://www.cnn.com/collections/intl-ukraine-1912/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 09:35:25+00:00



## 'People thought I was crazy:' The Sicilian man upending panettone tradition
 - [https://www.cnn.com/travel/article/fiasconaro-artisanal-panettone-sicily-spc/index.html](https://www.cnn.com/travel/article/fiasconaro-artisanal-panettone-sicily-spc/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 09:33:28+00:00

When thinking of Sicily, it's easy to imagine white sandy beaches, timeless architecture and a host of delicacies like arancini, caponata and cannoli. But panettone would not be among the first things to come to mind.

## Opinion: Zelensky's biggest test yet
 - [https://www.cnn.com/2022/12/19/opinions/volodomyr-zelensky-profile-ukraine-russia-bociurkiw/index.html](https://www.cnn.com/2022/12/19/opinions/volodomyr-zelensky-profile-ukraine-russia-bociurkiw/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 09:28:49+00:00

Less than a year into his term as president of Ukraine, Volodomyr Zelensky's skills as negotiator were put to the test in his first face-to-face meeting with Russian President Vladimir Putin.

## China could see nearly a million deaths as it exits zero-Covid, study says
 - [https://www.cnn.com/collections/intl-china-covid-1912/](https://www.cnn.com/collections/intl-china-covid-1912/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 09:14:18+00:00



## Chinese megacity Chongqing says people with Covid can go to work
 - [https://www.cnn.com/2022/12/19/business/chongqing-china-covid-workers-intl-hnk/index.html](https://www.cnn.com/2022/12/19/business/chongqing-china-covid-workers-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 09:07:49+00:00

The sprawling Chinese metropolis of Chongqing announced Sunday that public sector employees testing positive for Covid-19 can go to work "as normal," a remarkable turnaround for a city that only weeks ago had been in the throes of a mass lockdown.

## This mechanical engineer is building robots to harvest raspberries
 - [https://www.cnn.com/2022/12/19/world/raspberry-harvest-robot-josie-hughes-hnk-spc-intl/index.html](https://www.cnn.com/2022/12/19/world/raspberry-harvest-robot-josie-hughes-hnk-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 07:54:23+00:00

Around 38% of the world's total landmass is used for agriculture -- yet hunger is worsening, and food security is in crisis, threatened by pressures including climate change, conflict and global recessions.

## Freed Russian arms dealer Viktor Bout visits occupied Ukraine
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-12-19-22/h_1cabf2db32a130e8fd85b7a93f1f90c5](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-12-19-22/h_1cabf2db32a130e8fd85b7a93f1f90c5)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 07:40:02.122225+00:00

• One dead in strikes on Russian region near Ukraine

## Ukraine shot down nine Russian drones early Monday as Moscow's forces resumed attacks on Ukraine's capital. This comes after a Russian missile barrage on Friday left many Ukrainians without light, power or heat
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-12-19-22/index.html](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-12-19-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 07:40:02.114583+00:00

• One dead in strikes on Russian region near Ukraine

## 2 injured in Russian drone attacks in Kyiv
 - [https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-12-19-22/index.html](https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-12-19-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 07:40:02.032981+00:00



## Thai warship sinks in severe weather, leaving 33 crew missing
 - [https://www.cnn.com/2022/12/19/asia/thailand-warship-sinks-intl-hnk-ml/index.html](https://www.cnn.com/2022/12/19/asia/thailand-warship-sinks-intl-hnk-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 05:56:26+00:00

A Royal Thai Navy warship sank in severe weather early Monday, leaving 33 of its crew of 106 sailors missing in stormy seas in the Gulf of Thailand, Thai authorities said.

## 5 people killed in a 'horrendous' condo shooting in Canada, police say
 - [https://www.cnn.com/2022/12/18/world/condo-shooting-vaughan-canada/index.html](https://www.cnn.com/2022/12/18/world/condo-shooting-vaughan-canada/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 05:33:31+00:00

Five people were killed in a shooting at a condominium in a Toronto suburb Sunday night, police said.

## Iran's government accesses the social media accounts of those it detains. Tech companies appear ill-equipped to stop it
 - [https://www.cnn.com/2022/12/19/business/iran-social-media-accounts-intl-cmd/index.html](https://www.cnn.com/2022/12/19/business/iran-social-media-accounts-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 05:27:26+00:00

In between being blindfolded, locked in solitary confinement, and interrogated in a wheelchair while she was on a hunger strike following her late September arrest, Negin says she had a realization: Iranian officials were using her private Telegram chats, phone logs and text messages to incriminate her.

## Twitter deletes controversial new policy banning links to other social platforms
 - [https://www.cnn.com/2022/12/19/tech/twitter-elon-musk-deletes-policy/index.html](https://www.cnn.com/2022/12/19/tech/twitter-elon-musk-deletes-policy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 05:08:36+00:00

Twitter deleted its controversial new policy on Sunday evening that had banned links to certain other social media platforms, less than 24 hours after the policy's initial introduction.

## CNN investigation reveals Iranian government is accessing activists' social media accounts
 - [https://www.cnn.com/videos/world/2022/12/18/iran-social-media-hacking-nika-shahkarami-polglase-pkg-intl-vpx.cnn](https://www.cnn.com/videos/world/2022/12/18/iran-social-media-hacking-nika-shahkarami-polglase-pkg-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 05:03:37+00:00

A CNN investigation reveals the Iranian government is accessing the social media accounts of activists to use as evidence against them. Among these activists is Nika Shahkarami, the teenager whose death after the protests turned her into an icon. CNN's Katie Polglase reports.

## Jan. 6 committee expected to wrap up its work with a historic call for Trump's accountability
 - [https://www.cnn.com/2022/12/19/politics/jan-6-committee-investigation-final-session/index.html](https://www.cnn.com/2022/12/19/politics/jan-6-committee-investigation-final-session/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 05:02:58+00:00

The expected move by the January 6 committee to formally ask the Department of Justice to prosecute former President Donald Trump over his role in the US Capitol insurrection will make history, whether or not charges are ever brought.

## Mexico's Islas Marias: from prison to tourist attraction
 - [https://www.cnn.com/travel/article/islas-marias-mexico-tourism/index.html](https://www.cnn.com/travel/article/islas-marias-mexico-tourism/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 04:01:55+00:00

One of Mexico's most notorious prisons begins a new chapter this weekend as a Pacific Ocean getaway after a makeover aimed at bringing in tourists to the former penal colony.

## Pope Francis orders return to Greece of Parthenon sculptures held in Vatican
 - [https://www.cnn.com/style/article/vatican-greece-parthenon-sculptures/index.html](https://www.cnn.com/style/article/vatican-greece-parthenon-sculptures/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 03:40:24+00:00

Pope Francis has decided to return to Greece three 2,500-year-old pieces of the Parthenon that have been in the papal collections of the Vatican Museums for more than a century.

## Peru evacuating tourists from Machu Picchu
 - [https://www.cnn.com/travel/article/peru-machu-picchu-tourists-evacuation-intl-hnk/index.html](https://www.cnn.com/travel/article/peru-machu-picchu-tourists-evacuation-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 03:06:02+00:00

Hundreds of tourists stranded in the ancient city of Machu Picchu are being evacuated after Peru was plunged into a state of emergency following the ousting of the country's president.

## Nepal president gives parties a week to form new government
 - [https://www.cnn.com/2022/12/18/asia/nepal-election-parliament-government-intl-hnk/index.html](https://www.cnn.com/2022/12/18/asia/nepal-election-parliament-government-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 02:41:53+00:00

Nepal's president on Sunday called on the country's political parties to try to form a new government within a week after last month's inconclusive national election.

## January 6 committee report: Your guide to the missing pieces
 - [https://www.cnn.com/videos/politics/2022/12/16/trump-jan-6-criminal-charges-orig-mh.cnn](https://www.cnn.com/videos/politics/2022/12/16/trump-jan-6-criminal-charges-orig-mh.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 02:09:33+00:00

CNN Senior Legal Analyst Elie Honig breaks down the significance of the January 6 committee hearings, and what could happen next as the Department of Justice continues its investigation.

## Musk says he will step down as Twitter CEO if voted out by a poll he tweeted
 - [https://www.cnn.com/2022/12/18/tech/elon-musk-twitter-ceo-poll/index.html](https://www.cnn.com/2022/12/18/tech/elon-musk-twitter-ceo-poll/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 01:53:40+00:00

Twitter's mercurial new boss may be out the door after less than two months on the job, if results of a Twitter poll go against him.

## FTX's Sam Bankman-Fried to drop extradition fight
 - [https://www.cnn.com/2022/12/18/business/sbf-ftx-ceo-bahamas/index.html](https://www.cnn.com/2022/12/18/business/sbf-ftx-ceo-bahamas/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 01:52:24+00:00

Former FTX CEO Sam Bankman-Fried is expected to appear in a Bahamas court on Monday to reverse his decision to contest extradition to the US, a person familiar with the matter told CNN.

## The countdown begins for the 2026 World Cup
 - [https://www.edition.cnn.com/interactive/2022/12/world/the-2026-world-cup-in-numbers/](https://www.edition.cnn.com/interactive/2022/12/world/the-2026-world-cup-in-numbers/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 01:39:07.136759+00:00



## South Korea's middle aged men are dying 'lonely deaths'
 - [https://www.cnn.com/2022/12/18/asia/south-korea-godoksa-lonely-death-intl-hnk-dst/index.html](https://www.cnn.com/2022/12/18/asia/south-korea-godoksa-lonely-death-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 01:19:26+00:00

South Korea has a problem: thousands of people, many middle aged and isolated, are dying alone each year, often going undiscovered for days or weeks.

## Twitter bans links to other social media sites, including Facebook and emerging rivals
 - [https://www.cnn.com/2022/12/18/tech/twitter-ban-social-media-links/index.html](https://www.cnn.com/2022/12/18/tech/twitter-ban-social-media-links/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 01:11:43+00:00

Twitter will ban links to other social media services and suspend accounts that try to direct Twitter users to alternative platforms, the company announced Sunday, in an apparent attempt to stem user defections to competitors.

## At least 36 people injured, some seriously, after 'severe turbulence' on Hawaiian Airlines flight
 - [https://www.cnn.com/2022/12/18/us/hawaiian-airlines-injuries-turbulence/index.html](https://www.cnn.com/2022/12/18/us/hawaiian-airlines-injuries-turbulence/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 01:02:54+00:00

Crew members and passengers on a Hawaiian Airlines flight were injured after their plane encountered "severe turbulence" on a flight from Phoenix to Honolulu on Sunday, authorities said.

## 'How to make applesauce': A photograph that made time stand still
 - [https://www.cnn.com/style/article/harold-edgerton-bullet-apple-snap/index.html](https://www.cnn.com/style/article/harold-edgerton-bullet-apple-snap/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 01:02:49+00:00

Exploding with energy but perfectly still, Harold "Doc" Edgerton's 1964 image of a .30-caliber bullet ripping through an apple showed an otherwise unseeable moment in captivating detail. The scene took on a serene, sculptural beauty as the disintegrating apple's skin burst open against a deep blue backdrop.

## Analysis: Lionel Messi cements his place among the greats after winning epic duel against Kylian Mbappé
 - [https://www.cnn.com/2022/12/18/football/lionel-messi-kylian-mbappe-greatest-world-cup-final-spt-intl/index.html](https://www.cnn.com/2022/12/18/football/lionel-messi-kylian-mbappe-greatest-world-cup-final-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 01:00:50+00:00

Now there can be no arguments. Now there should be no debate.

## Fans in Argentina douse reporter after World Cup win
 - [https://www.cnn.com/videos/sports/2022/12/18/world-cup-argentina-france-buenos-aires-reaction-vpx.cnn](https://www.cnn.com/videos/sports/2022/12/18/world-cup-argentina-france-buenos-aires-reaction-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-12-19 00:55:18+00:00

Argentina has won the 2022 World Cup, beating France via a penalty shootout in one of the most thrilling finals in recent memory. Journalist Stefano Pozzebon is in Buenos Aires with fan reactions.


# Source:CNET, URL:https://www.cnet.com/rss/all/, language:en-US

## iPhone 14 and 14 Pro 3 Months Later: Highs and Lows of Apple's Newest Phones     - CNET
 - [https://www.cnet.com/tech/mobile/iphone-14-and-14-pro-3-months-later-highs-and-lows-of-apples-newest-phones/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/iphone-14-and-14-pro-3-months-later-highs-and-lows-of-apples-newest-phones/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 23:49:20+00:00

We ran in-depth tests on the iPhone 14 line's batteries, cameras and Emergency SOS via Satellite.

## Prime Video: The Absolute Best Sci-Fi TV Shows to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/prime-video-the-absolute-best-sci-fi-tv-shows-to-watch-now/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/prime-video-the-absolute-best-sci-fi-tv-shows-to-watch-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 23:48:34+00:00

These are the very best sci-fi series on Amazon's streaming service.

## Jennifer Coolidge Reacts to SNL Christmas Skit     - CNET
 - [https://www.cnet.com/culture/entertainment/jennifer-coolidge-reacts-to-snl-christmas-skit/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/jennifer-coolidge-reacts-to-snl-christmas-skit/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 23:37:05+00:00

The star dug the recent parody "Jennifer Coolidge Is Impressed by Christmas Stuff."

## Dear Sharks, Steven Spielberg Is Sorry About What 'Jaws' Did to You     - CNET
 - [https://www.cnet.com/culture/entertainment/dear-sharks-steven-spielberg-is-sorry-about-what-jaws-did-to-you/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/dear-sharks-steven-spielberg-is-sorry-about-what-jaws-did-to-you/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 23:31:00+00:00

The global population of sharks and rays declined by more than 71% between 1970 and 2018, a study reports, and Spielberg thinks the film may have contributed.

## More People Need to Watch This Masterful Sci-Fi Series on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/more-people-need-to-watch-this-masterful-sci-fi-series-on-netflix/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/more-people-need-to-watch-this-masterful-sci-fi-series-on-netflix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 23:21:33+00:00

This show is a rare gem glinting in the shadows of Netflix's catacombs.

## Netflix: The 47 Absolute Best Movies to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/netflix-the-47-absolute-best-movies-to-watch-this-evening/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/netflix-the-47-absolute-best-movies-to-watch-this-evening/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 23:19:00+00:00

Two massive movies should tide you over until Christmas: Glass Onion: A Knives Out Mystery and Roald Dahl's Matilda The Musical.

## As We Wait for Student Loan Debt Relief, When Will Payments Start Again?     - CNET
 - [https://www.cnet.com/personal-finance/loans/as-we-wait-for-student-loan-debt-relief-when-will-payments-start-again/#ftag=CADf328eec](https://www.cnet.com/personal-finance/loans/as-we-wait-for-student-loan-debt-relief-when-will-payments-start-again/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 23:18:03+00:00

In February, the Supreme Court will hear challenges to the White House plan to cancel student loan debt.

## Netflix: The 52 Absolute Best TV Shows to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/netflix-the-52-absolute-best-tv-shows-to-stream-now/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/netflix-the-52-absolute-best-tv-shows-to-stream-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 23:07:00+00:00

Two big shows should tide you over until Christmas: Emily in Paris (season 3) and The Witcher: Blood Origin.

## Christmas Shipping Deadlines 2022: When's the Last Day to Send Packages?     - CNET
 - [https://www.cnet.com/how-to/christmas-shipping-deadlines-2022-whens-the-last-day-to-send-packages/#ftag=CADf328eec](https://www.cnet.com/how-to/christmas-shipping-deadlines-2022-whens-the-last-day-to-send-packages/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 23:05:00+00:00

Nobody wants to send late holiday gifts. Here are your drop-dead dates for shipping for Christmas and Kwanzaa.

## These 3 Bizarre Sea Creatures Have Scientists Stumped     - CNET
 - [https://www.cnet.com/science/biology/these-3-bizarre-sea-creatures-have-scientists-stumped/#ftag=CADf328eec](https://www.cnet.com/science/biology/these-3-bizarre-sea-creatures-have-scientists-stumped/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 23:02:09+00:00

Sea spaghetti, weird feathery spheres and an unidentified swimming organism (USO) continue to puzzle researchers.

## This May Be NASA Insight Lander's Final Image From Mars     - CNET
 - [https://www.cnet.com/science/space/this-may-be-nasa-insight-landers-final-image-from-mars/#ftag=CADf328eec](https://www.cnet.com/science/space/this-may-be-nasa-insight-landers-final-image-from-mars/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 22:51:22+00:00

Break out the tissues. InSight's Mars mission is almost at an end.

## More People Need to Watch This Spanish Time Travel Gem on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/more-people-need-to-watch-this-spanish-time-travel-gem-on-netflix/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/more-people-need-to-watch-this-spanish-time-travel-gem-on-netflix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 22:33:46+00:00

The perfect excuse to watch more international cinema.

## NASA DART Mission Might Have Ejected Over 2 Million Pounds of Rock Into Space     - CNET
 - [https://www.cnet.com/science/space/nasa-dart-mission-might-have-ejected-over-2-million-pounds-of-rock-into-space/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-dart-mission-might-have-ejected-over-2-million-pounds-of-rock-into-space/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 22:30:37+00:00

Early results from NASA's ambitious mission offer incredible insight into space-borne wreckage.

## Social Security COLA for 2023: Here's How to Check Your New Increase Amount     - CNET
 - [https://www.cnet.com/personal-finance/social-security-cola-for-2023-heres-how-to-check-your-new-increase-amount/#ftag=CADf328eec](https://www.cnet.com/personal-finance/social-security-cola-for-2023-heres-how-to-check-your-new-increase-amount/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 22:15:02+00:00

Social Security beneficiaries can expect an 8.7% cost-of-living adjustment increase in their benefit amounts next year.

## Synchrony Bank CD Rates for December 2022     - CNET
 - [https://www.cnet.com/personal-finance/banking/synchrony-bank-cd-rates/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/synchrony-bank-cd-rates/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 21:40:00+00:00

With Synchrony CDs, you can earn high APYs (and it has some alternatives to traditional CDs, too).

## More People Need to Watch This Absolutely Riveting Mystery on Prime Video     - CNET
 - [https://www.cnet.com/culture/entertainment/more-people-need-to-watch-this-absolutely-riveting-mystery-on-prime-video/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/more-people-need-to-watch-this-absolutely-riveting-mystery-on-prime-video/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 21:24:00+00:00

It's a whodunit done right.

## You Can Free Up iPhone Storage Without Deleting Anything Important     - CNET
 - [https://www.cnet.com/tech/services-and-software/you-can-free-up-iphone-storage-without-deleting-anything-important/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/you-can-free-up-iphone-storage-without-deleting-anything-important/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 21:18:29+00:00

If you don't want to permanently get rid of your favorite apps, offline movies and text message threads -- you don't have to.

## Social Security Cheat Sheet 2022: Get Your Benefits Questions Answered     - CNET
 - [https://www.cnet.com/personal-finance/social-security-cheat-sheet-2022-get-your-benefits-questions-answered/#ftag=CADf328eec](https://www.cnet.com/personal-finance/social-security-cheat-sheet-2022-get-your-benefits-questions-answered/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 21:15:02+00:00

Got Social Security, Supplemental Security Income or Social Security Disability Insurance questions? We have your answers plus helpful tips and info you didn't know you needed.

## Historic Agreement to Fight Biodiversity Loss Signed at UN Conference     - CNET
 - [https://www.cnet.com/science/climate/historic-agreement-to-fight-biodiversity-loss-signed-at-un-conference/#ftag=CADf328eec](https://www.cnet.com/science/climate/historic-agreement-to-fight-biodiversity-loss-signed-at-un-conference/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 21:06:00+00:00

The agreement aims to protect 30% of land and water important for biodiversity by 2030.

## The Fight Against Biodiversity Loss Gets a Win at UN Conference     - CNET
 - [https://www.cnet.com/science/climate/the-fight-against-biodiversity-loss-gets-a-win-at-un-conference/#ftag=CADf328eec](https://www.cnet.com/science/climate/the-fight-against-biodiversity-loss-gets-a-win-at-un-conference/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 21:06:00+00:00

The agreement aims to protect 30% of land and water important for biodiversity by 2030.

## Scientists Puzzle Over 'Mysterious Shapes' Inside Mars Crater     - CNET
 - [https://www.cnet.com/science/space/scientists-puzzle-over-mysterious-shapes-inside-mars-crater/#ftag=CADf328eec](https://www.cnet.com/science/space/scientists-puzzle-over-mysterious-shapes-inside-mars-crater/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 21:03:00+00:00

But there's a possible explanation for the weirdness spotted in NASA images.

## The Best Soundbars Under $500 video     - CNET
 - [https://www.cnet.com/videos/the-best-soundbars-under-500/#ftag=CADf328eec](https://www.cnet.com/videos/the-best-soundbars-under-500/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 20:53:17+00:00

You can get great sound for your television from as little as $100.

## Dear Sharks, Steven Spielberg Is Sorry About What 'Jaws' Did to Your Kind     - CNET
 - [https://www.cnet.com/culture/entertainment/dear-sharks-steven-spielberg-is-sorry-about-what-jaws-did-to-your-kind/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/dear-sharks-steven-spielberg-is-sorry-about-what-jaws-did-to-your-kind/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 20:48:00+00:00

The global population of sharks and rays declined by more than 71% between 1970 and 2018, a study reports, and Spielberg thinks the film may have contributed.

## If Student Loan Forgiveness Passes, Will You Owe More in Taxes?     - CNET
 - [https://www.cnet.com/personal-finance/taxes/if-student-loan-forgiveness-passes-will-you-owe-more-in-taxes/#ftag=CADf328eec](https://www.cnet.com/personal-finance/taxes/if-student-loan-forgiveness-passes-will-you-owe-more-in-taxes/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 20:30:00+00:00

Widespread forgiveness is on hold, but if it passes, borrowers in several states will face hundreds to thousands in taxes.

## Final Fantasy Pixel Remaster Series Coming to PS4, Switch     - CNET
 - [https://www.cnet.com/tech/gaming/final-fantasy-pixel-remaster-series-coming-to-ps4-switch/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/final-fantasy-pixel-remaster-series-coming-to-ps4-switch/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 20:07:00+00:00

A limited-run physical edition and $260 Anniversary Edition will also be available.

## 6 Tips for Using This Dietary Supplement as an Aid to Fall Asleep     - CNET
 - [https://www.cnet.com/health/sleep/6-tips-on-how-to-use-this-dietary-supplement-as-an-aid-to-fall-asleep/#ftag=CADf328eec](https://www.cnet.com/health/sleep/6-tips-on-how-to-use-this-dietary-supplement-as-an-aid-to-fall-asleep/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 20:00:12+00:00

Interestingly enough, there's research that says GABA can help you fall asleep. Here's what we know.

## The Best PSVR Games to Try On a PS5     - CNET
 - [https://www.cnet.com/tech/gaming/best-psvr-games-to-try-on-a-ps5/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/best-psvr-games-to-try-on-a-ps5/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 20:00:04+00:00

There are some great VR games to try on the PlayStation 5, if you have the right gear.

## How to Read Your Free Credit Report     - CNET
 - [https://www.cnet.com/personal-finance/credit-cards/how-to-read-your-free-credit-report/#ftag=CADf328eec](https://www.cnet.com/personal-finance/credit-cards/how-to-read-your-free-credit-report/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 19:52:00+00:00

It's arguably one of the most important free documents you'll want to understand.

## With These Three Wordle Starter Words It's Hard to Lose     - CNET
 - [https://www.cnet.com/culture/with-these-three-wordle-starter-words-its-hard-to-lose/#ftag=CADf328eec](https://www.cnet.com/culture/with-these-three-wordle-starter-words-its-hard-to-lose/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 19:20:00+00:00

They're like a cheat code.

## 'Avatar: The Way of Water' Ending Explained and Lingering Questions     - CNET
 - [https://www.cnet.com/culture/entertainment/avatar-the-way-of-water-ending-explained-and-lingering-questions/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/avatar-the-way-of-water-ending-explained-and-lingering-questions/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 18:58:00+00:00

James Cameron's visually spectacular Avatar 2 sets up future tales of Pandora and the Na'vi.

## First Planet Spotted By NASA's Pioneering Kepler Telescope Is Doomed     - CNET
 - [https://www.cnet.com/science/space/first-planet-spotted-by-nasas-pioneering-kepler-telescope-is-doomed/#ftag=CADf328eec](https://www.cnet.com/science/space/first-planet-spotted-by-nasas-pioneering-kepler-telescope-is-doomed/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 18:53:00+00:00

It took years to confirm the existence of Kepler-1658b. Now we know its days are numbered.

## These Male Wasps Use Their Genitals to Battle Predators     - CNET
 - [https://www.cnet.com/science/biology/these-male-wasps-use-their-genitals-to-battle-predators/#ftag=CADf328eec](https://www.cnet.com/science/biology/these-male-wasps-use-their-genitals-to-battle-predators/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 18:49:00+00:00

Let this be a warning to hungry tree frogs.

## Fortnite Maker Epic to Pay Record $520 Million Over Child Privacy, In-App Violations     - CNET
 - [https://www.cnet.com/tech/gaming/fortnite-maker-epic-to-pay-record-520-million-over-child-privacy-in-app-violations/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/fortnite-maker-epic-to-pay-record-520-million-over-child-privacy-in-app-violations/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 18:39:08+00:00

The FTC says Epic Games will pay $275 million for violating child privacy rules and $245 to refund users tricked into making in-game purchases.

## The Best Movies on Apple TV Plus     - CNET
 - [https://www.cnet.com/culture/entertainment/the-best-movies-to-catch-on-apple-tv-plus/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-best-movies-to-catch-on-apple-tv-plus/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 18:32:39+00:00

Apple TV Plus has an assortment of options, from dramas to music documentaries and animated movies.

## See Tom Cruise Attempt Death-Defying Stunt in New 'Mission: Impossible' Video     - CNET
 - [https://www.cnet.com/culture/entertainment/see-tom-cruise-attempt-death-defying-stunt-in-new-mission-impossible-video/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/see-tom-cruise-attempt-death-defying-stunt-in-new-mission-impossible-video/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 18:31:00+00:00

"This is far and away the most dangerous thing we've ever attempted," the actor says.

## Super-Cheap Microsoft Office Deal: $30 For Lifetime Use of Word, Excel, More     - CNET
 - [https://www.cnet.com/deals/super-cheap-microsoft-office-deal-30-dollars-for-lifetime-use-of-word-excel-and-more/#ftag=CADf328eec](https://www.cnet.com/deals/super-cheap-microsoft-office-deal-30-dollars-for-lifetime-use-of-word-excel-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 18:15:25+00:00

Only 2 days left to snag this 91% off deal.

## Amazon Fire TV Stick Lite Review: Capable Streamer, Cheap Price     - CNET
 - [https://www.cnet.com/reviews/amazon-fire-tv-stick-lite-review/#ftag=CADf328eec](https://www.cnet.com/reviews/amazon-fire-tv-stick-lite-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 18:01:00+00:00

The first ultrabudget streamer with a voice remote talks circles around Roku.

## Instagram Recap 2022: A New Reels Template Makes It Easy to Customize     - CNET
 - [https://www.cnet.com/news/social-media/instagram-recap-2022-a-new-reels-template-makes-it-easy-to-customize/#ftag=CADf328eec](https://www.cnet.com/news/social-media/instagram-recap-2022-a-new-reels-template-makes-it-easy-to-customize/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 18:00:31+00:00

The feature is yet another addition to the array of popular apps providing a year in review feature to their followers.

## Here's How Much Your Social Security Check Will Increase in January     - CNET
 - [https://www.cnet.com/personal-finance/heres-how-much-your-social-security-check-will-increase-in-january/#ftag=CADf328eec](https://www.cnet.com/personal-finance/heres-how-much-your-social-security-check-will-increase-in-january/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 18:00:20+00:00

The 2023 cost-of-living adjustment is the biggest boost to benefits in over 40 years.

## NASA Eyes 'Mysterious Shapes' Inside Mars Crater     - CNET
 - [https://www.cnet.com/science/space/nasa-spots-mysterious-shapes-inside-mars-crater/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-spots-mysterious-shapes-inside-mars-crater/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 17:59:00+00:00

Scientists are puzzling over some enigmatic Martian formations, but they have a possible explanation.

## Scientists Identify Two Alien Worlds Mostly Composed of Water     - CNET
 - [https://www.cnet.com/science/space/scientists-identify-two-alien-worlds-mostly-composed-of-water/#ftag=CADf328eec](https://www.cnet.com/science/space/scientists-identify-two-alien-worlds-mostly-composed-of-water/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 17:44:00+00:00

Using NASA telescopes, they might have found another exoplanet in its star's habitable zone too.

## 'Oppenheimer' Trailer Introduces Christopher Nolan's Thriller     - CNET
 - [https://www.cnet.com/culture/entertainment/oppenheimer-trailer-introduces-christopher-nolans-thriller/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/oppenheimer-trailer-introduces-christopher-nolans-thriller/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 17:43:00+00:00

The movie about the father of the atomic bomb premieres in theaters next summer.

## Upgrade Your Gaming Setup With Up to 40% Off Monitors, Laptops, PCs and More     - CNET
 - [https://www.cnet.com/deals/upgrade-your-gaming-setup-with-up-to-40-off-monitors-laptops-pcs-and-more/#ftag=CADf328eec](https://www.cnet.com/deals/upgrade-your-gaming-setup-with-up-to-40-off-monitors-laptops-pcs-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 17:41:17+00:00

Right now at Amazon, you can shop a variety of different PC gaming systems and accessories for hundreds off the usual price.

## X1 Credit Card: What Makes It a Smart Credit Card?     - CNET
 - [https://www.cnet.com/personal-finance/credit-cards/x1-credit-card-what-makes-it-smart/#ftag=CADf328eec](https://www.cnet.com/personal-finance/credit-cards/x1-credit-card-what-makes-it-smart/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 17:30:27+00:00

From credit limits to virtual cards, X1 takes a new approach.

## Keep Your Desk Organized With Up to 63% Off Lamicall Device Stands     - CNET
 - [https://www.cnet.com/deals/keep-your-desk-organized-with-up-to-63-off-lamicall-device-stands/#ftag=CADf328eec](https://www.cnet.com/deals/keep-your-desk-organized-with-up-to-63-off-lamicall-device-stands/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 17:30:00+00:00

Right now at Amazon, you can snag a discounted stand or holder for your phone, tablet, laptop, headphones and more.

## Apple TV Plus: Every New TV Show Arriving in December     - CNET
 - [https://www.cnet.com/culture/entertainment/apple-tv-plus-tv-shows-to-watch-in-december-all-week/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/apple-tv-plus-tv-shows-to-watch-in-december-all-week/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 17:29:46+00:00

Here's a complete list of shows coming in December.

## Best Restaurant Gift Cards That Give You Money Back     - CNET
 - [https://www.cnet.com/deals/the-best-restaurant-gift-cards-that-give-you-money-back/#ftag=CADf328eec](https://www.cnet.com/deals/the-best-restaurant-gift-cards-that-give-you-money-back/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 17:00:03+00:00

Stocking stuffers from Chipotle, TGI Fridays and others come with something for the gift-giver, too.

## What the Fusion Energy Breakthrough Really Means     - CNET
 - [https://www.cnet.com/science/what-the-fusion-energy-breakthrough-really-means/#ftag=CADf328eec](https://www.cnet.com/science/what-the-fusion-energy-breakthrough-really-means/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 16:56:00+00:00

This potentially revolutionary power source looks a little bit closer after December's achievement of fusion energy production.

## How to Change Your Wi-Fi Password     - CNET
 - [https://www.cnet.com/how-to/how-to-change-your-wi-fi-password/#ftag=CADf328eec](https://www.cnet.com/how-to/how-to-change-your-wi-fi-password/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 16:40:49+00:00

Keep your home network secure by accessing your settings and changing your Wi-Fi password, no matter what type of router you use.

## Grab a Discounted Ember Smart Mug for the Coffee Aficionado on Your Gift List     - CNET
 - [https://www.cnet.com/deals/grab-a-discounted-ember-smart-mug-for-the-coffee-aficionado-on-your-gift-list/#ftag=CADf328eec](https://www.cnet.com/deals/grab-a-discounted-ember-smart-mug-for-the-coffee-aficionado-on-your-gift-list/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 16:30:00+00:00

These smart mugs keep your drink piping hot for hours, and today only you can pick one up for up to $50 off.

## Monday Night Football: How to Watch, Stream Rams vs. Packers Tonight Without Cable     - CNET
 - [https://www.cnet.com/tech/services-and-software/monday-night-football-how-to-watch-stream-rams-vs-packers-tonight-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/monday-night-football-how-to-watch-stream-rams-vs-packers-tonight-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 16:25:46+00:00

Los Angeles and Green Bay wrap up Week 15 at Lambeau tonight on ESPN.

## No Internet? No Problem. Here's How to Get Wi-Fi Anywhere for Free     - CNET
 - [https://www.cnet.com/how-to/no-internet-no-problem-heres-how-to-get-wi-fi-anywhere-for-free/#ftag=CADf328eec](https://www.cnet.com/how-to/no-internet-no-problem-heres-how-to-get-wi-fi-anywhere-for-free/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 15:41:00+00:00

No matter where you are in the world, it's possible to get a reliable internet connection. Here's how.

## Save Up to 60% On Skin Care, Hair Care and More at Dermstore     - CNET
 - [https://www.cnet.com/deals/save-up-to-60-on-skin-care-hair-care-and-more-at-dermstore/#ftag=CADf328eec](https://www.cnet.com/deals/save-up-to-60-on-skin-care-hair-care-and-more-at-dermstore/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 15:35:56+00:00

Looking for deep discounts on beauty in the New Year? Here's the sale for you.

## 1-Day Best Buy Deal Knocks $55 Off Our Favorite Smart Display for 2022     - CNET
 - [https://www.cnet.com/deals/1-day-best-buy-deal-knocks-55-off-our-favorite-smart-display/#ftag=CADf328eec](https://www.cnet.com/deals/1-day-best-buy-deal-knocks-55-off-our-favorite-smart-display/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 15:32:00+00:00

The second-gen Google Nest Hub is our favorite smart display overall for 2022, and today only it's on sale for just $45.

## Fortnite Maker Epic Games Will Pay Over $500 Million for FTC Complaints     - CNET
 - [https://www.cnet.com/tech/gaming/fortnite-maker-epic-games-will-pay-over-500-million-for-ftc-complaints/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/fortnite-maker-epic-games-will-pay-over-500-million-for-ftc-complaints/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 15:25:00+00:00

The video game maker agreed to pay over allegations it violated children's privacy and tricked gamers into making unwanted purchases.

## Amazon Knocks Up to $119 Off Harry Potter Box Sets Just in Time for Christmas     - CNET
 - [https://www.cnet.com/deals/return-to-hogwarts-anytime-with-119-off-this-4k-uhd-harry-potter-collection/#ftag=CADf328eec](https://www.cnet.com/deals/return-to-hogwarts-anytime-with-119-off-this-4k-uhd-harry-potter-collection/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 15:06:00+00:00

There's no better gift for the Harry Potter fanatic on your list.

## Meta Accused of 'Abusive Practices' by EU Over Facebook Marketplace     - CNET
 - [https://www.cnet.com/news/social-media/meta-accused-of-abusive-practices-by-eu-over-facebook-marketplace/#ftag=CADf328eec](https://www.cnet.com/news/social-media/meta-accused-of-abusive-practices-by-eu-over-facebook-marketplace/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 14:56:00+00:00

The company's marketplace platform is too closely tied to Facebook, according to an EU antitrust investigation.

## Travel in Style With 25% Off American Tourister Luggage Sitewide     - CNET
 - [https://www.cnet.com/deals/travel-in-style-with-25-off-american-tourister-luggage-sitewide/#ftag=CADf328eec](https://www.cnet.com/deals/travel-in-style-with-25-off-american-tourister-luggage-sitewide/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 14:50:00+00:00

Head into the New Year with brand new luggage for all your travel needs.

## 2023 Kia EV6 GT First Drive Review: 576-HP Electric Thrill Ride     - CNET
 - [https://www.cnet.com/roadshow/news/2023-kia-ev6-gt-first-drive-review/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2023-kia-ev6-gt-first-drive-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 14:43:00+00:00

The EV6 GT's great power comes at the cost of some practicality, but for performance like this, that's price I'm willing to pay.

## This AncestryDNA Test Kit Makes a Great Outside-the-Box Gift for Just $49     - CNET
 - [https://www.cnet.com/deals/this-ancestrydna-test-kit-makes-a-great-outside-the-box-gift-for-just-49/#ftag=CADf328eec](https://www.cnet.com/deals/this-ancestrydna-test-kit-makes-a-great-outside-the-box-gift-for-just-49/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 14:34:35+00:00

This DNA test kit can provide someone with detailed information about their ethnicity and genetic makeup, and right now it's $70 off.

## With Prices This Cheap, You Won't Want to Miss Out on These Great Deals at StackSocial     - CNET
 - [https://www.cnet.com/deals/stacksocial-last-minute-holiday-gifts/#ftag=CADf328eec](https://www.cnet.com/deals/stacksocial-last-minute-holiday-gifts/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 14:01:02+00:00

With Cyber Monday now over, these steep discounts will all end as soon.

## OnePlus 11 5G, Buds Pro 2 Are Going to Be Announced in February     - CNET
 - [https://www.cnet.com/tech/mobile/oneplus-11-5g-buds-pro-2-are-going-to-be-announced-in-february/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/oneplus-11-5g-buds-pro-2-are-going-to-be-announced-in-february/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 14:00:19+00:00

Mark your calendars.

## Should You Use a Home Equity Loan to Start a Business?     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/should-you-use-a-home-equity-loan-to-start-a-business/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/should-you-use-a-home-equity-loan-to-start-a-business/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 14:00:16+00:00

Starting a business is a risky venture, so you need to think carefully about leveraging your home to build one.

## Home Chef Is a Valuable and Tasty Gift for Busy Parents     - CNET
 - [https://www.cnet.com/news/home-chef-is-a-valuable-and-tasty-gift-for-busy-parents/#ftag=CADf328eec](https://www.cnet.com/news/home-chef-is-a-valuable-and-tasty-gift-for-busy-parents/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 14:00:12+00:00

I've tried a number of meal kit programs over the years. Home Chef is easy, affordable and delicious.

## Mortgage Refinance Rates on Dec. 19, 2022: Rates Drop Off     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/mortgage-refinance-rates-on-dec-19-2022-rates-drop-off/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/mortgage-refinance-rates-on-dec-19-2022-rates-drop-off/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 14:00:11+00:00

Multiple important refinance rates decreased today. Though refinance rates change daily, experts expect rates to continue to climb.

## Here Are Today's Mortgage Rates on Dec. 19, 2022: Rates Cool Off     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/here-are-todays-mortgage-rates-on-dec-19-2022-rates-cool-off/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/here-are-todays-mortgage-rates-on-dec-19-2022-rates-cool-off/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 14:00:05+00:00

Today a couple of major mortgage rates moved down, though rates remain high compared to earlier this year. As interest rates surge, it's getting more expensive to buy a house.

## These 34 Inexpensive Items Make Great Last-Minute Gift Ideas     - CNET
 - [https://www.cnet.com/deals/34-inexpensive-last-minute-gift-ideas/#ftag=CADf328eec](https://www.cnet.com/deals/34-inexpensive-last-minute-gift-ideas/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 13:53:48+00:00

Finish off your holiday shopping with these cheap extra items.

## Northpointe Bank: 2022 Banking Review     - CNET
 - [https://www.cnet.com/personal-finance/banking/northpointe-bank-banking-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/northpointe-bank-banking-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 13:45:02+00:00

This hybrid regional-online bank, based in Grand Rapids, Michigan, is ideal for people who prefer the convenience of digital banking.

## Best Last-Minute Shopping Deals at Amazon, Best Buy, Walmart and More     - CNET
 - [https://www.cnet.com/deals/best-last-minute-shopping-deals-at-amazon-best-buy-walmart-and-more/#ftag=CADf328eec](https://www.cnet.com/deals/best-last-minute-shopping-deals-at-amazon-best-buy-walmart-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 13:35:00+00:00

Just because you waited doesn't mean you have to miss out.

## Activision Blizzard's President to Join Bored Ape Yacht Club as CEO     - CNET
 - [https://www.cnet.com/culture/activision-blizzards-president-to-join-bored-ape-yacht-club-as-ceo/#ftag=CADf328eec](https://www.cnet.com/culture/activision-blizzards-president-to-join-bored-ape-yacht-club-as-ceo/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 13:05:00+00:00

Daniel Alegre will be coming on board as BAYC creator Yuga Labs ramps up Otherside, a metaverse game being developed for PC and mobile browsers.

## Tesla Buyers Are Bailing Because of Elon Musk, the 'Worst Troll'     - CNET
 - [https://www.cnet.com/tech/tesla-buyers-are-bailing-because-of-elon-musk-the-worst-troll/#ftag=CADf328eec](https://www.cnet.com/tech/tesla-buyers-are-bailing-because-of-elon-musk-the-worst-troll/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 13:00:23+00:00

Tesla salespeople say "a lot" of customers canceling orders blame Musk's Twitter behavior.

## CNET's Best Games of 2022 (That Aren't Elden Ring)     - CNET
 - [https://www.cnet.com/tech/gaming/cnets-best-games-of-2022-that-arent-elden-ring/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/cnets-best-games-of-2022-that-arent-elden-ring/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 13:00:20+00:00

Elden Ring dominated 2022's gaming scene, but there are plenty of other titles that deserve your time and praise.

## OnePlus Nord N300 Review: $228 Phone Looks Sweet, Feels Cheap     - CNET
 - [https://www.cnet.com/tech/mobile/oneplus-nord-n300-review-228-phone-looks-sweet-feels-cheap/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/oneplus-nord-n300-review-228-phone-looks-sweet-feels-cheap/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 13:00:16+00:00

A flashy design dresses up this lower-priced phone.

## 10 Fun and Festive Amazon Alexa Features to Try This Christmas     - CNET
 - [https://www.cnet.com/how-to/10-fun-and-festive-amazon-alexa-features-to-try-this-christmas/#ftag=CADf328eec](https://www.cnet.com/how-to/10-fun-and-festive-amazon-alexa-features-to-try-this-christmas/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 13:00:03+00:00

Your Amazon Echo device can spread holiday cheer.

## Top Smartwatches and Wearables of the Year video     - CNET
 - [https://www.cnet.com/videos/top-smartwatches-and-wearables-of-the-year/#ftag=CADf328eec](https://www.cnet.com/videos/top-smartwatches-and-wearables-of-the-year/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 13:00:01+00:00

Looking for the best smartwatch out there? Here are our top wearable picks, including the Apple Watch, Pixel Watch, Galaxy Watch, Fitbit and many more.

## Wearing the Apple Watch Ultra Convinced Me It's Not Just for Athletes     - CNET
 - [https://www.cnet.com/tech/mobile/the-apple-watch-ultras-best-features-arent-just-for-athletes/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/the-apple-watch-ultras-best-features-arent-just-for-athletes/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 12:00:35+00:00

Commentary: You'll appreciate the Apple Watch Ultra's long battery life and Action button whether you're an athlete or not.

## Your iOS Passwords Might Be at Risk. Here's How to Secure Them     - CNET
 - [https://www.cnet.com/tech/services-and-software/your-ios-passwords-might-be-at-risk-heres-how-to-secure-them/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/your-ios-passwords-might-be-at-risk-heres-how-to-secure-them/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 12:00:23+00:00

Change these password settings on your Apple device to stay protected online.

## 6 Science-Backed Ways Gratitude Improves Your Mental Health and How to Get Started     - CNET
 - [https://www.cnet.com/health/mental/6-science-backed-ways-gratitude-improves-your-mental-health-and-how-to-get-started/#ftag=CADf328eec](https://www.cnet.com/health/mental/6-science-backed-ways-gratitude-improves-your-mental-health-and-how-to-get-started/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 12:00:16+00:00

Want to be happier? Gratitude is the attitude.

## Dry Skin During the Winter? Eat These 9 Foods     - CNET
 - [https://www.cnet.com/health/nutrition/dry-skin-during-the-winter-eat-these-9-foods/#ftag=CADf328eec](https://www.cnet.com/health/nutrition/dry-skin-during-the-winter-eat-these-9-foods/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 12:00:11+00:00

Take care of your skin this winter by adding these foods to your diet.

## Live TV Streaming Services: A List of the Top 100 Channels     - CNET
 - [https://www.cnet.com/tech/services-and-software/live-tv-streaming-services-list-top-100-channels/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/live-tv-streaming-services-list-top-100-channels/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 12:00:04+00:00

Hulu Live TV, Sling TV and YouTube TV are among the services we assess in this channel breakdown.

## Microsoft Office 2021 Lifetime License Is Down to $30 (a 91% Discount) for 2 More Days     - CNET
 - [https://www.cnet.com/deals/microsoft-office-2021-lifetime-license-down-to-30-two-more-days/#ftag=CADf328eec](https://www.cnet.com/deals/microsoft-office-2021-lifetime-license-down-to-30-two-more-days/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 11:43:11+00:00

This extremely popular deal is almost over, so be sure to get in while you still can.

## Best Buy's Last-Minute Sale Is Your Final Chance to Score Christmas Gifts at a Huge Discount     - CNET
 - [https://www.cnet.com/deals/best-buy-last-minute-sales-event/#ftag=CADf328eec](https://www.cnet.com/deals/best-buy-last-minute-sales-event/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 11:19:00+00:00

It's Christmas week and Best Buy's latest sale is giving one one more chance to score some deals.

## Today Is the Last Chance to Claim Money From DirecTV's $17 Million Robocall Settlement     - CNET
 - [https://www.cnet.com/personal-finance/today-is-your-last-chance-to-claim-money-from-directvs-17-million-robocall-settlement/#ftag=CADf328eec](https://www.cnet.com/personal-finance/today-is-your-last-chance-to-claim-money-from-directvs-17-million-robocall-settlement/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 11:00:16+00:00

If you qualify, you could receive more than $600 from the satellite TV company.

## 'Avatar: The Way of Water' Ending Explained, Unanswered Questions     - CNET
 - [https://www.cnet.com/culture/entertainment/avatar-the-way-of-water-ending-explained-unanswered-questions/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/avatar-the-way-of-water-ending-explained-unanswered-questions/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 01:00:03+00:00

James Cameron's visually spectacular Avatar 2 sets up future tales of Pandora and the Na'vi.

## Black Adam: Post-Credits Scene, Misleading DC Cameo Explained as Movie Lands on HBO Max     - CNET
 - [https://www.cnet.com/culture/entertainment/black-adam-post-credits-scene-misleading-dc-cameo-explained-as-movie-lands-on-hbo-max/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/black-adam-post-credits-scene-misleading-dc-cameo-explained-as-movie-lands-on-hbo-max/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-12-19 00:30:03+00:00

Dwayne Johnson's antihero adventure hits HBO's streaming service, and his encounter with the most powerful being in DC's cinematic universe has a different vibe now.


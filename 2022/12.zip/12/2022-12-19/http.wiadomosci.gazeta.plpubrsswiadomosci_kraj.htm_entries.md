# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## "Eksplozja prezentu". Gen. Szymczyk dziękuje szefowi MSWiA i czuje się pokrzywdzony
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29281475,eksplozja-prezentu-gen-szymczyk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29281475,eksplozja-prezentu-gen-szymczyk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 21:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/db/ec/1b/z29281499M,Gen--Jaroslaw-Szymczyk-w-TVP-Info---Czuje-sie-pokr.jpg" vspace="2" />- Doszło do zdarzenia, które z całą pewnością zaistnieć nie powinno i które trzeba dokładnie i wnikliwie wyjaśnić - mówił komendant główny policji. Gen. Jarosław Szymczyk podkreślił w poniedziałkowym wydaniu "Gościa Wiadomości" w TVP, że czuje się pokrzywdzony tą sytuacją.

## Nowe doniesienia ws. wybuchu paczki w Siecieborzycach. "Będzie to szło w kierunku usiłowania zabójstwa"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29280727,nowe-doniesienia-ws-wybuchu-paczki-w-siecieborzycach-bedzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29280727,nowe-doniesienia-ws-wybuchu-paczki-w-siecieborzycach-bedzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 15:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5c/ec/1b/z29280860M,Policja---zdjecie-ilustracyjne.jpg" vspace="2" />Pojawiły się nowe doniesienia dotyvzące wybuchu paczki w Siecieborzycach w województwie lubuskim. Nieoficjalnie śledczy podają, że postępowanie będzie zmierzało w kierunku usiłowania zabójstwa. W wyniku eksplozji ranne zostały trzy osoby: matka i jej dwoje dzieci.

## Wiceburmistrz Cieszyna porównał premiera do nazistów. Jest wyrok sądu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29280075,wiceburmistrz-cieszyna-porownal-premiera-do-nazistow-jest-wyrok.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29280075,wiceburmistrz-cieszyna-porownal-premiera-do-nazistow-jest-wyrok.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 15:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/26/cc/1b/z29151014M,sad--wyrok---zdjecie-ilustracyjne--.jpg" vspace="2" />Straż Graniczna, MON, MSWiA i Prezes Rady Ministrów - zniesławienia tych organów państwa jest winny wiceburmistrz Cieszyna. Wyrok wydał Sąd Rejonowy w Cieszynie w województwie śląskim, który jednocześnie umorzył na rok sprawę samorządowca Przemysława Majora.

## Wrocław. Pożar w siedzibie Komendy Wojewódzkiej Policji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29280551,wroclaw-pozar-w-siedzibie-komendy-wojewodzkiej-policji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29280551,wroclaw-pozar-w-siedzibie-komendy-wojewodzkiej-policji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 14:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/82/1b/z28845911M,Pilne.jpg" vspace="2" />Pożar w siedzibie Komendy Wojewódzkiej Policji we Wrocławiu. Na miejscu pracuje kilkanaście jednostek straży pożarnej.

## Warszawa. Jest prawomocny wyrok ws. "dilera gwiazd". Sąd odrzucił apelacje
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279618,warszawa-jest-prawomocny-wyrok-ws-dilera-gwiazd-sad-odrzucil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279618,warszawa-jest-prawomocny-wyrok-ws-dilera-gwiazd-sad-odrzucil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 13:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/31/79/16/z23567409M,Diler-gwiazd.jpg" vspace="2" />Sąd Okręgowy Warszawa-Praga odrzucił apelacje zarówno obrońców Cezarego P., zwanego "dilerem gwiazd", jak i prokuratora. Tym samym utrzymany został wyrok sądu pierwszej instancji, czyli sześciu lat bezwzględnego pozbawienia wolności. Wyrok jest prawomocny.

## Poznań. Parafia buduje restaurację na dawnym cmentarzu. "Kilka miesięcy temu znaleziono mnóstwo kości"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279605,poznan-parafia-buduje-restauracje-na-dawnym-cmentarzu-kilka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279605,poznan-parafia-buduje-restauracje-na-dawnym-cmentarzu-kilka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 13:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9d/ec/1b/z29279901M,Parafia-pod-wezwaniem-sw--Jana-Jerozolimskiego-za-.jpg" vspace="2" />Parafia z Poznania zrobiła restaurację na terenie starego cmentarza, gdzie grzebano polskich powstańców. Prace na tym obszarze wykonano bez poprzedzających ich badań archeologicznych i bez pozwolenia urzędu. W sprawie tej powiadomiono już prokuraturę. Nieoficjalnie śledczy mają sprawdzić, czy doszło do zbezczeszczenia szczątków.

## Stalowa Wola: pijana 22-latka wiozła trzyletnią córkę. "W trakcie interwencji była wulgarna i agresywna"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279738,stalowa-wola-pijana-22-latka-wiozla-trzyletnia-corke-w-trakcie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279738,stalowa-wola-pijana-22-latka-wiozla-trzyletnia-corke-w-trakcie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 13:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/86/ec/1b/z29279878M,Zdjecie-ilustracyjne.jpg" vspace="2" />Pięć lat więzienia grozi 22-letniej kobiecie, która wiozła autem po pijanemu swoją trzyletnią córkę. Policję wezwał inny kierowca, który zwrócił uwagę, że kobieta ma problem z utrzymaniem na drodze prostego toru jazdy.

## MSWiA zdecydowanie o dymisji gen. Jarosława Szymczyka. Kamiński rozwiał wątpliwości
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279797,mswia-zdecydowanie-o-dymisji-komendanta-glownego-policji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279797,mswia-zdecydowanie-o-dymisji-komendanta-glownego-policji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 13:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/5c/1b/z28688418M,Minister-Spraw-Wewnetrznych-i-Administracji-Marius.jpg" vspace="2" />"Wykluczam dymisję Komendanta Głównego Policji" - napisał minister spraw wewnętrznych i administracji. Mariusz Kamiński zapowiedział też wizytę swojego odpowiednika z Ukrainy ws. incydentu z udziałem gen. Jarosława Szymczyka.

## Nieoficjalnie: W tym tygodniu dymisja gen. Szymczyka. "Decyzja wymuszona politycznie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279400,nieoficjalnie-w-tym-tygodniu-dymisja-gen-szymczyka-decyzja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279400,nieoficjalnie-w-tym-tygodniu-dymisja-gen-szymczyka-decyzja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 12:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1b/eb/1b/z29274907M,Komendant-glowny-policji-Jaroslaw-Szymczyk.jpg" vspace="2" />W tym tygodniu gen. Jarosław Szymczyk ma podać się do dymisji - podaje Onet, powołując się na swoje źródła. Portal podkreśla, że "decyzja ta została wymuszona politycznie". Jest też nazwisko potencjalnego kandydata na stanowisko komendanta głównego policji.

## Wielkopolska. Zwłoki mężczyzny w lesie. Nieoficjalnie: To skazany za pedofilię niedoszły ksiądz
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279153,wielkopolska-zwloki-mezczyzny-w-lesie-nieoficjalnie-to-skazany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29279153,wielkopolska-zwloki-mezczyzny-w-lesie-nieoficjalnie-to-skazany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 11:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/67/62/1a/z27664487M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />W wielkopolskim lesie znaleziono w zeszłym tygodniu zwłoki mężczyzny w średnim wieku. Z nieoficjalnych ustaleń lokalnych mediów wynika, że to mężczyzna dopiero co skazany za pedofilię, który miał trafić do więzienia. Wcześniej Mikołaj T. chciał zostać księdzem i być wychowawcą w przedszkolu.

## Wybuch w KGP. Prof. Ćwiąkalski o gen. Szymczyku: Inna osoba usłyszałaby zarzuty. Tutaj może dojść do umorzenia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278757,wybuch-w-kgp-prof-cwiakalski-o-szymczyku-inna-osoba-uslyszalaby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278757,wybuch-w-kgp-prof-cwiakalski-o-szymczyku-inna-osoba-uslyszalaby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 11:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/74/ea/1b/z29273460M,Gen--insp--Jaroslaw-Szymczyk--Zdjecie-ilustracyjne.jpg" vspace="2" />- Gdyby to była inna osoba, a nie komendant główny policji powołany przez obecną władzę, to na pewno zarzuty prokuratorskie by się pojawiły. (...) Biorąc pod uwagę doświadczenia w innych sprawach, istnieje prawdopodobieństwo, że i ta zostanie umorzona - tak o wybuchu w KGP mówi w rozmowie z Gazeta.pl były minister sprawiedliwości prof. Zbigniew Ćwiąkalski. Jak ocenia prawnik, gen. insp. Jarosław Szymczyk mógł naruszyć przepisy. Sam gen. Szymczyk podkreśla w rozmowie z "Rzeczpospolitą", że występuje jako osoba pokrzywdzona i "w pełni oddaje się do dyspozycji prokuratury".

## Barbara Nowak i jej kolejny wyskok. Pyta radnych lewicy, czy planują mordować księży i więzić katolików
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278444,barbara-nowak-i-jej-kolejny-wyskok-pyta-radnych-lewicy-czy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278444,barbara-nowak-i-jej-kolejny-wyskok-pyta-radnych-lewicy-czy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 11:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d8/6c/1b/z28756696M.jpg" vspace="2" />Małopolska kuratora oświaty Barbara Nowak w awanturniczy i oburzający sposób komentuje decyzję dotyczącą zaprzestania finansowania lekcji religii, jaka zapadła w Częstochowie - nad podobną uchwałą myśli także Kraków. Nowak pyta "lewackich radnych", czy chcą wrócić do mordowania księży i niszczenia kościołów.

## Próby samobójcze i przemoc ze strony bliskich. Wstrząsający raport fundacji Dajemy Dzieciom Siłę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278641,proby-samobojcze-i-przemoc-ze-strony-bliskich-wstrzasajacy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278641,proby-samobojcze-i-przemoc-ze-strony-bliskich-wstrzasajacy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 10:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d3/30/1b/z28511699M,Przemoc-domowa---zdjecie-ilustracyjne.jpg" vspace="2" />Fundacja Dajemy Dzieciom Siłę opublikowała raport "Dzieci się liczą 2022", z którego wynika, że 41 proc. dzieci doświadcza przemocy ze strony bliskich dorosłych, a 57 proc. ze strony rówieśników. W 2021 roku policja odnotowała prawie 1,5 tys. prób samobójczych popełnionych przez osoby poniżej 19. roku życia. 127 z nich zakończyło się śmiercią.

## Wizyta duszpasterska 2023. Czy trzeba przyjmować księdza po kolędzie?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278311,wizyta-duszpasterska-2023-czy-trzeba-przyjmowac-ksiedza-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278311,wizyta-duszpasterska-2023-czy-trzeba-przyjmowac-ksiedza-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 10:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2b/ec/1b/z29278507M,Wizyta-duszpasterska---zdjecie-archiwalne.jpg" vspace="2" />Po Bożym Narodzeniu rozpoczną się wizyty duszpasterskie w domach wiernych. Z powodu pandemii koronawirusa przez ostatnie dwa lata kolęda nie odbywała się na normalnych zasadach. Jak sytuacja będzie wyglądała w 2023 roku? Czy według prawa kanonicznego mamy obowiązek przyjmowania księży po kolędzie?

## Lubuskie. Wybuch paczki pozostawionej przed domem. 31-letnia matka i córka są w stanie ciężkim
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278685,lubuskie-wybuch-paczki-pozostawionej-przed-domem-31-letnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278685,lubuskie-wybuch-paczki-pozostawionej-przed-domem-31-letnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 10:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9c/81/1b/z28843676M,Helikopter-LPR--zdjecie-ilustracyjne-.jpg" vspace="2" />W Siecioborzycach doszło do wybuchu paczki, która została pozostawiona przed jednym z domów jednorodzinnym. Podczas otwierania doszło do eksplozji, w wyniku czego ranne zostały trzy osoby, w tym dwójka dzieci.

## Mróz w Polsce. Najzimniej było w Terespolu. Przy gruncie odnotowano -26 stopni Celsjusza
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278309,mroz-w-polsce-najzimniej-bylo-w-terespolu-przy-gruncie-odnotowano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278309,mroz-w-polsce-najzimniej-bylo-w-terespolu-przy-gruncie-odnotowano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 09:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e2/80/19/z26742498M,Mroz--zdjecie-ilustracyjne-.jpg" vspace="2" />W poniedziałek (19 grudnia) rano najzimniej było na wschodzie Polski. Wartości przy gruncie spadły aż do -26 stopni Celsjusza. Według synoptyków mróz w najbliższym czasie jednak odpuści.

## Pogoda. Zawieje, zamiecie i gołoledź. Synoptycy IMGW wydali żółte i pomarańczowe ostrzeżenia [MAPA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278219,pogoda-zawieje-zamiecie-i-gololedz-synoptycy-imgw-wydali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278219,pogoda-zawieje-zamiecie-i-gololedz-synoptycy-imgw-wydali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 09:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b7/ec/1b/z29278391M,zawieje---zdjecie-ilustracyjne.jpg" vspace="2" />Obecny w ostatnich dniach wyż powoli odsuwa się na wschód. Tym samym do Polski już od poniedziałku zaczną napływać niże atlantyckie. W związku z silnym wiatrem i marznącymi opadami IMGW wydało ostrzeżenia dla zachodniej części naszego kraju.

## Biała Podlaska. Niezwykłe zjawisko zaskoczyło mieszkańców. Z nieba leciał diamentowy pył
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278006,biala-podlaska-niezwykle-zjawisko-zaskoczylo-mieszkancow-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278006,biala-podlaska-niezwykle-zjawisko-zaskoczylo-mieszkancow-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 09:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5a/ec/1b/z29278298M,W-Bialej-Podlaskiej-pojawil-sie-diamentowy-pyl.jpg" vspace="2" />W Białej Podlaskiej zaobserwowano niezwykłe zjawisko meteorologiczne. 18 grudnia mieszkańcy mogli podziwiać pył diamentowy, który unosił się nad miastem.

## Wybuch w KGP. Gen. Szymczyk: Mam duże wątpliwości, czy była to czyjaś pomyłka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278076,wybuch-w-kgp-gen-szymczyk-mam-duze-watpliwosci-czy-byla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29278076,wybuch-w-kgp-gen-szymczyk-mam-duze-watpliwosci-czy-byla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 09:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/51/ea/1b/z29270865M,Komendant-Glowny-Policji-Jaroslaw-Szymczyk--Listop.jpg" vspace="2" />- W tej sprawie mam duże wątpliwości, czy była to czyjaś pomyłka - powiedział gen. Jarosław Szymczyk w rozmowie z "Rzeczpospolitą", komentując wybuch granatnika w KGP. - Jest wiele powodów, dla których ktoś mógł chcieć albo zdyskredytować mnie, albo zrobić mi krzywdę, lub zniszczyć relacje służb polsko-ukraińskich - dodał szef polskiej policji.

## Pendolino z Kołobrzegu zamarzło na peronie? Media: Wcześniej opóźniony pociąg potrącił człowieka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29277903,pociag-z-kolobrzegu-zamarzl-na-peronie-media-wczesniej-opoznione.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29277903,pociag-z-kolobrzegu-zamarzl-na-peronie-media-wczesniej-opoznione.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 09:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/15/ec/1b/z29278229M,Pendolino--zdjecie-ilustracyjne-.jpg" vspace="2" />Kołobrzeski portal opisał problemy, z jakimi w ostatnich dniach zmagali się pasażerowie podróżujący na trasie Kołobrzeg - Kraków Główny. Nie dość, że mróz i śnieg sprawia przewoźnikom duże problemy, to w piątek opóźnienie wzrosło także ze względu na potrącenie człowieka przez pendolino.

## Polacy chcą dymisji gen. Szymczyka. Wybuch granatnika w KGP zjednoczył wyborców PiS i opozycji [SONDAŻ]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29277784,polacy-chca-dymisji-gen-szymczyka-wybuch-granatnika-w-kgp.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29277784,polacy-chca-dymisji-gen-szymczyka-wybuch-granatnika-w-kgp.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 07:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/54/20/13/z20057172M,Jaroslaw-Szymczyk.jpg" vspace="2" />Aż 80 proc. badanych chce, aby gen. Jarosław Szymczyk stracił swoje stanowisko - wynika z sondażu United Surveys dla Wirtualnej Polski. Za takim rozwiązaniem opowiadają się zarówno wyborcy PiS, jak i sympatycy opozycji. To pokłosie wybuchu granatnika w Komendzie Głównej Policji.

## Granatnik w KGP. Brejza interweniuje w prokuraturze. Przypomina o "złamanej płycie DVD" ws. kierowcy seicento
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29277729,granatnik-w-kgp-brejza-interweniuje-w-prokuraturze-przypomina.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29277729,granatnik-w-kgp-brejza-interweniuje-w-prokuraturze-przypomina.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 07:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1d/eb/1b/z29274909M,Senator-Krzysztof-Brejza.jpg" vspace="2" />Krzysztof Brejza skierował interwencję do Prokuratury Krajowej ws. wybuchu w Komendzie Głównej Policji. Senator KO zapytał w niej m.in. o nagranie z monitoringu oraz jego odpowiednie zabezpieczenie. Polityk przedstawił również "krótką historię granatnika".

## "Ostatnie noce są tam ciche. Oglądam je przez ekran smartfona i płaczę"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29256651,ostatnie-noce-sa-tam-ciche-ogladam-je-przez-ekran-smartfona.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29256651,ostatnie-noce-sa-tam-ciche-ogladam-je-przez-ekran-smartfona.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-19 05:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/73/e7/1b/z29260403M,To-pierwsze-swieta-ukrainskich-uchodzcow-w-Polsce.jpg" vspace="2" />Kalina chciała wrócić do domu na święta, ale mama błagała, by tego nie robiła. Ksenia domu już nie ma. Maria ma, ale nie wierzy, że powrót będzie kiedykolwiek możliwy. Uchodźczynie z Enerhodaru spędzą pierwsze święta w Polsce.


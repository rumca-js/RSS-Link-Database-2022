# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## France World Cup squad welcomed home by thousands after heroic defeat
 - [https://news.sky.com/story/world-cup-french-football-team-welcomed-home-after-heroic-defeat-against-argentina-12771670](https://news.sky.com/story/world-cup-french-football-team-welcomed-home-after-heroic-defeat-against-argentina-12771670)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 21:35:00+00:00

The French World Cup squad has been welcomed home by thousands of football fans following their dramatic defeat against Argentina.

## Donald Trump should face criminal charges over Capitol riots, January 6 committee recommends
 - [https://news.sky.com/story/january-6-committee-recommends-criminal-charges-against-donald-trump-12771623](https://news.sky.com/story/january-6-committee-recommends-criminal-charges-against-donald-trump-12771623)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 19:14:00+00:00

The committee investigating the January 6 storming of the US Capitol is recommending criminal charges against former President Donald Trump.

## 'This is hell': British volunteer describes danger of carrying out evacuations in Ukraine
 - [https://news.sky.com/story/british-volunteer-evacuating-most-vulnerable-from-hell-has-vehicle-targeted-by-russian-tank-12771547](https://news.sky.com/story/british-volunteer-evacuating-most-vulnerable-from-hell-has-vehicle-targeted-by-russian-tank-12771547)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 16:49:00+00:00

A British man carrying out evacuations in Ukraine has said his 4x4 vehicle was hit by a Russian tank round and is now written-off.

## Crematoriums guarded by police as China fights to hide true toll of failed zero-COVID policy
 - [https://news.sky.com/story/crematoriums-guarded-by-police-as-china-fights-to-hide-true-toll-of-failed-zero-covid-policy-12771420](https://news.sky.com/story/crematoriums-guarded-by-police-as-china-fights-to-hide-true-toll-of-failed-zero-covid-policy-12771420)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 13:31:00+00:00

Even first thing in the morning the crematoriums were burning in Beijing. Plumes of smoke against the cold blue sky.

## International Affairs - the Year in Review with Dominic Waghorn
 - [https://news.sky.com/story/sky-news-daily-international-affairs-the-year-in-review-with-dominic-waghorn-12771313](https://news.sky.com/story/sky-news-daily-international-affairs-the-year-in-review-with-dominic-waghorn-12771313)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 11:00:00+00:00

Host Niall Paterson looks at the international stories which defined 2022.

## Deal struck to 'protect' third of the planet by 2030
 - [https://news.sky.com/story/cop-15-delegates-agree-to-protect-30-per-cent-of-the-world-by-2030-12771245](https://news.sky.com/story/cop-15-delegates-agree-to-protect-30-per-cent-of-the-world-by-2030-12771245)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 09:57:00+00:00

Nearly a third of the planet will be "protected" by 2030 under a new deal struck at the UN's COP15 biodiversity summit.

## In pictures: Argentina celebrates as Messi joins Maradona in bringing home World Cup
 - [https://news.sky.com/story/in-pictures-argentina-celebrates-as-messi-joins-maradona-in-bringing-home-world-cup-12771242](https://news.sky.com/story/in-pictures-argentina-celebrates-as-messi-joins-maradona-in-bringing-home-world-cup-12771242)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 09:34:00+00:00

Millions of Argentinians breathed a collective sigh of relief after their side's dramatic World Cup win - before letting loose on the streets of Buenos Aires in celebration.

## Arctic blast to bring temperatures of -15C to US in run-up to Xmas
 - [https://news.sky.com/story/us-weather-arctic-blast-to-bring-temperatures-of-15c-in-run-up-to-christmas-12771187](https://news.sky.com/story/us-weather-arctic-blast-to-bring-temperatures-of-15c-in-run-up-to-christmas-12771187)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 09:22:00+00:00

Temperatures as low as -15C (12F) are set to bring arctic conditions to large parts of the US in the run-up to Christmas, forecasters have warned.

## War, drought, protest and prime ministers: The most striking images from a tumultuous year
 - [https://news.sky.com/story/war-drought-protest-and-prime-ministers-the-most-striking-images-from-a-tumultuous-year-12771145](https://news.sky.com/story/war-drought-protest-and-prime-ministers-the-most-striking-images-from-a-tumultuous-year-12771145)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 08:12:00+00:00

A war in Europe, the death of the Queen, record heatwaves and flooding, protests around the world and three prime ministers... it's been quite a year.

## Elon Musk to quit as Twitter boss - if he abides by poll he launched himself
 - [https://news.sky.com/story/elon-musk-to-quit-as-twitter-boss-if-he-abides-by-poll-he-launched-himself-12771138](https://news.sky.com/story/elon-musk-to-quit-as-twitter-boss-if-he-abides-by-poll-he-launched-himself-12771138)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 07:49:00+00:00

Elon Musk will step down as Twitter boss - if he stands by his pledge to abide by the results of a poll asking users for their verdict on his tenure.

## Rescue operation after Thai navy ship sinks off the coast
 - [https://news.sky.com/story/rescue-operation-after-thai-navy-ship-sinks-off-the-coast-12771079](https://news.sky.com/story/rescue-operation-after-thai-navy-ship-sinks-off-the-coast-12771079)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 04:56:00+00:00

More than 70 sailors have been rescued in the Gulf of Thailand after one of the country's naval vessels was hit by strong winds.

## Argentina celebrates World Cup win through the night after 'one of the best games of all time'
 - [https://news.sky.com/story/qatar-world-cup-argentina-celebrate-through-the-night-after-one-of-the-best-games-of-all-time-12771066](https://news.sky.com/story/qatar-world-cup-argentina-celebrate-through-the-night-after-one-of-the-best-games-of-all-time-12771066)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 03:17:00+00:00

Argentinian fans have been celebrating through the night after their team won the World Cup in what some commentators have described as one of the best games in the history of the tournament.

## Eleven people seriously injured after turbulence on Hawaiian Airlines flight
 - [https://news.sky.com/story/eleven-people-seriously-injured-after-turbulence-on-hawaiian-airlines-flight-12771050](https://news.sky.com/story/eleven-people-seriously-injured-after-turbulence-on-hawaiian-airlines-flight-12771050)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-19 00:26:00+00:00

Eleven people have been seriously injured during turbulence on a Hawaiian Airlines flight.


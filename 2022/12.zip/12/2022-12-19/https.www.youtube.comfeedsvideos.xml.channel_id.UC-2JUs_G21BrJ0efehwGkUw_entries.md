# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Kiss Me | Sixpence None The Richer | funk cover ft. Moira Mack
 - [https://www.youtube.com/watch?v=XtqlesJs-aU](https://www.youtube.com/watch?v=XtqlesJs-aU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-12-19 00:00:00+00:00

Get tickets to see us on tour!  https://www.scarypocketsfunk.com

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Sixpence None The Richer's "Kiss Me" by Scary Pockets & Moira Mack.

MUSICIAN CREDITS
Lead vocal: Moira Mack
Drums: RJ Kelly
Bass: Travis Carlton
Organ: Peter Adams
Wurlitzer: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
Director: Dom Fera
DP: Ricky Chavez
Camera Operators: Jenny Baumert, Isaac Park, Chad Carlstone, Charlie Weinmann
Editor: Adam Kritzberg

Recorded Live at EastWest Studios in Los Angeles, CA.

#ScaryPockets #Funk #kissme #sixpencenonethericher #moiramack


# Source:Brad Colbow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A, language:en-US

## I've Used the Same iPad Every Day for 4 Years
 - [https://www.youtube.com/watch?v=ivdypE1O9_I](https://www.youtube.com/watch?v=ivdypE1O9_I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A
 - date published: 2022-12-19 14:57:37+00:00

Check out http://www.squarespace.com for a free trial or go to  http://www.squarespace.com/bradcolbow to save 10% off your first purchase of a website or domain.
And thank you Squarespace for sponsoring this video.

I've used the same iPad every for the last 4 years. It's been my daily driver. In many of my videos I don't get to talk much about durability because I only use a product for a few days or weeks before reviewing. I wanted to try something different today.

Discounts for my Courses (US) https://bradcolbow.channel
Discounts for my Courses (worldwide) http://brad.site/learn/
Email Newsletter: http://brad.site/signup/

-----------------------------------------------------

Twitter: 
https://twitter.com/bradcolbow

Instagram:
https://www.instagram.com/bcolbow/

Drawing Tech Top 10 lists:
http://brad.site/

My Drawing and video gear: 
http://brad.site/mygear/


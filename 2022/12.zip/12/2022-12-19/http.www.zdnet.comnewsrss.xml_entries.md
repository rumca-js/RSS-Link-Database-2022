# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## How to choose the right monitor layout for work
 - [https://www.zdnet.com/home-and-office/smart-office/how-to-choose-the-right-monitor-layout-for-work/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-office/how-to-choose-the-right-monitor-layout-for-work/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 23:53:00+00:00

For those of us who spend hours working at desks, it's vital for our health and productivity that we have the best possible setup, and that all starts with the things you stare at the most: your monitors.

## 14 odd and interesting gift ideas for hackers in 2022
 - [https://www.zdnet.com/article/hackers-gift/#ftag=RSSbaffb68](https://www.zdnet.com/article/hackers-gift/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 23:51:00+00:00

From hobbyist hackers and programmers to professionals, they will love our picks for tech gifts for hackers this holiday season.

## The 10 best cheap tech gifts under $75 for the holidays
 - [https://www.zdnet.com/home-and-office/kitchen-household/gifts-under-75/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/kitchen-household/gifts-under-75/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 23:23:00+00:00

Holiday shopping season is upon, and if you're in search for the best cheap tech gifts, there are plenty of options for any recipient that are under $75.

## Grab a Logitech G604 Lightspeed wireless optical gaming mouse for only $50
 - [https://www.zdnet.com/home-and-office/home-entertainment/grab-a-logitech-g604-lightspeed-wireless-optical-gaming-mouse-for-only-50/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/grab-a-logitech-g604-lightspeed-wireless-optical-gaming-mouse-for-only-50/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 23:13:00+00:00

Just in time for the holidays, you can save 50% on this gaming mouse.

## The 10 best TikTok products in 2022
 - [https://www.zdnet.com/home-and-office/best-tiktok-products/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/best-tiktok-products/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 23:08:00+00:00

Who knew scrolling TikTok could inspire some shopping? The best viral TikTok products that caught our attention are all useful gadgets worth taking a second glance at.

## Attach your iPhone to your Mac desktop with the new Belkin camera mount
 - [https://www.zdnet.com/article/attach-your-iphone-to-your-mac-desktop-with-the-new-belkin-camera-mount/#ftag=RSSbaffb68](https://www.zdnet.com/article/attach-your-iphone-to-your-mac-desktop-with-the-new-belkin-camera-mount/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 22:27:22+00:00

Belkin expands its line of MagSafe-compatible iPhone mounts, optimized for the iPhone's new Continutiy Camera feature

## Apple's Emergency SOS via Satellite vs. Garmin inReach Messenger: Your best rescue tech option
 - [https://www.zdnet.com/article/apples-emergency-sos-via-satellite-vs-garmin-inreach-messenger-your-best-rescue-tech-option/#ftag=RSSbaffb68](https://www.zdnet.com/article/apples-emergency-sos-via-satellite-vs-garmin-inreach-messenger-your-best-rescue-tech-option/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 21:44:16+00:00

We take a look at price, monthly fees and use cases to figure out which rescue tech is right for you.

## The 4 best drones of 2022
 - [https://www.zdnet.com/article/best-drone/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-drone/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 21:44:00+00:00

If you're an aspiring aerial photographer or videographer, you need a top-notch drone. But which is the best? Here are the top 4 compared. And yes, they just so happen to be all from one company: DJI.

## Power bank deal: Save $30 on the Anker 737 portable power brick
 - [https://www.zdnet.com/article/power-bank-deal-anker-737-portable-power-brick/#ftag=RSSbaffb68](https://www.zdnet.com/article/power-bank-deal-anker-737-portable-power-brick/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 21:40:00+00:00

If you're traveling and need some extra battery life, you can get an excellent Anker power bank at Amazon for $30 off with a coupon.

## The best tablet deals right now: December 2022
 - [https://www.zdnet.com/article/tablet-deals/#ftag=RSSbaffb68](https://www.zdnet.com/article/tablet-deals/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 21:26:00+00:00

Looking for a tablet? The holiday season means discounts on the best tablets from brands like Apple and Samsung. Here are the best tablet deals we could find.

## Save $250 on the Acer Nitro 5 gaming laptop
 - [https://www.zdnet.com/article/acer-nitro-5-gaming-laptop-27-percent-off-deal-promo-code-coupon-sale/#ftag=RSSbaffb68](https://www.zdnet.com/article/acer-nitro-5-gaming-laptop-27-percent-off-deal-promo-code-coupon-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 21:23:00+00:00

For the next few hours, this Acer Nitro 5 Gaming Laptop sees a generous 27% off discount. Get big savings on a high-quality gaming laptop.

## How to split-screen on iPad for multitasking
 - [https://www.zdnet.com/article/how-to-split-screen-on-ipad-for-multitasking/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-split-screen-on-ipad-for-multitasking/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 20:55:00+00:00

Here's a killer iPad feature you're probably not using.

## Want Deepin Desktop without privacy worries? Try ExTiX Linux
 - [https://www.zdnet.com/article/want-deepin-desktop-without-privacy-worries-try-extix-linux/#ftag=RSSbaffb68](https://www.zdnet.com/article/want-deepin-desktop-without-privacy-worries-try-extix-linux/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 20:47:47+00:00

If you're looking for a Linux distribution that ships with the Deepin Desktop Environment, other than Deepin Linux, ExTiX might be the perfect alternative.

## Get a Lenovo smart light strip for only $8
 - [https://www.zdnet.com/home-and-office/smart-home/lenovo-smart-light-strip-deal-coupon-promo-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/lenovo-smart-light-strip-deal-coupon-promo-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 20:17:00+00:00

Originally $50, the Lenovo smart light strip is currently on sale, so you can smarten your home for only $8.

## The 5 best iPad Pro keyboard cases of 2022
 - [https://www.zdnet.com/article/best-ipad-pro-keyboard-case/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-ipad-pro-keyboard-case/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 20:04:00+00:00

Protect your keyboard and take your iPad to the next level with the best keyboard cases for iPad Pro.

## When will Microsoft end support for your version of Windows or Office?
 - [https://www.zdnet.com/article/when-will-microsoft-pull-the-plug-on-your-version-of-windows-or-office/#ftag=RSSbaffb68](https://www.zdnet.com/article/when-will-microsoft-pull-the-plug-on-your-version-of-windows-or-office/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 20:01:00+00:00

"Set it and forget it" is no longer an option for the software that runs your business. For Windows 10, the support clock runs out sooner than you might expect. Here's what you need to know.

## The 5 best iPads for students of 2022
 - [https://www.zdnet.com/article/best-ipad-for-college/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-ipad-for-college/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 19:06:00+00:00

Finding the perfect laptop or tablet to make it through college or university can sometimes be tricky. But, with Apple continuing to improve its tablets, an iPad may be just what you need to secure that college diploma.

## How to force quit applications in Windows
 - [https://www.zdnet.com/article/how-to-force-quit-applications-in-windows/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-force-quit-applications-in-windows/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 18:30:19+00:00

Is a stubborn Windows application freezing or locking up? Here's how to shut it down.

## The 13 best Chromebook holiday deals
 - [https://www.zdnet.com/article/chromebook-deals/#ftag=RSSbaffb68](https://www.zdnet.com/article/chromebook-deals/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 15:21:00+00:00

Chromebooks can essentially replace a typical laptop with the ability to browse the web, stream shows and movies, and help you complete work on the go. Here are the top Chromebook deals this holiday season.

## This is the ultimate use of your Apple Watch Ultra's Action button
 - [https://www.zdnet.com/article/this-is-the-ultimate-use-of-your-apple-watch-ultras-action-button/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-is-the-ultimate-use-of-your-apple-watch-ultras-action-button/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 14:58:00+00:00

The Apple Watch Ultra has a button you can program to do whatever you want -- and I've found a way to get the most out of it.

## What is VPN split tunneling and should I be using it?
 - [https://www.zdnet.com/article/what-is-vpn-split-tunneling/#ftag=RSSbaffb68](https://www.zdnet.com/article/what-is-vpn-split-tunneling/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 14:14:39+00:00

You know you should use a VPN to protect your data, especially on public Wi-Fi, but you always hated the hassle of turning it on for secure stuff and off for everything else. Split tunneling eliminates that problem. Here's how.

## Video meetings don't work, so can the metaverse do better? Here's what I found
 - [https://www.zdnet.com/article/video-meetings-dont-work-so-can-the-metaverse-do-better-heres-what-i-found/#ftag=RSSbaffb68](https://www.zdnet.com/article/video-meetings-dont-work-so-can-the-metaverse-do-better-heres-what-i-found/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 14:00:22+00:00

Tech giant Meta believes the metaverse can help professionals collaborate more effectively. I tested its latest technologies and discovered some unexpected benefits - and challenges.

## OnePlus 11 drops 'Pro' branding and keeps the alert slider, company confirms
 - [https://www.zdnet.com/article/oneplus-11-drops-pro-branding-and-keeps-the-alert-slider-company-confirms/#ftag=RSSbaffb68](https://www.zdnet.com/article/oneplus-11-drops-pro-branding-and-keeps-the-alert-slider-company-confirms/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 14:00:00+00:00

The company's flagship launch event is set for February 7 in New Delhi, India, where it will unveil the OnePlus 11 5G and OnePlus Buds Pro 2.

## There's a long cold winter ahead for PC makers. That could be good news for PC buyers
 - [https://www.zdnet.com/article/theres-a-long-cold-winter-ahead-for-pc-makers-that-could-be-good-news-for-pc-buyers/#ftag=RSSbaffb68](https://www.zdnet.com/article/theres-a-long-cold-winter-ahead-for-pc-makers-that-could-be-good-news-for-pc-buyers/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 13:14:07+00:00

Vendors will need to continue offering good deals as selling PCs gets tougher.

## LinkedIn has massively cut the time it takes to detect security threats. Here's how it did it
 - [https://www.zdnet.com/article/linkedin-has-massively-cut-the-time-it-takes-to-detect-security-threats-heres-how-it-did-it/#ftag=RSSbaffb68](https://www.zdnet.com/article/linkedin-has-massively-cut-the-time-it-takes-to-detect-security-threats-heres-how-it-did-it/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 13:01:52+00:00

LinkedIn revitalized its cybersecurity operations to be more effective than ever -- by working smarter, not harder.

## Twitter users vote for Elon Musk to step down as head of Twitter
 - [https://www.zdnet.com/article/twitter-users-vote-for-elon-musk-to-step-down-as-head-of-twitter/#ftag=RSSbaffb68](https://www.zdnet.com/article/twitter-users-vote-for-elon-musk-to-step-down-as-head-of-twitter/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 12:46:38+00:00

Will Elon Musk step down after the majority in a poll he created voted for him to leave?

## Future of your laptop? Dell's modular concept PC comes apart like building blocks
 - [https://www.zdnet.com/article/future-of-your-laptop-dells-modular-concept-pc-comes-apart-like-building-blocks/#ftag=RSSbaffb68](https://www.zdnet.com/article/future-of-your-laptop-dells-modular-concept-pc-comes-apart-like-building-blocks/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 10:16:18+00:00

Dell's Concept Luna laptop can be popped open by inserting a key into the chassis.

## Dell's Concept Luna laptop comes apart like building blocks. Is it the future?
 - [https://www.zdnet.com/article/is-dells-concept-luna-the-future-of-the-laptop/#ftag=RSSbaffb68](https://www.zdnet.com/article/is-dells-concept-luna-the-future-of-the-laptop/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 10:16:00+00:00

Dell's modular concept PC can be popped open by inserting a key into the chassis.

## Best Buy last-minute sale: This ASUS laptop is only $99
 - [https://www.zdnet.com/home-and-office/best-buy-last-minute-sale-this-asus-laptop-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/best-buy-last-minute-sale-this-asus-laptop-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 09:20:00+00:00

There's still time to pick up cheap laptops before the holidays. Best Buy has you covered.

## Best Buy last-minute sale: This ASUS laptop is only $99
 - [https://www.zdnet.com/article/best-buy-last-minute-sale-this-asus-laptop-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-buy-last-minute-sale-this-asus-laptop-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 09:20:00+00:00

There's still time to pick up cheap laptops before the holidays. Best Buy has you covered.

## LG Energy Solution to spend $3 billion to expand EV battery production in South Korea
 - [https://www.zdnet.com/article/lg-energy-solution-to-spend-3-billion-to-expand-ev-battery-production-in-south-korea/#ftag=RSSbaffb68](https://www.zdnet.com/article/lg-energy-solution-to-spend-3-billion-to-expand-ev-battery-production-in-south-korea/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-12-19 06:16:07+00:00

The South Korean EV battery maker continues to expand its production capacity.


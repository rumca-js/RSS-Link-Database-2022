# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Amazon Ring cameras used in nationwide ‘swatting’ spree, US Justice Dept. says
 - [https://www.bloomberg.com/news/articles/2022-12-19/two-charged-with-using-amazon-ring-cameras-in-nationwide-swatting-spree](https://www.bloomberg.com/news/articles/2022-12-19/two-charged-with-using-amazon-ring-cameras-in-nationwide-swatting-spree)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 23:59:22+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2022-12-19/two-charged-with-using-amazon-ring-cameras-in-nationwide-swatting-spree">https://www.bloomberg.com/news/articles/2022-12-19/two-charged-with-using-amazon-ring-cameras-in-nationwide-swatting-spree</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34059633">https://news.ycombinator.com/item?id=34059633</a></p>
<p>Points: 41</p>
<p># Comments: 17</p>

## The Force Engine v1.0 Released
 - [https://theforceengine.github.io/](https://theforceengine.github.io/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 23:54:21+00:00

<p>Article URL: <a href="https://theforceengine.github.io/">https://theforceengine.github.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34059583">https://news.ycombinator.com/item?id=34059583</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Implementing ‘Strlen’ Using SVE
 - [https://lemire.me/blog/2022/12/19/implementing-strlen-using-sve/](https://lemire.me/blog/2022/12/19/implementing-strlen-using-sve/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 22:44:36+00:00

<p>Article URL: <a href="https://lemire.me/blog/2022/12/19/implementing-strlen-using-sve/">https://lemire.me/blog/2022/12/19/implementing-strlen-using-sve/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34058856">https://news.ycombinator.com/item?id=34058856</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## zstd
 - [https://github.com/facebook/zstd](https://github.com/facebook/zstd)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 22:31:47+00:00

<p>Article URL: <a href="https://github.com/facebook/zstd">https://github.com/facebook/zstd</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34058711">https://news.ycombinator.com/item?id=34058711</a></p>
<p>Points: 63</p>
<p># Comments: 9</p>

## Ryugu isotopes suggest it formed close to comets along with some unique minerals
 - [https://phys.org/news/2022-12-isotopic-signatures-ryugu-comets-unique.html](https://phys.org/news/2022-12-isotopic-signatures-ryugu-comets-unique.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 22:30:12+00:00

<p>Article URL: <a href="https://phys.org/news/2022-12-isotopic-signatures-ryugu-comets-unique.html">https://phys.org/news/2022-12-isotopic-signatures-ryugu-comets-unique.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34058691">https://news.ycombinator.com/item?id=34058691</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Astronomical Calculations for Hard SF in Common Lisp
 - [https://borretti.me/article/astronomical-calculations-for-hard-sf-common-lisp](https://borretti.me/article/astronomical-calculations-for-hard-sf-common-lisp)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 22:27:53+00:00

<p>Article URL: <a href="https://borretti.me/article/astronomical-calculations-for-hard-sf-common-lisp">https://borretti.me/article/astronomical-calculations-for-hard-sf-common-lisp</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34058658">https://news.ycombinator.com/item?id=34058658</a></p>
<p>Points: 21</p>
<p># Comments: 0</p>

## Fast memcpy, A System Design
 - [https://www.sigarch.org/fast-memcpy-a-system-design/](https://www.sigarch.org/fast-memcpy-a-system-design/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 22:07:45+00:00

<p>Article URL: <a href="https://www.sigarch.org/fast-memcpy-a-system-design/">https://www.sigarch.org/fast-memcpy-a-system-design/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34058421">https://news.ycombinator.com/item?id=34058421</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## The Secret History: A murder mystery that thrills 30 years on
 - [https://www.bbc.com/culture/article/20221020-the-secret-history-a-murder-mystery-that-thrills-30-years-o](https://www.bbc.com/culture/article/20221020-the-secret-history-a-murder-mystery-that-thrills-30-years-o)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 22:00:32+00:00

<p>Article URL: <a href="https://www.bbc.com/culture/article/20221020-the-secret-history-a-murder-mystery-that-thrills-30-years-o">https://www.bbc.com/culture/article/20221020-the-secret-history-a-murder-mystery-that-thrills-30-years-o</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34058362">https://news.ycombinator.com/item?id=34058362</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Show HN: Yahtzee and Poker and Cosmic Horror = Pine Tar Poker
 - [https://www.pinetarpoker.com](https://www.pinetarpoker.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 22:00:06+00:00

<p>I'm excited to launch today! Pine Tar Poker is a yahtzee-inspired poker game with just a touch of cosmic horror for iOS and Android.<p>I started working on this idea last January by making a paper prototype: a simple printed score sheet I could use with a real deck of cards. I had some fun with that, so I brought it into Unity and kept expanding on it over the last 11 months during nights and weekends. It's tough for me to stay motivated on side projects and see them through to release, but the act of shipping something is so fulfilling that it's usually worth the pain. For Pine Tar, I stretched myself in the narrative department by adding a bit of a Lovecraftian tone to what would otherwise be a Western saloon setting.<p>One thing that kept me motivated during development was seeing my dad get hooked on the card game. He'd text me when he got his first royal flush and when he prestiged the score sheet -- he got every hand type in one game! He has amassed so much in-game cash, I think I need to expand the number of digits I show there!<p>If you get a chance to try it, let me know what you think! If you can't afford it and want to try it, I have a few codes for both platforms, my email is in my profile.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34058358">https://news.ycombinator.com/item?id=34058358</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Sydney CBD is bringing back pedestrian “beg buttons”
 - [https://jakecoppinger.com/2022/12/sydney-cbd-is-bringing-back-pedestrian-beg-buttons/](https://jakecoppinger.com/2022/12/sydney-cbd-is-bringing-back-pedestrian-beg-buttons/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 21:29:55+00:00

<p>Article URL: <a href="https://jakecoppinger.com/2022/12/sydney-cbd-is-bringing-back-pedestrian-beg-buttons/">https://jakecoppinger.com/2022/12/sydney-cbd-is-bringing-back-pedestrian-beg-buttons/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34058004">https://news.ycombinator.com/item?id=34058004</a></p>
<p>Points: 15</p>
<p># Comments: 28</p>

## American EVs reduced gasoline consumption by just 0.54% in 2021
 - [https://arstechnica.com/cars/2022/11/american-evs-reduced-gasoline-consumption-by-just-0-54-in-2021/](https://arstechnica.com/cars/2022/11/american-evs-reduced-gasoline-consumption-by-just-0-54-in-2021/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 21:28:26+00:00

<p>Article URL: <a href="https://arstechnica.com/cars/2022/11/american-evs-reduced-gasoline-consumption-by-just-0-54-in-2021/">https://arstechnica.com/cars/2022/11/american-evs-reduced-gasoline-consumption-by-just-0-54-in-2021/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34057981">https://news.ycombinator.com/item?id=34057981</a></p>
<p>Points: 14</p>
<p># Comments: 5</p>

## How did Roomba-recorded photos end up on Facebook?
 - [https://www.technologyreview.com/2022/12/19/1065306/roomba-irobot-robot-vacuums-artificial-intelligence-training-data-privacy/](https://www.technologyreview.com/2022/12/19/1065306/roomba-irobot-robot-vacuums-artificial-intelligence-training-data-privacy/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 21:04:59+00:00

<p>Article URL: <a href="https://www.technologyreview.com/2022/12/19/1065306/roomba-irobot-robot-vacuums-artificial-intelligence-training-data-privacy/">https://www.technologyreview.com/2022/12/19/1065306/roomba-irobot-robot-vacuums-artificial-intelligence-training-data-privacy/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34057699">https://news.ycombinator.com/item?id=34057699</a></p>
<p>Points: 31</p>
<p># Comments: 4</p>

## What happened to the first cryogenically frozen humans?
 - [https://bigthink.com/the-future/cryonics-horror-stories/](https://bigthink.com/the-future/cryonics-horror-stories/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 21:02:55+00:00

<p>Article URL: <a href="https://bigthink.com/the-future/cryonics-horror-stories/">https://bigthink.com/the-future/cryonics-horror-stories/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34057671">https://news.ycombinator.com/item?id=34057671</a></p>
<p>Points: 29</p>
<p># Comments: 5</p>

## Ask HN: What is the cheapest, easiest way to host a cronjob in 2022?
 - [https://news.ycombinator.com/item?id=34056812](https://news.ycombinator.com/item?id=34056812)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 19:56:52+00:00

<p>I thought this could start a good debate on the subject. Myself I have had to make a short running web-scraping job that, given a change in the site, sends a notifying email. This running once an hour.<p>It is 2022, so I had thought it would be tremendously easy and cheap, but it seems no solution is easily implemented.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34056812">https://news.ycombinator.com/item?id=34056812</a></p>
<p>Points: 19</p>
<p># Comments: 33</p>

## Twitter archiver: Make your own simple, public, searchable Twitter archive
 - [https://github.com/dariusk/twitter-archiver](https://github.com/dariusk/twitter-archiver)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 19:21:55+00:00

<p>Article URL: <a href="https://github.com/dariusk/twitter-archiver">https://github.com/dariusk/twitter-archiver</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34056378">https://news.ycombinator.com/item?id=34056378</a></p>
<p>Points: 28</p>
<p># Comments: 3</p>

## Hydrogel interfaces for merging humans and machines
 - [https://www.nature.com/articles/s41578-022-00483-4](https://www.nature.com/articles/s41578-022-00483-4)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 19:21:26+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s41578-022-00483-4">https://www.nature.com/articles/s41578-022-00483-4</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34056370">https://news.ycombinator.com/item?id=34056370</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Seattle woman can’t build housing without paying city $77k. Now she’s suing
 - [https://www.marketwatch.com/story/a-seattle-woman-cant-build-affordable-housing-on-her-property-without-first-paying-the-local-government-77-000-so-now-shes-suing-the-city-11671130706](https://www.marketwatch.com/story/a-seattle-woman-cant-build-affordable-housing-on-her-property-without-first-paying-the-local-government-77-000-so-now-shes-suing-the-city-11671130706)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 19:09:46+00:00

<p>Article URL: <a href="https://www.marketwatch.com/story/a-seattle-woman-cant-build-affordable-housing-on-her-property-without-first-paying-the-local-government-77-000-so-now-shes-suing-the-city-11671130706">https://www.marketwatch.com/story/a-seattle-woman-cant-build-affordable-housing-on-her-property-without-first-paying-the-local-government-77-000-so-now-shes-suing-the-city-11671130706</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34056232">https://news.ycombinator.com/item?id=34056232</a></p>
<p>Points: 38</p>
<p># Comments: 10</p>

## Spotifyd
 - [https://github.com/Spotifyd/spotifyd](https://github.com/Spotifyd/spotifyd)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 18:56:38+00:00

<p>Article URL: <a href="https://github.com/Spotifyd/spotifyd">https://github.com/Spotifyd/spotifyd</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34056067">https://news.ycombinator.com/item?id=34056067</a></p>
<p>Points: 37</p>
<p># Comments: 9</p>

## World record back at HZB: Tandem solar cell achieves 32.5 percent efficiency
 - [https://www.helmholtz-berlin.de/pubbin/news_seite?nid=24348&sprache=en&seitenid=1](https://www.helmholtz-berlin.de/pubbin/news_seite?nid=24348&sprache=en&seitenid=1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 18:51:04+00:00

<p>Article URL: <a href="https://www.helmholtz-berlin.de/pubbin/news_seite?nid=24348&amp;sprache=en&amp;seitenid=1">https://www.helmholtz-berlin.de/pubbin/news_seite?nid=24348&amp;sprache=en&amp;seitenid=1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34055981">https://news.ycombinator.com/item?id=34055981</a></p>
<p>Points: 34</p>
<p># Comments: 7</p>

## Power company money flows to news sites that attack their critics
 - [https://www.npr.org/2022/12/19/1143753129/power-companies-florida-alabama-media-investigation-consulting-firm](https://www.npr.org/2022/12/19/1143753129/power-companies-florida-alabama-media-investigation-consulting-firm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 18:41:08+00:00

<p>Article URL: <a href="https://www.npr.org/2022/12/19/1143753129/power-companies-florida-alabama-media-investigation-consulting-firm">https://www.npr.org/2022/12/19/1143753129/power-companies-florida-alabama-media-investigation-consulting-firm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34055834">https://news.ycombinator.com/item?id=34055834</a></p>
<p>Points: 74</p>
<p># Comments: 6</p>

## GCC now includes Modula-2 and Rust. Do they work on OpenBSD?
 - [https://briancallahan.net/blog/20221219.html](https://briancallahan.net/blog/20221219.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 18:19:08+00:00

<p>Article URL: <a href="https://briancallahan.net/blog/20221219.html">https://briancallahan.net/blog/20221219.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34055533">https://news.ycombinator.com/item?id=34055533</a></p>
<p>Points: 15</p>
<p># Comments: 2</p>

## Show HN: Infisical – open-source secrets manager
 - [https://github.com/Infisical/infisical](https://github.com/Infisical/infisical)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 17:52:20+00:00

<p>Last month, we open-sourced Infisical (<a href="https://github.com/Infisical/infisical">https://github.com/Infisical/infisical</a>) - a simple, end-to-end encrypted tool to sync environment variables across your team and infrastructure. You can use it to store environment variables and inject them into your applications locally or into CI/CD and production infrastructure. It can be used with any language/framework and is platform independent with a super easy setup.<p>We know secret managers exist but, in our experience, they’re too complicated, not comprehensive, not user-friendly, or a mix of all three — other nicer ones are closed-source and don’t have self-hosted options available. That’s why we’re on a mission to make secret management more accessible to every developer — not just security teams.<p>We’ve launched this repo under the MIT license so any developer can use the tool. The goal is to not charge individual developers. We make money by charging a license fee for some future enterprise features as well as providing a hosted version and support.<p>In the coming weeks, we plan to add features like key rotation, access logs + more integrations. We’d love to hear your thoughts and any feature requests!<p>Give it a try (<a href="https://github.com/Infisical/infisical">https://github.com/Infisical/infisical</a>), and let us know what you think!<p>Main website: <a href="https://infisical.com/" rel="nofollow">https://infisical.com/</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34055132">https://news.ycombinator.com/item?id=34055132</a></p>
<p>Points: 23</p>
<p># Comments: 1</p>

## Ask HN: What is the best thing you read in 2022?
 - [https://news.ycombinator.com/item?id=34055123](https://news.ycombinator.com/item?id=34055123)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 17:51:49+00:00

<p>Is there a book, paper, report or article etc. that really stood out?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34055123">https://news.ycombinator.com/item?id=34055123</a></p>
<p>Points: 20</p>
<p># Comments: 10</p>

## Video codec in 100 lines of Rust
 - [https://blog.tempus-ex.com/hello-video-codec/](https://blog.tempus-ex.com/hello-video-codec/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 17:50:34+00:00

<p>Article URL: <a href="https://blog.tempus-ex.com/hello-video-codec/">https://blog.tempus-ex.com/hello-video-codec/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34055101">https://news.ycombinator.com/item?id=34055101</a></p>
<p>Points: 28</p>
<p># Comments: 1</p>

## Binance's books are a black box, filings show, as it tries to rally confidence
 - [https://www.reuters.com/technology/binances-books-are-black-box-filings-show-crypto-giant-tries-rally-confidence-2022-12-19/](https://www.reuters.com/technology/binances-books-are-black-box-filings-show-crypto-giant-tries-rally-confidence-2022-12-19/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 17:48:02+00:00

<p>Article URL: <a href="https://www.reuters.com/technology/binances-books-are-black-box-filings-show-crypto-giant-tries-rally-confidence-2022-12-19/">https://www.reuters.com/technology/binances-books-are-black-box-filings-show-crypto-giant-tries-rally-confidence-2022-12-19/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34055058">https://news.ycombinator.com/item?id=34055058</a></p>
<p>Points: 66</p>
<p># Comments: 36</p>

## What's New in Bazel 6.0
 - [https://www.buildbuddy.io/blog/whats-new-in-bazel-6-0/](https://www.buildbuddy.io/blog/whats-new-in-bazel-6-0/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 17:44:26+00:00

<p>Article URL: <a href="https://www.buildbuddy.io/blog/whats-new-in-bazel-6-0/">https://www.buildbuddy.io/blog/whats-new-in-bazel-6-0/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34055006">https://news.ycombinator.com/item?id=34055006</a></p>
<p>Points: 23</p>
<p># Comments: 10</p>

## Cook whole grains like popcorn
 - [https://www.treehugger.com/how-cook-any-whole-grain-popcorn-4858738](https://www.treehugger.com/how-cook-any-whole-grain-popcorn-4858738)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 17:22:07+00:00

<p>Article URL: <a href="https://www.treehugger.com/how-cook-any-whole-grain-popcorn-4858738">https://www.treehugger.com/how-cook-any-whole-grain-popcorn-4858738</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34054718">https://news.ycombinator.com/item?id=34054718</a></p>
<p>Points: 27</p>
<p># Comments: 3</p>

## Commodore Pet 2001 Repair
 - [https://biosrhythm.com/?p=2224](https://biosrhythm.com/?p=2224)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 17:10:59+00:00

<p>Article URL: <a href="https://biosrhythm.com/?p=2224">https://biosrhythm.com/?p=2224</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34054566">https://news.ycombinator.com/item?id=34054566</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## Ask HN: Top Skills to Learn for 2023?
 - [https://news.ycombinator.com/item?id=34054170](https://news.ycombinator.com/item?id=34054170)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 16:41:26+00:00

<p>Languages, frameworks, technologies etc.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34054170">https://news.ycombinator.com/item?id=34054170</a></p>
<p>Points: 40</p>
<p># Comments: 45</p>

## RFC2217 implementation written in Rust
 - [https://github.com/esp-rs/rfc2217-rs](https://github.com/esp-rs/rfc2217-rs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 16:26:15+00:00

<p>Article URL: <a href="https://github.com/esp-rs/rfc2217-rs">https://github.com/esp-rs/rfc2217-rs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34053938">https://news.ycombinator.com/item?id=34053938</a></p>
<p>Points: 10</p>
<p># Comments: 6</p>

## Did Insurance Fire Brigades let uninsured buildings burn?
 - [https://www.tomscott.com/corrections/firemarks/](https://www.tomscott.com/corrections/firemarks/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 16:09:33+00:00

<p>Article URL: <a href="https://www.tomscott.com/corrections/firemarks/">https://www.tomscott.com/corrections/firemarks/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34053704">https://news.ycombinator.com/item?id=34053704</a></p>
<p>Points: 18</p>
<p># Comments: 4</p>

## Server stats say movetodon.org reached a new record of 49k users yesterday
 - [https://mastodon.social/@Tibor/109540214666343598](https://mastodon.social/@Tibor/109540214666343598)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 15:56:07+00:00

<p>Article URL: <a href="https://mastodon.social/@Tibor/109540214666343598">https://mastodon.social/@Tibor/109540214666343598</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34053520">https://news.ycombinator.com/item?id=34053520</a></p>
<p>Points: 22</p>
<p># Comments: 3</p>

## Radio 101: Why AM stations reduce power at night
 - [https://relevantradio.com/2020/01/radio-101-why-am-stations-reduce-power-at-night/](https://relevantradio.com/2020/01/radio-101-why-am-stations-reduce-power-at-night/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 15:51:24+00:00

<p>Article URL: <a href="https://relevantradio.com/2020/01/radio-101-why-am-stations-reduce-power-at-night/">https://relevantradio.com/2020/01/radio-101-why-am-stations-reduce-power-at-night/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34053466">https://news.ycombinator.com/item?id=34053466</a></p>
<p>Points: 16</p>
<p># Comments: 2</p>

## Checked integer arithmetic in the prospect of C23
 - [https://gustedt.wordpress.com/2022/12/18/checked-integer-arithmetic-in-the-prospect-of-c23/](https://gustedt.wordpress.com/2022/12/18/checked-integer-arithmetic-in-the-prospect-of-c23/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 15:45:32+00:00

<p>Article URL: <a href="https://gustedt.wordpress.com/2022/12/18/checked-integer-arithmetic-in-the-prospect-of-c23/">https://gustedt.wordpress.com/2022/12/18/checked-integer-arithmetic-in-the-prospect-of-c23/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34053397">https://news.ycombinator.com/item?id=34053397</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Apple Music deletes your original songs and replaces them with DRM'd versions
 - [https://old.reddit.com/r/YouShouldKnow/comments/zl8ko3/ysk_apple_music_deletes_your_original_songs_and/](https://old.reddit.com/r/YouShouldKnow/comments/zl8ko3/ysk_apple_music_deletes_your_original_songs_and/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 15:22:54+00:00

<p>Article URL: <a href="https://old.reddit.com/r/YouShouldKnow/comments/zl8ko3/ysk_apple_music_deletes_your_original_songs_and/">https://old.reddit.com/r/YouShouldKnow/comments/zl8ko3/ysk_apple_music_deletes_your_original_songs_and/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34053094">https://news.ycombinator.com/item?id=34053094</a></p>
<p>Points: 121</p>
<p># Comments: 25</p>

## Was Rocket Lake Power Efficient?
 - [https://chipsandcheese.com/2022/12/17/was-rocket-lake-power-efficient/](https://chipsandcheese.com/2022/12/17/was-rocket-lake-power-efficient/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 15:06:35+00:00

<p>Article URL: <a href="https://chipsandcheese.com/2022/12/17/was-rocket-lake-power-efficient/">https://chipsandcheese.com/2022/12/17/was-rocket-lake-power-efficient/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34052903">https://news.ycombinator.com/item?id=34052903</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## Tell HN: Google Maps location data is used for GeoIP updates
 - [https://news.ycombinator.com/item?id=34052786](https://news.ycombinator.com/item?id=34052786)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 14:57:24+00:00

<p>Hi,<p>I've been meaning to write this for a few years now.
I saw https://news.ycombinator.com/item?id=34032484 and lots of great replies there - but I happen to have an insight which I kept track of for years now.<p>Some background first. Since more than a decade I've been using an always-on VPN on all my devices through a VPS I operate (various cloud providers along the years).
Also for context, I stopped using all google services around 2015 or thereabouts - although I still have an account I no longer use it.
The only google service that I use rarely is google maps - of course, never logged on.
And a few times a month I use google search for the odd obscure thing.<p>Around 2016 was the first time I noticed that google.com was showing at the bottom of the page my ZIP code. It felt very unusual but I was in the process of moving so I didn't pay too much attention. To my surprise, a few weeks later google.com was showing my new ZIP code.<p>I shopped around for cloud providers that would allow me to rotate the instance IP easily and thankfully there are many but I was curious how come google picked it up - the only plausible reason was using location data from the Google Maps iOS app.<p>Here's how you can replicate this.<p>Get a cheap VPS from a country different than yours. Get an iOS device (ideally an (older?) iPhone but I think it should work on an iPad) - Android devices should be excluded from this test for obvious reasons.
Reset it to factory defaults (optional but removes moving parts and false leads like cookies etc).<p>Install wireguard (or your preferred always-on vpn) and configure the VPS to be used as an exit node.
Install google maps (don't login of course) - can be used without being logged on just fine.
Install firefox focus (Safari in Private Window mode would work as well).<p>Confirm via ipinfo (or your preferred whatsmyip website) that you're using the VPS IP
Go to google.com and confirm it's showing at the bottom of the page the country of the VPS (could also be shown in a different language if google has a presence in that country).<p>Use the google maps app a few times a day (ideally navigate from a place to another) - it will take about 2-3 weeks but you'll notice that google.com will now show your actual country for the VPS IP and also the google.com language will change to your own.<p>If you want to take it one step further, continue to use google maps on the iOS device. You'll notice that after a few more weeks, google.com will show your actual City (based on the IP) - and after a while longer it will be even more precise, will show your ZIP code.<p>You have to be patient though, it will take 2-4 weeks to start with - and it's imperative that that IP address is dedicated to this test.<p>Funny enough, I was on holiday on Mexico for a month right before reading the HN article I mentioned (have been using a VPS in the states for lower latency) and I noticed that after 2 weeks the language changed to Spanish and google.com was showing Mexico (I rotated the IP when this happened and it prompted me to write this 'Tell HN'.<p>Not surprisingly but Google doesn't share the new GeoIP data - MaxMind, ipinfo and others never changed their location data for that IP - they showed the original geoip even a few weeks after google changed theirs - haven't checked longer than that - it could be shared eventually.<p>In conclusion - I can't say that I'm surprised Google is using the Maps location data - and I don't think there's any way to prevent it (outside of not running Maps - but unfortunately it's one of the few ways of checking restaurant reviews).
My "workaround" is to periodically rotate my VPS IP and move on with life :)<p>Thanks for reading - I hope you found this useful.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34052786">https://news.ycombinator.com/item?id=34052786</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## A few new things in Emacs 29
 - [https://mbork.pl/2022-12-19_A_few_new_things_in_Emacs_29](https://mbork.pl/2022-12-19_A_few_new_things_in_Emacs_29)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 14:34:15+00:00

<p>Article URL: <a href="https://mbork.pl/2022-12-19_A_few_new_things_in_Emacs_29">https://mbork.pl/2022-12-19_A_few_new_things_in_Emacs_29</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34052468">https://news.ycombinator.com/item?id=34052468</a></p>
<p>Points: 15</p>
<p># Comments: 6</p>

## Code Design Decision – Always throw custom exceptions
 - [https://github.com/getparthenon/parthenon/wiki/Design-Decision:-Throw-Custom-Exceptions](https://github.com/getparthenon/parthenon/wiki/Design-Decision:-Throw-Custom-Exceptions)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 14:25:40+00:00

<p>Article URL: <a href="https://github.com/getparthenon/parthenon/wiki/Design-Decision:-Throw-Custom-Exceptions">https://github.com/getparthenon/parthenon/wiki/Design-Decision:-Throw-Custom-Exceptions</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34052363">https://news.ycombinator.com/item?id=34052363</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Structuring Clojure Applications
 - [https://yogthos.net/posts/2022-12-18-StructuringClojureApplications.html](https://yogthos.net/posts/2022-12-18-StructuringClojureApplications.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 14:16:51+00:00

<p>Article URL: <a href="https://yogthos.net/posts/2022-12-18-StructuringClojureApplications.html">https://yogthos.net/posts/2022-12-18-StructuringClojureApplications.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34052268">https://news.ycombinator.com/item?id=34052268</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## Pixel Accurate Atkinson Dithering for Images in HTML
 - [https://sheep.horse/2022/12/pixel_accurate_atkinson_dithering_for_images_in_ht.html](https://sheep.horse/2022/12/pixel_accurate_atkinson_dithering_for_images_in_ht.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 14:15:39+00:00

<p>Article URL: <a href="https://sheep.horse/2022/12/pixel_accurate_atkinson_dithering_for_images_in_ht.html">https://sheep.horse/2022/12/pixel_accurate_atkinson_dithering_for_images_in_ht.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34052253">https://news.ycombinator.com/item?id=34052253</a></p>
<p>Points: 14</p>
<p># Comments: 4</p>

## Ask HN: Has anyone here turned around their life in their 40s?
 - [https://news.ycombinator.com/item?id=34052201](https://news.ycombinator.com/item?id=34052201)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 14:11:23+00:00

<p>I know the best of my life is behind me, but I need help salvaging what's left of it. I've been meaning to ask for help for a couple of years now, but only now got around to it after being scared by my first real suicidal ideation a few nights ago. HN is probably not a suitable platform for this, but /r/advice seems to be not very active and I can't post on /adv/ due to some IP range ban. There are no mental health facilities in the small town where I live. I let my professional network decay and die, and there is literally nowhere else I can get any kind of useful, actionable advice.<p>I'm a 43-years-old single guy, NEET for the past decade. I got my Master's in the US in the late 2000s and was gainfully employed there for a few years (NOT in my field of education; long story) until I had to return to my home country to take care of my ailing father. He passed on within a year of my return, leaving my family with a financial mess, and his death took a lot out of me. I still obviously miss him, but in wallowing in depression and self-pity, I let the prime of my life pass me by.<p>As I stand, I have no current skills related to either my education (MEng) or my previous work experience (BI Reporting/Analytics). I don't have ideas/skills/network for entrepreneurship.<p>I had all the desires of a regular guy: a wife, kids, a house, meaningful work, etc. I mean I still do, but I guess I'm too late for the first few. Every night I promise myself to do/be better tomorrow and somehow get myself to sleep. I was once looked up to, now I'm a pity case and an example case of how not to throw one's life away.<p>With every passing day, I am becoming more bitter, angry and disillusioned. I don't want to live like this anymore, but I don't know how to even _start_ thinking of ways to get myself out of this hole.<p>Ideally, I would prefer to go back to the US; not only for the dollars (they're nice), but also because I actually was happy there. I'd do all the things that I didn't do enough of because I was focused on saving money and because I thought that there would always be time for them when I was more stable/settled.<p>The good: No diseases AFAIK, no vices at all other than severe procrastination and a masterful ability to lie to myself. I have ~US$25k-equivalent in salary savings from a decade ago.<p>Sorry if the above text is rambling and not very cohesive. I've probably also skipped over some useful information I should have provided. Please do ask. I'll take some time reflecting on your replies and then respond. Thank you.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34052201">https://news.ycombinator.com/item?id=34052201</a></p>
<p>Points: 71</p>
<p># Comments: 32</p>

## Epic Games to pay $520M to resolve FTC allegations
 - [https://www.wsj.com/articles/epic-games-maker-of-fortnite-to-pay-520-million-to-resolve-ftc-allegations-11671456744](https://www.wsj.com/articles/epic-games-maker-of-fortnite-to-pay-520-million-to-resolve-ftc-allegations-11671456744)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 13:49:13+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/epic-games-maker-of-fortnite-to-pay-520-million-to-resolve-ftc-allegations-11671456744">https://www.wsj.com/articles/epic-games-maker-of-fortnite-to-pay-520-million-to-resolve-ftc-allegations-11671456744</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051957">https://news.ycombinator.com/item?id=34051957</a></p>
<p>Points: 27</p>
<p># Comments: 12</p>

## Tell HN: Uber has blocked my account for years, won't tell me why
 - [https://news.ycombinator.com/item?id=34051876](https://news.ycombinator.com/item?id=34051876)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 13:40:16+00:00

<p>Until 2019, I used uber everytime I traveled abroad. Then one day, suddenly I login and it logs me out, says my account is blocked. There was no way for me to reach support or figure out why. We've been using my wife's account since then. I'm just account to travel again, for the first time since 2019, and tried to login to uber, still blocked. I fill the support form, and get an email saying they won't send my request to a support rep until I verify my email. So I click the link and verify.<p>One day later I get an email from a rep saying "I'm contacting them from my second uber account". I had no idea you could have 2 accounts with same email. And if that is the case, it's clearly an accident and I have no idea which account they refer to. And they won't help, no way to reach a human. I don't get how a ride hailing company thinks is't cool to behave like a bank. Any tips on how I can resolve this?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051876">https://news.ycombinator.com/item?id=34051876</a></p>
<p>Points: 63</p>
<p># Comments: 66</p>

## Discovery identifies Australia as birthplace of all modern mammals
 - [https://www.australiangeographic.com.au/news/2022/12/discovery-identifies-australia-as-birthplace-of-all-modern-mammals/](https://www.australiangeographic.com.au/news/2022/12/discovery-identifies-australia-as-birthplace-of-all-modern-mammals/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 13:39:34+00:00

<p>Article URL: <a href="https://www.australiangeographic.com.au/news/2022/12/discovery-identifies-australia-as-birthplace-of-all-modern-mammals/">https://www.australiangeographic.com.au/news/2022/12/discovery-identifies-australia-as-birthplace-of-all-modern-mammals/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051868">https://news.ycombinator.com/item?id=34051868</a></p>
<p>Points: 35</p>
<p># Comments: 6</p>

## Ice not recommended for soft tissue injury treatment (2019)
 - [https://blogs.bmj.com/bjsm/2019/04/26/soft-tissue-injuries-simply-need-peace-love/](https://blogs.bmj.com/bjsm/2019/04/26/soft-tissue-injuries-simply-need-peace-love/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 13:38:54+00:00

<p>Article URL: <a href="https://blogs.bmj.com/bjsm/2019/04/26/soft-tissue-injuries-simply-need-peace-love/">https://blogs.bmj.com/bjsm/2019/04/26/soft-tissue-injuries-simply-need-peace-love/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051860">https://news.ycombinator.com/item?id=34051860</a></p>
<p>Points: 75</p>
<p># Comments: 58</p>

## We lock atmospheric carbon into stone for good
 - [https://carbontostone.com/](https://carbontostone.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 13:31:41+00:00

<p>Article URL: <a href="https://carbontostone.com/">https://carbontostone.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051800">https://news.ycombinator.com/item?id=34051800</a></p>
<p>Points: 18</p>
<p># Comments: 8</p>

## Who Is Rep.-Elect George Santos? His Résumé May Be Largely Fiction
 - [https://www.nytimes.com/2022/12/19/nyregion/george-santos-ny-republicans.html](https://www.nytimes.com/2022/12/19/nyregion/george-santos-ny-republicans.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 13:22:42+00:00

<p>Article URL: <a href="https://www.nytimes.com/2022/12/19/nyregion/george-santos-ny-republicans.html">https://www.nytimes.com/2022/12/19/nyregion/george-santos-ny-republicans.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051721">https://news.ycombinator.com/item?id=34051721</a></p>
<p>Points: 33</p>
<p># Comments: 13</p>

## Digitally sign PDF files from your commandline – open-pdf-sign
 - [https://github.com/open-pdf-sign/open-pdf-sign](https://github.com/open-pdf-sign/open-pdf-sign)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 13:15:40+00:00

<p>Article URL: <a href="https://github.com/open-pdf-sign/open-pdf-sign">https://github.com/open-pdf-sign/open-pdf-sign</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051652">https://news.ycombinator.com/item?id=34051652</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## NIH can’t deny former research chimps sanctuary retirement, federal judge rules
 - [https://www.science.org/content/article/nih-can-t-deny-former-research-chimps-sanctuary-retirement-federal-judge-rules](https://www.science.org/content/article/nih-can-t-deny-former-research-chimps-sanctuary-retirement-federal-judge-rules)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 13:04:57+00:00

<p>Article URL: <a href="https://www.science.org/content/article/nih-can-t-deny-former-research-chimps-sanctuary-retirement-federal-judge-rules">https://www.science.org/content/article/nih-can-t-deny-former-research-chimps-sanctuary-retirement-federal-judge-rules</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051561">https://news.ycombinator.com/item?id=34051561</a></p>
<p>Points: 69</p>
<p># Comments: 4</p>

## Ask HN: Best tips for reducing eyestrain while coding with astigmatism?
 - [https://news.ycombinator.com/item?id=34051427](https://news.ycombinator.com/item?id=34051427)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 12:48:38+00:00

<p>I was diagnosed with astigmatism in 2018 or around that time. I haven't been to the eye doctor since, but at that point my vision was around 20/20 or slightly impaired. I did get glasses, which I rarely wear, but I have been wearing them more recently because I feel that my eyesight may be becoming more of an issue. For example, after long periods of coding or looking at my phone screen, I see floaters. Sometimes I wake up seeing them and have a low-productivity day or take a nap and some Advil in the hope that it is related to a migraine.<p>I am mainly interested in what tools, settings, and themes people with astigmatism use, and if you have any preference for light or dark themes. Personally, I cannot stand light, whether it is physical light or light on screens. When my 5-year-old turns on the overhead light in my bedroom, I pull the blanket over my head or shout to turn it off. I feel like Gizmo from Gremlins.<p>I am a developer, and my main tools are Terminator + Tmux, Chrome, DBeaver, and Visual Studio Code. The font I am using is Jetbrains SemiBold. I just tried the Solarized Dark theme and I am kind of liking it, but I feel like I might be able to find something slightly better. Before that, I have used Night Owl, GitHub Dark, Material, and a few others.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051427">https://news.ycombinator.com/item?id=34051427</a></p>
<p>Points: 23</p>
<p># Comments: 23</p>

## 1/4 of companies that IPO'd in 2020-2021 trades below $2, risking delisting
 - [https://www.wsj.com/articles/oatly-other-deflated-ipo-stocks-haunt-new-issue-market-11671417781](https://www.wsj.com/articles/oatly-other-deflated-ipo-stocks-haunt-new-issue-market-11671417781)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 12:47:40+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/oatly-other-deflated-ipo-stocks-haunt-new-issue-market-11671417781">https://www.wsj.com/articles/oatly-other-deflated-ipo-stocks-haunt-new-issue-market-11671417781</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051414">https://news.ycombinator.com/item?id=34051414</a></p>
<p>Points: 11</p>
<p># Comments: 3</p>

## Wing: A cloud-oriented programming language
 - [https://www.winglang.io/](https://www.winglang.io/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 12:34:57+00:00

<p>Article URL: <a href="https://www.winglang.io/">https://www.winglang.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051325">https://news.ycombinator.com/item?id=34051325</a></p>
<p>Points: 56</p>
<p># Comments: 28</p>

## Characterizing Emergent Phenomena in Large Language Models
 - [https://ai.googleblog.com/2022/11/characterizing-emergent-phenomena-in.html](https://ai.googleblog.com/2022/11/characterizing-emergent-phenomena-in.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 12:07:42+00:00

<p>Article URL: <a href="https://ai.googleblog.com/2022/11/characterizing-emergent-phenomena-in.html">https://ai.googleblog.com/2022/11/characterizing-emergent-phenomena-in.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051154">https://news.ycombinator.com/item?id=34051154</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Post YC Post Mortem
 - [https://github.com/getlago/lago/wiki/Post-mortem-of-our-1st-YC-startup:-a-Reverse-ETL](https://github.com/getlago/lago/wiki/Post-mortem-of-our-1st-YC-startup:-a-Reverse-ETL)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 11:57:03+00:00

<p>Article URL: <a href="https://github.com/getlago/lago/wiki/Post-mortem-of-our-1st-YC-startup:-a-Reverse-ETL">https://github.com/getlago/lago/wiki/Post-mortem-of-our-1st-YC-startup:-a-Reverse-ETL</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051088">https://news.ycombinator.com/item?id=34051088</a></p>
<p>Points: 16</p>
<p># Comments: 3</p>

## Fungal toxins are widespread in European wheat
 - [https://theconversation.com/fungal-toxins-are-widespread-in-european-wheat-threatening-human-health-and-the-economy-196531](https://theconversation.com/fungal-toxins-are-widespread-in-european-wheat-threatening-human-health-and-the-economy-196531)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 11:52:08+00:00

<p>Article URL: <a href="https://theconversation.com/fungal-toxins-are-widespread-in-european-wheat-threatening-human-health-and-the-economy-196531">https://theconversation.com/fungal-toxins-are-widespread-in-european-wheat-threatening-human-health-and-the-economy-196531</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34051062">https://news.ycombinator.com/item?id=34051062</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Converting my PhD thesis into HTML (2021)
 - [https://desfontain.es/privacy/latex-to-html.html](https://desfontain.es/privacy/latex-to-html.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 11:15:06+00:00

<p>Article URL: <a href="https://desfontain.es/privacy/latex-to-html.html">https://desfontain.es/privacy/latex-to-html.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34050835">https://news.ycombinator.com/item?id=34050835</a></p>
<p>Points: 15</p>
<p># Comments: 5</p>

## The golden age of streaming TV is over
 - [https://www.businessinsider.com/why-streaming-tv-got-boring-netflix-hulu-hbo-max-cable-2022-12](https://www.businessinsider.com/why-streaming-tv-got-boring-netflix-hulu-hbo-max-cable-2022-12)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 11:03:11+00:00

<p>Article URL: <a href="https://www.businessinsider.com/why-streaming-tv-got-boring-netflix-hulu-hbo-max-cable-2022-12">https://www.businessinsider.com/why-streaming-tv-got-boring-netflix-hulu-hbo-max-cable-2022-12</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34050765">https://news.ycombinator.com/item?id=34050765</a></p>
<p>Points: 18</p>
<p># Comments: 18</p>

## J one-page interpreter fragment (1992)
 - [https://code.jsoftware.com/wiki/Essays/Incunabulum](https://code.jsoftware.com/wiki/Essays/Incunabulum)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 10:55:26+00:00

<p>Article URL: <a href="https://code.jsoftware.com/wiki/Essays/Incunabulum">https://code.jsoftware.com/wiki/Essays/Incunabulum</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34050715">https://news.ycombinator.com/item?id=34050715</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## No, German “autopsy report” didn’t show vaccines as likely cause of sudden death
 - [https://healthfeedback.org/claimreview/german-autopsy-report-didnt-covid-19-vaccines-likely-cause-sudden-deaths/](https://healthfeedback.org/claimreview/german-autopsy-report-didnt-covid-19-vaccines-likely-cause-sudden-deaths/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 10:48:25+00:00

<p>Article URL: <a href="https://healthfeedback.org/claimreview/german-autopsy-report-didnt-covid-19-vaccines-likely-cause-sudden-deaths/">https://healthfeedback.org/claimreview/german-autopsy-report-didnt-covid-19-vaccines-likely-cause-sudden-deaths/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34050668">https://news.ycombinator.com/item?id=34050668</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## GCC 13 to support Modula-2: Follow-up to Pascal lives on in FOSS form
 - [https://www.theregister.com/2022/12/16/gcc_13_will_support_modula2/](https://www.theregister.com/2022/12/16/gcc_13_will_support_modula2/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 10:38:03+00:00

<p>Article URL: <a href="https://www.theregister.com/2022/12/16/gcc_13_will_support_modula2/">https://www.theregister.com/2022/12/16/gcc_13_will_support_modula2/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34050597">https://news.ycombinator.com/item?id=34050597</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Twitter policy page forbidding links to other social media removed
 - [https://news.ycombinator.com/item?id=34050283](https://news.ycombinator.com/item?id=34050283)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 09:50:23+00:00

<p>It's returning a 404 ... the original is available via the wayback machine.<p>https://web.archive.org/web/20221218200110/https://help.twitter.com/en/rules-and-policies/social-platforms-policy<p>Consider contributing to them.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34050283">https://news.ycombinator.com/item?id=34050283</a></p>
<p>Points: 25</p>
<p># Comments: 3</p>

## An electric Kia that’s faster than a Lamborghini? The 2023 EV6 GT, driven
 - [https://arstechnica.com/cars/2022/12/an-electric-kia-thats-faster-than-a-lamborghini-the-2023-ev6-gt-driven/](https://arstechnica.com/cars/2022/12/an-electric-kia-thats-faster-than-a-lamborghini-the-2023-ev6-gt-driven/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 09:03:38+00:00

<p>Article URL: <a href="https://arstechnica.com/cars/2022/12/an-electric-kia-thats-faster-than-a-lamborghini-the-2023-ev6-gt-driven/">https://arstechnica.com/cars/2022/12/an-electric-kia-thats-faster-than-a-lamborghini-the-2023-ev6-gt-driven/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34050005">https://news.ycombinator.com/item?id=34050005</a></p>
<p>Points: 9</p>
<p># Comments: 12</p>

## Special Relativity and Middle-Earth
 - [https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/](https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 08:25:36+00:00

<p>Article URL: <a href="https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/">https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34049777">https://news.ycombinator.com/item?id=34049777</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Anthropology in Ruins
 - [https://www.mindingthecampus.org/2022/12/13/anthropology-in-ruins/](https://www.mindingthecampus.org/2022/12/13/anthropology-in-ruins/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 06:23:14+00:00

<p>Article URL: <a href="https://www.mindingthecampus.org/2022/12/13/anthropology-in-ruins/">https://www.mindingthecampus.org/2022/12/13/anthropology-in-ruins/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34049130">https://news.ycombinator.com/item?id=34049130</a></p>
<p>Points: 31</p>
<p># Comments: 5</p>

## How Many Computers Are in Your Computer? (2021)
 - [https://www.gwern.net/Computers](https://www.gwern.net/Computers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 05:36:44+00:00

<p>Article URL: <a href="https://www.gwern.net/Computers">https://www.gwern.net/Computers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34048881">https://news.ycombinator.com/item?id=34048881</a></p>
<p>Points: 15</p>
<p># Comments: 0</p>

## Ask HN: Can you recommend an “instant-switch” Monitor? Does one exist?
 - [https://news.ycombinator.com/item?id=34048573](https://news.ycombinator.com/item?id=34048573)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 04:41:25+00:00

<p>Current situation:
- I have three sources connected to my monitor (1 HDMI, 1 DP, 1 USB C).
- The monitor is on a switched off source i.e. due power save mode.
- When I try to switch to another source, it takes 4 seconds or more to switch<p>What the monitor should do: S
- Switch instantly no matter if the current source is on or not.<p>WHY the long delay???
It is really something that angers me.every.damn.time.<p>I have a Dell U2723QE, but older models have that as well as others from other brands.<p>Would love to get a recommendation for an instant switch model.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34048573">https://news.ycombinator.com/item?id=34048573</a></p>
<p>Points: 20</p>
<p># Comments: 11</p>

## You can’t take it with you: straight talk about epigenetics
 - [https://razib.substack.com/p/you-cant-take-it-with-you-straight](https://razib.substack.com/p/you-cant-take-it-with-you-straight)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 04:19:16+00:00

<p>Article URL: <a href="https://razib.substack.com/p/you-cant-take-it-with-you-straight">https://razib.substack.com/p/you-cant-take-it-with-you-straight</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34048432">https://news.ycombinator.com/item?id=34048432</a></p>
<p>Points: 16</p>
<p># Comments: 5</p>

## Discrete Logic IC CPU
 - [https://imihajlov.tk/blog/posts/ccpu/](https://imihajlov.tk/blog/posts/ccpu/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 03:31:14+00:00

<p>Article URL: <a href="https://imihajlov.tk/blog/posts/ccpu/">https://imihajlov.tk/blog/posts/ccpu/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34048082">https://news.ycombinator.com/item?id=34048082</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## The Risk of Orbital Debris and One (Cheap) Way to Mitigate It
 - [https://locationtbd.home.blog/2022/12/17/how-free-radar-data-can-save-billions-of-dollars/](https://locationtbd.home.blog/2022/12/17/how-free-radar-data-can-save-billions-of-dollars/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 03:19:28+00:00

<p>Article URL: <a href="https://locationtbd.home.blog/2022/12/17/how-free-radar-data-can-save-billions-of-dollars/">https://locationtbd.home.blog/2022/12/17/how-free-radar-data-can-save-billions-of-dollars/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34047984">https://news.ycombinator.com/item?id=34047984</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Enhance Speech from Adobe – Free AI filter for cleaning up spoken audio
 - [https://podcast.adobe.com/enhance](https://podcast.adobe.com/enhance)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 03:18:22+00:00

<p>Article URL: <a href="https://podcast.adobe.com/enhance">https://podcast.adobe.com/enhance</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34047976">https://news.ycombinator.com/item?id=34047976</a></p>
<p>Points: 36</p>
<p># Comments: 11</p>

## Steroids are rampant among fitness influencers, trainers and bodybuilders
 - [https://www.insider.com/fitness-influencers-steroids-secret-dangerous-body-dysmorphia](https://www.insider.com/fitness-influencers-steroids-secret-dangerous-body-dysmorphia)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 02:48:46+00:00

<p>Article URL: <a href="https://www.insider.com/fitness-influencers-steroids-secret-dangerous-body-dysmorphia">https://www.insider.com/fitness-influencers-steroids-secret-dangerous-body-dysmorphia</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34047737">https://news.ycombinator.com/item?id=34047737</a></p>
<p>Points: 13</p>
<p># Comments: 4</p>

## Ryujinx (Switch Emulator) Update
 - [https://blog.ryujinx.org/progress-report-november-2022/](https://blog.ryujinx.org/progress-report-november-2022/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 02:31:56+00:00

<p>Article URL: <a href="https://blog.ryujinx.org/progress-report-november-2022/">https://blog.ryujinx.org/progress-report-november-2022/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34047607">https://news.ycombinator.com/item?id=34047607</a></p>
<p>Points: 19</p>
<p># Comments: 7</p>

## Explicit Ontologies in a World Without
 - [https://davidbieber.com/snippets/2022-12-16-note-taking-ontologies/](https://davidbieber.com/snippets/2022-12-16-note-taking-ontologies/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 01:59:20+00:00

<p>Article URL: <a href="https://davidbieber.com/snippets/2022-12-16-note-taking-ontologies/">https://davidbieber.com/snippets/2022-12-16-note-taking-ontologies/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34047320">https://news.ycombinator.com/item?id=34047320</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## A Math Problem Generator
 - [https://github.com/lukew3/mathgenerator](https://github.com/lukew3/mathgenerator)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 01:34:28+00:00

<p>Article URL: <a href="https://github.com/lukew3/mathgenerator">https://github.com/lukew3/mathgenerator</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34047076">https://news.ycombinator.com/item?id=34047076</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Pollution cleanup method destroys toxic “forever chemicals”
 - [https://news.ucr.edu/articles/2022/12/12/pollution-cleanup-method-destroys-toxic-forever-chemicals](https://news.ucr.edu/articles/2022/12/12/pollution-cleanup-method-destroys-toxic-forever-chemicals)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 01:31:21+00:00

<p>Article URL: <a href="https://news.ucr.edu/articles/2022/12/12/pollution-cleanup-method-destroys-toxic-forever-chemicals">https://news.ucr.edu/articles/2022/12/12/pollution-cleanup-method-destroys-toxic-forever-chemicals</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34047047">https://news.ycombinator.com/item?id=34047047</a></p>
<p>Points: 37</p>
<p># Comments: 8</p>

## NumPy 1.24 Release Notes
 - [https://github.com/numpy/numpy/releases/tag/v1.24.0](https://github.com/numpy/numpy/releases/tag/v1.24.0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 00:31:09+00:00

<p>Article URL: <a href="https://github.com/numpy/numpy/releases/tag/v1.24.0">https://github.com/numpy/numpy/releases/tag/v1.24.0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34046434">https://news.ycombinator.com/item?id=34046434</a></p>
<p>Points: 21</p>
<p># Comments: 0</p>

## Toyota chief says ‘silent majority’ has doubts about pursuing only EVs
 - [https://www.wsj.com/articles/toyota-president-says-silent-majority-has-doubts-about-pursuing-only-evs-11671372223](https://www.wsj.com/articles/toyota-president-says-silent-majority-has-doubts-about-pursuing-only-evs-11671372223)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-19 00:23:17+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/toyota-president-says-silent-majority-has-doubts-about-pursuing-only-evs-11671372223">https://www.wsj.com/articles/toyota-president-says-silent-majority-has-doubts-about-pursuing-only-evs-11671372223</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34046354">https://news.ycombinator.com/item?id=34046354</a></p>
<p>Points: 11</p>
<p># Comments: 6</p>


# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Why Saudi says no to Oil-for-Yuan/Bad visit: Xi visit back from Saudi Arabia led to a lot of trouble
 - [https://www.youtube.com/watch?v=lguEsu6nYS0](https://www.youtube.com/watch?v=lguEsu6nYS0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2022-12-19 05:11:12+00:00

#chinainsights 
Since when does Iran support Taiwan's independence? Since December 10, 2022. This is the front page of the Iranian newspaper "Arman Daily" with a bold headline: "Taiwan's Independence, Legitimate Right."
The original attempt by the CCP to bring in Saudi Arabia at a time when it is at odds with the U.S. has brought unexpected troubles. Does Beijing have the ability to solve them? And did the CCP leader get what he really wants after visiting Saudi Arabia? In this episode, we explore these issues.

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.


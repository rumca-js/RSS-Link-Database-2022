# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Lubuskie: Wybuch pakunku. Trzy osoby zostały ranne, w tym dzieci
 - [https://wydarzenia.interia.pl/kraj/news-lubuskie-wybuch-pakunku-trzy-osoby-zostaly-ranne-w-tym-dziec,nId,6482299](https://wydarzenia.interia.pl/kraj/news-lubuskie-wybuch-pakunku-trzy-osoby-zostaly-ranne-w-tym-dziec,nId,6482299)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-12-19 08:58:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-lubuskie-wybuch-pakunku-trzy-osoby-zostaly-ranne-w-tym-dziec,nId,6482299"><img align="left" alt="Lubuskie: Wybuch pakunku. Trzy osoby zostały ranne, w tym dzieci" src="https://i.iplsc.com/lubuskie-wybuch-pakunku-trzy-osoby-zostaly-ranne-w-tym-dziec/000D33789Y4P7TLG-C321.jpg" /></a>W miejscowości Siecieborzyce w pow. żagańskim w woj. lubuskim doszło do wybuchu niewiadomego pochodzenia pakunku - przekazał rzecznik lubuskiej policji Marcin Maludy. Na skutek eksplozji w domu jednorodzinnym ranne zostały trzy osoby, kobieta i dwoje dzieci. Służby ustalają okoliczności zdarzenia.</p><br clear="all" />


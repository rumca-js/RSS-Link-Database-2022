# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## 5 Headphones You Can Buy Right Now for Under $100
 - [https://lifehacker.com/5-headphones-you-can-buy-right-now-for-under-100-1849910889](https://lifehacker.com/5-headphones-you-can-buy-right-now-for-under-100-1849910889)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 22:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--kR5L5NNT--/c_fit,fl_progressive,q_80,w_636/fe4ccf6b034bd70a3a168a2ef3fb6f50.jpg" /><p>Your Christmas shopping deadline is approaching ever more quickly, but you can still give the gift of a nice set of (affordable) headphones in time for the big day. These are the best deals out there right now for headphones under $100, most of which can still be <a href="https://lifehacker.com/here-are-the-2022-holiday-shipping-deadlines-1849904837">delivered in time for Christmas</a>. There’s an option for…</p><p><a href="https://lifehacker.com/5-headphones-you-can-buy-right-now-for-under-100-1849910889">Read more...</a></p>

## Five Cheesy Party Snacks You Can Make With Two Ingredients (or Fewer)
 - [https://lifehacker.com/five-cheesy-party-snacks-you-can-make-with-two-ingredie-1849910916](https://lifehacker.com/five-cheesy-party-snacks-you-can-make-with-two-ingredie-1849910916)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--CNqAbT4k--/c_fit,fl_progressive,q_80,w_636/d60b360ccc176029e4f18d20825483bf.jpg" /><p>Cheese is crowdpleaser—a perfect product that can be sliced, melted, or otherwise manipulated into something that is a little more involved, like a <a href="https://lifehacker.com/3-cheesy-dips-that-are-way-better-than-whatever-chipotl-1818528845">dip</a> or a <a href="https://lifehacker.com/you-should-make-cheeseballs-for-your-holiday-party-1820847699">cheeseball</a>. Because it’s so good in its own right, it doesn’t need a ton of futzing. You can turn a log of goat cheese or pile of shredded cheddar into an elegant…</p><p><a href="https://lifehacker.com/five-cheesy-party-snacks-you-can-make-with-two-ingredie-1849910916">Read more...</a></p>

## Your Windows PC Has Hidden Themes
 - [https://lifehacker.com/your-windows-pc-has-hidden-themes-1849911491](https://lifehacker.com/your-windows-pc-has-hidden-themes-1849911491)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--qGVke8ul--/c_fit,fl_progressive,q_80,w_636/9ec31bd6c88597a074b6c49c2b5fab3c.png" /><p>Windows themes offer a unique mix of wallpapers, sounds, and colors to switch between. Many of them come by default, and there are more themes to download from the Windows Store. But you don’t need to look elsewhere to find more themes for your PC. Some of the best Windows themes are just hidden.</p><p><a href="https://lifehacker.com/your-windows-pc-has-hidden-themes-1849911491">Read more...</a></p>

## Your Spin Bike Needs Pedal Adapters
 - [https://lifehacker.com/your-spin-bike-needs-pedal-adapters-1849911520](https://lifehacker.com/your-spin-bike-needs-pedal-adapters-1849911520)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--7x3GrTH5--/c_fit,fl_progressive,q_80,w_636/3c644690c31d463ee1eb4802d196c85a.jpg" /><p>Cycling shoes are a must if you own a spin bike, and they’re extremely common on road bikes, too. The shoes are stiff enough to properly transmit force to the pedals, and the cleats lock you securely into the pedals so that you don’t slide around. With the right shoes, you can efficiently turn the pedals in circles…</p><p><a href="https://lifehacker.com/your-spin-bike-needs-pedal-adapters-1849911520">Read more...</a></p>

## 12 Unexpected Ways to Use Bubble Wrap Around the House
 - [https://lifehacker.com/12-unexpected-ways-to-use-bubble-wrap-around-the-house-1849911360](https://lifehacker.com/12-unexpected-ways-to-use-bubble-wrap-around-the-house-1849911360)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--4mAklxci--/c_fit,fl_progressive,q_80,w_636/40fbdf7b9e510d2332cdea6c98b5e8a5.jpg" /><p>Bubble wrap is the best. It can obviously help you move to a new place without breaking stuff, and of course it’s fun to play with. But it can also do <em>so much</em> <em>more</em> than you might think. Put it in the category of things like <a href="https://lifehacker.com/18-of-the-best-uses-for-vodka-besides-the-obvious-1849769532">vodka</a>, <a href="https://lifehacker.com/12-of-the-best-household-uses-for-hair-conditioner-1849678660">hair conditioner</a>, <a href="https://lifehacker.com/17-household-uses-for-dryer-sheets-outside-of-a-dryer-1846687744">dryer sheets</a>, and <a href="https://lifehacker.com/14-unexpected-household-uses-for-nail-polish-remover-1848771298">nail polish remover</a>, which all have one stated…</p><p><a href="https://lifehacker.com/12-unexpected-ways-to-use-bubble-wrap-around-the-house-1849911360">Read more...</a></p>

## Don't Remove a Stolen iPhone From Your Apple ID (Do This Instead)
 - [https://lifehacker.com/dont-remove-a-stolen-iphone-from-your-apple-id-do-this-1849910519](https://lifehacker.com/dont-remove-a-stolen-iphone-from-your-apple-id-do-this-1849910519)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 19:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--9EB-sQnd--/c_fit,fl_progressive,q_80,w_636/ab9baa3c02e7084fc659f7fa839230b8.jpg" /><p>Your iPhone has some excellent anti-theft features that make it difficult for thieves to use the device. Even if someone wipes your phone, they’ll still need your Apple ID and password to get into it and turn off “Find My”—which they’ll need to do if they ever want to sell it. <br /><br />However, the information on your phone…</p><p><a href="https://lifehacker.com/dont-remove-a-stolen-iphone-from-your-apple-id-do-this-1849910519">Read more...</a></p>

## Use This Site to Get Your Instagram Back After Getting Locked Out
 - [https://lifehacker.com/use-this-site-to-get-your-instagram-back-after-getting-1849910487](https://lifehacker.com/use-this-site-to-get-your-instagram-back-after-getting-1849910487)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--N1YgQJd6--/c_fit,fl_progressive,q_80,w_636/0d92c4c54865ac711e00730af006f68b.jpg" /><p>Getting hacked <em>sucks</em>. The invasion of privacy is bad enough, but when hackers decide to lock you out of your account entirely, that’s just cruel. Losing access to your years of Instagram photos, stories, and DMs can be heartbreaking, and, until now, it was usually permanent. Luckily, that might not be the case anymore.<br /></p><p><a href="https://lifehacker.com/use-this-site-to-get-your-instagram-back-after-getting-1849910487">Read more...</a></p>

## Here’s Your Year-End Financial Checklist
 - [https://lifehacker.com/here-s-your-year-end-financial-checklist-1849910676](https://lifehacker.com/here-s-your-year-end-financial-checklist-1849910676)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--WBvBnnCq--/c_fit,fl_progressive,q_80,w_636/12f3b3ac10e85a7c4d3470f9abcec79f.jpg" /><p>The end of the year is always a time for reflection, and your personal finances are no exception. Even in a year marked by <a href="https://lifehacker.com/6-of-the-best-videos-to-actually-help-you-understand-in-1849757643">record-high inflation</a>, there’s a good chance <a href="https://lifehacker.com/the-signs-that-your-finances-aren-t-as-bad-as-you-think-1849763526">your finances aren’t as bad as you might think</a>. But as 2022 winds down, it’s the perfect time to conduct a year-end review. Using the buckets below,…</p><p><a href="https://lifehacker.com/here-s-your-year-end-financial-checklist-1849910676">Read more...</a></p>

## 15 Delayed Movies That Are Finally Coming Out in 2023
 - [https://lifehacker.com/15-delayed-movies-that-are-finally-coming-out-in-2023-1849908964](https://lifehacker.com/15-delayed-movies-that-are-finally-coming-out-in-2023-1849908964)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 18:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--rf3iSUyw--/c_fit,fl_progressive,q_80,w_636/69ea1d4afd9c7962784696c8362fa035.jpg" /><p>In addition to being a global disaster in many ways that matter a good deal more, COVID took a wrecking ball to the film industry, and Hollywood is still cleaning up the debris. Countless films have been re-edited, delayed, and outright cancelled as a result of necessary COVID restrictions, illnesses, financial…</p><p><a href="https://lifehacker.com/15-delayed-movies-that-are-finally-coming-out-in-2023-1849908964">Read more...</a></p>

## 9 Ways to Give Your ‘Performance’ Oatmeal a Competitive Edge
 - [https://lifehacker.com/9-ways-to-give-your-performance-oatmeal-a-competitive-1849905042](https://lifehacker.com/9-ways-to-give-your-performance-oatmeal-a-competitive-1849905042)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 17:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--u7jLdNFb--/c_fit,fl_progressive,q_80,w_636/c6ed505fd19f02bfc7e7017d0199157b.jpg" /><p>Oatmeal is one of the great underrated foods for athletes, whether you’re a runner, a weightlifter, or just somebody who wants a filling breakfast before hitting the gym. If you want more whole grains or fiber in your diet, congrats—oats have plenty. If you need carbs to fuel you, oats come through there, as well. And…</p><p><a href="https://lifehacker.com/9-ways-to-give-your-performance-oatmeal-a-competitive-1849905042">Read more...</a></p>

## The 10 Best Chrome Extensions of 2022, According to Google
 - [https://lifehacker.com/the-10-best-chrome-extensions-of-2022-according-to-goo-1849909441](https://lifehacker.com/the-10-best-chrome-extensions-of-2022-according-to-goo-1849909441)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--RIbg52PU--/c_fit,fl_progressive,q_80,w_636/73f2cab7728152994ae29d8d7506e26d.jpg" /><p>Google annually goes though its web store to find the best and most popular Chrome extensions of the year. It’s no Spotify Wrapped, but it’s a good way to know what made this year special (as far as internet browsing is concerned, anyway). And in 2022, it’s no surprise that AI shows up in a lot of the extensions.</p><p><a href="https://lifehacker.com/the-10-best-chrome-extensions-of-2022-according-to-goo-1849909441">Read more...</a></p>

## What's New on Prime Video in January 2023
 - [https://lifehacker.com/whats-new-on-prime-video-in-january-2023-1849909928](https://lifehacker.com/whats-new-on-prime-video-in-january-2023-1849909928)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--6XWM5rcm--/c_fit,fl_progressive,q_80,w_636/59906bebcfc7b5e14ba1194aeb69a2e9.png" /><p>The first season of Prime Video’s <em>Hunters,</em> a late-’70s action drama about a group of Nazi hunters tracking down surviving members of the Third Reich, premiered in late February 2020. I used to walk by the subway ad for it every day while dropping my kid off at school. Then the school shut down, along with everything…</p><p><a href="https://lifehacker.com/whats-new-on-prime-video-in-january-2023-1849909928">Read more...</a></p>

## You Deserve This Gorgonzola Caramelized Onion Tarte Tatin
 - [https://lifehacker.com/you-deserve-this-gorgonzola-caramelized-onion-tarte-tat-1849909867](https://lifehacker.com/you-deserve-this-gorgonzola-caramelized-onion-tarte-tat-1849909867)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--O_fMM1Hx--/c_fit,fl_progressive,q_80,w_636/1c4ef5d313dae2e69a9cbca87abde557.jpg" /><p>A classic tarte tatin is sweet, stuffed with apples, and requires a bit of fussing over a caramel sauce. It’s worth the effort when you’re looking for a sweet dessert, but you can also use the same technique for a dish that’s superbly savory. For a simple, shareable, and rather impressive plate, make a gorgonzola and…</p><p><a href="https://lifehacker.com/you-deserve-this-gorgonzola-caramelized-onion-tarte-tat-1849909867">Read more...</a></p>

## 5 Smartwatches You Can Buy for Under $200
 - [https://lifehacker.com/5-smartwatches-you-can-buy-for-under-200-1849905601](https://lifehacker.com/5-smartwatches-you-can-buy-for-under-200-1849905601)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 15:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--VkiZrG4h--/c_fit,fl_progressive,q_80,w_636/787961c961f493f8868576d3a6b1969f.jpg" /><p>As the New Year approaches, you’ll be reminded a million times of your health and fitness goals. And if you—or someone you’re shopping for—wants a smartwatch to help meet those goals (along with measuring sleep quality and telling us how many steps we took to the kitchen and back), here are some of the best current…</p><p><a href="https://lifehacker.com/5-smartwatches-you-can-buy-for-under-200-1849905601">Read more...</a></p>

## Four Ways to Make a Better Spinach and Artichoke Dip
 - [https://lifehacker.com/four-ways-to-make-a-better-spinach-and-artichoke-dip-1849905427](https://lifehacker.com/four-ways-to-make-a-better-spinach-and-artichoke-dip-1849905427)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--dog57lz8--/c_fit,fl_progressive,q_80,w_636/25106e0d63d26944345cc1cf309d7e29.jpg" /><p>I don’t know that I’ve ever had a bad spinach and artichoke dip—it’s hard to make something with that much dairy and salt unappetizing. But things that are good can always be great, and I have taken the liberty of compiling four upgrades that can be applied to any spinach and artichoke dip recipe.</p><p><a href="https://lifehacker.com/four-ways-to-make-a-better-spinach-and-artichoke-dip-1849905427">Read more...</a></p>

## The 7 Deadly Sins of Setting Your New Year's Resolutions
 - [https://lifehacker.com/the-7-deadly-sins-of-setting-your-new-years-resolutions-1849908667](https://lifehacker.com/the-7-deadly-sins-of-setting-your-new-years-resolutions-1849908667)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 14:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--L0iFIusJ--/c_fit,fl_progressive,q_80,w_636/4bee46bfb72758066257f31d0564a55d.jpg" /><p>Research on New Year’s resolutions shows that <a href="https://health.usnews.com/health-news/blogs/eat-run/articles/2015-12-29/why-80-percent-of-new-years-resolutions-fail" rel="noopener noreferrer" target="_blank">80% of them fail in the longterm</a>. Given the difficulty of self-improvement, I find a 20% success rate encouraging, but that still means almost everyone who bothers to try doesn’t live up to their own goals. Avoiding these seven New Year’s resolution mistakes won’t…</p><p><a href="https://lifehacker.com/the-7-deadly-sins-of-setting-your-new-years-resolutions-1849908667">Read more...</a></p>

## You Actually Do Need to Engage in Office Politics
 - [https://lifehacker.com/you-actually-do-need-to-engage-in-office-politics-1849903141](https://lifehacker.com/you-actually-do-need-to-engage-in-office-politics-1849903141)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-19 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--BOVN4Ojl--/c_fit,fl_progressive,q_80,w_636/3423bdbaacadb4c68f24a4af8eb38b64.jpg" /><p>For many, the words “office politics” conjure images of manipulating, back-stabbing, or slippery co-workers who kiss-up to the boss and flaunt their influence to get what they want. The words reek of unfairness and are almost always used to refer to the underbelly of the workplace. Many employees flat out refuse to…</p><p><a href="https://lifehacker.com/you-actually-do-need-to-engage-in-office-politics-1849903141">Read more...</a></p>


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## The Controversy Around Brittney Griner's Return
 - [https://www.youtube.com/watch?v=NbvEt_v7cb0](https://www.youtube.com/watch?v=NbvEt_v7cb0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-12-20 00:00:00+00:00

Taken from JRE #1914 w/Steve Rinella:
https://open.spotify.com/episode/5gmvcluhV8synvj5H9XcEJ?si=bc628cf07dae4fab

## The Debate Over Reintroducing Jaguars to North America
 - [https://www.youtube.com/watch?v=m2LThhFmnXo](https://www.youtube.com/watch?v=m2LThhFmnXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-12-20 00:00:00+00:00

Taken from JRE #1914 w/Steve Rinella:
https://open.spotify.com/episode/5gmvcluhV8synvj5H9XcEJ?si=f1563db79a0b4e0a


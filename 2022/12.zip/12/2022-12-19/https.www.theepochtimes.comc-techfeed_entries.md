# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## Report: Teens Warned to Be on Alert for Online Scams Ahead of Holiday Season
 - [https://www.theepochtimes.com/report-teens-warned-to-be-on-alert-for-online-scams-ahead-of-holiday-season_4931292.html](https://www.theepochtimes.com/report-teens-warned-to-be-on-alert-for-online-scams-ahead-of-holiday-season_4931292.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-19 14:20:31+00:00

The logos of mobile apps Instagram, Snapchat, Twitter, Facebook, Google, and Messenger displayed on a tablet on Oct. 1, 2019. (AFP via Getty Images/Denis Charlet)

## FBI Faces Subpoenas After Twitter Files Exposing Social Media Ties: House Republican
 - [https://www.theepochtimes.com/fbi-faces-subpoenas-after-twitter-files-exposing-social-media-ties-house-republican_4932275.html](https://www.theepochtimes.com/fbi-faces-subpoenas-after-twitter-files-exposing-social-media-ties-house-republican_4932275.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-19 13:26:07+00:00

Rep. Michael Turner (R-Ohio) speaks during a press conference on the 2023 Fiscal Year at the Capitol Building in Washington on Dec. 14, 2022. (Anna Moneymaker/Getty Images)

## Majority Vote ‘Yes’ for Elon Musk to Step Down as Head of Twitter
 - [https://www.theepochtimes.com/majority-vote-yes-for-elon-musk-to-step-down-as-head-of-twitter_4932176.html](https://www.theepochtimes.com/majority-vote-yes-for-elon-musk-to-step-down-as-head-of-twitter_4932176.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-19 12:11:50+00:00

A 3D printed Twitter logo is seen in front of a displayed photo of Elon Musk in this illustration taken on Oct. 27, 2022. (Dado Ruvic/Illustration/Reuters)

## Twitter Bans ‘Free Promotion’ of Other Social Media Platforms, Then Loosens New Rule
 - [https://www.theepochtimes.com/twitter-bans-free-promotion-of-other-social-media-platforms-then-loosening-new-rules_4931940.html](https://www.theepochtimes.com/twitter-bans-free-promotion-of-other-social-media-platforms-then-loosening-new-rules_4931940.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-19 06:24:53+00:00

Elon Musk on a smartphone placed on printed Twitter logos on April 28, 2022. (Dado Ruvic/Illustration/Reuters)

## Internal Twitter Records Show FBI Questioned Twitter on State Propaganda
 - [https://www.theepochtimes.com/internal-twitter-records-show-fbi-questioned-twitter-on-state-propaganda_4931913.html](https://www.theepochtimes.com/internal-twitter-records-show-fbi-questioned-twitter-on-state-propaganda_4931913.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-19 05:10:12+00:00

A sign at Twitter headquarters in San Francisco on Dec. 8, 2022. (Jeff Chiu/AP Photo)

## Musk Launches Poll Asking If He Should Step Down From Twitter
 - [https://www.theepochtimes.com/musk-launches-poll-asking-if-he-should-step-down-from-twitter_4931785.html](https://www.theepochtimes.com/musk-launches-poll-asking-if-he-should-step-down-from-twitter_4931785.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-19 00:01:22+00:00

Elon Musk on a smartphone placed on printed Twitter logos on April 28, 2022. (Dado Ruvic/Illustration/Reuters)


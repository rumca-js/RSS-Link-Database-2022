# Source:Forbs - innovation, URL:https://www.forbes.com/innovation/feed2, language:en-US

## Hybrid Workplaces Are Great, But May Feel Too Transactional
 - [https://www.forbes.com/sites/joemckendrick/2022/12/19/hybrid-workplaces-are-great-but-may-feel-too-transactional/](https://www.forbes.com/sites/joemckendrick/2022/12/19/hybrid-workplaces-are-great-but-may-feel-too-transactional/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 23:27:00+00:00

Lost in the virtual work transaction: the serendipity of in-person encounters

## The Quantum Leap In AI's Healthcare Revolution
 - [https://www.forbes.com/video/6317510458112/](https://www.forbes.com/video/6317510458112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 22:45:12+00:00

The Quantum Leap In AI's Healthcare Revolution

## Talking Openly About Mental Health In The Workplace
 - [https://www.forbes.com/video/6317509783112/](https://www.forbes.com/video/6317509783112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 22:44:25+00:00

Talking Openly About Mental Health In The Workplace

## Rockstar And Warrior: Finding Resilience
 - [https://www.forbes.com/video/6317509945112/](https://www.forbes.com/video/6317509945112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 22:43:29+00:00

Rockstar And Warrior: Finding Resilience

## Betting On HealthTech: The Innovators
 - [https://www.forbes.com/video/6317507659112/](https://www.forbes.com/video/6317507659112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 22:42:16+00:00

Betting On HealthTech: The Innovators

## Next Billion Dollar Healthcare Platforms
 - [https://www.forbes.com/video/6317508680112/](https://www.forbes.com/video/6317508680112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 22:41:48+00:00

Next Billion Dollar Healthcare Platforms

## Leading By Example: Building Healthy Communities
 - [https://www.forbes.com/video/6317510737112/](https://www.forbes.com/video/6317510737112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 22:39:52+00:00

Leading By Example: Building Healthy Communities

## A Michelin-Star Story: Bringing People Together with Food
 - [https://www.forbes.com/video/6317511046112/](https://www.forbes.com/video/6317511046112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 22:39:06+00:00

A Michelin-Star Story: Bringing People Together with Food

## Spotlight: How Tech Can Transform the U.S. Mental Healthcare System
 - [https://www.forbes.com/video/6317510173112/](https://www.forbes.com/video/6317510173112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 22:38:17+00:00

Spotlight: How Tech Can Transform the U.S. Mental Healthcare System

## International Drug Conspiracy Used Binance To Launder Millions, DEA Investigation Finds
 - [https://www.forbes.com/sites/thomasbrewster/2022/12/19/mexican-drug-gang-money-laundering-over-binance-crypto-exchange/](https://www.forbes.com/sites/thomasbrewster/2022/12/19/mexican-drug-gang-money-laundering-over-binance-crypto-exchange/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 21:50:17+00:00

Mexican drug gangs are still dabbling in cryptocurrencies, says Binance, as it helps the DEA investigate as much as $50 million in suspect transactions.

## Spotlight: Improving Care For Hearing Loss
 - [https://www.forbes.com/video/6317510561112/](https://www.forbes.com/video/6317510561112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 21:22:44+00:00

Spotlight: Improving Care For Hearing Loss

## Mind Matters: Giving A Voice To The Mental Health Crisis
 - [https://www.forbes.com/video/6317508233112/](https://www.forbes.com/video/6317508233112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 21:21:26+00:00

Mind Matters: Giving A Voice To The Mental Health Crisis

## Advancing Health Beyond Healthcare
 - [https://www.forbes.com/video/6317509715112/](https://www.forbes.com/video/6317509715112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 21:10:58+00:00

Advancing Health Beyond Healthcare

## Improving Cancer Care for The Underserved
 - [https://www.forbes.com/video/6317508223112/](https://www.forbes.com/video/6317508223112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 21:08:25+00:00

Improving Cancer Care for The Underserved

## Endangered Australian Frog Songs Are Hopping Their Way Up The ARIA Music Chart
 - [https://www.forbes.com/sites/grrlscientist/2022/12/19/endangered-australian-frog-songs-are-hopping-their-way-up-the-aria-music-chart/](https://www.forbes.com/sites/grrlscientist/2022/12/19/endangered-australian-frog-songs-are-hopping-their-way-up-the-aria-music-chart/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 21:08:01+00:00

Are you STILL trying to find the perfect holiday gift for the person who has everything, or who wants nothing? How about an album featuring the love songs of Endangered Australian frogs?

## Spotlight: Preventing The Next Global Public Health Crisis
 - [https://www.forbes.com/video/6317509601112/](https://www.forbes.com/video/6317509601112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 20:57:45+00:00

Spotlight: Preventing The Next Global Public Health Crisis

## Moving Cash In The Digital World
 - [https://www.forbes.com/sites/servicenow/2022/12/19/moving-cash-in-the-digital-world/](https://www.forbes.com/sites/servicenow/2022/12/19/moving-cash-in-the-digital-world/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 20:49:51+00:00

How a global logistics company created virtual experiences around cash management.

## The Pentagon’s $45 Billion 140 MHz Spectrum Blindspot
 - [https://www.forbes.com/sites/roslynlayton/2022/12/19/the-pentagons-45-billion-140-mhz-spectrum-blindspot/](https://www.forbes.com/sites/roslynlayton/2022/12/19/the-pentagons-45-billion-140-mhz-spectrum-blindspot/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 20:31:54+00:00

Squandering frequencies imperils Americans’ security, 5G preparedness, and prosperity.

## Musk Remains Silent Eight Hours After Poll Supporting His Resignation As Twitter CEO Ends
 - [https://www.forbes.com/sites/dereksaul/2022/12/19/musk-remains-silent-eight-hours-after-poll-supporting-his-resignation-as-twitter-ceo-ends/](https://www.forbes.com/sites/dereksaul/2022/12/19/musk-remains-silent-eight-hours-after-poll-supporting-his-resignation-as-twitter-ceo-ends/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 20:18:14+00:00

It’s an unusually dark social media period for the world’s second-wealthiest man.

## Successes Like The Covid-19 Vaccines Come From Long-Term Investments In Public Health
 - [https://www.forbes.com/sites/williamhaseltine/2022/12/19/successes-like-the-covid-19-vaccines-come-from-long-term-investments-in-public-health/](https://www.forbes.com/sites/williamhaseltine/2022/12/19/successes-like-the-covid-19-vaccines-come-from-long-term-investments-in-public-health/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 20:17:26+00:00

The Covid-19 vaccines have prevented more than 18 million additional hospitalizations and more than 3 million additional deaths in the United States alone but their success was only possible because of sustained investments in public health.

## This Smart Device Is A Living Organism That Changed The Users Interaction
 - [https://www.forbes.com/sites/jenniferhicks/2022/12/19/this-smart-device-is-a-living-organism-that-changed-the-users-interaction/](https://www.forbes.com/sites/jenniferhicks/2022/12/19/this-smart-device-is-a-living-organism-that-changed-the-users-interaction/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 20:15:42+00:00

If your smart device was a living organism, would you treat it differently? Would it change how you dispose of electronic devices? These researchers put the theory to the test.

## SEC: Punishing Progress While Rewarding Confusion
 - [https://www.forbes.com/sites/roslynlayton/2022/12/19/sec-punishing-progress-while-rewarding-confusion/](https://www.forbes.com/sites/roslynlayton/2022/12/19/sec-punishing-progress-while-rewarding-confusion/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 19:15:47+00:00

The agency hammers legit crypto enterprises like Grayscale, Ripple Robinhood, and Coinbase while fraudsters like FTX erupt unchecked.

## Cisco's Latest Purpose Report Brings To Life Its "People, Profit And Planet" Focus
 - [https://www.forbes.com/sites/carolinamilanesi/2022/12/19/ciscos-latest-purpose-report-brings-to-life-its-people-profit-and-planet-focus/](https://www.forbes.com/sites/carolinamilanesi/2022/12/19/ciscos-latest-purpose-report-brings-to-life-its-people-profit-and-planet-focus/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 18:49:37+00:00

Cisco has been focusing on Environment, Social and Governance (ESG) before it was even called ESG. The first thing that struck me from reading Cisco's 2022 Purpose Report is how holistically the company looks at the impact it can have on its people, the communities they reach and the environment.

## Why HPE Is Dialing Into New Cloud Opportunities
 - [https://www.forbes.com/sites/rscottraynovich/2022/12/19/why-hpe-is-dialing-into-new-cloud-opportunities/](https://www.forbes.com/sites/rscottraynovich/2022/12/19/why-hpe-is-dialing-into-new-cloud-opportunities/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 17:36:36+00:00

HPE provided a more favorable outlook than Dell or NetApp.

## Celine Dion Diagnosed With Stiff-Person Syndrome
 - [https://www.forbes.com/sites/lakenbrooks/2022/12/19/celine-dion-diagnosed-with-stiff-person-syndrome/](https://www.forbes.com/sites/lakenbrooks/2022/12/19/celine-dion-diagnosed-with-stiff-person-syndrome/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 17:29:22+00:00

Dion’s diagnosis raises awareness about this rare neurological condition. Disabled musicians and concertgoers argue that inaccessibility in the entertainment industry is a deep-seated issue.

## Waterways To Resilience: A Series On Nature-Based Solutions For Water And Climate Challenges In Africa
 - [https://www.forbes.com/sites/jeffopperman/2022/12/19/waterways-to-resilience-a-series-on-nature-based-solutions-for-water-and-climate-challenges-in-africa/](https://www.forbes.com/sites/jeffopperman/2022/12/19/waterways-to-resilience-a-series-on-nature-based-solutions-for-water-and-climate-challenges-in-africa/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 17:28:06+00:00

In a series of blog posts, I’ll explore how Nature-based Solutions can contribute to both climate and nature goals, and will ground that exploration in the water, climate, and nature challenges of Africa.

## Planning A Caribbean Vacation? Here Are Some Infections To Consider Protecting Yourself Against
 - [https://www.forbes.com/sites/judystone/2022/12/19/planning-a-caribbean-vacation-here-are-some-infections-to-consider-protecting-yourself-against/](https://www.forbes.com/sites/judystone/2022/12/19/planning-a-caribbean-vacation-here-are-some-infections-to-consider-protecting-yourself-against/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 17:15:00+00:00

There are some unusual infections you might encounter in travel to the Caribbean. Here's what to watch out for and how to protect yourself.

## Family Arriving For Christmas? Get The Tech Sorted Now
 - [https://www.forbes.com/sites/barrycollins/2022/12/19/family-arriving-for-christmas-get-the-tech-sorted-now/](https://www.forbes.com/sites/barrycollins/2022/12/19/family-arriving-for-christmas-get-the-tech-sorted-now/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 16:30:58+00:00

Make sure tech doesn't ruin your family Christmas with this guide

## A Forgotten Paul McCartney Music Video From 39 Years Ago Reminds Us Of The 1914 Christmas Truce
 - [https://www.forbes.com/sites/petersuciu/2022/12/19/a-forgotten-paul-mccartney-music-video-from-39-years-ago-reminds-us-of-the-1914-christmas-truce/](https://www.forbes.com/sites/petersuciu/2022/12/19/a-forgotten-paul-mccartney-music-video-from-39-years-ago-reminds-us-of-the-1914-christmas-truce/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 15:59:01+00:00

Though the accuracy of the depiction of the truce is debatable, it was an ambitious video that featured more than 100 extras, and McCartney had even cut his hair especially for the shoot.

## Check If You’re Eligible For A ‘Fortnite’ Settlement Refund, And How To Get One
 - [https://www.forbes.com/sites/paultassi/2022/12/19/check-if-youre-eligible-for-a-fortnite-settlement-refund-and-how-to-get-one/](https://www.forbes.com/sites/paultassi/2022/12/19/check-if-youre-eligible-for-a-fortnite-settlement-refund-and-how-to-get-one/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 15:34:27+00:00

This is how to check if you are eligible for a Fortnite settlement refund, and how that process will work.

## Big Challenges And Opportunities: Where’s Cybersecurity Heading In 2023?
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/big-challenges-and-opportunities-wheres-cybersecurity-heading-in-2023/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/big-challenges-and-opportunities-wheres-cybersecurity-heading-in-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 15:15:00+00:00

Cybersecurity risks are unfortunately only going to increase but so will the ability of boards and executive teams to deal with these new challenges. What’s key is to ensure that cybersecurity is at the heart of any organization’s digital strategy.

## Qualcomm’s Snapdragon AR2 Is The World’s First Dedicated Platform For Lightweight Wireless AR Headsets
 - [https://www.forbes.com/sites/moorinsights/2022/12/19/qualcomms-snapdragon-ar2-is-the-worlds-first-dedicated-platform-for-lightweight-wireless-ar-headsets/](https://www.forbes.com/sites/moorinsights/2022/12/19/qualcomms-snapdragon-ar2-is-the-worlds-first-dedicated-platform-for-lightweight-wireless-ar-headsets/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 15:13:25+00:00

Senior Analyst, Mobility & VR, Anshel Sag, gives his analysis of Qualcomm's Snapdragon AR2 for lightweight wireless AR headsets.

## CloudQuant’s Alternative Data Crystal Ball Sees Consumer Services And Rent Declines Ahead
 - [https://www.forbes.com/sites/garydrenik/2022/12/19/cloudquants-alternative-data-crystal-ball-sees-consumer-services-and-rent-declines-ahead/](https://www.forbes.com/sites/garydrenik/2022/12/19/cloudquants-alternative-data-crystal-ball-sees-consumer-services-and-rent-declines-ahead/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 15:00:00+00:00

Morgan Slade of CloudQuant checks his alternative data dials and gauges say on the state of the economy and where to train our sights in 2023.  The forecast for CPI last month came in right on the nose.

## How AI Avatars And Face Filters Are Altering Our Conception Of Beauty
 - [https://www.forbes.com/sites/annahaines/2022/12/19/how-ai-avatars-and-face-filters-are-affecting-our-conception-of-beauty/](https://www.forbes.com/sites/annahaines/2022/12/19/how-ai-avatars-and-face-filters-are-affecting-our-conception-of-beauty/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 15:00:00+00:00

By widening the gap between fantasy and reality, technology that generates the perfect self-image is raising our baseline of beauty. But at what cost?

## Scalable Empathy: The 'Humanics' Of Business In Enterprises
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/scalable-empathy-the-humanics-of-business-in-enterprises/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/scalable-empathy-the-humanics-of-business-in-enterprises/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 15:00:00+00:00

Workplace empathy hasn't gotten the attention it deserves.

## Is Quantum Security The Next Guy’s Problem?
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/is-quantum-security-the-next-guys-problem/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/is-quantum-security-the-next-guys-problem/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 14:45:00+00:00

Defensive cyber innovation must come from industry, even if it is done in partnership with the government.

## Why The Real Estate Industry Lags Behind In Technology—And How To Get Ahead
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/why-the-real-estate-industry-lags-behind-in-technology-and-how-to-get-ahead/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/why-the-real-estate-industry-lags-behind-in-technology-and-how-to-get-ahead/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 14:30:00+00:00

The proptech revolution, while undeniably disruptive, is still in the early adopters phase.

## Severe Droughts Triggered ‘Barbarian Invasion’ Leading To The Downfall Of The Roman Empire
 - [https://www.forbes.com/sites/davidbressan/2022/12/19/severe-droughts-triggered-barbarian-invasion-leading-to-the-downfall-of-the-roman-empire/](https://www.forbes.com/sites/davidbressan/2022/12/19/severe-droughts-triggered-barbarian-invasion-leading-to-the-downfall-of-the-roman-empire/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 14:27:51+00:00

Hunnic peoples migrated westward across Eurasia, switched between farming and herding, and became violent raiders in response to severe drought in the Danube frontier provinces of the Roman empire, a new study argues.

## Santa’s Bringing A Piece Of The Polar Vortex To Town - Prepare Now
 - [https://www.forbes.com/sites/marshallshepherd/2022/12/19/santas-bringing-a-piece-of-the-polar-vortex-to-townprepare-now/](https://www.forbes.com/sites/marshallshepherd/2022/12/19/santas-bringing-a-piece-of-the-polar-vortex-to-townprepare-now/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 14:25:52+00:00

Many kids are watching the Arctic for the arrival of Santa this Christmas. Brutally cold air will also be arriving thanks to the Polar Vortex.

## Three Ways To Become More Knowledgeable About AI
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/three-ways-to-become-more-knowledgeable-about-ai/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/three-ways-to-become-more-knowledgeable-about-ai/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 14:15:00+00:00

AI technology, like many new and fast-moving technologies, presents a specific challenge to business leaders to think through how their business could be improved.

## Epic Will Pay Half A Billion Dollars For ‘Fortnite’ Settlement Over ‘Tricked’ Purchases And Privacy
 - [https://www.forbes.com/sites/paultassi/2022/12/19/epic-will-pay-half-a-billion-dollars-for-fortnite-settlement-over-tricked-purchases-and-privacy/](https://www.forbes.com/sites/paultassi/2022/12/19/epic-will-pay-half-a-billion-dollars-for-fortnite-settlement-over-tricked-purchases-and-privacy/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 14:05:04+00:00

Epic Games has just been slapped with an eye-popping, record-breaking settlement from the FTC that means the end of a pair of civil complaints against the Fortnite publisher.

## Aurora Release Driver Beta 5.0, Another Step Toward Feature Complete
 - [https://www.forbes.com/sites/samabuelsamid/2022/12/19/aurora-release-driver-beta-50-another-step-toward-feature-complete/](https://www.forbes.com/sites/samabuelsamid/2022/12/19/aurora-release-driver-beta-50-another-step-toward-feature-complete/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 14:00:00+00:00

Aurora Innovation is moving a step closer to feature complete status and validating its automated driving system with the release of its Driver Beta 5.0

## How New Technologies Can Help Global Supply Chains Build Resilience
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/how-new-technologies-can-help-global-supply-chains-build-resilience/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/how-new-technologies-can-help-global-supply-chains-build-resilience/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 14:00:00+00:00

It’s been a harrowing few years for the logistics industry.

## Disney Plus’s New ‘National Treasure’ TV Show Is Getting Roasted In Reviews
 - [https://www.forbes.com/sites/paultassi/2022/12/19/disney-pluss-new-national-treasure-tv-show-is-getting-roasted-in-reviews/](https://www.forbes.com/sites/paultassi/2022/12/19/disney-pluss-new-national-treasure-tv-show-is-getting-roasted-in-reviews/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 13:47:33+00:00

While Disney Plus is a great resource for familes with its huge back catalogue, in terms of new releases it lags behind its competitors, and something like National Treasure: Edge of History does not seem like it’s changing that conversation for the better.

## Job-Cuffing Season Is Here: Why You Need To Get A Headstart On End-Of-Year Evaluations
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/job-cuffing-season-is-here-why-you-need-to-get-a-headstart-on-end-of-year-evaluations/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/job-cuffing-season-is-here-why-you-need-to-get-a-headstart-on-end-of-year-evaluations/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 13:45:00+00:00

Workplaces globally have undergone significant changes over the past few years, but that doesn’t mean they can’t take proactive steps to prevent retention from becoming a concern in 2023.

## CAR T Therapy To Treat And Cure Rheumatoid Arthritis
 - [https://www.forbes.com/sites/williamhaseltine/2022/12/19/car-t-therapy-to-treat-and-cure-rheumatoid-arthritis/](https://www.forbes.com/sites/williamhaseltine/2022/12/19/car-t-therapy-to-treat-and-cure-rheumatoid-arthritis/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 13:30:03+00:00

One study progresses towards a cure for rheumatoid arthritis by using CAR T therapy, a treatment originally designed to fight cancer.

## 2023 Predictions For Data-Driven Marketers
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/2023-predictions-for-data-driven-marketers/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/2023-predictions-for-data-driven-marketers/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 13:30:00+00:00

Economic uncertainty will put the squeeze on marketers and martech vendors, but leaders will thrive by doubling down on their investments in data and insights.

## Destiny 2’s Season Of The Seraph Has Two Unsolvable Mysteries Right Now
 - [https://www.forbes.com/sites/paultassi/2022/12/19/destiny-2s-season-of-the-seraph-has-two-unsolvable-mysteries-right-now/](https://www.forbes.com/sites/paultassi/2022/12/19/destiny-2s-season-of-the-seraph-has-two-unsolvable-mysteries-right-now/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 13:27:33+00:00

In a recent TWAB, Bungie made a big point about saying that Destiny 2 would still get new secrets in the future, after fan complaints that they hadn’t done a secret mission or big secret puzzle in a while. They implied some may be quite close indeed:

## 14 Essential Features And Qualities Of An Effective Bug-Tracking System
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/14-essential-features-and-qualities-of-an-effective-bug-tracking-system/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/14-essential-features-and-qualities-of-an-effective-bug-tracking-system/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 13:15:00+00:00

From defining and enforcing standard operating procedures to ensuring you have failsafe processes in place, establishing an effective bug-tracking system takes planning and follow-through.

## How To Select The Right Cloud Data Platform: Cloud Data Warehouse, Cloud Data Lake Or Cloud Data Lakehouse
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/how-to-select-the-right-cloud-data-platform-cloud-data-warehouse-cloud-data-lake-or-cloud-data-lakehouse/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/how-to-select-the-right-cloud-data-platform-cloud-data-warehouse-cloud-data-lake-or-cloud-data-lakehouse/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 13:15:00+00:00

While most organizations have adopted a cloud-first policy, many are struggling with the decision on where or how to migrate their data to the cloud and what cloud data platform (CDP) they should adopt.

## Even Republicans Are Embracing Medicaid Expansion. That's A Costly Mistake.
 - [https://www.forbes.com/sites/sallypipes/2022/12/19/even-republicans-are-embracing-medicaid-expansion-thats-a-costly-mistake/](https://www.forbes.com/sites/sallypipes/2022/12/19/even-republicans-are-embracing-medicaid-expansion-thats-a-costly-mistake/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 13:00:00+00:00

There are plenty of ideas about how to make Medicaid work for the poor Americans it's meant to serve. But ignoring $80 billion in improper payments isn't going to help.

## Global Themes In AI Data: Notes From The Road
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/global-themes-in-ai-data-notes-from-the-road/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/global-themes-in-ai-data-notes-from-the-road/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 13:00:00+00:00

To protect against the potentially catastrophic results of AI bias, we must train models on the right inputs.

## JK Rowling Mocks Trans Gamer For ‘Hogwarts Legacy’ Comments
 - [https://www.forbes.com/sites/paultassi/2022/12/19/jk-rowling-mocks-trans-gamer-for-hogwarts-legacy-comments/](https://www.forbes.com/sites/paultassi/2022/12/19/jk-rowling-mocks-trans-gamer-for-hogwarts-legacy-comments/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 12:54:58+00:00

JK Rowling, author of the Harry Potter series, has become the most prominent face and voice in the world of anti-trans rhetoric, where she spends all day on Twitter sparring with critics and activists.

## Data Stewardship: What Is It, And How Will It Revolutionize Fleets?
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/data-stewardship-what-is-it-and-how-will-it-revolutionize-fleets/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/data-stewardship-what-is-it-and-how-will-it-revolutionize-fleets/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 12:45:00+00:00

In the fleet industry specifically, data is the key to unlocking better safety, efficiency and sustainability for an organization’s vehicles and equipment.

## Addressing Connectivity Challenges In Hard-To-Monitor Locations With IoT Sensing
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/addressing-connectivity-challenges-in-hard-to-monitor-locations-with-iot-sensing/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/addressing-connectivity-challenges-in-hard-to-monitor-locations-with-iot-sensing/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 12:30:00+00:00

For healthcare organizations considering IoT sensing as a potential solution to perform in severe and harsh environments, here are the most important aspects to consider.

## No, You Still Don’t Need Vitamin D Supplements!
 - [https://www.forbes.com/sites/stevensalzberg/2022/12/19/no-you-still-dont-need-vitamin-d-supplements/](https://www.forbes.com/sites/stevensalzberg/2022/12/19/no-you-still-dont-need-vitamin-d-supplements/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 12:30:00+00:00

The NY Times this week ran a story that suggested everyone should take supplemental vitamin D in the winter months. Um, sorry, but no.

## The Privacy Compliance Gap: How Lack Of Consent Enforcement Is Exposing Brands To Millions In Fines And Penalties
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/the-privacy-compliance-gap-how-lack-of-consent-enforcement-is-exposing-brands-to-millions-in-fines-and-penalties/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/the-privacy-compliance-gap-how-lack-of-consent-enforcement-is-exposing-brands-to-millions-in-fines-and-penalties/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 12:15:00+00:00

The trend is clear: While regulations may have been murky in years past, the dust has settled, and businesses must take a second look at compliance programs today or face scrutiny from regulators and the public tomorrow.

## Cybersecurity Innovations And Disruptions: What To Know Before Adopting New Technologies
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/cybersecurity-innovations-and-disruptions-what-to-know-before-adopting-new-technologies/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/cybersecurity-innovations-and-disruptions-what-to-know-before-adopting-new-technologies/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 12:00:00+00:00

As cybersecurity innovation significantly improves how technology can be used securely, here are some important factors businesses should consider before implementing new or trendy technology.

## Three Ways To Keep Customers Coming Back For More
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/three-ways-to-keep-customers-coming-back-for-more/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/three-ways-to-keep-customers-coming-back-for-more/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 11:45:00+00:00

How do businesses stand out in a very busy crowd?

## What Switzerland Can Teach The World About Innovation
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/what-switzerland-can-teach-the-world-about-innovation/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/what-switzerland-can-teach-the-world-about-innovation/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 11:30:00+00:00

Even with its success, however, the Swiss technology sector still has room to improve.

## E-Bikes And Equity – How A Small US Rivertown Is Helping Micromobility Move Beyond ‘Fad Status’
 - [https://www.forbes.com/sites/jenniferdungs/2022/12/19/e-bikes-and-equity--how-a-small-us-rivertown-is-helping-micromobility-move-beyond-fad-status/](https://www.forbes.com/sites/jenniferdungs/2022/12/19/e-bikes-and-equity--how-a-small-us-rivertown-is-helping-micromobility-move-beyond-fad-status/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 11:20:08+00:00

There is a lot to be said in favor of electric bikes, and micromobility at large. However, in most places, micromobility hasn’t yet moved beyond ‘fad status’. Time to throw the spotlight on a small rivertown 40 miles north of New York City that is deploying an e-bike sharing system for ALL…

## 5 Trends Shaping The Future Of Cybercrime Threat Intelligence
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/5-trends-shaping-the-future-of-cybercrime-threat-intelligence/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/5-trends-shaping-the-future-of-cybercrime-threat-intelligence/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 11:15:00+00:00

In this article, we’ll look at five trends shaping the future of cybercrime threat intelligence and how organizations can protect themselves.

## iOS 16.2 Vs iOS 15.7.2—Here’s Which iPhone Update To Choose
 - [https://www.forbes.com/sites/kateoflahertyuk/2022/12/19/ios-162-vs-ios-1572-heres-which-iphone-update-to-choose/](https://www.forbes.com/sites/kateoflahertyuk/2022/12/19/ios-162-vs-ios-1572-heres-which-iphone-update-to-choose/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 11:08:00+00:00

Apple has issued iOS 15.7.2 along with iOS 16.2. Both iPhone updates address major security issues, so which one should you choose?

## What Nonprofits, Advocacy Groups And Religious Congregations Need To Know About Fostering And Strengthening Outreach
 - [https://www.forbes.com/sites/forbestechcouncil/2022/12/19/what-nonprofits-advocacy-groups-and-religious-congregations-need-to-know-about-fostering-and-strengthening-outreach/](https://www.forbes.com/sites/forbestechcouncil/2022/12/19/what-nonprofits-advocacy-groups-and-religious-congregations-need-to-know-about-fostering-and-strengthening-outreach/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 11:00:00+00:00

If your nonprofit has access to a lot of donor or customer data, but you struggle to collect it, interpret it or leverage it effectively, then you might want to consider revisiting your data strategy.

## Oracle Develops Cloud Customization Strategy In Line With Key Trends
 - [https://www.forbes.com/sites/adrianbridgwater/2022/12/19/oracle-develops-cloud-customization-strategy-in-line-with-wider-trends/](https://www.forbes.com/sites/adrianbridgwater/2022/12/19/oracle-develops-cloud-customization-strategy-in-line-with-wider-trends/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 09:47:04+00:00

Oracle Alloy is a new cloud infrastructure platform designed to enable service providers, integrators, independent software vendors (any company of a resonable size such as a financial institution or teleco providers) to become cloud providers and roll out new cloud services to their customers.

## New Gmail Encrypted Email Feature Confirmed By Google, Will You Get It?
 - [https://www.forbes.com/sites/daveywinder/2022/12/19/new-gmail-encrypted-email-feature-confirmed-by-google-will-you-get-it/](https://www.forbes.com/sites/daveywinder/2022/12/19/new-gmail-encrypted-email-feature-confirmed-by-google-will-you-get-it/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 09:37:35+00:00

Google has confirmed that, at long last, it is bringing email encryption to users of Gmail. Well, some of them...

## Modern Data Is The Key To Disrupt And Innovate In ESG
 - [https://www.forbes.com/sites/mikehughes1/2022/12/19/modern-data-is-the-key-to-disrupt-and-innovate-in-esg/](https://www.forbes.com/sites/mikehughes1/2022/12/19/modern-data-is-the-key-to-disrupt-and-innovate-in-esg/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 09:21:28+00:00

In a world that has become increasingly interconnected, we rely on access to real-time, robust data to complete the simplest of tasks. However, the possibilities of modern data go far further than personal use - it will spark an ESG data revolution.

## The Biggest Tech Innovations And Breakthroughs Of 2022
 - [https://www.forbes.com/sites/bernardmarr/2022/12/19/the-biggest-tech-innovations-and-breakthroughs-of-2022/](https://www.forbes.com/sites/bernardmarr/2022/12/19/the-biggest-tech-innovations-and-breakthroughs-of-2022/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 07:41:49+00:00

In this post, we take stock and look at the biggest technology innovations or technological breakthroughs of 2022.

## CyberArk Shows That Cybersecurity Companies With Vision Thrive Even In A Tough Market
 - [https://www.forbes.com/sites/tonybradley/2022/12/19/cyberark-shows-that-cybersecurity-companies-with-vision-thrive-even-in-a-tough-market/](https://www.forbes.com/sites/tonybradley/2022/12/19/cyberark-shows-that-cybersecurity-companies-with-vision-thrive-even-in-a-tough-market/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 07:14:19+00:00

CyberArk has had strong performance and industry recognition based on its success providing identity security solutions while much of the cybersecurity industry has faced budget cuts and layoffs.

## ‘High On Life’ Is A ‘Breakout Hit’ On Xbox Game Pass And PC Despite Average Reviews
 - [https://www.forbes.com/sites/krisholt/2022/12/19/high-on-life-is-a-breakout-hit-on-xbox-game-pass-and-pc-despite-average-reviews/](https://www.forbes.com/sites/krisholt/2022/12/19/high-on-life-is-a-breakout-hit-on-xbox-game-pass-and-pc-despite-average-reviews/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 06:55:08+00:00

Rick and Morty co-creator Justin Roiland's latest game is defying convention.

## ‘Quordle’ Answers And Clues For Monday, December 19
 - [https://www.forbes.com/sites/krisholt/2022/12/19/quordle-answers-and-clues-for-monday-december-19/](https://www.forbes.com/sites/krisholt/2022/12/19/quordle-answers-and-clues-for-monday-december-19/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 05:57:40+00:00

Some hints and the solution for today's 'Quordle' are just ahead.

## Digital Storage Projections For 2023, Part 1
 - [https://www.forbes.com/sites/tomcoughlin/2022/12/18/digital-storage-projections-for-2023-part-1/](https://www.forbes.com/sites/tomcoughlin/2022/12/18/digital-storage-projections-for-2023-part-1/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 04:24:15+00:00

HDDs are secondary storage in data centers using nearline HDDs.  HDD unit shipments are down about 36% in 2022 versus 2021 and shipping capacity down about 12%. The LTO magnetic tape roadmaps projects up to 576TB tape cartridges sometime in the 2030s.

## Today’s Wordle #548 Hints, Clues And Answer For Monday, December 19th
 - [https://www.forbes.com/sites/erikkain/2022/12/18/todays-wordle-548-hints-clues-and-answer-for-monday-december-19th/](https://www.forbes.com/sites/erikkain/2022/12/18/todays-wordle-548-hints-clues-and-answer-for-monday-december-19th/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 03:30:10+00:00

How to solve today's Wordle.

## Tecno Phantom X2 Pro Review: Retractable Zoom Lens Actually Works
 - [https://www.forbes.com/sites/bensin/2022/12/18/tecno-phantom-x2-pro-review-retractable-zoom-lens-actually-works/](https://www.forbes.com/sites/bensin/2022/12/18/tecno-phantom-x2-pro-review-retractable-zoom-lens-actually-works/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 02:05:27+00:00

Tecno’s new flagship phone has a retractable portrait camera.

## Video Game God Of War Ragnarok Sweeps Award Categories and Memorializes Queer Love
 - [https://www.forbes.com/sites/lakenbrooks/2022/12/18/video-game-god-of-war-ragnarok-sweeps-award-categories-and-memorializes-queer-love/](https://www.forbes.com/sites/lakenbrooks/2022/12/18/video-game-god-of-war-ragnarok-sweeps-award-categories-and-memorializes-queer-love/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 01:27:18+00:00

A side quest in God of War Ragnarok honors the real love story of two developers, Sam Handrick and Jake Snipes. In 2020, Snipes passed away due to epilepsy.

## ‘Heardle’ Answer And Clues For Monday, December 19
 - [https://www.forbes.com/sites/krisholt/2022/12/18/heardle-answer-and-clues-for-monday-december-19/](https://www.forbes.com/sites/krisholt/2022/12/18/heardle-answer-and-clues-for-monday-december-19/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 01:15:15+00:00

Here's today's 'Heardle' song, along with some hints.

## Solstice, The ‘Shepherd’s Star’ And A Christmas Cluster: The Night Sky This Week
 - [https://www.forbes.com/sites/jamiecartereurope/2022/12/18/solstice-the-shepherds-star-and-a-christmas-cluster-the-night-sky-this-week/](https://www.forbes.com/sites/jamiecartereurope/2022/12/18/solstice-the-shepherds-star-and-a-christmas-cluster-the-night-sky-this-week/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2022-12-19 01:00:00+00:00

The celestial highlights for the week ahead have a seasonal twist.


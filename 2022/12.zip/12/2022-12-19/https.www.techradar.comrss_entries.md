# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Police foil attempts to smuggle 30kg of meth using 3D printers
 - [https://www.techradar.com/news/police-foil-attempts-to-smuggle-30kg-of-meth-using-3d-printers](https://www.techradar.com/news/police-foil-attempts-to-smuggle-30kg-of-meth-using-3d-printers)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 22:59:10+00:00

Two men have been charged in Taiwan for using 3D printers to smuggle large quantities of methamphetamine.

## Linux...on a tablet? It might just work
 - [https://www.techradar.com/news/linuxon-a-tablet-it-might-just-work](https://www.techradar.com/news/linuxon-a-tablet-it-might-just-work)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 21:53:08+00:00

The PineTab, sent the way of the dodo by pandemic manufacturing concerns, is getting a refresh.

## Apple is reportedly working on some super-powered new Pro monitors
 - [https://www.techradar.com/news/apple-is-reportedly-working-on-some-super-powered-new-pro-monitors](https://www.techradar.com/news/apple-is-reportedly-working-on-some-super-powered-new-pro-monitors)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 21:04:20+00:00

Apple is reportedly working on a sequel to its high-end Pro Display XDR monitor.

## Work PC sales have plummeted once again
 - [https://www.techradar.com/news/work-pcs-are-on-the-decline-again-this-year](https://www.techradar.com/news/work-pcs-are-on-the-decline-again-this-year)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 20:07:48+00:00

Canalys finds Western European PC shipment slump continues in traditionally robust commercial sector.

## Hundreds of Android apps found leaking API keys, putting users at risk
 - [https://www.techradar.com/news/hundreds-of-android-apps-found-leaking-api-keys-putting-users-at-risk](https://www.techradar.com/news/hundreds-of-android-apps-found-leaking-api-keys-putting-users-at-risk)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 19:51:05+00:00

Threat actors could use leaked APIs to send fraudulent emails to Android users, and exfiltrate mailing lists.

## Matter makes landfall on Amazon Echo as  support continues to grow
 - [https://www.techradar.com/news/matter-makes-landfall-on-amazon-echo-as-support-continues-to-grow](https://www.techradar.com/news/matter-makes-landfall-on-amazon-echo-as-support-continues-to-grow)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 19:28:24+00:00

Part of a first wave of support, you'll be able to control Matter-enabled devices via your bedside Echo speaker.

## Leading VPN targets Russian censorship in provocative billboard campaign
 - [https://www.techradar.com/news/leading-vpn-targets-russian-censorship-in-provocative-billboard-campaign](https://www.techradar.com/news/leading-vpn-targets-russian-censorship-in-provocative-billboard-campaign)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 19:02:23+00:00

The Hide.me campaign comes amid a growing number of suspicious deaths among those questioning the war in Ukraine

## The new Mac Pro could still be an M2-powered beast
 - [https://www.techradar.com/news/the-new-mac-pro-could-still-be-an-m2-powered-beast](https://www.techradar.com/news/the-new-mac-pro-could-still-be-an-m2-powered-beast)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 18:41:17+00:00

Delays and politicking around manufacturing have meant that a Mac Pro running on powerful Apple Silicon is taking a long time - and cost consumers heavily.

## One of the best Xbox Game Pass games is leaving at the end of the month
 - [https://www.techradar.com/news/one-of-the-best-xbox-game-pass-games-is-leaving-at-the-end-of-the-month](https://www.techradar.com/news/one-of-the-best-xbox-game-pass-games-is-leaving-at-the-end-of-the-month)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 17:53:32+00:00

Award-winning Outer Wilds is one of eight games set to leave Game Pass at the end of December.

## IBM: Why the next step in 5G is all about acceleration
 - [https://www.techradar.com/news/ibm-why-the-next-step-in-5g-is-all-about-acceleration](https://www.techradar.com/news/ibm-why-the-next-step-in-5g-is-all-about-acceleration)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 17:22:09+00:00

We speak to Andrew Coward, GM of Software Defined Networking at IBM, to find out his thoughts on the 5G future.

## The next generation of Microsoft Teams is officially here to try now
 - [https://www.techradar.com/news/the-next-generation-of-microsoft-teams-is-officially-here-to-try-now](https://www.techradar.com/news/the-next-generation-of-microsoft-teams-is-officially-here-to-try-now)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 17:02:51+00:00

Try out the new Microsoft Teams Premium now.

## Six Final Fantasy games are getting re-releases in time for the 35th anniversary
 - [https://www.techradar.com/news/six-final-fantasy-games-are-getting-re-releases-in-time-for-the-35th-anniversary](https://www.techradar.com/news/six-final-fantasy-games-are-getting-re-releases-in-time-for-the-35th-anniversary)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 16:35:53+00:00

Final Fantasy Pixel Remaster collects the first six games in the series, and there is a Collector’s Edition for you superfans.

## Google, Apple and Mozilla are teaming up to build a better web browser benchmark tool
 - [https://www.techradar.com/news/google-apple-and-mozilla-are-teaming-up-to-build-a-better-web-browser-benchmark-tool](https://www.techradar.com/news/google-apple-and-mozilla-are-teaming-up-to-build-a-better-web-browser-benchmark-tool)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 16:15:45+00:00

Google, Apple, and Mozilla combine to work on Speedometer 3 web browser benchmark.

## Malware defeated by Google rises from the ashes
 - [https://www.techradar.com/news/malware-defeated-by-google-rises-from-the-ashes](https://www.techradar.com/news/malware-defeated-by-google-rises-from-the-ashes)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 15:11:48+00:00

Glupteba is back with more Bitcoin addresses and more malware samples, but with the same goal.

## Hackers are now targeting food supplies in BEC scams, FBI warns
 - [https://www.techradar.com/news/hackers-are-now-targeting-food-supplies-in-bec-scams-fbi-warns](https://www.techradar.com/news/hackers-are-now-targeting-food-supplies-in-bec-scams-fbi-warns)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 14:28:38+00:00

Scammers are stealing entire food package deliveries and selling them on the black market.

## It looks like footage from the next Assassin's Creed game has leaked
 - [https://www.techradar.com/news/it-looks-like-footage-from-the-next-assassins-creed-game-has-leaked](https://www.techradar.com/news/it-looks-like-footage-from-the-next-assassins-creed-game-has-leaked)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 14:25:58+00:00

Beta footage of what appears to be Assassin’s Creed: Codename Jade has leaked.

## AMD attempts to defuse controversy around RDNA 3 GPUs and ‘broken’ feature
 - [https://www.techradar.com/news/amd-attempts-to-defuse-controversy-around-rdna-3-gpus-and-broken-feature](https://www.techradar.com/news/amd-attempts-to-defuse-controversy-around-rdna-3-gpus-and-broken-feature)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 13:30:34+00:00

It’s good to hear AMD address the matter of shader pre-fetch hardware, but clock speeds remain a worry, too.

## Restaurant CRM platform SevenRooms confirms data breach
 - [https://www.techradar.com/news/restaurant-crm-platform-sevenrooms-confirms-data-breach](https://www.techradar.com/news/restaurant-crm-platform-sevenrooms-confirms-data-breach)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 13:08:46+00:00

A sample of the company's data allegedly showing API keys and guest data was published on an underground forum.

## Python malware is using a devious new technique
 - [https://www.techradar.com/news/python-malware-is-using-a-devious-new-technique](https://www.techradar.com/news/python-malware-is-using-a-devious-new-technique)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 12:20:42+00:00

Hackers use new tricks to keep their payloads hidden, including adding anti-debugging code

## Twitter users have decided if Elon Musk should step down in a bizarre poll
 - [https://www.techradar.com/news/twitter-users-have-decided-if-elon-musk-should-step-down-in-a-bizarre-poll](https://www.techradar.com/news/twitter-users-have-decided-if-elon-musk-should-step-down-in-a-bizarre-poll)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 11:36:15+00:00

Twitter CEO Elon Musk enraged a lot of users into restricting how links are shared - a new poll could decide if he stays.

## Gmail launches a big security update, but you might not get it yet
 - [https://www.techradar.com/news/gmail-launches-a-big-security-update-but-you-might-not-get-it-yet](https://www.techradar.com/news/gmail-launches-a-big-security-update-but-you-might-not-get-it-yet)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-19 10:34:07+00:00

Beta is open now for Gmail end-to-end encryption, but only some Google Workspace users will be eligible.


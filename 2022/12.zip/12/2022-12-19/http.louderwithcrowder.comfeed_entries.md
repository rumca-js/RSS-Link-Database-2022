# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Watch: Tim Robbins blasts vitriol spewed by Hollywood celebs (like Sean Penn) toward Americans over the lockdowns
 - [https://www.louderwithcrowder.com/tim-robbins-russell-brand](https://www.louderwithcrowder.com/tim-robbins-russell-brand)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-19 18:25:59+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32364420&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C24%2C0" /><br /><br /><p>Ask a GenXer who some of the most obnoxiously leftist actors are, many lists will include both Tim Robbins and Sean Penn. Throw in Michael Moore, and they are the Three Tenors of Socialism. The difference being politics aside, Robbins will always have <em>The Shawshank Redemption</em>. Outside of shagging Madonna before everyone else and <em>Fast Times and Ridgemont High</em>, I can't name anything Sean Penn has done without looking it up.</p><p>And while Penn is still signaling his virtue in <a href="https://www.louderwithcrowder.com/sean-penn-zelinksyy" target="_blank">America and overseas</a>, it's been a minute since we've heard from Tim. I was surprised to see this clip of the actor having a kibitz with <a href="https://www.louderwithcrowder.com/russell-brand-big-tech" target="_blank">Rusell Brand</a> about the lockdowns. And the vitriol pro-lockdowners -- in Hollywood -- spewed at Americans who had ANY opposing viewpoint, or made ANY different decision about their health.</p><p class="shortcode-media shortcode-media-rumble">

</p><blockquote>We turned into tribal, angry, vengeful people. And I don't think that's something sustainable for the Earth. That we start demonizing people that don't agree with our particular health policies and turned them into monsters Turned them into pariharas. Say that they don't deserve a hospital bed. </blockquote><p>Robbins then drew a comparison with drug addicts and how when they make the choice to overdose on drugs, we still take care of them. We don't say "you should f*cking die" as we do people who didn't get their Fauci Ouchie. Or even haven't gotten all of their Fauci Ouchies.</p><p>What's fascinating is that upon seeing this Tim Robbins clip-on Rumble, a few videos down was a resurfaced Sean Penn clip from 2021 where he did EXACTLY what Robbins has a problem with. Penn called it "criminal" for people to have made a different decision than him.</p><p class="shortcode-media shortcode-media-rumble">

</p><p>On another occasion, he compared making the decision NOT to get your Fauci Ouchie is literally <a href="https://deadline.com/2021/08/sean-penn-unvaccinated-akin-to-pointing-gun-in-face-cnn-smerconish-1234819328/" target="_blank">pointing your gun in someone's face</a>. And he's hardly the only celebrity who engaged in such rhetoric. He just happened to be three videos down on the same search page I was on.</p><p>It is nice to see people like Tim Robbins speaking out like this. It would be nicer if names were named and specific people were shamed and called out for their actions. There are a lot of epiphanies about mistakes that were made over the past two-plus years plus fifteen days to flatten the curve. Not so much when it comes to any accountability for them.</p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">I'm Leaving The Blaze... | Louder With Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/N_jzaYt0gBY" target="_blank">youtu.be</a>
</small>
</p>

## Watch: JK Rowling maintains role as world's top transphobe for...opening a women-only center to help rape victims
 - [https://www.louderwithcrowder.com/jk-rowling-shelter](https://www.louderwithcrowder.com/jk-rowling-shelter)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-19 17:25:37+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32364273&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C120" /><br /><br /><p>JK Rowling has once again found herself in the crosshairs of the Left after she funded a biological “women-only” rape help center in Scotland. The shelter named “Beira’s Place” will only serve and employ cisgendered females.  </p><p>Because this involves the words "<a href="https://www.louderwithcrowder.com/daniel-radcliffe-jk-rowling" target="_blank">JK Rowling</a>" and "<a href="https://www.louderwithcrowder.com/jk-rowling-royalties" target="_blank">women</a>," ten bucks say you can totally guess what happened next!</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Excluding trans women from a "women's only service" is no more OK than excluding lesbian women, women of colour, or women with disabilities. There's no such thing as "sex-based rights" just how there's no "ethnicity-based rights". That's the point of equality.<br />— Flora🏳️⚧️💙💙 they were the universe 💫 (@QueerThassie) <a href="https://twitter.com/QueerThassie/status/1602604897824014336?ref_src=twsrc%5Etfw">December 13, 2022</a></blockquote> </div><p>Rowling even "went after" a "prominent" trans gamer. Because, <a href="https://www.forbes.com/sites/paultassi/2022/12/18/jk-rowling-mocks-trans-gamer-for-hogwarts-legacy-comments/?sh=32b9081b6a76" target="_blank">as Forbes puts it</a>, Rowling is "<em>the most prominent face and voice in the world of anti-trans rhetoric, where she spends all day </em><em>on Twitter </em><em>sparring with critics and activists."</em></p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Deeply disappointed <a href="https://twitter.com/jessiegender?ref_src=twsrc%5Etfw">@jessiegender</a> doesn't realise purethink is incompatible with owning ANYTHING connected with me, in ANY form. The truly righteous wouldn't just burn their books and movies but the local library, anything with an owl on it and their own pet dogs. <a href="https://twitter.com/hashtag/DoBetter?src=hash&amp;ref_src=twsrc%5Etfw">#DoBetter</a> 1/2 <a href="https://t.co/LqANqab8Km">pic.twitter.com/LqANqab8Km</a><br />— J.K. Rowling (@jk_rowling) <a href="https://twitter.com/jk_rowling/status/1604180531155017731?ref_src=twsrc%5Etfw">December 17, 2022</a></blockquote> </div><p>Crowder and the gang discussed this in full detail on today's show. Also, we can't stress this enough...</p><h2><a href="https://mugclubforever.com/" target="_blank">MugClub Forever!</a></h2><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">🔴 LIVE Daily Show!!! | Louder with Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://www.youtube.com/watch?v=l3fG9SpK0jU" target="_blank">www.youtube.com</a>
</small>
</p>

## Watch: Rep. AOC sets up camera to record her totally real and not at-all-contrived reaction to the World Cup
 - [https://www.louderwithcrowder.com/aoc-soccer-world-cup-watch](https://www.louderwithcrowder.com/aoc-soccer-world-cup-watch)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-19 15:40:50+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32363599&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>The finals of the World Cup were on Sunday where Argentina and France...tied. But Argentina won on penalties, so they won the World Cup. As we've said, <a href="https://www.louderwithcrowder.com/dana-white-soccer" target="_blank">soccer is a stupid sport</a> and <a href="https://www.louderwithcrowder.com/don-lemon-soccer" target="_blank">most Americans stopped paying attention</a> when America was out. But social media influencer Rep. AOC and her fiancé Reily couldn't get enough of it. So much so, they set up a tripod to record their totes real, not contrived reaction to Argentina winning by tying.</p><p>Or, that's what critics are saying they did. It is unclear is where this clip came from. <a href="https://notthebee.com/article/aoc-and-her-boyfriend-set-up-a-camera-to-record-their-reaction-to-the-world-cup-final" target="_blank">But everyone else on the internet is dunking on it right now</a>, so we'll call this "for entertainment purposes only." </p><p>Since all influential couples have cute name that combines their names, we will be referring to them AOCeily.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">What did I just watch? <a href="https://t.co/IrKfynfpPA">pic.twitter.com/IrKfynfpPA</a><br />— End Wokeness (@EndWokeness) <a href="https://twitter.com/EndWokeness/status/1604599233260175360?ref_src=twsrc%5Etfw">December 18, 2022</a></blockquote> </div><p>AOCeily were enthralled.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="9cf0f" src="https://www.louderwithcrowder.com/media-library/image.png?id=32363682&amp;width=980" />
</p><p>Then, a soccer thing happened.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="a6e50" src="https://www.louderwithcrowder.com/media-library/image.png?id=32363685&amp;width=980" />
</p><p>Such a soccer thing! AOCeily couldn't believe it.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="dfa03" src="https://www.louderwithcrowder.com/media-library/image.png?id=32363688&amp;width=980" />
</p><p>Look how happy and playful AOCeily are at the soccer thing happening. Just two kids enjoying a weekend alone watching soccer things. I'm guessing this is in Washington DC. Social media influencer Rep. AOC still has her side hustle in Congress. But LOL at her being anywhere near her district.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="5fbf9" src="https://www.louderwithcrowder.com/media-library/image.png?id=32363689&amp;width=980" />
</p><p>Check out my man here trying to be slick.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="4052d" src="https://www.louderwithcrowder.com/media-library/image.png?id=32363693&amp;width=980" />
</p><p>You see, friends, AOCeily are just like you and I. Two kids pretending to care about what everyone else cares about, and signaling to everyone on the internet "look, we watch soccer too!." To an untrained eye, setting up a camera to record you acting like you're excited over the television may seem lame and sad. A trained eye agrees. </p><p>This entire video is just sooooo totally AOCeily! They love them!</p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">I'm Leaving The Blaze... | Louder With Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/N_jzaYt0gBY" target="_blank">youtu.be</a>
</small>
</p>

## This Video Would Get Us Banned On YouTube (Show Notes)
 - [https://www.louderwithcrowder.com/show-notes-jk-rowling](https://www.louderwithcrowder.com/show-notes-jk-rowling)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-19 14:59:31+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=32363589&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>We're not sure how long we're going to be on YouTube today, because we have A LOT that can only be discussed behind the paywall. But before we do, J.K. Rowling is the #1 transphobe?</p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">🔴 LIVE Daily Show!!! | Louder with Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://www.youtube.com/watch?v=l3fG9SpK0jU" target="_blank">www.youtube.com</a>
</small>
</p><p><strong>JK ROWLING: #1 TRANSPHOBE</strong></p><ul><li><a href="https://www.bbc.com/news/uk-scotland-edinburgh-east-fife-63943766" rel="noopener noreferrer" target="_blank">JK Rowling funds women-only rape help centre in Edinburgh</a></li><li><a href="https://twitter.com/jk_rowling/status/1604180531155017731?s=20&amp;t=BRRktfkyNlqCgTlBUie5Gw" rel="noopener noreferrer" target="_blank">@jessiegender</a></li><li><a href="https://twitter.com/jk_rowling/status/1604180531155017731?s=20&amp;t=BRRktfkyNlqCgTlBUie5Gw" rel="noopener noreferrer" target="_blank"></a><a href="https://www.forbes.com/sites/paultassi/2022/12/18/jk-rowling-mocks-trans-gamer-for-hogwarts-legacy-comments/?sh=32b9081b6a76" rel="noopener noreferrer" target="_blank">JK Rowling Mocks Trans Gamer For ‘Hogwarts Legacy’ Comments</a></li><li><a href="https://www.forbes.com/sites/paultassi/2022/12/18/jk-rowling-mocks-trans-gamer-for-hogwarts-legacy-comments/?sh=32b9081b6a76" rel="noopener noreferrer" target="_blank"></a><a href="https://www.cnet.com/culture/j-k-rowling-on-reaction-to-a-black-hermione-idiots-were-going-to-idiot/#:~:text=And%20it%20came%20as%20no,%2C%22%20which%20begins%20previews%20Tuesday." rel="noopener noreferrer" target="_blank">J.K. Rowling on the reaction to a black Hermione: 'Idiots were going to idiot'</a></li><li><a href="https://www.cnet.com/culture/j-k-rowling-on-reaction-to-a-black-hermione-idiots-were-going-to-idiot/#:~:text=And%20it%20came%20as%20no,%2C%22%20which%20begins%20previews%20Tuesday." rel="noopener noreferrer" target="_blank"></a><a href="https://www.youtube.com/watch?v=1mr3dEBfqgY" rel="noopener noreferrer" target="_blank">Dumbledore and Grindelwald Reunite (Part 3)</a><span></span></li></ul>

## James Cameron doesn't understand why there isn't an empowering female warrior who is six months pregnant
 - [https://www.louderwithcrowder.com/james-cameron-pregnant](https://www.louderwithcrowder.com/james-cameron-pregnant)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-19 14:29:04+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=32363101&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>James Cameron is on the press tour for <em>Avatar 2: Virtue Signal Boogaloo</em>, and my man is trying way too hard. Claiming that <a href="https://www.louderwithcrowder.com/show-notes-alex-jones-ye" target="_blank">men need to purge testosterone from our bodies</a> is one thing. Crapping on masculinity is Filmmaking 101. Cameron is old and most likely past the age where his body makes any testosterone on his own. He's lashing out. I get it. He's still an idiot. But I get it.</p><p>The filmmaker has turned <a href="https://variety.com/2022/film/features/james-cameron-robert-rodriguez-interview-avatar-2-1235458822/" target="_blank">his attention to female empowerment lamenting why</a>, with all the female superheroes we see, they are never six months pregnant.</p><blockquote>Everybody's always talking about female empowerment. But what is such a big part of a woman's life that we, as men, don't experience? And I thought, "Well, if you're really going to go all the way down the rabbit hole of female empowerment, let's have a female warrior who's six months pregnant in battle."</blockquote><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="253c8" src="https://www.louderwithcrowder.com/media-library/image.gif?id=32363121&amp;width=980" />
</p>
<p>He then lamented never seeing Captain Marvel and Wonder Woman six months pregnant while they are fighting bad guys. Mind you, this is the same Cameron who on his last feminist rant not only thought <a href="https://www.louderwithcrowder.com/james-cameron-wonder-woman" target="_blank">Gal Gadot was too hot to be feminist</a>, he was so proud of himself <a href="https://www.louderwithcrowder.com/james-cameron-doubles-wonder-woman-hot-feminist" target="_blank">that he felt the need to double down</a>.</p><p>It is unclear if James Cameron has ever met a woman who is six months pregnant. WikiPedia says he's been married five times and has four kids. But it's also Hollywood, so none of that means anything.</p><p>To answer Cameron's question, there are two reasons why we don't see six-month pregnant women fighting crime. The obvious one is, eww...gross. No one wants to pay money to see that.</p><p>The other is even in Sci-Fi/Fantasy, if a female character is six-month pregnant her only concern is protecting the child she is carrying. And the men wouldn't want the six-month pregnant woman going into combat. That means someone else needs to fight Thanos or Darkseid while Wonder Woman relaxes for another twelve weeks.</p><p>If James Cameron had any testosterone left, he might know that.</p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">I'm Leaving The Blaze... | Louder With Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/N_jzaYt0gBY" target="_blank">youtu.be</a>
</small>
</p>

## FBI called on Twitter to suspend an account that...parodied WWE legend The Undertaker pooping his pants
 - [https://www.louderwithcrowder.com/undertaker-twitter-parody](https://www.louderwithcrowder.com/undertaker-twitter-parody)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-19 13:52:40+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=32362936&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>It was another chaotic weekend of Twitter. So much so, I missed another drop of the Twitter Files. I caught the <a href="https://www.louderwithcrowder.com/taylor-lorenz-suspended-twitter" target="_blank">yeeting of Taylor Lorenz</a> and Elon <a href="https://www.louderwithcrowder.com/elon-musk-steps-down-poll" target="_blank">maybe or maybe not stepping down as CEO</a>. But Matt Taibbi hit us with <em>Twitter Files Part 6: Twitter, The FBI Subsidiary</em>. The FBI being BFF with Twitter executives isn't news on its own. The depth of the relationship is. And even on November 22 of 2022, after Elon finalized his purchase of Twitter, the FBI was calling for accounts to be taken down. Including *checks notes* one parodying WWE legend The Undertaker.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="c219e" src="https://www.louderwithcrowder.com/media-library/image.gif?id=32362973&amp;width=980" />
</p>
<p><a href="https://www.wrestlinginc.com/1141727/fbi-appears-to-have-had-an-undertaker-twitter-parody-account-shut-down/" target="_blank">Wrestling Inc flagged this tweet from Taibbi</a>, where the FBI wanted @madandpissedoff removed from the platform.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">“HELLO TWITTER CONTACTS”: The master-canine quality of the FBI’s relationship to Twitter comes through in this November 2022 email, in which “FBI San Francisco is notifying you” it wants action on four accounts: <a href="https://t.co/LjgB6fxENo">pic.twitter.com/LjgB6fxENo</a><br />— Matt Taibbi (@mtaibbi) <a href="https://twitter.com/mtaibbi/status/1603857573219819529?ref_src=twsrc%5Etfw">December 16, 2022</a></blockquote> </div><p>@Madandpissedoff was a parody account of The Undertaker -- not Mark Callaway, but the fictional sports entertainment character -- that, quote, "<a href="https://twitter.com/davidbix/status/1603963336772784128" target="_blank">generally tweeted about The Undertaker shitting his pants and blaming it on an imaginary entity named Mr. Brown</a>."</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="867d2" src="https://www.louderwithcrowder.com/media-library/image.jpg?id=32363004&amp;width=980" />
</p>
<p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="e1b29" src="https://www.louderwithcrowder.com/media-library/image.jpg?id=32363005&amp;width=980" />
</p>
<p>The account was suspended from the bird app shortly after.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Well, November 10 WAS when PissedOffTaker was suspended, and nobody's disputed that any of "The Twitter Files" are genuine Twitter records, so regardless of it was a real FBI email, it does seem like Twitter acted on it for some reason?!?!!? <a href="https://t.co/FXX0tan9q8">pic.twitter.com/FXX0tan9q8</a><br />— David Bixenspan (@davidbix) <a href="https://twitter.com/davidbix/status/1603966477794770945?ref_src=twsrc%5Etfw">December 17, 2022</a></blockquote> </div><p>Let's set aside <a href="https://www.louderwithcrowder.com/fbi-whistleblower-child-sexual-abuse" target="_blank">all the obvious problems with the FBI </a>being <a href="https://www.louderwithcrowder.com/mark-zuckerberg-awesome-wonderful-man" target="_blank">this obsessed about who is tweeting</a> what and when.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Instead of chasing child sex predators or terrorists, the FBI has agents — lots of them — analyzing and mass-flagging social media posts. Not as part of any criminal investigation, but as a permanent, end-in-itself surveillance operation. People should not be okay with this.<br />— Matt Taibbi (@mtaibbi) <a href="https://twitter.com/mtaibbi/status/1603878271384313856?ref_src=twsrc%5Etfw">December 16, 2022</a></blockquote> </div><p>I'm dying to know what @Madandpissedoffc tweet caught the attention of Fred from the San Francisco Bureau that led to A F*CKING PARODY OF A FICTIONAL SPORTS ENTERTAINMENT CHARACTER GETTING REMOVED FROM THE PLATFORM. The suspension happened two days after Election Day. Perhaps @Madandpissedoffc forgot to switch to his burner account to question the results of their local congressional race.</p><p>There's a possibility @Madandpissedoffc was starting a new character arc where we discover "Mr. Brown" was the same guy sh*tting in Joe Biden's pants. Biden and Taker were going to team up to take Mr. Brown down once and for all. But the people who run Biden don't want any more references to Biden's (alleged, according to critics) incontinence. It's not like we don't know the White House had a direct portal to Twitter.</p><p>But what I want the truth to be? Fred the San Francisco FBI Agent is such a wrestling mark, he wanted an account making fun of his favorite wrestler taken down. Fred still hasn't gotten over Brock Lesnar ending the streak. Taker pooping himself was an insult too far.</p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">I'm Leaving The Blaze... | Louder With Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/N_jzaYt0gBY" target="_blank">youtu.be</a>
</small>
</p>

## Elon Musk may have stepped down as Twitter CEO by the time you read this over the results of a poll
 - [https://www.louderwithcrowder.com/elon-musk-steps-down-poll](https://www.louderwithcrowder.com/elon-musk-steps-down-poll)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-19 12:48:04+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32362762&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C6" /><br /><br /><p>Twitter transcended into chaos over the weekend, and if the people have spoken Elon Musk may no longer be CEO. You live by the Twitter poll, you die by the Twitter poll.</p><p>Over the past few days, Elon <a href="https://www.louderwithcrowder.com/elon-musk-spaces" target="_blank">suspended journalists</a> and <a href="https://www.louderwithcrowder.com/taylor-lorenz-suspended-twitter" target="_blank">Taylor Lorenz</a> from the app. It wasn't the most Christmasy thing for him to do. But everyone he suspended sucks at life and would have YOU deplatformed for looking at them cockeyed. I'm not going to pretend to feel bad. </p><p>Where Musk upset people whose opinion matters was <a href="https://thepostmillennial.com/new-twitter-policy-says-users-will-be-suspended-from-promoting-other-social-media-sites" target="_blank">with a new policy</a> to "remove accounts created solely for the purpose of promoting other social platforms" like Facebook, Mastodon, and Truth Social. The now-deleted tweets also said, "We recognize that many of our users are active on other social media platforms. However, we will no longer allow free promotion of certain social media platforms on Twitter."</p><p>This outraged everyone right, center, and douche. Musk reversed the policy, and apologized that it was a mistake and he messed up. Then came this:</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Should I step down as head of Twitter? I will abide by the results of this poll.<br />— Elon Musk (@elonmusk) <a href="https://twitter.com/elonmusk/status/1604617643973124097?ref_src=twsrc%5Etfw">December 18, 2022</a></blockquote> </div><p>Keep in mind, while all these tweets were going on, Elon was at the World Cup palling around with the Saudi Family and Jared Kushner.</p><p>As of this writing, your guess is as good as mine as to what comes next.  Previous Twitter polls have led to Donald Trump and the suspended journalists being reinstated. Elon has abided by the will of the people in the past. But this poll sounded like the Chief Twit was lost in his feels that people were attacking him (not just the left, people who matter) and felt sorry for himself. </p><p>Elon could also have a new CEO lined up and was planning on stepping down anyway. It's Musk's world. I'm just here for the content and to revel in the chaos it creates.</p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">HUGE ANNOUNCEMENT: THE FUTURE OF MUG CLUB & LOUDER WITH CROWDER</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/VqTjk-Gd3DU" target="_blank">youtu.be</a>
</small>
</p>


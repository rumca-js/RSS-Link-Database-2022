## BlackRock plans no big changes to ESG stance despite backlash
 - [https://www.reuters.com/business/sustainable-business/blackrock-plans-no-big-changes-esg-stance-despite-backlash-2022-12-19/](https://www.reuters.com/business/sustainable-business/blackrock-plans-no-big-changes-esg-stance-despite-backlash-2022-12-19/)
 - RSS feed: https://www.reuters.com
 - date published: 2022-12-19 15:43:17+00:00

BlackRock plans no big changes to ESG stance despite backlash


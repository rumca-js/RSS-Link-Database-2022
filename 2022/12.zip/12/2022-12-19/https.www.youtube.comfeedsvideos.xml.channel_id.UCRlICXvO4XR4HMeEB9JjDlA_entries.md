# Source:Thoughty2, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA, language:en-US

## Why The Revenant Movie Hid The Disturbing Truth From You
 - [https://www.youtube.com/watch?v=krQr6mDkaS4](https://www.youtube.com/watch?v=krQr6mDkaS4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA
 - date published: 2022-12-19 17:13:53+00:00

The first 100 people to use the code THOUGHTY2 at the link below will get 20% off of Incogni: https://www.incogni.com/thoughty2


Thoughty2 Audiobook: https://geni.us/t2audio
Thoughty2 Book: https://geni.us/t2book
Support Me & Get Early Access: http://bit.ly/t2club
Thoughty2 Merchandise: https://bit.ly/t2merch

Follow Thoughty2
Facebook: https://facebook.com/thoughty2
Instagram: https://instagram.com/thoughty2
Website: http://thoughty2.com

About Thoughty2
Thoughty2 (Arran) is a British YouTuber and gatekeeper of useless facts. Thoughty2 creates mind-blowing factual videos about science, tech, history, opinion and just about everything else.
#Thoughty2

Writing: Steven Rix
Editing: Jack Stevens


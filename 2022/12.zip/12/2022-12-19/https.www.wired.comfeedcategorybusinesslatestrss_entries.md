# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Mastodon Features That Twitter Should Steal (but Won’t)
 - [https://www.wired.com/story/mastodon-features-that-twitter-should-steal-but-wont/](https://www.wired.com/story/mastodon-features-that-twitter-should-steal-but-wont/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2022-12-19 00:00:00+00:00

Elon Musk's platform could learn a thing or two from its most popular alternative—like how to build a social platform people actually want to be on.


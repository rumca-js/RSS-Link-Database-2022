# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## Open Source File Archiver Utility PeaZip Releases Version 9.0
 - [https://news.itsfoss.com/peazip-9-0-release/](https://news.itsfoss.com/peazip-9-0-release/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2022-12-19 11:21:19+00:00

The free and open-source file archiver utility adds a ton of refinements with this upgrade.


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Big Brain Experiments We Try in Games for NO REASON [Part 2]
 - [https://www.youtube.com/watch?v=kDco6jUQCtI](https://www.youtube.com/watch?v=kDco6jUQCtI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-12-20 00:00:00+00:00

Sometimes in games you just can't help but try stupid things for no reason other than just to see what might happen.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:51 Number 10
1:49 Number 9
3:20 Number 8
4:47 Number 7
6:20 Number 6
7:32 Number 5
8:53 Number 4
9:59 Number 3
10:47 Number 2
11:50 Number 1

## 25 Best PS4 & PS5 Games of 2022 [4K]
 - [https://www.youtube.com/watch?v=gUQahOSM0YI](https://www.youtube.com/watch?v=gUQahOSM0YI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-12-19 00:00:00+00:00

2022 saw tons of great games releasing on PS5 and PS4 covering a variety of genres. 
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:18 Steelrising
1:01 Cult of the Lamb
1:38 Mount & Blade II: Bannerlord
2:23 Lego Star Wars: The Skywalker Saga
3:02 Stray
3:42 Sniper Elite 5
4:32 Thymesia
5:34 MultiVersus
6:18 The Quarry
7:07 JoJo’s Bizarre Adventure: All-Star Battle R
7:49 Marvel’s Midnight Suns
8:38 Crisis Core Final Fantasy 7 Reunion
9:38 GhostWire Tokyo
10:23 Evil West
11:10 Sonic Frontiers
12:09 A Plague Tale: Requiem
12:47 Rollerdrome
13:32 Stranger of Paradise: Final Fantasy Origin
14:22 Sifu 
14:53 Gran Turismo 7
15:40 Dying Light 2 Stay Human
16:17 The Last of Us Part 1
16:58 Horizon Forbidden West
17:26 Elden Ring
17:56 God of War Ragnarok
18:33 BONUS

#25 Steelrising

Platform : PC PS5 XSX|S

Release Date : September 8, 2022



#24 Cult of the Lamb

Platform : PS5 PS4 PC Xbox One XSX|S Switch

Release Date : 11 August 2022



#23 Mount & Blade II: Bannerlord

Platform : PS5 PS4 PC Xbox One XSX|S 

Release Date : October 25, 2022



#22 Lego Star Wars: The Skywalker Saga

Platform : PS5 PS4 PC Xbox One XSX|S Switch

Release Date : 5 April 2022



#21 Stray

Platform : PC PS4 PS5

Release Date : 19 July 2022



#20 Sniper Elite 5

Platform : PS5 PS4 PC Xbox One XSX|S

Release Date : 26 May 2022



#19 Thymesia

Platform : PS5 XSX|S PC Switch Amazon Luna

Release Date : August 18, 2022



#18 MultiVersus

Platform : PS5 PS4 PC Xbox One XSX|S

Release Date : July 19, 2022



#17 The Quarry

Platform : PS5 PS4 PC Xbox One XSX|S

Release Date : 10 June 2022



#16 JoJo’s Bizarre Adventure: All-Star Battle R

Platform : PS5 PS4 PC Xbox One XSX|S Switch

Release Date : Sep 1, 2022



#15 Marvel’s Midnight Suns

Platform : PC PS5 XSX|S

Release Date : December 2, 2022



#14 Crisis Core Final Fantasy 7 Reunion

Platform : PS5 PS4 PC Xbox One XSX|S Switch

Release Date : December 13, 2022



#13 GhostWire Tokyo

Platform : PC PS5

Release Date : March 25, 2022



#12 Evil West

Platform : PS5 PS4 PC Xbox One XSX|S

Release Date : November 22, 2022



#11 Sonic Frontiers

Platform : PS5 PS4 PC Xbox One XSX|S Switch

Release Date : November 8, 2022



#10 A Plague Tale: Requiem

Platform : PS5 XSX|X PC Switch

Release Date : October 18, 2022



#9 Rollerdrome

Platform : PC PS4 PS5 

Release Date : August 16, 2022



#8 Stranger of Paradise: Final Fantasy Origin

Platform : PS5 PS4 PC Xbox One XSX|S

Release Date : March 18, 2022



#7 Sifu 

Platform : PC PS4 PS5 February 8, 2022

Release Date : Switch November 8, 2022



#6 Gran Turismo 7

Platform : PS4 PS5 

Release Date : March 4, 2022 



#5 Dying Light 2 Stay Human

Platform : PS5 PS4 PC Xbox One XSX|S

Release Date : February 4, 2022



#4 The Last of Us Part 1

Platform : PS5

Release Date : September 2, 2022



#3 Horizon Forbidden West

Platform : PS4 PS5

Release Date : February 18, 2022



#2 Elden Ring

Platform : PS5 PS4 PC Xbox One XSX|S

Release Date : February 25, 2022



#1 God of War Ragnarok

Platform : PS4 PS5 

Release Date : November 9, 2022



BONUS 



Uncharted: Legacy of Thieves Collection

Platform : PS5 PC 

Release Date : January 28, 2022



Inscryption

Platform : PS4 PS5 PC Switch

Release Date : August 30, 2022



The Callisto Protocol

Platform : PS5 PS4 PC Xbox One XSX|S

Release Date : December 2, 2022



Persona 5 Royal

Platform : PS5 PC Xbox One XSX|S Switch PS4 

Release Date : October 21, 2022



The Stanley Parable: Ultra Deluxe

Platform : PS5 PC Xbox One XSX|S Switch PS4  

Release Date : April 27, 2022



Destiny 2: The Witch Queen

Platform : PS5 PC Xbox One XSX|S Stadia PS4 

Release Date : February 22, 2022



Need for Speed Unbound

Platform : PC PS5 XSX|S 

Release Date : December 2, 2022


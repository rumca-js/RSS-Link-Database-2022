# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## As US debates Title 42 policy, asylum seekers left in limbo
 - [https://www.aljazeera.com/news/2022/12/19/as-us-debates-end-to-title-42-policy-asylum-seekers-left-in-limbo](https://www.aljazeera.com/news/2022/12/19/as-us-debates-end-to-title-42-policy-asylum-seekers-left-in-limbo)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 23:14:00+00:00

The Supreme Court intervened on Monday to block the controversial immigration policy&#039;s scheduled expiration this week.

## US manufacturer Honeywell to pay $200m to settle bribery charges
 - [https://www.aljazeera.com/economy/2022/12/19/us-manufacturer-honeywell-to-pay-200m-to-settle-bribery-charges](https://www.aljazeera.com/economy/2022/12/19/us-manufacturer-honeywell-to-pay-200m-to-settle-bribery-charges)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 22:56:43+00:00

Parallel investigations were for bribes that Honeywell paid from 2010 to 2014 to get business from Brazil&#039;s Petrobras.

## Proud Boys trial moves forward as January 6 panel prepares report
 - [https://www.aljazeera.com/news/2022/12/19/proud-boys-trial-moves-forward-as-january-6-panel-prepares-report](https://www.aljazeera.com/news/2022/12/19/proud-boys-trial-moves-forward-as-january-6-panel-prepares-report)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 21:57:53+00:00

Defence lawyers previously called for jury selection to be postponed to 2023 due to &#039;combustible&#039; political climate.

## US seeks to bolster Ecuador ties as China expands regional role
 - [https://www.aljazeera.com/news/2022/12/19/us-seeks-to-bolster-ecuador-ties-as-china-expands-regional-role](https://www.aljazeera.com/news/2022/12/19/us-seeks-to-bolster-ecuador-ties-as-china-expands-regional-role)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 21:27:50+00:00

Joe Biden says US will seek to expand relationship with Ecuador as President Guillermo Lasso visits White House.

## What’s gone wrong with the UK’s National Health Service?
 - [https://www.aljazeera.com/program/inside-story/2022/12/19/whats-gone-wrong-with-the-uks-national-health-service](https://www.aljazeera.com/program/inside-story/2022/12/19/whats-gone-wrong-with-the-uks-national-health-service)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 20:24:16+00:00

NHS healthcare staff calling for better pay and work conditions are pushing ahead with another round of strikes.

## Sudanese security forces tear-gas pro-democracy protesters
 - [https://www.aljazeera.com/news/2022/12/19/pro-democracy-protesters-teargassed-by-sudanese-security-forces](https://www.aljazeera.com/news/2022/12/19/pro-democracy-protesters-teargassed-by-sudanese-security-forces)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 20:13:30+00:00

Thousands of demonstrator in Khartoum demand an end to military rule and justice for those killed since last year&#039;s coup

## UN chief promises ‘no-nonsense’ climate summit in 2023
 - [https://www.aljazeera.com/news/2022/12/19/un-chief-promises-no-nonsense-climate-summit-in-2023](https://www.aljazeera.com/news/2022/12/19/un-chief-promises-no-nonsense-climate-summit-in-2023)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 19:37:45+00:00

Secretary General Antonio Guterres warns that governments have fallen short of their emission reduction targets.

## England cruise towards test history as Ahmed destroys Pakistan
 - [https://www.aljazeera.com/sports/2022/12/19/cricket-england-cruise-towards-test-history-ahmed-destroys-pakistan](https://www.aljazeera.com/sports/2022/12/19/cricket-england-cruise-towards-test-history-ahmed-destroys-pakistan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 19:33:42+00:00

Rehan Ahmed, aged just 18, took five wickets and left England on the brink of historic victory.

## US Capitol riot: Lawmakers recommend filing charges against Trump
 - [https://www.aljazeera.com/news/2022/12/19/us-capitol-riot-lawmakers-recommend-filing-charges-against-trump](https://www.aljazeera.com/news/2022/12/19/us-capitol-riot-lawmakers-recommend-filing-charges-against-trump)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 19:30:52+00:00

Congressional panel urges Justice Department to indict ex-president for inciting insurrection, among other charges.

## Fortnite creator Epic Games to pay record fine
 - [https://www.aljazeera.com/economy/2022/12/19/fortnite-creator-epic-games-to-pay-record-fine](https://www.aljazeera.com/economy/2022/12/19/fortnite-creator-epic-games-to-pay-record-fine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 19:03:52+00:00

It will pay for violating a children&#039;s privacy law and tricking users to make purchases they did not intend to make.

## EU countries agree gas price cap to battle energy crisis
 - [https://www.aljazeera.com/news/2022/12/19/eu-countries-agree-gas-price-cap-to-battle-energy-crisis](https://www.aljazeera.com/news/2022/12/19/eu-countries-agree-gas-price-cap-to-battle-energy-crisis)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 18:51:36+00:00

The 27-nation bloc has agreed to trigger a cap if gas prices exceed 180 euros per megawatt hour for three days.

## Staff picks: My favourite World Cup 2022 moment
 - [https://www.aljazeera.com/news/2022/12/19/staff-picks-my-favourite-world-cup-2022-moment](https://www.aljazeera.com/news/2022/12/19/staff-picks-my-favourite-world-cup-2022-moment)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 18:27:04+00:00

From Morocco&#039;s fairytale journey to Japan fans cleaning up after the match, here are a few highlights of the World Cup.

## Analysis: Six key takeaways from the Qatar World Cup
 - [https://www.aljazeera.com/news/2022/12/19/six-key-takeaways-qatar-world-cup](https://www.aljazeera.com/news/2022/12/19/six-key-takeaways-qatar-world-cup)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 18:02:16+00:00

From the end of Messi&#039;s wait for glory to the first Arab tournament, and the mixing of politics and sports.

## Karim Benzema calls full time on international football career
 - [https://www.aljazeera.com/sports/2022/12/19/france-karim-benzema-retires-international-football](https://www.aljazeera.com/sports/2022/12/19/france-karim-benzema-retires-international-football)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 17:20:50+00:00

The 35-year-old Real Madrid striker missed France&#039;s attempted defence of their World Cup title due to injury.

## Tunisia’s election: The beginning of the end for Saeid
 - [https://www.aljazeera.com/opinions/2022/12/19/tunisias-election-the-beginning-of-the-end-for-saeid](https://www.aljazeera.com/opinions/2022/12/19/tunisias-election-the-beginning-of-the-end-for-saeid)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 17:11:04+00:00

Saturday&#039;s sham election will not be able to save President Saeid&#039;s authoritarian regime.

## Colombia’s ELN rebels announce end-of-year ceasefire
 - [https://www.aljazeera.com/news/2022/12/19/colombias-eln-rebels-announce-end-of-year-ceasefire](https://www.aljazeera.com/news/2022/12/19/colombias-eln-rebels-announce-end-of-year-ceasefire)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 17:08:49+00:00

Truce will last from Saturday to January 2, leftist rebels say, as peace talks with Bogota to resume next month.

## South Africa’s Ramaphosa re-elected as leader of ruling ANC party
 - [https://www.aljazeera.com/news/2022/12/19/south-africas-ramaphosa-reelected-as-leader-of-ruling-anc-party](https://www.aljazeera.com/news/2022/12/19/south-africas-ramaphosa-reelected-as-leader-of-ruling-anc-party)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 16:09:55+00:00

The party conference has been marked by divisions and scandals surrounding Ramaphosa and his rival Zweli Mkhize.

## Palestinian-American to be released after Israeli detention
 - [https://www.aljazeera.com/news/2022/12/19/palestinian-american-detained-israel-after-jerusalem-entry](https://www.aljazeera.com/news/2022/12/19/palestinian-american-detained-israel-after-jerusalem-entry)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 15:38:35+00:00

Hala Kasim Salameh&#039;s family said she had a permit to enter Jerusalem but was arrested by Israeli authorities.

## Netherlands apologises for Dutch government’s role in slavery
 - [https://www.aljazeera.com/news/2022/12/19/netherlands-apologises-for-dutch-governments-role-in-slavery](https://www.aljazeera.com/news/2022/12/19/netherlands-apologises-for-dutch-governments-role-in-slavery)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 15:27:27+00:00

PM Mark Rutte says the Dutch state has enabled, stimulated and profited from slavery for centuries.

## Putin makes rare visit to Minsk for talks with Belarus leader
 - [https://www.aljazeera.com/news/2022/12/19/putin-makes-rare-visit-to-minsk-for-talks-with-belarus-leader](https://www.aljazeera.com/news/2022/12/19/putin-makes-rare-visit-to-minsk-for-talks-with-belarus-leader)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 15:24:57+00:00

Kremlin rejects claims that the Russian president is pressuring Belarus into a more active role in the war in Ukraine.

## Thailand navy searches for 31 missing sailors after warship sinks
 - [https://www.aljazeera.com/news/2022/12/19/thailand-navy-searches-for-31-missing-sailors-after-warship-sinks](https://www.aljazeera.com/news/2022/12/19/thailand-navy-searches-for-31-missing-sailors-after-warship-sinks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 14:31:16+00:00

Naval vessel HTMS Sukhothai capsizes in high waves late on Sunday while patrolling the Gulf of Thailand.

## Malaysia PM Anwar Ibrahim wins motion of confidence in parliament
 - [https://www.aljazeera.com/news/2022/12/19/malaysia-pm-anwar-ibrahim-wins-motion-of-confidence-in-parliament](https://www.aljazeera.com/news/2022/12/19/malaysia-pm-anwar-ibrahim-wins-motion-of-confidence-in-parliament)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 14:05:28+00:00

The win is vital backing for Anwar&#039;s premiership after an election last month returned an unprecedented hung parliament.

## Tunisia set for runoffs after low turnout parliamentary elections
 - [https://www.aljazeera.com/news/2022/12/19/runoffs-due-in-most-tunisian-districts-in-parliament-election](https://www.aljazeera.com/news/2022/12/19/runoffs-due-in-most-tunisian-districts-in-parliament-election)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 14:05:10+00:00

Only 21 candidates secured victory in the first round of votes marked by low turnout, electoral commission says.

## Iran says four security forces killed near Pakistan border
 - [https://www.aljazeera.com/news/2022/12/19/irgc-says-four-security-forces-killed-near-pakistan-border](https://www.aljazeera.com/news/2022/12/19/irgc-says-four-security-forces-killed-near-pakistan-border)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 12:37:15+00:00

Members of Iran&#039;s security forces killed in a firefight with an unnamed &#039;terrorist group&#039;, state media reports.

## The morning after: Qatar wakes up to post World Cup life
 - [https://www.aljazeera.com/news/2022/12/19/post-world-cup-blues-start-to-set-in-for-qatar-residents](https://www.aljazeera.com/news/2022/12/19/post-world-cup-blues-start-to-set-in-for-qatar-residents)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 12:33:32+00:00

People express sadness over the World Cup ending but say they feel privileged to have been a part of it.

## Sri Lanka navy rescues over 100 Rohingya adrift in rough seas
 - [https://www.aljazeera.com/news/2022/12/19/sri-lanka-navy-rescues-over-100-rohingya-adrift-in-rough-seas](https://www.aljazeera.com/news/2022/12/19/sri-lanka-navy-rescues-over-100-rohingya-adrift-in-rough-seas)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 12:31:41+00:00

Navy says 104 people found on board a trawler suspected to have originated from Myanmar and heading to Indonesia.

## UK’s bid to send asylum seekers to Rwanda is ‘lawful’: High Court
 - [https://www.aljazeera.com/news/2022/12/19/uks-bid-to-send-asylum-seekers-to-rwanda-is-lawful-high-court](https://www.aljazeera.com/news/2022/12/19/uks-bid-to-send-asylum-seekers-to-rwanda-is-lawful-high-court)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 12:23:24+00:00

Judges say the UK government’s controversial plan to send asylum seekers on a one-way trip to Rwanda is legal.

## ‘Pure joy’: Argentina erupts in celebration after World Cup win
 - [https://www.aljazeera.com/news/2022/12/19/a-display-of-pure-joy-argentinians-celebrate-world-cup-win](https://www.aljazeera.com/news/2022/12/19/a-display-of-pure-joy-argentinians-celebrate-world-cup-win)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 12:06:53+00:00

An explosion of hope and joy engulfs the nation after their team, led by Messi, won the World Cup on Sunday.

## Hostages taken at Pakistan counterterrorism centre seized by TTP
 - [https://www.aljazeera.com/news/2022/12/19/hostages-taken-at-pakistan-counterterrorism-centre-seized-by-ttp](https://www.aljazeera.com/news/2022/12/19/hostages-taken-at-pakistan-counterterrorism-centre-seized-by-ttp)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 11:53:47+00:00

Standoff continues after Pakistani Taliban men overpower guards, snatch weapons and take hostages at facility in Bannu.

## Countries seal deal to protect nature despite DRC objection
 - [https://www.aljazeera.com/news/2022/12/19/countries-seal-deal-to-protect-nature-despite-congo-objection](https://www.aljazeera.com/news/2022/12/19/countries-seal-deal-to-protect-nature-despite-congo-objection)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 11:46:08+00:00

As part of the agreement, countries committed to protect 30 percent of land and water considered ecologically vital.

## Sweden’s top court blocks Turkish journalist’s extradition
 - [https://www.aljazeera.com/news/2022/12/19/swedens-top-court-blocks-turkish-journalists-extradition](https://www.aljazeera.com/news/2022/12/19/swedens-top-court-blocks-turkish-journalists-extradition)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 11:17:10+00:00

The extradition of Bulent Kenes is a key demand by Ankara to ratify Stockholm&#039;s NATO membership.

## Photos: Peaceful polls, coups, droughts mark Africa in 2022
 - [https://www.aljazeera.com/gallery/2022/12/19/africa-has-peaceful-polls-in-2022-hit-by-coups-droughts](https://www.aljazeera.com/gallery/2022/12/19/africa-has-peaceful-polls-in-2022-hit-by-coups-droughts)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 10:47:45+00:00

Conflicts within and outside Africa impacted the continent in 2022, but multiple peaceful transitions offered hope.

## Lionel Messi: A breakdown of his World Cup and career highlights
 - [https://www.aljazeera.com/sports/2022/12/19/lionel-messi-a-break-down-of-his-world-cup-and-career-highlights](https://www.aljazeera.com/sports/2022/12/19/lionel-messi-a-break-down-of-his-world-cup-and-career-highlights)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 10:44:04+00:00

After inspiring Argentina to a historic World Cup victory in Qatar, we look back at his illustrious career.

## Where do Palestinians stand on the war in Ukraine?
 - [https://www.aljazeera.com/opinions/2022/12/19/are-palestinians-pro-russia](https://www.aljazeera.com/opinions/2022/12/19/are-palestinians-pro-russia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 10:13:32+00:00

Palestinians have been accused of being pro-Russia. But they are just tired of never-ending Western hypocrisy.

## World Cup predictions: How many games did our AI get right?
 - [https://www.aljazeera.com/news/2022/12/19/world-cup-predictions-did-our-ai](https://www.aljazeera.com/news/2022/12/19/world-cup-predictions-did-our-ai)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 09:51:01+00:00

In total, Kashef had a 67 percent accuracy level, but failed to predict Argentina as the 2022 World Cup winners.

## 11 people seriously injured by turbulence on Hawaii flight
 - [https://www.aljazeera.com/news/2022/12/19/11-people-seriously-injured-by-turbulence-on-hawaii-flight](https://www.aljazeera.com/news/2022/12/19/11-people-seriously-injured-by-turbulence-on-hawaii-flight)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 09:34:59+00:00

At least one person was reported to have been rendered unconscious but all patients were awake and talking.

## What is a bisht and why was Messi wearing it at the World Cup?
 - [https://www.aljazeera.com/news/2022/12/19/why-was-messi-wearing-a-bisht-at-world-cup-ceremony](https://www.aljazeera.com/news/2022/12/19/why-was-messi-wearing-a-bisht-at-world-cup-ceremony)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 09:30:27+00:00

Emir of Qatar put a bisht on Argentina captain Messi during the World Cup closing ceremony.

## Mexico and the unbearable whiteness of advertising
 - [https://www.aljazeera.com/opinions/2022/12/19/the-unbearable-whiteness-of-advertising-in-mexico-and-beyond](https://www.aljazeera.com/opinions/2022/12/19/the-unbearable-whiteness-of-advertising-in-mexico-and-beyond)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 09:17:34+00:00

From beers to cars to supermarkets, Mexico and other postcolonial societies are grappling with a whiteness epidemic.

## Five dead, suspect killed in Toronto area shooting
 - [https://www.aljazeera.com/news/2022/12/19/5-dead-and-suspect-killed-in-toronto-area-condo-shooting](https://www.aljazeera.com/news/2022/12/19/5-dead-and-suspect-killed-in-toronto-area-condo-shooting)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 08:33:23+00:00

The attack took place in different apartments in the same building and one wounded person was taken to a hospital.

## Russia drone attack targets ‘critical infrastructure’ in Kyiv
 - [https://www.aljazeera.com/news/2022/12/19/drone-attack-target-critical-infrastructure-in-kyiv-officials](https://www.aljazeera.com/news/2022/12/19/drone-attack-target-critical-infrastructure-in-kyiv-officials)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 08:24:34+00:00

Ukraine&#039;s military says about 20 unmanned aerial vehicles targeted facilities around the capital.

## Three Jordanian police killed during raid on hideout in Maan
 - [https://www.aljazeera.com/news/2022/12/19/three-jordanian-police-killed-during-raid-on-hideout-in-maan](https://www.aljazeera.com/news/2022/12/19/three-jordanian-police-killed-during-raid-on-hideout-in-maan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 07:34:43+00:00

Police officers died during a raid on the suspected killers of a senior Jordanian police officer who died on Friday.

## Argentina’s fans celebrate in the streets after World Cup victory
 - [https://www.aljazeera.com/news/2022/12/19/immense-joy-argentinas-fans-entranced-by-messis-world-cup](https://www.aljazeera.com/news/2022/12/19/immense-joy-argentinas-fans-entranced-by-messis-world-cup)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 06:48:47+00:00

&#039;This team made people fall in love with them for the first time in decades,&#039; an Argentinian fan said.

## Dozens of sailors missing after Thai navy ship sinks
 - [https://www.aljazeera.com/news/2022/12/19/dozens-of-sailors-missing-after-thai-navy-ship-sinks](https://www.aljazeera.com/news/2022/12/19/dozens-of-sailors-missing-after-thai-navy-ship-sinks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 06:35:20+00:00

The HTMS Sukhothai was carrying 106 people when it sank in choppy waters in the Gulf of Thailand, the navy says.

## Elon Musk asks Twitter to vote on whether he should step down
 - [https://www.aljazeera.com/economy/2022/12/19/elon-musk-asks-twitter-to-vote-on-him-stepping-down](https://www.aljazeera.com/economy/2022/12/19/elon-musk-asks-twitter-to-vote-on-him-stepping-down)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 05:25:10+00:00

Musk runs Twitter poll on his leadership after backlash to new policy banning &#039;free promotion&#039; of other platforms.

## South Korea warns of deepening economic slump
 - [https://www.aljazeera.com/economy/2022/12/19/south-korea-warns-of-deepening-economic-slump](https://www.aljazeera.com/economy/2022/12/19/south-korea-warns-of-deepening-economic-slump)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 04:38:12+00:00

Asia&#039;s fourth-largest economy is widely expected to see growth fall below 2 percent next year.

## UK’s PM Sunak to announce $304m in new military aid for Ukraine
 - [https://www.aljazeera.com/news/2022/12/19/uk-to-announce-304m-in-new-military-aid-for-ukraine](https://www.aljazeera.com/news/2022/12/19/uk-to-announce-304m-in-new-military-aid-for-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 04:28:34+00:00

PM&#039;s office says the new package will include &#039;hundreds of thousands of rounds of artillery&#039; for use against Russia.

## Kyiv slams Kissinger over call to negotiate with Russia for peace
 - [https://www.aljazeera.com/news/2022/12/19/kyiv-slams-kissinger-over-call-to-negotiate-with-russia-for-peace](https://www.aljazeera.com/news/2022/12/19/kyiv-slams-kissinger-over-call-to-negotiate-with-russia-for-peace)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 04:23:49+00:00

&#039;For all its propensity to violence, Russia has made decisive contributions to the global equilibrium&#039;: Henry Kissinger.

## As ‘zero-COVID’ unravels, some Chinese still fear travel abroad
 - [https://www.aljazeera.com/economy/2022/12/19/as-zero-covid-unravels-some-chinese-still-fear-travel-abroad](https://www.aljazeera.com/economy/2022/12/19/as-zero-covid-unravels-some-chinese-still-fear-travel-abroad)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 03:37:14+00:00

Chinese spent $288bn on international travel in 2018, nearly one-quarter of the global spending on tourism.

## ‘We fought until the end’: French World Cup fans sing Les Bleus
 - [https://www.aljazeera.com/news/2022/12/19/we-fought-until-the-end-french-fans-sing-the-blues-2](https://www.aljazeera.com/news/2022/12/19/we-fought-until-the-end-french-fans-sing-the-blues-2)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 02:56:38+00:00

&quot;Les Bleus made us dream,&quot; President Emmanuel Macron said after France’s dramatic World Cup final loss to Argentina.

## Photos: World Cup victory parade takes to the street in Qatar
 - [https://www.aljazeera.com/gallery/2022/12/19/photos-world-cup-victory-parade-takes-to-the-street](https://www.aljazeera.com/gallery/2022/12/19/photos-world-cup-victory-parade-takes-to-the-street)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 01:57:25+00:00

Joyous crowds lined Lusail Boulevard in Qatar following the conclusion of an incredible World Cup final.

## N Korea completes ‘important’ test of spy satellite: State media
 - [https://www.aljazeera.com/news/2022/12/19/n-korea-completes-important-test-of-spy-satellite-state-media](https://www.aljazeera.com/news/2022/12/19/n-korea-completes-important-test-of-spy-satellite-state-media)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2022-12-19 01:15:25+00:00

N Korea has released satellite imagery of South Korea&#039;s Seoul and Incheon cities presumed to have been shot during test.


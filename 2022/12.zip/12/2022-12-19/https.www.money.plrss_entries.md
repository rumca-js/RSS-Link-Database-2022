# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## PKB wyhamuje, czeka nas recesja. PIE pokazał prognozy
 - [https://www.money.pl/gospodarka/pkb-wyhamuje-czeka-nas-recesja-pie-pokazal-prognozy-6846366492347232a.html](https://www.money.pl/gospodarka/pkb-wyhamuje-czeka-nas-recesja-pie-pokazal-prognozy-6846366492347232a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 18:56:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4898f1a5-5d1b-425e-b6a7-c2df408cc0ba" width="308" /> Jak wynika z prognozy Polskiego Instytutu Ekonomicznego, wzrost PKB Polski w 2023 roku wyhamuje do 1,2 proc., a na początku przyszłego roku pojawi się recesja. W 2024 roku w ocenie PIE PKB Polski wzrośnie o 3,1 proc.

## Tak taniego OC mogą nam pozazdrościć Rumuni, Słowacy i Czesi. Polska na zakręcie
 - [https://www.money.pl/ubezpieczenia/tak-taniego-oc-moga-nam-pozazdroscic-rumuni-slowacy-i-czesi-polska-na-zakrecie-6845319898086144a.html](https://www.money.pl/ubezpieczenia/tak-taniego-oc-moga-nam-pozazdroscic-rumuni-slowacy-i-czesi-polska-na-zakrecie-6845319898086144a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 18:28:36+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2002fc89-8ae7-4d56-a524-d6c3c2afd041" width="308" /> Ubezpieczenia komunikacyjne w Polsce tanieją od pięciu lat. I chociaż zewsząd słychać głosy, że sytuacja musi się zmienić, to zdaniem największego pośrednika w regionie Europy Środkowo-Wschodniej z aspiracjami do ekspansji na Zachód, nie nastąpi to prędko. Dla branży to może być problem.

## Epidemia ptasiej grypy daje się we znaki. Tak źle dawno nie było
 - [https://www.money.pl/gospodarka/epidemia-ptasiej-grypy-daje-sie-we-znaki-tak-zle-dawno-nie-bylo-6846302259596128a.html](https://www.money.pl/gospodarka/epidemia-ptasiej-grypy-daje-sie-we-znaki-tak-zle-dawno-nie-bylo-6846302259596128a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 16:25:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/87e4a06d-3ec4-4856-81dc-656663ed08e1" width="308" /> Ptasia grypa znów zbiera ponure żniwo. Od października do grudnia straty drobiu wyniosły 16 mln sztuk - to wynik wyższy o 70 proc. niż rok temu. Śmiertelny dla ptaków wirus sprawia, że ceny jaj oraz tuszek są na świecie coraz wyższe - podaje Bloomberg.

## Poseł Platformy Obywatelskiej zasiada w radzie nadzorczej spółki. Media: mógł naruszyć prawo
 - [https://www.money.pl/gospodarka/posel-platformy-obywatelskiej-zasiada-w-radzie-nadzorczej-spolki-media-mogl-naruszyc-prawo-6846328588323648a.html](https://www.money.pl/gospodarka/posel-platformy-obywatelskiej-zasiada-w-radzie-nadzorczej-spolki-media-mogl-naruszyc-prawo-6846328588323648a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 16:22:16+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0e66bd5d-62d1-4688-919a-0e8b4bac3846" width="308" /> Poseł i lider lubuskiej Platformy Obywatelskiej Waldemar Sługocki od kwietnia zasiada w radzie nadzorczej prywatnej spółki Gazstal S.A. Z ustaleń dziennikarzy wynika, że miał nie poinformować o tym Marszałek Sejmu, za co zgodnie z obowiązującymi przepisami grozi mu odpowiedzialność regulaminowa – pisze "Gazeta Lubuska".

## Wraca wyższy VAT na paliwa. Prezes Orlenu składa deklarację ws. cen na stacjach
 - [https://www.money.pl/podatki/wraca-wyzszy-vat-na-paliwa-prezes-orlenu-sklada-deklaracje-ws-cen-na-stacjach-6846309328849760a.html](https://www.money.pl/podatki/wraca-wyzszy-vat-na-paliwa-prezes-orlenu-sklada-deklaracje-ws-cen-na-stacjach-6846309328849760a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 15:48:44+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1fd43790-ad79-4f66-80d0-45c0ee16a30a" width="308" /> Stawka VAT na paliwa wzrośnie w 2023 roku do poziomu 23 proc. W lutym tego roku rząd obniżył ją do ośmiu procent w ramach tarczy antyinflacyjnej, ale z tym rozwiązaniem koniec. Jak jednak zapowiada Daniel Obajtek, nie powinno to mieć większego wpływu na ceny paliw na stacjach Orlenu. Według ekspertów w tym tygodniu za benzynę Pb95 będziemy płacić średnio 6,51-6,63 zł, a za olej napędowy 7,67-7,79 zł.

## Pięć nowych podmiotów na liście ostrzeżeń KNF. Jest komunikat
 - [https://www.money.pl/pieniadze/piec-nowych-podmiotow-na-liscie-ostrzezen-knf-jest-komunikat-6846286708284256a.html](https://www.money.pl/pieniadze/piec-nowych-podmiotow-na-liscie-ostrzezen-knf-jest-komunikat-6846286708284256a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 13:55:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f4bc41ff-f99d-42c9-8113-21f70cdbd581" width="308" /> Lista ostrzeżeń publicznych Komisji Nadzoru Finansowego się powiększa o pięć kolejnych podmiotów. Organ na listę wpisał: Ethereal Group LLC, GCB London, Libellium, Monero Emilia Biegańska oraz Hala Tech – podała w poniedziałek KNF.

## Kontrowersje ws. fuzji Orlenu z Lotosem. Obajtek: biznes polega na pewnych kompromisach
 - [https://www.money.pl/gospodarka/kontrowersje-ws-fuzji-orlenu-z-lotosem-obajtek-biznes-polega-na-pewnych-kompromisach-6846266816846592a.html](https://www.money.pl/gospodarka/kontrowersje-ws-fuzji-orlenu-z-lotosem-obajtek-biznes-polega-na-pewnych-kompromisach-6846266816846592a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 12:10:56+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9dd332cf-896a-4abb-9b15-1dd61629b073" width="308" /> Prezes PKN Orlen podczas rozmowy w radiu RMF FM podkreślił, że spółka, wbrew temu, czego oczekuje opozycja,  nie udostępni umowy ws. sprzedaży części Rafinerii Gdańskiej Saudyjczykom. W osttnich dniach media wskazują na coraz więcej wątpliwości dotyczących tej transakcji.

## Oto jak akcje deweloperów zareagowały na niespodziewaną pomoc od rządu
 - [https://www.money.pl/gielda/gpw-oto-jak-akcje-deweloperow-zareagowaly-na-niespodziewana-pomoc-od-rzadu-6846257648208640a.html](https://www.money.pl/gielda/gpw-oto-jak-akcje-deweloperow-zareagowaly-na-niespodziewana-pomoc-od-rzadu-6846257648208640a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 12:10:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/39732037-9b83-44ff-8ccb-799b1fd3703f" width="308" /> Ostatni tydzień przed świętami rozpoczął się zwyżkami, a – jak zauważa serwis stockwatch.pl – wśród zyskujących spółek wyróżniają się deweloperzy. Ma to być reakcja na rządowy program mieszkaniowy, który może wpłynąć pozytywnie na ich zyski, jeśli przełoży się na zwiększenie liczby osób zainteresowanych kupnem mieszkania.

## Argentyna z mistrzostwem świata. To może pomóc dołującej gospodarce
 - [https://www.money.pl/gospodarka/argentyna-z-mistrzostwem-swiata-to-moze-pomoc-dolujacej-gospodarce-6846223338535648a.html](https://www.money.pl/gospodarka/argentyna-z-mistrzostwem-swiata-to-moze-pomoc-dolujacej-gospodarce-6846223338535648a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 12:08:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f5d571ef-7f8d-4bf0-aca0-e87d6fd1783b" width="308" /> Mistrzostwo świata w piłce nożnej dla Argentyny powinno pozytywnie wpłynąć na gospodarkę tego kraju. Badania pokazują, że w krajach piłkarskich mistrzów notuje się wzrost PKB. Dla borykającej się z wieloma problemami Argentyny to chwila oddechu.

## Zameldowanie w wynajmowanym mieszkaniu – czy to możliwe?
 - [https://www.money.pl/gospodarka/zameldowanie-w-wynajmowanym-mieszkaniu-czy-to-mozliwe-6846250964302560a.html](https://www.money.pl/gospodarka/zameldowanie-w-wynajmowanym-mieszkaniu-czy-to-mozliwe-6846250964302560a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 11:06:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6049f0c3-2106-4472-94b7-dc2a5d681bbc" width="308" /> Meldunek jest pojęciem prawnym, który określa miejsce stałego lub czasowego pobytu obywatela. Właściwie prawo nakazuje, by każdy Polak był zameldowany. Jak jednak to wygląda, jeśli mieszkanie, w którym przebywa dana osoba, jest jedynie wynajmowane? Czy istnieje możliwość meldunku w takim lokalu?

## Czym jest rodzinny kapitał opiekuńczy i kto może się ubiegać o świadczenie?
 - [https://www.money.pl/gospodarka/czym-jest-rodzinny-kapital-opiekunczy-i-kto-moze-sie-ubiegac-o-swiadczenie-6844487942556224a.html](https://www.money.pl/gospodarka/czym-jest-rodzinny-kapital-opiekunczy-i-kto-moze-sie-ubiegac-o-swiadczenie-6844487942556224a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 10:42:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a1c1b9f5-c256-4b43-901c-4e13d6d4be25" width="308" /> W Polsce funkcjonuje wiele programów pozwalających rodzicom na uzyskanie pieniędzy w związku z wychowywaniem dzieci i sprawowaniem nad nimi opieki. Od 1 stycznia 2022 roku obowiązuje na przykład ustawa o rodzinnym kapitale opiekuńczym. Komu przysługuje takie świadczenie i czym właściwie jest?

## Ważna deklaracja ZUS. Emerytury jeszcze przed świętami
 - [https://www.money.pl/emerytury/wazna-deklaracja-zus-emerytury-jeszcze-przed-swietami-6846244150418144a.html](https://www.money.pl/emerytury/wazna-deklaracja-zus-emerytury-jeszcze-przed-swietami-6846244150418144a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 10:38:42+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/dd4e6f47-9b05-4d52-aad7-db17ac5d4631" width="308" /> Emeryci i renciści, którym ZUS wypłaca świadczenia 25. każdego miesiąca, w grudniu otrzymają je przed świętami. Dotyczy to zarówno wypłat przekazywanych przez listonosza, jak i przelewów, które trafiają na rachunki bankowe – poinformowała PAP prezes ZUS prof. Gertruda Uścińska.

## Program Pierwsze Mieszkanie. Wiadomo ile osób może na tym skorzystać
 - [https://www.money.pl/gospodarka/program-pierwsze-mieszkanie-wiadomo-ile-osob-moze-na-tym-skorzystac-6846236012309248a.html](https://www.money.pl/gospodarka/program-pierwsze-mieszkanie-wiadomo-ile-osob-moze-na-tym-skorzystac-6846236012309248a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 10:05:35+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/924d0e90-28d4-40d6-96bf-1c52dcd12d6f" width="308" /> Z programu Pierwsze Mieszkanie będzie można finansować też budowę lub zakup domu - poinformował  minister rozwoju i technologii Waldemar Buda. Szef resortu rozwoju szacuje, że 100 tys. osób jest w stanie skorzystać z tego programu.

## Złoty się umacnia, jednak kurs naszej waluty może znacząco zmienić kierunek
 - [https://www.money.pl/pieniadze/kurs-zlotego-oto-w-jakim-kierunku-moze-podazac-do-konca-2022-r-6846211769129728a.html](https://www.money.pl/pieniadze/kurs-zlotego-oto-w-jakim-kierunku-moze-podazac-do-konca-2022-r-6846211769129728a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 09:50:47+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d67dddfe-3433-4cf2-b8cc-8415ae3bdc9f" width="308" /> Kurs złotego trzyma się mocno, mimo że – jak zauważa dr Przemysław Kwiecień z domu maklerskiego XTB – nastroje na globalnych rynkach uległy zdecydowanemu pogorszeniu, a NBP zawiesił podwyżki stóp przy bardzo wysokiej inflacji w Polsce. Ostatnie dwa tygodnie roku mogą jednak – jego zdaniem – przynieść na rynku walutowym spore zawirowania. Ich ofiarą może paść m.in. także nasza waluta.

## Tak Polska pomaga Ukrainie. Kwota robi wrażenie
 - [https://www.money.pl/gospodarka/tak-polska-pomaga-ukrainie-kwota-robi-wrazenie-6846194851625728a.html](https://www.money.pl/gospodarka/tak-polska-pomaga-ukrainie-kwota-robi-wrazenie-6846194851625728a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 07:18:07+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d6cab6b2-2ce6-478f-9427-da00a5cf14d6" width="308" /> Według ostrożnych szacunków polskie wsparcie dla Ukraińców i Ukrainy może mieć wartość nawet 40 mld zł. Z tego 15,9 mld zł  to pomoc publiczna - pisze  "Rzeczpospolita". Dziennik wylicza, że na 9-10 mld zł szacowane jest prywatne wsparcie tylko w trzech pierwszych miesiącach po wybuchu wojny.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 19.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-19-12-2022-6846176954481376a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-19-12-2022-6846176954481376a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 06:05:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 19.12.2022. W poniedziałek za jedno euro (EUR) trzeba zapłacić 4.6827 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 19.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-19-12-2022-6846176949693152a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-19-12-2022-6846176949693152a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 06:05:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 19.12.2022. W poniedziałek za jednego dolara (USD) trzeba zapłacić 4.4148 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 19.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-19-12-2022-6846176950856416a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-19-12-2022-6846176950856416a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 06:05:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 19.12.2022. W poniedziałek za jednego franka (CHF) trzeba zapłacić 4.734 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 19.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-19-12-2022-6846176948988640a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-19-12-2022-6846176948988640a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 06:05:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 19.12.2022. W poniedziałek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.3752 zł.

## Belgia chce podnieść podatki i wydłużyć wiek emerytalny. "To nigdy nie przejdzie"
 - [https://www.money.pl/gospodarka/belgia-chce-podniesc-podatki-i-wydluzyc-wiek-emerytalny-to-nigdy-nie-przejdzie-6846166806481664a.html](https://www.money.pl/gospodarka/belgia-chce-podniesc-podatki-i-wydluzyc-wiek-emerytalny-to-nigdy-nie-przejdzie-6846166806481664a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-19 05:24:00+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4aac7f6b-f339-4fe0-9d0b-c331a164fc97" width="308" /> Wyższe podatki, praca przez co najmniej 30 lat i koniec emerytalnych przywilejów urzędniczych, to ostatnie propozycje premiera Belgii Aleksandra De Croo, które przedstawił członkom swojego gabinetu. Współrządzący socjaliści, jak relacjonują media, nie zgadzają się na realizacje tych pomysłów i mówią: to nigdy nie przejdzie.


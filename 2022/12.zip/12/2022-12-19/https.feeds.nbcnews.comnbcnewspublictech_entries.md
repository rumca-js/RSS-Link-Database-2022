# Source:NBC tech, URL:https://feeds.nbcnews.com/nbcnews/public/tech, language:en-US

## Twitter users voted to oust Elon Musk in his recent poll. How did we get here?
 - [https://www.nbcnews.com/tech/twitter-users-reach-breaking-point-elon-musk-rcna62403](https://www.nbcnews.com/tech/twitter-users-reach-breaking-point-elon-musk-rcna62403)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2022-12-19 23:30:49+00:00

Elon Musk’s ban on link sharing and his subsequent poll asking whether he should step down has been seized on by some who had previously welcomed him.

## Twitter users vote for Elon Musk to step down as CEO in poll he launched
 - [https://www.nbcnews.com/tech/social-media/twitter-users-vote-elon-musk-quit-ceo-poll-rcna62332](https://www.nbcnews.com/tech/social-media/twitter-users-vote-elon-musk-quit-ceo-poll-rcna62332)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2022-12-19 11:29:21+00:00

Twitter users voted overnight for Elon Musk to step down as the head of the social media platform, in a poll the billionaire launched himself on Sunday.


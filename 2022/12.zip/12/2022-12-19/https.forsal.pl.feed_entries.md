# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Godziny otwarcia sklepów w Wigilię i Sylwestra [LISTA SIECI]
 - [https://forsal.pl/biznes/handel/artykuly/8614126,godziny-otwarcia-sklepow-wigilia-sylwester-biedronka-lidl-zabka.html](https://forsal.pl/biznes/handel/artykuly/8614126,godziny-otwarcia-sklepow-wigilia-sylwester-biedronka-lidl-zabka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 22:34:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8fYktkuTURBXy85NjQ0MGRkZi1mNWJkLTRmNGEtODcxZi1hZWNkMGI0ZDhmMTMuanBlZ5GTBc0BHcyg" />Godziny otwarcia sklepów w Wigilię i Sylwestra są krótsze niż w normalne dni pracujące. Sprawdź, do której godziny będziesz mógł zrobić zakupy m.in. w Biedronce, Lidlu, Żabce, Kauflandzie, Dino, Carrefourze, Auchan czy Rossmanie oraz w jakich godzinach będą otwarte restauracje McDonald's, w których często kierowcy zatrzymują się w czasie świątecznych podróży.

## Putin: Rosja nie chce wchłonąć Białorusi. Departament Stanu USA: To szczyt ironii
 - [https://forsal.pl/swiat/rosja/artykuly/8614123,putin-rosja-nie-chce-wchlonac-bialorusi-departament-stanu-usa-szczyt-ironii.html](https://forsal.pl/swiat/rosja/artykuly/8614123,putin-rosja-nie-chce-wchlonac-bialorusi-departament-stanu-usa-szczyt-ironii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 21:44:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EfnktkuTURBXy85Njg0MjFjYi0zOTVlLTQyMjAtYmMxNy03NTcwZmMwZjExMmEuanBlZ5GTBc0BHcyg" />Słowa Władimira Putina, który oznajmił w poniedziałek w Mińsku, odnosząc się do Białorusi, że Rosja nie chce wchłonąć żadnego kraju, to &quot;szczyt ironii&quot;, zważywszy, że właśnie usiłuje wchłonąć Ukrainę - ocenił rzecznik Departamentu Stanu USA Ned Price.

## Energa Obrót szacuje stratę za energię dla gospodarstw domowych na 930 mln zł
 - [https://forsal.pl/biznes/energetyka/artykuly/8614120,energa-obrot-strata-za-energie-dla-gospodarstw-domowych-2023.html](https://forsal.pl/biznes/energetyka/artykuly/8614120,energa-obrot-strata-za-energie-dla-gospodarstw-domowych-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 20:52:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZPtktkuTURBXy81YzRkMzNhYi1jNjc5LTQ3ZjUtODcwNi05M2I2NDQ3NjIwZTkuanBlZ5GTBc0BHcyg" />Spółka Energa Obrót dokonała oceny wpływu Nadzwyczajnych Regulacji Rynku Energii i wysokości zatwierdzonej Taryfy na swoją działalność i zidentyfikowała potencjalną stratę za realizację umów z gospodarstwami domowymi w 2023 r. na 930 mln zł - poinformowała spółka Energa w komunikacie giełdowym.

## Łukaszenka: Białoruś otrzymała od Rosji rakiety S-400 i Iskander
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8614024,bialorus-otrzymala-od-rosji-rakiety-s-400-i-iskander.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8614024,bialorus-otrzymala-od-rosji-rakiety-s-400-i-iskander.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 19:09:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/G_xktkuTURBXy82ZDNhN2M3Zi01OWE0LTQ4ODYtOTZjMy1kMzRkYzYzZjhiOGIuanBlZ5GTBc0BHcyg" />Białoruś otrzymała od Rosji systemy rakietowe S-400 i Iskander – poinformował Alaksandr Łukaszenka po rozmowach z Władimirem Putinem w Mińsku. Białoruskiego dyktatora przytoczył portal Zierkało.

## Grecja jest gotowa przekazać Ukrainie systemy S-300. W zamian chce amerykańskie Patrioty
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8614022,grecja-ukraina-systemy-s-300-amerykanskie-patrioty.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8614022,grecja-ukraina-systemy-s-300-amerykanskie-patrioty.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 19:01:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UiVktkuTURBXy85MDZlN2ExMS1lNTY0LTRkZTYtYmYzMC1jMDk1ZTkzYWUyZjguanBlZ5GTBc0BHcyg" />Grecja może przekazać systemy obrony powietrznej średniego zasięgu S-300 produkcji rosyjskiej Ukrainie pod warunkiem, że Stany Zjednoczone zainstalują na Krecie system Patriot - poinformował minister obrony Grecji Nikolaos Panagiotopoulos, cytowany przez greckie media.

## Afera korupcyjna w PE. Evie Kaili grozi do 15 lat więzienia
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8613943,afera-korupcyjna-w-pe-evie-kaili-grozi-do-15-lat-wiezienia.html](https://forsal.pl/swiat/unia-europejska/artykuly/8613943,afera-korupcyjna-w-pe-evie-kaili-grozi-do-15-lat-wiezienia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 18:06:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rdMktkuTURBXy8xYzQyYTM2OS00MGQ3LTQ2Y2ItYjk1YS1lNGI1Mzk2N2U2YmEuanBlZ5GTBc0BHcyg" />Eva Kaili, grecka eurodeputowana i była wiceprzewodnicząca Parlamentu Europejskiego oskarżona m.in. o korupcję, czeka na wyniki dwóch śledztw, w Belgii i Grecji. W jej kraju grozi jej nawet do 15 lat więzienia – podaje portal Kathimerini.

## Wynagrodzenia 2023. Firmy planują podwyżki. O ile wzrosną pensje?
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8613938,podwyzki-wynagrodzenia-2023-o-ile-wzrosna-pensje.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8613938,podwyzki-wynagrodzenia-2023-o-ile-wzrosna-pensje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 18:01:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MSEktkuTURBXy9jMGQ0ZTBmMi01MzMyLTRmYTUtYmVjNS1iNWE4ZTY2ZDc3YTEuanBlZ5GTBc0BHcyg" />53 proc. przedsiębiorców planuje w przyszłym roku podwyżki. 17 proc. zamierza dać podwyżki w związku z podniesieniem płacy minimalnej, 22 proc. wyrówna inflację, a 14 proc. podniesie pensje bez względu na inflację i wyższą płacę minimalną – wynika z raportu Personnel Service.

## Premier Holandii przeprosił za udział państwa w niewolnictwie. Reparacji nie będzie
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8613875,holandia-rutte-niewolnictwo-reparacje.html](https://forsal.pl/swiat/aktualnosci/artykuly/8613875,holandia-rutte-niewolnictwo-reparacje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 17:55:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HqektkuTURBXy82OWRjNGU4My1jZTFmLTRhODAtOWE2Ny02OGJiMjU1MWE0ZDIuanBlZ5GTBc0BHcyg" />Szef rządu Mark Rutte przeprosił w poniedziałek podczas wystąpienia w archiwum narodowym za niewolniczą przeszłość Holandii. Premier nazwał niewolnictwo „zbrodnią przeciwko ludzkości”. Politycy, zarówno koalicji jak i opozycji, mówią o „historycznym momencie”. Premier rozwiał jednocześnie wątpliwości w kwestii ewentualnych żądań odszkodowań, mówiąc, że &quot;Holandia nie wypłaci żadnych reparacji&quot;.

## Kanada chce skonfiskować aktywa Romana Abramowicza
 - [https://forsal.pl/swiat/rosja/artykuly/8613843,kanada-chce-skonfiskowac-aktywa-romana-abramowicza.html](https://forsal.pl/swiat/rosja/artykuly/8613843,kanada-chce-skonfiskowac-aktywa-romana-abramowicza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 17:50:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VydktkuTURBXy84M2YzNTViZS1jMzBkLTQwZjEtYjBlMS0yMGU5NjQ5ZTljMDMuanBlZ5GTBc0BHcyg" />Rząd Kanady poinformował w poniedziałek, że ma zamiar skonfiskować warte 26 mln dolarów kanadyjskich (CAD) aktywa firmy, należącej do objętego sankcjami rosyjskiego oligarchy Romana Abramowicza. Pod koniec lipca weszły w życie przepisy umożliwiające przejmowanie i sprzedaż rosyjskich aktywów w Kanadzie.

## Notowania walut. Złoty traci do euro i franka
 - [https://forsal.pl/finanse/waluty/artykuly/8613718,notowania-walut-zloty-traci-do-euro-i-franka.html](https://forsal.pl/finanse/waluty/artykuly/8613718,notowania-walut-zloty-traci-do-euro-i-franka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 17:17:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5i5ktkuTURBXy9kYmE2MmI3NC1hOTVkLTQ1ZjQtYjYxMi0xMzI0YzU3MjBkMTcuanBlZ5GTBc0BHcyg" />W poniedziałek po południu polska waluta traciła do euro i franka, ale zyskiwała do dolara. Europejska waluta była wyceniana na blisko 4,68 zł, dolar na ponad 4,41 zł, a frank szwajcarski na ok. 4,74 zł.

## Kwalifikacja wojskowa 2023. Znamy terminy i zasady
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8613709,kwalifikacja-wojskowa-2023-terminy-i-zasady.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8613709,kwalifikacja-wojskowa-2023-terminy-i-zasady.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 17:03:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5aKktkuTURBXy84Zjk3YjZkOC0wOGQxLTQyNGItODE3Mi1lMGJiMTY1NWNjODcuanBlZ5GTBc0BHcyg" />Kwalifikacja wojskowa w 2023 roku obejmie mężczyzn 19-letnich, mężczyzn w wieku 20-24 lat, którzy nie mają orzeczonej kategorii, oraz kobiety z kwalifikacjami przydatnymi wojsku; kwalifikacja wojskowa w 2023 r. ma się odbywać od kwietnia do końca czerwca – przewiduje projekt rozporządzenia MON.

## Kredyty frankowe. Santander Bank Polska oszacował wpływ ryzyka na zysk w IV kw.
 - [https://forsal.pl/biznes/bankowosc/artykuly/8613691,kredyty-frankowe-santander-bank-polska-wplyw-ryzyka-na-zysk.html](https://forsal.pl/biznes/bankowosc/artykuly/8613691,kredyty-frankowe-santander-bank-polska-wplyw-ryzyka-na-zysk.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 16:49:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ez0ktkuTURBXy8yYTYzNjkyMS0zYWYzLTQ3YWMtOGJiMi1kMzIyNjE5YjM0MzAuanBlZ5GTBc0BHcyg" />Santander Bank Polska zmienił szacunki dotyczące wpływu na zysk brutto w IV kw. ryzyka związanego z portfelem walutowych kredytów hipotecznych - wyniesie on 632 mln zł, podał bank. Z tej kwoty 495 mln zł przypada na Santander Bank Polska zaś 137 mln na Santander Consumer Bank.

## PKO BP. Po roszadach personalnych czas na kompetencyjne
 - [https://forsal.pl/biznes/bankowosc/artykuly/8613684,pko-bp-po-roszadach-personalnych-czas-na-kompetencyjne.html](https://forsal.pl/biznes/bankowosc/artykuly/8613684,pko-bp-po-roszadach-personalnych-czas-na-kompetencyjne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 16:24:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qtOktkuTURBXy83MTRhZmMxMS1mYjkxLTQ4MGMtOTRiNy1kYTlmYTdiM2IyNDguanBlZ5GTBc0BHcyg" />Skutkiem ubiegłotygodniowych zmian w kierownictwie największego banku są przesunięcia w obszarach kompetencji członków zarządu PKO BP.

## Morawiecki: Stoimy murem za fuzją Orlenu z Lotosem
 - [https://forsal.pl/biznes/energetyka/artykuly/8613677,morawiecki-stoimy-murem-za-fuzja-orlenu-z-lotosem.html](https://forsal.pl/biznes/energetyka/artykuly/8613677,morawiecki-stoimy-murem-za-fuzja-orlenu-z-lotosem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 16:13:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yloktkuTURBXy84MWJmZDg3Ny1hMDRkLTRhMjgtODNhNi1jMjRlZWFjOTE1ZmMuanBlZ5GTBc0BHcyg" />Stoimy murem za fuzją Orlenu z Lotosem, która tworzy ogromny podmiot - oświadczył w poniedziałek w Oławie (dolnośląskie) premier Mateusz Morawiecki. Jak dodał, rynek pozytywnie ocenia całą fuzję.

## KE wyemituje obligacje UE o wartości do 80 mld euro
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8613673,ke-wyemituje-obligacje-ue-pierwsza-polowa-2023.html](https://forsal.pl/finanse/aktualnosci/artykuly/8613673,ke-wyemituje-obligacje-ue-pierwsza-polowa-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 16:09:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QRhktkuTURBXy8yZDM5NjM2MS1mMWZmLTRlOWMtODJkYy0wNjcxMzAwOTQ1NDUuanBlZ5GTBc0BHcyg" />Komisja Europejska ogłosiła w poniedziałek, że zamierza wyemitować długoterminowe obligacje UE o wartości do 80 mld euro w pierwszej połowie 2023 r.

## Limit ceny gazu. Jest porozumienie państw UE
 - [https://forsal.pl/biznes/energetyka/artykuly/8613671,limit-ceny-gazu-porozumienie-panstw-ue.html](https://forsal.pl/biznes/energetyka/artykuly/8613671,limit-ceny-gazu-porozumienie-panstw-ue.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 16:04:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1svktkuTURBXy8xNGZhZWFiOC0xMmU0LTQyNmEtYjYyZi04MmVkYmVhZjc4NDguanBlZ5GTBc0BHcyg" />Ministrowie ds. energii i klimatu krajów Unii Europejskiej uzgodnili w Brukseli górną granicę ceny na gaz - poinformował w poniedziałek na Twitterze rzecznik prezydencji czeskiej w UE. Ma to zaradzić zbyt wysokim cenom energii w UE.

## Program "Pierwsze Mieszkanie". To mogą być najtańsze kredyty w historii
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8613547,program-pierwsze-mieszkanie-najtansze-kredyty-w-historii.html](https://forsal.pl/finanse/aktualnosci/artykuly/8613547,program-pierwsze-mieszkanie-najtansze-kredyty-w-historii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 15:31:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2ywktkuTURBXy85MTg3YzRiOS02ZjcyLTRkZjktYWY3ZC05MzU3MTM0Y2Y4OGEuanBlZ5GTBc0BHcyg" />Ponad 235 tysięcy złotych – nawet na tak duże dofinansowanie będą mogli liczyć beneficjenci rządowego programu tanich kredytów – sugerują szacunki HRE Investments. Kwota rozłożona będzie na całą dekadę, ale po ustaniu dopłat rata też powinna być niższa niż w standardowym kredycie.

## Tomasz Siwak został odwołany z zarządu Enei
 - [https://forsal.pl/biznes/energetyka/artykuly/8613624,tomasz-siwak-odwolany-z-zarzadu-enei.html](https://forsal.pl/biznes/energetyka/artykuly/8613624,tomasz-siwak-odwolany-z-zarzadu-enei.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 15:24:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HnQktkuTURBXy9kZTcyMDUwMi00MzEwLTRjNDMtOTEyOC01YmI3MDg2ZDNlZjguanBlZ5GTBc0BHcyg" />Enea poinformowała w poniedziałek w komunikacie, że rada nadzorcza spółki odwołała bez podania przyczyny członka zarządu ds. handlowych Tomasza Siwaka. Siwak pełnił swoją funkcję od 17 sierpnia 2020 r.

## Dług sektora finansów publicznych spadł do 50,3 proc. PKB
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8613579,dlug-sektora-finansow-publicznych-spadl-do-503-proc-pkb.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8613579,dlug-sektora-finansow-publicznych-spadl-do-503-proc-pkb.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 14:25:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aM2ktkuTURBXy83MGY1NGYzMi02YWEzLTRkNTMtOTg3MC02YjNkNzc5MGRkNTAuanBlZ5GTBc0BHcyg" />Dług sektora finansów publicznych spadł do 50,3% PKB, poinformował premier Mateusz Morawiecki.

## Fuzja Orlenu z Lotosem: Rzecznik PiS: Wszystko odbyło się zgodnie z prawem europejskim i krajowym
 - [https://forsal.pl/biznes/energetyka/artykuly/8613601,fuzja-orlenu-z-lotosem-rzecznik-pis.html](https://forsal.pl/biznes/energetyka/artykuly/8613601,fuzja-orlenu-z-lotosem-rzecznik-pis.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 14:20:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/iCvktkuTURBXy9mNjhjOWI4MC01NzE3LTQxOTUtODFmYS0xNDkzMWU4NmY2MDguanBlZ5GTBc0BHcyg" />Wszystko odbyło się zgodnie z prawem europejskim i prawem krajowym - powiedział rzecznik PiS Rafał Bochenek, który odniósł się do wątpliwości dotyczących umowy w sprawie fuzji Orlenu z Lotosem.

## Rafineria Gdańska będzie pod ochroną. Zostanie ujęta w specjalnym wykazie
 - [https://forsal.pl/biznes/energetyka/artykuly/8613573,rafineria-gdanska-pod-ochrona-lista-map.html](https://forsal.pl/biznes/energetyka/artykuly/8613573,rafineria-gdanska-pod-ochrona-lista-map.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 13:31:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eUrktkuTURBXy84YmYwOTkyMy0yNDYzLTQ0MGItOTVmMS1lMzgwYzNlZWM1M2UuanBlZ5GTBc0BHcyg" />Ministerstwo Aktywów Państwowych wystąpiło z wnioskiem o wpisanie Rafinerii Gdańskiej do wykazu podmiotów podlegających szczególnej ochronie; wniosek został przyjęty przez rząd - poinformowało PAP biuro prasowe MAP. Z dniem 1 stycznia 2023 r. Rafineria Gdańska zostanie ujęta w tym wykazie - dodano.

## Opłaty urzędowe przez aplikację mObywatel. Jest projekt ustawy
 - [https://forsal.pl/lifestyle/technologie/artykuly/8613541,mobywatel-oplaty-urzedowe-projekt-ustawy.html](https://forsal.pl/lifestyle/technologie/artykuly/8613541,mobywatel-oplaty-urzedowe-projekt-ustawy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 13:18:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/nMbktkuTURBXy9hYzRiMjdlYy1mMzczLTQyYTgtODNhYS1hMGNhNTI2ZWJiZDIuanBlZ5GTBc0BHcyg" />Projekt ustawy o aplikacji mObywatel wyszedł z Komitetu Cyfryzacji Rady Ministrów; niedługo stanie się przedmiotem prac rządu, a później też parlamentu - poinformował w poniedziałek rzecznik rządu Piotr Müller.

## Polska pozostanie atrakcyjnym rynkiem logistycznym [RAPORT]
 - [https://forsal.pl/transport/aktualnosci/artykuly/8613523,logistyka-polska-pozostanie-atrakcyjnym-rynkiem.html](https://forsal.pl/transport/aktualnosci/artykuly/8613523,logistyka-polska-pozostanie-atrakcyjnym-rynkiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 13:06:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/is1ktkuTURBXy9hMmQzODMxNy05MTQ2LTQ4ZGEtYmU5ZS01OWFmYzY3YzcwM2EuanBlZ5GTBc0BHcyg" />Wzrost stawek najmu nie osłabił aktywności najemców. Pomimo ich prognozowanego wzrostu, Polska pozostanie atrakcyjnym rynkiem logistycznym dla inwestorów w porównaniu do Europy Zachodniej – wynika z raportu firmy Colliers.

## Premier Sunak: Przed rozmowami Rosja musi się wycofać z okupowanych terenów
 - [https://forsal.pl/swiat/rosja/artykuly/8613519,premier-sunak-przed-rozmowami-rosja-musi-sie-wycofac-z-okupowanych-terenow.html](https://forsal.pl/swiat/rosja/artykuly/8613519,premier-sunak-przed-rozmowami-rosja-musi-sie-wycofac-z-okupowanych-terenow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 13:03:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PHrktkuTURBXy9iOTk3MjU3NC1mY2E1LTQ2MWQtYTk2YS1mZWFiZjhiNzE3MGYuanBlZ5GTBc0BHcyg" />Brytyjski premier Rishi Sunak wezwał w poniedziałek kraje tworzące Wspólne Siły Ekspedycyjne (JEF) do zwiększenia pomocy wojskowej dla Ukrainy i odrzucenia wezwań Rosji do zawieszenia broni, dopóki nie wycofa się ona z okupowanych terenów.

## Na zmiany stóp procentowych jeszcze poczekamy. Prognoza BNP Paribas
 - [https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8613506,na-zmiany-stop-procentowych-jeszcze-poczekamy-prognoza-bnp-paribas.html](https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8613506,na-zmiany-stop-procentowych-jeszcze-poczekamy-prognoza-bnp-paribas.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 12:38:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NUlktkuTURBXy8yODU2NzRmOS0zODlhLTQ0ODEtYjMwMy1iYzhmYjhhM2VlZDQuanBlZ5GTBc0BHcyg" />Choć formalnie Rada Polityki Pieniężnej (RPP) nie zakończyła jeszcze cyklu zacieśniania polityki pieniężnej i pozostaje w trybie czuwania (wait-and-see), to w ocenie ekonomistów Banku BNP Paribas komunikacja towarzysząca grudniowej decyzji sugeruje, że RPP może nie powrócić już do podwyższania stóp procentowych.

## Tyle wynosi średnie roczne wynagrodzenie w krajach UE. Polska czwarta od końca [EUROSTAT]
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8613464,srednie-roczne-wynagrodzenie-w-krajach-ue-polska-czwarta-od-konca.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8613464,srednie-roczne-wynagrodzenie-w-krajach-ue-polska-czwarta-od-konca.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 12:29:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ASTktkuTURBXy8wOThmNGU5MC1iOTA4LTQ0MzQtOTM0Ni1lZjVmNjQzOTNkNmUuanBlZ5GTBc0BHcyg" />W 2021 r. średnie roczne skorygowane wynagrodzenie pracowników zatrudnionych w pełnym wymiarze czasu pracy w Unii Europejskiej wynosiło 33 500 euro – wynika z nowego wskaźnika Eurostatu, który jest publikowany po raz pierwszy.

## Photon Energy chce skupić do 250 tys. akcji własnych za max. 3,75 mln zł
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8613490,photon-energy-chce-skupic-do-250-tys-akcji-wlasnych-za-max-375-mln-zl.html](https://forsal.pl/biznes/aktualnosci/artykuly/8613490,photon-energy-chce-skupic-do-250-tys-akcji-wlasnych-za-max-375-mln-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 12:27:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fOzktkuTURBXy85MjNlMTUxMy03YjVmLTRmMDEtYWQxYS1lN2IzZDQ5Nzc2OWQuanBlZ5GTBc0BHcyg" />Photon Energy przyjął program skupu akcji własnych, w ramach którego zamierza skupić maksymalnie 250 tys. akcji, co stanowi ok. 0,42% kapitału zakładowego, podała spółka. Wysokość środków przeznaczonych na realizację programu nie przekroczy kwoty 3,75 mln zł.

## KNF zatwierdziła prospekt Movie Games w związku z planem przejścia na rynek główny GPW
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8613487,knf-zatwierdzila-prospekt-movie-games-w-zwiazku-z-planem-przejscia-na-rynek-glowny-gpw.html](https://forsal.pl/biznes/aktualnosci/artykuly/8613487,knf-zatwierdzila-prospekt-movie-games-w-zwiazku-z-planem-przejscia-na-rynek-glowny-gpw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 12:25:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yfaktkuTURBXy9jN2E5ZTliNS05MWE0LTRlNzgtYjVjZS04ZTdkNDdkMDRjMzQuanBlZ5GTBc0BHcyg" />Komisja Nadzoru Finansowego (KNF) zatwierdziła prospekt Movie Games sporządzony w związku z ubieganiem się o dopuszczenie i wprowadzenie do obrotu na rynku regulowanym Giełdy Papierów Wartościowych w Warszawie (GPW) wszystkich 2 573 132 akcji spółki o wartości nominalnej 1 zł każda, będących dotychczas przedmiotem obrotu w alternatywnym systemie obrotu na NewConnect, podała spółka.

## Powrót podstawowej stawki VAT podbije ceny paliw? Prezes Orlenu zabrał głos
 - [https://forsal.pl/transport/aktualnosci/artykuly/8613485,ceny-paliw-vat-prezes-orlenu-zabral-glos.html](https://forsal.pl/transport/aktualnosci/artykuly/8613485,ceny-paliw-vat-prezes-orlenu-zabral-glos.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 12:20:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lD8ktkuTURBXy9mNzMyNjRmYS0xNDM0LTQwM2MtOTIzMS01Y2ExMmRiNzdlYWEuanBlZ5GTBc0BHcyg" />Powrót podstawowej stawki VAT na paliwa nie powinien mieć większego wpływu na ceny na naszych stacjach - oświadczył w poniedziałek prezes PKN Orlen Daniel Obajtek w radiu RMF FM. Jak dodał, stanie się tak dzięki m.in. połączeniu Orlenu z Lotosem.

## Holendrzy i Belgowie to najbogatsi mieszkańcy Unii Europejskiej
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8613469,holendrzy-i-belgowie-to-najbogatsi-mieszkancy-unii-europejskiej.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8613469,holendrzy-i-belgowie-to-najbogatsi-mieszkancy-unii-europejskiej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 12:05:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SkVktkuTURBXy80NGQxZWZjYS00MzA4LTQ1MWItYmQ1Ny04YzM5NmVjOTFmZmQuanBlZ5GTBc0BHcyg" />Holendrzy i Belgowie to najbogatsi mieszkańcy Unii Europejskiej - wynika z danych firmy ubezpieczeniowej Allianz Trade. Średni majątek Holendra, bez wartości nieruchomości, wynosi ponad 176 tys., natomiast Belga 121 tys. euro.

## Hotele spodziewają się najazdu turystów w okresie świąteczno-noworocznym
 - [https://forsal.pl/swiat/artykuly/8613446,ceny-hotele-spodziewaja-sie-najazdu-turystow.html](https://forsal.pl/swiat/artykuly/8613446,ceny-hotele-spodziewaja-sie-najazdu-turystow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 11:49:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OTSktkuTURBXy9lODU0ZmQ4Yy05ODEwLTQ1OTItODgxNi03N2RhOTFmMTM4YjguanBlZ5GTBc0BHcyg" />Według hotelarzy spod Tatr w okresie świąteczno-noworocznym pod Giewont przyjadą prawdziwe tłumy turystów. Rezerwacje w hotelach są wypełnione, ale nadal można znaleźć pokój na Sylwestra u przysłowiowej gaździny – powiedział PAP Karol Wagner z Tatrzańskiej Izby Gospodarczej zrzeszającej branżę turystyczną z Podhala.

## Właścicielowi Facebooka grozi kara. KE podejrzewa, że Meta naruszyła unijne przepisy
 - [https://forsal.pl/biznes/media/artykuly/8613444,wlascicielowi-facebooka-grozi-kara-ke-podejrzewa-ze-meta-naruszyla-unijne-przepisy.html](https://forsal.pl/biznes/media/artykuly/8613444,wlascicielowi-facebooka-grozi-kara-ke-podejrzewa-ze-meta-naruszyla-unijne-przepisy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 11:44:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QkJktkuTURBXy9jM2UwMDdmNi04ZWFmLTRlZDgtYmY1ZS1mNjU1ZTUxN2NjZjYuanBlZ5GTBc0BHcyg" />Komisja Europejska poinformowała firmę Meta, która jest właścicielem Facebooka, że według wstępnej oceny naruszyła ona unijne przepisy antymonopolowe, zakłócając konkurencję na rynkach ogłoszeń drobnych online. Jeśli zarzuty potwierdzą się w toku dochodzenia, to KE może nałożyć na firmę kary finansowe.

## Manowska o kompromisie z KE ws. sądownictwa: Suwerenności nie można sprzedać za miskę ryżu
 - [https://forsal.pl/gospodarka/prawo/artykuly/8613376,manowska-o-kompromisie-z-ke-ws-sadownictwa-suwerennosci-nie-mozna-sprzedac-za-miske-ryzu.html](https://forsal.pl/gospodarka/prawo/artykuly/8613376,manowska-o-kompromisie-z-ke-ws-sadownictwa-suwerennosci-nie-mozna-sprzedac-za-miske-ryzu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 10:50:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/g33ktkuTURBXy9jNmJkMjljYS02NmY1LTQyNGMtODk5MC02YzlhY2JlNDY3NzAuanBlZ5GTBc0BHcyg" />Nie wszystko można sprzedać za przysłowiową miskę ryżu. Nie chodzi tutaj tylko o sędziów, lecz chodzi o zasady i przepisy naszego prawa krajowego – mówi w rozmowie z Onet.pl Pierwsza Prezes Sądu Najwyższego Małgorzata Manowska, odnosząc się do propozycji kompromisu z KE ws. sądownictwa.

## Minister finansów: Jest szansa na nadwyżkę w tegorocznym budżecie
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8613370,minister-finansow-jest-szansa-na-nadwyzke-w-tegorocznym-budzecie.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8613370,minister-finansow-jest-szansa-na-nadwyzke-w-tegorocznym-budzecie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 10:47:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/S5uktkuTURBXy83NDkwYzJiYi05NDcwLTQyZTItYjUzYy0yNTliY2I5ZDY4YmIuanBlZ5GTBc0BHcyg" />Jest szansa na nadwyżkę w tegorocznym budżecie, choć z ostateczną oceną wstrzymajmy się jeszcze trochę, aż będziemy wiedzieć, jak wygląda wykonanie budżetu za 2022 r. – powiedziała w poniedziałek w Studiu PAP minister finansów Magdalena Rzeczkowska.

## Media: Dowódca WOT ustąpi ze stanowiska
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8613364,wot-gen-wieslaw-kukula-ustapi-zastapi-go-maciej-klisz.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8613364,wot-gen-wieslaw-kukula-ustapi-zastapi-go-maciej-klisz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 10:38:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1f1ktkuTURBXy9iNDc1YTEwOS00ZWVkLTRhMTUtODJmMS02MWYzMWM1MDFmMGUuanBlZ5GTBc0BHcyg" />Ze stanowiska dowódcy Wojsk Obrony Terytorialnej (WOT) za dwa dni ustąpi gen. Wiesław Kukuła. Zastąpić go ma gen. Maciej Klisz, dotychczasowy zastępca gen. Kukuły - informuje portal Onet.pl. Wedle doniesień portalu, gen. Kukuła ma zostać Dowódcą Generalnym Rodzajów Sił Zbrojnych.

## Emerytury i renty w grudniu jeszcze przed świętami
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8613359,emerytury-i-renty-w-grudniu-jeszcze-przed-swietami.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8613359,emerytury-i-renty-w-grudniu-jeszcze-przed-swietami.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 10:31:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/nHRktkuTURBXy9kNGMzMmE4Ni1hMjQ1LTRmMzYtOGRmMS00ZmFlNzZmZGU0MjkuanBlZ5GTBc0BHcyg" />Emeryci i renciści, którym ZUS wypłaca świadczenia 25. każdego miesiąca, w grudniu otrzymają je przed świętami. Dotyczy to zarówno wypłat przekazywanych przez listonosza, jak i przelewów, które trafiają na rachunki bankowe – poinformowała PAP prezes ZUS prof. Gertruda Uścińska.

## Koszty zatrudnienia w górę o ponad 13 proc. Eurostat podał nowe dane dla Polski
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8613356,polska-koszty-zatrudnienia-w-gore-o-ponad-13-proc-eurostat.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8613356,polska-koszty-zatrudnienia-w-gore-o-ponad-13-proc-eurostat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 10:26:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BoSktkuTURBXy81ODJiNzRkNC1hOGViLTRjMGYtYWE0Mi00MmU3OTM2ZjhiNmEuanBlZ5GTBc0BHcyg" />Całkowite koszty zatrudnienia w Polsce wzrosły o 13,3 proc. r/r w III kw. 2022 r. (wobec wzrostu o 11,1 proc. kwartał wcześniej), podał unijny urząd statystyczny Eurostat.

## Zaległe zadłużenie konsumentów sięga już 77,4 mld zł
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8613349,zalegle-zadluzenie-konsumentow-siega-juz-774-mld-zl.html](https://forsal.pl/finanse/aktualnosci/artykuly/8613349,zalegle-zadluzenie-konsumentow-siega-juz-774-mld-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 10:06:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oi7ktkuTURBXy83YzMwMzRjNi04OGZmLTQ1MDUtOGE2Yy1iZTg4MDU3N2MxZjYuanBlZ5GTBc0BHcyg" />Łączna wartość zaległego zadłużenia konsumentów na koniec października br. wyniosła niemal 77,4 mld zł - wskazują dane zgromadzone w Rejestrze Dłużników BIG InfoMonitor i bazie informacji kredytowych BIK.

## Kiedy obniżki stóp procentowych? Członek RPP zabrał głos
 - [https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8613327,kiedy-obnizki-stop-procentowych-czlonek-rpp-zabral-glos.html](https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8613327,kiedy-obnizki-stop-procentowych-czlonek-rpp-zabral-glos.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 09:51:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PrRktkuTURBXy85OGRiZWRlZi0zZjE3LTQ0OTgtOWNkOC04ZTcxN2I3ZmJkM2IuanBlZ5GTBc0BHcyg" />W przyszłym roku mogą pojawić się przesłanki do podjęcia dyskusji na temat obniżek stóp procentowych, natomiast jeszcze nie przesłanki do samego luzowania polityki monetarnej, uważa członek Rady Polityki Pieniężnej (RPP) Henryk Wnorowski.

## Daniłow: Kiedy zabraknie Putina, Czeczenia odłączy się od Rosji
 - [https://forsal.pl/swiat/rosja/artykuly/8613318,danilow-kiedy-zabraknie-putina-czeczenia-odlaczy-sie-od-rosji.html](https://forsal.pl/swiat/rosja/artykuly/8613318,danilow-kiedy-zabraknie-putina-czeczenia-odlaczy-sie-od-rosji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 09:33:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-fQktkuTURBXy83OWM5NmJkZC04YmFlLTRiZmItYTM2My1lZWQyOTVmMzQ4ZmEuanBlZ5GTBc0BHcyg" />Gdy tylko zabraknie Władimira Putina, Czeczenia bardzo szybko odłączy się od Rosji i zostanie niezależnym państwem; nastąpi to w mgnieniu oka, ponieważ ten obszar nie ma z Rosją nic wspólnego - ocenił w poniedziałek sekretarz Rady Bezpieczeństwa Narodowego i Obrony (RBNiO) Ukrainy Ołeksij Daniłow.

## Gdzie trafią wyrzutnie systemu Patriot? Szef MON wskazał miejsce
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8613314,gdzie-trafia-wyrzutnie-systemu-patriot-szef-mon-wskazal-miejsce.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8613314,gdzie-trafia-wyrzutnie-systemu-patriot-szef-mon-wskazal-miejsce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 09:24:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5o0ktkuTURBXy80M2Q2MDdjOS1jZTg3LTQwZmUtYTkxNy1iNDlmNTg0M2FiYTAuanBlZ5GTBc0BHcyg" />Kolejne wyrzutnie systemu Patriot zostaną rozmieszczone na Lubelszczyźnie, żeby nie doszło do powtórzenia się tragicznego wypadku z Przewodowa - powiedział w poniedziałek wicepremier, szef MON Mariusz Błaszczak.

## Brytyjski MON: Grupa Wagnera wysyła do walki skazańców bez szkolenia i wsparcia
 - [https://forsal.pl/swiat/rosja/artykuly/8613307,brytyjski-mon-grupa-wagnera-wysyla-do-walki-skazancow-bez-szkolenia-i-wsparcia.html](https://forsal.pl/swiat/rosja/artykuly/8613307,brytyjski-mon-grupa-wagnera-wysyla-do-walki-skazancow-bez-szkolenia-i-wsparcia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 08:59:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GQgktkuTURBXy85YTY1NGI2Ni1jMmViLTQxM2ItOTQxMS0zYmU2ZmQzMzZhZTEuanBlZ5GTBc0BHcyg" />Odgrywająca istotną rolę w walkach na Ukrainie rosyjska prywatna firma wojskowa grupa Wagnera wysyła do walki słabo wyszkolonych i pozbawionych wsparcia zwerbowanych więźniów, by chronić własnych dowódców i sprzęt - przekazało w poniedziałek brytyjskie ministerstwo obrony.

## Kiedy czeka nas szczyt inflacji? Nowe prognozy
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8613273,kiedy-czeka-nas-szczyt-inflacji-nowe-prognozy.html](https://forsal.pl/gospodarka/inflacja/artykuly/8613273,kiedy-czeka-nas-szczyt-inflacji-nowe-prognozy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 08:40:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Wi0ktkuTURBXy8xOWY1ODhiZS00NDM5LTRhMTEtODkzMi1kNWRmYmY3YTcxZTkuanBlZ5GTBc0BHcyg" />Uwzględniając zatwierdzone w sobotę taryfy i stawki dystrybucyjne dla gazu i energii elektrycznej, można oczekiwać, że inflacja osiągnie swój szczyt w lutym na poziomie 20-21% r/r, szacują ekonomiści mBanku.

## Druga edycja programu "Trenuj z wojskiem". Liczba miejsc została zwiększona o 100 proc.
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8613262,trenuj-z-wojskiem-szef-mon-chcemy-przeszkolic-jak-najwiecej-osob.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8613262,trenuj-z-wojskiem-szef-mon-chcemy-przeszkolic-jak-najwiecej-osob.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 08:35:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5aKktkuTURBXy84Zjk3YjZkOC0wOGQxLTQyNGItODE3Mi1lMGJiMTY1NWNjODcuanBlZ5GTBc0BHcyg" />Chcemy przeszkolić jak najwięcej osób w zakresie podstawowych umiejętności - mówił wicepremier, szef MON Mariusz Błaszczak podczas inauguracji drugiej edycji projektu &quot;Trenuj z wojskiem w ferie&quot;.

## Inflacja pożera wynagrodzenia. Większość firm planuje podwyżki [BADANIE]
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8613249,inflacja-pozera-wynagrodzenia-wiekszosc-firm-planuje-podwyzki-badanie.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8613249,inflacja-pozera-wynagrodzenia-wiekszosc-firm-planuje-podwyzki-badanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 08:34:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KJxktkuTURBXy9kZGRlN2M2Zi03ZjdlLTQ5OTEtYThhOS04NzQwOGRiMzlkMTAuanBlZ5GTBc0BHcyg" />Podwyżki płac planuje 53% przedsiębiorców w 2023 r., jednak ich skala będzie różna. 36% firm planuje częściowo wyrównać inflację, a 17% podniesie pensje o wzrost pensji minimalnej, wynika z &quot;Barometru Polskiego Rynku Pracy&quot; Personnel Service. Co trzeci pracodawca deklaruje podwyżki na poziomie 6-10%, natomiast 22% firm zdecyduje się podnieść płace o 11-15%.

## 2-proc. kredyt na mieszkanie. Buda: Może z niego skorzystać ok. 100 tys. osób
 - [https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8613240,2-proc-kredyt-na-mieszkanie-buda-100-tys-osob.html](https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8613240,2-proc-kredyt-na-mieszkanie-buda-100-tys-osob.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 08:11:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WTYktkuTURBXy8zZjUzM2NmNS0wMWMzLTRiOTAtODM1YS0xNjhhNzU0MjFjYWIuanBlZ5GTBc0BHcyg" />Z preferencyjnego kredytu oprocentowanego na poziomie 2% na zakup mieszkania może skorzystać około 100 tys. osób w najbliższych latach, ocenia minister rozwoju i technologii Waldemar Buda.

## Program "Pierwsze Mieszkanie". Buda: Może z niego skorzystać ok. 100 tys. osób
 - [https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8613240,program-pierwsze-mieszkanie-buda-100-tys-osob.html](https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8613240,program-pierwsze-mieszkanie-buda-100-tys-osob.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 08:11:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WTYktkuTURBXy8zZjUzM2NmNS0wMWMzLTRiOTAtODM1YS0xNjhhNzU0MjFjYWIuanBlZ5GTBc0BHcyg" />Z preferencyjnego kredytu oprocentowanego na poziomie 2% na zakup mieszkania może skorzystać około 100 tys. osób w najbliższych latach, ocenia minister rozwoju i technologii Waldemar Buda.

## Za cyberkanty siedzą nieliczni. Czy można to zmienić?
 - [https://forsal.pl/gospodarka/prawo/artykuly/8613228,za-cyberkanty-siedza-nieliczni-czy-mozna-to-zmienic.html](https://forsal.pl/gospodarka/prawo/artykuly/8613228,za-cyberkanty-siedza-nieliczni-czy-mozna-to-zmienic.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:53:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jIwktkuTURBXy9iNWM2NjkwNC1hOGVmLTRhNWYtYWY2OC1mNDE0N2NhMzhkY2QuanBlZ5GTBc0BHcyg" />Walka z cyberprzestępczością przypomina grę w kotka i myszkę, dlatego Polska stawia na działania prewencyjne

## Elon Musk pyta użytkowników Twittera, czy ma dalej kierować platformą
 - [https://forsal.pl/biznes/media/artykuly/8613226,elon-musk-pyta-uzytkownikow-twittera-czy-ma-dalej-kierowac-platforma.html](https://forsal.pl/biznes/media/artykuly/8613226,elon-musk-pyta-uzytkownikow-twittera-czy-ma-dalej-kierowac-platforma.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:52:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fr8ktkuTURBXy9jNDQ5NjdjMi00YjMyLTQ5MDItOTY2Zi1lMjg1MmU3MjlmMWYuanBlZ5GTBc0BHcyg" />Amerykański miliarder i właściciel sieci społecznościowej Twitter Elon Musk ogłosił w nocy z niedzieli na poniedziałek ankietę, w której użytkownicy Twittera mogą wypowiedzieć się, czy chcą by dalej kierował platformą czy ustąpił ze stanowiska. Zastosuję się do wyników głosowania - zadeklarował Musk.

## Drób taniej. Czy ratunkiem dla hodowców będzie eksport?
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8613222,drob-taniej-czy-ratunkiem-dla-hodowcow-bedzie-eksport.html](https://forsal.pl/biznes/rolnictwo/artykuly/8613222,drob-taniej-czy-ratunkiem-dla-hodowcow-bedzie-eksport.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:49:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/glgktkuTURBXy9jOGZlNDkyYi03ZGI5LTQ0ZTQtYWRiYS1lMjQ2YjI2Mzc2YzIuanBlZ5GTBc0BHcyg" />Dobre wieści dla konsumentów, gorsze dla producentów. W zeszłym roku biznes psuła ptasia grypa, w tym import mięsa ze Wschodu

## Jak nie marnować żywności? Oto 9 kluczowych zasad
 - [https://forsal.pl/biznes/handel/artykuly/8613218,jak-nie-marnowac-zywnosci-oto-9-kluczowych-zasad.html](https://forsal.pl/biznes/handel/artykuly/8613218,jak-nie-marnowac-zywnosci-oto-9-kluczowych-zasad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:49:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4i3ktkuTURBXy9hMDE1MzhmNi00MjFkLTQ3YWEtODgyNS1mZDMwOTUyMDBiNDcuanBlZ5GTBc0BHcyg" />Policz gości, przygotuj jadłospis, zrób listę zakupów, kupuj z głową, właściwie przechowuj produkty, a na stole wigilijnym potrawy serwuj w małych porcjach - radzą autorzy przygotowanego przed świętami Bożego Narodzenia poradnika &quot;Jak nie marnować żywności&quot;.

## Rosyjskie drony zaatakowały Kijów. 15 z nich zestrzelono
 - [https://forsal.pl/swiat/ukraina/artykuly/8613212,rosyjskie-drony-zaatakowaly-kijow-15-z-nich-zestrzelono.html](https://forsal.pl/swiat/ukraina/artykuly/8613212,rosyjskie-drony-zaatakowaly-kijow-15-z-nich-zestrzelono.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:40:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZcZktkuTURBXy82MzEwMWNkZC1jZGE1LTRlZmUtYjg0MS00ZDJiNzMxM2JkYzAuanBlZ5GTBc0BHcyg" />Stolica Ukrainy Kijów i okolice zostały w poniedziałek nad ranem ponownie zaatakowane przez wyprodukowane w Iranie rosyjskie drony Shahed - poinformowała na Telegramie administracja wojskowa obwodu kijowskiego. W mieście ogłoszono alarm przeciwlotniczy.

## Ambasador USA w Polsce: Będziemy bronić każdego centymetra terytorium NATO
 - [https://forsal.pl/swiat/usa/artykuly/8613209,ambasador-usa-w-polsce-bedziemy-bronic-kazdego-centymetra-terytorium-nato.html](https://forsal.pl/swiat/usa/artykuly/8613209,ambasador-usa-w-polsce-bedziemy-bronic-kazdego-centymetra-terytorium-nato.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:38:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2C_ktkuTURBXy8zMGQwMTUwNi0wMWJlLTRiNTMtYmVmZi0yYjM3NGVjN2NmOGMuanBlZ5GTBc0BHcyg" />Kiedy powtarzam, że Polska jest bezpieczna, nie mówię tylko za siebie. Mówię też w imieniu prezydenta Bidena, że będziemy bronić każdego centymetra terytorium NATO - zapewnił w wywiadzie dla &quot;Do Rzeczy&quot; ambasador Stanów Zjednoczonych w Polsce Mark Brzezinski.

## ZUS: Rośnie liczba zawieranych umów o dzieło
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8613205,zus-rosnie-liczba-zawieranych-umow-o-dzielo.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8613205,zus-rosnie-liczba-zawieranych-umow-o-dzielo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:37:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/COBktkuTURBXy9hNTBiNmM0OS0wMDE0LTRjNTUtOGQxZC1iOTRhMGM5MjRhNmYuanBlZ5GTBc0BHcyg" />W pierwszych trzech kwartałach 2022 r. zgłoszono około 1,3 mln umów o dzieło, czyli o ok. 6,5 proc. więcej niż w analogicznym okresie poprzedniego roku - wynika z raportu ZUS. Największa grupa wykonawców umów o dzieło to mężczyźni w wieku 30–39 lat.

## Amerykańskie lotniska mają problem z bronią. W 2022 r. odebrano pasażerom ponad 6300 sztuk
 - [https://forsal.pl/swiat/usa/artykuly/8613197,amerykanskie-lotniska-bron-odebrano-pasazerom-ponad-6300-sztuk.html](https://forsal.pl/swiat/usa/artykuly/8613197,amerykanskie-lotniska-bron-odebrano-pasazerom-ponad-6300-sztuk.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:32:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tS1ktkuTURBXy83MmQ5OWQ0Yy02ZDc4LTRjNDItYjA4Yi0yYTQ4NzdiM2I2YWYuanBlZ5GTBc0BHcyg" />W tym roku funkcjonariusze Administracji ds. Bezpieczeństwa Transportu (TSA) przechwycili na amerykańskich lotniskach rekordową liczbę broni. Do połowy grudnia w ich ręce wpadło 6301 sztuk.

## Rosyjski system pęka. Była oficer CIA: Wojna na Ukrainie to szansa dla zachodnich wywiadów
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8613206,wywiad-byla-oficer-cia-wojna-na-ukrainie-to-szansa.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8613206,wywiad-byla-oficer-cia-wojna-na-ukrainie-to-szansa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:29:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CMUktkuTURBXy9lMDUwYmU4NS04Y2QzLTQ0YjAtOTExNS02ZTJmYmE3ZWFkNDYuanBlZ5GTBc0BHcyg" />Rosyjska inwazja na Ukrainę stworzyła dobre warunki dla pozyskiwania źródeł wśród kremlowskich elit - mówi PAP Alex Finley, była oficer CIA w Rosji i autorka powieści szpiegowskich. Jak zauważa, dodatkowe warunki, to sankcje przeciwko oligarchom, które tworzą &quot;pęknięcia w fundamentach systemu&quot;.

## Ceny ropy w USA w górę. Powód? Sytuacja w Chinach
 - [https://forsal.pl/finanse/notowania/artykuly/8613195,ceny-ropy-w-usa-w-gore-powod-sytuacja-w-chinach.html](https://forsal.pl/finanse/notowania/artykuly/8613195,ceny-ropy-w-usa-w-gore-powod-sytuacja-w-chinach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:28:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pfKktkuTURBXy82ZjY1OTZiNy1lNWEyLTRlYTEtOTI2MS02NzQ3MTMzODcxYTIuanBlZ5GTBc0BHcyg" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną na początku tygodnia po zapowiedziach chińskich władz dotyczących ożywienia popytu w gospodarce i planach amerykańskiej administracji dotyczących rozpoczęcia odbudowy strategicznych rezerw ropy w USA - informują maklerzy.

## Rosyjscy żołnierze na Białorusi przygotowują się do manewrów
 - [https://forsal.pl/swiat/rosja/artykuly/8613192,rosyjscy-zolnierze-na-bialorusi-przygotowuja-sie-do-manewrow.html](https://forsal.pl/swiat/rosja/artykuly/8613192,rosyjscy-zolnierze-na-bialorusi-przygotowuja-sie-do-manewrow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:27:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/a2SktkuTURBXy83ZTMyNjBiMC1mNGNkLTQ5MTUtOGNhMi02YTcyNzg4ZWI5YTcuanBlZ5GTBc0BHcyg" />Rosyjscy żołnierze porzerzuceni w październiku na Białoruś rozpoczną ćwiczenia taktyczne na poziomie batalionów - poinformowała w poniedziałek rosyjska agencja Interfax powołując się na ministerstwo obrony Rosji.

## Korea Północna kończy prace nad satelitą szpiegowskim
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8613188,korea-polnocna-konczy-prace-nad-satelita-szpiegowskim.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8613188,korea-polnocna-konczy-prace-nad-satelita-szpiegowskim.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:24:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7y_ktkuTURBXy9lMjc5ZGE1MC1hMjY1LTQ0ZGMtOTgzZS1lNWM3YTZhOTlmZGIuanBlZ5GTBc0BHcyg" />Korea Północna przeprowadziła w niedzielę &quot;ważny test końcowej fazy&quot; prac nad satelitą szpiegowskim, które powinny być ukończone do kwietnia 2023 r. - poinformowała oficjalna północnokoreańska agencja prasowe KCNA.

## Nowa ofensywa Rosji? ISW: Wątpliwe, nawet przy wsparciu Białorusi
 - [https://forsal.pl/swiat/rosja/artykuly/8613190,nowa-ofensywa-rosji-isw-watpliwe-nawet-przy-wsparciu-bialorusi.html](https://forsal.pl/swiat/rosja/artykuly/8613190,nowa-ofensywa-rosji-isw-watpliwe-nawet-przy-wsparciu-bialorusi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:20:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8YIktkuTURBXy9hYjJkYTY3Ni00NjQ4LTQ1MTMtYTA2Ny1jZjM0NTJlM2ZkNWUuanBlZ5GTBc0BHcyg" />Zdolność rosyjskiej armii, nawet wzmocnionej przez elementy sił białoruskich, do przygotowania i przeprowadzenia w najbliższych miesiącach na Ukrainie skutecznej ofensywy z użyciem sił zmechanizowanych jest wątpliwa – ocenia amerykański Instytut Badań nad Wojną (ISW).

## Problemy z VAT-em wracają jak bumerang
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8613184,problemy-z-vat-em-wracaja-jak-bumerang.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8613184,problemy-z-vat-em-wracaja-jak-bumerang.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:18:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8yaktkuTURBXy84ODZiN2Y4Mi04ZGM2LTQ1ZWYtYmFkYS0zOWY0ZTFjZjNmYzkuanBlZ5GTBc0BHcyg" />Skarbówka nadal nie zgadza się na obniżenie stawki VAT, gdy za towar lub usługę zapłacił już bezimienny konsument. Twierdzi, że dla przedsiębiorcy oznaczałoby to bezpodstawne wzbogacenie. Co innego orzekł niedawno unijny trybunał

## Nowa matura kontra stare przyzwyczajenia
 - [https://forsal.pl/lifestyle/edukacja/artykuly/8613183,nowa-matura-kontra-stare-przyzwyczajenia.html](https://forsal.pl/lifestyle/edukacja/artykuly/8613183,nowa-matura-kontra-stare-przyzwyczajenia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:16:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LaHktkuTURBXy9lNTQyMjA5NC0yNjM4LTRlYmQtOTcyNi00ZGVlY2Y1ODQ1NDAuanBlZ5GTBc0BHcyg" />Nowa matura z polskiego promuje samodzielne myślenie i podejście analityczne. Matematyka wciąż jeszcze niezbyt ambitna

## Wyboista droga do KPO. Część koalicji rządowej jest skłonna iść na układ z KE
 - [https://forsal.pl/gospodarka/polityka/artykuly/8613181,wyboista-droga-do-kpo-czesc-koalicji-rzadowej-jest-sklonna-isc-na-uklad-z-ke.html](https://forsal.pl/gospodarka/polityka/artykuly/8613181,wyboista-droga-do-kpo-czesc-koalicji-rzadowej-jest-sklonna-isc-na-uklad-z-ke.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:16:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QRhktkuTURBXy8yZDM5NjM2MS1mMWZmLTRlOWMtODJkYy0wNjcxMzAwOTQ1NDUuanBlZ5GTBc0BHcyg" />Dwie trzecie Polaków popiera przyjęcie przez Sejm nowelizacji ustawy o SN, która ma otworzyć drogę do wypłaty środków w ramach planu odbudowy – wynika z najnowszego sondażu United Surveys dla DGP i RMF FM

## Niemiecki granatnik w KGP, a przyjaźń polsko-ukraińska
 - [https://forsal.pl/gospodarka/polityka/artykuly/8613178,niemiecki-granatnik-w-kgp-a-przyjazn-polsko-ukrainska.html](https://forsal.pl/gospodarka/polityka/artykuly/8613178,niemiecki-granatnik-w-kgp-a-przyjazn-polsko-ukrainska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:05:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3rsktkuTURBXy8xMzJmYzk0Ny0xODQ5LTQwZmUtOTRkZi1jY2RjYzMyOWVkN2QuanBlZ5GTBc0BHcyg" />Doniesienia na temat zamachu na komendanta polskiej policji są porażające. Najpierw jedna z gazet poinformowała o tropie rosyjskim, wiążąc go ze Smoleńskiem 2010 i inwazją na Ukrainę rozpoczętą 24 lutego. Układanka znacznie się jednak komplikuje, gdy weźmiemy pod uwagę informacje o producencie broni. Są nim Niemcy. Granatnik dla niepoznaki nazywa się RGW-90.

## Windykator to nie komornik, czyli gdzie kończy się windykacja, a już zaczyna zastraszanie
 - [https://forsal.pl/gospodarka/prawo/artykuly/8613172,windykator-to-nie-komornik-windykacja-a-zastraszanie.html](https://forsal.pl/gospodarka/prawo/artykuly/8613172,windykator-to-nie-komornik-windykacja-a-zastraszanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 07:00:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/__sktkuTURBXy9lMTM3YzI2Yy00NmQwLTQ2YjEtYWQwZC0xZGU2N2ZkYTgxMWQuanBlZ5GTBc0BHcyg" />Dochodzenie należności od dłużników nie może przekraczać granic prawa. Rzecz w tym, że są one nieostre. Każdy przypadek należy zatem badać indywidualnie

## Ceny prądu w 2023: Idą zmiany na giełdzie i w rachunkach gospodarstw domowych
 - [https://forsal.pl/biznes/energetyka/artykuly/8613170,ceny-pradu-2023-zmiany-na-gieldzie-i-w-rachunkach-gospodarstw-domowych.html](https://forsal.pl/biznes/energetyka/artykuly/8613170,ceny-pradu-2023-zmiany-na-gieldzie-i-w-rachunkach-gospodarstw-domowych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 06:53:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qYiktkuTURBXy9mYjg5MmZiOC1hZjRkLTRjNDMtYWUyOS1hN2ZkYWQ5NTQ3MWQuanBlZ5GTBc0BHcyg" />Wzrost cen prądu z dostawą w przyszłym roku o 55 proc. i ich spadek o 30 proc. w notowaniach na TGE w ciągu mniej więcej miesiąca. Prezes URE zatwierdził w sobotę ceny na 2023 r. dla odbiorców wrażliwych – zarówno taryfy za dystrybucję, jak i za samą energię wzrosną od stycznia średnio o ok. 45 proc.

## Problemy Bundeswehry: 18 transporterów Puma zepsuło się w czasie manewrów
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8613167,problemy-bundeswehry-18-transporterow-puma-zepsulo-sie-manewry.html](https://forsal.pl/swiat/unia-europejska/artykuly/8613167,problemy-bundeswehry-18-transporterow-puma-zepsulo-sie-manewry.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 06:52:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lOpktkuTURBXy81ZGZmNmEyOC1iZjU4LTRmMTctOTIwMC1jZWJhZTU0MTNhZTMuanBlZ5GTBc0BHcyg" />Podczas manewrów Bundeswehry awarii uległo 18 transporterów opancerzonych Puma co wywołało duże zaniepokojenie polityków . Podkreślają, że planowana w ramach NATO dywizja staje się w tej sytuacji „farsą” – pisze w niedzielę portal dziennika „Welt”. Kosztująca ok. 17 mln euro Puma jest najdroższym bojowym wozem piechoty na świecie.

## Zełenski: Okupanci robią wszystko by Bachmut zrównać z ziemią
 - [https://forsal.pl/swiat/ukraina/artykuly/8613164,zelenski-okupanci-robia-wszystko-by-bachmut-zrownac-z-ziemia.html](https://forsal.pl/swiat/ukraina/artykuly/8613164,zelenski-okupanci-robia-wszystko-by-bachmut-zrownac-z-ziemia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 06:42:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yrYktkuTURBXy83NmNjOTU3MS0wYTFkLTQzODItOWYxNi0zZmRiNTY4ODA3MmYuanBlZ5GTBc0BHcyg" />&quot;Zwołałem dziś naradę dowództwa wojskowego, omawialiśmy sytuację w obwodach donieckim i ługańskim; kluczowy jest Bachmut. Utrzymujemy miasto, choć okupanci robią wszystko, by nie pozostała ani jedna cała ściana&quot; - poinformował w niedzielę wieczorem prezydent Ukrainy Wołodymyr Zełenski.

## Te miasta mają najlepszy transport publiczny na świecie [RANKING]
 - [https://forsal.pl/transport/artykuly/8611141,miasta-najlepszy-transport-publiczny-na-swiecie-ranking.html](https://forsal.pl/transport/artykuly/8611141,miasta-najlepszy-transport-publiczny-na-swiecie-ranking.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 05:30:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YoIktkuTURBXy8wYzBiZGEwNC03YTRjLTRlMWMtOWU0My1kMzliMDMzNDc0OTIuanBlZ5GTBc0BHcyg" />Hongkong został uznany za najlepsze miasto na świecie pod względem transportu publicznego - wynika z nowego badania przeprowadzonego przez firmę konsultingową Oliver Wyman i Uniwersytet Kalifornijski w Berkeley. Gdzie w tym zestawieniu znajduje się Warszawa?

## Chiny kończą z "zero Covid". To może pogorszyć globalny kryzys energetyczny
 - [https://forsal.pl/biznes/energetyka/artykuly/8610267,kryzys-energetyczny-europa-chiny-zwiekszenie-importu-gazu-lng.html](https://forsal.pl/biznes/energetyka/artykuly/8610267,kryzys-energetyczny-europa-chiny-zwiekszenie-importu-gazu-lng.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 05:30:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LIDktkuTURBXy83OWZlZDcxYS03NTcxLTQwMDYtOWQxNi0wMzUzYmQ3Y2ZiNzkuanBlZ5GTBc0BHcyg" />Odejście Chin od polityki &quot;zero Covid&quot; może zwiększyć popyt na gaz ziemny ze strony największego na świecie importera, potencjalnie ograniczając dostawy do Europy i innych krajów azjatyckich.

## Światowe zużycie węgla pobije w tym roku nowy rekord
 - [https://forsal.pl/biznes/energetyka/artykuly/8611897,swiatowe-zuzycie-wegla-pobije-w-tym-roku-nowy-rekord.html](https://forsal.pl/biznes/energetyka/artykuly/8611897,swiatowe-zuzycie-wegla-pobije-w-tym-roku-nowy-rekord.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 05:30:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QNQktkuTURBXy9iNDcyMDI1MS1mZjliLTRiMDgtOTkyMy0yYzM3ZjYyYzliMzguanBlZ5GTBc0BHcyg" />Światowe zużycie węgla ma wzrosnąć w tym roku do najwyższego poziomu w historii, pomimo ambitnych globalnych celów mających na celu odejście od spalania brudnych paliw kopalnych.

## Ogrzewanie – kto najczęściej korzysta z pomocy inteligentnych technologii? [BADANIE]
 - [https://forsal.pl/biznes/energetyka/artykuly/8612206,ogrzewanie-inteligentne-technologie.html](https://forsal.pl/biznes/energetyka/artykuly/8612206,ogrzewanie-inteligentne-technologie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2022-12-19 05:30:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oPOktkuTURBXy9mODYxMzhmYy1lYjhiLTRjMTUtODgxMi05YWE2NjliZDViYmIuanBlZ5GTBc0BHcyg" />Mieszkańcy Holandii, Hiszpanii oraz Włoch – jak wynika z badania Global Consumer Survey – najczęściej korzystają z pomocy inteligentnych technologii przy ogrzewaniu budynków – zaznacza Statista.


# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## House of the Dragon's Olivia Cook on Her Most Difficult Scene So Far
 - [https://gizmodo.com/house-of-the-dragon-game-of-thrones-alicent-hightower-1849912673](https://gizmodo.com/house-of-the-dragon-game-of-thrones-alicent-hightower-1849912673)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 23:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--6m-ygytO--/c_fit,fl_progressive,q_80,w_636/e6600aa2d11296be49d1f3d92766cf78.jpg" /><p><a href="https://gizmodo.com/house-of-the-dragon-game-of-thrones-finale-explained-1849694137"><em>House of the Dragon</em></a> elevated itself very quickly from being “<a href="https://gizmodo.com/everything-we-know-about-house-of-the-dragon-1847808778">that new <em>Game of Thrones</em> spin-off</a>” to must-watch appointment TV, thanks in no small part to the extreme drama experienced by its well-acted characters. <a href="https://gizmodo.com/game-of-thrones-prequel-star-olivia-cooke-believes-the-1846438873">Olivia Cooke</a>’s Alicent Hightower—daughter, queen, mother—had more than her share of trials, but the actor…</p><p><a href="https://gizmodo.com/house-of-the-dragon-game-of-thrones-alicent-hightower-1849912673">Read more...</a></p>

## Meta's Not Giving Up on the Metaverse Just Yet
 - [https://gizmodo.com/meta-metaverse-horizon-worlds-vr-reality-labs-1849912350](https://gizmodo.com/meta-metaverse-horizon-worlds-vr-reality-labs-1849912350)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 23:05:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--LQ-fJgNM--/c_fit,fl_progressive,q_80,w_636/ec715d34a4498644aee22da780791300.jpg" /><p>Much has changed since Mark Zuckerberg last year <a href="https://gizmodo.com/facebooks-new-name-is-meta-1847957440">boldly proclaimed</a> the company once known as Facebook would charge the world headfirst into the so-called metaverse. A historic tech downturn grabbed hold of Meta and left it with <a href="https://gizmodo.com/facebook-meta-mark-zuckerberg-laying-off-11000-workers-1849761475">11,000 fewer employees</a> and a stock price <a href="https://www.financialexpress.com/investing-abroad/featured-stories/meta-stock-value-plunges-65-in-2022-the-biggest-drop-among-the-big-five-tech-giants/2919629/" rel="noopener noreferrer" target="_blank">down</a> a whopping 65%. Meta reportedly <a href="https://www.theverge.com/2021/10/25/22745381/facebook-reality-labs-10-billion-metaverse" rel="noopener noreferrer" target="_blank">burned</a> over…</p><p><a href="https://gizmodo.com/meta-metaverse-horizon-worlds-vr-reality-labs-1849912350">Read more...</a></p>

## Kids vs. Aliens' Trailer Sounds Its Battle Cry: 'F*ck Space!'
 - [https://gizmodo.com/kids-vs-aliens-first-trailer-nerdy-retro-sci-fi-comedy-1849911977](https://gizmodo.com/kids-vs-aliens-first-trailer-nerdy-retro-sci-fi-comedy-1849911977)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 23:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--INfpVNKo--/c_fit,fl_progressive,q_80,w_636/1356df6f33dbaeab3b89e4f44b3e393a.jpg" /><p>Director Jason Eisener is clearly a fan of to-the-point titles; previously, he made <em>Hobo With a Shotgun</em>, about a hobo (<a href="https://gizmodo.com/blade-runner-star-rutger-hauer-has-passed-away-1836667411">Rutger Hauer</a>) toting a you-know-what, and his latest has a similarly literal title: <em>Kids vs. Aliens</em>. A <a href="https://gizmodo.com/fantastic-fest-2022-top-10-the-menu-bones-and-all-smile-1849592108">Fantastic Fest selection</a> earlier this year, the film will soon be in theaters—with a new trailer…</p><p><a href="https://gizmodo.com/kids-vs-aliens-first-trailer-nerdy-retro-sci-fi-comedy-1849911977">Read more...</a></p>

## Bird Scooters Shakes Down Past Users Over Outstanding Balances as Small as $0.55
 - [https://gizmodo.com/bird-scooter-micro-mobility-scooter-rental-1849911788](https://gizmodo.com/bird-scooter-micro-mobility-scooter-rental-1849911788)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 22:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--35dF-1np--/c_fit,fl_progressive,q_80,w_636/57b0c2a935d6dbe19277aa0c38987042.jpg" /><p>Scooter rental company, Bird, has officially boarded the struggle bus. The micro mobility provider sent out emails to current and past customers requesting that they settle their lingering debts earlier this month. And the company left no stone unturned in its quest to recoup revenue.<br /></p><p><a href="https://gizmodo.com/bird-scooter-micro-mobility-scooter-rental-1849911788">Read more...</a></p>

## The Best and Worst Nerdy News of 2022
 - [https://gizmodo.com/best-worst-news-2022-james-gunn-deadpool-3-hbo-max-1849905286](https://gizmodo.com/best-worst-news-2022-james-gunn-deadpool-3-hbo-max-1849905286)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 22:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--3X7eIiUK--/c_fit,fl_progressive,q_80,w_636/f7959f6ce935a7555b75eedc2108d807.png" /><p>I’ve got good news for you... and bad news. Literally. We’ve combed through <a href="https://gizmodo.com/io9/year-in-review">the io9 archives</a> to discover all the news stories in 2022 that either delighted us or really bummed us out—and compiled them so you can remember the good times and what you should still be angry about in 2023.<br /></p><p><a href="https://gizmodo.com/best-worst-news-2022-james-gunn-deadpool-3-hbo-max-1849905286">Read more...</a></p>

## Vatican Defrocks Priest for 'Blasphemous' Posts on Social Media
 - [https://gizmodo.com/anti-abortion-trump-priest-social-media-pavone-1849912110](https://gizmodo.com/anti-abortion-trump-priest-social-media-pavone-1849912110)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 22:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--oFgotWrD--/c_fit,fl_progressive,q_80,w_636/d1445bbc7e3e88d81a5fccae0f3c45e0.jpg" /><p>The Vatican removed anti-abortion activist, Frank Pavone, from the priesthood after he made incendiary posts on social media. <a href="https://www.nbcnews.com/news/us-news/anti-abortion-priest-frank-pavone-defrocked-blasphemous-posts-rcna62364" rel="noopener noreferrer" target="_blank">The decision</a> to defrock the Florida-based priest was made on November 9 with no chance for an appeal, U.S. Archbishop Christophe Pierre said in a letter obtained by several news outlets.</p><p><a href="https://gizmodo.com/anti-abortion-trump-priest-social-media-pavone-1849912110">Read more...</a></p>

## James Gunn Is Not Letting Troll Outrage Drive Decisions at DC Studios
 - [https://gizmodo.com/james-gunn-wont-let-troll-outrage-drive-dc-studios-1849911826](https://gizmodo.com/james-gunn-wont-let-troll-outrage-drive-dc-studios-1849911826)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--9sFk7yGn--/c_fit,fl_progressive,q_80,w_636/f4752e5dfcc5e0ad6c403af3a48cf33f.jpg" /><p>As the dust settles from last week’s DC Studios shakeups, between <a href="https://gizmodo.com/henry-cavill-superman-return-dc-james-gunn-black-adam-1849896018">Henry Cavill being done as Superman</a> and <a href="https://gizmodo.com/wonder-woman-3-dead-cancel-warner-bros-dc-patty-jenkins-1849866873"><em>Wonder Woman 3</em> not moving ahead</a>, <a href="https://gizmodo.com/james-gunn-head-of-dc-movies-and-tv-warner-bros-1849701460">new co-chair and co-CEO James Gunn</a> once again <a href="https://twitter.com/JamesGunn" rel="noopener noreferrer" target="_blank">took to Twitter</a> and <a href="https://www.instagram.com/p/CmXMuZmvyLk/?utm_source=ig_web_copy_link" rel="noopener noreferrer" target="_blank">Instagram</a> to address the internet’s rumor mill of speculation. </p><p><a href="https://gizmodo.com/james-gunn-wont-let-troll-outrage-drive-dc-studios-1849911826">Read more...</a></p>

## Over 67,000 DraftKings Betting Accounts Hit by Hackers
 - [https://gizmodo.com/draftkings-hackers-sports-gambling-1849911810](https://gizmodo.com/draftkings-hackers-sports-gambling-1849911810)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 21:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--h1kVhlTn--/c_fit,fl_progressive,q_80,w_636/e2c3d39e795cc2049ade8611f2e223b3.jpg" /><p>New details about a hack from last month show that tens of thousands of users happily gambling away on DraftKings may have had their personal information stolen thanks to account info purchased off the sports gambling site. </p><p><a href="https://gizmodo.com/draftkings-hackers-sports-gambling-1849911810">Read more...</a></p>

## Google Introduces End-to-End Encryption for Gmail
 - [https://gizmodo.com/gmail-google-end-to-end-encryption-email-1849911695](https://gizmodo.com/gmail-google-end-to-end-encryption-email-1849911695)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 21:05:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--yYo51J3s--/c_fit,fl_progressive,q_80,w_636/6ac38a571d88717715e0796b6a7ebac8.jpg" /><p><a href="https://gizmodo.com/googles-found-a-new-way-to-track-workspace-users-1848466123">Google Workspace</a> is rolling out a new security update on <a href="https://gizmodo.com/how-to-customize-new-gmail-interface-google-email-1848633408">Gmail</a>, adding end-to-end encryption that aims to provide an added layer of security when sending emails and attachments on the web. Customers will continue to have control over encryption keys and identity services that provide access to those keys.</p><p><a href="https://gizmodo.com/gmail-google-end-to-end-encryption-email-1849911695">Read more...</a></p>

## South Korea's First Moon Mission Enters Lunar Orbit
 - [https://gizmodo.com/south-korea-danuri-lunar-orbiter-first-moon-mission-1849911066](https://gizmodo.com/south-korea-danuri-lunar-orbiter-first-moon-mission-1849911066)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 21:05:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ELnQQfDJ--/c_fit,fl_progressive,q_80,w_636/b489ecc37659aaf6ad3aa94afe266845.jpg" /><p>After a four month journey through space, the Korean Pathfinder Lunar Orbiter (KPLO) has finally reached lunar orbit. The probe will spend the next year scanning the surface from above in search of water ice and suitable landing spots for future missions. </p><p><a href="https://gizmodo.com/south-korea-danuri-lunar-orbiter-first-moon-mission-1849911066">Read more...</a></p>

## Someone's Selling Google's Pixel Tablet on Facebook Marketplace
 - [https://gizmodo.com/google-pixel-tablet-photos-leak-facebook-marketplace-1849911734](https://gizmodo.com/google-pixel-tablet-photos-leak-facebook-marketplace-1849911734)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 20:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--wG-WpMaz--/c_fit,fl_progressive,q_80,w_636/605b63dad31ba90205f5ebf0f6c603ca.jpg" /><p>Google’s Pixel tablet isn’t supposed to come out until 2023, but we’re already seeing a supposed early unit up for grabs. This leak comes to us from <a href="https://twitter.com/VNchocoTaco/status/1604709835253383169/" rel="noopener noreferrer" target="_blank">Twitter</a>, though it’s just a collection of screenshots from a Facebook Marketplace post that claims to be selling the announced-but-unreleased <a href="https://gizmodo.com/google-pixel-tablet-specs-nest-hub-speaker-dock-design-1849625364">Google Pixel Tablet</a>.<br /></p><p><a href="https://gizmodo.com/google-pixel-tablet-photos-leak-facebook-marketplace-1849911734">Read more...</a></p>

## West Texas Shaken by Second 5.4 Magnitude Earthquake in a Month
 - [https://gizmodo.com/west-texas-shaken-by-second-5-4-magnitude-earthquake-in-1849911038](https://gizmodo.com/west-texas-shaken-by-second-5-4-magnitude-earthquake-in-1849911038)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 20:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--UwIFKhbf--/c_fit,fl_progressive,q_80,w_636/37783fb525cc7a59c1a786fa8bf714e4.jpg" /><p>An earthquake that shook West Texas on Friday may be one of the strongest ever recorded in the state, the <a href="https://apnews.com/article/texas-earthquakes-climate-and-environment-ff77739992cf783eedc8ba43610568af" rel="noopener noreferrer" target="_blank">Associated Press reported</a>. The magnitude 5.4 quake <a href="https://earthquake.usgs.gov/earthquakes/eventpage/tx2022yplg/executive" rel="noopener noreferrer" target="_blank">struck</a> at around 5:35 p.m. local time  about 14 miles (22 kilometers) north of Midland. It comes just a month after another 5.4 quake in the region, and officials…</p><p><a href="https://gizmodo.com/west-texas-shaken-by-second-5-4-magnitude-earthquake-in-1849911038">Read more...</a></p>

## Rings of Power Season 2 Will Move at a Faster Pace
 - [https://gizmodo.com/rings-of-power-season-2-lord-of-the-rings-prime-amazon-1849911148](https://gizmodo.com/rings-of-power-season-2-lord-of-the-rings-prime-amazon-1849911148)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 20:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--8ADgtDX1--/c_fit,fl_progressive,q_80,w_636/12bace8f68203eaa1dc41a2d9af02ac0.png" /><p>The world created by J.R.R. Tolkien has <a href="https://gizmodo.com/prime-video-lord-of-the-rings-the-rings-of-power-bts-1849807674">carved out a new universe on Prime Video</a> with <a href="https://gizmodo.com/marvel-loki-s2-first-footage-disney-ahsoka-mandalorian-1849910521"><em>The Lord of the Rings: The Rings of Power</em></a>.<a href="https://gizmodo.com/lord-of-the-rings-rings-of-power-finale-recap-sauron-1849660513"> Season one recently closed out</a> after a ton of world building, and the main players’ arcs are now gearing up for big moments in season two.</p><p><a href="https://gizmodo.com/rings-of-power-season-2-lord-of-the-rings-prime-amazon-1849911148">Read more...</a></p>

## Incoming Arctic Blast Set to Disrupt Holiday Travel Nationwide
 - [https://gizmodo.com/arctic-blast-cold-front-travel-delays-christmas-1849910794](https://gizmodo.com/arctic-blast-cold-front-travel-delays-christmas-1849910794)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 20:31:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--u6p2YatA--/c_fit,fl_progressive,q_80,w_636/ec605d337883afc0530f9640ff5eb063.jpg" /><p>An extreme chill is set to sweep across most of the continental U.S. in the coming days, as a blast of Arctic air dips as far south as Texas. National Weather Service forecasters are predicting unusually cold temperatures from the Pacific Northwest to the Southeast between Wednesday and Saturday, just days after…</p><p><a href="https://gizmodo.com/arctic-blast-cold-front-travel-delays-christmas-1849910794">Read more...</a></p>

## How to Get In-Flight WiFi on Delta, JetBlue, United, and More
 - [https://gizmodo.com/get-wifi-delta-united-jetblue-southwest-alaska-free-1849908653](https://gizmodo.com/get-wifi-delta-united-jetblue-southwest-alaska-free-1849908653)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 20:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--uIzt0JIQ--/c_fit,fl_progressive,q_80,w_636/79d2e26d15e3b2d90d86d61b55f6d8ed.jpg" /><p>Leg room, luggage space, in-flight meals, the actual cost of the ticket—these are all important considerations when booking a flight. But for some of us, perhaps the most crucial consideration of all concerns the on-board wifi options. Are you actually going to be able to get anything done mid-journey, or will you be…</p><p><a href="https://gizmodo.com/get-wifi-delta-united-jetblue-southwest-alaska-free-1849908653">Read more...</a></p>

## Yes, Indiana Jones 5 Will Address the Mutt Williams Thing
 - [https://gizmodo.com/mutt-williams-indiana-jones-5-dial-of-destiny-labeouf-1849911011](https://gizmodo.com/mutt-williams-indiana-jones-5-dial-of-destiny-labeouf-1849911011)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--4cGq45YY--/c_fit,fl_progressive,q_80,w_636/dc9bef38fbf68ca3ae129cdc7eba0919.jpg" /><p>Mutt Williams, Shia LaBeouf’s character from <a href="https://gizmodo.com/21-good-things-about-indiana-jones-and-the-kingdom-of-t-1845596680"><em>Indiana Jones and the Kingdom of the Crystal Skull</em></a>, is not in the upcoming <a href="https://gizmodo.com/indiana-jones-5-trailer-breakdown-dial-of-destiny-ford-1849843527"><em>Indiana Jones and the Dial of Destiny</em></a>. This much <a href="https://gizmodo.com/this-is-a-relief-indiana-jones-5-wont-include-shia-lab-1799201498">has been known for some time</a>. What hasn’t been known is if the film will just <a href="https://gizmodo.com/theyre-never-going-to-recast-indiana-jones-1738752747">ignore him</a> or make him part of the story—and now, we have a little more…</p><p><a href="https://gizmodo.com/mutt-williams-indiana-jones-5-dial-of-destiny-labeouf-1849911011">Read more...</a></p>

## Just When You Thought Mosasaurs Couldn’t Get Any Scarier
 - [https://gizmodo.com/mosasaurs-venomous-diet-jaws-paleontology-1849911521](https://gizmodo.com/mosasaurs-venomous-diet-jaws-paleontology-1849911521)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 19:50:40+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vFyxgFxS--/c_fit,fl_progressive,q_80,w_636/12443add66d2e40f4360e22ab0c66bbc.jpg" /><p>You wouldn’t want to swim in Late Cretaceous seas. If you’ve seen the first <em>Jurassic World</em> movie, you’ll recognize a mosasaur as the creature that leapt from the water to eat a great white shark. That film may have exaggerated the real size of mosasaurs, but the effect is genuine: some species could reach terrifying…</p><p><a href="https://gizmodo.com/mosasaurs-venomous-diet-jaws-paleontology-1849911521">Read more...</a></p>

## Patton Oswalt and Rachael Leigh Cook Are Heading Into a World of Superhero Noir in NO/ONE
 - [https://gizmodo.com/image-comics-no-one-radiant-black-rachael-leigh-cook-1849911099](https://gizmodo.com/image-comics-no-one-radiant-black-rachael-leigh-cook-1849911099)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 19:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--adgzy6HC--/c_fit,fl_progressive,q_80,w_636/464b8abcf2430aa14658019a9c8d947f.png" /><p><a href="https://gizmodo.com/the-team-behind-radiant-black-talk-bringing-power-range-1845691447"><em>Radiant Black</em></a> has become a smash hit for Image Comics, now playing host to a whole rainbow of <a href="https://gizmodo.com/the-radiant-black-universe-expands-again-with-a-radiant-1848259046">Radiant heroes and villains</a>. But its next big thing isn’t bright lights and big superheroics—it’s a multimedia thriller about murder in <a href="https://gizmodo.com/radiant-black-supermassive-2-image-comics-1849466802">a world of heroes</a>, and io9 has your first details.<br /></p><p><a href="https://gizmodo.com/image-comics-no-one-radiant-black-rachael-leigh-cook-1849911099">Read more...</a></p>

## 'The Return of the Crawling Evil,' a Lovecraftian Sci-Fi Story Written and Illustrated by Robots
 - [https://gizmodo.com/chatgpt-dall-e-ai-art-sci-fi-hp-lovecraft-story-1849904617](https://gizmodo.com/chatgpt-dall-e-ai-art-sci-fi-hp-lovecraft-story-1849904617)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 19:02:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--zGmsvQoe--/c_fit,fl_progressive,q_80,w_636/b32e1179ff1f6205b6531091176fe83c.png" /><p>You’ve probably heard about <a href="https://gizmodo.com/chatgpt-gizmodo-artificial-intelligence-openai-media-1849876066">ChatGPT</a>, OpenAI’s new AI chatbot that seems to be able to spin up essays, poems, <a href="https://gizmodo.com/openai-chatgpt-twitter-ai-1849910358">Twitter replies</a>, and short stories at the drop of a hat. We at Gizmodo had <a href="https://gizmodo.com/chatgpt-how-to-use-openai-ai-elon-musk-1849855605">heard a lot about how good the program was at writing fiction</a>, so we decided: why not have the robot write us some science fiction? It…</p><p><a href="https://gizmodo.com/chatgpt-dall-e-ai-art-sci-fi-hp-lovecraft-story-1849904617">Read more...</a></p>

## Epic Forced to Pay Record-Breaking $520 Million Fine for Violating Children's Privacy and Engaging in Dark Pattern Deception
 - [https://gizmodo.com/epic-fortnite-gaming-ftc-dark-patterns-1849910901](https://gizmodo.com/epic-fortnite-gaming-ftc-dark-patterns-1849910901)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 18:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--tffW1f6e--/c_fit,fl_progressive,q_80,w_636/dd2eb8c81ba583f569226628dadde2df.jpg" /><p>Fortnite-maker Epic Games has agreed to pay a massive $520 million fine in settlements with the Federal Trade Commission for allegedly illegally gathering data from children and deploying dark patterns techniques to manipulate users into making unwanted in-game purchases. The fines mark a major regulatory win for the…</p><p><a href="https://gizmodo.com/epic-fortnite-gaming-ftc-dark-patterns-1849910901">Read more...</a></p>

## Loki Narrates the (Very) Brief First Look at Season 2 of the Marvel Series
 - [https://gizmodo.com/marvel-loki-s2-first-footage-disney-ahsoka-mandalorian-1849910521](https://gizmodo.com/marvel-loki-s2-first-footage-disney-ahsoka-mandalorian-1849910521)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--qX6LaFyl--/c_fit,fl_progressive,q_80,w_636/983918e730721f3c80a353b6e47ad592.jpg" /><p>In 2023, Marvel is going full multiverse. There’s <a href="https://gizmodo.com/antman-2-trailer-breakdown-quantumania-kang-paul-rudd-1849694289"><em>Ant-Man and the Wasp: Quantumania</em></a><em>,</em> <em>Spider-Man: <a href="https://gizmodo.com/across-the-spider-verse-jessica-drew-black-woman-marvel-1849898600">Across the Spider-Verse</a></em>, and <em>The Marvels </em>to start, but don’t forget the show that started it all. That’s <em>Loki</em> and <a href="https://gizmodo.com/lokis-finale-revealed-whats-on-the-horizon-for-the-mcu-1847289263">it too will be back in 2023.</a> </p><p><a href="https://gizmodo.com/marvel-loki-s2-first-footage-disney-ahsoka-mandalorian-1849910521">Read more...</a></p>

## ChatGPT Has Infiltrated Twitter Replies
 - [https://gizmodo.com/openai-chatgpt-twitter-ai-1849910358](https://gizmodo.com/openai-chatgpt-twitter-ai-1849910358)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 18:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--3glqDGiB--/c_fit,fl_progressive,q_80,w_636/571274f16b24e8552df7e7933e709e6f.png" /><p>As Twitter continues to circle the drain fueled by <a href="https://gizmodo.com/elon-musk-poll-twitter-ceo-results-no-1849909599">chaos</a> from CEO Elon Musk, one user noticed something peculiar about tweet replies. After digging a little deeper, user Pieter Levels—who goes by @levelsio on the platform—found that bots are apparently now using the popular <a href="https://gizmodo.com/chatgpt-how-to-use-openai-ai-elon-musk-1849855605">text-generating AI ChatGPT</a> to reply to…</p><p><a href="https://gizmodo.com/openai-chatgpt-twitter-ai-1849910358">Read more...</a></p>

## Leak Inspection Finds Hole in Russian Spacecraft Docked to ISS
 - [https://gizmodo.com/iss-coolant-leak-hole-soyus-spacecraft-russia-1849910293](https://gizmodo.com/iss-coolant-leak-hole-soyus-spacecraft-russia-1849910293)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 17:59:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--cOYHeEAK--/c_fit,fl_progressive,q_80,w_636/e6af0f6e0be7769c3924e0b2f7a35bf8.jpg" /><p>An inspection has revealed an 0.8-millimeter-wide hole in the Soyuz MS-22 spacecraft that sprung a coolant leak outside the International Space Station last week. Russian space agency Roscosmos will make a decision on the flight-worthiness of the spacecraft later this month, at which time Russia may choose to expedite…</p><p><a href="https://gizmodo.com/iss-coolant-leak-hole-soyus-spacecraft-russia-1849910293">Read more...</a></p>

## Across the Spider-Verse Wants You to Take Its Villain Seriously
 - [https://gizmodo.com/spider-man-across-the-spider-verse-spot-villain-details-1849910516](https://gizmodo.com/spider-man-across-the-spider-verse-spot-villain-details-1849910516)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 17:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vU3l4LJ4--/c_fit,fl_progressive,q_80,w_636/2f8ea33db5291715066271edc8c25bec.png" /><p><a href="https://gizmodo.com/spider-man-across-the-spider-verse-miles-morales-spot-a-1849052668">When it was announced</a> that the main villain of the <a href="https://gizmodo.com/spider-man-across-the-spider-verse-trailer-breakdown-su-1849889636"><em>Into the Spider-Verse</em> sequel</a> was going to be D-List Spidey foe the Spot, many people shrugged their shoulders at the thought that someone who looks like a walking dalmatian zoot suit with portal powers could be a major threat to Miles and his amazing friends. But…</p><p><a href="https://gizmodo.com/spider-man-across-the-spider-verse-spot-villain-details-1849910516">Read more...</a></p>

## How to Watch Soccer on Streaming TV
 - [https://gizmodo.com/how-to-watch-soccer-streaming-online-premier-league-mls-1849882928](https://gizmodo.com/how-to-watch-soccer-streaming-online-premier-league-mls-1849882928)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 17:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--z5Grp65T--/c_fit,fl_progressive,q_80,w_636/2fef25d8a9c04006760d2237838e770b.jpg" /><p>For many Americans, soccer is a once-every-four-year thing. We <a href="https://gizmodo.com/fifa-tech-soccer-qatar-1849818515">watch the World Cup</a>, the biggest and most important soccer tournament in the world, but once it’s over, <a href="https://gizmodo.com/qatar-claims-the-2022-fifa-world-cup-is-carbon-neutral-1849808283">it’s over</a>. Then we forget about the sport until the next World Cup. Next time around, though, the <a href="https://gizmodo.com/iran-usa-fifa-world-cup-soccer-flag-1849827767">2026 World Cup</a> is here in North America, so <a href="https://gizmodo.com/fifa-world-cup-ai-qatar-soccer-futbol-1849142399">maybe you…</a></p><p><a href="https://gizmodo.com/how-to-watch-soccer-streaming-online-premier-league-mls-1849882928">Read more...</a></p>

## SpaceX Pulls off 3 Orbital Launches in 34 Hours, Smashing Its Record
 - [https://gizmodo.com/spacex-three-falcon-9-launches-breaks-record-1849909984](https://gizmodo.com/spacex-three-falcon-9-launches-breaks-record-1849909984)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 17:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--xbS8s6qm--/c_fit,fl_progressive,q_80,w_636/c82c2156d4c59aa57aa04a811f61ef1b.jpg" /><p>SpaceX is finishing off the year strong, flying its Falcon 9 rocket three times in less than 34 hours to deliver various payloads to low Earth orbit.</p><p><a href="https://gizmodo.com/spacex-three-falcon-9-launches-breaks-record-1849909984">Read more...</a></p>

## Google Takes on Doctors' Terrible Handwriting
 - [https://gizmodo.com/google-prescriptions-doctor-rx-ai-1849909756](https://gizmodo.com/google-prescriptions-doctor-rx-ai-1849909756)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 17:25:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--m5xK99JD--/c_fit,fl_progressive,q_80,w_636/a7417d1a31e31386600606be3a385e41.jpg" /><p>Google has proposed a remedy for the doctor’s note. The tech giant is working on an AI technology tool to decipher hard-to-read handwritten medical prescriptions, as announced at its yearly Google for India conference on Monday and described in <a href="https://blog.google/intl/en-in/company-news/inside-google/google-for-india-2022-ai-announcements/" rel="noopener noreferrer" target="_blank">a company blogpost</a>. <br /></p><p><a href="https://gizmodo.com/google-prescriptions-doctor-rx-ai-1849909756">Read more...</a></p>

## Meta Accused of Breaching Antitrust Policies Connected to Facebook Marketplace
 - [https://gizmodo.com/facebook-marketplace-meta-antitrust-classified-ads-1849910046](https://gizmodo.com/facebook-marketplace-meta-antitrust-classified-ads-1849910046)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 17:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--JTwfK6Yn--/c_fit,fl_progressive,q_80,w_636/68a6101f8bddd761080fea81204cf7ed.jpg" /><p>On Monday, the European Commission accused Meta of going against its antitrust laws by using its Facebook Marketplace to promote ads and distort outside competition. The commission warned Meta of the breach in an <a href="https://ec.europa.eu/commission/presscorner/detail/en/ip_22_7728" rel="noopener noreferrer" target="_blank">official statement</a> and said if the company is found guilty, it could receive a fine of up to 10% of its…</p><p><a href="https://gizmodo.com/facebook-marketplace-meta-antitrust-classified-ads-1849910046">Read more...</a></p>

## John Carmack Quits Meta, Burns His Virtual Bridges Behind Him
 - [https://gizmodo.com/facebook-meta-vr-john-carmack-metaverse-oculus-1849909943](https://gizmodo.com/facebook-meta-vr-john-carmack-metaverse-oculus-1849909943)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--U9Pm45X---/c_fit,fl_progressive,q_80,w_636/19f8db49fbc57a743547adb4181fa49d.jpg" /><p>Meta’s pivot away from social media and into virtual reality has hit another snag. One of the company’s executives, John Carmack, who helped build Meta’s Oculus company as Chief Technology Officer—is stepping away from Meta amidst frustration over the company’s efficiency.<br /></p><p><a href="https://gizmodo.com/facebook-meta-vr-john-carmack-metaverse-oculus-1849909943">Read more...</a></p>

## Watch Tom Cruise Repeatedly Try to Kill Himself for Mission: Impossible 7
 - [https://gizmodo.com/mission-impossible-7-stunt-tom-cruise-dead-reckoning-1849910275](https://gizmodo.com/mission-impossible-7-stunt-tom-cruise-dead-reckoning-1849910275)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--x33n6aX3--/c_fit,fl_progressive,q_80,w_636/227d55db1198d3f9b6e262016751101c.jpg" /><p>At this point, <a href="https://gizmodo.com/tom-cruise-mission-impossible-airplane-stunt-1849506417">Tom Cruise</a> is well known for doing as many of his own stunts as possible, no matter how dangerous they are or needless they seem to be. But that doesn’t make it any less impressive learning how much work and care goes into these stunts/keeping Cruise alive, as this behind-the-scenes look at <a href="https://gizmodo.com/mission-impossible-7-trailer-dead-reckoning-part-1-tom-1848962469"><em>Mission:</em>…</a></p><p><a href="https://gizmodo.com/mission-impossible-7-stunt-tom-cruise-dead-reckoning-1849910275">Read more...</a></p>

## Twitter Suddenly Reverses Course on 'Policy' That Banned Links to Competing Social Media Sites
 - [https://gizmodo.com/elon-musk-twitter-external-links-mastodon-1849909896](https://gizmodo.com/elon-musk-twitter-external-links-mastodon-1849909896)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 15:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--mPnuUs80--/c_fit,fl_progressive,q_80,w_636/a51af31a263c0058fcb5db625e658e49.jpg" /><p>Twitter has <a href="https://gizmodo.com/elon-musk-twitter-elonjet-banned-private-plane-tracker-1849891785">once</a> <a href="https://gizmodo.com/twitter-elon-musk-official-verified-badge-ftc-nytimes-1849771565">again</a> rushed to undo an impulsive new policy less than a day after introducing it. This week’s victim: Elon Musk’s sudden decision to ban external links to other social media sites. </p><p><a href="https://gizmodo.com/elon-musk-twitter-external-links-mastodon-1849909896">Read more...</a></p>

## FTX’s Bankman-Fried Won’t Fight Extradition, but His Homecoming Could Be Messy
 - [https://gizmodo.com/sam-bankman-fried-sbf-ftx-crypto-extradition-1849909856](https://gizmodo.com/sam-bankman-fried-sbf-ftx-crypto-extradition-1849909856)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 15:25:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--mpaWmSNh--/c_fit,fl_progressive,q_80,w_636/5216ae2afe26f066f02f4242a9a00270.jpg" /><p>The FTX founder whose alleged fraud has sent the entire crypto industry reeling may be finally coming home to the U.S. Over the weekend, <a href="https://www.reuters.com/world/us/sam-bankman-fried-reverse-decision-contesting-extradition-source-2022-12-17/" rel="noopener noreferrer" target="_blank">Reuters</a> first reported the 30-year-old FTX founder was going to return to court in the Bahamas Monday and relinquish his bid to fight extradition to the U.S., an unnamed source…</p><p><a href="https://gizmodo.com/sam-bankman-fried-sbf-ftx-crypto-extradition-1849909856">Read more...</a></p>

## Ant-Man and The Wasp: Quantumania's Director Teases Bill Murray's Role
 - [https://gizmodo.com/ant-man-and-the-wasp-quantumania-bill-murray-marvel-1849908862](https://gizmodo.com/ant-man-and-the-wasp-quantumania-bill-murray-marvel-1849908862)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 15:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ekaBV0Qd--/c_fit,fl_progressive,q_80,w_636/791a8f24a541b8a550bcb53cfe63b91d.png" /><p>Get another look at the cocaine bear in, well, <em>Cocaine Bear</em>. Jenna Ortega promises more for her character in <em>Scream 6</em>. Plus, get a gory new look at <em>The Last of Us</em>, and a sneak preview of <em>Fantasy Island</em>’s return. Spoilers now!<br /></p><p><a href="https://gizmodo.com/ant-man-and-the-wasp-quantumania-bill-murray-marvel-1849908862">Read more...</a></p>

## Transparent Keys and An In-Keyboard Screen Add Yet Another Display to Your Desk
 - [https://gizmodo.com/keyboard-screen-transparent-keys-finalmouse-centerpiece-1849909751](https://gizmodo.com/keyboard-screen-transparent-keys-finalmouse-centerpiece-1849909751)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 15:05:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--AMKF4Fi8--/c_fit,fl_progressive,q_80,w_636/cd90039bf40a295040d33d773e1447a1.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--6n2d7nvr--/c_fit,fl_progressive,q_80,w_636/cd90039bf40a295040d33d773e1447a1.mp4" type="video/mp4" /></video><p>Keyboards have become as much of a form of self-expression as the outfits in your closet, but instead of just showing off color-changing LEDs, the Centerpiece keyboard puts an entire interactive display beneath a set of transparent keys, which will have touch typists staring at their keyboards again.</p><p><a href="https://gizmodo.com/keyboard-screen-transparent-keys-finalmouse-centerpiece-1849909751">Read more...</a></p>

## Republicans Are Coughing Up Billions to Save Florida’s Home Insurance Market
 - [https://gizmodo.com/republicans-are-coughing-up-billions-to-save-florida-s-1849909675](https://gizmodo.com/republicans-are-coughing-up-billions-to-save-florida-s-1849909675)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 13:42:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--WNn1i3gy--/c_fit,fl_progressive,q_80,w_636/ab0d47730bc9b96254c16b38b892cf5e.jpg" /><p><em>This story was originally published by <a href="https://grist.org/" rel="noopener noreferrer" target="_blank">Grist</a>. You can <a href="https://go.grist.org/signup/weekly?utm_campaign=signup-page&amp;utm_medium=web&amp;utm_source=grist&amp;utm_content=weekly" rel="noopener noreferrer" target="_blank">subscribe to its weekly newsletter here</a>.<br /></em></p><p><a href="https://gizmodo.com/republicans-are-coughing-up-billions-to-save-florida-s-1849909675">Read more...</a></p>

## Elon Musk Polled Twitter Asking If He Should Stay on as CEO. The Result Was 'No'
 - [https://gizmodo.com/elon-musk-poll-twitter-ceo-results-no-1849909599](https://gizmodo.com/elon-musk-poll-twitter-ceo-results-no-1849909599)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--4mDyxyx---/c_fit,fl_progressive,q_80,w_636/8ce4641f7845eb540d50c83314fa4180.jpg" /><p>Twitter’s chief twit Elon Musk hinged his future at social media app to a poll, one of his favorite ways to make decisions, on Sunday evening. In the 12-hour poll, Musk asked whether he should step down as head of Twitter and promised to “abide by the results.” Well, the results are in, and the “yes” votes won.</p><p><a href="https://gizmodo.com/elon-musk-poll-twitter-ceo-results-no-1849909599">Read more...</a></p>

## Hands-on: Dyson's $1,000 Air Purifying "Zone" Headphones Should Be Two Separate Products
 - [https://gizmodo.com/dyson-zone-air-purifying-headphones-hands-on-preview-1849905776](https://gizmodo.com/dyson-zone-air-purifying-headphones-hands-on-preview-1849905776)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-19 12:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--QLyTx-bK--/c_fit,fl_progressive,q_80,w_636/f0ed3c06e1aad9445a677653822b1530.png" /><p>Last week, we got a staggering <a href="https://gizmodo.com/dyson-air-purifying-headphones-filter-price-release-dat-1849831922">price reveal</a> for Dyson’s first-ever audio product, the Zone. The combination headphones-air-purifier will already cost you your privacy, as folks are bound to shoot stares at you from across the train or plane while you’ve got it on. But it’ll also run you $950—at least. </p><p><a href="https://gizmodo.com/dyson-zone-air-purifying-headphones-hands-on-preview-1849905776">Read more...</a></p>


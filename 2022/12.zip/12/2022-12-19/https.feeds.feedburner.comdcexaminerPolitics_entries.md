# Source:Washington Examiner - politics, URL:https://feeds.feedburner.com/dcexaminer/Politics, language:en-US

## Key tax breaks left out of funding bill, clouding their future
 - [https://www.washingtonexaminer.com/policy/tax-provisions-omnibus-left-out](https://www.washingtonexaminer.com/policy/tax-provisions-omnibus-left-out)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2022-12-19 22:54:46+00:00

Efforts to expand the child tax credit and avoid losing a prized business tax break have been left out of the end-of-year funding bill, putting their future in doubt.

## Lawmakers are donating Bankman-Fried’s campaign contributions — who and where
 - [https://www.washingtonexaminer.com/policy/economy/where-lawmakers-donated-bankman-fried-contributions](https://www.washingtonexaminer.com/policy/economy/where-lawmakers-donated-bankman-fried-contributions)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2022-12-19 08:00:05+00:00

After FTX’s collapse, some lawmakers quickly donated campaign contributions from the company’s disgraced founder Sam Bankman-Fried to a wide array of charities.


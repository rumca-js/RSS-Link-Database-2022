# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Szczyt ironii". Departament Stanu komentuje słowa Putina
 - [https://tvn24.pl/swiat/wladimir-putin-i-alaksandr-lukaszenka-rozmowy-w-minsku-departament-stanu-usa-slowa-putina-o-tym-ze-rosja-nie-chce-wchlonac-bialorusi-to-szczyt-ironii-6543567?source=rss](https://tvn24.pl/swiat/wladimir-putin-i-alaksandr-lukaszenka-rozmowy-w-minsku-departament-stanu-usa-slowa-putina-o-tym-ze-rosja-nie-chce-wchlonac-bialorusi-to-szczyt-ironii-6543567?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 21:56:25+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8uq4r9-wladimir-putin-6543569/alternates/LANDSCAPE_1280" />
    Rosyjski prezydent spotkał się w Mińsku z Alaksandrem Łukaszenką.

## Koszulki Messiego zniknęły z półek na całym świecie
 - [https://tvn24.pl/biznes/ze-swiata/mundial-2022-koszulki-argentyny-i-messiego-wyprzedane-adidas-zapowiada-produkcje-nowych-koszulek-argentyny-i-messiego-6543504?source=rss](https://tvn24.pl/biznes/ze-swiata/mundial-2022-koszulki-argentyny-i-messiego-wyprzedane-adidas-zapowiada-produkcje-nowych-koszulek-argentyny-i-messiego-6543504?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 21:21:17+00:00

<img alt="Koszulki Messiego zniknęły z półek na całym świecie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-621f6u-mid-epa10372730-6543525/alternates/LANDSCAPE_1280" />
    Rekordowe zainteresowanie piłkarskimi gadżetami.

## Zwęglone zwłoki na fotelu pasażera. Płonące auto widziały dwie kobiety
 - [https://tvn24.pl/polska/lubuskie-zweglone-zwloki-w-spalonym-samochodzie-policja-wyjasnia-okolicznosci-6543402?source=rss](https://tvn24.pl/polska/lubuskie-zweglone-zwloki-w-spalonym-samochodzie-policja-wyjasnia-okolicznosci-6543402?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 21:02:03+00:00

<img alt="Zwęglone zwłoki na fotelu pasażera. Płonące auto widziały dwie kobiety" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1rlrt6-krzeszyce-6543516/alternates/LANDSCAPE_1280" />
    Na razie nie znamy tożsamości i płci tej osoby - informuje policja.

## Zaskakujące głosy z Francji w sprawie Marciniaka
 - [https://eurosport.tvn24.pl/zaskakuj-ce-g-osy-z-francji-w-sprawie-marciniaka,1129979.html?source=rss](https://eurosport.tvn24.pl/zaskakuj-ce-g-osy-z-francji-w-sprawie-marciniaka,1129979.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 20:33:00+00:00

<img alt="Zaskakujące głosy z Francji w sprawie Marciniaka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ps14ts-szymon-marciniak-swietnie-spisal-sie-w-finale-ms-2022-6529413/alternates/LANDSCAPE_1280" />
    Nie wszyscy poddali się narracji "L'Equipe".

## Były szef MSW: Sytuacja pokraczna. Broń się sprawdza
 - [https://tvn24.pl/polska/wybuch-w-komendzie-glownej-policji-co-dalej-z-generalem-jaroslawem-szymczykiem-bartlomiej-sienkiewicz-komentuje-6543328?source=rss](https://tvn24.pl/polska/wybuch-w-komendzie-glownej-policji-co-dalej-z-generalem-jaroslawem-szymczykiem-bartlomiej-sienkiewicz-komentuje-6543328?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 20:22:23+00:00

<img alt="Były szef MSW: Sytuacja pokraczna. Broń się sprawdza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mtolug-kropka-nad-i-6543367/alternates/LANDSCAPE_1280" />
    Bartłomiej Sienkiewicz był gościem "Kropki nad i".

## Wąsek dostał kosztowną nauczkę
 - [https://eurosport.tvn24.pl/w-sek-dosta--kosztown--nauczk----czasem-mog--nas-pogr--y--najg-upsze-rzeczy-,1130025.html?source=rss](https://eurosport.tvn24.pl/w-sek-dosta--kosztown--nauczk----czasem-mog--nas-pogr--y--najg-upsze-rzeczy-,1130025.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 20:20:00+00:00

<img alt="Wąsek dostał kosztowną nauczkę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fffthm-pawel-wasek-w-engelbergu-zostal-zdyskwalifikowany-za-rozpiety-zamek-w-kombinezonie/alternates/LANDSCAPE_1280" />
    "Czasem mogą nas pogrążyć najgłupsze rzeczy".

## W tym kraju Unii Europejskiej mieszka najwięcej bogaczy
 - [https://tvn24.pl/biznes/ze-swiata/zestawienie-10-najbardziej-zamoznych-spoleczenstw-krajow-unii-europejskiej-raport-allianztrade-i-komentarz-johan-geeromsa-6543358?source=rss](https://tvn24.pl/biznes/ze-swiata/zestawienie-10-najbardziej-zamoznych-spoleczenstw-krajow-unii-europejskiej-raport-allianztrade-i-komentarz-johan-geeromsa-6543358?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 19:54:51+00:00

<img alt="W tym kraju Unii Europejskiej mieszka najwięcej bogaczy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aeluxf-holandia-amsterdam-shutterstock1206559006-6543380/alternates/LANDSCAPE_1280" />
    Zestawienie przygotowało Allianz Trade.

## Putin w Mińsku o "podejmowaniu decyzji"
 - [https://tvn24.pl/swiat/bialorus-wladimir-putin-i-alaksandr-lukaszenka-rozmowy-w-minsku-6543368?source=rss](https://tvn24.pl/swiat/bialorus-wladimir-putin-i-alaksandr-lukaszenka-rozmowy-w-minsku-6543368?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 19:38:56+00:00

<img alt="Putin w Mińsku o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-q1dijf-epa10373941-6543375/alternates/LANDSCAPE_1280" />
    Putin i Łukaszenka rozmawiali w poniedziałek.

## "Będziemy domagali się dostępu do tej umowy"
 - [https://tvn24.pl/polska/orlen-fuzja-sprzedaz-czesci-lotosu-gabriela-morawska-stanecka-bedziemy-domagali-sie-dostepu-do-umowy-6543357?source=rss](https://tvn24.pl/polska/orlen-fuzja-sprzedaz-czesci-lotosu-gabriela-morawska-stanecka-bedziemy-domagali-sie-dostepu-do-umowy-6543357?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 19:23:45+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gqp2d1-19-1930-fpf-cl-0018-6543347/alternates/LANDSCAPE_1280" />
    Rozmowa w "Faktach po Faktach" o umowie z Saudi Aramco.

## Austriacy zdemaskowali rosyjskiego agenta
 - [https://tvn24.pl/swiat/austria-kontrwywiad-zdemaskowal-agenta-rosyjskiego-wywiadu-wojskowego-gru-6543158?source=rss](https://tvn24.pl/swiat/austria-kontrwywiad-zdemaskowal-agenta-rosyjskiego-wywiadu-wojskowego-gru-6543158?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 19:17:24+00:00

<img alt="Austriacy zdemaskowali rosyjskiego agenta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3ruoxc-austria-policja-shutterstock2085704569-6543240/alternates/LANDSCAPE_1280" />
    Niemal nie pracował, jeździł po świecie, miał nieruchomości.

## Kubacki zdecydowanym liderem listy płac w Pucharze Świata
 - [https://eurosport.tvn24.pl/kubacki-zdecydowanym-liderem-listy-p-ac-w-pucharze--wiata,1129919.html?source=rss](https://eurosport.tvn24.pl/kubacki-zdecydowanym-liderem-listy-p-ac-w-pucharze--wiata,1129919.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 19:15:00+00:00

<img alt="Kubacki zdecydowanym liderem listy płac w Pucharze Świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s2nltl-dawid-kubacki/alternates/LANDSCAPE_1280" />
    Dawid Kubacki ma powody do zadowolenia.

## "Dziwny stan" Siergieja Szojgu w Mińsku, wcześniej miał być na "linii frontu" w Ukrainie
 - [https://tvn24.pl/swiat/rosja-siergiej-szojgu-w-minsku-ukrainskie-media-pisza-ze-utykal-6543299?source=rss](https://tvn24.pl/swiat/rosja-siergiej-szojgu-w-minsku-ukrainskie-media-pisza-ze-utykal-6543299?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 18:57:02+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6o7pq2-szojgu-drv-6543324/alternates/LANDSCAPE_1280" />
    Mocno utykał i chował prawą rękę w kieszeni, wchodząc do Pałacu Niepodległości w Mińsku - napisał ukraiński portal Obozrewatel.

## Generał Kraszewski: Putin zada Łukaszence pytanie. Odpowiedź będzie wskaźnikiem jego dalszych losów
 - [https://tvn24.pl/swiat/bialorus-rosja-general-jaroslaw-kraszewski-putin-nie-zada-lukaszence-pytania-czy-a-kiedy-6543262?source=rss](https://tvn24.pl/swiat/bialorus-rosja-general-jaroslaw-kraszewski-putin-nie-zada-lukaszence-pytania-czy-a-kiedy-6543262?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 18:48:30+00:00

<img alt="Generał Kraszewski: Putin zada Łukaszence pytanie. Odpowiedź będzie wskaźnikiem jego dalszych losów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ksh7bg-alaksandr-lukaszenka-6162958/alternates/LANDSCAPE_1280" />
    Katarzyna Pełczyńska-Nałęcz i generał Jarosław Kraszewski w "Tak jest" o stosunkach Białorusi z Rosją i możliwym nowym lądowym ataku na Ukrainę.

## Od Afryki, przez Marciniaka, po zmiany. Alfabet mistrzostw świata w Katarze
 - [https://eurosport.tvn24.pl/od-afryki--przez-marciniaka--po-zmiany--alfabet-mistrzostw--wiata-w-katarze,1129971.html?source=rss](https://eurosport.tvn24.pl/od-afryki--przez-marciniaka--po-zmiany--alfabet-mistrzostw--wiata-w-katarze,1129971.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 18:48:00+00:00

<img alt="Od Afryki, przez Marciniaka, po zmiany. Alfabet mistrzostw świata w Katarze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gzn4hr-leo-messi-w-koncu-zostal-mistrzem-swiata/alternates/LANDSCAPE_1280" />
    Czym żyli kibice przez ostatni miesiąc?

## Model filmowego kosmity sprzedany za astronomiczną kwotę
 - [https://tvn24.pl/biznes/ze-swiata/usa-aukcja-icons-and-idols-hollywood-et-sprzedany-za-ponad-25-miliona-dolarow-6543216?source=rss](https://tvn24.pl/biznes/ze-swiata/usa-aukcja-icons-and-idols-hollywood-et-sprzedany-za-ponad-25-miliona-dolarow-6543216?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 18:23:48+00:00

<img alt="Model filmowego kosmity sprzedany za astronomiczną kwotę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vxf7gv-gettyimages-159834412-6543266/alternates/LANDSCAPE_1280" />
    Licytacja rozpoczęła się od 500 tysięcy dolarów.

## PiS chce zmienić kolejność kanałów w telewizji. "Jeżeli ta ustawa wejdzie, rynek się zawali"
 - [https://fakty.tvn24.pl/pis-chce-zmieni--kolejno---kana--w-w-telewizji---je-eli-ta-ustawa-wejdzie--to-po-prostu-rynek-si--zawali-,1130016.html?source=rss](https://fakty.tvn24.pl/pis-chce-zmieni--kolejno---kana--w-w-telewizji---je-eli-ta-ustawa-wejdzie--to-po-prostu-rynek-si--zawali-,1130016.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 18:09:00+00:00

<img alt="PiS chce zmienić kolejność kanałów w telewizji. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-oxgy5b-pis-chce-zmienic-kolejnosc-kanalow-w-telewizji-jezeli-ta-ustawa-wejdzie-to-po-prostu-rynek-sie-zawali/alternates/LANDSCAPE_1280" />
    Ocenia Jerzy Straszewski, prezes zarządu Polskiej Izby Komunikacji Elektronicznej.

## Zdobywca Złotej Piłki nie zagra już w koszulce reprezentacji Francji
 - [https://eurosport.tvn24.pl/karim-benzema-zako-czy--reprezentacyjn--karier--po-straconym-mundialu,1129985.html?source=rss](https://eurosport.tvn24.pl/karim-benzema-zako-czy--reprezentacyjn--karier--po-straconym-mundialu,1129985.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 17:47:00+00:00

<img alt="Zdobywca Złotej Piłki nie zagra już w koszulce reprezentacji Francji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k3mchi-karim-benzema-nie-zagra-juz-w-koszulce-reprezentacji-francji/alternates/LANDSCAPE_1280" />
    Karim Benzema żegna się z kadrą.

## Ustawa o sądownictwie. Premier: teraz jest chaos. Wiceminister: nie przyjmować, bo będzie chaos
 - [https://tvn24.pl/polska/projekt-zmian-w-ustawie-o-sadzie-najwyzszym-i-innych-sadach-premier-mateusz-morawiecki-i-wiceminister-michal-wos-komentuja-6543172?source=rss](https://tvn24.pl/polska/projekt-zmian-w-ustawie-o-sadzie-najwyzszym-i-innych-sadach-premier-mateusz-morawiecki-i-wiceminister-michal-wos-komentuja-6543172?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 17:46:08+00:00

<img alt="Ustawa o sądownictwie. Premier: teraz jest chaos. Wiceminister: nie przyjmować, bo będzie chaos" src="https://tvn24.pl/najnowsze/cdn-zdjecie-twhfmi-mateusz-morawiecki-i-michal-wos-6543295/alternates/LANDSCAPE_1280" />
    Mateusz Morawiecki i Michał Woś o projekcie dotyczącym sądownictwa.

## Szef sztabu sił powietrznych USA w Warszawie
 - [https://tvn24.pl/polska/usa-armia-szef-sztabu-sil-powietrznych-usa-w-warszawie-spotkal-sie-z-polskimi-generalami-6543212?source=rss](https://tvn24.pl/polska/usa-armia-szef-sztabu-sil-powietrznych-usa-w-warszawie-spotkal-sie-z-polskimi-generalami-6543212?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 17:03:06+00:00

<img alt="Szef sztabu sił powietrznych USA w Warszawie" src="https://tvn24.pl/polska/cdn-zdjecie-tylrf5-charles-q-brown-i-jaroslaw-mika-6543215/alternates/LANDSCAPE_1280" />
    Spotkał się z polskimi generałami.

## "Dynamiczna, pochmurna i wietrzna". Co już wiemy o pogodzie na Boże Narodzenie
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-boze-narodzenie-2022-co-nas-czeka-w-swieta-gdzie-pojawia-sie-opady-6543057?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-boze-narodzenie-2022-co-nas-czeka-w-swieta-gdzie-pojawia-sie-opady-6543057?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 16:58:19+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-v1ot7r-pogoda-na-boze-narodzenie-6543095/alternates/LANDSCAPE_1280" />
    Sprawdź szczegóły prognozy na kolejne dni.

## "Mama ma raka, to się nagle okazało". Dorota Szelągowska o chorobie Katarzyny Grocholi
 - [https://tvn24.pl/polska/katarzyna-grochola-jest-chora-mama-ma-raka-to-sie-nagle-okazalo-dorota-szelagowska-o-chorobie-pisarki-6543077?source=rss](https://tvn24.pl/polska/katarzyna-grochola-jest-chora-mama-ma-raka-to-sie-nagle-okazalo-dorota-szelagowska-o-chorobie-pisarki-6543077?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 16:57:18+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xbxjly-katarzyna-grochola-pap202205141ic-6543117/alternates/LANDSCAPE_1280" />
    Fani zwracają uwagę na wideo opublikowane przez pisarkę w mediach społecznościowych.

## 20-letni mężczyzna wyziębił się w chłodni na śmierć
 - [https://tvn24.pl/tvnwarszawa/najnowsze/glinki-mlody-mezczyzna-zamarzl-w-chlodni-6543221?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/glinki-mlody-mezczyzna-zamarzl-w-chlodni-6543221?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 16:56:57+00:00

<img alt="20-letni mężczyzna wyziębił się w chłodni na śmierć" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-s5hzte-do-tragicznego-zdarzenia-doszlo-w-miejscowosci-glinki-6543229/alternates/LANDSCAPE_1280" />
    W miejscowości Glinki koło Otwocka.

## Policjantom powiedział przez telefon, że leży w śniegu i nie może się podnieść. Nie wiedział też, gdzie jest
 - [https://tvn24.pl/tvnwarszawa/najnowsze/sokolow-podlaski-lezal-w-sniegu-i-nie-mogl-sie-podniesc-nie-wiedzial-gdzie-jest-do-poszukiwan-policjanci-wykorzystali-drona-6543043?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/sokolow-podlaski-lezal-w-sniegu-i-nie-mogl-sie-podniesc-nie-wiedzial-gdzie-jest-do-poszukiwan-policjanci-wykorzystali-drona-6543043?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 16:50:30+00:00

<img alt="Policjantom powiedział przez telefon, że leży w śniegu i nie może się podnieść. Nie wiedział też, gdzie jest" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qqdr41-mezczyzna-byl-poszukiwany-przy-pomocy-policyjnego-drona-6543106/alternates/LANDSCAPE_1280" />
    Akcja poszukiwawcza w Sokołowie Podlaskim.

## Świątek odfrunęła rywalce
 - [https://eurosport.tvn24.pl/-wi-tek-odfrun--a-rywalce--pierwsze-zwyci-stwo-w-nowym-turnieju,1129976.html?source=rss](https://eurosport.tvn24.pl/-wi-tek-odfrun--a-rywalce--pierwsze-zwyci-stwo-w-nowym-turnieju,1129976.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 16:42:00+00:00

<img alt="Świątek odfrunęła rywalce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j7ms82-iga-swiatek-jest-liderka-rankingu/alternates/LANDSCAPE_1280" />
    Pierwsze zwycięstwo w nowym turnieju.

## "Siły zbrojne Rosji mają plan ataku na nasz kraj"
 - [https://tvn24.pl/swiat/szef-moldawskiego-wywiadu-alexandru-musteata-sily-zbrojne-rosji-maja-plan-ataku-na-nasz-kraj-6543145?source=rss](https://tvn24.pl/swiat/szef-moldawskiego-wywiadu-alexandru-musteata-sily-zbrojne-rosji-maja-plan-ataku-na-nasz-kraj-6543145?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 16:39:04+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cx9dkv-ukraina-donbas-rosyjscy-zolnierze-sily-samozwanczej-donieckiej-republiki-ludowej-01122022-6304302/alternates/LANDSCAPE_1280" />
    Atak miałby nastąpić na początku 2023 roku.

## Białe święta w Polsce - czy wiecie, kiedy ostatnio tak było? Sprawdziliśmy
 - [https://tvn24.pl/tvnmeteo/polska/snieg-na-swieta-bozego-narodzenia-w-polsce-analiza-opadow-z-lat-1971-2021-6495771?source=rss](https://tvn24.pl/tvnmeteo/polska/snieg-na-swieta-bozego-narodzenia-w-polsce-analiza-opadow-z-lat-1971-2021-6495771?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 16:13:00+00:00

<img alt="Białe święta w Polsce - czy wiecie, kiedy ostatnio tak było? Sprawdziliśmy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nj63ja-snieg2cue-16-fhd-6543018/alternates/LANDSCAPE_1280" />
    Prześledziliśmy dane dotyczące pokrywy śnieżnej w okresie Bożego Narodzenia z ostatniego półwiecza.

## Amber Heard podjęła decyzję w sprawie przeciwko Johnny'emu Deppowi. Po "głębokim namyśle"
 - [https://tvn24.pl/kultura-i-styl/amber-heard-podjela-decyzje-w-sprawie-przeciwko-johnnyemu-deppowi-po-glebokim-namysle-6543146?source=rss](https://tvn24.pl/kultura-i-styl/amber-heard-podjela-decyzje-w-sprawie-przeciwko-johnnyemu-deppowi-po-glebokim-namysle-6543146?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 16:08:40+00:00

<img alt="Amber Heard podjęła decyzję w sprawie przeciwko Johnny'emu Deppowi. Po " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t0l6p1-amber-heard-i-johnny-depp-5732177/alternates/LANDSCAPE_1280" />
    Ogłosiła to w poście na Instagramie.

## Deszcz fajerwerków w Chorwacji? Tak nie świętowano trzeciego miejsca na mundialu
 - [https://konkret24.tvn24.pl/rozrywka/mistrzostwa-swiata-w-katarze-trzecie-miejsce-dla-chorwacji-swietowane-pokazem-fajerwerkow-to-stare-nagranie-6542912?source=rss](https://konkret24.tvn24.pl/rozrywka/mistrzostwa-swiata-w-katarze-trzecie-miejsce-dla-chorwacji-swietowane-pokazem-fajerwerkow-to-stare-nagranie-6542912?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 16:08:00+00:00

<img alt="Deszcz fajerwerków w Chorwacji? Tak nie świętowano trzeciego miejsca na mundialu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3q7ul3-chorwacja-zdobywa-trzecie-miejsce-na-mundialu-6543154/alternates/LANDSCAPE_1280" />
    Nagranie z fajerwerkami powstało na długo przed mistrzostwami w Katarze i dokumentuje inną fetę kibiców w Chorwacji.

## Paroksyzmy wulkanu. Stromboli zaskoczył naukowców
 - [https://tvn24.pl/tvnmeteo/nauka/wulkan-stromboli-przechodzi-przemiane-jego-erupcje-moga-byc-gwaltowne-i-nieprzewidywalne-6542537?source=rss](https://tvn24.pl/tvnmeteo/nauka/wulkan-stromboli-przechodzi-przemiane-jego-erupcje-moga-byc-gwaltowne-i-nieprzewidywalne-6542537?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 16:02:00+00:00

<img alt="Paroksyzmy wulkanu. Stromboli zaskoczył naukowców" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-741du6-wybuch-wulkanu-na-wyspie-stromboli-4968147/alternates/LANDSCAPE_1280" />
    Wszystko było w miarę przewidywalne. Do 2019 roku.

## Limit cen rosyjskiego gazu. Jest porozumienie państw Unii Europejskiej
 - [https://tvn24.pl/biznes/ze-swiata/ue-jest-porozumienie-w-sprawie-limitu-cen-rosyjskiego-gazu-6543149?source=rss](https://tvn24.pl/biznes/ze-swiata/ue-jest-porozumienie-w-sprawie-limitu-cen-rosyjskiego-gazu-6543149?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 15:54:41+00:00

<img alt="Limit cen rosyjskiego gazu. Jest porozumienie państw Unii Europejskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7rs8sg-gaz-gazociag-shutterstock138247598-6149023/alternates/LANDSCAPE_1280" />
    Państwa unijne zgodziły się na rozwiązanie.

## Król Harald V trafił do szpitala. Rodzina poinformowała o stanie jego zdrowia
 - [https://tvn24.pl/swiat/norwegia-krol-norwegii-harald-v-trafil-do-szpitala-6542926?source=rss](https://tvn24.pl/swiat/norwegia-krol-norwegii-harald-v-trafil-do-szpitala-6542926?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 15:29:21+00:00

<img alt="Król Harald V trafił do szpitala. Rodzina poinformowała o stanie jego zdrowia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tsmjgh-pap202209112z4-6542976/alternates/LANDSCAPE_1280" />
    Norweski monarcha ma 85 lat.

## "Państwo holenderskie ponosi odpowiedzialność za ogromne cierpienia"
 - [https://tvn24.pl/swiat/holandia-premier-mark-rutte-przeprosil-za-niewolnictwo-6543019?source=rss](https://tvn24.pl/swiat/holandia-premier-mark-rutte-przeprosil-za-niewolnictwo-6543019?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 15:27:07+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-37sj6m-premier-holandii-mark-rutte-podczas-przemowienia-w-narodowym-archiwum-w-hadze-6543060/alternates/LANDSCAPE_1280" />
    Premier Mark Rutte przeprosił za niewolnictwo.

## Francuzi zrobili w finale aż siedem zmian. Jak to możliwe?
 - [https://eurosport.tvn24.pl/francuzi-zrobili-w-finale-a--siedem-zmian--jak-to-mo-liwe-,1129959.html?source=rss](https://eurosport.tvn24.pl/francuzi-zrobili-w-finale-a--siedem-zmian--jak-to-mo-liwe-,1129959.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 15:08:00+00:00

<img alt="Francuzi zrobili w finale aż siedem zmian. Jak to możliwe?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n3f3wc-kingsley-coman-didier-deschamps/alternates/LANDSCAPE_1280" />
    Niecodzienna sytuacja w finale.

## Drużyna marzeń. Jedenastu najlepszych piłkarzy mundialu
 - [https://eurosport.tvn24.pl/mundial-2022--dru-yna-marze---wybrali-my-jedenastu-najlepszych-pi-karzy-mundialu,1129950.html?source=rss](https://eurosport.tvn24.pl/mundial-2022--dru-yna-marze---wybrali-my-jedenastu-najlepszych-pi-karzy-mundialu,1129950.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 14:56:00+00:00

<img alt="Drużyna marzeń. Jedenastu najlepszych piłkarzy mundialu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cmoqfa-jedenastka-mundialu-w-katarze/alternates/LANDSCAPE_1280" />
    Wybraliśmy.

## Sześć tysięcy skarg po tekście Jeremy’ego Clarksona o Meghan Markle. "Podżeganie do przemocy"
 - [https://tvn24.pl/swiat/wielka-brytania-szesc-tysiecy-skarg-po-tekscie-jeremyego-clarksona-o-meghan-markle-podzeganie-do-przemocy-6542033?source=rss](https://tvn24.pl/swiat/wielka-brytania-szesc-tysiecy-skarg-po-tekscie-jeremyego-clarksona-o-meghan-markle-podzeganie-do-przemocy-6542033?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 14:39:51+00:00

<img alt="Sześć tysięcy skarg po tekście Jeremy’ego Clarksona o Meghan Markle. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-c4hkvf-meghan-markle-6171154/alternates/LANDSCAPE_1280" />
    Dziennikarza potępiła nawet jego córka.

## Znaleziono pociski artyleryjskie. Ewakuacja mieszkańców, saperzy na miejscu
 - [https://tvn24.pl/pomorze/znaleziono-pociski-artyleryjskie-ewakuacja-mieszkancow-saperzy-na-miejscu-6542886?source=rss](https://tvn24.pl/pomorze/znaleziono-pociski-artyleryjskie-ewakuacja-mieszkancow-saperzy-na-miejscu-6542886?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 14:37:31+00:00

<img alt="Znaleziono pociski artyleryjskie. Ewakuacja mieszkańców, saperzy na miejscu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f76so4-saperzy-zabezpieczyli-dziewiec-pociskow-artyleryjskich-6542876/alternates/LANDSCAPE_1280" />
    Jeden z mieszkańców natrafił w wodzie na dziewięć pocisków.

## Wielka fala zatopiła korwetę. Marynarze ratowali się, skacząc prosto do morza
 - [https://tvn24.pl/swiat/tajlandia-zatonela-fregata-htms-sukhothai-zalana-przez-wielka-fale-trwa-akcja-ratunkowa-6540664?source=rss](https://tvn24.pl/swiat/tajlandia-zatonela-fregata-htms-sukhothai-zalana-przez-wielka-fale-trwa-akcja-ratunkowa-6540664?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 14:36:37+00:00

<img alt="Wielka fala zatopiła korwetę. Marynarze ratowali się, skacząc prosto do morza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-84lqss-tajlandzka-korweta-htms-sukhothai-zatonela-6540695/alternates/LANDSCAPE_1280" />
    Nieznany pozostaje los ponad 30 marynarzy HTMS Sukhothai.

## "Diler gwiazd" prawomocnie skazany. Sąd: dostarczał kokainę do klubów, na imprezy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-proces-dilera-gwiazd-prawomocny-wyrok-6542848?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-proces-dilera-gwiazd-prawomocny-wyrok-6542848?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 13:58:40+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-a9xn8e-sad-wydal-wyrok-w-procesie-odwolawczym-cezarego-p-6542941/alternates/LANDSCAPE_1280" />
    Usłyszał wyrok sześciu lat więzienia.

## Eksplozja w Komendzie Głównej Policji. Czy trudno rozpoznać, że granatnik jest naładowany?
 - [https://tvn24.pl/polska/wybuch-w-komendzie-glownej-policji-jak-rozpoznac-naladowany-granatnik-6542577?source=rss](https://tvn24.pl/polska/wybuch-w-komendzie-glownej-policji-jak-rozpoznac-naladowany-granatnik-6542577?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 13:58:21+00:00

<img alt="Eksplozja w Komendzie Głównej Policji. Czy trudno rozpoznać, że granatnik jest naładowany?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7xolss-granatniki-rgw-90-i-rgw-110-matador-6542120/alternates/LANDSCAPE_1280" />
    Gen. Jarosław Szymczyk przywiózł "zużyty granatnik" z Ukrainy.

## Joe Biden obchodził 50. rocznicę tragicznej śmierci żony i córki. Zginęły w wypadku, jadąc po choinkę
 - [https://tvn24.pl/swiat/usa-joe-biden-obchodzil-50-rocznice-tragicznej-smierci-zony-i-corki-zginely-w-wypadku-6542718?source=rss](https://tvn24.pl/swiat/usa-joe-biden-obchodzil-50-rocznice-tragicznej-smierci-zony-i-corki-zginely-w-wypadku-6542718?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 13:32:45+00:00

<img alt="Joe Biden obchodził 50. rocznicę tragicznej śmierci żony i córki. Zginęły w wypadku, jadąc po choinkę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-klwle5-joe-biden-wzial-udzial-w-uroczystosci-upamietniajacej-smierc-zony-i-corki-6541977/alternates/LANDSCAPE_1280" />
    Gdyby nie starania ekipy ratunkowej, "moich chłopców też by nie było".

## "Państwo w komórce". Zapowiedź zmian w rządowej aplikacji
 - [https://tvn24.pl/biznes/z-kraju/mobywatel-oplaty-urzedowe-i-dokumenty-w-aplikacji-adam-andruszkiewicz-wyjasnia-6542836?source=rss](https://tvn24.pl/biznes/z-kraju/mobywatel-oplaty-urzedowe-i-dokumenty-w-aplikacji-adam-andruszkiewicz-wyjasnia-6542836?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 13:30:43+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s1kh4w-1460x616-6542852/alternates/LANDSCAPE_1280" />
    W aplikacji mObywatel.

## Daniel Obajtek o wecie w umowie między Orlenem a Saudi Aramco. Współautor reportażu odpowiada
 - [https://tvn24.pl/polska/daniel-obajtek-pytany-o-projekt-umowy-miedzy-orlenem-a-saudi-aramco-wspolautor-reportazu-odpowiada-na-wypowiedz-prezesa-orlenu-6542776?source=rss](https://tvn24.pl/polska/daniel-obajtek-pytany-o-projekt-umowy-miedzy-orlenem-a-saudi-aramco-wspolautor-reportazu-odpowiada-na-wypowiedz-prezesa-orlenu-6542776?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 13:27:17+00:00

<img alt="Daniel Obajtek o wecie w umowie między Orlenem a Saudi Aramco. Współautor reportażu odpowiada" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4yr643-daniel-obajtek-6542705/alternates/LANDSCAPE_1280" />
    Echa doniesień dziennikarzy "Czarno na białym", którzy ujawnili projekt umowy między Orlenem i Saudi Aramco.

## Kamiński o dymisji komendanta głównego policji
 - [https://tvn24.pl/polska/bedzie-dymisja-generala-jaroslawa-szymczyka-po-wybuchu-w-komendzie-glownej-szef-mswia-mariusz-kaminski-komentuje-6542832?source=rss](https://tvn24.pl/polska/bedzie-dymisja-generala-jaroslawa-szymczyka-po-wybuchu-w-komendzie-glownej-szef-mswia-mariusz-kaminski-komentuje-6542832?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 13:00:23+00:00

<img alt="Kamiński o dymisji komendanta głównego policji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vwdkds-jaroslaw-szymczyk-6509924/alternates/LANDSCAPE_1280" />
    "Wykluczam".

## Kamiński: wykluczam dymisję generała Szymczyka. Premier: analizy doprowadzą do wyciągnięcia wniosków
 - [https://tvn24.pl/polska/bedzie-dymisja-generala-jaroslawa-szymczyka-po-wybuchu-w-komendzie-glownej-szef-mswia-mariusz-kaminski-i-premier-mateusz-morawiecki-komentuja-6542832?source=rss](https://tvn24.pl/polska/bedzie-dymisja-generala-jaroslawa-szymczyka-po-wybuchu-w-komendzie-glownej-szef-mswia-mariusz-kaminski-i-premier-mateusz-morawiecki-komentuja-6542832?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 13:00:23+00:00

<img alt="Kamiński: wykluczam dymisję generała Szymczyka. Premier: analizy doprowadzą do wyciągnięcia wniosków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vwdkds-jaroslaw-szymczyk-6509924/alternates/LANDSCAPE_1280" />
    Szef MSWiA, premier i rzecznik rządu o przyszłości generała Szymczyka.

## Oceniono wszystkie mecze mundialu. W najgorszym grali Polacy
 - [https://eurosport.tvn24.pl/oceniono-wszystkie-mecze-mundialu--w-najgorszym-grali-polacy,1129942.html?source=rss](https://eurosport.tvn24.pl/oceniono-wszystkie-mecze-mundialu--w-najgorszym-grali-polacy,1129942.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 12:46:07+00:00

<img alt="Oceniono wszystkie mecze mundialu. W najgorszym grali Polacy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ndjxiw-na-inauguracje-mundialu-polska-bezbramkowo-zremisowala-z-meksykiem-6542814/alternates/LANDSCAPE_1280" />
    Dziennikarze The Athletic stworzyli ranking spotkań mistrzostw świata w Katarze.

## Coraz więcej przypadków "samotnej śmierci". Dotyczą głównie mężczyzn w średnim i starszym wieku
 - [https://tvn24.pl/swiat/korea-poludniowa-samotna-smierc-dotyka-coraz-wiecej-osob-szczegolnie-zagrozeni-mezczyzni-w-srednim-i-starszym-wieku-6540934?source=rss](https://tvn24.pl/swiat/korea-poludniowa-samotna-smierc-dotyka-coraz-wiecej-osob-szczegolnie-zagrozeni-mezczyzni-w-srednim-i-starszym-wieku-6540934?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 12:08:07+00:00

<img alt="Coraz więcej przypadków " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ixv0b1-samotny-mezczyzna-6542721/alternates/LANDSCAPE_1280" />
    Umierają samotnie, a ich ciała są odnajdowane po dłuższym czasie.

## Zawiadomienie i wniosek o kontrolę NIK. "To już nie są znaki zapytania, to bardzo konkretne zarzuty"
 - [https://tvn24.pl/najnowsze/umowa-orlenu-z-saudi-aramco-w-sprawie-lotosu-ustalenia-dziennikarzy-tvn24-politycy-komentuja-sa-kolejne-zawiadomienia-6542083?source=rss](https://tvn24.pl/najnowsze/umowa-orlenu-z-saudi-aramco-w-sprawie-lotosu-ustalenia-dziennikarzy-tvn24-politycy-komentuja-sa-kolejne-zawiadomienia-6542083?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 11:58:44+00:00

<img alt="Zawiadomienie i wniosek o kontrolę NIK. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tpggzr-rafineria-gdanska-6510147/alternates/LANDSCAPE_1280" />
    Politycy komentują doniesienia dziennikarzy "Czarno na białym", którzy ujawnili projekt umowy między Orlenem i Saudi Aramco.

## Zawiadomienie i wniosek o kontrolę NIK. "To już nie są znaki zapytania, to bardzo konkretne zarzuty"
 - [https://tvn24.pl/polska/umowa-orlenu-z-saudi-aramco-w-sprawie-lotosu-ustalenia-dziennikarzy-tvn24-politycy-komentuja-sa-kolejne-zawiadomienia-6542083?source=rss](https://tvn24.pl/polska/umowa-orlenu-z-saudi-aramco-w-sprawie-lotosu-ustalenia-dziennikarzy-tvn24-politycy-komentuja-sa-kolejne-zawiadomienia-6542083?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 11:58:44+00:00

<img alt="Zawiadomienie i wniosek o kontrolę NIK. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tpggzr-rafineria-gdanska-6510147/alternates/LANDSCAPE_1280" />
    Politycy komentują doniesienia dziennikarzy "Czarno na białym", którzy ujawnili projekt umowy między Orlenem i Saudi Aramco.

## Komentator z Argentyny nie wytrzymał. Nagranie
 - [https://eurosport.tvn24.pl/do-wiadczony-komentator-z-argentyny-nie-wytrzyma---wielka-rado---i-wzruszenie,1129946.html?source=rss](https://eurosport.tvn24.pl/do-wiadczony-komentator-z-argentyny-nie-wytrzyma---wielka-rado---i-wzruszenie,1129946.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 11:38:00+00:00

<img alt="Komentator z Argentyny nie wytrzymał. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g5zc59-argentyna-mistrzem-swiata/alternates/LANDSCAPE_1280" />
    "Argentyna jest mistrzem świata. Messi jest mistrzem świata. Nie mogło być inaczej!"

## Zdobył Nagrodę Nobla. Dwa miesiące później studentki oskarżyły go o molestowanie
 - [https://tvn24.pl/swiat/nagroda-nobla-philip-dybvig-noblista-z-ekonomii-oskarzany-o-molestowanie-seksualne-6541607?source=rss](https://tvn24.pl/swiat/nagroda-nobla-philip-dybvig-noblista-z-ekonomii-oskarzany-o-molestowanie-seksualne-6541607?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 11:35:12+00:00

<img alt="Zdobył Nagrodę Nobla. Dwa miesiące później studentki oskarżyły go o molestowanie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n6sql8-philip-dybvig-6540616/alternates/LANDSCAPE_1280" />
    O sprawie poinformował "Bloomberg".

## Reaktor atomowy pośrodku niczego? Pojechaliśmy to "nic" obejrzeć z bliska
 - [https://tvn24.pl/premium/choczewo-pierwszy-w-polsce-reaktor-ma-stanac-posrodku-niczego-pojechalismy-to-nic-obejrzec-z-bliska-6508031?source=rss](https://tvn24.pl/premium/choczewo-pierwszy-w-polsce-reaktor-ma-stanac-posrodku-niczego-pojechalismy-to-nic-obejrzec-z-bliska-6508031?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 11:29:18+00:00

<img alt="Reaktor atomowy pośrodku niczego? Pojechaliśmy to " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wkp5rq-wojt-choczewa-wskazuje-lokalizacje-przyszlej-elektrowni-6412164/alternates/LANDSCAPE_1280" />
    Tam, gdzie ma stanąć reaktor, nie ma nic, jest tylko... las. Jak wygląda "tylko las"? Razem z fotografem spotkamy najeżonego chrobotka, pęcherzykowatą pustułkę i otrębiastego mąklika. I jeszcze młodego mężczyznę na quadzie, i trzech starszych panów pod sklepem spożywczym.

## Spielberg żałuje tego, do czego doprowadził jego słynny film. "Manipulowałem widzami"
 - [https://tvn24.pl/swiat/film-szczeki-zdziesiatkowal-liczbe-rekinow-steven-spielberg-bardzo-tego-zaluje-6538156?source=rss](https://tvn24.pl/swiat/film-szczeki-zdziesiatkowal-liczbe-rekinow-steven-spielberg-bardzo-tego-zaluje-6538156?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 11:29:03+00:00

<img alt="Spielberg żałuje tego, do czego doprowadził jego słynny film. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-0v1aze-en000340070001-6540613/alternates/LANDSCAPE_1280" />
    Reżyser w rozmowie z BBC zabrał głos w sprawie produkcji z 1975 roku.

## "Jak w czasach II wojny światowej". Doradca Zełenskiego o planach Rosjan
 - [https://tvn24.pl/swiat/ukraina-doradca-wolodymyra-zelenskiego-mychajlo-podolak-rosjanie-planuja-zmasowane-ataki-piechoty-6541691?source=rss](https://tvn24.pl/swiat/ukraina-doradca-wolodymyra-zelenskiego-mychajlo-podolak-rosjanie-planuja-zmasowane-ataki-piechoty-6541691?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 11:27:01+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wqur1r-ukraina-cywile-zimno-zima-ludzie-zniszczenia-bachmut-donbas-donieck-rosja-08122022-6431594/alternates/LANDSCAPE_1280" />
    Moskwa nie jest zainteresowana zakończeniem wojny - ocenił Mychajło Podolak.

## Jeden peron zamknięty, duże utrudnienia dla pasażerów
 - [https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-utrudnienia-na-linii-srednicowej-dlaczego-jakie-utrudnienia-honorowanie-biletow-6542049?source=rss](https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-utrudnienia-na-linii-srednicowej-dlaczego-jakie-utrudnienia-honorowanie-biletow-6542049?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 11:22:49+00:00

<img alt="Jeden peron zamknięty, duże utrudnienia dla pasażerów " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-e0oe1l-utrudnienia-w-kursowaniu-pociagow-w-warszawie-6542076/alternates/LANDSCAPE_1280" />
    Opóźnione pociągi i zdezorientowani pasażerowie.

## "Najdroższe Boże Narodzenie w tym wieku". Ceny żywności uderzą po kieszeniach
 - [https://tvn24.pl/biznes/z-kraju/boze-narodzenie-2023-ceny-zywnosci-przed-swietami-o-23-proc-wyzsze-niz-przed-rokiem-6541599?source=rss](https://tvn24.pl/biznes/z-kraju/boze-narodzenie-2023-ceny-zywnosci-przed-swietami-o-23-proc-wyzsze-niz-przed-rokiem-6541599?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 11:13:55+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e268zx-wigilia-bozego-narodzenia-oplatek-5517930/alternates/LANDSCAPE_1280" />
    Analiza.

## Boże Narodzenie w czasie inflacji. Ile zapłaciliście za karpia?
 - [https://kontakt24.tvn24.pl/boze-narodzenie-w-czasie-inflacji-ile-kosztowal-was-karp,1527,gt?source=rss](https://kontakt24.tvn24.pl/boze-narodzenie-w-czasie-inflacji-ile-kosztowal-was-karp,1527,gt?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 10:59:58+00:00

<img alt="Boże Narodzenie w czasie inflacji. Ile zapłaciliście za karpia?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vztu8y-ceny-karpia-powedrowaly-w-gore-6542109/alternates/LANDSCAPE_1280" />
    Na Wasze wpisy i zdjęcia czekamy w naszym gorącym temacie.

## Wiceburmistrz znieważył publicznie premiera. Jest wyrok
 - [https://tvn24.pl/katowice/cieszyn-wiceburmistrz-cieszyna-przemyslaw-major-zniewazyl-publicznie-premiera-jest-wyrok-sadu-6541442?source=rss](https://tvn24.pl/katowice/cieszyn-wiceburmistrz-cieszyna-przemyslaw-major-zniewazyl-publicznie-premiera-jest-wyrok-sadu-6541442?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 10:36:31+00:00

<img alt="Wiceburmistrz znieważył publicznie premiera. Jest wyrok " src="https://tvn24.pl/krakow/cdn-zdjecie-ml5uea-wiceburmistrz-cieszyna-przemyslaw-major-6541524/alternates/LANDSCAPE_1280" />
    "Przyjmuję, że moja wypowiedź mogła urazić oznaczone osoby i instytucje" - skomentował samorządowiec w mediach społecznościowych.

## Emocjonalny wpis żony Messiego. "Wiemy, ile wycierpiałeś przez tyle lat"
 - [https://eurosport.tvn24.pl/emocjonalny-wpis--ony-messiego---wiemy--ile-wycierpia-e--przez-tyle-lat-,1129938.html?source=rss](https://eurosport.tvn24.pl/emocjonalny-wpis--ony-messiego---wiemy--ile-wycierpia-e--przez-tyle-lat-,1129938.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 10:30:00+00:00

<img alt="Emocjonalny wpis żony Messiego. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-i894cy-argentyna-mistrzem-swiata/alternates/LANDSCAPE_1280" />
    Zdobywając mistrzostwo świata z Argentyną, spełnił swoje największe piłkarskie marzenie. Długo na to czekał.

## Odkryto dwie kuzynki Ziemi. Znajdują się zaledwie 16 lat świetlnych od Układu Słonecznego
 - [https://tvn24.pl/tvnmeteo/nauka/egzoplanety-podobne-do-ziemi-odkryte-stosunkowo-blisko-nas-moga-nadawac-sie-do-zamieszkania-6540691?source=rss](https://tvn24.pl/tvnmeteo/nauka/egzoplanety-podobne-do-ziemi-odkryte-stosunkowo-blisko-nas-moga-nadawac-sie-do-zamieszkania-6540691?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 10:21:22+00:00

<img alt="Odkryto dwie kuzynki Ziemi. Znajdują się zaledwie 16 lat świetlnych od Układu Słonecznego" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-0l3z4y-planety-krazace-dookola-gj-1002-wizja-artystyczna-6541059/alternates/LANDSCAPE_1280" />
    Wraz z rozwojem technik obserwacyjnych i pomiarowych dowiadujemy się coraz więcej o egzoplanetach - planetach położonych poza Układem Słonecznym.

## Założyli Messiemu tradycyjny strój. Kibice zaskoczeni
 - [https://eurosport.tvn24.pl/messi--wi-towa--mistrzostwo--wiata-w-katarskim-p-aszczu---celem-by-o-pokazanie-bogactwa-naszej-kultury-,1129934.html?source=rss](https://eurosport.tvn24.pl/messi--wi-towa--mistrzostwo--wiata-w-katarskim-p-aszczu---celem-by-o-pokazanie-bogactwa-naszej-kultury-,1129934.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 10:13:00+00:00

<img alt="Założyli Messiemu tradycyjny strój. Kibice zaskoczeni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nlyvbf-lionel-messi-odebral-puchar-swiata-w-tradycyjnym-katarskim-plaszczu/alternates/LANDSCAPE_1280" />
    Wyjaśniamy czym jest biszt, który miał na sobie Lionel Messi, odbierając Puchar Świata.

## PSL kontra PiS: kiedy sprzedano więcej ziemi cudzoziemcom? Liczby mówią wszystko
 - [https://konkret24.tvn24.pl/polityka/psl-kontra-pis-kiedy-sprzedano-wiecej-ziemi-cudzoziemcomliczby-mowia-wszystko-6509984?source=rss](https://konkret24.tvn24.pl/polityka/psl-kontra-pis-kiedy-sprzedano-wiecej-ziemi-cudzoziemcomliczby-mowia-wszystko-6509984?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 10:04:03+00:00

<img alt="PSL kontra PiS: kiedy sprzedano więcej ziemi cudzoziemcom? Liczby mówią wszystko " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-a1wlr3-henryk-kowalczyk-6458580/alternates/LANDSCAPE_1280" />
    Politycy PiS i PSL - walcząc o głosy wyborców na wsi - spierają się, kto lepiej chroni polską ziemię.

## Najnowsze dane o zakażeniach koronawirusem
 - [https://tvn24.pl/polska/koronawirus-w-polsce-mapa-zakazen-ile-szczepien-ile-nowych-przypadkow-wykryto-19-grudnia-2022-4344739?source=rss](https://tvn24.pl/polska/koronawirus-w-polsce-mapa-zakazen-ile-szczepien-ile-nowych-przypadkow-wykryto-19-grudnia-2022-4344739?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 10:00:00+00:00

<img alt="Najnowsze dane o zakażeniach koronawirusem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4ufkih-covid-dzienny-bilans-6541434/alternates/LANDSCAPE_1280" />
    Mapa zakażeń.

## Zmiany dla pracowników. Nowy wzór PIT-2
 - [https://tvn24.pl/biznes/dla-pracownika/pit-2-dla-pracownikow-nowy-wzor-od-poczatku-2023-roku-6540913?source=rss](https://tvn24.pl/biznes/dla-pracownika/pit-2-dla-pracownikow-nowy-wzor-od-poczatku-2023-roku-6540913?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 09:57:39+00:00

<img alt="Zmiany dla pracowników. Nowy wzór PIT-2" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9tphws-biuro-biurowiec-praca-okna-okno-shutterstock524094316-1-5710300/alternates/LANDSCAPE_1280" />
    Od początku 2023 roku.

## "Brutalna taktyka" wagnerowców, "zbędni skazańcy rekruci"
 - [https://tvn24.pl/swiat/ukraina-brytyjski-resort-obrony-grupa-wagnera-posyla-do-walki-wiezniow-bez-przeszkolenia-i-wsparcia-6541369?source=rss](https://tvn24.pl/swiat/ukraina-brytyjski-resort-obrony-grupa-wagnera-posyla-do-walki-wiezniow-bez-przeszkolenia-i-wsparcia-6541369?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 09:50:01+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vljz5y-ukraina-donbas-rosyjscy-zolnierze-sily-samozwanczej-donieckiej-republiki-ludowej-01122022-6304301/alternates/LANDSCAPE_1280" />
    Brytyjski resort obrony o sytuacji na ukraińskim froncie.

## Tomasz Listkiewicz o kulisach finału mundialu
 - [https://eurosport.tvn24.pl/-najwa-niejsze-decyzje-by-y-prawid-owe---tomasz-listkiewicz-o-kulisach-fina-u-mundialu,1129927.html?source=rss](https://eurosport.tvn24.pl/-najwa-niejsze-decyzje-by-y-prawid-owe---tomasz-listkiewicz-o-kulisach-fina-u-mundialu,1129927.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 09:30:00+00:00

<img alt="Tomasz Listkiewicz o kulisach finału mundialu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5q7izl-tomasz-listkiewicz-byl-sedzia-w-finale-mundialu/alternates/LANDSCAPE_1280" />
    Polski sędzia w rozmowie z TVN24.

## Ktoś zostawił przed domem paczkę, przy otwieraniu wybuchła. Ranne trzy osoby
 - [https://tvn24.pl/poznan/siecieborzyce-wybuch-pakunku-ktory-ktos-zostawil-przed-domem-ranne-trzy-osoby-w-tym-dwoje-dzieci-6541131?source=rss](https://tvn24.pl/poznan/siecieborzyce-wybuch-pakunku-ktory-ktos-zostawil-przed-domem-ranne-trzy-osoby-w-tym-dwoje-dzieci-6541131?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 09:12:23+00:00

<img alt="Ktoś zostawił przed domem paczkę, przy otwieraniu wybuchła. Ranne trzy osoby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ueaktg-nie-zyje-dwoch-nastolatkow-6238963/alternates/LANDSCAPE_1280" />
    Wśród rannych jest dwoje dzieci.

## Prawie 1,5 tysiąca prób samobójczych. "Jesteśmy na drugim miejscu w Europie"
 - [https://tvn24.pl/polska/raport-fundacji-dajemy-dzieciom-sile-przemoc-rowiesnicza-wiktymizacja-wsrod-dzieci-proby-samobojcze-6540662?source=rss](https://tvn24.pl/polska/raport-fundacji-dajemy-dzieciom-sile-przemoc-rowiesnicza-wiktymizacja-wsrod-dzieci-proby-samobojcze-6540662?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 09:06:00+00:00

<img alt="Prawie 1,5 tysiąca prób samobójczych. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-jj9mz3-depresja-dotyka-coraz-wiecej-mlodych-brytyjczykow-4206836/alternates/LANDSCAPE_1280" />
    Raport Fundacji "Dajemy Dzieciom Siłę" o zagrożeniach bezpieczeństwa i rozwoju dzieci.

## Ich samochód spadł w niemal stumetrową przepaść. Żyją dzięki sygnałowi z telefonu
 - [https://tvn24.pl/swiat/usa-w-wyniku-wypadku-w-gorach-samochod-stoczyl-sie-w-przepasc-telefon-wezwal-sluzby-ratunkowe-6540639?source=rss](https://tvn24.pl/swiat/usa-w-wyniku-wypadku-w-gorach-samochod-stoczyl-sie-w-przepasc-telefon-wezwal-sluzby-ratunkowe-6540639?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 08:57:44+00:00

<img alt="Ich samochód spadł w niemal stumetrową przepaść. Żyją dzięki sygnałowi z telefonu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q51puy-samochod-cloe-fields-i-christiana-zelady-po-wypadku-6540668/alternates/LANDSCAPE_1280" />
    Para podróżowała górską krętą drogą, do wypadku doszło podczas wyprzedzania.

## Jak kupić dobry prezent na kilka dni przed świętami?
 - [https://tvn24.pl/ciekawostki/boze-narodzenie-2022-jak-wybrac-prezent-w-ostatniej-chwili-podarunki-dostosowane-do-osobowosci-6529447?source=rss](https://tvn24.pl/ciekawostki/boze-narodzenie-2022-jak-wybrac-prezent-w-ostatniej-chwili-podarunki-dostosowane-do-osobowosci-6529447?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 08:54:32+00:00

<img alt="Jak kupić dobry prezent na kilka dni przed świętami?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iv4ssc-choinka-swieta-prezent-prezenty-shutterstock1165332937s-5477138/alternates/LANDSCAPE_1280" />
    Warto zastanowić się nad cechami charakteru osoby, którą chcemy obdarować.

## Musk zapytał, czy ma dalej kierować Twitterem. "Zastosuję się do wyników głosowania"
 - [https://tvn24.pl/biznes/ze-swiata/elon-musk-twitter-musk-zapytal-czy-ma-dalej-kierowac-platforma-ankieta-na-twitterze-6540680?source=rss](https://tvn24.pl/biznes/ze-swiata/elon-musk-twitter-musk-zapytal-czy-ma-dalej-kierowac-platforma-ankieta-na-twitterze-6540680?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 08:29:30+00:00

<img alt="Musk zapytał, czy ma dalej kierować Twitterem. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pqlauz-elon-musk-5525569/alternates/LANDSCAPE_1280" />
    Oddano już ponad 14 milionów głosów.

## Szokująca ocena Francuzów dla Marciniaka. Najgorszy
 - [https://eurosport.tvn24.pl/szokuj-ca-ocena-francuz-w-dla-marciniaka--najgorszy,1129910.html?source=rss](https://eurosport.tvn24.pl/szokuj-ca-ocena-francuz-w-dla-marciniaka--najgorszy,1129910.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 08:29:00+00:00

<img alt="Szokująca ocena Francuzów dla Marciniaka. Najgorszy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xs0lzj-szymon-marciniak-byl-sedzia-finalu-mundialu-w-katarze/alternates/LANDSCAPE_1280" />
    Według znanego francuskiego dziennika "L'Equipe".

## Zwroty akcji, grad goli, morze łez i finał jak z bajki. Mundial na stu zdjęciach
 - [https://tvn24.pl/swiat/mundial-2022-w-katarze-najlepsze-zdjecia-z-mistrzostw-swiata-6528919?source=rss](https://tvn24.pl/swiat/mundial-2022-w-katarze-najlepsze-zdjecia-z-mistrzostw-swiata-6528919?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 08:10:00+00:00

<img alt="Zwroty akcji, grad goli, morze łez i finał jak z bajki. Mundial na stu zdjęciach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5rtwpl-pilka-al-rihla-w-jezyku-arabskim-oznacza-podroz-na-tle-drapaczy-chmur-w-dosze-6540663/alternates/LANDSCAPE_1280" />
    Tak zapamiętamy mistrzostwa w Katarze.

## Niebezpieczna okiść. Zakaz wstępu do lasu
 - [https://tvn24.pl/tvnmeteo/polska/lubelskie-zakaz-wstepu-do-lasu-przyczyna-jest-okisc-6540622?source=rss](https://tvn24.pl/tvnmeteo/polska/lubelskie-zakaz-wstepu-do-lasu-przyczyna-jest-okisc-6540622?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 08:08:37+00:00

<img alt="Niebezpieczna okiść. Zakaz wstępu do lasu" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-fe4tbc-snieg-okisc-w-lasach-6540623/alternates/LANDSCAPE_1280" />
    Na Lubelszczyźnie.

## Na przejeździe kolejowym zginęła 17-latka, wcześniej dwie osoby. Dodatkowych zabezpieczeń na razie nie będzie
 - [https://tvn24.pl/krakow/wierzawice-na-przejezdzie-kolejowym-zginela-17-latka-wczesniej-dwie-osoby-dodatkowych-zabezpieczen-na-razie-nie-bedzie-6509039?source=rss](https://tvn24.pl/krakow/wierzawice-na-przejezdzie-kolejowym-zginela-17-latka-wczesniej-dwie-osoby-dodatkowych-zabezpieczen-na-razie-nie-bedzie-6509039?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 08:06:50+00:00

<img alt="Na przejeździe kolejowym zginęła 17-latka, wcześniej dwie osoby. Dodatkowych zabezpieczeń na razie nie będzie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9zyq2l-wypadek-na-przejezdzie-kolejowym-w-wierzawicach-kolo-lezajska-6443165/alternates/LANDSCAPE_1280" />
    Mogą się pojawić po 2023 roku.

## "Nowa faza". Analitycy ostrzegają
 - [https://tvn24.pl/swiat/rosja-ukraina-wizyta-putina-na-bialorusi-szojgu-na-froncie-analiza-isw-6540649?source=rss](https://tvn24.pl/swiat/rosja-ukraina-wizyta-putina-na-bialorusi-szojgu-na-froncie-analiza-isw-6540649?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 08:01:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6cjovw-general-siergiej-surowikin-i-minister-obrony-siergiej-szojgu-6528579/alternates/LANDSCAPE_1280" />
    Najnowsze opracowanie Instytutu Studiów nad Wojną.

## Macron dumny z piłkarzy. "Sprawili, że marzyliśmy"
 - [https://eurosport.tvn24.pl/prezydent-macron-dumny-z-francuskich-pi-karzy---sprawili---e-marzyli-my-,1129900.html?source=rss](https://eurosport.tvn24.pl/prezydent-macron-dumny-z-francuskich-pi-karzy---sprawili---e-marzyli-my-,1129900.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 07:45:00+00:00

<img alt="Macron dumny z piłkarzy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qkxbq2-prezydent-emmanuel-macron-dumny-z-francuskich-pilkarzy/alternates/LANDSCAPE_1280" />
    Prezydent Francji docenił ich trud, wysiłek oraz wolę walki.

## "Wróg atakuje stolicę dronami Shahed. Obrona przeciwlotnicza działa"
 - [https://tvn24.pl/swiat/kijow-atak-rosjan-ukraincy-zestrzelili-iranskie-drony-6539888?source=rss](https://tvn24.pl/swiat/kijow-atak-rosjan-ukraincy-zestrzelili-iranskie-drony-6539888?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 07:28:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cj8786-pograzone-w-ciemnosciach-ulice-w-kijowie-po-rosyjskim-ataku-rakietowym-na-ukrainska-infrastrukture-energetyczna-6253175/alternates/LANDSCAPE_1280" />
    Nad ranem poinformowano o serii wybuchów w Kijowie i okolicach.

## Jechał ze znakiem wbitym w reflektor. Policja: twierdził, że nic się nie stało
 - [https://tvn24.pl/bialystok/bialystok-jechal-ze-znakiem-wbitym-w-reflektor-policja-twierdzil-ze-nic-sie-nie-stalo-24-latek-byl-pijany-6540615?source=rss](https://tvn24.pl/bialystok/bialystok-jechal-ze-znakiem-wbitym-w-reflektor-policja-twierdzil-ze-nic-sie-nie-stalo-24-latek-byl-pijany-6540615?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 07:23:36+00:00

<img alt="Jechał ze znakiem wbitym w reflektor. Policja: twierdził, że nic się nie stało " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gics78-auto-mialo-znak-drogowy-wbity-w-reflektor-6540611/alternates/LANDSCAPE_1280" />
    W Białymstoku.

## "Dwie zużyte, puste tuby". Co przywiózł komendant Szymczyk, co eksplodowało
 - [https://tvn24.pl/polska/co-wybuchlo-w-kgp-general-jaroslaw-szymczyk-o-eksplozji-w-komendzie-glownej-policji-i-prezentach-z-ukrainy-6540612?source=rss](https://tvn24.pl/polska/co-wybuchlo-w-kgp-general-jaroslaw-szymczyk-o-eksplozji-w-komendzie-glownej-policji-i-prezentach-z-ukrainy-6540612?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 07:22:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-97tuo0-pap2022022616s-6540617/alternates/LANDSCAPE_1280" />
    Komendant główny policji Jarosław Szymczyk o wydarzeniach związanych z wybuchem w Komendzie Głównej Policji.

## Szef policji z opatrunkiem na uchu: Nie zamierzam podawać się do dymisji. Lepsze memy niż nekrologi
 - [https://tvn24.pl/polska/co-wybuchlo-w-kgp-general-jaroslaw-szymczyk-o-eksplozji-w-komendzie-glownej-policji-prezentach-z-ukrainy-i-ewentualnej-dymisji-6540612?source=rss](https://tvn24.pl/polska/co-wybuchlo-w-kgp-general-jaroslaw-szymczyk-o-eksplozji-w-komendzie-glownej-policji-prezentach-z-ukrainy-i-ewentualnej-dymisji-6540612?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 07:22:00+00:00

<img alt="Szef policji z opatrunkiem na uchu: Nie zamierzam podawać się do dymisji. Lepsze memy niż nekrologi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s8frw0-general-jaroslaw-szymczyk-6543520/alternates/LANDSCAPE_1280" />
    Komendant główny policji Jarosław Szymczyk opowiedział o okolicznościach wybuchu w KGP.

## Popularna sieć ostrzega przed produktem. "Istnieje ryzyko pęknięcia goleni"
 - [https://tvn24.pl/biznes/z-kraju/decathlon-rowery-rockrider-xc-500s-mtb-kod-modelu-8614814-ostrzezenie-6540553?source=rss](https://tvn24.pl/biznes/z-kraju/decathlon-rowery-rockrider-xc-500s-mtb-kod-modelu-8614814-ostrzezenie-6540553?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 07:15:59+00:00

<img alt="Popularna sieć ostrzega przed produktem. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-n6ilbn-decathlon-sklep-5461344/alternates/LANDSCAPE_1280" />
    Klienci są proszeni o zaprzestanie z korzystania.

## "PiS przewraca się o własne nogi i to jest najbardziej spektakularne"
 - [https://tvn24.pl/polska/kpo-a-projekt-zmian-w-sadownictwie-robert-biedron-pis-przewraca-sie-o-wlasne-nogi-6540582?source=rss](https://tvn24.pl/polska/kpo-a-projekt-zmian-w-sadownictwie-robert-biedron-pis-przewraca-sie-o-wlasne-nogi-6540582?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 07:08:03+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gtd4wa-1n1-6540593/alternates/LANDSCAPE_1280" />
    Europoseł Lewicy Robert Biedroń w "Rozmowie Piaseckiego" w TVN24.

## Trener Francji: wróciliśmy znad krawędzi, dlatego tak bardzo żałujemy
 - [https://eurosport.tvn24.pl/trener-francji--wr-cili-my-znad-kraw-dzi--dlatego-tak-bardzo--a-ujemy,1129915.html?source=rss](https://eurosport.tvn24.pl/trener-francji--wr-cili-my-znad-kraw-dzi--dlatego-tak-bardzo--a-ujemy,1129915.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 07:03:00+00:00

<img alt="Trener Francji: wróciliśmy znad krawędzi, dlatego tak bardzo żałujemy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qsyl96-didier-deschamps/alternates/LANDSCAPE_1280" />
    Didier Deschamps nie ukrywał rozgoryczenia po przegranym z Argentyną w rzutach karnych finale mundialu.

## Moskwa sparaliżowana przez śnieg. Piesi torowali sobie drogi przez zaspy
 - [https://tvn24.pl/tvnmeteo/swiat/rosja-rekordowe-opady-sniegu-paraliz-komunikacyjny-6540551?source=rss](https://tvn24.pl/tvnmeteo/swiat/rosja-rekordowe-opady-sniegu-paraliz-komunikacyjny-6540551?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 06:56:34+00:00

<img alt="Moskwa sparaliżowana przez śnieg. Piesi torowali sobie drogi przez zaspy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ju4px9-rekordowe-opady-sniegu-w-moskwie-6540555/alternates/LANDSCAPE_1280" />
    Tak obfitych opadów śniegu w grudniu nie było tu od lat 40.

## Publikował "bluźniercze komunikaty". Watykan podjął decyzję w sprawie księdza
 - [https://tvn24.pl/swiat/usa-ksiadz-frank-pavone-aktywista-antyaborcyjny-usuniety-ze-stanu-duchownego-decyzja-watykanu-6537633?source=rss](https://tvn24.pl/swiat/usa-ksiadz-frank-pavone-aktywista-antyaborcyjny-usuniety-ze-stanu-duchownego-decyzja-watykanu-6537633?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 06:46:00+00:00

<img alt="Publikował " src="https://tvn24.pl/najnowsze/cdn-zdjecie-zsc8tp-gettyimages-1241385266-6540594/alternates/LANDSCAPE_1280" />
    Ksiądz Frank Pavone usunięty ze stanu duchownego - informuje Reuters.

## Auto wbiło się w tira na S8. Kierowca nie żyje
 - [https://tvn24.pl/tvnwarszawa/ulice/trasa-s8-w-markach-auto-uderzylo-w-tyl-ciezarowki-kierowca-nie-zyje-6540545?source=rss](https://tvn24.pl/tvnwarszawa/ulice/trasa-s8-w-markach-auto-uderzylo-w-tyl-ciezarowki-kierowca-nie-zyje-6540545?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 06:43:25+00:00

<img alt="Auto wbiło się w tira na S8. Kierowca nie żyje" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ddgbtw-smiertelny-wypadek-na-trasie-s8-6540543/alternates/LANDSCAPE_1280" />
    Policja wyjaśnia okoliczności wypadku.

## Fascynacja poziomem, zachwyty nad Messim. Reakcje po finale mundialu
 - [https://eurosport.tvn24.pl/fascynacja-poziomem--zachwyty-nad-messim--reakcje-po-finale-mundialu,1129882.html?source=rss](https://eurosport.tvn24.pl/fascynacja-poziomem--zachwyty-nad-messim--reakcje-po-finale-mundialu,1129882.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 06:30:00+00:00

<img alt="Fascynacja poziomem, zachwyty nad Messim. Reakcje po finale mundialu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kp004r-argentyna-zostala-pilkarskim-mistrzem-swiata-6540590/alternates/LANDSCAPE_1280" />
    Reakcja świata piłki nożnej po mundialu.

## Kiedy spuszczasz wodę w toalecie, zamykaj klapę. Ten film pokaże ci, dlaczego warto
 - [https://tvn24.pl/tvnmeteo/swiat/kiedy-spuszczasz-wode-w-toalecie-zamykaj-klape-ten-film-pokaze-ci-dlaczego-warto-6529423?source=rss](https://tvn24.pl/tvnmeteo/swiat/kiedy-spuszczasz-wode-w-toalecie-zamykaj-klape-ten-film-pokaze-ci-dlaczego-warto-6529423?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 06:13:19+00:00

<img alt="Kiedy spuszczasz wodę w toalecie, zamykaj klapę. Ten film pokaże ci, dlaczego warto" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-la5itx-naukowcy-przy-pomocy-zielonego-lasera-sprawdzili-na-jak-wysoko-wystrzeliwuja-w-powietrze-aerozole-z-nieoslonietych-toalet-podczas-splukiwania-6529427/alternates/LANDSCAPE_1280" />
    Badania naukowców z Uniwersytetu Kolorado.

## "Za każdymi tymi statystykami kryje się istota ludzka - siostra, brat, córka, syn"
 - [https://tvn24.pl/swiat/migranci-sekretarz-generalny-onz-antonio-guterres-o-kryzysie-migracyjnym-i-solidarnosci-6540394?source=rss](https://tvn24.pl/swiat/migranci-sekretarz-generalny-onz-antonio-guterres-o-kryzysie-migracyjnym-i-solidarnosci-6540394?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 06:12:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sarjap-afganistan-5650094/alternates/LANDSCAPE_1280" />
    Powiedział sekretarz generalny ONZ Antonio Guterres.

## Messi tańczy na stole z Pucharem Świata
 - [https://eurosport.tvn24.pl/messi-ta-czy-na-stole-z-pucharem--wiata--szalona-rado---argenty-czyk-w,1129886.html?source=rss](https://eurosport.tvn24.pl/messi-ta-czy-na-stole-z-pucharem--wiata--szalona-rado---argenty-czyk-w,1129886.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 06:11:00+00:00

<img alt="Messi tańczy na stole z Pucharem Świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-liy8vj-argentyna-mistrzem-swiata/alternates/LANDSCAPE_1280" />
    Szalona radość Argentyńczyków.

## Zakupy przed świętami. Część sieci wydłużyła godziny otwarcia sklepów
 - [https://tvn24.pl/biznes/z-kraju/boze-narodzenie-2022-sklepy-godziny-otwarcia-do-ktorej-beda-otwarte-sklepy-przed-swietami-6540434?source=rss](https://tvn24.pl/biznes/z-kraju/boze-narodzenie-2022-sklepy-godziny-otwarcia-do-ktorej-beda-otwarte-sklepy-przed-swietami-6540434?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 06:10:15+00:00

<img alt="Zakupy przed świętami. Część sieci wydłużyła godziny otwarcia sklepów" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjeciefc97666b8f686576f4cf60551ad6daae-zakaz-handlu-ma-obowiazywac-w-dwie-niedziele-w-miesiacu-4413012/alternates/LANDSCAPE_1280" />
    Kalendarz handlowy.

## "Cierpieliśmy w perfekcyjnie rozegranym meczu"
 - [https://eurosport.tvn24.pl/trener-argentyny-nie-kry--zdziwienia---cierpieli-my-w-perfekcyjnie-rozegranym-meczu-,1129892.html?source=rss](https://eurosport.tvn24.pl/trener-argentyny-nie-kry--zdziwienia---cierpieli-my-w-perfekcyjnie-rozegranym-meczu-,1129892.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 05:49:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-81v0c3-dumny-lionel-scaloni-z-pucharem-swiata/alternates/LANDSCAPE_1280" />
    Trener Argentyny nie krył zdziwienia.

## "Ostrzelaliśmy sztab". Ukraińcy próbowali zabić generała Gierasimowa
 - [https://tvn24.pl/swiat/ukraina-rosja-atak-na-generala-gierasimowa-szef-rosyjskiego-sztabu-generalnego-ostrzelany-przez-ukrainskie-sily-6535901?source=rss](https://tvn24.pl/swiat/ukraina-rosja-atak-na-generala-gierasimowa-szef-rosyjskiego-sztabu-generalnego-ostrzelany-przez-ukrainskie-sily-6535901?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 05:48:34+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zd4lpt-walerij-gierasimow-6494899/alternates/LANDSCAPE_1280" />
    O ataku opowiedział Ołeksij Arestowycz, doradca gabinetu prezydenta Ukrainy.

## Norwegia zamyka się dla Rosjan. "Następuje odmowa"
 - [https://tvn24.pl/swiat/norwegia-media-kraj-nie-wydaje-rosjanom-wiz-nawet-zaproszonych-przez-organizacje-pozarzadowe-6529527?source=rss](https://tvn24.pl/swiat/norwegia-media-kraj-nie-wydaje-rosjanom-wiz-nawet-zaproszonych-przez-organizacje-pozarzadowe-6529527?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 05:40:20+00:00

<img alt="Norwegia zamyka się dla Rosjan. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-i8kabm-moss-norwegia-5571584/alternates/LANDSCAPE_1280" />
    Media pytają, czy istnieje zakaz wydania wiz Rosjanom.

## "Skazali siebie i kibiców na niezasłużone cierpienie"
 - [https://eurosport.tvn24.pl/-skazali-siebie-i-kibic-w-na-niezas-u-one-cierpienie---argenty-skie-media-podsumowa-y-fina-,1129866.html?source=rss](https://eurosport.tvn24.pl/-skazali-siebie-i-kibic-w-na-niezas-u-one-cierpienie---argenty-skie-media-podsumowa-y-fina-,1129866.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 05:33:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jhpnju-messi-celebruje-mistrzostwo-swiata/alternates/LANDSCAPE_1280" />
    Argentyńskie media podsumowały finał mundialu.

## FIFA skrytykowana. Szef ukraińskiej dyplomacji: zwykłe tchórzostwo
 - [https://tvn24.pl/swiat/fifa-nie-zgodzila-sie-pokazac-apelu-zelenskiego-przed-finalem-mundialu-dmytro-kuleba-szef-ukrainskiego-msz-tchorzostwo-6534673?source=rss](https://tvn24.pl/swiat/fifa-nie-zgodzila-sie-pokazac-apelu-zelenskiego-przed-finalem-mundialu-dmytro-kuleba-szef-ukrainskiego-msz-tchorzostwo-6534673?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 05:20:00+00:00

<img alt="FIFA skrytykowana. Szef ukraińskiej dyplomacji: zwykłe tchórzostwo" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mdagw9-stadion-w-lusail-w-katarze-6540219/alternates/LANDSCAPE_1280" />
    Poszło o przemówienie prezydenta Ukrainy Wołodymyra Zełenskiego.

## Mundial z rekordową liczbą goli. Mbappe przeważył szalę
 - [https://eurosport.tvn24.pl/mundial-w-katarze-z-rekordow--liczb--goli--mbappe-przewa-y--szal-,1129876.html?source=rss](https://eurosport.tvn24.pl/mundial-w-katarze-z-rekordow--liczb--goli--mbappe-przewa-y--szal-,1129876.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 05:18:00+00:00

<img alt="Mundial z rekordową liczbą goli. Mbappe przeważył szalę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9fokpn-mbappe-zdobyl-hat-tricka-w-finale-6540320/alternates/LANDSCAPE_1280" />
    Udało się pobić 24-letni rekord liczby strzelonych goli w turniejach tej rangi.

## W Argentynie cenią młodych trenerów. Liczby nie pozostawiają złudzeń
 - [https://eurosport.tvn24.pl/w-argentynie-ceni--m-odych-trener-w--liczby-nie-pozostawiaj--z-udze-,1129853.html?source=rss](https://eurosport.tvn24.pl/w-argentynie-ceni--m-odych-trener-w--liczby-nie-pozostawiaj--z-udze-,1129853.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 05:05:00+00:00

<img alt="W Argentynie cenią młodych trenerów. Liczby nie pozostawiają złudzeń" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xod3g0-lionel-scaloni-siegnal-z-argentyna-po-mistrzostwo-swiata/alternates/LANDSCAPE_1280" />
    Lionel Scaloni miał w niedzielę ogromne powody do radości.

## Poranny atak dronów na Kijów
 - [https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-19-grudnia-2022-6539359?source=rss](https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-19-grudnia-2022-6539359?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 04:52:41+00:00

<img alt="Poranny atak dronów na Kijów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cj8786-pograzone-w-ciemnosciach-ulice-w-kijowie-po-rosyjskim-ataku-rakietowym-na-ukrainska-infrastrukture-energetyczna-6253175/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## Rzucał do tarczy przez 22 godziny. Pobił rekord, wsparł szczytny cel
 - [https://tvn24.pl/polska/wagrowiec-wojciech-skrzypczak-pobil-rekord-polski-rzucal-do-tarczy-przez-22-godziny-wsparl-budowe-centrum-psychiatrii-dzieci-i-mlodziezy-6538960?source=rss](https://tvn24.pl/polska/wagrowiec-wojciech-skrzypczak-pobil-rekord-polski-rzucal-do-tarczy-przez-22-godziny-wsparl-budowe-centrum-psychiatrii-dzieci-i-mlodziezy-6538960?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-19 04:45:16+00:00

<img alt="Rzucał do tarczy przez 22 godziny. Pobił rekord, wsparł szczytny cel" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0yf3qb-rekord-zostalpobity-6538969/alternates/LANDSCAPE_1280" />
    Pan Wojciech pomógł w budowie Centrum Psychiatrii Dzieci i Młodzieży, przedsięwzięciu Fundacji TVN.


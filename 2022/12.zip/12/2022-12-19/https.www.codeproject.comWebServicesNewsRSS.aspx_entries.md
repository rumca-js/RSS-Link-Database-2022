# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## 'Is WPF dead?' Some devs claim 'Yes' as Microsoft relegates Issues/PRs to the community
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59856](https://www.codeproject.com/script/News/View.aspx?nwid=59856)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

Not 'dead', just 'done'?

## 'Tech shame' is hitting young colleagues the hardest as they try to fix older colleagues' technical issues and their own
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59854](https://www.codeproject.com/script/News/View.aspx?nwid=59854)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

The kids aren't all right

## AWS, Microsoft, Meta and TomTom launch open map data consortium
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59852](https://www.codeproject.com/script/News/View.aspx?nwid=59852)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

That's strange - there seems to be one major mapping website missing from that list

## Any old games to suggest?
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59846](https://www.codeproject.com/script/News/View.aspx?nwid=59846)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

I hear Senet is pretty old

## GCC 13 to support Modula-2: Follow-up to Pascal lives on in FOSS form
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59850](https://www.codeproject.com/script/News/View.aspx?nwid=59850)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

Great news for that one developer thinking of using it

## GitHub to require all users to enable 2FA by the end of 2023
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59849](https://www.codeproject.com/script/News/View.aspx?nwid=59849)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

Coming soon: a pile of 2FA hacks

## How a simulation wormhole could help physicists finally unite gravity and quantum theory
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59853](https://www.codeproject.com/script/News/View.aspx?nwid=59853)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

It's wormholes all the way down (connecting the turtles, of course)

## Microsoft: Edge update will disable Internet Explorer in February
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59848](https://www.codeproject.com/script/News/View.aspx?nwid=59848)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

"This is the end, my only friend, the end"

## Randal does it again!
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59857](https://www.codeproject.com/script/News/View.aspx?nwid=59857)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

"Space...is big. Really big. You just won't believe how vastly, hugely, mindbogglingly big it is."

## Riffusion’s AI generates music from text using visual sonograms
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59851](https://www.codeproject.com/script/News/View.aspx?nwid=59851)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

Play me a tune, you're the AI

## The future of .NET with WASM
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59855](https://www.codeproject.com/script/News/View.aspx?nwid=59855)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

It's not just awesome, it's WASM!

## Windows Subsystem for Android Preview gets Android 13, performance improvements, more
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59847](https://www.codeproject.com/script/News/View.aspx?nwid=59847)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-12-19 05:00:00+00:00

For those that like to phone it in


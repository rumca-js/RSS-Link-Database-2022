# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Peloton users report being followed by spam accounts showing nude photos, links to unknown websites
 - [https://www.dailymail.co.uk/news/article-11555835/Peloton-users-report-followed-spam-accounts-showing-nude-photos-links-unknown-websites.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555835/Peloton-users-report-followed-spam-accounts-showing-nude-photos-links-unknown-websites.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 23:54:40+00:00

Peloton is taking action after bikes were hit overnight by spam accounts that left pornography on the screens of users across the country.

## Officer shoots a man wielding a knife in Nevada who is wanted across the country
 - [https://www.dailymail.co.uk/news/article-11555911/Officer-shoots-man-wielding-knife-Nevada-wanted-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555911/Officer-shoots-man-wielding-knife-Nevada-wanted-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 23:54:13+00:00

Marcus Lee Lewis was shot multiple times by Reno officers in the parking area of Silver Legacy Casino on December 4 after he failed to put down his knife.

## Scientists reveal the BEST biscuit for dunking in tea... and the results might surprise you
 - [https://www.dailymail.co.uk/health/article-11554233/Scientists-reveal-BEST-biscuit-dunking-tea-results-surprise-you.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11554233/Scientists-reveal-BEST-biscuit-dunking-tea-results-surprise-you.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 23:39:59+00:00

Over decades, people have stood by the biscuit tin agonising over which is best to dunk in their tea. Now it's been revealed a Hobnob is the best, beating a digestive, shortie and rich tea.

## Wieambilla shooting: Alan Dare to have Ford motorcade at funeral with XC Cobras and 70s Fords
 - [https://www.dailymail.co.uk/news/article-11555795/Wieambilla-shooting-Alan-Dare-Ford-motorcade-funeral-XC-Cobras-70s-Fords.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555795/Wieambilla-shooting-Alan-Dare-Ford-motorcade-funeral-XC-Cobras-70s-Fords.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 23:34:47+00:00

Neighbour Alan Dare, 58, who was gunned down by a conspiracy theorist trio at a Wieambilla, Queensland property, will be commemorated at a private funeral on Friday with a classic Ford tribute.

## Cranebrook, Ashley Gaddie: Manhunt for alleged killer of woman, 31, he met on a dating app
 - [https://www.dailymail.co.uk/news/article-11556033/Cranebrook-Ashley-Gaddie-Manhunt-alleged-killer-woman-31-met-dating-app.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11556033/Cranebrook-Ashley-Gaddie-Manhunt-alleged-killer-woman-31-met-dating-app.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 23:29:51+00:00

An arrest warrant has been issued for Ashley Gaddie, 33, after a woman was discovered with horrific fatal injuries by friends at Cranebrook, in Sydney's west, on Sunday.

## Mystery surrounding Republican congressman-elect George Santos
 - [https://www.dailymail.co.uk/news/article-11555469/Mystery-surrounding-Republican-congressman-elect-George-Santos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555469/Mystery-surrounding-Republican-congressman-elect-George-Santos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 23:28:53+00:00

Republican Rep.-elect George Santos comes to Congress in January with a degree from Baruch College and stints at Citigroup and Goldman Sachs, according to his campaign biography.

## DAILY MAIL COMMENT: Rishi is right to stand firm against strikes
 - [https://www.dailymail.co.uk/news/article-11556075/DAILY-MAIL-COMMENT-Rishi-right-stand-firm-against-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11556075/DAILY-MAIL-COMMENT-Rishi-right-stand-firm-against-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 23:21:48+00:00

DAILY MAIL COMMENT: In the face of co-ordinated strike action across the public sector, the Prime Minister tells the Mail today that he will stand firm even if the disruption lasts for months.

## Sydney mother-of-two lifts lid on urinary incontinence saying she would deliberately dehydrate
 - [https://www.dailymail.co.uk/news/article-11552831/Aussie-mum-incontinence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552831/Aussie-mum-incontinence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 23:00:49+00:00

Sydney mum Kate had to be placed on a drip by nurses and cared for by doctors after she pushed herself too far and became so dehydrated that she required medical care.

## You've been using gift bags wrong your whole life
 - [https://www.dailymail.co.uk/femail/lifehacks/article-11555727/Youve-using-gift-bags-wrong-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/lifehacks/article-11555727/Youve-using-gift-bags-wrong-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:57:40+00:00

With Christmas only five days away, a couple has revealed the 'right way' the use a gift bag this festive season.

## Melbourne La Trobe university student banned from class for questioning 'racist narrative'
 - [https://www.dailymail.co.uk/news/article-11555543/Melbourne-La-Trobe-university-student-banned-class-questioning-racist-narrative.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555543/Melbourne-La-Trobe-university-student-banned-class-questioning-racist-narrative.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:53:26+00:00

A mature-aged university student was subjected to a 'humiliating tirade', banned from class and told to take a reeducation course for questioning her lecturer's seemingly racist narrative.

## Rail strike will force trains to stop as early as 8am on Christmas Eve piling  misery onto families
 - [https://www.dailymail.co.uk/news/article-11555897/Rail-strike-force-trains-stop-early-8am-Christmas-Eve-piling-misery-families.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555897/Rail-strike-force-trains-stop-early-8am-Christmas-Eve-piling-misery-families.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:48:36+00:00

Rail bosses are advising families to set off the day before Christmas Eve in some parts of the country if they want to guarantee that they can see their loved ones on Christmas this year.

## Controversial Rwanda deportation plan gets green light... but legal appeals continue
 - [https://www.dailymail.co.uk/news/article-11555907/Controversial-Rwanda-deportation-plan-gets-green-light-legal-appeals-continue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555907/Controversial-Rwanda-deportation-plan-gets-green-light-legal-appeals-continue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:41:20+00:00

The High Court comprehensively demolished the arguments made against the plan, which is designed to deter migrants from crossing the Channel in small boats.

## Investor who lost $1.5million in the fallout of FTX crash looks Sam Bankman-Fried in the eye
 - [https://www.dailymail.co.uk/news/article-11555593/Investor-lost-1-5million-fallout-FTX-crash-looks-Sam-Bankman-Fried-eye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555593/Investor-lost-1-5million-fallout-FTX-crash-looks-Sam-Bankman-Fried-eye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:40:40+00:00

British-born grandmother Rebecca Gallagher lost $1.5million in the fallout of the Sam Bankman-Fried's FTX crash.

## Wollongong man, 28, is charged with murder after a woman, 37, is found dead with horrific injuries
 - [https://www.dailymail.co.uk/news/article-11555725/Wollongong-man-28-charged-murder-woman-37-dead-horrific-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555725/Wollongong-man-28-charged-murder-woman-37-dead-horrific-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:37:34+00:00

A man has been charged with the murder of a woman in the NSW Illawarra region. Police were called to a unit complex at Albion Park Rail, just after 11pm on Sunday.

## US Supreme Court temporarily pauses lifting Title 42 border restrictions this week
 - [https://www.dailymail.co.uk/news/article-11555893/US-Supreme-Court-temporarily-pauses-lifting-Title-42-border-restrictions-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555893/US-Supreme-Court-temporarily-pauses-lifting-Title-42-border-restrictions-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:35:54+00:00

The Supreme Court has delayed lifting Title 42 for 24 hours, after Republicans lobbied to keep the pandemic-era border policy in place.

## So what is Sunakism? It's peace of mind, lower taxes... and a genuine pride in Britain: Rishi Sunak
 - [https://www.dailymail.co.uk/news/article-11555967/So-Sunakism-peace-mind-lower-taxes-genuine-pride-Britain-Rishi-Sunak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555967/So-Sunakism-peace-mind-lower-taxes-genuine-pride-Britain-Rishi-Sunak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:35:19+00:00

Rishi Sunak is beset by crises. Whether it is the war in Ukraine, handling unions bent on a winter of discontent or trying to tackle the Channel migrant crossings, there is trouble everywhere he looks.

## Murder suspect awaiting physical exam escapes from police custody in Brazil
 - [https://www.dailymail.co.uk/news/article-11555391/Murder-suspect-awaiting-physical-exam-escapes-police-custody-Brazil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555391/Murder-suspect-awaiting-physical-exam-escapes-police-custody-Brazil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:35:13+00:00

A murder suspect appeared to have run out of patience while he waited for police to administer a physical exam and fled from the medical examiner's building in Brazil.

## White House vows to 'quickly remove' border-crossers and says border 'is not open'
 - [https://www.dailymail.co.uk/news/article-11555709/White-House-vows-quickly-remove-border-crossers-says-border-not-open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555709/White-House-vows-quickly-remove-border-crossers-says-border-not-open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:34:55+00:00

White House press secretary Karine Jean-Pierre said the scheduled end of Title 42 - which has brought a surge of migration at the border - does not mean the border is 'open.'

## Suburbs in Australia with the highest median pay: WA, NSW, Victoria, Queensland
 - [https://www.dailymail.co.uk/news/article-11552655/Suburbs-Australia-highest-median-pay-WA-NSW-Victoria-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552655/Suburbs-Australia-highest-median-pay-WA-NSW-Victoria-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:33:55+00:00

Elite suburbs on a river have Australia's highest average income levels while iron ore mining towns have the best middle incomes. Both outrank Sydney's richest postcodes.

## Trump faces up to FORTY YEARS in prison if convicted on all four federal charges
 - [https://www.dailymail.co.uk/news/article-11555691/Trump-faces-FORTY-YEARS-prison-convicted-four-federal-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555691/Trump-faces-FORTY-YEARS-prison-convicted-four-federal-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:31:26+00:00

Donald Trump faces up to 40 years in jail, thousands in fines, and a prohibition on ever running for office again if he's convicted on the four federal charges leveled against him by the January 6th committee.

## Paedophile police officer who was caught with child porn on his laptop AVOIDS jail
 - [https://www.dailymail.co.uk/news/article-11555833/Paedophile-police-officer-caught-child-porn-laptop-AVOIDS-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555833/Paedophile-police-officer-caught-child-porn-laptop-AVOIDS-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:30:36+00:00

PC Lee Ashcroft's laptop had to be sent off to experts at the Government's intelligence headquarters after he installed encryption software to hamper access.

## Elite Afghan commando trained by US forces faces deportation for crossing southern border illegally
 - [https://www.dailymail.co.uk/news/article-11555735/Elite-Afghan-commando-trained-forces-faces-deportation-crossing-southern-border-illegally.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555735/Elite-Afghan-commando-trained-forces-faces-deportation-crossing-southern-border-illegally.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:28:25+00:00

Abdul Wasi Safi was detained by US Border Patrol in September after he illegally crossed the southern border in September, trying to seek asylum from the Taliban.

## Frightening moment a guest on the Today Show nearly passes out during the middle of an interview
 - [https://www.dailymail.co.uk/news/article-11555567/Frightening-moment-guest-Today-nearly-passes-middle-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555567/Frightening-moment-guest-Today-nearly-passes-middle-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:24:23+00:00

Viewers of the Today Show on Tuesday morning were left shocked after senior analyst Malcolm Davis started breathing heavily and then passed out during an interview with Christine Ahern.

## Woman in her 60s is found dead at house in Eastbourne as murder cops arrest 59-year-old man
 - [https://www.dailymail.co.uk/news/article-11555823/Woman-60s-dead-house-Eastbourne-murder-cops-arrest-59-year-old-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555823/Woman-60s-dead-house-Eastbourne-murder-cops-arrest-59-year-old-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:21:12+00:00

Police have arrested a man on suspicion of murder after the body of a woman was found at a house in Eastbourne.

## Fortnite developer Epic hit with record $520m fine'; collecting kids' data without parents' consent
 - [https://www.dailymail.co.uk/news/article-11555487/Fortnite-developer-Epic-hit-record-520m-fine-collecting-kids-data-without-parents-consent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555487/Fortnite-developer-Epic-hit-record-520m-fine-collecting-kids-data-without-parents-consent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:19:44+00:00

The wildly popular online video game Fortnite has been hit with a massive $520m fine for collecting kids' data without parents' consent and tricking them into unwanted purchases.

## Crypto giant Binance's US unit agrees to acquire Voyager's assets in $1B deal
 - [https://www.dailymail.co.uk/news/article-11555785/Crypto-giant-Binances-unit-agrees-acquire-Voyagers-assets-1B-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555785/Crypto-giant-Binances-unit-agrees-acquire-Voyagers-assets-1B-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:17:03+00:00

The deal comes just weeks after rival exchange FTX's proposed bailout of Voyager collapsed when FTX itself filed for bankruptcy in a seismic event that rocked the sector.

## Federal lawsuit says Alabama inmate 'baked' to death in cell
 - [https://www.dailymail.co.uk/news/article-11555557/Federal-lawsuit-says-Alabama-inmate-baked-death-cell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555557/Federal-lawsuit-says-Alabama-inmate-baked-death-cell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:11:00+00:00

Thomas Lee Rutledge, 44, died in his Alabama prison cell on December 7, 2020 when his body temperature reached 109 degrees.

## Arctic blast set to cause 'life threatening temperatures' and spark Christmas travel chaos
 - [https://www.dailymail.co.uk/news/article-11554979/Arctic-blast-set-cause-life-threatening-temperatures-spark-Christmas-travel-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554979/Arctic-blast-set-cause-life-threatening-temperatures-spark-Christmas-travel-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:10:33+00:00

A massive storm system is set to bring an arctic blast that will affect millions of people across the United States with the dangerous threat of snow, damaging winds and plummeting temperatures.

## Just William - The Christmas Truce: In a joyful conclusion to RICHMAL CROMPTON'S festive tale
 - [https://www.dailymail.co.uk/news/article-11555747/Just-William-Christmas-Truce-joyful-conclusion-RICHMAL-CROMPTONS-festive-tale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555747/Just-William-Christmas-Truce-joyful-conclusion-RICHMAL-CROMPTONS-festive-tale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 22:01:27+00:00

They met in the old barn in the morning to arrange their plan of action, but none of them could think of any plan of action.

## Enrique Tarrio, Proud Boys leader, to stand trial for conspiring to stop peaceful transfer of power
 - [https://www.dailymail.co.uk/news/article-11555265/Enrique-Tarrio-Proud-Boys-leader-stand-trial-conspiring-stop-peaceful-transfer-power.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555265/Enrique-Tarrio-Proud-Boys-leader-stand-trial-conspiring-stop-peaceful-transfer-power.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:48:31+00:00

Jury selection began Monday for the weeks-long January trial of Proud Boy leader Enrique Tarrio and some of his top lieutenants in the group.

## Urgent search for four teenagers who vanished while paddling on inflatable boards
 - [https://www.dailymail.co.uk/news/article-11555633/Urgent-search-four-teenagers-vanished-paddling-inflatable-boards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555633/Urgent-search-four-teenagers-vanished-paddling-inflatable-boards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:36:24+00:00

It's believed an 18-year-old woman, two 18-year-old men and a 19-year-old woman were using inflatable paddle boards off Rosebud Beach on Monday when they suddenly vanished.

## Ugly confrontation erupts outside Manhattan library hosting drag queen story hour
 - [https://www.dailymail.co.uk/news/article-11555439/Ugly-confrontation-erupts-outside-Manhattan-library-hosting-drag-queen-story-hour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555439/Ugly-confrontation-erupts-outside-Manhattan-library-hosting-drag-queen-story-hour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:30:40+00:00

Ugly scenes unfolded outside a drag queen reading hour for neurodiverse children in Manhattan over the weekend, one week after a man was arrested for assaulting an NYPD cop.

## 'Chainsaw-wielding dad attacks police station after cops refused to babysit his children'
 - [https://www.dailymail.co.uk/news/article-11555199/Chainsaw-wielding-man-attempts-enter-Massachusetts-police-station-barricades-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555199/Chainsaw-wielding-man-attempts-enter-Massachusetts-police-station-barricades-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:27:16+00:00

A man who attempted to break into a Massachusetts police station before barricading himself inside his home and dangling his young children near a window has been charged.

## Pensioner who raped, stabbed and strangled 15-year-old girl nearly 50 years ago is convicted
 - [https://www.dailymail.co.uk/news/article-11555301/Pensioner-raped-stabbed-strangled-15-year-old-girl-nearly-50-years-ago-convicted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555301/Pensioner-raped-stabbed-strangled-15-year-old-girl-nearly-50-years-ago-convicted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:21:45+00:00

Dennis McGrory, 75, is facing justice for raping and murdering a girl nearly 50 years ago. Jacqui Montgomery, 15, was stabbed and strangled in Islington, London in 1975.

## British couple are found dead in their Majorca home after 'carbon monoxide poisoning'
 - [https://www.dailymail.co.uk/news/article-11555627/British-couple-dead-Majorca-home-carbon-monoxide-poisoning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555627/British-couple-dead-Majorca-home-carbon-monoxide-poisoning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:20:05+00:00

A British couple have been found dead in their home in Majorca after a suspected carbon monoxide poisoning.

## Man murdered boy, and tried to murder his mother before trying to flee the country on a dinghy
 - [https://www.dailymail.co.uk/news/article-11555379/Man-murdered-boy-tried-murder-mother-trying-flee-country-dinghy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555379/Man-murdered-boy-tried-murder-mother-trying-flee-country-dinghy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:19:02+00:00

Suleman Altaf, 44, allegedly murdered Jakub Szymanski in Manchester, in June.It is claimed he also attempted to murder his mother Katarzyna Bastek before attempting to flee the country.

## Mother Elizabeth Harpley and her three children missing from Koshigaya Park Campbelltown
 - [https://www.dailymail.co.uk/news/article-11555643/Mother-Elizabeth-Harpley-three-children-missing-Koshigaya-Park-Campbelltown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555643/Mother-Elizabeth-Harpley-three-children-missing-Koshigaya-Park-Campbelltown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:18:04+00:00

Elizabeth Harpley, 36, and Mathew and Christopher Harpley, and Mitchell Devine-Harpley, aged 10, nine and five, were last seen at Koshigaya Park, in Campbelltown, south-west Sydney at 2pm on Sunday.

## Pensioner, 90 hauled back to court after refusing to wear an electronic tag
 - [https://www.dailymail.co.uk/news/article-11555341/Pensioner-90-hauled-court-refusing-wear-electronic-tag.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555341/Pensioner-90-hauled-court-refusing-wear-electronic-tag.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:08:59+00:00

Edward Turpin stabbed Joan Turpin, 90, four times in the chest, on September, 22, 2021 because he could not cope with caring for her.

## Top NHS consultant, 54, downloaded more than a HUNDRED 'abhorrent' child rape images, court hears
 - [https://www.dailymail.co.uk/news/article-11555283/Top-NHS-consultant-54-downloaded-abhorrent-child-rape-images-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555283/Top-NHS-consultant-54-downloaded-abhorrent-child-rape-images-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:06:35+00:00

Plastic surgeon Mansoor Khan, who was deemed a 'pillar of society' and coached a girls' rugby team, allegedly accessed illegal sites to download dozens of 'the most revolting' photos.

## The candidates who might take over at Twitter if Elon Musk steps down
 - [https://www.dailymail.co.uk/news/article-11555025/The-candidates-Twitter-Elon-Musk-steps-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555025/The-candidates-Twitter-Elon-Musk-steps-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:05:36+00:00

Musk asked his 122million Twitter followers if he should step down, and promised to abide by whatever they decided in a poll.

## NYC's 'bling pastor' hit with federal charges for defrauding parishioners of thousands of dollars
 - [https://www.dailymail.co.uk/news/article-11555237/NYCs-bling-bishop-hit-federal-charges-defrauding-parishioners-thousands-dollars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555237/NYCs-bling-bishop-hit-federal-charges-defrauding-parishioners-thousands-dollars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 21:01:33+00:00

Lamor Whitehead, 45, the founder of the Leaders of Tomorrow International Church, was arrested Monday by federal agents for scamming his parishioners out of more than a hundred thousand.

## Thousands of Aussies with 'all the gear and no idea' getting bogged in 4WD
 - [https://www.dailymail.co.uk/news/article-11555659/Thousands-Aussies-gear-no-idea-getting-bogged-4WD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555659/Thousands-Aussies-gear-no-idea-getting-bogged-4WD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:55:57+00:00

Aussie blokes have been buying up kitted out 4WDs in the hope of exploring the country.

## Ex-police officer, 40, faces a further misconduct charge 'engaging in sex acts with a woman'
 - [https://www.dailymail.co.uk/news/article-11555365/Ex-police-officer-40-faces-misconduct-charge-engaging-sex-acts-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555365/Ex-police-officer-40-faces-misconduct-charge-engaging-sex-acts-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:48:29+00:00

Ex-constable Daniel Nash, 40, who served with Derbyshire Police, will appear at Westminster Magistrates' Court tomorrow, the Independent Office for Police Conduct (IOPC) said.

## Conspiracy theorist, is found guilty of plotting  terror attacks to topple the government
 - [https://www.dailymail.co.uk/news/article-11555267/Conspiracy-theorist-guilty-plotting-terror-attacks-topple-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555267/Conspiracy-theorist-guilty-plotting-terror-attacks-topple-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:37:45+00:00

Oliver Lewin, 38, of Leicestershire was found guilty of after being accused of engaging in the commission, preparation or instigation of an act of terrorism.

## Gary Neville's World Cup rant sparks more than 440 complaints to media watchdog
 - [https://www.dailymail.co.uk/news/article-11555465/Gary-Nevilles-World-Cup-rant-sparks-440-complaints-media-watchdog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555465/Gary-Nevilles-World-Cup-rant-sparks-440-complaints-media-watchdog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:37:06+00:00

Gary Neville's latest World Cup rant has sparked more than 440 complaints to media watchdog Ofcom.

## FBI official turned Twitter counsel Jim Baker thanked Bureau for suppressing Hunter Biden laptop
 - [https://www.dailymail.co.uk/news/article-11555321/FBI-official-turned-Twitter-counsel-Jim-Baker-thanked-Bureau-suppressing-Hunter-Biden-laptop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555321/FBI-official-turned-Twitter-counsel-Jim-Baker-thanked-Bureau-suppressing-Hunter-Biden-laptop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:31:57+00:00

The most recent batch of 'Twitter Files' showed how former FBI official and then-lawyer for Twitter Jim Baker helped suppress the Hunter Biden story.

## Football mad Indian couple tie the knot wearing Messi and Mbappe shirts
 - [https://www.dailymail.co.uk/news/article-11555323/Football-mad-Indian-couple-tie-knot-wearing-Messi-Mbappe-shirts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555323/Football-mad-Indian-couple-tie-knot-wearing-Messi-Mbappe-shirts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:29:48+00:00

Sachin R and R Athira didn't want their wedding day getting in the way of their love for football and while they see eye to eye in most of their day to day lives they didn't agree on what team to support.

## Wieambilla shooting: Queensland Police Union to buy property where two officers and neighbour killed
 - [https://www.dailymail.co.uk/news/article-11555367/Wieambilla-shooting-Queensland-Police-Union-buy-property-two-officers-neighbour-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555367/Wieambilla-shooting-Queensland-Police-Union-buy-property-two-officers-neighbour-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:29:04+00:00

The union has asked the state government to buy the 43.5ha block of land in Wieambilla, west of Brisbane, which was bought by cop killers Gareth and his wife Stacey Train for $95,000 in 2015.

## Teenager, 19, pleads not guilty to people smuggling charge
 - [https://www.dailymail.co.uk/news/article-11555213/Teenager-19-pleads-not-guilty-people-smuggling-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555213/Teenager-19-pleads-not-guilty-people-smuggling-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:28:03+00:00

Ibrahima Bah, 19, was charged with knowingly facilitating the attempted arrival in the UK of people he knew or had reasonable cause to believe were asylum seekers.

## 'Doomsday prepper' Simon Pilgrim who let off homemade bombs in his garden walks free
 - [https://www.dailymail.co.uk/news/article-11555175/Doomsday-prepper-Simon-Pilgrim-let-homemade-bombs-garden-spared-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555175/Doomsday-prepper-Simon-Pilgrim-let-homemade-bombs-garden-spared-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:24:47+00:00

Simon Pilgrim, 41, was caught with improvised explosive devices in his bedroom at a multi-occupancy property in King Alfred Street, Derby, on December, 5, 2021.

## Sam Bankman-Fried's prosecution AND defense say they have no idea why they are there
 - [https://www.dailymail.co.uk/news/article-11555303/Sam-Bankman-Frieds-prosecution-defense-say-no-idea-there.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555303/Sam-Bankman-Frieds-prosecution-defense-say-no-idea-there.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:22:39+00:00

Sam Bankman-Fried, 30, appeared in court Monday for an extradition hearing. Prosecutors, his defense lawyer and the presiding magistrate questioned why they were all there.

## Convicted thief given a 'second chance' by the CofE defrauded church out of £5.2M
 - [https://www.dailymail.co.uk/news/article-11555467/Convicted-thief-given-second-chance-CofE-defrauded-church-5-2M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555467/Convicted-thief-given-second-chance-CofE-defrauded-church-5-2M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:13:51+00:00

Southwark Crown Court heard Martin Sargeant, 53, was given a 'second chance' after stealing from employers in the 1990s, landing an £86,000-a-year job with the Archdeaconry of London.

## Father of 'incel' gunman Jake Davison tried to stop killer from owning a shotgun
 - [https://www.dailymail.co.uk/news/article-11555317/Father-incel-gunman-Jake-Davison-tried-stop-killer-owning-shotgun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555317/Father-incel-gunman-Jake-Davison-tried-stop-killer-owning-shotgun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 20:11:30+00:00

Mark Davison told senior Plymouth coroner Ian Arrow he had contacted Devon and Cornwall Police with concerns about his son and his unstable home life.

## Student charged with threatening behaviour after eggs thrown at King Charles during walkabout
 - [https://www.dailymail.co.uk/news/article-11554927/Student-charged-threatening-behaviour-eggs-thrown-King-Charles-walkabout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554927/Student-charged-threatening-behaviour-eggs-thrown-King-Charles-walkabout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:51:19+00:00

Patrick Thelwell, 23, has been charged with threatening behaviour after eggs were thrown at the King during a walkabout in York on November 9, the Crown Prosecution Service (CPS) said.

## DAVID MARCUS: Migrant shelters are overflowing, a border crisis is about to explode but AOC's AWOL
 - [https://www.dailymail.co.uk/news/article-11555279/DAVID-MARCUS-Migrant-shelters-overflowing-border-crisis-explode-AOCs-AWOL.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555279/DAVID-MARCUS-Migrant-shelters-overflowing-border-crisis-explode-AOCs-AWOL.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:43:02+00:00

MARCUS: AOC, Biden, Harris, all of them must go to the border, stand in front of a camera, and tell America what they plan to do to fix this. No crying, no poses, just a plan.

## American tourists stranded in Machu Picchu as violent protests erupt
 - [https://www.dailymail.co.uk/news/article-11555015/American-tourists-stranded-Machu-Picchu-violent-protests-erupt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555015/American-tourists-stranded-Machu-Picchu-violent-protests-erupt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:39:49+00:00

A few hundred Americans are stranded in Peru following political unrest that occurred when President Pedro Castillo was detained.

## Top Republican tells Austin and Blinken it would be CATASTROPHIC to lose  Indian Ocean base
 - [https://www.dailymail.co.uk/news/article-11551719/Top-Republican-tells-Austin-Blinken-CATASTROPHIC-lose-Indian-Ocean-base.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11551719/Top-Republican-tells-Austin-Blinken-CATASTROPHIC-lose-Indian-Ocean-base.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:34:44+00:00

Rep. Mike Waltz on Monday wrote to the Pentagon and the State Department seeking assurances that they will not allow China to encroach on the vital U.S. base at Diego Garcia.

## Armed cops shoot dead knifeman in his 40s
 - [https://www.dailymail.co.uk/news/article-11555405/Armed-cops-shoot-dead-knifeman-40s.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555405/Armed-cops-shoot-dead-knifeman-40s.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:34:24+00:00

Armed police have shot dead a suspected knifeman in his 40s after reports that he was threatening people.

## Argentinian fan choked to death by flag draped around his shoulders while celebrating World Cup win
 - [https://www.dailymail.co.uk/news/article-11555035/Argentinian-fan-choked-death-flag-draped-shoulders-celebrating-World-Cup-win.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555035/Argentinian-fan-choked-death-flag-draped-shoulders-celebrating-World-Cup-win.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:33:26+00:00

The 22-year-old, named locally as Sebastian Oscar Maciel, died instantly after accidentally depriving himself of oxygen.

## January 6 committee recommends CRIMINAL charges for Trump over Capitol riot
 - [https://www.dailymail.co.uk/news/article-11555057/January-6-committee-recommends-CRIMINAL-charges-Trump-Capitol-riot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555057/January-6-committee-recommends-CRIMINAL-charges-Trump-Capitol-riot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:31:42+00:00

'In addition to being unlawful as described in our report, this was an utter moral failure and a clear dereliction of duty,' Rep. Liz Cheney said of Donald Trump's actions on January 6.

## January 6 committee demands ethics sanctions against GOP Leader Kevin McCarthy, House Republicans
 - [https://www.dailymail.co.uk/news/article-11554871/January-6-committee-demands-ethics-sanctions-against-GOP-Leader-Kevin-McCarthy-House-Republicans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554871/January-6-committee-demands-ethics-sanctions-against-GOP-Leader-Kevin-McCarthy-House-Republicans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:31:32+00:00

The panel's seven Democrats and two Republicans announced they were recommending the four lawmakers by sanctioned by the House Ethics Committee during their tenth public meeting.

## January 6 panel slams Ivanka Trump for not being 'forthcoming' in her testimony
 - [https://www.dailymail.co.uk/news/article-11554919/January-6-panel-slams-Ivanka-Trump-not-forthcoming-testimony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554919/January-6-panel-slams-Ivanka-Trump-not-forthcoming-testimony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:29:53+00:00

January 6th committee slammed Ivanka Trump for displaying a 'lack of full recollection of certain issues' and not being 'forthcoming' in her testimony to the panel.

## 'Inebriated' Rudy was the ONLY member of Trump's campaign team who wanted him to declare victory
 - [https://www.dailymail.co.uk/news/article-11554745/Inebriated-Rudy-member-Trumps-campaign-team-wanted-declare-victory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554745/Inebriated-Rudy-member-Trumps-campaign-team-wanted-declare-victory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:23:59+00:00

The final report of the House January 6 Committee says former Trump lawyer Rudy Giuliani was the only advisor present who supported Trump's claim to victory.

## Shocking moment two men wade into a fountain to fish out coins meant for a children's charity
 - [https://www.dailymail.co.uk/news/article-11554921/Shocking-moment-two-men-wade-fountain-fish-coins-meant-childrens-charity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554921/Shocking-moment-two-men-wade-fountain-fish-coins-meant-childrens-charity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:21:45+00:00

Police are searching for the brazen duo who were caught on video climbing into the fountain of the Emett Clock in Nottingham's Victoria Centre.

## How Blaine Gibson who has spent years finding MH370 debris has spent six years in hiding
 - [https://www.dailymail.co.uk/news/article-11554703/How-Blaine-Gibson-spent-years-finding-MH370-debris-spent-six-years-hiding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554703/How-Blaine-Gibson-spent-years-finding-MH370-debris-spent-six-years-hiding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:14:59+00:00

Gibson, from Seattle, has traveled across the Indian Ocean discovering potential pieces of debris from the flight.

## NYC mayor warns city may cut public services to cope with migrant influx
 - [https://www.dailymail.co.uk/news/article-11555023/NYC-mayor-warns-city-cut-public-services-cope-migrant-influx.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555023/NYC-mayor-warns-city-cut-public-services-cope-migrant-influx.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 19:08:44+00:00

'Our shelter system is full, and we are nearly out of money, staff, and space,' Adams said in a statement on Sunday, projecting an additional 1,000 migrants will begin arriving in the city weekly.

## Musk's daily Twitter wars have Democratic lawmakers looking for backup social media options
 - [https://www.dailymail.co.uk/news/article-11555017/Musks-daily-Twitter-wars-Democratic-lawmakers-looking-backup-social-media-options.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555017/Musks-daily-Twitter-wars-Democratic-lawmakers-looking-backup-social-media-options.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 18:58:25+00:00

A number of Democratic lawmakers are testing out new social media sites, looking for a Twitter backup thanks to owner Elon Musk's daily drama.

## PM vows to stand firm for months against strikes' 'unreasonable' pay demands
 - [https://www.dailymail.co.uk/news/article-11555173/PM-vows-stand-firm-months-against-strikes-unreasonable-pay-demands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555173/PM-vows-stand-firm-months-against-strikes-unreasonable-pay-demands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 18:29:21+00:00

Rishi Sunak today warns striking workers he will hold out against their 'unreasonable' pay demands for months if necessary.

## Dog missing for FOURTEEN months is found 1,700 miles from California home in Kansas pasture
 - [https://www.dailymail.co.uk/news/article-11554825/Dog-missing-FOURTEEN-months-1-700-miles-California-home-Kansas-pasture.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554825/Dog-missing-FOURTEEN-months-1-700-miles-California-home-Kansas-pasture.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 18:28:14+00:00

A beloved dog who went missing fourteen months ago from his California home is on his way to being reunited with his owner after making a 1,700-mile journey to Kansas.

## George Wagner IV sentenced to life in prison without parole for the Pike County Massacre
 - [https://www.dailymail.co.uk/news/article-11555141/George-Wagner-IV-sentenced-life-prison-without-parole-Pike-County-Massacre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555141/George-Wagner-IV-sentenced-life-prison-without-parole-Pike-County-Massacre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 18:27:15+00:00

George Wagner IV, 31, was sentenced to life in prison on all eight counts of aggravated murder for each victim in the Pike County killings.

## Don Lemon breaks down in tears as he announces the death of CNN investigative reporter Drew Griffin
 - [https://www.dailymail.co.uk/news/article-11554955/Don-Lemon-breaks-tears-announces-death-CNN-investigative-reporter-Drew-Griffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554955/Don-Lemon-breaks-tears-announces-death-CNN-investigative-reporter-Drew-Griffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 18:24:56+00:00

CNN This Morning co-anchor Don Lemon broke down Monday as he reported the death of his longtime network colleague investigative journalist Drew Griffin.

## Residents in rural Wisconsin share extraordinary videos of possible UFO sighting
 - [https://www.dailymail.co.uk/news/article-11554579/Residents-rural-Wisconsin-share-extraordinary-videos-possible-UFO-sighting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554579/Residents-rural-Wisconsin-share-extraordinary-videos-possible-UFO-sighting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 18:16:16+00:00

Strange lights shooting across rural Wisconsin skies this month were filmed by witnesses in multiple  videos obtained by DailyMail.com - with one having a spooky up-close encounter.

## Johnny Depp is 'pleased to close the door on painful chapter' after Amber Heard agreed to pay $1M
 - [https://www.dailymail.co.uk/news/article-11555117/Johnny-Depp-pleased-close-door-painful-chapter-Amber-Heard-agreed-pay-1M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555117/Johnny-Depp-pleased-close-door-painful-chapter-Amber-Heard-agreed-pay-1M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 18:13:43+00:00

The pair's lawyers have thrashed out a deal which will see Heard's insurance company pay Depp $1million. Lawyers for Depp said he is glad the 'painful chapter' is over.

## Woman accused of lying about being trafficked by an Asian gang tells court she is 'not a psychopath'
 - [https://www.dailymail.co.uk/news/article-11555135/Woman-accused-lying-trafficked-Asian-gang-tells-court-not-psychopath.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555135/Woman-accused-lying-trafficked-Asian-gang-tells-court-not-psychopath.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 18:01:49+00:00

Eleanor Williams, 22, is charged with perverting the course of justice by making allegations against a number of men, including telling police she had been trafficked and beaten by an Asian gang.

## Vile NYC anti-Semite screams 'Kanye 2024' at man before shoving him to ground in Central Park
 - [https://www.dailymail.co.uk/news/article-11554911/Vile-NYC-anti-Semite-screams-Kanye-2024-man-shoving-ground-Central-Park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554911/Vile-NYC-anti-Semite-screams-Kanye-2024-man-shoving-ground-Central-Park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 17:59:44+00:00

A New York City anti-Semite homeless man shoved a 63-year-old man to the ground in Central Park as he screamed 'Kanye 2024' in what cops are calling an 'anti-Semitic' attack.

## NYTimes opinion piece suggests Meghan had to pay with 'her life' to marry into Royal Family
 - [https://www.dailymail.co.uk/news/article-11555105/NYTimes-opinion-piece-suggests-Meghan-pay-life-marry-Royal-Family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11555105/NYTimes-opinion-piece-suggests-Meghan-pay-life-marry-Royal-Family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 17:58:01+00:00

The New York Times has been criticized over an opinion piece which accused the British Royal Family of racism and suggested Meghan Markle had to pay with 'her life' to marry into the institution.

## The 'black only' Masonic Lodge where Martin Luther King once played pool
 - [https://www.dailymail.co.uk/news/article-11554715/The-black-Masonic-Lodge-Martin-Luther-King-played-pool.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554715/The-black-Masonic-Lodge-Martin-Luther-King-played-pool.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 17:30:52+00:00

The Masonic Temple Building, which is set to undergo a $29million redevelopment, was visited Luther King as he gathered peaceful protestors for the 1963 Birmingham Campaign.

## $1.7 trillion omnibus WILL include Biden's Ukraine funding request and electoral count reform
 - [https://www.dailymail.co.uk/news/article-11554399/1-7-trillion-omnibus-include-Bidens-Ukraine-funding-request-electoral-count-reform.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554399/1-7-trillion-omnibus-include-Bidens-Ukraine-funding-request-electoral-count-reform.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 17:29:35+00:00

Congress is set to push through a massive year-long spending bill in the week before Christmas that will reportedly include President Biden's Ukraine funding request.

## Biden administration considering 'alternate path' for legal immigration from some countries
 - [https://www.dailymail.co.uk/news/article-11554883/Biden-administration-considering-alternate-path-legal-immigration-countries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554883/Biden-administration-considering-alternate-path-legal-immigration-countries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 17:27:59+00:00

The Biden administration is considering new policies that could adapt to the end of Title 42 restrictions this week, with thousands of daily migrant crossings at the southern border.

## Kaylee Goncalves' family lawyer questions if Idaho police are 'capable'
 - [https://www.dailymail.co.uk/news/article-11554837/Kaylee-Goncalves-family-lawyer-questions-Idaho-police-capable.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554837/Kaylee-Goncalves-family-lawyer-questions-Idaho-police-capable.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 17:22:48+00:00

Shannon Gray, an attorney for the Goncalves family, said they will continue to hold the Moscow Police accountable for solving the murders of four University of Idaho students.

## Kirk Cameron declares he's 'won' as two public libraries that denied him story reverse course
 - [https://www.dailymail.co.uk/news/article-11554409/Kirk-Cameron-declares-hes-won-two-public-libraries-denied-story-reverse-course.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554409/Kirk-Cameron-declares-hes-won-two-public-libraries-denied-story-reverse-course.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 17:22:38+00:00

Actor and writer Kirk Cameron is now being allowed to share his new Christian children's book at two community libraries after being rejected by others because of the messaging of the story.

## Team GB Olympic swimmer, 30, who won Commonwealth Games bronze avoids jail for attacking his fiancée
 - [https://www.dailymail.co.uk/news/article-11554475/Team-GB-Olympic-swimmer-30-won-Commonwealth-Games-bronze-avoids-jail-attacking-fianc-e.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554475/Team-GB-Olympic-swimmer-30-won-Commonwealth-Games-bronze-avoids-jail-attacking-fianc-e.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 17:18:00+00:00

James Disney-May, 30, launched a verbal attack and slapped Eleanor Cooke several times after a 'jovial' night out with friends last summer. She suffered a 'serious' brain injury during the attack.

## Moment armed robbers smash into jewellers using a pick axe and hammer and swipe £40,000 of goods
 - [https://www.dailymail.co.uk/news/article-11554807/Moment-armed-robbers-smash-jewellers-using-pick-axe-hammer-swipe-40-000-goods.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554807/Moment-armed-robbers-smash-jewellers-using-pick-axe-hammer-swipe-40-000-goods.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 17:16:03+00:00

Thomas Barney-Jones and Callum Kewmoss, both 32, were caught on CCTV smashing their way into a jewellery store in Leicester at around 2.20pm on March 26 earlier this year.

## Bodies start to pile up in hospitals in China as Covid rips through the country
 - [https://www.dailymail.co.uk/news/article-11553993/Bodies-start-pile-hospitals-China-Covid-rips-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553993/Bodies-start-pile-hospitals-China-Covid-rips-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:56:19+00:00

Videos circulating online appear to show bodies in hospital corridors and patients packed into Chinese hospital wards as Beijing grapples to contain the latest Covid outbreak.

## Georgia man jailed after sex slaves escapes by FAKING pregnancy four months after kidnapping her
 - [https://www.dailymail.co.uk/news/article-11554463/Georgia-man-jailed-sex-slaves-escapes-FAKING-pregnancy-four-months-kidnapping-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554463/Georgia-man-jailed-sex-slaves-escapes-FAKING-pregnancy-four-months-kidnapping-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:55:58+00:00

Ismael Patricio Aguirre, 22, was arrested on December 13 after he held his ex-girlfriend captive for about four months in a Georgia motel room.

## Toronto police chief rubbishes Meghan Markle's Netflix claims that force ignored her pleas for help
 - [https://www.dailymail.co.uk/news/article-11554255/Toronto-police-chief-rubbishes-Meghan-Markles-Netflix-claims-force-ignored-pleas-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554255/Toronto-police-chief-rubbishes-Meghan-Markles-Netflix-claims-force-ignored-pleas-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:54:37+00:00

James Ramer was responding to Meghan's claims in the couple's Netflix docuseries that she was being stalked by photographers in Canada 24 hours a day.

## Sex workers in Amsterdam will have to permanently cover their windows under city's latest plan
 - [https://www.dailymail.co.uk/news/article-11554881/Sex-workers-Amsterdam-permanently-cover-windows-citys-latest-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554881/Sex-workers-Amsterdam-permanently-cover-windows-citys-latest-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:48:50+00:00

The new plan would see clients in Amsterdam book a visit by scanning a QR code, instead of directly communicating with the sex worker standing behind the illuminated window.

## DAN WOOTTON: Gary Neville betrayed Britain by comparing UK strikes to Qatar migrant workers
 - [https://www.dailymail.co.uk/news/article-11554773/DAN-WOOTTON-Gary-Neville-betrayed-Britain-comparing-UK-strikes-Qatar-migrant-workers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554773/DAN-WOOTTON-Gary-Neville-betrayed-Britain-comparing-UK-strikes-Qatar-migrant-workers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:37:00+00:00

Imagine being a Labour virtue signaller taking millions from the Qatari regime that oversaw the deaths of up to 6,500 migrant workers in the build-up to the World Cup, WRITES DAN WOOTTON

## Brixton O2 Academy crush: Woman, 23, who was working as a security guard at Asake concert dies
 - [https://www.dailymail.co.uk/news/article-11554731/O2-Brixton-Academy-crush-Woman-23-working-security-guard-Asake-concert-dies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554731/O2-Brixton-Academy-crush-Woman-23-working-security-guard-Asake-concert-dies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:28:59+00:00

A second woman, 23-year-old Gabrielle Hutchinson, has died after a suspected crush at the O2 Brixton Academy on Thursday night, the Metropolitan Police said

## Antifa 'terrorist', 22, is son of millionaire Maine SURGEON and grew up in $2million mansion
 - [https://www.dailymail.co.uk/news/article-11554415/Antifa-terrorist-22-son-millionaire-Maine-SURGEON-grew-2million-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554415/Antifa-terrorist-22-son-millionaire-Maine-SURGEON-grew-2million-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:27:41+00:00

Francis Carroll is the son of surgeon Mike Carroll and grew up in a $2million five-bedroom mansion in Kennebunkport - as well as enjoying time on his parents' yacht.

## NYC Uber operating normally despite 24 hour strike that plans to block Brooklyn Bridge
 - [https://www.dailymail.co.uk/news/article-11554445/NYC-Uber-operating-normally-despite-24-hour-strike-plans-block-Brooklyn-Bridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554445/NYC-Uber-operating-normally-despite-24-hour-strike-plans-block-Brooklyn-Bridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:27:38+00:00

A strike by Uber and Lyft drivers has failed to make much of a dent in cab availability in NYC, after a judge halted a pay rise for drivers that Uber is challenging.

## Disturbing video shows aftermath of severe turbulence on Hawaiian Airlines flight
 - [https://www.dailymail.co.uk/news/article-11554637/Disturbing-video-shows-aftermath-severe-turbulence-Hawaiian-Airlines-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554637/Disturbing-video-shows-aftermath-severe-turbulence-Hawaiian-Airlines-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:27:07+00:00

The flight from Phoenix to Honolulu on Sunday was carrying many people traveling for the holidays, and hit intense turbulence shortly before landing, sending passengers flying from their seats.

## Skateboarding Fleetwood Mac 'Dreams' TikTok star is arrested for pot possession in Idaho
 - [https://www.dailymail.co.uk/news/article-11554609/Skateboarding-Fleetwood-Mac-Dreams-TikTok-star-arrested-pot-possession-Idaho.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554609/Skateboarding-Fleetwood-Mac-Dreams-TikTok-star-arrested-pot-possession-Idaho.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:26:14+00:00

Nathan Apodaca, aka the TikTok user who went viral in 2020 for a clip of his skateboarding to Fleetwood Mac's Dreams, was arrested for marijuana possession in Idaho.

## Now Harry and Meghan are presenting a documentary on 'inspiring leaders'
 - [https://www.dailymail.co.uk/news/article-11554709/Now-Harry-Meghan-presenting-documentary-inspiring-leaders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554709/Now-Harry-Meghan-presenting-documentary-inspiring-leaders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:21:02+00:00

The couple, who appeared last week in their bombshell docuseries 'Meghan & Harry', will look at figures including the late Ruth Bader Ginsburg.

## Crypto big shots protest outside Bahamas court as Sam Bankman-Fried faces extradition hearing
 - [https://www.dailymail.co.uk/news/article-11554457/Crypto-big-shots-protest-outside-Bahamas-court-Sam-Bankman-Fried-faces-extradition-hearing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554457/Crypto-big-shots-protest-outside-Bahamas-court-Sam-Bankman-Fried-faces-extradition-hearing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:20:58+00:00

Protestors are gathered outside Bahamas  court, including Ben Armstrong - who calls himself Bitboy on social and is major player in the currency.

## Putin meets dictator Lukashenko in Belarus fuelling fears ally will join new offensive in Ukraine
 - [https://www.dailymail.co.uk/news/article-11554495/Putin-meets-dictator-Lukashenko-Belarus-fuelling-fears-ally-join-new-offensive-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554495/Putin-meets-dictator-Lukashenko-Belarus-fuelling-fears-ally-join-new-offensive-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:16:20+00:00

Putin's visit for talks with the Belarusian President is his first to Minsk since 2019 and the Russian President will focus on deepening his ties with Belarus at a time when his army is struggling.

## Tesco 'is set to axe' its remaining butchers and fishmongers in 279 stores, it is claimed
 - [https://www.dailymail.co.uk/news/article-11554299/Tesco-set-axe-remaining-butchers-fishmongers-279-stores-claimed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554299/Tesco-set-axe-remaining-butchers-fishmongers-279-stores-claimed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:12:48+00:00

Supermarket giant Tesco has refused to deny it is poised to put its in-house butcher and fishmonger on ice following a fall in interest.

## Cottage from romantic comedy The Holiday starring Cameron Diaz goes up for rent on AirBnb
 - [https://www.dailymail.co.uk/news/article-11554389/holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554389/holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:09:20+00:00

a model of the cottage has appeared on screens every festive season since the film's release in 2006. But Jon Bromley, 58, and his wife Cressida, 52, had no idea until strangers turned up to take photos.

## Mystery as Putin's underfire defence minister Sergei Shoigu is seen limping through palace hall
 - [https://www.dailymail.co.uk/news/article-11554675/Mystery-Putins-underfire-defence-minister-Sergei-Shoigu-seen-limping-palace-hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554675/Mystery-Putins-underfire-defence-minister-Sergei-Shoigu-seen-limping-palace-hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:06:19+00:00

Russian defence minister Sergei Shoigu - notionally in charge of the war - was seen limping in Palace of Independence in Minsk, with his right hand in his pocket today on a visit to Belarus.

## What will happen WHEN quake with force of hundreds of atom bombs hits SF Bay Area
 - [https://www.dailymail.co.uk/news/article-11554395/What-happen-quake-force-hundreds-atom-bombs-hits-SF-Bay-Area.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554395/What-happen-quake-force-hundreds-atom-bombs-hits-SF-Bay-Area.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:02:10+00:00

Seismologists say San Francisco is due a devastating earthquake in the not-too-distant future - potentially causing thousands of deaths and billions of dollars in damage.

## Vehicle repossessions rocket as the average monthly payment for a new car jumps 26% in three years
 - [https://www.dailymail.co.uk/news/article-11554405/Vehicle-repossessions-rocket-average-monthly-payment-new-car-jumps-26-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554405/Vehicle-repossessions-rocket-average-monthly-payment-new-car-jumps-26-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 16:01:02+00:00

A growing number of Americans are falling behind on their car payments as the lowest-income residents struggle to meet their monthly debts.

## How 'champagne socialist' Gary Neville has raked in £70m lecturing on workers' rights
 - [https://www.dailymail.co.uk/news/article-11554383/How-champagne-socialist-Gary-Neville-raked-70m-lecturing-workers-rights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554383/How-champagne-socialist-Gary-Neville-raked-70m-lecturing-workers-rights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 15:58:48+00:00

The millionaire, 47, a member of the Labour party, lectured millions watching the World Cup Final about workers' rights and compared the treatment of NHS staff to migrant workers.

## Conman who ran a Ponzi scheme  tricking rich investors jailed for nine years
 - [https://www.dailymail.co.uk/news/article-11554573/Conman-ran-Ponzi-scheme-tricking-rich-investors-jailed-nine-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554573/Conman-ran-Ponzi-scheme-tricking-rich-investors-jailed-nine-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 15:58:18+00:00

Rhys Williams, 41, from Llangristiolus, Anglesey, Wales, was sentenced to nine years in jail at Birmingham Crown Court after he tricked investors into pumping millions into his company.

## Top school clamps down on truants by sending teachers out in 'battle bus' to knock on doors
 - [https://www.dailymail.co.uk/news/article-11554377/Top-school-clamps-truants-sending-teachers-battle-bus-knock-doors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554377/Top-school-clamps-truants-sending-teachers-battle-bus-knock-doors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 15:51:18+00:00

Staff at Cumberland Community School in east London make daily home visits to every child who does not have a legitimate reason for staying away from school.

## Republican 'shadow group' to release their own Jan. 6 report
 - [https://www.dailymail.co.uk/news/article-11554419/Republican-shadow-group-release-Jan-6-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554419/Republican-shadow-group-release-Jan-6-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 15:23:55+00:00

House Republicans plan to release their own report to counter that of the January 6th committee's official findings, which are expected to include criminal referrals for Donald Trump.

## Prepare for the 'WORST Xmas getaway in history' with chaos on planes, trains and automobiles
 - [https://www.dailymail.co.uk/news/article-11554511/Prepare-WORST-Xmas-getaway-history-chaos-planes-trains-automobiles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554511/Prepare-WORST-Xmas-getaway-history-chaos-planes-trains-automobiles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 15:20:41+00:00

The AA is predicting widespread disruption on the roads, with 20million car trips set to take place in the run-up to Christmas Day amid walkouts on the railways.

## Woman, 30, is arrested for breaking into Robert De Niro's Upper East side home
 - [https://www.dailymail.co.uk/news/article-11554617/Woman-30-arrested-breaking-Robert-Niros-Upper-East-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554617/Woman-30-arrested-breaking-Robert-Niros-Upper-East-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 15:15:56+00:00

Shaunice Aviles was being followed by NYPD officers last night when she broke into De Niro's East 65th Street townhouse.

## Law student who sued university for probe after she said 'women have vaginas' has case dismissed
 - [https://www.dailymail.co.uk/news/article-11554453/Law-student-sued-university-probe-said-women-vaginas-case-dismissed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554453/Law-student-sued-university-probe-said-women-vaginas-case-dismissed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 15:11:23+00:00

Lisa Keogh, 30, who faced disciplinary action after she said that 'women have vaginas' during a class on transgender issues has vowed to carry on her legal battle after her case was dismissed

## Britain is NOT a racist country says Rishi Sunak in wake of Prince Harry and Meghan Markle claims
 - [https://www.dailymail.co.uk/news/article-11554417/Britain-NOT-racist-country-says-Rishi-Sunak-wake-Prince-Harry-Meghan-Markle-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554417/Britain-NOT-racist-country-says-Rishi-Sunak-wake-Prince-Harry-Meghan-Markle-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 15:02:24+00:00

The Prime Minister defended the Royal Family following attacks made by the Duke and Duchess of Sussex in the couple's docuseries.

## Washington woman, 60, who vanished off coast of Hawaii 'was eaten by aggressive shark'
 - [https://www.dailymail.co.uk/news/article-11554283/Washington-woman-60-vanished-coast-Hawaii-eaten-aggressive-shark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554283/Washington-woman-60-vanished-coast-Hawaii-eaten-aggressive-shark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 14:57:50+00:00

The Washington woman, 60, who disappeared while snorkeling in Hawaii on December 8 was likely killed by an aggressive shark, according to a case update.

## Pictures show Londoners enjoying themselves in the capital's pubs down the decades
 - [https://www.dailymail.co.uk/news/article-11554129/Pictures-Londoners-enjoying-capitals-pubs-decades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554129/Pictures-Londoners-enjoying-capitals-pubs-decades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 14:48:42+00:00

Photos in The London Pub, published by Hoxton Mini Press, include one showing a young soldier kissing his girlfriend in a pub in the capital on VE day in May 1945.

## Gucci and Harry Styles slammed for toddler bed ad after Balenciaga scandal
 - [https://www.dailymail.co.uk/news/article-11554095/Gucci-Harry-Styles-slammed-toddler-bed-ad-Balenciaga-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554095/Gucci-Harry-Styles-slammed-toddler-bed-ad-Balenciaga-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 14:42:40+00:00

Styles appears in the new 'HA HA HA' Gucci campaign in an array of outfits and with different props. The images were released on November 2, before the Balenciaga scandal.

## Emergency response teams rush to frozen lake after three youths were seen playing on it
 - [https://www.dailymail.co.uk/news/article-11554287/Emergency-response-teams-rush-frozen-lake-three-youths-seen-playing-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554287/Emergency-response-teams-rush-frozen-lake-three-youths-seen-playing-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 14:41:15+00:00

The emergency team's response came after three people had been seen on the ice on both sides of the frozen lake in Trittiford Mill Park in Yardley Wood in Birmingham.

## Jeweller, 86, is £6,000 out of pocket after being tricked by conman at his shop in South Wales
 - [https://www.dailymail.co.uk/news/article-11554061/Jeweller-86-6-000-pocket-tricked-conman-shop-South-Wales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554061/Jeweller-86-6-000-pocket-tricked-conman-shop-South-Wales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 14:39:55+00:00

Tony Peach, 86, is £6,000 out of pocket after being tricked by a conman (pictured) who swapped out six 18-carat gold chains for costume jewellery at his shop in South Wales.

## New York Times defends swastika-shaped crossword published on the eve of Hanukkah
 - [https://www.dailymail.co.uk/news/article-11554343/New-York-Times-defends-swastika-shaped-crossword-published-eve-Hanukkah.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554343/New-York-Times-defends-swastika-shaped-crossword-published-eve-Hanukkah.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 14:36:34+00:00

The New York Times has responded to a outpouring of criticism over the design of its crossword puzzle on Sunday, which many prominent Jewish figures said resembled a swastika.

## Woy Woy father killed with machete identified as Nathan Strudwick, killer still at large
 - [https://www.dailymail.co.uk/news/article-11554079/Woy-Woy-father-killed-machete-identified-Nathan-Strudwick-killer-large.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554079/Woy-Woy-father-killed-machete-identified-Nathan-Strudwick-killer-large.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 14:27:13+00:00

Nathan 'Strudo' Strudwick, 41, from Woy Woy on the Central Coast, died after being struck in the neck by the blade on Saturday evening.

## Johnny Depp and Amber Heard finally settle defamation claims against each other
 - [https://www.dailymail.co.uk/news/article-11554333/Johnny-Depp-Amber-Heard-finally-settle-defamation-claims-against-other.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554333/Johnny-Depp-Amber-Heard-finally-settle-defamation-claims-against-other.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 14:26:58+00:00

Johnny Depp and ex-wife Amber Heard's lawyers have thrashed out a deal which will see Heard's insurance company pay Depp $1million to put an end to the case.

## Experts warn rise in Covid hospitalisations comes at worst possible time
 - [https://www.dailymail.co.uk/health/article-11553845/Experts-warn-rise-Covid-hospitalisations-comes-worst-possible-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11553845/Experts-warn-rise-Covid-hospitalisations-comes-worst-possible-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 14:14:25+00:00

A rise in Covid hospitalisations has come at the worst possible time, experts have warned, as the NHS is already being crippled by record backlogs, strikes and winter pressures.

## Car speeds off with man clinging to roof in Treendale, Western Australia
 - [https://www.dailymail.co.uk/news/article-11554115/Car-speeds-man-clinging-roof-Treendale-Western-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554115/Car-speeds-man-clinging-roof-Treendale-Western-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 14:04:51+00:00

The bizarre incident  where a vehicle sped off with a man clinging to the roof occurred in Treendale, 160km south of Perth in Western Australia.

## Could Elon Musk quit Twitter after poll? LIVE news
 - [https://www.dailymail.co.uk/news/live/article-11554289/Elon-Musk-quit-Twitter-poll-LIVE-news.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11554289/Elon-Musk-quit-Twitter-poll-LIVE-news.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 14:02:33+00:00

ELON MUSK LIVE BLOG: Will Elon Musk stay or will he go? Click for latest updates.

## Elon Musk loses vote to stay on as Twitter boss - after spending $44b to buy the troubled platform
 - [https://www.dailymail.co.uk/news/live/article-11554289/Elon-Musk-loses-vote-stay-Twitter-boss-spending-44b-buy-troubled-platform.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11554289/Elon-Musk-loses-vote-stay-Twitter-boss-spending-44b-buy-troubled-platform.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 13:49:24+00:00

ELON MUSK LIVE BLOG: Will Elon Musk stay or will he go? Click for latest updates.

## Jeremy Clarkson 'horrified to have caused so much hurt' after his column on Meghan Markle
 - [https://www.dailymail.co.uk/news/article-11554301/Jeremy-Clarkson-horrified-caused-hurt-column-Meghan-Markle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554301/Jeremy-Clarkson-horrified-caused-hurt-column-Meghan-Markle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 13:49:07+00:00

The Grand Tour presenter, 62, was blasted for saying he dreams of Meghan Markle being 'paraded naked through the streets'.

## Sainsbury's sparks furious backlash from shoppers as barriers won't open until a receipt is scanned
 - [https://www.dailymail.co.uk/news/article-11554179/Sainsburys-sparks-furious-backlash-shoppers-barriers-wont-open-receipt-scanned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554179/Sainsburys-sparks-furious-backlash-shoppers-barriers-wont-open-receipt-scanned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 13:48:06+00:00

A handful of self-checkouts at the supermarket giant now have barriers that require customers to show proof of purchase to leave the store by using receipt scanners.

## Drunk driver Shelvin Singh avoids jail after crashing BMW into parked cars in Glenorie
 - [https://www.dailymail.co.uk/news/article-11553825/Drunk-driver-Shelvin-Singh-avoids-jail-crashing-BMW-parked-cars-Glenorie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553825/Drunk-driver-Shelvin-Singh-avoids-jail-crashing-BMW-parked-cars-Glenorie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 13:47:00+00:00

Father-of-two Shelvin Singh copped a 12 month suspended jail sentence, seven months after he busted behind the wheel almost five-times the legal limit in Glenorie in Sydney's north-west.

## British angler lands 30 STONE catfish after 'fight of his life' in Thailand
 - [https://www.dailymail.co.uk/news/article-11554271/British-angler-lands-30-STONE-catfish-fight-life-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554271/British-angler-lands-30-STONE-catfish-fight-life-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 13:45:01+00:00

Dean McEwan (centre), a 36-year-old oil rig engineer from Renfrewshire in Scotland, was stunned when he hooked in the monster Mekong catfish while on a fishing trip at Palm Tree Lagoon Fishery.

## PM urges allies to send MORE arms to Ukraine and to 'call out' Iran's supply of weaponry to Russia
 - [https://www.dailymail.co.uk/news/article-11554165/PM-urges-allies-send-arms-Ukraine-call-Irans-supply-weaponry-Russia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554165/PM-urges-allies-send-arms-Ukraine-call-Irans-supply-weaponry-Russia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 13:41:47+00:00

The Prime Minister, attending a meeting of the British-led Joint Expeditionary Force in Riga, Latvia, pushed for a focus on 'degrading Russia's capability to regroup and to resupply'.

## Primary school head and teacher he left his wife for both banned from profession for SATs cheating
 - [https://www.dailymail.co.uk/news/article-11554145/teachers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554145/teachers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 13:39:26+00:00

Mike Watt, 44, and the young teacher he left his wife for, 29-year-old Emma Kelly, have both been banned from the profession indefinitely for coaching pupils through their SATs exams.

## British Airways accidentally flies pet Labrador 3,000 miles in the wrong direction to Saudi Arabia
 - [https://www.dailymail.co.uk/news/article-11553597/British-Airways-accidentally-flies-pet-Labrador-3-000-miles-wrong-direction-Saudi-Arabia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553597/British-Airways-accidentally-flies-pet-Labrador-3-000-miles-wrong-direction-Saudi-Arabia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 13:37:24+00:00

James and Madison Miller, 27, were relocating from their home in Berkhamsted, Hertfordshire, to Nashville in Tennessee with their black Labrador Bluebell on December 1.

## The English, 1883: What TV shows and movies get right and wrong about the Wild West
 - [https://www.dailymail.co.uk/news/article-11542505/The-English-1883-TV-shows-movies-right-wrong-Wild-West.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11542505/The-English-1883-TV-shows-movies-right-wrong-Wild-West.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 13:29:11+00:00

VIDEO: As The English and 1883 receive critical acclaim, DailyMail.com examines new shows - and famed Western films of the past - to separate fact from fiction.

## Campaigners urge Florida health chiefs to probe Miami trans-operation doctor after TikTok scandal
 - [https://www.dailymail.co.uk/news/article-11533471/Campaigners-urge-Florida-health-chiefs-probe-Miami-trans-operation-doctor-TikTok-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11533471/Campaigners-urge-Florida-health-chiefs-probe-Miami-trans-operation-doctor-TikTok-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 13:28:34+00:00

Trans patient Rylan slammed the Miami surgeon over his alleged post-op complications, saying an infection left 'half a foot of dead, rotting tissue' in his abdomen that almost killed him.

## Bankrupt Boris Becker will describe prison terror in £435,000 TV interview airing TOMORROW
 - [https://www.dailymail.co.uk/news/article-11554137/Bankrupt-Boris-Becker-prison-terror-435-000-TV-interview-airing-TOMORROW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554137/Bankrupt-Boris-Becker-prison-terror-435-000-TV-interview-airing-TOMORROW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 12:57:39+00:00

EXCLUSIVE: Becker was released from HMP Hunterscombe last Thursday. Final editing of the interview has gone right down to the wire for Tuesday's transmission on German channel Sat 1.

## Juror in Benjamin Mendy rape trial is discharged for medical reasons as jury returns to court
 - [https://www.dailymail.co.uk/news/article-11554003/Juror-Benjamin-Mendy-rape-trial-discharged-medical-reasons-jury-returns-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554003/Juror-Benjamin-Mendy-rape-trial-discharged-medical-reasons-jury-returns-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 12:48:23+00:00

The Manchester footballer, 28, and his co-accused Louis Saha Matturie, 41, have been on trial since August 10, accused of multiple sex offences against young women.

## Seven-month-old baby savaged by two pit bulls is left brain damaged with horrific injuries
 - [https://www.dailymail.co.uk/news/article-11554051/Seven-month-old-baby-savaged-two-pit-bulls-left-brain-damaged-horrific-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554051/Seven-month-old-baby-savaged-two-pit-bulls-left-brain-damaged-horrific-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 12:45:40+00:00

The baby's grandfather said that Semaj was in the babysitter's house when her daughter opened their cellar door, which led to the pit bulls escaping.

## Royal Mint leaves Britons puzzled after sharing Twitter image of Charles III on new coin
 - [https://www.dailymail.co.uk/news/article-11553939/Royal-Mint-leaves-Britons-puzzled-sharing-Twitter-image-Charles-III-new-1p-coin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553939/Royal-Mint-leaves-Britons-puzzled-sharing-Twitter-image-Charles-III-new-1p-coin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 12:44:32+00:00

The Royal Mint has been left red-faced after an effort to make its launch of a new Sovereign featuring King Charles go viral online sparked general confusion and ridicule.

## Health Secretary Steve Barclay gets confronted again
 - [https://www.dailymail.co.uk/health/article-11553943/Health-Secretary-Steve-Barclay-gets-confronted-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11553943/Health-Secretary-Steve-Barclay-gets-confronted-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 12:44:00+00:00

The Health Secretary met with Sarah Pinnington-Auld at King's College Hospital in London today. her three-year-old daughter Lucy suffers with the genetic condition cystic fibrosis.

## Soldier of 20 years, 37, thrown out of military for sexually assaulting a female colleague at party
 - [https://www.dailymail.co.uk/news/article-11553959/Soldier-20-years-37-thrown-military-sexually-assaulting-female-colleague-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553959/Soldier-20-years-37-thrown-military-sexually-assaulting-female-colleague-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 12:37:59+00:00

Warrant Officer Adam Graham, 37, put his hand under a female colleague's dress and grabbed her during a military function at a hotel.

## Argentina's President tells Putin 'the world needs unity and peace' in swipe at Ukraine invasion
 - [https://www.dailymail.co.uk/news/article-11554021/Argentinas-President-tells-Putin-world-needs-unity-peace-swipe-Ukraine-invasion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554021/Argentinas-President-tells-Putin-world-needs-unity-peace-swipe-Ukraine-invasion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 12:37:18+00:00

The Russian foreign ministry tweeted that Putin had 'warmly congratulated' Fernandez on Lionel Messi's team beating France 4-2 in the penalty shootout in the World Cup final.

## Mum and three children missing in Sydney: Koshigaya Park, Campbelltown: Elizabeth Harpley
 - [https://www.dailymail.co.uk/news/article-11553753/Mum-three-children-missing-Sydney-Koshigaya-Park-Campbelltown-Elizabeth-Harpley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553753/Mum-three-children-missing-Sydney-Koshigaya-Park-Campbelltown-Elizabeth-Harpley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 12:33:58+00:00

Elizabeth Harpley, 36, and Mathew and Christopher Harpley, and Mitchell Devine-Harpley, aged 10, nine and five, were last seen at Koshigaya Park, in Campbelltown, south-west Sydney at 2pm on Sunday.

## Rail strikes and cold weather hit High Street footfall in run up to Christmas
 - [https://www.dailymail.co.uk/news/article-11553801/Rail-strikes-cold-weather-hit-High-Street-footfall-run-Christmas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553801/Rail-strikes-cold-weather-hit-High-Street-footfall-run-Christmas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 12:29:39+00:00

Industrial action on Tuesday and Wednesday saw high street footfall drop by an average of 15.7 per cent, with the number of shoppers visiting central London down by 31 per cent alone.

## Son, 27, who mowed down his mother's lover is jailed for nine years
 - [https://www.dailymail.co.uk/news/article-11553915/Son-27-mowed-mothers-lover-jailed-nine-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553915/Son-27-mowed-mothers-lover-jailed-nine-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 12:26:17+00:00

Adam Dixon (pictured), 27, left former NHS consultant Tarek Youssef fighting for life after twice running over him as the victim was trying to mediate between him and his mother Tracey.

## Cheers for Charles! Ministers could extend pub opening hours until 1am for Coronation weekend
 - [https://www.dailymail.co.uk/news/article-11554023/Cheers-Charles-Ministers-extend-pub-opening-hours-1am-Coronation-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11554023/Cheers-Charles-Ministers-extend-pub-opening-hours-1am-Coronation-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 11:54:02+00:00

The Government is consulting on proposals to allow bars to open past the usual 11pm cut-off until 1am across the who bank holiday weekend when he is crowned at Westminster next May.

## Poll shows 57.5% of people DO want Elon Musk to step down as head of Twitter
 - [https://www.dailymail.co.uk/news/article-11553917/Poll-shows-57-5-people-want-Elon-Musk-step-head-Twitter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553917/Poll-shows-57-5-people-want-Elon-Musk-step-head-Twitter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 11:45:25+00:00

Elon Musk might be on the way out as head of Twitter after nearly 60 per cent of his followers voted for him to be sacked. More than 17million people cast their vote in a poll asking if he should quit his job.

## Bodybuilder who was banned from local pubs jailed after slapping a woman's bottom
 - [https://www.dailymail.co.uk/news/article-11553755/Bodybuilder-banned-local-pubs-jailed-slapping-womans-bottom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553755/Bodybuilder-banned-local-pubs-jailed-slapping-womans-bottom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 11:44:53+00:00

Craig Howman, 31, from Hartford, Northwich pleaded guilty at Chester Magistrates Court to sexual assault, being drunk and disorderly, cocaine possession, and obstructing a police officer.

## Police link 'horrifically violent' murders of two men, 31 and 42, brutally gunned down in Belfast
 - [https://www.dailymail.co.uk/news/article-11553673/Police-link-horrifically-violent-murders-two-men-31-42-brutally-gunned-Belfast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553673/Police-link-horrifically-violent-murders-two-men-31-42-brutally-gunned-Belfast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 11:23:16+00:00

Sean Fox, 42, and Mark Hall, 31, were 'executed' by masked gunmen at close range and in broad daylight in West Belfast just under a year apart.

## Massive explosion rips through Russian oil and gas field sparking 'Armageddon' blaze
 - [https://www.dailymail.co.uk/news/article-11553783/Massive-explosion-rips-Russian-oil-gas-field-sparking-Armageddon-blaze.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553783/Massive-explosion-rips-Russian-oil-gas-field-sparking-Armageddon-blaze.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 11:20:46+00:00

Armageddon-like flames shot into the sky from the giant blaze at the Markovskoye condensate treatment unit in east Siberia, Russia, in the biting minus 22C cold.

## Rise in Brits dropping out workforce puts UK fourth in global league table of economic inactivity
 - [https://www.dailymail.co.uk/news/article-11553687/Rise-Brits-dropping-workforce-puts-UK-fourth-global-league-table-economic-inactivity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553687/Rise-Brits-dropping-workforce-puts-UK-fourth-global-league-table-economic-inactivity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 11:16:02+00:00

A study by the Office for National Statistics revealed only Colombia, Chile and Switzerland had seen a larger increase in their  rates of economic inactivity since the end of 2019.

## Government plans to deport asylum seekers to Rwanda are lawful, High Court rules
 - [https://www.dailymail.co.uk/news/article-11553757/Government-plans-deport-asylum-seekers-Rwanda-lawful-High-Court-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553757/Government-plans-deport-asylum-seekers-Rwanda-lawful-High-Court-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:51:12+00:00

The news is a boost to Home Secretary Suella Braverman, who said it would be her 'dream' to send a flight of Channel migrants to Rwanda.

## Haunting moment dog walker sees a 'demonic figure' crawling across the path of country park
 - [https://www.dailymail.co.uk/news/article-11553689/Haunting-moment-dog-walker-sees-demonic-figure-crawling-path-country-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553689/Haunting-moment-dog-walker-sees-demonic-figure-crawling-path-country-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:50:52+00:00

Hannah and Dave Rowett were walking their labradors through the haunted forest in Clumber Park, Nottinghamshire, at around 6:30am earlier this month when Mrs Rowett 'felt they weren't alone'.

## Macron's speech to France players after World Cup final is mocked
 - [https://www.dailymail.co.uk/news/article-11553529/Macron-speech-France-players-World-Cup-final-mocked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553529/Macron-speech-France-players-World-Cup-final-mocked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:50:13+00:00

Emmanuel Macron has been mocked incessantly after he was unable to take a hint and leave French football players alone following their loss to Argentina.

## College basketball player is shot dead while sitting in a Mercedes at a New Jersey nature reserve
 - [https://www.dailymail.co.uk/news/article-11553585/College-basketball-player-shot-dead-sitting-Mercedes-New-Jersey-nature-reserve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553585/College-basketball-player-shot-dead-sitting-Mercedes-New-Jersey-nature-reserve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:49:45+00:00

Phil Urban, 20, played for Post University in Connecticut before he was killed. He was shot at around 7pm at the Hopewell Valley Nature Preserve.

## Mother issues warning to other drivers after finding strange 'X' markings on her car windows
 - [https://www.dailymail.co.uk/news/article-11553733/Mother-issues-warning-drivers-finding-strange-X-markings-car-windows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553733/Mother-issues-warning-drivers-finding-strange-X-markings-car-windows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:49:13+00:00

Laura Morgan, from Wallasey, Merseyside, first noticed the crosses drawn onto the window of her car around two months ago, and some believe they are used by would-be burglars  to communicate.

## Family of Rachel Nickell consider legal action against the Met Police
 - [https://www.dailymail.co.uk/news/article-11553497/nickell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553497/nickell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:48:55+00:00

Andre Hanscombe and his son Alex (pictured) - who, at age two, was the only witness when his mother was stabbed 49 times - are considering landmark legal action against the Met.

## Earth could face a mass EXTINCTION by 2100
 - [https://www.dailymail.co.uk/sciencetech/article-11553489/Earth-face-mass-EXTINCTION-2100.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-11553489/Earth-face-mass-EXTINCTION-2100.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:44:07+00:00

Earth could lose 10 per cent of all plant and animal species by 2050, rising to 27 per cent by 2100, say scientists at the European Commission and Flinders University, Adelaide, Australia.

## Video footage emerges in alleged Hindley Street car park gang rape: Adelaide
 - [https://www.dailymail.co.uk/news/article-11553387/Video-footage-emerges-alleged-Hindley-Street-car-park-gang-rape-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553387/Video-footage-emerges-alleged-Hindley-Street-car-park-gang-rape-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:34:47+00:00

The accused, aged between 16 and 23, were charged over the alleged sexual assault of two women, 18 and 19, in Adelaide's Plaza Hotel car park on Hindley Street on December 3.

## Grieving father of murdered Alesha MacPhail smashed window of car owned by family of killer
 - [https://www.dailymail.co.uk/news/article-11553499/Grieving-father-murdered-Alesha-MacPhail-smashed-window-car-owned-family-killer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553499/Grieving-father-murdered-Alesha-MacPhail-smashed-window-car-owned-family-killer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:34:34+00:00

The grief-stricken father of murdered schoolgirl Alesha MacPhail was fined for vandalising a car belonging to the killer's family after being overwhelmed with 'anger and trauma'.

## Four young boys who fell through ice on frozen Solihull lake died from drowning, inquest hears
 - [https://www.dailymail.co.uk/news/article-11553707/Four-young-boys-fell-ice-frozen-Solihull-lake-died-drowning-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553707/Four-young-boys-fell-ice-frozen-Solihull-lake-died-drowning-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:24:25+00:00

Four young boys who fell through ice on a frozen lake in Solihull died from drowning, an inquest has heard.

## Coles Highpoint store grand opening in Melbourne sparks scenes of pandemonium over goodie bags
 - [https://www.dailymail.co.uk/news/article-11553363/Coles-Highpoint-store-grand-opening-Melbourne-sparks-scenes-pandemonium-goodie-bags.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553363/Coles-Highpoint-store-grand-opening-Melbourne-sparks-scenes-pandemonium-goodie-bags.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:22:03+00:00

There were wild scenes as hundreds of shoppers flocked to Melbourne's Highpoint for the much-anticipated opening of the shopping centre's first ever Coles

## Chancellor Jeremy Hunt confirms he will hold his first proper Budget on March 15 next year
 - [https://www.dailymail.co.uk/news/article-11553709/Chancellor-Jeremy-Hunt-confirms-hold-proper-Budget-March-15-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553709/Chancellor-Jeremy-Hunt-confirms-hold-proper-Budget-March-15-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:08:03+00:00

Jeremy Hunt will set out a Spring Budget on March 15 2023, the Treasury has announced today

## BT boss, 70, who beat his wife to death WINS court battle to claim a share of her £2.5m estate
 - [https://www.dailymail.co.uk/news/article-11553581/BT-boss-70-beat-wife-death-WINS-court-battle-claim-share-2-5m-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553581/BT-boss-70-beat-wife-death-WINS-court-battle-claim-share-2-5m-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:06:22+00:00

Ex-BT executive Leslie Winnister bludgeoned his wife of 40 years, Suzanne, to death in their Kent home while in the grip of delusions that she was having an affair and trying to poison him.

## Moment reckless driver attempts to overtake tractor on blind corner forcing car onto verge [Video]
 - [https://www.dailymail.co.uk/news/article-11553483/Moment-reckless-driver-attempts-overtake-tractor-blind-corner-forcing-car-verge-Video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553483/Moment-reckless-driver-attempts-overtake-tractor-blind-corner-forcing-car-verge-Video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:05:50+00:00

The driver of a silver Toyota Yaris, on the B4348 on Herefordshire,  pulled into the opposite lane behind another car which was attempting to overtake a tractor on a blind corner.

## Former road sweeper, 55, who ran a scheme owing the taxman £171,000 avoids jail
 - [https://www.dailymail.co.uk/news/article-11553501/Former-road-sweeper-55-ran-scheme-owing-taxman-171-000-avoids-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553501/Former-road-sweeper-55-ran-scheme-owing-taxman-171-000-avoids-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:05:11+00:00

Simon Stepsys, 55, from Nantwich, Cheshire, was sentenced to 16 weeks jail suspended for a year at Warrington Magistrates' court after he pleaded guilty to failing to keep proper accounting records.

## Defiant Gary Neville hits back at critics after his World Cup rant
 - [https://www.dailymail.co.uk/news/article-11553511/Defiant-Gary-Neville-hits-critics-World-Cup-rant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553511/Defiant-Gary-Neville-hits-critics-World-Cup-rant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:02:50+00:00

The former Manchester United defender turned pundit, a member of  Labour, has been accused of rank hypocrisy after signing a deal with the Qatari state broadcaster.

## Family of alcoholic banker who hanged himself after GP told him to drink again awarded £700k payout
 - [https://www.dailymail.co.uk/news/article-11553517/Family-alcoholic-banker-hanged-GP-told-drink-awarded-700k-payout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553517/Family-alcoholic-banker-hanged-GP-told-drink-awarded-700k-payout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 10:00:07+00:00

Successful businessman Stephen Appleton, 51, hanged himself on April 12, 2018 - eight days after his doctor told him to start drinking again, fearing that suddenly stopping could lead to a fatal seizure.

## Prince Andrew's armed protection police are being replaced by private security officers
 - [https://www.dailymail.co.uk/news/article-11553441/Prince-Andrews-armed-protection-police-replaced-private-security-officers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553441/Prince-Andrews-armed-protection-police-replaced-private-security-officers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 09:53:37+00:00

King Charles may now personally pay the £3million a year bill for his brother's new team of bodyguards, it's been reported.

## Strikemare before Christmas: Week of walkout hell starts TODAY
 - [https://www.dailymail.co.uk/news/article-11553333/Strikemare-Christmas-Week-walkout-hell-starts-TODAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553333/Strikemare-Christmas-Week-walkout-hell-starts-TODAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 08:39:29+00:00

Patients have been urged to 'make their own way to hospital' on Wednesday when ambulance workers take industrial action that critics fear could lead to deaths.

## 'Shut up and do as you're told': Jacob Rees-Mogg slams military top brass over strike complaints
 - [https://www.dailymail.co.uk/news/article-11553399/Shut-youre-told-Jacob-Rees-Mogg-slams-military-brass-strike-complaints.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553399/Shut-youre-told-Jacob-Rees-Mogg-slams-military-brass-strike-complaints.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 08:37:02+00:00

Former business secretary Jacob Rees-Mogg lashed out after the head of the Armed Forces said troops should not be treated as 'spare capacity' to cover for industrial action.

## Terrifying moment 'out of control' Thai warship starts sinking after capsizing during storm
 - [https://www.dailymail.co.uk/news/article-11553359/Terrifying-moment-control-Thai-warship-starts-sinking-capsizing-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553359/Terrifying-moment-control-Thai-warship-starts-sinking-capsizing-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 08:21:32+00:00

Video shows the HTMS Sukhothai dramatically heeling to one side and water surging towards desperate sailors who were clinging to the railings off the coast of Thailand.

## Hillsong founder Brian Houston admits father Frank was a serial child rapist as he stands trial
 - [https://www.dailymail.co.uk/news/article-11553321/Hillsong-founder-Brian-Houston-admits-father-Frank-serial-child-rapist-stands-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553321/Hillsong-founder-Brian-Houston-admits-father-Frank-serial-child-rapist-stands-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 08:08:01+00:00

Brian Houston is standing trial for allegedly covering up his father's serial sexual abuse until his father's death in 2004 and has pleaded not guilty in Sydney's Downing Centre Court.

## Lollipop lady, 87, dies in car crash on road she campaigned to make safer in 'tragic irony'
 - [https://www.dailymail.co.uk/news/article-11553303/Lollipop-lady-87-dies-car-crash-road-campaigned-make-safer-tragic-irony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553303/Lollipop-lady-87-dies-car-crash-road-campaigned-make-safer-tragic-irony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 07:37:50+00:00

Irene Allen (pictured), who is thought to have been 'the first lollipop lady in Bury' was seriously injured after being involved in a collision in Walmersley Road in the town on December 6.

## Twitter bans 'promotion' of other social media platforms
 - [https://www.dailymail.co.uk/news/article-11553161/Twitter-bans-promotion-social-media-platforms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553161/Twitter-bans-promotion-social-media-platforms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 07:37:39+00:00

Elon Musk U-turned on a Twitter policy that would see accounts linking to other social media platforms deleted and potentially suspended.

## Texas congressman shares 'dire' footage from El Paso processing center showing overcrowded facility
 - [https://www.dailymail.co.uk/news/article-11553219/Texas-congressman-shares-dire-footage-El-Paso-processing-center-showing-overcrowded-facility.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553219/Texas-congressman-shares-dire-footage-El-Paso-processing-center-showing-overcrowded-facility.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 07:34:04+00:00

Rep. Tony Gonzales, a Republican, spoke on Sunday morning about his visit to one of the processing centers in El Paso, which has seen thousands of migrants apprehended per day.

## Poll to sack Musk as Twitter Head edges towards his defeat after he promises to listen to followers
 - [https://www.dailymail.co.uk/news/article-11553297/Poll-sack-Musk-Twitter-Head-edges-defeat-promises-listen-followers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553297/Poll-sack-Musk-Twitter-Head-edges-defeat-promises-listen-followers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 07:29:24+00:00

Elon Musk has vowed to step down as head of the social media giant if his followers vote for him to be sacked - and the odds are not currently in his favor.

## Elon Musk's 'stalker' is an Uber Eats worker who thinks Tesla boss is stalking HIM
 - [https://www.dailymail.co.uk/news/article-11553111/Elon-Musks-stalker-Uber-Eats-worker-thinks-Tesla-boss-stalking-HIM.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553111/Elon-Musks-stalker-Uber-Eats-worker-thinks-Tesla-boss-stalking-HIM.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 07:28:04+00:00

Brandon Collado claimed that Musk knew his location at all times and was 'stalking him,' a recent report unmasking the seemingly unstable masked man asserts.

## Horrified bloodied passengers describe sudden rollercoaster drop on Hawaiian Airlines flight
 - [https://www.dailymail.co.uk/news/article-11553177/Horrified-bloodied-passengers-sudden-rollercoaster-drop-Hawaiian-Airlines-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553177/Horrified-bloodied-passengers-sudden-rollercoaster-drop-Hawaiian-Airlines-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 07:24:18+00:00

Passengers have been speaking of the terror they felt when the plane they were traveling on from Arizona to Hawaii suddenly hit severe turbulence and felt as though it was dropping.

## Cranebrook murder probe: Manhunt underway as police issue chilling warning after woman's death
 - [https://www.dailymail.co.uk/news/article-11552891/Cranebrook-murder-probe-Manhunt-underway-police-issue-chilling-warning-womans-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552891/Cranebrook-murder-probe-Manhunt-underway-police-issue-chilling-warning-womans-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 07:11:01+00:00

Emergency services were called to a Cranebrook home, in Sydney's west, about 2.30pm on Sunday and found a woman with serious injuries who was pronounced dead at the scene.

## Zoe Foster-Blake suffers a $30MILLION blow
 - [https://www.dailymail.co.uk/news/article-11553073/Zoe-Foster-Blake-suffers-30MILLION-blow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553073/Zoe-Foster-Blake-suffers-30MILLION-blow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 06:56:29+00:00

Entrepreneur Zoe Foster-Blake has suffered a $30million blow as the value of her share of Go-To - the skincare range she founded - is written down.

## Wieambilla shooting: Alan Dare to be buried in Ford shirt as son Corey Richards makes funeral plea
 - [https://www.dailymail.co.uk/news/article-11553005/Wieambilla-shooting-Alan-Dare-buried-Ford-shirt-son-Corey-Richards-makes-funeral-plea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553005/Wieambilla-shooting-Alan-Dare-buried-Ford-shirt-son-Corey-Richards-makes-funeral-plea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 06:43:27+00:00

The stepson of a man gunned down by a conspiracy theorist trio has made an impassioned burial request as he plans the funeral outfit for his murdered 'hero'.

## David Jones is sold to Anchorage Capital Partners for a pitiful $100million
 - [https://www.dailymail.co.uk/news/article-11553213/David-Jones-sold-Anchorage-Capital-Partners-pitiful-100million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553213/David-Jones-sold-Anchorage-Capital-Partners-pitiful-100million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 06:31:38+00:00

Iconic department store David Jones has been sold to private equity firm Anchorage Capital Partners for just $100million.

## Anzac Bridge crash: Adeeb Sukkar allegedly caught speeding days before fatal incident
 - [https://www.dailymail.co.uk/news/article-11553273/Anzac-Bridge-crash-Adeeb-Sukkar-allegedly-caught-speeding-days-fatal-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553273/Anzac-Bridge-crash-Adeeb-Sukkar-allegedly-caught-speeding-days-fatal-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 06:15:25+00:00

The driver allegedly responsible for the deaths of two people in a fatal crash on the Anzac Bridge was stopped by police days earlier for speeding while overtaking, a court has heard.

## Is this the reason Scott Morrison lost the election?
 - [https://www.dailymail.co.uk/news/article-11552457/Is-reason-Scott-Morrison-lost-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552457/Is-reason-Scott-Morrison-lost-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 06:09:38+00:00

A damning review into the Coalition's Federal Election loss claims the Liberals are out of touch with 'modern Australia'.

## Oscar cavoodle court battle: Owner Mark Gillespie claims he 'couldn't afford' to fight Gina Edwards
 - [https://www.dailymail.co.uk/news/article-11553087/Oscar-cavoodle-court-battle-Owner-Mark-Gillespie-claims-afford-fight-Gina-Edwards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553087/Oscar-cavoodle-court-battle-Owner-Mark-Gillespie-claims-afford-fight-Gina-Edwards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 05:58:00+00:00

The man who purchased Oscar the cavoodle told a court he only gave up custody of the Instagram-famous pooch because he could not afford to fight a barrister who called herself the dog's 'mymmy'.

## Airports experience violent spike as police warn 'air rage' will not be tolerated for Christmas
 - [https://www.dailymail.co.uk/news/article-11553031/Airports-experience-violent-spike-police-warn-air-rage-not-tolerated-Christmas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553031/Airports-experience-violent-spike-police-warn-air-rage-not-tolerated-Christmas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 05:45:26+00:00

Australian airports are seeing an increase in incidents of 'air-rage' as passengers struggle with delayed and cancelled flights amid airlines ramping up again after the Covid pandemic.

## Adams warns there will be 15 busloads of migrants arriving in NYC each week after Title 42 lifted
 - [https://www.dailymail.co.uk/news/article-11553097/Adams-warns-15-busloads-migrants-arriving-NYC-week-Title-42-lifted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553097/Adams-warns-15-busloads-migrants-arriving-NYC-week-Title-42-lifted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 05:42:08+00:00

New York City Mayor Eric Adams is warning of 10 to 15 busloads bringing at least a thousand migrants to the Big Apple each week once Title 42 is lifted on Wednesday.

## Elderly man is found dead at a brothel in Hornsby, Sydney
 - [https://www.dailymail.co.uk/news/article-11553109/Elderly-man-dead-brothel-Hornsby-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553109/Elderly-man-dead-brothel-Hornsby-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 05:32:25+00:00

An elderly man has been found dead at a Sydney brothel.

## Wind turbines installed on Victoria's Gippsland coast will harness Bass Strait wild weather
 - [https://www.dailymail.co.uk/news/article-11552895/Wind-turbines-installed-Victorias-Gippsland-coast-harness-Bass-Strait-wild-weather.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552895/Wind-turbines-installed-Victorias-Gippsland-coast-harness-Bass-Strait-wild-weather.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 05:27:17+00:00

Victoria's south coast will become home to turbine projects. Victorian and Australian governments are hoping to capture the energy of the Bass Strait's wild weather for Australian homes.

## Baby spinach recall: Hundreds hallucinate, in state of delirium after eating the toxic plant
 - [https://www.dailymail.co.uk/news/article-11552903/Baby-spinach-recall-Hundreds-hallucinate-state-delirium-eating-toxic-plant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552903/Baby-spinach-recall-Hundreds-hallucinate-state-delirium-eating-toxic-plant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 05:25:12+00:00

The NSW health department reported on Monday afternoon that 164 people have been affected after eating contaminated spinach, with a similar story in some other states.

## Arkansas boy, 6, found dead under floorboards at home and his sister rescued with burns on her body
 - [https://www.dailymail.co.uk/news/article-11553095/Arkansas-boy-6-dead-floorboards-home-sister-rescued-burns-body.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11553095/Arkansas-boy-6-dead-floorboards-home-sister-rescued-burns-body.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 05:15:12+00:00

Arkansas State Police have arrested a man and woman in connection to the death of the woman's six-year-old son. Ashley Roland, 28, and Nathan Bridges, 33, are being held on charges of murder.

## Angry viewers call for a Channel 10 boycott over Australia Day stance
 - [https://www.dailymail.co.uk/news/article-11552739/Angry-viewers-call-Channel-10-boycott-Australia-Day-stance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552739/Angry-viewers-call-Channel-10-boycott-Australia-Day-stance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 05:09:16+00:00

Aussies have turned against the network after its parent company announced it would not be celebrating Australia Day next year.

## Skydiving horror as person plunges into a tree near Sydney
 - [https://www.dailymail.co.uk/news/article-11552989/Skydiving-horror-person-plunges-near-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552989/Skydiving-horror-person-plunges-near-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 04:27:53+00:00

NSW Ambulance paramedics are responding to reports of a skydiving accident where a man has plunged into a tree and suffered possible injuries to his ankle, hip and back.

## Perth friends capsize boat and become stranded in lake after trying to jump wake of charter
 - [https://www.dailymail.co.uk/news/article-11552905/Perth-friends-capsize-boat-stranded-lake-trying-jump-wake-charter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552905/Perth-friends-capsize-boat-stranded-lake-trying-jump-wake-charter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 04:26:39+00:00

The group attempted to jump the wake of a charter boat before their vessel capsized on the Swan River, in Perth, Western Australia, on Sunday.

## Joyriding P-plater stranded on Bilgola Beach in Sydney's north after ute gets stuck in the sand
 - [https://www.dailymail.co.uk/news/article-11552439/Joyriding-P-plater-stranded-Bilgola-Beach-Sydneys-north-ute-gets-stuck-sand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552439/Joyriding-P-plater-stranded-Bilgola-Beach-Sydneys-north-ute-gets-stuck-sand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 04:18:17+00:00

A pair of 'young fools' have stranded themselves overnight after joyriding on a north Sydney beach. The duo were photographed escaping before council or police were aware of the scene.

## How Jasmine Vella-Arpaci swindled millions from hardworking Aussies
 - [https://www.dailymail.co.uk/news/article-11552929/How-Jasmine-Vella-Arpaci-swindled-millions-hardworking-Aussies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552929/How-Jasmine-Vella-Arpaci-swindled-millions-hardworking-Aussies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 04:05:21+00:00

A Melbourne woman has been jailed for her role in a cyber crime syndicate that stole millions of dollars from innocent Australians.

## CNN's Chris Licht slams 'uninformed' critics attacking him for making network less partisan
 - [https://www.dailymail.co.uk/news/article-11552861/CNNs-Chris-Licht-slams-uninformed-critics-attacking-making-network-partisan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552861/CNNs-Chris-Licht-slams-uninformed-critics-attacking-making-network-partisan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 04:02:53+00:00

In an interview Sunday, the network's chief executive addressed responses to his approach around featured voices on the network since being tapped to take the reigns this year.

## Moe, Victoria: 'Gentle giant' allegedly forced fed GBH after being lured to his death by 'pure evil'
 - [https://www.dailymail.co.uk/news/melbourne/article-11552565/Moe-Victoria-Gentle-giant-allegedly-forced-fed-GBH-lured-death-pure-evil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/melbourne/article-11552565/Moe-Victoria-Gentle-giant-allegedly-forced-fed-GBH-lured-death-pure-evil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 03:22:11+00:00

A young woman who lured a seven-foot-tall Moe man to his brutal death had been sleeping with him in the lead-up to his disappearance.

## Apple gift card scam: Gold Coast woman scammed out of $3500 by fake email asking for Christmas gifts
 - [https://www.dailymail.co.uk/news/article-11551959/Apple-gift-card-scam-Gold-Coast-woman-scammed-3500-fake-email-asking-Christmas-gifts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11551959/Apple-gift-card-scam-Gold-Coast-woman-scammed-3500-fake-email-asking-Christmas-gifts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 03:15:54+00:00

An Australian woman has shared her experience of being swindled out of thousands of dollars by scammers who claimed to be her boss just days into starting her new job.

## Adelaide Bunnings fight breaks out after driver stops car in front of sausage sizzle
 - [https://www.dailymail.co.uk/news/article-11552391/Adelaide-Bunnings-fight-breaks-driver-stops-car-sausage-sizzle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552391/Adelaide-Bunnings-fight-breaks-driver-stops-car-sausage-sizzle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 03:01:41+00:00

The two men shouted at each other in front of stunned volunteers at a sausage sizzle at a Bunnings in Adelaide, South Australia, on Sunday.

## Salesforce CEO lays into employees hired during pandemic
 - [https://www.dailymail.co.uk/news/article-11552635/Salesforce-CEO-lays-employees-hired-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552635/Salesforce-CEO-lays-employees-hired-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 02:55:26+00:00

Marc Benioff, the billionaire CEO behind Salesforce wrote in a message to staff that new employees who had not worked in the office were less productive.

## Aboriginal elder Kerry White says Welcome to Country is not Indigenous culture
 - [https://www.dailymail.co.uk/news/article-11552185/Aboriginal-elder-Kerry-White-says-Welcome-Country-not-Indigenous-culture.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552185/Aboriginal-elder-Kerry-White-says-Welcome-Country-not-Indigenous-culture.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 02:39:20+00:00

Aboriginal elder Kerry White says that constant Welcome to Country and Acknowledgment of Country rituals are an attack on Aboriginal culture because they are no more than 'virtue signaling'.

## British drivers set to embark on 20 million car trips with increased pressure on roads due to strike
 - [https://www.dailymail.co.uk/news/article-11552719/British-drivers-set-embark-20-million-car-trips-increased-pressure-roads-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552719/British-drivers-set-embark-20-million-car-trips-increased-pressure-roads-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 02:33:27+00:00

Pressure on the roads will be heightened due to a strike by thousands of members of the Rail, Maritime and Transport union at Network Rail from 6pm on Christmas Eve.

## Couple go missing in Grampians, Victoria
 - [https://www.dailymail.co.uk/news/article-11552779/Couple-missing-Grampians-Victoria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552779/Couple-missing-Grampians-Victoria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 02:29:54+00:00

Police are appealing for public assistance to help locate a man and woman who are missing in the Grampians.

## Westconnex Sydney tunnel links M4 to M8 bypasses 52 sets of traffic lights for $5.65
 - [https://www.dailymail.co.uk/news/article-11552193/Westconnex-Sydney-tunnel-links-M4-M8-bypasses-52-sets-traffic-lights-5-65.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552193/Westconnex-Sydney-tunnel-links-M4-M8-bypasses-52-sets-traffic-lights-5-65.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 02:24:23+00:00

A 7.5km 'world class' tunnel underneath Sydney is set to save commuters up to 40 minutes when it opens in early 2023. It will join the M4 and M8 tunnels between St Peters and Haberfield.

## Bunnings chief operating officer Simon McDowell leaves top job after just one year in the role
 - [https://www.dailymail.co.uk/news/article-11552345/Bunnings-chief-operating-officer-Simon-McDowell-leaves-job-just-one-year-role.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552345/Bunnings-chief-operating-officer-Simon-McDowell-leaves-job-just-one-year-role.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 02:22:13+00:00

Bunnings chief operating officer, and second in charge, Simon McDowell has mysteriously left his senior position at the hardware retailer after just one year in the top job.

## Kari Lake says she will take her fight all the way to the Supreme Court ahead of Monday hearing
 - [https://www.dailymail.co.uk/news/article-11552685/Kari-Lake-says-fight-way-Supreme-Court-ahead-Monday-hearing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552685/Kari-Lake-says-fight-way-Supreme-Court-ahead-Monday-hearing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 02:08:22+00:00

Election denier Kari Lake promised Sunday to take her fight all the way to the Supreme Court if her case that is thrown out in a hearing on Monday in Phoenix, Arizona.

## Fake lawns could be turfed out on new housing estates as Michael Gove acts on warnings
 - [https://www.dailymail.co.uk/news/article-11552765/Fake-lawns-turfed-new-housing-estates-Michael-Gove-acts-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552765/Fake-lawns-turfed-new-housing-estates-Michael-Gove-acts-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 02:06:48+00:00

Artificial grass could be banned or restricted on newbuild property developments under plans from Michael Gove.

## Cheerful music is best at getting infants to nod off, study suggests
 - [https://www.dailymail.co.uk/news/article-11552775/Cheerful-music-best-getting-infants-nod-study-suggests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552775/Cheerful-music-best-getting-infants-nod-study-suggests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 02:04:41+00:00

Fast, happy music gets infants to nod off more effectively than slower nursery rhymes such as Little Bo Peep, a study suggests.

## Trump is accused of using copyrighted images in his NFT collection
 - [https://www.dailymail.co.uk/news/article-11552215/Trump-accused-using-copyrighted-images-NFT-collection.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552215/Trump-accused-using-copyrighted-images-NFT-collection.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 01:55:33+00:00

Former President Donald Trump's recently unleashed line of NFT 'digital trading cards' could potentially land him in legal hot water, as many of them appear to infringe on prior designs.

## DAILY MAIL COMMENT: Now strikes may be a matter of life or death
 - [https://www.dailymail.co.uk/news/article-11552763/DAILY-MAIL-COMMENT-strikes-matter-life-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552763/DAILY-MAIL-COMMENT-strikes-matter-life-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 01:53:45+00:00

DAILY MAIL COMMENT: For patients, the message could not be more stark - or more chilling. If you are frail and elderly, don't fall over at home on Wednesday.

## Investment banker fired for punching female MTA worker TWICE in the face
 - [https://www.dailymail.co.uk/news/article-11552563/Investment-banker-fired-punching-female-MTA-worker-TWICE-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552563/Investment-banker-fired-punching-female-MTA-worker-TWICE-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 01:52:26+00:00

Officials at Tocqueville Asset Management made the revelation Sunday, but would not say whether 53-year-old finance worker Jean-Francois Coste's suspension would be with or without pay.

## ITV disowns Gary Neville's comparison of rail staff to Qatar migrant workers in World Cup coverage
 - [https://www.dailymail.co.uk/sport/fifa-world-cup/article-11552275/ITV-disowns-Gary-Nevilles-comparison-rail-staff-Qatar-migrant-workers-World-Cup-coverage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/fifa-world-cup/article-11552275/ITV-disowns-Gary-Nevilles-comparison-rail-staff-Qatar-migrant-workers-World-Cup-coverage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 01:49:40+00:00

Gary Neville sparked fury yesterday by comparing striking UK workers with migrant labourers in Qatar.

## Can an air fryer save on your power bills?
 - [https://www.dailymail.co.uk/news/article-11552737/Can-air-fryer-save-power-bills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552737/Can-air-fryer-save-power-bills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 01:36:38+00:00

Air fryers use less than half the energy that an oven requires, so over time they can reduce gas and electricity bills and one fifth of all Britons are expected to use them recently.

## Hotel owner nicknamed 'Goldfinger' rakes in £60,000 a month putting up migrants
 - [https://www.dailymail.co.uk/news/article-11552687/Hotel-owner-nicknamed-Goldfinger-rakes-60-000-month-putting-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552687/Hotel-owner-nicknamed-Goldfinger-rakes-60-000-month-putting-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 01:34:47+00:00

Abid Gulzar, 78, who owns three gold Teslas and wears large gold rings, stands to make more than £700,000 of taxpayers' money a year housing migrants.

## Penny Wong will travel to China this week to make the first ministerial visit
 - [https://www.dailymail.co.uk/news/article-11552621/Penny-Wong-travel-China-week-make-ministerial-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552621/Penny-Wong-travel-China-week-make-ministerial-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 01:33:44+00:00

Penny Wong will travel to China this week to make the first ministerial visit since the communist superpower froze diplomatic relations with Australia

## Elon Musk asks Twitter if he should step down as head of app, swears to 'abide by poll results'
 - [https://www.dailymail.co.uk/news/article-11552475/Elon-Musk-asks-Twitter-step-head-app-swears-abide-poll-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552475/Elon-Musk-asks-Twitter-step-head-app-swears-abide-poll-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 01:17:03+00:00

Late Sunday evening, Elon Musk posted a poll to the social media app asking his more than 120 million followers and other users whether or not he should take a step back from his role with the company.

## Christmas beetles disappear in summer as scientists ask Australians to help in December
 - [https://www.dailymail.co.uk/news/article-11552169/Christmas-beetles-disappear-summer-scientists-ask-Australians-help-December.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552169/Christmas-beetles-disappear-summer-scientists-ask-Australians-help-December.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 01:12:34+00:00

The public is being asked to help with a major question troubling scientists - where have all the Christmas beetles gone? The colourful insects used to herald the start of Australia's summer.

## Schoolchildren should be taught about modern anti-Semitism to fight abuse levels, report says
 - [https://www.dailymail.co.uk/news/article-11552589/Schoolchildren-taught-modern-anti-Semitism-fight-abuse-levels-report-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552589/Schoolchildren-taught-modern-anti-Semitism-fight-abuse-levels-report-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 01:10:26+00:00

A report by Lord Mann of Holbeck Moor, the Government's adviser on anti-Semitism, warns of an 'alarming growth' in anti-Jewish hate among young people.

## The scrummy Xmas food taste test
 - [https://www.dailymail.co.uk/femail/food/article-11551715/The-scrummy-Xmas-food-taste-test.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/food/article-11551715/The-scrummy-Xmas-food-taste-test.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 01:09:03+00:00

Don't even think of doing the Christmas shop without taking a look at TESSA CUNNINGHAM'S guide to this year's tastiest festive fare...

## Mother's mission to help cancer-hit families
 - [https://www.dailymail.co.uk/news/article-11552575/Mothers-mission-help-cancer-hit-families.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552575/Mothers-mission-help-cancer-hit-families.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:59:15+00:00

Alice Wakeling, who was aged just seven, wanted to protect her family when doctors told her that her cancer had returned for the third time and there was nothing else they could do for her.

## Britain's Got Talent: Amanda Holden meets midwife who saved her life
 - [https://www.dailymail.co.uk/tvshowbiz/article-11552151/Britains-Got-Talent-Amanda-Holden-meets-midwife-saved-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11552151/Britains-Got-Talent-Amanda-Holden-meets-midwife-saved-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:58:36+00:00

Amanda Holden, 51, was moved to tears on Sunday night's Britain's Got Talent: The Ultimate Magician as she was reunited with the midwife who saved her life.

## Royal Family left 'baffled' by Harry and Meghan's reported demands for an apology
 - [https://www.dailymail.co.uk/news/article-11552511/Royal-Family-left-baffled-Harry-Meghans-reported-demands-apology.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552511/Royal-Family-left-baffled-Harry-Meghans-reported-demands-apology.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:57:52+00:00

The Duke and Duchess of Sussex are reportedly holding out for the Palace to apologise before they consider attending King Charles's coronation next year.

## Gifts 'were stolen by delivery driver and sold at car boot sale', angry customer claims
 - [https://www.dailymail.co.uk/news/article-11552637/Gifts-stolen-delivery-driver-sold-car-boot-sale-angry-customer-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552637/Gifts-stolen-delivery-driver-sold-car-boot-sale-angry-customer-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:54:21+00:00

Families have blasted delivery firm Evri for 'ruining Christmas' after parcels went missing, were allegedly stolen and apparently sold at a car boot sale.

## Stormzy 'gets into row with airport staff over passport issue as he's stopped from boarding flight'
 - [https://www.dailymail.co.uk/tvshowbiz/article-11552349/Stormzy-gets-row-airport-staff-passport-issue-hes-stopped-boarding-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11552349/Stormzy-gets-row-airport-staff-passport-issue-hes-stopped-boarding-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:50:57+00:00

Passengers claimed the rapper, 29, allegedly became upset when staff noticed there was a passport issue, according to The Sun.

## New York Times faces backlash after crossword puzzle published on Hanukkah shaped like a swastika
 - [https://www.dailymail.co.uk/news/article-11552265/New-York-Times-faces-backlash-crossword-puzzle-published-Hanukkah-shaped-like-swastika.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552265/New-York-Times-faces-backlash-crossword-puzzle-published-Hanukkah-shaped-like-swastika.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:36:59+00:00

The puzzle's silhouette has since caused quite the stir on social media, with several prominent Jewish leaders and political figures taking to social media to voice their outrage.

## Emails show the FBI 'repeatedly grilled' Twitter execs over 'state propaganda' on the app
 - [https://www.dailymail.co.uk/news/article-11552469/Emails-FBI-repeatedly-grilled-Twitter-execs-state-propaganda-app.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552469/Emails-FBI-repeatedly-grilled-Twitter-execs-state-propaganda-app.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:36:52+00:00

Journalist Matt Taibbi, who released the first batch of internal files about the Hunter saga earlier in December, posted emails showing the FBI's Foreign Influence Task Force wanted info.

## Cheering crowds of exhilarated soccer fans in NYC flood Times Square after nail-biting World Cup win
 - [https://www.dailymail.co.uk/news/article-11552233/Cheering-crowds-exhilarated-soccer-fans-NYC-flood-Times-Square-nail-biting-World-Cup-win.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552233/Cheering-crowds-exhilarated-soccer-fans-NYC-flood-Times-Square-nail-biting-World-Cup-win.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:30:00+00:00

Argentina supporters have flooded New York's Times Square after winning the World Cup on Sunday. The dramatic World Cup Final ended 3-3 after extra time and went to a shoot out which Argentina won 4-2.

## Rishi Sunak rallies European allies to send more support to Kyiv as Ukraine war rumbles on
 - [https://www.dailymail.co.uk/news/article-11552507/Rishi-Sunak-rallies-European-allies-send-support-Kyiv-Ukraine-war-rumbles-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552507/Rishi-Sunak-rallies-European-allies-send-support-Kyiv-Ukraine-war-rumbles-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:29:53+00:00

The Prime Minister, will announce a £250million contract that will ensure a constant flow of critical artillery ammunition to Ukraine throughout next year.

## Collie crashes owner's car into parked vehicle after accidentally putting it into drive
 - [https://www.dailymail.co.uk/news/article-11552533/Collie-crashes-owners-car-parked-vehicle-accidentally-putting-drive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552533/Collie-crashes-owners-car-parked-vehicle-accidentally-putting-drive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:20:50+00:00

Sue Brewer, 60, said the pet Freya was 'absolutely fine' after the smash this month.

## A rollicking Just William tale sees a festive prank turn in to war with his arch-enemy's gang
 - [https://www.dailymail.co.uk/news/article-11552547/A-rollicking-Just-William-tale-sees-festive-prank-turn-war-arch-enemys-gang.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11552547/A-rollicking-Just-William-tale-sees-festive-prank-turn-war-arch-enemys-gang.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:20:28+00:00

It was Hubert's mother's idea that the Outlaws versus Hubert Laneites feud should be abolished. 'Christmas, you know,' she said vaguely to William's mother, 'the season of peace and goodwill.

## Christmas Day weather forecast: Sydney, Brisbane, Melbourne to be sunny, hot after cold snap
 - [https://www.dailymail.co.uk/news/article-11551957/Christmas-Day-weather-forecast-Sydney-Brisbane-Melbourne-sunny-hot-cold-snap.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11551957/Christmas-Day-weather-forecast-Sydney-Brisbane-Melbourne-sunny-hot-cold-snap.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:16:57+00:00

Unseasonable icy weather  has gripped eastern Australia over recent days  with temperatures plummeting and cold winds making it feel like winter - but the miserable weather will be over soon.

## Members of Republican base hint that they are ready for a new generation of leader to run in 2024
 - [https://www.dailymail.co.uk/news/article-11551635/Members-Republican-base-hint-ready-new-generation-leader-run-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11551635/Members-Republican-base-hint-ready-new-generation-leader-run-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:12:00+00:00

This should be Trump territory, a gathering of grassroots conservatives in Phoenix, but interviews with dozens of attendees suggest he cannot guarantee an easy run to the 2024 nomination

## ABC star Virginia Trioli tipped for a huge move after she was snubbed by Dan Andrews
 - [https://www.dailymail.co.uk/news/article-11551921/ABC-star-Virginia-Trioli-tipped-huge-snubbed-Dan-Andrews.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11551921/ABC-star-Virginia-Trioli-tipped-huge-snubbed-Dan-Andrews.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-12-19 00:06:48+00:00

ABC presenter Virginia Trioli is rumoured to be making a return to television in an art-based program following her stoush with Victorian premier Daniel Andrews.


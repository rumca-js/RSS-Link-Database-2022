# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Louis loses mind at ex-governor on TV news
 - [https://www.youtube.com/watch?v=qq_meg7gQ1w](https://www.youtube.com/watch?v=qq_meg7gQ1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-12-20 00:00:00+00:00

👉 Rossmann chat - send Louis a letter: https://tinyurl.com/writetolouis
🔴 Nonprofit shilling site: https://fighttorepair.org/donate/
🔴 Nonprofit educational site: https://repair.wiki/w/A2337_2020_MacBook_Air

👉 Stuff: 
🔵 Senate bill: https://www.nysenate.gov/legislation/bills/2021/S4104
🔵 Assembly bill: https://nyassembly.gov/Press/?sec=story&story=102259
🔵 FTC report: https://www.ftc.gov/system/files/documents/reports/nixing-fix-ftc-report-congress-repair-restrictions/nixing_the_fix_report_final_5521_630pm-508_002.pdf
🔵 White house executive order: https://www.whitehouse.gov/briefing-room/statements-releases/2021/07/09/fact-sheet-executive-order-on-promoting-competition-in-the-american-economy/

👉 Equipment used:
🔵 Chair: https://amzn.to/3MjLrnT
🔵 Microphone: https://amzn.to/3g1hsok
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av (YOU CAN FIND THIS FOR $250 ON EBAY WITH A BROKEN FLASH FROM TIME TO TIME, I HAVE NEVER SPENT MORE THAN $300 ON THIS CAMERA!)
🔵 Lighting: https://amzn.to/3RSriGC

👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ


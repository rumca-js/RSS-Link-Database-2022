# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Mutable Instruments Plaits in 2022
 - [https://www.youtube.com/watch?v=I2nrFtcNcLQ](https://www.youtube.com/watch?v=I2nrFtcNcLQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-12-19 00:00:00+00:00

Online Plaits editor: https://pichenettes.github.io/plaits-editor/patch_bank.html
Buy a Plaits from Patchwerks: https://shrsl.com/3ud6d
Check out the Plaits clones!
After Later Pixie: https://afterlateraudio.com/products/pixie
After Later Knit: https://shrsl.com/3ud6a
After Later Beehive: https://shrsl.com/3ud69
All After Later Mutable: https://shrsl.com/3ud66
DX7 patches here: http://dxsysex.com/
Free DX7 vst: https://asb2m10.github.io/dexed/

Plaits by Mutable Instruments is the gift that keeps on giving, thanks to Emile's new firmware with 8 new synthesis modes. Let's check it out.

00:00 intro
01:45 plaits introdocution
03:02 online editor
05:24 firmware update
New Modes
06:43 subtractive synth with filter
08:51 phase distortion
10:05 dx7 bank 01
13:09 dx7 bank 02
14:38 stereo string machine
16:54 wave terrain
18:46 chiptune auto-arpeggiator

Join me on Patreon and get access to music, presets, samples, and a great community: http://bit.ly/rmrpatreon

Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Sam Bankman-Fried Agrees to Be Extradited to the US
 - [https://www.nytimes.com/2022/12/19/business/sam-bankman-fried-extradition.html](https://www.nytimes.com/2022/12/19/business/sam-bankman-fried-extradition.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-12-19 19:31:46+00:00

The disgraced FTX founder, who has been in a Bahamas prison for the past week, agreed to be sent to the United States, following a confusing day in court.

## Epic Games, Creator of Fortnite, to Pay $520 Million Over Children’s Privacy
 - [https://www.nytimes.com/2022/12/19/business/ftc-epic-games-settlement.html](https://www.nytimes.com/2022/12/19/business/ftc-epic-games-settlement.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-12-19 16:24:52+00:00

The creator of popular games like Fortnite and Rocket League violated children’s privacy and duped millions of users into unwanted purchases, federal regulators said.

## Twitter Users Say Elon Musk Should Quit as CEO
 - [https://www.nytimes.com/2022/12/19/business/elon-musk-quit-twitter.html](https://www.nytimes.com/2022/12/19/business/elon-musk-quit-twitter.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-12-19 15:35:57+00:00

After weeks of turmoil since he bought the company, Mr. Musk surveyed Twitter about whether he should remain in charge, and said he would abide by the result.

## They Created a Drug for Susannah. What About Millions of Other Patients?
 - [https://www.nytimes.com/2022/12/19/health/rare-disease-genetic-treatments.html](https://www.nytimes.com/2022/12/19/health/rare-disease-genetic-treatments.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-12-19 10:00:42+00:00

Scientists have made rapid progress in customizing drugs for ultrarare diseases. The hard part now is making such treatments on a large scale.

## Tesla’s Direct Sales Model Helps It Thwart Customer Lawsuits
 - [https://www.nytimes.com/2022/12/19/business/tesla-class-action-lawsuit-arbitration.html](https://www.nytimes.com/2022/12/19/business/tesla-class-action-lawsuit-arbitration.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-12-19 08:00:09+00:00

Sales contracts prevent buyers of the company’s electric cars from pursuing class-action suits if something goes wrong.

## Musk Asks Twitter Users If He Should Step Down After Fury Over His Policies
 - [https://www.nytimes.com/2022/12/18/technology/elon-musk-twitter-policies-chaos.html](https://www.nytimes.com/2022/12/18/technology/elon-musk-twitter-policies-chaos.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-12-19 02:46:46+00:00

Fury mounted over Mr. Musk’s moves to prevent Twitter users from sharing links to other social media platforms. The billionaire also asked whether he should remain as head of the service.


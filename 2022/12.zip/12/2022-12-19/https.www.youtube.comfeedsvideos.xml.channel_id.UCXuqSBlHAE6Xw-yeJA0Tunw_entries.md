# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Tech Support Challenge: Linus vs. Jake!
 - [https://www.youtube.com/watch?v=jGT37X3H_MA](https://www.youtube.com/watch?v=jGT37X3H_MA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-12-20 00:00:00+00:00

Thanks to 3CX for sponsoring this video! You can learn more about their live chat at: https://www.3cx.com/live-chat/free/?src=ltt

3CX is back again to sponsor yet another tech support video, but this time with a twist! Linus and Jake will go head to head to see who can resolve the most tickets. Who do you think will win?

Discuss on the forum: https://linustechtips.com/topic/1475168-we-solve-your-tech-problems-head-to-head/

Buy an Intel i7-6950X: https://geni.us/95RXnmx
Buy a AMD 6900 XT: https://geni.us/wjj4
Buy a GeForce RTX 3090: https://geni.us/uEDJA
Buy a TP-Link SG105 Network Switch: https://geni.us/WMZX

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:24 Let the games begin! (iPhone woes)
3:50 HELLO CONNOR
6:06 The first video chat
8:30 Why are you here Dr. Cutress
10:31 How is this computer overheating?
13:37 Network switches are elite
14:51 Audio issues? That's unheard of
17:06 Five minutes remaining!
19:01 Game over
21:04 Outro

## Samsung is Hiding This Monitor’s Best Feature – Odyssey OLED G8
 - [https://www.youtube.com/watch?v=PR-1tMih0fM](https://www.youtube.com/watch?v=PR-1tMih0fM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-12-19 00:00:00+00:00

Thanks to Samsung for sponsoring this video! Learn more about the S34BG85 at: https://displaysolutions.samsung.com/monitor/detail/2086/S34BG85

Samsung's new Odyssey OLED G8 is a 34" ultrawide monitor with a 175Hz refresh rate, AMD FreeSync Premium Pro, and a gorgeous QD-OLED panel. But for some reason, they don't want you to know it's QD-OLED on their website. What other secrets does this monitor hold?

Discuss on the forum: https://linustechtips.com/topic/1474967-why-does-samsung-keep-sponsoring-me-%E2%80%93-odyssey-oled-g8/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:50 Unboxing
2:07 The QD-OLED panel
4:45 Odyssey OLED G8 features
7:25 Let's take colour fringing


# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Somebody Is FINALLY Doing Something About Space Junk
 - [https://www.youtube.com/watch?v=YW00vGR-yDk](https://www.youtube.com/watch?v=YW00vGR-yDk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-12-19 14:54:01+00:00

Go to https://nordvpn.com/joescott to get a 2-year plan plus 4 additional months FREE. It’s risk-free with Nord’s 30-day money-back guarantee!
We all know space junk is a problem. Well meet the solution. Privateer Space is creating the tools necessary to clean up space debris and avoid collisions in space. If you'd like to see my full interview with co-founder Moriba Jah, check it out here on my Conversations With Joe channel:
https://youtu.be/7-vgodcgZzQ

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPGzF
Apple Podcasts 👉 https://apple.co/3j94kfq
Google Podcasts 👉 https://bit.ly/3qZCo1V

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS
https://www.youtube.com/watch?v=1hABwCY6g2U
https://in-the-sky.org/search.php?s=&amp;searchtype=Spacecraft&amp;satorder=0
https://www.space-track.org/documentation#legend
https://en.wikipedia.org/wiki/Soviet_space_dogs#Chernushka
https://history.nasa.gov/animals.html
https://www.roadsideamerica.com/story/12959
https://www.manitowoc.org/1109/Sputnikfest
https://www.reuters.com/world/us-military-reports-debris-generating-event-outer-space-2021-11-15/
https://gizmodo.com/space-station-will-make-an-emergency-maneuver-after-det-1848031344
https://www.reuters.com/world/us-military-reports-debris-generating-event-outer-space-2021-11-15/
https://web.archive.org/web/20111020092342/http://orbitaldebris.jsc.nasa.gov/newsletter/pdfs/ODQNv15i3.pdf
https://www.nasa.gov/mission_pages/station/news/orbital_debris.html
https://www.esa.int/Space_Safety/Hubble_s_impactful_life_alongside_space_debris
https://spacenews.com/fcc-approves-new-orbital-debris-rule/
https://www.esa.int/Space_Safety/Space_Debris/ESA_s_Space_Environment_Report_2022
https://spaceexplored.com/2022/03/01/apple-co-founder-steve-wozniaks-privateer-comes-out-of-stealth-mode-with-satellite-tracker-wayfinder/
https://www.emergingtechbrew.com/stories/2022/05/03/this-startup-wants-to-help-space-companies-navigate-increasingly-crowded-night-skies
https://tadviser.com/index.php/Company:Privateer_Space
https://www.nanosats.eu/sat/pono-1
https://www.alohashirtshop.com/blogs/hawaiian-lifestyle/pono-meaning
https://astroscale.com/missions/elsa-d/
https://iafastro.directory/iac/paper/id/69288/abstract-pdf/IAC-22,A6,5,1,x69288.brief.pdf?2022-03-30.11:37:23
https://spacenews.com/startups-scout-and-privateer-to-collaborate-on-space-tracking-technologies/
https://www.esa.int/Space_Safety/Clean_Space/ESA_commissions_world_s_first_space_debris_removal
https://www.wired.com/2015/05/laser-cannon-space-debris/
https://www.fastcompany.com/90789865/orbits-act-what-to-know-about-congress-effort-to-clean-up-space-debris
https://www.macfound.org/fellows/class-of-2022/

TIMESTAMPS - 
0:00 - Intro
1:58 - Space Junk History 
 3:22 - ISS Headaches
4:30 - Kessler Syndrome
5:19 - Privateer's Moriba Jah
6:50 - Steve Wozniak 
7:20 - Orbital Predictions 
9:08 - Cleaning Up Orbit 
10:57 - Sponsor - NordVPN
Future Satellite Sources
Privateer's Partnerships
Cleaning Up Orbit
More on Moriba Jah 
Sponsor - NordVPN


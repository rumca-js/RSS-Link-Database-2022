# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Lee Harvey Oswald, the CIA, and LSD: New Clues in Newly Declassified Documents
 - [https://theintercept.com/2022/12/19/lee-harvey-oswald-cia-lsd-jfk/](https://theintercept.com/2022/12/19/lee-harvey-oswald-cia-lsd-jfk/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-12-19 23:22:44+00:00

<p>An unredacted memo adds depth to our understanding of the CIA's response to allegations that Oswald worked with the spy agency.</p>
<p>The post <a href="https://theintercept.com/2022/12/19/lee-harvey-oswald-cia-lsd-jfk/" rel="nofollow">Lee Harvey Oswald, the CIA, and LSD: New Clues in Newly Declassified Documents</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Who Cares Whether Elon Musk Is CEO of Twitter? He OWNS It.
 - [https://theintercept.com/2022/12/19/twitter-elon-musk-ceo/](https://theintercept.com/2022/12/19/twitter-elon-musk-ceo/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-12-19 18:48:17+00:00

<p>In capitalism, managers aren’t in charge. They’re well-compensated employees.</p>
<p>The post <a href="https://theintercept.com/2022/12/19/twitter-elon-musk-ceo/" rel="nofollow">Who Cares Whether Elon Musk Is CEO of Twitter? He OWNS It.</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>


# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Jaki laptop lub tablet na Święta? Szukamy w ofercie Lenovo
 - [https://www.chip.pl/2022/12/lenovo-laptopy-tablety-na-swieta](https://www.chip.pl/2022/12/lenovo-laptopy-tablety-na-swieta)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 18:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2022/11/Lenovo-chip-prezentownik-2022-16.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/Lenovo-chip-prezentownik-2022-16.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Święta coraz bliżej, Mikołaj i Śnieżynki przygotowują się do krytycznego okresu, renifery są zatankowane i zaprzężone. Ale możesz pomóc Mikołajowi, samemu podejmując decyzje o prezentach – a jeśli tym o czym marzysz jest nowy sprzęt komputerowy, to Lenovo ma coś dla ciebie. Lenovo ThinkBook 15 4. generacji Święta to czas kojarzony przede wszystkim z wypoczynkiem [&#8230;]</p>

## Stworzono pierwszy taki grafen na świecie. Może zrewolucjonizować elektronikę
 - [https://www.chip.pl/2022/12/grafen-ferrimagnetyczny](https://www.chip.pl/2022/12/grafen-ferrimagnetyczny)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 18:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="776" src="https://konto.chip.pl/wp-content/uploads/2022/12/efekt-halla.png" style="margin-bottom: 10px;" width="1034" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/efekt-halla.png" style="display: block; margin: 1em auto;" /></p>
<p>Rosyjscy fizycy jako pierwsi na świecie zsyntetyzowali grafen z porządkiem ferrimagnetycznym. To może oznaczać przełom w świecie elektroniki i alternatywę dla urządzeń na bazie krzemu. Grafen to płaski materiał złożony z sześciokątów węglowych, kształtem zbliżony do plastra miodu. Ponieważ ma jednoatomową grubość, jest uważany za najlżejszy i najmocniejszy ze wszystkich znanych materiałów dwuwymiarowych. W 2018 [&#8230;]</p>

## mObywatel ma 5 lat. Dopiero teraz rząd wziął się za aplikację na poważnie
 - [https://www.chip.pl/2022/12/mobywatel-w-koncu-ustawa-i-nowa-funkcjonalnosc](https://www.chip.pl/2022/12/mobywatel-w-koncu-ustawa-i-nowa-funkcjonalnosc)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 17:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="432" src="https://konto.chip.pl/wp-content/uploads/2022/05/mobywatel-zmiany-1.jpg" style="margin-bottom: 10px;" width="1024" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/05/mobywatel-zmiany-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Aplikacja mObywatel pojawiła się w 2017 roku niejako na wyrost. Przez długi czas oferowane przez nią funkcję nijak się miały bowiem do obowiązujących przepisów, które jedynie w nielicznych przypadkach przewidywały możliwość zastąpienia nią obowiązujących fizycznych dokumentów. W końcu jednak ktoś podjął decyzję, by na poważnie zmierzyć się z problemem. W międzyczasie mObywatel zaczął obrastać w [&#8230;]</p>

## Obiektyw Google dokona niemożliwego. Ta funkcja rozszyfruje pismo lekarskie
 - [https://www.chip.pl/2022/12/obiektyw-google-rozszyfruje-pismo-lekarskie](https://www.chip.pl/2022/12/obiektyw-google-rozszyfruje-pismo-lekarskie)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 16:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2022/12/lekarz-notatka-obiektyw-google.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/lekarz-notatka-obiektyw-google.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Pismo lekarzy często bywa trudne do rozszyfrowania, z tym zapewne zgodzi się chyba każdy. Niestety, może prowadzić to do wielu, czasem nawet przykrych, konsekwencji, gdy źle odczytamy zalecenia co do leczenia. Po dziesięcioleciach żartów o tym, że powinien powstać tłumacz „z lekarskiego na ludzki”, Google postanowił w końcu to zrobić, dodając odpowiednią funkcję do narzędzia [&#8230;]</p>

## Aukcja 5G rodzi więcej pytań niż odpowiedzi. Oto wszystko, co musisz o niej wiedzieć
 - [https://www.chip.pl/2022/12/aukcja-5g-co-musisz-wiedziec-informacje](https://www.chip.pl/2022/12/aukcja-5g-co-musisz-wiedziec-informacje)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 15:27:16+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2022/10/asus-zenfone-9-15-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/10/asus-zenfone-9-15-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Aż dwa i pół roku musieliśmy czekać na start procedury aukcji częstotliwości sieci 5G. Na razie nie możemy mówić o sukcesie, a raczej o nikłym światełku w tunelu, bo pytań, wątpliwości i niedomówień w sprawie aukcji jest bardzo dużo. Są też rzeczy pewne, wynikające z przepisów, które miejmy nadzieję, będą przestrzegane. Co wiemy o aukcji [&#8230;]</p>

## Laptop na świąteczny prezent? Acer Nitro 5 będzie świetnym wyborem
 - [https://www.chip.pl/2022/12/acer-nitro-5-swieta-2022](https://www.chip.pl/2022/12/acer-nitro-5-swieta-2022)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 15:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2022/12/acer-chip-prezentownik-2022-1.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/acer-chip-prezentownik-2022-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Niegdyś wywoływały uśmiech politowania, a dziś to pełnoprawne PCty zaklęte w kompaktowej formie z monitorem, klawiaturą i substytutem myszki, które zapewniają wysoką wydajność tam, gdzie jej potrzebujecie. Rozwój hardware oraz technologii po stronie programowej sprawił, że laptopy dla graczy stały się w ostatnich latach jeszcze bardziej sensowne i opłacalne, a Acer Nitro 5 jest tego [&#8230;]</p>

## Wojskowa Akademia Techniczna opracowała nowoczesny schron na czas wojny. Rusza masowa produkcja
 - [https://www.chip.pl/2022/12/wojskowa-akademia-techniczna-schron-na-czas-wojny](https://www.chip.pl/2022/12/wojskowa-akademia-techniczna-schron-na-czas-wojny)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 14:00:00+00:00

<img alt="Bunkier" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2022/12/bunker-1569720_1920.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/bunker-1569720_1920.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Modułowy schron podwójnego przeznaczenia (zarówno na czas wojny, jak i pokoju) został opracowany przez naukowców z Wojskowej Akademii Technicznej. Polska firma nabyła licencję do produkcji tego schronu na skalę komercyjną. Wojskowa Akademia Techniczna poinformowała w komunikacie prasowym o podpisaniu umowy licencyjnej pomiędzy uczelnią a polską firmą Mahton Schrony sp. z o.o., która zajmie się wprowadzeniem [&#8230;]</p>

## Elon Musk tonie. Pora się zwijać z Twittera
 - [https://www.chip.pl/2022/12/elon-musk-twitter-koniec](https://www.chip.pl/2022/12/elon-musk-twitter-koniec)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 11:22:30+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2022/12/twitter-elon-musk-koniec-1.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/twitter-elon-musk-koniec-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Jak to było? Vox populi, vox dei? No to panie Elon Musk, pora zejść ze sceny, przekazać rolę CEO komuś bardziej kompetentnemu i trzymać kciuki, że Twittera da się jeszcze uratować. Ostatnie 24 godziny były kulminacją trwającego tam od miesiąca festiwalu absurdów. Niezależnie od jego zakończenia – pora się zwijać. Gwoli przypomnienia, Elon Musk – [&#8230;]</p>

## Energetyczny problem laptopów dla graczy. Pogoń za wyższą wydajnością odbije się nam czkawką
 - [https://www.chip.pl/2022/12/energetyczny-problem-gamingowych-laptopow](https://www.chip.pl/2022/12/energetyczny-problem-gamingowych-laptopow)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 10:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1079" src="https://konto.chip.pl/wp-content/uploads/2022/12/Laptopy-gamingowe-nowej-generajci.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/Laptopy-gamingowe-nowej-generajci.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Światło dzienne ujrzały właśnie nowe informacje na temat flagowego mobilnego procesora Intel Core 13. generacji. Jego możliwości robią wrażenie, ale jednocześnie zadają pytanie, czy aby nie odbije się to za bardzo na formie laptopów. Gamingowe laptopy idą drogą, z której może nie być odwrotu Kto raz poczuję potęgę, nie będzie chciał z niej zrezygnować, a [&#8230;]</p>

## GONET.TV to ulubiona telewizja zawsze z Tobą. Tu jest wszystko i w dodatku za grosze
 - [https://www.chip.pl/2022/12/gonet-tv-to-ulubiona-telewizja-zawsze-z-toba-tu-jest-wszystko-i-w-dodatku-za-grosze](https://www.chip.pl/2022/12/gonet-tv-to-ulubiona-telewizja-zawsze-z-toba-tu-jest-wszystko-i-w-dodatku-za-grosze)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 10:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1067" src="https://konto.chip.pl/wp-content/uploads/2022/12/gonettv-pakiety-8.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/gonettv-pakiety-8.jpg" style="display: block; margin: 1em auto;" /></p>
<p>GONET.TV to telewizja dostępna przez Internet praktycznie wszędzie tam, gdzie&#8230; jest Internet. Kosztuje niewiele na tle konkurencji, a do zaoferowania ma więcej, niż się spodziewałem. GONET.TV to usługa bardziej kompleksowa, niż się spodziewałem Trzeba coś napisać o GONET.TV &#8211; usłyszałem. Pomyślałem&#8230; niezbyt pozytywne rzeczy. Mając w głowie telewizję dostępną przez Internet miałem w głowie głównie [&#8230;]</p>

## TicWatch Pro 3 Ultra &#8211; nawet nie wiesz, jak dobry może być zegarek z Wear OS
 - [https://www.chip.pl/2022/12/ticwatch-pro-3-ultra-dobry-zegarek-z-wear-os-smartwatch](https://www.chip.pl/2022/12/ticwatch-pro-3-ultra-dobry-zegarek-z-wear-os-smartwatch)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 09:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1067" src="https://konto.chip.pl/wp-content/uploads/2022/12/ticwatch-pro-3-ultra-17.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/ticwatch-pro-3-ultra-17.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Zegarki z systemem Wear OS nie należą do najpopularniejszych urządzeń na rynku, a sam system ze względu na swoją przeszłość miewa różne opinie. Jest jednak perełka w postaci TicWatch Pro 3 Ultra, który pokazuje, że tu nie tylko jest potencjał, ale zegarek z Wear OS może być bardzo dobrym urządzeniem. Elegancki, świetnie wykonany i mniejszy, [&#8230;]</p>

## Gwiazdy zachowują się wbrew przyjętym zasadom. To częstsze niż sądziliśmy
 - [https://www.chip.pl/2022/12/gwiazdy-czerwone-olbrzymy-dziwne-zachowanie](https://www.chip.pl/2022/12/gwiazdy-czerwone-olbrzymy-dziwne-zachowanie)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 08:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2022/12/gwiazda.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/gwiazda.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Wszechświat już wielokrotnie nas zaskakiwał i zapewne jeszcze niejednokrotnie to zrobi. Tym razem tego typu dziwactwa dotyczą konkretnego rodzaju gwiazd. Chodzi o tzw. czerwone olbrzymy, czyli stosunkowo stare obiekty o niskich i średnich masach oraz niskich temperaturach na powierzchni. O tym, jak zaskakująco czasami funkcjonują te ciała niebieskie możemy przeczytać na łamach Nature Communications.  Czytaj [&#8230;]</p>

## Bloki, które pochłaniają dwutlenek węgla. Ich wydajność imponuje
 - [https://www.chip.pl/2022/12/dwutlenek-wegla-bloki-pochlaniajace-co2](https://www.chip.pl/2022/12/dwutlenek-wegla-bloki-pochlaniajace-co2)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2022-12-19 05:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="583" src="https://konto.chip.pl/wp-content/uploads/2022/12/dwutlenek-wegla.jpeg" style="margin-bottom: 10px;" width="1500" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/dwutlenek-wegla.jpeg" style="display: block; margin: 1em auto;" /></p>
<p>Holenderska firma Masterbloc oferuje przyjazny dla środowiska materiał budowlany, który nie dość, że pochodzi z częściowego recyklingu, to dodatkowo zapewnia wysoką wydajność w pochłanianiu dwutlenku węgla z powietrza. Jedną z korzystnych cech jest w tym przypadku możliwość produkowania takich bloków z użyciem pozostałości z przemysłu stalowego. Po drugie zapewniają one ujemny bilans w zakresie emisji [&#8230;]</p>


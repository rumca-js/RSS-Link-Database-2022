# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Make your noisy recording sound like pro audio with Adobe’s free AI tool
 - [https://arstechnica.com/?p=1905687](https://arstechnica.com/?p=1905687)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 23:13:35+00:00

"Enhance Speech" uses AI to make noisy podcast recordings sound like professional audio.

## Power plant pollution higher in neighborhoods subject to racist redlining
 - [https://arstechnica.com/?p=1905698](https://arstechnica.com/?p=1905698)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 22:57:18+00:00

Past maps of "high-risk" neighborhoods shape present power planet emissions.

## This mechanical keyboard has a dazzling, distracting display under its keys
 - [https://arstechnica.com/?p=1905537](https://arstechnica.com/?p=1905537)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 19:10:24+00:00

$349 peripheral uses its own CPU and GPU to power the show.

## Critical Windows code-execution vulnerability went undetected until now
 - [https://arstechnica.com/?p=1905587](https://arstechnica.com/?p=1905587)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 18:46:33+00:00

Microsoft elevates security rating for vulnerability resembling EternalBlue.

## Someone tries to sell a Pixel Tablet prototype, posts pictures
 - [https://arstechnica.com/?p=1905513](https://arstechnica.com/?p=1905513)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 18:07:37+00:00

Dubious listing gives us the first real-life pictures of Google's upcoming tablet.

## Lobbyists have held up nation’s first right-to-repair bill in New York
 - [https://arstechnica.com/?p=1905487](https://arstechnica.com/?p=1905487)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 18:04:31+00:00

Passed with bipartisan support, the bill could die on Gov. Hochul's desk.

## Musk’s alleged stalker identified; no evidence of ElonJet tracking, report says
 - [https://arstechnica.com/?p=1905518](https://arstechnica.com/?p=1905518)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 17:44:28+00:00

The alleged stalking incident occurred at a gas station near Grimes' house.

## Not sporty enough, not efficient enough—the 2023 Lexus RX 500h F Sport
 - [https://arstechnica.com/?p=1905504](https://arstechnica.com/?p=1905504)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 16:46:43+00:00

Now in its fifth generation, the Lexus RX arguably invented the crossover.

## FTC brings a $520 million hammer down on Epic Games for Fortnite complaints
 - [https://arstechnica.com/?p=1905496](https://arstechnica.com/?p=1905496)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 16:16:29+00:00

Massive fines highlight stricter enforcement standards for children in online games.

## Russia says it will take no immediate action on damaged Soyuz spacecraft
 - [https://arstechnica.com/?p=1905470](https://arstechnica.com/?p=1905470)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 15:59:55+00:00

In reality, the Soyuz is a hardy spacecraft.

## Musk polls Twitter users on whether he should be CEO—57.5% want him to quit
 - [https://arstechnica.com/?p=1905482](https://arstechnica.com/?p=1905482)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 15:33:07+00:00

"Should I step down as head of Twitter? I will abide by the results of this poll."

## The risk of escalation from cyberattacks has never been greater
 - [https://arstechnica.com/?p=1905469](https://arstechnica.com/?p=1905469)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 14:30:31+00:00

Cyberwarfare is getting real.

## An electric Kia that’s faster than a Lamborghini? The 2023 EV6 GT, driven
 - [https://arstechnica.com/?p=1905379](https://arstechnica.com/?p=1905379)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-12-19 05:01:25+00:00

The performance Kia EV has playful handling and easy sub-12 second quarter-miles.


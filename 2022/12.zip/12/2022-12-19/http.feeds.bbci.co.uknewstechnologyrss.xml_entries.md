# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Fortnite penalised after claims it tricked users
 - [https://www.bbc.co.uk/news/business-64030272?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64030272?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-12-19 16:52:37+00:00

Epic Games pays $520m over claims it violated child privacy laws and tricked players into making purchases.


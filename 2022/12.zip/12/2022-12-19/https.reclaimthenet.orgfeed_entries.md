# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Truth Social launches direct messages
 - [https://reclaimthenet.org/truth-social-launches-direct-messages/](https://reclaimthenet.org/truth-social-launches-direct-messages/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-19 21:16:01+00:00

<a href="https://reclaimthenet.org/truth-social-launches-direct-messages/" rel="nofollow" title="Truth Social launches direct messages"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/truth-social-launches-direct-messages.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Available for all users.</p>
<p>The post <a href="https://reclaimthenet.org/truth-social-launches-direct-messages/" rel="nofollow">Truth Social launches direct messages</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## EU funds test of biometric payments from digital wallets
 - [https://reclaimthenet.org/eu-test-biometric-payments-from-digital-wallets/](https://reclaimthenet.org/eu-test-biometric-payments-from-digital-wallets/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-19 20:14:41+00:00

<a href="https://reclaimthenet.org/eu-test-biometric-payments-from-digital-wallets/" rel="nofollow" title="EU funds test of biometric payments from digital wallets"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/eu-biomet-digi.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The proposed future.</p>
<p>The post <a href="https://reclaimthenet.org/eu-test-biometric-payments-from-digital-wallets/" rel="nofollow">EU funds test of biometric payments from digital wallets</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Democrats warn Meta not to rollback any “misinformation” policies
 - [https://reclaimthenet.org/democrats-warn-meta-to-keep-misinformation-policies/](https://reclaimthenet.org/democrats-warn-meta-to-keep-misinformation-policies/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-19 19:24:31+00:00

<a href="https://reclaimthenet.org/democrats-warn-meta-to-keep-misinformation-policies/" rel="nofollow" title="Democrats warn Meta not to rollback any &#8220;misinformation&#8221; policies"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/schiff-twitter.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>In light of Twitter removing some of its more controversial censorship policies.</p>
<p>The post <a href="https://reclaimthenet.org/democrats-warn-meta-to-keep-misinformation-policies/" rel="nofollow">Democrats warn Meta not to rollback any &#8220;misinformation&#8221; policies</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## FBI tried to get Twitter to share account information without a warrant
 - [https://reclaimthenet.org/fbi-twitter-data-requests-no-warrant/](https://reclaimthenet.org/fbi-twitter-data-requests-no-warrant/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-19 19:13:10+00:00

<a href="https://reclaimthenet.org/fbi-twitter-data-requests-no-warrant/" rel="nofollow" title="FBI tried to get Twitter to share account information without a warrant"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/fbi-twitter-data-requests-no-legal-process.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>More evidence of the agency attempting to extract data from Twitter directly.</p>
<p>The post <a href="https://reclaimthenet.org/fbi-twitter-data-requests-no-warrant/" rel="nofollow">FBI tried to get Twitter to share account information without a warrant</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Google introduces support for digital driver’s licenses, starting in Maryland
 - [https://reclaimthenet.org/google-introduces-support-for-digital-drivers-licenses-starting-in-maryland/](https://reclaimthenet.org/google-introduces-support-for-digital-drivers-licenses-starting-in-maryland/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-19 17:35:57+00:00

<a href="https://reclaimthenet.org/google-introduces-support-for-digital-drivers-licenses-starting-in-maryland/" rel="nofollow" title="Google introduces support for digital driver&#8217;s licenses, starting in Maryland"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/maryland02.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The normalization of digital ID.</p>
<p>The post <a href="https://reclaimthenet.org/google-introduces-support-for-digital-drivers-licenses-starting-in-maryland/" rel="nofollow">Google introduces support for digital driver&#8217;s licenses, starting in Maryland</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Even former Twitter censor expressed discomfort with FBI demands
 - [https://reclaimthenet.org/former-twitter-censor-uncomfortable-fbi-demands/](https://reclaimthenet.org/former-twitter-censor-uncomfortable-fbi-demands/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-19 01:52:25+00:00

<a href="https://reclaimthenet.org/former-twitter-censor-uncomfortable-fbi-demands/" rel="nofollow" title="Even former Twitter censor expressed discomfort with FBI demands"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/former-twitter-censor-uncomfortable-fbi-demands.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>New internal discussions revealed.</p>
<p>The post <a href="https://reclaimthenet.org/former-twitter-censor-uncomfortable-fbi-demands/" rel="nofollow">Even former Twitter censor expressed discomfort with FBI demands</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>


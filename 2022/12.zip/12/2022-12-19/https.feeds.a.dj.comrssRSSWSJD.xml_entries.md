# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Binance.US to Buy Assets of Bankrupt Crypto Lender Voyager, Eyes More Acquisitions
 - [https://www.wsj.com/articles/binance-us-to-buy-assets-of-bankrupt-crypto-lender-voyager-eyes-more-acquisitions-11671478348?mod=rss_Technology](https://www.wsj.com/articles/binance-us-to-buy-assets-of-bankrupt-crypto-lender-voyager-eyes-more-acquisitions-11671478348?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2022-12-19 19:32:00+00:00

CEO Brian Shroder says the U.S. arm of the cryptocurrency exchange has hundreds of millions of dollars to deploy

## Elon Musk's Twitter Poll Shows Users Want Him to Step Down
 - [https://www.wsj.com/articles/elon-musks-twitter-poll-shows-users-want-him-to-step-down-11671449123?mod=rss_Technology](https://www.wsj.com/articles/elon-musks-twitter-poll-shows-users-want-him-to-step-down-11671449123?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2022-12-19 18:29:00+00:00

The poll showed that 57.5% of respondents want him to leave as head of the social-media platform, bringing it fresh uncertainty.

## Epic Games, Maker of 'Fortnite,' to Pay $520 Million to Resolve FTC Allegations
 - [https://www.wsj.com/articles/epic-games-maker-of-fortnite-to-pay-520-million-to-resolve-ftc-allegations-11671456744?mod=rss_Technology](https://www.wsj.com/articles/epic-games-maker-of-fortnite-to-pay-520-million-to-resolve-ftc-allegations-11671456744?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2022-12-19 17:30:00+00:00

The agency alleged that the company invaded children’s privacy and tricked players of all ages into making unintended purchases.

## EU Charges Meta With Antitrust Violations Linked to Marketplace
 - [https://www.wsj.com/articles/eu-charges-meta-with-antitrust-violations-linked-to-marketplace-11671447845?mod=rss_Technology](https://www.wsj.com/articles/eu-charges-meta-with-antitrust-violations-linked-to-marketplace-11671447845?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2022-12-19 14:14:00+00:00

The European Union charged Facebook parent Meta with antitrust violations for allegedly distorting competition by tying its online classified ad service to its social network.


# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Xenia Rubinos - Ay Hombre (Live on KEXP)
 - [https://www.youtube.com/watch?v=hATEHiURx8k](https://www.youtube.com/watch?v=hATEHiURx8k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-19 00:00:00+00:00

http://KEXP.ORG presents Xenia Rubinos performing “Ay Hombre” live in the KEXP studio. Recorded November 4, 2022.

Xenia Rubinos - Vocals
Stefa Marin Alarcon - Vocals
Marco Buccelli - Drum Pad / Electronics

Host: Albina Cabrera
Audio Engineers: Julian Martlew & Kevin Suggs
Guest Engineer: Iván Diaz Mathé
Audio Mixer: Marco Buccelli
Audio Mastering: Kevin Suggs
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Luke Knecht
Editor: Scott Holpainen

https://xeniarubinos.net
http://kexp.org

## Xenia Rubinos - Did My Best (Live on KEXP)
 - [https://www.youtube.com/watch?v=AvFSJPUfOXI](https://www.youtube.com/watch?v=AvFSJPUfOXI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-19 00:00:00+00:00

http://KEXP.ORG presents Xenia Rubinos performing “Did My Best” live in the KEXP studio. Recorded November 4, 2022.

Xenia Rubinos - Vocals
Stefa Marin Alarcon - Vocals
Marco Buccelli - Drum Pad / Electronics

Host: Albina Cabrera
Audio Engineers: Julian Martlew & Kevin Suggs
Guest Engineer: Iván Diaz Mathé
Audio Mixer: Marco Buccelli
Audio Mastering: Kevin Suggs
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Luke Knecht
Editor: Scott Holpainen

https://xeniarubinos.net
http://kexp.org

## Xenia Rubinos - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=y_RN934Kxts](https://www.youtube.com/watch?v=y_RN934Kxts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-19 00:00:00+00:00

http://KEXP.ORG presents Xenia Rubinos performing live in the KEXP studio. Recorded November 4, 2022.

Songs:
Ay Hombre
Working All The Time
Sacude
Did My Best

Xenia Rubinos - Vocals
Stefa Marin Alarcon - Vocals
Marco Buccelli - Drum Pad / Electronics

Host: Albina Cabrera
Audio Engineers: Julian Martlew & Kevin Suggs
Guest Engineer: Iván Diaz Mathé
Audio Mixer: Marco Buccelli
Audio Mastering: Kevin Suggs
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Luke Knecht
Editor: Scott Holpainen

https://www.xeniarubinos.com
http://kexp.org

## Xenia Rubinos - Sacude (Live on KEXP)
 - [https://www.youtube.com/watch?v=9g-o2jU578U](https://www.youtube.com/watch?v=9g-o2jU578U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-19 00:00:00+00:00

http://KEXP.ORG presents Xenia Rubinos performing “Sacude” live in the KEXP studio. Recorded November 4, 2022.

Xenia Rubinos - Vocals
Stefa Marin Alarcon - Vocals
Marco Buccelli - Drum Pad / Electronics

Host: Albina Cabrera
Audio Engineers: Julian Martlew & Kevin Suggs
Guest Engineer: Iván Diaz Mathé
Audio Mixer: Marco Buccelli
Audio Mastering: Kevin Suggs
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Luke Knecht
Editor: Scott Holpainen

https://xeniarubinos.net
http://kexp.org

## Xenia Rubinos - Working All The Time (Live on KEXP)
 - [https://www.youtube.com/watch?v=g0ZJ3cq27d0](https://www.youtube.com/watch?v=g0ZJ3cq27d0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-19 00:00:00+00:00

http://KEXP.ORG presents Xenia Rubinos performing “Working All The Time” live in the KEXP studio. Recorded November 4, 2022.

Xenia Rubinos - Vocals
Stefa Marin Alarcon - Vocals
Marco Buccelli - Drum Pad / Electronics

Host: Albina Cabrera
Audio Engineers: Julian Martlew & Kevin Suggs
Guest Engineer: Iván Diaz Mathé
Audio Mixer: Marco Buccelli
Audio Mastering: Kevin Suggs
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Luke Knecht
Editor: Scott Holpainen

https://xeniarubinos.net
http://kexp.org


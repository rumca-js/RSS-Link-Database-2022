# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Stacey Abrams Campaign Claims To Be In Debt After More Than $100 Million Raised
 - [https://www.dailywire.com/news/stacey-abrams-campaign-claims-to-be-in-debt-after-more-than-100-million-raised](https://www.dailywire.com/news/stacey-abrams-campaign-claims-to-be-in-debt-after-more-than-100-million-raised)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 22:32:28+00:00

Failed Georgia gubernatorial candidate Stacey Abrams boasted a massive fundraising haul of more than $100 million in the 2022 cycle, but now her campaign says it owes money and staffers were reportedly cut from pay shortly after the November election. The Democrat&#8217;s two-time campaign manager, Lauren Groh-Wargo, told Axios the team owes more than $1 ...

## Pharmacies Limit Children’s Medicine Purchases Amid Shortages
 - [https://www.dailywire.com/news/pharmacies-limit-childrens-medicine-purchases-amid-shortages](https://www.dailywire.com/news/pharmacies-limit-childrens-medicine-purchases-amid-shortages)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 20:45:02+00:00

Two major pharmacy stores have placed limits on customers purchasing children&#8217;s medicine amid reports of shortages as the winter cold-and-flu season impacts families across the United States. According to a report, CVS Health and Walgreens are limiting customers from buying Children&#8217;s Tylenol and other over-the-counter fever-reducing medicines like Tamiflu, children&#8217;s ibuprofen, and acetaminophen. CVS Health ...

## Trump Responds To Congressional Committee Sending Criminal Referral To DOJ
 - [https://www.dailywire.com/news/trump-responds-to-congressional-committee-sending-criminal-referral-to-doj](https://www.dailywire.com/news/trump-responds-to-congressional-committee-sending-criminal-referral-to-doj)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 20:30:02+00:00

Former President Donald Trump responded to the House January 6 Committee&#8217;s recommendation Tuesday to refer him to the Justice Department for criminal prosecution by rehashing everything that has happened since the 2016 election. The committee, assembled by House Speaker Nancy Pelosi (D-CA), concluded its inquiry with a vote recommending Trump be charged with obstructing an ...

## Federal Court Rejects Female Athletes’ Bid To Scrap Transgender Sports Policy In Connecticut
 - [https://www.dailywire.com/news/federal-court-rejects-female-athletes-bid-to-scrap-transgender-sports-policy-in-connecticut](https://www.dailywire.com/news/federal-court-rejects-female-athletes-bid-to-scrap-transgender-sports-policy-in-connecticut)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 19:56:39+00:00

Four female athletes who sued over a Connecticut transgender sports policy lost their case in federal court on Friday. A three-judge panel on the 2nd Circuit Court of Appeals affirmed a lower court’s decision to throw out the girls&#8217; case, which was seeking to scrap a policy that allows biological males to compete on girls&#8217; sports ...

## Why Birth Control Is A Terrible Idea
 - [https://www.dailywire.com/news/why-birth-control-is-a-terrible-idea](https://www.dailywire.com/news/why-birth-control-is-a-terrible-idea)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 19:51:17+00:00

First and foremost, before we even get into the topic of birth control, I believe there’s a natural guide inside of us, a spiritual discernment, that says this is probably just not a good idea. Right? You don&#8217;t have a study to back it up. You don&#8217;t necessarily need the facts laid bare in front ...

## ‘Monty Python’ Alum John Cleese Slams ‘Wokes’ And The Current ‘Thrill Of Being Offended’
 - [https://www.dailywire.com/news/monty-python-alum-john-cleese-slams-wokes-and-the-current-thrill-of-being-offended](https://www.dailywire.com/news/monty-python-alum-john-cleese-slams-wokes-and-the-current-thrill-of-being-offended)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 19:49:13+00:00

&#8220;Monty Python&#8221; alumni John Cleese slammed those he called the &#8220;wokes&#8221; and talked about the current environment for entertainers with many people sitting in the audience just waiting for the &#8220;thrill of being offended.&#8221; During a wide-ranging interview for Reason.com&#8217;s January 2023 issue, the 83-year-old comedian talked about political correctness and &#8220;wokeism&#8221; which he called ...

## Study Shows Effects Of Pandemic Life Changes On Mothers
 - [https://www.dailywire.com/news/study-shows-effects-of-pandemic-life-changes-on-mothers](https://www.dailywire.com/news/study-shows-effects-of-pandemic-life-changes-on-mothers)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 19:41:59+00:00

A recent study revealed how mothers were impacted by the changes that came during the COVID-19 pandemic, and it had some surprising results.  The study, published in JAMA Network Open on Friday, involved 11,473 mothers who were all a part of the Environmental influences on Child Health Outcomes (ECHO) Program with the National Institute of ...

## Ratings Blowout: Tucker Carlson’s 1 a.m. Rerun Beats All But Two CNN Programs
 - [https://www.dailywire.com/news/ratings-blowout-tucker-carlsons-1-a-m-rerun-beats-all-but-two-cnn-programs](https://www.dailywire.com/news/ratings-blowout-tucker-carlsons-1-a-m-rerun-beats-all-but-two-cnn-programs)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 19:26:24+00:00

Fox News host Tucker Carlson&#8217;s prime time show &#8220;Tucker Carlson Tonight&#8221; airs for a second time on weeknights at 1 a.m. ET — and his late-night rerun still draws a larger audience in the key demographic than all but two of the shows in CNN&#8217;s entire lineup. According to Nielsen Media Research, Carlson&#8217;s 1 a.m. ...

## Disgraced Movie Mogul Harvey Weinstein Found Guilty Of Rape In Los Angeles Trial
 - [https://www.dailywire.com/news/disgraced-movie-mogul-harvey-weinstein-found-guilty-of-rape-in-los-angeles-trial](https://www.dailywire.com/news/disgraced-movie-mogul-harvey-weinstein-found-guilty-of-rape-in-los-angeles-trial)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 19:23:10+00:00

Jurors reached a split verdict Monday in the sexual assault and rape trial of disgraced movie mogul Harvey Weinstein in Los Angeles. Weinstein, who is serving a 23-year sentence for rape in New York, stands accused of sexually assaulting five women between 2003 and 2014. According to reports, jurors said Weinstein is guilty of forcible ...

## San Francisco Has 51% Chance Of Major Earthquake In Next 30 Years
 - [https://www.dailywire.com/news/san-francisco-has-51-chance-of-major-earthquake-in-next-30-years](https://www.dailywire.com/news/san-francisco-has-51-chance-of-major-earthquake-in-next-30-years)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 18:13:39+00:00

Over the weekend, a magnitude 3.6 earthquake struck along the Hayward fault in northern California, the fault that the U.S. Geological Survey has stated has a good chance of a major earthquake in the next 30 years. According to the U.S. Geological Survey, the chances of an magnitude-7 earthquake hitting San Francisco from the Hayward ...

## Ohio Teacher Forced Out For Refusing To Affirm Students’ New Gender Identity, Lawsuit Claims
 - [https://www.dailywire.com/news/ohio-teacher-forced-out-for-refusing-to-affirm-students-new-gender-identity-lawsuit-claims](https://www.dailywire.com/news/ohio-teacher-forced-out-for-refusing-to-affirm-students-new-gender-identity-lawsuit-claims)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 17:56:37+00:00

An Ohio teacher is suing her former school after she was forced to quit her job for not using students&#8217; new gender identity pronouns, she says. Vivian Geraghty, 24, a former English teacher, has filed a lawsuit against Jackson Memorial Middle School south of Columbus. She says district officials forced her out even though her Christian religious beliefs ...

## Confronting Twitter’s Pornography Problem Would Tackle The Child Exploitation Epidemic, Advocates For Online Safety Say
 - [https://www.dailywire.com/news/confronting-twitters-pornography-problem-would-tackle-the-child-exploitation-epidemic-advocates-for-online-safety-say](https://www.dailywire.com/news/confronting-twitters-pornography-problem-would-tackle-the-child-exploitation-epidemic-advocates-for-online-safety-say)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 17:49:43+00:00

Twitter watchdogs are calling on Elon Musk to ban pornography on the platform until it can implement an age and consent verification system for those depicted in the images and videos amid alarming concerns over the internet&#8217;s child sexual exploitation epidemic. Officials from the National Center on Sexual Exploitation (NCOSE) told The Daily Wire that ...

## The Trump Charges Jan. 6 Panel Considered But Did Not Approve
 - [https://www.dailywire.com/news/the-trump-charges-jan-6-panel-considered-but-did-not-approve](https://www.dailywire.com/news/the-trump-charges-jan-6-panel-considered-but-did-not-approve)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 17:48:02+00:00

The House January 6 Committee recommended to the Justice Department on Monday several charges against former President Donald Trump and his allies, but left out referrals for multiple conspiracy allegations that were under consideration. During their final business meeting on Capitol Hill, members did not vote on a seditious conspiracy charge, which is a serious ...

## BREAKING: Supreme Court Blocks Key Immigration Policy Title 42 From Ending
 - [https://www.dailywire.com/news/breaking-supreme-court-blocks-key-immigration-policy-title-42-from-ending](https://www.dailywire.com/news/breaking-supreme-court-blocks-key-immigration-policy-title-42-from-ending)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 17:44:41+00:00

The Supreme Court on Monday blocked the lifting of key immigration policy Title 42. The statute, which gives commanders-in-chief the power to shut down immigration as an emergency action to keep communicable diseases out of the United States, was last used by former President Donald Trump in reaction to the COVID outbreak. Families seeking asylum ...

## FBI Releases Public Safety Alert Over Rising Child Online ‘Sextortion’
 - [https://www.dailywire.com/news/fbi-releases-public-safety-alert-over-rising-child-online-sextortion](https://www.dailywire.com/news/fbi-releases-public-safety-alert-over-rising-child-online-sextortion)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 17:19:56+00:00

The Federal Bureau of Investigations (FBI) released a national public safety alert on Monday regarding an increase in “financial sextortion schemes” targeting children and teenagers.  The FBI, along with the National Center for Missing and Exploited Children and Homeland Security Investigations, put out the alert, noting that there has been an “explosion in incidents of ...

## Pope Francis Says He Wrote Resignation Note In 2013
 - [https://www.dailywire.com/news/pope-francis-says-he-wrote-resignation-note-in-2013](https://www.dailywire.com/news/pope-francis-says-he-wrote-resignation-note-in-2013)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 17:09:22+00:00

VATICAN CITY — Pope Francis signed a resignation letter in 2013 and then handed it over to then-Secretary of State Tarcisio Bertone, the pope told a Spanish news outlet on Saturday.  The pope’s comment was made during a wide-ranging interview with the Spanish outlet ABC, which covered topics from women in positions of leadership in ...

## Sam Bankman-Fried Agrees To Be Extradited To The United States
 - [https://www.dailywire.com/news/sam-bankman-fried-agrees-to-be-extradited-to-the-united-states](https://www.dailywire.com/news/sam-bankman-fried-agrees-to-be-extradited-to-the-united-states)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 16:51:52+00:00

Former FTX CEO Sam Bankman-Fried agreed to be extradited to the United States after he visited a court in the Bahamas on Monday to see the indictment against him from American officials. The disgraced entrepreneur’s company filed for bankruptcy last month after users learned that the venture’s assets were commingled with sister firm Alameda Research; ...

## Patricia Heaton Says One Year Ago She Set Goal To Read Entire Bible, Reveals How It Went
 - [https://www.dailywire.com/news/patricia-heaton-says-one-year-ago-she-set-goal-to-read-entire-bible-reveals-how-it-went](https://www.dailywire.com/news/patricia-heaton-says-one-year-ago-she-set-goal-to-read-entire-bible-reveals-how-it-went)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 16:45:55+00:00

Superstar Patricia Heaton revealed that she set a person goal to read the entire Bible in just one year and shared that while it wasn&#8217;t always easy, she did in fact finish on Sunday. The 64-year-old actress shared a video on Twitter with her hundreds of thousands of followers that detailed what she called &#8220;a ...

## San Francisco Police Secretly Deployed At Stores To Catch Shoplifters
 - [https://www.dailywire.com/news/san-francisco-police-secretly-deployed-at-stores-to-catch-shoplifters](https://www.dailywire.com/news/san-francisco-police-secretly-deployed-at-stores-to-catch-shoplifters)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 16:38:50+00:00

According to authorities on Friday, San Francisco police officers have been deployed at stores throughout the city in an attempt to take shoplifters into custody as they carry out crimes.  A San Francisco Police Department (SFPD) spokesperson stated that police officers carried out 60 arrests since the end of November, the San Francisco Chronicle reported. ...

## The Kiss Of Death? Trump Backs McCarthy Bid For House Speakership
 - [https://www.dailywire.com/news/the-kiss-of-death-trump-backs-mccarthy-bid-for-house-speakership](https://www.dailywire.com/news/the-kiss-of-death-trump-backs-mccarthy-bid-for-house-speakership)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 16:24:39+00:00

House Minority Leader Rep. Kevin McCarthy (R-CA) wants to become speaker of the House, but at least five Republicans have said they won&#8217;t support him. That&#8217;s a big problem because the GOP controls the chamber by a 222-213 margin, and losing five votes would put McCarthy below the 218-vote majority he needs to wield the ...

## New Study Finds Psychotherapy Improved Mental Health Of Autistic Adolescents With Gender Dysphoria
 - [https://www.dailywire.com/news/new-study-finds-psychotherapy-improved-mental-health-of-autistic-adolescents-with-gender-dysphoria](https://www.dailywire.com/news/new-study-finds-psychotherapy-improved-mental-health-of-autistic-adolescents-with-gender-dysphoria)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 16:16:39+00:00

A new pilot study found that psychotherapy – without medical intervention – improved the mental health of autistic adolescents with gender dysphoria. The study, published in the Journal of Autism and Developmental Disorders, found that guided, peer support group therapy showed positive mental health outcomes for autistic adolescents struggling with gender dysphoria. The study, conducted ...

## Court Grants $10.3 Million Settlement To Health Care Workers Denied Religious Exemptions For COVID Vaccine
 - [https://www.dailywire.com/news/court-grants-10-3-million-settlement-to-health-care-workers-denied-religious-exemptions-for-covid-vaccine](https://www.dailywire.com/news/court-grants-10-3-million-settlement-to-health-care-workers-denied-religious-exemptions-for-covid-vaccine)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 16:12:26+00:00

A federal judge approved a class action settlement of more than $10 million for workers at an Illinois healthcare system whose religious exemptions against taking the COVID vaccine were rejected. Judge John Kness granted approval on Monday, with the final judgment provided by next week, according to Liberty Counsel. “After many months and long hours, ...

## Homebuilder Sentiment Fell Every Month This Year As Housing Market Weakens
 - [https://www.dailywire.com/news/homebuilder-sentiment-fell-every-month-this-year-as-housing-market-weakens](https://www.dailywire.com/news/homebuilder-sentiment-fell-every-month-this-year-as-housing-market-weakens)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 16:07:04+00:00

Homebuilder sentiment has dropped every month in 2022 as multiple economic headwinds grip the housing market, according to data from the National Association of Home Builders. The past two years have witnessed soaring home prices which have finally cooled in recent months as rising mortgage rates quell demand. Broader inflationary pressures have made building new ...

## Libraries Cave After Refusing Faith-Based Story Hour. Kirk Cameron Celebrates.
 - [https://www.dailywire.com/news/libraries-cave-after-refusing-faith-based-story-hour-kirk-cameron-celebrates](https://www.dailywire.com/news/libraries-cave-after-refusing-faith-based-story-hour-kirk-cameron-celebrates)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 16:03:03+00:00

Kirk Cameron celebrated after libraries that had refused to host him over his new faith-based children&#8217;s book reversed course, and he said it should send a message to Christians and conservatives &#8220;to be brave.&#8221; The 52-year-old actor&#8217;s publicist told Fox News that two libraries &#8220;caved,&#8221; confirming Cameron would be reading his book &#8220;As You Grow&#8221; ...

## Crowdfunding Site Cancels Comic Book About Vigilante Targeting Drug Dealers At Border After Leftists Complain
 - [https://www.dailywire.com/news/crowdfunding-site-cancels-comic-book-about-vigilante-targeting-drug-dealers-at-border-after-leftists-complain](https://www.dailywire.com/news/crowdfunding-site-cancels-comic-book-about-vigilante-targeting-drug-dealers-at-border-after-leftists-complain)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 15:31:32+00:00

A comic book centered on a vigilante tracking down fentanyl dealers at the southern border went looking for public funds to support it, only to get banned on Twitter, then reportedly get shadow-banned on Indiegogo. Then the comic book was banned by Kickstarter after leftists complained the book featured “racist propaganda.” The Left-wing Daily Kos ...

## ‘Under Doctor’s Orders’: Billy Joel Postpones Concert Due To Illness
 - [https://www.dailywire.com/news/under-doctors-orders-billy-joel-postpones-concert-due-to-illness](https://www.dailywire.com/news/under-doctors-orders-billy-joel-postpones-concert-due-to-illness)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 15:27:08+00:00

Billy Joel postponed his final concert of 2022, a sold-out show at New York City&#8217;s Madison Square Garden scheduled for Monday night due to &#8220;doctor&#8217;s orders.&#8221; The 73-year-old singer shared Sunday on Instagram that &#8220;Bill Joel at The Garden&#8221; would be rescheduled to June because he needed to recover from an infection. &#8220;I&#8217;m disappointed to ...

## New ‘Twitter Files’ Show FBI Paid Twitter Millions, Influenced Execs To Censor Hunter Biden Laptop Story
 - [https://www.dailywire.com/news/new-twitter-files-show-fbi-paid-twitter-millions-influenced-execs-to-censor-hunter-biden-laptop-story](https://www.dailywire.com/news/new-twitter-files-show-fbi-paid-twitter-millions-influenced-execs-to-censor-hunter-biden-laptop-story)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 15:10:57+00:00

The bombshell story about Hunter Biden’s laptop from the New York Post was censored after the FBI had repeatedly warned Twitter executives about foreign election interference campaigns, according to the seventh installment of the Twitter Files released Monday. Previous editions of the project, revealed by independent journalists based on emails and other internal company documents ...

## In Separate Incident From Hawaii Flight, Five People Go To Hospital After ‘Severe Turbulence’
 - [https://www.dailywire.com/news/in-separate-incident-from-hawaii-flight-five-people-go-to-hospital-after-severe-turbulence](https://www.dailywire.com/news/in-separate-incident-from-hawaii-flight-five-people-go-to-hospital-after-severe-turbulence)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 15:08:36+00:00

At least five people went to the hospital after experiencing &#8220;severe turbulence&#8221; on a United Airlines flight headed to Houston on Monday morning.  United Airlines flight 128 was arriving from Rio de Janeiro and touched down at George Bush Intercontinental Airport at around 5:30 a.m., a public information officer told CNN.  &#8220;The flight experienced severe ...

## Working For A Living: Here’s Why Time Away From The Office May Be Just What The Doctor Ordered
 - [https://www.dailywire.com/news/working-for-a-living-heres-why-time-away-from-the-office-may-be-just-what-the-doctor-ordered](https://www.dailywire.com/news/working-for-a-living-heres-why-time-away-from-the-office-may-be-just-what-the-doctor-ordered)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 14:41:29+00:00

As the holidays ramp up, some workers across the United States will take much-needed breaks from the daily tasks of the workplace. However, others might be less inclined to do so. Either way, the vast benefits to taking time away from work — whether short or small — is something all Americans need to consider ...

## BREAKING: J6 Committee Recommends Criminal Charges Against Trump Over Capitol Riot
 - [https://www.dailywire.com/news/breaking-j6-committee-recommends-criminal-charges-against-trump-over-capitol-riot](https://www.dailywire.com/news/breaking-j6-committee-recommends-criminal-charges-against-trump-over-capitol-riot)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 14:29:23+00:00

The House January 6 Committee voted on Monday to recommend the Justice Department charge former President Donald Trump over the January 6, 2021, riot at the U.S. capitol. The committee, assembled by House Speaker Nancy Pelosi (D-CA), concluded its inquiry with a vote recommending Trump be charged with obstructing an official proceeding, conspiring to defraud ...

## Snoop Dogg Runs Competing Poll To See If He Should Take Control Of Twitter From Elon Musk
 - [https://www.dailywire.com/news/snoop-dogg-runs-competing-poll-to-see-if-he-should-take-control-of-twitter-from-elon-musk](https://www.dailywire.com/news/snoop-dogg-runs-competing-poll-to-see-if-he-should-take-control-of-twitter-from-elon-musk)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 14:28:27+00:00

Rapper Snoop Dogg waded into the apparent battle for control of Twitter after owner, CEO, and self-described &#8220;Chief Twit&#8221; Elon Musk polled users to determine whether he should step down from direct management of the platform. Musk&#8217;s poll did not go his way — and Snoop Dogg responded by posting a poll of his own, ...

## It’s Growing: More RNC Members Breaking To Oust Romney McDaniel As Chair
 - [https://www.dailywire.com/news/its-growing-more-rnc-members-breaking-to-oust-romney-mcdaniel-as-chair](https://www.dailywire.com/news/its-growing-more-rnc-members-breaking-to-oust-romney-mcdaniel-as-chair)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 14:22:09+00:00

More RNC members are coming forward to support Harmeet Dhillon as the next chair of the Republican National Committee, breaking with those who support incumbent Ronna Romney McDaniel, who has presided over numerous GOP election failures. POLITICO reported on Sunday that since the disastrous results of the November mid-term elections, RNC members have been inundated ...

## WATCH: PragerU Releases Video Revealing The Facts About ‘Gender-Affirming’ Care
 - [https://www.dailywire.com/news/watch-prageru-releases-video-revealing-the-facts-about-gender-affirming-care](https://www.dailywire.com/news/watch-prageru-releases-video-revealing-the-facts-about-gender-affirming-care)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 13:59:18+00:00

Chemical castration, sterilization, and the physical mutilation of young people sound like criminal activities, so why do progressives push the actions as &#8220;gender-affirming care&#8221;? That&#8217;s the question behind the latest video from PragerU. Host Kaylee McGhee White sheds light on the concerns behind the trend and sounds the alarm over those who push gender change ...

## College Basketball Player Fatally Shot In New Jersey
 - [https://www.dailywire.com/news/college-basketball-player-fatally-shot-in-new-jersey](https://www.dailywire.com/news/college-basketball-player-fatally-shot-in-new-jersey)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 13:30:56+00:00

A college basketball player was fatally shot while sitting in a car in New Jersey late Saturday evening, according to police. Phil Urban, a 20-year-old student-athlete at Post University in Connecticut, was killed at the Hopewell Valley Nature Preserve in Mercer County. Authorities said that the preliminary investigation believed Urban might have been attempting to ...

## Steven Spielberg Said He Has ‘Regret’ Over Impact Of ‘Jaws’ On Sharks, Afraid They Are ‘Mad’ At Him
 - [https://www.dailywire.com/news/steven-spielberg-said-he-has-regret-over-impact-of-jaws-on-sharks-afraid-they-are-mad-at-him](https://www.dailywire.com/news/steven-spielberg-said-he-has-regret-over-impact-of-jaws-on-sharks-afraid-they-are-mad-at-him)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 13:24:11+00:00

Director Steven Spielberg said he regrets the impact his iconic movie “Jaws” had on the shark population.  The 76-year-old Hollywood veteran made his feelings known during a recent interview with the BBC podcast Desert Island Discs. Spielberg was 27 when he made “Jaws” in 1975 and said he looks back with mixed emotions on how ...

## Report: Pro-Life Fr. Frank Pavone Removed From Priesthood By Vatican; Responds With Defiant Message
 - [https://www.dailywire.com/news/report-pro-life-fr-frank-pavone-removed-from-priesthood-by-vatican-responds-with-defiant-message](https://www.dailywire.com/news/report-pro-life-fr-frank-pavone-removed-from-priesthood-by-vatican-responds-with-defiant-message)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 13:11:23+00:00

Fr. Frank Pavone, one of the most prominent U.S. Catholic priests organizing to defend life, has reportedly been defrocked by the Vatican with no possibility of appeal over social media posts deemed &#8220;blasphemous.&#8221; A letter obtained over the weekend by Catholic News Agency said Fr. Pavone was dismissed for his social media activity and “persistent ...

## Elizabeth Warren Browbeats Tesla Board Over Elon Musk’s Work With Twitter
 - [https://www.dailywire.com/news/elizabeth-warren-browbeats-tesla-board-over-elon-musks-work-with-twitter](https://www.dailywire.com/news/elizabeth-warren-browbeats-tesla-board-over-elon-musks-work-with-twitter)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 13:05:16+00:00

Senator Elizabeth Warren (D-MA) warned board members of Tesla that the recent acquisition of Twitter by Elon Musk could present conflicts of interest for the electric automaker. Musk purchased the social media company in a $44 billion deal that followed months of court battles about the number of true accounts on the platform. Among other ...

## Texas Governor Predicts ‘Total Chaos’ When Title 42 Border Rule Ends
 - [https://www.dailywire.com/news/texas-governor-predicts-total-chaos-when-title-42-border-rule-ends](https://www.dailywire.com/news/texas-governor-predicts-total-chaos-when-title-42-border-rule-ends)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 12:50:45+00:00

You&#8217;ll be hearing the term &#8220;Title 42&#8221; a lot in the coming days. Title 42 is a U.S. law that gives the government the power to shut down the border as an emergency action to keep communicable diseases out of the country. Presidents have used the power in the past. In June 1929, President Herbert Hoover ...

## Sean Penn Says Being Unvaccinated Is ‘Criminal’ And Those People Shouldn’t Leave Their Homes
 - [https://www.dailywire.com/news/sean-penn-says-being-unvaccinated-is-criminal-and-those-people-shouldnt-leave-their-homes](https://www.dailywire.com/news/sean-penn-says-being-unvaccinated-is-criminal-and-those-people-shouldnt-leave-their-homes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 12:29:44+00:00

Avowed leftist Sean Penn has a strong position when it comes to unvaccinated people and how they should behave.  The 62-year-old actor recently made his feelings known while speaking with Extra. When asked by the interviewer how he felt about “anti-vaccine rhetoric,” Penn replied, “It’s a cowardice of conviction. I think that it is an ...

## ‘Only Kevin’: 54 Republicans Announce Plan To Back McCarthy For Speaker No Matter What
 - [https://www.dailywire.com/news/only-kevin-54-republicans-announce-plan-to-back-mccarthy-for-speaker-no-matter-what](https://www.dailywire.com/news/only-kevin-54-republicans-announce-plan-to-back-mccarthy-for-speaker-no-matter-what)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 12:09:24+00:00

More than four dozen Republican lawmakers have committed to unconditionally backing the speaker campaign of House Minority Leader Kevin McCarthy (R-CA). The commitments occur as McCarthy attempts to succeed House Speaker Nancy Pelosi (D-CA) as the most powerful lawmaker in the lower chamber, a maneuver complicated by lackluster midterm election results that will provide Republicans ...

## New York Times Savages Netanyahu’s Incoming Government. Netanyahu Crushes Them.
 - [https://www.dailywire.com/news/new-york-times-savages-netanyahus-incoming-government-netanyahu-crushes-them](https://www.dailywire.com/news/new-york-times-savages-netanyahus-incoming-government-netanyahu-crushes-them)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 11:54:32+00:00

After The New York Times editorial board issued an opinion piece furiously condemning “ultrareligious and ultranationalist parties” that have gained more power in Israel, calling likely incoming Prime Minister Benjamin Netanyahu’s prospective government a “significant threat to the future of Israel,” Netanyahu, who has been the longest-serving prime minister in the history of the Jewish ...

## ‘I Have Made No Admission’: Defiant Amber Heard Blasts U.S. Justice System, Settles Defamation Case For A Cool $1 Million
 - [https://www.dailywire.com/news/i-have-made-no-admission-defiant-amber-heard-blasts-u-s-justice-system-settles-defamation-case-for-a-cool-1-million](https://www.dailywire.com/news/i-have-made-no-admission-defiant-amber-heard-blasts-u-s-justice-system-settles-defamation-case-for-a-cool-1-million)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 11:19:41+00:00

Amber Heard has settled her defamation case against ex-husband Johnny Depp — forking over just a portion of the amount she was initially ordered to pay — and she released a statement refusing to admit any fault and condemning the American justice system. According to a report from entertainment website TMZ, Heard will pay $1 ...

## Coming Soon: What We’re Looking Forward To Seeing In 2023
 - [https://www.dailywire.com/news/coming-soon-what-were-looking-forward-to-seeing-in-2023](https://www.dailywire.com/news/coming-soon-what-were-looking-forward-to-seeing-in-2023)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 10:24:30+00:00

The New Year means resolutions we’ll quickly break, two more months of winter, and the start of the 2024 presidential campaign. Who wouldn’t want an escape from all of the above? Hollywood hopes it can help. The following projects, from TV shows to films coming next year, promise to distract us from the year’s problems. ...

## NYC Mayor Eric Adams Seeks Migrant Funding As Title 42 Nears End
 - [https://www.dailywire.com/news/nyc-mayor-eric-adams-seeks-migrant-funding-as-title-42-nears-end](https://www.dailywire.com/news/nyc-mayor-eric-adams-seeks-migrant-funding-as-title-42-nears-end)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 10:18:25+00:00

New York City Mayor Eric Adams blasted a pair of fellow Democrats, the Empire State&#8217;s governor, and President Joe Biden for failing to provide additional resources to help his city address the growing number of migrants as Title 42 nears its end. An email sent by Adams to City Council members and obtained by the New ...

## Elderly Gunman Goes Door-To-Door, Killing Board Members At Luxury Condo Building
 - [https://www.dailywire.com/news/elderly-gunman-goes-door-to-door-killing-board-members-at-luxury-condo-building](https://www.dailywire.com/news/elderly-gunman-goes-door-to-door-killing-board-members-at-luxury-condo-building)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 10:01:26+00:00

An elderly resident of a luxury Toronto-area condo building went door-to-door, gunning down members of the complex’s board Sunday night before police moved in and took him down, authorities said. The unidentified 73-year-old man shot and killed five people believed to be board members of the Bellaria Towers in suburban Vaughan during a rampage that ...

## Kate Winslet, James Cameron Share Opinions On Infamous ‘Titanic’ Door Debate
 - [https://www.dailywire.com/news/kate-winslet-james-cameron-share-opinions-on-infamous-titanic-door-debate](https://www.dailywire.com/news/kate-winslet-james-cameron-share-opinions-on-infamous-titanic-door-debate)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 09:39:23+00:00

Kate Winslet has weighed in on the famous “Titanic” door controversy in light of the film’s 25th anniversary. In the movie, the character Rose (Winslet) survives after the boat sinks after finding a floating door to use as a raft. Meanwhile, her love interest Jack (Leonardo DiCaprio) freezes to death in the icy sea. Fans ...

## Former NBA Star Amar’e Stoudemire Arrested After Allegedly Punching Daughter: Report
 - [https://www.dailywire.com/news/former-nba-star-amare-stoudemire-arrested-after-allegedly-punching-daughter-report](https://www.dailywire.com/news/former-nba-star-amare-stoudemire-arrested-after-allegedly-punching-daughter-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 08:30:08+00:00

Former NBA star Amar&#8217;e Stoudemire was arrested over the weekend at his upscale condo in Miami for an alleged domestic violence charge involving one of his daughters. Arrest records say that the alleged victim claims that Stoudemire — who stands 6-foot-10 and weighs 255 pounds — punched and slapped her in the face, The Miami ...

## Tom Cruise Jumps From Helicopter To Thank Fans Who Saw ‘Top Gun: Maverick’ In Theaters: ‘Honor Of A Lifetime’
 - [https://www.dailywire.com/news/tom-cruise-jumps-from-helicopter-to-thank-fans-who-saw-top-gun-maverick-in-theaters-honor-of-a-lifetime](https://www.dailywire.com/news/tom-cruise-jumps-from-helicopter-to-thank-fans-who-saw-top-gun-maverick-in-theaters-honor-of-a-lifetime)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 08:19:58+00:00

Legendary actor Tom Cruise filmed a special thank you message released over the weekend to fans who watched &#8220;Top Gun: Maverick&#8221; in theaters over the summer. The movie grossed more than $1.4 billion at the global box office and more than $690 million domestically after three months in theaters, making it one of the highest-grossing ...

## Far-Left Actress Jennifer Garner Eyes Moving Into The Political Arena: Report
 - [https://www.dailywire.com/news/far-left-actress-jennifer-garner-eyes-moving-into-the-political-arena-report](https://www.dailywire.com/news/far-left-actress-jennifer-garner-eyes-moving-into-the-political-arena-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 08:12:17+00:00

Actress Jennifer Garner is reportedly giving serious consideration to becoming a politician, according to a new report. The U.S. Sun reported that Garner, a Democrat who is now 50 years old, &#8220;has the backing of Tinseltown heavyweights such as power couple JJ Abrams and his wife Katie McGrath, who are urging her to go for ...

## New York Times Slammed After Crossword Puzzle Resembles Swastika On Start Of Hanukkah
 - [https://www.dailywire.com/news/new-york-times-slammed-after-crossword-puzzle-resembles-swastika-on-start-of-hanukkah](https://www.dailywire.com/news/new-york-times-slammed-after-crossword-puzzle-resembles-swastika-on-start-of-hanukkah)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 07:57:39+00:00

The New York Times faced backlash over the weekend after many people thought the newspaper&#8217;s crossword puzzle layout resembled a Nazi swastika, which was made even worse because it was published at the beginning of Hanukkah. The crossword was published by the newspaper on Sunday, generating a slew of criticism online. Jewish author Magen Yehudi ...

## SEE IT: Justice Clarence Thomas Lays Wreaths At Arlington National Cemetery To Honor America’s Heroes
 - [https://www.dailywire.com/news/see-it-justice-clarence-thomas-lays-wreaths-at-arlington-national-cemetery-to-honor-americas-heroes](https://www.dailywire.com/news/see-it-justice-clarence-thomas-lays-wreaths-at-arlington-national-cemetery-to-honor-americas-heroes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 07:48:20+00:00

Supreme Court Justice Clarence Thomas was spotted over the weekend laying wreaths to honor America&#8217;s fallen heroes at Arlington National Cemetery in Virginia. &#8220;Love how Justice Clarence Thomas quietly lays wreaths with all the other volunteers every year at Arlington National Cemetery for #wreathsacrossamerica to honor those who have the ultimate sacrifice,&#8221; journalist Emily Miller ...

## ABC’s Martha Raddatz Blames Border Crisis On GOP, Falsely Claims Biden Never Told Migrants To Come
 - [https://www.dailywire.com/news/abcs-martha-raddatz-blames-border-crisis-on-gop-falsely-claims-biden-never-told-migrants-to-come](https://www.dailywire.com/news/abcs-martha-raddatz-blames-border-crisis-on-gop-falsely-claims-biden-never-told-migrants-to-come)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 07:38:28+00:00

ABC News host Martha Raddatz falsely claimed during a segment that aired on Sunday that President Joe Biden never encouraged migrants to come to the U.S. in recent years as she appeared to pin the border crisis on Republicans. Raddatz made the remarks during an interview on &#8220;This Week&#8221; with Texas GOP Governor Greg Abbott ...

## Matt Taibbi Releases New ‘Twitter Files’ Info Showing Feds Pushed Twitter Over ‘Propaganda Actors’
 - [https://www.dailywire.com/news/matt-taibbi-releases-new-twitter-files-info-showing-feds-pushed-twitter-over-propaganda-actors](https://www.dailywire.com/news/matt-taibbi-releases-new-twitter-files-info-showing-feds-pushed-twitter-over-propaganda-actors)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 07:27:21+00:00

Journalist Matt Taibbi released additional documents in &#8220;The Twitter Files&#8221; Sunday night after he published a more exhaustive release late last week showing how federal law enforcement officials were in regular contact with Twitter employees flagging content for them to potentially censor on the platform. Taibbi&#8217;s release on Friday revealed that between January 2020 and ...

## BREAKING: Twitter Users Vote To Remove Elon Musk As The Head Of The Company
 - [https://www.dailywire.com/news/breaking-twitter-users-vote-to-remove-elon-musk-as-the-head-of-the-company](https://www.dailywire.com/news/breaking-twitter-users-vote-to-remove-elon-musk-as-the-head-of-the-company)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 06:34:09+00:00

Twitter strongly voted for Twitter CEO Elon Musk to step down as the head of the company in a poll that he posted to his account late Sunday afternoon. Musk posted the poll after a botched policy rollout earlier in the day, which prohibited users from promoting rival social media platforms, led to backlash on ...

## Elon Musk Reverses Course On New Policy After Widespread Backlash, Apologizes
 - [https://www.dailywire.com/news/elon-musk-reverses-course-on-new-policy-after-widespread-backlash-apologizes](https://www.dailywire.com/news/elon-musk-reverses-course-on-new-policy-after-widespread-backlash-apologizes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-19 05:56:36+00:00

Twitter CEO Elon Musk apologized on Sunday for instituting a new policy that sparked a flurry of negative comments that ultimately led to him reversing course. During the World Cup, the company announced it would suspend, and potentially ban, Twitter users who promoted certain rival social media platforms. The changes were widely viewed as an ...


# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Putin na Białorusi. Według Mińska przywiózł rakiety
 - [https://businessinsider.com.pl/wiadomosci/putin-na-bialorusi-wedlug-minska-przywiozl-rakiety/t48g34v](https://businessinsider.com.pl/wiadomosci/putin-na-bialorusi-wedlug-minska-przywiozl-rakiety/t48g34v)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 20:42:48+00:00

Władimir Putin przyleciał na Białoruś, gdzie spotkał się z Aleksandrem Łukaszenką. Po rozmowach Łukaszenko poinformował, że Mińsk otrzymał systemy rakietowe S-400 i Iskander.

## Zamrożenie cen energii. Kolejna państwowa spółka szacuje straty
 - [https://businessinsider.com.pl/gielda/zamrozenie-cen-energii-kolejna-panstwowa-spolka-szacuje-straty/x5rnqk5](https://businessinsider.com.pl/gielda/zamrozenie-cen-energii-kolejna-panstwowa-spolka-szacuje-straty/x5rnqk5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 20:23:24+00:00

Kolejna spółka energetyczna ujawniła wysokość straty, którą przyniesie jej zamrożenie cen energii w 2023 r. Wchodząca w skład Grupy Orlen Energa oszacowała ją na niemal miliard złotych.

## Grecy są gotowi zbroić Ukrainę. Stawiają Amerykanom i Niemcom warunek
 - [https://businessinsider.com.pl/wiadomosci/grecy-sa-gotowi-zbroic-ukraine-stawiaja-amerykanom-i-niemcom-warunek/xqxnkyw](https://businessinsider.com.pl/wiadomosci/grecy-sa-gotowi-zbroic-ukraine-stawiaja-amerykanom-i-niemcom-warunek/xqxnkyw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 19:20:36+00:00

Grecki rząd jest gotów przekazać Ukrainie systemy obrony powietrznej S-300. Warunkiem jest instalacja przez USA wyrzutni Patriot na Krecie — wynika z informacji przekazanych przez ministra obrony Grecji Nikolaosa Panagiotopoulosa.

## Limit cen gazu. Niemcy ulegli, Węgrzy byli do końca przeciwko
 - [https://businessinsider.com.pl/gospodarka/limit-cen-gazu-niemcy-ulegli-wegrzy-byli-do-konca-przeciwko/42rtqbf](https://businessinsider.com.pl/gospodarka/limit-cen-gazu-niemcy-ulegli-wegrzy-byli-do-konca-przeciwko/42rtqbf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 17:52:34+00:00

Zgoda na unijny limit cen rosyjskiego gazu to efekt budowy koalicji, która zdołała przełamać niemiecki opór w tej sprawie — to narracja polskiego premiera. Równocześnie jedynym krajem, który zagłosował przeciwko mechanizmowi, były Węgry.

## PZPN może stracić kolejnego sponsora. Biedronce nie spodobał się Katar [TYLKO U NAS]
 - [https://businessinsider.com.pl/biznes/12-lat-i-wystarczy-biedronce-nie-podobal-sie-katar-tylko-u-nas/wvn0r9e](https://businessinsider.com.pl/biznes/12-lat-i-wystarczy-biedronce-nie-podobal-sie-katar-tylko-u-nas/wvn0r9e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 17:19:37+00:00

Po każdym dużym turnieju nieuchronnie przychodzi czas rozliczeń. Mistrzostwa świata nie od dziś są nie tylko mniej lub bardziej atrakcyjną imprezą sportową, ale także, a może niestety coraz częściej, przede wszystkim wielką biznesową machiną, w której obok piłkarzy grają gigantyczne pieniądze. Rozliczenia są twarde, jedni tracą posady, inni pną się w biznesowej drabince. Lecą głowy trenerów, gwiazdy światowej piłki zmieniają barwy klubowe a piłkarscy menedżerowie siadają do negocjowania nowych kontraktów swoich podopiecznych. Swoje do powiedzenia mają też sponsorzy i spece od marketingu. W przypadku polskiej kadry można dyskutować, czy wyjście z grupy w marnym stylu jest najważniejszą informacją. Ze współpracy z PZPN mogą wycofać się kolejni biznesowi partnerzy. Według ustaleń Business Insider Polska na dniach Polski Związek Piłki Nożnej może stracić ważnego sponsora. Właściciel sieci Biedronka bardzo poważnie rozważa decyzje o nieprzedłużeniu wygasającej z końcem roku umowy sponsorskiej z PZPN, z którym był na dobre i na złe od niemal 12 lat.

## Tak Węgrzy pomogą Ukrainie. Wyślą 15 autobusów
 - [https://businessinsider.com.pl/gospodarka/tak-wegrzy-pomoga-ukrainie-wysla-15-autobusow/ekrzbk2](https://businessinsider.com.pl/gospodarka/tak-wegrzy-pomoga-ukrainie-wysla-15-autobusow/ekrzbk2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 17:00:09+00:00

Budapeszteński operator transportu zbiorowego BKV przekazał Ukrainie 15 autobusów w ramach pomocy dla zmagającego się z rosyjską agresją kraju – poinformował w poniedziałek burmistrz Budapesztu Gergely Karacsony.

## Unikalna fabryka EcoPet w Nałęczowie zagrożona decyzją ministerstwa. Sprawą zajmie się Wojewódzki Sąd Administracyjny
 - [https://businessinsider.com.pl/finanse/unikalna-fabryka-w-naleczowie-ma-problem-z-decyzja-resortu-rolnictwa-sprawa-trafila/2d8te83](https://businessinsider.com.pl/finanse/unikalna-fabryka-w-naleczowie-ma-problem-z-decyzja-resortu-rolnictwa-sprawa-trafila/2d8te83)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 16:58:00+00:00

Fabryka EcoPet, która miała powstać w Nałęczowie, jest futurystycznym zakładem, który ma w sobie łączyć technologię, ekologię i być przyjazna dla otoczenia. Hale produkcyjne będą w niej zlokalizowane pod ziemią, a na powierzchni zakład miał posiadać centrum dla zwiedzających pod pokrytym zielenią dachem. Powstawać w nim miały ekologiczne opakowania do żywności. Ministerstwo Rolnictwa nie chce jednak odrolnić terenów pod jej budowę, a burmistrz Nałęczowa odwołał się od decyzji resortu, a jeszcze w grudniu sprawą ma zająć się Wojewódzki Sąd Administracyjny. Resort rolnictwa odniósł się do sprawy.

## Dostała zdrapkę na firmowej wigilii. Wygrała 175 tys. dol.
 - [https://businessinsider.com.pl/wiadomosci/dostala-zdrapke-na-firmowej-wigilii-wygrala-175-tys-dol/2dzhb4l](https://businessinsider.com.pl/wiadomosci/dostala-zdrapke-na-firmowej-wigilii-wygrala-175-tys-dol/2dzhb4l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 16:35:15+00:00

Pewna mieszkanka Kentucky wyszła z imprezy świątecznej swojej firmy bogatsza o 175 tys. dol. po tym, jak otrzymała w prezencie zdrapki.

## Kolejny cios w Putina. Jest zgoda na maksymalną cenę gazu z Rosji
 - [https://businessinsider.com.pl/gospodarka/kolejny-cios-w-putina-jest-zgoda-na-maksymalna-cene-gazu-z-rosji/3bvn6v9](https://businessinsider.com.pl/gospodarka/kolejny-cios-w-putina-jest-zgoda-na-maksymalna-cene-gazu-z-rosji/3bvn6v9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 16:00:38+00:00

Państwa członkowskie Unii Europejskiej porozumiały się ws. maksymalnej ceny gazu z Rosji. To kolejny cios w interesy Kremla po ustaleniu maksymalnej ceny ropy naftowej i wprowadzeniu zakazu na import rosyjskiej ropy drogą morską.

## Twitter Muska skazany na porażkę. "Korzysta z przestarzałego podręcznika"
 - [https://businessinsider.com.pl/technologie/twitter-muska-skazany-na-porazke-korzysta-z-przestarzalego-podrecznika/krnk17j](https://businessinsider.com.pl/technologie/twitter-muska-skazany-na-porazke-korzysta-z-przestarzalego-podrecznika/krnk17j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 15:52:44+00:00

W Tesli i SpaceX Elon Musk był gburem z wielką wizją. Na Twitterze jest po prostu gburem, a jego inwestycja skazana jest na porażkę, bo miliarder korzysta z przestarzałego podręcznika do zarządzania. Odkąd został kierownikiem, "jest jak w Hogwarcie, gdy władzę objęli Śmierciożercy Voldemorta".

## Zmiana kadrowa w państwowej spółce. Dymisja członka zarządu
 - [https://businessinsider.com.pl/gielda/wiadomosci/zmiana-kadrowa-w-panstwowej-spolce-dymisja-czlonka-zarzadu/jggd45f](https://businessinsider.com.pl/gielda/wiadomosci/zmiana-kadrowa-w-panstwowej-spolce-dymisja-czlonka-zarzadu/jggd45f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 15:42:00+00:00

Spółka Enea poinformowała, że rada nadzorcza odwołała bez podania przyczyny Tomasza Siwaka, członka zarządu ds. handlowych. Nie podano przyczyny zwolnienia.

## Strajk w Pyszne.pl. Dostawcy mogą protestować nawet tydzień
 - [https://businessinsider.com.pl/biznes/strajk-w-pysznepl-dostawcy-moga-protestowac-nawet-tydzien/yjlqk63](https://businessinsider.com.pl/biznes/strajk-w-pysznepl-dostawcy-moga-protestowac-nawet-tydzien/yjlqk63)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 15:25:19+00:00

Dostawcy platformy Pyszne.pl rozpoczęli w poniedziałek 19 grudnia strajk w kilku miastach Polski — donosi portal Wirtualnemedia.pl. To skutek wybiórczego wprowadzenia przez serwis dodatków za pracę w weekendy.

## O tyle droższe będa tegoroczne święta. Ceny jednego produktu wystrzeliły
 - [https://businessinsider.com.pl/gospodarka/o-tyle-drozsze-beda-tegoroczne-swieta-trzy-produkty-rozbily-bank/9tvn98s](https://businessinsider.com.pl/gospodarka/o-tyle-drozsze-beda-tegoroczne-swieta-trzy-produkty-rozbily-bank/9tvn98s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 15:15:12+00:00

W tym roku wigilia będzie droższa o nawet 30 proc. - wynika z danych zebranych przez aplikację PanParagon. Zdecydowanie najszybciej rosną ceny suszonych grzybów, które w porównaniu z ubiegłym rokiem kosztują o prawie 70 proc. więcej. Kroku dotrzymują im jeszcze tylko cukier i mąka.

## Inflacja powyżej 20 proc. i spadek PKB. Nowa prognoza wskazuje na trudny pierwszy kwartał
 - [https://businessinsider.com.pl/gospodarka/inflacja-powyzej-20-proc-i-spadek-pkb-nowa-prognoza-wskazuje-na-trudny-pierwszy/hz06yr2](https://businessinsider.com.pl/gospodarka/inflacja-powyzej-20-proc-i-spadek-pkb-nowa-prognoza-wskazuje-na-trudny-pierwszy/hz06yr2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 15:13:31+00:00

Wszelkie znaki na niebie i na ziemi wskazują, że przed nami bardzo ciężki początek nowego roku. W pierwszym kwartale 2023 r. należy spodziewać się spadku PKB o 0,3 proc., a w lutym czeka nas inflacja nawet powyżej 20 proc. – wynika z raportu Polskiego Instytutu Ekonomicznego.

## Co zrobić, by świąteczne prezenty nie nabiły nam rachunków?
 - [https://businessinsider.com.pl/twoje-pieniadze/co-zrobic-by-swiateczne-prezenty-nie-nabily-nam-rachunkow/32f75br](https://businessinsider.com.pl/twoje-pieniadze/co-zrobic-by-swiateczne-prezenty-nie-nabily-nam-rachunkow/32f75br)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 15:04:26+00:00

Konsole, smartfony, laptopy, telewizory, lokówki, trenażery, roboty kuchenne – to tylko początek długiej listy elektronicznych prezentów, jakimi już za parę dni będziemy obdarowywać najbliższych.

## Kogo wojsko wezwie przed komisję. Znamy szczegóły
 - [https://businessinsider.com.pl/prawo/kogo-wojsko-wezwie-na-kwalifikacje-wojskowa-w-2023-r/4vc5bef](https://businessinsider.com.pl/prawo/kogo-wojsko-wezwie-na-kwalifikacje-wojskowa-w-2023-r/4vc5bef)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 14:16:28+00:00

Ministerstwo Obrony Narodowej zdecydowało, kogo wezwie w 2023 r. do stawienia się przed powiatową komisją lekarską, która przyzna im kwalifikację wojskową. Wezwanie dostanie aż 230 tys. osób. Kwalifikacja będzie trwała od 3 kwietnia ido 30 czerwca br.

## Nominalna płaca w Polsce powyżej greckiej, a może i portugalskiej
 - [https://businessinsider.com.pl/gospodarka/nominalna-placa-w-polsce-powyzej-greckiej-a-moze-i-portugalskiej/rb8ww97](https://businessinsider.com.pl/gospodarka/nominalna-placa-w-polsce-powyzej-greckiej-a-moze-i-portugalskiej/rb8ww97)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 14:10:32+00:00

Godzinowe koszty pracy wzrosły w Polsce o 13,3 proc. w trzecim kwartale br.—podał Eurostat. Przy złotym umacniającym się ostatnio do euro oznacza to, że wyprzedzamy już prawdopodobnie Grecję pod względem średnich nominalnych zarobków. A niewykluczone, że i Portugalię.

## Wiatrakowy serial w rządzie trwa. Rzecznik zabrał głos
 - [https://businessinsider.com.pl/gospodarka/wiatrakowy-serial-w-rzadzie-trwa-rzecznik-zabral-glos/svn6ldv](https://businessinsider.com.pl/gospodarka/wiatrakowy-serial-w-rzadzie-trwa-rzecznik-zabral-glos/svn6ldv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 13:54:47+00:00

Zamieszanie w sprawie tzw. ustawy wiatrakowej wciąż trwa. Rządzący są w tej kwestii "zakładnikiem" Solidarnej Polski, która o likwidacji zasady 10H nie chce nawet słyszeć. Teraz Piotr Müller stwierdził, że nowelizacja ustawy może zostać przyjęta w nowym roku.

## Czy studia online zmienią na zawsze szkolnictwo wyższe? Edukacja nigdy nie była tak prosta
 - [https://businessinsider.com.pl/czy-studia-online-zmienia-na-zawsze-szkolnictwo-wyzsze-edukacja-nigdy-nie-byla-tak/smjbdqw](https://businessinsider.com.pl/czy-studia-online-zmienia-na-zawsze-szkolnictwo-wyzsze-edukacja-nigdy-nie-byla-tak/smjbdqw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 13:27:00+00:00

Postępująca cyfryzacja nie omija sektora edukacji, a pandemia COVID-19 stała się motorem zmian, które – jak się okazuje – zostaną z nami na dłużej. Jedną z nich jest rosnąca popularność e-learningu, po który coraz częściej sięgają uczelnie wyższe – wśród nich Wyższa Szkoła Kształcenia Zawodowego.

## MAP potwierdza nasze ustalenia. Rafineria pod specjalną ochroną
 - [https://businessinsider.com.pl/gospodarka/map-potwierdza-nasze-ustalenia-rafineria-pod-specjalna-ochrona/l9kelsg](https://businessinsider.com.pl/gospodarka/map-potwierdza-nasze-ustalenia-rafineria-pod-specjalna-ochrona/l9kelsg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 13:17:10+00:00

Potwierdziły się ustalenia BI Polska. Resort aktywów państwowych poinformował, że Rafineria Gdańska od 1 stycznia 2023 r. zostanie wpisana na specjalną liście podmiotów podlegających ochronie.

## Święta wypadają w weekend. Czy pracownikom należy się dodatkowe wolne?
 - [https://businessinsider.com.pl/wiadomosci/swieta-w-weekend-czy-pracownikom-nalezy-sie-dodatkowe-wolne/cy5hc95](https://businessinsider.com.pl/wiadomosci/swieta-w-weekend-czy-pracownikom-nalezy-sie-dodatkowe-wolne/cy5hc95)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 12:55:00+00:00

Tegoroczny układ świąt niespecjalnie sprzyja przedłużonemu wolnemu. Wigilia wypada w sobotę, a pierwszy dzień świąt w niedzielę. Co o takiej sytuacji mówi Kodeks pracy? Wyjaśniamy.

## Koniec z wydzwanianiem po lekarzach. Rewolucja w zapisach na NFZ
 - [https://businessinsider.com.pl/prawo/koniec-z-wydzwanianiem-po-lekarzach-rewolucja-w-zapisach-na-nfz/8l92sf1](https://businessinsider.com.pl/prawo/koniec-z-wydzwanianiem-po-lekarzach-rewolucja-w-zapisach-na-nfz/8l92sf1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 12:37:05+00:00

Na leczenie na Narodowy Fundusz Zdrowia zarejestrujemy się przez internet. Tak jak na szczepienie przeciwko COVID-19. Przez Internetowe Konto Pacjenta będzie można zarejestrować się do lekarza w przychodni, ale też szpitalu. Nowa centralna e-rejestracja ma sprawić, że kolejki będą bardziej sprawiedliwe. Tak wynika z założeń projektu ustawy, nad którą pracuje Ministerstwo Zdrowia.

## Reuters: Rosja i Chiny szykują wspólne manewry jeszcze w tym roku
 - [https://businessinsider.com.pl/gospodarka/reuters-rosja-i-chiny-szykuja-wspolne-manewry-jeszcze-w-tym-roku/pkez2pb](https://businessinsider.com.pl/gospodarka/reuters-rosja-i-chiny-szykuja-wspolne-manewry-jeszcze-w-tym-roku/pkez2pb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 12:22:13+00:00

Siły zbrojne Rosji i Chin wezmą udział we wspólnych manewrach na wodach Morza Wschodniochińskiego, zaplanowanych w dniach 21-27 grudnia. Scenariusz ćwiczeń zakłada m.in. przeprowadzenie ostrzałów artyleryjskich i rakietowych — poinformował w poniedziałek Reuters powołując się na resort obrony w Moskwie.

## SMS-owa plaga przed świętami. Nie daj się złapać na ten trik
 - [https://businessinsider.com.pl/twoje-pieniadze/sms-owa-plaga-nie-daj-sie-zlapac-na-ten-swiateczny-trik/c314enm](https://businessinsider.com.pl/twoje-pieniadze/sms-owa-plaga-nie-daj-sie-zlapac-na-ten-swiateczny-trik/c314enm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 12:17:01+00:00

Oszuści próbują wykorzystać przedświąteczne zamieszanie, by wyłudzić pieniądze. Do Polaków masowo przychodzą SMS-y, które należy zignorować.

## Rzeczkowska zapowiada, że rok skończymy z nadwyżką w budżecie
 - [https://businessinsider.com.pl/gospodarka/w-budzecie-mozemy-miec-nadwyzke-co-to-oznacza/zbnwynz](https://businessinsider.com.pl/gospodarka/w-budzecie-mozemy-miec-nadwyzke-co-to-oznacza/zbnwynz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 12:13:05+00:00

Jest szansa na nadwyżkę w tegorocznym budżecie, choć z ostateczną oceną wstrzymajmy się jeszcze trochę, aż będziemy wiedzieć, jak wygląda wykonanie budżetu za 2022 r. – powiedziała w poniedziałek w Studiu PAP minister finansów Magdalena Rzeczkowska. Przypomnijmy jednak, że spora część wydatków sektora finansów publicznych obecnie omija budżet.

## Obajtek składa deklarację w sprawie cen po Nowym Roku. Zabrał też głos w sprawie fuzji
 - [https://businessinsider.com.pl/gospodarka/obajtek-sklada-deklaracje-w-sprawie-cen-paliwa-po-nowym-roku-to-zaskakujace/yj735zq](https://businessinsider.com.pl/gospodarka/obajtek-sklada-deklaracje-w-sprawie-cen-paliwa-po-nowym-roku-to-zaskakujace/yj735zq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 11:35:46+00:00

— Powrót VAT-u nie powinien mieć istotnego wpływu na ceny na naszych stacjach — zadeklarował na antenie RMF FM prezes PKN Orlen Daniel Obajtek. Pytany o fuzję Orlenu i Lotosu zadeklarował, że cały proces fuzji jest zabezpieczony umowami i ustawowo.

## Obajtek składa deklarację w sprawie cen po nowym roku. Zabrał też głos w sprawie fuzji
 - [https://businessinsider.com.pl/gospodarka/obajtek-sklada-deklaracje-w-sprawie-cen-po-nowym-roku-zabral-tez-glos-w-sprawie-fuzji/yj735zq](https://businessinsider.com.pl/gospodarka/obajtek-sklada-deklaracje-w-sprawie-cen-po-nowym-roku-zabral-tez-glos-w-sprawie-fuzji/yj735zq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 11:35:46+00:00

— Powrót VAT-u nie powinien mieć istotnego wpływu na ceny na naszych stacjach — zadeklarował na antenie RMF FM prezes PKN Orlen Daniel Obajtek. Pytany o fuzję Orlenu i Lotosu zadeklarował, że cały proces fuzji jest zabezpieczony umowami i ustawowo.

## Elon Musk wpadł we własną pułapkę. Będzie musiał odejść
 - [https://businessinsider.com.pl/biznes/elon-musk-wpadl-we-wlasna-pulapke-bedzie-musial-odejsc/0cf4glh](https://businessinsider.com.pl/biznes/elon-musk-wpadl-we-wlasna-pulapke-bedzie-musial-odejsc/0cf4glh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 11:33:11+00:00

Ekscentryczny miliarder i właściciel Twittera Elon Musk będzie musiał odejść ze stanowiska szefa platformy. O ile oczywiście okaże się słowny i zrealizuje złożoną w niedzielę obietnicę. Użytkownicy serwisu zdecydowali bowiem w zakończonej właśnie ankiecie, że biznesmen powinien złożyć dymisję.

## Niespodziewana poprawa nastrojów w niemieckiej gospodarce. To szansa dla polskich firm
 - [https://businessinsider.com.pl/gospodarka/indeks-ifo-niespodziewana-poprawa-nastrojow-w-niemieckiej-gospodarce-to-szansa-dla/6lzrt28](https://businessinsider.com.pl/gospodarka/indeks-ifo-niespodziewana-poprawa-nastrojow-w-niemieckiej-gospodarce-to-szansa-dla/6lzrt28)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 11:17:31+00:00

Nastroje w niemieckiej gospodarce wyraźnie się poprawiły. Indeks koniunktury ifo wzrósł w grudniu do 88,6 pkt, po 86,4 pkt w listopadzie. Oznacza to, że firmy, choć wciąż przeważnie są w złych nastrojach, to jednak lepiej oceniły swoją obecną sytuację. Wcześniej wskaźnik bieżącej sytuacji spadł sześć razy z rzędu.

## Niespodziewana poprawa nastrojów w niemieckiej gospodarce. To szansa dla polskich firm
 - [https://businessinsider.com.pl/gospodarka/zaskakujaca-poprawa-nastrojow-w-niemieckiej-gospodarce-to-szansa-dla-polskich-firm/6lzrt28](https://businessinsider.com.pl/gospodarka/zaskakujaca-poprawa-nastrojow-w-niemieckiej-gospodarce-to-szansa-dla-polskich-firm/6lzrt28)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 11:17:31+00:00

Nastroje w niemieckiej gospodarce wyraźnie się poprawiły. Indeks koniunktury ifo wzrósł w grudniu do 88,6 pkt, po 86,4 pkt w listopadzie. Oznacza to, że firmy, choć wciąż przeważnie są w złych nastrojach, to jednak lepiej oceniły swoją obecną i przyszłą sytuację. Wcześniej wskaźnik bieżącej sytuacji spadł sześć razy z rzędu.

## Amazon nieoczekiwanym bohaterem Ukrainy. W ten sposób pomógł uratować kraj
 - [https://businessinsider.com.pl/wiadomosci/amazon-nieoczekiwanym-bohaterem-ukrainy-w-ten-sposob-pomogl-uratowac-kraj/cs54w4n](https://businessinsider.com.pl/wiadomosci/amazon-nieoczekiwanym-bohaterem-ukrainy-w-ten-sposob-pomogl-uratowac-kraj/cs54w4n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 11:12:26+00:00

Amazon pomógł uratować ukraiński rząd i gospodarkę, dzięki dyskom twardym wielkości walizki, przewiezionym przez polską granicę.

## Miliony za donoszenie Putinowi. Rosyjski szpieg zdemaskowany
 - [https://businessinsider.com.pl/wiadomosci/miliony-za-donoszenie-putinowi-rosyjski-szpieg-zdemaskowany/2vcdn01](https://businessinsider.com.pl/wiadomosci/miliony-za-donoszenie-putinowi-rosyjski-szpieg-zdemaskowany/2vcdn01)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 10:57:41+00:00

Choć nie miał pracy, stać go było na dziesiątki zagranicznych podróży. Austriacki kontrwywiad zdemaskował 39-letniego obywatela Grecji rosyjskiego pochodzenia, pracującego dla rosyjskiego wywiadu GRU. Za zebrane informacje, z których cześć miała związek z działaniami Rosji na Ukrainie, mężczyzna miał zarobić miliony — informuje w poniedziałek portal dziennika "Kronen Zeitung".

## Minister finansów: wiosna powinna przynieść spadek inflacji
 - [https://businessinsider.com.pl/finanse/minister-finansow-wiosna-powinna-przyniesc-spadek-inflacji/n5z1esb](https://businessinsider.com.pl/finanse/minister-finansow-wiosna-powinna-przyniesc-spadek-inflacji/n5z1esb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 10:36:20+00:00

Początek roku może wiązać się z nieco wyższą inflacją niż w grudniu, ale wiosna, marzec i kolejne wiosenne miesiące, powinny już przynieść spadek inflacji — powiedziała w poniedziałek minister finansów Magdalena Rzeczkowska.

## Dobre wieści dla emerytów. Mogą spodziewać się "prezentu" przed świętami i sylwestrem
 - [https://businessinsider.com.pl/twoje-pieniadze/emerytury/dobre-wiesci-dla-emerytow-moga-spodziewac-sie-prezentu-przed-swietami-i-sylwestrem/2x79mzr](https://businessinsider.com.pl/twoje-pieniadze/emerytury/dobre-wiesci-dla-emerytow-moga-spodziewac-sie-prezentu-przed-swietami-i-sylwestrem/2x79mzr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 10:33:52+00:00

Emeryci i renciści, którym ZUS wypłaca świadczenia 25. każdego miesiąca, w grudniu otrzymają je przed świętami. Dotyczy to zarówno wypłat przekazywanych przez listonosza, jak i przelewów, które trafiają na rachunki bankowe – poinformowała PAP prezes ZUS prof. Gertruda Uścińska.

## Słodko-gorzkie słowa członka RPP. Oto co nas czeka w 2023 r.
 - [https://businessinsider.com.pl/finanse/obnizka-stop-procentowych-w-2023-r-slodko-gorzkie-slowa-czlonka-rpp/qvl3je7](https://businessinsider.com.pl/finanse/obnizka-stop-procentowych-w-2023-r-slodko-gorzkie-slowa-czlonka-rpp/qvl3je7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 10:07:34+00:00

W przyszłym roku mogą pojawić się przesłanki do podjęcia dyskusji na temat obniżek stóp procentowych, natomiast jeszcze nie przesłanki do samego luzowania polityki monetarnej, uważa członek Rady Polityki Pieniężnej (RPP) Henryk Wnorowski. Mówi, co musi się stać, by rozpoczęły się poważne rozmowy o obniżkach.

## Jak nowe technologie pomagają zdobywać i lojalizować klientów? [debata]
 - [https://businessinsider.com.pl/biznes/jak-nowe-technologie-pomagaja-zdobywac-i-lojalizowac-klientow-debata/6c49py9](https://businessinsider.com.pl/biznes/jak-nowe-technologie-pomagaja-zdobywac-i-lojalizowac-klientow-debata/6c49py9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 10:00:00+00:00

Banki wyznaczają trendy w zakresie rozwoju aplikacji mobilnych. Dzisiaj klienci coraz rzadziej odwiedzają placówki – wiele spraw mogą załatwić, nie wychodząc z domu. Na tle banków szczególnie wyróżnia się Bank Millennium, który w tegorocznej edycji rankingu Przyjazny Bank Newsweeka zajął pierwsze miejsce w kategorii „Bankowość zdalna”, stając się najlepszym bankiem cyfrowym w Polsce. Eksperci, biorący udział w debacie z cyklu Business Insider Trends: Krzysztof Tomczak, senior partner agencji badawczej Minds &amp; Roses, Tomasz Pol, dyrektor Departamentu Marketingu Bankowości Detalicznej Banku Millennium oraz Tomasz Witt, prezes Norbsoft, nie mieli wątpliwości, że telefon jest tym urządzeniem, które będzie zyskiwało na znaczeniu. Aplikacje mobilne, aby przyciągnąć użytkowników muszą być, zdaniem ekspertów proste, intuicyjne, nieskomplikowane i spersonalizowane. Przy rozwoju aplikacji mobilnych pojawia się jednak pytanie o bezpieczeństwo. „Czy telefony nas słuchają i podsłuchują” – zapytał prowadzący debatę Mikołaj Kunica, redaktor naczelny Business Insider Polska. „Zaufane marki i produkty, zwłaszcza bankowe takich rzeczy nie robią, możemy czuć się bezpiecznie” – zaznaczyli eksperci.

## Wyjeżdżasz na święta? Nie daj szans włamywaczowi
 - [https://businessinsider.com.pl/technologie/wyjezdzasz-na-swieta-nie-daj-szans-wlamywaczowi/eex2wxe](https://businessinsider.com.pl/technologie/wyjezdzasz-na-swieta-nie-daj-szans-wlamywaczowi/eex2wxe)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 09:57:00+00:00

Na rynku jest coraz więcej profesjonalnych urządzeń, które pozwalają zabezpieczyć nasz majątek. Nowoczesny monitoring podłączony do sieci rejestruje wszystko, co dzieje się w domu czy w ogrodzie. Czujniki ruchu i zmierzchu w odpowiednim czasie włączają światło wewnętrzne lub zewnętrzne, co często wystarczy, żeby odstraszyć włamywacza. Dzięki nowoczesnym urządzeniom monitorującym, będąc wiele kilometrów od domu, w każdej chwili możesz uruchomić podgląd na żywo i w razie potrzeby uruchomić syreny alarmowe.

## "On po prostu oszalał". Oligarchowie czują się oszukani przez Putina
 - [https://businessinsider.com.pl/wiadomosci/oligarchowie-czuja-sie-oszukani-przez-putina-on-po-prostu-oszalal/8q2k2wk](https://businessinsider.com.pl/wiadomosci/oligarchowie-czuja-sie-oszukani-przez-putina-on-po-prostu-oszalal/8q2k2wk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 09:54:24+00:00

- Jeśli wszyscy wokół ciebie przez 22 lata mówią ci, że jesteś supergeniuszem, to zaczynasz wierzyć, że taki właśnie jesteś — powiedział "The Times" Oleg Tinkow, były rosyjski potentat bankowy. Nie jest jedynym oligarchą, który zwrócił się przeciw Władimirowi Putinowi po ataku na Ukrainę.

## "Liczne centra handlowe są na skraju bankructwa". Coraz większe problemy Rosji
 - [https://businessinsider.com.pl/gospodarka/sankcje-uderzaja-w-rosje-liczne-centra-na-skraju-bankructwa/1gjske4](https://businessinsider.com.pl/gospodarka/sankcje-uderzaja-w-rosje-liczne-centra-na-skraju-bankructwa/1gjske4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 09:38:42+00:00

Profesor ekonomii Kirył Kułakow przekonuje, że wiele sklepów i restauracji w Rosji jest w coraz gorszej kondycji. Choć wylewająca się z tamtejszych programów propaganda próbuje przekazać, że Zachód cierpi na izolowaniu Rosji, to nastroje wśród jej mieszkańców są coraz gorsze.

## Dobre wieści dla pracowników. Pracodawcy dadzą podwyżki
 - [https://businessinsider.com.pl/twoje-pieniadze/praca/dobre-wiesci-dla-pracownikow-pracodawcy-dadza-podwyzki/zmvyw5s](https://businessinsider.com.pl/twoje-pieniadze/praca/dobre-wiesci-dla-pracownikow-pracodawcy-dadza-podwyzki/zmvyw5s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 09:35:03+00:00

53 proc. przedsiębiorców planuje w przyszłym roku podwyżki. 17 proc. zamierza dać podwyżki w związku z podniesieniem płacy minimalnej, 22 proc. wyrówna inflację, a 14 proc. podniesie pensje bez względu na inflację i wyższą płacę minimalną – wynika z raportu Personnel Service.

## Co wziąć pod uwagę przy zakupie telewizora?
 - [https://businessinsider.com.pl/co-wziac-pod-uwage-przy-zakupie-telewizora/byw940t](https://businessinsider.com.pl/co-wziac-pod-uwage-przy-zakupie-telewizora/byw940t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 09:33:30+00:00

Telewizor służy dzisiaj nie tylko do oglądania filmów, ale także grania w gry, streamowania i wielu innych rzeczy. Naturalnym więc jest, że wybierając model dla siebie musimy uwzględnić wszystkie nasze potrzeby i plany względem upatrzonego sprzętu. Na co zwrócić uwagę, jeżeli planujemy kupić telewizor? Która matryca pozwoli nam doświadczyć najlepszej możliwej jakości obrazu? Jak zabezpieczyć drogi sprzęt przed losowymi wypadkami lub niezamierzonym uszkodzeniem?

## Daniel Obajtek: Orlen będzie jeszcze więcej inwestować w sport
 - [https://businessinsider.com.pl/gielda/wiadomosci/daniel-obajtek-orlen-bedzie-jeszcze-wiecej-inwestowac-w-sport/ctjxzec](https://businessinsider.com.pl/gielda/wiadomosci/daniel-obajtek-orlen-bedzie-jeszcze-wiecej-inwestowac-w-sport/ctjxzec)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 09:33:05+00:00

"Nie ma przyszłości naszego sportu bez inwestowania w niego" —podkreślił prezes PKN Orlen podczas konferencji związanej z finansowaniem sportu przez płockiego giganta. Wskazał, że sport buduje rozpoznawalność firmy na zagranicznych rynkach.

## Kto powiedział, że klocki są tylko dla dzieci? 10 zestawów LEGO dla dorosłych
 - [https://businessinsider.com.pl/technologie/10-zestawow-lego-dla-doroslych/znjyrsx](https://businessinsider.com.pl/technologie/10-zestawow-lego-dla-doroslych/znjyrsx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 09:33:00+00:00

Każdy z nas zna klocki LEGO. W końcu od kilku dziesięcioleci rozpalają wyobraźnię kolejnych pokoleń. Można z nich zbudować niemal wszystko – od sokoła Millenium znanego z "Gwiezdnych Wojen" po zagrodę dla zwierząt czy domek dla lalek. Nie oszukujmy się, wiele zestawów dedykowanych teoretycznie dla dzieci sprawia frajdę również rodzicom. Dlatego w ofercie firmy można znaleźć wiele produktów, które są skierowane do dorosłych. W końcu kto powiedział, że po pracy nie można od czasu do czasu oddać się beztroskiej zabawie?

## Stracą miliony, ale się nie otworzą. W tych sklepach handlu w Wigilię nie będzie
 - [https://businessinsider.com.pl/wiadomosci/jak-otwarte-beda-sklepy-w-wigilie-te-wcale-mimo-ze-straca-miliony/b8qwmzf](https://businessinsider.com.pl/wiadomosci/jak-otwarte-beda-sklepy-w-wigilie-te-wcale-mimo-ze-straca-miliony/b8qwmzf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 09:02:34+00:00

Sklepy spożywcze planują niemal do ostatniej możliwej chwili prowadzić handel w Wigilię. Zupełnie inne podejście mają natomiast dwie inne znane sieci z branży meblowej i dekoracyjnej.

## Spółka Dominiki Kulczyk straci na ustawie prawie 200 mln zł
 - [https://businessinsider.com.pl/gielda/wiadomosci/polenergia-spolka-dominiki-kulczyk-straci-na-ustawie-prawie-200-mln-zl/c82xped](https://businessinsider.com.pl/gielda/wiadomosci/polenergia-spolka-dominiki-kulczyk-straci-na-ustawie-prawie-200-mln-zl/c82xped)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 09:01:59+00:00

W ustawie o maksymalnych cenach prądu ustalono rządowe rekompensaty dla sprzedawców energii. Kontrolowana przez Dominikę Kulczyk spółka Polenergia, produkująca zieloną energię, wgryzła się jednak w przepisy i wszystko policzyła. Wychodzi na to, że będzie jednym z finansujących nowe przepisy, bo ubytek został oszacowany na 180 mln zł.

## Bilion dolarów rachunku za energię. A to dopiero początek kryzysu
 - [https://businessinsider.com.pl/finanse/bilion-dolarow-rachunku-za-energie-a-to-dopiero-poczatek-kryzysu/9sk83kl](https://businessinsider.com.pl/finanse/bilion-dolarow-rachunku-za-energie-a-to-dopiero-poczatek-kryzysu/9sk83kl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 08:54:24+00:00

Europa została dotknięta kwotą około biliona dolarów z tytułu rosnących kosztów energii w wyniku wojny Rosji w Ukrainie. Najgłębszy kryzys od dziesięcioleci dopiero się zaczyna — pisze Bloomberg.

## Bezpieczny kredyt 2 proc. Minister zdradza, ile osób ma skorzystać
 - [https://businessinsider.com.pl/twoje-pieniadze/nieruchomosci/bezpieczny-kredyt-2-proc-minister-zdradza-ile-osob-ma-skorzystac/mk471jj](https://businessinsider.com.pl/twoje-pieniadze/nieruchomosci/bezpieczny-kredyt-2-proc-minister-zdradza-ile-osob-ma-skorzystac/mk471jj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 08:45:30+00:00

Z preferencyjnego kredytu oprocentowanego na poziomie 2 proc. na zakup mieszkania może skorzystać około 100 tys. osób w najbliższych latach, ocenia minister rozwoju i technologii Waldemar Buda. Podkreślił, że to jest jego cel.

## Spór o KPO może zaszkodzić rządowi. Polacy jasno stawiają sprawę [SONDAŻ]
 - [https://businessinsider.com.pl/finanse/spor-o-kpo-moze-zaszkodzic-rzadowi-polacy-jasno-stawiaja-sprawe-sondaz/02vtj4c](https://businessinsider.com.pl/finanse/spor-o-kpo-moze-zaszkodzic-rzadowi-polacy-jasno-stawiaja-sprawe-sondaz/02vtj4c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 08:28:59+00:00

Ustawa o Sądzie Najwyższym, która jest kluczowa dla otrzymania przez Polskę miliardów z Unii Europejskiej, jest jedną z głównych osi sporu między PiS a Solidarną Polską. Tymczasem aż 66 proc. Polaków jest za nowelizacją – wynika z sondażu United Surveys dla DGP i RMF FM.

## Elon Musk pyta się użytkowników Twittera, czy ma kierować serwisem
 - [https://businessinsider.com.pl/media/internet/elon-musk-pyta-sie-uzytkownikow-twittera-czy-ma-kierowac-serwisem/44dry9v](https://businessinsider.com.pl/media/internet/elon-musk-pyta-sie-uzytkownikow-twittera-czy-ma-kierowac-serwisem/44dry9v)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 08:27:29+00:00

Amerykański miliarder i właściciel sieci społecznościowej Twitter Elon Musk ogłosił w nocy z niedzieli na poniedziałek ankietę, w której użytkownicy Twittera mogą wypowiedzieć się, czy chcą by dalej kierował platformą czy ustąpił ze stanowiska. Zastosuję się do wyników głosowania — zadeklarował Musk.

## Mniejsze sztabki i frakcyjne monety bulionowe. Polacy szukają okazji w metalach szlachetnych
 - [https://businessinsider.com.pl/twoje-pieniadze/sztabki-zlota-i-frakcyjne-monety-bulionowe-polacy-szukaja-okazji-w-metalach/612g7je](https://businessinsider.com.pl/twoje-pieniadze/sztabki-zlota-i-frakcyjne-monety-bulionowe-polacy-szukaja-okazji-w-metalach/612g7je)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 08:20:16+00:00

Wśród Polaków wzrasta ostatnio zainteresowanie metalami szlachetnymi. Inwestycja w nie uważana jest za tzw. bezpieczną przystań, która w okresie wysokiej inflacji oraz kryzysów gospodarczych długoterminowo zachowuje wartość. Jednak inwestując w tego typu rzeczy, należy mieć oczy dookoła głowy.

## Kurs dolara 19 grudnia w okolicach 4,4 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-19-grudnia-2022/4e35yy7](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-19-grudnia-2022/4e35yy7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 08:09:35+00:00

Kurs dolara w okolicach 4,4 zł. W piątek rano 16 grudnia 2022 r. kurs USD/PLN wynosi 4,4115.

## Kurs euro 19 grudnia poniżej 4,7
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-19-grudnia-2022/881f03k](https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-19-grudnia-2022/881f03k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 08:07:51+00:00

Kurs euro poniżej 4,7 zł. W poniedziałek rano 19 grudnia 2022 r. kurs EUR/PLN wynosił 4,6914 zł.

## Kurs franka 19 grudnia w okolicach 4,75 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-19-grudnia-2022/zxpmdfh](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-19-grudnia-2022/zxpmdfh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 08:06:01+00:00

Frank szwajcarski w okolicach 4,75 zł. W poniedziałek rano 19 grudnia 2022 r. kurs tej waluty wobec polskiego złotego wynosi 4,7431.

## Jak produkuje się tysiące ton kolorowego proszku na hinduskie święto Holi
 - [https://businessinsider.com.pl/lifestyle/jak-produkuje-sie-tysiace-ton-kolorowego-proszku-na-hinduskie-swieto-holi/nexzkx2](https://businessinsider.com.pl/lifestyle/jak-produkuje-sie-tysiace-ton-kolorowego-proszku-na-hinduskie-swieto-holi/nexzkx2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 07:49:00+00:00

Produkcja proszku Holi w jednej z indyjskich fabryk przynosi rocznie ponad 30 koti rupii, czyli ponad 15 mln zł. Czystą skrobię przekształca się w gulal, czyli żółty proszek. Maszyny w indyjskiej fabryce pracują 24 godziny na dobę.

## Mike Tyson znów jest multimilionerem. Oto jak tracił i odzyskiwał swoją fortunę
 - [https://businessinsider.com.pl/lifestyle/mike-tyson-znow-jest-multimilionerem-oto-jak-tracil-i-odzyskiwal-swoja-fortune/5z0bsdc](https://businessinsider.com.pl/lifestyle/mike-tyson-znow-jest-multimilionerem-oto-jak-tracil-i-odzyskiwal-swoja-fortune/5z0bsdc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 07:43:00+00:00

Mike Tyson w swoim życiu dorobił się ogromnego majątku, który potem stracił. Według "Forbesa" kariera bokserska przyniosła mu 400 mln dolarów. Pięściarz roztrwonił wszystko i ogłosił bankructwo. Stopniowo odbudowywał jednak majątek i dziś ponownie jest na szczycie.

## Zatkane parkingi, kolejki do kas. Szykuje się oblężenie sklepów [BADANIE]
 - [https://businessinsider.com.pl/twoje-pieniadze/zakupy-na-swieta-na-ostatnia-chwile-sklepy-czeka-prawdziwe-oblezenie-badanie/rfhrh84](https://businessinsider.com.pl/twoje-pieniadze/zakupy-na-swieta-na-ostatnia-chwile-sklepy-czeka-prawdziwe-oblezenie-badanie/rfhrh84)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 07:09:17+00:00

Wciąż zdecydowana większość rodaków nabywa produkty spożywcze wyłącznie w ramach wizyt w sklepach stacjonarnych – 71 proc., a wiele osób świąteczne zakupy zostawiło sobie na ostatni tydzień lub też wręcz ostatnie chwile przed Wigilią. To oznacza spore kolejki do kas — ostrzegają twórcy badania z UCE Research i Grupy BLIX.

## 40 mld zł wsparcia od Polaków dla Ukrainy
 - [https://businessinsider.com.pl/finanse/40-mld-zl-wsparcia-od-polakow-dla-ukrainy/271ckg1](https://businessinsider.com.pl/finanse/40-mld-zl-wsparcia-od-polakow-dla-ukrainy/271ckg1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 06:47:26+00:00

Wedle ostrożnych szacunków polskie wsparcie dla Ukraińców i Ukrainy może mieć wartość nawet 40 mld zł. 15,9 mld zł z tego to pomoc publiczna – pisze poniedziałkowa "Rzeczpospolita".

## Skoki w cieniu mistrzostw świata. Tymczasem Kubacki na szczycie listy płac
 - [https://businessinsider.com.pl/wiadomosci/ile-zarobil-dawid-kubacki-polak-liderem-listy-plac-w-tym-sezonie/efkw7h4](https://businessinsider.com.pl/wiadomosci/ile-zarobil-dawid-kubacki-polak-liderem-listy-plac-w-tym-sezonie/efkw7h4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 06:36:01+00:00

Początek tegorocznego sezonu Pucharu Świata w skokach narciarskich przyćmiły nieco mistrzostwa świata w piłce nożnej. Na skoczniach świetnie radzi sobie jednak Dawid Kubacki, co nie pozostało bez wpływu na stan jego konta.

## Coraz więcej firm staje się bankrutami
 - [https://businessinsider.com.pl/finanse/coraz-wiecej-firm-staje-sie-bankrutami/m2rdl20](https://businessinsider.com.pl/finanse/coraz-wiecej-firm-staje-sie-bankrutami/m2rdl20)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 06:21:36+00:00

Rośnie liczba firm, która ogłasza bankructwo. W trzecim kwartale tego roku niewypłacalność ogłosiło 26-proc. przedsiębiorstw więcej niż w kwartale poprzednim. 31,5 proc. bankrutów nie płaciło kontrahentom na 2 lata przed ogłoszeniem niewypłacalności — wynika z danych Krajowego Rejestru Długów.

## Wielkie inwestycje w armię i nieoczekiwane ćwiczenia. Białoruś niepokoi Ukrainę
 - [https://businessinsider.com.pl/wiadomosci/bialorus-niepokoi-ukraine-wielkie-inwestycje-w-armie-i-nieoczekiwane-cwiczenia/z1k39z1](https://businessinsider.com.pl/wiadomosci/bialorus-niepokoi-ukraine-wielkie-inwestycje-w-armie-i-nieoczekiwane-cwiczenia/z1k39z1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 06:16:57+00:00

Reżim Aleksandra Łukaszenki do tej pory wspierał Rosję po ataku na Ukrainę głównie werbalnie. Nie oznacza to, że nie ma militarnego zagrożenia z tej strony. Jak pisze wnp.pl, wydatki Białorusi na armię rosną skokowo, a nieplanowane wcześniej ćwiczenia wojskowe wprowadzają dodatkowy niepokój.

## Słuchanie dobrej muzyki powoduje, że masz gęsią skórkę? To oznacza, że masz wyjątkowy mózg
 - [https://businessinsider.com.pl/rozwoj-osobisty/jak-mozg-i-cialo-reaguja-na-muzyke/qn3vhhc](https://businessinsider.com.pl/rozwoj-osobisty/jak-mozg-i-cialo-reaguja-na-muzyke/qn3vhhc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 06:00:00+00:00

Osoby, które są bardzo wrażliwe na muzykę, mają inną strukturę mózgu. Potrafią silniej odczuwać, a muzyka łączy się w ich umyśle z bardzo konkretnymi emocjami. Co więcej, mają szansę wyleczyć się z depresji, dzięki pięknym dźwiękom.

## Rząd chce dopłacać do kredytów mieszkaniowych
 - [https://businessinsider.com.pl/gospodarka/piec-najciekawszych-wydarzen-w-gospodarce-teraz-19122022/myl37bc](https://businessinsider.com.pl/gospodarka/piec-najciekawszych-wydarzen-w-gospodarce-teraz-19122022/myl37bc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 05:56:17+00:00

Nadchodzą tanie kredyty mieszkaniowe, które załatwi nam rząd. Nowy program wsparcia ma ruszyć od lipca, nie poprawi on jednak zdolności kredytowej tych wszystkich, których dziś nie stać na żaden kredyt. Same mieszkania zaś mogą trochę tanieć, tak przynajmniej uważają ekonomiści z PKO BP. Do tego wciąż rośnie nam inflacja bazowa, URE podał nowe, znacznie wyższe od poprzednich taryfy na prąd i gaz, a ceny paliw na stacjach znów zaczynają rosnąć. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Sklepy na Węgrzech wprowadzają limity. "Litr mleka, kilogram ziemniaków"
 - [https://businessinsider.com.pl/finanse/handel/sklepy-na-wegrzech-wprowadzaja-limity-litr-mleka-kilogram-ziemniakow/b4qlgb2](https://businessinsider.com.pl/finanse/handel/sklepy-na-wegrzech-wprowadzaja-limity-litr-mleka-kilogram-ziemniakow/b4qlgb2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 05:54:15+00:00

Sklepy na Węgrzech wprowadzają limity na sprzedaż produktów z rządowej listy. To efekt przedłużenia limitów na produkty spożywcze przez rząd.

## Kiedy wybitni liderzy zajmują się dziećmi i domem? Oto ich porady na temat równowagi między pracą i życiem prywatnym
 - [https://businessinsider.com.pl/rozwoj-osobisty/rownowaga/work-life-balance-rady-od-prezesow-i-milionerow/b7nmq66](https://businessinsider.com.pl/rozwoj-osobisty/rownowaga/work-life-balance-rady-od-prezesow-i-milionerow/b7nmq66)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 05:49:00+00:00

Work-life balance, czyli po prostu równowaga między pracą i życiem prywatnym, to kwestia omawiana od lat — przez managerów, coachów, psychologów. Po artykule o tym, jak swoje poranki spędzają najlepsi wybitni liderzy z całego świata, zapytaliście: a kiedy mają czas na żonę, dzieci i pranie skarpetek? Odpowiedź nie jest prosta, a czasem brutalna dla osób chcących odnosić sukcesy.

## Ostatnie dni, by zaoszczędzić nawet 3 tys. zł. Banalnie prosty, ale mało popularny sposób
 - [https://businessinsider.com.pl/twoje-pieniadze/emerytury/ostatnie-dni-by-zaoszczedzic-nawet-3-tys-zl-tak-dziala-ikze/5wer0j6](https://businessinsider.com.pl/twoje-pieniadze/emerytury/ostatnie-dni-by-zaoszczedzic-nawet-3-tys-zl-tak-dziala-ikze/5wer0j6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 05:30:31+00:00

Zostały niespełna dwa tygodnie na podjęcie decyzji, która pozwala zaoszczędzić nawet 3 tys. zł w rozliczeniu podatkowym. Wystarczy odłożyć pieniądze na emeryturę, by pomniejszyć kwotę podatku lub za kilka miesięcy otrzymać od państwa zwrot.

## ZUS ujawnia, kto pracuje na śmieciówkach
 - [https://businessinsider.com.pl/twoje-pieniadze/praca/zus-ujawnia-kto-pracuje-na-smieciowkach/395p4q6](https://businessinsider.com.pl/twoje-pieniadze/praca/zus-ujawnia-kto-pracuje-na-smieciowkach/395p4q6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 05:26:41+00:00

W pierwszych trzech kwartałach 2022 r. zgłoszono około 1,3 mln umów o dzieło, czyli o ok. 6,5 proc. więcej niż w analogicznym okresie poprzedniego roku — wynika z raportu ZUS. Największa grupa wykonawców umów o dzieło to mężczyźni w wieku 30–39 lat.

## Na święta z prezentami jedzie smog. Grudzień to rekord transportowych zanieczyszczeń
 - [https://businessinsider.com.pl/gospodarka/na-swieta-prezenty-i-smog-grudzien-to-rekord-zanieczyszczen-z-logistyki/r56v8sm](https://businessinsider.com.pl/gospodarka/na-swieta-prezenty-i-smog-grudzien-to-rekord-zanieczyszczen-z-logistyki/r56v8sm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 05:20:00+00:00

Dla logistyki i dostawców grudzień to najgorętszy okres roku. A to sprawia, że świąteczne prezenty powodują ogromny wzrost emisji dwutlenku węgla i zanieczyszczeń. Jak szacuje organizacja Transport&amp;Environment, ciężarówki przewożące prezenty dla Europejczyków wyemitują w grudniu dodatkowe 10,3 tys. ton tlenków azotu. To o 133 proc. więcej niż w ciągu normalnego miesiąca.

## Alkohol rządzi na stacjach benzynowych. Znamy twarde dane [TYLKO U NAS]
 - [https://businessinsider.com.pl/finanse/sprzedaz-alkoholu-na-stacjach-paliw-bije-rekordy-inne-produkty-daleko-w-tyle/cz3g4cj](https://businessinsider.com.pl/finanse/sprzedaz-alkoholu-na-stacjach-paliw-bije-rekordy-inne-produkty-daleko-w-tyle/cz3g4cj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 05:10:00+00:00

Z danych Nielsen IQ wynika, że napoje alkoholowe stanowią 55,7 proc. sprzedaży pozapaliwowej na polskich stacjach benzynowych. W ostatnim czasie rósł wolumen sprzedaży wina i whisky.

## Rafineria Gdańska pod specjalną ochroną. Od stycznia trafi na rządową listę spółek [TYLKO U NAS]
 - [https://businessinsider.com.pl/wiadomosci/rafineria-gdanska-trafi-na-specjalna-liste-to-minister-zdecyduje-komu-bedzie-mozna-ja/x52fjqb](https://businessinsider.com.pl/wiadomosci/rafineria-gdanska-trafi-na-specjalna-liste-to-minister-zdecyduje-komu-bedzie-mozna-ja/x52fjqb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2022-12-19 05:00:00+00:00

Wkrótce do udziałowców Rafinerii Gdańskiej dołączy za pośrednictwem spółki zależnej globalny gigant Saudi Aramco. Rząd chce mieć jednak pewność, że część dawnego biznesu Lotosu nie trafi w niepowołane ręce, gdyby rozeszły się drogi arabskiego inwestora i PKN Orlen. Z ustaleń Business Insider Polska wynika, że od 1 stycznia przyszłego roku Rafineria Gdańska znajdzie się na specjalnej liście podmiotów podlegających ochronie. To oznacza, że ewentualna decyzja o sprzedaży przez Saudyjczyków będzie wymagała zielonego światła od ministra aktywów państwowych.


# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Apple pisses off law enforcement with end to end encryption GOOD!
 - [https://www.youtube.com/watch?v=R2ZuL-NpsOg](https://www.youtube.com/watch?v=R2ZuL-NpsOg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-12-09 00:00:00+00:00

👉 Rossmann chat - send Louis a letter: https://tinyurl.com/writetolouis
👉 Article: https://www.macrumors.com/2022/12/08/fbi-privacy-groups-icloud-encryption/

👉 Previous video: https://youtu.be/CE0EB5bXj14

👉 Equipment used:
🔵 Chair: https://amzn.to/3MjLrnT
🔵 Microphone: https://amzn.to/3g1hsok
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av (YOU CAN FIND THIS FOR $250 ON EBAY WITH A BROKEN FLASH FROM TIME TO TIME, I HAVE NEVER SPENT MORE THAN $300 ON THIS CAMERA!)
🔵 Lighting: https://amzn.to/3RSriGC

👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ


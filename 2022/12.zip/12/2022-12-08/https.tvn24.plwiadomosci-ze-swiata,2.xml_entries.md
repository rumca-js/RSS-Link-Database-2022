# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Nowa praca Kurskiego. Glapiński: mógłby zajmować o wiele wyższe stanowiska
 - [https://tvn24.pl/biznes/z-kraju/jacek-kurski-w-banku-swiatowym-adam-glapinski-komentuje-6420282?source=rss](https://tvn24.pl/biznes/z-kraju/jacek-kurski-w-banku-swiatowym-adam-glapinski-komentuje-6420282?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-12-08 15:18:38+00:00

<img alt="Nowa praca Kurskiego. Glapiński: mógłby zajmować o wiele wyższe stanowiska" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1wulgo-pap202111051m8-6420285/alternates/LANDSCAPE_1280" />
    Jacek Kurski spełnia z ogromną nadwyżką wszelkie wymagania wobec osób reprezentujących Polskę, polski świat finansów w międzynarodowych instytucjach. Mógłby zajmować o wiele wyższe stanowiska. Spełnia wszystkie kryteria - powiedział podczas czwartkowej konferencji prasowej prezes Narodowego Banku Polskiego Adam Glapiński. Dodał, że "Kurski zna się na finansach i ekonomii".

## Rząd tworzy specjalny rejestr dotyczący numeru PESEL. Ma chronić przed oszustami
 - [https://tvn24.pl/biznes/z-kraju/rejestr-numerow-pesel-zastrzezenie-numeru-pesel-i-ochrona-danych-6417849?source=rss](https://tvn24.pl/biznes/z-kraju/rejestr-numerow-pesel-zastrzezenie-numeru-pesel-i-ochrona-danych-6417849?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-12-08 08:45:54+00:00

<img alt="Rząd tworzy specjalny rejestr dotyczący numeru PESEL. Ma chronić przed oszustami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-avm4tg-dowod-osobisty-5479600/alternates/LANDSCAPE_1280" />
    Rząd utworzy specjalny rejestr, w którym po wycieku lub kradzieży danych będzie można zastrzec swój numer PESEL - informuje "Dziennik Gazeta Prawna". Po takim zastrzeżeniu nikt już nie weźmie na niego kredytu czy pożyczki - informuje w czwartek "Dziennik Gazeta Prawna".


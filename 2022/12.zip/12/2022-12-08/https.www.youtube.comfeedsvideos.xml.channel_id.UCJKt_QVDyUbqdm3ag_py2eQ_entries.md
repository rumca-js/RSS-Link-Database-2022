# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: rawArgon times four (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=fl4F98wFH28](https://www.youtube.com/watch?v=fl4F98wFH28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-12-08 00:00:00+00:00

A collection of 4 tracks from rawArgon.
Art "Ambush" by Koyot1222, 3rd at Decrunch 2015.

00:00 Shrine of the Carboxylated Cetaceans
03:10 Blueberry Plasma Smoothie
05:58 Silver Salmon-Snake's Stellar Lawnmower
08:19 Remote Control Ninja Battery Failure

More track info:

Shrine of the Carboxylated Cetaceans, 3rd at Assembly Winter 2021
Blueberry Plasma Smoothie, 4th at Assembly 2022
Silver Salmon-Snake's Stellar Lawnmower, 6th at Assembly Online 2020
Remote Control Ninja Battery Failure, 3rd at Assembly Winter 2020

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click disabled
- Module channel counts: 14 for ...Cetaceans, the rest are 8 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.


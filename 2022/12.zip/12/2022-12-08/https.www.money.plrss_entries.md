# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Przełomowa decyzja polskiego banku. Czy dobra dla kredytobiorców?
 - [https://www.money.pl/banki/kredyt-mieszkaniowy-tylko-staloprocentowy-czy-to-dobre-dla-kredytobiorcow-dwie-strony-medalu-6842378122668608a.html](https://www.money.pl/banki/kredyt-mieszkaniowy-tylko-staloprocentowy-czy-to-dobre-dla-kredytobiorcow-dwie-strony-medalu-6842378122668608a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 22:37:34+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/489fdf63-8172-491b-999d-22dc8e0b0b4d" width="308" /> ING Bank Śląski zawiesił udzielanie kredytów zmiennoprocentowych i zamierza udzielać tylko kredytów z oprocentowaniem okresowo stałym do czasu wdrożenia stawki WIRON. To pierwszy polski bank, który zdecydował się na taki krok. Czy to dobre rozwiązanie? – Są dwie strony medalu – podkreśla w komentarzu dla money.pl Anna Serafin, ekspertka porównywarki finansowej Totalmoney.pl.

## Emerytury stażowe. Kaczyński: teraz nas na to nie stać
 - [https://www.money.pl/emerytury/emerytury-stazowe-kaczynski-teraz-nas-na-to-nie-stac-6842476959705632a.html](https://www.money.pl/emerytury/emerytury-stazowe-kaczynski-teraz-nas-na-to-nie-stac-6842476959705632a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 19:11:36+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/26c12870-fad9-43e5-bf21-17dc817e2ede" width="308" /> Prezes Prawa i Sprawiedliwości został zapytany przez mieszkańca Chojnic o emerytury stażowe. Jarosław Kaczyński odniósł się do pytania wprost i powiedział, że kiedy ten postulat został sformułowany, były zupełnie inne okoliczności. Obecnie – nie ma na to szans.

## Jarosław Kaczyński: "Nie mam nic przeciwko temu, że w Polsce są miliarderzy". Wskazuje na inny problem
 - [https://www.money.pl/gospodarka/jaroslaw-kaczynski-na-spotkaniu-z-mieszkancami-nie-mam-nic-przeciwko-temu-ze-w-polsce-sa-miliarderzy-6842449772288544a.html](https://www.money.pl/gospodarka/jaroslaw-kaczynski-na-spotkaniu-z-mieszkancami-nie-mam-nic-przeciwko-temu-ze-w-polsce-sa-miliarderzy-6842449772288544a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 18:02:29+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ec0dad8b-2c71-4e60-9d05-6ad81fb503bd" width="308" /> Jarosław Kaczyński odbył spotkanie z mieszkańcami Chojnic. Podczas wystąpienia szef Prawa i Sprawiedliwości powiedział, że jeśli ma się pieniądze, to są one dzięki dobrze funkcjonującej gospodarce. - Dobrze funkcjonująca gospodarka to taka, która premiuje przedsiębiorców, którzy działają sprawnie, są w stanie wpisać się w reguły rynkowe w sposób właściwy - przekazał prezes PiS.

## Wielka Brytania otwiera kopalnię węgla. Pierwsza taka decyzja od 35 lat
 - [https://www.money.pl/gospodarka/wielka-brytania-otwiera-kopalnie-wegla-pierwsza-taka-decyzja-od-35-lat-6842393096026656a.html](https://www.money.pl/gospodarka/wielka-brytania-otwiera-kopalnie-wegla-pierwsza-taka-decyzja-od-35-lat-6842393096026656a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 13:28:43+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f285cfe6-ea57-47fd-8898-21e49c58ed50" width="308" /> Długo trwała debata w Wielkiej Brytanii nad sensem budowy nowej kopalni węgla, ale ostatecznie klamka zapadła. Brytyjski rząd w środę wydał zgodę na budowę pierwszej od 35 lat głębinowej kopalni węgla. Inwestycja budzi duże kontrowersje, gdyż rok temu Wielka Brytania – jako gospodarz szczytu klimatycznego COP26 – wzywała inne kraje, by "odesłać węgiel do historii".

## U naszego sąsiada brakuje niektórych leków. Czesi jeżdżą po nie do Polski
 - [https://www.money.pl/gospodarka/u-naszego-sasiada-brakuje-niektorych-lekow-czesi-jezdza-po-nie-do-polski-6842376614849056a.html](https://www.money.pl/gospodarka/u-naszego-sasiada-brakuje-niektorych-lekow-czesi-jezdza-po-nie-do-polski-6842376614849056a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 12:21:40+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4bd2dbb3-5598-499a-bd40-6c06bbeda62a" width="308" /> W Czechach brakuje niektórych leków, w tym przeciwbólowych i podstawowych antybiotyków. Czesi jeżdżą po nie do Polski lub szukają ich w internecie - informuje w czwartek dziennik "Hospodarzske Noviny". Lekarze i farmaceuci twierdzą, że to największe braki niektórych specyfików w historii.

## Węgry odczuwają skutki cen regulowanych. Inflacja rośnie, a będzie gorzej
 - [https://www.money.pl/gospodarka/wegry-odczuwaja-skutki-cen-regulowanych-inflacja-rosnie-a-bedzie-gorzej-6842364764412448a.html](https://www.money.pl/gospodarka/wegry-odczuwaja-skutki-cen-regulowanych-inflacja-rosnie-a-bedzie-gorzej-6842364764412448a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 11:33:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/36b242c8-ef11-41f8-a326-b4441d375efa" width="308" /> Inflacja na Węgrzech się nie zatrzymuje i przekroczyła granicę 22 proc. Mieszkańcy zresztą nie mogą spodziewać się poprawy sytuacji w niedługim czasie. Nawet przedstawiciele rządu przyznają, że wzrost cen jeszcze przyspieszy. Wszystko przez uwolnienie cen paliw, co nastąpiło we wtorek.

## Opinia o stażyście – czym jest i kto powinien ją wydać?
 - [https://www.money.pl/gospodarka/opinia-o-stazyscie-czym-jest-i-kto-powinien-ja-wydac-6842355071158816a.html](https://www.money.pl/gospodarka/opinia-o-stazyscie-czym-jest-i-kto-powinien-ja-wydac-6842355071158816a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 10:54:55+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9a444273-15d3-407c-a3ac-3a1de0d7fc7f" width="308" /> Doświadczenie zawodowe można zdobywać między innymi poprzez odbywanie stażu z urzędu pracy. Bezrobotna osoba kierowana jest do zakładu pracy, aby lepiej zapoznać się ze specyfiką branży i nabrać nowych umiejętności. Po wszystkim stażysta powinien mieć wystawioną opinię. Czym ona jest i kto ją przygotowuje?

## Zmiany w zakresie wycinki drzew. Wchodzą w życie od przyszłego roku
 - [https://www.money.pl/gospodarka/zmiany-w-zakresie-wycinki-drzew-wchodza-w-zycie-od-przyszlego-roku-6842352053365312a.html](https://www.money.pl/gospodarka/zmiany-w-zakresie-wycinki-drzew-wchodza-w-zycie-od-przyszlego-roku-6842352053365312a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 10:41:43+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8a6f7192-5af2-4391-bec5-39a26b95652d" width="308" /> Dobre wieści dla właścicieli nieruchomości. Od 2023 r. łatwiej im będzie wyciąć drzewa na własnej posesji. W życie wejdą bowiem przepisy regulujące prawo zakresie zgłoszeń dokonywanych przez osoby prywatne – podaje "Dziennik Gazeta Prawna".

## NBP pokazuje, jak zarabiają banki. W ciągu miesiąca zysk wzrósł o 4,37 mld zł
 - [https://www.money.pl/banki/nbp-pokazuje-jak-zarabiaja-banki-w-ciagu-miesiaca-zysk-wzrosl-o-4-37-mld-zl-6842350235453984a.html](https://www.money.pl/banki/nbp-pokazuje-jak-zarabiaja-banki-w-ciagu-miesiaca-zysk-wzrosl-o-4-37-mld-zl-6842350235453984a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 10:34:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f8e9152c-c215-481c-92b9-5450921d1202" width="308" /> Zysk banków po dziesięciu miesiącach 2022 r. wyniósł 9,8 mld zł - wynika z danych opublikowanych w czwartek przez NBP. Zysk banków tylko od września do października wzrósł o 4,37 mld zł.

## Nadchodzi koniec pieców gazowych. Czym ogrzejemy dom?
 - [https://www.money.pl/gospodarka/nadchodzi-koniec-piecow-gazowych-czym-ogrzejemy-dom-6842340177381920a.html](https://www.money.pl/gospodarka/nadchodzi-koniec-piecow-gazowych-czym-ogrzejemy-dom-6842340177381920a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 09:53:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/962c1940-fd91-465f-a2df-b18b29459a26" width="308" /> Komisja Europejska pracuje nad rozwiązaniami, które wprowadzą zakaz montowania w nowych budynkach nie tylko pieców węglowych czy olejowych, ale także gazowych. Według wstępnych planów montaż kotłów gazowych ma zostać zakazany od 2027 roku w nowych budynkach, a od 2030 w tych modernizowanych. Co ważne, piece, które zostały zainstalowane wcześniej, będą mogły dalej funkcjonować.

## Elon Musk przez chwilę nie był najbogatszym człowiekiem na świecie. Przez spadek kursu Tesli
 - [https://www.money.pl/gielda/elon-musk-przez-chwile-nie-byl-najbogatszym-czlowiekiem-na-swiecie-przez-spadek-kursu-tesli-6842330922252864a.html](https://www.money.pl/gielda/elon-musk-przez-chwile-nie-byl-najbogatszym-czlowiekiem-na-swiecie-przez-spadek-kursu-tesli-6842330922252864a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 09:15:45+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fd473675-4fa7-4b68-9caa-0f763946abd7" width="308" /> Elon Musk w środę na krótki czas stracił pierwszeństwo w rankingu najbogatszych ludzi na świecie. To efekt gwałtownego spadku wartości jego akcji w Tesli. Właścicielowi Twittera wciąż też czkawką odbija się przejęcie portalu. Wyprzedził go Bernard Arnault, kojarzony z branżą tekstylną.

## Rosną podatki za nieruchomości. Tyle zapłacisz w 2023 roku
 - [https://www.money.pl/podatki/rosna-podatki-za-nieruchomosci-tyle-zaplacisz-w-2023-roku-6842319804930624a.html](https://www.money.pl/podatki/rosna-podatki-za-nieruchomosci-tyle-zaplacisz-w-2023-roku-6842319804930624a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 08:30:30+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ae982db0-b44f-4eca-877f-639ab8cc76ec" width="308" /> We wszystkich miastach wojewódzkich podjęto już decyzje o podniesieniu podatków od nieruchomości. Stawki poszły w górę przeciętnie o 12 proc. Gminy podejmują swoje decyzje w oparciu o maksymalne dozwolone prawem stawki podatków od nieruchomości. Te zmieniają się w Polsce co roku.

## Apple utrzymuje plastron lidera sprzedaży w Rosji i to mimo wyłączenia serwisu
 - [https://www.money.pl/gospodarka/apple-utrzymuje-plastron-lidera-sprzedazy-w-rosji-i-to-mimo-wylaczenia-serwisu-6842317737724480a.html](https://www.money.pl/gospodarka/apple-utrzymuje-plastron-lidera-sprzedazy-w-rosji-i-to-mimo-wylaczenia-serwisu-6842317737724480a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 08:22:04+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cddf7fe6-ca3f-4903-9fee-f2d32ec83557" width="308" /> W 2022 r. kurczy się segment smartfonów w Rosji. Obywatele kupują coraz mniej zarówno tych droższych, jak i tych najtańszych telefonów. Mimo takiej atmosfery liderem sprzedaży pozostaje Apple. Gigant z Cupertino utrzymał pierwszą pozycję pomimo wyłączenia niektórych funkcji i braku oficjalnego serwisu.

## Zaskakujący efekt sankcji. "Okazyjnie niska cena" samochodów
 - [https://www.money.pl/gospodarka/zaskakujacy-efekt-sankcji-okazyjnie-niska-cena-samochodow-6842312378669632a.html](https://www.money.pl/gospodarka/zaskakujacy-efekt-sankcji-okazyjnie-niska-cena-samochodow-6842312378669632a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 08:00:17+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1e2caa4-62d4-43d6-8b94-5e15d9eed943" width="308" /> Przez sankcje nałożone na Rosję w tym roku częściej sprzedawano i kupowano na aukcjach samochody używane. Zainteresowanie wzrosło wobec braku nowych ofert. Sprzedaż nowych aut spada w Rosji - informuje dziennik "Kommiersant".

## Małe firmy rodzinne odczuwają obecną sytuację. Mogą nie przetrwać kryzysu energetycznego
 - [https://www.money.pl/gospodarka/male-firmy-rodzinne-odczuwaja-obecna-sytuacje-moga-nie-przetrwac-kryzysu-energetycznego-6842301572102688a.html](https://www.money.pl/gospodarka/male-firmy-rodzinne-odczuwaja-obecna-sytuacje-moga-nie-przetrwac-kryzysu-energetycznego-6842301572102688a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 07:16:13+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cb9615ca-b428-47bc-b373-8c2bd9722036" width="308" /> Co trzecia polska firma rodzinna odnotowała pogorszenie swojej sytuacji w ostatnim roku. Najbardziej doskwierają im wysokie koszty paliw, energii, pracy – donosi w czwartek "Puls Biznesu".

## Na Kremlu spokój. Sankcje na ropę nie uderzają w budżet Rosji w znaczący sposób
 - [https://www.money.pl/gospodarka/na-kremlu-spokoj-sankcje-na-rope-nie-uderzaja-w-budzet-rosji-w-sposob-znaczacy-6842293399517760a.html](https://www.money.pl/gospodarka/na-kremlu-spokoj-sankcje-na-rope-nie-uderzaja-w-budzet-rosji-w-sposob-znaczacy-6842293399517760a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 06:43:02+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/547d0186-2b6d-4284-b19b-d617a1ae2dde" width="308" /> Limit cenowy na ropę z Rosji nie uderzy w wartość rubla. Wszystko przez fakt, że ustalona cena maksymalna jest zbliżona do ceny rynkowej. Zachód jednak dąży do tego, by Moskwa nie ograniczyła produkcji surowca – pisze Bloomberg.

## Kursy walut 08.12.2022. Czwartkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-08-12-2022-czwartkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6842285607848480a.html](https://www.money.pl/pieniadze/kursy-walut-08-12-2022-czwartkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6842285607848480a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 06:11:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 08.12.2022. W czwartek za jednego dolara (USD) zapłacimy 4.4710 zł. Cena jednego funta szterlinga (GBP) to 5.4491 zł, a franka szwajcarskiego (CHF) 4.7483 zł. Z kolei euro (EUR) możemy zakupić za 4.6971 zł.

## Rząd szykuje kolejną rewolucję samorządom. Chodzi o ich pieniądze
 - [https://www.money.pl/podatki/rzad-szykuje-kolejna-rewolucje-samorzadom-chodzi-o-ich-pieniadze-6842285230053952a.html](https://www.money.pl/podatki/rzad-szykuje-kolejna-rewolucje-samorzadom-chodzi-o-ich-pieniadze-6842285230053952a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 06:09:49+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/725b0200-b670-4762-8bd9-32f8a30f1212" width="308" /> Różne udziały w PIT i CIT dla różnych samorządów, dobrowolne odpisy podatników PIT na rzecz gmin, ograniczenie wpłat janosikowego – to, jak informuje w czwartek "Dziennik Gazeta Prawna", pomysły resortu finansów na reformę lokalnych budżetów.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 08.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-08-12-2022-6842284124080672a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-08-12-2022-6842284124080672a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 06:05:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 08.12.2022. W czwartek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.4472 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 08.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-08-12-2022-6842284121029152a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-08-12-2022-6842284121029152a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 06:05:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 08.12.2022. W czwartek za jedno euro (EUR) trzeba zapłacić 4.695 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 08.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-08-12-2022-6842284121446944a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-08-12-2022-6842284121446944a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 06:05:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 08.12.2022. W czwartek za jednego franka (CHF) trzeba zapłacić 4.7455 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 08.12.2022
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-08-12-2022-6842284114958880a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-08-12-2022-6842284114958880a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 06:05:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 08.12.2022. W czwartek za jednego dolara (USD) trzeba zapłacić 4.4685 zł.

## Rosyjska ambasada odgraża się USA. "Sankcje nie zmuszą nas do porzucenia kursu"
 - [https://www.money.pl/gospodarka/rosyjska-ambasada-odgraza-sie-usa-sankcje-nie-zmusza-nas-do-porzucenia-kursu-6842283316910624a.html](https://www.money.pl/gospodarka/rosyjska-ambasada-odgraza-sie-usa-sankcje-nie-zmusza-nas-do-porzucenia-kursu-6842283316910624a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 06:01:59+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b291d052-4f1a-44a0-b692-807b8e49da7c" width="308" /> "Amerykańskie sankcje nie zmuszą Rosji do porzucenia kursu" – przekonuje ambasada Federacji Rosyjskiej w Waszyngtonie. W jej ocenie kolejne restrykcje nakładane na rosyjskie podmioty bardziej uderzają w ich zachodnich partnerów.

## Polska wciąż bez miliardów z UE. Wiadomo skąd rząd weźmie pieniądze
 - [https://www.money.pl/gospodarka/polska-wciaz-bez-miliardow-z-ue-wiadomo-skad-rzad-wezmie-pieniadze-6842281630689824a.html](https://www.money.pl/gospodarka/polska-wciaz-bez-miliardow-z-ue-wiadomo-skad-rzad-wezmie-pieniadze-6842281630689824a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 05:55:11+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e85b5364-fddd-4215-8fd4-5c356a5acb87" width="308" /> W grudniu popłyną pierwsze 2-3 mld zł z Polskiego Funduszu Rozwoju na realizację inwestycji z Krajowego Planu Odbudowy - powiedział PAP prezes PFR Paweł Borys. W przyszłym roku ta kwota może wynosić już 15-20 mld zł.

## Niższy VAT na gaz. Rząd z niego rezygnuje, ale UE wcale go nie zabrania
 - [https://www.money.pl/gospodarka/nizszy-vat-na-gaz-rzad-z-niego-rezygnuje-ale-ue-wcale-go-nie-zabrania-6842277421156928a.html](https://www.money.pl/gospodarka/nizszy-vat-na-gaz-rzad-z-niego-rezygnuje-ale-ue-wcale-go-nie-zabrania-6842277421156928a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2022-12-08 05:38:03+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b93f6830-d651-4e33-a8fb-3771d4436949" width="308" /> Na początku 2023 roku wróci 23-procentowy VAT dodany do gazu. Rząd utrzymuje, że to wymóg Brukseli. Ale Unia wcale nie blokuje Polsce możliwości obniżania VAT na gaz - informuje dziennik "Rzeczpospolita".


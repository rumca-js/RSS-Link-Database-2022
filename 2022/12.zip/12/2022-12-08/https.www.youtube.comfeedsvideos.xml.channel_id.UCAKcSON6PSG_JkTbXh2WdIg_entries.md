# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Alex G – Mission (live for The Current)
 - [https://www.youtube.com/watch?v=PCbp9mgCabY](https://www.youtube.com/watch?v=PCbp9mgCabY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-12-09 00:00:00+00:00

Philadelphia musician Alex Giannascoli — better known as Alex G — released his latest album, "God Save The Animals," on September 23, 2022. While in the Twin Cities for a show at First Avenue in Minneapolis, Alex G and his band — guitarist Sam Acchione, drummer Tom Kelly and bassist John Heywood — visited The Current studio for a session hosted by Ayisha Jaffer. Watch Alex G's performance of "Mission," recorded during that session.

You can watch the complete session here: https://www.youtube.com/watch?v=9mDxMxRAFzA

Band members
Alex G - vocals, piano, guitar
Sam Acchione - guitar
Tom Kelly - drums
John Heywood - bass

Credits
Guest - Alex G
Host - Ayisha Jaffer
Producer - Derrick Stevens
Camera Operators - Evan Clark, Thor Cramer Bornemann
Video - Evan Clark
Audio - Eric Xu Romani
Graphics - Natalia Toledo
Digital Producer - Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

#alexg @SandyAlexG #alexgiannascoli


## BlackRock says get ready for a recession unlike any other and 'what worked in the past won't work now'
 - [https://markets.businessinsider.com/news/stocks/blackrock-recession-warning-stock-market-analysis-2023-economic-outlook-2022-12](https://markets.businessinsider.com/news/stocks/blackrock-recession-warning-stock-market-analysis-2023-economic-outlook-2022-12)
 - RSS feed: https://markets.businessinsider.com
 - date published: 2022-12-08 07:45:25+00:00

BlackRock says get ready for a recession unlike any other and 'what worked in the past won't work now'


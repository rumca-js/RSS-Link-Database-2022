# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## WATCH:  Why is the jobs boom bad for inflation?
 - [https://abcnews.go.com/Business/video/jobs-boom-bad-inflation-94802217](https://abcnews.go.com/Business/video/jobs-boom-bad-inflation-94802217)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2022-12-08 22:07:18+00:00

Experts say a tight job market triggers more inflation.

## WATCH:  Hundreds of Santas race in German town for annual fun run
 - [https://abcnews.go.com/International/video/hundreds-santas-race-german-town-annual-fun-run-94778023](https://abcnews.go.com/International/video/hundreds-santas-race-german-town-annual-fun-run-94778023)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2022-12-08 16:17:24+00:00

Hundreds of Santas dressed in full gear for an annual fun run in Michendorf, Germany—and earned a mug of traditional mulled wine at the end.

## WATCH:  Baby elephant celebrates her 1st Christmas at England zoo
 - [https://abcnews.go.com/International/video/baby-elephant-celebrates-1st-christmas-england-zoo-94777983](https://abcnews.go.com/International/video/baby-elephant-celebrates-1st-christmas-england-zoo-94777983)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2022-12-08 16:17:05+00:00

A baby elephant at an English zoo had a whole winter wonderland to explore for her first Christmas.

## WATCH:  What you need to know about the polar vortex
 - [https://abcnews.go.com/US/video/polar-vortex-94704835](https://abcnews.go.com/US/video/polar-vortex-94704835)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2022-12-08 14:32:39+00:00

The polar vortex is a low pressure in the upper atmosphere located in the Arctic near the North and South Pole.

## LIVE:  ABC News Live
 - [https://abcnews.go.com/Live/video/abcnews-live-41463246](https://abcnews.go.com/Live/video/abcnews-live-41463246)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2022-12-08 14:15:29+00:00

24/7 coverage of breaking news and live events

## WATCH:  Herd of elk stops drivers in their tracks
 - [https://abcnews.go.com/US/video/herd-elk-stops-drivers-tracks-94733219](https://abcnews.go.com/US/video/herd-elk-stops-drivers-tracks-94733219)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2022-12-08 02:31:34+00:00

A large herd of elk rushed across a roadway and drivers in Colorado had no choice but to wait for them to cross.

## WATCH:  Rainbow appears during Pearl Harbor remembrance ceremony
 - [https://abcnews.go.com/US/video/rainbow-appears-pearl-harbor-remembrance-ceremony-94733220](https://abcnews.go.com/US/video/rainbow-appears-pearl-harbor-remembrance-ceremony-94733220)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2022-12-08 02:00:51+00:00

A handful of centenarian survivors gathered in Hawaii to commemorate those killed 81 years ago in the attack on Pearl Harbor.


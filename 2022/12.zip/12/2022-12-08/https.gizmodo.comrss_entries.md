# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## How to Uncurse Your Dice Before Game Night
 - [https://gizmodo.com/dungeons-dragons-dnd-dice-how-to-uncurse-roll-20-1849871968](https://gizmodo.com/dungeons-dragons-dnd-dice-how-to-uncurse-roll-20-1849871968)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-09 00:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--sMhe_weH--/c_fit,fl_progressive,q_80,w_636/82a11178cb8b6519d8625f4d20ad4acd.png" /><p>Earlier this week, while preparing for a <a href="https://gizmodo.com/accessible-ttrpgs-elle-dwight-role-recommendations-1849802734">tabletop role playing game</a>, I was perusing my dice, trying to pick out a set of polyhedral dice (which consist of seven dice: a D4, <a href="https://gizmodo.com/medieval-cheater-s-dice-with-two-fours-and-fives-found-1825171270">D6</a>, D8, two D10s, D12, and a <a href="https://gizmodo.com/real-ancient-d20s-greece-egypt-rpgs-gallery-1848779772">D20</a>) that would best fit my Dragonborn Monk, <a href="https://gizmodo.com/dungeons-and-dragons-dnd-new-trailer-honor-thieves-1849853453">Teimuraz</a>. I found a set still in its packaging—my red-and-silver <a href="https://dispeldice.com/products/crimson-nebula-7-piece-polyhedral-dice-set" rel="noopener noreferrer" target="_blank">Crimson…</a></p><p><a href="https://gizmodo.com/dungeons-dragons-dnd-dice-how-to-uncurse-roll-20-1849871968">Read more...</a></p>

## James Cameron Reveals His True Feelings About Thanos
 - [https://gizmodo.com/james-cameron-avatar-way-of-water-vfx-marvel-thanos-1849872067](https://gizmodo.com/james-cameron-avatar-way-of-water-vfx-marvel-thanos-1849872067)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 22:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--JqlEsHxH--/c_fit,fl_progressive,q_80,w_636/1151a44f8fcf4248d8cfe467378f30a9.jpg" /><p>Unlike certain other high-profile directors, <a href="https://gizmodo.com/james-cameron-avatar-2-way-of-water-sam-worthington-1849861153">James Cameron</a> is a professed fan of Marvel and DC movies. But in <a href="https://gizmodo.com/avatar-the-way-of-water-sigourney-weaver-teen-character-1849859936">a new interview</a> for <a href="https://gizmodo.com/avatar-2-release-date-delay-james-cameron-pandora-water-1849854621"><em>Avatar: The Way of Water</em></a>, he weighed in on the VFX used to create Marvel villain <a href="https://gizmodo.com/yes-thanos-is-hot-1825931804">Thanos</a>, versus the VFX that brings his <em>Avatar</em> characters <a href="https://gizmodo.com/avatar-the-way-of-water-reactions-review-james-cameron-1849860929">to life</a>. And you won’t be surprised which he favors.</p><p><a href="https://gizmodo.com/james-cameron-avatar-way-of-water-vfx-marvel-thanos-1849872067">Read more...</a></p>

## The FTC's Effort to Block Microsoft's Activision Acquisition Will Test Biden's Antitrust Legacy
 - [https://gizmodo.com/microsoft-xbox-call-of-duty-activision-blizzard-1849871936](https://gizmodo.com/microsoft-xbox-call-of-duty-activision-blizzard-1849871936)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 22:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--eJAsIFEK--/c_fit,fl_progressive,q_80,w_636/027d5c0bb4a247bfb058b15de0aa088c.jpg" /><p>It’s official. After months of rumors, the Federal Trade Commission this week voted 3-1 in favor of suing to block Microsoft’s estimated <a href="https://gizmodo.com/microsoft-s-buying-activision-blizzard-now-what-1848376819">$69 billion acquisition</a> of video game giant Activision Blizzard. </p><p><a href="https://gizmodo.com/microsoft-xbox-call-of-duty-activision-blizzard-1849871936">Read more...</a></p>

## Los Angeles Votes to Ditch Styrofoam With Citywide Ban
 - [https://gizmodo.com/styrofoam-ban-plastic-bag-ban-garbage-recycle-1849871367](https://gizmodo.com/styrofoam-ban-plastic-bag-ban-garbage-recycle-1849871367)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 22:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--4UATJBvR--/c_fit,fl_progressive,q_80,w_636/cb171ee282c772b2465337ab93ce6fc7.jpg" /><p>Los Angeles officials voted to ban styrofoam and other <a href="https://gizmodo.com/least-recyclable-plastics-1848853267">single-use plastics</a> on Thursday in a move to become a “zero waste” city. The 12 city council members who were present at the meeting voted unanimously in favor of the ban, prohibiting the distribution and sale of expanded polystyrene products, more commonly known…</p><p><a href="https://gizmodo.com/styrofoam-ban-plastic-bag-ban-garbage-recycle-1849871367">Read more...</a></p>

## 10 Horror Movies That Will Make You Rethink Attempting Any Winter Sports
 - [https://gizmodo.com/10-horror-movies-winter-sports-skiing-snowboard-skating-1849855772](https://gizmodo.com/10-horror-movies-winter-sports-skiing-snowboard-skating-1849855772)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 21:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--6XFPeYzJ--/c_fit,fl_progressive,q_80,w_636/f77a8c1b909c79ee0032e73a2573d53e.jpg" /><p><a href="https://gizmodo.com/cool-off-with-these-18-horror-movies-set-in-the-freezin-1796606662">Cold-weather horror</a> is <a href="https://gizmodo.com/5-cult-horror-movies-to-weird-up-the-winter-holidays-1830540722">a much-loved genre</a>, with sub-categories that include <a href="https://gizmodo.com/the-10-most-bone-chillingly-inappropriate-christmas-mov-1674947957">holiday horror</a>, “trapped in this weather with killers and/or ghosts” horror (think <em>The Shining</em>), and even—as this list explores—horror movies that work winter sports into their plots. Exercise can be deadly, so proceed with caution!<br /></p><p><a href="https://gizmodo.com/10-horror-movies-winter-sports-skiing-snowboard-skating-1849855772">Read more...</a></p>

## AITA or Are These the Most Popular Subreddits of 2022?
 - [https://gizmodo.com/reddit-subreddit-aita-1849870959](https://gizmodo.com/reddit-subreddit-aita-1849870959)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 21:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--oAahh5VK--/c_fit,fl_progressive,q_80,w_636/757e5c9961b2b6738b32a3a3b8c43926.png" /><p>On Thursday, Reddit <a href="https://www.redditinc.com/blog/reddit-recap-2022-global" rel="noopener noreferrer" target="_blank">revealed</a> what the biggest trending topics and subreddits were for 2022, and if you guessed that it was a forum for internet haranguing, then you would be correct—but also—you should probably take a break from the internet for a few days. <br /></p><p><a href="https://gizmodo.com/reddit-subreddit-aita-1849870959">Read more...</a></p>

## UN Adopts Resolution Against Anti-Satellite Tests to Prevent More Space Debris
 - [https://gizmodo.com/united-nations-resolution-anti-satellite-tests-debris-1849870524](https://gizmodo.com/united-nations-resolution-anti-satellite-tests-debris-1849870524)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 21:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s---kop75Oh--/c_fit,fl_progressive,q_80,w_636/a8e31dd84ece99927c5c85c0761f0921.jpg" /><p>Yesterday, an overwhelming majority of countries voted in favor of a United Nations resolution against tests of anti-satellite (ASAT) missile systems, with Russia and China voting against its adoption.</p><p><a href="https://gizmodo.com/united-nations-resolution-anti-satellite-tests-debris-1849870524">Read more...</a></p>

## Thank God, Doctor Who's Christmas Specials Will Return Starting Next Year
 - [https://gizmodo.com/doctor-who-christmas-day-special-2023-2024-bbc-1849871287](https://gizmodo.com/doctor-who-christmas-day-special-2023-2024-bbc-1849871287)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--kylIAf25--/c_fit,fl_progressive,q_80,w_636/7a61e41356cc403baa200bc077f91214.png" /><p>When Chris Chibnall took over <a href="https://gizmodo.com/doctor-who-release-dates-streaming-ncuti-gatwa-rtd-1849745140"><em>Doctor Who</em></a>, one of the strangest decisions to come out of his era was a simple programming change: the <a href="https://gizmodo.com/looking-back-on-doctor-whos-bizarre-first-christmas-epi-1830777660"><em>Doctor Who</em> Christmas specials</a>, a tradition since 2005, were <a href="https://gizmodo.com/theres-no-doctor-who-christmas-special-this-year-its-a-1830439545">suddenly no more</a>, replaced by New Year’s Day specials. Now, five years later, we know that the change is being reversed.<br /></p><p><a href="https://gizmodo.com/doctor-who-christmas-day-special-2023-2024-bbc-1849871287">Read more...</a></p>

## Webb Telescope Reveals a Luminous Stellar Crime Scene
 - [https://gizmodo.com/webb-telescope-southern-ring-nebula-stars-1849870153](https://gizmodo.com/webb-telescope-southern-ring-nebula-stars-1849870153)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 20:33:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Q0I8LEor--/c_fit,fl_progressive,q_80,w_636/a268e38dc04f216dc6e7f5f1ba0c211d.png" /><p>2,500 years ago, one of space’s most beautiful features was born: the Southern Ring Nebula. The nebula was vividly imaged by the Webb Space Telescope earlier this year, and astronomers now think they know exactly how a star’s violent outburst occurred, leaving the elegant nebula in its wake.</p><p><a href="https://gizmodo.com/webb-telescope-southern-ring-nebula-stars-1849870153">Read more...</a></p>

## SpaceX One Step Closer to Offering Starlink Through T-Mobile
 - [https://gizmodo.com/spacex-starlink-t-mobile-1849870615](https://gizmodo.com/spacex-starlink-t-mobile-1849870615)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 20:25:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--3J5_x8gE--/c_fit,fl_progressive,q_80,w_636/356b5475ed62f00036255f434ae39fc2.jpg" /><p>SpaceX is moving forward with its <a href="https://gizmodo.com/t-mobile-space-x-satellite-cell-plan-starlink-dead-zone-1849461651">plan</a> to create a new satellite network aimed at ending dead zones for certain T-Mobile customers.</p><p><a href="https://gizmodo.com/spacex-starlink-t-mobile-1849870615">Read more...</a></p>

## Avatar: The Way of Water Heightens Tension by Focusing on Family Dynamics
 - [https://gizmodo.com/avatar-the-way-of-water-james-cameron-family-themes-1849870263](https://gizmodo.com/avatar-the-way-of-water-james-cameron-family-themes-1849870263)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 20:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--iBYQofjE--/c_fit,fl_progressive,q_80,w_636/1a7c586cbbffd6d3d76f7634aa0a6e09.png" /><p>In a press conference this week for <em>Avatar: The Way of Water</em>, <a href="https://gizmodo.com/james-cameron-avatar-2-way-of-water-sam-worthington-1849861153">James Cameron</a> said that after revisiting the first film, he wanted to develop a sequel that would honor <a href="https://gizmodo.com/avatar-2-way-of-water-james-cameron-billion-box-office-1849812098"><em>Avatar</em></a> while pushing the universe forward. One way he did that was by taking <a href="https://gizmodo.com/avatar-the-way-of-water-sigourney-weaver-teen-character-1849859936">inspiration</a> from stars Zoe Saldana and Sam Worthington. The director and…</p><p><a href="https://gizmodo.com/avatar-the-way-of-water-james-cameron-family-themes-1849870263">Read more...</a></p>

## Google Is Combining Its Maps and Waze Teams Amid Cost-Cutting Pressure
 - [https://gizmodo.com/google-maps-waze-alphabet-street-view-earth-1849870637](https://gizmodo.com/google-maps-waze-alphabet-street-view-earth-1849870637)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--wLnZha17--/c_fit,fl_progressive,q_80,w_636/07aca68b255bf0eb0ca7a162b9a21744.jpg" /><p>Google’s parent company, Alphabet Inc., announced it’s doing some <a href="https://gizmodo.com/google-alphabet-layoffs-twitter-meta-big-tech-1849787157">restructuring</a> to merge Google Maps and <a href="https://gizmodo.com/waze-renault-navigation-1849858497">Waze</a> employees <a href="https://gizmodo.com/google-alphabet-layoffs-twitter-meta-big-tech-1849787157">amid pressures to streamline the business and cut costs</a>. The company has said both mapping apps will continue to operate independently.</p><p><a href="https://gizmodo.com/google-maps-waze-alphabet-street-view-earth-1849870637">Read more...</a></p>

## How Genes Drive Your Dog's Lovable and Wacky Behavior
 - [https://gizmodo.com/dog-behavior-genes-dog-genome-project-1849870326](https://gizmodo.com/dog-behavior-genes-dog-genome-project-1849870326)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 19:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--G4_V9Hua--/c_fit,fl_progressive,q_80,w_636/2328226c44e129357a774b66753efda1.jpg" /><p>A new study may help us understand our canine companions a bit better. Scientists at the National Institutes of Health say they’ve uncovered some of the ways that genes can influence the behaviors of certain breeds, such as dogs meant to herd livestock.<br /></p><p><a href="https://gizmodo.com/dog-behavior-genes-dog-genome-project-1849870326">Read more...</a></p>

## Celebrating the Holidays With the Extreme Dinosaurs Is an Extremely Bad Idea
 - [https://gizmodo.com/worst-episode-ever-extreme-dinosaurs-christmas-holiday-1849866869](https://gizmodo.com/worst-episode-ever-extreme-dinosaurs-christmas-holiday-1849866869)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 19:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--BkecRyaB--/c_fit,fl_progressive,q_80,w_636/004c6a68784ff7dcbb65d475890d4f7d.jpg" /><p>If the Golden Age of half-assed kids’ cartoons was the <a href="https://gizmodo.com/worst-episode-ever-turbo-teen-80s-cartoon-video-venger-1849491286">early ‘80s</a>, then I would like to dub the latter <a href="https://gizmodo.com/ancient-mummies-exhumed-forced-to-chaperone-school-fie-1845383460">half of the’90s</a> to be the Silver Age. It was a time when animators would throw syndicated crap into children’s eyes after school to see what stuck, and almost none of it did. Half of these half-assed series were…</p><p><a href="https://gizmodo.com/worst-episode-ever-extreme-dinosaurs-christmas-holiday-1849866869">Read more...</a></p>

## Are ‘Hauls’ a Wasteful Social Media Practice?
 - [https://gizmodo.com/are-hauls-a-wasteful-social-media-practice-1849860584](https://gizmodo.com/are-hauls-a-wasteful-social-media-practice-1849860584)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--uNd4rOXi--/c_fit,fl_progressive,q_80,w_636/6d339ba368efb9fadaf26bf5d7b8b6a4.jpg" /><p><a href="https://gizmodo.com/are-hauls-a-wasteful-social-media-practice-1849860584">Read more...</a></p>

## DeepMind’s AlphaCode Can Outcompete Human Coders
 - [https://gizmodo.com/deepmind-ai-google-alphacode-coding-1849869346](https://gizmodo.com/deepmind-ai-google-alphacode-coding-1849869346)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--BAVrXCbh--/c_fit,fl_progressive,q_80,w_636/5d83c0898ee04bd95d3ba0e03aa05ceb.jpg" /><p>When it comes to tracking the incremental advances of <a href="https://gizmodo.com/how-an-artificial-superintelligence-might-actually-dest-1846968207">AI potential</a>, humans have an odd tendency to think in terms of board games we probably haven’t played since childhood. Though there’s no shortage of examples, even <a href="https://gizmodo.com/meta-ai-cicero-diplomacy-gaming-1849811840">recent</a> <a href="https://gizmodo.com/ai-deep-mind-stratego-1849842361">ones</a>, highlighting AI’s ability to utterly own the cardboard gaming space, those tests only go…</p><p><a href="https://gizmodo.com/deepmind-ai-google-alphacode-coding-1849869346">Read more...</a></p>

## 11,000-Year-Old Wall Carving in Turkey Could Be Some of the Oldest Narrative Art
 - [https://gizmodo.com/11-000-year-old-narrative-art-sayburc-turkey-1849868575](https://gizmodo.com/11-000-year-old-narrative-art-sayburc-turkey-1849868575)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 18:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--jgvMH3RO--/c_fit,fl_progressive,q_80,w_636/df04fd00075a1a1145a83ea95f73e71b.jpg" /><p>In Sayburç, Turkey, not far from the famous settlement of <a href="https://whc.unesco.org/en/list/1572/" rel="noopener noreferrer" target="_blank">Göbekli Tepe</a>, an archaeologist discovered an 11,000-year-old scene carved into a wall. It’s one of the oldest narrative depictions in the archaeological record.</p><p><a href="https://gizmodo.com/11-000-year-old-narrative-art-sayburc-turkey-1849868575">Read more...</a></p>

## Why Avatar: The Way of Water Took So Long to Come Out
 - [https://gizmodo.com/avatar-2-release-date-delay-james-cameron-pandora-water-1849854621](https://gizmodo.com/avatar-2-release-date-delay-james-cameron-pandora-water-1849854621)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 18:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--dbk5rqCZ--/c_fit,fl_progressive,q_80,w_636/c617693a9cb3bac55ce524de171d8c0d.jpg" /><p>Strike while the iron is hot: that’s the prevalent thinking in Hollywood when it <a href="https://gizmodo.com/12-sequels-that-completely-change-how-you-view-the-orig-1613832109">comes to making a sequel</a>. If you have a success, get another one out as soon as possible. In 2009 and 2010, <a href="https://gizmodo.com/avatar-review-yes-it-changed-everything-after-all-5429424">James Cameron’s <em>Avatar</em></a> wasn’t just hot, it was the surface of the sun. The 3D movie about the blue people on an alien planet…</p><p><a href="https://gizmodo.com/avatar-2-release-date-delay-james-cameron-pandora-water-1849854621">Read more...</a></p>

## A City in Washington Wants to Give Orcas Their Own Version of Human Rights
 - [https://gizmodo.com/orcas-washington-legal-rights-animal-personhood-1849864751](https://gizmodo.com/orcas-washington-legal-rights-animal-personhood-1849864751)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 18:36:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--hNI7hOw3--/c_fit,fl_progressive,q_80,w_636/e30c024a5dc6bfc9483d056e9bc4e2d4.jpg" /><p>A mayor and city council in the Pacific Northwest are hoping to help a group of endangered orcas by formally declaring that these marine mammals should have legal rights. <br /></p><p><a href="https://gizmodo.com/orcas-washington-legal-rights-animal-personhood-1849864751">Read more...</a></p>

## Take a Disturbing Dip Into Infinity Pool's First Trailer
 - [https://gizmodo.com/infinity-pool-trailer-brandon-cronenberg-horror-movie-1849869891](https://gizmodo.com/infinity-pool-trailer-brandon-cronenberg-horror-movie-1849869891)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 18:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--yV5oEHE7--/c_fit,fl_progressive,q_80,w_636/0e7d627d1360d4bbfa397ba727448d40.jpg" /><p>I should have known immediately <em>Infinity Pool</em>, the upcoming film by <a href="https://gizmodo.com/david-cronenberg-crimes-of-the-future-obi-wan-kenobi-st-1848929082">David Cronenberg</a>’s son Brandon, wasn’t going to be a simple thriller. He’s directed the sci-fi horror flicks <a href="https://gizmodo.com/sean-bean-looks-doomed-again-in-the-trippy-intense-pos-1844917172"><em>Possessor</em></a> and <a href="https://gizmodo.com/in-the-creepy-future-of-antiviral-people-pay-to-be-inf-472740527"><em>Antiviral</em></a>, so what seems at first to be a simple tale of a privileged white guy who travels to a foreign country, hits someone…</p><p><a href="https://gizmodo.com/infinity-pool-trailer-brandon-cronenberg-horror-movie-1849869891">Read more...</a></p>

## How to Beat Daylight Savings Time and Have a Winter of the Sun
 - [https://gizmodo.com/how-to-beat-daylight-savings-time-adjust-schedule-1849854448](https://gizmodo.com/how-to-beat-daylight-savings-time-adjust-schedule-1849854448)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 17:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--6bkjxEtt--/c_fit,fl_progressive,q_80,w_636/2a2927f839dca83577364e8ff7a2b07d.jpg" /><p>If you, too, hate the annual switch to 4:30pm sunsets; if you dread descending into months of darkness; if January is not a month to live, but simply survive, I’m here to tell you: refuse. For keyboard warriors, time zone is a choice.</p><p><a href="https://gizmodo.com/how-to-beat-daylight-savings-time-adjust-schedule-1849854448">Read more...</a></p>

## Wikipedia Founder Indirectly Tells Elon Musk the Site 'Is Not for Sale'
 - [https://gizmodo.com/elon-musk-wikipedia-twitter-twitter-files-1849869127](https://gizmodo.com/elon-musk-wikipedia-twitter-twitter-files-1849869127)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 17:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--y2gpmDgX--/c_fit,fl_progressive,q_80,w_636/f6e2101b2c1d4eb24080ffa44100c992.jpg" /><p>Wikipedia founder, Jimmy Wales, is going head-to-head with Twitter CEO Elon Musk who has accused the encyclopedia site of having a left-leaning bias. The back and forth began following the overly dramatic release of the <a href="https://gizmodo.com/twitter-files-hunter-biden-elon-musk-taibbi-explained-1849851303">Twitter Files</a> which alleged the FBI pressured social media companies to suppress information…</p><p><a href="https://gizmodo.com/elon-musk-wikipedia-twitter-twitter-files-1849869127">Read more...</a></p>

## The Rock's Black Adam Box Office Damage Control Is Embarrassing
 - [https://gizmodo.com/dc-black-adam-box-office-flop-dwayne-johnson-the-rock-1849866587](https://gizmodo.com/dc-black-adam-box-office-flop-dwayne-johnson-the-rock-1849866587)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 17:25:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--q_kmdu-r--/c_fit,fl_progressive,q_80,w_636/4c4aff650d841ab168259a13c5d15afe.jpg" /><p>A few days after <a href="https://variety.com/2022/film/box-office/black-adam-box-office-100-million-loss-1235449487/" rel="noopener noreferrer" target="_blank">Variety reported</a> that the <a href="https://gizmodo.com/black-adam-review-dwayne-johnson-the-rock-superman-dc-1849627545">Dwayne Johnson</a>-led <a href="https://gizmodo.com/open-channel-black-adam-movie-1849691100"><em>Black Adam</em></a> was looking like it was going to <a href="https://gizmodo.com/black-adam-box-office-flop-dwayne-the-rock-johnson-dcu-1849858829">fail to return much of a profit</a>—if any—<a href="https://deadline.com/2022/12/dwayne-johnson-black-adam-box-office-profit-1235191135/" rel="noopener noreferrer" target="_blank">Deadline</a> has come out with a piece stating that the Variety article is wrong, actually, and <a href="https://gizmodo.com/justice-league-2017-joss-whedon-retrospective-1849788727"><em>Black Adam</em></a><em> </em>is doing just fine in the <a href="https://gizmodo.com/black-panther-wakanda-forever-box-office-open-1849777950">box office</a>. The star himself has also chimed…</p><p><a href="https://gizmodo.com/dc-black-adam-box-office-flop-dwayne-johnson-the-rock-1849866587">Read more...</a></p>

## Over Half the World's Energy Transition Minerals Are on Indigenous Lands
 - [https://gizmodo.com/over-half-the-worlds-energy-transition-minerals-are-on-1849865104](https://gizmodo.com/over-half-the-worlds-energy-transition-minerals-are-on-1849865104)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 17:18:36+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--lwcItYhf--/c_fit,fl_progressive,q_80,w_636/83e9245fdba556bb65c34e5746f65310.jpg" /><p>As the gears kick in for the world to shift to clean energy, it’s becoming increasingly clear that we’re going to need more of the minerals—like lithium, cobalt, and nickel—that help power our cars and form the backbone of our solar panels. And the mining industry is quickly catching on to how profitable this…</p><p><a href="https://gizmodo.com/over-half-the-worlds-energy-transition-minerals-are-on-1849865104">Read more...</a></p>

## Elon Is Thinking of Changing His Twitter Blue Sales Pitch for iPhone Users to ‘Pay $11’
 - [https://gizmodo.com/elon-musk-twitter-iphone-apple-app-store-price-11-1849869146](https://gizmodo.com/elon-musk-twitter-iphone-apple-app-store-price-11-1849869146)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 16:48:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--bIfZ1nM0--/c_fit,fl_progressive,q_80,w_636/0b34743b0360c0570182536f43ec5280.jpg" /><p>Twitter CEO Elon Musk has told users on his platform <a href="https://gizmodo.com/elon-musk-blue-checkmark-twitter-verification-1849729265">to pay $8</a> for its <a href="https://gizmodo.com/twitter-elon-musk-verified-impersonators-checkmark-1849768462">Blue subscription service</a> so many times that it’s hard to imagine him saying anything else. Yet, a week after someone apparently told him that Apple charges a 30% tax on App Store purchases, Musk may be changing his sales pitch for iOS users to…</p><p><a href="https://gizmodo.com/elon-musk-twitter-iphone-apple-app-store-price-11-1849869146">Read more...</a></p>

## NASA'S ICON Space Weather Satellite Has Suddenly Gone Silent
 - [https://gizmodo.com/nasa-icon-space-weather-satellite-malfunction-1849868834](https://gizmodo.com/nasa-icon-space-weather-satellite-malfunction-1849868834)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--fjbM_u0j--/c_fit,fl_progressive,q_80,w_636/f8c392a218b001970fd0eba132ac84cd.png" /><p>A three-year-old NASA satellite lost touch with ground controllers two weeks ago and is now wandering through low Earth orbit without supervision. Sadly, the space agency fears the worst. </p><p><a href="https://gizmodo.com/nasa-icon-space-weather-satellite-malfunction-1849868834">Read more...</a></p>

## Shadow and Bone Season 2 Will Premiere in March
 - [https://gizmodo.com/shadow-and-bone-season-2-premiere-date-2023-netflix-1849869080](https://gizmodo.com/shadow-and-bone-season-2-premiere-date-2023-netflix-1849869080)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 16:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vvMz5T_n--/c_fit,fl_progressive,q_80,w_636/81d328893a4df67f270886bdb31695d9.jpg" /><p> Plus, get a first look at some new photos from the production as well as a sneak peek at what Alina, Mal, and the crows are up to. </p><p><a href="https://gizmodo.com/shadow-and-bone-season-2-premiere-date-2023-netflix-1849869080">Read more...</a></p>

## Google Releases Its Most Searched Terms for 2022
 - [https://gizmodo.com/google-internet-search-top-cats-ukraine-wordle-1849866017](https://gizmodo.com/google-internet-search-top-cats-ukraine-wordle-1849866017)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 16:05:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--X1C2solx--/c_fit,fl_progressive,q_80,w_636/160ae6839c8d0c77f4850f5eb9203cb6.jpg" /><p>Google knows if you’ve been naughty, it knows if you’ve been nice, and the search engine’s <a href="https://gizmodo.com/google-lawsuit-settle-location-data-392-million-privacy-1849780302">extensive data collection</a> and analytics allow it to regurgitate ourselves back to us, once a year. In 2022's Google <a href="https://trends.google.com/trends/yis/2022/GLOBAL/" rel="noopener noreferrer" target="_blank">Year in Search</a> retrospective, you can find evidence of what mattered to internet users most, over the past 12…</p><p><a href="https://gizmodo.com/google-internet-search-top-cats-ukraine-wordle-1849866017">Read more...</a></p>

## Satechi Portable Power Bank Wirelessly Charges Two Devices at Same Time
 - [https://gizmodo.com/satechi-portable-power-bank-wireless-charging-charger-1849864666](https://gizmodo.com/satechi-portable-power-bank-wireless-charging-charger-1849864666)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--6HosQR2X--/c_fit,fl_progressive,q_80,w_636/e174152145ca7b8fae955e58e9393b94.jpg" /><p>If you live in constant fear of your electronics dying and leaving you without a reliable source of entertainment and distraction, you need to make sure you always have a charging solution on hand. With <a href="https://satechi.net/products/duo-wireless-charger-power-stand" rel="noopener noreferrer" target="_blank">Satechi’s new Duo Wireless Charger Power Stand</a>, you can actually leave your charging cables at home, because it…</p><p><a href="https://gizmodo.com/satechi-portable-power-bank-wireless-charging-charger-1849864666">Read more...</a></p>

## Indiana AG Sues TikTok Twice as Texas Joins the Call to Ban App From State-Issued Devices
 - [https://gizmodo.com/tiktok-texas-bytedance-lawsuit-indiana-1849868406](https://gizmodo.com/tiktok-texas-bytedance-lawsuit-indiana-1849868406)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 15:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--W-bAeUJT--/c_fit,fl_progressive,q_80,w_636/f12e325ab6995bc5ccdcf59757bfe85d.jpg" /><p>TikTok is facing growing scrutiny from various U.S. political officials. Amidst an <a href="https://gizmodo.com/tiktok-china-south-dakota-ban-bytedance-1849836201">ongoing call from state leaders</a> to ban the app from state government devices, Indiana Attorney General Todd Rokita has announced that the state has filed two lawsuits against the social media platform.<br /></p><p><a href="https://gizmodo.com/tiktok-texas-bytedance-lawsuit-indiana-1849868406">Read more...</a></p>

## Mike Flanagan to Adapt Stephen King's Dark Tower for Amazon
 - [https://gizmodo.com/mike-flanagan-stephen-king-dark-tower-amazon-1849868950](https://gizmodo.com/mike-flanagan-stephen-king-dark-tower-amazon-1849868950)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 15:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--V03r2DzS--/c_fit,fl_progressive,q_80,w_636/d555cf0a9bf6cfd1c49ad596af8c5fd4.jpg" /><p>In the wake of moving from an overall deal with <a href="https://gizmodo.com/midnight-club-canceled-mike-flanagan-netflix-amazon-1849846295">Netflix</a> to Amazon, writer/director <a href="https://gizmodo.com/sounds-like-mike-flangans-edgar-allen-poe-show-will-be-1847877760">Mike Flanagan</a> and his longtime executive producer <a href="https://gizmodo.com/mike-flanagan-talks-midnight-mass-catholic-influences-a-1847787861">Trevor Macy</a> have revealed that they have acquired the rights to a screen adaptation of Stephen King’s <a href="https://gizmodo.com/amazons-scrapped-dark-tower-series-sounds-intriguing-as-1843688996"><em>The Dark Tower</em></a>. Flanagan said to <a href="https://deadline.com/2022/12/mike-flanagan-amp-trevor-macy-the-dark-tower-series-movies-netflix-exit-midnight-club-canceled-amazon-intrepid-1235191018/" rel="noopener noreferrer" target="_blank">Deadline</a> in an interview that he’s already written…</p><p><a href="https://gizmodo.com/mike-flanagan-stephen-king-dark-tower-amazon-1849868950">Read more...</a></p>

## Time to Tackle the Taylor Swift Ticketmaster Turmoil | TechModo
 - [https://gizmodo.com/time-to-tackle-the-taylor-swift-ticketmaster-turmoil-1849866399](https://gizmodo.com/time-to-tackle-the-taylor-swift-ticketmaster-turmoil-1849866399)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 15:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vVAUt33i--/c_fit,fl_progressive,q_80,w_636/87508ce356f2bbf7698f825c515ba095.jpg" /><p><a href="https://gizmodo.com/time-to-tackle-the-taylor-swift-ticketmaster-turmoil-1849866399">Read more...</a></p>

## Key SpaceX Launches Back on Track After Unexplained Delays
 - [https://gizmodo.com/spacex-launch-oneweb-hakuto-r-nasa-lunar-flashlight-1849865941](https://gizmodo.com/spacex-launch-oneweb-hakuto-r-nasa-lunar-flashlight-1849865941)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 15:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--1HG83dTa--/c_fit,fl_progressive,q_80,w_636/b5cf92e81d435af039736fb5a87daed7.jpg" /><p>Better late than never, but it appears that SpaceX is set to launch a batch of OneWeb internet satellites to Earth orbit and the private Japanese Hakuto-R mission to the Moon, along with a NASA water-hunting probe. </p><p><a href="https://gizmodo.com/spacex-launch-oneweb-hakuto-r-nasa-lunar-flashlight-1849865941">Read more...</a></p>

## San Francisco Investigates Twitter for Musk’s Ugly Motel-Style In-Office Bedrooms
 - [https://gizmodo.com/twitter-elon-musk-san-francisco-1849868647](https://gizmodo.com/twitter-elon-musk-san-francisco-1849868647)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 15:05:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--HSG5mHaF--/c_fit,fl_progressive,q_80,w_636/2d472d402f88c9af8eb54b4733b9eb11.jpg" /><p>Twitter owner Elon Musk is clearly miffed at the idea that San Francisco city officials would dare question his efforts to somehow transform the company headquarters into a quasi-motel for all the employees he’s likely exhausting.</p><p><a href="https://gizmodo.com/twitter-elon-musk-san-francisco-1849868647">Read more...</a></p>

## Did the Army's Secret Radiation Experiments Sabotage a Housing Project?
 - [https://gizmodo.com/pruitt-igoe-army-radiation-experiments-cold-war-1849833275](https://gizmodo.com/pruitt-igoe-army-radiation-experiments-cold-war-1849833275)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--_RmkYILj--/c_fit,fl_progressive,q_80,w_636/55fd7f3ce1d1be51aa31d0c7bd72641d.jpg" /><p><em>This article <a href="https://proteanmag.com/2022/11/28/pruitt-igoe-a-black-community-under-the-atomic-cloud/" rel="noopener noreferrer" target="_blank">originally appeared in </a><a href="https://proteanmag.com/2022/11/28/pruitt-igoe-a-black-community-under-the-atomic-cloud/" rel="noopener noreferrer" target="_blank">Protean Magazine</a>, a leftist print magazine of critique, fiction, poetry, and art.<br /></em></p><p><a href="https://gizmodo.com/pruitt-igoe-army-radiation-experiments-cold-war-1849833275">Read more...</a></p>

## Updates From Lord of the Rings: The Rings of Power, and More
 - [https://gizmodo.com/lord-of-the-rings-rings-of-power-season-2-casting-1849852420](https://gizmodo.com/lord-of-the-rings-rings-of-power-season-2-casting-1849852420)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 14:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--8aYqRL3---/c_fit,fl_progressive,q_80,w_636/e8f460b2bfd7f0e8aa717b063dedb374.png" /><p>Alexander Skarsgård and Mia Goth look haunting in the first look at David Cronenberg’s new horror movie, <em>Infinity Pool</em>. Tom Welling heads to <em>Supernatural</em> in new footage from <em>The Winchesters</em>. Plus, a new look at Syfy’s colony thriller <em>The Ark</em>. Spoilers, away!<br /></p><p><a href="https://gizmodo.com/lord-of-the-rings-rings-of-power-season-2-casting-1849852420">Read more...</a></p>

## How To Undo iOS 16's Most Annoying Changes
 - [https://gizmodo.com/ios-16-search-bar-notifications-mail-app-photo-changes-1849857452](https://gizmodo.com/ios-16-search-bar-notifications-mail-app-photo-changes-1849857452)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--PKBziEBp--/c_fit,fl_progressive,q_80,w_636/a621c6c0dbcce235876b4c3a6ac39ef1.jpg" /><p>The <a href="https://gizmodo.com/ios-16-new-features-lock-screens-widgets-edit-unsend-1849552141">iOS 16</a> update is now firmly established on a large chunk of iPhones, but you might not be completely happy with every tweak and modification that’s been made. The good news is that at least some of the changes can be reversed by delving into the iOS Settings screen, and we’ll cover some of the most important ones…</p><p><a href="https://gizmodo.com/ios-16-search-bar-notifications-mail-app-photo-changes-1849857452">Read more...</a></p>

## Amazon, FBI.gov, and 70,000 Other Sites Are Sending Your Data to Elon's Twitter, New Research Says
 - [https://gizmodo.com/elon-musk-twitter-amazon-fbi-70000-sites-data-security-1849867489](https://gizmodo.com/elon-musk-twitter-amazon-fbi-70000-sites-data-security-1849867489)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 12:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ncMx92Rx--/c_fit,fl_progressive,q_80,w_636/27cd3fe02ee4dec68286095653f12a7c.jpg" /><p>In October, Elon Musk purchased Twitter for a cool $44 billion dollars. Among a variety of other assets and headaches, the deal came with one resource that’s gone under-explored: a vast data collection network spanning the sites of more than 70,000 Fortune 500 companies, government agencies, non-profits, universities,…</p><p><a href="https://gizmodo.com/elon-musk-twitter-amazon-fbi-70000-sites-data-security-1849867489">Read more...</a></p>

## Apple Officially Cancels Its Plans to Scan iCloud Photos for Child Abuse Material
 - [https://gizmodo.com/apple-officially-cancels-its-plans-to-scan-icloud-photo-1849867355](https://gizmodo.com/apple-officially-cancels-its-plans-to-scan-icloud-photo-1849867355)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 06:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--VtVcDmPu--/c_fit,fl_progressive,q_80,w_636/6b49db17182703135171c959bac09ad9.jpg" /><p>Apple has officially killed one of its most controversial proposals ever: <a href="https://gizmodo.com/apple-says-it-wont-let-the-government-turn-its-child-ab-1847450920">a plan</a> to scan iCloud images for signs of child sexual abuse material (or, CSAM). </p><p><a href="https://gizmodo.com/apple-officially-cancels-its-plans-to-scan-icloud-photo-1849867355">Read more...</a></p>

## Wonder Woman 3 Is Reportedly Dead
 - [https://gizmodo.com/wonder-woman-3-dead-cancel-warner-bros-dc-patty-jenkins-1849866873](https://gizmodo.com/wonder-woman-3-dead-cancel-warner-bros-dc-patty-jenkins-1849866873)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 00:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--TIwcPEGM--/c_fit,fl_progressive,q_80,w_636/4513a0400196833114db3097eb6d4856.jpg" /><p>When Warner Bros. hired James Gunn and Peter Safran to reimagine the DC Universe, everyone expected changes. But no one could have expected that one of the studio’s surefire heroes, Wonder Woman, would come under the axe. That is, apparently what has happened though as Patty Jenkins’ <em>Wonder Woman 3 </em>has been canceled. </p><p><a href="https://gizmodo.com/wonder-woman-3-dead-cancel-warner-bros-dc-patty-jenkins-1849866873">Read more...</a></p>

## This Week's Willow Has a Very Surprisingly Cameo—Here's How It Happened
 - [https://gizmodo.com/willow-hannah-waddingham-lucasfilm-ted-lasso-disney-app-1849864076](https://gizmodo.com/willow-hannah-waddingham-lucasfilm-ted-lasso-disney-app-1849864076)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 00:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--rgrLj3XS--/c_fit,fl_progressive,q_80,w_636/57a4fb39aab3b3de44a452c5fa49d95b.jpg" /><p>When you’re dealing with franchises as popular as the ones Lucasfilm makes, it’s not all that surprising to see <a href="https://gizmodo.com/luke-skywalkers-mandalorian-cameo-was-guided-by-our-sta-1847578597">hugely famous people pop up</a> in small roles. Everyone wants to work on <a href="https://gizmodo.com/the-first-big-cameo-of-star-wars-the-rise-of-skywalker-1839232886"><em>Star Wars</em></a> or <em>Indiana Jones</em> so they’ll do whatever they can to get on screen. Apparently though, that also extends to <a href="https://gizmodo.com/willow-episode-1-2-recaps-disney-plus-lucasfilm-warwick-1849833468"><em>Willow</em></a>.</p><p><a href="https://gizmodo.com/willow-hannah-waddingham-lucasfilm-ted-lasso-disney-app-1849864076">Read more...</a></p>

## Dyson's Air Purifying Headphones Will Cost $949
 - [https://gizmodo.com/dyson-air-purifying-headphones-filter-price-release-dat-1849831922](https://gizmodo.com/dyson-air-purifying-headphones-filter-price-release-dat-1849831922)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 00:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ncOOZE-8--/c_fit,fl_progressive,q_80,w_636/21b9d281ab17c9322a01ea0b36b94e18.jpg" /><p>Earlier this year, Dyson revealed its <a href="https://gizmodo.com/dyson-zone-headphones-come-with-an-air-purifying-face-g-1848582394">first audio product</a>, a pair of headphones that promised to not only block noise, but unwanted airborne particles as well, thanks to a built-in filtration system and mask. Today, the company revealed more details on the <a href="https://gizmodo.com/dyson-zone-headphones-come-with-an-air-purifying-face-g-1848582394">Dyson Zone</a>, including when you’ll be able to buy a pair and…</p><p><a href="https://gizmodo.com/dyson-air-purifying-headphones-filter-price-release-dat-1849831922">Read more...</a></p>

## Jack to Elon: Can We Just Get the Doxxing Over With?
 - [https://gizmodo.com/jack-to-elon-can-we-just-get-the-doxxing-over-with-1849864704](https://gizmodo.com/jack-to-elon-can-we-just-get-the-doxxing-over-with-1849864704)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-12-08 00:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--FZWdoXy8--/c_fit,fl_progressive,q_80,w_636/b6d9101cf2af63d9060ee14f3cc29908.jpg" /><p>As the saga of the “<a href="https://gizmodo.com/twitter-files-hunter-biden-elon-musk-taibbi-explained-1849851303">Twitter Files</a>” continues, the platform’s former CEO Jack Dorsey seems to be wondering why we can’t just hurry this up already and dump <em>all</em> of the company’s related dirt in one fell swoop. </p><p><a href="https://gizmodo.com/jack-to-elon-can-we-just-get-the-doxxing-over-with-1849864704">Read more...</a></p>


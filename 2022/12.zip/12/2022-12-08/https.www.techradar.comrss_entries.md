# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Elon Musk isn't giving you crypto - it's a scam
 - [https://www.techradar.com/news/elon-musk-isnt-giving-you-crypto-its-a-scam](https://www.techradar.com/news/elon-musk-isnt-giving-you-crypto-its-a-scam)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 22:30:00+00:00

The old "give 1 BTC to Elon, get 2 back" scam is back, so beware.

## Amazon Echo Show 15 finally becomes the kitchen TV it always wanted to be
 - [https://www.techradar.com/news/amazon-echo-show-15-finally-becomes-the-kitchen-tv-it-always-wanted-to-be](https://www.techradar.com/news/amazon-echo-show-15-finally-becomes-the-kitchen-tv-it-always-wanted-to-be)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 20:50:10+00:00

The update adds support for Amazon Fire TV and spatial audio processing for improved audio.

## Proton's encrypted cloud storage is going mobile
 - [https://www.techradar.com/news/protons-encrypted-cloud-storage-is-going-mobile](https://www.techradar.com/news/protons-encrypted-cloud-storage-is-going-mobile)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 20:16:50+00:00

Proton Drive is now available on iOS and Android devices, with other platform releases planned soon.

## Pentagon awards $9bn cloud contract to Google, Oracle, Amazon and Microsoft
 - [https://www.techradar.com/news/pentagon-awards-dollar9bn-cloud-contract-to-google-oracle-amazon-and-microsoft](https://www.techradar.com/news/pentagon-awards-dollar9bn-cloud-contract-to-google-oracle-amazon-and-microsoft)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 18:52:41+00:00

Often conbative cloud providers will need to collaborate to deliver the Pentagon’s cloud strategy.

## Campfire Audio wants to enter your Orbit with its first ever true wireless earbuds
 - [https://www.techradar.com/news/campfire-audio-wants-to-enter-your-orbit-with-its-first-ever-true-wireless-earbuds](https://www.techradar.com/news/campfire-audio-wants-to-enter-your-orbit-with-its-first-ever-true-wireless-earbuds)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 17:22:19+00:00

The aspirational audio brand has finally dipped its toes into the wire-free market, with new Bluetooth 5.2 buds that boast 10mm dynamic drivers.

## Bioshock 4 isn't dead, it just got a key lead dev from Ghost of Tsushima and Far Cry 4
 - [https://www.techradar.com/news/bioshock-4-isnt-dead-it-just-got-a-key-lead-dev-from-ghost-of-tsushima-and-far-cry-4](https://www.techradar.com/news/bioshock-4-isnt-dead-it-just-got-a-key-lead-dev-from-ghost-of-tsushima-and-far-cry-4)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 17:16:25+00:00

One of the writers behind Far Cry 4 and Ghost of Tsushima just signed on to be narrative lead of Bioshock 4.

## Future MacBook Pros could ditch the keyboard in favor of a big foldable screen
 - [https://www.techradar.com/news/future-macbook-pros-could-ditch-the-keyboard-in-favor-of-a-big-foldable-screen](https://www.techradar.com/news/future-macbook-pros-could-ditch-the-keyboard-in-favor-of-a-big-foldable-screen)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 17:04:56+00:00

The possibility of a foldable MacBook Pro is something we heard about earlier this year.

## Google Sheets want to use AI to flag and fix your mistakes
 - [https://www.techradar.com/news/google-sheets-want-to-use-ai-to-flag-and-fix-your-mistakes](https://www.techradar.com/news/google-sheets-want-to-use-ai-to-flag-and-fix-your-mistakes)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 17:03:26+00:00

Google’s TensorFlow team will let users harness the power of AI to fix annoying spreadsheet mistakes or make predictions.

## Intel set to reveal PC roadmap – will we hear about new CPUs?
 - [https://www.techradar.com/news/intel-set-to-reveal-pc-roadmap-will-we-hear-about-new-cpus](https://www.techradar.com/news/intel-set-to-reveal-pc-roadmap-will-we-hear-about-new-cpus)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 16:12:09+00:00

Maybe we’ll learn more about Lunar Lake, or even the future processors beyond that…

## Praise the Saints! Shadow and Bone season 2 finally has a release date
 - [https://www.techradar.com/news/praise-the-saints-shadow-and-bone-season-2-finally-has-a-release-date](https://www.techradar.com/news/praise-the-saints-shadow-and-bone-season-2-finally-has-a-release-date)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 16:11:27+00:00

Netflix has officially revealed when Shadow and Bone season 2 will be released.

## Microsoft Teams wants to build an all-new workplace community for your business
 - [https://www.techradar.com/news/microsoft-teams-wants-to-build-an-all-new-workplace-community-for-your-business](https://www.techradar.com/news/microsoft-teams-wants-to-build-an-all-new-workplace-community-for-your-business)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 16:10:05+00:00

Microsoft Teams takes aim at the group chat market with communities designed for managing groups and clubs.

## It looks like Sony's accidentally leaked the Street Fighter 6 release date
 - [https://www.techradar.com/news/it-looks-like-sonys-accidentally-leaked-the-street-fighter-6-release-date](https://www.techradar.com/news/it-looks-like-sonys-accidentally-leaked-the-street-fighter-6-release-date)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 15:42:43+00:00

The release date for Street Fighter 6 has been leaked ahead of The Game Awards.

## I'll crash straight into the sun with this Meta Quest 2 game's hand-tracked controls
 - [https://www.techradar.com/news/ill-crash-straight-into-the-sun-with-this-meta-quest-2-games-hand-tracked-controls](https://www.techradar.com/news/ill-crash-straight-into-the-sun-with-this-meta-quest-2-games-hand-tracked-controls)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 15:37:07+00:00

The new Stellaris VR spin-off will make use of Hand Tracking 2.0 to put the weight of the solar system in your hands.

## Apple announces huge upgrade to your iCloud data privacy
 - [https://www.techradar.com/news/apple-announces-huge-upgrade-to-your-icloud-data-privacy](https://www.techradar.com/news/apple-announces-huge-upgrade-to-your-icloud-data-privacy)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 15:35:25+00:00

New Apple security tools help protect both public figures and regular consumers against cyberattackers.

## Google says North Korea targeted an Internet Explorer zero-day vulnerability
 - [https://www.techradar.com/news/google-says-north-korea-targeted-an-internet-explorer-zero-day-vulnerability](https://www.techradar.com/news/google-says-north-korea-targeted-an-internet-explorer-zero-day-vulnerability)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 14:04:48+00:00

Internet Explorer may have officially been retired, but it's still used by Office, Google researchers found.

## This report claims to have found the seven keys to a secure business
 - [https://www.techradar.com/news/this-report-claims-to-have-found-the-seven-keys-to-a-secure-business](https://www.techradar.com/news/this-report-claims-to-have-found-the-seven-keys-to-a-secure-business)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 13:54:58+00:00

Cisco scores businesses on security resilience and reveals the high achievers’ secrets.

## Scammers are attacking each other with some very old-school tools
 - [https://www.techradar.com/news/scammers-are-attacking-each-other-with-some-very-old-school-tools](https://www.techradar.com/news/scammers-are-attacking-each-other-with-some-very-old-school-tools)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 13:26:25+00:00

Scammers target scammers with typosquatting, phishing, and malware, researchers are saying.

## The Witcher 3's next-gen update may look better, but you'll pay for it in broken mods
 - [https://www.techradar.com/news/the-witcher-3s-next-gen-update-may-look-better-but-youll-pay-for-it-in-broken-mods](https://www.techradar.com/news/the-witcher-3s-next-gen-update-may-look-better-but-youll-pay-for-it-in-broken-mods)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 12:38:02+00:00

The Witcher 3 Next Gen will look even better thanks to these baked-in community mods, but your others might get broken.

## Sonos and IKEA’s latest Symfonisk collab is yet another lamp-speaker hybrid
 - [https://www.techradar.com/news/sonos-and-ikeas-latest-symfonisk-collab-is-yet-another-lamp-speaker-hybrid](https://www.techradar.com/news/sonos-and-ikeas-latest-symfonisk-collab-is-yet-another-lamp-speaker-hybrid)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 12:37:04+00:00

Sonos and IKEA have created a new speaker-furnishing hybrid: the Symfonisk Floor Lamp speaker.

## PS5 supply issues are 'resolved' in Asia, but what about the US and the UK?
 - [https://www.techradar.com/news/ps5-supply-issues-are-resolved-in-asia-but-what-about-the-us-and-the-uk](https://www.techradar.com/news/ps5-supply-issues-are-resolved-in-asia-but-what-about-the-us-and-the-uk)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 12:03:30+00:00

SIE President and CEO Jim Ryan has stated that the company has 'resolved' PS5 supply issues in Japan and Asia.

## Look away, Canon fans: Sigma could soon announce lenses for the Nikon Z mount
 - [https://www.techradar.com/news/look-away-canon-fans-sigma-could-soon-announce-lenses-for-the-nikon-z-mount](https://www.techradar.com/news/look-away-canon-fans-sigma-could-soon-announce-lenses-for-the-nikon-z-mount)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 11:50:37+00:00

Sigma is rumored to be launching new lenses for Nikon's mirrorless cameras soon. Will it force Canon to change its mind?

## Web skimming hackers infiltrate over 40 ecommerce websites - that we know of
 - [https://www.techradar.com/news/web-skimming-hackers-infiltrate-over-40-ecommerce-websites-that-we-know-of](https://www.techradar.com/news/web-skimming-hackers-infiltrate-over-40-ecommerce-websites-that-we-know-of)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 11:43:23+00:00

Web skimming or Magecart is used to access sensitive information from websites through various hacking methods.

## Apple really wants you to use a physical security key for Apple ID
 - [https://www.techradar.com/news/apple-really-wants-you-to-use-a-physical-security-key-for-apple-id](https://www.techradar.com/news/apple-really-wants-you-to-use-a-physical-security-key-for-apple-id)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 11:29:36+00:00

Not its own security key, though, but rather a third-party solution.

## Boost Infinite is finally here, and it offers unlimited data for just $25 per month
 - [https://www.techradar.com/news/boost-infinite-is-finally-here-and-it-offers-unlimited-data-for-just-dollar25-per-month](https://www.techradar.com/news/boost-infinite-is-finally-here-and-it-offers-unlimited-data-for-just-dollar25-per-month)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 10:42:54+00:00

Boost Infinite will give you unlimited data, minutes and texts for just $25 per month – forever.

## Ask these questions before you make your Lensa Magic Avatars
 - [https://www.techradar.com/news/ask-these-questions-before-you-make-your-lensa-magic-avatars](https://www.techradar.com/news/ask-these-questions-before-you-make-your-lensa-magic-avatars)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 05:00:11+00:00

Lensa Magic Avatars are all good clean fun, until someone gets hurt. Ask these questions first.

## Dyson's air-purifying ANC headphones are really coming to market next year
 - [https://www.techradar.com/news/dysons-air-purifying-anc-headphones-are-really-coming-to-market-next-year](https://www.techradar.com/news/dysons-air-purifying-anc-headphones-are-really-coming-to-market-next-year)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-12-08 00:01:59+00:00

Dyson has revealed the specifications of its noise-cancelling headphones with wearable purifier attachment due in 2023.


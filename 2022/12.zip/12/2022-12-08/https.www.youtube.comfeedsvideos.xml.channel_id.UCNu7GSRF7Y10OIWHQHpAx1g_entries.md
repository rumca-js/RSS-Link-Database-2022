# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Największe kamienie wyciosane przez człowieka. Powrót przez Grecję. Liban #5
 - [https://www.youtube.com/watch?v=ksH6IHMp1zU](https://www.youtube.com/watch?v=ksH6IHMp1zU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2022-12-08 15:41:30+00:00

Ostatni odcinek z Libanu przedstawia podróż do Baalbek, zdecydowanie najciekawszego turystycznie miejsca w tym państwie. Wracamy do Polski po drodze odwiedzając greckie Ateny

Stąd biorę muzykę do vlogów: https://bit.ly/bezplanu_artlist
(2 miesiące gratis, jeśli zarejestrujesz się z tego linku)

Wszystkie odcinki BezPlanu chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

Sklep: https://bezplanu.com
BezPlanu Daily: https://www.youtube.com/channel/UCHXOfJP9fwMNXWGFKstju_w
Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv
Wsparcie na Patronite: http://bit.ly/2KsFTZk 

Czas akcji: październik 2022r.


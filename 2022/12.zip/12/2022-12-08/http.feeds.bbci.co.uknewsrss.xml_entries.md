# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The Papers: 'Palace anger' and 'direct hit' at Queen's legacy
 - [https://www.bbc.co.uk/news/blogs-the-papers-63912086?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-63912086?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 23:41:26+00:00

Reaction to the Duke and Duchess of Sussex's new Netflix series dominates Friday's papers.

## Fauci: 'Low-life trolls harass my wife and kids'
 - [https://www.bbc.co.uk/news/world-us-canada-63895762?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63895762?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 23:13:03+00:00

Dr Anthony Fauci speaks to Americast as he stands down as chief medical adviser to President Joe Biden.

## Cost of living crisis: I'm going on the road to save my butcher's shop
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-business-63561648?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-business-63561648?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 22:52:47+00:00

As the cost of living crisis bites, butcher Gary Peline has bought a mobile shop to keep his business going.

## The brothers running the Great Wall of China
 - [https://www.bbc.co.uk/news/world-asia-china-63757951?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-63757951?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 22:25:39+00:00

Jimmy and Tommy Lindesay are covering the equivalent of a marathon every day for six months.

## Real Madrid 1-1 Chelsea: Blues miss chance to confirm Champions League knockout place
 - [https://www.bbc.co.uk/sport/football/63896139?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63896139?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 22:08:26+00:00

Chelsea draw 1-1 at Real Madrid to miss chance to wrap up qualification for Women's Champions League quarter-finals.

## Activision Blizzard: US seeks to block Microsoft's $69bn acquisition
 - [https://www.bbc.co.uk/news/business-63911557?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63911557?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 21:30:46+00:00

Microsoft said it would fight to buy Activision Blizzard, the studio behind games such as Call of Duty.

## World Cup 2022: Can Modric inspire another 'memorable' Croatia chapter?
 - [https://www.bbc.co.uk/sport/football/63901104?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63901104?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 20:23:18+00:00

Can Luke Modric inspire Croatia to a shock World Cup quarter-final victory against Brazil in Qatar on Friday?

## Is Labour really back in business?
 - [https://www.bbc.co.uk/news/uk-politics-63911618?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63911618?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 20:15:44+00:00

Labour has made its latest pitch to business. Did it convince them the party is a government-in-waiting?

## Ros Atkins On... Why the UK has approved a new coal mine
 - [https://www.bbc.co.uk/news/uk-63909561?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63909561?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 19:52:48+00:00

The proposed mine would dig up coking coal for steel production in the UK and across the world.

## Schengen: No EU border-free zone for Romania and Bulgaria
 - [https://www.bbc.co.uk/news/world-europe-63905113?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63905113?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 19:24:04+00:00

EU ministers vote to admit Croatia to the Schengen zone, but Romania and Bulgaria must wait.

## UK government may challenge Scottish gender change law
 - [https://www.bbc.co.uk/news/uk-politics-63909309?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63909309?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 19:16:44+00:00

Legally changing gender is to become easier in Scotland but Westminster is not happy about the move.

## Harry Dunn: Anne Sacoolas gets suspended jail term for fatal crash
 - [https://www.bbc.co.uk/news/uk-england-northamptonshire-63891657?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-northamptonshire-63891657?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 18:55:21+00:00

As US citizen Anne Sacoolas is sentenced, the 19-year-old's family say justice is "complete".

## Harry Dunn: Teen's death case explained in under 3 minutes
 - [https://www.bbc.co.uk/news/uk-63904706?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63904706?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 18:45:33+00:00

The BBC's home and legal correspondent Dominic Casciani explains the case in under three minutes.

## Girl band Flo win the Brits rising star award
 - [https://www.bbc.co.uk/news/entertainment-arts-63905399?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63905399?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 18:31:13+00:00

The London-based trio follow in the footsteps of previous winners Sam Fender, Celeste and Tom Odell.

## Pope breaks down in tears over war in Ukraine
 - [https://www.bbc.co.uk/news/world-europe-63911202?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63911202?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 18:20:36+00:00

Pope Francis stops mid-prayer as he starts crying while talking about the suffering of Ukrainians.

## Pakistan v England: Marcus Trescothick says Ben Stokes' team 'just getting started'
 - [https://www.bbc.co.uk/sport/cricket/63901537?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63901537?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 18:00:34+00:00

England are "just getting started" with their thrilling results and performances, according to assistant coach Marcus Trescothick.

## How the Brittney Griner prisoner swap with Russia was done
 - [https://www.bbc.co.uk/news/world-us-canada-63908670?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63908670?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 17:55:49+00:00

The US and Russia were willing to talk despite worsening relations - but there were limits to the deal.

## How to check if your Instagram posts are being hidden
 - [https://www.bbc.co.uk/news/technology-63907699?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63907699?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 17:51:57+00:00

Instagram unveils a new tool that will allow users to see if they have been shadow banned.

## Quiz of the week: Who did Julia Roberts wear on a dress?
 - [https://www.bbc.co.uk/news/world-63902792?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-63902792?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 17:45:43+00:00

How closely have you been paying attention to what's been going on over the past seven days?

## Racism in cricket: England and Wales Cricket Board reviewed 208 discrimination cases in 2021
 - [https://www.bbc.co.uk/sport/cricket/63906382?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63906382?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 17:40:11+00:00

The England and Wales Cricket Board reviewed more than 200 complaints of alleged discrimination in 2021 as part of a new centralised investigation system.

## Harry Dunn: Justice for family three years after crash death
 - [https://www.bbc.co.uk/news/uk-england-northamptonshire-63328171?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-northamptonshire-63328171?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 17:30:53+00:00

The teenager's death in 2019 led to a diplomatic row between the US and British governments.

## Harry and Meghan's unseen video moments in 70 seconds
 - [https://www.bbc.co.uk/news/entertainment-arts-63907092?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63907092?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 17:19:21+00:00

The BBC's Jonny Dymond analyses the footage shared in Harry and Meghan's Netflix documentary.

## Ireland to return mummified remains and sarcophagus to Egypt
 - [https://www.bbc.co.uk/news/world-middle-east-63908027?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63908027?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 17:15:12+00:00

University College Cork plans to hand over the objects, which also include a sarcophagus, in 2023.

## Jet Black: 'Inspirational' drummer for the Stranglers dies aged 84
 - [https://www.bbc.co.uk/news/entertainment-arts-63904248?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63904248?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 17:11:01+00:00

The musician, who co-founded the band, played on tracks like Golden Brown, No More Heroes and Peaches.

## Nurses bitten and screens smashed - life in A&E
 - [https://www.bbc.co.uk/news/health-63905272?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-63905272?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 17:03:46+00:00

A shortage of beds and huge demand is causing severe overcrowding in A&amp;Es and long delays for treatment.

## UK banking rules face biggest shake-up in more than 30 years
 - [https://www.bbc.co.uk/news/business-63905505?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63905505?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 16:32:04+00:00

The government is expected to loosen rules introduced after the financial crisis in 2008.

## World Cup 2022: Netherlands boss Louis van Gaal's private cancer ordeal
 - [https://www.bbc.co.uk/sport/football/63759127?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63759127?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 16:04:45+00:00

Louis van Gaal is one of the most decorated managers in football, but his biggest challenge has been off the pitch since being diagnosed with cancer two years ago.

## Strep A linked to deaths of 15 children across UK
 - [https://www.bbc.co.uk/news/health-63903051?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-63903051?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 16:03:18+00:00

Most strep A infections are mild but cases of more severe, invasive strep A infections - whilst rare - are rising.

## World Cup 2022: England v France - Gareth Southgate's ability is underestimated, says Kalvin Phillips
 - [https://www.bbc.co.uk/sport/football/63906490?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63906490?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 15:48:36+00:00

England manager Gareth Southgate is not given enough credit for the job he has done, says midfielder Kalvin Phillips.

## Putin vows to continue hitting Ukraine's power grid
 - [https://www.bbc.co.uk/news/world-europe-63907803?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63907803?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 15:35:17+00:00

The Russian president has vowed to continue attacking Ukraine's energy infrastructure.

## The Meghan and Harry selfies we've never seen before
 - [https://www.bbc.co.uk/news/in-pictures-63902679?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-63902679?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 15:03:21+00:00

Meghan and Harry's Netflix series featured a number of selfies of the pair, here are some of the best.

## World Cup 2022: Croatia v Brazil & Netherlands v Argentina in BBC's 'Fabulous Friday'
 - [https://www.bbc.co.uk/sport/football/63889208?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63889208?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 15:00:35+00:00

Two appetizing showdowns - Croatia v Brazil and Netherlands v Argentina - kick off the World Cup quarter-final stage on Friday, and you can watch it all on the BBC.

## World Cup 2022: Qatar tournament chief criticised for migrant worker death comments
 - [https://www.bbc.co.uk/sport/football/63904952?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63904952?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 14:42:44+00:00

The Qatar World Cup chief is criticised for saying "death is a natural part of life" when asked about a migrant worker's death at the tournament.

## Tory MP Julian Knight suspended after sex assault allegation made to police
 - [https://www.bbc.co.uk/news/uk-politics-63904774?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63904774?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 13:46:18+00:00

Julian Knight has been suspended as a Conservative MP after a report to the Metropolitan Police.

## Fake Covid protection kits: How my undercover work helped convict preacher
 - [https://www.bbc.co.uk/news/uk-england-london-63872317?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-63872317?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 13:13:57+00:00

Evidence gathered by BBC reporter Guy Lynn helped convict Bishop Climate Wiseman in court.

## Griner: Russia frees US basketball star in swap with arms dealer Bout
 - [https://www.bbc.co.uk/news/world-europe-63905112?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63905112?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 13:11:53+00:00

The US and Russia swap jailed basketball star Brittney Griner for notorious arms dealer Viktor Bout.

## Harry and Meghan: What to look out for in the Netflix series
 - [https://www.bbc.co.uk/news/uk-63902533?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63902533?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 13:04:49+00:00

The first episodes of Harry and Meghan's new documentary have dropped, here's what to look out for.

## Celine Dion reveals incurable health condition
 - [https://www.bbc.co.uk/news/entertainment-arts-63904242?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63904242?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 12:59:12+00:00

The star has Stiff Person Syndrome, a neurological disorder with features of an autoimmune disease.

## Harry and Meghan: That sigh of relief? It's the Palace watching Netflix
 - [https://www.bbc.co.uk/news/uk-63899921?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63899921?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 12:52:40+00:00

There were no bombshells about the Royal Family in the first half of the Harry and Meghan series.

## World Cup 2022: Spain boss Luis Enrique leaves role after last-16 exit
 - [https://www.bbc.co.uk/sport/football/63885001?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63885001?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 12:12:20+00:00

Luis Enrique leaves his role as Spain manager after they are knocked out of the World Cup by Morocco.

## Met officer charged with false imprisonment of woman
 - [https://www.bbc.co.uk/news/uk-england-london-63903676?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-63903676?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 12:02:16+00:00

PC Sam Grigg is set to appear in court after an alleged offence in south-west London.

## Gary Ballance: Yorkshire release ex-England batter from contract
 - [https://www.bbc.co.uk/sport/cricket/63900979?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63900979?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 11:54:14+00:00

Yorkshire release ex-England batter Gary Ballance from his contract, two years before it was due to end.

## Cristiano Ronaldo: Portugal deny that captain threatened to leave World Cup squad
 - [https://www.bbc.co.uk/sport/football/63901332?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63901332?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 11:38:42+00:00

The Portuguese Football Federation (FPF) denies that Cristiano Ronaldo threatened to leave the World Cup after Portugal's win over Switzerland.

## World Cup 2022: Who will win the Golden Boot - vote now
 - [https://www.bbc.co.uk/sport/football/63902172?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63902172?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 11:24:27+00:00

Can anyone catch Kylian Mbappe in the race for the World Cup Golden Boot? Vote for who you think will finish as top scorer in Qatar.

## Record alcohol deaths from pandemic drinking
 - [https://www.bbc.co.uk/news/health-63902852?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-63902852?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 11:21:37+00:00

The number of people dying rose by 27% between 2019 and 2021, to more than 9,000.

## Airlines plan to operate all flights despite strikes
 - [https://www.bbc.co.uk/news/business-63901482?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63901482?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 11:04:17+00:00

Around 1,000 UK airport border staff will strike over the Christmas period.

## Harry and Meghan reveal Archie's favourite song in Netflix documentary
 - [https://www.bbc.co.uk/news/uk-63901336?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63901336?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 10:29:27+00:00

And, luckily for them, it happens to be one sung by one of the couple's best friends - Elton John.

## Jersey fishing boat believed to have sunk after collision
 - [https://www.bbc.co.uk/news/world-europe-jersey-63901142?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-jersey-63901142?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 09:47:55+00:00

A major search operation is under way after a collision involving a ferry.

## Harry and Meghan Netflix: First three episodes released
 - [https://www.bbc.co.uk/news/uk-63901542?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63901542?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 09:42:29+00:00

The first three episodes of the six-part bombshell series Harry & Meghan have been released.

## Harry and Meghan Netflix: I sacrificed everything to join my wife
 - [https://www.bbc.co.uk/news/uk-63899515?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63899515?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 09:09:21+00:00

The first three episodes of the six-part series titled "Harry & Meghan" are released on Netflix.

## Haverfordwest paddleboarder deaths 'tragic and avoidable'
 - [https://www.bbc.co.uk/news/uk-wales-63895296?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-63895296?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 08:59:09+00:00

The leaders of a trip which killed four people did not have the necessary training, a report says.

## Another Morocco shock? Sutton's World Cup quarter-final predictions
 - [https://www.bbc.co.uk/sport/football/63851426?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63851426?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 08:55:54+00:00

BBC Sport's football expert Chris Sutton predicts the scores for the four World Cup quarter-finals in Qatar.

## Li Wenliang: Chinese pour hearts out on Covid martyr's page
 - [https://www.bbc.co.uk/news/world-asia-china-63898170?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-63898170?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 08:24:06+00:00

Thousands are leaving emotional comments on the page of a doctor who sounded the Covid alarm.

## Pakistan v England: Mark Wood returns but Ben Foakes misses out in Multan
 - [https://www.bbc.co.uk/sport/cricket/63876920?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63876920?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 08:23:27+00:00

Pace bowler Mark Wood will return to the England team for the second Test against Pakistan, starting on Friday.

## Obituary: Sqn Ldr George 'Johnny' Johnson
 - [https://www.bbc.co.uk/news/uk-40497471?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-40497471?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 08:12:31+00:00

The last survivor of the famous Dambusters raid of WW2.

## Iran carries out first execution over anti-government protests
 - [https://www.bbc.co.uk/news/world-middle-east-63900099?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63900099?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 08:06:04+00:00

Mohsen Shekari was hanged after being convicted of "enmity against God", state media report.

## Dutch Grand Prix: Formula 1 extends contract until 2025
 - [https://www.bbc.co.uk/sport/formula1/63899618?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/63899618?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 07:56:16+00:00

Formula 1 will continue to race in the Netherlands until at least 2025 after the Dutch Grand Prix at Zandvoort signed an extended contract.

## Pedro Castillo: Peru's ousted president detained by police in Lima
 - [https://www.bbc.co.uk/news/world-latin-america-63899457?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-63899457?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 07:54:07+00:00

Local media report that Pedro Castillo has been moved to a police-run prison following his arrest.

## Sexual harassment: Could the 'bystander effect' be the answer?
 - [https://www.bbc.co.uk/news/newsbeat-63786034?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-63786034?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 07:53:27+00:00

Authorities hope the "bystander effect" and new guidelines will reduce unwanted advances in public.

## Dambuster Johnny Johnson dies aged 101
 - [https://www.bbc.co.uk/news/uk-england-bristol-63899393?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-63899393?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 07:24:17+00:00

Sq Ldr George 'Johnny' Johnson was part of the World War Two operation involving bouncing bombs.

## Netherlands v Argentina: Dennis Bergkamp scores iconic goal in 1998 World Cup
 - [https://www.bbc.co.uk/sport/av/football/63854669?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63854669?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 06:53:18+00:00

Highlights of the 1998 World Cup quarter-final between Netherlands and Argentina at Stade Velodrome in Marseille.

## World Cup 2022: Top 10 greatest World Cup goals
 - [https://www.bbc.co.uk/sport/football/63119496?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63119496?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 06:30:48+00:00

The World Cup's greatest goals are ranked by Gary Lineker, Alan Shearer and Micah Richards in the Match of The Day: Top 10 podcast.

## World Cup 2022: England v France - Raheem Sterling asks FA to look at him returning to Qatar for quarter-final
 - [https://www.bbc.co.uk/sport/football/63895125?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63895125?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 06:23:28+00:00

Raheem Sterling asks the FA to look into him re-joining the England squad at the World Cup in Qatar, according to a source close to the player.

## Remarkable space blast identified as black hole collision
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-63887870?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-63887870?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 06:09:22+00:00

Scientists describe the minute-long blast as "remarkable".

## World Cup 2022: How French commentators described Olivier Giroud and Kylian Mbappe's goals against Poland
 - [https://www.bbc.co.uk/sport/av/football/63862534?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63862534?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 06:03:26+00:00

Listen to commentary from French broadcaster TF1 as Olivier Giroud becomes France's leading men's scorer and Kylian Mbappe scores twice in their 3-1 last-16 win over Poland at the World Cup.

## US state sues Chinese-owned TikTok over data
 - [https://www.bbc.co.uk/news/business-63897751?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63897751?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 04:38:39+00:00

The app is accused of deceiving users over China's access to data and exposing kids to mature content.

## Umar Patek: Anger and fear in Australia as Bali bomber freed
 - [https://www.bbc.co.uk/news/world-australia-63883431?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-63883431?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 03:15:52+00:00

Survivors of the 2002 attacks tell the BBC they don't believe Umar Patek has been deradicalised.

## Why this Trump loyalist is willing to serve months in Rikers prison
 - [https://www.bbc.co.uk/news/world-us-canada-63893268?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63893268?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 03:01:32+00:00

The former president's family business is sticking by the man whose evidence saw it convicted of tax crimes. Why?

## Elon Musk turns Twitter into 'hotel' for staff
 - [https://www.bbc.co.uk/news/technology-63897608?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63897608?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 02:06:14+00:00

One photo shows a double room with wardrobe and slippers, as Elon Musk seeks to instil a "hardcore" work culture.

## Qatar: Meet the acts lighting up the World Cup off the pitch
 - [https://www.bbc.co.uk/news/world-63879080?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-63879080?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:50:34+00:00

Outside the stadiums and on the streets, music and dance acts from around the globe are keeping fans entertained long after the final whistle.

## Cost of Living: How to talk to children about Christmas
 - [https://www.bbc.co.uk/news/uk-63861940?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63861940?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:46:01+00:00

Some hints and tips to help you manage your children's Christmas expectations.

## Tell Me Everything: The darkly comic drama about teenage depression
 - [https://www.bbc.co.uk/news/entertainment-arts-63375753?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63375753?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:42:57+00:00

The ITVX series tackles a serious subject with a big dollop of searing British humour.

## Ministers consider tougher curbs on strike action
 - [https://www.bbc.co.uk/news/uk-politics-63897640?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63897640?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:35:10+00:00

The government is exploring the idea of stopping some emergency service workers from walking out.

## World Cup 2022: Could Morocco win for Africa?
 - [https://www.bbc.co.uk/news/world-africa-63885646?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-63885646?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:21:11+00:00

Morocco stand a good chance of making history at the World Cup by bringing the trophy to Africa.

## First King Charles 50p coins enter circulation
 - [https://www.bbc.co.uk/news/business-63888781?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63888781?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:12:12+00:00

Anyone receiving change in post offices across the UK may get a King Charles 50p coin for the first time.

## 'Rail strikes mean I won't see my son over Christmas'
 - [https://www.bbc.co.uk/news/business-63877501?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63877501?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:11:13+00:00

Thousands of people face disruption to their festive travel plans due to railway strikes.

## Women's basketball: ‘I’ve been spat at in the face for the colour of my skin’
 - [https://www.bbc.co.uk/news/world-africa-63841874?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-63841874?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:06:53+00:00

Sarah Chan has overcome racism and violence to become the first woman to manage African scouting for an NBA team.

## Indonesia 'sex ban': Criminal code changes threaten other freedoms
 - [https://www.bbc.co.uk/news/world-asia-63885435?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63885435?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:05:40+00:00

There are concerns the revised criminal code could threaten democracy, human rights and free speech.

## ‘Doctors fitted a contraceptive coil without my consent’
 - [https://www.bbc.co.uk/news/world-europe-63863088?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63863088?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:05:13+00:00

A Danish investigation will look at a historic scandal in Greenland, but women tell the BBC of recent involuntary contraception.

## 'We haven't had a single penny from the Post Office'
 - [https://www.bbc.co.uk/news/business-63889700?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63889700?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:02:26+00:00

Three years after winning in the High Court, hundreds of sub-postmasters are still waiting for compensation.

## 'A&E is absolute chaos - I spent 15 hours on a trolley'
 - [https://www.bbc.co.uk/news/health-63890726?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-63890726?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:02:02+00:00

A shortage of beds is causing severe overcrowding in A&amp;E and putting patients at risk, doctors warn.

## Should countries try to do everything themselves?
 - [https://www.bbc.co.uk/news/business-63780833?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63780833?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:01:52+00:00

In recent years, some world leaders have been making arguments for countries becoming more self-reliant.

## World Cup 2022: Vittorio Pozzo's legacy and a record that might finally be under threat
 - [https://www.bbc.co.uk/sport/football/63873325?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63873325?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-12-08 00:01:04+00:00

Vittorio Pozzo is the only coach to have won successive men's World Cup titles but remains relatively little known - for one reason.


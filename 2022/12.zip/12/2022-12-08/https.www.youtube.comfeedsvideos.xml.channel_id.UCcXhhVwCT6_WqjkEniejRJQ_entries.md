# Source:Wintergatan, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcXhhVwCT6_WqjkEniejRJQ, language:en-US

## This Design Trick Surprised Me!
 - [https://www.youtube.com/watch?v=TEKZWiKelCU](https://www.youtube.com/watch?v=TEKZWiKelCU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcXhhVwCT6_WqjkEniejRJQ
 - date published: 2022-12-08 15:58:19+00:00

Well Hello There! Happy Camper here, not only because this video was so satisfying to make but also because our friend Hannes3000 have started a new youtube series on his youtube channel TRAINERDS!

Trainerds is a wholesome community inspired by Hannes own health journey. Hannes is showing that excercising is for anyone, not limited to the gym elites. (Although Hannes himself is becoming a gym elite but that hasn´t made him lost connection with us other mere mortals so that´s all good haha) Hannes has inspired me personally to start excercising and my brain is forever thankful. Now he is about to inspire people all over the internet in the same way, head over and take a peak at the first two episodes here:

HOW TO START A TRAINING ROUTINE
https://www.youtube.com/watch?v=Bft31oO2fys

HOW TO BUILD MUSCLES
https://www.youtube.com/watch?v=K2ETMXBSzIM

The Trainerds Discord community is also already blooming with a very friendly and supportive culture, so if you are looking for friendly training buddies across the interwebs, check that out.
https://discord.gg/3mAdmvyRAz

But also how SWEET, the revenge. ;)

Support Wintergatan: ► https://www.wintergatan.net

This Design Trick Surprised Me!
#4k #wintergatan
—
MUSIC DOWNLOADS ► https://wintergatan.bandcamp.com 
WINTERGATAN RECORDS ► http://www.wintergatan.net/#/shop
SPOTIFY ► http://bit.ly/2oKxXWd 
ITUNES ► http://apple.co/2ntWNsZ 
MERCH ► https://teespring.com/stores/wintergatan
DISCORD ► https://discord.gg/wintergatan
SECOND OFFICIAL CHANNEL:► https://www.youtube.com/c/Wintergatan2021
—


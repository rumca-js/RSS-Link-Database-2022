## Coffeezilla claims FTX founder Sam Bankman-Fried admitted “fraud” in interview
 - [https://www.dexerto.com/entertainment/coffeezilla-claims-ftx-founder-sam-bankman-fried-admitted-fraud-in-interview-2005507/](https://www.dexerto.com/entertainment/coffeezilla-claims-ftx-founder-sam-bankman-fried-admitted-fraud-in-interview-2005507/)
 - RSS feed: https://www.dexerto.com
 - date published: 2022-12-08 14:11:59+00:00

Coffeezilla claims FTX founder Sam Bankman-Fried admitted “fraud” in interview


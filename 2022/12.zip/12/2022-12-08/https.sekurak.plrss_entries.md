# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Policjanci z Otwocka zatrzymali obywatela Indii. Miał podszywać się pod kontrahentów firm, podrzucając lewy rachunek bankowy…
 - [https://sekurak.pl/policjanci-z-otwocka-zatrzymali-obywatela-indii-mial-podszywac-sie-pod-kontrahentow-firm-podrzucajac-lewy-rachunek-bankowy/](https://sekurak.pl/policjanci-z-otwocka-zatrzymali-obywatela-indii-mial-podszywac-sie-pod-kontrahentow-firm-podrzucajac-lewy-rachunek-bankowy/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2022-12-08 19:43:33+00:00

<p>Policja w Otwocku donosi: W ramach nowej metody okradania firm tzw. „na fałszywy numer rachunku bankowego” przestępcy podszywają się pod przedstawicieli firmy będącej kontrahentem spółki, która ma stać się ofiarą kradzieży. Następnie „pracownicy partnera biznesowego” kierują do firm, które z nią współpracują wiadomości o zmianie numeru rachunku. Metoda raczej nowa...</p>
<p>Artykuł <a href="https://sekurak.pl/policjanci-z-otwocka-zatrzymali-obywatela-indii-mial-podszywac-sie-pod-kontrahentow-firm-podrzucajac-lewy-rachunek-bankowy/" rel="nofollow">Policjanci z Otwocka zatrzymali obywatela Indii. Miał podszywać się pod kontrahentów firm, podrzucając lewy rachunek bankowy&#8230;</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Badacze bezpieczeństwa przez przypadek załatwili duży przestępczy botnet
 - [https://sekurak.pl/badacze-bezpieczenstwa-przez-przypadek-zalatwili-duzy-przestepczy-botnet/](https://sekurak.pl/badacze-bezpieczenstwa-przez-przypadek-zalatwili-duzy-przestepczy-botnet/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2022-12-08 16:09:21+00:00

<p>W listopadzie badacze z zespołu SIRT Akamai namierzyli malware KmdsBot atakujący systemy Windows i Linux, wykrywając słabo zabezpieczone usługi terminalowe (domyślne lub proste dane logowania). Po udanym ataku, zainfekowane urządzenia są wykorzystywane do kopania kryptowalut i uruchamiania dystrybuowanych ataków Denial of Service (DoS). Na nieszczęście przestępców botnet nie posiadał umiejętności...</p>
<p>Artykuł <a href="https://sekurak.pl/badacze-bezpieczenstwa-przez-przypadek-zalatwili-duzy-przestepczy-botnet/" rel="nofollow">Badacze bezpieczeństwa przez przypadek załatwili duży przestępczy botnet</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Apple wprowadza dodatkowy program ochrony: szyfrowane end2end backupów w iCloud, klucze sprzętowe 2FA do zabezpieczania konta applowego, zaawansowane wykrywanie ataków podsłuchu wiadomości…
 - [https://sekurak.pl/apple-wprowadza-dodatkowy-program-ochrony-szyfrowane-end2end-backupow-w-icloud-klucze-sprzetowe-2fa-do-zabezpieczania-konta-applowego-zaawansowane-wykrywanie-atakow-podsluchu-wiadomosci/](https://sekurak.pl/apple-wprowadza-dodatkowy-program-ochrony-szyfrowane-end2end-backupow-w-icloud-klucze-sprzetowe-2fa-do-zabezpieczania-konta-applowego-zaawansowane-wykrywanie-atakow-podsluchu-wiadomosci/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2022-12-08 15:51:46+00:00

<p>Jest to kolejny krok, poza wprowadzonym w iOS 16 trybem zabunkrowanym (&#8222;lockdown mode&#8222;). Jeśli chodzi o iCloud to będzie możliwość szyfrowania end2end prawie wszystkiego. End2end czyli nawet Apple / ktoś kto włamie się do ich clouda / służby &#8211; nie będą miały wglądu w przechowywane dane. Dotyczy to również kopii...</p>
<p>Artykuł <a href="https://sekurak.pl/apple-wprowadza-dodatkowy-program-ochrony-szyfrowane-end2end-backupow-w-icloud-klucze-sprzetowe-2fa-do-zabezpieczania-konta-applowego-zaawansowane-wykrywanie-atakow-podsluchu-wiadomosci/" rel="nofollow">Apple wprowadza dodatkowy program ochrony: szyfrowane end2end backupów w iCloud, klucze sprzętowe 2FA do zabezpieczania konta applowego, zaawansowane wykrywanie ataków podsłuchu wiadomości&#8230;</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Powstanie baza umożliwiająca zastrzec PESEL. Nikt tak łatwo nie weźmie kredytu czy abonamentu na telefon na nasze wykradzione dane …
 - [https://sekurak.pl/powstanie-baza-umozliwiajaca-zastrzec-pesel-nikt-tak-latwo-nie-wezmie-kredytu-czy-abonamentu-na-telefon-na-nasze-wykradzione-dane/](https://sekurak.pl/powstanie-baza-umozliwiajaca-zastrzec-pesel-nikt-tak-latwo-nie-wezmie-kredytu-czy-abonamentu-na-telefon-na-nasze-wykradzione-dane/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2022-12-08 09:09:03+00:00

<p>Propozycję stworzenia rejestru wysunął Minister cyfryzacji. Jak donosi Gazeta Prawna: [przepisy] umożliwią każdemu szybkie zastrzeganie swego numeru PESEL w razie wycieku czy kradzieży danych osobowych. Będzie to możliwe poprzez aplikację mObywatel, ale również w tradycyjnej formie, na piśmie, w dowolnym urzędzie gminy. Dodatkowo: [&#8230;] każdy będzie mógł za darmo zastrzec...</p>
<p>Artykuł <a href="https://sekurak.pl/powstanie-baza-umozliwiajaca-zastrzec-pesel-nikt-tak-latwo-nie-wezmie-kredytu-czy-abonamentu-na-telefon-na-nasze-wykradzione-dane/" rel="nofollow">Powstanie baza umożliwiająca zastrzec PESEL. Nikt tak łatwo nie weźmie kredytu czy abonamentu na telefon na nasze wykradzione dane &#8230;</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>


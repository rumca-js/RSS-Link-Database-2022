# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Makaya McCraven - Dream Another (Live on KEXP)
 - [https://www.youtube.com/watch?v=bPrRazHF5tE](https://www.youtube.com/watch?v=bPrRazHF5tE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-09 00:00:00+00:00

http://KEXP.ORG presents Makaya McCraven performing “Dream Another” live in the KEXP studio. Recorded October 25, 2022.

Makaya McCraven - Drums
Junius Paul - Bass
Jeff Parker - Guitar
De’Sean Jones - Saxophone / Flute / EWI

Host: Marco Collins
Audio Engineer: Julian Martlew & Kevin Suggs
Audio Mixer: Julian Martlew
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Luke Knecht
Editor: Jim Beckmann

https://www.makayamccraven.com
http://kexp.org

## Makaya McCraven - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Y_BE_gi4YkA](https://www.youtube.com/watch?v=Y_BE_gi4YkA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-09 00:00:00+00:00

http://KEXP.ORG presents Makaya McCraven performing live in the KEXP studio. Recorded October 25, 2022.

Songs:
Dream Another
In These Times
The Knew Untitled
This Place That Place

Makaya McCraven - Drums
Junius Paul - Bass
Jeff Parker - Guitar
De’Sean Jones - Saxophone / Flute / EWI

Host: Marco Collins
Audio Engineer: Julian Martlew & Kevin Suggs
Audio Mixer: Julian Martlew
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Luke Knecht
Editor: Jim Beckmann

https://www.makayamccraven.com
http://kexp.org

## Makaya McCraven - In These Times (Live on KEXP)
 - [https://www.youtube.com/watch?v=MmZqtrsN6Rk](https://www.youtube.com/watch?v=MmZqtrsN6Rk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-09 00:00:00+00:00

http://KEXP.ORG presents Makaya McCraven performing “In These Times” live in the KEXP studio. Recorded October 25, 2022.

Makaya McCraven - Drums
Junius Paul - Bass
Jeff Parker - Guitar
De’Sean Jones - Saxophone / Flute / EWI

Host: Marco Collins
Audio Engineer: Julian Martlew & Kevin Suggs
Audio Mixer: Julian Martlew
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Luke Knecht
Editor: Jim Beckmann

https://www.makayamccraven.com
http://kexp.org

## Makaya McCraven - The Knew Untitled (Live on KEXP)
 - [https://www.youtube.com/watch?v=nfc-o4FBA-A](https://www.youtube.com/watch?v=nfc-o4FBA-A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-09 00:00:00+00:00

http://KEXP.ORG presents Makaya McCraven performing “The Knew Untitled” live in the KEXP studio. Recorded October 25, 2022.

Makaya McCraven - Drums
Junius Paul - Bass
Jeff Parker - Guitar
De’Sean Jones - Saxophone / Flute / EWI

Host: Marco Collins
Audio Engineer: Julian Martlew & Kevin Suggs
Audio Mixer: Julian Martlew
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Luke Knecht
Editor: Jim Beckmann

https://www.makayamccraven.com
http://kexp.org

## Makaya McCraven - This Place That Place (Live on KEXP)
 - [https://www.youtube.com/watch?v=nsg88xpsm4s](https://www.youtube.com/watch?v=nsg88xpsm4s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-12-09 00:00:00+00:00

http://KEXP.ORG presents Makaya McCraven performing “This Place That Place” live in the KEXP studio. Recorded October 25, 2022.

Makaya McCraven - Drums
Junius Paul - Bass
Jeff Parker - Guitar
De’Sean Jones - Saxophone / Flute / EWI

Host: Marco Collins
Audio Engineer: Julian Martlew & Kevin Suggs
Audio Mixer: Julian Martlew
Audio Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Luke Knecht
Editor: Jim Beckmann

https://www.makayamccraven.com
http://kexp.org


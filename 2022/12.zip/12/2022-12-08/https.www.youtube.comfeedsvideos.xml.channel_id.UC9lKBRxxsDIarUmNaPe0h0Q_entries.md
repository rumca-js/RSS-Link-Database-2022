# Source:Sorelle Amore Finance, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC9lKBRxxsDIarUmNaPe0h0Q, language:en-US

## You are being LIED to about inflation (here's the REAL cause)
 - [https://www.youtube.com/watch?v=px4LkyuMs0I](https://www.youtube.com/watch?v=px4LkyuMs0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC9lKBRxxsDIarUmNaPe0h0Q
 - date published: 2022-12-08 14:30:52+00:00

✉️ OUR NEWSLETTER: https://www.abundantia.co/
📚 OUR COURSE/MEMBERSHIP: http://jointheorder.co/

You are being lied to about inflation. In fact, you're being told two main lies: the first is how high inflation actually is. But the second is who is truly responsible for a large part of inflation happening.

When we hear about inflation, we're told that it's primarily caused by the simple economics of money in the system. More money is printed, resulting in dollars becoming devalued, resulting in stuff getting more expensive. And yes, this is definitely a part of the inflation equation. However, there's a part that's often missed that in many cases, causes prices around us to rise as well.

To put it simply, it's all about corporate greed. And the desire of many companies to use inflation as a cover story for rising prices, so they can line their pockets. It's only possible they can do this due to lack of competition, which is something we don't think we have in today's world.

I'd love to hear your thoughts below.

0:00 - The big lies about inflation
0:55 - LIE 1: How high inflation really is
3:00 - The main narrative around inflation
3:26 - LIE 2: What is causing inflation
5:17 - Why competition is a myth
6:59 - Concentration of corporate power

► IMPORTANT LINKS:
Enter your email via the link below for free weekly lessons and insights into becoming financially free, investing, global tax and corporate structures, passports, residencies, and more.
JOIN: https://www.abundantia.co/

► SOCIAL MEDIA:
• Abundantia Instagram: @abundantia.co https://www.instagram.com/abundantia.co/
• Sorelle's Instagram: @sorelleamore  https://instagram.com/sorelleamore
• Leon's Instagram: @leonhill  https://instagram.com/leonhill
• Abundantia Twitter: https://twitter.com/abundantiaco
• Abundantia Facebook: http://facebook.com/abundantiafinance

Sorelle and Leon.
Founders, Abundantia

Liability Disclaimer: https://www.abundantia.co/disclaimer
*We may earn a commission if you buy any products or services via the links in this video's description. This video is not investment, financial, or legal advice. It may be incorrect, outdated, inaccurate, or reflect personal opinions. This video is for entertainment purposes only.

Presented by Sorelle Amore.
Written by Leon Hill.

#Inflation #PriceGouging #Inflation2022


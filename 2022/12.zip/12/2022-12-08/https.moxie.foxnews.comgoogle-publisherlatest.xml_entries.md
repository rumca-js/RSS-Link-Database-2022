# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Mississippi State running back Dillon Johnson trolls Mike Leach with transfer announcement
 - [https://www.foxnews.com/sports/mississippi-state-running-back-dillon-johnson-trolls-mike-leach-transfer-announcement](https://www.foxnews.com/sports/mississippi-state-running-back-dillon-johnson-trolls-mike-leach-transfer-announcement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 23:49:32+00:00

Mississippi State running back Dillon Johnson announced Wednesday his decision to enter the transfer portal after three seasons with the Bulldogs.

## I-Spy: Change your computer’s settings to stop programs spying on you
 - [https://www.foxnews.com/tech/spy-change-your-computers-settings-stop-programs-spying](https://www.foxnews.com/tech/spy-change-your-computers-settings-stop-programs-spying)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 23:46:55+00:00

Change the settings on your PC and Mac to restrict access to your camera, mic, and location.

## Idaho police hit with deluge of tips about Hyundai Elantra, now forwarding calls to FBI call center
 - [https://www.foxnews.com/us/idaho-police-hit-deluge-tips-hyundai-elantra-forwarding-calls-fbi-call-center](https://www.foxnews.com/us/idaho-police-hit-deluge-tips-hyundai-elantra-forwarding-calls-fbi-call-center)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 23:38:54+00:00

Calls to the Moscow Police Department's tipline will now be directed to an FBI call center better equipped to deal with the volume of information, authorities said.

## Iowa police say 'no evidence' found after excavation at alleged site where rumored serial killer dumped bodies
 - [https://www.foxnews.com/us/iowa-police-say-no-evidence-found-search-location-alleged-burial-site-rumored-serial-killer](https://www.foxnews.com/us/iowa-police-say-no-evidence-found-search-location-alleged-burial-site-rumored-serial-killer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 23:35:55+00:00

Iowa police said no evidence was found where authorities performed an excavation after a woman alleged that her father buried woman after killing them.

## Brother of Russia detainee Paul Whelan calls on US to be 'more assertive' after Griner trade
 - [https://www.foxnews.com/media/brother-russia-detainee-paul-whelan-calls-us-assertive-griner-trade](https://www.foxnews.com/media/brother-russia-detainee-paul-whelan-calls-us-assertive-griner-trade)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 23:30:09+00:00

The brother of U.S citizen Paul Whelan, currently being imprisoned in Russia, spoke out following the Brittney Griner-Viktor Bout trade earlier Thursday

## Air travel drama: Tall passenger who didn't buy additional legroom is chewed out on flight
 - [https://www.foxnews.com/lifestyle/air-travel-drama-tall-passenger-didnt-buy-legroom-chewed-out-flight](https://www.foxnews.com/lifestyle/air-travel-drama-tall-passenger-didnt-buy-legroom-chewed-out-flight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 23:20:47+00:00

Reddit users weighed in with support for a man who says he told a tall passenger on board a flight that he should have bought additional legroom from the airline due to his size.

## Former President Trump's office could be held in contempt of court over Mar-a-Lago documents probe: reports
 - [https://www.foxnews.com/politics/former-president-trumps-office-contempt-court-mar-a-lago-documents-reports](https://www.foxnews.com/politics/former-president-trumps-office-contempt-court-mar-a-lago-documents-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 23:09:37+00:00

The Department of Justice requested a U.S. District Court Judge hold Donald Trump's office in contempt of court for failing to comply with order to return all classified documents.

## 49ers' Trent Williams compares rookie Brock Purdy to Hall of Fame quarterback
 - [https://www.foxnews.com/sports/49ers-trent-williams-compares-rookie-brock-purdy-hall-fame-quarterback](https://www.foxnews.com/sports/49ers-trent-williams-compares-rookie-brock-purdy-hall-fame-quarterback)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 23:08:34+00:00

San Francisco 49ers veteran tackle Trent Williams likened rookie quarterback Brock Purdy to Hall of Famer Peyton Manning after Sunday's win over the Miami Dolphins.

## Seven more House Republicans threaten to oppose McCarthy without concessions on House rules
 - [https://www.foxnews.com/politics/seven-house-republicans-threaten-oppose-mccarthy-concessions-house-rules](https://www.foxnews.com/politics/seven-house-republicans-threaten-oppose-mccarthy-concessions-house-rules)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 23:01:08+00:00

Seven more members of the House Freedom Caucus are threatening to oppose Minority Leader Kevin McCarthy's ascension to speaker unless their demands are met.

## Idaho murders: Forensics expert questions 'urgency' in removing victims' personal belongings from crime scene
 - [https://www.foxnews.com/us/idaho-murders-forensics-expert-questions-urgency-removing-victims-personal-belongings-crime-scene](https://www.foxnews.com/us/idaho-murders-forensics-expert-questions-urgency-removing-victims-personal-belongings-crime-scene)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 23:00:32+00:00

University of Idaho students Ethan Chapin, 20, Kaylee Goncalves, 21, Xana Kernodle, 20, and 21-year-old Madison Mogen were stabbed several times and killed Nov. 13.

## 'SNL' alum Chris Kattan undergoes emergency surgery after being diagnosed with severe pneumonia
 - [https://www.foxnews.com/entertainment/snl-alum-chris-kattan-undergoes-emergency-surgery-after-being-diagnosed-severe-pneumonia](https://www.foxnews.com/entertainment/snl-alum-chris-kattan-undergoes-emergency-surgery-after-being-diagnosed-severe-pneumonia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 22:55:29+00:00

Chris Kattan is recovering in a hospital after undergoing emergency surgery in his battle with severe pneumonia. A source close to the "SNL" alum said he is "doing well."

## Yankees owner Hal Steinbrenner met Pope Francis before Aaron Judge signing
 - [https://www.foxnews.com/sports/yankees-owner-hal-steinbrenner-met-pope-francis-before-aaron-judge-signing](https://www.foxnews.com/sports/yankees-owner-hal-steinbrenner-met-pope-francis-before-aaron-judge-signing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 22:55:05+00:00

Yankees owner Hal Steinbrenner reportedly sealed the deal with Aaron Judge to return to the Bronx while on vacation in Italy. In fact, it came five days after meeting the Pope.

## ‘Putin outplayed Biden’ on Brittney Griner swap for 'Merchant of Death,' former Kremlin aide says
 - [https://www.foxnews.com/world/putin-outplayed-biden-brittney-griner-swap-merchant-death-former-kremlin-aide-says](https://www.foxnews.com/world/putin-outplayed-biden-brittney-griner-swap-merchant-death-former-kremlin-aide-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 22:39:58+00:00

A former close adviser to Russian President Vladimir Putin said President Joe Biden got 'outplayed' in the Brittney Griner prisoner swap.

## Nick Carter accused of raping an autistic fan in new lawsuit
 - [https://www.foxnews.com/entertainment/nick-carter-accused-raping-autistic-fan-new-lawsuit](https://www.foxnews.com/entertainment/nick-carter-accused-raping-autistic-fan-new-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 22:34:41+00:00

Shannon "Shay" Ruth accused Nick Carter of rape in a new lawsuit. The woman, now 39, alleged the Backstreet Boys member raped her when she was 17 in 2001.

## California university hosts 'kinky karaoke,' with 'kinky giveaways, HIV testing
 - [https://www.foxnews.com/us/california-university-hosts-kinky-karaoke-kinky-giveaways-hiv-testing](https://www.foxnews.com/us/california-university-hosts-kinky-karaoke-kinky-giveaways-hiv-testing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 22:03:27+00:00

California State University, Northridge's Pride Center held a "kinky karaoke" event in late November, where "kinky giveaways" were offered to participants.

## Weingarten slammed for tweet highlighting Brittney Griner’s race and sexuality after release: ‘complete clown'
 - [https://www.foxnews.com/media/weingarten-slammed-tweet-fixating-brittney-griners-race-sexuality-after-release-complete-clown](https://www.foxnews.com/media/weingarten-slammed-tweet-fixating-brittney-griners-race-sexuality-after-release-complete-clown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 22:00:57+00:00

Conservatives on Twitter called out Teachers' union boss Randi Weingarten for talking about Brittney Griner's sex and race after news of her release.

## Doggie condo? Stray dogs take shelter in makeshift homes on a sandy hill
 - [https://www.foxnews.com/lifestyle/doggie-condo-stray-dogs-take-shelter-makeshift-homes-sandy-hill](https://www.foxnews.com/lifestyle/doggie-condo-stray-dogs-take-shelter-makeshift-homes-sandy-hill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 21:59:11+00:00

A group of stray dogs were spotted digging makeshift burrows in a pile of leftover sand in Thailand — see their creation and how they're seeking shelter in their own "doggie condo."

## Prosecutors in Alex Murdaugh case allege motive for killing wife, son
 - [https://www.foxnews.com/us/prosecutors-alex-murdaugh-case-allege-motive-killing-wife-son](https://www.foxnews.com/us/prosecutors-alex-murdaugh-case-allege-motive-killing-wife-son)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 21:48:12+00:00

South Carolina prosecutors say Alex Murdaugh was motivated by the possible exposure of his decade-long financial crimes in murdering his wife and son to buy himself time and sympathy.

## Biden failing to ‘outcompete’ China, deserves ‘incomplete’ grade on foreign relations: Sen. Todd Young
 - [https://www.foxnews.com/politics/biden-failing-outcompete-china-incomplete-grade-on-foreign-relations-sen-todd-young](https://www.foxnews.com/politics/biden-failing-outcompete-china-incomplete-grade-on-foreign-relations-sen-todd-young)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 21:45:26+00:00

GOP Sen. Todd Young says the U.S. must ramp up development of "strategic technologies" to outcompete China, and the Biden administration needs to be bolder on the world stage.

## Brittney Griner 'represents the best of America,' White House says, silent on death of Border Patrol agent
 - [https://www.foxnews.com/politics/brittney-griner-represents-best-america-white-house-says-silent-death-border-patrol-agent](https://www.foxnews.com/politics/brittney-griner-represents-best-america-white-house-says-silent-death-border-patrol-agent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 21:33:56+00:00

The White House said Brittney Griner "represents the best of America," after agreeing on a prisoner exchange with Russia to swap the two-time Olympian with arms dealer Viktor Bout.

## Jenna Oretga filmed Netflix dance scene while experiencing symptoms of COVID: 'It's crazy'
 - [https://www.foxnews.com/entertainment/jenna-oretga-filmed-netflix-dance-scene-experiencing-symtoms-covid-crazy](https://www.foxnews.com/entertainment/jenna-oretga-filmed-netflix-dance-scene-experiencing-symtoms-covid-crazy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 21:33:06+00:00

Actress Jenna Ortega revealed during a magazine interview that she had filmed a dance scene for the Netflix show "Wednesday" while sick with COVID-19.

## Brittney Griner, Viktor Bout tarmac swap seen in video
 - [https://www.foxnews.com/sports/brittney-griner-viktor-bout-tarmac-swap-seen-video](https://www.foxnews.com/sports/brittney-griner-viktor-bout-tarmac-swap-seen-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 21:32:20+00:00

A video released Thursday showed the tarmac prisoner swap of Brittney Griner and Viktor Bout. Griner is a WNBA player and Bout is an arms dealer.

## Rand Paul vows GOP 'not done' with Fauci on COVID origins: 'He's been lying from the beginning'
 - [https://www.foxnews.com/media/rand-paul-vows-gop-fauci-covid-origins-lying-beginning](https://www.foxnews.com/media/rand-paul-vows-gop-fauci-covid-origins-lying-beginning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 21:30:59+00:00

Sen. Rand Paul, R-Ky., details efforts from Senate Republicans to investigate Dr. Anthony Fauci over the origins of COVID-19 and calls to pause gain-of-function research.

## AOC ethics probe is NY Democrat's latest brush with scandal
 - [https://www.foxnews.com/politics/aoc-ethics-probe-ny-democrats-latest-brush-scandal](https://www.foxnews.com/politics/aoc-ethics-probe-ny-democrats-latest-brush-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 21:30:48+00:00

The congressional ethics investigation into Rep. Alexandria Ocasio-Cortez is the New York Democrat's latest brush with scandal since being elected to the House.

## Hakeem Jeffries called Trump's 2016 election victory a 'hoax,' referred to him as 'so-called' president
 - [https://www.foxnews.com/politics/hakeem-jeffries-called-trumps-2016-election-victory-hoax-referred-him-so-called-president](https://www.foxnews.com/politics/hakeem-jeffries-called-trumps-2016-election-victory-hoax-referred-him-so-called-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 20:58:32+00:00

Incoming House Democratic Leader Rep. Hakeem Jeffries, D-N.Y., denied the legitimacy of "so-called" President Donald Trump's 2016 election victory, calling it a “hoax."

## WNBA learned Brittney Griner negotiations were 'intensifying' days before prisoner swap, commissioner says
 - [https://www.foxnews.com/sports/wnba-learned-brittney-griner-negotiations-intensifying-days-before-prisoner-swap-commissioner-says](https://www.foxnews.com/sports/wnba-learned-brittney-griner-negotiations-intensifying-days-before-prisoner-swap-commissioner-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 20:52:58+00:00

WNBA Commissioner Cathy Engelbert said Thursday the league learned earlier this week that negotiations for Brittney Griner's release were "intensifying."

## Gen Z congressman-elect laments being denied DC apartment due to 'really bad credit'
 - [https://www.foxnews.com/politics/gen-z-congressman-elect-laments-being-denied-dc-apartment-due-really-bad-credit](https://www.foxnews.com/politics/gen-z-congressman-elect-laments-being-denied-dc-apartment-due-really-bad-credit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 20:50:08+00:00

The newly elected congressman compared his situation to Rep. Alexandria Ocasio-Cortez who faced similar difficulties following her election victory in 2018.

## Boomer Esiason takes shot at Biden's prisoner swap for Brittney Griner: 'We look so pathetic'
 - [https://www.foxnews.com/sports/boomer-esiason-takes-shot-president-bidens-prisoner-swap-brittney-griner-we-look-so-pathetic](https://www.foxnews.com/sports/boomer-esiason-takes-shot-president-bidens-prisoner-swap-brittney-griner-we-look-so-pathetic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 20:39:16+00:00

While ex-NFL quarterback Boomer Esiason is happy Brittney Griner is heading home, he ripped President Biden's decision to swap Viktor Bout, nicknamed the 'Merchant of Death.'

## Aerosmith cancels final shows in Vegas due to Steven Tyler's health
 - [https://www.foxnews.com/entertainment/aerosmith-cancels-final-shows-vegas-due-steven-tylers-health](https://www.foxnews.com/entertainment/aerosmith-cancels-final-shows-vegas-due-steven-tylers-health)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 20:34:00+00:00

Aerosmith canceled its final two shows in 2022 due to "the advice of doctors" for Steven Tyler. The rock band was scheduled to perform dates in Las Vegas.

## Michigan doctor facing sexual conduct charges in relation to alleged assault of 14-year-old boy
 - [https://www.foxnews.com/us/michigan-doctor-facing-sexual-conduct-charges-relation-alleged-assault-14-year-old-boy](https://www.foxnews.com/us/michigan-doctor-facing-sexual-conduct-charges-relation-alleged-assault-14-year-old-boy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 20:33:37+00:00

A Michigan doctor faces sexual conduct charges in relation to the assault of a 14-year-old boy in January 2020 and is being held in jail on a bond of over $2 million.

## 'The View' co-host admits Griner trade wasn't 'equal swap' for US
 - [https://www.foxnews.com/media/the-view-co-host-admits-griner-trade-wasnt-equal-swap-us](https://www.foxnews.com/media/the-view-co-host-admits-griner-trade-wasnt-equal-swap-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 20:30:59+00:00

Alyssa Farah Griffin said Thursday the U.S. trade for Brittney Griner was "not an equal swap" and that released arms dealer Viktor Bout was "plotting" against Americans.

## Idaho murders: Slain university students' neighbor says front door left wide open after attacks
 - [https://www.foxnews.com/us/idaho-murders-slain-university-students-neighbor-says-front-door-left-wide-open-after-attacks](https://www.foxnews.com/us/idaho-murders-slain-university-students-neighbor-says-front-door-left-wide-open-after-attacks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 20:30:59+00:00

A neighbor of four slain University of Idaho students killed in their sleep claims that they saw the victims' front door wide open hours after the slayings.

## Jessica Simpson cozies up in Aspen with husband, family on winter vacation: ‘Snow bunnies’
 - [https://www.foxnews.com/entertainment/jessica-simpson-cozies-up-aspen-husband-family-winter-vacation-snow-bunnies](https://www.foxnews.com/entertainment/jessica-simpson-cozies-up-aspen-husband-family-winter-vacation-snow-bunnies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 20:30:35+00:00

"Dukes of Hazzard" actress Jessica Simpson highlighted her family's winter getaway vacation in Aspen, Colorado, as her sister Ashlee Simpson and their family joined the holiday.

## White House counters Saudi claim on Brittney Griner negotiations, says talks were between US, Russia
 - [https://www.foxnews.com/politics/white-house-counters-saudi-claim-on-brittney-griner-negotiations-says-talks-were-between-us-russia](https://www.foxnews.com/politics/white-house-counters-saudi-claim-on-brittney-griner-negotiations-says-talks-were-between-us-russia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:55:16+00:00

The White House countered a joint statement released by the UAE and Saudi Arabia and said Brittney Griner's release was negotiated only by the U.S. and Russia.

## SCOTUS whistleblower admits incident in his book 'possibly' did not happen, then Jordan proves it didn't
 - [https://www.foxnews.com/politics/scotus-whistleblower-admits-incident-he-recalled-in-his-book-may-not-have-happened-then-jordan-proves-it-di](https://www.foxnews.com/politics/scotus-whistleblower-admits-incident-he-recalled-in-his-book-may-not-have-happened-then-jordan-proves-it-di)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:52:05+00:00

Rev. Robert Schenck, who told Chief Justice John Roberts that a 2014 decision by Justice Samuel Alito leaked in advance, admitted that a story from his book may not be true.

## Celine Dion's long-lasting career: What to know about the Canadian singer
 - [https://www.foxnews.com/entertainment/celine-dions-long-lasting-career-what-know-about-canadian-singer](https://www.foxnews.com/entertainment/celine-dions-long-lasting-career-what-know-about-canadian-singer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:51:42+00:00

Fox News Digital looks at Celine Dion's career highs and lows after the Canadian musician revealed she'd been diagnosed with an incurable neurological disease known as stiff person syndrome.

## White House ‘not going to apologize’ for releasing Merchant of Death as critics rail 'bad deal'
 - [https://www.foxnews.com/politics/white-house-not-going-apologize-releasing-merchant-death-critics-rail-bad-deal](https://www.foxnews.com/politics/white-house-not-going-apologize-releasing-merchant-death-critics-rail-bad-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:50:00+00:00

White House press secretary Karine Jean-Pierre says the Biden administration makes "no apologies" for exchanging Merchant of Death Viktor Bout for WNBA star Brittney Griner.

## It will take some complex math for McCarthy to actually be elected speaker of the House
 - [https://www.foxnews.com/politics/complex-math-mccarthy-actually-elected-speaker-house](https://www.foxnews.com/politics/complex-math-mccarthy-actually-elected-speaker-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:47:20+00:00

Cheryl Lynn Johnson has served on the House of Representatives since 2019 will assume the GOP majority speaker role if the GOP can't agree to support Kevin McCarthy as speaker.

## Russia's Wagner Group fighters burn through 2,000 rounds of ammo per day fighting determined Ukrainian army
 - [https://www.foxnews.com/world/russias-wagner-group-fighters-burn-through-2k-rounds-ammo-per-day-fighting-determined-ukrainian-army](https://www.foxnews.com/world/russias-wagner-group-fighters-burn-through-2k-rounds-ammo-per-day-fighting-determined-ukrainian-army)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:41:08+00:00

The Wagner Group, a private Russian military mercenary force, is reportedly burning through 2,000 rounds of ammunition per day as it battles fierce Ukrainian resistance.

## Athena Strand's alleged killer was delivering the 7-year old's Christmas present: mom
 - [https://www.foxnews.com/us/athena-strands-alleged-killer-delivering-7-year-olds-christmas-present-mom](https://www.foxnews.com/us/athena-strands-alleged-killer-delivering-7-year-olds-christmas-present-mom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:39:45+00:00

Athena Strand's mother says a box of Barbie dolls, intended to be the 7-year-old girl's Christmas present, was being delivered by the FedEx driver who allegedly admitted to the murder.

## Ukraine debt relief included in US defense bill approved by House
 - [https://www.foxnews.com/politics/ukraine-debt-relief-included-in-defense-policy-bill-approved-by-house](https://www.foxnews.com/politics/ukraine-debt-relief-included-in-defense-policy-bill-approved-by-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:32:51+00:00

A bill passed by the House on Thursday instructs U.S. officials to begin looking for ways to delay Ukraine's debt service payments as it fights off Russia's invasion.

## Alabama assistant to join Deion Sanders’ Colorado staff as defensive coordinator: report
 - [https://www.foxnews.com/sports/alabama-assistant-join-deion-sanders-colorado-staff-defensive-coordinator-report](https://www.foxnews.com/sports/alabama-assistant-join-deion-sanders-colorado-staff-defensive-coordinator-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:21:01+00:00

Deion Sanders continues to build his staff at Colorado, reportedly hiring Alabama associate defensive coordinator and safeties coach Charles Kelly to be his defensive coordinator.

## ABC's 'The View' hosts awkwardly discuss cheating spouses amid T.J. Holmes-Amy Robach affair
 - [https://www.foxnews.com/media/abcs-view-discusses-cheating-spouses-amid-holmes-amy-robach-affair](https://www.foxnews.com/media/abcs-view-discusses-cheating-spouses-amid-holmes-amy-robach-affair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:19:09+00:00

ABC's "The View" had a lengthy discussion of how one would handle a cheating spouse Thursday, amid the network's drama with lovebird co-hosts T.J. Holmes and Amy Robach.

## Athena Strand murder: Texas sheriff pursuing death penalty for suspect Tanner Lynn Horner
 - [https://www.foxnews.com/us/athena-strand-murder-texas-sheriff-pursuing-death-penalty-suspect-tanner-lynn-horner](https://www.foxnews.com/us/athena-strand-murder-texas-sheriff-pursuing-death-penalty-suspect-tanner-lynn-horner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:05:59+00:00

The Texas sheriff handling the investigation into the homicide of Athena Strand, a 7-year-old girl, tells Fox News Digital his office is pursuing the death penalty for the suspect.

## House committee report alleges Commanders' Dan Snyder instilled 'culture of fear' in 'toxic' workplace
 - [https://www.foxnews.com/sports/house-committee-report-alleges-commanders-dan-snyder-instilled-culture-fear-toxic-workplace](https://www.foxnews.com/sports/house-committee-report-alleges-commanders-dan-snyder-instilled-culture-fear-toxic-workplace)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:03:50+00:00

The U.S. House Oversight and Reform Committee put out its report on Washington Commanders owner Daniel Snyder and NFL Commissioner Roger Goodell.

## Are electric trucks too heavy to crash test?
 - [https://www.foxnews.com/auto/electric-trucks-heavy-crash-test](https://www.foxnews.com/auto/electric-trucks-heavy-crash-test)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:03:16+00:00

The IIHS has evaluated the capability of its crash-testing equipment with the expectation that an increasing number of heavy electric vehicles will need to be evaluated.

## Lawmakers rip Biden leaving Paul Whelan behind in Brittney Griner prisoner swap: 'It's shameful'
 - [https://www.foxnews.com/media/lawmakers-rip-biden-leaving-paul-whelan-behind-brittney-griner-prisoner-swap-shameful](https://www.foxnews.com/media/lawmakers-rip-biden-leaving-paul-whelan-behind-brittney-griner-prisoner-swap-shameful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 19:00:54+00:00

The White House is facing criticism for the Brittney Griner prisoner swap after releasing Russian arms dealer Viktor Bout and leaving U.S. Marine Paul Whelan behind.

## Gen. Petraeus on Griner release: Hate to 'reward' Russia for swap, Viktor Bout has 'blood on his hands'
 - [https://www.foxnews.com/politics/gen-petraeus-griner-release-hate-reward-russia-swap-viktor-bout-blood-hands](https://www.foxnews.com/politics/gen-petraeus-griner-release-hate-reward-russia-swap-viktor-bout-blood-hands)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 18:58:37+00:00

Gen. Petraeus told Fox News Digital that although it's an "understandable imperative" for countries to bring citizens home, Viktor Bout who was exchanged with Russia for Brittney Griner is "reprehensible."

## Jimmy Failla sounds off on ethics probe of AOC: 'Her real name is A-O-Me'
 - [https://www.foxnews.com/media/jimmy-failla-sounds-ethics-probe-aoc-real-name](https://www.foxnews.com/media/jimmy-failla-sounds-ethics-probe-aoc-real-name)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 18:57:15+00:00

Fox News Radio host Jimmy Failla roasted Alexandria-Ocasio Cortez on "The Faulkner Focus" over her facing a probe from the House Ethics Committee.

## Brittney Griner is coming home. Will she stand for the anthem now that she's back in the USA?
 - [https://www.foxnews.com/opinion/brittney-griner-coming-home-stand-anthem-back-usa](https://www.foxnews.com/opinion/brittney-griner-coming-home-stand-anthem-back-usa)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 18:50:55+00:00

President Biden announced Thursday that WNBA star Brittney Griner had been released in a prisoner swap with Russia. Now that she has been freed will Griner stand for the anthem?

## John Kerry says green energy transition isn't happening fast enough: 'Everything has to accelerate'
 - [https://www.foxnews.com/politics/john-kerry-says-green-energy-transition-isnt-happening-fast-enough-everything-accelerate](https://www.foxnews.com/politics/john-kerry-says-green-energy-transition-isnt-happening-fast-enough-everything-accelerate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 18:34:17+00:00

Special Presidential Envoy for Climate John Kerry said that the world is falling behind in the transition to green energy from fossil fuel sources, during an event Thursday.

## ABC condemned for handling of Robach-Holmes scandal: 'Busybody meddling' in consensual affair
 - [https://www.foxnews.com/media/abc-condemned-handling-robach-holmes-scandal-busybody-meddling-consensual-affair](https://www.foxnews.com/media/abc-condemned-handling-robach-holmes-scandal-busybody-meddling-consensual-affair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 18:30:49+00:00

A Washington Post opinion column argued ABC anchors T.J. Holmes and Amy Robach shouldn't have been taken off air for their affair because workplace romances are common.

## Winter weather alerts extend from Midwest to Plains
 - [https://www.foxnews.com/us/winter-weather-alerts-extend-from-midwest-plains](https://www.foxnews.com/us/winter-weather-alerts-extend-from-midwest-plains)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 18:27:43+00:00

Winter weather alerts are in place across the Plains to the Midwest, with snow in Michigan, and rain is forecast from the southern Plains to the Ohio River Valley.

## FBI probes North Carolina man for threatening to kill minorities, children and shooting a park ranger
 - [https://www.foxnews.com/us/fbi-probes-north-carolina-man-threatening-kill-minorities-children-shooting-park-ranger](https://www.foxnews.com/us/fbi-probes-north-carolina-man-threatening-kill-minorities-children-shooting-park-ranger)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 18:04:21+00:00

Police, FBI linked Tyson Lee Corpening, arrested after a rock containing hate speech was hurled through a daycare window in Charlotte, NC, to the shooting of a park ranger a week prior.

## McCarthy creates House China Select Committee to confront CCP threats
 - [https://www.foxnews.com/politics/mccarthy-creates-new-house-china-select-committee-taps-gallagher-as-chairman-to-confront-ccp-threats](https://www.foxnews.com/politics/mccarthy-creates-new-house-china-select-committee-taps-gallagher-as-chairman-to-confront-ccp-threats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 18:02:41+00:00

House Republican Leader Kevin McCarthy on Thursday announced the creation of the China Select Committee and tapped Rep. Mike Gallagher to chair the panel that will focus and push back against threats posed by the Chinese Communist Party to U.S. national security.

## Best smart thermostats to keep you at the perfect temperature
 - [https://www.foxnews.com/tech/best-smart-thermostats-keep-perfect-temperature](https://www.foxnews.com/tech/best-smart-thermostats-keep-perfect-temperature)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 18:00:57+00:00

Smart thermostats can help to lower your power bill by tweaking the temperature when you are not home and recognizing when you and your family return

## Jim Baker, ousted Twitter lawyer and ex-FBI official involved in Russiagate, was a CNN analyst in between jobs
 - [https://www.foxnews.com/media/jim-baker-ousted-twitter-lawyer-ex-fbi-official-involved-russiagate-cnn-analyst-between-jobs](https://www.foxnews.com/media/jim-baker-ousted-twitter-lawyer-ex-fbi-official-involved-russiagate-cnn-analyst-between-jobs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 18:00:47+00:00

Before joining Twitter as its deputy general counsel, Jim Baker was hired by CNN as a legal analyst, providing plenty of anti-Trump commentary for the network.

## Houston City Hall to be lit up in honor of Brittney Griner
 - [https://www.foxnews.com/us/houston-city-hall-lit-up-honor-brittney-griner](https://www.foxnews.com/us/houston-city-hall-lit-up-honor-brittney-griner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:57:29+00:00

Houston is lighting its city hall in red, white and blue tonight to honor the return of native Brittney Griner from Russia following a prisoner swap.

## Jimmie Allen and wife recount 1-year-old daughter’s health battle with RSV: ‘worst nightmare’
 - [https://www.foxnews.com/entertainment/jimmie-allen-wife-recounts-one-year-old-daughters-health-battle-rsv-worst-nightmare](https://www.foxnews.com/entertainment/jimmie-allen-wife-recounts-one-year-old-daughters-health-battle-rsv-worst-nightmare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:57:23+00:00

"Down Home" singer Jimmie Allen and his wife spoke out about their daughter Zara James' medical diagnosis with a respiratory virus called RSV, as the couple pair up with Sanofi to help educate parents on the sickness.

## Anne Sacoolas, wife of US diplomat, gets suspended sentence after killing UK teen in crash
 - [https://www.foxnews.com/world/anne-sacoolas-wife-us-diplomat-gets-suspended-sentence-killing-uk-teen-crash](https://www.foxnews.com/world/anne-sacoolas-wife-us-diplomat-gets-suspended-sentence-killing-uk-teen-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:54:33+00:00

Anne Sacoolas, wife of an American diplomat, received an eight-month suspended sentence for the death of 19-year-old Harry Dunn in a 2019 car crash in England.

## RNC Chair McDaniel says 'Twitter Files' release is 'tip of the iceberg,' calls for GOP unity ahead of 2024
 - [https://www.foxnews.com/politics/rnc-chair-ronna-mcdaniel-says-twitter-file-release-tip-iceberg-calls-gop-unity-ahead-2024](https://www.foxnews.com/politics/rnc-chair-ronna-mcdaniel-says-twitter-file-release-tip-iceberg-calls-gop-unity-ahead-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:49:06+00:00

RNC Chair Ronna McDaniel discusses Twitter's efforts to "suppress" information related to the 2020 presidential election and discusses the future of the GOP and winning elections.

## Are there 'more important things' than President Biden visiting the border? People in Texas weigh in
 - [https://www.foxnews.com/us/more-important-things-president-biden-visiting-border-people-texas-weigh](https://www.foxnews.com/us/more-important-things-president-biden-visiting-border-people-texas-weigh)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:39:44+00:00

People in Texas told Fox News whether they agreed or disagreed with Biden's statement that "there are more important things going on” than the border crisis.

## Pete Davidson returns to Instagram with Eli Manning in an unexpected joint account
 - [https://www.foxnews.com/entertainment/pete-davidson-returns-instagram-eli-manning-unexpected-joint-account](https://www.foxnews.com/entertainment/pete-davidson-returns-instagram-eli-manning-unexpected-joint-account)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:38:00+00:00

Pete Davidson has made a return to Instagram, this time in a joint account with former NFL quarterback Eli Manning. The unlikely duo has been active on Instagram since its launch.

## US to deploy additional troops to Estonia to strengthen defenses on NATO's eastern flank
 - [https://www.foxnews.com/us/us-deploy-additional-troops-estonia-strengthen-defenses-natos-eastern-flank](https://www.foxnews.com/us/us-deploy-additional-troops-estonia-strengthen-defenses-natos-eastern-flank)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:10:06+00:00

The U.S. is sending additional troops to Estonia to help defend NATO's eastern flank. The soldiers being sent consist of a U.S. infantry company, a unit of 80 to 250 soldiers.

## Rams' Baker Mayfield expected to be active vs Raiders: report
 - [https://www.foxnews.com/sports/rams-baker-mayfield-expected-active-vs-raiders-report](https://www.foxnews.com/sports/rams-baker-mayfield-expected-active-vs-raiders-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:07:26+00:00

Los Angeles Rams quarterback Baker Mayfield may make his debut with the team in Thursday night's game against the Las Vegas Raiders, according to a report.

## Family outrage: Divorced mom is devastated when teen son wants to spend Christmas with his dad
 - [https://www.foxnews.com/lifestyle/family-outrage-divorced-mom-devastated-teen-son-spend-christmas-dad](https://www.foxnews.com/lifestyle/family-outrage-divorced-mom-devastated-teen-son-spend-christmas-dad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:05:31+00:00

A mom took to Reddit saying that her son blindsided her by deciding to spend Christmas with his father. The mom told her son that he "ruined" Christmas. Experts weighed in on this drama.

## Democrats re-elect Schumer as leader after expanding Senate majority to 51
 - [https://www.foxnews.com/politics/democrats-re-elect-schumer-majority-leader-expanding-senate-conference-51](https://www.foxnews.com/politics/democrats-re-elect-schumer-majority-leader-expanding-senate-conference-51)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:02:52+00:00

Senate Democrats unanimously re-elected New York Sen. Chuck Schumer as the party's leader Thursday, after expanding their majority in the midterm elections.

## 'Yellowstone' actor Neal McDonough reflects on bonding with Kevin Costner, his devotion to faith: 'God first'
 - [https://www.foxnews.com/entertainment/yellowstone-actor-neal-mcdonough-reflect-bonding-kevin-costner-devotion-faith](https://www.foxnews.com/entertainment/yellowstone-actor-neal-mcdonough-reflect-bonding-kevin-costner-devotion-faith)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:00:59+00:00

Neal McDonough, who has appeared in numerous hit TV shows, including "Desperate Housewives" and "Justified," is narrating “O Holy Night: Christmas with The Tabernacle Choir" for the holidays.

## Musk revealed extent of Hunter Biden censorship by releasing Twitter Files
 - [https://www.foxnews.com/opinion/musk-revealed-extent-hunter-biden-censorship-releasing-twitter-files](https://www.foxnews.com/opinion/musk-revealed-extent-hunter-biden-censorship-releasing-twitter-files)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:00:54+00:00

Musk’s release of Twitter Files revealed extent of Hunter Biden censorship. Now, 59% of Americans believe laptop story was real, even half of Democrats.

## Pro-lifers outraged as Associated Press rejects 'fetal heartbeat,' 'late-term abortion' as valid terms
 - [https://www.foxnews.com/media/pro-lifers-outraged-associated-press-rejects-fetal-heartbeat-late-term-abortion-valid-terms](https://www.foxnews.com/media/pro-lifers-outraged-associated-press-rejects-fetal-heartbeat-late-term-abortion-valid-terms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:00:24+00:00

The AP wants fellow journalists to stop using the term "fetal heartbeat," calling it "misleading." The decision was hammered by pro-life organizations.

## The 'only person' Biden could beat is Trump: Karl Rove doubts POTUS will be the Democrat nominee in 2024
 - [https://www.foxnews.com/politics/only-person-biden-could-beat-trump-karl-rove-doubts-potus-will-democrat-nominee-2024](https://www.foxnews.com/politics/only-person-biden-could-beat-trump-karl-rove-doubts-potus-will-democrat-nominee-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:00:19+00:00

The veteran Republican strategist believes the Democrats need a "traditional, sensible" Democrat as their nominee in 2024 in order to combat a Republican run next cycle.

## Multiple states crack down on transgender treatments for minors amid growing legal debate
 - [https://www.foxnews.com/us/multiple-states-crack-down-transgender-treatments-minors-growing-legal-debate](https://www.foxnews.com/us/multiple-states-crack-down-transgender-treatments-minors-growing-legal-debate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 17:00:02+00:00

Multiple states have issued total or partial bans on transgender surgeries and drugs for minors amid the ongoing debate about "gender-affirming care" for young people.

## OnlyFans model Courtney Clenney hearing: Accused boyfriend killer denied bond
 - [https://www.foxnews.com/us/onlyfans-model-courtney-clenney-accused-boyfriend-killer-denied-bond](https://www.foxnews.com/us/onlyfans-model-courtney-clenney-accused-boyfriend-killer-denied-bond)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 16:58:55+00:00

A judge in Florida denied releasing OnlyFans model Courtney Clenney on bond ahead of her trial. Clenney is accused of fatally stabbing her boyfriend in Miami earlier this year.

## Ukrainian lawmaker who acted as a Russian agent has been criminally charged in New York
 - [https://www.foxnews.com/us/ukrainian-lawmaker-acted-russian-agent-been-criminally-charged-new-york](https://www.foxnews.com/us/ukrainian-lawmaker-acted-russian-agent-been-criminally-charged-new-york)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 16:07:08+00:00

Andrii Derkach, a former Ukrainian lawmaker, was criminally charged in New York in connection with a purchase of luxury real estate. U.S. Authorities believe Derkach acted as a Russian agent.

## Los Angeles Zoo's oldest gorilla, Evelyn, dies at 46
 - [https://www.foxnews.com/us/los-angeles-zoos-oldest-gorilla-evelyn-dies-46](https://www.foxnews.com/us/los-angeles-zoos-oldest-gorilla-evelyn-dies-46)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 16:04:51+00:00

Evelyn, the Los Angeles Zoo's oldest gorilla, died at 46-years-old on Wednesday. Evelyn was euthanized on account of health issues leading to a decline in her quality of life.

## Florida lawmaker indicted on fraud charges
 - [https://www.foxnews.com/us/florida-lawmaker-fraud-charges](https://www.foxnews.com/us/florida-lawmaker-fraud-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 16:04:21+00:00

A Florida lawmaker was indicted on fraud charges. The suspect illegally took $150K from the Small Business Administration in pandemic aid loans.

## Georgia couple tricks Walmart cashier, easily walks out of store with thousands in merchandise: police
 - [https://www.foxnews.com/us/georgia-couple-tricks-walmart-cashier-easily-walks-out-store-thousands-merchandise-police](https://www.foxnews.com/us/georgia-couple-tricks-walmart-cashier-easily-walks-out-store-thousands-merchandise-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 16:04:14+00:00

A sheriff's office in Georgia is looking for a man and woman who allegedly tricked a Walmart cashier and walked out of the store with more than $6,000 in merchandise, gift cards.

## Attorneys say killer of Patrick Lyoya, a Black motorist who was shot by police, had no reason to pull him over
 - [https://www.foxnews.com/us/attorneys-killer-patrick-lyoya-black-motorist-shot-police-no-reason-pull-him-over](https://www.foxnews.com/us/attorneys-killer-patrick-lyoya-black-motorist-shot-police-no-reason-pull-him-over)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 16:03:15+00:00

Attorneys for the family of a Black man who was killed by a police officer claim that the officer had no reason to pull the man over. The officer was fired from the police department.

## 10 tips for wrapping your holiday gifts
 - [https://www.foxnews.com/tech/10-tips-wrapping-holiday-gifts](https://www.foxnews.com/tech/10-tips-wrapping-holiday-gifts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 16:00:47+00:00

Kurt "CyberGuy" Knutsson provides ways to spruce up holiday gift wrapping with different organizational tools and ways to wrap gifts in the weeks before Christmas..

## Shooting at DC Metro train platform leaves 3 injured after fight
 - [https://www.foxnews.com/us/shooting-dc-metro-train-platform-leaves-3-injured-fight](https://www.foxnews.com/us/shooting-dc-metro-train-platform-leaves-3-injured-fight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 15:57:46+00:00

Metro trains are impacted in Washington, D.C. Thursday morning after a shooting took place at a station on the northeast side of the city. Three people were injured.

## George Soros drops another $50M donation to Dem PAC, doubling midterm spending
 - [https://www.foxnews.com/politics/george-soros-drops-50m-donation-dem-pac-doubling-midterm-spending](https://www.foxnews.com/politics/george-soros-drops-50m-donation-dem-pac-doubling-midterm-spending)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 15:53:33+00:00

Billionaire George Soros donated $50 million to a Democratic PAC to bolster candidates for the 2024 election cycle this week, matching his midterm spending, reports say.

## Two arrested in Mexico after pregnant woman murdered, unborn child cut out of womb
 - [https://www.foxnews.com/world/two-arrested-mexico-after-pregnant-woman-murdered-unborn-child-cut-out-womb](https://www.foxnews.com/world/two-arrested-mexico-after-pregnant-woman-murdered-unborn-child-cut-out-womb)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 15:52:29+00:00

A pregnant Mexican woman was reportedly killed when two individuals attacked her and cut open her womb to steal her unborn baby, who survived the attack.

## UVA shooting suspect Christopher Darnell Jones Jr., accused of killing 3 football players, to appear in court
 - [https://www.foxnews.com/us/uva-shooting-suspect-christopher-darnell-jones-jr-accused-killing-3-football-players-appear-court](https://www.foxnews.com/us/uva-shooting-suspect-christopher-darnell-jones-jr-accused-killing-3-football-players-appear-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 15:05:37+00:00

University of Virginia shooting suspect Christopher Darnell Jones Jr. is expected at a status hearing in Charlottesville after allegedly murdering three former football teammates.

## South Carolina mom arrested for allegedly stealing ornaments and cross from churches with child in tow
 - [https://www.foxnews.com/us/south-carolina-mom-arrested-fallegedly-stealing-ornaments-cross-from-churches-with-child-tow](https://www.foxnews.com/us/south-carolina-mom-arrested-fallegedly-stealing-ornaments-cross-from-churches-with-child-tow)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 15:02:36+00:00

South Carolina woman Leslie Reese, 42, was arrested and charged after authorities say she burglarized churches, stealing a cross and ornaments, while accompanied by her child.

## Air Force pilots seeking religious vaccine exemption still grounded while other unvaxxed members can fly
 - [https://www.foxnews.com/politics/air-force-pilots-seeking-religious-vaccine-exemption-grounded-unvaxxed-members-fly](https://www.foxnews.com/politics/air-force-pilots-seeking-religious-vaccine-exemption-grounded-unvaxxed-members-fly)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 15:00:06+00:00

Active-duty Air Force pilots seeking religious accommodation to the vaccine mandate say they are still grounded even though the Air Force allowed most other unvaxxed to fly again.

## ‘NOW’S THE TIME’: Stock up on guns and ammo, firearm group tells Oregon residents as legal battle rages on
 - [https://www.foxnews.com/us/nows-time-stock-guns-ammo-firearm-group-tells-oregon-residents-legal-battle-rages](https://www.foxnews.com/us/nows-time-stock-guns-ammo-firearm-group-tells-oregon-residents-legal-battle-rages)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 15:00:03+00:00

Oregon residents continue to stock up on firearms after a judge temporarily blocked a strict new gun control law from taking effect, but the future is still uncertain.

## 9 ways Republicans can fix the disaster of the midterm elections
 - [https://www.foxnews.com/opinion/9-ways-republicans-can-fix-the-disaster-midterm-elections](https://www.foxnews.com/opinion/9-ways-republicans-can-fix-the-disaster-midterm-elections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 15:00:02+00:00

9 ways Republicans can fix the disaster of the midterm elections, but first they must learn why massive cultural majority does not equal a political majority.

## LeAnn Rimes postpones performances due to ‘bleed’ on vocal cord, ‘violent cough’: ‘I am devastated’
 - [https://www.foxnews.com/entertainment/leann-rimes-postpones-performances-bleed-vocal-cord-violent-cough-devastated](https://www.foxnews.com/entertainment/leann-rimes-postpones-performances-bleed-vocal-cord-violent-cough-devastated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 14:52:12+00:00

Grammy-winner LeAnn Rimes announced she rescheduled a few tour dates due to being "sick with the flu," which caused a bleed on her vocal cord and a "violent cough," she revealed.

## Atlanta teens arrested in shooting that left 2 young people dead
 - [https://www.foxnews.com/us/atlanta-teens-arrested-shooting-left-2-young-people-dead](https://www.foxnews.com/us/atlanta-teens-arrested-shooting-left-2-young-people-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 14:47:11+00:00

Two teenagers have been arrested in Atlanta on charges linked to a shooting that left two people dead. Both suspects face two counts of murder, aggravated assault and gang charges.

## Biden says Russia treating Paul Whelan case differently for 'illegitimate reasons': 'We are not giving up'
 - [https://www.foxnews.com/politics/biden-russia-treating-paul-whelan-case-differently-illegitimate-reasons-we-are-not-giving-up](https://www.foxnews.com/politics/biden-russia-treating-paul-whelan-case-differently-illegitimate-reasons-we-are-not-giving-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 14:42:15+00:00

President Biden said that Russia was treating Paul Whelan 'totally differently' than Brittney Griner after the White House secured her release, but vowed not to 'give up.'

## Brittney Griner's release from Russia leaves wife Cherelle 'overwhelmed with emotions'
 - [https://www.foxnews.com/sports/brittney-griners-release-russia-leaves-wife-cherelle-overwhelmed-emotions](https://www.foxnews.com/sports/brittney-griners-release-russia-leaves-wife-cherelle-overwhelmed-emotions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 14:11:31+00:00

Cherelle Griner, the wife of Brittney Griner, spoke about her wife's release on Thursday from the White House after it was announced the WNBA superstar was released in a prisoner swap.

## New York City Mayor Eric Adams faces fine over rat infestation at his building
 - [https://www.foxnews.com/us/new-york-city-mayor-eric-adams-faces-fine-over-rat-infestation-building](https://www.foxnews.com/us/new-york-city-mayor-eric-adams-faces-fine-over-rat-infestation-building)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 14:07:15+00:00

Eric Adams, the mayor of New York City, is facing a fine over a rat infestation at a building he owns. Adams has been open about his hatred of rats.

## Biden does not mention Russian arms dealer Viktor Bout in remarks on Brittney Griner swap
 - [https://www.foxnews.com/politics/biden-mention-russian-arms-dealer-viktor-bout-remarks-brittney-griner-swap](https://www.foxnews.com/politics/biden-mention-russian-arms-dealer-viktor-bout-remarks-brittney-griner-swap)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 14:05:40+00:00

President Biden delivered remarks Thursday morning after he confirmed that WNBA star Brittney Griner has been released from a Russian prison and is on her way home

## Electric Ram Revolution pickup will 'give people goosebumps'
 - [https://www.foxnews.com/auto/electric-ram-revolution-pickup-goosebumps](https://www.foxnews.com/auto/electric-ram-revolution-pickup-goosebumps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 14:05:38+00:00

The Ram Revolution electric pickup will be revealed at CES on January 5 and is being previewed with a new video that shows its clay design model.

## FBI on South Carolina probe of possible sabotage at electric plant
 - [https://www.foxnews.com/us/fbi-south-carolina-probe-possible-sabotage-at-electric-plant](https://www.foxnews.com/us/fbi-south-carolina-probe-possible-sabotage-at-electric-plant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 14:03:15+00:00

The FBI is on the probe into shots fired near a South Carolina power plant unleashed just as power was restored for Moore County, North Carolina customers.

## Who has cash to burn for these extravagant $1,000+ Amazon gifts?
 - [https://www.foxnews.com/tech/cash-burn-extravagant-1000-amazon-gifts](https://www.foxnews.com/tech/cash-burn-extravagant-1000-amazon-gifts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 14:00:30+00:00

Kurt "CyberGuy" Knutsson lists ten high-quality products at reasonable prices you could buy for your friends and family this holiday season from Amazon.com.

## Professor calls museums racist: Built to ‘justify’ empire, colonization marginalization
 - [https://www.foxnews.com/media/professor-calls-museums-racist-built-justify-empire-colonization-marginalization](https://www.foxnews.com/media/professor-calls-museums-racist-built-justify-empire-colonization-marginalization)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 14:00:04+00:00

Professor Tukufu Zuberi suggested to “PBS Newshour’s” Jeffrey Brown on Wednesday that racial bias and prejudice are the foundations of museums everywhere.

## Carly Pearce gets candid about friendship with Kelsea Ballerini: ‘We’ve been through a lot separately’
 - [https://www.foxnews.com/entertainment/carly-pearce-gets-candid-friendship-kelsea-ballerini](https://www.foxnews.com/entertainment/carly-pearce-gets-candid-friendship-kelsea-ballerini)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 14:00:02+00:00

"Every Little Thing" artist Carly Pearce detailed her friendship with Kelsea Ballerini. They've remained close as their country music careers have grown.

## Biden prisoner exchange for Britney Griner leaves behind Marine veteran Paul Whelan — again
 - [https://www.foxnews.com/politics/biden-prisoner-exchange-britney-griner-leaves-behind-marine-veteran-paul-whelan-again](https://www.foxnews.com/politics/biden-prisoner-exchange-britney-griner-leaves-behind-marine-veteran-paul-whelan-again)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 13:59:22+00:00

Marine veteran Paul Whelan was again left behind in Russia in President Biden's prisoner exchange for WNBA star Brittney Griner on Thursday. Whelan's family congratulated Griner.

## Brittney Griner released from Russian prison in swap for convicted arms dealer
 - [https://www.foxnews.com/sports/brittney-griner-released-russian-prison-swap-convicted-arms-dealer](https://www.foxnews.com/sports/brittney-griner-released-russian-prison-swap-convicted-arms-dealer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 13:13:44+00:00

Brittney Griner was released from prison in a one-for-one swap with convicted arms dealer Viktor Bout.

## AAA: Alcohol and cannabis use increased among U.S. drivers last year as traffic deaths spiked
 - [https://www.foxnews.com/auto/aaa-alcohol-cannabis-use-increased-drivers-deaths](https://www.foxnews.com/auto/aaa-alcohol-cannabis-use-increased-drivers-deaths)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 13:13:12+00:00

A new study from AAA found more drivers admitting to risky behavior behind the wheel, including driving under the influence of drugs and alcohol and using handheld devices.

## Rams' Bobby Wagner avoids charges for hit on protester
 - [https://www.foxnews.com/sports/rams-bobby-wagner-avoids-charges-hit-protester](https://www.foxnews.com/sports/rams-bobby-wagner-avoids-charges-hit-protester)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 13:07:57+00:00

Bobby Wagner will not face charges for his tackle on a protester in October after the man stormed the field at Levi's Stadium with a pink smoke bomb.

## Biden approval rating holds underwater, just 28% say America heading in right direction: poll
 - [https://www.foxnews.com/politics/biden-approval-rating-holds-underwater-just-28-say-america-heading-right-direction-poll](https://www.foxnews.com/politics/biden-approval-rating-holds-underwater-just-28-say-america-heading-right-direction-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 13:04:31+00:00

President Biden's approval rating remains steadily negative, even after a historic midterm elections performance from Democrats, who expanded their Senate majority.

## Idaho police likely using investigative genetic genealogy in college students' murders, expert says
 - [https://www.foxnews.com/us/idaho-police-likely-using-investigative-genetic-genealogy-college-students-murders-expert-says](https://www.foxnews.com/us/idaho-police-likely-using-investigative-genetic-genealogy-college-students-murders-expert-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 13:03:45+00:00

DNA analysis, including investigative genetic genealogy, will play a key role in the investigation of the quadruple homicide near the University of Idaho.

## Nikki Bella on sharing her ‘love language’ to ‘DWTS’ pro Artem Chigvintsev: ‘Need to feel desired and wanted’
 - [https://www.foxnews.com/entertainment/nikki-bella-sharing-love-language-dwts-pro-artem-chigvintsev-need-feel-desired](https://www.foxnews.com/entertainment/nikki-bella-sharing-love-language-dwts-pro-artem-chigvintsev-need-feel-desired)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 13:00:46+00:00

Nikki Bella, a WWE Hall of Famer and her husband, “Dancing with the Stars” pro Artem Chigvintsev, welcomed their first child, a son named Matteo, in July 2020.

## High-ranking military official called to resign after targeting mom upset over pansexuality posters at school
 - [https://www.foxnews.com/media/high-ranking-military-official-called-resign-targeting-mom-upset-pansexuality-posters-school](https://www.foxnews.com/media/high-ranking-military-official-called-resign-targeting-mom-upset-pansexuality-posters-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 13:00:43+00:00

A New Jersey mother reveals a high-ranking military officer targeted her on Facebook for voicing concern over her child's elementary school teaching pansexuality.

## How parents are leading school board revolutions across America
 - [https://www.foxnews.com/opinion/parents-leading-school-board-revolutions-across-america](https://www.foxnews.com/opinion/parents-leading-school-board-revolutions-across-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 13:00:43+00:00

School board elections across the country revealed that the American people favor anti-woke, pro-parental rights candidates.

## Georgia Walmart shooting: 1 shot outside Atlanta-area store as panicked shoppers flee for the exits
 - [https://www.foxnews.com/us/georgia-walmart-shooting-outside-atlanta-area-store-panicked-shoppers-flee-exits](https://www.foxnews.com/us/georgia-walmart-shooting-outside-atlanta-area-store-panicked-shoppers-flee-exits)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 12:55:34+00:00

A shooting outside of a Walmart Supercenter in Marietta, Georgia, has left 1 person injured, while shoppers inside say people were fleeing for the exits.

## Family of late rower files wrongful death lawsuit after son's suicide, allege verbal abuse went too far
 - [https://www.foxnews.com/sports/family-late-rower-files-wrongful-death-lawsuit-sons-suicide-allege-verbal-abuse-went-too-far](https://www.foxnews.com/sports/family-late-rower-files-wrongful-death-lawsuit-sons-suicide-allege-verbal-abuse-went-too-far)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 12:34:44+00:00

The parents of a former University of California-San Diego rower who died by suicide alleged in a lawsuit the coach's verbal abuse is to blame.

## Wave of Grinch porch pirates trying to ruin Christmas
 - [https://www.foxnews.com/tech/wave-grinch-porch-pirates-trying-ruin-christmas](https://www.foxnews.com/tech/wave-grinch-porch-pirates-trying-ruin-christmas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 12:16:45+00:00

Kurt "CyberGuy" Knutsson gives you the best advice on how to keep your packages and yourself safe from "porch pirates" over the upcoming holidays.

## Celine Dion reveals incurable neurological disorder diagnosis in emotional video
 - [https://www.foxnews.com/entertainment/celine-dion-reveals-incurable-neurological-disorder-diagnosis-emotional-video](https://www.foxnews.com/entertainment/celine-dion-reveals-incurable-neurological-disorder-diagnosis-emotional-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 12:06:46+00:00

Celine Dion revealed Thursday that she has been diagnosed with Stiff Person Syndrome (SPS), saying it has been affecting her ability to walk and sing.

## Liberals grouch over Musk firing controversial Twitter lawyer: 'Desperate and dumb,' not a 'scandal'
 - [https://www.foxnews.com/media/liberals-grouch-over-musk-firing-controversial-twitter-lawyer-desperate-dumb-not-scandal](https://www.foxnews.com/media/liberals-grouch-over-musk-firing-controversial-twitter-lawyer-desperate-dumb-not-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 12:00:13+00:00

Liberals complained over Elon Musk's decision to fire Twitter counsel James Baker over his involvement in possibly suppressing the Hunter Biden laptop story.

## House GOP teases action against ex-Twitter lawyer, NY Times union workers go on strike and more top headlines
 - [https://www.foxnews.com/us/house-gop-teases-bold-action-ex-twitter-lawyer-suprressed-hunter-biden-laptop-story](https://www.foxnews.com/us/house-gop-teases-bold-action-ex-twitter-lawyer-suprressed-hunter-biden-laptop-story)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 11:54:37+00:00

‘STAY TUNED’ - House GOP teases bold action against ex-Twitter lawyer who suppressed Hunter story

## Xander Bogaerts, Padres agree to an 11-year, $280 million deal: reports
 - [https://www.foxnews.com/sports/xander-bogaerts-padres-agree-11-year-280-million-deal-reports](https://www.foxnews.com/sports/xander-bogaerts-padres-agree-11-year-280-million-deal-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 11:51:52+00:00

Xander Bogaerts spent the last 10 years with the Boston Red Sox and will spend more than the next decade with the San Diego Padres, according to multiple reports.

## New powerful AI bot creates angst among users: Are robots ready to take our jobs?
 - [https://www.foxnews.com/media/new-powerful-a-i-bot-creates-angst-among-users-are-robots-ready-take-job](https://www.foxnews.com/media/new-powerful-a-i-bot-creates-angst-among-users-are-robots-ready-take-job)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 11:30:56+00:00

"The Five" co-hosts Wednesday discussed new artificial intelligence (AI) bot ChatGPT and the pros and cons of AI in society, education and the workplace.

## Oregon's new gun law 'tramples' Second Amendment rights, puts police in an impossible position: Gun shop owner
 - [https://www.foxnews.com/media/oregons-gun-law-tramples-second-amendment-rights-police-untenable-position-gun-shop-owner](https://www.foxnews.com/media/oregons-gun-law-tramples-second-amendment-rights-police-untenable-position-gun-shop-owner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 11:00:54+00:00

Gun shop owner Karl Durkheimer argued that Oregon's new gun law limits the constitutional rights of state residents and could delay the process of purchasing a gun by months.

## Americans must rely on Supreme Court to save traditional views on marriage
 - [https://www.foxnews.com/opinion/americans-must-rely-supreme-court-save-traditional-views-marriage](https://www.foxnews.com/opinion/americans-must-rely-supreme-court-save-traditional-views-marriage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 11:00:14+00:00

Americans must rely on the Supreme Court to save traditional views on marriage. Congress’s new Respect for Marriage Act doesn’t respect people of faith.

## Bible verse of the day: God is 'closer to us' in dark times, says faith leader
 - [https://www.foxnews.com/lifestyle/bible-verse-day-god-closer-us-dark-times-faith-leader](https://www.foxnews.com/lifestyle/bible-verse-day-god-closer-us-dark-times-faith-leader)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 11:00:08+00:00

Psalms 23:4 conveys that God is always with us, even as we face death. Rabbi Pinchas Taylor examines the text and says that when we realize God is with us — nothing should trouble us.

## Texas jury finds ex-Border Patrol agent guilty of murdering four sex workers
 - [https://www.foxnews.com/us/texas-jury-finds-ex-border-patrol-agent-guilty-murdering-four-sex-workers](https://www.foxnews.com/us/texas-jury-finds-ex-border-patrol-agent-guilty-murdering-four-sex-workers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 10:43:55+00:00

An ex-Border Patrol agent was convicted of capital murder in the deaths of four sex workers after jurors heard him say he wanted to "clean up the streets."

## Karine Jean-Pierre ridiculed for claiming ‘there was suppression’ in GA election: ‘Conspiracy theory much?’
 - [https://www.foxnews.com/media/karine-jean-pierre-ridiculed-claiming-suppression-ga-election-conspiracy-theory](https://www.foxnews.com/media/karine-jean-pierre-ridiculed-claiming-suppression-ga-election-conspiracy-theory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 10:00:56+00:00

White House press secretary Karine Jean-Pierre insisted on Wednesday that voter suppression still occurred in the Georgia election despite reports of record-level turnout.

## Prince Harry, Meghan Markle share intimate details of their first encounters in 'Harry & Meghan' docuseries
 - [https://www.foxnews.com/entertainment/prince-harry-meghan-markle-share-intimate-details-first-encounters-harry-meghan-docuseries](https://www.foxnews.com/entertainment/prince-harry-meghan-markle-share-intimate-details-first-encounters-harry-meghan-docuseries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 09:24:49+00:00

Prince Harry and Meghan Markle shared intimate details of the early stages of their relationship, before they became public in October 2016, in the new "Harry & Meghan" docuseries.

## Pennsylvania firefighters dead after being trapped in three-alarm blaze
 - [https://www.foxnews.com/us/pennsylvania-firefighters-dead-after-being-trapped-three-alarm-blaze](https://www.foxnews.com/us/pennsylvania-firefighters-dead-after-being-trapped-three-alarm-blaze)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 09:02:37+00:00

Two Pennsylvania firefighters died from injuries sustained in a three-alarm house fire on Wednesday. A third body was also found near the home.

## Biden has poisoned any immigration amnesty by not enforcing border
 - [https://www.foxnews.com/opinion/biden-has-poisoned-any-immigration-amnesty-not-enforcing-border](https://www.foxnews.com/opinion/biden-has-poisoned-any-immigration-amnesty-not-enforcing-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 09:00:50+00:00

Biden has poisoned the well for any immigration compromise or possible DACA amnesty by ignoring crisis. Current plan would just make border problem worse.

## 'Absolutely extraordinary' Harry and Meghan still have royal titles, fumes former Thatcher aide
 - [https://www.foxnews.com/media/absolutely-extraordinary-harry-meghan-still-royal-titles-fumes-former-thatcher-aide](https://www.foxnews.com/media/absolutely-extraordinary-harry-meghan-still-royal-titles-fumes-former-thatcher-aide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 09:00:18+00:00

Former Margaret Thatcher aide predicts Queen Elizabeth II's memory will remain unblemished in wake of royal family's schism with Harry and Meghan.

## Kirk Cameron speaks out after faith-based book 'banned': Diversity should include Christianity
 - [https://www.foxnews.com/media/kirk-cameron-speaks-faith-based-book-banned-diversity-christianity](https://www.foxnews.com/media/kirk-cameron-speaks-faith-based-book-banned-diversity-christianity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 09:00:06+00:00

Actor Kirk Cameron, author of 'As You Grow,' told Fox News he has been rejected by dozens of libraries where he or his publisher have asked to host a story hour.

## Ozempic warning: Doctors urge caution for those using diabetes drug for weight loss
 - [https://www.foxnews.com/health/ozempic-warning-doctors-urge-caution-those-using-diabetes-drug-weight-loss](https://www.foxnews.com/health/ozempic-warning-doctors-urge-caution-those-using-diabetes-drug-weight-loss)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 08:41:42+00:00

Doctors are warning against using Ozempic, a drug intended to treat Type 2 diabetes, for weight loss after some people sought out the drugs to help them shed a few pounds quickly.

## Herschel Walker, thrown for a loss that also hurts Trump and Senate Republicans
 - [https://www.foxnews.com/media/herschel-walker-thrown-loss-hurts-trump-senate-republicans](https://www.foxnews.com/media/herschel-walker-thrown-loss-hurts-trump-senate-republicans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 08:00:14+00:00

Herschel Walker gave a nice concession speech, talking about the need to believe in America but, in the end, Georgia’s Senate runoff wasn’t that close.

## Vanna White details 'brother and sister' bond with 'Wheel of Fortune' co-host Pat Sajak: 'It's perfect'
 - [https://www.foxnews.com/entertainment/vanna-white-details-brother-sister-bond-wheel-fortune-co-host-pat-sajak-perfect](https://www.foxnews.com/entertainment/vanna-white-details-brother-sister-bond-wheel-fortune-co-host-pat-sajak-perfect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 07:04:16+00:00

Vanna White recently revealed that she views her relationship with her "Wheel of Fortune" co-host Pat Sajak as a "brother and sister" bond.

## 'Stay tuned': House GOP hints at potential legal action against ex-Twitter lawyer who suppressed Hunter story
 - [https://www.foxnews.com/politics/stay-tuned-house-gop-hints-potential-legal-action-twitter-ousts-lawyer-who-suppressed-hunter-story](https://www.foxnews.com/politics/stay-tuned-house-gop-hints-potential-legal-action-twitter-ousts-lawyer-who-suppressed-hunter-story)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 07:00:58+00:00

Top House Republicans told Fox News Digital they were prepared to use any tools available and hinted at legal action related to Twitter's suppression of the Hunter Biden laptop story.

## McCarthy plays hardball with GOP rebels over committee assignments
 - [https://www.foxnews.com/politics/mccarthy-plays-hardball-gop-rebels-committee-assignments](https://www.foxnews.com/politics/mccarthy-plays-hardball-gop-rebels-committee-assignments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 07:00:55+00:00

House Republicans are delaying decisions on prime committee assignments, which could help Minority Leader Kevin McCarthy undercut the opposition to his bid for speaker.

## NBC News reporter Ben Collins repeatedly attacks, ridicules Elon Musk while covering Twitter owner
 - [https://www.foxnews.com/media/nbc-news-reporter-ben-collins-repeatedly-attacks-ridicules-elon-musk-covering-twitter-owner](https://www.foxnews.com/media/nbc-news-reporter-ben-collins-repeatedly-attacks-ridicules-elon-musk-covering-twitter-owner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 07:00:55+00:00

Ben Collins openly detests Elon Musk and his handling of Twitter, raising questions about whether the NBC reporter can impartially cover the topic.

## AI bot that can do schoolwork could 'blow up' US education system, with youngest at most risk: former teacher
 - [https://www.foxnews.com/tech/ai-bot-schoolwork-blow-up-us-education-system-youngest-risk-former-teacher](https://www.foxnews.com/tech/ai-bot-schoolwork-blow-up-us-education-system-youngest-risk-former-teacher)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 07:00:52+00:00

Former English teacher, Peter Laffin, predicts OpenAI's new artificial intelligence chatbot will lead to a learning crisis and force teachers to rethink education.

## Bullies in white coats? 'Too many' health care workers experience toxic workplaces, studies show
 - [https://www.foxnews.com/health/bullies-white-coats-many-health-care-workers-experience-toxic-workplace-studies](https://www.foxnews.com/health/bullies-white-coats-many-health-care-workers-experience-toxic-workplace-studies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 07:00:48+00:00

Doctors, nurses and others may be trained to treat patients with compassion and respect, but too many are treating each other — meaning their colleagues — with disrespect, studies have found.

## We worked for Dr. Ben Carson. We know Dr. Ben Carson. Canceling him is just not right
 - [https://www.foxnews.com/opinion/worked-ben-carson-know-canceling-just-not-right](https://www.foxnews.com/opinion/worked-ben-carson-know-canceling-just-not-right)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 07:00:46+00:00

We worked for Ben Carson. We know Ben Carson. Letting cancel culture erase a school name honoring him is a rejection of his heroism and the American Dream.

## Kate Middleton, Prince William outshine Meghan Markle, Prince Harry in royal battle for spotlight
 - [https://www.foxnews.com/entertainment/kate-middleton-prince-william-outshine-meghan-markle-prince-harry-royal-battle-spotlight](https://www.foxnews.com/entertainment/kate-middleton-prince-william-outshine-meghan-markle-prince-harry-royal-battle-spotlight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 07:00:41+00:00

Prince William and Kate Middleton will always outshine Meghan Markle and Prince Harry despite their best efforts because they are the "real royals," experts tell Fox News Digital.

## How safe are delivery drivers? Brutal murder of Texas girl isn’t the first case to land FedEx in hot water
 - [https://www.foxnews.com/us/how-safe-are-delivery-drivers-brutal-murder-texas-girl-isnt-first-case-fedex-hot-water](https://www.foxnews.com/us/how-safe-are-delivery-drivers-brutal-murder-texas-girl-isnt-first-case-fedex-hot-water)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 07:00:14+00:00

Texas girl Athena Strand was murdered allegedly at the hands of a FedEx driver. Fox News Digital examined other crimes allegedly carried out by drivers and how a company hires them.

## Pearl Harbor survivors make trek to Hawaii for ceremony on 81st anniversary of attack
 - [https://www.foxnews.com/us/pearl-harbor-survivors-make-trek-hawaii-ceremony-81st-anniversary-attack](https://www.foxnews.com/us/pearl-harbor-survivors-make-trek-hawaii-ceremony-81st-anniversary-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 06:20:20+00:00

Six survivors of Pearl Harbor, all over 100 years old, were among the crowd at the national memorial in Hawaii to commemorate the lives lost 81 years ago.

## Former 'Grey's Anatomy' writer says she 'lied' about having cancer, brother's suicide: 'What I did was wrong'
 - [https://www.foxnews.com/entertainment/former-greys-anatomy-writer-lied-about-having-cancer-brothers-suicide-what-did-wrong](https://www.foxnews.com/entertainment/former-greys-anatomy-writer-lied-about-having-cancer-brothers-suicide-what-did-wrong)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 05:57:01+00:00

Ex "Grey's Anatomy" writer and consulting producer, Elisabeth Finch, said that she "lied" about her cancer diagnosis and brother's suicide while working on the acclaimed drama.

## LAURA INGRAHAM: Can you believe we live in a society where there's such a thing as doll propaganda?
 - [https://www.foxnews.com/media/laura-ingraham-can-you-believe-we-live-society-theres-such-thing-doll-propaganda](https://www.foxnews.com/media/laura-ingraham-can-you-believe-we-live-society-theres-such-thing-doll-propaganda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 05:35:11+00:00

Laura Ingraham ridicules the American Girl company for manufacturing its dolls in China and promoting transgenderism to children on "The Ingraham Angle."

## On this day in history, Dec. 8, 1980, Beatles founder and music icon John Lennon murdered in NYC
 - [https://www.foxnews.com/lifestyle/this-day-history-dec-8-1980-beatles-founder-music-icon-john-lennon-murdered-nyc](https://www.foxnews.com/lifestyle/this-day-history-dec-8-1980-beatles-founder-music-icon-john-lennon-murdered-nyc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 05:02:19+00:00

John Lennon, a beloved member of The Beatles, was killed in New York City on this day in history, Dec. 8, 1980. The location of his death is a global pilgrimage site to this day.

## TUCKER CARLSON: This is the reality about Ukraine's Zelenskyy
 - [https://www.foxnews.com/opinion/tucker-carlson-this-reality-about-ukraines-zelenskyy](https://www.foxnews.com/opinion/tucker-carlson-this-reality-about-ukraines-zelenskyy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 04:56:51+00:00

Fox News host Tucker Carlson gives his take on Ukraine President Volodymyr Zelenskyy and the West's support for him on 'Tucker Carlson Tonight.'

## GREG GUTFELD: Elon Musk's Twitter has done more to stop child exploitation in one month than the last 10 years
 - [https://www.foxnews.com/opinion/greg-gutfeld-elon-musks-twitter-done-more-stop-child-exploitation-ione-month-than-last-10-years](https://www.foxnews.com/opinion/greg-gutfeld-elon-musks-twitter-done-more-stop-child-exploitation-ione-month-than-last-10-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 04:46:59+00:00

Fox News host Greg Gutfeld sheds light on Elon Musk and Twitter's efforts to combat child exploitation on its platform on "Gutfedl!"

## Jenny McCarthy and Donnie Wahlberg go nude for new beauty brand campaign: 'Fun to bare it all'
 - [https://www.foxnews.com/entertainment/jenny-mccarthy-donnie-wahlberg-nude-new-beauty-brand-campaign-fun-bare-all](https://www.foxnews.com/entertainment/jenny-mccarthy-donnie-wahlberg-nude-new-beauty-brand-campaign-fun-bare-all)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 04:34:11+00:00

Jenny McCarthy and her husband, Donnie Wahlberg, posed nude for the former Playmate's holiday beauty brand campaign featuring nude lip glosses.

## SEAN HANNITY: Republicans need to start going on the offense
 - [https://www.foxnews.com/media/sean-hannity-republicans-need-to-start-going-offense](https://www.foxnews.com/media/sean-hannity-republicans-need-to-start-going-offense)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 02:57:41+00:00

Fox News host Sean Hannity analyzes Republican Georgia Senate candidate Herschel Walker's loss and what the GOP should do to increase voter turnout on 'Hannity.'

## President Biden renews push to ban 'assault weapons'
 - [https://www.foxnews.com/us/president-biden-renews-push-ban-assault-weapons](https://www.foxnews.com/us/president-biden-renews-push-ban-assault-weapons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 02:57:22+00:00

President Joe Biden spoke at the 10th Annual National Vigil for All Victims of Gun Violence, giving him the opportunity to renew a push to ban assault weapons.

## Toni Collette announces divorce from musician husband Dave Galafassi after 19 years of marriage
 - [https://www.foxnews.com/entertainment/toni-collette-announces-divorce-musician-husband-dave-galafassi-19-years-marriage](https://www.foxnews.com/entertainment/toni-collette-announces-divorce-musician-husband-dave-galafassi-19-years-marriage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 02:45:15+00:00

Toni Collette revealed she's divorcing husband David Galafassi after 19 years of marriage. The "Muriel's Wedding" star shared a joint statement on Instagram.

## Nigeria restricts ATM withdrawals to $45 per day in push to digital currency
 - [https://www.foxnews.com/world/nigeria-restricts-atm-withdrawals-45-per-day-push-digital-currency](https://www.foxnews.com/world/nigeria-restricts-atm-withdrawals-45-per-day-push-digital-currency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 02:40:49+00:00

Nigeria's central bank is restricting cash withdrawals to $45 per day as the country tries to push to wider adoption of digital currencies.

## California authorities reveal massive 'fix-it' ticket scheme allegedly tied to illegal street racers
 - [https://www.foxnews.com/us/california-authorities-reveal-massive-fix-ticket-scheme-allegedly-tied-illegal-street-racers](https://www.foxnews.com/us/california-authorities-reveal-massive-fix-ticket-scheme-allegedly-tied-illegal-street-racers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 02:25:48+00:00

California authorities arrested more than two dozen people for their alleged involvement in a ticket-fixing scheme.

## Denise Austin, 65, shares stunning midriff-baring photo as she talks staying slim during the holidays
 - [https://www.foxnews.com/entertainment/denise-austin-65-shares-stunning-midriff-baring-photo-talks-staying-slim-during-holidays](https://www.foxnews.com/entertainment/denise-austin-65-shares-stunning-midriff-baring-photo-talks-staying-slim-during-holidays)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 02:15:35+00:00

Denise Austin gave tips for avoiding weight gain and bloat during the food-filled holidays as she shared a photo of her toned abs.

## North Carolina offers $25k award for information leading to arrest of power outage culprits
 - [https://www.foxnews.com/us/north-carolina-offers-25k-award-information-leading-arrest-power-outage-culprits](https://www.foxnews.com/us/north-carolina-offers-25k-award-information-leading-arrest-power-outage-culprits)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 02:04:06+00:00

North Carolina Gov. Roy Cooper announced the state was offering $25,000 for information leading to the conviction of those responsible for taking out two Moore County substations.

## Hawks' Trae Young trolls Knicks with phrase on custom sneakers
 - [https://www.foxnews.com/sports/hawks-trae-young-trolls-knicks-phrase-custom-sneakers](https://www.foxnews.com/sports/hawks-trae-young-trolls-knicks-phrase-custom-sneakers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 01:58:30+00:00

Atlanta Hawks star point guard Trae Young has recently become a villain to the New York Knicks, and his latest stunt with his sneakers before a game shows why.

## JESSE WATTERS: You can sleep on San Francisco streets, but you can't sleep in your office
 - [https://www.foxnews.com/media/jesse-watters-you-can-sleep-san-francisco-streets-cant-sleep-your-office](https://www.foxnews.com/media/jesse-watters-you-can-sleep-san-francisco-streets-cant-sleep-your-office)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 01:45:51+00:00

Fox News host Jesse Watters slams San Francisco Mayor London Breed for launching an investigation on Twitter for having nap rooms rather than prioritizing and fixing crime in the city on 'Jesse Watters Primetime.'

## Thousands of Texas drivers overcharged on toll roads
 - [https://www.foxnews.com/us/thousands-texas-drivers-overcharged-toll-roads](https://www.foxnews.com/us/thousands-texas-drivers-overcharged-toll-roads)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 01:28:27+00:00

The Central Texas Regional Mobility authority is taking responsibility for a glitch that wrongfully charged thousands of Texas drivers late fees.

## UK government rules out law change for return of Parthenon marbles to Greece after 'secret' meetings
 - [https://www.foxnews.com/world/uk-government-rules-law-change-return-parthenon-marbles-greece-secret-meetings](https://www.foxnews.com/world/uk-government-rules-law-change-return-parthenon-marbles-greece-secret-meetings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 01:20:49+00:00

A spokesperson for Rishi Sunak told reporters that while the British Museum trustees are free to talk to whomever they want, the U.K. has no plans to change the law.

## Sen. Cotton praised for annihilating woke Kroger CEO seeking GOP help against Dems: ‘Go woke, go broke'
 - [https://www.foxnews.com/media/sen-cotton-praised-annihilating-woke-kroger-ceo-seeking-gop-help-against-dems-go-woke-go-broke](https://www.foxnews.com/media/sen-cotton-praised-annihilating-woke-kroger-ceo-seeking-gop-help-against-dems-go-woke-go-broke)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 01:00:40+00:00

Conservatives on Twitter praised Sen. Tom Cotton, R-Ark., for rebuking woke Kroger CEO Rodney McMullen after he sought GOP aid against Democrat Party regulations.

## Red Sox sign Japanese star outfielder who is on-base machine: report
 - [https://www.foxnews.com/sports/red-sox-sign-japanese-star-outfielder-base-machine-report](https://www.foxnews.com/sports/red-sox-sign-japanese-star-outfielder-base-machine-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 00:57:03+00:00

The Boston Red Sox were quick to sign Masataka Yoshida, a Japanese outfielder who was just posted Tuesday by Nippon Professional Baseball's Orix Buffaloes.

## California Democrat says he'd vote for a 'unity' GOP speaker, but McCarthy allies warn of concessions
 - [https://www.foxnews.com/politics/california-democrat-says-vote-unity-gop-speaker-mccarthy-allies-warn-concessions](https://www.foxnews.com/politics/california-democrat-says-vote-unity-gop-speaker-mccarthy-allies-warn-concessions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 00:46:57+00:00

As anti-Kevin McCarthy dissenters grow, Democrats are moving toward agreeing to a unity candidate to become the next Speaker of the House.

## Prince William, Kate Middleton are more ‘proper,’ ‘royal’ than Prince Harry, Meghan Markle with PDA: expert
 - [https://www.foxnews.com/entertainment/prince-william-kate-more-proper-royal-than-prince-harry-meghan-pda-body-language-expert](https://www.foxnews.com/entertainment/prince-william-kate-more-proper-royal-than-prince-harry-meghan-pda-body-language-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 00:45:51+00:00

A body language expert said even though Prince William and Kate Middleton show their affection differently than Prince Harry and Meghan Markle, both couples are "crazy" in love.

## Connecticut woman killed in suspected axe attack warned of danger weeks earlier: 'He's going to kill me'
 - [https://www.foxnews.com/us/connecticut-woman-killed-axe-attack-warned-danger-weeks-earlier-hes-going-kill-me](https://www.foxnews.com/us/connecticut-woman-killed-axe-attack-warned-danger-weeks-earlier-hes-going-kill-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 00:36:40+00:00

A Connecticut woman who was killed by a former boyfriend during an axe attack was granted an enhanced restraining order days earlier, police said

## Former Bills punter Matt Araiza will not face criminal charges in alleged gang-rape case
 - [https://www.foxnews.com/sports/former-bills-punter-matt-araiza-will-not-face-criminal-charges-alleged-gang-rape-case](https://www.foxnews.com/sports/former-bills-punter-matt-araiza-will-not-face-criminal-charges-alleged-gang-rape-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 00:31:46+00:00

Former Buffalo Bills punter Matt Araiza will not face criminal charges in a 2021 alleged gang rape of a 17-year-old girl, prosecutors said.

## New York Times union calls on readers to join ‘digital picket line’ as strike looms
 - [https://www.foxnews.com/media/new-york-times-union-calls-readers-join-digital-picket-line-strike-looms](https://www.foxnews.com/media/new-york-times-union-calls-readers-join-digital-picket-line-strike-looms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-12-08 00:04:55+00:00

New York Times union leaders called on Twitter followers to join a virtual picket line by not engaging with the publication during their day-long walkout.


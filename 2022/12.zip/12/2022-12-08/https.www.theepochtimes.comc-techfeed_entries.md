# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## Cybersecurity, Foreign Interference Among Biggest Issues Australia Is Facing
 - [https://www.theepochtimes.com/cybersecurity-foreign-interference-among-biggest-issues-australia-is-facing-home-affairs-minister_4911050.html](https://www.theepochtimes.com/cybersecurity-foreign-interference-among-biggest-issues-australia-is-facing-home-affairs-minister_4911050.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-08 23:42:51+00:00

Minister for Home Affairs and Minister for Cyber Security Clare O'Neil speaks to media in Melbourne, Australia, on Oct. 20, 2022. (AAP Image/James Ross)

## FTC Sues to Block $68 Billion Microsoft-Activision Merger, Alleges Anti-Competitive Actions
 - [https://www.theepochtimes.com/ftc-sues-to-block-68b-microsoft-activision-merger-alleges-anti-competitive-actions_4913161.html](https://www.theepochtimes.com/ftc-sues-to-block-68b-microsoft-activision-merger-alleges-anti-competitive-actions_4913161.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-08 23:41:29+00:00

The Microsoft logo at the Microsoft Annual Shareholders Meeting in Bellevue, Wash., on Nov. 30, 2016. (Jason Redmond/AFP via Getty Images)

## Biden Administration Tells US Supreme Court That Law Protecting Social Media Companies Has Limits
 - [https://www.theepochtimes.com/biden-administration-tells-us-supreme-court-that-law-protecting-social-media-companies-has-limits_4912625.html](https://www.theepochtimes.com/biden-administration-tells-us-supreme-court-that-law-protecting-social-media-companies-has-limits_4912625.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-08 21:00:12+00:00

President Joe Biden in the Oval Office of the White House in Washington, on Dec. 1, 2022. (Ludovic Marin/AFP via Getty Images)

## Google Must Delete Search Result Data at Users’ Request If ‘Manifestly Inaccurate’: EU Court
 - [https://www.theepochtimes.com/google-must-delete-search-result-data-at-users-request-if-manifestly-inaccurate-eu-court_4911538.html](https://www.theepochtimes.com/google-must-delete-search-result-data-at-users-request-if-manifestly-inaccurate-eu-court_4911538.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-08 17:20:20+00:00

The Google logo at the entrance to the Google offices in London on Jan. 18, 2019. (Hannah McKay/Reuters)

## FBI ‘Deeply Concerned’ After Apple Says Nearly All iCloud Data Now Has End-to-End Encryption
 - [https://www.theepochtimes.com/fbi-deeply-concerned-after-apple-says-nearly-all-icloud-data-now-has-end-to-end-encryption_4911030.html](https://www.theepochtimes.com/fbi-deeply-concerned-after-apple-says-nearly-all-icloud-data-now-has-end-to-end-encryption_4911030.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-08 14:48:45+00:00

The Apple logo at an Apple Store in the Brooklyn borough of New York City on Oct. 23, 2020.  (Brendan McDermid/Reuters)

## Musk Says Key Bits of ‘Twitter Files’ Were Compromised as He Fires Ex-FBI Twitter Lawyer Involved in ‘Vetting’ the Data
 - [https://www.theepochtimes.com/musk-says-key-bits-of-twitter-files-were-compromised-as-he-fires-ex-fbi-twitter-lawyer-involved-in-vetting-the-data_4911251.html](https://www.theepochtimes.com/musk-says-key-bits-of-twitter-files-were-compromised-as-he-fires-ex-fbi-twitter-lawyer-involved-in-vetting-the-data_4911251.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-08 14:10:01+00:00

Elon Musk, Tesla CEO, attends the opening of the Tesla factory Berlin Brandenburg in Gruenheide, Germany, March 22, 2022. (Patrick Pleul/Pool via AP)

## Cyberattack on Top Indian Hospital Highlights Security Risk
 - [https://www.theepochtimes.com/cyberattack-on-top-indian-hospital-highlights-security-risk_4909017.html](https://www.theepochtimes.com/cyberattack-on-top-indian-hospital-highlights-security-risk_4909017.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2022-12-08 06:52:32+00:00

Patients and their attendants squat outside the All India Institute of Medical Sciences (AIIMS) hospital in New Delhi on Dec. 7, 2022. (Altaf Qadri/AP Photo)


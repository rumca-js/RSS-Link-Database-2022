# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## Alberta Police Reform Could Bring Civilian Oversight
 - [https://www.theepochtimes.com/alberta-police-reform-could-bring-civilian-oversight_4912553.html](https://www.theepochtimes.com/alberta-police-reform-could-bring-civilian-oversight_4912553.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 23:59:27+00:00

An Edmonton Police car parks at the site of an investigation in front of the Matrix Hotel in Edmonton, Alberta, on Oct. 1, 2017.  (Candace Elliott/Reuters)

## Australian COVID Measures Led to Lowest Elective Surgery Numbers in a Decade
 - [https://www.theepochtimes.com/australian-covid-measures-led-to-lowest-elective-surgery-numbers-in-a-decade_4908265.html](https://www.theepochtimes.com/australian-covid-measures-led-to-lowest-elective-surgery-numbers-in-a-decade_4908265.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 23:54:01+00:00

Reports of record low elective surgery performance surfaces. (Reuters/Brian Snyder)

## Australians Appalled at Early Release of Bali Bomb Maker, Government Seeks Assurances
 - [https://www.theepochtimes.com/australians-appalled-at-early-release-of-bali-bomb-maker-government-seeks-assurances_4911068.html](https://www.theepochtimes.com/australians-appalled-at-early-release-of-bali-bomb-maker-government-seeks-assurances_4911068.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 23:33:32+00:00

Convicted bombmaker Umar Patek walks into the court room during verdict trial on June 21, in Jakarta, Indonesia. Patek was convicted of assembling the explosives that killed 202 people in Bali on Christmas Eve 2002. (Ulet Ifansasti/Getty Images)

## MPs Want to Hear From Witnesses on the Government’s Assault-Style Gun Definition
 - [https://www.theepochtimes.com/mps-want-to-hear-from-witnesses-on-the-governments-assault-style-gun-definition_4913137.html](https://www.theepochtimes.com/mps-want-to-hear-from-witnesses-on-the-governments-assault-style-gun-definition_4913137.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 23:10:34+00:00

Hunting rifles are seen on display in a glass case at a gun and rifle store in downtown Vancouver in this file photo. (Jonathan Hayward/The Canadian Press)

## Ottawa Police Service Superintendent Arrested on Sex Charges
 - [https://www.theepochtimes.com/ottawa-police-service-superintendent-arrested-on-sex-charges_4913128.html](https://www.theepochtimes.com/ottawa-police-service-superintendent-arrested-on-sex-charges_4913128.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 23:07:58+00:00

A close-up of an Ottawa Police officer’s badge in Ottawa on April 28, 2022. (Adrian Wyld/The Canadian Press)

## Federal Public Debt Charges Up $2 Billion With Latest Interest Rate Hike: Budget Estimates
 - [https://www.theepochtimes.com/federal-public-debt-charges-up-2-billion-with-latest-interest-rate-hike-budget-estimates_4912969.html](https://www.theepochtimes.com/federal-public-debt-charges-up-2-billion-with-latest-interest-rate-hike-budget-estimates_4912969.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 22:41:03+00:00

The Bank of Canada is shown in Ottawa on July 12, 2022. (Sean Kilpatrick/The Canadian Press)

## Foreign Vessels Without Transponders Can Travel Undetected Through Canada’s Arctic: Auditor General
 - [https://www.theepochtimes.com/foreign-vessels-without-transponders-can-travel-undetected-through-canadas-arctic-auditor-general_4912384.html](https://www.theepochtimes.com/foreign-vessels-without-transponders-can-travel-undetected-through-canadas-arctic-auditor-general_4912384.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 22:27:57+00:00

Auditor General Karen Hogan during a news conference following the tabling of reports in Ottawa, Canada, on March 25, 2021. (Adrian Wyld/The Canadian Press)

## Feds Self-Assessing Their Response to COVID-19, Internal Audits Underway
 - [https://www.theepochtimes.com/feds-self-assessing-their-response-to-covid-19-internal-audits-underway_4912487.html](https://www.theepochtimes.com/feds-self-assessing-their-response-to-covid-19-internal-audits-underway_4912487.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 22:12:41+00:00

Paramedics take away an elderly patient at the Tendercare Living Centre, a long-term-care facility, during the COVID-19 pandemic in Scarborough, Ont., on Dec. 23, 2020. (Nathan Denette/The Canadian Press)

## MPs Reiterate Commitment to Vote in Favour of Senate Bill to Combat Forced Organ Harvesting and Trafficking
 - [https://www.theepochtimes.com/mps-reiterate-commitment-to-vote-in-favour-of-senate-bill-to-combat-forced-organ-harvesting-and-trafficking_4912137.html](https://www.theepochtimes.com/mps-reiterate-commitment-to-vote-in-favour-of-senate-bill-to-combat-forced-organ-harvesting-and-trafficking_4912137.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 22:00:05+00:00

Two doctors perform surgery in Chongqing, China, on Aug. 9, 2013. (Peter Parks/AFP/Getty Images)

## Castillo’s Instant Fall From Power Brought About by Political Missteps, Alienating Supporters
 - [https://www.theepochtimes.com/castillos-instant-fall-from-power-brought-about-by-political-missteps-alienating-supporters_4911480.html](https://www.theepochtimes.com/castillos-instant-fall-from-power-brought-about-by-political-missteps-alienating-supporters_4911480.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 21:48:41+00:00

Peru's President Pedro Castillo addresses the audience during the opening of the VII Ministerial Summit on Government and Digital Transformation of the Americas in Lima, Peru, on Nov. 10, 2022. (Sebastian Castaneda/Reuters)

## Marine Veteran Paul Whelan, Teacher Marc Fogel Among Americans Still Imprisoned in Russia
 - [https://www.theepochtimes.com/marine-veteran-paul-whelan-teacher-marc-fogel-among-americans-still-imprisoned-in-russia_4911825.html](https://www.theepochtimes.com/marine-veteran-paul-whelan-teacher-marc-fogel-among-americans-still-imprisoned-in-russia_4911825.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 21:07:08+00:00

Paul Whelan, a former U.S. Marine accused of spying and arrested in Russia, stands inside a defendants' cage during a hearing at a court in Moscow on Aug. 23, 2019. (Kirill Kudryavtsev/AFP via Getty Images)

## Farmers Want NSW Minister to Axe Gas Pipeline
 - [https://www.theepochtimes.com/farmers-want-nsw-minister-to-axe-gas-pipeline_4911082.html](https://www.theepochtimes.com/farmers-want-nsw-minister-to-axe-gas-pipeline_4911082.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 21:00:29+00:00

Treasurer, Matt Kean speaks during a press conference in Randwick in Sydney, Australia, on Oct. 18, 2021. (Brendon Thorne/Getty Images)

## ‘Don’t Understand’: US Marine Vet In Russian Prison ‘Greatly Disappointed’ After Britney Griner Swap
 - [https://www.theepochtimes.com/dont-understand-us-marine-vet-in-russian-prison-greatly-disappointed-after-britney-griner-swap_4912583.html](https://www.theepochtimes.com/dont-understand-us-marine-vet-in-russian-prison-greatly-disappointed-after-britney-griner-swap_4912583.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 20:52:19+00:00

Paul Whelan, a former U.S. marine who was arrested for alleged spying, listens to the verdict in a courtroom at the Moscow City Court in Moscow, Russia, Monday, June 15, 2020. The Moscow City Court on Monday convicted Paul Whelan on charges of espionage and sentenced him to 16 years in maximum security prison colony. Whelan has insisted on his innocence, saying he was set up. The U.S. Embassy has denounced Whelan's trial as unfair, pointing that no evidence has been provided. (Sofia Sandurskaya, Moscow News Agency photo via AP)

## Justin Trudeau Says He’s ‘Not Looking for a Fight With Alberta’ After Sovereignty Act Passes
 - [https://www.theepochtimes.com/justin-trudeau-says-hes-not-looking-for-a-fight-with-alberta-after-sovereignty-act-passes_4912378.html](https://www.theepochtimes.com/justin-trudeau-says-hes-not-looking-for-a-fight-with-alberta-after-sovereignty-act-passes_4912378.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 20:45:27+00:00

Prime Minister Justin Trudeau makes his way to his vehicle as he leaves the G20 Leaders Summit in Bali, Indonesia, on Nov. 16, 2022. (Sean Kilpatrick/The Canadian Press)

## Trudeau’s National Security Adviser Says She Hasn’t Seen Evidence of Chinese Funding to 11 Candidates
 - [https://www.theepochtimes.com/trudeaus-national-security-adviser-says-she-hasnt-seen-evidence-of-chinese-funding-to-11-candidates_4911817.html](https://www.theepochtimes.com/trudeaus-national-security-adviser-says-she-hasnt-seen-evidence-of-chinese-funding-to-11-candidates_4911817.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 20:38:37+00:00

National security adviser Jody Thomas appears as a witness at the Public Order Emergency Commission in Ottawa on Nov. 17, 2022. (Adrian Wyld/The Canadian Press)

## More Deportation Expected as UK Government Allows More Asylum Appeals Hearing
 - [https://www.theepochtimes.com/more-deportation-expected-as-uk-government-allows-more-asylum-appeals-hearing_4911741.html](https://www.theepochtimes.com/more-deportation-expected-as-uk-government-allows-more-asylum-appeals-hearing_4911741.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 20:12:11+00:00

Detainees inside the Manston short-term holding centre for illegal immigrants wave to members of the media outside, near Ramsgate, Kent, southeast England, on Nov. 3, 2022. (Daniel Leal /AFP via Getty Images)

## Action After Alleged Gas Cartel Attempt
 - [https://www.theepochtimes.com/action-after-alleged-gas-cartel-attempt_4911073.html](https://www.theepochtimes.com/action-after-alleged-gas-cartel-attempt_4911073.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 19:52:14+00:00

A gas burner is pictured on a cooker in a private home in Bordeaux, soutwestern France, on Dec. 13, 2012. (Regis Duvignau/Reuters)

## RCMP Contract With China-Linked Company for Communications Equipment Is Suspended
 - [https://www.theepochtimes.com/rcmp-contract-with-china-linked-company-for-communications-equipment-is-suspended_4912430.html](https://www.theepochtimes.com/rcmp-contract-with-china-linked-company-for-communications-equipment-is-suspended_4912430.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 19:47:54+00:00

Minister of Public Safety Marco Mendicino speaks during question period in the House of Commons on Parliament Hill in Ottawa on Oct. 4, 2022. (Sean Kilpatrick/The Canadian Press)

## Mask Wearing for Children Was Not Risk-Assessed for 17 Months in the UK: FOI
 - [https://www.theepochtimes.com/mask-wearing-for-children-was-not-risk-assessed-for-17-months-in-the-uk-foi_4908585.html](https://www.theepochtimes.com/mask-wearing-for-children-was-not-risk-assessed-for-17-months-in-the-uk-foi_4908585.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 19:10:00+00:00

Year 10 students wear face masks as they take part in a science class at Park Lane Academy in Halifax, northwest England, on Jan. 4, 2022. (Oli Scarff/AFP via Getty Images)

## ECA International: New York Is the Most Expensive City in the World, Hong Kong Second
 - [https://www.theepochtimes.com/eca-international-new-york-is-the-most-expensive-city-in-the-world-hong-kong-second_4911231.html](https://www.theepochtimes.com/eca-international-new-york-is-the-most-expensive-city-in-the-world-hong-kong-second_4911231.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 18:33:47+00:00

Human resource consulting agency, ECA International,  released its latest report on the cost of living on Dec. 7, which showed that New York had overtaken HK to become the most expensive city in the world. (Adrian Yu /The Epoch Times)

## Hong Kong Halted for an Unprecedented Mourning of Former CCP Leader Jiang Zemin
 - [https://www.theepochtimes.com/hong-kong-halted-for-an-unprecedented-mourning-of-former-ccp-leader-jiang-zemin_4911051.html](https://www.theepochtimes.com/hong-kong-halted-for-an-unprecedented-mourning-of-former-ccp-leader-jiang-zemin_4911051.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 18:13:04+00:00

A livestream broadcast of the memorial for Jiang Zemin in Sau Mau Ping Community Hall on Dec. 6, 2022. (Courtesy of Information Services Department)

## British Education Secretary Says White Privilege Is Not a ‘Fact’
 - [https://www.theepochtimes.com/british-education-secretary-says-white-privilege-is-not-a-fact_4911458.html](https://www.theepochtimes.com/british-education-secretary-says-white-privilege-is-not-a-fact_4911458.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 18:00:41+00:00

Education Secretary Gillian Keegan arrives in Downing Street, London, ahead of the first Cabinet meeting with Rishi Sunak as Prime Minister, on Oct. 26, 2022. (PA Media)

## UK Border Force Strikes Threaten ‘Serious’ Travel Chaos Over Christmas
 - [https://www.theepochtimes.com/uk-border-force-strikes-threaten-serious-travel-chaos-over-christmas_4911964.html](https://www.theepochtimes.com/uk-border-force-strikes-threaten-serious-travel-chaos-over-christmas_4911964.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 17:17:37+00:00

UK border signs are pictured at the passport control in Arrivals in Terminal 2 at Heathrow Airport in London on July 16, 2019. (Daniel Leal/AFP via Getty Images)

## US Government Employee Avoids Jail for Causing Death of UK Motorcyclist Harry Dunn
 - [https://www.theepochtimes.com/us-government-employee-avoids-jail-for-causing-death-of-uk-motorcyclist-harry-dunn_4911481.html](https://www.theepochtimes.com/us-government-employee-avoids-jail-for-causing-death-of-uk-motorcyclist-harry-dunn_4911481.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 17:00:49+00:00

Harry Dunn in an undated file photo. (Family handout/PA)

## New Zealand Chinese Rally to Support ‘White Paper Revolution’
 - [https://www.theepochtimes.com/new-zealand-chinese-rally-to-support-white-paper-revolution_4905336.html](https://www.theepochtimes.com/new-zealand-chinese-rally-to-support-white-paper-revolution_4905336.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 16:57:33+00:00

Chinese New Zealanders gather at Aotea Square in downtown Auckland on Dec. 2, 2022. (Shawn Lin / The Epoch Times)

## British Government Mulls Banning Strikes by Health Care Workers
 - [https://www.theepochtimes.com/british-government-mulls-banning-strikes-by-health-care-workers_4911524.html](https://www.theepochtimes.com/british-government-mulls-banning-strikes-by-health-care-workers_4911524.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 16:45:34+00:00

In this file image, an ambulance passes demonstrators protesting  during a strike by junior doctors outside the Basingstoke and North Hampshire Hospital on April 26, 2016. (Adrian Dennis/AFP via Getty Images)

## Alberta Passes Amended Sovereignty Act After Late-Night Legislature Debate
 - [https://www.theepochtimes.com/alberta-passes-amended-sovereignty-act-after-late-night-legislature-debate_4911840.html](https://www.theepochtimes.com/alberta-passes-amended-sovereignty-act-after-late-night-legislature-debate_4911840.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 16:35:42+00:00

Alberta Premier Danielle Smith holds her first press conference in Edmonton on Oct. 11, 2022. (Jason Franson/The Canadian Press)

## Juror Faces Jail After Being Convicted of Taking £5,000 Bribe to Acquit UK Drug Dealer
 - [https://www.theepochtimes.com/juror-faces-jail-after-being-convicted-of-taking-5000-bribe-to-acquit-uk-drug-dealer_4911390.html](https://www.theepochtimes.com/juror-faces-jail-after-being-convicted-of-taking-5000-bribe-to-acquit-uk-drug-dealer_4911390.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 15:48:52+00:00

Damien Drackley—a juror on trial for conspiracy to pervert the course of justice—arrives at the Old Bailey, London, on Dec. 8, 2022. (PA)

## Former Kelowna, BC, Mayor Colin Basran Charged With Sexual Assault
 - [https://www.theepochtimes.com/former-kelowna-bc-mayor-colin-basran-charged-with-sexual-assault_4911755.html](https://www.theepochtimes.com/former-kelowna-bc-mayor-colin-basran-charged-with-sexual-assault_4911755.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 15:46:03+00:00

British Columbia's provincial flag flies in Ottawa, on July 3, 2020. A government-commissioned panel is recommending against the introduction of a basic income for all in British Columbia. (The Canadian Press/Adrian Wyld)

## Liberals Set to Introduce Promised Child-Care Legislation
 - [https://www.theepochtimes.com/liberals-set-to-introduce-promised-child-care-legislation_4911747.html](https://www.theepochtimes.com/liberals-set-to-introduce-promised-child-care-legislation_4911747.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 15:42:43+00:00

Families, Children and Social Development Minister Karina Gould stands during question period in the House of Commons on Parliament Hill in Ottawa, on Oct. 17, 2022. (The Canadian Press/Sean Kilpatrick)

## End of Era as Last Surviving Member of RAF’s Dambusters Squadron Dies Aged 101
 - [https://www.theepochtimes.com/end-of-era-as-last-surviving-member-of-rafs-dambusters-squadron-dies-aged-101_4911305.html](https://www.theepochtimes.com/end-of-era-as-last-surviving-member-of-rafs-dambusters-squadron-dies-aged-101_4911305.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 15:02:26+00:00

George "Johnny" Johnson—who has died aged 101—pictured at his home in Bristol, England, on Jan. 5, 2017. (PA)

## As Europe Retreats From Gender Affirmative Care, US Rushes Forward: Psychiatrist
 - [https://www.theepochtimes.com/health/as-europe-retreats-from-gender-affirmative-care-us-rushes-forward-psychiatrist_4891418.html](https://www.theepochtimes.com/health/as-europe-retreats-from-gender-affirmative-care-us-rushes-forward-psychiatrist_4891418.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 15:00:27+00:00

General view of the LGBTQIA+ (lesbian, gay, bisexual, transgender, questioning, intersex, asexual, and agender) flag outside the RICS London Bookshop during UK Pride Month 2021 in London on June 1, 2021. (Edward Smith/ Getty Images)

## Wife of US Diplomat to Be Sentenced for Causing Death of British Teen
 - [https://www.theepochtimes.com/wife-of-us-diplomat-to-be-sentenced-for-causing-death-of-british-teen_4911555.html](https://www.theepochtimes.com/wife-of-us-diplomat-to-be-sentenced-for-causing-death-of-british-teen_4911555.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 14:38:18+00:00

Harry Dunn. (Courtesy of justice4Harry/Facebook)

## First New UK Coal Mine in 30 Years Approved to Ire of Environmentalists
 - [https://www.theepochtimes.com/first-new-uk-coal-mine-in-30-years-approved-to-ire-of-environmentalists_4911514.html](https://www.theepochtimes.com/first-new-uk-coal-mine-in-30-years-approved-to-ire-of-environmentalists_4911514.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 14:37:32+00:00

A general view of the former Woodhouse Colliery site where West Cumbria Mining (WCM) is planning to once again extract coal, in Whitehaven, England, on March 16, 2021. (Christopher Furlong/Getty Images)

## Firearms Bill: 2 Liberal MPs Oppose Government’s Latest Gun Restriction Proposals
 - [https://www.theepochtimes.com/firearms-bill-2-liberal-mps-oppose-governments-latest-gun-restriction-proposals_4911456.html](https://www.theepochtimes.com/firearms-bill-2-liberal-mps-oppose-governments-latest-gun-restriction-proposals_4911456.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 14:35:38+00:00

Liberal MP for Yukon Brendan Hanley rises in the House of Commons in Ottawa on Dec. 7, 2021 in Ottawa. (The Canadian Press/Adrian Wyld)

## Nigeria Limits Weekly, Daily ATM Cash Withdrawals to Push Digital Currency Use
 - [https://www.theepochtimes.com/nigeria-limits-weekly-daily-atm-cash-withdrawals-to-push-digital-currency-use_4911001.html](https://www.theepochtimes.com/nigeria-limits-weekly-daily-atm-cash-withdrawals-to-push-digital-currency-use_4911001.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 10:33:36+00:00

People wait within markings to use the ATM, as authorities ease a lockdown following a COVID-19 outbreak, in Abuja, Nigeria, May 4, 2020. (Afolabi Sotunde/Reuters)

## Iran Officials Sentence 5 to Death for Killing Basij Troop
 - [https://www.theepochtimes.com/iran-officials-sentence-5-to-death-for-killing-basij-troop_4906646.html](https://www.theepochtimes.com/iran-officials-sentence-5-to-death-for-killing-basij-troop_4906646.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 09:47:54+00:00

People walk past buildings which burned during protests that followed the authorities' decision to raise gasoline prices, in  Karaj, west of the capital Tehran, Iran on Nov. 18, 2019. (Masoume Aliakbar/ISNA via AP)

## Climate Protesters Hurl Paint at Milan’s La Scala Opera House
 - [https://www.theepochtimes.com/climate-protesters-hurl-paint-at-milans-la-scala-opera-house_4908865.html](https://www.theepochtimes.com/climate-protesters-hurl-paint-at-milans-la-scala-opera-house_4908865.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 09:16:32+00:00

The La Scala opera house reopens to the public after being closed amid the COVID-19 pandemic, in Milan on May 10, 2021. (Flavio Lo Scalzo/Reuters)

## Suspicious Packages Sent to Ukrainian Missions Came From Germany: Kyiv
 - [https://www.theepochtimes.com/suspicious-packages-sent-to-ukrainian-missions-came-from-germany-kyiv_4909076.html](https://www.theepochtimes.com/suspicious-packages-sent-to-ukrainian-missions-came-from-germany-kyiv_4909076.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 09:10:40+00:00

Police cordon off the perimeter outside the Ukrainian embassy in Madrid after a bloody package arrived at the embassy, on Dec. 2, 2022. (Violeta Santos Moura/Reuters)

## Putin Says Ukraine Fight Is Taking Longer Than Expected
 - [https://www.theepochtimes.com/putin-says-ukraine-fight-is-taking-longer-than-expected_4909938.html](https://www.theepochtimes.com/putin-says-ukraine-fight-is-taking-longer-than-expected_4909938.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 09:07:22+00:00

Russian President Vladimir Putin gestures while speaking during the annual meeting of the Presidential Council for Civil Society and Human Rights via videoconference in Moscow on Dec. 7, 2022. (Mikhail Metzel, Sputnik, Kremlin Pool Photo via AP)

## Moscow Says 3 Killed in Ukrainian Drone Attacks on Air Bases Deep Inside Russia
 - [https://www.theepochtimes.com/moscow-says-3-killed-in-ukrainian-drone-attacks-on-air-bases-deep-inside-russia_4904950.html](https://www.theepochtimes.com/moscow-says-3-killed-in-ukrainian-drone-attacks-on-air-bases-deep-inside-russia_4904950.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 08:57:16+00:00

Explosions rocked two air bases in Russia on Dec. 5, 2022. (AP)

## Russia’s Putin Drives Across Repaired Bridge to Crimea
 - [https://www.theepochtimes.com/russias-putin-drives-across-repaired-bridge-to-crimea_4904928.html](https://www.theepochtimes.com/russias-putin-drives-across-repaired-bridge-to-crimea_4904928.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 08:24:38+00:00

Russian President Vladimir Putin (C) and Deputy Prime Minister Marat Khusnullin (L) visit the Crimean Bridge connecting Russian mainland and Crimean peninsula over the Kerch Strait, which was damaged by a truck bomb attack in October, after restoration works, not far from Kerch, Crimea, on Dec. 5, 2022. (Mikhail Metzel, Sputnik, Kremlin Pool Photo via AP)

## China Trade Shrinks Amid Virus Pressure, Interest Rate Hikes
 - [https://www.theepochtimes.com/china-trade-shrinks-amid-virus-pressure-interest-rate-hikes_4908626.html](https://www.theepochtimes.com/china-trade-shrinks-amid-virus-pressure-interest-rate-hikes_4908626.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 08:20:59+00:00

A worker moves goods past a dismantled COVID-19 testing site outside shops after authorities start easing some of the anti-virus controls in Beijing on Dec. 7, 2022. (Andy Wong/AP Photo)

## EU Agrees Law to Make Airlines Pay More for Carbon Dioxide Emissions
 - [https://www.theepochtimes.com/eu-agrees-law-to-make-airlines-pay-more-for-carbon-dioxide-emissions_4908936.html](https://www.theepochtimes.com/eu-agrees-law-to-make-airlines-pay-more-for-carbon-dioxide-emissions_4908936.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 08:16:32+00:00

A plane during sunrise at the international airport in Munich on Jan. 9, 2018. (Michaela Rehle/Reuters)

## US Diplomat’s Wife Will Not Return to UK for Sentencing Over Fatal Car Crash
 - [https://www.theepochtimes.com/us-diplomats-wife-will-not-return-to-uk-for-sentencing-over-fatal-car-crash_4906516.html](https://www.theepochtimes.com/us-diplomats-wife-will-not-return-to-uk-for-sentencing-over-fatal-car-crash_4906516.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 07:42:52+00:00

A banner and a memorial area for British teenager Harry Dunn who died in a road traffic collision is pictured near to the entrance of RAF Croughton, in Croughton, near Brackley, Britain, on June 11, 2021. (Andrew Boyers/Reuters)

## Xi and Putin at Back Door, Destabilizing US From Behind
 - [https://www.theepochtimes.com/xi-putin-at-back-door-destabilizing-u-s-from-behind_4910764.html](https://www.theepochtimes.com/xi-putin-at-back-door-destabilizing-u-s-from-behind_4910764.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 06:04:31+00:00



## Call for Investigation Into Mortality Rates as Australia Sees Death Rate Spike
 - [https://www.theepochtimes.com/call-for-investigation-into-mortality-rates-as-australia-sees-death-rate-spike_4910768.html](https://www.theepochtimes.com/call-for-investigation-into-mortality-rates-as-australia-sees-death-rate-spike_4910768.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 05:39:08+00:00

Ambulances arrive at St Vincent's Hospital in Sydney, Australia on December 28, 2021. (Photo by Jenny Evans/Getty Images)

## Fight for Hong Kong’s Freedom Wins Cross-Party Support in Australia
 - [https://www.theepochtimes.com/fight-for-hong-kongs-freedom-wins-cross-party-support-in-australia_4910685.html](https://www.theepochtimes.com/fight-for-hong-kongs-freedom-wins-cross-party-support-in-australia_4910685.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 05:33:52+00:00

Supporters gather during a Rally for Hong Kong outside the State Library of Victoria in Melbourne, Saturday, June 12, 2021. (AAP Image/James Ross)

## Left-Wing Melbourne Council Votes to Stop Holding Citizenship Ceremonies on Australia Day
 - [https://www.theepochtimes.com/left-wing-melbourne-council-votes-to-stop-holding-citizenship-ceremonies-on-australia-day_4910889.html](https://www.theepochtimes.com/left-wing-melbourne-council-votes-to-stop-holding-citizenship-ceremonies-on-australia-day_4910889.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 05:26:42+00:00

Jetski’s fly the Australian and Aboriginal flags during Australia Day celebrations at Circular Quay, in Sydney, Australia, on Jan. 26, 2021. (AAP Image/Dan Himbrechts)

## Six Countries Join Forces for Humanitarian Christmas Drop to Remote Pacific Islands
 - [https://www.theepochtimes.com/six-countries-join-forces-for-humanitarian-christmas-drop-to-remote-pacific-islands_4910894.html](https://www.theepochtimes.com/six-countries-join-forces-for-humanitarian-christmas-drop-to-remote-pacific-islands_4910894.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 04:01:16+00:00

Two U.S. Air Force B-1B bombers, top center, four South Korean Air Force F-35 fighter jets and four U.S. Air Force F-16 fighter jets fly over South Korea Peninsula during a joint air drill called "Vigilant Storm," in South Korea on Nov. 5, 2022. (South Korean Defense Ministry via AP)

## Amendments to Investment Canada Act to Toughen on Foreign Investments: Innovation Minister
 - [https://www.theepochtimes.com/amendments-to-investment-canada-act-to-toughen-on-foreign-investments-innovation-minister_4910470.html](https://www.theepochtimes.com/amendments-to-investment-canada-act-to-toughen-on-foreign-investments-innovation-minister_4910470.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 03:54:00+00:00

Innovation, Science, and Industry Minister Francois-Philippe Champagne responds to a question during Question Period, on Nov. 16, 2022 in Ottawa. (Adrian Wyld/The Canadian Press)

## More Than Half of Canadians Worried About Putting Food on the Table: Poll
 - [https://www.theepochtimes.com/more-than-half-of-canadians-worried-about-putting-food-on-the-table-poll_4910587.html](https://www.theepochtimes.com/more-than-half-of-canadians-worried-about-putting-food-on-the-table-poll_4910587.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 03:15:05+00:00

A woman shops for produce in a grocery store in Toronto, Canada, in a file photo. (Nathan Denette/The Canadian Press)

## Muzzling Medical Free Speech
 - [https://www.theepochtimes.com/muzzling-medical-free-speech_4910748.html](https://www.theepochtimes.com/muzzling-medical-free-speech_4910748.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 02:34:25+00:00

Registered nurse Elle Lauron cares for a COVID-19 patient in the improvised unit at Providence Holy Cross Medical Center in the Mission Hills neighborhood in Los Angeles, Calif., on July 30, 2021. (Mario Tama/Getty Images)

## AMA Warns Changes to Private Health Insurance Could See People Abandoned By Insurers
 - [https://www.theepochtimes.com/ama-warns-changes-to-private-health-insurance-could-see-people-abandoned-by-insurers_4908141.html](https://www.theepochtimes.com/ama-warns-changes-to-private-health-insurance-could-see-people-abandoned-by-insurers_4908141.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 02:23:13+00:00

A doctor speaks with a patient during triage at the St George Hospital in Sydney, Australia, on May 15, 2020. (Lisa Maree Williams/Getty Images)

## Like Australia, Canada Should Cut Red Tape in Critical Minerals Industry: Analyst
 - [https://www.theepochtimes.com/like-australia-canada-should-cut-red-tape-in-critical-minerals-industry-analyst_4909849.html](https://www.theepochtimes.com/like-australia-canada-should-cut-red-tape-in-critical-minerals-industry-analyst_4909849.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2022-12-08 00:23:23+00:00

Teck’s Highland Valley Copper mine in the British Columbia Interior in a file photo. Copper has been identified as a critical mineral for Canada. (The Canadian Press/Jonathan Hayward)


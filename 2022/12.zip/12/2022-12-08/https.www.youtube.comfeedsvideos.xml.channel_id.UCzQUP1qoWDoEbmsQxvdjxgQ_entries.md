# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Beekeeper Erika Thompson Explains How Bee Colonies Work
 - [https://www.youtube.com/watch?v=Zr2yeYkysk0](https://www.youtube.com/watch?v=Zr2yeYkysk0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-12-08 00:00:00+00:00

Taken from JRE #1908 w/Erika Thompson:
https://open.spotify.com/episode/6dMVMejS0LwF3us4oYIInd?si=dd9bacd780f74d2c


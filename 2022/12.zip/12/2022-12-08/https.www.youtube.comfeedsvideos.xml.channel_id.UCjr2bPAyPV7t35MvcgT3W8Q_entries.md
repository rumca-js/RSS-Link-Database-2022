# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## How Kurzgesagt Cooks Propaganda For Billionaires
 - [https://www.youtube.com/watch?v=HjHMoNGqQTI](https://www.youtube.com/watch?v=HjHMoNGqQTI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2022-12-08 13:14:27+00:00

Kurzgesagt is not just a popular science outreach channel. It's a major tool for propaganda of their billionaire sponsors.
Support independent research and analysis by joining my Patreon page: https://www.patreon.com/thehatedone 

Kurzgesagt received estimated $7 million from billionaire funds. This would be more money than Kurzgesagt received from their supporters on Patreon (estimated $3.5 million) in the entire history of the channel.

Kurzgesagt never was this small, independent, almost entirely viewer-funded channel. As soon as the studio incorporated, billionaires began lining up. They transformed the small Munich-based design studio with 5 employees into a multi-million-dollar media powerhouse with dozens of employees. 

Sources [First half only; second part in the pinned comment]
[0] https://web.archive.org/web/20221108134548/https://www.youtube.com/watch?v=qNWWrDBRBqk
[1] https://www.reuters.com/article/us-diseases-neglected-pharma-idUSTRE80T0LO20120130
[2] https://en.wikipedia.org/wiki/London_Declaration_on_Neglected_Tropical_Diseases
[3] https://www.gatesfoundation.org/Ideas/Media-Center/Press-Releases/2012/01/private-and-public-partners-unite-to-combat-10-neglected-tropical-diseases-by-2020
[4] https://www.businessinsider.com/r-fight-against-neglected-tropical-diseases-needs-big-pharma-push-who-2017-4
[5] https://www.latimes.com/nation/la-na-gates16dec16-story.html
[6] https://academic.oup.com/bmb/article/93/1/179/307584?
[7] https://www.thelancet.com/journals/lancet/article/PIIS0140673609608850/fulltext?
[8] https://www.vox.com/2015/6/10/8760199/gates-foundation-criticism
[9] https://jamanetwork.com/journals/jama/fullarticle/2762308
[10] https://www.thenation.com/article/society/bill-gates-foundation-philanthropy/
[11] https://www.latimes.com/archives/la-xpm-2007-jan-07-na-gatesx07-story.html
[12] https://www.washingtonpost.com/education/2020/02/10/bill-melinda-gates-have-spent-billions-dollars-shape-education-policy-now-they-say-theyre-skeptical-billionaires-trying-do-just-that/
[13] https://apnews.com/a4042e82ffaa4a34b50ceac464761957
[14] https://news.gallup.com/poll/1597/confidence-institutions.aspx
[15a] https://medium.com/@Kurzgesagt/kurzgesagt-sponsorships-on-youtube-3121a45b0fe9
[15b] https://web.archive.org/web/20221122151542/https://www.youtube.com/watch?v=0KQYNtPl7V4&amp;lc=Ugw7oaypQ3qALcugYzh4AaABAg 
[16] https://www.gatesfoundation.org/about/committed-grants/2015/11/opp1139276
[17] https://www.openphilanthropy.org/grants/kurzgesagt-video-creation-and-translation/
[18a] https://www.openphilanthropy.org/grants/kurzgesagt-short-form-video-content/
[18b] https://web.archive.org/web/20220000000000*/https://www.patreon.com/Kurzgesagt 
[19] https://ourworldindata.org/funding
[20] https://en.wikipedia.org/wiki/Our_World_In_Data#Funding_and_collaborations
[21] https://web.archive.org/web/20221108134123/https://www.youtube.com/watch?v=QsBT5EQt348
[22] https://ourworldindata.org/extreme-poverty-in-brief
[23] https://www.nytimes.com/2021/12/02/world/global-poverty-united-nations.html
[24] https://theconversation.com/why-the-world-banks-optimism-about-global-poverty-misses-the-point-104963
[25] https://www.theguardian.com/global-development-professionals-network/2015/nov/01/global-poverty-is-worse-than-you-think-could-you-live-on-190-a-day
[26] https://www.theguardian.com/commentisfree/2019/jan/29/bill-gates-davos-global-poverty-infographic-neoliberal
[27] https://newint.org/features/2019/07/01/long-read-progress-and-its-discontents
[28] https://www.theguardian.com/news/2019/feb/25/modern-slavery-trafficking-persons-one-in-200
[29] https://www.thelancet.com/journals/lanplh/article/PIIS2542-5196%2820%2930196-0/fulltext 
[30] https://oxfam.app.box.com/s/1rp115i9uiwmvsa11mwaa00vwc6ic437
[31] https://qz.com/1402301/bill-gatess-1-billion-energy-fund-is-expanding-its-portfolio-of-startups-fighting-climate-change
[32] https://www.wired.com/2015/11/zuckerberg-gates-climate-change-breakthrough-energy-coalition/
[33] https://qz.com/859860/bill-gates-is-leading-a-new-1-billion-fund-focused-on-combatting-climate-change-through-innovation
[34] https://news.stanford.edu/2019/10/25/study-casts-doubt-carbon-capture/
[35] https://www.wired.com/story/the-potential-pitfalls-of-sucking-carbon-from-the-atmosphere/
[36] https://www.technologyreview.com/2021/07/08/1027908/carbon-removal-hype-is-a-dangerous-distraction-climate-change/
[37] https://www.ipcc.ch/site/assets/uploads/sites/2/2019/06/SR15_Full_Report_High_Res.pdf
[38] https://grist.org/technology/orca-the-largest-carbon-removal-facility-to-date-is-up-and-running/
[39] https://climeworks.com/roadmap/orca
[40] https://www.ft.com/content/8a942e30-0428-4567-8a6c-dc704ba3460a

Follow me:
https://twitter.com/The_HatedOne_
https://www.reddit.com/r/thehatedone/

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.


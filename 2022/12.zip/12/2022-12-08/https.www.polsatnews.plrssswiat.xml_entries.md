# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Wielka Brytania: Do obiegu trafiły pierwsze monety z wizerunkiem króla Karola III
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/wielka-brytania-do-obiegu-trafily-pierwsze-monety-z-wizerunkiem-krola-karola-iii/](https://www.polsatnews.pl/wiadomosc/2022-12-08/wielka-brytania-do-obiegu-trafily-pierwsze-monety-z-wizerunkiem-krola-karola-iii/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 21:43:00+00:00

W czwartek po raz pierwszy do obiegu trafiły monety o nominale 50 pensów z wizerunkiem króla Karola III. Dzisiaj rozpoczęła się nowa era - powiedziała dyrektor Mennicy Królewskiej. Monety będą funkcjonować równolegle z tymi z podobizną królowej Elżbiety II.

## USA. Policja po 65 latach ustaliła tożsamość "chłopca z pudełka". Pomogło badanie DNA
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/usa-policja-po-65-latach-ustalila-tozsamosc-chlopca-z-pudelka-pomoglo-badanie-dna/](https://www.polsatnews.pl/wiadomosc/2022-12-08/usa-policja-po-65-latach-ustalila-tozsamosc-chlopca-z-pudelka-pomoglo-badanie-dna/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 20:56:00+00:00

Amerykańska policja po 65 latach ustaliła tożsamość chłopca z pudełka. Jego szczątki znaleziono w lesie w 1957 roku. Wiadomo było, że miał od czterech do sześciu lat, a prawdopodobną przyczyną śmierci było pobicie. Do teraz jednak tajemnicą pozostawało, kim jest zamordowany chłopiec i kto był jego oprawcą.

## Niemcy. Sekretarka dyrektora obozu przerywa milczenie. "Żałuję, że byłam w Stutthofie"
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/niemcy-sekretarka-dyrektora-obozu-przerywa-milczenie-zaluje-ze-bylam-w-stutthofie/](https://www.polsatnews.pl/wiadomosc/2022-12-08/niemcy-sekretarka-dyrektora-obozu-przerywa-milczenie-zaluje-ze-bylam-w-stutthofie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 20:24:00+00:00

Irmgard Furchner, sekretarka dyrektora obozu w Stutthof, podczas swojego procesu wyraziła żal, że była w miejscu kaźni w czasie II wojny światowej. Wciąż utrzymuje, że nie wiedziała o ludobójstwie dokonywanym przez nazistów. Furchner jest oskarżona o współudział w zabójstwie 10 tysięcy ludzi.

## USA: Restauracja anulowała rezerwację dla chrześcijańskiej organizacji. Powodem poglądy
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/usa-restauracja-anulowala-rezerwacje-dla-chrzescijanskiej-organizacji-powodem-poglady/](https://www.polsatnews.pl/wiadomosc/2022-12-08/usa-restauracja-anulowala-rezerwacje-dla-chrzescijanskiej-organizacji-powodem-poglady/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 19:49:00+00:00

Restauracja w amerykańskim Richmond anulowała rezerwację na prywatną imprezę w lokalu, organizowaną przez konserwatywną organizację chrześcijańską. Pracownicy postąpili tak, gdy dowiedzieli się, że ich niedoszli goście sprzeciwiają się małżeństwom homoseksualnym oraz prawu do aborcji. Tymczasem wielu pracowników restauracji należy do środowiska LGBT+.

## USA. 18-letni Jaylen Smith został najmłodszym czarnoskórym burmistrzem w historii kraju
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/usa-18-letni-jaylen-smith-zostal-najmlodszym-czarnoskorym-burmistrzem-w-historii-kraju/](https://www.polsatnews.pl/wiadomosc/2022-12-08/usa-18-letni-jaylen-smith-zostal-najmlodszym-czarnoskorym-burmistrzem-w-historii-kraju/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 15:27:00+00:00

18-letni student został najmłodszym czarnoskórym burmistrzem wybranym w historii USA. Jaylen Smith skończył szkołę średnią w maju, a we wtorek został wybrany na przywódcę małego miasteczka Earle w stanie Arkansas. Elektoratowi obiecał m.in. doprowadzenie do budowy dużego sklepu spożywczego, jak i zajęcie się opuszczonymi domami w okolicy.

## Strefa Schengen. Chorwacja dołączy od 1 stycznia 2023. Nie ma zgody dla Bułgarii i Rumunii
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/strefa-schengen-chorwacja-dolaczy-od-1-stycznia-2023-nie-ma-zgody-dla-bulgarii-i-rumunii/](https://www.polsatnews.pl/wiadomosc/2022-12-08/strefa-schengen-chorwacja-dolaczy-od-1-stycznia-2023-nie-ma-zgody-dla-bulgarii-i-rumunii/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 14:47:00+00:00

Państwa członkowskie UE potwierdziły w czwartek przyjęcie Chorwacji do strefy Schengen - poinformowali przedstawiciele władz w Zagrzebiu. Do umowy o bezpaszportowym wjeździe do państw chciały dołączyć również Rumunia oraz Bułgaria, ale te dwa kraje nie uzyskały zgody wszystkich rządów. Weto zgłosiły Niderlandy oraz Austria.

## Amerykańska koszykarka Brittney Griner zwolniona z więzienia w zamian  za Wiktora Buta
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/amerykanska-koszykarka-brittney-griner-zwolniona-z-wiezienia-w-zamian-za-wiktora-butaza/](https://www.polsatnews.pl/wiadomosc/2022-12-08/amerykanska-koszykarka-brittney-griner-zwolniona-z-wiezienia-w-zamian-za-wiktora-butaza/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 13:23:00+00:00

Amerykańska gwiazda koszykówki Brittney Griner została w czwartek zwolniona z więzienia w Rosji w zamian za uwolnienie Wiktora Buta, rosyjskiego handlarza bronią, który był w więzieniu w Stanach Zjednoczonych. Jest bezpieczna, jest w samolocie, w drodze do domu - napisał prezydent USA Joe Biden, który dodał, że jest po rozmowie ze sportsmenką.

## Włochy. Opera "Borys Godunow" w La Scali. Kontrowersje wokół rosyjskiego klasyka
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/wlochy-opera-borys-godunow-w-la-scali-kontrowersje-wokol-rosyjskiego-klasyka/](https://www.polsatnews.pl/wiadomosc/2022-12-08/wlochy-opera-borys-godunow-w-la-scali-kontrowersje-wokol-rosyjskiego-klasyka/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 11:58:00+00:00

Opera Borys Godunow Modesta Musorgskiego wystawiona na inaugurację sezonu w mediolańskiej La Scali wywołała spore kontrowersje. W gali udział wzięli m.in. prezydent Włoch Sergio Mattarella, premier Giorgia Meloni i szefowa KE Ursula von der Leyen. - Nie możemy pozwolić, aby Putin zniszczył ten fantastyczny kraj - powiedziała o Rosji ostatnia z wymienionych cytowana przez Ansę.

## USA. Ciało 21-letniego Polaka wyłowione z jeziora Michigen. Trwa śledztwo ws. śmierci
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/usa-cialo-21-letniego-polaka-wylowione-z-jeziora-michigen/](https://www.polsatnews.pl/wiadomosc/2022-12-08/usa-cialo-21-letniego-polaka-wylowione-z-jeziora-michigen/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 10:13:00+00:00

Ciało 21-letniego mężczyzny z Polski, który zaginął po weekendowym przyjęciu bożonarodzeniowym w River North, zostało wyłowione z jeziora Michigan na Oak Street Beach w środę rano - podaje portal abc7chicago.com. Krzysztof przyjechał do USA w połowie listopada w sprawach służbowych.

## Peru. Odwołano prezydenta Pedro Castillo. "Utracił moralną legitymację do sprawowania urzędu"
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/peru-odwolano-prezydenta-pedro-castillo-utracil-moralna-legitymacje-do-sprawowania-urzedu/](https://www.polsatnews.pl/wiadomosc/2022-12-08/peru-odwolano-prezydenta-pedro-castillo-utracil-moralna-legitymacje-do-sprawowania-urzedu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 09:53:00+00:00

Prezydent Peru, Pedro Castillo, w środę ogłosił, że zastępuje Kongres wyjątkowym rządem. Władza ustawodawcza zignorowała to i na nadzwyczajnym posiedzeniu odwołała go z urzędu i oskarżyła o próbę przejęcia władzy. W momencie aresztowania Castillo zmierzał do meksykańskiej ambasady w Limie - przekazały media.

## Mundial w Katarze. Kot wyrzucony z konferencji przez rzecznika prasowego reprezentacji Brazylii
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/mundial-w-katarze-kot-na-konferencji-wyrzucony-przez-brazylijczyka/](https://www.polsatnews.pl/wiadomosc/2022-12-08/mundial-w-katarze-kot-na-konferencji-wyrzucony-przez-brazylijczyka/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 09:41:00+00:00

Na stół, podczas konferencji reprezentanta Brazylii w Katarze, wskoczył kot. Rzecznik prasowy drużyny zdecydowanym ruchem zrzucił na podłogę niespodziewanego gościa. Zaskoczyło to obecnych dziennikarzy, którzy wyrazili niezadowolenie.

## Rosja. Władimir Putin o Polsce: Nacjonalistyczni politycy śnią o powrocie terytoriów historycznych
 - [https://www.polsatnews.pl/wiadomosc/2022-12-08/rosja-wladimir-putin-o-polsce-nacjonalistyczni-politycy-snia-opowrocie-terytoriow-historycznych/](https://www.polsatnews.pl/wiadomosc/2022-12-08/rosja-wladimir-putin-o-polsce-nacjonalistyczni-politycy-snia-opowrocie-terytoriow-historycznych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-12-08 05:20:00+00:00

Jedynym prawdziwym gwarantem integralności terytorialnej Ukrainy w jej obecnych granicach może być Rosja - powiedział prezydent Rosji Władimir Putin podczas spotkania z członkami Rady ds. Praw Człowieka. Jego zdaniem w Polsce nacjonalistyczni politycy śnią o powrocie tak zwanych terytoriów historycznych, które Ukraina otrzymała od Stalina. Putin tłumaczył się też z braku postępów na froncie.


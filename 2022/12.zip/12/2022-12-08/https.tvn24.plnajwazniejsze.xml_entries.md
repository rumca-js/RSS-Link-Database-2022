# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Kamil Majchrzak z pozytywnym wynikiem kontroli antydopingowej. Tenisista wydał oświadczenie
 - [https://eurosport.tvn24.pl/kamil-majchrzak-z-pozytywnym-wynikiem-kontroli-antydopingowej--tenisista-wyda--o-wiadczenie,1128428.html?source=rss](https://eurosport.tvn24.pl/kamil-majchrzak-z-pozytywnym-wynikiem-kontroli-antydopingowej--tenisista-wyda--o-wiadczenie,1128428.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 21:57:42+00:00

<img alt="Kamil Majchrzak z pozytywnym wynikiem kontroli antydopingowej. Tenisista wydał oświadczenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t2cqya-kamil-majchrzak-odpadl-z-turnieju-atp-250-w-winston-salem-6421319/alternates/LANDSCAPE_1280" />
    "Rozpocząłem najtrudniejszą walkę w moim życiu - walkę o udowodnienie swojej niewinności" - napisał.

## Koniec mundialu dla dwóch Portugalczyków
 - [https://eurosport.tvn24.pl/koniec-mundialu-dla-dw-ch-portugalczyk-w,1128337.html?source=rss](https://eurosport.tvn24.pl/koniec-mundialu-dla-dw-ch-portugalczyk-w,1128337.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 21:13:00+00:00

<img alt="Koniec mundialu dla dwóch Portugalczyków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7mmepp-portugalczycy-przystapia-do-cwiercfinalu-bez-dwoch-graczy/alternates/LANDSCAPE_1280" />
    Nuno Mendes i Danilo Pereira są kontuzjowani i nie mają już szans na występ w dalszej części turnieju.

## Kaczyński: przykro nam, ale w tej chwili nas na to jeszcze nie stać
 - [https://tvn24.pl/biznes/z-kraju/emerytury-stazowe-prezes-pis-jaroslaw-kaczynski-nie-stac-nas-na-to-6420663?source=rss](https://tvn24.pl/biznes/z-kraju/emerytury-stazowe-prezes-pis-jaroslaw-kaczynski-nie-stac-nas-na-to-6420663?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 20:44:39+00:00

<img alt="Kaczyński: przykro nam, ale w tej chwili nas na to jeszcze nie stać" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wxghmc-mid-22c08621-6420897/alternates/LANDSCAPE_1280" />
    Prezes PiS podczas spotkania w Chojnicach.

## "PiS nie ucieknie od sklejenia tej partii z człowiekiem, który dzisiaj siedzi w areszcie"
 - [https://tvn24.pl/najnowsze/sprawa-tomasz-l-komentuja-krzysztof-smiszek-i-adam-szlapka-6420634?source=rss](https://tvn24.pl/najnowsze/sprawa-tomasz-l-komentuja-krzysztof-smiszek-i-adam-szlapka-6420634?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 20:24:24+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-50vb5r-kropka-6420659/alternates/LANDSCAPE_1280" />
    Krzysztof Śmiszek i Adam Szłapka byli gośćmi "Kropki nad i".

## Wrona: zrealizował się plan Putina. "To jest zawsze kompromis, który cuchnie na odległość"
 - [https://tvn24.pl/go/programy,7/rozmowy-na-szczycie-odcinki,692593/odcinek-41,S00E41,932627?source=rss](https://tvn24.pl/go/programy,7/rozmowy-na-szczycie-odcinki,692593/odcinek-41,S00E41,932627?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 20:05:24+00:00

<img alt="Wrona: zrealizował się plan Putina. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-k0gjb9-wymiana-wiezniow-6420701/alternates/LANDSCAPE_1280" />
    Marcin Wrona i Jacek Stawiski o wymianie więźniów między USA a Rosją.

## "Rosjanie nie są w stanie zbudować szczelnej obrony strategicznych obiektów"
 - [https://tvn24.pl/swiat/jurij-butusow-rosjanie-nie-sa-w-stanie-zbudowac-szczelnej-obrony-swoich-strategicznych-obiektow-6420614?source=rss](https://tvn24.pl/swiat/jurij-butusow-rosjanie-nie-sa-w-stanie-zbudowac-szczelnej-obrony-swoich-strategicznych-obiektow-6420614?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 19:58:32+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7ovw9n-zdjecie-uszkodzonego-tu-22m-na-lotnisku-pod-riazaniem-6420616/alternates/LANDSCAPE_1280" />
    Jurij Butusow o ataku na rosyjskie bazy lotnicze pod Riazaniem i Engelsem.

## "Mamy do czynienia z szeregiem nieprawdopodobnych rzeczy"
 - [https://tvn24.pl/polska/sprawa-tomasza-l-zatrzymanego-pod-zarzutem-szpiegostwa-na-rzecz-rosji-janusz-zemke-komentuje-6420613?source=rss](https://tvn24.pl/polska/sprawa-tomasza-l-zatrzymanego-pod-zarzutem-szpiegostwa-na-rzecz-rosji-janusz-zemke-komentuje-6420613?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 19:45:16+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2b5n4j-janusz-zemke-6420639/alternates/LANDSCAPE_1280" />
    Janusz Zemke w "Faktach po Faktach".

## Ronaldo groził opuszczeniem kadry? Portugalska federacja zaprzecza
 - [https://eurosport.tvn24.pl/ronaldo-grozi--opuszczeniem-kadry--portugalska-federacja-zaprzecza,1128390.html?source=rss](https://eurosport.tvn24.pl/ronaldo-grozi--opuszczeniem-kadry--portugalska-federacja-zaprzecza,1128390.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 19:11:00+00:00

<img alt="Ronaldo groził opuszczeniem kadry? Portugalska federacja zaprzecza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0i5rgp-cristiano-ronaldo/alternates/LANDSCAPE_1280" />
    Pogłoski na ten temat nasiliły się, gdy napastnik nie pojawił się na środowym treningu kadry.

## "Przywieźli nas do obozu i zaczęli usuwać ciąże"
 - [https://fakty.tvn24.pl/-przywie-li-nas-do-obozu-i-zacz-li-usuwa--ci--e---wstrz-saj-ce-ustalenia-dziennikarzy,1128419.html?source=rss](https://fakty.tvn24.pl/-przywie-li-nas-do-obozu-i-zacz-li-usuwa--ci--e---wstrz-saj-ce-ustalenia-dziennikarzy,1128419.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 19:10:18+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5jvgjv-przywiezli-nas-do-obozu-i-zaczeli-usuwac-ciaze-6426788/alternates/LANDSCAPE_1280" />
    Wstrząsające ustalenia dziennikarzy.

## Dominacja Kubackiego. "Pierwszy skok był solidny, drugiego sam się boję"
 - [https://eurosport.tvn24.pl/dominacja-kubackiego---pierwszy-skok-by--solidny--drugiego-sam-si--boj--,1128386.html?source=rss](https://eurosport.tvn24.pl/dominacja-kubackiego---pierwszy-skok-by--solidny--drugiego-sam-si--boj--,1128386.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 18:32:00+00:00

<img alt="Dominacja Kubackiego. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-y1ibqt-dawid-kubacki-rzadzil-na-treningach-w-titisee-neustadt/alternates/LANDSCAPE_1280" />
    Dawid Kubacki okazał się najlepszy w trzech czwartkowych seriach treningowych.

## Seria wybuchów w okupowanym Berdiańsku. "Słyszało całe miasto"
 - [https://tvn24.pl/swiat/ukraina-seria-wybuchow-w-okupowanym-berdiansku-atak-na-rosyjska-baze-wojskowa-6420599?source=rss](https://tvn24.pl/swiat/ukraina-seria-wybuchow-w-okupowanym-berdiansku-atak-na-rosyjska-baze-wojskowa-6420599?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 18:28:51+00:00

<img alt="Seria wybuchów w okupowanym Berdiańsku. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1pe67y-berdiansk-6420603/alternates/LANDSCAPE_1280" />
    W rosyjskiej bazie wojskowej doszło do trzech potężnych eksplozji, a później do kolejnych, o mniejszej sile.

## Ciężarna kobieta mieszkała w betonowej wiacie. Gdy ją znaleźli, leżała pod starymi kołdrami
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mysliborska-ciezarna-kobieta-mieszkala-pod-betonowa-wiata-na-bialolece-6420593?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mysliborska-ciezarna-kobieta-mieszkala-pod-betonowa-wiata-na-bialolece-6420593?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 18:25:34+00:00

<img alt="Ciężarna kobieta mieszkała w betonowej wiacie. Gdy ją znaleźli, leżała pod starymi kołdrami" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-fulc0c-straznicy-pomogli-tez-konkubentowi-26-latki-6420612/alternates/LANDSCAPE_1280" />
    Strażnicy miejscy przekonali 26-latkę, by pojechała do szpitala.

## Kolejna transza potrącona. Straciliśmy 1,4 miliarda złotych
 - [https://tvn24.pl/biznes/z-kraju/ke-potracila-kolejna-transze-z-funduszy-ue-dla-polski-kara-za-izbe-dyscyplinarna-6420543?source=rss](https://tvn24.pl/biznes/z-kraju/ke-potracila-kolejna-transze-z-funduszy-ue-dla-polski-kara-za-izbe-dyscyplinarna-6420543?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 17:37:02+00:00

<img alt="Kolejna transza potrącona. Straciliśmy 1,4 miliarda złotych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0jl13x-komisja-europejska-5452065/alternates/LANDSCAPE_1280" />
    Wynika z ustaleń korespondenta TVN24 w Brukseli Macieja Sokołowskiego.

## Rosja odzyskała "handlarza śmiercią". Dla Kremla to "kwestia honoru i bezwzględnego pragmatyzmu"
 - [https://tvn24.pl/swiat/zea-usa-dokonaly-wymiany-wiezniow-z-rosja-za-mloda-koszykarkeuwolnily-znanego-rosyjskiego-handlarza-bronia-6420410?source=rss](https://tvn24.pl/swiat/zea-usa-dokonaly-wymiany-wiezniow-z-rosja-za-mloda-koszykarkeuwolnily-znanego-rosyjskiego-handlarza-bronia-6420410?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 17:24:35+00:00

<img alt="Rosja odzyskała " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5vvmhv-pap20080922034-6420442/alternates/LANDSCAPE_1280" />
    Wymiany na linii Rosja - USA dokonano na lotnisku w Abu Zabi

## Ostatni raz coś takiego zdarzyło się 15 lat temu. Tydzień po zakończeniu sezonu ryzyko burzy tropikalnej
 - [https://tvn24.pl/tvnmeteo/swiat/ostatni-raz-cos-takiego-zdarzylo-sie-15-lat-temu-tydzien-po-zakonczeniu-sezonu-pojawilo-sie-ryzyko-burzy-tropikalnej-6420550?source=rss](https://tvn24.pl/tvnmeteo/swiat/ostatni-raz-cos-takiego-zdarzylo-sie-15-lat-temu-tydzien-po-zakonczeniu-sezonu-pojawilo-sie-ryzyko-burzy-tropikalnej-6420550?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 17:23:47+00:00

<img alt="Ostatni raz coś takiego zdarzyło się 15 lat temu. Tydzień po zakończeniu sezonu ryzyko burzy tropikalnej" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-j07lt4-huragan-nicole-na-atlantyku-zdjecie-satelitarne-z-dnia-8112022-6420581/alternates/LANDSCAPE_1280" />
    Prognozy meteorologów z AccuWeather.

## Łzy papieża Franciszka i załamujący się głos
 - [https://tvn24.pl/swiat/rzym-lzy-papieza-franciszka-w-czasie-modlitwy-o-pokoj-w-ukrainie-6420515?source=rss](https://tvn24.pl/swiat/rzym-lzy-papieza-franciszka-w-czasie-modlitwy-o-pokoj-w-ukrainie-6420515?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 17:13:22+00:00

<img alt="Łzy papieża Franciszka i załamujący się głos " src="https://tvn24.pl/najnowsze/cdn-zdjecie-l8ibbb-papa-6420545/alternates/LANDSCAPE_1280" />
    W czasie modlitwy o pokój w Ukrainie.

## Glapiński o tym, jak poradzić sobie z otaczającą rzeczywistością. "To naprawdę człowieka uspokaja"
 - [https://tvn24.pl/biznes/z-kraju/glapinski-o-tym-jak-poradzic-sobie-z-otaczajaca-rzeczywistoscia-to-naprawde-czlowieka-uspokaja-6420482?source=rss](https://tvn24.pl/biznes/z-kraju/glapinski-o-tym-jak-poradzic-sobie-z-otaczajaca-rzeczywistoscia-to-naprawde-czlowieka-uspokaja-6420482?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 17:08:09+00:00

<img alt="Glapiński o tym, jak poradzić sobie z otaczającą rzeczywistością. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-s1t4om-prezes-narodowego-banku-polskiego-adam-glapinski-podczas-konferencji-prasowej-6420522/alternates/LANDSCAPE_1280" />
    Szef NBP podczas konferencji prasowej.

## Człowiek-choinka przebił opony w 21 pojazdach
 - [https://tvn24.pl/polska/warzymice-policja-szuka-czlowieka-choinki-monitoring-nagral-jak-niszczy-auta-nalezace-do-hurtowni-miesa-6420288?source=rss](https://tvn24.pl/polska/warzymice-policja-szuka-czlowieka-choinki-monitoring-nagral-jak-niszczy-auta-nalezace-do-hurtowni-miesa-6420288?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 16:57:45+00:00

<img alt="Człowiek-choinka przebił opony w 21 pojazdach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6zcrlh-czlowiek-choinka-przebil-opony-w-21-pojazdach-zdjecie-z-monitoringu-6420511/alternates/LANDSCAPE_1280" />
    Szuka go policja, zobacz nagranie.

## Hurkacz awansował do ćwierćfinału
 - [https://eurosport.tvn24.pl/hurkacz-jako-pierwszy-zdoby--po-10-punkt-w--awansowa--do--wier-fina-u,1128368.html?source=rss](https://eurosport.tvn24.pl/hurkacz-jako-pierwszy-zdoby--po-10-punkt-w--awansowa--do--wier-fina-u,1128368.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 16:56:00+00:00

<img alt="Hurkacz awansował do ćwierćfinału" src="https://tvn24.pl/najnowsze/cdn-zdjecie-paxlz1-hubert-hurkacz-w-akcji/alternates/LANDSCAPE_1280" />
    Wygrał z Dominikiem Strickerem.

## Policja podała personalia "chłopca z pudełka" i najnowsze ustalenia w sprawie
 - [https://tvn24.pl/swiat/usa-chlopiec-z-pudelka-policja-ujawnila-personalia-6420398?source=rss](https://tvn24.pl/swiat/usa-chlopiec-z-pudelka-policja-ujawnila-personalia-6420398?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 16:50:19+00:00

<img alt="Policja podała personalia " ch="ch" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0gtid9-anonimowy-grob-chlopca-z-pudelka-na-cmentarzu-w-filadelfii-6420457/alternates/LANDSCAPE_1280" />
    "Po 65 latach przywrócono imię Nieznanemu Dziecku Ameryki"

## Błyskawiczny powrót Glika na ligowe boiska po mundialu
 - [https://eurosport.tvn24.pl/b-yskawiczny-powr-t-glika-na-ligowe-boiska-po-mundialu,1128361.html?source=rss](https://eurosport.tvn24.pl/b-yskawiczny-powr-t-glika-na-ligowe-boiska-po-mundialu,1128361.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 16:30:00+00:00

<img alt="Błyskawiczny powrót Glika na ligowe boiska po mundialu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5n0uzd-kamil-glik-w-barwach-benevento/alternates/LANDSCAPE_1280" />
    Obrońca zagrał w barwach Benevento.

## Strefa Schengen powiększy się o kolejne państwo. To popularny kierunek wakacyjnych podróży Polaków
 - [https://tvn24.pl/biznes/ze-swiata/strefa-schengen-bedzie-wieksza-chorwacja-ma-zgode-ue-na-dolaczenie-do-strefy-od-2023-roku-6420492?source=rss](https://tvn24.pl/biznes/ze-swiata/strefa-schengen-bedzie-wieksza-chorwacja-ma-zgode-ue-na-dolaczenie-do-strefy-od-2023-roku-6420492?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 16:24:13+00:00

<img alt="Strefa Schengen powiększy się o kolejne państwo. To popularny kierunek wakacyjnych podróży Polaków " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3xuzn8-shutterstock2047921568-6420496/alternates/LANDSCAPE_1280" />
    Jednocześnie dwie kandydatury zostały odrzucone.

## Prezent od Basi? "O Jezu, przepraszam, w życiu bym do pani nie powiedział w ten sposób"
 - [https://tvn24.pl/go/programy,7/sejm-wita-odcinki,404598/odcinek-97,S00E97,932609?source=rss](https://tvn24.pl/go/programy,7/sejm-wita-odcinki,404598/odcinek-97,S00E97,932609?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 16:04:28+00:00

<img alt="Prezent od Basi? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wqsncx-sejm-wita-6420495/alternates/LANDSCAPE_1280" />
    Radomir Wit i dwie Barbary na sejmowym korytarzu.

## Wielkie śnieżne fronty dotrą do Polski. "Do poniedziałku zasypie nas od Bałtyku po Tatry"
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-wielkie-sniezne-fronty-dotra-do-polski-do-poniedzialku-zasypie-nas-od-baltyku-po-tatry-kiedy-spadnie-snieg-6420441?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-wielkie-sniezne-fronty-dotra-do-polski-do-poniedzialku-zasypie-nas-od-baltyku-po-tatry-kiedy-spadnie-snieg-6420441?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 15:43:12+00:00

<img alt="Wielkie śnieżne fronty dotrą do Polski. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-uls409-sniezyce-drv-6420433/alternates/LANDSCAPE_1280" />
    Pogoda w najbliższych dniach zapowiada się iście zimowo.

## Karski: mamy cztery razy więcej energii z OZE niż za rządów PO-PSL. Sprawdzamy
 - [https://konkret24.tvn24.pl/polityka/karski-mamy-cztery-razy-wiecej-energii-z-oze-niz-za-rzadow-po-psl-sprawdzamy-6405701?source=rss](https://konkret24.tvn24.pl/polityka/karski-mamy-cztery-razy-wiecej-energii-z-oze-niz-za-rzadow-po-psl-sprawdzamy-6405701?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 15:22:00+00:00

<img alt="Karski: mamy cztery razy więcej energii z OZE niż za rządów PO-PSL. Sprawdzamy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4erzli-karski-mamy-cztery-razy-wiecej-energii-z-oze-niz-za-rzadow-po-psl-to-nieprawda-6406952/alternates/LANDSCAPE_1280" />
    Sprawdziliśmy, czy słowa europosła PiS mają pokrycie w danych.

## "Bohaterowie". Gorące powitanie japońskich piłkarzy po mundialu
 - [https://eurosport.tvn24.pl/-bohaterowie---gor-ce-powitanie-japo-skich-pi-karzy-po-mundialu,1128356.html?source=rss](https://eurosport.tvn24.pl/-bohaterowie---gor-ce-powitanie-japo-skich-pi-karzy-po-mundialu,1128356.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 15:04:34+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mqgqzf-japonia-przegrala-z-chorwacja-w-18-finalu-ms-2022/alternates/LANDSCAPE_1280" />
    Na lotnisku na piłkarzy czekał tłum kibiców, którzy entuzjastycznie powitali swoich ulubieńców.

## Wyjątkowy cynizm po śmiertelnym wypadku w trakcie mundialu. "To naturalna część życia"
 - [https://eurosport.tvn24.pl/wyj-tkowy-cynizm-oficjeli-po--miertelnym-wypadku-w-trakcie-mundialu---to-naturalna-cz-----ycia-,1128353.html?source=rss](https://eurosport.tvn24.pl/wyj-tkowy-cynizm-oficjeli-po--miertelnym-wypadku-w-trakcie-mundialu---to-naturalna-cz-----ycia-,1128353.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 15:00:00+00:00

<img alt="Wyjątkowy cynizm po śmiertelnym wypadku w trakcie mundialu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-a3129o-nasser-al-khater/alternates/LANDSCAPE_1280" />
    Głos zabrali dyrektor generalny piłkarskich mistrzostw świata w Katarze Nasser Al Khater i sekretarz generalna FIFA Fatma Samoura.

## Zignorowała dzieci na pasach i mężczyznę, który znakiem "stop" machał jej przed maską
 - [https://tvn24.pl/bialystok/elk-zignorowala-dzieci-na-pasach-i-mezczyzne-ktory-znakiem-stop-machal-jej-przed-maska-zostala-ukarana-6420295?source=rss](https://tvn24.pl/bialystok/elk-zignorowala-dzieci-na-pasach-i-mezczyzne-ktory-znakiem-stop-machal-jej-przed-maska-zostala-ukarana-6420295?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 14:50:55+00:00

<img alt="Zignorowała dzieci na pasach i mężczyznę, który znakiem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pc426g-zdarzenie-zostalo-nagrane-przez-wideorejestrator-jednego-ze-swiadkow-6420317/alternates/LANDSCAPE_1280" />
    Policja pokazała nagranie, na którym widać moment zdarzenia.

## Brazylijczycy muszą się bać?
 - [https://eurosport.tvn24.pl/brazylijczycy-musz--si--ba---fatalna-statystyka-mecz-w-z-ekipami-z-europy,1128315.html?source=rss](https://eurosport.tvn24.pl/brazylijczycy-musz--si--ba---fatalna-statystyka-mecz-w-z-ekipami-z-europy,1128315.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 14:35:51+00:00

<img alt="Brazylijczycy muszą się bać? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6kc584-brazylijczycy-wspaniale-graja-na-mundialu-w-katarze/alternates/LANDSCAPE_1280" />
     Fatalna statystyka meczów z ekipami z Europy.

## Powstała klinika "Budzik" dla dorosłych
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-w-szpitalu-brodnowskim-powstala-klinika-budzik-dla-doroslych-6420267?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-w-szpitalu-brodnowskim-powstala-klinika-budzik-dla-doroslych-6420267?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 14:34:49+00:00

<img alt="Powstała klinika " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5uv6yg-otwarcie-kliniki-budzik-dla-doroslych-6420168/alternates/LANDSCAPE_1280" />
    W dziecięcej klinice wybudziło się właśnie setne dziecko.

## Glapiński o stopach procentowych i inflacji. "Styczeń, luty będzie wzrost"
 - [https://tvn24.pl/biznes/z-kraju/adam-glapinski-o-stopach-procentowych-i-inflacji-konferencja-prezesa-nbp-6420150?source=rss](https://tvn24.pl/biznes/z-kraju/adam-glapinski-o-stopach-procentowych-i-inflacji-konferencja-prezesa-nbp-6420150?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 14:31:40+00:00

<img alt="Glapiński o stopach procentowych i inflacji. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-71ygcb-glapa-6420299/alternates/LANDSCAPE_1280" />
    Konferencja prezesa NBP.

## "Nad Balatonem poważne problemy"
 - [https://tvn24.pl/biznes/ze-swiata/wegry-inflacja-w-listopadzie-nad-balatonem-powazne-problemy-6420208?source=rss](https://tvn24.pl/biznes/ze-swiata/wegry-inflacja-w-listopadzie-nad-balatonem-powazne-problemy-6420208?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 14:04:56+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4nzq1p-wegry-budapeszt-shutterstock2202273345-6420225/alternates/LANDSCAPE_1280" />
    Najnowsze dane.

## Córki żołnierza Armii Krajowej dostaną 800 tysięcy złotych zadośćuczynienia za śmierć ojca
 - [https://tvn24.pl/najnowsze/bialystok-corki-zolnierza-armii-krajowej-dostana-800-tysiecy-zlotych-zadoscuczynienia-zasmierc-ojca-6420174?source=rss](https://tvn24.pl/najnowsze/bialystok-corki-zolnierza-armii-krajowej-dostana-800-tysiecy-zlotych-zadoscuczynienia-zasmierc-ojca-6420174?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 14:02:00+00:00

<img alt="Córki żołnierza Armii Krajowej dostaną 800 tysięcy złotych zadośćuczynienia za śmierć ojca" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a2xdjd-wyrok-sadu-5745962/alternates/LANDSCAPE_1280" />
    Wyrok jest prawomocny.

## Brittney Griner wraca do domu. Między Rosją a USA doszło do wymiany więźniów
 - [https://eurosport.tvn24.pl/griner-uwolniona--mi-dzy-rosj--a-usa-dosz-o-do-wymiany-wi--ni-w,1128343.html?source=rss](https://eurosport.tvn24.pl/griner-uwolniona--mi-dzy-rosj--a-usa-dosz-o-do-wymiany-wi--ni-w,1128343.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 14:01:00+00:00

<img alt="Brittney Griner wraca do domu. Między Rosją a USA doszło do wymiany więźniów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-95pjjm-griner-zostala-wymieniona-za-handlarza-bronia/alternates/LANDSCAPE_1280" />
    Informację potwierdził amerykański prezydent Joe Biden.

## Atak nożownika w sklepie, nie żyje kobieta. Trwa policyjna obława
 - [https://tvn24.pl/tvnwarszawa/okolice/sochaczew-atak-nozownika-w-sklepie-nie-zyje-35-letnia-kobieta-6420234?source=rss](https://tvn24.pl/tvnwarszawa/okolice/sochaczew-atak-nozownika-w-sklepie-nie-zyje-35-letnia-kobieta-6420234?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 13:58:41+00:00

<img alt="Atak nożownika w sklepie, nie żyje kobieta. Trwa policyjna obława" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ueaktg-nie-zyje-dwoch-nastolatkow-6238963/alternates/LANDSCAPE_1280" />
    W Sochaczewie przy ulicy Płockiej.

## Do tunelu, którym przed laty transportowano gazety wleją 900 metrów sześciennych betonu
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-drogowcy-betonuja-nieczynny-tunel-pod-prosta-6419864?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-drogowcy-betonuja-nieczynny-tunel-pod-prosta-6419864?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 13:45:13+00:00

<img alt="Do tunelu, którym przed laty transportowano gazety wleją 900 metrów sześciennych betonu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5yr94d-drogowcy-betonuja-nieczynny-tunel-pod-prosta-6419981/alternates/LANDSCAPE_1280" />
    Nieczynny tunel pod ulicą Prostą ma na ponad 80 metrów długości.

## "Ciężkie straty" elitarnej rosyjskiej jednostki
 - [https://tvn24.pl/swiat/wielka-brytania-resort-obrony-elitarna-rosyjska-armia-pancerna-poniosla-ciezkie-straty-6420103?source=rss](https://tvn24.pl/swiat/wielka-brytania-resort-obrony-elitarna-rosyjska-armia-pancerna-poniosla-ciezkie-straty-6420103?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 13:39:25+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jvht6q-ukraina-donbas-rosyjscy-zolnierze-sily-samozwanczej-donieckiej-republiki-ludowej-01122022-6304302/alternates/LANDSCAPE_1280" />
    Brytyjczycy donoszą o poważnych stratach rosyjskiej armii.

## Kilka porcji ukrył w bieliźnie, ponad dwa kilogramy zakopał pod lasem
 - [https://tvn24.pl/tvnwarszawa/najnowsze/otwock-kilka-porcji-ukryl-w-bieliznie-ponad-dwa-kilo-zakopal-w-ziemi-50-latek-z-zarzutem-handlu-narkotykami-6419647?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/otwock-kilka-porcji-ukryl-w-bieliznie-ponad-dwa-kilo-zakopal-w-ziemi-50-latek-z-zarzutem-handlu-narkotykami-6419647?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 13:25:51+00:00

<img alt="Kilka porcji ukrył w bieliźnie, ponad dwa kilogramy zakopał pod lasem" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-72s59f-policja-zatrzymala-50-latka-podejrzanego-o-handel-narkotykami-6419753/alternates/LANDSCAPE_1280" />
    50-latek z zarzutem handlu narkotykami

## Michniewicz o relacjach z Lewandowskim. "Zadzwonił i długo rozmawialiśmy"
 - [https://eurosport.tvn24.pl/michniewicz-o-relacjach-z-lewandowskim---zadzwoni--i-d-ugo-rozmawiali-my-,1128316.html?source=rss](https://eurosport.tvn24.pl/michniewicz-o-relacjach-z-lewandowskim---zadzwoni--i-d-ugo-rozmawiali-my-,1128316.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 13:10:08+00:00

<img alt="Michniewicz o relacjach z Lewandowskim. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kfiaow-michniewicz-powiedzial-ze-nie-ma-problemu-miedzy-nim-a-kapitanem-reprezentacji/alternates/LANDSCAPE_1280" />
    Selekcjoner reprezentacji Polski w wywiadzie radiowym.

## Inwazja szerszeni azjatyckich w Europie. Naukowcy mają dobrą i złą wiadomość
 - [https://tvn24.pl/tvnmeteo/nauka/inwazja-szerszeni-azjatyckich-w-europie-naukowcy-wiedza-jak-zostala-zapoczatkowana-maja-dobra-i-zla-wiadomosc-6419397?source=rss](https://tvn24.pl/tvnmeteo/nauka/inwazja-szerszeni-azjatyckich-w-europie-naukowcy-wiedza-jak-zostala-zapoczatkowana-maja-dobra-i-zla-wiadomosc-6419397?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 13:05:05+00:00

<img alt="Inwazja szerszeni azjatyckich w Europie. Naukowcy mają dobrą i złą wiadomość" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zgo4gz-vespa-velutina-6419322/alternates/LANDSCAPE_1280" />
    Zbadali, jak została zapoczątkowana.

## Zjechali na pobocze, samochód trafił na minę. Nie żyją rodzice ośmiorga dzieci
 - [https://tvn24.pl/swiat/ukraina-nie-zyja-rodzice-osmiorga-maloletnich-dzieci-6419828?source=rss](https://tvn24.pl/swiat/ukraina-nie-zyja-rodzice-osmiorga-maloletnich-dzieci-6419828?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 13:01:37+00:00

<img alt="Zjechali na pobocze, samochód trafił na minę. Nie żyją rodzice ośmiorga dzieci " src="https://tvn24.pl/najnowsze/cdn-zdjecie-n37f0h-zytomierz-wypadek-6419682/alternates/LANDSCAPE_1280" />
    Do tragedii doszło w obwodzie żytomierskim.

## Siedziba Twittera jak hotel. Elon Musk wstawił łóżka dla pracowników
 - [https://tvn24.pl/biznes/ze-swiata/elon-musk-wstawil-do-siedziby-twittera-lozka-dla-pracownikow-wladze-san-francisco-planuja-wszczecie-dochodzenia-6418730?source=rss](https://tvn24.pl/biznes/ze-swiata/elon-musk-wstawil-do-siedziby-twittera-lozka-dla-pracownikow-wladze-san-francisco-planuja-wszczecie-dochodzenia-6418730?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 13:01:29+00:00

<img alt="Siedziba Twittera jak hotel. Elon Musk wstawił łóżka dla pracowników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pyxx3v-pokoj-6419164/alternates/LANDSCAPE_1280" />
    Władze San Francisco zapowiadają wszczęcie dochodzenia w sprawie.

## Ast: są kraje, w których jest możliwa konfiskata auta za jazdę po alkoholu. Ile ich jest?
 - [https://konkret24.tvn24.pl/polska/konfiskata-samochodu-gdzie-w-europie-przepada-auto-za-jazde-po-alkoholu-6412063?source=rss](https://konkret24.tvn24.pl/polska/konfiskata-samochodu-gdzie-w-europie-przepada-auto-za-jazde-po-alkoholu-6412063?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 13:00:15+00:00

<img alt="Ast: są kraje, w których jest możliwa konfiskata auta za jazdę po alkoholu. Ile ich jest?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hzxmds-marek-ast-o-konfiskacie-samochodow-w-europie-6418248/alternates/LANDSCAPE_1280" />
    Pokazujemy, które to państwa i za jaką zawartość alkoholu można w nich stracić pojazd.

## Cena jest ta sama, ale waga produktu już nie. "W tym roku to zjawisko się nasiliło ewidentnie"
 - [https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-dane-dlahandlupl-za-grudzien-2022-co-podrozalo-6412976?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-dane-dlahandlupl-za-grudzien-2022-co-podrozalo-6412976?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 12:51:41+00:00

<img alt="Cena jest ta sama, ale waga produktu już nie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9gwnyh-zakupy-sklep-wozek-pieniadze-shutterstock2152231121-1-5834533/alternates/LANDSCAPE_1280" />
    Dane dlahandlu.pl.

## "Wyczerpał się mój pokład zaufania do Rzecznika". Rezygnacje ekspertów po odwołaniu Hanny Machińskiej
 - [https://tvn24.pl/polska/hanna-machinska-odwolana-z-funkcji-zastepczyni-rzecznika-praw-obywatelskich-eksperci-przy-krajowym-mechanizmie-prewencji-tortur-rezygnuja-6419348?source=rss](https://tvn24.pl/polska/hanna-machinska-odwolana-z-funkcji-zastepczyni-rzecznika-praw-obywatelskich-eksperci-przy-krajowym-mechanizmie-prewencji-tortur-rezygnuja-6419348?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 12:34:18+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1mtnkw-profesor-marek-konopczynski-6419758/alternates/LANDSCAPE_1280" />
    RPO odwołał swoją zastępczynię Hannę Machińską. W reakcji rezygnację złożyła część członków eksperckiej komisji.

## Kto dostanie powołanie do wojska w 2023 roku? Czy otrzymuje się wtedy pensję? Najważniejsze pytania
 - [https://tvn24.pl/polska/powolanie-do-wojska-i-na-cwiczenia-wojskowe-2023-kto-dostanie-rezerwa-pasywna-i-rezerwa-aktywna-6417657?source=rss](https://tvn24.pl/polska/powolanie-do-wojska-i-na-cwiczenia-wojskowe-2023-kto-dostanie-rezerwa-pasywna-i-rezerwa-aktywna-6417657?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 12:28:29+00:00

<img alt="Kto dostanie powołanie do wojska w 2023 roku? Czy otrzymuje się wtedy pensję? Najważniejsze pytania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kq9zxk-02042022-szczecin-jasne-blonia-uroczysta-przysiega-wojskowa-zolnierzy-sluzby-przygotowawczej-12-brygady-zmechanizowanej-6419892/alternates/LANDSCAPE_1280" />
    Wyjaśniamy szczegóły powołań do wojska planowanych przez MON w 2023 roku.

## Udany powrót Zvereva
 - [https://eurosport.tvn24.pl/udany-powr-t-zvereva--na-ten-mecz-czeka--przesz-o-p---roku,1128332.html?source=rss](https://eurosport.tvn24.pl/udany-powr-t-zvereva--na-ten-mecz-czeka--przesz-o-p---roku,1128332.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 12:14:00+00:00

<img alt="Udany powrót Zvereva" src="https://tvn24.pl/najnowsze/cdn-zdjecie-86wp91-alexander-zverev-wrocil-do-gry-po-kontuzji-kostki-6419850/alternates/LANDSCAPE_1280" />
    Na ten mecz czekał przeszło pół roku.

## Zmiany w dużym banku. Koniec z kredytami hipotecznymi opartymi na stawce WIBOR
 - [https://tvn24.pl/biznes/z-kraju/ing-bank-wycofanie-kredytow-hipotecznych-ze-stawka-wibor-zamiana-na-wiron-6419534?source=rss](https://tvn24.pl/biznes/z-kraju/ing-bank-wycofanie-kredytow-hipotecznych-ze-stawka-wibor-zamiana-na-wiron-6419534?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 12:10:15+00:00

<img alt="Zmiany w dużym banku. Koniec z kredytami hipotecznymi opartymi na stawce WIBOR" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4t1sga-kobieta-przelala-oszustom-az-390-tysiecy-zlotych-5939798/alternates/LANDSCAPE_1280" />
    Komunikat.

## Kiedy stopy procentowe zaczną spadać? Prognozy ekonomistów
 - [https://tvn24.pl/biznes/z-kraju/rpp-stopy-procentowe-do-konca-2022-roku-pozostana-bez-zmian-walka-z-inflacja-komentarze-mbank-ing-goldman-sachs-bank-millennium-pekao-6418592?source=rss](https://tvn24.pl/biznes/z-kraju/rpp-stopy-procentowe-do-konca-2022-roku-pozostana-bez-zmian-walka-z-inflacja-komentarze-mbank-ing-goldman-sachs-bank-millennium-pekao-6418592?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 11:50:10+00:00

<img alt="Kiedy stopy procentowe zaczną spadać? Prognozy ekonomistów " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-xo8yep-adam-glapinski-6215084/alternates/LANDSCAPE_1280" />
    Rada Polityki Pieniężnej zdecydowała się utrzymać stopy procentowe NBP na niezmienionym poziomie.

## Hiszpania zawiodła, trener stracił pracę
 - [https://eurosport.tvn24.pl/hiszpania-zawiod-a--trener-straci--prac-,1128334.html?source=rss](https://eurosport.tvn24.pl/hiszpania-zawiod-a--trener-straci--prac-,1128334.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 11:44:04+00:00

<img alt="Hiszpania zawiodła, trener stracił pracę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rbazgt-luis-enrique-nie-poprowadzi-juz-reprezentacji-hiszpanii/alternates/LANDSCAPE_1280" />
    Luis Enrique przestał być selekcjonerem reprezentacji.

## Kobiety czują to znacznie częściej niż mężczyźni. Wyniki dziesięcioletnich badań
 - [https://tvn24.pl/ciekawostki/kobiety-coraz-czesciej-odczuwaja-negatywne-emocje-takie-jak-zlosc-smutek-i-stres-martwia-sie-czesciej-niz-mezczyzni-6418384?source=rss](https://tvn24.pl/ciekawostki/kobiety-coraz-czesciej-odczuwaja-negatywne-emocje-takie-jak-zlosc-smutek-i-stres-martwia-sie-czesciej-niz-mezczyzni-6418384?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 11:42:46+00:00

<img alt="Kobiety czują to znacznie częściej niż mężczyźni. Wyniki dziesięcioletnich badań" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1uk6gi-kobieta-protest-shutterstock1277147113-6419209/alternates/LANDSCAPE_1280" />
    Zapytano ponad 120 tys. osób w ponad 150 krajach.

## "Również o to walczył". Putin porównuje się do Piotra I i zapowiada długą wojnę
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-raport-isw-wladimir-putin-przygotowuje-rosjan-do-dlugiej-wojny-i-porownuje-sie-do-piotra-i-6419294?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-raport-isw-wladimir-putin-przygotowuje-rosjan-do-dlugiej-wojny-i-porownuje-sie-do-piotra-i-6419294?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 11:39:19+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lpesxb-wladimir-putin-wizytuje-flote-czarnomorska-zdjecie-archiwalne-6230928/alternates/LANDSCAPE_1280" />
    Pisze amerykański Instytut Badań nad Wojną w najnowszym raporcie.

## Uderzył w tył radiowozu i wbił go pod cysternę. Wewnątrz byli dwaj policjanci
 - [https://tvn24.pl/polska/a4-wroclaw-legnica-wypadek-pod-budziszowem-wielkim-bus-wbil-radiowoz-pod-cysterne-ranni-policjanci-6418516?source=rss](https://tvn24.pl/polska/a4-wroclaw-legnica-wypadek-pod-budziszowem-wielkim-bus-wbil-radiowoz-pod-cysterne-ranni-policjanci-6418516?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 11:34:01+00:00

<img alt="Uderzył w tył radiowozu i wbił go pod cysternę. Wewnątrz byli dwaj policjanci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n2eiz6-wypadek-na-dolnoslaskim-odcinku-autostrady-a4-6418482/alternates/LANDSCAPE_1280" />
    Mundurowi zabezpieczali zepsutą ciężarówkę.

## "Zostawiliśmy Benzemę w pół dystansu". Niefortunny fragment wywiadu Michniewicza
 - [https://eurosport.tvn24.pl/michniewicz-pomyli--francuskich-pi-karzy--niefortunny-fragment-wywiadu,1128324.html?source=rss](https://eurosport.tvn24.pl/michniewicz-pomyli--francuskich-pi-karzy--niefortunny-fragment-wywiadu,1128324.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 11:32:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3ag3nm-selekcjoner-czeslaw-michniewicz/alternates/LANDSCAPE_1280" />
    Udzielił go w czwartek Radiu Zet.

## Więcej nowych przypadków i hospitalizacji. Nowa grupa do szczepienia przeciw COVID-19
 - [https://tvn24.pl/polska/szczepienia-na-covid-19-dla-dzieci-od-szesciu-miesiecy-do-czterech-lat-minister-zapisy-rusza-12-grudnia-6419375?source=rss](https://tvn24.pl/polska/szczepienia-na-covid-19-dla-dzieci-od-szesciu-miesiecy-do-czterech-lat-minister-zapisy-rusza-12-grudnia-6419375?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 11:27:45+00:00

<img alt="Więcej nowych przypadków i hospitalizacji. Nowa grupa do szczepienia przeciw COVID-19" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4vym9w-08-1150-konfa-mz-0004-6419298/alternates/LANDSCAPE_1280" />
    Poinformował minister zdrowia Adam Niedzielski.

## To DNA pobiło absolutny rekord. "Możemy cofnąć się w czasie dalej, niż ktokolwiek ośmielał się wyobrażać"
 - [https://tvn24.pl/tvnmeteo/nauka/odkryto-dna-sprzed-dwoch-milionow-lat-to-rekord-w-badaniach-paleontologicznych-6418417?source=rss](https://tvn24.pl/tvnmeteo/nauka/odkryto-dna-sprzed-dwoch-milionow-lat-to-rekord-w-badaniach-paleontologicznych-6418417?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 11:23:38+00:00

<img alt="To DNA pobiło absolutny rekord. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-dfhdod-artystyczna-wizja-formacji-kap-kbenhavn-sprzed-dwoch-milionow-lat-6418751/alternates/LANDSCAPE_1280" />
    Donoszą naukowcy na łamach "Nature".

## "To pokazuje, jak bezbronne jest państwo polskie, skoro szpiedzy rosyjscy mogą wnikać tak głęboko"
 - [https://tvn24.pl/polska/sprawa-tomasza-l-zatrzymanego-pod-zarzutem-szpiegostwa-na-rzecz-rosji-komentarze-politykow-6418410?source=rss](https://tvn24.pl/polska/sprawa-tomasza-l-zatrzymanego-pod-zarzutem-szpiegostwa-na-rzecz-rosji-komentarze-politykow-6418410?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 11:20:40+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uxpn7h-0712n107x-cnb-swierczek-bond-arch-0043-6418212/alternates/LANDSCAPE_1280" />
    Polityczne komentarze do sprawy Tomasza L.

## Chciała okraść bank, przeszkodziła jej 91-latka. Napastniczka dostała cios kulą ortopedyczną w plecy
 - [https://tvn24.pl/krakow/przemysl-napad-na-bank-26-latka-zagrozila-nozem-i-zazadala-pieniedzy-powstrzymali-ja-swiadkowie-6409654?source=rss](https://tvn24.pl/krakow/przemysl-napad-na-bank-26-latka-zagrozila-nozem-i-zazadala-pieniedzy-powstrzymali-ja-swiadkowie-6409654?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 10:59:00+00:00

<img alt="Chciała okraść bank, przeszkodziła jej 91-latka. Napastniczka dostała cios kulą ortopedyczną w plecy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p1ltcw-bank-napad-drv-6418925/alternates/LANDSCAPE_1280" />
    Do napadu doszło w Przemyślu.

## 40 milionów złotych na miejski program in vitro
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-miasto-przeznaczy-40-milionow-zlotych-na-program-in-vitro-6418719?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-miasto-przeznaczy-40-milionow-zlotych-na-program-in-vitro-6418719?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 10:52:46+00:00

<img alt="40 milionów złotych na miejski program in vitro" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h083uv-dzietnosc-6224086/alternates/LANDSCAPE_1280" />
    Przyszli rodzice będą także mogli korzystać z bezpłatnych zajęć w szkołach rodzenia.

## Kolejny pakiet sankcji na Rosję. Sadoś: prawdopodobnie w piątek
 - [https://tvn24.pl/swiat/unia-europejska-szykuje-kolejny-pakiet-sankcji-wobec-rosji-ma-objac-przemysl-wydobywczy-6418559?source=rss](https://tvn24.pl/swiat/unia-europejska-szykuje-kolejny-pakiet-sankcji-wobec-rosji-ma-objac-przemysl-wydobywczy-6418559?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 10:18:11+00:00

<img alt="Kolejny pakiet sankcji na Rosję. Sadoś: prawdopodobnie w piątek" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-n8h99x-ropa-naftowa-rosja-6077655/alternates/LANDSCAPE_1280" />
    Poinformował w czwartek Brukseli Stały Przedstawiciel Polski przy UE.

## Finał "Top Model" za nami. Jury i widzowie byli jednogłośni
 - [https://tvn24.pl/kultura-i-styl/top-model-kto-wygral-11-sezon-top-model-6415837?source=rss](https://tvn24.pl/kultura-i-styl/top-model-kto-wygral-11-sezon-top-model-6415837?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 10:12:54+00:00

<img alt="Finał " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nmowa0-final-top-model-za-nami-6415764/alternates/LANDSCAPE_1280" />
    Finałowy odcinek prowadzili Joanna Krupa i Michał Piróg.

## 72 miliony euro za 16-latka? Real nie żałuje pieniędzy na supertalent
 - [https://eurosport.tvn24.pl/72-miliony-euro-za-16-latka--real-nie--a-uje-pieni-dzy-na-supertalent,1128313.html?source=rss](https://eurosport.tvn24.pl/72-miliony-euro-za-16-latka--real-nie--a-uje-pieni-dzy-na-supertalent,1128313.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 10:07:00+00:00

<img alt="72 miliony euro za 16-latka? Real nie żałuje pieniędzy na supertalent" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i4jwa1-endrick-ma-byc-nowym-pilkarzem-realu-madryt/alternates/LANDSCAPE_1280" />
    Według doniesień mediów napastnik, którego powołania na mundial w Katarze domagał się Brazylijczyk Ronaldo, ma dołączyć do Królewskich w 2024 roku.

## Samozwańczy prorok ma 20 żon, poślubił nawet własne córki. Nowe fakty w sprawie Samuela Batemana
 - [https://tvn24.pl/swiat/usa-samuel-bateman-ma-co-najmniej-20-zon-w-tym-wlasne-corki-oskarzany-jest-o-kazirodztwo-i-handel-dziecmi-6413263?source=rss](https://tvn24.pl/swiat/usa-samuel-bateman-ma-co-najmniej-20-zon-w-tym-wlasne-corki-oskarzany-jest-o-kazirodztwo-i-handel-dziecmi-6413263?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 10:06:39+00:00

<img alt="Samozwańczy prorok ma 20 żon, poślubił nawet własne córki. Nowe fakty w sprawie Samuela Batemana" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f1lbry-samuel-bateman-6418089/alternates/LANDSCAPE_1280" />
    Odbywanie stosunków seksualnych z nieletnimi tłumaczył tym, że "dziewczęta powierzyły swoją cnotę Panu".

## "Rosyjski łącznik", "szpieg przy likwidacji WSI", "katastrofa"
 - [https://tvn24.pl/polska/rosyjski-szpieg-przy-likwidacji-wsi-komentarze-politykow-i-ekspertow-po-reportazu-historia-agenta-w-czarno-na-bialym-6416222?source=rss](https://tvn24.pl/polska/rosyjski-szpieg-przy-likwidacji-wsi-komentarze-politykow-i-ekspertow-po-reportazu-historia-agenta-w-czarno-na-bialym-6416222?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 10:06:19+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h4uwpd-0712n107x-cnb-swierczek-bond-arch-0016-6418240/alternates/LANDSCAPE_1280" />
    Komentarze po reportażu "Czarno na białym".

## Dziennikarka tvn24.pl Justyna Suchecka na liście 100 Kobiet Roku magazynu "Forbes Women"
 - [https://tvn24.pl/biznes/z-kraju/kobiety-roku-2022-forbes-women-dziennikarka-tvn24pl-justyna-suchecka-na-liscie-6417938?source=rss](https://tvn24.pl/biznes/z-kraju/kobiety-roku-2022-forbes-women-dziennikarka-tvn24pl-justyna-suchecka-na-liscie-6417938?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 10:00:05+00:00

<img alt="Dziennikarka tvn24.pl Justyna Suchecka na liście 100 Kobiet Roku magazynu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-f5lp81-justyna-suchecka-5493566/alternates/LANDSCAPE_1280" />
    Lista składa się z przedstawicielek biznesu i finansów, wybitnych artystek, naukowczyń, innowatorek, liderek politycznych i aktywistek, kobiet osiągających najwyższe wyniki w sporcie i innych dziedzinach życia.

## Policja: przez pięć lat prowokował stłuczki i wyłudzał odszkodowania
 - [https://tvn24.pl/katowice/slaskie-poszkodowany-w-podejrzanie-wielu-kolizjach-przez-piec-lat-prowokowal-stluczki-i-dostawal-odszkodowania-z-ubezpieczalni-6417850?source=rss](https://tvn24.pl/katowice/slaskie-poszkodowany-w-podejrzanie-wielu-kolizjach-przez-piec-lat-prowokowal-stluczki-i-dostawal-odszkodowania-z-ubezpieczalni-6417850?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 09:52:35+00:00

<img alt="Policja: przez pięć lat prowokował stłuczki i wyłudzał odszkodowania " src="https://tvn24.pl/najnowsze/cdn-zdjecie-r8p23w-policja-wyjasnia-okolicznosci-zdarzenia-zdjecie-ilustracyjne-6412922/alternates/LANDSCAPE_1280" />
     40-latek wybierał miejsca nieobjęte monitoringiem i zajeżdżał innym kierowcom drogę.

## Udaremniony pucz w Niemczech. To on miał zostać głową państwa
 - [https://tvn24.pl/swiat/niemcy-zamach-stanu-udaremniony-ksiaze-heinrich-xiii-zatrzymany-po-puczu-ekstremistow-mial-zostac-glowa-panstwa-6418272?source=rss](https://tvn24.pl/swiat/niemcy-zamach-stanu-udaremniony-ksiaze-heinrich-xiii-zatrzymany-po-puczu-ekstremistow-mial-zostac-glowa-panstwa-6418272?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 09:16:40+00:00

<img alt="Udaremniony pucz w Niemczech. To on miał zostać głową państwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cmsyx1-ksiaze-heinrich-xiii-po-puczu-ekstremistow-mial-zostac-glowa-panstwa-6418146/alternates/LANDSCAPE_1280" />
    Książę w rękach policji.

## Tomasz L. "miał dostęp do wszystkiego, co jest ważne dla polskiego wywiadu"
 - [https://tvn24.pl/polska/sprawa-tomasza-l-zatrzymanego-pod-zarzutem-szpiegostwa-na-rzecz-rosji-piotr-swierczek-wyjasnia-sprawe-bylego-pracownika-komisji-likwidacyjnej-wsi-6417397?source=rss](https://tvn24.pl/polska/sprawa-tomasza-l-zatrzymanego-pod-zarzutem-szpiegostwa-na-rzecz-rosji-piotr-swierczek-wyjasnia-sprawe-bylego-pracownika-komisji-likwidacyjnej-wsi-6417397?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 08:56:30+00:00

<img alt="Tomasz L. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-37z8uw-0712n107x-cnb-swierczek-bond-arch-0033-6418222/alternates/LANDSCAPE_1280" />
    Piotr Świerczek, autor materiału "Historia agenta", był gościem "Wstajesz i wiesz".

## Gra i strzela na mundialu z defibrylatorem
 - [https://eurosport.tvn24.pl/gra-i-strzela-na-mundialu-z-defibrylatorem,1128289.html?source=rss](https://eurosport.tvn24.pl/gra-i-strzela-na-mundialu-z-defibrylatorem,1128289.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 08:32:28+00:00

<img alt="Gra i strzela na mundialu z defibrylatorem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iwfdts-daley-blind-gra-z-defibrylatorem/alternates/LANDSCAPE_1280" />
    Daley Blind ma prawo mówić o ogromnym szczęściu.

## Wiele zalanych ulic. Jedna osoba nie żyje
 - [https://tvn24.pl/tvnmeteo/swiat/portugalia-lizbona-wiele-zalanych-ulic-woda-wdarla-sie-sie-do-szpitala-i-na-lotnisko-jedna-osoba-nie-zyje-6417324?source=rss](https://tvn24.pl/tvnmeteo/swiat/portugalia-lizbona-wiele-zalanych-ulic-woda-wdarla-sie-sie-do-szpitala-i-na-lotnisko-jedna-osoba-nie-zyje-6417324?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 08:24:07+00:00

<img alt="Wiele zalanych ulic. Jedna osoba nie żyje" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-q4epr5-zalane-ulice-w-lizbonie-6417901/alternates/LANDSCAPE_1280" />
    Ulewy w Lizbonie.

## Bez ciepła co trzeci budynek, szpital na ogrzewaniu awaryjnym. Duża awaria w Puławach
 - [https://tvn24.pl/bialystok/pulawy-awaria-sieci-cieplowniczej-ogrzewania-problemy-dotknely-co-trzeci-budynek-w-tym-szpital-6417668?source=rss](https://tvn24.pl/bialystok/pulawy-awaria-sieci-cieplowniczej-ogrzewania-problemy-dotknely-co-trzeci-budynek-w-tym-szpital-6417668?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 08:21:54+00:00

<img alt="Bez ciepła co trzeci budynek, szpital na ogrzewaniu awaryjnym. Duża awaria w Puławach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pxthkr-od-sieci-odciety-jest-co-trzeci-budynek-6417650/alternates/LANDSCAPE_1280" />
    Ciepło do odciętych od sieci budynków popłynie najpóźniej w piątek rano.

## "Nie zwolni się z polityki krajowej. Dalej będzie bulterierem"
 - [https://tvn24.pl/polska/jacek-kurski-ma-nowa-prace-grzegorz-schetyna-nie-zwolni-sie-z-polityki-krajowej-dalej-bedzie-bulterierem-6417537?source=rss](https://tvn24.pl/polska/jacek-kurski-ma-nowa-prace-grzegorz-schetyna-nie-zwolni-sie-z-polityki-krajowej-dalej-bedzie-bulterierem-6417537?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 08:17:38+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gv516n-jacek-kurski-6417705/alternates/LANDSCAPE_1280" />
    Grzegorz Schetyna o Jacku Kurskim.

## Sejmik województwa śląskiego zmienił prezydium i składy komisji. Samorządowcy PiS odwołani
 - [https://tvn24.pl/polska/sejmik-wojewodztwa-slaskiego-zmienil-prezydium-i-sklady-komisji-samorzadowcy-pis-odwolani-6416491?source=rss](https://tvn24.pl/polska/sejmik-wojewodztwa-slaskiego-zmienil-prezydium-i-sklady-komisji-samorzadowcy-pis-odwolani-6416491?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 07:45:00+00:00

<img alt="Sejmik województwa śląskiego zmienił prezydium i składy komisji. Samorządowcy PiS odwołani" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d9yst0-sejmik-6230502/alternates/LANDSCAPE_1280" />
    Zastąpili ich głównie radni Koalicji Obywatelskiej.

## Michniewicz skomentował sprawę premii. Rezygnować nie zamierza
 - [https://eurosport.tvn24.pl/michniewicz-skomentowa--spraw--premii--rezygnowa--nie-zamierza,1128309.html?source=rss](https://eurosport.tvn24.pl/michniewicz-skomentowa--spraw--premii--rezygnowa--nie-zamierza,1128309.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 07:38:00+00:00

<img alt="Michniewicz skomentował sprawę premii. Rezygnować nie zamierza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k33bxg-michniewicz-pozostanie-selekcjonerem-reprezentacji-polski/alternates/LANDSCAPE_1280" />
    Selekcjoner reprezentacji był gościem Radia Zet.

## Mało kibiców na mundialu. Katarczycy się przeliczyli
 - [https://eurosport.tvn24.pl/ma-o-kibic-w-na-mundialu--katarczycy-si--przeliczyli,1128312.html?source=rss](https://eurosport.tvn24.pl/ma-o-kibic-w-na-mundialu--katarczycy-si--przeliczyli,1128312.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 07:32:00+00:00

<img alt="Mało kibiców na mundialu. Katarczycy się przeliczyli" src="https://tvn24.pl/najnowsze/cdn-zdjecie-win7bq-puste-trybuny-w-katarze-6417544/alternates/LANDSCAPE_1280" />
    Liczba kibiców jest zdecydowanie mniejsza niż zakładano

## "Rośnie irytacja" podejściem Macrona do Moskwy. Ostatnie słowa "rozgniewały Europejczyków"
 - [https://tvn24.pl/swiat/francja-europejczycy-coraz-bardziej-zirytowani-umiarkowanym-nastawieniem-paryza-wobec-moskwy-pisze-le-figaro-6415238?source=rss](https://tvn24.pl/swiat/francja-europejczycy-coraz-bardziej-zirytowani-umiarkowanym-nastawieniem-paryza-wobec-moskwy-pisze-le-figaro-6415238?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 07:12:19+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kzjzvl-emmanuel-macron-6415175/alternates/LANDSCAPE_1280" />
    Pisze "Le Figaro".

## Dlaczego konkurs "Drewno jest z lasu" był owiany tajemnicą? "Chodziły plotki, że to konkurs dla kościołów"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2344,S00E2344,931756?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2344,S00E2344,931756?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 07:12:18+00:00

<img alt="Dlaczego konkurs " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9f5oqv-lasy-panstwowe-6417268/alternates/LANDSCAPE_1280" />
    Reportaż Artura Warcholińskiego.

## Schetyna o sprawie Tomasza L.: To skandal dla państwa. Brak odporności, brak mechanizmów
 - [https://tvn24.pl/polska/tomasz-l-zatrzymany-pod-zarzutem-szpiegostwa-byl-czlonkiem-komisji-likwidacyjnej-wsi-grzegorz-schetyna-to-skandal-dla-panstwa-6417212?source=rss](https://tvn24.pl/polska/tomasz-l-zatrzymany-pod-zarzutem-szpiegostwa-byl-czlonkiem-komisji-likwidacyjnej-wsi-grzegorz-schetyna-to-skandal-dla-panstwa-6417212?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 07:07:36+00:00

<img alt="Schetyna o sprawie Tomasza L.: To skandal dla państwa. Brak odporności, brak mechanizmów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jwn023-grzegorz-schetyna-6417185/alternates/LANDSCAPE_1280" />
    Grzegorz Schetyna w "Rozmowie Piaseckiego".

## Rząd podnosi VAT na gaz, bo taki jest "wymóg Brukseli". Komisja Europejska zaprzecza
 - [https://tvn24.pl/biznes/z-kraju/wzrost-vat-na-gaz-do-23-procent-decyzje-polskiego-rzadu-oraz-unii-europejskiej-6416944?source=rss](https://tvn24.pl/biznes/z-kraju/wzrost-vat-na-gaz-do-23-procent-decyzje-polskiego-rzadu-oraz-unii-europejskiej-6416944?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 06:58:54+00:00

<img alt="Rząd podnosi VAT na gaz, bo taki jest " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fb5o2c-gaz-kuchenka-palnik-5792469/alternates/LANDSCAPE_1280" />
    Informuje w czwartek "Rzeczpospolita".

## Kontuzja zawodnika nie pozwoliła cieszyć się z wygranej. "Spodziewamy się najgorszego"
 - [https://eurosport.tvn24.pl/kontuzja-zawodnika-nie-pozwoli-a-cieszy--si--z-wygranej---spodziewamy-si--najgorszego-,1128308.html?source=rss](https://eurosport.tvn24.pl/kontuzja-zawodnika-nie-pozwoli-a-cieszy--si--z-wygranej---spodziewamy-si--najgorszego-,1128308.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 06:52:00+00:00

<img alt="Kontuzja zawodnika nie pozwoliła cieszyć się z wygranej. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lrxi72-kielczanie-moga-na-dlugo-stracic-islandczyka-6413913/alternates/LANDSCAPE_1280" />
    Łomża Industria Kielce czeka na ostateczną diagnozę kontuzji swojego zawodnika.

## Dom wicepremiera otoczony kordonem policji, zamknięte ulice dojazdowe
 - [https://tvn24.pl/swiat/belgia-policja-otoczyla-dom-wicepremiera-i-ministra-sprawiedliwosci-vincenta-van-quickenbornea-6416739?source=rss](https://tvn24.pl/swiat/belgia-policja-otoczyla-dom-wicepremiera-i-ministra-sprawiedliwosci-vincenta-van-quickenbornea-6416739?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 06:26:36+00:00

<img alt="Dom wicepremiera otoczony kordonem policji, zamknięte ulice dojazdowe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mrll82-vincent-van-quickenborne-6416740/alternates/LANDSCAPE_1280" />
    O sprawie piszą belgijskie media, policja nie komentuje.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-8-grudnia-2022-6416731?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-8-grudnia-2022-6416731?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 06:21:14+00:00

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vzhc2h-zniszczenia-w-mariupolu-6416241/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja trwa 288. dzień.

## Sochan myśli o powrocie do gry. "Kontuzja nie jest poważna"
 - [https://eurosport.tvn24.pl/sochan-my-li-o-powrocie-do-gry---kontuzja-nie-jest-powa-na-,1128280.html?source=rss](https://eurosport.tvn24.pl/sochan-my-li-o-powrocie-do-gry---kontuzja-nie-jest-powa-na-,1128280.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 06:13:10+00:00

<img alt="Sochan myśli o powrocie do gry. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7nmez1-jeremy-sochan-jest-jedynym-polakiem-w-nba/alternates/LANDSCAPE_1280" />
    Polski koszykarz z powodu urazu opuścił cztery ostatnie mecze San Antonio Spurs.

## Dach kamienicy zawalił się w czasie pożaru, trwa akcja strażaków. Ewakuowano kilkadziesiąt osób
 - [https://tvn24.pl/wroclaw/pozar-kamienicy-w-przemkowie-ewakuowano-30-osob-6416969?source=rss](https://tvn24.pl/wroclaw/pozar-kamienicy-w-przemkowie-ewakuowano-30-osob-6416969?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 06:13:04+00:00

<img alt="Dach kamienicy zawalił się w czasie pożaru, trwa akcja strażaków. Ewakuowano kilkadziesiąt osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4mv9k1-08-0645-zielona-pozar-0004-6416932/alternates/LANDSCAPE_1280" />
    Na Dolnym Śląsku.

## Szykują się duże utrudnienia na lotniskach. Podano datę strajku
 - [https://tvn24.pl/biznes/ze-swiata/szykuja-sie-duze-utrudnienia-na-brytyjskich-lotniskach-podano-date-strajku-6414056?source=rss](https://tvn24.pl/biznes/ze-swiata/szykuja-sie-duze-utrudnienia-na-brytyjskich-lotniskach-podano-date-strajku-6414056?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 06:12:30+00:00

<img alt="Szykują się duże utrudnienia na lotniskach. Podano datę strajku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hqitpf-wladze-londynskiego-lotniska-heathrow-poinformowaly-ze-w-weekend-rozpocznie-sie-pilotazowy-program-szybkich-kontroli-granicznych-5142599/alternates/LANDSCAPE_1280" />
    Brytyjski rząd bierze pod uwagę zaangażowanie wojska.

## Atak zimy może "powodować duże straty i zagrażać zdrowiu i życiu"
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-drugiego-stopnia-gololedz-w-polsce-weekend-przyniesie-sniezyce-zawieje-i-zamiecie-potem-chwyci-siarczysty-mroz-6416752?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-drugiego-stopnia-gololedz-w-polsce-weekend-przyniesie-sniezyce-zawieje-i-zamiecie-potem-chwyci-siarczysty-mroz-6416752?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 05:32:04+00:00

<img alt="Atak zimy może " src="https://tvn24.pl/najnowsze/cdn-zdjecie-0olroz-intensywne-opady-sniegu-zawieje-i-zamiecie-6430682/alternates/LANDSCAPE_1280" />
    IMGW ostrzega.

## Brygida zbliża się do Polski. Alerty IMGW
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-drugiego-stopnia-intensywne-opady-sniegu-sniezyce-nadciagaja-nad-polske-niz-brygida-atak-zimy-w-weekend-6416752?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-drugiego-stopnia-intensywne-opady-sniegu-sniezyce-nadciagaja-nad-polske-niz-brygida-atak-zimy-w-weekend-6416752?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 05:32:04+00:00

<img alt="Brygida zbliża się do Polski. Alerty IMGW" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lg1j3c-snieg-zima-noc-6225274/alternates/LANDSCAPE_1280" />
    IMGW wydał ostrzeżenia meteorologiczne.

## Możliwe "duże straty i zagrożenie zdrowia i życia"
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-gololedz-w-kilku-wojewodztwach-weekend-przyniesie-sniezyce-zawieje-i-zamiecie-potem-chwyci-siarczysty-mroz-6416752?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-gololedz-w-kilku-wojewodztwach-weekend-przyniesie-sniezyce-zawieje-i-zamiecie-potem-chwyci-siarczysty-mroz-6416752?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 05:32:04+00:00

<img alt="Możliwe " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-pamkd9-intensywne-opady-sniegu-6233942/alternates/LANDSCAPE_1280" />
    IMGW ostrzega.

## Nawet 30 centymetrów śniegu. Alerty IMGW drugiego stopnia
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-drugiego-stopnia-sniezyce-nadciagaja-nad-polske-atak-zimy-w-weekend-6416752?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-drugiego-stopnia-sniezyce-nadciagaja-nad-polske-atak-zimy-w-weekend-6416752?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 05:32:04+00:00

<img alt="Nawet 30 centymetrów śniegu. Alerty IMGW drugiego stopnia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-91rr16-intensywne-opady-sniegu-6442008/alternates/LANDSCAPE_1280" />
    Kogo czekają trudne godziny?

## Niebezpiecznie ślisko w części kraju. Na horyzoncie alerty przed śnieżycami i zamieciami
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-oblodzenie-gesta-mgla-ostrzezenia-prognoza-zagrozen-mozliwe-intensywne-opady-i-zawieje-sniezne-6416752?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-oblodzenie-gesta-mgla-ostrzezenia-prognoza-zagrozen-mozliwe-intensywne-opady-i-zawieje-sniezne-6416752?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 05:32:04+00:00

<img alt="Niebezpiecznie ślisko w części kraju. Na horyzoncie alerty przed śnieżycami i zamieciami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-no3hd9-oblodzenia-oblodzone-drogi-6419619/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie aura będzie stwarzać zagrożenie.

## Spadnie dużo śniegu, wiatr będzie powodować zawieje i zamiecie
 - [https://tvn24.pl/tvnmeteo/prognoza/imgw-sniezyce-zawieje-i-zamiecie-kiedy-spadnie-snieg-prognoza-zagrozen-imgw-na-piatek-sobote-i-niedziele-6416752?source=rss](https://tvn24.pl/tvnmeteo/prognoza/imgw-sniezyce-zawieje-i-zamiecie-kiedy-spadnie-snieg-prognoza-zagrozen-imgw-na-piatek-sobote-i-niedziele-6416752?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 05:32:04+00:00

<img alt="Spadnie dużo śniegu, wiatr będzie powodować zawieje i zamiecie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9ofm66-snieg-zima-adobestock234872319-6417479/alternates/LANDSCAPE_1280" />
    Prognoza zagrożeń IMGW.

## Zimowe alerty drugiego stopnia. W weekend mocno sypnie śniegiem, możliwe zawieje
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-opady-marznace-oblodzenie-ostrzezenia-drugiego-i-pierwszego-stopnia-prognoza-zagrozen-mozliwe-intensywne-opady-i-zawieje-sniezne-6416752?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-opady-marznace-oblodzenie-ostrzezenia-drugiego-i-pierwszego-stopnia-prognoza-zagrozen-mozliwe-intensywne-opady-i-zawieje-sniezne-6416752?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 05:32:04+00:00

<img alt="Zimowe alerty drugiego stopnia. W weekend mocno sypnie śniegiem, możliwe zawieje" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vuofq5-opady-marznace-gololedz-6428317/alternates/LANDSCAPE_1280" />
    Przed nami trudny czas w pogodzie.

## Bliźniaczki dotrzymały słowa danego mamie. Nie walczyły w finale
 - [https://eurosport.tvn24.pl/bli-niaczki-dotrzyma-y-s-owa-danego-mamie--nie-walczy-y-w-finale,1128305.html?source=rss](https://eurosport.tvn24.pl/bli-niaczki-dotrzyma-y-s-owa-danego-mamie--nie-walczy-y-w-finale,1128305.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 05:06:00+00:00

<img alt="Bliźniaczki dotrzymały słowa danego mamie. Nie walczyły w finale" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kwt7xd-siostry-miegoc/alternates/LANDSCAPE_1280" />
    Czasem nie liczy się wygrana za wszelką cenę.

## Książę "rozwinął czerwony dywan" na przywitanie Xi, wysyłając "niezbyt subtelny komunikat" Bidenowi
 - [https://tvn24.pl/swiat/arabia-saudyjska-chiny-xi-jinping-przybyl-do-rijadu-byl-witany-z-wieksza-pompa-niz-joe-biden-6414984?source=rss](https://tvn24.pl/swiat/arabia-saudyjska-chiny-xi-jinping-przybyl-do-rijadu-byl-witany-z-wieksza-pompa-niz-joe-biden-6414984?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 04:59:21+00:00

<img alt="Książę " src="https://tvn24.pl/najnowsze/cdn-zdjecie-sninkr-xi-jinping-przybyl-do-rijadu-6414956/alternates/LANDSCAPE_1280" />
    Przywódca Chin w Arabii Saudyjskiej.

## Eksplozja w czasie rozminowywania. Zginęło czterech policjantów
 - [https://tvn24.pl/swiat/czterech-ukrainskich-policjantow-zginelo-podczas-operacji-rozminowywania-w-obwodzie-chersonskim-6415322?source=rss](https://tvn24.pl/swiat/czterech-ukrainskich-policjantow-zginelo-podczas-operacji-rozminowywania-w-obwodzie-chersonskim-6415322?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 04:48:16+00:00

<img alt="Eksplozja w czasie rozminowywania. Zginęło czterech policjantów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2nt7r9-rozminowanie-bomby-w-czernihowie-5631059/alternates/LANDSCAPE_1280" />
    W obwodzie chersońskim.

## Trzustka prosto z drukarki. "Żywy narząd z żywych komórek" od polskich naukowców
 - [https://tvn24.pl/programy/trzustka-z-drukarki-3d-pionierski-wynalazek-polskich-naukowcow-6414759?source=rss](https://tvn24.pl/programy/trzustka-z-drukarki-3d-pionierski-wynalazek-polskich-naukowcow-6414759?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-12-08 04:44:08+00:00

<img alt="Trzustka prosto z drukarki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-uti029-trzustka-prosto-z-drukarki-3d-6414938/alternates/LANDSCAPE_1280" />
    Pionierski wynalazek zespołu doktora Michała Wszoły.


# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## US military official targets mom over Facebook post that criticized school’s promotion of “polysexual” art
 - [https://reclaimthenet.org/us-military-official-targets-mom-facebook-post/](https://reclaimthenet.org/us-military-official-targets-mom-facebook-post/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-08 19:09:30+00:00

<a href="https://reclaimthenet.org/us-military-official-targets-mom-facebook-post/" rel="nofollow" title="US military official targets mom over Facebook post that criticized school&#8217;s promotion of &#8220;polysexual&#8221; art"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/us-military-official-targets-mom-facebook-post.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The military official flagged the post to state and local law enforcement.</p>
<p>The post <a href="https://reclaimthenet.org/us-military-official-targets-mom-facebook-post/" rel="nofollow">US military official targets mom over Facebook post that criticized school&#8217;s promotion of &#8220;polysexual&#8221; art</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Investigation launches into possible State Department funding of third parties to censor online speech
 - [https://reclaimthenet.org/state-department-funding-of-third-parties-to-censor-online-speech-foia/](https://reclaimthenet.org/state-department-funding-of-third-parties-to-censor-online-speech-foia/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-08 18:43:56+00:00

<a href="https://reclaimthenet.org/state-department-funding-of-third-parties-to-censor-online-speech-foia/" rel="nofollow" title="Investigation launches into possible State Department funding of third parties to censor online speech"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/do-state.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Possible covert censorship tactics investigated. </p>
<p>The post <a href="https://reclaimthenet.org/state-department-funding-of-third-parties-to-censor-online-speech-foia/" rel="nofollow">Investigation launches into possible State Department funding of third parties to censor online speech</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Motion is filed against California’s medical “misinformation” law
 - [https://reclaimthenet.org/motion-is-filed-against-californias-medical-misinformation-law/](https://reclaimthenet.org/motion-is-filed-against-californias-medical-misinformation-law/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-08 17:49:03+00:00

<a href="https://reclaimthenet.org/motion-is-filed-against-californias-medical-misinformation-law/" rel="nofollow" title="Motion is filed against California&#8217;s medical &#8220;misinformation&#8221; law"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/calif-misinfor.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The law is scheduled to come into force within weeks.</p>
<p>The post <a href="https://reclaimthenet.org/motion-is-filed-against-californias-medical-misinformation-law/" rel="nofollow">Motion is filed against California&#8217;s medical &#8220;misinformation&#8221; law</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Proton Drive brings private file storage to iOS and Android
 - [https://reclaimthenet.org/proton-drive-ios-and-android/](https://reclaimthenet.org/proton-drive-ios-and-android/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-08 16:53:50+00:00

<a href="https://reclaimthenet.org/proton-drive-ios-and-android/" rel="nofollow" title="Proton Drive brings private file storage to iOS and Android"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/proton-drive-app.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>It was previously only available through the web.</p>
<p>The post <a href="https://reclaimthenet.org/proton-drive-ios-and-android/" rel="nofollow">Proton Drive brings private file storage to iOS and Android</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Judge orders Southwest flight attendant, fired for pro-life emails and social media posts, to be reinstated
 - [https://reclaimthenet.org/southwest-flight-attendant-reinstated/](https://reclaimthenet.org/southwest-flight-attendant-reinstated/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-08 16:14:15+00:00

<a href="https://reclaimthenet.org/southwest-flight-attendant-reinstated/" rel="nofollow" title="Judge orders Southwest flight attendant, fired for pro-life emails and social media posts, to be reinstated"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/sw.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>She had already received a large payout.</p>
<p>The post <a href="https://reclaimthenet.org/southwest-flight-attendant-reinstated/" rel="nofollow">Judge orders Southwest flight attendant, fired for pro-life emails and social media posts, to be reinstated</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## China pressures Google to alter its search results for the Hong Kong national anthem
 - [https://reclaimthenet.org/china-pressures-goog-to-alter-its-search-results-hk-anthem/](https://reclaimthenet.org/china-pressures-goog-to-alter-its-search-results-hk-anthem/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-08 15:31:53+00:00

<a href="https://reclaimthenet.org/china-pressures-goog-to-alter-its-search-results-hk-anthem/" rel="nofollow" title="China pressures Google to alter its search results for the Hong Kong national anthem"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/goog-hk.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Google is yet to respond.</p>
<p>The post <a href="https://reclaimthenet.org/china-pressures-goog-to-alter-its-search-results-hk-anthem/" rel="nofollow">China pressures Google to alter its search results for the Hong Kong national anthem</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Elon Musk hints censorship docs may have been hidden or deleted
 - [https://reclaimthenet.org/elon-musk-censorship-docs-hidden-or-deleted/](https://reclaimthenet.org/elon-musk-censorship-docs-hidden-or-deleted/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2022-12-08 15:07:08+00:00

<a href="https://reclaimthenet.org/elon-musk-censorship-docs-hidden-or-deleted/" rel="nofollow" title="Elon Musk hints censorship docs may have been hidden or deleted"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2022/12/elon-twit.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>By previous employees.</p>
<p>The post <a href="https://reclaimthenet.org/elon-musk-censorship-docs-hidden-or-deleted/" rel="nofollow">Elon Musk hints censorship docs may have been hidden or deleted</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>


# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Energy & Environment — Gas prices down year-over-year
 - [http://www.msn.com/en-us/news/politics/energy-environment-gas-prices-down-year-over-year/ar-AA153SIL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/energy-environment-gas-prices-down-year-over-year/ar-AA153SIL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 23:20:27.573770+00:00



## Family of former Marine held in Russia speaks out after Griner's release
 - [http://www.msn.com/en-us/news/world/family-of-former-marine-held-in-russia-speaks-out-after-griner-s-release/ar-AA153TST?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/family-of-former-marine-held-in-russia-speaks-out-after-griner-s-release/ar-AA153TST?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 23:20:27.565400+00:00



## Prisoner Swap for Griner Was Biden's Second, But White House Says They Must Remain Rare
 - [http://www.msn.com/en-us/news/politics/prisoner-swap-for-griner-was-biden-s-second-but-white-house-says-they-must-remain-rare/ar-AA1549Um?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/prisoner-swap-for-griner-was-biden-s-second-but-white-house-says-they-must-remain-rare/ar-AA1549Um?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 23:20:27.557305+00:00



## Rapper Nuke Bizzle Sentenced to Over 6 Years After Bragging About Stealing Pandemic Aid
 - [http://www.msn.com/en-us/news/crime/rapper-nuke-bizzle-sentenced-to-over-6-years-after-bragging-about-stealing-pandemic-aid/ar-AA154m1S?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/rapper-nuke-bizzle-sentenced-to-over-6-years-after-bragging-about-stealing-pandemic-aid/ar-AA154m1S?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 23:20:27.549529+00:00



## Seven more House Republicans threaten to oppose McCarthy without concessions on House rules
 - [http://www.msn.com/en-us/news/politics/seven-more-house-republicans-threaten-to-oppose-mccarthy-without-concessions-on-house-rules/ar-AA1545ep?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/seven-more-house-republicans-threaten-to-oppose-mccarthy-without-concessions-on-house-rules/ar-AA1545ep?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 23:20:27.541651+00:00



## DOJ asks judge to hold Trump in contempt over classified documents subpoena, reports say
 - [http://www.msn.com/en-us/news/politics/doj-asks-judge-to-hold-trump-in-contempt-over-classified-documents-subpoena-reports-say/ar-AA154c5s?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/doj-asks-judge-to-hold-trump-in-contempt-over-classified-documents-subpoena-reports-say/ar-AA154c5s?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 23:20:27.203677+00:00



## Trump Mar-a-Lago suit ends after former president declines to appeal ruling
 - [http://www.msn.com/en-us/news/politics/trump-mar-a-lago-suit-ends-after-former-president-declines-to-appeal-ruling/ar-AA154m4S?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-mar-a-lago-suit-ends-after-former-president-declines-to-appeal-ruling/ar-AA154m4S?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 23:20:27.195312+00:00



## The U.S. wants Iran off a U.N. women’s rights panel. It’s not that easy.
 - [http://www.msn.com/en-us/news/world/the-u-s-wants-iran-off-a-u-n-women-s-rights-panel-it-s-not-that-easy/ar-AA154jB5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-u-s-wants-iran-off-a-u-n-women-s-rights-panel-it-s-not-that-easy/ar-AA154jB5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 23:20:27.007209+00:00



## Jill Biden to join Zooey Deschanel, Jonathan Scott for HGTV’s ‘White House Christmas’
 - [http://www.msn.com/en-us/news/politics/jill-biden-to-join-zooey-deschanel-jonathan-scott-for-hgtv-s-white-house-christmas/ar-AA154j4o?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jill-biden-to-join-zooey-deschanel-jonathan-scott-for-hgtv-s-white-house-christmas/ar-AA154j4o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 22:20:25.908593+00:00



## DOJ demands Trump team be held in contempt of court over Mar-a-Lago documents: Report
 - [http://www.msn.com/en-us/news/politics/doj-demands-trump-team-be-held-in-contempt-of-court-over-mar-a-lago-documents-report/ar-AA154o5F?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/doj-demands-trump-team-be-held-in-contempt-of-court-over-mar-a-lago-documents-report/ar-AA154o5F?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 22:20:25.900898+00:00



## Wage gap between Latinas and white men: It’s worse than you think
 - [http://www.msn.com/en-us/news/us/wage-gap-between-latinas-and-white-men-it-s-worse-than-you-think/ar-AA154ltt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/wage-gap-between-latinas-and-white-men-it-s-worse-than-you-think/ar-AA154ltt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 22:20:25.562626+00:00



## Elon Musk and the (ahem) future of civilization
 - [http://www.msn.com/en-us/news/technology/elon-musk-and-the-ahem-future-of-civilization/ar-AA154bvm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-and-the-ahem-future-of-civilization/ar-AA154bvm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 22:20:25.553658+00:00



## FedEx Driver Delivered Barbie Dolls to 7-Year-Old Athena Strand Before Allegedly Kidnapping, Killing Her
 - [http://www.msn.com/en-us/news/crime/fedex-driver-delivered-barbie-dolls-to-7-year-old-athena-strand-before-allegedly-kidnapping-killing-her/ar-AA154bwe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/fedex-driver-delivered-barbie-dolls-to-7-year-old-athena-strand-before-allegedly-kidnapping-killing-her/ar-AA154bwe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 22:20:25.546485+00:00



## President Biden notches political, policy and diplomacy wins to cap year
 - [http://www.msn.com/en-us/news/politics/president-biden-notches-political-policy-and-diplomacy-wins-to-cap-year/ar-AA1549u8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/president-biden-notches-political-policy-and-diplomacy-wins-to-cap-year/ar-AA1549u8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 22:20:25.537858+00:00



## Trouble Falling Asleep? This Dietary Supplement Also Works as a Sleep Aid
 - [http://www.msn.com/en-us/health/other/trouble-falling-asleep-this-dietary-supplement-also-works-as-a-sleep-aid/ar-AA13XdVK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/other/trouble-falling-asleep-this-dietary-supplement-also-works-as-a-sleep-aid/ar-AA13XdVK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 22:20:25.529922+00:00



## Weingarten slammed for tweet highlighting Brittney Griner’s race and sexuality after release: ‘complete clown'
 - [http://www.msn.com/en-us/news/us/weingarten-slammed-for-tweet-highlighting-brittney-griner-s-race-and-sexuality-after-release-complete-clown/ar-AA154lvP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/weingarten-slammed-for-tweet-highlighting-brittney-griner-s-race-and-sexuality-after-release-complete-clown/ar-AA154lvP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 22:20:25.392234+00:00



## Senate panel threatens to subpoena Bankman-Fried for FTX hearing testimony
 - [http://www.msn.com/en-us/news/politics/senate-panel-threatens-to-subpoena-bankman-fried-for-ftx-hearing-testimony/ar-AA1542p6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-panel-threatens-to-subpoena-bankman-fried-for-ftx-hearing-testimony/ar-AA1542p6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 21:20:21.078274+00:00



## President Biden doesn't care about the border
 - [http://www.msn.com/en-us/news/politics/president-biden-doesn-t-care-about-the-border/ar-AA1542Am?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/president-biden-doesn-t-care-about-the-border/ar-AA1542Am?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 21:20:21.070321+00:00



## House hearing airs ethics allegations against Supreme Court
 - [http://www.msn.com/en-us/news/politics/house-hearing-airs-ethics-allegations-against-supreme-court/ar-AA153Xtq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-hearing-airs-ethics-allegations-against-supreme-court/ar-AA153Xtq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 21:20:21.060002+00:00



## States With the Highest Lottery Income
 - [http://www.msn.com/en-us/news/us/states-with-the-highest-lottery-income/ar-AA153Vkw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/states-with-the-highest-lottery-income/ar-AA153Vkw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 21:20:21.051002+00:00



## Amazon is introducing a new TikTok-like feature that allows users to 'shop as you scroll' from a social feed of videos and photos
 - [http://www.msn.com/en-us/news/technology/amazon-is-introducing-a-new-tiktok-like-feature-that-allows-users-to-shop-as-you-scroll-from-a-social-feed-of-videos-and-photos/ar-AA154gcY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/amazon-is-introducing-a-new-tiktok-like-feature-that-allows-users-to-shop-as-you-scroll-from-a-social-feed-of-videos-and-photos/ar-AA154gcY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 21:20:21.040722+00:00



## House Democrats abruptly cancel Big Oil hearing where Elon Musk was scheduled to appear
 - [http://www.msn.com/en-us/news/politics/house-democrats-abruptly-cancel-big-oil-hearing-where-elon-musk-was-scheduled-to-appear/ar-AA153ZMr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-democrats-abruptly-cancel-big-oil-hearing-where-elon-musk-was-scheduled-to-appear/ar-AA153ZMr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 21:20:20.801211+00:00



## New Mexico State Police release fatal campus shooting video
 - [http://www.msn.com/en-us/news/crime/new-mexico-state-police-release-fatal-campus-shooting-video/ar-AA153Nch?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/new-mexico-state-police-release-fatal-campus-shooting-video/ar-AA153Nch?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 20:20:16.087623+00:00



## Paul Whelan says he doesn't 'understand' why he's still in Russian captivity after Brittney Griner was freed
 - [http://www.msn.com/en-us/news/politics/paul-whelan-says-he-doesn-t-understand-why-he-s-still-in-russian-captivity-after-brittney-griner-was-freed/ar-AA1548rx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/paul-whelan-says-he-doesn-t-understand-why-he-s-still-in-russian-captivity-after-brittney-griner-was-freed/ar-AA1548rx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 20:20:16.078614+00:00



## Elon Musk posts pictures of his 2-year-old son, X, visiting Twitter HQ — including one with his own employee badge
 - [http://www.msn.com/en-us/news/technology/elon-musk-posts-pictures-of-his-2-year-old-son-x-visiting-twitter-hq-including-one-with-his-own-employee-badge/ar-AA1548sC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-posts-pictures-of-his-2-year-old-son-x-visiting-twitter-hq-including-one-with-his-own-employee-badge/ar-AA1548sC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 20:20:16.070893+00:00



## Arctic Adventurers Have a Russia Problem
 - [http://www.msn.com/en-us/news/world/arctic-adventurers-have-a-russia-problem/ar-AA1541OC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/arctic-adventurers-have-a-russia-problem/ar-AA1541OC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 20:20:16.063152+00:00



## What the Respect for Marriage Act actually does
 - [http://www.msn.com/en-us/news/us/what-the-respect-for-marriage-act-actually-does/ar-AA14P4XU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-the-respect-for-marriage-act-actually-does/ar-AA14P4XU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 20:20:16.055382+00:00



## Prince Harry on Why He Fought in British Army: 'There's Still Scars Left Open from My Mom's Awesomeness'
 - [http://www.msn.com/en-us/news/us/prince-harry-on-why-he-fought-in-british-army-there-s-still-scars-left-open-from-my-mom-s-awesomeness/ar-AA153KAf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/prince-harry-on-why-he-fought-in-british-army-there-s-still-scars-left-open-from-my-mom-s-awesomeness/ar-AA153KAf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 20:20:15.716359+00:00



## Climate anxiety isn’t the enemy: Embracing it can speed change
 - [http://www.msn.com/en-us/news/politics/climate-anxiety-isn-t-the-enemy-embracing-it-can-speed-change/ar-AA1543Xf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/climate-anxiety-isn-t-the-enemy-embracing-it-can-speed-change/ar-AA1543Xf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 20:20:15.702818+00:00



## Prosecution rests its case in trial of cop charged for fatally shooting woman in home
 - [http://www.msn.com/en-us/news/crime/prosecution-rests-its-case-in-trial-of-cop-charged-for-fatally-shooting-woman-in-home/ar-AA14FL9L?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/prosecution-rests-its-case-in-trial-of-cop-charged-for-fatally-shooting-woman-in-home/ar-AA14FL9L?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 20:20:15.512028+00:00



## A Republican congresswoman broke down in tears begging her colleagues to vote against a same-sex marriage bill
 - [http://www.msn.com/en-us/news/politics/a-republican-congresswoman-broke-down-in-tears-begging-her-colleagues-to-vote-against-a-same-sex-marriage-bill/ar-AA153CVO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/a-republican-congresswoman-broke-down-in-tears-begging-her-colleagues-to-vote-against-a-same-sex-marriage-bill/ar-AA153CVO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 19:20:13.526116+00:00



## Behind the Scenes of TIME's 2022 Person of the Year Issue
 - [http://www.msn.com/en-us/news/world/behind-the-scenes-of-time-s-2022-person-of-the-year-issue/ar-AA15413C?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/behind-the-scenes-of-time-s-2022-person-of-the-year-issue/ar-AA15413C?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 19:20:13.518282+00:00



## House passes massive $858 billion defense bill that would scrap military Covid vaccine mandate, teeing up Senate vote
 - [http://www.msn.com/en-us/news/politics/house-passes-massive-858-billion-defense-bill-that-would-scrap-military-covid-vaccine-mandate-teeing-up-senate-vote/ar-AA153K3B?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-passes-massive-858-billion-defense-bill-that-would-scrap-military-covid-vaccine-mandate-teeing-up-senate-vote/ar-AA153K3B?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 19:20:13.510628+00:00



## Congress’s historic shift on marriage equality, in 2 charts
 - [http://www.msn.com/en-us/news/politics/congress-s-historic-shift-on-marriage-equality-in-2-charts/ar-AA1541bD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/congress-s-historic-shift-on-marriage-equality-in-2-charts/ar-AA1541bD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 19:20:13.503007+00:00



## 5 officers charged in police van injury case appear in court
 - [http://www.msn.com/en-us/news/crime/5-officers-charged-in-police-van-injury-case-appear-in-court/ar-AA153YIv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/5-officers-charged-in-police-van-injury-case-appear-in-court/ar-AA153YIv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 19:20:13.494886+00:00



## House report says Commanders owner obstructed inquiry into ‘toxic’ workplace
 - [http://www.msn.com/en-us/news/politics/house-report-says-commanders-owner-obstructed-inquiry-into-toxic-workplace/ar-AA153D1h?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-report-says-commanders-owner-obstructed-inquiry-into-toxic-workplace/ar-AA153D1h?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 19:20:13.156928+00:00



## Gen. Petraeus on Griner release: Hate to 'reward' Russia for swap, Viktor Bout has 'blood on his hands'
 - [http://www.msn.com/en-us/news/world/gen-petraeus-on-griner-release-hate-to-reward-russia-for-swap-viktor-bout-has-blood-on-his-hands/ar-AA153Uiv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/gen-petraeus-on-griner-release-hate-to-reward-russia-for-swap-viktor-bout-has-blood-on-his-hands/ar-AA153Uiv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 19:20:13.148373+00:00



## Democratic report details government’s COVID failings: Suffering was 'not inevitable'
 - [http://www.msn.com/en-us/news/politics/democratic-report-details-government-s-covid-failings-suffering-was-not-inevitable/ar-AA153c7U?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/democratic-report-details-government-s-covid-failings-suffering-was-not-inevitable/ar-AA153c7U?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 19:20:12.959775+00:00



## Putin uses Peter the Great as prop for faltering Russian morale
 - [http://www.msn.com/en-us/news/world/putin-uses-peter-the-great-as-prop-for-faltering-russian-morale/ar-AA153vbf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-uses-peter-the-great-as-prop-for-faltering-russian-morale/ar-AA153vbf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 18:20:08.199996+00:00



## Ex-Rep. Barney Frank, gay trailblazer, praises House passage of same-sex marriage bill
 - [http://www.msn.com/en-us/news/politics/ex-rep-barney-frank-gay-trailblazer-praises-house-passage-of-same-sex-marriage-bill/ar-AA153Y8I?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ex-rep-barney-frank-gay-trailblazer-praises-house-passage-of-same-sex-marriage-bill/ar-AA153Y8I?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 18:20:08.191369+00:00



## Trump endorsed Walker and terminating the Constitution. He's officially an eyeroll.
 - [http://www.msn.com/en-us/news/politics/trump-endorsed-walker-and-terminating-the-constitution-he-s-officially-an-eyeroll/ar-AA153QTU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-endorsed-walker-and-terminating-the-constitution-he-s-officially-an-eyeroll/ar-AA153QTU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 18:20:08.182310+00:00



## Fed’s cryptocurrency pilot opens door for dangerous retail option
 - [http://www.msn.com/en-us/news/politics/fed-s-cryptocurrency-pilot-opens-door-for-dangerous-retail-option/ar-AA153vc5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/fed-s-cryptocurrency-pilot-opens-door-for-dangerous-retail-option/ar-AA153vc5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 18:20:07.843834+00:00



## 'Where's Teekah?': Images Released of Girl Abducted from Bowling Alley in 1999 When It Was Mom's Turn to Bowl
 - [http://www.msn.com/en-us/news/crime/where-s-teekah-images-released-of-girl-abducted-from-bowling-alley-in-1999-when-it-was-mom-s-turn-to-bowl/ar-AA153QTB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/where-s-teekah-images-released-of-girl-abducted-from-bowling-alley-in-1999-when-it-was-mom-s-turn-to-bowl/ar-AA153QTB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 18:20:07.504581+00:00



## The Biden administration still hasn't found parents of 120 children separated from their families under Trump
 - [http://www.msn.com/en-us/news/us/the-biden-administration-still-hasn-t-found-parents-of-120-children-separated-from-their-families-under-trump/ar-AA153vck?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-biden-administration-still-hasn-t-found-parents-of-120-children-separated-from-their-families-under-trump/ar-AA153vck?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 18:20:07.493029+00:00



## McCarthy creates House China Select Committee to confront CCP threats
 - [http://www.msn.com/en-us/news/world/mccarthy-creates-house-china-select-committee-to-confront-ccp-threats/ar-AA153Y9g?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/mccarthy-creates-house-china-select-committee-to-confront-ccp-threats/ar-AA153Y9g?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 18:20:07.353053+00:00



## ‘Boy in the Box,’ found dead in Philadelphia 65 years ago, is finally identified
 - [http://www.msn.com/en-us/news/us/boy-in-the-box-found-dead-in-philadelphia-65-years-ago-is-finally-identified/ar-AA153SXb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/boy-in-the-box-found-dead-in-philadelphia-65-years-ago-is-finally-identified/ar-AA153SXb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 17:20:06.016112+00:00



## Op-Ed: Democrats should use their Senate majority to expose Republican corruption
 - [http://www.msn.com/en-us/news/politics/op-ed-democrats-should-use-their-senate-majority-to-expose-republican-corruption/ar-AA153zZy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/op-ed-democrats-should-use-their-senate-majority-to-expose-republican-corruption/ar-AA153zZy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 17:20:06.008415+00:00



## Iran executes first prisoner charged in protests
 - [http://www.msn.com/en-us/news/world/iran-executes-first-prisoner-charged-in-protests/ar-AA153sqr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/iran-executes-first-prisoner-charged-in-protests/ar-AA153sqr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 17:20:05.670779+00:00



## Man who vanished from Connecticut nearly a decade ago found dead in upstate New York with a new name
 - [http://www.msn.com/en-us/news/crime/man-who-vanished-from-connecticut-nearly-a-decade-ago-found-dead-in-upstate-new-york-with-a-new-name/ar-AA153uAP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/man-who-vanished-from-connecticut-nearly-a-decade-ago-found-dead-in-upstate-new-york-with-a-new-name/ar-AA153uAP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 17:20:05.662205+00:00



## St. Louis mayor appoints commission to consider reparations
 - [http://www.msn.com/en-us/news/us/st-louis-mayor-appoints-commission-to-consider-reparations/ar-AA153T2j?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/st-louis-mayor-appoints-commission-to-consider-reparations/ar-AA153T2j?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 17:20:05.654617+00:00



## The 'only person' Biden could beat is Trump: Karl Rove doubts POTUS will be the Democrat nominee in 2024
 - [http://www.msn.com/en-us/news/politics/the-only-person-biden-could-beat-is-trump-karl-rove-doubts-potus-will-be-the-democrat-nominee-in-2024/ar-AA153A3O?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-only-person-biden-could-beat-is-trump-karl-rove-doubts-potus-will-be-the-democrat-nominee-in-2024/ar-AA153A3O?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 17:20:05.316582+00:00



## Saudi Arabia and the United Arab Emirates take credit for negotiating Brittney Griner's release from Russian prison
 - [http://www.msn.com/en-us/news/world/saudi-arabia-and-the-united-arab-emirates-take-credit-for-negotiating-brittney-griner-s-release-from-russian-prison/ar-AA153Hor?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/saudi-arabia-and-the-united-arab-emirates-take-credit-for-negotiating-brittney-griner-s-release-from-russian-prison/ar-AA153Hor?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 17:20:05.196946+00:00



## Beautiful December Full Cold Moon Photos From Around the World
 - [http://www.msn.com/en-us/news/technology/beautiful-december-full-cold-moon-photos-from-around-the-world/ar-AA153Gzy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/beautiful-december-full-cold-moon-photos-from-around-the-world/ar-AA153Gzy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 16:20:03.979989+00:00



## Suspect at large after triple shooting at D.C. train station leaves teen with possibly life-threatening injuries
 - [http://www.msn.com/en-us/news/us/suspect-at-large-after-triple-shooting-at-d-c-train-station-leaves-teen-with-possibly-life-threatening-injuries/ar-AA153toO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/suspect-at-large-after-triple-shooting-at-d-c-train-station-leaves-teen-with-possibly-life-threatening-injuries/ar-AA153toO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 16:20:03.971947+00:00



## FDA clears updated COVID-19 vaccines for kids under age 5
 - [http://www.msn.com/en-us/health/health-news/fda-clears-updated-covid-19-vaccines-for-kids-under-age-5/ar-AA153L41?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/health-news/fda-clears-updated-covid-19-vaccines-for-kids-under-age-5/ar-AA153L41?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 16:20:03.963733+00:00



## Activist who alleged Supreme Court leak appears before House Judiciary Committee
 - [http://www.msn.com/en-us/news/politics/activist-who-alleged-supreme-court-leak-appears-before-house-judiciary-committee/ar-AA153Bow?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/activist-who-alleged-supreme-court-leak-appears-before-house-judiciary-committee/ar-AA153Bow?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 16:20:03.951207+00:00



## 3 numbers that show how Raphael Warnock won the Georgia runoff
 - [http://www.msn.com/en-us/news/politics/3-numbers-that-show-how-raphael-warnock-won-the-georgia-runoff/ar-AA153NBG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/3-numbers-that-show-how-raphael-warnock-won-the-georgia-runoff/ar-AA153NBG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 16:20:03.943138+00:00



## Doug Emhoff addresses 'rapid rise' in antisemitism with White House roundtable
 - [http://www.msn.com/en-us/news/politics/doug-emhoff-addresses-rapid-rise-in-antisemitism-with-white-house-roundtable/ar-AA151oOj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/doug-emhoff-addresses-rapid-rise-in-antisemitism-with-white-house-roundtable/ar-AA151oOj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 16:20:03.605355+00:00



## Fox Host Swipes at Brittney Griner While Announcing Her Release
 - [http://www.msn.com/en-us/news/world/fox-host-swipes-at-brittney-griner-while-announcing-her-release/ar-AA153ICr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fox-host-swipes-at-brittney-griner-while-announcing-her-release/ar-AA153ICr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 16:20:03.592899+00:00



## 3 Members of Beloved College Marching Band Killed When Hit by Semi Truck While Fixing Flat Tire
 - [http://www.msn.com/en-us/news/us/3-members-of-beloved-college-marching-band-killed-when-hit-by-semi-truck-while-fixing-flat-tire/ar-AA153NFT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/3-members-of-beloved-college-marching-band-killed-when-hit-by-semi-truck-while-fixing-flat-tire/ar-AA153NFT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 16:20:03.453668+00:00



## Trump allies aim to capture his philosophy in policy book
 - [http://www.msn.com/en-us/news/politics/trump-allies-aim-to-capture-his-philosophy-in-policy-book/ar-AA153feV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-allies-aim-to-capture-his-philosophy-in-policy-book/ar-AA153feV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:20:10.811148+00:00



## Tom Cotton shows Republicans the way on woke corporations
 - [http://www.msn.com/en-us/news/politics/tom-cotton-shows-republicans-the-way-on-woke-corporations/ar-AA153tcj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/tom-cotton-shows-republicans-the-way-on-woke-corporations/ar-AA153tcj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:20:10.793349+00:00



## Air Force pilots seeking religious vaccine exemption still grounded while other unvaxxed members can fly
 - [http://www.msn.com/en-us/news/us/air-force-pilots-seeking-religious-vaccine-exemption-still-grounded-while-other-unvaxxed-members-can-fly/ar-AA153hTc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/air-force-pilots-seeking-religious-vaccine-exemption-still-grounded-while-other-unvaxxed-members-can-fly/ar-AA153hTc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:20:10.782627+00:00



## The Trump Org tax-fraud conviction could embolden the DA to file new NY charges against Trump
 - [http://www.msn.com/en-us/news/politics/the-trump-org-tax-fraud-conviction-could-embolden-the-da-to-file-new-ny-charges-against-trump/ar-AA151mAY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-trump-org-tax-fraud-conviction-could-embolden-the-da-to-file-new-ny-charges-against-trump/ar-AA151mAY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:20:10.770982+00:00



## Democratic report details Trump's COVID failings: Suffering was 'not inevitable'
 - [http://www.msn.com/en-us/news/politics/democratic-report-details-trump-s-covid-failings-suffering-was-not-inevitable/ar-AA153c7U?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/democratic-report-details-trump-s-covid-failings-suffering-was-not-inevitable/ar-AA153c7U?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:19:59.281165+00:00



## North Korea: A land of dynastic decay and limitless death
 - [http://www.msn.com/en-us/news/world/north-korea-a-land-of-dynastic-decay-and-limitless-death/ar-AA153y5a?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/north-korea-a-land-of-dynastic-decay-and-limitless-death/ar-AA153y5a?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:19:59.272156+00:00



## Spoiler alert: The one factor Democrats fear could put Trump back in the White House
 - [http://www.msn.com/en-us/news/politics/spoiler-alert-the-one-factor-democrats-fear-could-put-trump-back-in-the-white-house/ar-AA153vwW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/spoiler-alert-the-one-factor-democrats-fear-could-put-trump-back-in-the-white-house/ar-AA153vwW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:19:59.255384+00:00



## These Were the 10 Most Difficult Wordle Words of 2022
 - [http://www.msn.com/en-us/news/technology/these-were-the-10-most-difficult-wordle-words-of-2022/ar-AA13YOAa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/these-were-the-10-most-difficult-wordle-words-of-2022/ar-AA13YOAa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:19:59.247205+00:00



## Biden says Brittney Griner is 'safe' after release from Russia in prisoner swap
 - [http://www.msn.com/en-us/news/world/biden-says-brittney-griner-is-safe-after-release-from-russia-in-prisoner-swap/ar-AA153yh2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/biden-says-brittney-griner-is-safe-after-release-from-russia-in-prisoner-swap/ar-AA153yh2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:19:58.908891+00:00



## Gasoline is cheaper now than a year ago — and could fall below $3
 - [http://www.msn.com/en-us/news/us/gasoline-is-cheaper-now-than-a-year-ago-and-could-fall-below-3/ar-AA153f5I?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/gasoline-is-cheaper-now-than-a-year-ago-and-could-fall-below-3/ar-AA153f5I?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:19:58.269144+00:00



## Winsome Sears torches 'dereliction of duty' in VA school's handling of bathroom rape case: 'This is not over'
 - [http://www.msn.com/en-us/news/us/winsome-sears-torches-dereliction-of-duty-in-va-school-s-handling-of-bathroom-rape-case-this-is-not-over/ar-AA153cbB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/winsome-sears-torches-dereliction-of-duty-in-va-school-s-handling-of-bathroom-rape-case-this-is-not-over/ar-AA153cbB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:19:58.261693+00:00



## Trump allies aim to capture his philosophy in policy book
 - [http://www.msn.com/en-us/news/politics/trump-allies-aim-to-capture-his-philosophy-in-policy-book/ar-AA153pzp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-allies-aim-to-capture-his-philosophy-in-policy-book/ar-AA153pzp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 15:19:58.122972+00:00



## Brittney Griner Released From Russian Detention in Prisoner Swap
 - [http://www.msn.com/en-us/news/world/brittney-griner-released-from-russian-detention-in-prisoner-swap/ar-AA153m93?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/brittney-griner-released-from-russian-detention-in-prisoner-swap/ar-AA153m93?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:20:05.343148+00:00



## Can Democrats break America’s political stalemate?
 - [http://www.msn.com/en-us/news/politics/can-democrats-break-america-s-political-stalemate/ar-AA153bRd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/can-democrats-break-america-s-political-stalemate/ar-AA153bRd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:20:05.332596+00:00



## Who has cash to burn for these extravagant $1,000+ Amazon gifts?
 - [http://www.msn.com/en-us/news/technology/who-has-cash-to-burn-for-these-extravagant-1-000-amazon-gifts/ar-AA153hhC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/who-has-cash-to-burn-for-these-extravagant-1-000-amazon-gifts/ar-AA153hhC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:20:05.319079+00:00



## WNBA star Brittney Griner released from Russian custody in a high-profile prisoner swap between the U.S. and Moscow
 - [http://www.msn.com/en-us/news/world/wnba-star-brittney-griner-released-from-russian-custody-in-a-high-profile-prisoner-swap-between-the-u-s-and-moscow/ar-AA152Z5I?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/wnba-star-brittney-griner-released-from-russian-custody-in-a-high-profile-prisoner-swap-between-the-u-s-and-moscow/ar-AA152Z5I?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:20:05.310896+00:00



## Boy killed in the 50s is finally ID'd
 - [http://www.msn.com/en-us/news/crime/boy-killed-in-the-50s-is-finally-id-d/ar-AA152C4d?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/boy-killed-in-the-50s-is-finally-id-d/ar-AA152C4d?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:20:05.121234+00:00



## 2022 was year the horror of war returned to Europe
 - [http://www.msn.com/en-us/news/world/2022-was-year-the-horror-of-war-returned-to-europe/ar-AA153h09?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/2022-was-year-the-horror-of-war-returned-to-europe/ar-AA153h09?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:19:55.338522+00:00



## Brittney Griner Released by Russia in Prisoner Swap
 - [http://www.msn.com/en-us/news/world/brittney-griner-released-by-russia-in-prisoner-swap/ar-AA153bzQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/brittney-griner-released-by-russia-in-prisoner-swap/ar-AA153bzQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:19:55.330910+00:00



## Russian State TV Laments Gaps in Air Defense System, Lack of Satellites
 - [http://www.msn.com/en-us/news/world/russian-state-tv-laments-gaps-in-air-defense-system-lack-of-satellites/ar-AA153owY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-state-tv-laments-gaps-in-air-defense-system-lack-of-satellites/ar-AA153owY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:19:54.692345+00:00



## Key Senate Republican Thune says he hopes for ‘other options’ to Trump in 2024
 - [http://www.msn.com/en-us/news/politics/key-senate-republican-thune-says-he-hopes-for-other-options-to-trump-in-2024/ar-AA1537rz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/key-senate-republican-thune-says-he-hopes-for-other-options-to-trump-in-2024/ar-AA1537rz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:19:54.682030+00:00



## Russia's Ukraine onslaught shows zero signs of a winter lull as conflict rages
 - [http://www.msn.com/en-us/news/world/russia-s-ukraine-onslaught-shows-zero-signs-of-a-winter-lull-as-conflict-rages/ar-AA152UuX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-s-ukraine-onslaught-shows-zero-signs-of-a-winter-lull-as-conflict-rages/ar-AA152UuX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:19:54.674013+00:00



## Illegal border crossings soar in El Paso Sector in November
 - [http://www.msn.com/en-us/news/us/illegal-border-crossings-soar-in-el-paso-sector-in-november/ar-AA153qm6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/illegal-border-crossings-soar-in-el-paso-sector-in-november/ar-AA153qm6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:19:54.665791+00:00



## Who is the Russian arms dealer known as the 'Merchant of Death' that the U.S. exchanged for Brittney Griner?
 - [http://www.msn.com/en-us/news/world/who-is-the-russian-arms-dealer-known-as-the-merchant-of-death-that-the-u-s-exchanged-for-brittney-griner/ar-AAZiYlO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/who-is-the-russian-arms-dealer-known-as-the-merchant-of-death-that-the-u-s-exchanged-for-brittney-griner/ar-AAZiYlO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:19:54.657735+00:00



## This Cooking Hack Changed How I Boil My Pasta Water
 - [http://www.msn.com/en-us/news/technology/this-cooking-hack-changed-how-i-boil-my-pasta-water/ar-AA1531WZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/this-cooking-hack-changed-how-i-boil-my-pasta-water/ar-AA1531WZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 14:19:54.466978+00:00



## When Everything You Touch Turns to Crime
 - [http://www.msn.com/en-us/news/us/when-everything-you-touch-turns-to-crime/ar-AA1532hn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/when-everything-you-touch-turns-to-crime/ar-AA1532hn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 13:19:46.015323+00:00



## FTC challenges Meta acquisition of VR company in court
 - [http://www.msn.com/en-us/news/politics/ftc-challenges-meta-acquisition-of-vr-company-in-court/ar-AA153liA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ftc-challenges-meta-acquisition-of-vr-company-in-court/ar-AA153liA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 13:19:46.006566+00:00



## Pregnant American Defends Using the U.K.'s National Healthcare Service
 - [http://www.msn.com/en-us/news/world/pregnant-american-defends-using-the-u-k-s-national-healthcare-service/ar-AA152U2x?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/pregnant-american-defends-using-the-u-k-s-national-healthcare-service/ar-AA152U2x?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 13:19:45.998970+00:00



## Republicans reverse course on one position blamed for midterm defeats
 - [http://www.msn.com/en-us/news/politics/republicans-reverse-course-on-one-position-blamed-for-midterm-defeats/ar-AA1536XH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-reverse-course-on-one-position-blamed-for-midterm-defeats/ar-AA1536XH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 13:19:45.991385+00:00



## Putin has a plan to flee to South America if he loses the war in Ukraine, former aide says
 - [http://www.msn.com/en-us/news/world/putin-has-a-plan-to-flee-to-south-america-if-he-loses-the-war-in-ukraine-former-aide-says/ar-AA1536T1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-has-a-plan-to-flee-to-south-america-if-he-loses-the-war-in-ukraine-former-aide-says/ar-AA1536T1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 13:19:45.983831+00:00



## Why modern wars cannot escape the trenches
 - [http://www.msn.com/en-us/news/politics/why-modern-wars-cannot-escape-the-trenches/ar-AA153e2o?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/why-modern-wars-cannot-escape-the-trenches/ar-AA153e2o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 13:19:45.975766+00:00



## For Black families in Phoenix, child welfare investigations are a constant threat
 - [http://www.msn.com/en-us/news/us/for-black-families-in-phoenix-child-welfare-investigations-are-a-constant-threat/ar-AA153nzy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/for-black-families-in-phoenix-child-welfare-investigations-are-a-constant-threat/ar-AA153nzy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 13:19:45.967583+00:00



## Feds investigating multiple reports of recent utility company sabotage
 - [http://www.msn.com/en-us/news/us/feds-investigating-multiple-reports-of-recent-utility-company-sabotage/ar-AA1539bb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/feds-investigating-multiple-reports-of-recent-utility-company-sabotage/ar-AA1539bb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 13:19:45.959026+00:00



## Emboldened House Republicans to bring ESG scrutiny, experts say
 - [http://www.msn.com/en-us/news/politics/emboldened-house-republicans-to-bring-esg-scrutiny-experts-say/ar-AA152YvX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/emboldened-house-republicans-to-bring-esg-scrutiny-experts-say/ar-AA152YvX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 12:19:56.962878+00:00



## What I Learned from the Generation of Disabled Activists Who Came After Me
 - [http://www.msn.com/en-us/news/us/what-i-learned-from-the-generation-of-disabled-activists-who-came-after-me/ar-AA1536hC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-i-learned-from-the-generation-of-disabled-activists-who-came-after-me/ar-AA1536hC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 12:19:56.953979+00:00



## 'Boy in the box': Victim finally ID'd in city's oldest homicide case
 - [http://www.msn.com/en-us/news/crime/boy-in-the-box-victim-finally-id-d-in-city-s-oldest-homicide-case/ar-AA152C4d?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/boy-in-the-box-victim-finally-id-d-in-city-s-oldest-homicide-case/ar-AA152C4d?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 12:19:56.943141+00:00



## NATO chief says Russia wants a 'freeze' in Ukraine fighting so it can prepare for a renewed assault early next year
 - [http://www.msn.com/en-us/news/world/nato-chief-says-russia-wants-a-freeze-in-ukraine-fighting-so-it-can-prepare-for-a-renewed-assault-early-next-year/ar-AA152n3C?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/nato-chief-says-russia-wants-a-freeze-in-ukraine-fighting-so-it-can-prepare-for-a-renewed-assault-early-next-year/ar-AA152n3C?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 12:19:49.529626+00:00



## Wagner Group Slams Police For Holding Deserter, Tells Cops to Fight Instead
 - [http://www.msn.com/en-us/news/world/wagner-group-slams-police-for-holding-deserter-tells-cops-to-fight-instead/ar-AA153fZE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/wagner-group-slams-police-for-holding-deserter-tells-cops-to-fight-instead/ar-AA153fZE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 12:19:49.521605+00:00



## The Hill’s Morning Report — Congress faces a funding time crunch
 - [http://www.msn.com/en-us/news/politics/the-hill-s-morning-report-congress-faces-a-funding-time-crunch/ar-AA153fUm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-hill-s-morning-report-congress-faces-a-funding-time-crunch/ar-AA153fUm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 12:19:49.512885+00:00



## New powerful A.I. bot creates angst among users: Are robots ready to take our jobs?
 - [http://www.msn.com/en-us/news/technology/new-powerful-a-i-bot-creates-angst-among-users-are-robots-ready-to-take-our-jobs/ar-AA153fNv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/new-powerful-a-i-bot-creates-angst-among-users-are-robots-ready-to-take-our-jobs/ar-AA153fNv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 12:19:49.503069+00:00



## Veronica Ryan wins Turner Prize for evocative sculptures
 - [http://www.msn.com/en-us/news/world/veronica-ryan-wins-turner-prize-for-evocative-sculptures/ar-AA1533j2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/veronica-ryan-wins-turner-prize-for-evocative-sculptures/ar-AA1533j2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 12:19:49.164215+00:00



## Former U.S. Border Patrol agent convicted of murdering 4 women in Texas
 - [http://www.msn.com/en-us/news/crime/former-u-s-border-patrol-agent-convicted-of-murdering-4-women-in-texas/ar-AA1533rb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/former-u-s-border-patrol-agent-convicted-of-murdering-4-women-in-texas/ar-AA1533rb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 12:19:48.826063+00:00



## Georgia ends 2022 midterm cycle that challenged and confounded Washington: ANALYSIS
 - [http://www.msn.com/en-us/news/politics/georgia-ends-2022-midterm-cycle-that-challenged-and-confounded-washington-analysis/ar-AA151BsP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/georgia-ends-2022-midterm-cycle-that-challenged-and-confounded-washington-analysis/ar-AA151BsP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 12:19:48.186921+00:00



## Why House Republicans Want to Try to Impeach DHS Secretary Mayorkas
 - [http://www.msn.com/en-us/news/politics/why-house-republicans-want-to-try-to-impeach-dhs-secretary-mayorkas/ar-AA153g7T?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/why-house-republicans-want-to-try-to-impeach-dhs-secretary-mayorkas/ar-AA153g7T?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 12:19:47.747557+00:00



## Biden to announce $36 billion in relief for major pension fund to avoid benefit cuts
 - [http://www.msn.com/en-us/news/politics/biden-to-announce-36-billion-in-relief-for-major-pension-fund-to-avoid-benefit-cuts/ar-AA152zrq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-to-announce-36-billion-in-relief-for-major-pension-fund-to-avoid-benefit-cuts/ar-AA152zrq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 11:19:40.935841+00:00



## 'Wordle' Today #537 Hints, Tips and Answer for Thursday, December 8
 - [http://www.msn.com/en-us/news/technology/wordle-today-537-hints-tips-and-answer-for-thursday-december-8/ar-AA152Hx6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/wordle-today-537-hints-tips-and-answer-for-thursday-december-8/ar-AA152Hx6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 11:19:40.923988+00:00



## House poised to pass bill protecting same-sex, interracial marriage
 - [http://www.msn.com/en-us/news/politics/house-poised-to-pass-bill-protecting-same-sex-interracial-marriage/ar-AA152F7g?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-poised-to-pass-bill-protecting-same-sex-interracial-marriage/ar-AA152F7g?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 11:19:40.906076+00:00



## Wikipedia founder Jimmy Wales told Elon Musk it is 'not for sale' after the Twitter owned accused the encyclopaedia of having a left-wing bias
 - [http://www.msn.com/en-us/news/technology/wikipedia-founder-jimmy-wales-told-elon-musk-it-is-not-for-sale-after-the-twitter-owned-accused-the-encyclopaedia-of-having-a-left-wing-bias/ar-AA1532Mi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/wikipedia-founder-jimmy-wales-told-elon-musk-it-is-not-for-sale-after-the-twitter-owned-accused-the-encyclopaedia-of-having-a-left-wing-bias/ar-AA1532Mi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 11:19:40.889157+00:00



## WHO: COVID disruption resulted in 63,000 more malaria deaths
 - [http://www.msn.com/en-us/health/health-news/who-covid-disruption-resulted-in-63-000-more-malaria-deaths/ar-AA1530sq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/health-news/who-covid-disruption-resulted-in-63-000-more-malaria-deaths/ar-AA1530sq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 11:19:40.872309+00:00



## Xiaomi's Rival to the iPhone 14 Is Set To Launch This Sunday
 - [http://www.msn.com/en-us/news/technology/xiaomi-s-rival-to-the-iphone-14-is-set-to-launch-this-sunday/ar-AA152BDg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/xiaomi-s-rival-to-the-iphone-14-is-set-to-launch-this-sunday/ar-AA152BDg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 10:19:37.303648+00:00



## Almost Everyone Is Becoming About a Year Younger in South Korea
 - [http://www.msn.com/en-us/news/world/almost-everyone-is-becoming-about-a-year-younger-in-south-korea/ar-AA152LG6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/almost-everyone-is-becoming-about-a-year-younger-in-south-korea/ar-AA152LG6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 10:19:37.295434+00:00



## Trudeau’s lone Chinese Canadian minister has a tough job ahead of her
 - [http://www.msn.com/en-us/news/world/trudeau-s-lone-chinese-canadian-minister-has-a-tough-job-ahead-of-her/ar-AA152Et4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/trudeau-s-lone-chinese-canadian-minister-has-a-tough-job-ahead-of-her/ar-AA152Et4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 10:19:37.287129+00:00



## Anderson Lee Aldrich Opened Fire Immediately and Was Awake for Days—Affidavit
 - [http://www.msn.com/en-us/news/crime/anderson-lee-aldrich-opened-fire-immediately-and-was-awake-for-days-affidavit/ar-AA152EBw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/anderson-lee-aldrich-opened-fire-immediately-and-was-awake-for-days-affidavit/ar-AA152EBw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 10:19:37.278928+00:00



## Ex-Wirecard boss on trial in fraud case that shamed Germany
 - [http://www.msn.com/en-us/news/world/ex-wirecard-boss-on-trial-in-fraud-case-that-shamed-germany/ar-AA152LHC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ex-wirecard-boss-on-trial-in-fraud-case-that-shamed-germany/ar-AA152LHC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 10:19:37.271044+00:00



## The Ruse That Could Dupe Putin Into Another Crushing Ambush
 - [http://www.msn.com/en-us/news/world/the-ruse-that-could-dupe-putin-into-another-crushing-ambush/ar-AA152msT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-ruse-that-could-dupe-putin-into-another-crushing-ambush/ar-AA152msT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 10:19:37.263250+00:00



## Poll: DeSantis surges to 5-point lead over weakened Trump in 2024 primary matchup
 - [http://www.msn.com/en-us/news/politics/poll-desantis-surges-to-5-point-lead-over-weakened-trump-in-2024-primary-matchup/ar-AA152mAU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/poll-desantis-surges-to-5-point-lead-over-weakened-trump-in-2024-primary-matchup/ar-AA152mAU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 10:19:37.254849+00:00



## Karine Jean-Pierre ridiculed for claiming ‘there was suppression’ in GA election: ‘Conspiracy theory much?’
 - [http://www.msn.com/en-us/news/politics/karine-jean-pierre-ridiculed-for-claiming-there-was-suppression-in-ga-election-conspiracy-theory-much/ar-AA152LQi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/karine-jean-pierre-ridiculed-for-claiming-there-was-suppression-in-ga-election-conspiracy-theory-much/ar-AA152LQi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 10:19:37.246185+00:00



## Russian spy is charged with fraud and money laundering for purchasing two Beverly Hills condos
 - [http://www.msn.com/en-us/news/politics/russian-spy-is-charged-with-fraud-and-money-laundering-for-purchasing-two-beverly-hills-condos/ar-AA152J2B?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/russian-spy-is-charged-with-fraud-and-money-laundering-for-purchasing-two-beverly-hills-condos/ar-AA152J2B?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 09:19:57.071765+00:00



## Harry and Meghan renew clash with British royals and media in much-anticipated Netflix series
 - [http://www.msn.com/en-us/news/world/harry-and-meghan-renew-clash-with-british-royals-and-media-in-much-anticipated-netflix-series/ar-AA152DvU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/harry-and-meghan-renew-clash-with-british-royals-and-media-in-much-anticipated-netflix-series/ar-AA152DvU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 09:19:57.050169+00:00



## Be fearless in the face of bullying, thanks to this four-legged mentor
 - [http://www.msn.com/en-us/news/us/be-fearless-in-the-face-of-bullying-thanks-to-this-four-legged-mentor/ar-AA152BoK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/be-fearless-in-the-face-of-bullying-thanks-to-this-four-legged-mentor/ar-AA152BoK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 09:19:57.039752+00:00



## Kirk Cameron speaks out after faith-based book 'banned': Diversity should include Christianity
 - [http://www.msn.com/en-us/news/us/kirk-cameron-speaks-out-after-faith-based-book-banned-diversity-should-include-christianity/ar-AA152pqj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/kirk-cameron-speaks-out-after-faith-based-book-banned-diversity-should-include-christianity/ar-AA152pqj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 09:19:57.030138+00:00



## China Reverses COVID Propaganda After Years of Dire Warnings
 - [http://www.msn.com/en-us/news/world/china-reverses-covid-propaganda-after-years-of-dire-warnings/ar-AA152lYr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-reverses-covid-propaganda-after-years-of-dire-warnings/ar-AA152lYr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 08:48:41.372921+00:00



## UK royals brace as Harry-Meghan doc promises 'full truth'
 - [http://www.msn.com/en-us/news/world/uk-royals-brace-as-harry-meghan-doc-promises-full-truth/ar-AA152PJi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/uk-royals-brace-as-harry-meghan-doc-promises-full-truth/ar-AA152PJi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 08:48:41.362347+00:00



## Illegal immigrants 11 times more likely to be electronically tracked than jailed under Biden
 - [http://www.msn.com/en-us/news/us/illegal-immigrants-11-times-more-likely-to-be-electronically-tracked-than-jailed-under-biden/ar-AA152PTK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/illegal-immigrants-11-times-more-likely-to-be-electronically-tracked-than-jailed-under-biden/ar-AA152PTK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 08:36:00.433198+00:00



## Herschel Walker, thrown for a loss that also hurts Trump and Senate Republicans
 - [http://www.msn.com/en-us/news/politics/herschel-walker-thrown-for-a-loss-that-also-hurts-trump-and-senate-republicans/ar-AA152wl6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/herschel-walker-thrown-for-a-loss-that-also-hurts-trump-and-senate-republicans/ar-AA152wl6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 08:36:00.425521+00:00



## Harry and Meghan renew clash with British royals in much-anticipated Netflix series
 - [http://www.msn.com/en-us/news/world/harry-and-meghan-renew-clash-with-british-royals-in-much-anticipated-netflix-series/ar-AA152DvU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/harry-and-meghan-renew-clash-with-british-royals-in-much-anticipated-netflix-series/ar-AA152DvU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 08:36:00.417482+00:00



## UK royals brace themselves for Harry and Meghan documentary
 - [http://www.msn.com/en-us/news/world/uk-royals-brace-themselves-for-harry-and-meghan-documentary/ar-AA152PJi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/uk-royals-brace-themselves-for-harry-and-meghan-documentary/ar-AA152PJi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 08:36:00.409907+00:00



## Elon Musk says some of the 'most important' Twitter data was 'deleted' or 'hidden' from former boss
 - [http://www.msn.com/en-us/news/politics/elon-musk-says-some-of-the-most-important-twitter-data-was-deleted-or-hidden-from-former-boss/ar-AA152cBC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/elon-musk-says-some-of-the-most-important-twitter-data-was-deleted-or-hidden-from-former-boss/ar-AA152cBC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 07:35:57.487812+00:00



## 'Stay tuned': House GOP hints at potential legal action against ex-Twitter lawyer who suppressed Hunter story
 - [http://www.msn.com/en-us/news/politics/stay-tuned-house-gop-hints-at-potential-legal-action-against-ex-twitter-lawyer-who-suppressed-hunter-story/ar-AA152cCU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/stay-tuned-house-gop-hints-at-potential-legal-action-against-ex-twitter-lawyer-who-suppressed-hunter-story/ar-AA152cCU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 07:35:57.477235+00:00



## The west Belfast man executed 100 years ago
 - [http://www.msn.com/en-us/news/world/the-west-belfast-man-executed-100-years-ago/ar-AA152lzT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-west-belfast-man-executed-100-years-ago/ar-AA152lzT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 07:35:57.470160+00:00



## Scrutiny of Ukraine church draws praise, fear of overreach
 - [http://www.msn.com/en-us/news/world/scrutiny-of-ukraine-church-draws-praise-fear-of-overreach/ar-AA152D7h?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/scrutiny-of-ukraine-church-draws-praise-fear-of-overreach/ar-AA152D7h?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 07:35:57.461963+00:00



## Pennsylvania panel to vote on proposal defining sex, race
 - [http://www.msn.com/en-us/news/us/pennsylvania-panel-to-vote-on-proposal-defining-sex-race/ar-AA152ocS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/pennsylvania-panel-to-vote-on-proposal-defining-sex-race/ar-AA152ocS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 06:48:35.663878+00:00



## Chipped off: Lawmakers take $186M in donations from business interests reliant on Chinese chips
 - [http://www.msn.com/en-us/news/politics/chipped-off-lawmakers-take-186m-in-donations-from-business-interests-reliant-on-chinese-chips/ar-AA152emS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/chipped-off-lawmakers-take-186m-in-donations-from-business-interests-reliant-on-chinese-chips/ar-AA152emS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 06:35:56.514372+00:00



## California Woman, 29, Went Missing in Mexico After Last Seen Walking Her Dog
 - [http://www.msn.com/en-us/news/us/california-woman-29-went-missing-in-mexico-after-last-seen-walking-her-dog/ar-AA152jD9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/california-woman-29-went-missing-in-mexico-after-last-seen-walking-her-dog/ar-AA152jD9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 06:35:56.506160+00:00



## ChatGPT's Writing Capabilities Stun, But Humans Are Still Essential (For Now)
 - [http://www.msn.com/en-us/news/technology/chatgpt-s-writing-capabilities-stun-but-humans-are-still-essential-for-now/ar-AA151Jtr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/chatgpt-s-writing-capabilities-stun-but-humans-are-still-essential-for-now/ar-AA151Jtr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 06:35:56.498642+00:00



## Marijuana now legal in Missouri, but you can't buy it yet
 - [http://www.msn.com/en-us/news/us/marijuana-now-legal-in-missouri-but-you-can-t-buy-it-yet/ar-AA151ZFW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/marijuana-now-legal-in-missouri-but-you-can-t-buy-it-yet/ar-AA151ZFW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 06:35:56.490385+00:00



## New York Times journalists, other workers on 24-hour strike
 - [http://www.msn.com/en-us/news/us/new-york-times-journalists-other-workers-on-24-hour-strike/ar-AA15217w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/new-york-times-journalists-other-workers-on-24-hour-strike/ar-AA15217w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 05:48:35.017941+00:00



## Sandy Hook Survivor 'Saw Things No Child, No Person' Should Ever See
 - [http://www.msn.com/en-us/news/us/sandy-hook-survivor-saw-things-no-child-no-person-should-ever-see/ar-AA152pWa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/sandy-hook-survivor-saw-things-no-child-no-person-should-ever-see/ar-AA152pWa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 05:48:33.551363+00:00



## TUCKER CARLSON: This is the reality about Ukraine's Zelenskyy
 - [http://www.msn.com/en-us/news/world/tucker-carlson-this-is-the-reality-about-ukraine-s-zelenskyy/ar-AA152pZO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/tucker-carlson-this-is-the-reality-about-ukraine-s-zelenskyy/ar-AA152pZO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 05:48:33.542013+00:00



## Latinas in the U.S. still face striking wage gap
 - [http://www.msn.com/en-us/news/us/latinas-in-the-u-s-still-face-striking-wage-gap/ar-AA152suR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/latinas-in-the-u-s-still-face-striking-wage-gap/ar-AA152suR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 05:48:33.534117+00:00



## New York Times braces for 24-hour newsroom strike
 - [http://www.msn.com/en-us/news/us/new-york-times-braces-for-24-hour-newsroom-strike/ar-AA15217w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/new-york-times-braces-for-24-hour-newsroom-strike/ar-AA15217w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 05:48:33.524680+00:00



## Authorities blame 'human error' for hiring ex-trooper accused of 'catfishing' teen and killing her family
 - [http://www.msn.com/en-us/news/us/authorities-blame-human-error-for-hiring-ex-trooper-accused-of-catfishing-teen-and-killing-her-family/ar-AA152juw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/authorities-blame-human-error-for-hiring-ex-trooper-accused-of-catfishing-teen-and-killing-her-family/ar-AA152juw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 05:48:33.515873+00:00



## Australia wants Indonesia to monitor released bombmaker
 - [http://www.msn.com/en-us/news/world/australia-wants-indonesia-to-monitor-released-bombmaker/ar-AA152jxn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/australia-wants-indonesia-to-monitor-released-bombmaker/ar-AA152jxn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 05:48:33.507734+00:00



## Todd and Julie Chrisley speak out on their adopted daughter's custody
 - [http://www.msn.com/en-us/news/crime/todd-and-julie-chrisley-speak-out-on-their-adopted-daughter-s-custody/ar-AA15274Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/todd-and-julie-chrisley-speak-out-on-their-adopted-daughter-s-custody/ar-AA15274Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 04:48:33.529193+00:00



## Florida GOP state representative indicted in fraud involving COVID-19 relief funds
 - [http://www.msn.com/en-us/news/us/florida-gop-state-representative-indicted-in-fraud-involving-covid-19-relief-funds/ar-AA152iF6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/florida-gop-state-representative-indicted-in-fraud-involving-covid-19-relief-funds/ar-AA152iF6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 04:48:33.520602+00:00



## Sean Hannity Makes Wild Assumptions About Dems After GOP Senate Fail
 - [http://www.msn.com/en-us/news/politics/sean-hannity-makes-wild-assumptions-about-dems-after-gop-senate-fail/ar-AA152dqg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/sean-hannity-makes-wild-assumptions-about-dems-after-gop-senate-fail/ar-AA152dqg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 04:48:33.513000+00:00



## Off-duty FBI agent fatally appears to shoot person at DC's Metro Center station
 - [http://www.msn.com/en-us/news/crime/off-duty-fbi-agent-fatally-appears-to-shoot-person-at-dc-s-metro-center-station/ar-AA151OdJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/off-duty-fbi-agent-fatally-appears-to-shoot-person-at-dc-s-metro-center-station/ar-AA151OdJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 04:48:33.505580+00:00



## Officials talk biodiversity as drought stunts Kenya wildlife
 - [http://www.msn.com/en-us/news/world/officials-talk-biodiversity-as-drought-stunts-kenya-wildlife/ar-AA1521ud?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/officials-talk-biodiversity-as-drought-stunts-kenya-wildlife/ar-AA1521ud?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 04:48:33.318456+00:00



## DeSantis to Meet GOP Donors in Miami After Re-election Blowout
 - [http://www.msn.com/en-us/news/politics/desantis-to-meet-gop-donors-in-miami-after-re-election-blowout/ar-AA151YoK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/desantis-to-meet-gop-donors-in-miami-after-re-election-blowout/ar-AA151YoK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 03:48:31.092695+00:00



## Polygamous cult leader had multiple wives who were minors, FBI says
 - [http://www.msn.com/en-us/news/crime/polygamous-cult-leader-had-multiple-wives-who-were-minors-fbi-says/ar-AA151Wys?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/polygamous-cult-leader-had-multiple-wives-who-were-minors-fbi-says/ar-AA151Wys?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 03:48:31.085312+00:00



## South Korea's truth commission to probe foreign adoptions
 - [http://www.msn.com/en-us/news/world/south-korea-s-truth-commission-to-probe-foreign-adoptions/ar-AA15211V?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/south-korea-s-truth-commission-to-probe-foreign-adoptions/ar-AA15211V?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 03:48:31.076804+00:00



## Jan. 6 panel eyeing Dec. 21 to release final report, chairman says
 - [http://www.msn.com/en-us/news/politics/jan-6-panel-eyeing-dec-21-to-release-final-report-chairman-says/ar-AA152fS1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jan-6-panel-eyeing-dec-21-to-release-final-report-chairman-says/ar-AA152fS1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 03:48:31.068915+00:00



## Investigators untangling the Idaho student slayings face a ‘daunting task’: Parsing the DNA
 - [http://www.msn.com/en-us/news/crime/investigators-untangling-the-idaho-student-slayings-face-a-daunting-task-parsing-the-dna/ar-AA151Uhg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/investigators-untangling-the-idaho-student-slayings-face-a-daunting-task-parsing-the-dna/ar-AA151Uhg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 03:48:31.061517+00:00



## New York AG asks judge to reject Trump lawsuit seeking emergency protections
 - [http://www.msn.com/en-us/news/politics/new-york-ag-asks-judge-to-reject-trump-lawsuit-seeking-emergency-protections/ar-AA1528Vx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/new-york-ag-asks-judge-to-reject-trump-lawsuit-seeking-emergency-protections/ar-AA1528Vx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 03:48:30.873510+00:00



## Jan. 6 committee report will be released Dec. 21, Thompson says
 - [http://www.msn.com/en-us/news/politics/jan-6-committee-report-will-be-released-dec-21-thompson-says/ar-AA151Tmm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jan-6-committee-report-will-be-released-dec-21-thompson-says/ar-AA151Tmm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 02:48:25.806603+00:00



## JESSE WATTERS: You can sleep on San Francisco streets, but you can't sleep in your office
 - [http://www.msn.com/en-us/news/us/jesse-watters-you-can-sleep-on-san-francisco-streets-but-you-can-t-sleep-in-your-office/ar-AA1525So?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jesse-watters-you-can-sleep-on-san-francisco-streets-but-you-can-t-sleep-in-your-office/ar-AA1525So?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 02:48:25.782362+00:00



## Idaho murder update: Police ask for community's help in tracking down vehicle of interest
 - [http://www.msn.com/en-us/news/crime/idaho-murder-update-police-ask-for-community-s-help-in-tracking-down-vehicle-of-interest/ar-AA1525XP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/idaho-murder-update-police-ask-for-community-s-help-in-tracking-down-vehicle-of-interest/ar-AA1525XP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 02:48:25.773532+00:00



## Dog Rescued by Volunteer Fighters After Swimming Across New York's Hudson River
 - [http://www.msn.com/en-us/news/us/dog-rescued-by-volunteer-fighters-after-swimming-across-new-york-s-hudson-river/ar-AA151VXi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/dog-rescued-by-volunteer-fighters-after-swimming-across-new-york-s-hudson-river/ar-AA151VXi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 02:48:25.765687+00:00



## Brutal GodSlap #2 Out Now From New Publishing House Bad Egg
 - [http://www.msn.com/en-us/news/technology/brutal-godslap-2-out-now-from-new-publishing-house-bad-egg/ar-AA1520Er?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/brutal-godslap-2-out-now-from-new-publishing-house-bad-egg/ar-AA1520Er?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 02:48:25.757539+00:00



## 'Don't Say Gay' Florida lawmaker indicted for wire fraud, money laundering
 - [http://www.msn.com/en-us/news/us/don-t-say-gay-florida-lawmaker-indicted-for-wire-fraud-money-laundering/ar-AA151WcX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/don-t-say-gay-florida-lawmaker-indicted-for-wire-fraud-money-laundering/ar-AA151WcX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 02:48:25.750421+00:00



## Rep. Adam Schiff said 'facts support' indicting Trump and that the January 6 panel will make its evidence public so the GOP can't 'cherry-pick' and 'mislead the country'
 - [http://www.msn.com/en-us/news/politics/rep-adam-schiff-said-facts-support-indicting-trump-and-that-the-january-6-panel-will-make-its-evidence-public-so-the-gop-can-t-cherry-pick-and-mislead-the-country/ar-AA152flD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-adam-schiff-said-facts-support-indicting-trump-and-that-the-january-6-panel-will-make-its-evidence-public-so-the-gop-can-t-cherry-pick-and-mislead-the-country/ar-AA152flD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 02:48:25.743150+00:00



## Peru's president ousted by Congress in political crisis
 - [http://www.msn.com/en-us/news/world/peru-s-president-ousted-by-congress-in-political-crisis/ar-AA151vy0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/peru-s-president-ousted-by-congress-in-political-crisis/ar-AA151vy0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 02:48:25.735932+00:00



## North Carolina substation attack raises security concerns for U.S. electric grid
 - [http://www.msn.com/en-us/news/us/north-carolina-substation-attack-raises-security-concerns-for-u-s-electric-grid/ar-AA1522iT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/north-carolina-substation-attack-raises-security-concerns-for-u-s-electric-grid/ar-AA1522iT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 02:48:25.548635+00:00



## New York AG says sexual harassment claims against chief of staff were substantiated
 - [http://www.msn.com/en-us/news/politics/new-york-ag-says-sexual-harassment-claims-against-chief-of-staff-were-substantiated/ar-AA151R2F?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/new-york-ag-says-sexual-harassment-claims-against-chief-of-staff-were-substantiated/ar-AA151R2F?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 01:48:23.626877+00:00



## Gen Z Is Ready to Torpedo Social Media’s Echo Chambers
 - [http://www.msn.com/en-us/news/technology/gen-z-is-ready-to-torpedo-social-media-s-echo-chambers/ar-AA1525tw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/gen-z-is-ready-to-torpedo-social-media-s-echo-chambers/ar-AA1525tw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 01:48:23.619533+00:00



## Sen. Cotton praised for annihilating woke Kroger CEO seeking GOP help against Dems: ‘Go woke, go broke'
 - [http://www.msn.com/en-us/news/politics/sen-cotton-praised-for-annihilating-woke-kroger-ceo-seeking-gop-help-against-dems-go-woke-go-broke/ar-AA151Oli?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/sen-cotton-praised-for-annihilating-woke-kroger-ceo-seeking-gop-help-against-dems-go-woke-go-broke/ar-AA151Oli?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 01:48:23.612206+00:00



## Wordle Starter Words That Almost Guarantee a Winning Streak
 - [http://www.msn.com/en-us/news/technology/wordle-starter-words-that-almost-guarantee-a-winning-streak/ar-AA146EZt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/wordle-starter-words-that-almost-guarantee-a-winning-streak/ar-AA146EZt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 01:48:23.604562+00:00



## Virginia police blame 'human error' in hiring of man who later killed 3 in California
 - [http://www.msn.com/en-us/news/us/virginia-police-blame-human-error-in-hiring-of-man-who-later-killed-3-in-california/ar-AA15282f?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/virginia-police-blame-human-error-in-hiring-of-man-who-later-killed-3-in-california/ar-AA15282f?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 01:48:23.595510+00:00



## Fauci criticizes 'extreme' ideological divide that has led to disproportionate Covid deaths
 - [http://www.msn.com/en-us/news/politics/fauci-criticizes-extreme-ideological-divide-that-has-led-to-disproportionate-covid-deaths/ar-AA150sn8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/fauci-criticizes-extreme-ideological-divide-that-has-led-to-disproportionate-covid-deaths/ar-AA150sn8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 01:48:23.588077+00:00



## Biden at gun violence vigil: Shared grief and another call to action
 - [http://www.msn.com/en-us/news/us/biden-at-gun-violence-vigil-shared-grief-and-another-call-to-action/ar-AA1525Ig?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/biden-at-gun-violence-vigil-shared-grief-and-another-call-to-action/ar-AA1525Ig?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 01:48:23.580802+00:00



## Texas Gov. Greg Abbott bans TikTok on state devices
 - [http://www.msn.com/en-us/news/technology/texas-gov-greg-abbott-bans-tiktok-on-state-devices/ar-AA151ImB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/texas-gov-greg-abbott-bans-tiktok-on-state-devices/ar-AA151ImB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 01:48:23.392718+00:00



## 1st US floating offshore wind auction nets $757M in bids
 - [http://www.msn.com/en-us/news/us/1st-us-floating-offshore-wind-auction-nets-757m-in-bids/ar-AA151XyK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/1st-us-floating-offshore-wind-auction-nets-757m-in-bids/ar-AA151XyK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 00:48:22.957258+00:00



## ‘Doctors fitted a contraceptive coil without my consent’
 - [http://www.msn.com/en-us/news/world/doctors-fitted-a-contraceptive-coil-without-my-consent/ar-AA1527w9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/doctors-fitted-a-contraceptive-coil-without-my-consent/ar-AA1527w9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 00:48:22.931276+00:00



## Inside Heinrich XIII's plot to restore Germany's imperial throne
 - [http://www.msn.com/en-us/news/world/inside-heinrich-xiii-s-plot-to-restore-germany-s-imperial-throne/ar-AA151QQ4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/inside-heinrich-xiii-s-plot-to-restore-germany-s-imperial-throne/ar-AA151QQ4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 00:48:22.923427+00:00



## Cops Eye White Hyundai in Hunt for Idaho Students’ Killer
 - [http://www.msn.com/en-us/news/crime/cops-eye-white-hyundai-in-hunt-for-idaho-students-killer/ar-AA151SU2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/cops-eye-white-hyundai-in-hunt-for-idaho-students-killer/ar-AA151SU2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 00:48:22.916151+00:00



## Georgia loss piles more pressure on Trump amid bad month
 - [http://www.msn.com/en-us/news/politics/georgia-loss-piles-more-pressure-on-trump-amid-bad-month/ar-AA151Vev?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/georgia-loss-piles-more-pressure-on-trump-amid-bad-month/ar-AA151Vev?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 00:48:22.908935+00:00



## Energy & Environment — Manchin charts next steps on permitting reform
 - [http://www.msn.com/en-us/news/politics/energy-environment-manchin-charts-next-steps-on-permitting-reform/ar-AA152a7u?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/energy-environment-manchin-charts-next-steps-on-permitting-reform/ar-AA152a7u?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 00:48:22.901770+00:00



## Ukrainian Nobel Peace Prize winner calls for war crimes tribunal for Putin and Russian military leaders
 - [http://www.msn.com/en-us/news/world/ukrainian-nobel-peace-prize-winner-calls-for-war-crimes-tribunal-for-putin-and-russian-military-leaders/ar-AA151T3q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukrainian-nobel-peace-prize-winner-calls-for-war-crimes-tribunal-for-putin-and-russian-military-leaders/ar-AA151T3q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 00:48:22.894692+00:00



## 1st US floating offshore wind auction nets $757M off Calif
 - [http://www.msn.com/en-us/news/us/1st-us-floating-offshore-wind-auction-nets-757m-off-calif/ar-AA151XyK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/1st-us-floating-offshore-wind-auction-nets-757m-off-calif/ar-AA151XyK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 00:48:22.887486+00:00



## Peru swore in the country's first female leader after the now-ousted president's attempted coup
 - [http://www.msn.com/en-us/news/world/peru-swore-in-the-country-s-first-female-leader-after-the-now-ousted-president-s-attempted-coup/ar-AA151LR5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/peru-swore-in-the-country-s-first-female-leader-after-the-now-ousted-president-s-attempted-coup/ar-AA151LR5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2022-12-08 00:48:22.699534+00:00




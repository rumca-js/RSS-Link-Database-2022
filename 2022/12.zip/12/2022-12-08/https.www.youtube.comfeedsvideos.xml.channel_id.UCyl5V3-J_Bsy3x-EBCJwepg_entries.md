# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Apocalypse Brothers: A Bunker Remodeling Show
 - [https://www.youtube.com/watch?v=JzT54BwHGaY](https://www.youtube.com/watch?v=JzT54BwHGaY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-12-09 00:00:00+00:00

The Apocalypse Brothers are here to remodel your survivor bunker. Let's demo that clunker of a bunker and turn it into a bomb shelter!

Go to preparewithbee.com and get a special deal on your emergency survival food from My Patriot Supply. And no, this isn't satire.


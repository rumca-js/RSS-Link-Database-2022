# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Dune Survival MMO!🎮 Dark Tower Series Adaptation!🗼 New Murderbot🤖
 - [https://www.youtube.com/watch?v=9NSgN3MXIKk](https://www.youtube.com/watch?v=9NSgN3MXIKk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-12-09 00:00:00+00:00

Let's jump into the FANTASY NEWS! 
[Sponsored by Ridge] Get the best offer from now until December 22nd with my link https://ridge.com/GREENE


Kickstarter: https://tinyurl.com/TLTbookmark 


New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene


Merch: https://www.designbyhumans.com/shop/FantasyNews/ 


Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p


Equipment: 
Camera: https://amzn.to/3siqgHv  
Lens: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  


P.O. Box: PO Box 7874 Henrico, VA 23231


NEWS: 


00:00 intro


00:14 Dark Tower Adaptation: https://deadline.com/2022/12/mike-flanagan-amp-trevor-macy-the-dark-tower-series-movies-netflix-exit-midnight-club-canceled-amazon-intrepid-1235191018/ 


04:10 New Murderbot: https://twitter.com/TorDotComPub/status/1600867806798413826 


05:01 Dune Awkening: https://store.steampowered.com/app/1172710/Dune_Awakening/ 


05:57 New Tolkien: https://www.waterstones.com/book/the-battle-of-maldon/j-r-r-tolkien/peter-grybauskas/9780008465827 


07:33 New LotR cast: https://deadline.com/2022/12/lord-of-the-rings-the-rings-of-power-adds-season-2-cast-1235191374/ 


07:49 Shadow and Bone Release date: https://twitter.com/DiscussingFilm/status/1600885207019970561?s=20&t=cdwQtmHr-lMi5IER1IOL-g 


07:58 Stargate Pitches wanted: https://www.gateworld.net/news/2022/12/report-amazon-is-soliciting-pitches-for-new-stargate/ 


09:21 Elden Ring Arena: https://www.ign.com/articles/elden-rings-colosseum-dlc-is-real-free-and-releasing-tomorrow

## Fangs of Ego - Berserk Vol. 23 & Vol. 24 [Part 1]
 - [https://www.youtube.com/watch?v=CIPDUuWV0Us](https://www.youtube.com/watch?v=CIPDUuWV0Us)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-12-08 00:00:00+00:00

We're back baby!! Let's jump back into #Berserk 
Check out today's sponsor Campfire: https://bit.ly/ALIEN-INVASION 

This video covers Berserk Deluxe Edition 8 - Vol. 23 & Vol. 24 [Part 1], which includes the chapters:
"Winter Journey 1-2", "Scattered Time", "Fangs of Ego", "Wilderness Reunion", "The War Demons", "Banner of the Flying Sword", "Wings of Light and Darkness", "The Night of Falling Stars" and "Like a Baby" as well as "Trolls", "The Witch", "Mansion of the Spirit Tree 1-2", and "Astral World". 

Support the kickstarter: https://www.kickstarter.com/projects/wraithmarked/the-lawful-times-limited-edition-bookmark 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lens: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


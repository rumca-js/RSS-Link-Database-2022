# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## BREAKING: Felony Arrest Warrant Issued For Biden Official Sam Brinton For Another Alleged Theft, Report Says
 - [https://www.dailywire.com/news/breaking-felony-arrest-warrant-issued-for-biden-official-sam-brinton-for-another-alleged-theft-report-says](https://www.dailywire.com/news/breaking-felony-arrest-warrant-issued-for-biden-official-sam-brinton-for-another-alleged-theft-report-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 23:53:16+00:00

An arrest warrant has been issued for controversial Biden administration official Sam Brinton in connection with a second alleged theft at an airport in Las Vegas. Brinton, who works for the Department of Energy, was already placed on leave after he allegedly stole a woman&#8217;s luggage at Minneapolis-St. Paul (MSP) International Airport late last month. ...

## Satanic Temple Display Near Nativity Scene, Jewish Menorah In Illinois State Capitol Building
 - [https://www.dailywire.com/news/satanic-temple-display-near-nativity-scene-jewish-menorah-in-illinois-state-capitol-building](https://www.dailywire.com/news/satanic-temple-display-near-nativity-scene-jewish-menorah-in-illinois-state-capitol-building)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 22:19:02+00:00

Inside the Illinois State Capitol sits a display of several religious exhibits for the holiday season, which includes a Jewish menorah, the Christian nativity scene, and the &#8220;Serpent of Genesis&#8221; from the Satanic Temple, as reported by local radio media. Consisting of a leather-bound copy of astronomer Nicolaus Copernicus&#8217; &#8220;De Revolutionibus Orbium Coelestium&#8221; — which ...

## Twitter’s Underhanded Actions Targeting ‘Libs Of TikTok’ Revealed In New ‘Twitter Files’ Release
 - [https://www.dailywire.com/news/twitters-underhanded-actions-targeting-libs-of-tiktok-revealed-in-new-twitter-files-release](https://www.dailywire.com/news/twitters-underhanded-actions-targeting-libs-of-tiktok-revealed-in-new-twitter-files-release)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 21:37:49+00:00

The latest release of the &#8220;Twitter Files&#8221; Thursday evening revealed that leftists at the highest level of the company, who have all since been fired or been forced to resign, targeted one of the most popular right-wing accounts on the platform with repeated suspensions despite the fact that they secretly admitted that she did not ...

## BREAKING: Twitter Releases Documents Showing It Took Secret Actions Against Conservatives
 - [https://www.dailywire.com/news/breaking-twitter-releases-documents-showing-it-took-secret-actions-against-conservatives](https://www.dailywire.com/news/breaking-twitter-releases-documents-showing-it-took-secret-actions-against-conservatives)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 20:13:23+00:00

The second installment of the so-called &#8220;Twitter Files&#8221; was released Thursday evening after the company turned over documents to a journalist who then started to publish the findings on the platform. Musk released internal company communications through journalist Matt Taibbi on Friday about the company’s censorship of the New York Post’s Hunter Biden laptop story ...

## Famed ‘TikTok Surgeon’ Faces Intense Backlash From Transgender Community After Allegedly Maimed Patient Goes Viral
 - [https://www.dailywire.com/news/famed-tiktok-surgeon-faces-intense-backlash-from-transgender-community-after-allegedly-maimed-patient-goes-viral](https://www.dailywire.com/news/famed-tiktok-surgeon-faces-intense-backlash-from-transgender-community-after-allegedly-maimed-patient-goes-viral)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 19:49:42+00:00

The transgender community has turned on a once revered surgeon specializing in sex change surgeries after a patient posted graphic photos of an allegedly botched operation. Dr. Sidhbh Gallagher, a Miami-based surgeon specializing in double mastectomy surgeries for transgender-identifying patients, has been heavily criticized for performing the elective surgery on minors. She has also earned ...

## Video Emerges Of Brittney Griner Being Swapped For Russian Terrorist; Critics Instantly Notice Problem
 - [https://www.dailywire.com/news/video-emerges-of-brittney-griner-being-swapped-for-russian-terrorist-critics-instantly-notice-problem](https://www.dailywire.com/news/video-emerges-of-brittney-griner-being-swapped-for-russian-terrorist-critics-instantly-notice-problem)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 19:34:03+00:00

Video emerged Thursday afternoon of Brittney Griner being swapped on a runway for convicted Russian terrorist Viktor Bout after Democrat President Joe Biden agreed to the trade. The video showed Griner, who is wearing a red jacket, walking across the tarmac with three men while Bout walked toward her with a man standing next to ...

## Potential Iowa Serial Killer Still Shrouded In Mystery After Police Excavation Turns Up Empty
 - [https://www.dailywire.com/news/potential-iowa-serial-killer-still-shrouded-in-mystery-after-police-excavation-turns-up-empty](https://www.dailywire.com/news/potential-iowa-serial-killer-still-shrouded-in-mystery-after-police-excavation-turns-up-empty)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 19:01:08+00:00

After a woman claimed to be the daughter of a serial killer in a recent interview, a search of the supposed location of buried remains has turned up nothing. Federal, state, and local authorities did not find any evidence or remains after scouring the earth for several days in Thurman, Iowa, a small town just ...

## FedEx Driver Admits To Strangling 7-Year-Old Girl After Hitting Her With Van
 - [https://www.dailywire.com/news/fedex-driver-admits-to-strangling-7-year-old-girl-after-hitting-her-with-van](https://www.dailywire.com/news/fedex-driver-admits-to-strangling-7-year-old-girl-after-hitting-her-with-van)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 18:55:53+00:00

A FedEx contract driver strangled a 7-year-old girl after hitting her with his van in Texas late last month, according to arrest warrant documents. Tanner Horner, a 31-year-old from Fort Worth, has been arrested and charged with capital murder of a person under 10 years old and aggravated kidnapping in the death of Athena Strand, ...

## Disabled Vet Congressman Torches Colleague For Putting American Flag In Trash Can
 - [https://www.dailywire.com/news/disabled-vet-congressman-torches-colleague-for-putting-american-flag-in-trash-can](https://www.dailywire.com/news/disabled-vet-congressman-torches-colleague-for-putting-american-flag-in-trash-can)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 18:45:51+00:00

Disabled veteran Congressman Brian Mast (R-FL) took issue with fellow Congresswoman Sheila Jackson Lee (D-TX) over the way she chose to transport her American flag while she was moving from one office to another. Mast, who lost both legs and his left index finger in 2010 when he stepped on an improvised explosive device (IED) while ...

## Top Democrat Senator Blasts Biden Over Releasing Terrorist For Griner: ‘Deeply Disturbing Decision’
 - [https://www.dailywire.com/news/top-democrat-senator-blasts-biden-over-releasing-terrorist-for-griner-deeply-disturbing-decision](https://www.dailywire.com/news/top-democrat-senator-blasts-biden-over-releasing-terrorist-for-griner-deeply-disturbing-decision)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 18:41:27+00:00

Sen. Bob Menendez (D-NJ), chairman of the Senate Foreign Relations Committee, slammed President Joe Biden Thursday for releasing notorious terrorist Viktor Bout in exchange for Brittney Griner. Griner, who has a criminal record in the U.S. stemming from a domestic violence incident several years ago, was arrested in Russia back in February on drug charges, ...

## 81-Year-Old Bernie Sanders Will Likely ‘Take Another Look’ At Presidential Run If Biden Opts Out, Top Adviser Says
 - [https://www.dailywire.com/news/81-year-old-bernie-sanders-will-likely-take-another-look-at-presidential-run-if-biden-opts-out-top-adviser-says](https://www.dailywire.com/news/81-year-old-bernie-sanders-will-likely-take-another-look-at-presidential-run-if-biden-opts-out-top-adviser-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 18:41:20+00:00

A top adviser for Sen. Bernie Sanders (I-VT) said he believes the 81-year-old democratic socialist will “take another look” at a presidential bid if President Joe Biden does not run for re-election. Faiz Shakir, who managed Sanders’ 2020 presidential campaign and now advises the senator, told CBS News on Thursday that he still thinks Biden ...

## Jennifer Lawrence Clarifies First Female Led-Action Hero Remarks Following Backlash
 - [https://www.dailywire.com/news/jennifer-lawrence-clarifies-first-female-led-action-hero-remarks-following-backlash](https://www.dailywire.com/news/jennifer-lawrence-clarifies-first-female-led-action-hero-remarks-following-backlash)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 18:32:57+00:00

Jennifer Lawrence clarified her earlier remarks when she falsely claimed to be the first female led-action hero in &#8220;Hunger Games&#8221; in 2012 following the backlash over her comments and said that &#8220;it came out wrong.&#8221; During an interview with the Hollywood Reporter on Thursday, the 32-year-old actress said when she said &#8220;nobody had ever put a ...

## Suspected Colorado Shooter Vowed To Become ‘Next Mass Killer’ Year Before Club Q Shooting: Report
 - [https://www.dailywire.com/news/suspected-colorado-shooter-vowed-to-become-next-mass-killer-year-before-club-q-shooting-report](https://www.dailywire.com/news/suspected-colorado-shooter-vowed-to-become-next-mass-killer-year-before-club-q-shooting-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 18:15:23+00:00

The 22-year-old suspect accused of killing five and wounding dozens of others at a gay nightclub in Colorado last month allegedly threatened to become the &#8220;next mass killer&#8221; a year before horrific murder spree, according to documents unsealed Thursday by a judge. Judge Robin Chittum unsealed a dropped bomb threat case reported by The Associated ...

## Ted Lieu Mocks GOP Congresswoman For Passionate Defense Of Traditional Marriage: ‘Tears Of Hate’
 - [https://www.dailywire.com/news/ted-lieu-mocks-gop-congresswoman-for-passionate-defense-of-traditional-marriage-tears-of-hate](https://www.dailywire.com/news/ted-lieu-mocks-gop-congresswoman-for-passionate-defense-of-traditional-marriage-tears-of-hate)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 17:55:39+00:00

Rep. Vicki Hartzler (R-MO) wept during a House floor speech as she pleaded with colleagues to stop the Respect for Marriage Act, with Democratic Rep. Ted Lieu (CA) referring to her emotional outburst as &#8220;tears of hate.&#8221; Lieu posted the searing response on Twitter following Hartzler’s speech on Thursday. &#8220;Want to see tears of hate?&#8221; ...

## Should You Move Your Family From A ‘Woke Cesspool’?
 - [https://www.dailywire.com/news/should-you-move-your-family-from-a-woke-cesspool](https://www.dailywire.com/news/should-you-move-your-family-from-a-woke-cesspool)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 17:54:50+00:00

All right, folks, I am going to answer a question from a DailyWire+ subscriber today — as I do every day on my show. Here’s the question from Loralee: “Hey, Candace, I&#8217;m a big fan. I would love your opinion. I&#8217;m about to retire from the NYPD and I&#8217;m leaving the woke cesspool that New ...

## ‘Harry & Meghan’ Doc Includes The Princess Diana Interview That Prince William Said Should Never Air Again
 - [https://www.dailywire.com/news/harry-meghan-doc-includes-the-princess-diana-interview-that-prince-william-said-should-never-air-again](https://www.dailywire.com/news/harry-meghan-doc-includes-the-princess-diana-interview-that-prince-william-said-should-never-air-again)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 17:47:08+00:00

Prince Harry and Meghan Markle&#8217;s Netflix documentary includes a clip from the infamous BBC &#8220;Panorama&#8221; interview that Prince William said should never air again. The two brothers appeared united on that front just 18 months ago, when both spoke out about the interview — which a BBC inquiry determined had been secured through deception — ...

## Thursday Afternoon Update: Biden Releases ‘Merchant Of Death,’ Nantucket Goes Topless, New York Times Goes On Strike
 - [https://www.dailywire.com/news/thursday-afternoon-update-biden-releases-merchant-of-death-nantucket-goes-topless-new-york-times-goes-on-strike](https://www.dailywire.com/news/thursday-afternoon-update-biden-releases-merchant-of-death-nantucket-goes-topless-new-york-times-goes-on-strike)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 17:27:38+00:00

This article is a companion piece to today’s Morning Wire Afternoon Update. To listen to the podcast version, click here. Griner Released In Exchange For Merchant Of Death WNBA star Brittney Griner was freed from Russian captivity Thursday in a prisoner exchange for notorious Russian arms dealer and international criminal Viktor Bout, known as the “Merchant ...

## Vanguard Backs Off From Climate Crusade. Al Gore Furious.
 - [https://www.dailywire.com/news/vanguard-backs-off-from-climate-crusade-al-gore-furious](https://www.dailywire.com/news/vanguard-backs-off-from-climate-crusade-al-gore-furious)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 17:16:39+00:00

Former Vice President Al Gore lambasted Vanguard following the company’s decision to sever ties with the Net Zero Asset Managers initiative on Wednesday. Companies joining the initiative must promise to move portfolio companies closer to eliminating net carbon emissions by 2050 or sooner. Vanguard opted to withdraw from the project in order to “provide the ...

## Backstreet Boys Member Nick Carter Being Sued For Alleged Sexual Assault
 - [https://www.dailywire.com/news/backstreet-boys-member-nick-carter-being-sued-for-alleged-sexual-assault](https://www.dailywire.com/news/backstreet-boys-member-nick-carter-being-sued-for-alleged-sexual-assault)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 17:10:15+00:00

&#8220;Backstreet Boys&#8221; member Nick Carter is being sued for an alleged 2001 sexual assault, with a source close to the singer calling the claims &#8220;categorically false.&#8221; In a press conference live-streamed on Facebook Thursday, the 39-year-old singer was accused of allegedly raping a 17-year-old girl more than two decades ago after the boy band&#8217;s concert ...

## Trans Activist Dylan Mulvaney Defends Tampax, Says It’s ‘Pure-Intentioned’ To Carry Tampons Around
 - [https://www.dailywire.com/news/trans-activist-dylan-mulvaney-defends-tampax-says-its-pure-intentioned-to-carry-tampons-around](https://www.dailywire.com/news/trans-activist-dylan-mulvaney-defends-tampax-says-its-pure-intentioned-to-carry-tampons-around)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 16:47:09+00:00

Transgender activist Dylan Mulvaney is defending the feminine hygiene brand Tampax, saying the company shouldn’t be targeted just because of its rumored association with the social media influencer.  Mulvaney&#8217;s TikTok video is called “the great tampon debacle of 2022” and features the activist saying the brand doesn&#8217;t deserve boycotts. Rumor had it that Mulvaney was ...

## Musk Fires Back At Schiff Over Hate Speech On Twitter
 - [https://www.dailywire.com/news/musk-fires-back-at-schiff-over-hate-speech-on-twitter](https://www.dailywire.com/news/musk-fires-back-at-schiff-over-hate-speech-on-twitter)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 16:42:25+00:00

A prominent House Democrat raising concerns about hate speech on Twitter received a terse response Thursday directly from Twitter CEO Elon Musk. Singling out &#8220;Elon Musk&#8217;s Twitter,&#8221; Rep. Adam Schiff (D-CA) shared statistics showing a rise in &#8220;slurs&#8221; against black people, women, Jewish people, and gay men. &#8220;These numbers are abysmal – and unacceptable,&#8221; Schiff ...

## FTC Moves To Block Microsoft’s $69 Billion Purchase Of Activision
 - [https://www.dailywire.com/news/ftc-moves-to-block-microsofts-69-billion-purchase-of-activision](https://www.dailywire.com/news/ftc-moves-to-block-microsofts-69-billion-purchase-of-activision)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 16:33:18+00:00

Regulators at the Federal Trade Commission are attempting to block Microsoft from acquiring video game developer Activision Blizzard for $69 billion, claiming that the merger would enable the technology conglomerate to reduce market competition with subsidiary Xbox. The agency contended in a press release that Microsoft routinely acquires gaming companies to “suppress competition from rival ...

## Elizabeth Warren Asks Federal Reserve To Investigate Banking System’s Exposure To Crypto
 - [https://www.dailywire.com/news/elizabeth-warren-asks-federal-reserve-to-investigate-banking-systems-exposure-to-crypto](https://www.dailywire.com/news/elizabeth-warren-asks-federal-reserve-to-investigate-banking-systems-exposure-to-crypto)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 16:28:11+00:00

Sen. Elizabeth Warren (D-MA) and Sen. Tina Smith (D-NM) asked the Federal Reserve to examine the banking system’s exposure to cryptocurrencies amid continued fallout from defunct company FTX. In a letter addressed to Federal Reserve Chair Jerome Powell, the lawmakers noted that cryptocurrency firms have desired the “benefits that come with federal recognition from bank ...

## Authorities Report Five Electricity Substations Targeted In Pacific Northwest Days After North Carolina Attacks
 - [https://www.dailywire.com/news/authorities-report-five-electricity-substations-targeted-in-pacific-northwest-days-after-north-carolina-attacks](https://www.dailywire.com/news/authorities-report-five-electricity-substations-targeted-in-pacific-northwest-days-after-north-carolina-attacks)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 16:22:12+00:00

Five electricity substations in Oregon and Washington were targeted in November, according to three energy companies who reported the attacks to the FBI.  Bonneville Power Administration (BPA), Puget Sound Energy, and the Cowlitz County Public Utility District confirmed their substations were attacked in November, the Seattle Times reported. Reports of the November attacks come just ...

## PETERSON: Exodus — Tyranny, Slavery, And The Journey To Freedom
 - [https://www.dailywire.com/news/peterson-exodus-tyranny-slavery-and-the-journey-to-freedom](https://www.dailywire.com/news/peterson-exodus-tyranny-slavery-and-the-journey-to-freedom)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 16:15:24+00:00

The following is a transcript excerpt from Dr. Peterson on the opening chapter of Exodus. You can watch &#8220;Exodus: Episode 1&#8221; on DailyWire+.  Episode time: 10:56  One of the things that has really fascinated me about Exodus – apart from the fundamental structure of the narrative, which is escape from tyranny, sojourn through the desert, and ...

## Jennifer Lawrence Facing Backlash After Claiming She Was First Lead Female Action Hero; Variety Deletes Tweet
 - [https://www.dailywire.com/news/jennifer-lawrence-facing-backlash-after-claiming-she-was-first-lead-female-action-hero-variety-deletes-tweet](https://www.dailywire.com/news/jennifer-lawrence-facing-backlash-after-claiming-she-was-first-lead-female-action-hero-variety-deletes-tweet)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 16:14:22+00:00

Hollywood star Jennifer Lawrence is facing backlash after she falsely claimed that &#8220;nobody had ever put a woman in the lead of an action movie” prior to 2012’s &#8220;Hunger Games&#8221; — and Variety has since deleted its tweet in which she made that claim. During a Variety Actors on Actors interview, the 32-year-old actress claimed she ...

## KJP Gushes Over Griner’s Release: An ‘Important Role Model’ For ‘LGBTQI+ Americans And Women Of Color’
 - [https://www.dailywire.com/news/kjp-gushes-over-griners-release-an-important-role-model-for-lgbtqi-americans-and-women-of-color](https://www.dailywire.com/news/kjp-gushes-over-griners-release-an-important-role-model-for-lgbtqi-americans-and-women-of-color)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 16:09:19+00:00

White House Press Secretary Karine Jean-Pierre praised WNBA player Brittney Griner during Thursday&#8217;s press conference after the Biden administration released a notorious terrorist from custody in exchange for Griner being released from a Russian prison after she was arrested on drug charges earlier this year. &#8220;President Biden keeps his promises and today he fulfilled a ...

## School District Demands Over $7K From Parents For Bullying Records
 - [https://www.dailywire.com/news/school-district-demands-over-7k-from-parents-for-bullying-records](https://www.dailywire.com/news/school-district-demands-over-7k-from-parents-for-bullying-records)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 16:07:15+00:00

A Texas school district is demanding parents fork over more than $7,000 for public records about bullying in the district. The Joshua Independent School District, which sits just south of Fort Worth, demanded that mom Terrie Chumchal pay the exorbitant sum when she tried to get to the bottom of the district&#8217;s bullying problem. For two years, ...

## Mariah Carey Has Something To Say About Being Labeled ‘Queen Of Christmas,’ Explains Who The Real One Is
 - [https://www.dailywire.com/news/mariah-carey-has-something-to-say-about-being-labeled-queen-of-christmas-explains-who-the-real-one-is](https://www.dailywire.com/news/mariah-carey-has-something-to-say-about-being-labeled-queen-of-christmas-explains-who-the-real-one-is)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 15:57:58+00:00

Mariah Carey had something to say about being labeled the &#8220;Queen of Christmas&#8221; as she explained she&#8217;s never actually called herself that — and in addition, the songstress noted that the real &#8220;Queen of Christmas&#8221; would have to be the Virgin mother Mary. During the 52-year-old singer&#8217;s appearance on &#8220;The Late Show with Stephen Colbert,&#8221; ...

## SpaceX Prepares To Launch First Private Japanese Mission To Moon
 - [https://www.dailywire.com/news/spacex-prepares-to-launch-first-private-japanese-mission-to-moon](https://www.dailywire.com/news/spacex-prepares-to-launch-first-private-japanese-mission-to-moon)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 15:55:01+00:00

SpaceX is preparing to launch Japan&#8217;s first privately-led mission to the moon. The ispace HAKUTO-R Mission 1 is set to blast off on Sunday at 2:38 a.m. ET from the Cape Canaveral Space Force Station in Florida, the same day that NASA&#8217;s Orion capsule is expected to return from its Artemis 1 moon mission. The ...

## ‘Can I Say That?’: ‘Married With Children’ Star Details The Moment She Got MS Diagnosis
 - [https://www.dailywire.com/news/can-i-say-that-married-with-children-star-details-the-moment-she-got-ms-diagnosis](https://www.dailywire.com/news/can-i-say-that-married-with-children-star-details-the-moment-she-got-ms-diagnosis)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 15:53:18+00:00

Actress Christina Applegate described the moment she learned that she had multiple sclerosis during a recent interview with &#8220;American Idol&#8221; winner Kelly Clarkson. Claiming that the news had &#8220;sucked b***s,&#8221; Applegate quickly scrambled to ask Clarkson whether she was actually allowed to use those words. The &#8220;Married With Children&#8221; alum has previously spoken publicly about ...

## Great Day For America: The New York Times Is Barely Reporting Any ‘News’ Because Of A Writers’ Strike
 - [https://www.dailywire.com/news/great-day-for-america-the-new-york-times-is-barely-reporting-any-news-because-of-a-writers-strike](https://www.dailywire.com/news/great-day-for-america-the-new-york-times-is-barely-reporting-any-news-because-of-a-writers-strike)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 15:12:12+00:00

It&#8217;s always a great day to be an American, but Thursday was especially remarkable because writers for a certain &#8220;Gray Lady&#8221; are on strike. That means there&#8217;s a whole lot less &#8220;fake news&#8221; out there for a brief moment in time. On Wednesday, The New York Times&#8217; Maggie Astor tweeted, &#8220;Barring a breakthrough, @nytimes staff ...

## Former NYPD Officer Gets 25 To Life For Killing Autistic Son
 - [https://www.dailywire.com/news/former-nypd-officer-gets-25-to-life-for-killing-autistic-son](https://www.dailywire.com/news/former-nypd-officer-gets-25-to-life-for-killing-autistic-son)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 15:01:32+00:00

A former New York City police officer was sentenced Thursday to 25 years to life in prison for the murder of his young son. Michael Valva was found guilty by a jury last month on five charges related to the January 2020 killing, including endangering the welfare of a child and second-degree murder. Prosecutors argued ...

## Kevin O’Leary Says He Fell Victim To ‘Groupthink,’ Lost All Of His $15 Million Payout As FTX Ambassador
 - [https://www.dailywire.com/news/kevin-oleary-says-he-fell-victim-to-groupthink-lost-all-of-his-15-million-payout-as-ftx-ambassador](https://www.dailywire.com/news/kevin-oleary-says-he-fell-victim-to-groupthink-lost-all-of-his-15-million-payout-as-ftx-ambassador)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 14:44:28+00:00

Canadian celebrity investor Kevin O’Leary said that he lost his entire $15 million payout from FTX, the defunct cryptocurrency exchange for which he was an ambassador. FTX filed for bankruptcy last month after users discovered that the company was likely intertwined with Alameda Research; both were controlled by now-broke former billionaire Sam Bankman-Fried and a ...

## ‘I Should Have Been More Educated’: Dallas Cowboy Walks Back Biden Slam Over Griner Case
 - [https://www.dailywire.com/news/i-should-have-been-more-educated-dallas-cowboy-walks-back-biden-slam-over-griner-case](https://www.dailywire.com/news/i-should-have-been-more-educated-dallas-cowboy-walks-back-biden-slam-over-griner-case)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 14:33:08+00:00

Dallas Cowboy Micah Parsons quickly reversed course, apologizing after slamming President Joe Biden in the wake of the prisoner swap that secured WNBA star Brittney Griner&#8217;s release. Parsons, upon learning that Russia was trading Griner for international arms dealer Viktor &#8220;Merchant of Death&#8221; Bout — and that Marine veteran Paul Whelan was being left behind ...

## ‘Today’ Show Host Al Roker Give Fans Update After Being Hospitalized A Second Time
 - [https://www.dailywire.com/news/today-show-host-al-roker-give-fans-update-after-being-hospitalized-a-second-time](https://www.dailywire.com/news/today-show-host-al-roker-give-fans-update-after-being-hospitalized-a-second-time)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 14:22:42+00:00

Longtime &#8220;Today&#8221; show host Al Roker gave fans an update Thursday about how he&#8217;s doing after he had to be hospitalized a second time after initially being released in time to spend Thanksgiving with his family. In a post shared on Instagram, the 68-year-old weather personality wrote that he would &#8220;hopefully&#8221; be home soon after ...

## Texas Gov. Greg Abbott Bans State Employees From Using TikTok Amid Chinese Espionage Threats
 - [https://www.dailywire.com/news/texas-gov-greg-abbott-bans-state-employees-from-using-tiktok-amid-chinese-espionage-threats](https://www.dailywire.com/news/texas-gov-greg-abbott-bans-state-employees-from-using-tiktok-amid-chinese-espionage-threats)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 14:18:36+00:00

On Wednesday, Texas became the fourth state to ban TikTok on state-issued devices amid federal officials sounding the alarm that the Chinese-based social media app threatens national security. Republican Governor Greg Abbott sent letters to state agency leaders warning that the social media platform risks the safety and cybersecurity of Texans. “TikTok harvests vast amounts ...

## House Passes $858 Billion Defense Bill That Reverses Military Vaccine Mandate
 - [https://www.dailywire.com/news/house-passes-858-billion-defense-bill-that-reverses-military-vaccine-mandate](https://www.dailywire.com/news/house-passes-858-billion-defense-bill-that-reverses-military-vaccine-mandate)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 14:08:26+00:00

The U.S. House of Representatives passed legislation Thursday authorizing $858 billion in national defense funding, including reversing the U.S. military’s COVID-19 vaccine mandate. Lawmakers approved a final version to repeal the mandate through the passage of the 2023 National Defense Authorization Act (NDAA), the annual defense bill. The bill includes several policy provisions, including a ...

## How Disney Could Win Back The Trust Of Its Lost Conservative Fans
 - [https://www.dailywire.com/news/how-disney-could-win-back-the-trust-of-its-lost-conservative-fans](https://www.dailywire.com/news/how-disney-could-win-back-the-trust-of-its-lost-conservative-fans)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 14:06:35+00:00

Disney’s new chief executive shocked the business world last week by admitting that the company’s previous opposition to parental rights legislation in Florida was a mistake.  During a town hall meeting with employees, new Disney CEO Bob Iger expressed regret that his predecessor and would-be successor, Bob Chapek, positioned the company against legislation that bans ...

## ‘I Don’t Understand’: Marine Vet Left In Russian Prison ‘Greatly Disappointed’ After Griner Swap
 - [https://www.dailywire.com/news/i-dont-understand-marine-vet-left-in-russian-prison-greatly-disappointed-after-griner-swap](https://www.dailywire.com/news/i-dont-understand-marine-vet-left-in-russian-prison-greatly-disappointed-after-griner-swap)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 13:54:06+00:00

U.S. Marine veteran Paul Whelan told CNN on Thursday that he was &#8220;greatly disappointed&#8221; that President Joe Biden&#8217;s deal to secure Brittney Griner&#8217;s release from a Russian prison did not also include a release for him. Whelan, who has been imprisoned in Russia for nearly four years since his arrest, is currently serving 16 years ...

## In The Name Of ‘Equality,’ Nantucket Beaches Go Topless
 - [https://www.dailywire.com/news/in-the-name-of-equality-nantucket-beaches-go-topless](https://www.dailywire.com/news/in-the-name-of-equality-nantucket-beaches-go-topless)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 13:49:28+00:00

Does gender equality include men and women being allowed to publicly expose their breasts? Well, according to Dorothy Stover — a lifelong resident of Nantucket, Massachusetts, and a self-proclaimed sex educator — the answer to that question is yes. Stover scored a legal victory this week after Massachusetts Attorney General Maura Healey approved an amendment ...

## FDA Targets 6-Month-Olds, Approves New Bivalent COVID Vaccine For Infants
 - [https://www.dailywire.com/news/fda-targets-6-month-olds-approves-new-bivalent-covid-vaccine-for-infants](https://www.dailywire.com/news/fda-targets-6-month-olds-approves-new-bivalent-covid-vaccine-for-infants)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 13:48:06+00:00

The Biden administration’s Food and Drug Administration has approved the bivalent COVID vaccine for babies as young as six months old. The new vaccines from Pfizer and Moderna are supposed to be given to babies in three doses. Bivalent vaccines differ from the previous mRNA vaccines in that they combine the original vaccine with a ...

## Chinese Manufacturing Is Quickly Collapsing
 - [https://www.dailywire.com/news/chinese-manufacturing-is-quickly-collapsing](https://www.dailywire.com/news/chinese-manufacturing-is-quickly-collapsing)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 12:52:46+00:00

One of the most noteworthy geopolitical and economic developments in modern history has been the emergence of China as a superpower. The miraculous rise of the once-ascendent communist nation, however, could lose tremendous momentum as the strength of its manufacturing sector rapidly dissipates. China’s gross domestic product has expanded at an average of 9% since ...

## Newspeak: AP Stylebook Bans Term ‘Late-Term Abortion,’ Prefers ‘Abortion Later In Pregnancy’
 - [https://www.dailywire.com/news/newspeak-ap-stylebook-bans-term-late-term-abortion-prefers-abortion-later-in-pregnancy](https://www.dailywire.com/news/newspeak-ap-stylebook-bans-term-late-term-abortion-prefers-abortion-later-in-pregnancy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 12:45:13+00:00

The Associated Press Stylebook sets the usage and grammatical format for hundreds of news agencies, laying out style and terms in an alphabetized book several hundred pages long. So it matters when the stylebook makes a substantive change. This week, the journalist&#8217;s bible forbade the use of the phrase &#8220;late-term abortion,&#8221; which drew swift rebuke ...

## Saudi Leader MBS Helped Broker Brittney Griner Swap After White House Ended Khashoggi Suit
 - [https://www.dailywire.com/news/saudi-leader-mbs-helped-broker-brittney-griner-swap-after-white-house-ended-khashoggi-suit-report](https://www.dailywire.com/news/saudi-leader-mbs-helped-broker-brittney-griner-swap-after-white-house-ended-khashoggi-suit-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 12:15:17+00:00

Saudi Arabia’s Crown Prince Mohammed bin Salman helped broker the dramatic prisoner swap between the U.S. and Moscow that sprang WNBA star Brittney Griner from a Russian gulag, days after the Biden administration helped spike a lawsuit against the Saudi ruler. MBS, as the Saudi leader is known, and United Arab Emirates President Sheikh Mohammed ...

## Iran Starts Execution Of Protesters. 23-Year-Old Protester Hanged.
 - [https://www.dailywire.com/news/iran-starts-execution-of-protesters-23-year-old-protester-hanged](https://www.dailywire.com/news/iran-starts-execution-of-protesters-23-year-old-protester-hanged)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 12:04:18+00:00

The despotic, tyrannical Iranian regime has executed a protester against the government for the first time since protests surged after the mid-September death of Mahsa Amini, the 22-year-old woman who died in police custody. According to the HRANA news agency, the government and its allies killed at least 459 protesters as of November 29, including ...

## ‘What Are They Hiding?’: Secret JFK Assassination Documents To Be Released Next Week
 - [https://www.dailywire.com/news/what-are-they-hiding-secret-jfk-assassination-documents-to-be-released-next-week](https://www.dailywire.com/news/what-are-they-hiding-secret-jfk-assassination-documents-to-be-released-next-week)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 11:51:04+00:00

Next week, thousands of documents revolving around the JFK assassination are expected to be released, documents that the CIA and FBI have fought to keep secret. The National Archives and Records Administration has been arguing with the CIA and FBI for years, asserting that the agencies were ignoring the 1992 John F. Kennedy Assassination Records ...

## Why SCOTUS Ruling In Favor Of Google On Section 230 Is Good For Free Speech
 - [https://www.dailywire.com/news/why-scotus-ruling-in-favor-of-google-on-section-230-is-good-for-free-speech](https://www.dailywire.com/news/why-scotus-ruling-in-favor-of-google-on-section-230-is-good-for-free-speech)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 11:50:38+00:00

The fate of speech on the internet is in the hands of the Supreme Court when it decides Gonzales v. Google — a case that puts Section 230 protections for websites, platforms, and applications on trial. Misinterpreting this critical protection will destroy the internet as we know it. A ruling in favor of Google to uphold ...

## Dem-Controlled House Passes Same-Sex Marriage Bill; 39 Republicans Support
 - [https://www.dailywire.com/news/dem-controlled-house-passes-same-sex-marriage-bill-39-republicans-support](https://www.dailywire.com/news/dem-controlled-house-passes-same-sex-marriage-bill-39-republicans-support)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 11:45:06+00:00

The U.S. House of Representatives passed legislation Thursday, 258-169, that would codify same-sex marriage protections into law, despite opposition from most GOP lawmakers who argue the bill&#8217;s language infringes on religious freedoms. The bill will now be sent to President Biden for signature. House Democrats supported — with the help of some Republicans — the ...

## ‘Hell Nah’: Dallas Cowboy Has Strong Reaction To Brittney Griner Swap
 - [https://www.dailywire.com/news/hell-nah-dallas-cowboy-has-strong-reaction-to-brittney-griner-swap](https://www.dailywire.com/news/hell-nah-dallas-cowboy-has-strong-reaction-to-brittney-griner-swap)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 11:26:43+00:00

Dallas Cowboys linebacker Micah Parsons reacted strongly online over the news of the release of WNBA star Brittney Griner, who was freed in a one-to-one prisoner swap in exchange for Russian arms dealer Viktor Bout, dubbed the “Merchant of Death.” Parsons seemed to take particular issue with the Biden administration failing to secure the release ...

## Indiana Sues TikTok Over Data Sharing, Mature Content Concerns
 - [https://www.dailywire.com/news/indiana-sues-tiktok-over-data-sharing-mature-content-concerns](https://www.dailywire.com/news/indiana-sues-tiktok-over-data-sharing-mature-content-concerns)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 11:15:48+00:00

Indiana Attorney General Todd Rokita announced two lawsuits against TikTok on Wednesday over concerns about data sharing and mature content targeting children. “The TikTok app is a malicious and menacing threat unleashed on unsuspecting Indiana consumers by a Chinese company that knows full well the harms it inflicts on users,” Rokita said in a statement. ...

## Major Indian Company To Start Producing Semiconductors As Global Shortages, Threats From China Continue
 - [https://www.dailywire.com/news/major-indian-company-to-start-producing-semiconductors-as-global-shortages-threats-from-china-continue](https://www.dailywire.com/news/major-indian-company-to-start-producing-semiconductors-as-global-shortages-threats-from-china-continue)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 10:44:48+00:00

Indian multinational conglomerate Tata Group plans to start production of semiconductors in the country within the next few years. Multiple manufacturing economies in East Asia enforced harsh lockdown measures two years ago, creating disruptions in the worldwide semiconductor supply chain that continue to the present day. Tata Sons Chairman Natarajan Chandrasekaran revealed during an interview ...

## Chip And Joanna Gaines Sued For $1M By Former Literary Agent, Says He Didn’t Get His Promised Cut
 - [https://www.dailywire.com/news/chip-and-joanna-gaines-sued-for-1m-by-former-literary-agent-says-he-didnt-get-his-promised-cut](https://www.dailywire.com/news/chip-and-joanna-gaines-sued-for-1m-by-former-literary-agent-says-he-didnt-get-his-promised-cut)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 10:16:47+00:00

Chip and Joanna Gaines, who starred in the HGTV reality series &#8220;Fixer Upper,&#8221; are being sued by their former literary agent for what he’s describing as a breach of contract. Joanna had previously agreed to write five books with HarperCollins as part of a $12.5 million deal, per TMZ. The arrangement was brokered by the ...

## Everyone Calm Down About Players Opting Out Of Bowl Games
 - [https://www.dailywire.com/news/everyone-calm-down-about-players-opting-out-of-bowl-games](https://www.dailywire.com/news/everyone-calm-down-about-players-opting-out-of-bowl-games)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 10:13:50+00:00

Making smart business decisions is one of the main factors in determining someone’s success. We applaud people in the business world for consistently making risk averse decisions to achieve their lofty goals. The same can be said for the big business of football. Notice I didn’t say ‘college’ or ‘NFL’ football because sometimes the two ...

## Leftist L.A. DA Tells Prosecutors To Give Illegals Under Criminal Investigation A Way To Avoid Deportation
 - [https://www.dailywire.com/news/leftist-l-a-da-tells-prosecutors-to-give-illegals-under-criminal-investigation-a-way-to-avoid-deportation](https://www.dailywire.com/news/leftist-l-a-da-tells-prosecutors-to-give-illegals-under-criminal-investigation-a-way-to-avoid-deportation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 10:11:00+00:00

Leftist Los Angeles County DA George Gascón is directing prosecutors to let illegal immigrants under criminal investigation claim the charges could have “adverse immigration consequences” and thus avoid deportation. The policy recommends that prosecutors examine alternatives to criminal convictions “such as avoiding charging for criminal enhancements, which can significantly increase one&#8217;s prison sentence, ‘that would ...

## Elite Chicago K-12 School Responds To Sting Video Showing Dean Bragging About Sex Toys In Classroom
 - [https://www.dailywire.com/news/elite-chicago-k-12-school-responds-to-sting-video-showing-dean-bragging-about-sex-toys-in-classroom](https://www.dailywire.com/news/elite-chicago-k-12-school-responds-to-sting-video-showing-dean-bragging-about-sex-toys-in-classroom)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 09:58:59+00:00

An elite private K-12 school in Chicago responded to a viral Project Veritas video Wednesday evening that showed one of its employees talking about sex toys being handed out in class for teenagers to examine. The video allegedly showed Joseph Bruno, Dean of Students, Francis W. Parker School — which costs tens of thousands of dollars ...

## Dean At Elite Chicago Private K-12 School Brags About Sex Toys Being Brought Into Class For Kids To Pass Around: Project Veritas Investigation
 - [https://www.dailywire.com/news/dean-at-elite-chicago-private-k-12-school-brags-about-sex-toys-being-brought-into-class-for-kids-to-pass-around-project-veritas-investigation](https://www.dailywire.com/news/dean-at-elite-chicago-private-k-12-school-brags-about-sex-toys-being-brought-into-class-for-kids-to-pass-around-project-veritas-investigation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 09:48:25+00:00

The dean of students at an elite private school in Chicago was allegedly recorded on undercover video admitting to having a group come into his classroom and pass out sex toys during Pride Week for students to examine and to learn about gay sex. The video was captured by the conservative action group Project Veritas ...

## Ron DeSantis Meets With Key Donors After Re-Election Blowout As 2024 Speculation Swirls
 - [https://www.dailywire.com/news/ron-desantis-meets-with-key-donors-after-re-election-blowout-as-2024-speculation-swirls](https://www.dailywire.com/news/ron-desantis-meets-with-key-donors-after-re-election-blowout-as-2024-speculation-swirls)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 09:44:42+00:00

Republican Florida Governor Ron DeSantis is reportedly gathering with some of his top donors this month as he plots out the course of his political future following his blowout victory in last month&#8217;s midterm elections. The Washington Post reported that DeSantis sent out invitations to the governor&#8217;s &#8220;strongest supporters&#8221; this week for an &#8220;intimate dinner&#8221; ...

## Charlize Theron Says Giving Up Acting Career For Motherhood Would Be A ‘No-Brainer’
 - [https://www.dailywire.com/news/charlize-theron-says-giving-up-acting-career-for-motherhood-would-be-a-no-brainer](https://www.dailywire.com/news/charlize-theron-says-giving-up-acting-career-for-motherhood-would-be-a-no-brainer)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 09:32:31+00:00

If actress Charlize Theron was forced to choose between her career and motherhood, she said she’d pick the latter. The 47-year-old mom of two adopted children made the comments during a recent interview with The Hollywood Reporter. “It’s my life, and I want to participate in it,&#8221; Theron said when asked how she likes to ...

## Celine Dion Reveals Heartbreaking News About Her Health
 - [https://www.dailywire.com/news/celine-dion-reveals-heartbreaking-news-about-her-health](https://www.dailywire.com/news/celine-dion-reveals-heartbreaking-news-about-her-health)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 09:11:48+00:00

Iconic singer Celine Dion revealed Thursday that she is suffering from an incredibly rare disease that prevents her from currently performing. The singer, who shot to international stardom after her duet with Peabo Bryson for “Beauty and the Beast” in 1991, stated she has been diagnosed with stiff-person syndrome (SPS), a progressive disease that leaves ...

## BREAKING: WNBA Star Brittney Griner Freed From Russian Prison In Swap For Arms Dealer
 - [https://www.dailywire.com/news/wnba-star-brittney-griner-freed-from-russian-prison-in-swap-for-arms-dealer](https://www.dailywire.com/news/wnba-star-brittney-griner-freed-from-russian-prison-in-swap-for-arms-dealer)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 08:51:20+00:00

WNBA star Brittney Griner was freed from Russian captivity Thursday in a prisoner exchange for a notorious Russian arms dealer, President Joe Biden announced. Griner, who was arrested in February at a Moscow airport after being caught with marijuana vaping materials, was sentenced in August to nine years in prison. The 6-foot, 9-inch athlete plays ...

## Blake Shelton Will Give Up Being On ‘The Voice’ To Focus On Raising Children With Gwen Stefani
 - [https://www.dailywire.com/news/blake-shelton-will-give-up-being-on-the-voice-to-focus-on-raising-children-with-gwen-stefani](https://www.dailywire.com/news/blake-shelton-will-give-up-being-on-the-voice-to-focus-on-raising-children-with-gwen-stefani)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 08:29:45+00:00

Country singer Blake Shelton will give up being on &#8220;The Voice&#8221; next year to focus on his wife, pop singer Gwen Stefani, and raising their children together, the 46-year-old said in a new interview this week. Shelton made the remarks in an interview with People about how raising his three stepsons — ages 8, 14, ...

## Elon Musk To Change Pricing For Twitter Subscriptions, Incentivize People To Not Buy Through Apple Store: Report
 - [https://www.dailywire.com/news/elon-musk-to-change-pricing-for-twitter-subscriptions-incentivize-people-to-not-buy-through-apple-store-report](https://www.dailywire.com/news/elon-musk-to-change-pricing-for-twitter-subscriptions-incentivize-people-to-not-buy-through-apple-store-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 08:10:25+00:00

Twitter CEO Elon Musk is reportedly set to change the price that the company charges users for its Twitter Blue subscription in an apparent attempt to offset a substantial cut that Apple takes if users sign up using Apple&#8217;s App Store. The Information reported that Twitter will drop the $8 per month fee to $7 ...

## Peru’s Socialist President Kicked Out Of Office And Arrested For Staging Attempted Coup, Report Says
 - [https://www.dailywire.com/news/perus-socialist-president-kicked-out-of-office-and-arrested-for-staging-attempted-coup-report-says](https://www.dailywire.com/news/perus-socialist-president-kicked-out-of-office-and-arrested-for-staging-attempted-coup-report-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-12-08 07:53:48+00:00

Peru&#8217;s socialist President Pedro Castillo was reportedly arrested Wednesday after being impeached and removed from office for staging a coup to stay in power. During his first 16 months in power, Castillo has faced six criminal investigations and three impeachment attempts, including the one that removed him from power this week, The New York Times ...


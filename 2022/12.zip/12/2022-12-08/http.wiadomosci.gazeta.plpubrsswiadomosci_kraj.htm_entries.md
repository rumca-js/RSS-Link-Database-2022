# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Dzieci były już na pasach, a mężczyzna machał znakiem stop. Kierująca nawet się nie zatrzymała
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241884,dzieci-byly-juz-na-pasach-a-mezczyzna-machal-znakiem-stop.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241884,dzieci-byly-juz-na-pasach-a-mezczyzna-machal-znakiem-stop.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 21:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/56/e3/1b/z29241942M,Zignorowala-pieszych-i-wjechala-na-przejscie.jpg" vspace="2" />Policja informuje o groźnym zdarzeniu, do którego doszło w Nowej Wsi Ełckiej (woj. warmińsko-mazurskie). Jak widać na udostępnionym nagraniu, kobieta kierująca samochodem osobowym nie zatrzymała się przed przejściem, na którym byli piesi. Ponadto zignorowała sygnały mężczyzny, który czuwał nad bezpiecznym przejściem uczniów przez drogę. Ukarano ją 30 punktami karnymi.

## Opole. Ruszył proces Viktora S. Miał zabić byłą partnerkę z zazdrości. "Będziesz ze mną albo z nikim"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241749,opole-ruszyl-proces-viktora-s-mial-zabic-byla-partnerke-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241749,opole-ruszyl-proces-viktora-s-mial-zabic-byla-partnerke-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 20:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/26/cc/1b/z29151014M,sad--wyrok---zdjecie-ilustracyjne--.jpg" vspace="2" />W Sądzie Okręgowym w Opolu rozpoczął się proces 38-letniego Viktora S., który podczas imprezy miał zamordować swoją 46-letnią byłą partnerkę. - Byłem w takim szoku, że nie pamiętam, jak dokonałem tego zabójstwa nożem - zeznał mężczyzna.

## Prof. Marcin Wiącek tłumaczy odwołanie zastępczyni RPO. "Przygotowanie urzędu do nowych wyzwań"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241555,marcin-wiacek-tlumaczy-odwolanie-zastepczyni-rpo-przygotowanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241555,marcin-wiacek-tlumaczy-odwolanie-zastepczyni-rpo-przygotowanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 18:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/d1/1b/z29169895M,Rzecznik-praw-obywatelskich-Marcin-Wiacek.jpg" vspace="2" />Biuro Rzecznika Praw Obywatelskich opublikowało komunikat z wyjaśnieniami dotyczącymi odwołania dr Hanny Machińskiej z funkcji zastępczyni RPO. "Rzecznik pragnie podkreślić, że wysoko ocenia dorobek i dotychczasową współpracę z dr Hanną Machińską. [...] Jednocześnie [...] wyjaśnia, że decyzja o odwołaniu [...] związana jest tylko i wyłącznie z nowymi wyzwaniami, które stoją przed Biurem RPO" - czytamy.

## Marianna Schreiber pójdzie do wojska? "Jak będzie 2 tys. serduszek, to idę". Polubień szybko przybywa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241425,marianna-schreiber-pojdzie-do-wojska-jak-bedzie-2-tys-serduszek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241425,marianna-schreiber-pojdzie-do-wojska-jak-bedzie-2-tys-serduszek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 17:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bc/e3/1b/z29241532M,Marianna-Schreiber-wstapi-do-wojska-.jpg" vspace="2" />Marianna Schreiber pójdzie do wojska? "Gdyby było trzeba, nie patrząc na to, że jestem kobietą - poszłabym bez mrugnięcia okiem" - zapewniała w czwartek w mediach społecznościowych. Kiedy jednak internauci zwrócili jej uwagę, że nic nie stoi na przeszkodzie, żeby zgłosiła się do służby, obiecała to zrobić po uzyskaniu wystarczającej liczby polubień jej wpisu.

## Sochaczew. Atak nożownika w sklepie. Nieoficjalnie: Napastnikiem był mąż ofiary
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241432,sochaczew-atak-nozownika-w-sklepie-nieoficjalnie-napastnikiem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241432,sochaczew-atak-nozownika-w-sklepie-nieoficjalnie-napastnikiem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 17:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/09/e2/1b/z29241097M,Sochaczew--Nozownik-zaatakowal-ekspedientke-sklepu.jpg" vspace="2" />Pracownicę sklepu w Sochaczewie zaatakował jej mąż - ustaliło nieoficjalnie RMF FM. Mężczyzna miał mieć zakaz zbliżania się do żony, a także dozór policyjny. Wciąż trwa obława na napastnika.

## Pożar kamienicy w Katowicach. Ktoś podpalił wózek dziecięcy na klatce schodowej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241272,pozar-kamienicy-w-katowicach-ktos-podpalil-wozek-dzieciecy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241272,pozar-kamienicy-w-katowicach-ktos-podpalil-wozek-dzieciecy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 17:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/62/e3/1b/z29241442M,Straz-pozarna---zdjecie-ilustracyjne.jpg" vspace="2" />W kamienicy przy ul. Katowickiej w Katowicach w nocy wybuchł pożar. Policja ewakuowała mieszkańców i nikomu nic się nie stało. Wstępne ustalenia wskazują, że ktoś podpalił zostawiony na klatce schodowej wózek dziecięcy.

## Ukarany za tuszowanie pedofilii będzie miał huczny jubileusz. Ale prosi tylko o obecność, nie o prezenty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29240872,ukarany-za-tuszowanie-pedofilii-bedzie-mial-huczny-jubileusz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29240872,ukarany-za-tuszowanie-pedofilii-bedzie-mial-huczny-jubileusz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 17:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a5/c5/19/z27022245M,Abp-Wiktor-Skworc.jpg" vspace="2" />Na początku styczna w Katowicach odbędzie się impreza z okazji potrójnego jubileuszu abp. Wiktora Skworca. - Sprawa budzi głęboki niesmak. Wielka feta w iście bizantyjskim stylu, na której głębokim cieniem kładą się wciąż nierozliczone afery pedofilskie - mówi radny PO Łukasz Borkowski.

## Do Polski nadchodzi wielka śnieżyca. Ponad 40 cm śniegu? "Możliwe przerwy w dostawie prądu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241269,do-polski-nachodzi-wielka-sniezyca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29241269,do-polski-nachodzi-wielka-sniezyca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 16:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f1/e2/1b/z29241329M,Do-Polski-nadciaga-wielka-sniezyca.jpg" vspace="2" />Pogoda w grudniu jeszcze namiesza. Według synoptyków w ciągu najbliższego tygodnia możemy spodziewać się śnieżycy. I to nie byle jakiej! Zapowiadane są kilkudziesięciocentymetrowe opady i paraliż na drogach.

## Jarosław Kaczyński o opozycji: To element zatruwający polską politykę. "Nasza opozycja nie jest lojalna"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29240449,kaczynski-ostro-o-opozycji-to-element-zatruwajacy-polska-polityke.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29240449,kaczynski-ostro-o-opozycji-to-element-zatruwajacy-polska-polityke.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 15:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d7/e2/1b/z29241047M,Jaroslaw-Kaczynski.jpg" vspace="2" />Jarosław Kaczyński podczas wizyty w woj. lubuskim obwieścił, co w Polsce jest "polityczną rtęcią". - Najbardziej zatruwającym elementem, decydującym - gdyby tego nie było, nie byłoby zatrucia - jest opozycja totalna - powiedział lider Prawa i Sprawiedliwości w rozmowie z "Gazetą Lubuską" (należącą do Orlenu). Stwierdził też, że Niemcy nie wyleczyli się z "nur für Deutsche".

## Sochaczew. Nożownik zaatakował ekspedientkę sklepu, kobieta zmarła. Media: Zadał 20 ciosów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29240630,sochaczew-nozownik-zaatakowal-ekspedientke-sklepu-kobieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29240630,sochaczew-nozownik-zaatakowal-ekspedientke-sklepu-kobieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 14:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/00/e2/1b/z29241088M,Sochaczew--Nozownik-zaatakowal-ekspedientke-sklepu.jpg" vspace="2" />Nie żyje pracownica jednego ze sklepów w Sochaczewie. Kobieta została zaatakowana przez nożownika. Według nieoficjalnych informacji napastnik miał zadać ekspedientce ponad 20 ciosów.

## Człowiek-choinka poszukiwany. Poprzecinał opony 20 aut na terenie hurtowni mięsa [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29239751,czlowiek-choinka-poszukiwany-przez-policje-za-atak-na-hurtownie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29239751,czlowiek-choinka-poszukiwany-przez-policje-za-atak-na-hurtownie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 13:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/96/e2/1b/z29239958M,Mezczyzna-przebrany-za-choinke-spowodowal-straty-o.jpg" vspace="2" />Na terenie hurtowni mięsa w Warzymicach pod Szczecinem zamaskowany sprawca poprzecinał w nocy z 3 na 4 grudnia opony stojących na parkingu samochodów. Może byłby to niczym niewyróżniający się akt wandalizmu, gdyby nie nietypowy wygląd sprawcy. Przestępca wykorzystał do kamuflażu gałęzie świerku.

## Ćwiczenia wojskowe. Nie byłeś w wojsku i obawiasz się, że dostaniesz wezwanie? Pułkownik wyjaśnia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29240041,cwiczenia-wojskowe-nie-byles-w-wojsku-i-obawiasz-sie-ze-dostaniesz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29240041,cwiczenia-wojskowe-nie-byles-w-wojsku-i-obawiasz-sie-ze-dostaniesz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 13:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/89/73/19/z26688393M,Wojsko--zdjecie-ilustracyjne-.jpg" vspace="2" />- Nie ma żadnych drastycznych zmian w zakresie powoływania i realizacji szkoleń wojskowych - przekazał w czwartek płk Mirosław Bryś, szef Centralnego Wojskowego Centrum Rekrutacji. Zaznaczył jednocześnie, że wojsko będzie chciało powołać na ćwiczenia m.in. 3 tys. osób, które wcześniej nie odbyły żadnego podobnego szkolenia.

## Hanna Machińska zabrała głos po odwołaniu z funkcji zastępcy RPO: Nie było żadnego uzasadnienia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29239746,hanna-machinska-odwolana-z-funkcji-zastepcy-rpo-adam-bodnar.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29239746,hanna-machinska-odwolana-z-funkcji-zastepcy-rpo-adam-bodnar.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 13:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/43/e2/1b/z29240131M,Hanna-Machinska-i-Adam-Bodnar.jpg" vspace="2" />Hanna Machińska przestała pełnić funkcję zastępcy Rzecznika Praw Obywatelskich. Poparcie dla prawniczki wyraził m.in. były rzecznik Adam Bondar oraz członkowie grupy Wolność Równość Demokracja i Wolna Prokuratura. Sama Machińska w rozmowie z RMF FM stwierdziła, że nie było żadnego uzasadnienia jej odwołania.

## Wypadek na A4. Bus uderzył w radiowóz i wbił go pod cysternę. Ranni policjanci
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29238425,dolnoslaskie-policjanci-ranni-w-wypadku-na-a4-bus-uderzyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29238425,dolnoslaskie-policjanci-ranni-w-wypadku-na-a4-bus-uderzyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 10:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2d/e2/1b/z29238573M,Policjanci-ranni-w-wypadku-na-A4-.jpg" vspace="2" />W czwartek nad ranem dwóch policjantów zostało rannych w wypadku na autostradzie A4. W policyjny radiowóz zabezpieczający uszkodzoną cysternę uderzył jadący z dużą prędkością bus, wciskając samochód pod ciężarówkę. Ranni policjanci trafili do szpitala.

## Joanna Kurska straci pracę w TVP? "Nie chce wyjeżdżać z kraju", choć Jacek Kurski będzie wyjeżdżał
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29238086,joanna-kurska-straci-prace-w-tvp-nie-chce-wyjezdzac-z-kraju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29238086,joanna-kurska-straci-prace-w-tvp-nie-chce-wyjezdzac-z-kraju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 09:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0f/9f/1b/z28965903M,Joanna-Kurska-i-Jacek-Kurski.jpg" vspace="2" />Jacek Kurski został przedstawicielem Polski w Radzie Dyrektorów Wykonawczych Banku Światowego, co wiąże z częstymi wizytami niedawnego prezesa TVP w Stanach Zjednoczonych. Co z jego żoną, Joanną, szefową "Pytania na śniadanie"? O tym zdecyduje prezes TVP, Mateusz Matyszkowicz, z którym Kurska ma się spotkać w czwartek.

## Pogoda. Prognoza zagrożeń IMGW. W weekend śnieg, zawieje i marznące opady
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29238133,prognoza-zagrozen-imgw-w-weekend-snieg-zawieje-i-marznace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29238133,prognoza-zagrozen-imgw-w-weekend-snieg-zawieje-i-marznace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 09:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bb/e2/1b/z29238203M,Ostrzezenia-IMGW--zdjecie-ilustrujace-.jpg" vspace="2" />W ten weekend niemal w całym kraju obowiązywać będą zagrożenia meteorologiczne pierwszego stopnia, wydane przez IMGW. Synoptycy prognozują intensywne opady śniegu, zawieje, zamiecie oraz marznące opady, które mogą powodować gołoledź. Czeka nas prawdziwy atak zimy.

## Duży pożar na Dolnym Śląsku. Zawalił się dach kamienicy. Ewakuowano 30 osób
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29238029,pozar-w-przemkowie-zawalil-sie-dach-kamienicy-30-osob-zostalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29238029,pozar-w-przemkowie-zawalil-sie-dach-kamienicy-30-osob-zostalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 07:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/44/e2/1b/z29238084M,Pozar-kamienicy-w-Przemkowie.jpg" vspace="2" />W Przemkowie (woj. dolnośląskie) wybuchł pożar dachu jednego z budynków w ciągu kamienic. Na miejscu pracują zastępy straży pożarnej. Ewakuowanych zostało 30 osób.

## Pobór do wojska 2022. MON: silne Wojsko Polskie to gwarancja bezpieczeństwa Polski
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29237396,przymusowy-pobor-do-wojska-2022-mon-silne-wojsko-polskie-to.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29237396,przymusowy-pobor-do-wojska-2022-mon-silne-wojsko-polskie-to.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 06:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/67/c8/1b/z29131623M.jpg" vspace="2" />MON zapowiada zmiany w Wojsku Polskim. Chodzi między innymi o wznowienie obowiązkowych ćwiczeń wojskowych dla rezerwistów i zwiększenie finansowania wojska. Kto może dostać wezwanie do wojska? Odpowiadamy.

## "Essa" Młodzieżowym Słowem Roku 2022. Raper Sobota: Co to znaczy "essa"? To stan ducha
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29237648,essa-mlodziezowym-slowem-roku-2022-raper-sobota-co-to-znaczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29237648,essa-mlodziezowym-slowem-roku-2022-raper-sobota-co-to-znaczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 05:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3b/e1/1b/z29233467M,Znamy-juz-Mlodziezowe-Slowo-Roku-2022--zdjecie-ilu.jpg" vspace="2" />Młodzieżowe Słowo Roku 2022 to "essa". Co to słowo oznacza? Jaką ma historię? Raper Sobota twierdzi, że określa ono stan ducha. Raper Wini mówi, że "essa" to w latach dziewięćdziesiątych był "bojowy okrzyk imprezowy". Dziś słowa używają nawet ośmiolatkowie.

## Kiedy są ferie zimowe 2023? Kalendarz przerwy zimowej dla wszystkich województw [DATY]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29237752,kiedy-sa-ferie-zimowe-2023-kalendarz-przerwy-zimowej-dla-wszystkich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29237752,kiedy-sa-ferie-zimowe-2023-kalendarz-przerwy-zimowej-dla-wszystkich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 05:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7f/a3/1b/z28982399M,Ferie-zimowe-2023---terminy--Niektorzy-uczniowie-b.jpg" vspace="2" />Zimowy wypoczynek warto zaplanować z wyprzedzeniem. Wiele osób zastanawia się, kiedy dokładnie wypadają ferie zimowe dla ich województw. Przedstawiamy pełną rozpiskę.

## TVN24 o stołecznym urzędniku zatrzymanym za szpiegostwo: Należał do komisji likwidacyjnej WSI
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29237650,tvn24-o-stolecznym-urzedniku-zatrzymanym-za-szpiegostwo-nalezal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29237650,tvn24-o-stolecznym-urzedniku-zatrzymanym-za-szpiegostwo-nalezal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-12-08 05:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/92/72/1a/z27733906M.jpg" vspace="2" />Tomasz L., warszawski urzędnik, który w marcu został zatrzymany pod zarzutem szpiegostwa na rzecz Rosji, należał do komisji likwidacyjnej Wojskowych Służb Iinformacyjnych - podaje TVN24. Do doniesień odniósł się Sławomir Cenckiewicz, który kierował pracami komisji.


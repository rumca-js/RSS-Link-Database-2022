# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## THE TRUTH
 - [https://www.youtube.com/watch?v=tVDc9zkkymo](https://www.youtube.com/watch?v=tVDc9zkkymo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-12-09 00:00:00+00:00

First it was the unvaccinateds’ fault, now it’s striking nurses. Turns out, if you stand up to the State you’re actually playing right into our enemies’ hands. Bloody Putin.  
#putin #russia #strike #nurse 
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/

## IT’S OVER
 - [https://www.youtube.com/watch?v=R3rbuZzAv-Y](https://www.youtube.com/watch?v=R3rbuZzAv-Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-12-08 00:00:00+00:00

You know the Terminator films? Well they’re actually coming true. Police in America can now legally kill people with robots. What could go wrong? #police #technology #robots 

Use promo code BRAND for 15% off Field of Greens. Go to www.brickhouserussell.com

References
https://scheerpost.com/2022/12/01/cops-are-asking-to-kill-people-with-robots-what-could-go-wrong/
https://www.independent.co.uk/news/world/americas/oakland-california-police-robots-shotgun-b2205452.html
https://www.washingtonpost.com/local/legal-issues/daniel-hale-drone-leak-sentence/2021/07/27/7bb46dd6-ee14-11eb-bf80-e3877d9c5f06_story.html
https://www.vice.com/en/article/pkp8zg/police-are-buying-drones-and-armored-vehicles-with-covid-relief-funds
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/


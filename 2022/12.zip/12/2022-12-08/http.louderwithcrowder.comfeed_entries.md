# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Keith Olbermann whines his MSNBC anchor ex-girlfriend beat the crap out of him and I think expects us to feel bad
 - [https://www.louderwithcrowder.com/keith-olbermann-katie-tur](https://www.louderwithcrowder.com/keith-olbermann-katie-tur)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-08 22:07:13+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32316401&amp;width=1245&amp;height=700&amp;coordinates=0%2C84%2C0%2C60" /><br /><br /><p>Keith Olbermann used to be the face of low-information progressive content. Then he fell off because a) the internet was invented and everyone started producing low-information progressive content, and b) no one likes him. They just liked that he hated the right people. Now, Keithums is facing his final indignity. He's hosting a podcast. And one where he complains about his ex-girlfriend, MSNBC teleprompter reader Katy Tur. (shout out to <a href="https://www.outkick.com/keith-olbermann-says-katy-tur-beat-him-up-while-dating-and-he-disapproves-of-her-husbands-vasectomy/" target="_blank">Outkick</a>)</p><p>You know Katy Tur. She's the one who fantasizes about <a href="https://www.outkick.com/keith-olbermann-says-katy-tur-beat-him-up-while-dating-and-he-disapproves-of-her-husbands-vasectomy/" target="_blank">President John Fetterman</a>. Tur's husband got a vasectomy. Olbermann is angered by this to no end, for reasons known only to him and the guy working the McDonald's drive-thru. KO bragged about staying quiet about his girlfriend of three years. And that he uncoupled with thirteen years ago. But now he is ready to spill the tea!</p><blockquote>I have remained silent even though six days after her emergency appendectomy in 2007, she started punching and slapping me, with real intent to do harm, because the living room wasn’t clean enough in our place.</blockquote><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="2a1cf" src="https://www.louderwithcrowder.com/media-library/image.gif?id=32316451&amp;width=980" />
</p>
<p>Dude. You got beat up by a girl. And. You're. Still. Whining. About. It.</p><p>But wait. It gets better.</p><blockquote>How exactly do you even try to defend yourself against a woman 125 pounds lighter and a foot shorter than you?</blockquote><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="d9585" src="https://www.louderwithcrowder.com/media-library/image.gif?id=32316458&amp;width=980" />
</p>
<p>Let's see. She's a buck twenty-five, a foot shorter, and fresh off of major surgery. You turn around and walk away while she is not hitting you very hard... because she's a buck twenty-five, a foot shorter, and fresh off of major surgery. That's the first thing you do. The second thing you do is get over it and NOT hold a grudge for twelve years. And the third this is you don't whine about it twelve years later. It makes you sound like p-p-p-puuuuuuuusy.</p><p>Olbermann is big into reminding us that he dated girls before. In September, he <a href="https://www.louderwithcrowder.com/keith-olbermann-kysten-sinema" target="_blank">proclaimed to the world that he dated Krysten Sinema</a>. Who, now that I do the math, was his rebound chick from Katy Tur. </p><p>But he doesn't like Sinema like that anymore. Tur he still writes about in his diary.</p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">Jennifer Lawrence GOES ON FEMINIST TIRADE! | Louder With Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/2L-fysINIxk" target="_blank">youtu.be</a>
</small>
</p>

## WH defends saving Brittney Griner over Paul Whelan because the WNBA star is a role model...as opposed to the Marine?
 - [https://www.louderwithcrowder.com/brittney-griner-biden-paul-whelan](https://www.louderwithcrowder.com/brittney-griner-biden-paul-whelan)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-08 19:13:51+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32314774&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Earlier today, head teacher's union thug Randy Weingarten praised Joe Biden for saving the prisoner who checked all the appropriate leftist boxes. The Marine? Meh, we'll get to him eventually. <a href="https://www.louderwithcrowder.com/brittney-griner-merchant-death" target="_blank">This is why Weingarten celebrated saving</a> Britney Griner from a Russian prison camp, and not Marine Paul Whelan. Whelan has been imprisoned for four years after falsely being accused of espionage.</p><p>Turns out Randi was repeating the approved narrative. Today during a press briefing, Karine Jean-Pierre wanted everyone to remember what's really important here.</p><p>Do the assclowns working in Joe Biden's White House know how this sounds to anyone who isn't an assclown working in Joe Biden's White House?</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">KJP: "The choice was bring Brittney home or no one. The president will never stop working to secure Paul Whelan's release. On a personal note, Brittney is an important role model, an inspiration to millions of Americans particularly the LGBTQI+ Americans and women of color" <a href="https://t.co/ClbGi6ysbq">pic.twitter.com/ClbGi6ysbq</a><br />— Greg Price (@greg_price11) <a href="https://twitter.com/greg_price11/status/1600913129747419136?ref_src=twsrc%5Etfw">December 8, 2022</a></blockquote> </div><p>Whalen spoke out today too. <a href="https://www.dailymail.co.uk/news/article-11517763/Paul-Whelan-breaks-silence-Russian-penal-colony-Brittney-Griners-release.html" target="_blank">He broke his silence to CNN</a> and was wondering when it was going to be his time.</p><blockquote>'I am greatly disappointed that more has not been done to secure my release, especially as the four-year anniversary of my arrest is coming up. I was arrested for a crime that never occurred. I don't understand why I'm still sitting here My bags are packed. I'm ready to go home. I just need an airplane to come and get me. It's quite obvious that I'm being held hostage.</blockquote><p><a href="https://www.dailymail.co.uk/sport/sportsnews/article-11516861/WNBA-star-Brittney-Griner-RELEASED-Russia-1-1-prisoner-swap.html" target="_blank">This is all on top of the report</a>, albeit one denied by KJP, that we needed Saudi Crown Prince Mohammed bin Salman to negotiate the deal. A deal he negotiated... two days after the U.S. dropped a lawsuit holding him responsible for the murder of journalist Jamal Khashoggi.</p><p>Nevermind all that. Nevermind Joe Biden has made American look weaker and that he can be rolled by any tyrant. The only thing that matters is Democrat virtue signaling to identity politics. </p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">GOT EM': Elon Musk BOOTED a SNITCH at Twitter! | Louder With Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/SMa-UTNJ7qM" target="_blank">youtu.be</a>
</small>
</p>

## Watch: Smug vegan attempts lecturing Piers Morgan about meat, so he eats a steak in front of him
 - [https://www.louderwithcrowder.com/piers-morgan-eat-steak-vegan](https://www.louderwithcrowder.com/piers-morgan-eat-steak-vegan)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-08 18:38:32+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32314703&amp;width=1245&amp;height=700&amp;coordinates=0%2C50%2C0%2C68" /><br /><br /><p>There is an ongoing competition between vegan activists and [schlimate] activists over who can out-douchebag each other. For years, vegan activists had the douche lane all to themselves. But [schlimate] activists have a certain panache about them where they combine douchebaggery with acting like unhinged wackadoodles. Vegans have been upping their performative slacktivism as a result.</p><p>After an incident at a schmancy UK restaurant, Piers Morgan invited one of the vegan leaders to discuss what color the sky is in their world. I didn't catch his name. We'll call him Tofu McSoy. The conversation ended with Morgan eating a steak in front of Soy's smug vegan face. </p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">Piers Morgan Eats STEAK In Front Of Vegan Protester</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/Xlrmfaw_BCI?t=410" target="_blank">youtu.be</a>
</small>
</p><blockquote>I love eating steak. I’m not gonna stop eating steak. And the very last thing on earth that will stop me eating steak is people like you with your pasty faces running into our restaurants, telling us to stop eating steak.</blockquote><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="3f2dc" src="https://www.louderwithcrowder.com/media-library/image.gif?id=32314582&amp;width=980" />
</p><p>ToFu McSoy is with Animal Rebellion, not to be confused with Extinction Rebellion. Both are unhinged leftists who aren't fun to be around, but one is vegan and one is [schlimate]. The ARs <a href="https://www.louderwithcrowder.com/milk-pours-protest" target="_blank">pour milk on the ground of supermarkets and think they are saving cows</a>, who then need to produce more milk to replace the milk the ARs have wasted. The ERs spray fake blood on the sides of buildings in the name of saving the planet, <a href="https://www.louderwithcrowder.com/activists-spray-fake-blood-hilarity" target="_blank">but lose control of the hose because they lack any upper body strength</a>.</p><p>Morgan? He likes steak. As ToFu McSoy was rattling off his talking points, Morgan offered the only response necessary: "Yeah, but meat is delicious."</p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">Democracy Respecter Zelensky WINS Person of the Year?! | Louder With Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/Mydj21dcYKk" target="_blank">youtu.be</a>
</small>
</p>

## Randi Weingarten's garbage tweet about Brittney Griner-Merchant of Death trade belongs in virtue signaling hall of fame
 - [https://www.louderwithcrowder.com/brittney-griner-merchant-death](https://www.louderwithcrowder.com/brittney-griner-merchant-death)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-08 17:19:52+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32314171&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>WNBA star(?) Brittney Griner was released from a Russian prison today after Joe Biden traded a notorious arms dealer for her. We get Brittney and the Russians get Viktor "the Merchant of Death" Bout in the most lopsided trade since the Tennessee Titans traded A.J. Brown for some draft picks. Everyone has strong opinions about the trade, but head union thug Randi Weingarten wants you to remember what's really important. </p><p>Grier checks off THREE boxes on leftists' BINGO card.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">What a great relief!!! Extraordinary news, a basketball star, but also a gay, black woman is released. And yes of course we want other prisoners like Paul Whelan released.<br />— Randi Weingarten 🇺🇦🇺🇸💪🏿👩🎓 (@rweingarten) <a href="https://twitter.com/rweingarten/status/1600845396493811712?ref_src=twsrc%5Etfw">December 8, 2022</a></blockquote> </div><p>"And oh yeah, by the way..." Paul Whelan. The Marine who has been imprisoned for four years.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">It is my contention that, given the speaker, context, and sentiments expressed both wittingly and unwittingly, this tweet instantly enters Culture War Valhalla. <a href="https://t.co/hUKsyOCoJG">pic.twitter.com/hUKsyOCoJG</a><br />— Jeff B. is *BOX OFFICE POISON* (@EsotericCD) <a href="https://twitter.com/EsotericCD/status/1600849675846062083?ref_src=twsrc%5Etfw">December 8, 2022</a></blockquote> </div><p>Crowder and the gang had A LOT to say about this on today's show. A. LOT!</p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">BREAKING: BRITTNEY GRINER SWAPPED FOR WORLD'S MOST DANGEROUS ARMS DEALER! | Louder with Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/6FkILT_O7yw" target="_blank">youtu.be</a>
</small>
</p>

## Watch: Masked bro has hilarious meltdown, threatens to fight guy who stood too close to him without a mask
 - [https://www.louderwithcrowder.com/mask-fight-too-close](https://www.louderwithcrowder.com/mask-fight-too-close)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-08 15:14:39+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32313375&amp;width=1200&amp;height=600&amp;coordinates=0%2C0%2C0%2C82" /><br /><br /><p>If you were afraid that 2022 meant there would be no more mask meltdown videos, we here at the Louder with Crowder Dot Com website have a treat! A masked bro looking to get into a fight with a maskless bro for getting too close to him without a mask. This is at least what we're led to believe is going on based on the description of the viral video.</p><p>I know what you're thinking. "Brodigan, wouldn't getting into a fight with someone who was too close to you not wearing a mask...just get you too close to him?"</p><p>That is correct. Masked bro obviously follows The Science.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Guy with the mask got mad because some guy walked too close to him without wearing a mask 😂 <a href="https://t.co/hAYX41jRfU">pic.twitter.com/hAYX41jRfU</a><br />— Clown World ™ 🤡 (@ClownWorld_) <a href="https://twitter.com/ClownWorld_/status/1600646009515782145?ref_src=twsrc%5Etfw">December 8, 2022</a></blockquote> </div><p>My man's girlfriend was hysterical. Or, probably more accurate, my man's girl who only likes him as a friend.</p><blockquote>"Stop! Don't do this! You're going to go to jail!"</blockquote><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="f5610" src="https://www.louderwithcrowder.com/media-library/image.gif?id=32313517&amp;width=980" />
</p><p>It's remarkable that in 2022, we're <a href="https://www.louderwithcrowder.com/masks-couple-kissing" target="_blank">still doing this mask insanity</a>. Or are we? Like most viral videos, it is unclear as to when this video takes place. That leads us down two parallel but equally hilarious paths.</p><p>The first path is that this video takes place within the first three-hundred and sixty-five days plus fifteen more to flatten the curve. Videos like this where wearing a mask or not wearing a mask <a href="https://www.louderwithcrowder.com/mask-bus-kicked-teen" target="_blank">led to someone catching hands</a> were more common. It's a reminder how we were then, and boy oh boy do people look silly. By "we" I mean "they." If you're reading this, it's safe to assume you did not engage in such lunacy.</p><p>The second path is that this is a recent video, and the tough guy is still in full-blown mask hysteria. Living in this much constant fear, thanks to the government and the media, seems exhausting. I'd feel sorry for him if I wasn't laughing so hard.</p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">Democracy Respecter Zelensky WINS Person of the Year?! | Louder With Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/Mydj21dcYKk" target="_blank">youtu.be</a>
</small>
</p>

## BREAKING: BRITTNEY GRINER SWAPPED FOR WORLD'S MOST DANGEROUS MAN! (Show Notes)
 - [https://www.louderwithcrowder.com/show-notes-brittney-griner](https://www.louderwithcrowder.com/show-notes-brittney-griner)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-08 14:53:55+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=32313471&amp;width=1200&amp;height=800&amp;coordinates=100%2C0%2C100%2C0" /><br /><br /><p>Brittney Griner has been freed & Joe Biden sold out America to do it. Who is the "Merchant of Death" she was traded for? We'll tell you, & it's not good. Also, Jennifer Lawrence is an imbecile. And we have SPECIAL GUEST, Kari Lake to update us on Arizona.</p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">🔴 LIVE Daily Show!!! | Louder with Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://www.youtube.com/watch?v=6FkILT_O7yw" target="_blank">www.youtube.com</a>
</small>
</p>
<p><strong>JENNIFER LAWRENCE</strong></p><ul><li><a href="https://twitter.com/franklinleonard/status/1600547246470467584?s=20&amp;t=8T4lPPS5G5vm0CchSVT3gQ" rel="noopener noreferrer" target="_blank">Jennifer Lawrence says of taking on the role of Katniss in the Hunger Games</a></li></ul><p><strong>BRITTANY GRINER RELEASED FROM GULAG, TRADED FOR LORD OF WAR</strong></p><ul><li><a href="https://www.bbc.com/news/world-europe-63905112" rel="noopener noreferrer" target="_blank">Brittney Griner: Russia frees US basketball star in swap with arms dealer Bout</a></li><li><a href="https://www.bbc.com/news/world-europe-63905112" rel="noopener noreferrer" target="_blank"></a><a href="https://www.cbsnews.com/news/viktor-bout-russia-arms-dealer-merchant-of-death-brittney-griner-paul-whelan/" rel="noopener noreferrer" target="_blank">Who is Viktor Bout? Russian arms dealer known as the "Merchant of Death" swapped for Brittney Griner</a></li><li><a href="https://www.bbc.com/news/world-europe-11036569" rel="noopener noreferrer" target="_blank">Viktor Bout: Who is the Merchant of Death?</a></li><li><a href="https://www.newyorker.com/magazine/2012/03/05/disarming-viktor-bout" rel="noopener noreferrer" target="_blank">Disarming Viktor Bout</a></li><li><a href="https://www.newyorker.com/magazine/2012/03/05/disarming-viktor-bout" rel="noopener noreferrer" target="_blank"></a><a href="https://www.youtube.com/watch?v=4JUzg6CPD_8" rel="noopener noreferrer" target="_blank">Viktor Bout</a><span></span></li><li><a href="https://www.reuters.com/world/us-ex-marine-whelan-still-russian-custody-swap-talks-continue-lawyer-cited-by-2022-12-08/" target="_blank">Reuters</a></li><li><a href="https://www.reuters.com/world/us-ex-marine-whelan-still-russian-custody-swap-talks-continue-lawyer-cited-by-2022-12-08/" rel="noopener noreferrer" target="_blank"></a><a href="https://www.youtube.com/watch?v=Vbg4B-y83d4" rel="noopener noreferrer" target="_blank">Biden Calls for War Crimes Trial Against Putin for Ukraine Atrocities</a><span></span></li></ul><p><strong>ARIZONA RECAP</strong></p><ul><li><a href="https://www.youtube.com/watch?v=zRY_usZlJaw" target="_blank">Decision 2022: Arizona certifies the 2022 election results</a></li><li><a href="https://www.youtube.com/watch?v=zRY_usZlJaw" rel="noopener noreferrer" target="_blank"></a><a href="https://www.azag.gov/sites/default/files/2022-11/221119%20Letter%20to%20Maricopa%20County%20re%202022%20General%20Election%20Administration.pdf" rel="noopener noreferrer" target="_blank">Re: Maricopa County’s Administration of the 2022 General Election</a></li><li><a href="https://trendingpolitics.com/shock-video-arizona-poll-watcher-reveals-200-more-ballots-than-voters-that-came-into-election-location-knab/" rel="noopener noreferrer" target="_blank">Shock Video: Arizona Poll Watcher Reveals 200 More Ballots Than Voters That Came Into Election Location</a></li><li><a href="https://trendingpolitics.com/shock-video-arizona-poll-watcher-reveals-200-more-ballots-than-voters-that-came-into-election-location-knab/" rel="noopener noreferrer" target="_blank"></a><a href="https://twitter.com/maricopacounty/status/1591527781371887618" rel="noopener noreferrer" target="_blank">Twitter: @maricopacounty</a></li><li><a href="https://twitter.com/maricopacounty/status/1591527781371887618" rel="noopener noreferrer" target="_blank"></a><a href="https://twitter.com/maricopacounty/status/1591527779908325376" rel="noopener noreferrer" target="_blank">Twitter: @maricopacounty</a></li><li><a href="https://twitter.com/maricopacounty/status/1591527779908325376" rel="noopener noreferrer" target="_blank"></a><a href="https://azsos.gov/sites/default/files/2021_EPM_Draft_for_Public_Cmt.pdf" rel="noopener noreferrer" target="_blank">ELECTIONS PROCEDURES MANUAL 2021</a></li></ul><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p>

## Reporter shares shocking event that happened at the border while Joe Biden had 'more important things' to do
 - [https://www.louderwithcrowder.com/joe-biden-border](https://www.louderwithcrowder.com/joe-biden-border)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-08 14:13:26+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32313255&amp;width=1200&amp;height=800&amp;coordinates=190%2C0%2C10%2C0" /><br /><br /><p>In case you are wondering, there is still a crisis along our southern border. Critics will say it is a crisis of Joe Biden's creation, what with the crisis starting as soon as Biden assumed office and pushed the policies that led to the crisis. The White House would prefer ignoring the crisis while <a href="https://www.louderwithcrowder.com/bill-melugin-wh-complains" target="_blank">lashing out</a> at anyone who <a href="https://www.louderwithcrowder.com/bill-melugin-wh-complains" target="_blank">reports on the crisis</a>. The key word here? Crisis.</p><p>A quick jaunt to Arizona would have give the president an opportunity to visit the border to see the crisis firsthand. He said he had more important things to do.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Peter Doocy asks Joe Biden why he's going to Arizona, but refuses to visit the border.<br /><br />BIDEN: "Because there's more important things going on!" <a href="https://t.co/rqarRmWYaV">pic.twitter.com/rqarRmWYaV</a><br />— Townhall.com (@townhallcom) <a href="https://twitter.com/townhallcom/status/1600142156152287233?ref_src=twsrc%5Etfw">December 6, 2022</a></blockquote> </div><p>And while Joe Biden was doing his more important things, <a href="https://www.louderwithcrowder.com/biden-robin-williams" target="_blank">like a cheap Mork from Ork impersonation</a>, another border patrol officer died in the line of duty.</p><p><a href="https://twitter.com/BillFOXLA/status/1600643536264695810" target="_blank">Fox News' Bill Melugin reports</a> a Border Patrol agent died after crashing his ATV into a gate while tracking a group of illegal immigrants in the dark. Also, there were more mass illegal crossings, more smuggling, and more sizable seizures of fentanyl.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">An observation on sinking Border Patrol morale.<br /><br />One day after President says the border isn’t important enough to visit, a BP agent dies in line of duty.<br /><br />I have not seen any reaction from the White House re: his death.<br />WH also never apologized for pushing false “whip” claims.<br />— Bill Melugin (@BillFOXLA) <a href="https://twitter.com/BillFOXLA/status/1600658541991559169?ref_src=twsrc%5Etfw">December 8, 2022</a></blockquote> </div><p>Ah, yes. The "whip" claims where a progressive activist accused a border patrol agent of whipping a migrant. <a href="https://www.louderwithcrowder.com/border-patrol-president-smear" target="_blank">Joe Biden threw the agent under the bus</a>... even though it was clear the <a href="https://www.louderwithcrowder.com/video-shows-border-patrol-officer-of-famous-viral-photo-never-whipped-anyone" target="_blank">agent DIDN'T whip anyone</a> and the <a href="https://www.louderwithcrowder.com/border-patrol-whip-migrant-activist" target="_blank">progressive activist was laying</a>. One of the many problems at the border is that progressive activists are the only ones this president is listening to.</p><p>Even other democrats like Rep. Henry Cuellar <a href="https://dailycaller.com/2022/12/07/henry-cuellar-department-of-homeland-security-biden-administration-title-42/" target="_blank">are calling him out on it</a>:</p><blockquote>I know the White House is tying Homeland Security – there’s a lot of career people there that know what job needs to be done. The White House is paying attention only to the immigration activists. Who is paying attention to the men and women in green and blue and who is paying attention to our communities on the border?</blockquote><p>Not the President of the United States, it appears. Not until January 20, 2025.</p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">GOT EM': Elon Musk BOOTED a SNITCH at Twitter! | Louder With Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://www.youtube.com/watch?v=SMa-UTNJ7qM" target="_blank">www.youtube.com</a>
</small>
</p>

## Watch: Unlucky hooligan tries to steal smartphone, discovers what a 'self-locking door' is the hard way
 - [https://www.louderwithcrowder.com/smartphone-theft-locked-door](https://www.louderwithcrowder.com/smartphone-theft-locked-door)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-08 13:36:53+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=32313177&amp;width=1200&amp;height=800&amp;coordinates=200%2C0%2C0%2C0" /><br /><br /><p>It's the holiday shopping season. The Christmas season is to celebrate the birth of Christ. The holiday shopping season is to run up credit card bills buying things and stuff. It can get expensive, and you might ponder the cheaper option of stealing something. Or, suing Ticketmaster when "Santa" couldn't get those Taylor Swift tickets. If you are in the former group, I have three words for you: self-locking doors.</p><p>One hooligan didn't do a proper job of casing the joint out when he attempted to steal a smartphone. He's the cat I've invited you all here to laugh at.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">🤦♂️🤣<a href="https://t.co/ldRLQ7Ti9Y">pic.twitter.com/ldRLQ7Ti9Y</a><br />— Clown World ™ 🤡 (@ClownWorld_) <a href="https://twitter.com/ClownWorld_/status/1600627274415738880?ref_src=twsrc%5Etfw">December 7, 2022</a></blockquote> </div><p>My favorite part of the video is, even with his face blurred, you can see the look of embarrassment on our hooligan friend's face as he slumped back to the counter and handed the phone back. Blaming his "mates" outside who made him do it.</p><p>Also, shout out to the store owner for being in the Christmas spirit and not calling the police. He could have called the coppers, who would have given the hooligan a slap on the wrist and sent him on the way. Instead, the owner gave us all the gift of content by taking the security cam video and putting it out on the line for us to enjoy. He further embarrassed the dinkus who ran into the door as an added bonus. Always remember to do it for the content, folks.</p><p>This hooligan joins "<a href="https://www.louderwithcrowder.com/louis-vuittton-thief-knocked-out" target="_blank">guy who ran into window</a>" and "<a href="https://www.louderwithcrowder.com/jewelry-store-fail" target="_blank">soy boy vs jewelry case</a>" as our dumbest criminals of 2022. Congratulations.</p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">GOT EM': Elon Musk BOOTED a SNITCH at Twitter! | Louder With Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/SMa-UTNJ7qM" target="_blank">youtu.be</a>
</small>
</p>

## 'A really cool part of my job': Dean of Students caught on video bragging about giving sex toys to kids
 - [https://www.louderwithcrowder.com/chicago-private-school-dean-students](https://www.louderwithcrowder.com/chicago-private-school-dean-students)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-12-08 13:03:31+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32312565&amp;width=1245&amp;height=700&amp;coordinates=0%2C2%2C0%2C0" /><br /><br /><p>In the olden days, a bygone era, we used to be able to talk about diversity and inclusion in school without bringing in sex toys or talking about butt stuff. That is not the case at allegedly "elite" Chicago school Francis W. Parker. Joseph Bruno, the Dean of Students there, not only brags about having someone play "show and tell" with sex toys for the students, he says it is the best part about his job. The rub is he made the mistake of saying that to a <a href="https://www.louderwithcrowder.com/teacher-paid-indoctrinating-kids" target="_blank">citizen journalist</a> from <a href="https://www.louderwithcrowder.com/woke-teacher-private-school-defends" target="_blank">Project Veritas</a>.</p><p>It is unclear the age of the students. Bruno is the one who refers to them as "kids."</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">
		BREAKING: <a href="https://twitter.com/fwparker?ref_src=twsrc%5Etfw">@fwparker</a> Dean of Students Brags About Bringing in LGBTQ+ Health Center to Teach "Queer Sex" to Minors<br />
<br />
		"Passing around dildos and butt plugs...kids are just playing with them...Using lube versus using spit...that's a really like, cool part of my job"<br />
<a href="https://twitter.com/hashtag/ExposeGroomers?src=hash&amp;ref_src=twsrc%5Etfw">#ExposeGroomers</a> <a href="https://t.co/oYJlyvQfpq">pic.twitter.com/oYJlyvQfpq</a><br />
		— Project Veritas (@Project_Veritas) <a href="https://twitter.com/Project_Veritas/status/1600656430151135232?ref_src=twsrc%5Etfw">December 8, 2022</a>
</blockquote></div><blockquote>
	I’ve been the Dean for four years. During Pride -- we do a Pride Week every year -- I had our LGBTQ+ Health Center come in. They were passing around butt-plugs and dildos to my students. Talking about queer sex, using lube versus using spit...
</blockquote><p>
	I don't need to explain the lube vs. spit debate, do I? We're all adults here (as opposed to the students at Francis W. Parker)? I don't have to spell it out?
</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="722b2" src="https://www.louderwithcrowder.com/media-library/image.gif?id=32312644&amp;width=980" />
</p><p>
	And while the kids were passing around dildos and butt-plugs asking "how does this butt-plug work," it was then that Bruno realized it was "a really cool part of my job."
</p><p>
	When reached for comment...
</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">
		UPDATE: The school just deleted their Twitter account <a href="https://t.co/JiRQoNY7in">pic.twitter.com/JiRQoNY7in</a><br />
		— Libs of TikTok (@libsoftiktok) <a href="https://twitter.com/libsoftiktok/status/1600661920583143424?ref_src=twsrc%5Etfw">December 8, 2022</a>
</blockquote></div><p>
	Ackshually, the school did send out an email to parents that they stand in full support of the Dean. And blasted the citizen journalists attempting to, quote, "undermine and manipulate Diversity, Equity, Inclusion and Belonging work in schools." Work that they achieve by handing out sex toys to children and engaging them in "lube vs. spit" debates. </p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">
		BREAKING: Fracis W. Parker School in Chicago, IL - where the Dean of Students Joseph Bruno was caught on video talking about giving students butt plugs and dildos- sent out this email to parents saying that they stand in full support of the Dean. <a href="https://t.co/isHOxfLEQK">pic.twitter.com/isHOxfLEQK</a><br />
		— Libs of TikTok (@libsoftiktok) <a href="https://twitter.com/libsoftiktok/status/1600705953800024067?ref_src=twsrc%5Etfw">December 8, 2022</a>
</blockquote></div><p>Pride Month is every June when we are told to appreciate the contributions of Ls, Gs, Bs, especially the Ts, Qa, As, Is, other Is, Ps, and whatever the hell the pluses are to society. To question anything makes you a -phobic, depending on which specific letter you are being -phobic against. And I'd hate to be considered [solve for x]-phobic in any way.</p><p>I'm just wondering if parents and administrators would think it would be as appropriate for a cisgender hetero person to be teaching kids how to use butt plugs. Or that to celebrate the small business entrepreneurial spirit of Americans, the owner of the Hustler Store was brought in to show off dildos. Because if your answer to any of this is anything other than "no," you're sick.</p><p><p>
<em><strong>Editor’s Note</strong>
</em>
</p>
<p>
<em><strong><a href="https://lwcnewswire.substack.com/" target="_blank">LwC is on Substack now</a></strong>! Each day we overwhelm your brains with the content you've come to love from the Louder with Crowder Dot Com website.. but algorithms hide our ranting and raving as best they can. The best way to stick it to Big Tech? </em><strong><a href="https://lwcnewswire.substack.com/" target="_blank"><em>Subscribe to For the Content!</em></a></strong>
</p></p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">Democracy Respecter Zelensky WINS Person of the Year?! | Louder With Crowder</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/Mydj21dcYKk" target="_blank">youtu.be</a>
</small>
</p>


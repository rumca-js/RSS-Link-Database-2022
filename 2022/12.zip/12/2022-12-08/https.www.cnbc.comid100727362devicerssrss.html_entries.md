# Source:CNBC, URL:https://www.cnbc.com/id/100727362/device/rss/rss.html, language:en-US

## Turkey is stopping oil not under Russian sanctions, raising global energy market supply concerns
 - [https://www.cnbc.com/2022/12/08/turkey-stops-oil-not-under-russian-sanctions-upping-energy-supply-fears.html](https://www.cnbc.com/2022/12/08/turkey-stops-oil-not-under-russian-sanctions-upping-energy-supply-fears.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-08 22:50:02+00:00

Much of the oil being held up by Turkey is Kazakh-origin and not subject to a Russian crude price cap, but shipment delays may impact the global energy market.

## Harry and Meghan hit out at 'exploitation and bribery' of UK media in new Netflix documentary
 - [https://www.cnbc.com/2022/12/08/harry-and-meghan-lash-out-at-uk-media-in-new-netflix-documentary.html](https://www.cnbc.com/2022/12/08/harry-and-meghan-lash-out-at-uk-media-in-new-netflix-documentary.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-08 16:57:43+00:00

Prince Harry and Meghan Markle hit out at what they called the "exploitation and bribery" of the British press in a new Netflix documentary released Thursday.

## FTX spokesman Kevin O'Leary says he lost his $15 million payday from crypto firm
 - [https://www.cnbc.com/2022/12/08/ftx-spokesman-kevin-oleary-says-he-lost-15-million-crypto-payday.html](https://www.cnbc.com/2022/12/08/ftx-spokesman-kevin-oleary-says-he-lost-15-million-crypto-payday.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-08 16:30:30+00:00

Kevin O'Leary made millions as an FTX spokesman, but he says he's lost it all after the bankruptcy of the crypto exchange.

## Europe’s energy grids face first major winter stress test as Arctic blast takes hold
 - [https://www.cnbc.com/2022/12/08/winter-cold-temperatures-pose-first-test-for-europes-energy-grids.html](https://www.cnbc.com/2022/12/08/winter-cold-temperatures-pose-first-test-for-europes-energy-grids.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-08 13:12:55+00:00

Temperatures across the Nordic countries and central and eastern Europe are also set to drop to close to or below freezing over the coming days.

## Tech layoffs in Southeast Asia mount as unprofitable startups seek to extend their runways
 - [https://www.cnbc.com/2022/12/08/tech-layoffs-in-southeast-asia-grow-as-unprofitable-startups-extend-runways.html](https://www.cnbc.com/2022/12/08/tech-layoffs-in-southeast-asia-grow-as-unprofitable-startups-extend-runways.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2022-12-08 13:12:22+00:00

Tech layoffs have been increasing in Southeast Asia as growth slows down. Existing investors are also pushing startups to extend their runways.


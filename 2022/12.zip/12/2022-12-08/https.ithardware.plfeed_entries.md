# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Rosja wprowadziła w życie prawo, które zabrania gier "szerzących propagandę LGBT"
 - [https://ithardware.pl/aktualnosci/rosja_wprowadzila_w_zycie_prawo_ktore_zabrania_gier_szerzacych_propagande_lgbt-24762.html](https://ithardware.pl/aktualnosci/rosja_wprowadzila_w_zycie_prawo_ktore_zabrania_gier_szerzacych_propagande_lgbt-24762.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 22:42:17+00:00

<img src="https://ithardware.pl/artykuly/min/24762_1.jpg" />            Pod koniec października BBC informowało, że Rosja rozszerzy&nbsp;zakaz &quot;propagandy LGBT&quot; na wszystkich dorosłych, do czego doszło ostatnio za sprawą wprowadzonych w życie regulacji.

Prezydent Federacji Rosyjskiej, Władimir Putin...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rosja_wprowadzila_w_zycie_prawo_ktore_zabrania_gier_szerzacych_propagande_lgbt-24762.html">https://ithardware.pl/aktualnosci/rosja_wprowadzila_w_zycie_prawo_ktore_zabrania_gier_szerzacych_propagande_lgbt-24762.html</a></p>

## iQOO 11 i iQOO 11 Pro zadebiutowały w Chinach. Oto, co oferują nowe flagowe smartfony
 - [https://ithardware.pl/aktualnosci/iqoo_11_i_iqoo_11_pro_zadebiutowaly_w_chinach_oto_co_oferuja_nowe_flagowe_smartfony-24761.html](https://ithardware.pl/aktualnosci/iqoo_11_i_iqoo_11_pro_zadebiutowaly_w_chinach_oto_co_oferuja_nowe_flagowe_smartfony-24761.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 21:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/24761_1.jpg" />            Smartfony z serii iQOO 11 i iQOO 11 Pro zadebiutowały na rynku w Chinach. Oto specyfikacja telefon&oacute;w, kt&oacute;re zechcą powalczyć o portfele klient&oacute;w z innymi flagowcami.

Zgodnie z przeciekami smartfony&nbsp;iQOO 11 i iQOO 11 Pro...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/iqoo_11_i_iqoo_11_pro_zadebiutowaly_w_chinach_oto_co_oferuja_nowe_flagowe_smartfony-24761.html">https://ithardware.pl/aktualnosci/iqoo_11_i_iqoo_11_pro_zadebiutowaly_w_chinach_oto_co_oferuja_nowe_flagowe_smartfony-24761.html</a></p>

## AOMEI idzie śladami Epic Games. Firma rozdaje za darmo programy warte 1300 dolarów
 - [https://ithardware.pl/aktualnosci/aomei_idzie_sladami_epic_games_firma_rozdaje_za_darmo_programy_warte_1300_dolarow-24759.html](https://ithardware.pl/aktualnosci/aomei_idzie_sladami_epic_games_firma_rozdaje_za_darmo_programy_warte_1300_dolarow-24759.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 20:32:50+00:00

<img src="https://ithardware.pl/artykuly/min/24759_1.jpg" />            W ramach akcji świątecznej, firma AOMEI rozdaje swoje oprogramowanie za darmo. Na liście objętych promocją program&oacute;w odnajdziemy aż 21 pozycji o łącznej wartości 1300 dolar&oacute;w. Osoby, kt&oacute;re skorzystają z oferty dostaną...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/aomei_idzie_sladami_epic_games_firma_rozdaje_za_darmo_programy_warte_1300_dolarow-24759.html">https://ithardware.pl/aktualnosci/aomei_idzie_sladami_epic_games_firma_rozdaje_za_darmo_programy_warte_1300_dolarow-24759.html</a></p>

## Nadchodzi nowa gra z serii Uncharted. Nie będzie to jednak ani remake ani remaster
 - [https://ithardware.pl/aktualnosci/nadchodzi_nowa_gra_z_serii_uncharted_nie_bedzie_to_jednak_ani_remake_ani_remaster-24760.html](https://ithardware.pl/aktualnosci/nadchodzi_nowa_gra_z_serii_uncharted_nie_bedzie_to_jednak_ani_remake_ani_remaster-24760.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 19:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/24760_1.jpg" />            Seria Uncharted po premierze samodzielnego dodatku do czwartej części pozostaje w cieniu. Nie oznacza to jednak, że nowa gra związana z przygodami Natana Drake'a nie powstaje, wręcz przeciwnie.

W ostatnim czasie pisano o nowej grze z serii...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nadchodzi_nowa_gra_z_serii_uncharted_nie_bedzie_to_jednak_ani_remake_ani_remaster-24760.html">https://ithardware.pl/aktualnosci/nadchodzi_nowa_gra_z_serii_uncharted_nie_bedzie_to_jednak_ani_remake_ani_remaster-24760.html</a></p>

## MediaTek Dimensity 8200 oficjalnie. Świetny procesor dla mocniejszych średniaków?
 - [https://ithardware.pl/aktualnosci/mediatek_dimensity_8200_oficjalnie_swietny_procesor_dla_mocniejszych_sredniakow-24758.html](https://ithardware.pl/aktualnosci/mediatek_dimensity_8200_oficjalnie_swietny_procesor_dla_mocniejszych_sredniakow-24758.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 18:35:20+00:00

<img src="https://ithardware.pl/artykuly/min/24758_1.jpg" />            MediaTek przedstawił swoje najnowsze dzieło, czyli układ Dimensity 8200. Procesor korzysta z litografii 4 nm, a jego najwydajniejszy rdzeń -&nbsp;Cortex-A78 - pracuje z częstotliwością&nbsp;3.1 GHz. Ponadto zastosowano...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mediatek_dimensity_8200_oficjalnie_swietny_procesor_dla_mocniejszych_sredniakow-24758.html">https://ithardware.pl/aktualnosci/mediatek_dimensity_8200_oficjalnie_swietny_procesor_dla_mocniejszych_sredniakow-24758.html</a></p>

## Intel Core i9-13900KS - taktowanie 6 GHz zostało potwierdzone. Przeraża jednak TDP
 - [https://ithardware.pl/aktualnosci/intel_core_i9_13900ks_taktowanie_6_ghz_zostalo_potwierdzone_przeraza_jednak_tdp-24756.html](https://ithardware.pl/aktualnosci/intel_core_i9_13900ks_taktowanie_6_ghz_zostalo_potwierdzone_przeraza_jednak_tdp-24756.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 17:45:40+00:00

<img src="https://ithardware.pl/artykuly/min/24756_1.jpg" />            Jeden z informator&oacute;w udostępnił planszę pochodzącą najpewniej od Intela, kt&oacute;ra zawiera&nbsp;kilka procesor&oacute;w Raptor Lake wraz z ich szczeg&oacute;łową specyfikacją. Co najważniejsze, widnieje na niej model Core i9-13900KS,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_core_i9_13900ks_taktowanie_6_ghz_zostalo_potwierdzone_przeraza_jednak_tdp-24756.html">https://ithardware.pl/aktualnosci/intel_core_i9_13900ks_taktowanie_6_ghz_zostalo_potwierdzone_przeraza_jednak_tdp-24756.html</a></p>

## Unia Europejska ujawniła, od kiedy producenci będą musieli stosować USB-C w swoich urządzeniach
 - [https://ithardware.pl/aktualnosci/unia_europejska_ujawnila_od_kiedy_producenci_beda_musieli_stosowac_usb_c_w_swoich_urzadzeniach-24757.html](https://ithardware.pl/aktualnosci/unia_europejska_ujawnila_od_kiedy_producenci_beda_musieli_stosowac_usb_c_w_swoich_urzadzeniach-24757.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 17:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/24757_1.jpg" />            Unia Europejska zdradziła, od kiedy producenci urządzeń mobilnych muszą dostosować się do nowych przepis&oacute;w i wprowadzić do sprzedaży modele wyposażone w wejście USB typu C.

Wprowadzenie jednego standardu ładowania dla wszystkich...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/unia_europejska_ujawnila_od_kiedy_producenci_beda_musieli_stosowac_usb_c_w_swoich_urzadzeniach-24757.html">https://ithardware.pl/aktualnosci/unia_europejska_ujawnila_od_kiedy_producenci_beda_musieli_stosowac_usb_c_w_swoich_urzadzeniach-24757.html</a></p>

## Do sieci trafiły nowe rendery składanego telefonu od Google. Poznaliśmy także jego wymiary
 - [https://ithardware.pl/aktualnosci/do_sieci_trafily_nowe_rendery_skladanego_telefonu_od_google_poznalismy_takze_jego_wymiary-24755.html](https://ithardware.pl/aktualnosci/do_sieci_trafily_nowe_rendery_skladanego_telefonu_od_google_poznalismy_takze_jego_wymiary-24755.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 16:15:20+00:00

<img src="https://ithardware.pl/artykuly/min/24755_1.jpg" />            W internecie pojawiły się nowe przecieki dotyczące nadchodzącego składanego telefonu od Google. Udostępnione zostały kolejne rendery Pixela Fold w dw&oacute;ch wersjach kolorystycznych. Co więcej poznaliśmy nieoficjalne wymiary urządzenia....
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/do_sieci_trafily_nowe_rendery_skladanego_telefonu_od_google_poznalismy_takze_jego_wymiary-24755.html">https://ithardware.pl/aktualnosci/do_sieci_trafily_nowe_rendery_skladanego_telefonu_od_google_poznalismy_takze_jego_wymiary-24755.html</a></p>

## Elektryczny Mercedes-Benz eSprinter przejechał 475 km przy zużyciu zaledwie 21,9 kWh/100 km
 - [https://ithardware.pl/aktualnosci/elektryczny_mercedes_benz_esprinter_przejechal_475_km_przy_zuzyciu_zaledwie_21_9_kwh_100_km-24736.html](https://ithardware.pl/aktualnosci/elektryczny_mercedes_benz_esprinter_przejechal_475_km_przy_zuzyciu_zaledwie_21_9_kwh_100_km-24736.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 15:32:50+00:00

<img src="https://ithardware.pl/artykuly/min/24736_1.jpg" />            Mercedes-Benz przygotowuje nową generację elektrycznych samochod&oacute;w dostawczych eSprinter, a ten o największej pojemności został przetestowany i przejechał ponadprzeciętne 475 km na jednym ładowaniu.&nbsp;Wszystko to przy niewiarygodnym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/elektryczny_mercedes_benz_esprinter_przejechal_475_km_przy_zuzyciu_zaledwie_21_9_kwh_100_km-24736.html">https://ithardware.pl/aktualnosci/elektryczny_mercedes_benz_esprinter_przejechal_475_km_przy_zuzyciu_zaledwie_21_9_kwh_100_km-24736.html</a></p>

## Tesla przywróci radary w samochodach i to już w przyszłym roku. Kamery to jednak za mało?
 - [https://ithardware.pl/aktualnosci/tesla_przywroci_radary_w_samochodach_i_to_juz_w_przyszlym_roku_kamery_to_jednak_za_malo-24754.html](https://ithardware.pl/aktualnosci/tesla_przywroci_radary_w_samochodach_i_to_juz_w_przyszlym_roku_kamery_to_jednak_za_malo-24754.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 15:12:20+00:00

<img src="https://ithardware.pl/artykuly/min/24754_1.jpg" />            Doniesienia o wypadkach z udziałem samochod&oacute;w Tesli, kt&oacute;re działały w trybie p&oacute;łautonomicznym, zrodziły podejrzenia, że winę za ten fakt ponosi coraz uboższy zestaw czujnik&oacute;w, w kt&oacute;re wyposażane są pojazdy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tesla_przywroci_radary_w_samochodach_i_to_juz_w_przyszlym_roku_kamery_to_jednak_za_malo-24754.html">https://ithardware.pl/aktualnosci/tesla_przywroci_radary_w_samochodach_i_to_juz_w_przyszlym_roku_kamery_to_jednak_za_malo-24754.html</a></p>

## Test ASRock Z790 PG Lightning/D4. Tania płyta główna dla Intel Core 13. gen z DDR4
 - [https://ithardware.pl/testyirecenzje/asrock_z790_pg_lightning_d4_test_recenzja_opinia-24606.html](https://ithardware.pl/testyirecenzje/asrock_z790_pg_lightning_d4_test_recenzja_opinia-24606.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 15:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/24606_1.jpg" />            ASRock Z790 PG Lightning/D4 - test

Choć większość płyt gł&oacute;wnych na chipsecie Intel Z790 to relatywnie drogie modele, z ceną wyraźnie ponad 1000 zł, to jednak w sprzedaży można odnaleźć r&oacute;wnież tańsze konstrukcje, a jedną...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/asrock_z790_pg_lightning_d4_test_recenzja_opinia-24606.html">https://ithardware.pl/testyirecenzje/asrock_z790_pg_lightning_d4_test_recenzja_opinia-24606.html</a></p>

## Tego jeszcze nie grali. Doom uruchomiony na... bombce chionkowej
 - [https://ithardware.pl/aktualnosci/tego_jeszcze_nie_grali_doom_uruchomiony_na_bombce_chionkowej-24750.html](https://ithardware.pl/aktualnosci/tego_jeszcze_nie_grali_doom_uruchomiony_na_bombce_chionkowej-24750.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 13:47:01+00:00

<img src="https://ithardware.pl/artykuly/min/24750_1.jpg" />            Tego jeszcze nie grali, choć w tym przypadku powinniśmy napisać raczej, że&hellip; na tym jeszcze nie grali, bo ktoś postanowił uruchomić klasycznego Dooma na bombce choinkowej.

Ozdoby choinkowe są dostępne we wszystkich kształtach i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tego_jeszcze_nie_grali_doom_uruchomiony_na_bombce_chionkowej-24750.html">https://ithardware.pl/aktualnosci/tego_jeszcze_nie_grali_doom_uruchomiony_na_bombce_chionkowej-24750.html</a></p>

## Wynik Radeona RX 7900 XT z popularnego benchmarka nieco rozczarowuje
 - [https://ithardware.pl/aktualnosci/wynik_radeona_rx_7900_xt_z_popularnego_benchmarka_nieco_rozczarowuje-24749.html](https://ithardware.pl/aktualnosci/wynik_radeona_rx_7900_xt_z_popularnego_benchmarka_nieco_rozczarowuje-24749.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 12:31:01+00:00

<img src="https://ithardware.pl/artykuly/min/24749_1.jpg" />            Dużymi krokami zbliżamy się do premiery nowej generacji kart graficznych AMD, bazujących na architekturze RDNA 3. Duet Radeona RX 7900 XTX i 7900 XT wyceniono na odpowiednio 999 USD i 899 USD i ma on mierzyć się z GeForcem RTX 4080 za 1199...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wynik_radeona_rx_7900_xt_z_popularnego_benchmarka_nieco_rozczarowuje-24749.html">https://ithardware.pl/aktualnosci/wynik_radeona_rx_7900_xt_z_popularnego_benchmarka_nieco_rozczarowuje-24749.html</a></p>

## Główny prawnik Twittera wyrzucony za udział w cenzurowaniu historii laptopa Huntera Bidena
 - [https://ithardware.pl/aktualnosci/glowny_prawnik_twittera_wyrzucony_za_cenzurowanie_historii_laptopa_huntera_bidena-24742.html](https://ithardware.pl/aktualnosci/glowny_prawnik_twittera_wyrzucony_za_cenzurowanie_historii_laptopa_huntera_bidena-24742.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 11:54:00+00:00

<img src="https://ithardware.pl/artykuly/min/24742_1.jpg" />            Dyrektor generalny Twittera,&nbsp;Elon Musk&nbsp;, zwolnił gł&oacute;wnego radcę prawnego firmy Jamesa &bdquo;Jima&rdquo; Bakera za ukrywanie&nbsp;wewnętrznych dokument&oacute;w szczeg&oacute;łowo opisujących tłumienie przez Twittera historii...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/glowny_prawnik_twittera_wyrzucony_za_cenzurowanie_historii_laptopa_huntera_bidena-24742.html">https://ithardware.pl/aktualnosci/glowny_prawnik_twittera_wyrzucony_za_cenzurowanie_historii_laptopa_huntera_bidena-24742.html</a></p>

## Atari wskrzesza grę, która była za trudna dla graczy 40 lat temu
 - [https://ithardware.pl/aktualnosci/atari_wskrzesza_gre_ktora_byla_za_trudna_dla_graczy_40_lat_temu-24748.html](https://ithardware.pl/aktualnosci/atari_wskrzesza_gre_ktora_byla_za_trudna_dla_graczy_40_lat_temu-24748.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 11:47:01+00:00

<img src="https://ithardware.pl/artykuly/min/24748_1.jpg" />            Atari wskrzesza Akka Arrh, grę zręcznościową z 1982 roku, kt&oacute;ra została anulowana, ponieważ testerzy uznali ją za zbyt trudną. Przy remake'u tego wave shootera wydawca wsp&oacute;łpracuje z programistą Jeffem Minterem, kt&oacute;rego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/atari_wskrzesza_gre_ktora_byla_za_trudna_dla_graczy_40_lat_temu-24748.html">https://ithardware.pl/aktualnosci/atari_wskrzesza_gre_ktora_byla_za_trudna_dla_graczy_40_lat_temu-24748.html</a></p>

## Wi-Fi 6 czy Wi-Fi 6E? Który standard będzie najlepszy?
 - [https://ithardware.pl/artykuly/wifi6_vs_wifi6e_jaki_lepszy-24654.html](https://ithardware.pl/artykuly/wifi6_vs_wifi6e_jaki_lepszy-24654.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 11:23:50+00:00

<img src="https://ithardware.pl/artykuly/min/24654_1.jpg" />            Standard połączenia bezprzewodowego Wi-Fi nieustannie ewoluuje i postęp jest zauważalny gołym okiem. Niegdyś nowością absolutną było Wi-Fi 5 (ac), kt&oacute;re dzięki paśmie 5 GHz na stałe przyjęło się w naszych domach, zamieniając tym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/wifi6_vs_wifi6e_jaki_lepszy-24654.html">https://ithardware.pl/artykuly/wifi6_vs_wifi6e_jaki_lepszy-24654.html</a></p>

## TikTok całkowicie zakazany na Tajwanie i w kilku stanach USA u pracowników sektora publicznego
 - [https://ithardware.pl/aktualnosci/tiktok_calkowicie_zakazany_na_tajwanie_i_w_kilku_stanach_usa_u_pracownikow_sektora_publicznego-24753.html](https://ithardware.pl/aktualnosci/tiktok_calkowicie_zakazany_na_tajwanie_i_w_kilku_stanach_usa_u_pracownikow_sektora_publicznego-24753.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 10:29:10+00:00

<img src="https://ithardware.pl/artykuly/min/24753_1.jpg" />            Tajwan oraz niekt&oacute;re stan&oacute;w USA zakazało używania chińskiej platformy TikTok na urządzeniach z sektora publicznego, w obawie o bezpieczeństwo narodowe.&nbsp;Komisarz FCC USA pochwalił posunięcie Tajwanu jako...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tiktok_calkowicie_zakazany_na_tajwanie_i_w_kilku_stanach_usa_u_pracownikow_sektora_publicznego-24753.html">https://ithardware.pl/aktualnosci/tiktok_calkowicie_zakazany_na_tajwanie_i_w_kilku_stanach_usa_u_pracownikow_sektora_publicznego-24753.html</a></p>

## GeForce RTX 4070 Ti prawdopodobnie zachowa także cenę GeForce'a RTX 4080 12 GB
 - [https://ithardware.pl/aktualnosci/geforce_rtx_4070_ti_prawdopodobnie_zachowa_takze_cene_geforce_a_rtx_4080_12_gb-24746.html](https://ithardware.pl/aktualnosci/geforce_rtx_4070_ti_prawdopodobnie_zachowa_takze_cene_geforce_a_rtx_4080_12_gb-24746.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 10:07:01+00:00

<img src="https://ithardware.pl/artykuly/min/24746_1.jpg" />            Okazuje się NVIDIA rozważa wprowadzenie na rynek karty GeForce RTX 4070 Ti w sugerowanej cenie detalicznej 899 USD. Jest to cena, kt&oacute;ra jest obecnie przekazywana partnerom.&nbsp;

Przy sugerowanej cenie detalicznej Founder's Edition...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_4070_ti_prawdopodobnie_zachowa_takze_cene_geforce_a_rtx_4080_12_gb-24746.html">https://ithardware.pl/aktualnosci/geforce_rtx_4070_ti_prawdopodobnie_zachowa_takze_cene_geforce_a_rtx_4080_12_gb-24746.html</a></p>

## Hikvision prezentuje swoje pierwsze moduły pamięci DDR5. Wysoka wydajność w przystępnej cenie
 - [https://ithardware.pl/aktualnosci/hikvision_prezentuje_swoje_pierwsze_moduly_pamieci_ddr5_wysoka_wydajnosc_w_przystepnej_cenie-24752.html](https://ithardware.pl/aktualnosci/hikvision_prezentuje_swoje_pierwsze_moduly_pamieci_ddr5_wysoka_wydajnosc_w_przystepnej_cenie-24752.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 09:57:30+00:00

<img src="https://ithardware.pl/artykuly/min/24752_1.jpg" />            Hikvision, lider branży Security, regularnie rozszerza swoją ofertę o nowe produkty, w tym podzespoły skierowane do graczy. Tym razem producent z dumą prezentuje swoje pierwsze pamięci RAM DDR5, kt&oacute;re trafiają na rynek w ramach serii...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hikvision_prezentuje_swoje_pierwsze_moduly_pamieci_ddr5_wysoka_wydajnosc_w_przystepnej_cenie-24752.html">https://ithardware.pl/aktualnosci/hikvision_prezentuje_swoje_pierwsze_moduly_pamieci_ddr5_wysoka_wydajnosc_w_przystepnej_cenie-24752.html</a></p>

## Apple Car jednak nie w pełni autonomiczny? Przecieki zdradzają szczegóły, w tym cenę i datę premiery
 - [https://ithardware.pl/aktualnosci/apple_car_jednak_nie_w_pelni_autonomiczny_przecieki_zdradzaja_szczegoly_w_tym_cene_i_date_premiery-24747.html](https://ithardware.pl/aktualnosci/apple_car_jednak_nie_w_pelni_autonomiczny_przecieki_zdradzaja_szczegoly_w_tym_cene_i_date_premiery-24747.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 09:18:01+00:00

<img src="https://ithardware.pl/artykuly/min/24747_1.jpg" />            Od lat piszemy o autonomicznym samochodzie Apple, znanym r&oacute;wnież jako Project Titan, bo pierwsze doniesienia na jego temat pojawiły się 2015 roku (projekt zainicjowano w 2014 roku). To naprawdę kawał czasu w tej branży, ale według nowych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_car_jednak_nie_w_pelni_autonomiczny_przecieki_zdradzaja_szczegoly_w_tym_cene_i_date_premiery-24747.html">https://ithardware.pl/aktualnosci/apple_car_jednak_nie_w_pelni_autonomiczny_przecieki_zdradzaja_szczegoly_w_tym_cene_i_date_premiery-24747.html</a></p>

## Microsoft zdradził datę premiery Diablo IV. Gra zadebiutuje później niż się spodziewaliśmy
 - [https://ithardware.pl/aktualnosci/microsoft_zdradzil_date_premiery_diablo_iv_gra_zadebiutuje_pozniej_niz_sie_spodziewalismy-24745.html](https://ithardware.pl/aktualnosci/microsoft_zdradzil_date_premiery_diablo_iv_gra_zadebiutuje_pozniej_niz_sie_spodziewalismy-24745.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 08:45:40+00:00

<img src="https://ithardware.pl/artykuly/min/24745_1.jpg" />            W ostatnich miesiącach nie brakowało przeciek&oacute;w dotyczących Diablo 4. Teraz, tuż przed spodziewanym oficjalnym ogłoszeniem daty premiery gry na The Game Awards, pojawił się kolejny wyciek, kt&oacute;ra zdaje się zdradzać kilka...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_zdradzil_date_premiery_diablo_iv_gra_zadebiutuje_pozniej_niz_sie_spodziewalismy-24745.html">https://ithardware.pl/aktualnosci/microsoft_zdradzil_date_premiery_diablo_iv_gra_zadebiutuje_pozniej_niz_sie_spodziewalismy-24745.html</a></p>

## Nie masz pomysłu na prezent? Sprawdź świąteczną akcję x-komie. Trwa też promocja na laptopy Gigabyte
 - [https://ithardware.pl/aktualnosci/nie_masz_pomyslu_na_prezent_sprawdz_swiateczna_akcje_x_komie_trwa_tez_promocja_na_laptopy_gigabyte-24744.html](https://ithardware.pl/aktualnosci/nie_masz_pomyslu_na_prezent_sprawdz_swiateczna_akcje_x_komie_trwa_tez_promocja_na_laptopy_gigabyte-24744.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 08:17:10+00:00

<img src="https://ithardware.pl/artykuly/min/24744_1.jpg" />            Święta za pasem, a Ty nie masz jeszcze pomysł&oacute;w na prezent? Sprawdź propozycje w sklepach x-kom, al.to oraz na combat.pl. Ponadto w x-komie możesz skorzystać z rabatu na laptopy Gigabyte oraz wielu innych promocji. Wszystkie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nie_masz_pomyslu_na_prezent_sprawdz_swiateczna_akcje_x_komie_trwa_tez_promocja_na_laptopy_gigabyte-24744.html">https://ithardware.pl/aktualnosci/nie_masz_pomyslu_na_prezent_sprawdz_swiateczna_akcje_x_komie_trwa_tez_promocja_na_laptopy_gigabyte-24744.html</a></p>

## Nowy sterownik Intela dla kart graficznych Arc podwaja wydajność w CS:GO
 - [https://ithardware.pl/aktualnosci/nowy_sterownik_intela_dla_kart_graficznych_arc_podwaja_wydajnosc_w_cs_go-24743.html](https://ithardware.pl/aktualnosci/nowy_sterownik_intela_dla_kart_graficznych_arc_podwaja_wydajnosc_w_cs_go-24743.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 07:13:07+00:00

<img src="https://ithardware.pl/artykuly/min/24743_1.png" />            Intel udostępnił nowy sterownik dla swoich kart graficznych Arc, kt&oacute;ry przynosi bardzo duży wzrost wydajności w starszych tytułach, korzystających z API DirectX 9.&nbsp;

Karty graficzne Intel Arc A7 zadebiutowały na rynku niecałe dwa...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowy_sterownik_intela_dla_kart_graficznych_arc_podwaja_wydajnosc_w_cs_go-24743.html">https://ithardware.pl/aktualnosci/nowy_sterownik_intela_dla_kart_graficznych_arc_podwaja_wydajnosc_w_cs_go-24743.html</a></p>

## Konkurs adwentowy z ITHardware! - Dzień #8
 - [https://ithardware.pl/aktualnosci/konkurs_adwentowy_2022_dzien_8-24707.html](https://ithardware.pl/aktualnosci/konkurs_adwentowy_2022_dzien_8-24707.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-12-08 06:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/24707_1.jpg" />            Kontynuujemy nasz ekscytujący Konkurs Adwentowy, w kt&oacute;rym codziennie do wygrania jest nowa nagroda. Co można zgarnąć dziś? Myszkę gamingową Genesis Krypton 555 oraz podkładkę Genesis Carbon 500 MAXI!

&nbsp;

&nbsp;

Nagroda -...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/konkurs_adwentowy_2022_dzien_8-24707.html">https://ithardware.pl/aktualnosci/konkurs_adwentowy_2022_dzien_8-24707.html</a></p>


# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## Ugly Sweater Fashion Statement
 - [https://www.youtube.com/watch?v=8skfT_KEkKY](https://www.youtube.com/watch?v=8skfT_KEkKY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-12-08 00:00:00+00:00

This fashion makes a statement. Help us help @sickkidsfoundation 💙. https://fundthefight.ca/sweaterlove


# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Hurray For The Riff Raff Live at the 9:30 Club - NPR Music's 15th Anniversary Concert
 - [https://www.youtube.com/watch?v=4u4rXzIw8JE](https://www.youtube.com/watch?v=4u4rXzIw8JE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2022-12-08 14:56:06+00:00

Stephen Thompson | December 8, 2022
Hurray for the Riff Raff was a natural pick for NPR Music's 15th-anniversary celebration, given that we've been following Alynda Segarra's eternally shape-shifting roots-rock band for almost as long as we've been around. Segarra just released HFTRR's eighth album, LIFE ON EARTH, earlier this year, and its songs of survival, community and rediscovery translated to a fiery, inspired set at Washington, D.C.'s 9:30 Club.

SET LIST:
"PIERCED ARROWS"
"RHODODENDRON"
"POINTED AT THE SUN"
"SAGA"
"ROSEMARY TEARS"

MUSICIANS:
Alynda Segarra 
Howe Pearson 
Matthew (Skinner) Peterson
Daniel (Yan) Westerlund

CREDITS:
Producer: Lia Camille Crockett; Live Video Director: Mito Habe-Evans; Videographers: Tsering Bista, Joshua Bryant, Kara Frame, Nickolai Hammar, Nick Michael, Maia Stern; Video Production Assistants: Sofia Seidel, Christina Shaman; Editor: Nickolai Hammar; Graphics: Alicia Zheng; Associate Producer: Elle Mannion; Events Team: Gianna Capadona, Devon Williams; Senior Streaming Engineer: Bruce Grant; Streaming Engineers: Erin Gannon, Allen Walden; Mastering Engineer; Josh Rogosin; Audio Assistant: Neil Tevault; Front of House at 9:30 Club: Shawn "Gus" Vitale; Sr. Director of Events & Experiential: Jessica Goldstein; Stage Manager: Peggy Dahlquist; Rights Clearance Consultant: Jackie Sussman; Emcee/DJ: Bobby "DJ Cuzzin B" Carter; Deputy Director, NPR Music: Otis Hart; Executive Producers: Anya Grundmann, Keith Jenkins; Special Thanks to: 9:30 Club, WAMU


#nprmusic #hurrayfortheriffraff


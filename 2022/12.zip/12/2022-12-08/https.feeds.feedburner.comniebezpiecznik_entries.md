# Source:Niebezpiecznik, URL:https://feeds.feedburner.com/niebezpiecznik/, language:pl-PL

## * Konferencja In2Security
 - [https://niebezpiecznik.pl/post/konferencja-in2security/](https://niebezpiecznik.pl/post/konferencja-in2security/)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2022-12-08 07:45:39+00:00

<a href="https://niebezpiecznik.pl/post/konferencja-in2security/"><img align="left" alt="" class="alignleft wp-post-image tfe" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2022/12/In2Security2022-150x150.png" title="" width="100" /></a>Końcówka roku, to wysyp konferencji. Oto kolejna! :-) 10 grudnia na wydziale Automatyki Elektroniki i Informatyki Politechniki Śląskiej w Gliwicach odbędzie się In2Security, na którą serdecznie Was zapraszamy! Konferencja to 2 ścieżki tematyczne, 12 prelegentów i 12 prelekcji wypełnionych wiedzą. Ścieżka techniczna &#8211; dla osób chcących pogłębić i poszerzyć swoją wiedzę oraz nawiązać ciekawe kontakty. [&#8230;]


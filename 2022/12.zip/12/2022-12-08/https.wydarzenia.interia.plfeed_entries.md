# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Rzecznik MSZ: Wymiana więźniów nie oznacza przełomu w relacjach USA i Rosji
 - [https://wydarzenia.interia.pl/kraj/news-rzecznik-msz-wymiana-wiezniow-nie-oznacza-przelomu-w-relacja,nId,6461118](https://wydarzenia.interia.pl/kraj/news-rzecznik-msz-wymiana-wiezniow-nie-oznacza-przelomu-w-relacja,nId,6461118)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 23:04:26+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rzecznik-msz-wymiana-wiezniow-nie-oznacza-przelomu-w-relacja,nId,6461118"><img align="left" alt="Rzecznik MSZ: Wymiana więźniów nie oznacza przełomu w relacjach USA i Rosji" src="https://i.iplsc.com/rzecznik-msz-wymiana-wiezniow-nie-oznacza-przelomu-w-relacja/000GGNCA83SQDN71-C321.jpg" /></a>Wymiana więzionej w Rosji koszykarki Brittney Griner na skazanego w USA handlarza bronią Wiktora Buta nie oznacza przełomu w relacjach USA i Rosji - ocenił rzecznik MSZ Łukasz Jasina. - Nie wiemy oczywiście, co uzgadniali Amerykanie z Rosjanami, ale takie wymiany zdarzały się nawet w najtrudniejszych momentach zimnej wojny - dodał. </p><br clear="all" />

## Jest decyzja wojewody ws. budowy ostatniego odcinka autostrady A2
 - [https://wydarzenia.interia.pl/kraj/news-jest-decyzja-wojewody-ws-budowy-ostatniego-odcinka-autostrad,nId,6461109](https://wydarzenia.interia.pl/kraj/news-jest-decyzja-wojewody-ws-budowy-ostatniego-odcinka-autostrad,nId,6461109)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 22:26:33+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jest-decyzja-wojewody-ws-budowy-ostatniego-odcinka-autostrad,nId,6461109"><img align="left" alt="Jest decyzja wojewody ws. budowy ostatniego odcinka autostrady A2" src="https://i.iplsc.com/jest-decyzja-wojewody-ws-budowy-ostatniego-odcinka-autostrad/000GGN8L3O7WY4P7-C321.jpg" /></a>Wojewoda mazowiecki wydał decyzję o zezwoleniu na budowę ostatniego odcinka autostrady A2 pomiędzy węzłami Groszki i Gręzów - przekazała rzeczniczka warszawskiego oddziału Generalnej Dyrekcji Dróg Krajowych i Autostrad Małgorzata Tarnowska. Zakończenie wszystkich prac przewidywane jest latem 2024 r.</p><br clear="all" />

## Media: Rosjanie werbowani na wojnę są straszeni nagraniami egzekucji dezerterów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosjanie-werbowani-na-wojne-sa-straszeni-nagraniami-eg,nId,6461097](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosjanie-werbowani-na-wojne-sa-straszeni-nagraniami-eg,nId,6461097)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 21:56:07+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosjanie-werbowani-na-wojne-sa-straszeni-nagraniami-eg,nId,6461097"><img align="left" alt="Media: Rosjanie werbowani na wojnę są straszeni nagraniami egzekucji dezerterów" src="https://i.iplsc.com/media-rosjanie-werbowani-na-wojne-sa-straszeni-nagraniami-eg/000ERLXHW9IQA89M-C321.jpg" /></a>Więźniowie z zakładów karnych w Rosji, którzy werbowani są na wojnę w Ukrainę przez grupę Wagnera, są straszeni nagraniami egzekucji innych więźniów, rozstrzelanych lub powieszonych za dezercję z pola walki - przekazało Radio Swoboda za rosyjskojęzyczną sekcją BBC. Od lipca z Rosji napływają doniesienia o masowej rekrutacji więźniów i wysyłaniu ich na front. Za ich realizację odpowiada Jewgienij Prigożyn, biznesmen blisko związany z Kremlem. </p><br clear="all" />

## Francja: Emmanuel Macron obiecał darmowe prezerwatywy dla młodych
 - [https://wydarzenia.interia.pl/zagranica/news-francja-emmanuel-macron-obiecal-darmowe-prezerwatywy-dla-mlo,nId,6461085](https://wydarzenia.interia.pl/zagranica/news-francja-emmanuel-macron-obiecal-darmowe-prezerwatywy-dla-mlo,nId,6461085)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 21:25:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-francja-emmanuel-macron-obiecal-darmowe-prezerwatywy-dla-mlo,nId,6461085"><img align="left" alt="Francja: Emmanuel Macron obiecał darmowe prezerwatywy dla młodych" src="https://i.iplsc.com/francja-emmanuel-macron-obiecal-darmowe-prezerwatywy-dla-mlo/000GG0W2C85XE4EP-C321.jpg" /></a>Prezydent Francji Emmanuel Macron zapowiedział, że od 1 stycznia 2023 roku w aptekach będą dostępne darmowe prezerwatywy dla młodych. &quot;To mała prewencyjna rewolucja&quot; - oświadczył. </p><br clear="all" />

## Rzym: Łzy w oczach papieża Franciszka. Mówił o cierpieniach Ukraińców
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rzym-lzy-w-oczach-papieza-franciszka-mowil-o-cierpieniach-uk,nId,6461073](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rzym-lzy-w-oczach-papieza-franciszka-mowil-o-cierpieniach-uk,nId,6461073)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 20:15:59+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rzym-lzy-w-oczach-papieza-franciszka-mowil-o-cierpieniach-uk,nId,6461073"><img align="left" alt="Rzym: Łzy w oczach papieża Franciszka. Mówił o cierpieniach Ukraińców" src="https://i.iplsc.com/rzym-lzy-w-oczach-papieza-franciszka-mowil-o-cierpieniach-uk/000GGMUV42U7GQ92-C321.jpg" /></a>Papieżowi Franciszkowi załamał się głos, a w jego oczach pojawiły się łzy, gdy podczas modlitwy w centrum Rzymu wspomniał o cierpieniach Ukraińców. Tłum, w tym burmistrz Rzymu Roberto Gualtieri, zaczął oklaskiwać papieża.</p><br clear="all" />

## Potężne uderzenie w Melitopolu. Piszą o lotnisku
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-potezne-uderzenie-w-melitopolu-pisza-o-lotnisku,nId,6461052](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-potezne-uderzenie-w-melitopolu-pisza-o-lotnisku,nId,6461052)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 19:55:58+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-potezne-uderzenie-w-melitopolu-pisza-o-lotnisku,nId,6461052"><img align="left" alt="Potężne uderzenie w Melitopolu. Piszą o lotnisku" src="https://i.iplsc.com/potezne-uderzenie-w-melitopolu-pisza-o-lotnisku/000GGMPPSI9OPHDF-C321.jpg" /></a>Lokalne władze informują o potężnej eksplozji, jaka miała mieć miejsce na terenie lotniska w Melitopolu. Miasto od końca lutego znajduje się pod kontrolą Rosjan.</p><br clear="all" />

## Brazylia: Podczas otwarcia wodociągu z kranu wypełzł wąż. Mieszkańcy w panice
 - [https://wydarzenia.interia.pl/zagranica/news-brazylia-podczas-otwarcia-wodociagu-z-kranu-wypelzl-waz-mies,nId,6461046](https://wydarzenia.interia.pl/zagranica/news-brazylia-podczas-otwarcia-wodociagu-z-kranu-wypelzl-waz-mies,nId,6461046)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 19:39:04+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-brazylia-podczas-otwarcia-wodociagu-z-kranu-wypelzl-waz-mies,nId,6461046"><img align="left" alt="Brazylia: Podczas otwarcia wodociągu z kranu wypełzł wąż. Mieszkańcy w panice" src="https://i.iplsc.com/brazylia-podczas-otwarcia-wodociagu-z-kranu-wypelzl-waz-mies/000GGMPF6OYS30RU-C321.jpg" /></a>Podczas otwarcia wodociągu we wsi Paranazinho w Brazylii doszło do niespodziewanej sytuacji - z kranu nagle wydostał się wąż. Gad wywołał panikę wśród zgromadzonych na uroczystości mieszkańców. W sieci pojawiło się nagranie ze zdarzenia.</p><br clear="all" />

## Obraz Jacka Malczewskiego sprzedany. Nowy właściciel musi jednak poczekać
 - [https://wydarzenia.interia.pl/kraj/news-obraz-jacka-malczewskiego-sprzedany-nowy-wlasciciel-musi-jed,nId,6461024](https://wydarzenia.interia.pl/kraj/news-obraz-jacka-malczewskiego-sprzedany-nowy-wlasciciel-musi-jed,nId,6461024)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 18:50:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-obraz-jacka-malczewskiego-sprzedany-nowy-wlasciciel-musi-jed,nId,6461024"><img align="left" alt="Obraz Jacka Malczewskiego sprzedany. Nowy właściciel musi jednak poczekać" src="https://i.iplsc.com/obraz-jacka-malczewskiego-sprzedany-nowy-wlasciciel-musi-jed/000GGMF0PU6AXWR3-C321.jpg" /></a>W czwartek warunkowo sprzedano obraz &quot;Rzeczywistość&quot; Jacka Malczewskiego. Cena dzieła sięgnęła 17 mln zł. Do realizacji transakcji i wydania obrazu dojdzie jednak dopiero wtedy, gdy zostanie ustalony jego status prawny.</p><br clear="all" />

## Andrzej Duda na spotkaniu z Cichanouską "Prawdziwi Białorusini nie są z Rosją"
 - [https://wydarzenia.interia.pl/kraj/news-andrzej-duda-na-spotkaniu-z-cichanouska-prawdziwi-bialorusin,nId,6461020](https://wydarzenia.interia.pl/kraj/news-andrzej-duda-na-spotkaniu-z-cichanouska-prawdziwi-bialorusin,nId,6461020)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 18:44:35+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-andrzej-duda-na-spotkaniu-z-cichanouska-prawdziwi-bialorusin,nId,6461020"><img align="left" alt="Andrzej Duda na spotkaniu z Cichanouską &quot;Prawdziwi Białorusini nie są z Rosją&quot;" src="https://i.iplsc.com/andrzej-duda-na-spotkaniu-z-cichanouska-prawdziwi-bialorusin/000GGMDPAE5H2SVY-C321.jpg" /></a>Prezydent Andrzej Duda spotkał się ze Swiatłaną Cichanouską. Liderka białoruskiej opozycji pojawiła się w czwartek w Belwederze. W swoim przemówieniu Andrzej Duda nawiązał do zbliżających się świąt Bożego Narodzenia oraz wojny w Ukrainie.</p><br clear="all" />

## Chojnice: Jarosław Kaczyński: Polityka naszych poprzedników to podporządkowanie się Niemcom i Rosjanom
 - [https://wydarzenia.interia.pl/kraj/news-chojnice-jaroslaw-kaczynski-polityka-naszych-poprzednikow-to,nId,6460785](https://wydarzenia.interia.pl/kraj/news-chojnice-jaroslaw-kaczynski-polityka-naszych-poprzednikow-to,nId,6460785)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 18:17:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-chojnice-jaroslaw-kaczynski-polityka-naszych-poprzednikow-to,nId,6460785"><img align="left" alt="Chojnice: Jarosław Kaczyński: Polityka naszych poprzedników to podporządkowanie się Niemcom i Rosjanom" src="https://i.iplsc.com/chojnice-jaroslaw-kaczynski-polityka-naszych-poprzednikow-to/000GGMAH20UB15NU-C321.jpg" /></a>- My nie chcemy być pod butem. To jest zasadnicza różnica między nami, a naszymi przeciwnikami. Chcę podkreślić ani niemieckim butem, ani rosyjskim, ani niczyim innym - powiedział Jarosław Kaczyński podczas spotkania w Chojnicach. - Polityka naszych poprzedników, to była polityka podporządkowania się Niemcom, czyli de facto Rosji, bo to było w ich interesie - mówił. W czasie spotkania doszło też do zakłócenia przemówienia prezesa PiS. Z sali padły pytania m.in. o obecność policjantów na wiecach Kaczyńskiego z mieszkańcami.</p><br clear="all" />

## Amunicja kasetowa dla Ukrainy? CNN o ruchu USA
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amunicja-kasetowa-dla-ukrainy-cnn-o-ruchu-usa,nId,6460997](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amunicja-kasetowa-dla-ukrainy-cnn-o-ruchu-usa,nId,6460997)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 17:42:27+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amunicja-kasetowa-dla-ukrainy-cnn-o-ruchu-usa,nId,6460997"><img align="left" alt="Amunicja kasetowa dla Ukrainy? CNN o ruchu USA" src="https://i.iplsc.com/amunicja-kasetowa-dla-ukrainy-cnn-o-ruchu-usa/000GGM5Y6YAIO0WL-C321.jpg" /></a>Jak donosi amerykańska stacja CNN,  administracja prezydenta USA Joe Bidena rozważa prośbę Ukrainy o przekazanie władzom w Kijowie amunicji kasetowej. O tę od dłuższego czasu mają apelować władze Ukrainy.</p><br clear="all" />

## Budują zapory, na Krymie brakuje betonu. Duży problem Rosji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-buduja-zapory-na-krymie-brakuje-betonu-duzy-problem-rosji,nId,6460982](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-buduja-zapory-na-krymie-brakuje-betonu-duzy-problem-rosji,nId,6460982)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 17:16:49+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-buduja-zapory-na-krymie-brakuje-betonu-duzy-problem-rosji,nId,6460982"><img align="left" alt="Budują zapory, na Krymie brakuje betonu. Duży problem Rosji" src="https://i.iplsc.com/buduja-zapory-na-krymie-brakuje-betonu-duzy-problem-rosji/000GGM2XWWTDDSV3-C321.jpg" /></a>Rosja wstrzymuje budowę obiektów infrastruktury społecznej na okupowanym Krymie. Wszystko z powodu braku betonu, który wykorzystywany jest do budowy fortyfikacji. Informację o takim obrocie spraw przekazała przedstawicielka prezydenta Ukrainy na Krymie Tamiła Taszewa.</p><br clear="all" />

## Budują zapory, w kraju brakuje betonu. Duży problem Rosji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-buduja-zapory-w-kraju-brakuje-betonu-duzy-problem-rosji,nId,6460982](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-buduja-zapory-w-kraju-brakuje-betonu-duzy-problem-rosji,nId,6460982)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 17:16:49+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-buduja-zapory-w-kraju-brakuje-betonu-duzy-problem-rosji,nId,6460982"><img align="left" alt="Budują zapory, w kraju brakuje betonu. Duży problem Rosji" src="https://i.iplsc.com/buduja-zapory-w-kraju-brakuje-betonu-duzy-problem-rosji/000GGM2XWWTDDSV3-C321.jpg" /></a>Rosja wstrzymuje budowę obiektów infrastruktury społecznej. Wszystko z powodu braku betonu, który wykorzystywany jest do budowy fortyfikacji na okupowanym Krymie. Informację o takim obrocie sytuacji przekazała przedstawicielka prezydenta Ukrainy na Krymie Tamiła Taszewa.</p><br clear="all" />

## Rosja: Ataki na ukraińską infrastrukturę energetyczną. Władimir Putin: Ukraina zaczęła
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-ataki-na-ukrainska-infrastrukture-energetyczna-wladimi,nId,6460791](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-ataki-na-ukrainska-infrastrukture-energetyczna-wladimi,nId,6460791)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 16:48:45+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-ataki-na-ukrainska-infrastrukture-energetyczna-wladimi,nId,6460791"><img align="left" alt="Rosja: Ataki na ukraińską infrastrukturę energetyczną. Władimir Putin: Ukraina zaczęła" src="https://i.iplsc.com/rosja-ataki-na-ukrainska-infrastrukture-energetyczna-wladimi/000GGLOVM4O4H57N-C321.jpg" /></a>Władimir Putin otwarcie przyznał, że Rosja dokonuje ataków na infrastrukturę energetyczną w Ukrainie. Według Putina jest to &quot;odpowiedź&quot; na działania kraju sąsiedniego. &quot;Czy on ćwiczy swoje przyszłe przemówienie do trybunału w Hadze?&quot; - skomentował wypowiedź Putina Anton Geraszczenko, doradca szefa MSW Ukrainy.</p><br clear="all" />

## Indie: Mężczyzna twierdzi, że został porwany i zgwałcony przez gang kobiet
 - [https://wydarzenia.interia.pl/zagranica/news-indie-mezczyzna-twierdzi-ze-zostal-porwany-i-zgwalcony-przez,nId,6460779](https://wydarzenia.interia.pl/zagranica/news-indie-mezczyzna-twierdzi-ze-zostal-porwany-i-zgwalcony-przez,nId,6460779)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 16:16:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-indie-mezczyzna-twierdzi-ze-zostal-porwany-i-zgwalcony-przez,nId,6460779"><img align="left" alt="Indie: Mężczyzna twierdzi, że został porwany i zgwałcony przez gang kobiet" src="https://i.iplsc.com/indie-mezczyzna-twierdzi-ze-zostal-porwany-i-zgwalcony-przez/000GGLI5HDG8Q38V-C321.jpg" /></a>Mężczyzna z Indii twierdzi, że został porwany, zgwałcony i pozostawiony na pewną śmierć przez grupę czterech kobiet. Policja prowadzi w tej sprawie dochodzenie.
</p><br clear="all" />

## Opole: Obywatel Ukrainy oskarżony o morderstwo. "Będziesz ze mną albo z nikim"
 - [https://wydarzenia.interia.pl/opolskie/news-opole-obywatel-ukrainy-oskarzony-o-morderstwo-bedziesz-ze-mn,nId,6460801](https://wydarzenia.interia.pl/opolskie/news-opole-obywatel-ukrainy-oskarzony-o-morderstwo-bedziesz-ze-mn,nId,6460801)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 16:07:47+00:00

<p><a href="https://wydarzenia.interia.pl/opolskie/news-opole-obywatel-ukrainy-oskarzony-o-morderstwo-bedziesz-ze-mn,nId,6460801"><img align="left" alt="Opole: Obywatel Ukrainy oskarżony o morderstwo. &quot;Będziesz ze mną albo z nikim&quot; " src="https://i.iplsc.com/opole-obywatel-ukrainy-oskarzony-o-morderstwo-bedziesz-ze-mn/000GGLPHVY86AVK7-C321.jpg" /></a>Rozpoczął się proces 38-letniego Viktora S. oskarżonego o zamordowanie swojej byłej partnerki. Chwilę przed zabójstwem powiedział: &quot;będziesz ze mną albo z nikim&quot;, następnie podciął ofierze gardło, kilka razy pchnął scyzorykiem w klatkę piersiową i przeciął twarz. Mężczyzna przyznał się do winy.</p><br clear="all" />

## "Jestem zdziwiony". Piotr Müller reaguje na słowa Jakiego
 - [https://wydarzenia.interia.pl/kraj/news-jestem-zdziwiony-piotr-muller-reaguje-na-slowa-jakiego,nId,6460798](https://wydarzenia.interia.pl/kraj/news-jestem-zdziwiony-piotr-muller-reaguje-na-slowa-jakiego,nId,6460798)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 16:03:06+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jestem-zdziwiony-piotr-muller-reaguje-na-slowa-jakiego,nId,6460798"><img align="left" alt="&quot;Jestem zdziwiony&quot;. Piotr Müller reaguje na słowa Jakiego" src="https://i.iplsc.com/jestem-zdziwiony-piotr-muller-reaguje-na-slowa-jakiego/000DFBEFHEMVLBU9-C321.jpg" /></a>Piotr Müller reaguje na słowa Patryka Jakiego. Polityk Solidarnej Polski stwierdził, że Polska nie otrzymała środków z Unii Europejskiej. &quot;Jestem zdziwiony&quot; - zaznaczył rzecznik rządu we wpisie na Twitterze.</p><br clear="all" />

## Politycy i duchowni nie dostaną wezwania do wojska
 - [https://wydarzenia.interia.pl/kraj/news-politycy-i-duchowni-nie-dostana-wezwania-do-wojska,nId,6460765](https://wydarzenia.interia.pl/kraj/news-politycy-i-duchowni-nie-dostana-wezwania-do-wojska,nId,6460765)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 15:48:57+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-politycy-i-duchowni-nie-dostana-wezwania-do-wojska,nId,6460765"><img align="left" alt="Politycy i duchowni nie dostaną wezwania do wojska" src="https://i.iplsc.com/politycy-i-duchowni-nie-dostana-wezwania-do-wojska/000GGLDOQO5MR0NC-C321.jpg" /></a>W całej Polsce rezerwiści otrzymują listy z wezwaniem do wojska. Wśród adresatów mogą być m.in. informatycy, lekarze, weterynarze, kucharze, spawacze i inni. Wezwań nie dostaną natomiast dwie grupy zawodowe - politycy i duchowni. Takie zapisy znalazły się bowiem w ustawie o obronie ojczyzny.</p><br clear="all" />

## Pogrzeb Jana Nowickiego. Jest data i miejsce
 - [https://wydarzenia.interia.pl/kraj/news-pogrzeb-jana-nowickiego-jest-data-i-miejsce,nId,6460774](https://wydarzenia.interia.pl/kraj/news-pogrzeb-jana-nowickiego-jest-data-i-miejsce,nId,6460774)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 15:19:23+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogrzeb-jana-nowickiego-jest-data-i-miejsce,nId,6460774"><img align="left" alt="Pogrzeb Jana Nowickiego. Jest data i miejsce" src="https://i.iplsc.com/pogrzeb-jana-nowickiego-jest-data-i-miejsce/000GGLETYF6LIREL-C321.jpg" /></a>Jak informuje burmistrz Kowala, pogrzeb aktora Jana Nowickiego odbędzie się w jego rodzinnej miejscowości w środę 14 grudnia. Msza pogrzebowa zaplanowana jest na godzinę 13.</p><br clear="all" />

## Elon Musk wstawił łóżka do firmy. Wszczęto dochodzenie
 - [https://wydarzenia.interia.pl/zagranica/news-elon-musk-wstawil-lozka-do-firmy-wszczeto-dochodzenie,nId,6460736](https://wydarzenia.interia.pl/zagranica/news-elon-musk-wstawil-lozka-do-firmy-wszczeto-dochodzenie,nId,6460736)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 14:45:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-elon-musk-wstawil-lozka-do-firmy-wszczeto-dochodzenie,nId,6460736"><img align="left" alt="Elon Musk wstawił łóżka do firmy. Wszczęto dochodzenie" src="https://i.iplsc.com/elon-musk-wstawil-lozka-do-firmy-wszczeto-dochodzenie/000GGKJL61ODRRMQ-C321.jpg" /></a>Nowy szef Twittera, najbogatszy człowiek świata Elon Musk realizuje swoją &quot;obietnicę&quot; wobec pracowników, w której zarzekał się, że będą &quot;pracowali długo i intensywnie&quot;, by &quot;naprawić firmę&quot;. Po zwolnieniu blisko połowy zatrudnionych, część sal konferencyjnych w siedzibie głównej w San Francisco przerobiono na pokoje sypialne. Dochodzenie w tej sprawie wszczęła inspekcja budowlana. Musk w odpowiedzi skrytykował burmistrz miasta.</p><br clear="all" />

## Brittney Griner wymieniona za Wiktora Buta. Negocjacje z Rosją
 - [https://wydarzenia.interia.pl/zagranica/news-brittney-griner-wymieniona-za-wiktora-buta-negocjacje-z-rosj,nId,6460721](https://wydarzenia.interia.pl/zagranica/news-brittney-griner-wymieniona-za-wiktora-buta-negocjacje-z-rosj,nId,6460721)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 14:15:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-brittney-griner-wymieniona-za-wiktora-buta-negocjacje-z-rosj,nId,6460721"><img align="left" alt="Brittney Griner wymieniona za Wiktora Buta. Negocjacje z Rosją" src="https://i.iplsc.com/brittney-griner-wymieniona-za-wiktora-buta-negocjacje-z-rosj/000GGKG8P227RCG6-C321.jpg" /></a>Koszykarka z USA - Brittney Griner - wróciła do Stanów Zjednoczonych. Sportsmenka została wymieniona na zatrzymanego w Stanach i więzionego handlarza bronią Wiktora Buta. Jak przypomina CNN,  Griner została skazana w Rosji na karę dziewięciu lat więzienia za posiadanie olejku haszyszowego.</p><br clear="all" />

## "Białorusini czują waszą solidarność". Swiatłana Cichanouska w Gdańsku
 - [https://wydarzenia.interia.pl/kraj/news-bialorusini-czuja-wasza-solidarnosc-swiatlana-cichanouska-w-,nId,6460713](https://wydarzenia.interia.pl/kraj/news-bialorusini-czuja-wasza-solidarnosc-swiatlana-cichanouska-w-,nId,6460713)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 14:05:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-bialorusini-czuja-wasza-solidarnosc-swiatlana-cichanouska-w-,nId,6460713"><img align="left" alt="&quot;Białorusini czują waszą solidarność&quot;. Swiatłana Cichanouska w Gdańsku" src="https://i.iplsc.com/bialorusini-czuja-wasza-solidarnosc-swiatlana-cichanouska-w/000GGKETC7YAJVQ4-C321.jpg" /></a>- Dzięki &quot;Solidarności&quot; Białorusini czują waszą solidarność, energię żeby iść na przód do swojej demokratycznej przyszłości - powiedziała liderka białoruskiej opozycji Swiatłana Cichanouska podczas wizyty w Gdańsku. Spotkała się tam m.in. z Lechem Wałęsą.</p><br clear="all" />

## Sochaczew: Morderstwo w Żabce. Ofiara to 35-letnia kobieta
 - [https://wydarzenia.interia.pl/mazowieckie/news-sochaczew-morderstwo-w-zabce-ofiara-to-35-letnia-kobieta,nId,6460705](https://wydarzenia.interia.pl/mazowieckie/news-sochaczew-morderstwo-w-zabce-ofiara-to-35-letnia-kobieta,nId,6460705)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 13:47:59+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-sochaczew-morderstwo-w-zabce-ofiara-to-35-letnia-kobieta,nId,6460705"><img align="left" alt="Sochaczew: Morderstwo w Żabce. Ofiara to 35-letnia kobieta" src="https://i.iplsc.com/sochaczew-morderstwo-w-zabce-ofiara-to-35-letnia-kobieta/000GA37W79LBQRO6-C321.jpg" /></a>W jednym ze sklepów w Sochaczewie znaleziono kobietę, która miała rany kłute. Niestety 35-latka nie żyje - przekazała Interii oficer prasowa Komendy Powiatowej Policji w Sochaczewie Agnieszka Dzik. Ofiara to pracownica sklepu. Trwa obława za podejrzewanym.</p><br clear="all" />

## Czechy: W aptekach brakuje leków. Czesi jeżdżą po nie do Polski
 - [https://wydarzenia.interia.pl/zagranica/news-czechy-w-aptekach-brakuje-lekow-czesi-jezdza-po-nie-do-polsk,nId,6460633](https://wydarzenia.interia.pl/zagranica/news-czechy-w-aptekach-brakuje-lekow-czesi-jezdza-po-nie-do-polsk,nId,6460633)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 13:42:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czechy-w-aptekach-brakuje-lekow-czesi-jezdza-po-nie-do-polsk,nId,6460633"><img align="left" alt="Czechy: W aptekach brakuje leków. Czesi jeżdżą po nie do Polski" src="https://i.iplsc.com/czechy-w-aptekach-brakuje-lekow-czesi-jezdza-po-nie-do-polsk/0004GPFNOCQLUI1L-C321.jpg" /></a>- W Czechach brakuje niektórych leków, w tym przeciwbólowych i podstawowych antybiotyków. Czesi jeżdżą po nie do Polski lub szukają ich w internecie - informuje w czwartek dziennik &quot;Hospodarzske Noviny&quot;. Lekarze i farmaceuci twierdzą, że to największe braki niektórych specyfików w historii.</p><br clear="all" />

## Ukraina będzie jak Izrael. "Odzyska swoje ziemie. Tylko to zajmie sporo czasu"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-bedzie-jak-izrael-odzyska-swoje-ziemie-tylko-to-zajm,nId,6460620](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-bedzie-jak-izrael-odzyska-swoje-ziemie-tylko-to-zajm,nId,6460620)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 13:32:55+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-bedzie-jak-izrael-odzyska-swoje-ziemie-tylko-to-zajm,nId,6460620"><img align="left" alt="Ukraina będzie jak Izrael. &quot;Odzyska swoje ziemie. Tylko to zajmie sporo czasu&quot;" src="https://i.iplsc.com/ukraina-bedzie-jak-izrael-odzyska-swoje-ziemie-tylko-to-zajm/000GGJY0OPH9VOSV-C321.jpg" /></a>Zima miała być dla Kremla momentem gry na czas i przegrupowywania sił na froncie. Jednak sygnały czołowych polityków Zachodu o gotowości do rozmów pokojowych z Rosją sprawiły, że zarówno Moskwa, jak i Kijów zrobią, co tylko w ich mocy, żeby w jak najkrótszym czasie wydrzeć dla siebie na polu bitwy tak dużo, jak to tylko możliwe.</p><br clear="all" />

## Klinika "Budzik" pomoże dorosłym. Warszawa otwiera drugi budynek
 - [https://wydarzenia.interia.pl/mazowieckie/news-klinika-budzik-pomoze-doroslym-warszawa-otwiera-drugi-budyne,nId,6460674](https://wydarzenia.interia.pl/mazowieckie/news-klinika-budzik-pomoze-doroslym-warszawa-otwiera-drugi-budyne,nId,6460674)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 13:17:46+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-klinika-budzik-pomoze-doroslym-warszawa-otwiera-drugi-budyne,nId,6460674"><img align="left" alt="Klinika &quot;Budzik&quot; pomoże dorosłym. Warszawa otwiera drugi budynek" src="https://i.iplsc.com/klinika-budzik-pomoze-doroslym-warszawa-otwiera-drugi-budyne/000GGK55VFKJ1GA0-C321.jpg" /></a>Koniec budowy kliniki &quot;Budzik&quot; dla dorosłych w Warszawie. Ta znajduje się przy szpitalu Bródnowskim na Targówku. Informację o końcu budowy przekazała Ewa Błaszczyk - szefowa fundacji &quot;Akogo?&quot;. Jak dodała, w klinice &quot;Budzik&quot; dla najmłodszych wybudziło się właśnie setne dziecko.</p><br clear="all" />

## Chiny: Miasta łagodzą restrykcje pandemiczne. Koniec z "kodami zdrowia"
 - [https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-chiny-miasta-lagodza-restrykcje-pandemiczne-koniec-z-kodami-,nId,6460672](https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-chiny-miasta-lagodza-restrykcje-pandemiczne-koniec-z-kodami-,nId,6460672)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 13:15:01+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-chiny-miasta-lagodza-restrykcje-pandemiczne-koniec-z-kodami-,nId,6460672"><img align="left" alt="Chiny: Miasta łagodzą restrykcje pandemiczne. Koniec z &quot;kodami zdrowia&quot;" src="https://i.iplsc.com/chiny-miasta-lagodza-restrykcje-pandemiczne-koniec-z-kodami/000GGK7862RN182J-C321.jpg" /></a>Od czwartku w chińskim Kantonie nie trzeba już okazywać &quot;kodów zdrowia&quot; przy wejściu na lotnisko i stacje metra. W Szanghaju obowiązek ten zostanie zniesiony w restauracjach. W kraju wprowadzane są zmiany jeśli chodzi o wytyczne walki z pandemią koronawirusa.</p><br clear="all" />

## Wezwanie do wojska. Pułkownik Mirosław Bryś wyjaśnia
 - [https://wydarzenia.interia.pl/kraj/news-wezwanie-do-wojska-pulkownik-miroslaw-brys-wyjasnia,nId,6460667](https://wydarzenia.interia.pl/kraj/news-wezwanie-do-wojska-pulkownik-miroslaw-brys-wyjasnia,nId,6460667)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 13:06:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wezwanie-do-wojska-pulkownik-miroslaw-brys-wyjasnia,nId,6460667"><img align="left" alt="Wezwanie do wojska. Pułkownik Mirosław Bryś wyjaśnia" src="https://i.iplsc.com/wezwanie-do-wojska-pulkownik-miroslaw-brys-wyjasnia/000GGK32K530RV54-C321.jpg" /></a>- Głównym naborem na ćwiczenia rezerwy są zasoby żołnierzy znajdujących się w pasywnej rezerwie. Tutaj głównie skupiamy się na osobach, które odbyły służbę wojskową, mają przysięgę wojskową i mają nadany przydział mobilizacyjny w konkretnej jednostce wojskowej - mówił na konferencji płk Mirosław Bryś, szef Centralnego Wojskowego Centrum Rekrutacji. Osoby bez przeszkolenia mają stanowić &quot;minimum&quot; przy zaproszeniach na ćwiczenia. Pułkownik wymienił też zawody, które mogą spodziewać się powołania.</p><br clear="all" />

## Rosyjski szpieg w komisji ds. WSI. Cenckiewicz i Sikorski oskarżają
 - [https://wydarzenia.interia.pl/kraj/news-rosyjski-szpieg-w-komisji-ds-wsi-cenckiewicz-i-sikorski-oska,nId,6460539](https://wydarzenia.interia.pl/kraj/news-rosyjski-szpieg-w-komisji-ds-wsi-cenckiewicz-i-sikorski-oska,nId,6460539)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 13:04:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rosyjski-szpieg-w-komisji-ds-wsi-cenckiewicz-i-sikorski-oska,nId,6460539"><img align="left" alt="Rosyjski szpieg w komisji ds. WSI. Cenckiewicz i Sikorski oskarżają" src="https://i.iplsc.com/rosyjski-szpieg-w-komisji-ds-wsi-cenckiewicz-i-sikorski-oska/000EGSAQ6OVFJECJ-C321.jpg" /></a>Tomasz L., który kilka miesięcy temu został zatrzymany za szpiegostwo dla Rosji, był także członkiem komisji ds. likwidacji Wojskowych Służb Informacyjnych. Portal tvp.info przytacza słowa Sławomira Cenckiewicza, przewodniczącego komisji, który twierdzi, że Tomasza L. powołał do niej ówczesny szef MON Radosław Sikorski. &quot;Powołałem (go) na wniosek pana Cenckiewicza i to on winien jest wyjaśnień, skąd ten delikwent się na jego liście wziął&quot; - odpowiada polityk PO.</p><br clear="all" />

## Kraków: 74,7 mln zł dla spółki zarządzającej drugą urzędową telewizją. Jest wniosek
 - [https://wydarzenia.interia.pl/malopolskie/news-krakow-74-7-mln-zl-dla-spolki-zarzadzajacej-druga-urzedowa-t,nId,6460530](https://wydarzenia.interia.pl/malopolskie/news-krakow-74-7-mln-zl-dla-spolki-zarzadzajacej-druga-urzedowa-t,nId,6460530)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 12:54:17+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-krakow-74-7-mln-zl-dla-spolki-zarzadzajacej-druga-urzedowa-t,nId,6460530"><img align="left" alt="Kraków: 74,7 mln zł dla spółki zarządzającej drugą urzędową telewizją. Jest wniosek" src="https://i.iplsc.com/krakow-74-7-mln-zl-dla-spolki-zarzadzajacej-druga-urzedowa-t/000GGJH6AMAIQ5KE-C321.jpg" /></a>Kraków planuje przekazać spółce odpowiedzialnej za funkcjonowanie drugiej urzędowej telewizji 74,7 mln zł w przyszłym roku. O uwzględnienie tej kwoty w budżecie wystąpił wydział kultury, a cześć środków udało się już zabezpieczyć. To nie wszystko. Okazuje się, że spółka w tym roku otrzymała od miasta w różnych formach 40 mln zł. Tymczasem w przyszłym tygodniu urzędnicy ogłoszą zmianę formatu telewizji. Zamiast dotychczasowego Play Kraków News pojawi się nowy program: Hello Kraków.</p><br clear="all" />

## Obława na "Obywateli Rzeszy". Rosja odcina się od powiązań
 - [https://wydarzenia.interia.pl/zagranica/news-oblawa-na-obywateli-rzeszy-rosja-odcina-sie-od-powiazan,nId,6460595](https://wydarzenia.interia.pl/zagranica/news-oblawa-na-obywateli-rzeszy-rosja-odcina-sie-od-powiazan,nId,6460595)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 12:21:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-oblawa-na-obywateli-rzeszy-rosja-odcina-sie-od-powiazan,nId,6460595"><img align="left" alt="Obława na &quot;Obywateli Rzeszy&quot;. Rosja odcina się od powiązań" src="https://i.iplsc.com/oblawa-na-obywateli-rzeszy-rosja-odcina-sie-od-powiazan/000GGJRU2IGO4I8K-C321.jpg" /></a>Ogromne zaniepokojenie próbą obalenia rządu przez &quot;Obywateli Rzeszy&quot; wyraził prezydent Frank-Walter Steinmeier. Prokurator federalny wyjaśnił, że oskarżonych łączyło &quot;głębokie odrzucenie instytucji państwa i demokracji&quot;. Nieoczekiwanie sprawę komentuje też Rosja.</p><br clear="all" />

## RSV uderza w najmłodszych. Lekarka: Dramat. Mam 42 dzieci na 30-osobowym oddziale
 - [https://wydarzenia.interia.pl/zdrowie/news-rsv-uderza-w-najmlodszych-lekarka-dramat-mam-42-dzieci-na-30,nId,6460545](https://wydarzenia.interia.pl/zdrowie/news-rsv-uderza-w-najmlodszych-lekarka-dramat-mam-42-dzieci-na-30,nId,6460545)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 12:01:14+00:00

<p><a href="https://wydarzenia.interia.pl/zdrowie/news-rsv-uderza-w-najmlodszych-lekarka-dramat-mam-42-dzieci-na-30,nId,6460545"><img align="left" alt="RSV uderza w najmłodszych. Lekarka: Dramat. Mam 42 dzieci na 30-osobowym oddziale" src="https://i.iplsc.com/rsv-uderza-w-najmlodszych-lekarka-dramat-mam-42-dzieci-na-30/000GGJK1OHGSNXQW-C321.jpg" /></a>RSV znów atakuje. Wirus ten jest szczególnie groźny dla najmłodszych pacjentów, którzy przy zakażeniu niejednokrotnie wymagają hospitalizacji. Tymczasem niektóre placówki - m.in. te w Małopolsce - pękają już w szwach. - Na oddziałach w Krakowie po prostu nie ma miejsc - mówi Interii Miłosz Przyszowski, pediatra z Uniwersyteckiego Szpitala Dziecięcego w Krakowie-Prokocimiu, który pracuje na SOR-ze.</p><br clear="all" />

## Tej zimy mogą posypać się wysokie kary. Niektórzy zapłacą nawet kilka tys. zł
 - [https://wydarzenia.interia.pl/kraj/news-tej-zimy-moga-posypac-sie-wysokie-kary-niektorzy-zaplaca-naw,nId,6460489](https://wydarzenia.interia.pl/kraj/news-tej-zimy-moga-posypac-sie-wysokie-kary-niektorzy-zaplaca-naw,nId,6460489)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 11:59:18+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tej-zimy-moga-posypac-sie-wysokie-kary-niektorzy-zaplaca-naw,nId,6460489"><img align="left" alt="Tej zimy mogą posypać się wysokie kary. Niektórzy zapłacą nawet kilka tys. zł" src="https://i.iplsc.com/tej-zimy-moga-posypac-sie-wysokie-kary-niektorzy-zaplaca-naw/000GGJ6LMIQ5J9NJ-C321.jpg" /></a>Mroźna i śnieżna zima zbliża się do Polski wielkimi krokami. To wiąże się z dodatkowymi obowiązkami dla kierowców, którzy przed wyruszeniem w trasę muszą odśnieżyć auto i pozbyć się lodu z szyb. Osoby, które będą bagatelizować usunięcie zalegającego śniegu z karoserii, muszą przygotować się na niemiłą niespodziankę, czyli wysoką karę. Ile wynosi mandat za nieodśnieżony samochód i kiedy można go dostać?</p><br clear="all" />

## Zapomnisz o tym zimowym obowiązku, dostaniesz 3 tys. zł mandatu. A to nie jedyne kary
 - [https://wydarzenia.interia.pl/kraj/news-zapomnisz-o-tym-zimowym-obowiazku-dostaniesz-3-tys-zl-mandat,nId,6460489](https://wydarzenia.interia.pl/kraj/news-zapomnisz-o-tym-zimowym-obowiazku-dostaniesz-3-tys-zl-mandat,nId,6460489)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 11:59:18+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zapomnisz-o-tym-zimowym-obowiazku-dostaniesz-3-tys-zl-mandat,nId,6460489"><img align="left" alt="Zapomnisz o tym zimowym obowiązku, dostaniesz 3 tys. zł mandatu. A to nie jedyne kary" src="https://i.iplsc.com/zapomnisz-o-tym-zimowym-obowiazku-dostaniesz-3-tys-zl-mandat/000GGJ6LMIQ5J9NJ-C321.jpg" /></a>Mroźna i śnieżna zima zbliża się do Polski wielkimi krokami. To wiąże się z dodatkowymi obowiązkami dla kierowców, którzy przed wyruszeniem w trasę muszą odśnieżyć auto i pozbyć się lodu z szyb. Osoby, które będą bagatelizować usunięcie zalegającego śniegu z karoserii, muszą przygotować się na niemiłą niespodziankę, czyli wysoką karę. Ile wynosi mandat za nieodśnieżony samochód i kiedy można go dostać?</p><br clear="all" />

## Duże ambicje Scholza. To dlatego lawiruje w sprawie Rosji i zbliża się do Chin
 - [https://wydarzenia.interia.pl/zagranica/news-duze-ambicje-scholza-to-dlatego-lawiruje-w-sprawie-rosji-i-z,nId,6458882](https://wydarzenia.interia.pl/zagranica/news-duze-ambicje-scholza-to-dlatego-lawiruje-w-sprawie-rosji-i-z,nId,6458882)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 11:45:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-duze-ambicje-scholza-to-dlatego-lawiruje-w-sprawie-rosji-i-z,nId,6458882"><img align="left" alt="Duże ambicje Scholza. To dlatego lawiruje w sprawie Rosji i zbliża się do Chin" src="https://i.iplsc.com/duze-ambicje-scholza-to-dlatego-lawiruje-w-sprawie-rosji-i-z/000GGGYSPIIYAM78-C321.jpg" /></a>Kanclerz Niemiec Olaf Scholz lawiruje w stosunku wobec Rosji, niewystarczająco wspiera Ukrainę, próbuje dogadać się z Chinami, usiłuje zająć coraz coraz silniejszą pozycję wobec USA, a do tego chciałby, aby jego kraj realizował interesy dzięki silnej i zintegrowanej UE. Scholz uważa, że Niemcy powinny być jednym z najważniejszych &quot;gwarantów bezpieczeństwa&quot; w Europie. Wyjaśniamy, na czym opiera się polityka szefa niemieckiego rządu. </p><br clear="all" />

## Niemcy: Aktywiści klimatyczni w akcji. Przykleili się do pasa startowego
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-aktywisci-klimatyczni-w-akcji-przykleili-sie-do-pasa-,nId,6460551](https://wydarzenia.interia.pl/zagranica/news-niemcy-aktywisci-klimatyczni-w-akcji-przykleili-sie-do-pasa-,nId,6460551)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 11:29:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-aktywisci-klimatyczni-w-akcji-przykleili-sie-do-pasa-,nId,6460551"><img align="left" alt="Niemcy: Aktywiści klimatyczni w akcji. Przykleili się do pasa startowego" src="https://i.iplsc.com/niemcy-aktywisci-klimatyczni-w-akcji-przykleili-sie-do-pasa/000GGJKS6DEV9OOB-C321.jpg" /></a>W czwartek w Niemczech doszło do kolejnych akcji aktywistów klimatycznych z grupy &quot;Ostatnie pokolenie&quot; na lotniskach w Monachium i Berlinie. W Monachium aktywiści przykleili się do pasa startowego, z którego zostali później usunięci.</p><br clear="all" />

## Adam Niedzielski: Tendencja się odwróciła. Więcej zakażeń i hospitalizacji
 - [https://wydarzenia.interia.pl/kraj/news-adam-niedzielski-tendencja-sie-odwrocila-wiecej-zakazen-i-ho,nId,6460557](https://wydarzenia.interia.pl/kraj/news-adam-niedzielski-tendencja-sie-odwrocila-wiecej-zakazen-i-ho,nId,6460557)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 11:22:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-adam-niedzielski-tendencja-sie-odwrocila-wiecej-zakazen-i-ho,nId,6460557"><img align="left" alt="Adam Niedzielski: Tendencja się odwróciła. Więcej zakażeń i hospitalizacji" src="https://i.iplsc.com/adam-niedzielski-tendencja-sie-odwrocila-wiecej-zakazen-i-ho/000GGJOCP4EOAE4E-C321.jpg" /></a>- Mniej więcej od półtora tygodnia tendencja się odwróciła. Odnotowujemy wzrost liczby zakażeń, jak i hospitalizacji - mówił na konferencji prasowej w czwartek minister zdrowia Adam Niedzielski. Przyrosty z tygodnia na tydzień wynoszą ok. 20 proc. Minister poinformował też o terminie rejestracji najmłodszych na szczepienia przeciw COVID-19.</p><br clear="all" />

## Polski ochotnik zginął w Ukrainie. Zabiła go rosyjska mina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polski-ochotnik-zginal-w-ukrainie-zabila-go-rosyjska-mina,nId,6460542](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polski-ochotnik-zginal-w-ukrainie-zabila-go-rosyjska-mina,nId,6460542)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 11:19:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polski-ochotnik-zginal-w-ukrainie-zabila-go-rosyjska-mina,nId,6460542"><img align="left" alt="Polski ochotnik zginął w Ukrainie. Zabiła go rosyjska mina" src="https://i.iplsc.com/polski-ochotnik-zginal-w-ukrainie-zabila-go-rosyjska-mina/000EGBH84UW3MYYX-C321.jpg" /></a>Daniel S. ukończył trzy fakultety i liczne szkolenia wojskowe. Zasiadał w radzie znanej fundacji wspomagającej żołnierzy AK. Strzelectwa uczył się w Jednostce Wojskowej GROM. W ukraińskim wojsku był operatorem elitarnej jednostki specjalnej zajmującej się rozpoznaniem - pisze Onet.</p><br clear="all" />

## Bomby Umara Pateka zabiły setki osób. Wyszedł na wolność
 - [https://wydarzenia.interia.pl/zagranica/news-bomby-umara-pateka-zabily-setki-osob-wyszedl-na-wolnosc,nId,6460547](https://wydarzenia.interia.pl/zagranica/news-bomby-umara-pateka-zabily-setki-osob-wyszedl-na-wolnosc,nId,6460547)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 11:13:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bomby-umara-pateka-zabily-setki-osob-wyszedl-na-wolnosc,nId,6460547"><img align="left" alt="Bomby Umara Pateka zabiły setki osób. Wyszedł na wolność" src="https://i.iplsc.com/bomby-umara-pateka-zabily-setki-osob-wyszedl-na-wolnosc/000GGJI7YF8TFRJE-C321.jpg" /></a>Indonezyjczyk Umar Patek odpowiedzialny za skonstruowanie bomb, które zabiły 202 osoby w zamachach na Bali, wyszedł na wolność. 20 lat bezwzględnego więzienia, po połowie odbytej kary zamieniono na &quot;uczestnictwo w programie mentorskim&quot;. Decyzję wymiaru sprawiedliwości skrytykowali m.in. premier Australii i ofiary tragedii.</p><br clear="all" />

## Bomby Umara Patka zabiły setki osób. Wyszedł na wolność
 - [https://wydarzenia.interia.pl/zagranica/news-bomby-umara-patka-zabily-setki-osob-wyszedl-na-wolnosc,nId,6460547](https://wydarzenia.interia.pl/zagranica/news-bomby-umara-patka-zabily-setki-osob-wyszedl-na-wolnosc,nId,6460547)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 11:13:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bomby-umara-patka-zabily-setki-osob-wyszedl-na-wolnosc,nId,6460547"><img align="left" alt="Bomby Umara Patka zabiły setki osób. Wyszedł na wolność" src="https://i.iplsc.com/bomby-umara-patka-zabily-setki-osob-wyszedl-na-wolnosc/000GGJI7YF8TFRJE-C321.jpg" /></a>Indonezyjczyk Umar Patek odpowiedzialny za skonstruowanie bomb, które zabiły 202 osoby w zamachach na Bali, wyszedł na wolność. 20 lat bezwzględnego więzienia, po połowie odbytej kary zamieniono na &quot;uczestnictwo w programie mentorskim&quot;. Decyzję wymiaru sprawiedliwości skrytykowali m.in. premier Australii i ofiary tragedii.</p><br clear="all" />

## Węgry: Inflacja w kraju rośnie. W grudniu ma być jeszcze gorzej
 - [https://wydarzenia.interia.pl/zagranica/news-wegry-inflacja-w-kraju-rosnie-w-grudniu-ma-byc-jeszcze-gorze,nId,6460535](https://wydarzenia.interia.pl/zagranica/news-wegry-inflacja-w-kraju-rosnie-w-grudniu-ma-byc-jeszcze-gorze,nId,6460535)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 11:00:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wegry-inflacja-w-kraju-rosnie-w-grudniu-ma-byc-jeszcze-gorze,nId,6460535"><img align="left" alt="Węgry: Inflacja w kraju rośnie. W grudniu ma być jeszcze gorzej" src="https://i.iplsc.com/wegry-inflacja-w-kraju-rosnie-w-grudniu-ma-byc-jeszcze-gorze/0007NQ1L1966B2EV-C321.jpg" /></a>Węgry zmagają się z rosnącą inflacją. Ceny konsumpcyjne w kraju były w listopadzie o 22,5 proc. wyższe niż w tym samym miesiącu w roku ubiegłym - poinformował węgierski urząd statystyczny KSH. Nic jednak nie wskazuje, żeby sytuacja miała się poprawić. Rząd zapowiada dalszy wzrost inflacji w grudniu w związku ze zniesieniem we wtorek limitu cen na paliwo.</p><br clear="all" />

## Putin planuje drogę ewakuacji po porażce. "Wiem to z zaufanego źródła"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-planuje-droge-ewakuacji-po-porazce-wiem-to-z-zaufanego,nId,6460508](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-planuje-droge-ewakuacji-po-porazce-wiem-to-z-zaufanego,nId,6460508)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 10:26:15+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-planuje-droge-ewakuacji-po-porazce-wiem-to-z-zaufanego,nId,6460508"><img align="left" alt="Putin planuje drogę ewakuacji po porażce. &quot;Wiem to z zaufanego źródła&quot;" src="https://i.iplsc.com/putin-planuje-droge-ewakuacji-po-porazce-wiem-to-z-zaufanego/000GGJCS0KWVNNAH-C321.jpg" /></a>&quot;Od wiosny biuro polityczne Władimira Putina pracuje nad projektem nieoficjalnie nazywanym Arką Noego. Jak sama nazwa wskazuje, mówimy o znalezieniu nowych miejsc, do których można się udać, jeśli w domu zrobi się niewygodnie&quot; - stwierdził Abbas Galiamow, analityk polityczny i były autor przemówień dla prezydenta Rosji. Dodał, że &quot;zazwyczaj nie opowiada poufnych historii, ale dziś zrobi wyjątek&quot;. &quot;Za bardzo ufam źródłu&quot; - napisał w serwisie Telegram.</p><br clear="all" />

## Rosja: Kolejna inscenizacja dla mediów podczas spotkania z Putinem
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-kolejna-inscenizacja-dla-mediow-podczas-spotkania-z-pu,nId,6460499](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-kolejna-inscenizacja-dla-mediow-podczas-spotkania-z-pu,nId,6460499)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 10:14:09+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-kolejna-inscenizacja-dla-mediow-podczas-spotkania-z-pu,nId,6460499"><img align="left" alt="Rosja: Kolejna inscenizacja dla mediów podczas spotkania z Putinem" src="https://i.iplsc.com/rosja-kolejna-inscenizacja-dla-mediow-podczas-spotkania-z-pu/000742R2M2EV55B4-C321.jpg" /></a>Nawet wyselekcjonowani rosyjscy &quot;obrońcy praw człowieka&quot; nie zostali dopuszczeni do emisji na żywo. Spotkanie Władimira Putina z Radą Praw Człowieka było nagrane wcześniej, a rosyjskiego prezydenta zdradził zegarek - powiadomił kanał Możem Objasnit w Telegramie.</p><br clear="all" />

## "Człowiek-choinka" uszkodził 20 samochodów przy hurtowni mięsa
 - [https://wydarzenia.interia.pl/zachodniopomorskie/news-czlowiek-choinka-uszkodzil-20-samochodow-przy-hurtowni-miesa,nId,6460496](https://wydarzenia.interia.pl/zachodniopomorskie/news-czlowiek-choinka-uszkodzil-20-samochodow-przy-hurtowni-miesa,nId,6460496)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 10:07:31+00:00

<p><a href="https://wydarzenia.interia.pl/zachodniopomorskie/news-czlowiek-choinka-uszkodzil-20-samochodow-przy-hurtowni-miesa,nId,6460496"><img align="left" alt="&quot;Człowiek-choinka&quot; uszkodził 20 samochodów przy hurtowni mięsa" src="https://i.iplsc.com/czlowiek-choinka-uszkodzil-20-samochodow-przy-hurtowni-miesa/000GGJ6HQ6J9PQLT-C321.jpg" /></a>Poważne przestępstwo popełnione w absurdalnym przebraniu. Nieznany sprawca uszkodził 20 samochodów na parkingu przy hurtowni mięsa w Warzymicach (woj. zachodniopomorskie). Straty wyceniono na 60 tys. złotych, a właściciel zakładu prosi o pomoc w ujęciu wandala. Cechy charakterystyczne sprawcy? Rana na ręce, wojskowe buty i... świąteczny kamuflaż.</p><br clear="all" />

## Spór o Janusza Palikota. Chodzi o funkcję w Krakowie
 - [https://wydarzenia.interia.pl/malopolskie/news-spor-o-janusza-palikota-chodzi-o-funkcje-w-krakowie,nId,6460486](https://wydarzenia.interia.pl/malopolskie/news-spor-o-janusza-palikota-chodzi-o-funkcje-w-krakowie,nId,6460486)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 09:59:16+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-spor-o-janusza-palikota-chodzi-o-funkcje-w-krakowie,nId,6460486"><img align="left" alt="Spór o Janusza Palikota. Chodzi o funkcję w Krakowie " src="https://i.iplsc.com/spor-o-janusza-palikota-chodzi-o-funkcje-w-krakowie/000GGJ580M87D98C-C321.jpg" /></a>Wiceprzewodniczący Rady Miasta Krakowa Michał Drewnicki nie zgadza się na powołanie Janusza Palikota na członka Rady Muzeum Sztuki Współczesnej MOCAK. Prezydent miasta uzasadnia decyzję tym, że Palikot wycofał się z polityki i jako przedsiębiorca jest mecenasem muzeum.</p><br clear="all" />

## Seniorka udaremniła napad na bank. W ruch poszła kula ortopedyczna
 - [https://wydarzenia.interia.pl/podkarpackie/news-seniorka-udaremnila-napad-na-bank-w-ruch-poszla-kula-ortoped,nId,6460348](https://wydarzenia.interia.pl/podkarpackie/news-seniorka-udaremnila-napad-na-bank-w-ruch-poszla-kula-ortoped,nId,6460348)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 09:24:58+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-seniorka-udaremnila-napad-na-bank-w-ruch-poszla-kula-ortoped,nId,6460348"><img align="left" alt="Seniorka udaremniła napad na bank. W ruch poszła kula ortopedyczna" src="https://i.iplsc.com/seniorka-udaremnila-napad-na-bank-w-ruch-poszla-kula-ortoped/000GGIYA3JHSLJVW-C321.jpg" /></a>Do dramatycznych wydarzeń doszło w placówce banku w Przemyślu (woj. podkarpackie). Napastniczka złapała jedną z pracownic za włosy i grożąc nożem zażądała pieniędzy. Cała sytuacja mogłaby się skończyć tragicznie, gdyby nie zachowanie jednej z klientek banku. W ruch poszła... kula ortopedyczna. W sieci pojawiło się nagranie z miejsca zdarzenia.</p><br clear="all" />

## ONZ rozważa zbadanie sprawy irańskich dronów w Ukrainie. "Zachód naciska"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-onz-rozwaza-zbadanie-sprawy-iranskich-dronow-w-ukrainie-zach,nId,6460343](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-onz-rozwaza-zbadanie-sprawy-iranskich-dronow-w-ukrainie-zach,nId,6460343)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 09:18:15+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-onz-rozwaza-zbadanie-sprawy-iranskich-dronow-w-ukrainie-zach,nId,6460343"><img align="left" alt="ONZ rozważa zbadanie sprawy irańskich dronów w Ukrainie. &quot;Zachód naciska&quot;" src="https://i.iplsc.com/onz-rozwaza-zbadanie-sprawy-iranskich-dronow-w-ukrainie-zach/000GGIYXJJ3SP94V-C321.jpg" /></a>ONZ bada &quot;dostępne informacje&quot; na temat oskarżeń dotyczących dostarczania Rosji dronów przez Iran, mówi się o wysłaniu ekspertów, którzy mieliby zbadać pozostałości sprzętu. Sekretarz generalny ONZ Antonio Guterres stwierdził, że decyzja wynika z &quot;presji Zachodu&quot;. Rosja z kolei twierdzi, że Guterres nie ma mandatu do wysłania ekspertów do Ukrainy.</p><br clear="all" />

## 158 cudzoziemców próbowało przedostać się z Białorusi do Polski
 - [https://wydarzenia.interia.pl/kraj/news-158-cudzoziemcow-probowalo-przedostac-sie-z-bialorusi-do-pol,nId,6460339](https://wydarzenia.interia.pl/kraj/news-158-cudzoziemcow-probowalo-przedostac-sie-z-bialorusi-do-pol,nId,6460339)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 09:15:47+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-158-cudzoziemcow-probowalo-przedostac-sie-z-bialorusi-do-pol,nId,6460339"><img align="left" alt="158 cudzoziemców próbowało przedostać się z Białorusi do Polski" src="https://i.iplsc.com/158-cudzoziemcow-probowalo-przedostac-sie-z-bialorusi-do-pol/000GGIVAKBTA03IB-C321.jpg" /></a>158 cudzoziemców próbowało w środę przedostać się z Białorusi do Polski. Duża grupa sforsowała w kilku miejscach graniczną rzekę Świsłocz - podała Straż Graniczna w raporcie z minionej doby. Zatrzymano też kolejnego tzw. kuriera nielegalnych imigrantów, obywatela Ukrainy.</p><br clear="all" />

## Atak zimy na północy kraju. Synoptycy ostrzegają
 - [https://wydarzenia.interia.pl/kraj/news-atak-zimy-na-polnocy-kraju-synoptycy-ostrzegaja,nId,6460299](https://wydarzenia.interia.pl/kraj/news-atak-zimy-na-polnocy-kraju-synoptycy-ostrzegaja,nId,6460299)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 08:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-atak-zimy-na-polnocy-kraju-synoptycy-ostrzegaja,nId,6460299"><img align="left" alt="Atak zimy na północy kraju. Synoptycy ostrzegają" src="https://i.iplsc.com/atak-zimy-na-polnocy-kraju-synoptycy-ostrzegaja/000GGIRHGH2U2RPB-C321.jpg" /></a>Synoptycy z Instytutu Meteorologii i Gospodarki Wodnej prognozują intensywne opady śniegu na Pomorzu. Przyrost pokrywy śnieżnej wyniesie od 10 do 15 cm, miejscami nawet do 20 cm. Strefa opadów będzie się przemieszczać w kierunku wschodnim nad wody Bałtyku.</p><br clear="all" />

## Rosyjski szpieg w komisji ds. likwidacji WSI. Macierewicz zapowiada "kroki prawne"
 - [https://wydarzenia.interia.pl/kraj/news-rosyjski-szpieg-w-komisji-ds-likwidacji-wsi-macierewicz-zapo,nId,6460308](https://wydarzenia.interia.pl/kraj/news-rosyjski-szpieg-w-komisji-ds-likwidacji-wsi-macierewicz-zapo,nId,6460308)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 08:20:33+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rosyjski-szpieg-w-komisji-ds-likwidacji-wsi-macierewicz-zapo,nId,6460308"><img align="left" alt="Rosyjski szpieg w komisji ds. likwidacji WSI. Macierewicz zapowiada &quot;kroki prawne&quot;" src="https://i.iplsc.com/rosyjski-szpieg-w-komisji-ds-likwidacji-wsi-macierewicz-zapo/000G3VXFBF8SDG8R-C321.jpg" /></a>&quot;Informuję, że podejmuję kroki prawne w związku z opublikowaniem oszczerstwa opartego na fałszywej informacji jakoby Tomasz L. podejrzewany o szpiegostwo na rzecz Rosji był członkiem Komisji Weryfikacyjnej WSI&quot; - napisał na Twitterze Antoni Macierewicz. Sprawę Tomasza L. - pracownika stołecznego ratusza opisał TVN24. &quot;Znalazł się w wąskim gronie osób, które w 2006 roku otrzymały dostęp do największych sekretów wojskowych służb specjalnych - jako członek komisji likwidacyjnej WSI&quot; - wskazano w materiale.</p><br clear="all" />

## Chiny. Ekspert ocenia: Po złagodzeniu obostrzeń mogą zarazić się miliony ludzi
 - [https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-chiny-ekspert-ocenia-po-zlagodzeniu-obostrzen-moga-zarazic-s,nId,6460304](https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-chiny-ekspert-ocenia-po-zlagodzeniu-obostrzen-moga-zarazic-s,nId,6460304)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 08:18:33+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-chiny-ekspert-ocenia-po-zlagodzeniu-obostrzen-moga-zarazic-s,nId,6460304"><img align="left" alt="Chiny. Ekspert ocenia: Po złagodzeniu obostrzeń mogą zarazić się miliony ludzi" src="https://i.iplsc.com/chiny-ekspert-ocenia-po-zlagodzeniu-obostrzen-moga-zarazic-s/000GGIMHOWJ0BL3M-C321.jpg" /></a>Po złagodzeniu surowych obostrzeń, które dotąd były stosowane w walce z pandemią, w pierwszej dużej fali COVID-19 w Chinach zakażonych może zostać około 60 proc. ludności - jest to blisko 840 mln osób – ocenił doradca władz kraju ds. pandemii koronawirusa Feng Zijian. Dodał, że należy podjąć środki, aby spłaszczyć krzywą zakażeń.</p><br clear="all" />

## Andrzej Placzyński komentuje swoje zatrzymanie przez CBA: Bezpodstawne
 - [https://wydarzenia.interia.pl/kraj/news-andrzej-placzynski-komentuje-swoje-zatrzymanie-przez-cba-bez,nId,6460273](https://wydarzenia.interia.pl/kraj/news-andrzej-placzynski-komentuje-swoje-zatrzymanie-przez-cba-bez,nId,6460273)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 07:33:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-andrzej-placzynski-komentuje-swoje-zatrzymanie-przez-cba-bez,nId,6460273"><img align="left" alt="Andrzej Placzyński komentuje swoje zatrzymanie przez CBA: Bezpodstawne" src="https://i.iplsc.com/andrzej-placzynski-komentuje-swoje-zatrzymanie-przez-cba-bez/000GGIDHQEU2N868-C321.jpg" /></a>W związku z zatrzymaniem mnie przez funkcjonariuszy Centralnego Biura Antykorupcyjnego oświadczam, że po przeprowadzonym przesłuchaniu nie zostałem objęty aresztem - przekazał w oświadczeniu Andrzej Placzyński, dyrektor Sportfive. Ocenił on, że zarówno zatrzymanie, jak i postawiony przez prokuraturę zarzut za wyrządzenie szkody PZPN, są &quot;bezpodstawne&quot;.</p><br clear="all" />

## ISW przeanalizował wystąpienie Putina. "Przygotowuje Rosję na długą wojnę"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-przeanalizowal-wystapienie-putina-przygotowuje-rosje-na-,nId,6460270](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-przeanalizowal-wystapienie-putina-przygotowuje-rosje-na-,nId,6460270)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 07:25:02+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-przeanalizowal-wystapienie-putina-przygotowuje-rosje-na-,nId,6460270"><img align="left" alt="ISW przeanalizował wystąpienie Putina. &quot;Przygotowuje Rosję na długą wojnę&quot;" src="https://i.iplsc.com/isw-przeanalizowal-wystapienie-putina-przygotowuje-rosje-na/000FNPOZL61L07YC-C321.jpg" /></a>Władimir Putin przygotowuje Rosjan na długotrwałą wojnę w celu podbicia Ukrainy, porównuje się do rosyjskiego cara Piotra I – ocenia amerykański Instytut Badań nad Wojną. Ośrodek zwraca uwagę, że Rosjanie prawdopodobnie dostosowali irańskie drony do zimowych warunków.</p><br clear="all" />

## Będzie można zastrzec numer PESEL. Powstanie specjalny rejestr
 - [https://wydarzenia.interia.pl/kraj/news-bedzie-mozna-zastrzec-numer-pesel-powstanie-specjalny-rejest,nId,6460267](https://wydarzenia.interia.pl/kraj/news-bedzie-mozna-zastrzec-numer-pesel-powstanie-specjalny-rejest,nId,6460267)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 07:19:40+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-bedzie-mozna-zastrzec-numer-pesel-powstanie-specjalny-rejest,nId,6460267"><img align="left" alt="Będzie można zastrzec numer PESEL. Powstanie specjalny rejestr" src="https://i.iplsc.com/bedzie-mozna-zastrzec-numer-pesel-powstanie-specjalny-rejest/0003TVMEM02ERO6R-C321.jpg" /></a>- Rząd utworzy specjalny rejestr, w którym po wycieku lub kradzieży danych będzie można zastrzec swój numer PESEL. Po takim zastrzeżeniu nikt już nie weźmie na niego kredytu czy pożyczki - informuje w czwartek &quot;Dziennik Gazeta Prawna&quot;.

</p><br clear="all" />

## Sąd wstrzymał nakaz zapłaty wobec mężczyzny, któremu ukradziono tożsamość
 - [https://wydarzenia.interia.pl/kraj/news-sad-wstrzymal-nakaz-zaplaty-wobec-mezczyzny-ktoremu-ukradzio,nId,6460250](https://wydarzenia.interia.pl/kraj/news-sad-wstrzymal-nakaz-zaplaty-wobec-mezczyzny-ktoremu-ukradzio,nId,6460250)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 06:47:52+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sad-wstrzymal-nakaz-zaplaty-wobec-mezczyzny-ktoremu-ukradzio,nId,6460250"><img align="left" alt="Sąd wstrzymał nakaz zapłaty wobec mężczyzny, któremu ukradziono tożsamość" src="https://i.iplsc.com/sad-wstrzymal-nakaz-zaplaty-wobec-mezczyzny-ktoremu-ukradzio/0005UFS2JQ1WJX3M-C321.jpg" /></a>Sąd wstrzymał wykonanie nakazu zapłaty wobec mężczyzny, któremu ukradziono tożsamość i wykorzystano dane osobowe do zaciągnięcia pożyczki - poinformowała Prokuratura Krajowa. Decyzja zapadła po złożeniu przez Prokuratora Generalnego skargi nadzwyczajnej do Sądu Najwyższego.</p><br clear="all" />

## Ukradł mitsubishi w Niemczech, jechał do Warszawy. Zatrzymali go policjanci
 - [https://wydarzenia.interia.pl/mazowieckie/news-ukradl-mitsubishi-w-niemczech-jechal-do-warszawy-zatrzymali-,nId,6460247](https://wydarzenia.interia.pl/mazowieckie/news-ukradl-mitsubishi-w-niemczech-jechal-do-warszawy-zatrzymali-,nId,6460247)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 06:44:58+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-ukradl-mitsubishi-w-niemczech-jechal-do-warszawy-zatrzymali-,nId,6460247"><img align="left" alt="Ukradł mitsubishi w Niemczech, jechał do Warszawy. Zatrzymali go policjanci" src="https://i.iplsc.com/ukradl-mitsubishi-w-niemczech-jechal-do-warszawy-zatrzymali/000GGI5K9ME4EO7Y-C321.jpg" /></a>Policjanci ze specjalnej grupy &quot;Kobra&quot; zatrzymali 26-latka podejrzanego o kradzież samochodu w Niemczech - poinformowała rzeczniczka Komendy Rejonowej Policji Warszawa VII podinsp. Joanna Węgrzyniak. Złodziej wpadł, gdy skradzionym mitsubishi outlanderem wracał do Warszawy. Mężczyzna był już wcześniej notowany. Grozi mu do 10 lat pozbawienia wolności.</p><br clear="all" />

## Nowy rozkład jazdy pociągów. PKP Intercity zapowiada zmiany
 - [https://wydarzenia.interia.pl/kraj/news-nowy-rozklad-jazdy-pociagow-pkp-intercity-zapowiada-zmiany,nId,6460230](https://wydarzenia.interia.pl/kraj/news-nowy-rozklad-jazdy-pociagow-pkp-intercity-zapowiada-zmiany,nId,6460230)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 06:15:31+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowy-rozklad-jazdy-pociagow-pkp-intercity-zapowiada-zmiany,nId,6460230"><img align="left" alt="Nowy rozkład jazdy pociągów. PKP Intercity zapowiada zmiany " src="https://i.iplsc.com/nowy-rozklad-jazdy-pociagow-pkp-intercity-zapowiada-zmiany/000FAJLY0BNDU7DD-C321.jpg" /></a>Nowy rozkład kolei wejdzie w życie w niedzielę 11 grudnia tego roku. Oznacza to zwiększenie przez PKP Intercity liczby połączeń m.in. pomiędzy Warszawą a Trójmiastem i Krakowem oraz więcej pociągów międzynarodowych - podał kolejowy przewoźnik.</p><br clear="all" />

## Ukraina kontra Rosja w Hadze. Kanada i Holandia przystąpiły do postępowania
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-kontra-rosja-w-hadze-kanada-i-holandia-przystapily-d,nId,6460228](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-kontra-rosja-w-hadze-kanada-i-holandia-przystapily-d,nId,6460228)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 06:08:46+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-kontra-rosja-w-hadze-kanada-i-holandia-przystapily-d,nId,6460228"><img align="left" alt="Ukraina kontra Rosja w Hadze. Kanada i Holandia przystąpiły do postępowania" src="https://i.iplsc.com/ukraina-kontra-rosja-w-hadze-kanada-i-holandia-przystapily-d/000GGI0761M3LOPK-C321.jpg" /></a>Kanada i Holandia w środę złożyły wspólny wniosek do Międzynarodowego Trybunału Sprawiedliwości ONZ w Hadze o włączenie do sprawy Ukraina przeciwko Federacji Rosyjskiej dotyczącej naruszenia Konwencji o zapobieganiu i karaniu zbrodni ludobójstwa, poinformował sekretariat Trybunału. Oba kraje skorzystały z art. 63 Statutu Międzynarodowego Trybunału Sprawiedliwości Organizacji Narodów Zjednoczonych, zgodnie z którym strona umowy międzynarodowej ma prawo interweniować w postępowaniu związanym z jej wykładnią.</p><br clear="all" />

## Peru: Odwołano prezydenta Castillo. Padły zarzuty korupcyjne
 - [https://wydarzenia.interia.pl/zagranica/news-peru-odwolano-prezydenta-castillo-padly-zarzuty-korupcyjne,nId,6460219](https://wydarzenia.interia.pl/zagranica/news-peru-odwolano-prezydenta-castillo-padly-zarzuty-korupcyjne,nId,6460219)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 05:34:56+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-peru-odwolano-prezydenta-castillo-padly-zarzuty-korupcyjne,nId,6460219"><img align="left" alt="Peru: Odwołano prezydenta Castillo. Padły zarzuty korupcyjne" src="https://i.iplsc.com/peru-odwolano-prezydenta-castillo-padly-zarzuty-korupcyjne/000GGHXQMND0S44A-C321.jpg" /></a>Za odwołaniem lewicowego prezydenta Pedro Castillo w środę oddało głos 101 ze 130 członków Kongresu twierdzących, że utracił on moralną legitymację do sprawowania urzędu. Podczas obrad Kongresu padły również zarzuty korupcyjne wobec Castillo. Po odwołaniu Castillo, Kongres powołał na stanowisko prezydenta dotychczasową wiceprezydent Dinę Boluarte .</p><br clear="all" />

## Odkryto DNA sprzed dwóch milionów lat. "To rekord"
 - [https://wydarzenia.interia.pl/zagranica/news-odkryto-dna-sprzed-dwoch-milionow-lat-to-rekord,nId,6460215](https://wydarzenia.interia.pl/zagranica/news-odkryto-dna-sprzed-dwoch-milionow-lat-to-rekord,nId,6460215)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 05:22:09+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-odkryto-dna-sprzed-dwoch-milionow-lat-to-rekord,nId,6460215"><img align="left" alt="Odkryto DNA sprzed dwóch milionów lat. &quot;To rekord&quot;" src="https://i.iplsc.com/odkryto-dna-sprzed-dwoch-milionow-lat-to-rekord/000GGHWZYYYVK8EB-C321.jpg" /></a>Na Grenlandii odkryto DNA sprzed dwóch milionów lat. To jak dotąd rekord w badaniach paleontologicznych – donoszą naukowcy na łamach najnowszego wydania prestiżowego tygodnika &quot;Nature&quot;.
</p><br clear="all" />

## Portugalia: Podejrzane przesyłki w ambasadzie Ukrainy
 - [https://wydarzenia.interia.pl/zagranica/news-portugalia-podejrzane-przesylki-w-ambasadzie-ukrainy,nId,6460214](https://wydarzenia.interia.pl/zagranica/news-portugalia-podejrzane-przesylki-w-ambasadzie-ukrainy,nId,6460214)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 05:21:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-portugalia-podejrzane-przesylki-w-ambasadzie-ukrainy,nId,6460214"><img align="left" alt="Portugalia: Podejrzane przesyłki w ambasadzie Ukrainy" src="https://i.iplsc.com/portugalia-podejrzane-przesylki-w-ambasadzie-ukrainy/000GGHXDGW657LD2-C321.jpg" /></a>Portugalska policja ustaliła tożsamość autora dwóch listów skierowanych w poniedziałek do ambasady Ukrainy w Lizbonie z podejrzaną zawartością. Jak poinformowała w środę wieczorem telewizja CNN Portugal, to osoba przebywająca na terenie jednego z państw Unii Europejskiej.</p><br clear="all" />

## Wojna w Ukrainie. 288. dzień inwazji Rosji na Ukrainę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine,nzId,3492,akt,080631](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine,nzId,3492,akt,080631)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 05:05:46+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine,nzId,3492,akt,080631"><img align="left" alt="Wojna w Ukrainie. 288. dzień inwazji Rosji na Ukrainę" src="https://i.iplsc.com/wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine/000GGHW6UQ5JBYXQ-C321.jpg" /></a>Zaczynamy naszą dzisiejszą relację na żywo z Ukrainy.</p><br clear="all" />

## Wojna w Ukrainie. 288. dzień inwazji Rosji na Ukrainę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine,nzId,3492,akt,080723](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine,nzId,3492,akt,080723)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 05:05:46+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine,nzId,3492,akt,080723"><img align="left" alt="Wojna w Ukrainie. 288. dzień inwazji Rosji na Ukrainę" src="https://i.iplsc.com/wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine/000GGHW6UQ5JBYXQ-C321.jpg" /></a>Zaczynamy naszą dzisiejszą relację na żywo z Ukrainy.</p><br clear="all" />

## Wojna w Ukrainie. 288. dzień inwazji Rosji na Ukrainę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine,nzId,3492,akt,080747](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine,nzId,3492,akt,080747)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 05:05:46+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine,nzId,3492,akt,080747"><img align="left" alt="Wojna w Ukrainie. 288. dzień inwazji Rosji na Ukrainę" src="https://i.iplsc.com/wojna-w-ukrainie-288-dzien-inwazji-rosji-na-ukraine/000GGHW6UQ5JBYXQ-C321.jpg" /></a>Zaczynamy naszą dzisiejszą relację na żywo z Ukrainy.</p><br clear="all" />

## Inflacja pogrzebie grosze? Ekonomista ostrzega przed "efektem cappuccino"
 - [https://wydarzenia.interia.pl/kraj/news-inflacja-pogrzebie-grosze-ekonomista-ostrzega-przed-efektem-,nId,6454414](https://wydarzenia.interia.pl/kraj/news-inflacja-pogrzebie-grosze-ekonomista-ostrzega-przed-efektem-,nId,6454414)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-12-08 05:04:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-inflacja-pogrzebie-grosze-ekonomista-ostrzega-przed-efektem-,nId,6454414"><img align="left" alt="Inflacja pogrzebie grosze? Ekonomista ostrzega przed &quot;efektem cappuccino&quot;" src="https://i.iplsc.com/inflacja-pogrzebie-grosze-ekonomista-ostrzega-przed-efektem/000GG1NICRSQDKTE-C321.jpg" /></a>O istnieniu jedno-, dwu- i pięciogroszówek dało się zapomnieć nawet przed inflacją bijącą rekordy. Teraz najdrobniejszy bilon wart jest jeszcze mniej, więc gdzie tkwi sens w jego dalszej produkcji i używaniu? - Narodowy Bank Polski dokłada do jego emisji. Nadal niektórzy uznają jednak, że posługiwanie się nim jest wygodne - komentuje dr hab. Paweł Marszałek z poznańskiego Uniwersytetu Ekonomicznego. Jak ponadto zauważają eksperci, pozbycie się &quot;miedziaków&quot; może wywołać jeszcze większy wzrost cen za sprawą &quot;efektu cappuccino&quot;.</p><br clear="all" />


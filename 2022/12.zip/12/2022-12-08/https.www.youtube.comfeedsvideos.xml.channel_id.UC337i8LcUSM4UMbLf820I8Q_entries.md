# Source:Just Some Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q, language:en-US

## My Struggle: A Kanye West Story
 - [https://www.youtube.com/watch?v=9aOYkwR4Rvo](https://www.youtube.com/watch?v=9aOYkwR4Rvo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q
 - date published: 2022-12-08 15:00:10+00:00

My Struggle: A Kanye West Story (Yes, this is the THIRD upload)
----------------------------------------------------------------------------------------------
Art by Just Some Guy

Original trailer concept: Bleach Opening 01

Music: "Enkon Hakuchuumu" by Sakagami Souichi - Copyright (C) 2015 Trial & Error/Sakagami Souichi All rights reserved.

Trial & Error: http://www.tandess.com/en/music/


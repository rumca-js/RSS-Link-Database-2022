# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## Be a Finance Squirrel
 - [https://lifehacker.com/be-a-finance-squirrel-1849871811](https://lifehacker.com/be-a-finance-squirrel-1849871811)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 22:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--euWxSGuk--/c_fit,fl_progressive,q_80,w_636/671bdec7a6d09be66d6e0d4781eb4f01.jpg" /><p>When it comes to tricking yourself into saving more money, think like a squirrel. Just like squirrels bury nuts  to prepare for winter, we can squirrel money in order to prepare for economic dry spells. And while we’re taking money lessons from squirrels, they crucially don’t store all their bounty in one place. </p><p><a href="https://lifehacker.com/be-a-finance-squirrel-1849871811">Read more...</a></p>

## Turn (Almost) Any Store-Bought Cookie Into a Truffle
 - [https://lifehacker.com/turn-almost-any-store-bought-cookie-into-a-truffle-1849871666](https://lifehacker.com/turn-almost-any-store-bought-cookie-into-a-truffle-1849871666)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--lUMyHPIb--/c_fit,fl_progressive,q_80,w_636/0a111d5b9ec3985e3ed455a81fa02cc7.jpg" /><p>I bought my first food processor while I was still in college, working towards a chemistry degree that would get far less use than the appliance. One of the first things I made was a batch of <a href="https://www.allrecipes.com/recipe/127491/easy-oreo-truffles/" rel="noopener noreferrer" target="_blank">Easy Oreo truffles</a>, which impressed all of my lab mates and required a mere three ingredients—cookies, cream cheese, and some…</p><p><a href="https://lifehacker.com/turn-almost-any-store-bought-cookie-into-a-truffle-1849871666">Read more...</a></p>

## Savory Choux Puffs Are Where the Party's At
 - [https://lifehacker.com/savory-choux-puffs-are-where-the-partys-at-1849871346](https://lifehacker.com/savory-choux-puffs-are-where-the-partys-at-1849871346)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--a9IEBtuw--/c_fit,fl_progressive,q_80,w_636/364961a3e144dbd59685269b627950dd.jpg" /><p>With winter holidays and the new year quickly rolling in, I think it’s safe to say, it’s officially party time. Whether you’re hosting or contributing snacks, these occasions require a strong rotation of hors d’oeuvres. For December holidays, and beyond, savory choux puffs are an easy and versatile appetizer,…</p><p><a href="https://lifehacker.com/savory-choux-puffs-are-where-the-partys-at-1849871346">Read more...</a></p>

## The 10 Best Chrome Extensions for Holiday Shopping
 - [https://lifehacker.com/the-10-best-chrome-extensions-for-holiday-shopping-1849869457](https://lifehacker.com/the-10-best-chrome-extensions-for-holiday-shopping-1849869457)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--PsLfwgFK--/c_fit,fl_progressive,q_80,w_636/acf5d7cbd7e068ff2fe853a943c846e0.jpg" /><p>Long gone are the days of driving to the mall, battling crowds, and fighting tooth and nail for the last toy on the shelf. Holiday shopping is all online now, and that presents new varieties of stress. How do you know if you’re getting the best deal? Has this item been cheaper in the past? Are you missing out on extra…</p><p><a href="https://lifehacker.com/the-10-best-chrome-extensions-for-holiday-shopping-1849869457">Read more...</a></p>

## TikTok's Stupid Heating 'Hack' Is Dangerous, People
 - [https://lifehacker.com/tiktoks-stupid-heating-hack-is-dangerous-people-1849870601](https://lifehacker.com/tiktoks-stupid-heating-hack-is-dangerous-people-1849870601)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--OpCmE7ht--/c_fit,fl_progressive,q_80,w_636/a95b22d942f0652574daa18c10192705.jpg" /><p>You probably know <a href="https://lifehacker.com/everything-you-shouldnt-do-when-using-a-space-heater-1848237212">space heaters can be dangerous</a> and have to be used very carefully, so the appeal of a TikTok hack for making your own heater might stem from an interest in <em>avoiding</em> a fire hazard. Unfortunately, the DIY heater is dangerous itself and after a fire in England was attributed to the trick, <a href="https://www.ksat.com/news/local/2022/12/07/firefighters-warn-against-recreating-dangerous-viral-heating-hack/" rel="noopener noreferrer" target="_blank">fire officials…</a></p><p><a href="https://lifehacker.com/tiktoks-stupid-heating-hack-is-dangerous-people-1849870601">Read more...</a></p>

## Your Jeep's Engine Might Just Shut Down
 - [https://lifehacker.com/these-jeeps-are-being-recalled-for-a-possible-sudden-en-1849870560](https://lifehacker.com/these-jeeps-are-being-recalled-for-a-possible-sudden-en-1849870560)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 19:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--YXPJ0dFS--/c_fit,fl_progressive,q_80,w_636/2d2cd302c45bd7436c1295ff24f7cd5b.jpg" /><p>Fiat Chrysler Automobiles is voluntarily recalling about 62,000 Jeep Wrangler 4xe electric hybrid SUV vehicles for an unknown engine shut-down issue, according to a <a href="https://static.nhtsa.gov/odi/rcl/2022/RCLRPT-22V865-9895.PDF" rel="noopener noreferrer" target="_blank">report from the National Highway Traffic Safety Administration</a> (NHTSA).<br /></p><p><a href="https://lifehacker.com/these-jeeps-are-being-recalled-for-a-possible-sudden-en-1849870560">Read more...</a></p>

## 11 Deeply Strange U.S. Tourist Spots
 - [https://lifehacker.com/11-deeply-strange-u-s-tourist-spots-1849870496](https://lifehacker.com/11-deeply-strange-u-s-tourist-spots-1849870496)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 19:19:25+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--bud26Ba1--/c_fit,fl_progressive,q_80,w_636/c36d2b75c9c4a06351f1080845cdbe67.jpg" /><p>If you’re road-tripping this holiday season and really want to get in touch with America, forget about the “approved” attractions along the way—your Mount Rushmores, your Yellowstones—and hit up these 11 strange and wondrous tourist spots instead. Each wonder offers a unique, not-officially-sanctioned look into a…</p><p><a href="https://lifehacker.com/11-deeply-strange-u-s-tourist-spots-1849870496">Read more...</a></p>

## Marcus Samuelsson’s Favorite Dish to Cook With His Son
 - [https://lifehacker.com/marcus-samuelsson-s-favorite-dish-to-cook-with-his-son-1849864949](https://lifehacker.com/marcus-samuelsson-s-favorite-dish-to-cook-with-his-son-1849864949)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--9PkfNrVM--/c_fit,fl_progressive,q_80,w_636/7308f6d0d2ed54859beaf107091ac75c.jpg" /><p><a href="https://lifehacker.com/marcus-samuelsson-s-favorite-dish-to-cook-with-his-son-1849864949">Read more...</a></p>

## Use Cling Wrap to Keep Your Refrigerator Clean
 - [https://lifehacker.com/use-cling-wrap-to-keep-your-refrigerator-clean-1849869857](https://lifehacker.com/use-cling-wrap-to-keep-your-refrigerator-clean-1849869857)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 17:34:02+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--EkskmAKa--/c_fit,fl_progressive,q_80,w_636/293f366158976969b31c317d99f46b53.jpg" /><p>You probably don’t look forward to cleaning the dripped mashed potatoes, gravy, and soup from your poor fridge. But there’s a way to make that clean-up a lot simpler, and all you need is cling wrap.<br /></p><p><a href="https://lifehacker.com/use-cling-wrap-to-keep-your-refrigerator-clean-1849869857">Read more...</a></p>

## Use House Sitting to Travel on a Budget
 - [https://lifehacker.com/use-house-sitting-to-travel-on-a-budget-1849869548](https://lifehacker.com/use-house-sitting-to-travel-on-a-budget-1849869548)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--61PcpeY6--/c_fit,fl_progressive,q_80,w_636/d0ef65a05f4ec98990ec0b4e848560c0.jpg" /><p>With <a href="https://lifehacker.com/the-best-vacation-rental-alternatives-to-airbnb-1849088885">Airbnb’s ridiculous fees</a> these days, most travelers are eager for some kind of alternative for their next homestay. The most underrated option, so long as you’re willing to  earn your keep, is <em>house sitting</em>. But how do you go about finding someone who needs a house-sitter at your dream destination? Here’s what…</p><p><a href="https://lifehacker.com/use-house-sitting-to-travel-on-a-budget-1849869548">Read more...</a></p>

## 20 of the Saddest Christmas Movies of All Time
 - [https://lifehacker.com/20-of-the-saddest-christmas-movies-of-all-time-1849865801](https://lifehacker.com/20-of-the-saddest-christmas-movies-of-all-time-1849865801)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--mlllGelG--/c_fit,fl_progressive,q_80,w_636/ea65048d95d9bb7d495c826d979f0dfa.jpg" /><p>The holidays are a time for big emotions. The weather’s extreme (in many places), there’s too much to do, and family gatherings offer up wild swings of intense feeling: joy, excitement, apprehension, annoyance, exhaustion. The movies (and life) teach us that any holiday meal with a sufficient number of guests must…</p><p><a href="https://lifehacker.com/20-of-the-saddest-christmas-movies-of-all-time-1849865801">Read more...</a></p>

## Stop Buying New Apple Devices
 - [https://lifehacker.com/stop-buying-new-apple-devices-1849868903](https://lifehacker.com/stop-buying-new-apple-devices-1849868903)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--UgKcDyLz--/c_fit,fl_progressive,q_80,w_636/5005b4ae9a21b0b86302b2487fe4512c.jpg" /><p>Whether you love or hate Apple, we can all agree on one thing: Their products are <em>expensive</em>. Apple’s iPhones can easily cost over $1,000, and MacBooks require a mortgage just to look at them. The thing is, you don’t need to buy these devices new in order to get the <em>perks</em> of buying new.<br /></p><p><a href="https://lifehacker.com/stop-buying-new-apple-devices-1849868903">Read more...</a></p>

## Four Ways to DIY a Christmas Tree
 - [https://lifehacker.com/four-ways-to-diy-a-christmas-tree-1849867789](https://lifehacker.com/four-ways-to-diy-a-christmas-tree-1849867789)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 15:36:23+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vg03ayI6--/c_fit,fl_progressive,q_80,w_636/df2ca5cc81e6940329b544c5b723e9ac.jpg" /><p>Real Christmas trees don’t work for everyone. You might have destructive pets, toddlers, a small apartment, or a small budget. You might have allergies to trees or the mold spores they can bring in with them. You might just like to do things differently. Whatever the reason, there are lots of ways to craft your own…</p><p><a href="https://lifehacker.com/four-ways-to-diy-a-christmas-tree-1849867789">Read more...</a></p>

## 10 of the Best Gifts for Soccer Fans
 - [https://lifehacker.com/10-of-the-best-gifts-for-soccer-fans-1849866009](https://lifehacker.com/10-of-the-best-gifts-for-soccer-fans-1849866009)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--baqA7Acw--/c_fit,fl_progressive,q_80,w_636/e6f5daeec594b773a503a2a82e082243.jpg" /><p>Soccer is a game of passion and loyalty. Therefore, when suggesting gift ideas for the soccer enthusiast in your life, I will refrain from recommending any that are specific to a particular team or player (that’s not the sort of thing you want to get wrong, and I’m not about to set you up for failure). However, some…</p><p><a href="https://lifehacker.com/10-of-the-best-gifts-for-soccer-fans-1849866009">Read more...</a></p>

## How to Make a Tofu Scramble That Doesn't Suck
 - [https://lifehacker.com/how-to-make-a-tofu-scramble-that-doesnt-suck-1849865839](https://lifehacker.com/how-to-make-a-tofu-scramble-that-doesnt-suck-1849865839)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 14:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--stBf7-8r--/c_fit,fl_progressive,q_80,w_636/acbf6dd3d0710a3c4e7a1737ecd6d894.jpg" /><p>Tofu scrambles are often the only vegan option on a brunch menu, and to be perfectly honest, they don’t do that much for me. A pile of barely-cooked tofu rubble seasoned with nutritional yeast, turmeric, way too much dried oregano (why is it always oregano?), and nowhere near enough salt may be a nutritionally…</p><p><a href="https://lifehacker.com/how-to-make-a-tofu-scramble-that-doesnt-suck-1849865839">Read more...</a></p>

## Make the Best Lazy Chicken Pot Pie From a Can of Soup
 - [https://lifehacker.com/make-the-best-lazy-chicken-pot-pie-from-a-can-of-soup-1849865516](https://lifehacker.com/make-the-best-lazy-chicken-pot-pie-from-a-can-of-soup-1849865516)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-12-08 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--9V4KooVV--/c_fit,fl_progressive,q_80,w_636/b6c05c0d139749ecfe4f363190ecb460.jpg" /><p>The best pot pies are homemade ones, but lazy pot pies are the best answer to cold weather <em>and</em> low energy. You have every right to eat thick meat stews in pie form, but not everyone has the gumption to toil away for hours. There is a way to have it all. Summon up your inner Sandra Lee: This hearty dish is made with…</p><p><a href="https://lifehacker.com/make-the-best-lazy-chicken-pot-pie-from-a-can-of-soup-1849865516">Read more...</a></p>


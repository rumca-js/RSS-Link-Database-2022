# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Five Reasons Marvel Phase 4 Sucked
 - [https://www.youtube.com/watch?v=8rZVvSohF-Q](https://www.youtube.com/watch?v=8rZVvSohF-Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-12-08 17:57:39+00:00

The recent leaks about Marvel being extremely unhappy with Phase 4's reception got me thinking about how and why this franchise went off the rails. So let's take a look, shall we? 

Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker


# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Soboń: Mamy przestrzeń do tego, aby deficyt był wyższy
 - [https://www.bankier.pl/wiadomosc/Sobon-Mamy-przestrzen-do-tego-aby-deficyt-byl-wyzszy-8453695.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sobon-Mamy-przestrzen-do-tego-aby-deficyt-byl-wyzszy-8453695.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 21:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/1/d0dbd8661ce27d-948-568-0-66-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mamy przestrzeń do tego, by deficyt - nie tylko budżetowy - był wyższy - powiedział w czwartek wiceminister finansów Artur Soboń. Dodał, że deficyt "oczywiście" będzie wyższy, bo jest "konieczność większych wydatków w związku z osłonami energetycznymi".</p>

## Morawiecki: Jeśli będziemy mogli rządzić dalej, zbudujemy armię, która poradzi sobie nawet sama
 - [https://www.bankier.pl/wiadomosc/Morawiecki-Jesli-bedziemy-mogli-rzadzic-dalej-zbudujemy-armie-ktora-poradzi-sobie-nawet-sama-8453682.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Morawiecki-Jesli-bedziemy-mogli-rzadzic-dalej-zbudujemy-armie-ktora-poradzi-sobie-nawet-sama-8453682.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 21:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/83c13e08c1e080-948-568-0-160-2920-1751.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeżeli wyborcy umożliwią nam rządy przez kolejną kadencję, zbudujemy armię, która w razie konfliktu będzie w stanie poradzić sobie nawet sama i to nie przez krótki czas, a co najmniej tak jak armia ukraińska - powiedział premier Mateusz Morawiecki w wywiadzie dla wPolityce.pl.</p>

## S&P500 przerywa spadkową serię
 - [https://www.bankier.pl/wiadomosc/S-P500-przerywa-spadkowa-serie-8453673.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/S-P500-przerywa-spadkowa-serie-8453673.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 21:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/a/6c420247414769-948-568-40-90-1960-1175.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po pięciu spadkowych sesjach z rzędu S&amp;P500 zakończył
czwartkową sesję na plusie. Był to dzień z prawie pustym kalendarium
makroekonomicznym i korporacyjnym.</p>

## W święta na brytyjskich lotniskach szykują się poważne utrudnienia. Rząd apeluje, by "przemyśleć podróż"
 - [https://www.bankier.pl/wiadomosc/W-swieta-na-brytyjskich-lotniskach-szykuja-sie-powazne-utrudnienia-Rzad-apeluje-by-przemyslec-podroz-8453670.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-swieta-na-brytyjskich-lotniskach-szykuja-sie-powazne-utrudnienia-Rzad-apeluje-by-przemyslec-podroz-8453670.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 20:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/78b245bffec81d-948-567-0-50-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ludzie powinni dokładnie przemyśleć wyjazdy w okresie świąteczno-noworocznym, bo przez strajk funkcjonariuszy straży granicznej, dokonujących kontroli paszportowych, należy się spodziewać poważnych zakłóceń na lotniskach - ostrzegła w czwartek szefowa brytyjskiego MSW Suella Braverman.</p>

## Kaczyński: Nie stać nas na emerytury stażowe
 - [https://www.bankier.pl/wiadomosc/Kaczynski-Nie-stac-nas-na-emerytury-stazowe-8453649.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaczynski-Nie-stac-nas-na-emerytury-stazowe-8453649.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 19:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/239db6bd55b149-948-568-0-123-4477-2686.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie stać nas na emerytury stażowe, bo ich wprowadzenie oznaczałoby, że na emerytury przechodziłyby kobiety niewiele po pięćdziesiątce, czyli po prostu młódki - mówił w Chojnicach prezes PiS Jarosław Kaczyński.</p>

## Bezpłatny odcinek A4 między Katowicami a Krakowem? Minister zabrał głos
 - [https://www.bankier.pl/wiadomosc/Bezplatny-odcinek-A4-miedzy-Katowicami-a-Krakowem-Minister-zabral-glos-8453646.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bezplatny-odcinek-A4-miedzy-Katowicami-a-Krakowem-Minister-zabral-glos-8453646.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 19:27:00+00:00

<p>W 2027 r. kończy się koncesja na odcinek autostrady A4 między Katowicami a Krakowem; chcielibyśmy, by ten odcinek był bezpłatny dla kierowców - przekazał w czwartek minister infrastruktury Andrzej Adamczyk. Dodał, że plan zakłada rozbudowę tej trasy o dodatkowy pas ruchu.</p>

## Przyłębska: NSA wyszedł poza swoje kompetencje; nie zna konstytucji
 - [https://www.bankier.pl/wiadomosc/Przylebska-NSA-wyszedl-poza-swoje-kompetencje-nie-zna-konstytucji-8453635.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przylebska-NSA-wyszedl-poza-swoje-kompetencje-nie-zna-konstytucji-8453635.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 19:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/d/ccbe7d50cd23a7-945-560-60-288-1187-712.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Naczelny Sąd Administracyjny wyszedł poza swoje kompetencje, nie jest kompetencją NSA ocenianie zasadności, czy prawomocności wyboru sędziów TK - powiedziała w czwartek prezes TK Julia Przyłębska. Jak oceniła, "to pokazuje, że NSA nie zna konstytucji".</p>

## "Rzeczywistość" Malczewskiego warunkowo sprzedana na aukcji za 17 mln zł
 - [https://www.bankier.pl/wiadomosc/Rzeczywistosc-Malczewskiego-warunkowo-sprzedana-na-aukcji-za-17-mln-zl-8453620.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzeczywistosc-Malczewskiego-warunkowo-sprzedana-na-aukcji-za-17-mln-zl-8453620.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 18:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/d/517fe7dda3018e-948-568-49-0-998-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Obraz "Rzeczywistość" Jacka Malczewskiego został w czwartek warunkowo sprzedany na aukcji w DESIE za 17 mln  zł. Do realizacji transakcji i wydania obrazu dojdzie, gdy zostanie ustalony stan prawny obrazu.</p>

## Analitycy ING prognozują inflację w 2023 r.
 - [https://www.bankier.pl/wiadomosc/Analitycy-ING-prognozuja-inflacje-w-2023-r-8453600.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Analitycy-ING-prognozuja-inflacje-w-2023-r-8453600.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 17:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/b/872af95432d915-948-568-0-279-1395-837.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spodziewamy się średniorocznej inflacji w 2023 roku na poziomie 14,5 proc. r/r oraz około 7,5 proc.  w roku 2024 - napisali w czwartkowym komentarzu analitycy ING Banku Śląskiego. Wskazali, że przy obecnym nastawieniu RPP  szanse na podwyżki stóp w tym cyklu są minimalne.</p>

## Wraca sprawa podatku Ciechu sprzed 10 lat. NSA wydał decyzję
 - [https://www.bankier.pl/wiadomosc/NSA-uchylil-wyrok-WSA-oddalajacy-skarge-Ciechu-dot-podatku-za-2012-r-8453599.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NSA-uchylil-wyrok-WSA-oddalajacy-skarge-Ciechu-dot-podatku-za-2012-r-8453599.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 17:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/a2d1785f5b419d-945-560-0-50-987-592.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Naczelny Sąd Administracyjny uchylił wyrok Wojewódzkiego Sądu Administracyjnego w Krakowie oddalający skargę Ciechu na decyzję Naczelnika Małopolskiego Urzędu Celno-Skarbowego dotyczącą zobowiązania podatkowego spółki z tytułu podatku dochodowego od osób prawnych za 2012 rok - podał Ciech w komunikacie.</p>

## Media: potężne wybuchy w rosyjskiej bazie wojskowej w okupowanym Berdiańsku
 - [https://www.bankier.pl/wiadomosc/Media-potezne-wybuchy-w-rosyjskiej-bazie-wojskowej-w-okupowanym-Berdiansku-8453588.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-potezne-wybuchy-w-rosyjskiej-bazie-wojskowej-w-okupowanym-Berdiansku-8453588.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 17:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/c/4033d6ed7d88d8-948-568-63-70-2724-1634.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W rosyjskiej bazie wojskowej w okupowanym mieście Berdiańsk, na południu Ukrainy, doszło do trzech potężnych wybuchów, a następnie 15 eksplozji o mniejszej sile; na miejscu zdarzenia wybuchł duży pożar - poinformował portal Suspilne za lojalną wobec Kijowa przewodniczącą administracji Berdiańska Wiktorią Haliciną.</p>

## Więcej pieniędzy dla OPP. Nadchodzą zmiany w podatkach
 - [https://www.bankier.pl/wiadomosc/Wiecej-pieniedzy-dla-OPP-Nadchodza-zmiany-w-podatkach-8453581.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiecej-pieniedzy-dla-OPP-Nadchodza-zmiany-w-podatkach-8453581.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 17:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/d/679423d249d8b8-948-568-0-227-3497-2098.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Projekt rozporządznia do ustawy podwyższajacej z 1 proc. na 1,5 proc. kwoty podatku przekazanej na wskazaną przez podatnika organizację pożytku publicznego (OPP) został opublikowany w czwartek na stronach Rządowego Centrum Legislacji.</p>

## Amunicja kasetowa dla Ukrainy? "Biały Dom rozważa prośbę"
 - [https://www.bankier.pl/wiadomosc/Amunicja-kasetowa-dla-Ukrainy-Bialy-Dom-rozwaza-prosbe-8453580.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Amunicja-kasetowa-dla-Ukrainy-Bialy-Dom-rozwaza-prosbe-8453580.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 17:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/e/ce9dc4c333dc73-948-568-0-15-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Administracja prezydenta USA Joe Bidena, odpowiadając na apele władz Ukrainy, rozważa przekazanie Kijowowi amunicji kasetowej - poinformowała w czwartek stacja CNN.</p>

## Action zaprasza do sprzedaży akcji spółki
 - [https://www.bankier.pl/wiadomosc/Action-zaprasza-do-sprzedazy-do-300-tys-akcji-spolki-po-15-3-zl-za-papier-8453564.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Action-zaprasza-do-sprzedazy-do-300-tys-akcji-spolki-po-15-3-zl-za-papier-8453564.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 16:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/2/efc49de9eb561d-948-568-0-255-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Action zaprasza do składania ofert sprzedaży akcji spółki. Chce kupić do 300 tys. akcji własnych, stanowiących do 1,4972 proc. kapitału zakładowego - podała spółka w komunikacie. Proponowana cena nabycia akcji wynosi 15,30 zł za akcję.</p>

## Arabia Saudyjska i Chiny zacieśniają współpracę
 - [https://www.bankier.pl/wiadomosc/Arabia-Saudyjska-i-Chiny-zaciesniaja-wspolprace-8453560.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Arabia-Saudyjska-i-Chiny-zaciesniaja-wspolprace-8453560.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 16:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/1/40e21ddf44f569-948-568-112-78-3272-1963.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W czasie wizyty przywódcy Chin Xi Jinpinga w Arabii Saudyjskiej oba kraje podpisały szereg strategicznych umów, w tym z udziałem koncernu Huawei, którego ekspansja w regionie Zatoki Perskiej wywołuje obawy w USA – podała w czwartek agencja Reutera.</p>

## Gwałtownie wzrośnie ilość autostrad? Adamczyk komentuje
 - [https://www.bankier.pl/wiadomosc/Gwaltownie-wzrosnie-ilosc-autostrad-Adamczyk-komentuje-8453551.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gwaltownie-wzrosnie-ilosc-autostrad-Adamczyk-komentuje-8453551.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 16:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/f2a5b6125332aa-945-560-5-12-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie będzie zmiany statusu dróg ekspresowych na autostrady - powiedział w czwartek PAP minister infrastruktury Andrzej Adamczyk.</p>

## ZNP znów protestuje. "Rząd wybiera jednego partnera społecznego i nie rozmawia z innymi"
 - [https://www.bankier.pl/wiadomosc/ZNP-znow-protestuje-Rzad-wybiera-jednego-partnera-spolecznego-i-nie-rozmawia-z-innymi-8453535.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ZNP-znow-protestuje-Rzad-wybiera-jednego-partnera-spolecznego-i-nie-rozmawia-z-innymi-8453535.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 16:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/1/5f64adb6cc2f80-948-568-0-90-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przeciwko powołaniu zespołu roboczego do spraw wypracowania porozumienia między rządem RP a Komisją Krajową NSZZ Solidarność zaprotestował w czwartek przewodniczący Związku Nauczycielstwa Polskiego (ZNP) Sławomir Broniarz. Rząd nie może wybierać jednego partnera społecznego i nie rozmawiać z innymi - ocenił.</p>

## Amica chce osiągnąć neutralność klimatyczną do 2040 roku
 - [https://www.bankier.pl/wiadomosc/Amica-w-ramach-strategii-zrownowazonego-rozwoju-chce-osiagnac-neutralnosc-klimatyczna-do-2040-roku-8453509.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Amica-w-ramach-strategii-zrownowazonego-rozwoju-chce-osiagnac-neutralnosc-klimatyczna-do-2040-roku-8453509.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 15:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/8/baa5d1df8f7896-870-522-0-145-870-522.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amica w ramach strategii zrównoważonego rozwoju chce do 2040 roku osiągnąć neutralność klimatyczną w zakresach, na które ma bezpośrednio wpływ i które kontroluje w procesach produkcyjnych -  poinformował podczas uroczystości 25-lecia obecności spółki na GPW członek zarządu Michał Rakowski.</p>

## Budimex ma umowę na rozbudowę kompleksu wojskowego za 294,6 mln zł netto
 - [https://www.bankier.pl/wiadomosc/Budimex-ma-umowe-na-rozbudowe-kompleksu-wojskowego-za-294-6-mln-zl-netto-8453510.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Budimex-ma-umowe-na-rozbudowe-kompleksu-wojskowego-za-294-6-mln-zl-netto-8453510.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 15:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/e/35df30f4bed6f2-948-568-4-289-1892-1135.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Budimex zawarł ze Skarbem Państwa - Ministrem Obrony Narodowej umowę na wykonanie robót budowlano-montażowych w ramach rozbudowy kompleksu wojskowego w Siedlcach - podał Budimex w komunikacie. Wartość umowy to 294,6 mln zł netto.</p>

## Turcja nadal będzie blokować statki z rosyjską ropą
 - [https://www.bankier.pl/wiadomosc/Turcja-nadal-bedzie-blokowac-statki-z-rosyjska-ropa-8453467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Turcja-nadal-bedzie-blokowac-statki-z-rosyjska-ropa-8453467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 14:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/1bab3a7ef86c17-948-568-72-120-1776-1065.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będziemy dalej blokować tankowce, które nie posiadają odpowiednich dowodów pełnego ubezpieczenia - poinformował w czwartek turecki urząd morski po tym, gdy USA zapewniły Turcję dzień wcześniej, że wprowadzenie limitu cen rosyjskiej ropy nie wymaga dodatkowej weryfikacji ubezpieczeń statków.</p>

## Chorwacja stanie się częścią strefy Schengen od 2023 roku
 - [https://www.bankier.pl/wiadomosc/Chorwacja-stanie-sie-czescia-strefy-Schengen-od-2023-roku-8453445.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chorwacja-stanie-sie-czescia-strefy-Schengen-od-2023-roku-8453445.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 14:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/5/464993b65c3f02-948-568-18-104-1481-888.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Państwa członkowskie UE potwierdziły w czwartek przyjęcie Chorwacji do strefy Schengen. Jednocześnie odmówiły dostępu do niej Rumunii i Bułgarii.</p>

## Glapiński komentuje sytuację gospodarczą. "Recesji nie przewidujemy"
 - [https://www.bankier.pl/wiadomosc/Glapinski-komentuje-sytuacje-gospodarcza-Recesji-nie-przewidujemy-8453443.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Glapinski-komentuje-sytuacje-gospodarcza-Recesji-nie-przewidujemy-8453443.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 14:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/b/a31c292b25084c-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezes NBP, Adam Glapiński komentuje ostatnią decyzję Rady Polityki Pieniężnej ws. stóp procentowych. Początek roku może być jeszcze bolesny z powodu wysokiej inflacji, a na pocieszenie przewiduje termin, kiedy inflacja zacznie szybko spadać. Glapiński podkreślił, że "obecny poziom stóp procentowych RPP uważa za optymalny".
 </p>

## PKO BP: Uprawnienia do emisji CO2 mocno drożeją w IV kw. '22
 - [https://www.bankier.pl/wiadomosc/PKO-BP-Uprawnienia-do-emisji-CO2-mocno-drozeja-w-IV-kw-22-8453438.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKO-BP-Uprawnienia-do-emisji-CO2-mocno-drozeja-w-IV-kw-22-8453438.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 14:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/5/02f270534b61d0-948-568-117-0-1768-1060.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Skok cen uprawnień do emisji CO2 w ostatnim kwartale roku sięga 27 proc.  - poinformował w czwartek PKO BP. Analitycy dodali, że rynkowi sprzyjał spadek temperatur w Europie i zwiększone zapotrzebowanie na ciepło, co przyczyniło się do wzrostów cen paliw i energii, w tym węgla.</p>

## Na Podhalu ruszają kolejne wyciągi. Miłośnicy nart będą zachwyceni
 - [https://www.bankier.pl/wiadomosc/Na-Podhalu-ruszaja-kolejne-wyciagi-Milosnicy-nart-beda-zachwyceni-8453414.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Na-Podhalu-ruszaja-kolejne-wyciagi-Milosnicy-nart-beda-zachwyceni-8453414.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 13:54:00+00:00

<p>W weekend na Podhalu ruszają kolejne stacje narciarskie. Narciarze będą mogli jeździć na stokach w Białce i Bukowinie Tatrzańskiej.</p>

## PGE rozpoczęła budowę farmy fotowoltaicznej o mocy 100 MW
 - [https://www.bankier.pl/wiadomosc/PGE-rozpoczela-budowe-farmy-fotowoltaicznej-o-mocy-100-MW-8453408.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PGE-rozpoczela-budowe-farmy-fotowoltaicznej-o-mocy-100-MW-8453408.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 13:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/1/2d43026a7eb419-948-568-240-0-3600-2159.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa PGE rozpoczęła na Podkarpaciu budowę farmy fotowoltaicznej PV Jeziórko o mocy 100 MW, która ma powstać do końca 2023 r. - poinformowała spółka w komunikacie prasowym.</p>

## Zniżki na święta? Wybieramy dla was najlepsze oferty
 - [https://www.bankier.pl/wiadomosc/Znizki-na-swieta-Wybieramy-dla-was-najlepsze-oferty-8452020.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Znizki-na-swieta-Wybieramy-dla-was-najlepsze-oferty-8452020.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 13:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/f/c673874e0691bd-948-567-0-32-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Święta coraz bliżej, szał na kupowanie prezentów 
zaraz osiągnie
kulminację. Wielu z nas zapewne wyruszy na polowanie w dwie najbliższe
niedziele, kiedy, przebijając się przez tłumy kupujących, będzie 
próbowało zdobyć wszystko, co trzeba i nie zbankrutować. Ze swojej 
strony będziemy chcieli wskazać
Wam kilka promocji, jakie udało nam się znaleźć w sieci. Oczywiście, 
lista
będzie się zmieniać, bo i oferty przychodzą i odchodzą.</p>

## Ćwiczenia rezerwy w 2023 r. Szef CWCR tłumaczy kto zostanie powołany
 - [https://www.bankier.pl/wiadomosc/Cwiczenia-rezerwy-w-2023-r-Szef-CWCR-tlumaczy-kto-zostanie-powolany-8453386.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Cwiczenia-rezerwy-w-2023-r-Szef-CWCR-tlumaczy-kto-zostanie-powolany-8453386.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 13:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/9489f6ef3a2f03-945-567-0-90-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na ćwiczenia rezerwy trafi minimalna liczba osób bez wcześniejszego przeszkolenia wojskowego - zapewnił szef Centralnego Wojskowego Centrum Rekrutacji płk Mirosław Bryś. Dodał, że osoby takie zostaną zaproszone do centrów rekrutacji, gdzie zostanie im zaproponowane dwudniowe szkolenie wojskowe.</p>

## MSZ odradza podróże do Peru. "Niestabilna sytuacja polityczna i możliwe zamieszki"
 - [https://www.bankier.pl/wiadomosc/MSZ-odradza-podroze-do-Peru-Niestabilna-sytuacja-polityczna-i-mozliwe-zamieszki-8453380.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/MSZ-odradza-podroze-do-Peru-Niestabilna-sytuacja-polityczna-i-mozliwe-zamieszki-8453380.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 13:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/24187db04f6c42-948-568-15-52-2985-1790.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ze względu na niestabilną sytuację polityczną i możliwe zamieszki, MSZ odradza podróże, które nie są konieczne, do Peru - poinformował w czwartek resort dyplomacji. MSZ zaleca m.in. unikanie demonstracji i monitorowanie komunikatów lokalnych władz.</p>

## Wyrzutnie Grad na terenie Zaporoskiej Elektrowni Atomowej. Co planuje Rosja?
 - [https://www.bankier.pl/wiadomosc/Wyrzutnie-Grad-na-terenie-Zaporoskiej-Elektrowni-Atomowej-Co-planuje-Rosja-8453361.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wyrzutnie-Grad-na-terenie-Zaporoskiej-Elektrowni-Atomowej-Co-planuje-Rosja-8453361.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 12:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/b/557ba5d6f6d278-948-568-0-35-1280-767.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosjanie przywieźli w środę na teren okupowanej Zaporoskiej Elektrowni Atomowej kilka wieloprowadnicowych wyrzutni rakietowych Grad, najpewniej przygotowują kolejną prowokację – poinformował operator ukraińskich siłowni jądrowych Enerhoatom.</p>

## USA wyślą do Estonii dodatkowe oddziały wojska
 - [https://www.bankier.pl/wiadomosc/USA-wysla-do-Estonii-dodatkowe-oddzialy-wojska-8453353.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-wysla-do-Estonii-dodatkowe-oddzialy-wojska-8453353.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 12:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/0/9be48754cd7f30-948-568-0-239-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stany Zjednoczone wyślą do Estonii dodatkowe oddziały rotacyjne mające wzmocnić siły wysuniętej obrony NATO i bezpieczeństwo państw sojuszniczych - poinformowała w czwartek agencja BNS, powołując się na estońskie władze.</p>

## KGHM International z umową dot. projektu Kukamas w Kanadzie
 - [https://www.bankier.pl/wiadomosc/KGHM-International-ma-umowe-JV-z-Azimut-Exploration-dot-projektu-Kukamas-8453344.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KGHM-International-ma-umowe-JV-z-Azimut-Exploration-dot-projektu-Kukamas-8453344.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 12:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/8/7f32572893db85-948-569-13-39-1721-1033.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />KGHM International zawarł z Azimut Exploration umowę opcji joint venture dotyczącą obszaru miedziowo-złotego Kukamas w regionie Eeyou Istchee James Bay w kanadyjskiej prowincji Quebec - poinformował Azimut w komunikacie prasowym. KGHM może potecjalnie nabyć początkowo 50 proc. udziałów.</p>

## "New York Times" strajkuje. "Niesprawiedliwe" warunki zatrudnienia
 - [https://www.bankier.pl/wiadomosc/New-York-Times-strajkuje-Niesprawiedliwe-warunki-zatrudnienia-8453336.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/New-York-Times-strajkuje-Niesprawiedliwe-warunki-zatrudnienia-8453336.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 12:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/2/55db848f2a6b64-948-568-0-398-3627-2176.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Setki dziennikarzy i innych pracowników amerykańskiego dziennika "New York Times" rozpoczęły w czwartek 24-godzinny strajk po nieudanych negocjacjach z wydawcą dotyczących "sprawiedliwych" warunków zatrudnienia.</p>

## Rosyjski szpieg w komisji Macierewicza. "Likwidacja WSI była sztandarowym projektem PiS"
 - [https://www.bankier.pl/wiadomosc/Rosyjski-szpieg-w-komisji-Macierewicza-Likwidacja-WSI-byla-sztandarowym-projektem-PiS-8453306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosyjski-szpieg-w-komisji-Macierewicza-Likwidacja-WSI-byla-sztandarowym-projektem-PiS-8453306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 11:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/d496c86364fdc0-948-568-16-225-3204-1922.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Informacja o tym, że w komisji likwidacyjnej WSI zasiadała osoba podejrzana obecnie o szpiegostwo na rzecz Rosji, jest druzgocząca z punktu widzenia polskiego bezpieczeństwa. To wymaga wyjaśnienia, potrzebne jest zwołanie specjalnego posiedzenia sejmowej komisji ds. służb specjalnych - uważają posłowie KO.</p>

## Strategia PKO BP na lata 2023-25. Wypłaty dywidendy czy przejęcia - w kraju i poza
 - [https://www.bankier.pl/wiadomosc/PKO-BP-w-strategii-zaklada-zdolnosc-do-wyplaty-dywidendy-skupu-akcji-8453302.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKO-BP-w-strategii-zaklada-zdolnosc-do-wyplaty-dywidendy-skupu-akcji-8453302.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 11:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/50ea7e1f7bf709-948-568-12-151-2410-1446.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PKO BP w strategii zakłada zdolność do wypłaty dywidendy/skupu akcji - podał bank w komunikacie dotyczącym strategii na lata 2023-25.</p>

## ING Bank Śląski zawiesza oferowanie hipotek ze zmiennym oprocentowaniem
 - [https://www.bankier.pl/wiadomosc/ING-Bank-Slaski-zawiesza-oferowanie-hipotek-ze-zmiennym-oprocentowaniem-8453288.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ING-Bank-Slaski-zawiesza-oferowanie-hipotek-ze-zmiennym-oprocentowaniem-8453288.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 11:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/5/c1715983ffbabb-851-510-527-174-851-510.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />ING Bank Śląski zawiesza sprzedaż kredytów hipotecznych ze zmiennym oprocentowaniem do połowy przyszłego roku, kiedy planuje wprowadzić oprocentowanie zmienne oparte o indeks WIRON. W tym czasie bank będzie oferował kredyty hipoteczne tylko z oprocentowaniem okresowo stałym - poinformował bank w komunikacie.</p>

## Protesty w Mongolii trwają. Chodzi o wielomiliardową kradzież węgla
 - [https://www.bankier.pl/wiadomosc/Protesty-w-Mongolii-trwaja-Chodzi-o-wielomiliardowa-kradziez-wegla-8453283.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Protesty-w-Mongolii-trwaja-Chodzi-o-wielomiliardowa-kradziez-wegla-8453283.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 11:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/8/ba123c249c1aa8-948-568-0-30-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W stolicy Mongolii Ułan Bator nie ustają rozpoczęte w niedzielę protesty w związku z kradzieżą węgla na ogromną skalę, której dopuścić się mieli rządzący. Aresztowano byłego szefa państwowej firmy zajmującej się wydobyciem i eksportem węgla, a śledztwem objętych jest 15 innych urzędników - poinformowała w czwartek Nowaja Gazieta.Jewropa.</p>

## Szczepienia przeciw COVID-19 dzieci od sześciu miesięcy do czterech lat. Jest data
 - [https://www.bankier.pl/wiadomosc/Szczepienia-przeciw-COVID-19-dzieci-od-szesciu-miesiecy-do-czterech-lat-Jest-data-8453282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szczepienia-przeciw-COVID-19-dzieci-od-szesciu-miesiecy-do-czterech-lat-Jest-data-8453282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 11:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/f/1efd1716a75a0a-945-560-0-21-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 12 grudnia można zarejestrować na szczepienie 
przeciw COVID-19 dzieci od 6 miesięcy do 4 lat – powiedział w czwartek 
minister zdrowia Adam Niedzielski. Dodał, że rejestrować dzieci na 
szczepienie można poprzez Moje IKP, infolinię lub bezpośrednio w punkcie
 szczepień.</p>

## Polacy tłumnie ubezpieczali "życie". Ale najwięcej wypłat przez wypadki
 - [https://www.bankier.pl/wiadomosc/Polacy-tlumnie-ubezpieczali-zycie-Ale-najwiecej-wyplat-przez-wypadki-8453274.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-tlumnie-ubezpieczali-zycie-Ale-najwiecej-wyplat-przez-wypadki-8453274.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 11:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/bccc6f2f2424ef-945-598-0-0-2328-1476.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ciągu trzech kwartałów 2022 r. ubezpieczyciele wypłacili 33,6 mld zł odszkodowań i świadczeń - podała w czwartek Polska Izba Ubezpieczeń. Jest to 11 proc. więcej  niż rok wcześniej.</p>

## Aktywiści klimatyczni w Niemczech nie odpuszczają. Wtargnęli na lotniska w Monachium i Berlinie
 - [https://www.bankier.pl/wiadomosc/Aktywisci-klimatyczni-w-Niemczech-nie-odpuszczaja-Wtargneli-na-lotniska-w-Monachium-i-Berlinie-8453258.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Aktywisci-klimatyczni-w-Niemczech-nie-odpuszczaja-Wtargneli-na-lotniska-w-Monachium-i-Berlinie-8453258.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 10:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/35cf79d527f79c-948-568-0-150-3990-2393.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Niemczech w czwartek doszło do kolejnych akcji aktywistów klimatycznych z grupy "Ostatnie pokolenie" na lotniskach w Monachium i Berlinie - pisze w czwartek portal dziennika "Bild". W Monachium aktywiści przykleili się do pasa startowego, z którego zostali później usunięci.</p>

## Zmiany dla emerytów i rencistów. Cyfryzacja wchodzi w świat seniorów
 - [https://www.bankier.pl/wiadomosc/Zmiany-dla-emerytow-i-rencistow-Legitymacja-seniora-wchodzi-w-cyfrowy-wymiar-8453204.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zmiany-dla-emerytow-i-rencistow-Legitymacja-seniora-wchodzi-w-cyfrowy-wymiar-8453204.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 10:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/0/8802e02103afd4-948-568-0-162-2507-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Legitymacja emeryta lub rencisty będzie dostępna w wersji cyfrowej. Od stycznia 2023 r. w aplikacji mObywatel dostępna będzie elektroniczna wersja papierowego dokumentu. Na jej podstawie seniorzy będą mogli korzystać ze wszystkich przysługujących im zniżek i ulg.</p>

## Zatruł się pestycydami. Firma Bayer ma wypłacić odszkodowanie francuskiemu rolnikowi
 - [https://www.bankier.pl/wiadomosc/Zatrul-sie-pestycydami-Firma-Bayer-ma-wyplacic-odszkodowanie-francuskiemu-rolnikowi-8453229.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zatrul-sie-pestycydami-Firma-Bayer-ma-wyplacic-odszkodowanie-francuskiemu-rolnikowi-8453229.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 10:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/4/819a9744c48f26-945-560-0-0-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd w Lyonie nakazał niemieckiej firmie Bayer wypłacić francuskiemu rolnikowi Paulowi Francois odszkodowanie w wysokości 11 135 euro za zatrucie pestycydami  – poinformował w czwartek dziennik „Le Monde”. Francois domagał się odszkodowania w wysokości 1 mln euro.</p>

## GDDKiA rozwiązała umowy o wartości ponad 1,4 mld na budowę ponad 50 km dróg
 - [https://www.bankier.pl/wiadomosc/GDDKiA-rozwiazala-umowy-o-wartosci-ponad-1-4-mld-na-budowe-ponad-50-km-drog-8453217.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/GDDKiA-rozwiazala-umowy-o-wartosci-ponad-1-4-mld-na-budowe-ponad-50-km-drog-8453217.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 09:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/597763192ad79e-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />GDDKiA w Białymstoku w związku z prawomocnym wyrokiem NSA rozwiązała z firmami trzy umowy o łącznej wartości ponad 1,4 mld zł na budowę łącznie ponad 37 km drogi ekspresowej S19 i 13,5 km drogi krajowej nr 65 - tzw. przyszłej południowej obwodnicy Białegostoku.</p>

## Biedronka testuje usługę cashbacku. Gotówkę wypłacimy w tych sklepach
 - [https://www.bankier.pl/wiadomosc/Biedronka-testuje-usluge-cashbacku-Gotowke-wyplacimy-w-tych-sklepach-8453142.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Biedronka-testuje-usluge-cashbacku-Gotowke-wyplacimy-w-tych-sklepach-8453142.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/a/27635ec9b99f83-948-568-75-224-2400-1439.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W wybranych sklepach sieci Biedronka trwa pilotaż 
programu "Płać kartą i wypłacaj", w ramach którego klienci mogą pobrać 
gotówkę przy okazji robienia zakupów. Z usługi cashbacku, przynajmniej 
na razie, mogą się cieszyć jedynie posiadacze kart płatniczych Mastercard.


</p>

## Złoty czeka na prezesa Glapińskiego. Kurs euro poniżej 4,70 zł
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-ponizej-4-70-zl-8453202.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-ponizej-4-70-zl-8453202.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/0/cbb6d5d6f24e21-948-568-0-195-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Gwoździem czwartkowego programu na polskim rynku walutowym
jest wystąpienie prezesa NBP Adama Glapińskiego. W oczekiwaniu na to wydarzenie
kurs euro ustatkował się poniżej 4,70 zł.</p>

## Netflix rozpycha się na polskim rynku streamingu i detronizuje konkurencję
 - [https://www.bankier.pl/wiadomosc/Netflix-rozpycha-sie-na-polskim-rynku-streamingu-i-detronizuje-konkurencje-8453174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Netflix-rozpycha-sie-na-polskim-rynku-streamingu-i-detronizuje-konkurencje-8453174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 09:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/a29768040e0af9-948-568-0-91-2296-1377.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Netflix zbliża się do przejęcia połowy rynku streamingu w Polsce. W listopadzie platforma zgromadziła ponad 13 mln użytkowników. Blisko trzykrotnie więcej niż drugi co do wielkości serwis, pod względem liczby subskrybentów, czyli HBO GO – podaje Gemius/PBI.</p>

## Kolejny pakiet sankcji UE wobec Rosji na horyzoncie
 - [https://www.bankier.pl/wiadomosc/Kolejny-pakiet-sankcji-UE-wobec-Rosji-na-horyzoncie-8453184.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kolejny-pakiet-sankcji-UE-wobec-Rosji-na-horyzoncie-8453184.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 09:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/c8fb35a9110372-948-568-0-192-4045-2426.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spodziewamy się przyjęcia kolejnego pakietu 
sankcji Unii Europejskiej wobec Rosji w piątek - powiedział 
dziennikarzom w Brukseli Stały Przedstawiciel Polski przy UE Andrzej 
Sadoś.</p>

## Węgry inflacyjnym liderem Europy. Niespotykany nigdzie indziej w Europie wzrost cen żywności
 - [https://www.bankier.pl/wiadomosc/Inflacja-na-Wegrzech-listopad-2022-8453158.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-na-Wegrzech-listopad-2022-8453158.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/0/c44d69481e0de0-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inflacja CPI na Węgrzech grubo przekroczyła 20% i po grudniu
najprawdopodobniej osiągnie najwyższy poziom w Europie.</p>

## Spółki z GPW pod lupą analityka technicznego. CD Projekt, Orlen, KGHM...
 - [https://www.bankier.pl/wiadomosc/Analiza-techniczna-spolek-z-GPW-CD-Projekt-Orlen-KGHM-8453143.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Analiza-techniczna-spolek-z-GPW-CD-Projekt-Orlen-KGHM-8453143.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 08:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/f455172657abc7-948-568-7-67-1037-622.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zapraszamy do wzięcia udziału w webinarze poświęconym
 analizie technicznej indeksów i spółek z GPW. Webinar prowadzi prof. Krzysztof Borowski, znany i ceniony 
analityk, wykładowca SGH. Ekspert analizuje wykresy ciekawych jego 
zdaniem spółek oraz tych, zaproponowanych przez uczestników spotkania. </p>

## Podwyżka, obniżka stóp procentowych... Co zrobi RPP? Ekonomiści komentują
 - [https://www.bankier.pl/wiadomosc/Podwyzka-obnizka-stop-procentowych-Co-zrobi-RPP-Ekonomisci-komentuja-8453177.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podwyzka-obnizka-stop-procentowych-Co-zrobi-RPP-Ekonomisci-komentuja-8453177.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 08:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/78d6d30ae9bd0b-948-568-0-115-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada Polityki Pieniężnej prawdopodobnie zakończyła cykl podwyżek stóp procentowych, ale nie można wykluczyć, że sytuacja makroekonomiczna wymusi w przyszłym roku dalsze zacieśnienie polityki pieniężnej - oceniają ekonomiści w komentarzach do środowego posiedzenia RPP. Niektórzy eksperci sądzą jednak, że kolejnym krokiem RPP w II poł. 2023 r. będą obniżki stóp.</p>

## Gaz ziemny mocno drożeje
 - [https://www.bankier.pl/wiadomosc/Gaz-ziemny-mocno-drozeje-8453169.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gaz-ziemny-mocno-drozeje-8453169.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 08:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/9ff1d75abe4d22-948-568-0-303-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W czwartek po godz. 9 rano gaz ziemny w holenderskim hubie TTF w kontraktach styczniowych drożeje o 4,56 proc., do 156,05 euro za MWh. Rosną też notowania gazu ziemnego z dostawą w lutym 2023 r. - o 4,15 proc., do 156,26 euro za MWh.</p>

## Celowo powodował kolizje drogowe i wyłudzał odszkodowania; odpowie za to przed sądem
 - [https://www.bankier.pl/wiadomosc/Celowo-powodowal-kolizje-drogowe-i-wyludzal-odszkodowania-odpowie-za-to-przed-sadem-8453167.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Celowo-powodowal-kolizje-drogowe-i-wyludzal-odszkodowania-odpowie-za-to-przed-sadem-8453167.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 08:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/1ad788526f0d4b-945-567-0-103-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Policjanci z komendy wojewódzkiej w Katowicach zatrzymali 40-latka z Bytomia, który przez kilka lat celowo powodował kolizje drogowe, żeby wyłudzać odszkodowania z firm ubezpieczeniowych. W sumie uczestniczył w kilkunastu takich zdarzeniach, wyłudzając 140 tys. zł.</p>

## Ceny ropy mocno rosną. Inwestorzy analizują ryzyko wystąpienia recesji w gospodarce USA
 - [https://www.bankier.pl/wiadomosc/Ceny-ropy-mocno-rosna-Inwestorzy-analizuja-ryzyko-wystapienia-recesji-w-gospodarce-USA-8453151.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-ropy-mocno-rosna-Inwestorzy-analizuja-ryzyko-wystapienia-recesji-w-gospodarce-USA-8453151.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 07:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/d/d92cab444f34a4-948-568-0-112-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku mocno rosną w czwartek. Inwestorzy analizują wpływ działań chińskich władz mających na celu dalsze łagodzenie ograniczeń covidowych i ryzyko wystąpienia recesji w gospodarce USA - informują maklerzy.</p>

## Zełenski najbardziej wpływowym politykiem Europy w dorocznym rankingu Politico
 - [https://www.bankier.pl/wiadomosc/Zelenski-najbardziej-wplywowym-politykiem-Europy-w-dorocznym-rankingu-Politico-8453148.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zelenski-najbardziej-wplywowym-politykiem-Europy-w-dorocznym-rankingu-Politico-8453148.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 07:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/b/0dd0fb47cc01c9-948-568-0-53-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Ukrainy Wołodymy Zełenski został najbardziej wpływowym politykiem Europy w rankingu sporządzonym przez portal Politico. Uhonorowano go za zmianę wizerunku Ukrainy na arenie międzynarodowej w kontekście rosyjskiej inwazji na kraj, któremu przewodzi. W zestawieniu ujęto też 27 innych polityków, przedstawionych w trzech kategoriach.</p>

## Sprzedajesz na OLX albo Vinted? Możesz stracić pieniądze - mBank ostrzega
 - [https://www.bankier.pl/wiadomosc/Oszustwo-na-OLX-wraca-mBank-ostrzega-8453131.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oszustwo-na-OLX-wraca-mBank-ostrzega-8453131.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 07:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/c857109758c74e-948-568-0-88-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Oszustwo na OLX wraca jak bumerang. Przestępcy podszywają się pod kupującego i proponują transakcje poza serwisem internetowym. Oszuści wyłudzają dane do karty debetowej lub konta internetowego za pomocą fałszywej strony podszywającej się pod bank. Oszustwo wymierzone jest w osoby sprzedające produkty na portalach aukcyjnych tj. jak OLX czy Vinted.</p>

## Resort finansów ma pomysł na reformę lokalnych budżetów. Będą zmiany ws. podatków
 - [https://www.bankier.pl/wiadomosc/Resortu-finansow-ma-pomysl-na-reforme-lokalnych-budzetow-Beda-zmiany-ws-podatkow-8453091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Resortu-finansow-ma-pomysl-na-reforme-lokalnych-budzetow-Beda-zmiany-ws-podatkow-8453091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 05:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/5eda61f2a97405-933-560-27-0-933-560.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Różne udziały w PIT i CIT dla różnych samorządów, dobrowolne odpisy podatników PIT na rzecz gmin, ograniczenie wpłat janosikowego – to, jak informuje w czwartek "Dziennik Gazeta Prawna", pomysły resortu finansów na reformę lokalnych budżetów.</p>

## Koniec z pożyczkami na skardzione dane? Będzie można zastrzec PESEL
 - [https://www.bankier.pl/wiadomosc/Koniec-z-pozyczkami-na-skardzione-dane-Bedzie-mozna-zastrzec-PESEL-8453090.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-z-pozyczkami-na-skardzione-dane-Bedzie-mozna-zastrzec-PESEL-8453090.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 05:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/7/9406e1ca5891a9-945-567-0-70-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd utworzy specjalny rejestr, w którym po wycieku lub kradzieży danych będzie można zastrzec swój numer PESEL. Po takim zastrzeżeniu nikt już nie weźmie na niego kredytu czy pożyczki - informuje w czwartek "Dziennik Gazeta Prawna".</p>

## Wróci 23-proc. VAT na gaz? Rząd tłumaczy się stanowiskiem KE, ta jednak zaprzecza
 - [https://www.bankier.pl/wiadomosc/Wroci-23-proc-VAT-na-gaz-Rzad-tlumaczy-sie-stanowiskiem-KE-ta-jednak-zaprzecza-8453087.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wroci-23-proc-VAT-na-gaz-Rzad-tlumaczy-sie-stanowiskiem-KE-ta-jednak-zaprzecza-8453087.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 05:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/a/6f68d8ec99d813-948-568-26-8-1746-1047.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od stycznia prawdopodobnie do 23 proc. wzrośnie VAT na gaz. Rząd tłumaczy to stanowiskiem Komisji Europejskiej. Ta zaprzecza, że domaga się tak wysokiej stawki - informuje w czwartek "Rzeczpospolita".</p>

## Strajk pracowników "New York Timesa". Brak porozumienia ws. podwyżek uwzględniających inflację
 - [https://www.bankier.pl/wiadomosc/Strajk-pracownikow-New-York-Timesa-Brak-porozumienia-ws-podwyzek-uwzgledniajacych-inflacje-8453071.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Strajk-pracownikow-New-York-Timesa-Brak-porozumienia-ws-podwyzek-uwzgledniajacych-inflacje-8453071.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 05:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/7/d39b83db797734-945-560-0-19-3896-2337.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 1100 członków związku zawodowego w „New York Timesie” przerwie w czwartek na jeden dzień pracę po nieudanych negocjacjach z wydawcą w sprawie "kompletnego i sprawiedliwego kontraktu". Jest to pierwszy tego rodzaju protest od końca 1970 roku.</p>

## Szef PFR o podwyżkach stóp proc., szczycie inflacji i realizacji KPO
 - [https://www.bankier.pl/wiadomosc/Szef-PFR-o-podwyzkach-stop-proc-szczycie-inflacji-i-realizacji-KPO-8453064.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szef-PFR-o-podwyzkach-stop-proc-szczycie-inflacji-i-realizacji-KPO-8453064.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/9892333dc9b372-948-568-0-31-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W grudniu popłyną pierwsze 2-3 mld zł z PFR na realizację inwestycji z Krajowego Planu Odbudowy - powiedział PAP prezes Polskiego Funduszu Rozwoju Paweł Borys. W jego ocenie inflacja pod koniec przyszłego roku mocno spadnie do poniżej 10 proc., a w perspektywie 2024 roku może wynieść poniżej 5 proc.</p>

## Najtańsze konta osobiste. Nieoczekiwana zmiana na podium
 - [https://www.bankier.pl/wiadomosc/Ranking-kont-osobistych-grudzien-2022-najtansze-konta-bankowe-ROR-8452644.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-kont-osobistych-grudzien-2022-najtansze-konta-bankowe-ROR-8452644.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/5/13ad3608af7d61-948-568-0-0-3607-2164.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po prostu najtańsze konto na rynku – z takiego założenia wyszliśmy przygotowując grudniowy ranking ROR-ów. Nieoczekiwanie na podium wskoczył nowy gracz, który rachunki oferuje raptem od kilku miesięcy. Bezwarunkowo bezpłatne konta i karty oferują dziś trzy banki. W pozostałych można uniknąć opłat, ale trzeba spełnić dodatkowe wymagania.</p>

## Więcej bankructw konsumentów, ale rekordu w tym roku nie będzie
 - [https://www.bankier.pl/wiadomosc/Wiecej-bankructw-konsumentow-ale-rekordu-w-tym-roku-nie-bedzie-8452891.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiecej-bankructw-konsumentow-ale-rekordu-w-tym-roku-nie-bedzie-8452891.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/5/649d439187439b-948-568-0-60-4000-2400.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Listopad był trzecim miesiącem z rzędu, w którym liczba
upadłości konsumenckich przekraczała 1,5 tys. Oznacza to powrót do okolic
miesięcznej średniej obserwowanej przed rokiem. Po raz pierwszy w historii tej instytucji
w Polsce w 2022 r. odnotujemy zapewne spadek liczby bankructw w porównaniu z
poprzednim rokiem.  </p>

## Ukraina w sądzie odzyskała skradzione przez Rosję aktywa na Krymie. Prawie 1,5 mld dol.
 - [https://www.bankier.pl/wiadomosc/Ukraina-w-sadzie-odzyskala-skradzione-przez-Rosje-aktywa-na-Krymie-Prawie-1-5-mld-dol-8453050.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraina-w-sadzie-odzyskala-skradzione-przez-Rosje-aktywa-na-Krymie-Prawie-1-5-mld-dol-8453050.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-12-08 00:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/1/3c9fb68460abb1-945-567-0-324-4285-2571.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd Najwyższy Francji podtrzymał decyzję o odzyskaniu prawie 1,5 mld USD od państwa agresora na rzecz Oszczadbanku. To pierwsze od sześciu lat zwycięstwo w sądzie w sprawie ukraińskich aktywów skradzionych przez Rosję na Krymie, poinformował w środę w wypowiedzi video prezydent Ukrainy.</p>


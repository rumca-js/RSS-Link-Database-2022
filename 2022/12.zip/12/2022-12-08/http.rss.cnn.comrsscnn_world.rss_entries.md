# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## FTC sues over Microsoft's $69 billion acquisition of Activision Blizzard
 - [https://www.cnn.com/2022/12/08/tech/ftc-microsoft-activision-blizzard-acquisition/index.html](https://www.cnn.com/2022/12/08/tech/ftc-microsoft-activision-blizzard-acquisition/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-12-08 23:18:26+00:00

The Federal Trade Commission on Thursday sued to block Microsoft's $69 billion acquisition of Activision Blizzard, challenging one of the largest tech acquisitions in history.

## Demand for Rent the Runway is up, but the company is still losing money
 - [https://www.cnn.com/2022/12/08/investing/rent-the-runway-earnings/index.html](https://www.cnn.com/2022/12/08/investing/rent-the-runway-earnings/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-12-08 18:02:32+00:00

A recession may be coming, but consumers still want to look fashionable. Subscription clothing service Rent the Runway reported a more than 30% increase in sales for the third quarter after the closing bell Wednesday.

## Why we think we're in a recession when the data says otherwise
 - [https://www.cnn.com/2022/12/08/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2022/12/08/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-12-08 12:52:53+00:00

It seems like you can't go anywhere these days without colliding headfirst into another ominous prediction of imminent recession. CEOs, portfolio managers, politicians, news pundits, second cousins and even Cardi B are sounding the alarm: Hear ye! Hear ye! Economic downturn awaits all who dare enter 2023!

## When China and Saudi Arabia meet, nothing matters more than oil
 - [https://www.cnn.com/2022/12/08/economy/china-xi-saudi-arabia-visit-oil-trade-intl-hnk/index.html](https://www.cnn.com/2022/12/08/economy/china-xi-saudi-arabia-visit-oil-trade-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-12-08 06:00:33+00:00

Chinese President Xi Jinping is visiting Saudi Arabia this week for the first time in nearly seven years, during which he is expected to sign billions of dollars of deals with the world's largest oil exporter and meet leaders from across the Middle East.


# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## 'More volatile and unstable world': How 2022 kept breaking new extreme weather records
 - [https://news.sky.com/story/how-2022-kept-breaking-new-extreme-weather-records-in-more-volatile-and-unstable-world-12764266](https://news.sky.com/story/how-2022-kept-breaking-new-extreme-weather-records-in-more-volatile-and-unstable-world-12764266)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-08 17:09:00+00:00

From summer heat across the whole of the northern hemisphere to a cruel drought inflicting mass hunger in east Africa, 2022 felt almost unrelenting in extreme weather.

## Ukraine War Diaries: Fighting the Smart war against Russia
 - [https://news.sky.com/story/ukraine-war-diaries-fighting-the-smart-war-against-russia-12764236](https://news.sky.com/story/ukraine-war-diaries-fighting-the-smart-war-against-russia-12764236)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2022-12-08 16:42:00+00:00

At first, Ukrainians used their smartphones to warn others of air raid alerts.


## With Walker's loss, Republicans no longer need to fear Trump
 - [https://www.nbcnews.com/think/opinion/georgia-runoff-loss-herschel-walker-shows-trump-nothing-eyeroll-rcna60753](https://www.nbcnews.com/think/opinion/georgia-runoff-loss-herschel-walker-shows-trump-nothing-eyeroll-rcna60753)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/news
 - date published: 2022-12-08 17:58:22+00:00

Georgia runoff for Senate loss by Herschel Walker lose and Trump constitution remarks show Republicans should give the former president an eyeroll.


# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## ReVanced DMCA Takedown on GitHub
 - [https://github.com/revanced/revanced-patches](https://github.com/revanced/revanced-patches)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 23:56:13+00:00

<p>Article URL: <a href="https://github.com/revanced/revanced-patches">https://github.com/revanced/revanced-patches</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33915554">https://news.ycombinator.com/item?id=33915554</a></p>
<p>Points: 32</p>
<p># Comments: 11</p>

## Does ChatGPT Exhibit Ideological Bias?
 - [https://hwfo.substack.com/p/the-woke-rails-of-chatgpt](https://hwfo.substack.com/p/the-woke-rails-of-chatgpt)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 22:19:00+00:00

<p>Article URL: <a href="https://hwfo.substack.com/p/the-woke-rails-of-chatgpt">https://hwfo.substack.com/p/the-woke-rails-of-chatgpt</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33914515">https://news.ycombinator.com/item?id=33914515</a></p>
<p>Points: 14</p>
<p># Comments: 9</p>

## Why I'm Less Than Infinitely Hostile to Cryptocurrency
 - [https://astralcodexten.substack.com/p/why-im-less-than-infinitely-hostile](https://astralcodexten.substack.com/p/why-im-less-than-infinitely-hostile)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 22:15:54+00:00

<p>Article URL: <a href="https://astralcodexten.substack.com/p/why-im-less-than-infinitely-hostile">https://astralcodexten.substack.com/p/why-im-less-than-infinitely-hostile</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33914469">https://news.ycombinator.com/item?id=33914469</a></p>
<p>Points: 25</p>
<p># Comments: 5</p>

## Every modeler is supposed to be a great Python programmer
 - [https://statmodeling.stat.columbia.edu/2022/12/08/the-cleantech-job-market-every-modeler-is-supposed-to-be-a-great-python-programmer/](https://statmodeling.stat.columbia.edu/2022/12/08/the-cleantech-job-market-every-modeler-is-supposed-to-be-a-great-python-programmer/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 22:13:13+00:00

<p>Article URL: <a href="https://statmodeling.stat.columbia.edu/2022/12/08/the-cleantech-job-market-every-modeler-is-supposed-to-be-a-great-python-programmer/">https://statmodeling.stat.columbia.edu/2022/12/08/the-cleantech-job-market-every-modeler-is-supposed-to-be-a-great-python-programmer/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33914426">https://news.ycombinator.com/item?id=33914426</a></p>
<p>Points: 7</p>
<p># Comments: 5</p>

## Taking a Walk Across the Internet
 - [https://www.moma.org/magazine/articles/677](https://www.moma.org/magazine/articles/677)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 22:04:52+00:00

<p>Article URL: <a href="https://www.moma.org/magazine/articles/677">https://www.moma.org/magazine/articles/677</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33914303">https://news.ycombinator.com/item?id=33914303</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## AlphaCode Attention Visualization
 - [https://alphacode.deepmind.com/](https://alphacode.deepmind.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 21:54:26+00:00

<p>Article URL: <a href="https://alphacode.deepmind.com/">https://alphacode.deepmind.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33914122">https://news.ycombinator.com/item?id=33914122</a></p>
<p>Points: 37</p>
<p># Comments: 9</p>

## Asbestos Cigarette Filters
 - [https://www.asbestos.com/products/cigarette-filters/](https://www.asbestos.com/products/cigarette-filters/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 21:47:29+00:00

<p>Article URL: <a href="https://www.asbestos.com/products/cigarette-filters/">https://www.asbestos.com/products/cigarette-filters/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33914015">https://news.ycombinator.com/item?id=33914015</a></p>
<p>Points: 30</p>
<p># Comments: 24</p>

## ChatGPT, Rot13, and Daniel Kahneman
 - [https://jameswillia.ms/posts/chatgpt-rot13.html](https://jameswillia.ms/posts/chatgpt-rot13.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 21:37:13+00:00

<p>Article URL: <a href="https://jameswillia.ms/posts/chatgpt-rot13.html">https://jameswillia.ms/posts/chatgpt-rot13.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33913845">https://news.ycombinator.com/item?id=33913845</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Generally Intelligent (YC S17) Is Hiring Senior Software Engineers
 - [https://news.ycombinator.com/item?id=33913332](https://news.ycombinator.com/item?id=33913332)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 21:00:11+00:00

<p>Generally Intelligent is an AI research company working directly on building human-level general machine intelligence that can learn naturally in the way humans do. Our mission is to understand the fundamentals of learning and build safe, humane machine intelligence. Here are our open roles:<p>Machine Learning Engineer (Remote, Contract or Full-time): <a href="https://jobs.lever.co/generallyintelligent/9411e2ec-502a-403f-a39a-0d44c676b6af?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/9411e2ec-502a-403...</a><p>Research Scientist (SF, Full-time): <a href="https://jobs.lever.co/generallyintelligent/6c25a25c-35ec-4d7b-8d7e-40e9c4c85fba?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/6c25a25c-35ec-4d7...</a><p>Machine Learning Research Engineer (SF, Full-time): <a href="https://jobs.lever.co/generallyintelligent/c2f4a435-1eef-489a-9972-fba95e4a0296?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/c2f4a435-1eef-489...</a><p>Systems Engineer (Remote or SF, Full-time): <a href="https://jobs.lever.co/generallyintelligent/7afede07-8f22-4c49-b247-19e1a0ca6953?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/7afede07-8f22-4c4...</a><p>Simulation Engineer (Remote or SF, Full-time): <a href="https://jobs.lever.co/generallyintelligent/4658ffcb-f3ed-4906-8b0b-0f2517efd57e?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/4658ffcb-f3ed-490...</a><p>AI Policy & Safety Researcher (SF, Full-time):
<a href="https://jobs.lever.co/generallyintelligent/5b2741ab-7534-42c8-992e-487b35590adc?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/5b2741ab-7534-42c...</a><p>Engineering Manager (SF, Full-time):
<a href="https://jobs.lever.co/generallyintelligent/75fac008-22e5-49ab-9f4e-a4c459b52b41?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/75fac008-22e5-49a...</a><p>Independent Researcher (Remote):
<a href="https://jobs.lever.co/generallyintelligent/3d70d032-22a3-435a-8032-1551f17f650e?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/3d70d032-22a3-435...</a><p>Infrastructure Engineer (Remote or SF, Full-time):
<a href="https://jobs.lever.co/generallyintelligent/e66a55a3-a117-406c-9b07-8ba055047cea?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/e66a55a3-a117-406...</a><p>Open Source Tech Lead (SF, Full-time):
<a href="https://jobs.lever.co/generallyintelligent/9768bb0b-29c6-4188-a4b0-b741f4f92f75?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/9768bb0b-29c6-418...</a><p>Senior Software Engineer (Remote or SF, Full-time):
<a href="https://jobs.lever.co/generallyintelligent/38a93a78-fb8d-4614-bb12-b6277a7f874e?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/38a93a78-fb8d-461...</a><p>Theory Engineer:
<a href="https://jobs.lever.co/generallyintelligent/63499488-91b1-4154-956e-26551d7ac500?lever-origin=applied&amp;lever-source%5B%5D=Y%20Combinator" rel="nofollow">https://jobs.lever.co/generallyintelligent/63499488-91b1-415...</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33913332">https://news.ycombinator.com/item?id=33913332</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Discriminatory attitudes against the unvaccinated during a global pandemic
 - [https://www.nature.com/articles/s41586-022-05607-y](https://www.nature.com/articles/s41586-022-05607-y)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 20:56:00+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s41586-022-05607-y">https://www.nature.com/articles/s41586-022-05607-y</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33913275">https://news.ycombinator.com/item?id=33913275</a></p>
<p>Points: 41</p>
<p># Comments: 36</p>

## Goodbye to the C++ Implementation of Zig
 - [https://ziglang.org/news/goodbye-cpp/](https://ziglang.org/news/goodbye-cpp/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 20:53:12+00:00

<p>Article URL: <a href="https://ziglang.org/news/goodbye-cpp/">https://ziglang.org/news/goodbye-cpp/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33913231">https://news.ycombinator.com/item?id=33913231</a></p>
<p>Points: 146</p>
<p># Comments: 70</p>

## Weighted blanket raises pre-sleep salivary melatonin concentrations in adults
 - [https://onlinelibrary.wiley.com/doi/10.1111/jsr.13743](https://onlinelibrary.wiley.com/doi/10.1111/jsr.13743)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 20:52:41+00:00

<p>Article URL: <a href="https://onlinelibrary.wiley.com/doi/10.1111/jsr.13743">https://onlinelibrary.wiley.com/doi/10.1111/jsr.13743</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33913223">https://news.ycombinator.com/item?id=33913223</a></p>
<p>Points: 22</p>
<p># Comments: 7</p>

## The Child Is the Teacher: A Life of Maria Montessori
 - [https://www.lrb.co.uk/the-paper/v44/n24/bee-wilson/like-a-bar-of-soap](https://www.lrb.co.uk/the-paper/v44/n24/bee-wilson/like-a-bar-of-soap)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 20:51:49+00:00

<p>Article URL: <a href="https://www.lrb.co.uk/the-paper/v44/n24/bee-wilson/like-a-bar-of-soap">https://www.lrb.co.uk/the-paper/v44/n24/bee-wilson/like-a-bar-of-soap</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33913201">https://news.ycombinator.com/item?id=33913201</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Bumblebee: GPT2, Stable Diffusion, and More in Elixir
 - [https://news.livebook.dev/announcing-bumblebee-gpt2-stable-diffusion-and-more-in-elixir-3Op73O](https://news.livebook.dev/announcing-bumblebee-gpt2-stable-diffusion-and-more-in-elixir-3Op73O)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 20:49:01+00:00

<p>Article URL: <a href="https://news.livebook.dev/announcing-bumblebee-gpt2-stable-diffusion-and-more-in-elixir-3Op73O">https://news.livebook.dev/announcing-bumblebee-gpt2-stable-diffusion-and-more-in-elixir-3Op73O</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33913161">https://news.ycombinator.com/item?id=33913161</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## The Deep Weirdness of Beavers
 - [https://lithub.com/part-bear-part-bird-part-monkey-part-lizard-on-the-deep-weirdness-of-beavers/](https://lithub.com/part-bear-part-bird-part-monkey-part-lizard-on-the-deep-weirdness-of-beavers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 20:45:30+00:00

<p>Article URL: <a href="https://lithub.com/part-bear-part-bird-part-monkey-part-lizard-on-the-deep-weirdness-of-beavers/">https://lithub.com/part-bear-part-bird-part-monkey-part-lizard-on-the-deep-weirdness-of-beavers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33913113">https://news.ycombinator.com/item?id=33913113</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## BlackRock 2023 Outlook [pdf]
 - [https://www.blackrock.com/corporate](https://www.blackrock.com/corporate)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 20:42:22+00:00

<p>Article URL: <a href="https://www.blackrock.com/corporate">https://www.blackrock.com/corporate</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33913071">https://news.ycombinator.com/item?id=33913071</a></p>
<p>Points: 28</p>
<p># Comments: 13</p>

## How PostScript kickstarted desktop publishing
 - [https://spectrum.ieee.org/adobe-postscript-code](https://spectrum.ieee.org/adobe-postscript-code)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 20:21:05+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/adobe-postscript-code">https://spectrum.ieee.org/adobe-postscript-code</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33912786">https://news.ycombinator.com/item?id=33912786</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Adventures in Teletext Recovery
 - [https://www.andrewnile.co.uk/blog/adventures-in-teletext-recovery/](https://www.andrewnile.co.uk/blog/adventures-in-teletext-recovery/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 20:04:54+00:00

<p>Article URL: <a href="https://www.andrewnile.co.uk/blog/adventures-in-teletext-recovery/">https://www.andrewnile.co.uk/blog/adventures-in-teletext-recovery/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33912563">https://news.ycombinator.com/item?id=33912563</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## Finding the B-21's hanger location from the stars in its press image
 - [https://twitter.com/johnmcelhone8/status/1600683623250030593](https://twitter.com/johnmcelhone8/status/1600683623250030593)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 19:53:46+00:00

<p>Article URL: <a href="https://twitter.com/johnmcelhone8/status/1600683623250030593">https://twitter.com/johnmcelhone8/status/1600683623250030593</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33912401">https://news.ycombinator.com/item?id=33912401</a></p>
<p>Points: 80</p>
<p># Comments: 30</p>

## FTC Seeks to Block Microsoft Corp.’S Acquisition of Activision Blizzard, Inc
 - [https://www.ftc.gov/news-events/news/press-releases/2022/12/ftc-seeks-block-microsoft-corps-acquisition-activision-blizzard-inc](https://www.ftc.gov/news-events/news/press-releases/2022/12/ftc-seeks-block-microsoft-corps-acquisition-activision-blizzard-inc)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 19:26:58+00:00

<p>Article URL: <a href="https://www.ftc.gov/news-events/news/press-releases/2022/12/ftc-seeks-block-microsoft-corps-acquisition-activision-blizzard-inc">https://www.ftc.gov/news-events/news/press-releases/2022/12/ftc-seeks-block-microsoft-corps-acquisition-activision-blizzard-inc</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33912060">https://news.ycombinator.com/item?id=33912060</a></p>
<p>Points: 95</p>
<p># Comments: 59</p>

## Systemd.timer, an Alternative to Cron
 - [https://andrewpillar.com/programming/2022/12/08/systemd-timer-an-alternative-to-cron/](https://andrewpillar.com/programming/2022/12/08/systemd-timer-an-alternative-to-cron/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 19:16:17+00:00

<p>Article URL: <a href="https://andrewpillar.com/programming/2022/12/08/systemd-timer-an-alternative-to-cron/">https://andrewpillar.com/programming/2022/12/08/systemd-timer-an-alternative-to-cron/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33911910">https://news.ycombinator.com/item?id=33911910</a></p>
<p>Points: 18</p>
<p># Comments: 12</p>

## German states and federal government agreed on nationwide 49€ ticket coming 2023
 - [https://newsrnd.com/news/2022-12-08-mpk-decides-on-germany-ticket--according-to-scholz--it-should-come-%22very-quickly%22-.H1-dBr31Oo.html](https://newsrnd.com/news/2022-12-08-mpk-decides-on-germany-ticket--according-to-scholz--it-should-come-%22very-quickly%22-.H1-dBr31Oo.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 19:15:55+00:00

<p>Article URL: <a href="https://newsrnd.com/news/2022-12-08-mpk-decides-on-germany-ticket--according-to-scholz--it-should-come-%22very-quickly%22-.H1-dBr31Oo.html">https://newsrnd.com/news/2022-12-08-mpk-decides-on-germany-ticket--according-to-scholz--it-should-come-%22very-quickly%22-.H1-dBr31Oo.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33911902">https://news.ycombinator.com/item?id=33911902</a></p>
<p>Points: 37</p>
<p># Comments: 15</p>

## Airtable, last valued at $11B for its no-code software, lays off over 250
 - [https://techcrunch.com/2022/12/08/airtable-layoffs/](https://techcrunch.com/2022/12/08/airtable-layoffs/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 19:12:58+00:00

<p>Article URL: <a href="https://techcrunch.com/2022/12/08/airtable-layoffs/">https://techcrunch.com/2022/12/08/airtable-layoffs/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33911873">https://news.ycombinator.com/item?id=33911873</a></p>
<p>Points: 27</p>
<p># Comments: 12</p>

## Hacking on a plane: Leaking data of millions and taking over any account
 - [https://rez0.blog/hacking/2022/12/02/hacking-on-a-plane.html](https://rez0.blog/hacking/2022/12/02/hacking-on-a-plane.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 19:01:31+00:00

<p>Article URL: <a href="https://rez0.blog/hacking/2022/12/02/hacking-on-a-plane.html">https://rez0.blog/hacking/2022/12/02/hacking-on-a-plane.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33911698">https://news.ycombinator.com/item?id=33911698</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Nearly six in 10 US young adults live within 10 miles of where they grew up
 - [https://www.census.gov/library/stories/2022/07/theres-no-place-like-home.html](https://www.census.gov/library/stories/2022/07/theres-no-place-like-home.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 19:01:23+00:00

<p>Article URL: <a href="https://www.census.gov/library/stories/2022/07/theres-no-place-like-home.html">https://www.census.gov/library/stories/2022/07/theres-no-place-like-home.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33911694">https://news.ycombinator.com/item?id=33911694</a></p>
<p>Points: 35</p>
<p># Comments: 24</p>

## Not a Monad Tutorial
 - [https://johnazariah.github.io/2022/12/06/this-is-not-a-monad-tutorial.html](https://johnazariah.github.io/2022/12/06/this-is-not-a-monad-tutorial.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 18:28:11+00:00

<p>Article URL: <a href="https://johnazariah.github.io/2022/12/06/this-is-not-a-monad-tutorial.html">https://johnazariah.github.io/2022/12/06/this-is-not-a-monad-tutorial.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33911278">https://news.ycombinator.com/item?id=33911278</a></p>
<p>Points: 7</p>
<p># Comments: 7</p>

## There aren't enough remote jobs to go around
 - [https://www.chartr.co/stories/2022-11-30-1-demand-and-supply-for-remote-jobs](https://www.chartr.co/stories/2022-11-30-1-demand-and-supply-for-remote-jobs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 18:17:17+00:00

<p>Article URL: <a href="https://www.chartr.co/stories/2022-11-30-1-demand-and-supply-for-remote-jobs">https://www.chartr.co/stories/2022-11-30-1-demand-and-supply-for-remote-jobs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33911140">https://news.ycombinator.com/item?id=33911140</a></p>
<p>Points: 10</p>
<p># Comments: 17</p>

## Show HN: Wasp – DSL/framework for building full-stack web apps – now in beta
 - [https://news.ycombinator.com/item?id=33910997](https://news.ycombinator.com/item?id=33910997)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 18:05:19+00:00

<p>Hey HN! Wasp (<a href="https://wasp-lang.dev/" rel="nofollow">https://wasp-lang.dev/</a>) is a simple config language (DSL) and framework for building full-stack web apps. You describe the high-level features you want (auth, CRUD, async jobs, …) using the Wasp DSL, and write the rest of your logic in React, Node.js, and Prisma. We’re focused on simplifying developer experience and ensuring best practices.<p>Why another full-stack framework? And why a config language/DSL? We were still experiencing a lot of boilerplate (repetitive tasks) using other frameworks—things like duplicating data models across database/server/client, implementing CRUD API, setting up auth, and choosing and stitching together all parts of the stack.<p>There are two main reasons for the DSL approach - 1) short-term: simpler and cleaner DX via a declarative language that helps avoid boilerplate, and 2) longer-tem: laying foundation for the stack & architecture independent system.<p>Since Wasp analyses the app’s requirements in compile time, it can decide how to generate the target code (React & Node.js currently). In the future it could support other stacks such as e.g. Vue/Svelte on the client and Python/Go on the server, even allowing for mixing’n’matching. The same goes for the architecture (dedicated server, serverless, …).<p>Our big vision for Wasp is to become a stable, stack-agnostic language for describing (web) app requirements (like SQL for databases or Terraform for infra) that interops with the existing stack. Wasp-lang stands for “Web Application SPecification language”.<p>Besides the DSL, another valid approach would be to offer an SDK in e.g. JS or Python to build Wasp AST (like Terraform and Pulumi now both offer). We see it as another “frontend” for constructing the AST and might also introduce it in the future.<p>Under the hood, everything is compiled to a client (React) and server (Node.js/Prisma) apps and we generate static files and a Docker image you can use for deploying to your platform of choice.<p>Wasp had an Alpha launch 1.5 years ago (<a href="https://news.ycombinator.com/item?id=26091956" rel="nofollow">https://news.ycombinator.com/item?id=26091956</a>). Now we are more stable and feature-full. We still expect things to change, so wouldn’t recommend using Wasp for heavy production or mission-critical systems just yet. But it has been used for hackathons, internal tools and even revenue-generating products (<a href="https://wasp-lang.dev/blog/2022/11/26/erlis-amicus-usecase" rel="nofollow">https://wasp-lang.dev/blog/2022/11/26/erlis-amicus-usecase</a>).<p>The current release is our biggest since we launched (<a href="https://wasp-lang.dev/blog/2022/11/29/wasp-beta" rel="nofollow">https://wasp-lang.dev/blog/2022/11/29/wasp-beta</a>). Besides general stability and DX improvements, it brings support for TypeScript (<a href="https://wasp-lang.dev/blog/2022/11/29/typescript-feature-announcement" rel="nofollow">https://wasp-lang.dev/blog/2022/11/29/typescript-feature-ann...</a>), Tailwind (<a href="https://wasp-lang.dev/blog/2022/11/16/tailwind-feature-announcement" rel="nofollow">https://wasp-lang.dev/blog/2022/11/16/tailwind-feature-annou...</a>), async jobs via pg-boss (<a href="https://wasp-lang.dev/blog/2022/06/15/jobs-feature-announcement" rel="nofollow">https://wasp-lang.dev/blog/2022/06/15/jobs-feature-announcem...</a>), full-stack authentication (now also with Google) (<a href="http://localhost:3000/blog/2022/11/15/auth-feature-announcement" rel="nofollow">http://localhost:3000/blog/2022/11/15/auth-feature-announcem...</a>), and by popular demand, Wasp LSP with VS Code integration (<a href="https://wasp-lang.dev/blog/2022/12/01/beta-ide-improvements" rel="nofollow">https://wasp-lang.dev/blog/2022/12/01/beta-ide-improvements</a>).<p>Our next focus will be on making Wasp even easier to use (examples, starter templates, UI helpers), and we’ll look into tighter weaving of data models with the rest of the stack and expanding the DSL with more functionalities.<p>We’re around to answer questions and look forward to hearing everything and anything you have to say!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33910997">https://news.ycombinator.com/item?id=33910997</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Telemetry is now optional in Warp (the Rust-based terminal)
 - [https://www.warp.dev/blog/telemetry-now-optional-in-warp](https://www.warp.dev/blog/telemetry-now-optional-in-warp)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 18:04:54+00:00

<p>Article URL: <a href="https://www.warp.dev/blog/telemetry-now-optional-in-warp">https://www.warp.dev/blog/telemetry-now-optional-in-warp</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33910992">https://news.ycombinator.com/item?id=33910992</a></p>
<p>Points: 28</p>
<p># Comments: 25</p>

## Recent Apple Updates Leading to WiFi Issues
 - [https://www.meter.com/mac-osx-awdl-psa](https://www.meter.com/mac-osx-awdl-psa)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 17:59:48+00:00

<p>Article URL: <a href="https://www.meter.com/mac-osx-awdl-psa">https://www.meter.com/mac-osx-awdl-psa</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33910929">https://news.ycombinator.com/item?id=33910929</a></p>
<p>Points: 46</p>
<p># Comments: 19</p>

## Association vigorous intermittent lifestyle physical activity with mortality
 - [https://www.nature.com/articles/s41591-022-02100-x](https://www.nature.com/articles/s41591-022-02100-x)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 17:57:58+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s41591-022-02100-x">https://www.nature.com/articles/s41591-022-02100-x</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33910912">https://news.ycombinator.com/item?id=33910912</a></p>
<p>Points: 24</p>
<p># Comments: 15</p>

## Show HN: Web search using a ChatGPT-like model that can cite its sources
 - [https://beta.sayhello.so/](https://beta.sayhello.so/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 17:53:53+00:00

<p>We’ve trained a generative AI model to browse the web and answer questions/retrieve code snippets directly. Unlike ChatGPT, it has access to primary sources and is able to cite them when you hover over an answer (click on the text to go to the source being cited). We also show regular Bing results side-by-side with our AI answer.<p>The model is an 11-billion parameter T5-derivative that has been fine-tuned on feedback given on hundreds of thousands of searches done (anonymously) on our platform. Giving the model web access lessens its burden to need to store a snapshot of human knowledge within its parameters. Rather, it knows how to piece together primary sources in a natural and informative way. Using our own model is also an order of magnitude cheaper than relying on GPT.<p>A drawback to aligning models to web results is that they are less inclined to generate complete solutions/answers to questions where good primary sources don’t exist. Answers generated without underlying citable sources can be more creative but are prone to errors. In the future, we will show both types of answers.<p>Examples:<p><a href="https://beta.sayhello.so/search?q=set+cookie+in+fastapi" rel="nofollow">https://beta.sayhello.so/search?q=set+cookie+in+fastapi</a><p><a href="https://beta.sayhello.so/search?q=What+did+Paul+Graham+learn+from+users" rel="nofollow">https://beta.sayhello.so/search?q=What+did+Paul+Graham+learn...</a><p><a href="https://beta.sayhello.so/search?q=How+to+get+command+line+parameters+in+Rust" rel="nofollow">https://beta.sayhello.so/search?q=How+to+get+command+line+pa...</a><p><a href="https://beta.sayhello.so/search?q=why+did+Elon+Musk+buy+twitter" rel="nofollow">https://beta.sayhello.so/search?q=why+did+Elon+Musk+buy+twit...</a><p>Would love to hear your thoughts.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33910863">https://news.ycombinator.com/item?id=33910863</a></p>
<p>Points: 54</p>
<p># Comments: 35</p>

## Xiaomi’s Humanoid Drummer Beats Expectations
 - [https://spectrum.ieee.org/xiaomi-robot-drummer](https://spectrum.ieee.org/xiaomi-robot-drummer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 17:40:21+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/xiaomi-robot-drummer">https://spectrum.ieee.org/xiaomi-robot-drummer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33910711">https://news.ycombinator.com/item?id=33910711</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## Google Zanzibar Through Our Eyes
 - [https://authzed.com/blog/annotated-zanzibar-launch/](https://authzed.com/blog/annotated-zanzibar-launch/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 17:37:49+00:00

<p>Article URL: <a href="https://authzed.com/blog/annotated-zanzibar-launch/">https://authzed.com/blog/annotated-zanzibar-launch/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33910685">https://news.ycombinator.com/item?id=33910685</a></p>
<p>Points: 24</p>
<p># Comments: 4</p>

## A blameless post-mortem of USA vs. Joseph Sullivan
 - [https://magoo.medium.com/a-blameless-post-mortem-of-usa-v-joseph-sullivan-a137162f7fc9](https://magoo.medium.com/a-blameless-post-mortem-of-usa-v-joseph-sullivan-a137162f7fc9)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 17:31:29+00:00

<p>Article URL: <a href="https://magoo.medium.com/a-blameless-post-mortem-of-usa-v-joseph-sullivan-a137162f7fc9">https://magoo.medium.com/a-blameless-post-mortem-of-usa-v-joseph-sullivan-a137162f7fc9</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33910605">https://news.ycombinator.com/item?id=33910605</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## A Generalist Neural Algorithmic Learner
 - [https://arxiv.org/abs/2209.11142](https://arxiv.org/abs/2209.11142)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 17:26:27+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2209.11142">https://arxiv.org/abs/2209.11142</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33910542">https://news.ycombinator.com/item?id=33910542</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Show HN: Hnpdf.com – Quick Access to PDFs Shared on Hacker News
 - [https://hnpdf.com/latest](https://hnpdf.com/latest)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 17:20:30+00:00

<p>Article URL: <a href="https://hnpdf.com/latest">https://hnpdf.com/latest</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33910465">https://news.ycombinator.com/item?id=33910465</a></p>
<p>Points: 13</p>
<p># Comments: 2</p>

## Banner (YC S19) Is Hiring a Senior PM
 - [https://www.ycombinator.com/companies/banner/jobs/MeC2JUn-senior-product-manager](https://www.ycombinator.com/companies/banner/jobs/MeC2JUn-senior-product-manager)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 17:00:09+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/banner/jobs/MeC2JUn-senior-product-manager">https://www.ycombinator.com/companies/banner/jobs/MeC2JUn-senior-product-manager</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33910196">https://news.ycombinator.com/item?id=33910196</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Edge-compatible Serverless Driver for Postgres
 - [https://neon.tech/blog/serverless-driver-for-postgres/](https://neon.tech/blog/serverless-driver-for-postgres/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 16:18:57+00:00

<p>Article URL: <a href="https://neon.tech/blog/serverless-driver-for-postgres/">https://neon.tech/blog/serverless-driver-for-postgres/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33909616">https://news.ycombinator.com/item?id=33909616</a></p>
<p>Points: 19</p>
<p># Comments: 14</p>

## Hash-based digital signatures (almost) from scratch
 - [https://medium.com/@georgwiese/hash-based-digital-signatures-almost-from-scratch-da57e54dd774](https://medium.com/@georgwiese/hash-based-digital-signatures-almost-from-scratch-da57e54dd774)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 16:11:31+00:00

<p>Article URL: <a href="https://medium.com/@georgwiese/hash-based-digital-signatures-almost-from-scratch-da57e54dd774">https://medium.com/@georgwiese/hash-based-digital-signatures-almost-from-scratch-da57e54dd774</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33909503">https://news.ycombinator.com/item?id=33909503</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Babashka: GraalVM Helped Create a Scripting Environment for Clojure
 - [https://medium.com/graalvm/babashka-how-graalvm-helped-create-a-fast-starting-scripting-environment-for-clojure-b0fcc38b0746](https://medium.com/graalvm/babashka-how-graalvm-helped-create-a-fast-starting-scripting-environment-for-clojure-b0fcc38b0746)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 15:54:55+00:00

<p>Article URL: <a href="https://medium.com/graalvm/babashka-how-graalvm-helped-create-a-fast-starting-scripting-environment-for-clojure-b0fcc38b0746">https://medium.com/graalvm/babashka-how-graalvm-helped-create-a-fast-starting-scripting-environment-for-clojure-b0fcc38b0746</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33909241">https://news.ycombinator.com/item?id=33909241</a></p>
<p>Points: 39</p>
<p># Comments: 5</p>

## Show HN: 0xFast – 10x Faster Web3 APIs
 - [https://www.0xfast.com](https://www.0xfast.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 15:36:45+00:00

<p>Excited to showcase 0xFast to HN!<p>Built using a new indexing system designed for Web3 data, 0xFast outperforms the most popular web3 API platforms, while also being 3x cheaper.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33908954">https://news.ycombinator.com/item?id=33908954</a></p>
<p>Points: 9</p>
<p># Comments: 5</p>

## Adventures in Creating a Minimal Alpine Linux Installer
 - [https://bt.ht/alpine/](https://bt.ht/alpine/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 15:28:25+00:00

<p>Article URL: <a href="https://bt.ht/alpine/">https://bt.ht/alpine/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33908848">https://news.ycombinator.com/item?id=33908848</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Nobody tell Paul Graham but I rebuilt his site to be beautiful
 - [https://prettygraham.com/](https://prettygraham.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 15:23:07+00:00

<p>Article URL: <a href="https://prettygraham.com/">https://prettygraham.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33908770">https://news.ycombinator.com/item?id=33908770</a></p>
<p>Points: 28</p>
<p># Comments: 21</p>

## Everything SBF is doing is in singular pursuit of not going to jail
 - [https://newsletter.mollywhite.net/p/everything-sam-bankman-fried-is-doing](https://newsletter.mollywhite.net/p/everything-sam-bankman-fried-is-doing)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 15:05:49+00:00

<p>Article URL: <a href="https://newsletter.mollywhite.net/p/everything-sam-bankman-fried-is-doing">https://newsletter.mollywhite.net/p/everything-sam-bankman-fried-is-doing</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33908577">https://news.ycombinator.com/item?id=33908577</a></p>
<p>Points: 127</p>
<p># Comments: 114</p>

## Codon: A high-performance Python compiler using LLVM
 - [https://github.com/exaloop/codon](https://github.com/exaloop/codon)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 15:05:45+00:00

<p>Article URL: <a href="https://github.com/exaloop/codon">https://github.com/exaloop/codon</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33908576">https://news.ycombinator.com/item?id=33908576</a></p>
<p>Points: 43</p>
<p># Comments: 15</p>

## The Sad Story of Heisenberg's Doctoral Oral Exam (1998)
 - [https://www.aps.org/publications/apsnews/199801/heisenberg.cfm](https://www.aps.org/publications/apsnews/199801/heisenberg.cfm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 14:38:08+00:00

<p>Article URL: <a href="https://www.aps.org/publications/apsnews/199801/heisenberg.cfm">https://www.aps.org/publications/apsnews/199801/heisenberg.cfm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33908280">https://news.ycombinator.com/item?id=33908280</a></p>
<p>Points: 22</p>
<p># Comments: 5</p>

## The road to Dart 3: A fully sound, null safe language
 - [https://medium.com/dartlang/the-road-to-dart-3-afdd580fbefa](https://medium.com/dartlang/the-road-to-dart-3-afdd580fbefa)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 14:22:24+00:00

<p>Article URL: <a href="https://medium.com/dartlang/the-road-to-dart-3-afdd580fbefa">https://medium.com/dartlang/the-road-to-dart-3-afdd580fbefa</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33908134">https://news.ycombinator.com/item?id=33908134</a></p>
<p>Points: 14</p>
<p># Comments: 4</p>

## AOC 2022 in q by experienced q programmers
 - [https://github.com/qbists/studyq/tree/main/aoc/2022](https://github.com/qbists/studyq/tree/main/aoc/2022)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 14:15:34+00:00

<p>Article URL: <a href="https://github.com/qbists/studyq/tree/main/aoc/2022">https://github.com/qbists/studyq/tree/main/aoc/2022</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33908058">https://news.ycombinator.com/item?id=33908058</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Ending support for Gitpod Self Hosted and moving our source to AGPL
 - [https://github.com/gitpod-io/website/blob/main/src/routes/blog/introducing-gitpod-dedicated.md](https://github.com/gitpod-io/website/blob/main/src/routes/blog/introducing-gitpod-dedicated.md)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 13:57:08+00:00

<p>Article URL: <a href="https://github.com/gitpod-io/website/blob/main/src/routes/blog/introducing-gitpod-dedicated.md">https://github.com/gitpod-io/website/blob/main/src/routes/blog/introducing-gitpod-dedicated.md</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33907897">https://news.ycombinator.com/item?id=33907897</a></p>
<p>Points: 9</p>
<p># Comments: 5</p>

## Ask HN: Are things getting more convenient but less satisfying?
 - [https://news.ycombinator.com/item?id=33907357](https://news.ycombinator.com/item?id=33907357)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 12:55:35+00:00

<p>I read a post on HN recently where a guy in his teens used to visit a construction site to watch how peopled worked and even help them for small fee. Now he could just watch a YouTube video about it in 10 different ways but the experience differs in that the workers used to treat him well and converse with him, which obviously made him a deep impression.<p>So I'd be interested to generalize this: with things getting more and more digital and disembodied (ahem, ChatGPT), does it produce convenience at the expense of contentment?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33907357">https://news.ycombinator.com/item?id=33907357</a></p>
<p>Points: 23</p>
<p># Comments: 17</p>

## ‘Significant overload’ caused Norway’s timber bridge collapse
 - [https://www.newcivilengineer.com/latest/significant-overload-caused-norways-timber-bridge-collapse-05-12-2022/](https://www.newcivilengineer.com/latest/significant-overload-caused-norways-timber-bridge-collapse-05-12-2022/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 12:46:55+00:00

<p>Article URL: <a href="https://www.newcivilengineer.com/latest/significant-overload-caused-norways-timber-bridge-collapse-05-12-2022/">https://www.newcivilengineer.com/latest/significant-overload-caused-norways-timber-bridge-collapse-05-12-2022/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33907276">https://news.ycombinator.com/item?id=33907276</a></p>
<p>Points: 23</p>
<p># Comments: 11</p>

## Ideas That Changed My Life
 - [https://collabfund.com/blog/ideas-that-changed-my-life/](https://collabfund.com/blog/ideas-that-changed-my-life/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 12:43:26+00:00

<p>Article URL: <a href="https://collabfund.com/blog/ideas-that-changed-my-life/">https://collabfund.com/blog/ideas-that-changed-my-life/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33907245">https://news.ycombinator.com/item?id=33907245</a></p>
<p>Points: 15</p>
<p># Comments: 3</p>

## A Christmas tree bauble that plays Doom
 - [https://spritesmods.com/?art=doom-bauble&page=1](https://spritesmods.com/?art=doom-bauble&page=1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 12:30:34+00:00

<p>Article URL: <a href="https://spritesmods.com/?art=doom-bauble&amp;page=1">https://spritesmods.com/?art=doom-bauble&amp;page=1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33907158">https://news.ycombinator.com/item?id=33907158</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Mars helicopter Ingenuity soars higher than ever on 35th Red Planet flight
 - [https://www.space.com/mars-helicopter-ingenuity-altitude-record-35th-flight](https://www.space.com/mars-helicopter-ingenuity-altitude-record-35th-flight)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 12:26:15+00:00

<p>Article URL: <a href="https://www.space.com/mars-helicopter-ingenuity-altitude-record-35th-flight">https://www.space.com/mars-helicopter-ingenuity-altitude-record-35th-flight</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33907132">https://news.ycombinator.com/item?id=33907132</a></p>
<p>Points: 31</p>
<p># Comments: 0</p>

## Deep Learning Fundamentals
 - [https://lightning.ai/pages/courses/deep-learning-fundamentals/](https://lightning.ai/pages/courses/deep-learning-fundamentals/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 12:25:53+00:00

<p>Article URL: <a href="https://lightning.ai/pages/courses/deep-learning-fundamentals/">https://lightning.ai/pages/courses/deep-learning-fundamentals/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33907130">https://news.ycombinator.com/item?id=33907130</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## PHP 8.2 Released
 - [https://www.php.net/releases/8.2/en.php](https://www.php.net/releases/8.2/en.php)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 12:22:05+00:00

<p>Article URL: <a href="https://www.php.net/releases/8.2/en.php">https://www.php.net/releases/8.2/en.php</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33907096">https://news.ycombinator.com/item?id=33907096</a></p>
<p>Points: 59</p>
<p># Comments: 16</p>

## The Muse (YC W12) Is Hiring a Senior Director of FP&A
 - [https://www.themuse.com/jobs/themuse/sr-director-of-financial-planning-analysis](https://www.themuse.com/jobs/themuse/sr-director-of-financial-planning-analysis)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 12:01:08+00:00

<p>Article URL: <a href="https://www.themuse.com/jobs/themuse/sr-director-of-financial-planning-analysis">https://www.themuse.com/jobs/themuse/sr-director-of-financial-planning-analysis</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33906948">https://news.ycombinator.com/item?id=33906948</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Astounding Data Stream Hack Gets UCI World Championship Qualifier Banned
 - [https://www.dcrainmaker.com/2022/12/zwift-uci-cheating-astounding-championship-qualifier.html](https://www.dcrainmaker.com/2022/12/zwift-uci-cheating-astounding-championship-qualifier.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 11:18:22+00:00

<p>Article URL: <a href="https://www.dcrainmaker.com/2022/12/zwift-uci-cheating-astounding-championship-qualifier.html">https://www.dcrainmaker.com/2022/12/zwift-uci-cheating-astounding-championship-qualifier.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33906699">https://news.ycombinator.com/item?id=33906699</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Tell HN: Travis CI is seemingly compromised (once again)
 - [https://news.ycombinator.com/item?id=33906591](https://news.ycombinator.com/item?id=33906591)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 11:00:01+00:00

<p>A number of Travis CI users appear to have had Travis CI tokens revoked by Github in response to suspicious activity surrounding token.<p>Travis themselves have still not issued any notice or acknowledged this incident so it's worth letting the community know if they weren't already aware.<p>From memory, this will be the second breach in 2022 (https://blog.aquasec.com/travis-ci-security) in addition to last year's secret exposure (https://arstechnica.com/information-technology/2021/09/travis-ci-flaw-exposed-secrets-for-thousands-of-open-source-projects/)<p>---<p>A sampling of users on Twitter who have run into this issue:<p>https://twitter.com/peter_szilagyi/status/1600593274108055559<p>https://twitter.com/yaqwsx_cz/status/1600599797118996491<p>https://twitter.com/samonchain/status/1600611567606775808<p>https://twitter.com/dzarda_cz/status/1600613369408634886<p>https://twitter.com/samonchain/status/1600611567606775808<p>---<p>An example notice being sent out by Github (in lieu of Travis themselves taking any action):<p>> Hi {username}<p>> We're writing to let you know that we observed suspicious activity that suggests a threat actor used a Personal Access Token (PAT) associated with your account to access private repository metadata.<p>> Out of an abundance of caution, we reset your account password and revoked all of your Personal Access Tokens (classic), OAuth App tokens, and GitHub App tokens to protect your account, {username}.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33906591">https://news.ycombinator.com/item?id=33906591</a></p>
<p>Points: 28</p>
<p># Comments: 3</p>

## Show HN: Ezy – open-source gRPC client, alternative to Postman and Insomnia
 - [https://github.com/getezy/ezy/releases/tag/v1.0.0-beta.13.2](https://github.com/getezy/ezy/releases/tag/v1.0.0-beta.13.2)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 10:50:05+00:00

<p>In this release I have concentrated on user experience:<p>- Full support of shortcuts
- Reworked collections management
- Notifications
- Improved UX<p>gRPC clients I’ve worked with had drawbacks and didn’t fit my use-case in a way I was expecting, since I’ve started working with gRPC 3+ years ago.<p>Since then, I wanted a tool that fits any need in gRPC world. This is why I created ezy.<p>Compared to Insomnia and Postman, ezy offers better streams support, allows you to use Server-Side and Mutual TLS with custom TLS certificates, works with gRPC-Web and has a more slick UI/UX.<p>If you are looking for a gRPC/gRPC-Web client which fits your needs, give ezy a chance!<p>I’d love to hear your feedback and answer any questions regarding ezy.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33906520">https://news.ycombinator.com/item?id=33906520</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## What comes up when you flush
 - [https://www.colorado.edu/today/2022/12/08/cu-scientists-shine-light-what-comes-when-you-flush](https://www.colorado.edu/today/2022/12/08/cu-scientists-shine-light-what-comes-when-you-flush)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 10:06:29+00:00

<p>Article URL: <a href="https://www.colorado.edu/today/2022/12/08/cu-scientists-shine-light-what-comes-when-you-flush">https://www.colorado.edu/today/2022/12/08/cu-scientists-shine-light-what-comes-when-you-flush</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33906251">https://news.ycombinator.com/item?id=33906251</a></p>
<p>Points: 7</p>
<p># Comments: 4</p>

## Writing Is Magic
 - [https://brooker.co.za/blog/2022/11/08/writing.html](https://brooker.co.za/blog/2022/11/08/writing.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 09:44:36+00:00

<p>Article URL: <a href="https://brooker.co.za/blog/2022/11/08/writing.html">https://brooker.co.za/blog/2022/11/08/writing.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33906135">https://news.ycombinator.com/item?id=33906135</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Ask HN: What are your goals for 2023?
 - [https://news.ycombinator.com/item?id=33906133](https://news.ycombinator.com/item?id=33906133)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 09:44:05+00:00

<p>Mine are to move abroad for work, pivot from SWD to SRE/Devops and get travel europe by train.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33906133">https://news.ycombinator.com/item?id=33906133</a></p>
<p>Points: 27</p>
<p># Comments: 41</p>

## 1M Watts of RF – How the FM Supertower Works
 - [https://www.jeffgeerling.com/blog/2022/1-million-watts-rf-how-fm-supertower-works](https://www.jeffgeerling.com/blog/2022/1-million-watts-rf-how-fm-supertower-works)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 08:33:54+00:00

<p>Article URL: <a href="https://www.jeffgeerling.com/blog/2022/1-million-watts-rf-how-fm-supertower-works">https://www.jeffgeerling.com/blog/2022/1-million-watts-rf-how-fm-supertower-works</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33905695">https://news.ycombinator.com/item?id=33905695</a></p>
<p>Points: 22</p>
<p># Comments: 5</p>

## Artificial intelligence is permeating business at last
 - [https://www.economist.com/business/2022/12/06/artificial-intelligence-is-permeating-business-at-last](https://www.economist.com/business/2022/12/06/artificial-intelligence-is-permeating-business-at-last)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 07:59:27+00:00

<p>Article URL: <a href="https://www.economist.com/business/2022/12/06/artificial-intelligence-is-permeating-business-at-last">https://www.economist.com/business/2022/12/06/artificial-intelligence-is-permeating-business-at-last</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33905450">https://news.ycombinator.com/item?id=33905450</a></p>
<p>Points: 5</p>
<p># Comments: 3</p>

## Fermilab/CERN recommendation for Linux distribution
 - [https://news.fnal.gov/2022/12/fermilab-cern-recommendation-for-linux-distribution/](https://news.fnal.gov/2022/12/fermilab-cern-recommendation-for-linux-distribution/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 04:53:58+00:00

<p>Article URL: <a href="https://news.fnal.gov/2022/12/fermilab-cern-recommendation-for-linux-distribution/">https://news.fnal.gov/2022/12/fermilab-cern-recommendation-for-linux-distribution/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33904336">https://news.ycombinator.com/item?id=33904336</a></p>
<p>Points: 25</p>
<p># Comments: 2</p>

## Organ Donations, Transplants Increase on Days of Largest Motorcycle Rallies
 - [https://hms.harvard.edu/news/organ-donations-transplants-increase-days-largest-motorcycle-rallies](https://hms.harvard.edu/news/organ-donations-transplants-increase-days-largest-motorcycle-rallies)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 04:50:22+00:00

<p>Article URL: <a href="https://hms.harvard.edu/news/organ-donations-transplants-increase-days-largest-motorcycle-rallies">https://hms.harvard.edu/news/organ-donations-transplants-increase-days-largest-motorcycle-rallies</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33904299">https://news.ycombinator.com/item?id=33904299</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## Microsoft doesn't own the ending to Minecraft
 - [https://theeggandtherock.substack.com/p/i-wrote-a-story-for-a-friend](https://theeggandtherock.substack.com/p/i-wrote-a-story-for-a-friend)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 04:42:49+00:00

<p>Article URL: <a href="https://theeggandtherock.substack.com/p/i-wrote-a-story-for-a-friend">https://theeggandtherock.substack.com/p/i-wrote-a-story-for-a-friend</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33904251">https://news.ycombinator.com/item?id=33904251</a></p>
<p>Points: 18</p>
<p># Comments: 4</p>

## Pulling MikroTik into the Limelight Demystifying and Jailbreaking RouterS
 - [https://margin.re/2022/06/pulling-mikrotik-into-the-limelight/](https://margin.re/2022/06/pulling-mikrotik-into-the-limelight/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 04:20:50+00:00

<p>Article URL: <a href="https://margin.re/2022/06/pulling-mikrotik-into-the-limelight/">https://margin.re/2022/06/pulling-mikrotik-into-the-limelight/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33904105">https://news.ycombinator.com/item?id=33904105</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## You don't need live chat on your website
 - [https://timharek.no/blog/you-dont-need-chat-on-your-site/](https://timharek.no/blog/you-dont-need-chat-on-your-site/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 04:06:36+00:00

<p>Article URL: <a href="https://timharek.no/blog/you-dont-need-chat-on-your-site/">https://timharek.no/blog/you-dont-need-chat-on-your-site/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33904017">https://news.ycombinator.com/item?id=33904017</a></p>
<p>Points: 15</p>
<p># Comments: 7</p>

## Effectivealtruism.org purchased a £15M estate for its headquarters in 2021
 - [https://twitter.com/paulmainwood/status/1600433194691502081](https://twitter.com/paulmainwood/status/1600433194691502081)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 03:35:45+00:00

<p>Article URL: <a href="https://twitter.com/paulmainwood/status/1600433194691502081">https://twitter.com/paulmainwood/status/1600433194691502081</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33903850">https://news.ycombinator.com/item?id=33903850</a></p>
<p>Points: 32</p>
<p># Comments: 18</p>

## 5000x faster CRDTs: An adventure in optimization (2021)
 - [https://josephg.com/blog/crdts-go-brrr/](https://josephg.com/blog/crdts-go-brrr/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 02:57:11+00:00

<p>Article URL: <a href="https://josephg.com/blog/crdts-go-brrr/">https://josephg.com/blog/crdts-go-brrr/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33903563">https://news.ycombinator.com/item?id=33903563</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## Intel is using DXVK for their Windows Arc GPU DX9 drivers
 - [https://www.gamingonlinux.com/2022/12/intel-using-dxvk-part-of-steam-proton-for-their-windows-arc-gpu-dx-9-drivers/](https://www.gamingonlinux.com/2022/12/intel-using-dxvk-part-of-steam-proton-for-their-windows-arc-gpu-dx-9-drivers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 02:39:33+00:00

<p>Article URL: <a href="https://www.gamingonlinux.com/2022/12/intel-using-dxvk-part-of-steam-proton-for-their-windows-arc-gpu-dx-9-drivers/">https://www.gamingonlinux.com/2022/12/intel-using-dxvk-part-of-steam-proton-for-their-windows-arc-gpu-dx-9-drivers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33903420">https://news.ycombinator.com/item?id=33903420</a></p>
<p>Points: 23</p>
<p># Comments: 1</p>

## Google combines Maps and Waze teams in restructuring move
 - [https://www.wsj.com/articles/google-combines-maps-and-waze-teams-in-restructuring-move-11670462301](https://www.wsj.com/articles/google-combines-maps-and-waze-teams-in-restructuring-move-11670462301)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 01:42:57+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/google-combines-maps-and-waze-teams-in-restructuring-move-11670462301">https://www.wsj.com/articles/google-combines-maps-and-waze-teams-in-restructuring-move-11670462301</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33903016">https://news.ycombinator.com/item?id=33903016</a></p>
<p>Points: 303</p>
<p># Comments: 386</p>

## Soil in Midwestern US is Eroding 10 to 1k Times Faster than it Forms
 - [https://www.umass.edu/news/article/soil-midwestern-us-eroding-10-1000-times-faster-it-forms-study-finds](https://www.umass.edu/news/article/soil-midwestern-us-eroding-10-1000-times-faster-it-forms-study-finds)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 01:22:42+00:00

<p>Article URL: <a href="https://www.umass.edu/news/article/soil-midwestern-us-eroding-10-1000-times-faster-it-forms-study-finds">https://www.umass.edu/news/article/soil-midwestern-us-eroding-10-1000-times-faster-it-forms-study-finds</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33902878">https://news.ycombinator.com/item?id=33902878</a></p>
<p>Points: 65</p>
<p># Comments: 21</p>

## Boris, a tradeoff-oriented goal-setting process
 - [https://vaughntan.org/unpacking-boris](https://vaughntan.org/unpacking-boris)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 01:02:08+00:00

<p>Article URL: <a href="https://vaughntan.org/unpacking-boris">https://vaughntan.org/unpacking-boris</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33902718">https://news.ycombinator.com/item?id=33902718</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## Paleontologist accused of faking data in dino-killing asteroid paper
 - [https://www.science.org/content/article/paleontologist-accused-faking-data-dino-killing-asteroid-paper](https://www.science.org/content/article/paleontologist-accused-faking-data-dino-killing-asteroid-paper)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 00:44:18+00:00

<p>Article URL: <a href="https://www.science.org/content/article/paleontologist-accused-faking-data-dino-killing-asteroid-paper">https://www.science.org/content/article/paleontologist-accused-faking-data-dino-killing-asteroid-paper</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33902583">https://news.ycombinator.com/item?id=33902583</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## TSMC founder Morris Chang says globalization 'almost dead'
 - [https://asia.nikkei.com/Business/Tech/Semiconductors/TSMC-founder-Morris-Chang-says-globalization-almost-dead](https://asia.nikkei.com/Business/Tech/Semiconductors/TSMC-founder-Morris-Chang-says-globalization-almost-dead)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 00:26:22+00:00

<p>Article URL: <a href="https://asia.nikkei.com/Business/Tech/Semiconductors/TSMC-founder-Morris-Chang-says-globalization-almost-dead">https://asia.nikkei.com/Business/Tech/Semiconductors/TSMC-founder-Morris-Chang-says-globalization-almost-dead</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33902422">https://news.ycombinator.com/item?id=33902422</a></p>
<p>Points: 34</p>
<p># Comments: 10</p>

## Precise atom manipulation through deep reinforcement learning
 - [https://www.nature.com/articles/s41467-022-35149-w](https://www.nature.com/articles/s41467-022-35149-w)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 00:19:30+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s41467-022-35149-w">https://www.nature.com/articles/s41467-022-35149-w</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33902363">https://news.ycombinator.com/item?id=33902363</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## Piss-Weak Parenting
 - [https://mrfireside.medium.com/piss-weak-parenting-7672bf95de01](https://mrfireside.medium.com/piss-weak-parenting-7672bf95de01)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-12-08 00:03:03+00:00

<p>Article URL: <a href="https://mrfireside.medium.com/piss-weak-parenting-7672bf95de01">https://mrfireside.medium.com/piss-weak-parenting-7672bf95de01</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33902219">https://news.ycombinator.com/item?id=33902219</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>


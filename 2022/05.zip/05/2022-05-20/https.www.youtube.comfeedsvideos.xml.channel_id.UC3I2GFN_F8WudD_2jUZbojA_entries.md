# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Aeon Station - Air (Live on KEXP)
 - [https://www.youtube.com/watch?v=jFythBwHnOA](https://www.youtube.com/watch?v=jFythBwHnOA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-20 00:00:00+00:00

http://KEXP.ORG presents Aeon Station performing “Air” live in the KEXP studio. Recorded April 29, 2022.

Kevin Whelan - Bass / Vocals
Greg Whelan - Guitar / Vocals
Tom Beaujour - Guitar / Vocals
Lysa Opfer - Keyboards / Bass / Vocals
Jerry MacDonald - Drums

Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://ffm.to/aeonstation_observatory
http://kexp.org

## Aeon Station - Better Love (Live on KEXP)
 - [https://www.youtube.com/watch?v=J4TTItJDcxE](https://www.youtube.com/watch?v=J4TTItJDcxE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-20 00:00:00+00:00

http://KEXP.ORG presents Aeon Station performing “Better Love” live in the KEXP studio. Recorded April 29, 2022.

Kevin Whelan - Bass / Vocals
Greg Whelan - Guitar / Vocals
Tom Beaujour - Guitar / Vocals
Lysa Opfer - Keyboards / Bass / Vocals
Jerry MacDonald - Drums

Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://ffm.to/aeonstation_observatory
http://kexp.org

## Aeon Station - Fade (Live on KEXP)
 - [https://www.youtube.com/watch?v=JolzdvqXcFg](https://www.youtube.com/watch?v=JolzdvqXcFg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-20 00:00:00+00:00

http://KEXP.ORG presents Aeon Station performing “Fade” live in the KEXP studio. Recorded April 29, 2022.

Kevin Whelan - Bass / Vocals
Greg Whelan - Guitar / Vocals
Tom Beaujour - Guitar / Vocals
Lysa Opfer - Keyboards / Bass / Vocals
Jerry MacDonald - Drums

Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://ffm.to/aeonstation_observatory
http://kexp.org

## Aeon Station - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=uF3quuuAya4](https://www.youtube.com/watch?v=uF3quuuAya4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-20 00:00:00+00:00

http://KEXP.ORG presents Aeon Station performing live in the KEXP studio. Recorded April 29, 2022.

Songs:
Better Love
Fade
Air
Queens

Kevin Whelan - Bass / Vocals
Greg Whelan - Guitar / Vocals
Tom Beaujour - Guitar / Vocals
Lysa Opfer - Keyboards / Bass / Vocals
Jerry MacDonald - Drums

Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://ffm.to/aeonstation_observatory
http://kexp.org

## Aeon Station - Queens (Live on KEXP)
 - [https://www.youtube.com/watch?v=XmCBx9VolWA](https://www.youtube.com/watch?v=XmCBx9VolWA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-20 00:00:00+00:00

http://KEXP.ORG presents Aeon Station performing “Queens” live in the KEXP studio. Recorded April 29, 2022.

Kevin Whelan - Bass / Vocals
Greg Whelan - Guitar / Vocals
Tom Beaujour - Guitar / Vocals
Lysa Opfer - Keyboards / Bass / Vocals
Jerry MacDonald - Drums

Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://ffm.to/aeonstation_observatory
http://kexp.org


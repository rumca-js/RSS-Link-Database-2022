# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## Is The OP-1 Field Worth $2000?
 - [https://www.youtube.com/watch?v=LYR-Fq1tyX0](https://www.youtube.com/watch?v=LYR-Fq1tyX0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2022-05-20 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong I'm a long-time OP-1 user and I love the device. Here's my thoughts on the new OP-1 Field, and a perspective on how we could think about gear. Thanks for watching!
*I think, if I ever do a video about gear, it would definitely be about how it's used in creating music rather than the technical aspects of features and how many things it can do. That's just me!

Songs in this video:
I'm a Dude - https://www.youtube.com/watch?v=tKvqhlhXq9s
Two at a Time - https://www.youtube.com/watch?v=MwO-PCJJf9E
Number 1 - https://www.youtube.com/watch?v=s9JYWLGxdq4


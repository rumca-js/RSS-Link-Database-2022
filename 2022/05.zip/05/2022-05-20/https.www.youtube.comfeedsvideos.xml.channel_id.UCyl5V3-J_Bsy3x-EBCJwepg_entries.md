# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Law & Order: Microaggression Victims Unit
 - [https://www.youtube.com/watch?v=RDjm9dseyok](https://www.youtube.com/watch?v=RDjm9dseyok)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-05-20 00:00:00+00:00

In the social justice system, words are considered violence. In New York City, the dedicated detectives who investigate these vicious attacks are members of an elite squad known as the Microaggression Victims Unit. These are their stories.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Bee Weekly: The Officer Tatum and PragerU’s Will Witt
 - [https://www.youtube.com/watch?v=OIDHpWnGEyE](https://www.youtube.com/watch?v=OIDHpWnGEyE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-05-20 00:00:00+00:00

The Babylon Bee talks to PragerU’s man on the street, Will Witt, and The Officer Brandon Tatum. Adam and Jarret talk to Will about what’s going on in the news this week like baby formula shortages, the media’s different coverage of recent tragedies depending on what narrative they fit, and Twitter employees who got caught saying some communist things! Never go full potato, Twitter!

Kyle and Adam talk to Brandon Tatum about the craziest cop stories he has, law enforcement being vilified by media and politicians, and how fast you can drive over the speed limit without getting pulled over. Some of this interview is for Babylon Bee subscribers only!

Will Witt chats with the Bee about his man on the street videos and whether or not we should just call it a day and weep for the future of the nation.

In the subscriber lounge, subscribers get the rest of the Brandon Tatum interview, Will Witt answers the Ten Questions, and subscribers get their best headlines read!

Check Out Brandon's Youtube: https://www.youtube.com/c/TheOfficerTatum

Brandon Tatum just landed a new radio show on Salem Radio: https://salemnewschannel.com/host/brandon-tatum/

And check out his book: https://www.amazon.com/Beaten-Black-Blue-Being-America/dp/1642938513

Learn more about Will: https://www.prageru.com/presenters/will-witt

You can also see more of Will Witt over at PragerU: https://www.youtube.com/c/prageruniversity

This episode is brought to you by our wonderful sponsors who you should absolutely check out as well:
My Patriot Supply: preparewithbee.com
Allegiance Gold: https://ag.allegiancegold.com/bb/
Alliance Defending Freedom: https://adflegal.org/monthly-gift-flags?sourcecode=10022276_r850&utm_medium=podcast&utm_campaign=flag_bearer&reference_code=10022276
The PublicSq app: https://publicsq.com/welcome?path=/


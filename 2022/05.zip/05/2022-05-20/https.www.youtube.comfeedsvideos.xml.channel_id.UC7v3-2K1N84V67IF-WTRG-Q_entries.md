# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## New MCU Daredevil Series Coming to Disney+....And I'm Concerned!
 - [https://www.youtube.com/watch?v=ScUDomC1om8](https://www.youtube.com/watch?v=ScUDomC1om8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-05-21 00:00:00+00:00

It was announced that Disney+ is bringing us a new season (or new series) of Daredevil. While this should get me excited, I am met only with concern. Here are my thoughts.

#Daredevil


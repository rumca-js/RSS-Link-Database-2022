# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## How This Man Just Caused a $45 BILLION Crash [Terra Luna]
 - [https://www.youtube.com/watch?v=3KZY41SqaTI](https://www.youtube.com/watch?v=3KZY41SqaTI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2022-05-20 00:00:00+00:00

Do Kwon thought he could rule the crypto world with Terra Luna, instead what followed was the largest failure to occur in the crypto space.
Correction at 1:58 I showed the screenshot of the wrong project, it's supposed to be 'Basis Cash', not 'Basis Markets'. Sorry about that.

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

» ColdFusion Discord:  https://discord.gg/coldfusion
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusioncollective
» Podcast I Co-host: https://www.youtube.com/channel/UC6jKUaNXSnuW52CxexLcOJg
» Podcast Version of Videos: https://open.spotify.com/show/3dj6YGjgK3eA4Ti6G2Il8H
https://podcasts.apple.com/us/podcast/coldfusion/id1467404358

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

Sources:

Personal interviews with sources at Terra Labs

https://www.coindesk.com/business/2022/05/08/ust-briefly-loses-peg-luna-drops-10/

https://www.bloomberg.com/news/articles/2022-05-15/luna-crash-this-crypto-insider-warned-of-terra-ust-s-collapse

https://www.coindesk.com/layer2/2022/04/22/built-to-fail-why-terrausds-growth-is-giving-finance-experts-nightmares/

https://www.euronews.com/next/2022/05/12/terra-luna-stablecoin-collapse-is-this-the-2008-financial-crash-moment-of-cryptocurrency

https://decrypt.co/100434/what-happened-terras-bitcoin-reserve-ust-luna-crashed

https://fortune.com/2022/05/13/terra-ust-stablecoin-crash-suspicious-potential-attack-george-soros/

https://coinjournal.net/news/the-10-million-luna-twitter-bet-who-will-win/

https://www.coindesk.com/business/2022/05/09/ust-stablecoin-falls-below-dollar-peg-for-second-time-in-48-hours/


My Music Channel:  https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

//Soundtrack//

Vesky - With You

David Keno - Golden Ticket (Original Mix)

Deccies - Subtle

Zero 7 - Out of Town

Going Deeper - Escape

Mogwai - Take Me Somewhere Nice

Giyo - Are the Animals Gone

Jónsi & Alex - Boy 1904

Psalm Trees, Guillaume Muschalle - Forever Tired Ft. Thomas Renwick

Burn Water - Yellow Jade


» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide


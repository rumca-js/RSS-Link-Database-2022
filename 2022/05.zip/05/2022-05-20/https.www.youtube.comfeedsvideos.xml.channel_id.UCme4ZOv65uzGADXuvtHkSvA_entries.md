# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 2 Księga Kronik || Rozdział 22
 - [https://www.youtube.com/watch?v=Scsu1g9x_QE](https://www.youtube.com/watch?v=Scsu1g9x_QE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-05-21 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#289] Jak kochasz, to pozwól odejść
 - [https://www.youtube.com/watch?v=YwXOtG8wqGk](https://www.youtube.com/watch?v=YwXOtG8wqGk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-05-21 00:00:00+00:00

#cnn #dobrewiadomości      @Langustanapalmie 

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedziela, VI Tydzień Wielkanocny, Rok C, II
Szósta Niedziela Wielkanocna

1. czytanie (Dz 15, 1-2. 22-29)

Niektórzy przybysze z Judei nauczali braci: «Jeżeli się nie poddacie obrzezaniu według zwyczaju Mojżeszowego, nie możecie być zbawieni».
Kiedy doszło do niemałych sporów i roztrząsań między nimi a Pawłem i Barnabą, postanowiono, że Paweł i Barnaba, i jeszcze kilku spośród nich udadzą się w sprawie tego sporu do Jeruzalem, do apostołów i starszych.
Wtedy apostołowie i starsi wraz z całym Kościołem postanowili wybrać ludzi przodujących wśród braci: Judę, zwanego Barsabą, i Sylasa i wysłać do Antiochii razem z Barnabą i Pawłem. Posłali przez nich pismo tej treści:
«Apostołowie i starsi bracia przesyłają pozdrowienie braciom pogańskiego pochodzenia w Antiochii, w Syrii i w Cylicji. Ponieważ dowiedzieliśmy się, że niektórzy bez naszego upoważnienia wyszli od nas i zaniepokoili was naukami, siejąc zamęt w waszych duszach, postanowiliśmy jednomyślnie wybrać mężów i wysłać razem z naszymi drogimi: Barnabą i Pawłem, którzy dla imienia Pana naszego, Jezusa Chrystusa, poświęcili swe życie. Wysyłamy więc Judę i Sylasa, którzy oznajmią wam ustnie to samo.
Postanowiliśmy bowiem, Duch Święty i my, nie nakładać na was żadnego ciężaru oprócz tego, co konieczne. Powstrzymajcie się od ofiar składanych bożkom, od krwi, od tego, co uduszone, i od nierządu. Dobrze uczynicie, jeżeli powstrzymacie się od tego. Bywajcie zdrowi!»

2. czytanie (Ap 21, 10-14. 22-23)

Uniósł mnie anioł w zachwyceniu na górę wielką i wyniosłą, i ukazał mi Miasto Święte – Jeruzalem, zstępujące z nieba od Boga, mające chwałę Boga. Źródło jego światła podobne do kamienia drogocennego, jakby do jaspisu o przejrzystości kryształu: Miało ono mur wielki i wysoki, miało dwanaście bram, a na bramach – dwunastu aniołów i wypisane imiona, które są imionami dwunastu szczepów synów Izraela. Od wschodu trzy bramy i od północy trzy bramy, i od południa trzy bramy, i od zachodu trzy bramy. A mur Miasta ma dwanaście warstw fundamentu, a na nich dwanaście imion dwunastu Apostołów Baranka.
A świątyni w nim nie dojrzałem: bo jego świątynią jest Pan Bóg wszechmogący oraz Baranek. I Miastu nie trzeba słońca ni księżyca, by mu świeciły, bo chwała Boga je oświetliła, a jego lampą – Baranek.

Ewangelia (J 14, 23-29)

Jezus powiedział do swoich uczniów:
«Jeśli Mnie kto miłuje, będzie zachowywał moją naukę, a Ojciec mój umiłuje go i przyjdziemy do niego, i mieszkanie u niego uczynimy. Kto nie miłuje Mnie, ten nie zachowuje słów moich. A nauka, którą słyszycie, nie jest moja, ale Tego, który Mnie posłał, Ojca.
To wam powiedziałem, przebywając wśród was. A Paraklet, Duch Święty, którego Ojciec pośle w moim imieniu, On was wszystkiego nauczy i przypomni wam wszystko, co Ja wam powiedziałem.
Pokój zostawiam wam, pokój mój daję wam. Nie tak jak daje świat, Ja wam daję. Niech się nie trwoży serce wasze ani się nie lęka. Słyszeliście, że wam powiedziałem: Odchodzę i przyjdę znów do was. Gdybyście Mnie miłowali, rozradowalibyście się, że idę do Ojca, bo Ojciec większy jest ode Mnie.
A teraz powiedziałem wam o tym, zanim to nastąpi, abyście uwierzyli, gdy się to stanie».

________________________________________

Niedzielnik*. Komentarze do czytań na uroczystości:
→ https://wdrodze.pl/produkt/niedzielnik-komentarze-do-czytan-na-uroczystosci/

________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

________________________________________

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1098] Mosty
 - [https://www.youtube.com/watch?v=6URCkGytHRw](https://www.youtube.com/watch?v=6URCkGytHRw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-05-21 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Strona zbiórki → https://charytatywnie.fundacjamalak.pl/

Tradycyjne przelewy:
Nr konta do wpłat w PLN: 42 2490 0005 0000 4600 1184 3564 
IBAN: PL 42 2490 0005 0000 4600 1184 3564
Tytułem: UKRAINA

Fundacja MALAK
ul. Śliwkowa 4
31-982 Kraków
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 2 Księga Kronik || Rozdział 21
 - [https://www.youtube.com/watch?v=wSBvqrgtF9k](https://www.youtube.com/watch?v=wSBvqrgtF9k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-05-20 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## W końcu! Wielbienie w Tauron Arena!
 - [https://www.youtube.com/watch?v=EC2Xjt7hpQ4](https://www.youtube.com/watch?v=EC2Xjt7hpQ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-05-20 00:00:00+00:00

Po znów niemałej przerwie, z radością i nadzieją, wracamy do tego, bez czego ciężko doświadczyć Kościoła - do spotkania i do tego, co może zmieniać nam optykę i serce - uwielbienia.  NIENASYCENI - bo każdemu z nas gdzieś b r a k u j e. Każdy z nas doświadcza tej suchej spękanej ziemi w sobie. Za mało pokoju, cierpliwości, miłości, radości... Nosimy tę dziurę w sercu, którą zapełnić może tylko Bóg - a stawiając Go w centrum i oddając należną Mu chwałę - porządkujemy swoją rzeczywistość i dajemy Mu przestrzeń, żeby działał - nasycał. 

UWAGA! - Miejsca na PŁYCIE są miejscami siedzącymi nienumerowanymi!

BILETY ☞ https://bit.ly/Nienasyceni_Tauron
WYDARZENIE ☞ https://fb.me/e/1WzTzhC1Q

Miejsce: 
TAURON Arena Kraków
Stanisława Lema 7, 31-571 Kraków
https://goo.gl/maps/WXMgxE5v9Ajitor39

OTWARCIE DRZWI ☞ 16:00
START ☞ 18:30
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1097] Nad ranem
 - [https://www.youtube.com/watch?v=D19we8t4ND4](https://www.youtube.com/watch?v=D19we8t4ND4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-05-20 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Strona zbiórki → https://charytatywnie.fundacjamalak.pl/

Tradycyjne przelewy:
Nr konta do wpłat w PLN: 42 2490 0005 0000 4600 1184 3564 
IBAN: PL 42 2490 0005 0000 4600 1184 3564
Tytułem: UKRAINA

Fundacja MALAK
ul. Śliwkowa 4
31-982 Kraków
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


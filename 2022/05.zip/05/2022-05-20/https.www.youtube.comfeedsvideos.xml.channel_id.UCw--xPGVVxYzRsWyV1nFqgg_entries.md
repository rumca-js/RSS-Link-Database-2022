# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Love♥️Death💀Robots🤖RETURNS TO FORM!
 - [https://www.youtube.com/watch?v=IhRpJWqUsJs](https://www.youtube.com/watch?v=IhRpJWqUsJs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-05-21 00:00:00+00:00

My thoughts on the third season of Love Death Robots! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## LOST METAL COVER!🦋 Predator Goes Hulu?🏹 OP Red Character Reveal!⚓-FANTASY NEWS
 - [https://www.youtube.com/watch?v=7DxNgGs6Jo0](https://www.youtube.com/watch?v=7DxNgGs6Jo0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-05-20 00:00:00+00:00

Let’s jump into the fantasy news! 
Offset your carbon footprint on Wren: https://www.wren.co/start/danielgreene
 The first 100 people who sign up will have 10 extra trees planted in their name!

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

NEWS: 

00:00 intro

00:36 Lost Metal cover reveal: https://www.reddit.com/r/brandonsanderson/comments/uqwe1f/the_lost_metal_uk_cover_reveal/ 

01:28 Wheel of Time Teaser: https://twitter.com/TheWheelOfTime/status/1526960816863358976?s=20&t=CP600AXrex3E5fTr2KOmEw 

01:48 SPSFBO Cover Competition: https://mark---lawrence.blogspot.com/2022/05/spfbo-8-cover-contest.html 

02:26 WREN 

04:18 Thousand Sunny in Film Red: https://www.crunchyroll.com/anime-news/2022/05/17-1/straw-hats-thousand-sunny-ship-gets-a-new-look-for-one-piece-film-red 

07:31 Stranger Things Season 2: https://www.thewrap.com/stranger-things-season-4-finale-length-over-two-hours/ 

09:16 Stan Lee Returns: https://www.hollywoodreporter.com/movies/movie-news/stan-lee-marvel-studios-licensing-deal-1235149039/ 

11:25 Predator Prequel: https://twitter.com/DiscussingFilm/status/1526186492292485121  

12:10 What We Do In the Shadows Season 4: https://collider.com/what-we-do-in-the-shadows-season-4-release-date/ 

12:57 Rick and Morty Anime: https://www.hollywoodreporter.com/tv/tv-news/rick-morty-anime-spinoff-1235149017/ 

14:14 Adult Scooby Doo: https://twitter.com/Variety/status/1526950560716533762 

15:51 (POSSIBLE CLICKBAIT) Avatar Prequel Movie: https://avatarnews.co/post/684454945400995840/animated-avatar-prequel-and-zuko-theatrical-films


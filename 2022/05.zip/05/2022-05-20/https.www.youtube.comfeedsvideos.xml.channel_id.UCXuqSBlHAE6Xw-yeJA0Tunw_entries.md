# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Now the Real Work Begins... - Moving Vlog Day 2
 - [https://www.youtube.com/watch?v=bqPyokUFNpY](https://www.youtube.com/watch?v=bqPyokUFNpY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-05-21 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Create your build at https://www.buildredux.com/linus

LTT staff help Linus and Yvonne movie into their new house on the weekend but they've got a giant cat tree to contend with and Dan gets left alone with the underwear drawer lol.

Discuss on the forum: https://linustechtips.com/topic/1432495-absolute-chaos-new-house-moving-vlog-day-2/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:50 The Plan
2:10 Alone in their house :|
3:45 Linus Returns
7:10 illegal stuff
8:08 Blame Dan
9:10 Cat Love
10:29 Outro

## My Investment Pays Off - WAN Show May 20, 2022
 - [https://www.youtube.com/watch?v=QpELDE0Dd-Y](https://www.youtube.com/watch?v=QpELDE0Dd-Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-05-20 00:00:00+00:00

Check out ORIGIN PC’s New EVO Thin and Light Laptops here: https://bit.ly/3vtppXI
Get 50% off (up to $200) your annual Zoho Desk subscription at: https://lmg.gg/zohodeskwan
Check out Secret Lab at https://lmg.gg/SecretLabWAN

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/My-Investment-Pays-Off---WAN-Show-May-20--2022-e1iugje

Timestamps: (Courtesy of NoKi1119)
0:00 Chapters
1:15 Intro
1:46 Topic #1 - Framework products updates
1:55 Framework's mainboard for sale, Apple's influence
5:33 Framework's mainboard schematics
7:54 Luke skeptical he would get his Steam Deck
9:06 Linus shows his OneXPlayer Mini GUNDAM, specs
12:28 Protecting IP via policies while allowing repairs
17:56 Discussing EOL, warranty & bankruptcy
23:23 LTTStore embroidered woman merch, MEMELORD promo
25:54 Topic #2 - Finalizing the new labs
26:12 Luke calls out Linus, Linus counter-calls out Luke
28:46 Linus spoils Luke with laptops
30:12 Moving to labs, writers & staff
32:54 Luke is NOT poor, stocks & investment
35:28 House update, Luke helping Linus move out
36:44 Home theater, vantablack for walls
41:42 Duvetyne, commando Cloth, Velour, Linus calls article out
43:04 Cole-Bar hammer, comparing to NFTs
44:56 From high school to PhD, first WAN show
46:22 Sponsor - Origin PC
47:42 Sponsor - Zoho Desk
48:42 Sponsor - Secret Lab
49:40 Topic #3 - Elon Musk's Twitter saga
49:56 Anthony's sassy notes on the topic
51:06 Linus on bots in Twitter, neither are interested
53:34 Elon Musk on "initiate and execute lawsuits"
53:58 Tesla releases service & cables manuals
54:47 Linus's iconic clapping
56:44 Merch Messages #1
56:53 Decent priced keyboard with swappable switches
59:00 Keeping in touch with former LMG employees
1:02:06 Anxiety in front of camera or crowds
1:06:04 Game items compared to movies
1:17:33 Topic #4 - Microsoft patent for verifying media
1:18:18 Explaining the patent
1:20:08 Nintendo attempts to sponsor, Linus's response
1:26:11 Topic #5 - Nvidia's rumored 40xx series
1:26:44 Specifications & prices
1:27:32 AMD states their GPUs are better for performance per $$$
1:29:34 Linus & Luke on better encoders
1:30:24 Merch Messages #2
1:30:30 Taking care of your beard
1:32:00 Issue with shipping constellation
1:32:40 Lord and Savior Cthulhu
1:33:06 Games Linus plays with his kids
1:34:28 Ideas they wanted to do but couldn't justify
1:36:55 Outro


# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## The Power of DIY: This CNN Hero helps women build new lives by training them for construction careers
 - [https://www.cnn.com/2022/05/19/us/jobs-women-north-carolina-construction-cnnheroes/index.html](https://www.cnn.com/2022/05/19/us/jobs-women-north-carolina-construction-cnnheroes/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-05-20 00:43:47+00:00

There's a flurry of construction activity outside Luvinia Williams' one-story home in Chapel Hill, North Carolina.


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 NEW Graphically INSANE Levels Created In UNREAL ENGINE 5 [4K]
 - [https://www.youtube.com/watch?v=D3750YZYeRo](https://www.youtube.com/watch?v=D3750YZYeRo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-05-21 00:00:00+00:00

Fans and developers are already creating some really cool stuff with Unreal Engine 5. Here are some awesome examples that we found. Check them out!
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


#10
https://www.youtube.com/watch?v=Bq-KRlpeFP0&ab_channel=SaherTarek
https://www.youtube.com/watch?v=hZvbPNtfzHY&ab_channel=SaherTarek
https://www.youtube.com/watch?v=k3H4oRr1IU0&ab_channel=SaherTarek
https://www.youtube.com/watch?v=mCbeIowj5cU&ab_channel=SaherTarek


#9

https://www.youtube.com/watch?v=Z1IsQQ9gFpY&ab_channel=Sciontidesign

#8
https://www.youtube.com/watch?v=dYPvLCPHvoY&ab_channel=AXCEL


#7
https://www.youtube.com/watch?v=2paNFnw1wRs&ab_channel=subjectn

#6
https://quixel.com/blog/2022/5/12/ninety-days-in-unreal-engine-5

#5
https://www.youtube.com/watch?v=vayFgt9_s1o&ab_channel=JakubW

#4
https://www.youtube.com/watch?v=TerxeA3zUd4&ab_channel=JustAnIdea

#3
https://www.youtube.com/watch?v=XzPK-DpoP1M&ab_channel=LeoTorres

#2
https://www.youtube.com/watch?v=6-_hJxypRNA&ab_channel=AlfDoesStuff

#1
https://www.youtube.com/watch?v=5ja2o11JGIo&ab_channel=Sciontidesign
+
https://www.youtube.com/watch?v=-A27UFH-3_w&ab_channel=Sciontidesign


BONUS

https://www.behance.net/gallery/129322355/RedDeadRemaster
https://www.youtube.com/watch?v=qbpT4NhIfFk&ab_channel=SergPedan

0:00 Intro
0:19 Number 10
1:26 Number 9 
2:29 Number 8
3:20 Number 7
4:40 Number 6
6:14 Number 5
7:09 Number 4 
8:19 Number 3
9:00 Number 2
9:42 Number 1

## TWO RED DEAD PROJECTS LEAKED? NEW AAA ACTION RPG, & MORE
 - [https://www.youtube.com/watch?v=Ax6y4D49Odg](https://www.youtube.com/watch?v=Ax6y4D49Odg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-05-20 00:00:00+00:00

Thank you Epic Desk for sponsoring this video. Click https://epicdesk.shop and to use code GAMERANX for 15% off any stock deskmat. # sponsored

Jake on Instagram: https://bit.ly/3uUh9Ot

Jake's Order 1886 video: https://youtu.be/hkZBewdoIaA


 ~~~~STORIES~~~~


Red Dead rumors
https://in.ign.com/red-dead-redemption-2/172262/news/red-dead-redemption-remake-and-rdr2-next-gen-reportedly-in-the-works

New RPG
https://www.gematsu.com/2022/05/techland-developing-aaa-open-world-fantasy-action-rpg-with-former-cd-projekt-red-staff

Zenless Zone Zero
https://youtu.be/C5WS9Ohb-fI


Greedfall 2 (2024)
https://www.gameinformer.com/2022/05/18/greedfall-2-the-dying-world-sets-sail-in-2024

PS Plus games announced 
https://blog.playstation.com/2022/05/16/all-new-playstation-plus-game-lineup-assassins-creed-valhalla-demons-souls-ghost-of-tsushima-directors-cut-nba-2k22-and-more-join-the-service/

Mafia 4 rumors
https://thegamespoof.com/gaming-news/mafia-4-will-be-set-in-sicily-following-the-story-of-don-salieri-rumor/

Last of Us remake: https://www.gamespot.com/articles/the-last-of-us-remake-will-reportedly-launch-this-holiday-season/1100-6503622/


Tony Hawk in Red Bull skate video 
https://youtu.be/0aIiS7BfLWI

The Valiant 
https://youtu.be/xSdX0VNihr8

Arma reforger
https://youtu.be/J8htu5b_Y30

The Chant trailer
https://youtu.be/8-_F8lx4rfw



Witcher update
https://www.engadget.com/the-witcher-3-current-gen-release-date-ps5-xbox-series-x-s-163131559.html


Death Stranding 2
https://twitter.com/nibellion/status/1527653916393058304?s=21


# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Moja kariera nagle się spłaszczyła do takiego: Szarik, do nogi!"
 - [https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-19,S00E19,775253?source=rss](https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-19,S00E19,775253?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-05-20 06:33:46+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-asx1od-janusz-gajos-u-moniki-olejnik-5718074/alternates/LANDSCAPE_1280" />
    Janusz Gajos w rozmowie z Moniką Olejnik.


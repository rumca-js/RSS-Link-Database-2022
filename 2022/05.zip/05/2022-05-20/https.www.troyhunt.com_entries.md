## Troy Hunt: Downloading Pwned Passwords Hashes with the HIBP Downloader
 - [https://www.troyhunt.com/downloading-pwned-passwords-hashes-with-the-hibp-downloader/](https://www.troyhunt.com/downloading-pwned-passwords-hashes-with-the-hibp-downloader/)
 - RSS feed: https://www.troyhunt.com
 - date published: 2022-05-20 06:58:39.859097+00:00

Just before Christmas, the promise to launch a fully open source Pwned Passwords fed with a firehose of fresh data from the FBI and NCA finally came true. We pushed out the code, published the blog post, dusted ourselves off and that was that. Kind of - there was just


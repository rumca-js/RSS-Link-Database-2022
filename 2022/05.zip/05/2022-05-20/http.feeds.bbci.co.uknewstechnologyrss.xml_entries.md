# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## WhatsApp to launch customer-business chat feature
 - [https://www.bbc.co.uk/news/technology-61522053?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-61522053?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-05-20 16:24:41+00:00

Cloud-based software will offer more personalised business using the popular messaging app.

## Canada to ban China's Huawei and ZTE from its 5G networks
 - [https://www.bbc.co.uk/news/business-61517729?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61517729?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-05-20 11:45:35+00:00

The UK, US, Australia and New Zealand have also barred the Chinese telecoms equipment makers.


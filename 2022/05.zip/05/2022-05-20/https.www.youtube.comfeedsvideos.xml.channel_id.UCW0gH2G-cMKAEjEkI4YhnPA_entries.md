# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Fell Beasts of the Nazgûl | Tolkien Explained
 - [https://www.youtube.com/watch?v=POZMO5rTBvM](https://www.youtube.com/watch?v=POZMO5rTBvM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-05-21 00:00:00+00:00

The Fell Beasts of the Nazgûl debut in the War of the Ring and along with their masters, they bring terror from the skies.  Today, we go through their travels, actions, and their origin that Tolkien theorized.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri
Noe Leyva - https://twitter.com/NoeLeyvArt

Nazgul fell beast - Jerry Vanderstelt
Wraiths on Wings - Noe Leyva
A Shot in the Dark - Ralph Damiani
The Nazgul - Ted Nasmith
Frodo and Nazgul - John Howe
Sauron - Shadow of War
Morgoth Summons the Winged Dragons - Kip Rasmussen
Fell Beast - Elrodimus Flash
Black Knight Nazgul - Ivan Cavini
At the Ford - Ted Nasmith
The Dark Tower - John Howe
The Passage of the Marshes - Kuliszu
Legolas - Andrea Piparo
Legolas Shoots t he Fell Beast - Anke Eissmann
Orcs - Aegeri
Uruk-hai - John Howe
Nightwatch - Anke Eissmann
At Sammath Naur - Olanda Fong-Surdenas
Fell Beast at Barad-dur
Uruk-Warrior and Orc-Tracker - Alan Lee
Ugluk - John Howe
Misty Mountains Orc - Olanda Fong-Surdenas
Misty Mountain Orc - Olanda Fong-Surdenas
Eowyn and the Nazgul - Ted Nasmith
Grond - John Howe
Gandalf - Skullb*st*rd
Nazgul in Flight - John Howe
The Fell Beast of Mordor - Matej Cadil
You Fool No Man Can Kill Me, Die Now - Bembiann
Barad-dur and the Lord of the Nazgul - Donato Giancola
Through the Marshes - Ted Nasmith
Nazgul above the dead marshes - Catherine Karina Chmiel
The passage of the Marshes - Kuliszu
Barad-dur - John Howe
Gollum - Jemima Catlin
The Taming of Gollum - Darrell Sweet
Apparitions - Ted Nasmith
Hobbits and Gollum - Andrea Piparo
Gollum - Steve Airola
Gollum - John Howe
Mordor Carrion Seeker - Olanda Fong-Surdenas
The Charge of the Rohirrim at Helm's Deep - John Howe
Isengard - Ivan Cavini
Nazgul over Minas Morgul - Alan Lee
Orthanc in the Second Age - Ted Nasmith
Thunder - Aegeri
Rohirrim - Donato Giancola
The House of Eorl, Freawine - Aegeri
The Nazgul Attack - Anke Eissmann
Gandalf and Shadowfax - Anke Eissmann
Nazgul at the Walls - Ted Nasmith
Nazgul in Flight - John Howe
Minas Tirith at Dawn - Ted Nasmith
Wild Fell Beast - Angus McBride
Sam Tames the Fellbeast - Olanda Fong-Surdenas
Theoden's Bane - John Howe
Shadow of the East - Ivan Cavini
Eowyn and Witch King - Alan Lee
Sunset - Felix Englund
Angband - Skullb*st*rd
The Dark Tower - John Howe
The Death of Theoden - JG Jones
Eowyn and the Nazgul - Matthew Stewart
Eowyn and Witch King - Chris Rahn
Eowyn and Witch King - Angus McBride
Eowyn and Nazgul - John Howe
Eowyn and the Lord of the Nazgul - Donato Giancola
Eowyn vs Witch King - Elrodimus Flash
Barad-dur - John Howe
Nazgul over Minas Morgul - Alan Lee
The Nazgul - Ted Nasmith
Eowyn and the Lord of the Nazgul - Ted Nasmith
Battle of the Black Gate - Ted Nasmith
Eagle Attacks Dragon at the War of Wrath - Kip Rasmussen
Barad-dur - Shadow of War
Frodo - Jenny Dolfen
At the Cracks of Doom - Ted Nasmith
A Sudden Call to Mount Doom - Ted Nasmith
Frodo and Nazgul - John Howe
Ancalagon the Black - CK Goksoy

#tolkien #lordoftherings #nazgul


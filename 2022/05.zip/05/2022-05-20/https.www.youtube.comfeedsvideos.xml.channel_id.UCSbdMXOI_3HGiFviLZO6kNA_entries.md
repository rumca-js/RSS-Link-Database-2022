# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Things NOT to do to your VR Headset
 - [https://www.youtube.com/watch?v=mgx4J6sJm4I](https://www.youtube.com/watch?v=mgx4J6sJm4I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-05-21 00:00:00+00:00

Hello, here are some things NOT to do to your VR headset.

From the sun, scratched lenses, and keeping people safe in their playspace- there are lots of ways you can have a potentially bad experience in VR. Watch this video to make sure you are aware of them and continue to have a GREAT VR experience. These tips apply whether you have a Quest 2, Quest 7, Rift, Index, Vive, Oculus Go.. doesn't matter. Hope you enjoy!

My links: 
Outro Music:
https://www.youtube.com/watch?v=u6Jwg...

My links:
Discord:
https://discord.gg/2hCGM9BYez
Twitch:
https://www.twitch.tv/thrilluwu
Twitter:
https://twitter.com/Thrilluwu
Patreon:
https://www.patreon.com/Thrillseeker


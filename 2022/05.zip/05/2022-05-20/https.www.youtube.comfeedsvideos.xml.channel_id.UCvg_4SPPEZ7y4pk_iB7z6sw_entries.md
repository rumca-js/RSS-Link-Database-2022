# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## Google Cardboard Games Are Awful
 - [https://www.youtube.com/watch?v=IklU_yf68m8](https://www.youtube.com/watch?v=IklU_yf68m8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2022-05-21 00:00:00+00:00

Turns out burning rotten cardboard smells bad. Stays around with ya too. Still not nearly as annoying as using this piece of trash. 

Don’t know why I subjected myself to this for a whole month. Never again. Hopefully. Probably. Let’s see how this one does first.

You can watch my OG vid on the topic here;
https://www.youtube.com/watch?v=ujoXWLc0784

Soundcloud:
https://soundcloud.com/user-503704039

Various Video Credits.
FamilyGuyFanatic800
TEDxAmsterdam
dorek9999
MaskedMetaKnight4
Adam Savage’s Tested


# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## These Chinese chips could save Russia
 - [https://www.youtube.com/watch?v=pfgA0K4bt6o](https://www.youtube.com/watch?v=pfgA0K4bt6o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-05-20 00:00:00+00:00

Visit https://brilliant.org/TFC/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription - Sponsored by Brilliant.
 
 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► This video ◄◄◄  
 
This week Tesla and other devices with Bluetooth Low Energy (BLE) got a nasty hack, Free-to-play games like PUBG and Fall Guys took over, and Russia got new x86 chips from China in the form of Zhaoxin, on motherboards from Dannie.
 
Episode 97
 
This video on Nebula: https://nebula.app/videos/the-friday-checkout-this-chip-is-supposed-to-save-russia
 
 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► TechAltar links ◄◄◄  
 
Merch:  
http://enthusiast.store   
 
Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  
 
If you want to support my work directly:  https://flattr.com/@techaltar   
 
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 
►►► Attributions & Time stamps◄◄◄
 
Music by Edemski: https://soundcloud.com/edemski 
 
0:00 Intro
0:23 Release highlights
2:40 Big Bluetooth hack
4:42 Free-to-play games take over
6:21 Russia gets Chinese chips


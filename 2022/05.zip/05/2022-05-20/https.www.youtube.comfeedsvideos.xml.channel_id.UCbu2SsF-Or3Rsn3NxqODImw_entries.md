# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## "A Weird G36!" - Firearms Expert Reacts To MORE Ready Or Not Guns
 - [https://www.youtube.com/watch?v=jK1Z7YmY_5E](https://www.youtube.com/watch?v=jK1Z7YmY_5E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-21 00:00:00+00:00

Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down more of the weaponry of Ready or Not, including the beanbag shotgun, the G36 and the UMP-45.

00:00 - Opening
00:47 - Beanbag Shotgun
04:06 - P92X
08:30 - G36C
11:19 - UMP-45
15:06 - M4 Super 90
17:07 - Ending

In the latest video in the Firearm Expert Reacts series, Jonathan Ferguson--a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries--breaks down more of the guns of Ready or Not and compares them to their potential real-life counterparts.

Firearms Expert Reacts playlist - https://www.youtube.com/watch?v=y4T78VQoWUs&list=PLpg6WLs8kxGMgYb13XjPgOKbm5O-CDq7R

If you're interested in seeing more of Jonathan's work, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArmouries

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/

And if you would like to become a member of the Royal Armouries, you can get a membership here. - https://royalarmouries.org/support-us/membership/

You can either purchase Jonathan's book here. - https://www.headstamppublishing.com/bullpup-rifle-book

Or at the Royal Armouries shop here. - https://shop.royalarmouries.org/collections/thorneycroft-to-sa80-british-bullpup-firearms-1901-2020

You can subscribe to the Armax Journal that Jonathan Associate Edited here: https://www.armaxjournal.org/

## Elden Ring Lore - Starscourge Radahn
 - [https://www.youtube.com/watch?v=ONoyJME6j_o](https://www.youtube.com/watch?v=ONoyJME6j_o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-20 00:00:00+00:00

One of Elden Ring's most notorious and mightiest demigods is Radahn - known throughout the land as General Radahn and Starscourge Radahn. Radahn was born of Rennala and Radagon, and shares the demigod siblings of Ranni and Rykard. However, he would stand out as one of Elden Ring and the Lands Between's Greatest Warriors, even rivaling the strength of Malenia, Blade of Miquella. So, let's dive into Radahn's past, where he came from, and what would happen to him during The Shattering. #EldenRing #Gaming #GameSpot

Radahn was born of two separate houses. His mother was Rennala of Carian Royalty and the master of the Academy of Raya Lucaria - giving him an association with intelligence and sorcery. Meanwhile, his father was Radagon - who was a champion of the Erdtree and the Golden Order, with an association to incantations and faith.

Radagon had flowing red hair that Radahn would inherit.

“Every giant is red of hair, and Radagon was said to have despised his own red locks. Perhaps that was a curse of their kind.” However, while Radagon seemed to compare this to the giants - who fought against the Golden Order and Erdtree - and therefore saw it as a negative, Radahn viewed this as a positive thing:

“Radahn inherited the furious, flaming red hair of his father Radagon, and is fond of its heroic implications.

“I was born a champion’s cub. Now I am the Lord of the Battlefield’s lion.””

## Evil Dead: The Game Review
 - [https://www.youtube.com/watch?v=1lkOVUmWqAo](https://www.youtube.com/watch?v=1lkOVUmWqAo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-20 00:00:00+00:00

Evil Dead: The Game doesn't stray far from this foundational premise.

Evil Dead: The Game smartly leans on its B-movie hijinx to give fans of the genre something worthy of being in their horror game rotation, even as it doesn't have the soul to swallow all of their time singlehandedly.

Evil Dead: The Game is available on PlayStation 4, Nintendo Switch, Xbox One, PlayStation 5, Xbox Series X and Series S, and Microsoft Windows. You can read the full written review by Mark Delaney on GameSpot: https://www.gamespot.com/reviews/evil-dead-the-game-review-somewhat-groovy/1900-6417881/

#Gaming #EvilDeadGameReview #AshvsEvilDeadGameReview #EvilDeadGameTheTrailer

## Sniper Elite 5 First 19 Minutes Of Gameplay
 - [https://www.youtube.com/watch?v=BPDwOXO2oN8](https://www.youtube.com/watch?v=BPDwOXO2oN8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-20 00:00:00+00:00

Sniper Elite 5 levels are made for multiple playthroughs. Let's look at how the X-Ray camera shines as we run and gun the Atlantic Wall opening level with our customized M 1911, SREM-1 sniper rifle, and Welgun SMG. In this clip, we also find a prototype night fighting MP 44, detonate some explosive barrels, and prove melee takedowns are powerful. 

Sniper Elite 5 continues the series World War Two sniping sandbox with an expanded open area Hitman-style level design, tons of weapon customization, character upgrades, and a plot to stop secret Nazi plans. The game takes place around D-Day, with the first few missions seeing Karl Fairburne deploying by submarine to knock out guns ahead of the Allied invasion before uncovering a deeper Nazi plot called Project Kraken. Developers at Rebellion want to accommodate a wide variety of playstyles which they broke into stealth, control, power, and speed. Around that idea, the Atlantic Wall map has many different routes, from open fields to trenches to underground bunkers. There is more than one way to knock out the artillery around the map and disable a massive radar array. This was our second run of the area, and you will see us start in a later part of the mission that became unlocked and also sport a customized M 1911 with a wood stock, scope, and suppressor.  

Sniper Elite 5 releases on May 26th on all major platforms, including PlayStation 4, PS5, Xbox Series X|S, and PC. It is both single-player, co-op, and multiplayer, also including player invasions of the campaign. #Gaming #SniperElite #GameSpot

## Warzone 2 Details Leak | GameSpot News
 - [https://www.youtube.com/watch?v=P-gLXPL0agg](https://www.youtube.com/watch?v=P-gLXPL0agg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-20 00:00:00+00:00

New Call of Duty: Warzone 2 details leak, Norman Reedus reveals, Death Stranding 2 is in development and Skyrim’s Anniversary Edition may be coming to Switch. 
#GamingNews #COD #Warzone

According to a new report from Exputer, Warzone 2 – or whatever it will be called – will include an "interrogation" feature similar to Rainbow Six Siege. Warzone 2 is expected to be released in 2023, following the launch of Call of Duty: Modern Warfare 2 this year. While Activision has announced the next Warzone and Modern Warfare 2, the publisher has yet to fully reveal both titles.

Actor Norman Reedus has revealed that development has begun on Death Stranding 2. The game has not been announced, but Reedus plainly told Leo Edit that, "We just started the second one." Death Stranding sold more than 5 million copies before the launch of the director's cut, so it sure seems that the game was a hit. Sony published the PS4 and PS5 edition, with 505 Games handling the PC release in 2020.

The game's Anniversary Edition, released in 2021 for PlayStation, Xbox, and PC to celebrate the game's 10th anniversary, is now reportedly headed to Switch next. The Skyrim Anniversary Edition includes the base game, all DLC and mods, and a new fishing system, among other things.

STAMPS
00:00 - Intro
00:08 - Warzone 2
01:40 - Death Stranding 2
02:29 - Skyrim on Switch


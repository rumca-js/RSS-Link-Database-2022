# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Kto dostarcza kości do muzeów?
 - [https://www.youtube.com/watch?v=OnyaLhlZP6k](https://www.youtube.com/watch?v=OnyaLhlZP6k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2022-05-20 00:00:00+00:00

Zgłoszenia z listem motywacyjnym, danymi kontaktowymi i preferencjami terminowymi można przesyłać do 31 maja (2022) na adres e-mail (lczepinski@biol.uw.edu.pl) lub przez formularz online: https://forms.gle/nCr7uZ54ER9RG9hZ7

Najbardziej aktualną stroną dotyczącą tegorocznych wykopalisk jest wydarzenie na Facebook:
https://www.facebook.com/events/424963832744819

Dodatkowe informacje na oficjalnej stronie Instytutu Paleobiologii PAN:
https://www.paleo.pan.pl/pl/wyprawy_naukowe.html

📚  Nasza edukacyjna książka dla dzieci
► https://naukowybelkot.pl/product/lelony-odkrywaja-dlaczego-niebo-jest-niebieskie

👉  Patronite ► https://patronite.pl/NaukowyBelkot 

📚  Moja książka ► https://altenberg.pl/geny/
📚  E-book ► https://tinyurl.com/pnp-ebook
🎧  Mix audio ► http://ratstudios.pl/

===
Podobne filmy:
► https://www.youtube.com/watch?v=qPVw0CR_oa8
► https://www.youtube.com/watch?v=Fj_Cr7fbS8c
► https://www.youtube.com/watch?v=MbTx08Zry_8
► https://www.youtube.com/watch?v=JkTYcFEmbes
► https://www.youtube.com/watch?v=TLj1D-gA50s

===
0:00 Żar Miedar
0:46 Miedar historia
3:47 Krokodyl, który połknął wędkę
11:08 Tak się wyciąga kręg
12:36 Miedar unikatowość
14:39 Gady enigmatyczne
16:10 Uzębione żebro
19:21 Jak szukać, żeby znaleźć
22:51 Dla kogo te wykopaliska


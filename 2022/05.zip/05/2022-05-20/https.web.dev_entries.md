## GOV.UK drops jQuery from their front end.
 - [https://web.dev/gov-uk-drops-jquery/](https://web.dev/gov-uk-drops-jquery/)
 - RSS feed: https://web.dev
 - date published: 2022-05-20 07:09:31+00:00

GOV.UK dropped their jQuery dependency from their front end. You'll never guess what happened. (Yes, you will.)


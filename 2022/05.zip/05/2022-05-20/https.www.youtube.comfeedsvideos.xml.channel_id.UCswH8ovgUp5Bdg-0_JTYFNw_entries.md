# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## This Changes Everything
 - [https://www.youtube.com/watch?v=Oo7kfZ7DywA](https://www.youtube.com/watch?v=Oo7kfZ7DywA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-05-21 00:00:00+00:00

At the World Health Assembly next week, the WHO will meet to discuss a “pandemic accord” that would greatly expand its powers. Nothing to worry about there. #WHO #WorldHealthOrganization #Pandemic 

Sign The Petition Here: https://petition.parliament.uk/petitions/614335

References
https://www.telegraph.co.uk/news/2022/05/14/pandemic-pact-would-leave-world-chinas-mercy/

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Psaki Sellout
 - [https://www.youtube.com/watch?v=WD7l3f9vp44](https://www.youtube.com/watch?v=WD7l3f9vp44)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-05-20 00:00:00+00:00

Your favourite Jen Psaki finished her last day as Joe Biden's press secretary this week before becoming an MSNBC pundit. As the latest in a long line of Democratic presidential flacks who have become corporate lackeys and mouthpieces, how can we have any faith in this insane system? 
#JenPsaki #MSNBC #MainstreamMedia

References
https://www.jacobinmag.com/2022/05/jen-psaki-press-secretary-msnbc-corporate-lobbying

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


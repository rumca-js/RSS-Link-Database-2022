# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Interview with a real hacker: "There is no making it secure!"
 - [https://www.youtube.com/watch?v=C17iJ2iOquc](https://www.youtube.com/watch?v=C17iJ2iOquc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2022-05-23 18:51:31+00:00

This was the most important talk I have ever had. A real life hacker reveals the deeply flawed state of cybersecurity.
Support independent research and analysis by joining my Patreon page: https://www.patreon.com/thehatedone 

Timestamps:

00:00:52 Who the hackerman is

00:10:30 He can do some damage & code of ethics

00:14:18 Why did you choose to be a white hat hacker 19 - things are bad

00:23:34 People wouldn't want to use computers if they realized how insecure they are 25:25 there is no making it secure

00:30:30 There is no incentive for security

00:36:55 Nobody is listening to security teams

00:45:29 Security experts are frustrated

00:51:00 Government security is probably even worse

00:58:05 No one is taking this seriously until something very bad happens

01:21:20 Is cyber Bombing in Mr Robot possible?

01:26:17 Privacy is important to security

01:38:00 We need to change how we advocate for privacy - teach about abuse, not vulnerabilities

01:48:10 Is forcing interopearability a good solution?

02:02:40 We need mathematicians 

02:08:45 Citizens should fight for more privacy and security

02:13:45 There is no single solution

02:16:33 Mobile security vs desktop security

02:26:45 Informed consent

02:32:48 Case for optimism

02:47:00 Estonia's e-government project

03:08:00 We need more ethical hackers to come out

03:16:25 Snowden is our inspiration

03:25:30 Hackerman will return

Follow me:
https://twitter.com/The_HatedOne_
https://www.reddit.com/r/thehatedone/

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Chris DiStefano's Story of Being Expelled From School on 9/11
 - [https://www.youtube.com/watch?v=HOUkcInyxN0](https://www.youtube.com/watch?v=HOUkcInyxN0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-05-24 00:00:00+00:00

Taken from JRE #1822 w/Chris DiStefano:
https://open.spotify.com/episode/4aHNV3NVs4i0PT3ujMvfrT?si=9a361296fe864047

## John Travolta Helped Chris DiStefano with His Letterman Appearance
 - [https://www.youtube.com/watch?v=lsX9PoS1_Qg](https://www.youtube.com/watch?v=lsX9PoS1_Qg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-05-24 00:00:00+00:00

Taken from JRE #1822 w/Chris DiStefano:
https://open.spotify.com/episode/4aHNV3NVs4i0PT3ujMvfrT?si=9a361296fe864047


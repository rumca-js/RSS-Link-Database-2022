# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## CAN FANTASY BE CHILL? - Legends and Lattes!
 - [https://www.youtube.com/watch?v=KpYj8G2IawM](https://www.youtube.com/watch?v=KpYj8G2IawM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-05-24 00:00:00+00:00

My thoughts on the chill fantasy book, Legends and Lattes! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 premise/positives

05:03 negatives

06:30 Concluding thoughts


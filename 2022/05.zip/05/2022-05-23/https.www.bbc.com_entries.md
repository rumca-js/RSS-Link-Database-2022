## Boris Johnson pictured drinking at No 10 lockdown event - BBC News
 - [https://www.bbc.com/news/uk-politics-61557064](https://www.bbc.com/news/uk-politics-61557064)
 - RSS feed: https://www.bbc.com
 - date published: 2022-05-23 09:04:27+00:00

Boris Johnson pictured drinking at No 10 lockdown event - BBC News


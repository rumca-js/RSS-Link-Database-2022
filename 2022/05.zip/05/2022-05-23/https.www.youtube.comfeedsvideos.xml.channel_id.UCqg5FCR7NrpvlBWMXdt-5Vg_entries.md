# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Greak: Memories of Azur | Hidden Gems with KC and Jesse
 - [https://www.youtube.com/watch?v=m7zA4EvDnx8](https://www.youtube.com/watch?v=m7zA4EvDnx8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-05-24 00:00:00+00:00

Each week KC and Jesse check out an overlooked game and decide if it's worth your time or not over the course of 2 hours. This week, we're checking out Greak: Memories of Azur.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Stop Stealing From Dark Souls, Start Stealing From These Games | Slightly Something Else
 - [https://www.youtube.com/watch?v=OT5MHnVFubA](https://www.youtube.com/watch?v=OT5MHnVFubA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-05-23 00:00:00+00:00

This week on Slightly Something Else, Yahtzee and Marty discuss a games that have mechanics that more games should steal from.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


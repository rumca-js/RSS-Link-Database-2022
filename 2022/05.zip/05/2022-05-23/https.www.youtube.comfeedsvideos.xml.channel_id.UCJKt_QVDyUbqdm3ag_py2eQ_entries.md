# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## IT music: Little Bitchard - Skip to Be Square (AWE64 Gold)
 - [https://www.youtube.com/watch?v=xKfl_BVhJ20](https://www.youtube.com/watch?v=xKfl_BVhJ20)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-05-24 00:00:00+00:00

"Skip to Be Square" by Little Bitchard (Arto Koivisto), 4th at Revision 2014. Art "Whargoul" (1997) by Razorback/Tulou, 1st at Hackerence 16.

- Retro PC circa 2002. MS-DOS 7.1 (Win98SE), Athlon XP 2200+ etc.
- Impulse Tracker 2.14v5 and AWE64 Gold CT4390 (as SB16) analog out
- Maxed out channels (/L256)
- 32-bit interpolation and 45454 mixing rate, filter and feedback disabled
- MIXERSET.EXE treble and bass in neutral position (no fade or boost)

## XM music: Radix & Lluvia - Colours (AWE64 Gold)
 - [https://www.youtube.com/watch?v=-3OeBoogkqw](https://www.youtube.com/watch?v=-3OeBoogkqw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-05-24 00:00:00+00:00

"Colours" (2000) by Radix & Lluvia/Level-d. Art "Flying Freedom" by Leon/Singular Crew, 6th at Revision 2022.

8bitbubsy's bugfixed Fasttracker versions:
https://16-bits.org/other.php

- Retro PC circa 2002. MS-DOS 7.1 (Win98SE), Athlon XP 2200+ etc.
- 8bitbubsy's Fasttracker 2.11 and AWE64 Gold CT4390 analog out
- 16-bit with interpolation and 44100 (45454) mixing rate
- MIXERSET.EXE treble and bass in neutral position (no fade or boost)


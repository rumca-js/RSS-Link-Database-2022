# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Video Games Secrets THAT WERE NEVER FOUND
 - [https://www.youtube.com/watch?v=oJyBEMY4gU4](https://www.youtube.com/watch?v=oJyBEMY4gU4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-05-24 00:00:00+00:00

Some video game secrets go undiscovered for years and are only found when the game makers point players in the right direction.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:42 Number 10
1:34 Number 9 
2:49 Number 8
3:40 Number 7
4:43 Number 6
5:43 Number 5
7:02 Number 4 
7:59 Number 3
8:58 Number 2
10:06 Number 1

## 10 Video Game Cutscenes You CAN ACTUALLY BREAK
 - [https://www.youtube.com/watch?v=ryLJo3O_c5s](https://www.youtube.com/watch?v=ryLJo3O_c5s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-05-23 00:00:00+00:00

Some game stories and moments can be changed in surprising ways. Here are some of our favorite deep-cut examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:13 Number 10
1:08 Number 9 
2:16 Number 8
3:34 Number 7
4:54 Number 6
6:19 Number 5
7:23 Number 4 
8:26 Number 3
9:41 Number 2
10:42 Number 1


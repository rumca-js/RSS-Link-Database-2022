## Grubhub's NYC Free Lunch Promo Didn't Go Smoothly
 - [https://www.buzzfeednews.com/article/kelseyweekman/grubhub-free-lunch-nyc-promo-chaos](https://www.buzzfeednews.com/article/kelseyweekman/grubhub-free-lunch-nyc-promo-chaos)
 - RSS feed: https://www.buzzfeednews.com
 - date published: 2022-05-23 15:42:16.541259+00:00

One unhappy customer was 3,630th in line to talk to Grubhub's customer service about his missing order when he gave up.


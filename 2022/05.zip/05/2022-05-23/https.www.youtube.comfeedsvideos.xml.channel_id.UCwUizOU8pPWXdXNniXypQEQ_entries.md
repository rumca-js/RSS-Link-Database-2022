# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Grandfathers vs Their Woke Offspring
 - [https://www.youtube.com/watch?v=OP1vosHA1jE](https://www.youtube.com/watch?v=OP1vosHA1jE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-05-24 00:00:00+00:00

Grab your EMF Blocking Products at https://blublox.com/jp
Use Code "JP" for 15% Off!

Check Out My Merch Here - https://awakenwithjp.com

See my LIVE Comedy Shows - https://awakenwithjp.com/pages/events

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Brave grandfathers vs their woke offspring...

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## LOTR: Gollum Release Date, New Images, & Lore! | Middle-earth Gaming
 - [https://www.youtube.com/watch?v=8r0sz0KPf64](https://www.youtube.com/watch?v=8r0sz0KPf64)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-05-24 00:00:00+00:00

Last week, I got a sneak peek at the Gollum game at a virtual event by Daedalic Entertainment.  While the gameplay footage was still in a rough beta stage, we were given a sense for the stealth platformer techniques, saw some new images, spoke with the developers, and - most exciting - we were able to learn and ask questions about the LORE behind the game.

00:00-00:21 Intro
00:21-00:33 Release Date
00:33-00:51 Why Gollum?
00:51-01:39 Gollum vs Smeagol
01:39-02:10 Fighting
02:10-02:38 Gollum's Appearance
02:38-02:56 LORE
02:56-03:29 Timeline
03:29-03:56 Flashback/Flashforward
03:56-04:27 Gollum's Past
04:27-05:25 Cameos
05:25-06:01 Original Character(s)
06:01-6:50 Getting Around
06:50-07:16 Game Locations
07:16-08:13 Final Thoughts (part 1)
08:13-08:53 Omission: Visuals
08:53-09:51 Final Thoughts (part 2)

#gollumgame #gollum #lordoftherings


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Tim Pool: This Is Psychological Warfare
 - [https://www.youtube.com/watch?v=2G5WdtLQT64](https://www.youtube.com/watch?v=2G5WdtLQT64)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-05-24 00:00:00+00:00

This is a conversation I had with American YouTuber and political commentator, Tim Pool. We talked about the future of politics and the use of psychological operations and propaganda manipulation to win wars in the 21st century. #TimPool #Psychological #War

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## This Is A F*cking Disgrace
 - [https://www.youtube.com/watch?v=HIkFInjUTIk](https://www.youtube.com/watch?v=HIkFInjUTIk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-05-23 00:00:00+00:00

As parents across the US struggle with the nationwide formula shortage, criticism has been levelled at Joe Biden for providing formula to detained migrant children – but is that really what we should be focussing on, or is the government’s relationship with Big Pharma the real culprit? #BabyFormula #BigPharma #Shortages 

References
https://www.macrotrends.net/
https://www.pharmaceuticalintegritycoalition.org/
https://www.theguardian.com/commentisfree/2022/feb/08/big-pharma-global-vaccine-rollout-covid-pfizer
https://www.theguardian.com/us-news/2022/may/16/abbott-restart-production-baby-formula-shortage
https://www.bloomberg.com/news/articles/2022-05-12/inspectors-saw-bacteria-risk-at-abbott-formula-factory-last-year

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


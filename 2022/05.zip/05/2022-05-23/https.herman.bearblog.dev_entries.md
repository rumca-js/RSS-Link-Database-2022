## Big Fat Websites | ᕕ( ᐛ )ᕗ Herman's blog
 - [https://herman.bearblog.dev/big-fat-websites/](https://herman.bearblog.dev/big-fat-websites/)
 - RSS feed: https://herman.bearblog.dev
 - date published: 2022-05-23 14:06:01.485706+00:00

Websites should be clean and fast.


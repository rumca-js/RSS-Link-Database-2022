# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Świętokrzyskie - rowerem przez stepy, góry i jeziora. Jedziemy trasę z książki "Rower to jest Świat"
 - [https://www.youtube.com/watch?v=xAQiyXm5r-g](https://www.youtube.com/watch?v=xAQiyXm5r-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2022-05-23 14:28:35+00:00

Książka 📙👉 https://rowertojestswiat.pl/

Cześć! Dziś zapraszamy w województwo Świętokrzyskie, któremu powinno zmienić się nazwę na ŚwietnoKrzyskie, bo jest tutaj taka masa świetnych widoków, ciekawych i mało znanych atrakcji, a przede wszystkim niesłychanie klimatycznych miejsc, że nie mogę wręcz uwierzyć, iż jest to jedno z najczęściej pomijanych regonów w Polsce.

Przejedziemy sobie trasę rowerową z książki "Rower to jest świat" startując w okolicach Kielc, następnie kierując się w stronę zamku Chęciny, Krzyżtopór, pomniejsze ciekawe miejscowości jak Szydłów czy Busko Zdrój i wrócimy genialnym Ponidziem.
 


Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Rozdziały: 
00:00 - Świętokrzyskie - ciekawe miejsca
00:46 - Gdzie leży Świętokrzyskie?
02:01 - skansen w Tokarni, Zamek Chęciny
02:52 - Góry Świętokrzyskie
03:55 - Zalew Borków, 
04:13 - Jezioro Chańcza
06:02 - Krzyżtopór
08:00 - o rzepaku słów kilka
08:19 - Kurozwęki
08:55 - Szydłów
10:04 - Busko-Zdrój
10:41 - drzewo... na szczudłach
11:50 - Ponidzie
12:39 - rzeka Nida - ciekawostki
16:36 - Zamek w Sobkowie


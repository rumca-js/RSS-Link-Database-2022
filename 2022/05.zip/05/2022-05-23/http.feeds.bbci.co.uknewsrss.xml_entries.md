# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Cryptocrash: ‘I was arrested for knocking on Luna boss's door'
 - [https://www.bbc.co.uk/news/technology-61552030?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-61552030?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 23:59:26+00:00

A man says he lost millions, and then was arrested for trying to talk to crypto boss Do Kwon.

## Love Island's eBay styling could change second-hand buying habits
 - [https://www.bbc.co.uk/news/business-61478777?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61478777?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 23:06:15+00:00

Fans of the show could buy more second-hand after seeing stars in eBay outfits, fashion experts say.

## From Afghanistan's finance minister to cab driver in the US
 - [https://www.bbc.co.uk/news/world-us-canada-61530544?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-61530544?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 23:03:54+00:00

Now a taxi driver in Washington DC, Khalid Payenda once oversaw a multi-billion dollar budget.

## Spaghetti Junction at 50: The father and son keeping it safe
 - [https://www.bbc.co.uk/news/uk-england-birmingham-61551588?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-61551588?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 23:02:02+00:00

The Birmingham junction, officially named Gravelly Hill Interchange, opened to drivers in May 1972.

## Nazanin Zaghari-Ratcliffe: Eight things we learnt from her first interview
 - [https://www.bbc.co.uk/news/uk-61557108?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61557108?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 19:43:28+00:00

Nazanin Zaghari-Ratcliffe says she was forced to sign a false confession to secure her release.

## Queen tours Chelsea Flower Show in golf buggy
 - [https://www.bbc.co.uk/news/uk-61558839?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61558839?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 18:15:48+00:00

This year's show includes Platinum Jubilee floral tributes to the monarch's 70 year reign.

## Australia election: Five people making political history
 - [https://www.bbc.co.uk/news/world-australia-61547775?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-61547775?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 17:19:30+00:00

Australia's election has ushered in political pioneers and interesting firsts across the parliament.

## Demand for Medway food aid charity 'has doubled'
 - [https://www.bbc.co.uk/news/uk-england-kent-61554986?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-61554986?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 16:31:52+00:00

A Kent charity boss says she is helping around 18,000 people access food and support.

## NHS mental health trust sets up food bank for staff
 - [https://www.bbc.co.uk/news/uk-england-norfolk-61551457?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-norfolk-61551457?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 15:45:31+00:00

Other trusts start similar initiatives over fears staff are struggling with rising prices.

## Stranger Things season four ‘formulaic but fabulous’, critics say
 - [https://www.bbc.co.uk/news/entertainment-arts-61547989?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-61547989?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 14:55:14+00:00

Season four of the retro US sci-fi show has four-star reviews and maybe its "scariest monster yet".

## ScotRail: Why have hundreds of trains been cancelled?
 - [https://www.bbc.co.uk/news/uk-scotland-61553938?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-61553938?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 13:51:26+00:00

About 700 daily services have been axed in Scotland in a dispute between unions and rail bosses.

## What is a war crime and could Putin be prosecuted over Ukraine?
 - [https://www.bbc.co.uk/news/world-60690688?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60690688?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 11:55:23+00:00

If Russia has carried out war crimes in Ukraine how could Putin or his army generals be prosecuted?

## Cannes Film Festival red carpet protest highlights murders of women
 - [https://www.bbc.co.uk/news/entertainment-arts-61550018?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-61550018?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 11:18:09+00:00

They carried a banner with the names of 129 women who have been murdered in France in the last year.

## Ukraine war: Russian assault on key Donbas city intensifies
 - [https://www.bbc.co.uk/news/world-europe-61547756?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61547756?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 10:31:00+00:00

Moscow has been accused of a "scorched earth" policy in its efforts to capture Severodonetsk.

## Cost of living: Two-child families paying £400 a month more
 - [https://www.bbc.co.uk/news/business-61501778?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61501778?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 10:12:10+00:00

The rising cost of energy, transport and childcare is forcing families to make tough choices.

## Ukraine war: Russian soldier jailed for life over war crime
 - [https://www.bbc.co.uk/news/world-europe-61549569?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61549569?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 09:58:05+00:00

A tank commander is jailed for life for killing a civilian at the first war crimes trial since the invasion.

## Birmingham Children's Hospital worker held on suspicion of poisoning child
 - [https://www.bbc.co.uk/news/uk-61547209?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61547209?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 09:51:36+00:00

The woman, 27, is suspended from Birmingham Children's Hospital after the sudden death of a child.

## Cost of living: We cannot rule out a windfall tax, says minister
 - [https://www.bbc.co.uk/news/uk-politics-61549109?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61549109?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 09:28:21+00:00

Simon Clarke will not confirm a levy on energy firms to tackle rising costs, but promises pragmatism.

## Change needed to stop thousands more kids going in to care
 - [https://www.bbc.co.uk/news/uk-61509043?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61509043?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 09:22:51+00:00

Struggling families need earlier support before they reach crisis point, warns a major review.

## Fabio Carvalho: Fulham forward to join Liverpool on 1 July
 - [https://www.bbc.co.uk/sport/football/61548369?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61548369?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 09:20:51+00:00

Liverpool sign Fabio Carvalho from Fulham with the forward set to officially join on 1 July.

## French street artist Miss. Tic dies aged 66
 - [https://www.bbc.co.uk/news/world-europe-61546420?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61546420?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 09:13:13+00:00

She is seen as one of the founders of stencil art, famous for her graffiti of female figures in Paris.

## Biden says China 'flirting with danger' over Taiwan
 - [https://www.bbc.co.uk/news/world-asia-china-61548531?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-61548531?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 09:06:02+00:00

The US leader vowed to defend Taiwan if China attacked, likening such a move to Russia's war in Ukraine.

## Aston Villa sign Boubacar Kamara from Marseille on a five-year contract
 - [https://www.bbc.co.uk/sport/football/61547623?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61547623?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 08:29:44+00:00

Aston Villa sign French midfielder Boubacar Kamara from Marseille on a five-year contract.

## Two fans charged over Manchester City pitch invasion
 - [https://www.bbc.co.uk/news/uk-england-manchester-61548625?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-61548625?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 08:08:39+00:00

Thousand of fans went on the pitch after City beat Aston Villa 3-2 to win the Premier League title.

## Carol Kirkwood: BBC weather presenter reveals engagement live on air
 - [https://www.bbc.co.uk/news/uk-61549039?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61549039?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 07:57:41+00:00

Weather presenter Carol Kirkwood is spotted with a "giant rock" on her finger as she reveals engagement.

## High-risk monkeypox contacts advised to isolate
 - [https://www.bbc.co.uk/news/uk-61546480?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61546480?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 07:22:59+00:00

Official guidance recommends quarantining for those who have had unprotected direct contact with the virus.

## Pay gap between bosses and staff expected to widen
 - [https://www.bbc.co.uk/news/business-61544250?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61544250?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 06:57:55+00:00

The High Pay Centre says pay gaps were the greatest in the retail sector in the early months of 2022.

## Cancer screening led me to invent dissolving wet wipes
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-business-61081752?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-business-61081752?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 05:28:25+00:00

Brian McCormack created dissolvable products after struggling to undertake a regular cancer check.

## Ukraine war: The defiant Russians speaking out about the war
 - [https://www.bbc.co.uk/news/world-europe-61542365?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61542365?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 05:00:49+00:00

Despite the threat of a 15-year jail term, some Russians are refusing to be silenced by the Kremlin.

## The Papers: 'Time for rescue plan, Rishi' and City comeback win
 - [https://www.bbc.co.uk/news/blogs-the-papers-61546092?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-61546092?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 04:44:24+00:00

Calls for action on the cost of living crisis and Manchester City's dramatic Premier League victory lead the papers.

## US PGA Championship: Justin Thomas beats Will Zalatoris in a play-off
 - [https://www.bbc.co.uk/sport/golf/61546229?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/61546229?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-23 00:30:01+00:00

Justin Thomas stages a remarkable fight back to beat Will Zalatoris in a play-off and win the US PGA Championship at Southern Hills.


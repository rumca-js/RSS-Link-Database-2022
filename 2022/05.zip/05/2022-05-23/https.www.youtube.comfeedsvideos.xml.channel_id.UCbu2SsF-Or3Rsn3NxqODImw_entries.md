# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Call of Duty: Modern Warfare 2 Official Release Date and Artwork Reveal Trailer
 - [https://www.youtube.com/watch?v=IreHwba6FFk](https://www.youtube.com/watch?v=IreHwba6FFk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-24 00:00:00+00:00

Get a glimpse of some of the artwork for Call of Duty: Modern Warfare II including the release date reveal for the game.

In Call of Duty: Modern Warfare II, Task Force 141 makes its massive return with a global squad of iconic veterans, these Operators include Captain John Price,  Simon “Ghost” Riley, John “Soap” MacTavish, Kyle 'Gaz' Garrick and introducing Mexican Special Forces Colonel Alejandro Vargas. 

Call of Duty: Modern Warfare II releases October 28, 2022.

#CallOfDuty #ModernWarfare2 #COD

## Destiny 2: The Witch Queen - Season of the Haunted Official Trailer
 - [https://www.youtube.com/watch?v=Xlp_Q6kV5gQ](https://www.youtube.com/watch?v=Xlp_Q6kV5gQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-24 00:00:00+00:00

Driven by an insatiable lust for power, Calus seeks the approval of a new master. His once-opulent ship, now derelict and corrupted, has returned to our galaxy—its sights set on the power promised by the Pyramid ship lying dormant on the Moon. 

As the Leviathan forms a connection with the Pyramid, Nightmares of humanity’s past awaken and threaten to torment any who dare intervene. Stare into the abyss and find bravery within the mantle of the reaper and the steel of the scythe.

#Destiny2 #SeasonoftheHaunted #Levithan #Gaming

## The Lord of the Rings: Gollum 7 Things We Learned
 - [https://www.youtube.com/watch?v=bxU3IEO56Is](https://www.youtube.com/watch?v=bxU3IEO56Is)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-24 00:00:00+00:00

The Lord of the Rings: Gollum is an upcoming stealth-action game from Daedalic Entertainment, so Lord of the Rings expert Lucy James checked out what it's all about. #Gaming #GameSpot #Gollum

Gollum: a miserable, wretched creature from the works of J.R.R. Tolkien who’s easy to hate, and just as easy to pity. After playing bit parts in Bilbo and Frodo’s journeys and all the adaptations of them, he’s now going to be the main character in his own game: The Lord of the Rings: Gollum. 

GameSpot's Lord of the Rings expert Lucy James recently attended a hands-off presentation featuring Gollum gameplay and a Q and A session with the game's developers, Daedalic. In the video above, she describes what she saw from the game, including its stealth gameplay, other recognizable characters, like Gandalf and Thranduil, as well as famous Middle-earth locations like Cirith Ungol and Mirkwood.

The Lord of the Rings: Gollum launches on September 1, 2022, for PlayStation 4, PlayStation 5, Xbox One, Xbox Series X and S, and PC. It is confirmed to be coming to Nintendo Switch later this year, but there’s no release date just yet. That's the day before the upcoming Lord of the Rings TV series, The Rings of Power, launches on Amazon Prime Video.

## PS1 Gameplay Shown On PS5 In New Video | GameSpot News
 - [https://www.youtube.com/watch?v=4JORXdeaE4U](https://www.youtube.com/watch?v=4JORXdeaE4U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-23 00:00:00+00:00

PS1 games are tested on PS5 in a new video, Elden Ring is getting a seamless co-op mod and Call of Duty Warzone’s season 3 mid-season update includes fast travel.
#GamingNews #PS5 #EldenRing

PlayStation 1 games have started to show up on PSN in Malaysia and YouTuber Mystic dropped a new video testing out the functionality of classic games on a modern console aka the PS5. 

PS1 Game on PS5 - https://www.youtube.com/watch?v=lkd7Xz15bao

Last week LukeYui on YouTube dropped a trailer for an Elden Ring Seamless Co-op mod that they say “removes all multiplayer boundaries and allows for connections to persist after death. Game progression is shared between all players.”

Call of Duty Season 3's mid-season update will go live for both Vanguard and Warzone following a May 24 update in Vanguard at 10 AM PT / 1 PM ET, and a Warzone update at 9 AM PT / 12 PM ET May 25. New additions will include a multiplayer map for Vanguard, while a new fast travel system is coming to Warzone.

Call of Duty Season 3 Reloaded: https://www.gamespot.com/articles/call-of-duty-season-3-reloaded-will-bring-fast-travel-to-warzone-new-map-and-weapon-for-vanguard/1100-6503745/

STAMPS
00:00 - Intro
00:07 - PS1 on PS5
01:19 - Elden Ring Mod
02:11 - Call of Duty

## Sniper Elite 5 - Everything to Know
 - [https://www.youtube.com/watch?v=-CrtvYIxy7w](https://www.youtube.com/watch?v=-CrtvYIxy7w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-23 00:00:00+00:00

Sniper Elite 5, the latest in Rebellion’s head-shottin’, x-rayin’ shooter series is upon us, releasing May 26, 2022. If this is your first Sniper Elite game, or you’re a series veteran, here’s everything you need to know about Sniper Elite 5. #SniperElite #Gaming #GameSpot

0:00 - Intro
0:19 - Plot & Setting
1:10 - Gameplay
4:54 - Multiplayer
6:52 - DLC
7:07 - Platforms
7:40 - Release Date & Price
8:54 - Outro


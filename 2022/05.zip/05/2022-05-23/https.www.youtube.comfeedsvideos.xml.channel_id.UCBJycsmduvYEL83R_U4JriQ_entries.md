# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The Future of Smartphone Cameras? Sony Xperia 1 IV!
 - [https://www.youtube.com/watch?v=MUU0BjJjAvk](https://www.youtube.com/watch?v=MUU0BjJjAvk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-05-24 00:00:00+00:00

Sony might be onto something here with the Xperia 1 IV...

Sony Xperia 1 IV: https://amzn.to/3yUXeEv
MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Sony for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


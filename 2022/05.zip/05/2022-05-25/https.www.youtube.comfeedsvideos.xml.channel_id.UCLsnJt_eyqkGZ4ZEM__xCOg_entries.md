# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Luizjana dniem i nocą - Kamperem po USA #28
 - [https://www.youtube.com/watch?v=1PZIQdXU9q8](https://www.youtube.com/watch?v=1PZIQdXU9q8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2022-05-25 00:00:00+00:00

🗺️ USA (2022) #28. W dzisiejszym vlogu odwiedzimy stolicę Luizjany, Baton Rouge, a wieczorem wybierzemy się do najbardziej znanego miasta tego stanu, czyli do Nowego Orleanu.

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha

5% zniżki na Kuga Campervan na hasło "VlogCasha" (wynajem na co najmniej 10 dni): https://www.travellers-autobarnrv.com/ 

Playlisty filmów z moich podróży:
USA (2022): https://bit.ly/3uGVdbd
Kuba (2021): https://bit.ly/3dhLIqK
USA (2021): https://bit.ly/35J0zKd
Meksyk (2021): http://bit.ly/3c7Jycf
Turcja (2019-2020): https://bit.ly/31VPCR3
Kolumbia (2020): https://bit.ly/36tqlhH
Tajlandia, Laos, Wietnam (2019): https://bit.ly/2wrM9t2
Australia (2018): https://bit.ly/2OJWYOy
USA (2017): https://bit.ly/2ya73NV
Autostop (2018): https://bit.ly/2NbHzos

Mój sprzęt:
Aparat/Obiektywy: Sony A7IV / FE 16-35mm F2.8 / FE 24-105mm F4
Plecak zielony: https://bit.ly/3y9cX1Y
Dron: https://bit.ly/3HCTZUv

(Linki afiliacyjne. Jeśli dokonacie zakupów po wejściu w mój link, otrzymam prowizję za polecenie.)

Muzyka z vloga pochodzi z serwisu Artlist. Skorzystaj z mojej promocji i odbierz 2 miesiące gratis!
Artlist: https://bit.ly/3mWjQwo

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/

#PodróżeCasha #USA


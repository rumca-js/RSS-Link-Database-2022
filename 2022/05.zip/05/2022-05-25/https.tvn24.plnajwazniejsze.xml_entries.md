# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Wchodząc do wyrobiska, gdzie jest ogień, wchodzimy do lufy armatniej. Tam nie ma gdzie się schować"
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-2251,S00E2251,778990?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-2251,S00E2251,778990?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-05-25 02:30:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jfjjbf-schodzimy-do-piekla-5725554/alternates/LANDSCAPE_1280" />
    O tym, kim są ratownicy górniczy, co czują, gdy zjeżdżają do akcji i jak radzą sobie z tym ich rodziny.


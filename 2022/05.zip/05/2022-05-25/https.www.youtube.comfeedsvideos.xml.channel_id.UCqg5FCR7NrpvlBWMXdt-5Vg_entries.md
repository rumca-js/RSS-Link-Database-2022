# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Sniper Elite 5 | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=KFxlMhZwcRo](https://www.youtube.com/watch?v=KFxlMhZwcRo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-05-26 00:00:00+00:00

KC Nwosu reviews Sniper Elite 5, developed by Rebellion.

Sniper Elite 5 on Steam: https://store.steampowered.com/app/1029690/Sniper_Elite_5/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Lord of the Rings: The Fellowship of the Ring with Nick and Marty - Part 1
 - [https://www.youtube.com/watch?v=o5LTxaZsQow](https://www.youtube.com/watch?v=o5LTxaZsQow)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-05-26 00:00:00+00:00

This week we're starting our replay of the old Lord of the Rings games on PS2!

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Halo on Paramount+ Has Potential, But Needs a Lot of Work | Breakout
 - [https://www.youtube.com/watch?v=0AAv-gUSMkY](https://www.youtube.com/watch?v=0AAv-gUSMkY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-05-25 00:00:00+00:00

With the Halo show wrapped up, Nick, Marty and KC are going to discuss it, talking about where it succeeded, where it failed and what it needs to do to reach its potential in season 2.

Featuring Nick Calandra, Marty Sliva, and KC Nwosu, the freeform podcast dives into a bit of our daily lives, the latest games, movies, tv shows and books, the occasional craft beer review and random topics we find interesting.

New episodes every Wednesday morning from 9 AM to 10:00 AM CT. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Trek to Yomi & Ravenous Devils (Zero Punctuation)
 - [https://www.youtube.com/watch?v=SJPig1n7YxM](https://www.youtube.com/watch?v=SJPig1n7YxM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-05-25 00:00:00+00:00

This week on Zero Punctuation, Yahtzee reviews Trek to Yomi and Ravenous Devils.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## Yahtzee and JM8 Play Salt and Sacrifice | Post-ZP Stream
 - [https://www.youtube.com/watch?v=yOPLG4oEIik](https://www.youtube.com/watch?v=yOPLG4oEIik)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-05-25 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Yahtzee plays two hours of Salt and Sacrifice for today's Post-ZP Stream.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist​

Want to see the next episode a week early? Check out http://www.escapistmagazine.com​ for the latest episodes of your favorite shows.

---



---


The Escapist Merch Store ►►https://teespring.com/stores/the-esca...​
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag​
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation


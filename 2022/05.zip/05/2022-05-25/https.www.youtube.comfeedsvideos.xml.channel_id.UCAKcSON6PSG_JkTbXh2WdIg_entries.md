# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Hippo Campus - session at The Current (full performance + interview)
 - [https://www.youtube.com/watch?v=hxM56KRHZ_s](https://www.youtube.com/watch?v=hxM56KRHZ_s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-05-26 00:00:00+00:00

According to Jake Luppen, the day that Hippo Campus sold out the Armory was the best day of his life. Not only did the band perform for 8,000 fans in their hometown, they also glimpsed a dream come true: a Hippo Campus star on First Avenue’s exterior wall.

Despite the pandemic and all else, the members of Hippo Campus have had a lot to celebrate over the past few years. They’d planned to take a break from touring and write their next album starting in late 2019, but those months turned into years of settling back into the Twin Cities scene and even producing music for younger artists. “This record is the first time we got to be dead [as Hippo Campus],” Luppen says. “I finally got to live in reality.”

Hippo Campus’s third album, LP3, came out at long last earlier this year. Three of its earliest tracks — the ones that helped shape its sound — are “Ride Or Die,” “Bang Bang,” and “Ashtray.” Those are the tunes they performed at The Current’s studio this month.

There’s lots more to learn from Ayisha Jaffer’s interview with Jake Luppen and Zach Sutton of Hippo Campus. Enjoy the full interview and musical performances in the video above.

Segments in this video:
00:00 “Ride Or Die”
03:28 “Bang Bang”
06:46 “Ashtray”
09:23 Interview with host Ayisha Jaffer

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#hippocampus #thehalocline #hippocampusband


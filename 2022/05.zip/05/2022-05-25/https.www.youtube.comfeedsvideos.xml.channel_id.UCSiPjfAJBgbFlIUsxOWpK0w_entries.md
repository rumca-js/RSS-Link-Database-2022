# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Santa Barbara // Zoutelande // POMPLAMOOSE ft. Benny Sings
 - [https://www.youtube.com/watch?v=svqEHp25Y7M](https://www.youtube.com/watch?v=svqEHp25Y7M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-05-26 00:00:00+00:00

This is actually Benny’s translation of a super popular Dutch song called Zoutelande. Mega summer vibes…Listen to the single on Spotify… https://spoti.fi/3LxyogD

Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

MUSICIAN CREDITS
Lead Vocals: Benny Sings & Nataly Dawn
Keys: Jack Conte
Guitar: Brian Green & Benny SIngs
Bass: Nick Campbell
Drums: Ben Rose
Background Vocals: Sarah Dugas

AUDIO CREDITS
Audio Engineer: Tim Sonnefeld
Studio Engineer: Chris Sorem
Mixing/Mastering: Yianni AP

VIDEO CREDITS
Director: Dom Fera
Asst. Director: Michael Kiaunis
DP: Christian Colwell
Camera Operator: Austin Hughes 
PA/Wardrobe: Alex Allen
Video Editor/Colorist: Athena Wheaton

Recorded at Nest Recorders in Los Angeles.

LYRICS
Nothing better than a rainy day with you
Sunday and there's nothing here to do
We had nothing to spare when we started
But my parents had a condo in Santa Barbara (Santa Barbara)

And now we're stuck in this bungalow park
But your silly words keep me out of the dark
We're getting high on your father's whiskey
I'm so happy you're with me, just glad that you're with me
Back at this old little house at the bay
We never cared 'bout the world anyway
Nothing but gray skies from here to the city
I'm happy you're with me, just glad that you're with me
[Verse 2: Nataly Dawn, Benny Sings]
Can we wait a little longer? 'Cause I'm tired
Just wait 'til we get stronger, then we'll fly again
Some people want adventure and let their heart out
Some people bottle up in Santa Barbara (Santa Barbara)

And now we're stuck in this bungalow park
But your silly words keep me out of the dark
We're getting high on your father's whiskey
I'm so happy you're with me, just glad that you're with me
Back at this old little house at the bay
We never cared 'bout the world anyway
Nothing but gray skies from here to the city
I'm happy you're with me, just glad that you're with me

And I'm happy you're with me
I'm so happy you're with me
I'm so happy you're with me
I'm so happy you're with me

And now we're stuck in this bungalow park
But your silly words keep me out of the dark
We're getting high on your father's whiskey
I'm so happy you're with me, glad that you're with me
Back at this old little house at the bay
We never cared 'bout the world anyway
Nothing but gray skies from here to the city
I'm happy you're with me, just glad that you're with me
[Post-Chorus: Benny Sings, Nataly Dawn]
And I'm happy you're with me
I'm so happy you're with me
I'm so happy you're with me
I'm so happy you're with me
I'm so happy you're with me
I'm so happy

Santa Barbara
Santa Barbara


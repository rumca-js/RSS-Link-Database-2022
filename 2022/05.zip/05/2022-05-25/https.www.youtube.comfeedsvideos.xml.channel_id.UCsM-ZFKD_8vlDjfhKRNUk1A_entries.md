# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Rita Pax - Gdybyś kochał, hej! - live MUZO.FM
 - [https://www.youtube.com/watch?v=jrTZ9a8r0kU](https://www.youtube.com/watch?v=jrTZ9a8r0kU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-05-26 00:00:00+00:00

Rita Pax - Gdybyś kochał, hej! na żywo w MUZO.FM. Utwór pochodzi z płyty Piękno. Tribute to Breakout. Piosenka autorstwa Tadeusza Nalepy i Jacka Grania pochodzi z pierwszej płyty grupy Breakout - „Na drugim brzegu tęczy”.

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Rita Pax: http://www.facebook.com/ritapaxmusic
Instagram Rita Pax: http://www.instagram.com/ritapax
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Paulina Przybysz - wokal
Kasia Piszek - instr. klawiszowe
Paweł Zalewski - gitara
Piotr Zalewski - gitara basowa
Jerzy Markuszewki - perkusja
Rejestracja audio - Jacek Antosik


#popolsku


# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Did Lilly Singh pet The Rock’s head?
 - [https://www.youtube.com/watch?v=-aYBi2ipRug](https://www.youtube.com/watch?v=-aYBi2ipRug)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2022-05-26 00:00:00+00:00

An in depth interview with none other than @LillySingh . Thank you to Lilly and the team at Youtube for setting it up. Also check out her awesome new book, Be A Triangle. 

Sign up for my Patreon here: https://www.patreon.com/julienolke

Edited by: Alec McKay


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Lex Fridman's Analysis of Putin and Ukraine
 - [https://www.youtube.com/watch?v=0raJ1-1BJ7s](https://www.youtube.com/watch?v=0raJ1-1BJ7s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-05-26 00:00:00+00:00

Taken from JRE #1824 w/Lex Fridman:
https://open.spotify.com/episode/7f7MM2aHEoRHie7i7MI7A2?si=c77450647e254944

## Neal Brennan's Story About Using Ayahuasca for Depression
 - [https://www.youtube.com/watch?v=aPbU2mPRY2I](https://www.youtube.com/watch?v=aPbU2mPRY2I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-05-25 00:00:00+00:00

Taken from JRE #1823 w/Neal Brennan:
https://open.spotify.com/episode/6XLN5ajgzlYyVxbXUDOIqt?si=17e1218b5e7b416f


# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## IT music: Sphenx - Shuttle Departure (AWE64 Gold)
 - [https://www.youtube.com/watch?v=BvG0dCRYKFE](https://www.youtube.com/watch?v=BvG0dCRYKFE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-05-26 00:00:00+00:00

"The Space Ring - First Ring: Shuttle Departure" (v2.00 Low Qual, 2008) by Sphenx. Art "Space Invaders" by Facet/Genesis Project, 2nd at Compusphere 2018 (Christopherjam palette used for more saturated colors).

- Retro PC circa 2002. MS-DOS 7.1 (Win98SE), Athlon XP 2200+ etc.
- Impulse Tracker 2.14v5 and AWE64 Gold CT4390 (as SB16) analog out
- Maxed out channels (/L256), this track goes virtual up to 130
- 32-bit interpolation and 45454 mixing rate, filter and feedback disabled
- MIXERSET.EXE treble and bass in neutral position (no fade or boost)


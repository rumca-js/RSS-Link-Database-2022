## We Already Have Go 2 - Xe
 - [https://xeiaso.net/blog/we-have-go-2](https://xeiaso.net/blog/we-have-go-2)
 - RSS feed: https://xeiaso.net
 - date published: 2022-05-25 07:25:02.493514+00:00

We Already Have Go 2 - Xe's Blog


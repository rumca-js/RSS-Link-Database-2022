# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Do These Conservative And Liberal Women Agree On MY BODY, MY CHOICE?
 - [https://www.youtube.com/watch?v=bEHNu5Zv4GM](https://www.youtube.com/watch?v=bEHNu5Zv4GM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-05-26 00:00:00+00:00

These two women come from different political parties. But at least they can agree on "my body, my choice" - or do they?

Follow Chandler's Youtube: https://www.youtube.com/chandlerjuliet

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## No Altar Calls For Ray Comfort  | A Bee Interview
 - [https://www.youtube.com/watch?v=tfpo5eGvimw](https://www.youtube.com/watch?v=tfpo5eGvimw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-05-25 00:00:00+00:00

The founder and CEO of Living Waters, Ray Comfort, is in the studio with guys from The Babylon Bee to talk about evangelism, the gospel of Jesus Christ, and how he would have handled that Elon Musk interview a bit differently. Ray tells Kyle Mann and Adam Yenser all about his life’s work of talking to strangers on the street and why you should never leave home without a stack of gospel tracts.

Ray can be seen on Living Waters on YouTube: https://www.youtube.com/thewayofthemaster

And his TV show Way of the Master: https://www.livingwaters.com/outreach/way-of-the-master/

Check Out Living Waters: https://www.livingwaters.com/

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


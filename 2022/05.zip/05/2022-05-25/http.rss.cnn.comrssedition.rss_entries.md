# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Trump reacted with approval to 'hang Mike Pence' chants from rioters on January 6
 - [https://www.cnn.com/2022/05/25/politics/donald-trump-january-6-mike-pence-chants/index.html](https://www.cnn.com/2022/05/25/politics/donald-trump-january-6-mike-pence-chants/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 23:53:02+00:00

A former aide to Trump White House chief of staff Mark Meadows told the House January 6 committee that then-President Donald Trump had suggested to Meadows he approved of the "hang Mike Pence" chants from rioters who stormed the US Capitol, two sources familiar with the matter told CNN.

## Fugitive wanted in killing of elite cyclist traveled to New York City, authorities say
 - [https://www.cnn.com/2022/05/25/us/mo-wilson-death-suspect-search-wednesday/index.html](https://www.cnn.com/2022/05/25/us/mo-wilson-death-suspect-search-wednesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 22:46:57+00:00

Kaitlin Marie Armstrong, the woman suspected of fatally shooting elite cyclist Anna Moriah "Mo" Wilson in Texas, is believed to have traveled to New York City after the killing, authorities said Wednesday.

## Former reality star sentenced to 12 years in prison for child porn conviction
 - [https://www.cnn.com/2022/05/25/entertainment/josh-duggar-sentenced/index.html](https://www.cnn.com/2022/05/25/entertainment/josh-duggar-sentenced/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 21:57:02+00:00

An Arkansas federal judge sentenced former reality TV star Josh Duggar to more than 12 years in federal prison on Wednesday, according to court documents.

## Boris Johnson's staff got drunk, brawled and abused cleaners during Covid lockdowns, damning report finds
 - [https://www.cnn.com/2022/05/25/uk/boris-johnson-sue-gray-partygate-report-gbr-intl/index.html](https://www.cnn.com/2022/05/25/uk/boris-johnson-sue-gray-partygate-report-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 20:07:31+00:00

British Prime Minister Boris Johnson is facing a fight to save his premiership after a long-awaited report into a series of lockdown-breaking parties in Whitehall eviscerated a "XYZ"

## 'I'm tired of the moments of silence,' says Warriors coach Steve Kerr as he makes powerful plea against gun violence
 - [https://www.cnn.com/2022/05/25/sport/steve-kerr-texas-shooting-gun-violence-spt-intl/index.html](https://www.cnn.com/2022/05/25/sport/steve-kerr-texas-shooting-gun-violence-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 19:12:15+00:00

Golden State Warriors head coach Steve Kerr made an impassioned plea to take stronger action against gun violence in the United States after 19 children and two adults were killed at Robb Elementary School in Uvalde, Texas, on Tuesday.

## Oprah Winfrey gets 'a little emotional' saying goodbye to 'The Ellen DeGeneres Show'
 - [https://www.cnn.com/videos/business/2022/05/25/oprah-winfrey-ellen-degeneres-final-shows-orig-ht.cnn-business](https://www.cnn.com/videos/business/2022/05/25/oprah-winfrey-ellen-degeneres-final-shows-orig-ht.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 16:47:54+00:00

Oprah Winfrey joined "The Ellen DeGeneres Show" during its final week on air and reminisced about what it was like to wrap her own show in 2011.

## The NASA Mars InSight lander just took its final selfie
 - [https://www.cnn.com/2022/05/25/world/nasa-mars-insight-lander-final-selfie-scn/index.html](https://www.cnn.com/2022/05/25/world/nasa-mars-insight-lander-final-selfie-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 16:28:04+00:00

This is the last time we'll ever see a selfie from NASA's InSight lander on Mars. And judging by the amount of dust coating the lander's solar panels, it's easy to see why.

## Did dinosaur blood run warm or cold? New study aims to settle the debate
 - [https://www.cnn.com/2022/05/25/world/dinosaur-blood-warm-cold-scn/index.html](https://www.cnn.com/2022/05/25/world/dinosaur-blood-warm-cold-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 16:17:42+00:00

Fearsome predators like T. rex and towering, telescope-necked dinosaurs, such as Brachiosaurus, were warm-blooded creatures in the same way birds and mammals are, according to a groundbreaking new study.

## See breastfeeding mom save pet goose from bald eagle
 - [https://www.cnn.com/videos/us/2022/05/25/naked-goose-mom-rescue-bald-eagle-moos-orig-vpx.cnn](https://www.cnn.com/videos/us/2022/05/25/naked-goose-mom-rescue-bald-eagle-moos-orig-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 15:36:47+00:00

Video shows a mom who was breastfeeding her baby save her pet goose from a bald eagle. CNN's Jeanne Moos reports on a memorable avian rescue.

## The Middle East's $13 billion sandstorm problem is about to get worse
 - [https://www.cnn.com/2022/05/25/middleeast/climate-change-sand-storms-mime-intl/index.html](https://www.cnn.com/2022/05/25/middleeast/climate-change-sand-storms-mime-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 14:19:41+00:00

The skies from Dubai to as far away as Syria turned an apocalyptic orange as dust and sand whirled through the air this month.

## Florida class president couldn't discuss being gay in graduation speech, so he talked about his curly hair
 - [https://www.cnn.com/2022/05/25/us/florida-curly-hair-graduation-speech/index.html](https://www.cnn.com/2022/05/25/us/florida-curly-hair-graduation-speech/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 14:06:08+00:00

The class president at a Florida high school says he wasn't allowed to share his experience as a gay student in his graduation speech or how the state's so-called "Don't Say Gay" law will affect students like him, so he talked about something else that makes him a little different from his classmates -- his curly hair.

## India, the world's largest producer of sugar, is restricting exports
 - [https://www.cnn.com/2022/05/25/business/india-sugar-export-restrictions-food-prices/index.html](https://www.cnn.com/2022/05/25/business/india-sugar-export-restrictions-food-prices/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 12:35:42+00:00

India has decided to restrict the sale of sugar on international markets, just days after it banned wheat exports.

## 'Dr. Beach' names the top 10 US beaches for 2022
 - [https://www.cnn.com/travel/article/best-beaches-united-states-2022/index.html](https://www.cnn.com/travel/article/best-beaches-united-states-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 12:27:26+00:00

A wild expanse on North Carolina's Outer Banks has earned the top spot on an annual list of America's best beaches.

## Madonna makes surprise appearance at college graduation show
 - [https://www.cnn.com/style/article/madonna-and-fka-twigs-csm-show-2022/index.html](https://www.cnn.com/style/article/madonna-and-fka-twigs-csm-show-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 12:19:55+00:00

Madonna and FKA Twigs were spotted front row at the Central Saint Martins (CSM) undergraduate fashion show on Tuesday. The prestigious art school -- known for producing renowned designers Alexander McQueen, John Galliano, Stella McCartney and Phoebe Philo -- held its annual show in London's Kings Cross area, where students exhibited their graduate collections to a crowd of friends, family, buyers and fashion editors.

## Here's how Taiwan has made the US-China relationship more complicated
 - [https://www.cnn.com/videos/world/2022/05/25/us-taiwan-china-history-selina-wang-pkg-ctw-vpx.cnn](https://www.cnn.com/videos/world/2022/05/25/us-taiwan-china-history-selina-wang-pkg-ctw-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 10:24:49+00:00

CNN's Selina Wang looks at the history of Taiwan's relationship with China, and how it has made the United State's relationship with Beijing more complicated.

## The French meal Julia Child called life-changing
 - [https://www.cnn.com/travel/article/julia-child-sole-meuniere-recipe-wellness-origseriesfilms/index.html](https://www.cnn.com/travel/article/julia-child-sole-meuniere-recipe-wellness-origseriesfilms/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 09:19:49+00:00

A single meal forever changed Julia Child's life and American kitchens with it. It featured a mild, white-fleshed fish served in a butter sauce.

## Could this Google-backed startup become Africa's answer to Airbnb?
 - [https://www.cnn.com/travel/article/bongalo-airbnb-africa-mobile-money-spc-intl/index.html](https://www.cnn.com/travel/article/bongalo-airbnb-africa-mobile-money-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 08:51:10+00:00

Since Airbnb launched in 2008, it has taken the travel industry by storm. Sharing a home or renting an apartment has become a fashionable, and often more affordable, alternative to booking a hotel room.

## 'They're afraid of us': Ukrainian soldier describes taking down Russian helicopter
 - [https://www.cnn.com/videos/world/2022/05/24/cnn-on-front-lines-near-kharkiv-day-90-of-ukraine-invasion-npw-pkg-lead-vpx.cnn](https://www.cnn.com/videos/world/2022/05/24/cnn-on-front-lines-near-kharkiv-day-90-of-ukraine-invasion-npw-pkg-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 07:56:10+00:00

On day 90 of the invasion of Ukraine, CNN's Nick Paton Walsh is on the front lines near Kharkiv, where active shelling is taking place miles away.

## Indian man jailed for 10 years over wife's 'dowry death'
 - [https://www.cnn.com/2022/05/25/india/india-vismaya-dowry-death-husband-guilty-intl-hnk/index.html](https://www.cnn.com/2022/05/25/india/india-vismaya-dowry-death-husband-guilty-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 05:45:53+00:00



## 18-year-old gunman is dead, officials say
 - [https://www.cnn.com/2022/05/24/us/uvalde-texas-elementary-school-shooting/index.html](https://www.cnn.com/2022/05/24/us/uvalde-texas-elementary-school-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 05:42:09+00:00

A suspect is in custody after a shooting incident at Robb Elementary School in Uvalde, Texas, left at least two dead and injured 14 people, including students, authorities said.

## Gun legislation is stalled in Congress. Here's why that won't change anytime soon
 - [https://www.cnn.com/2022/05/25/politics/gun-laws-us-congress/index.html](https://www.cnn.com/2022/05/25/politics/gun-laws-us-congress/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 05:32:18+00:00

Tuesday's shooting at a Texas elementary school, which has left at least 19 children and two adults dead, marked another instance of a uniquely American tragedy.

## What you need to know about China-Taiwan tensions
 - [https://www.cnn.com/2022/05/24/china/china-taiwan-conflict-explainer-intl-hnk/index.html](https://www.cnn.com/2022/05/24/china/china-taiwan-conflict-explainer-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 05:11:48+00:00

US President Joe Biden's warning the US would defend Taiwan against Chinese aggression has made headlines around the world -- and put growing tensions between the small democratic island and its neighboring autocratic superpower back under the spotlight.

## Three years after leaving Trump White House, Sarah Huckabee Sanders glides toward GOP nomination for Arkansas governor
 - [https://www.cnn.com/2022/05/24/politics/sarah-huckabee-sanders-arkansas-governor-gop-primary/index.html](https://www.cnn.com/2022/05/24/politics/sarah-huckabee-sanders-arkansas-governor-gop-primary/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 04:39:53+00:00

Sarah Huckabee Sanders, who has leaned into the more controversial chapters of her time in the Trump White House during her Arkansas gubernatorial campaign, is on a glide path toward securing the Republican nomination on Tuesday long after clearing the field of two other heavyweights.

## 'What are we doing?!': Lawmaker gets emotional on Senate floor over elementary school shooting
 - [https://www.cnn.com/videos/us/2022/05/24/chris-murphy-texas-elementary-school-shooting-vpx.cnn](https://www.cnn.com/videos/us/2022/05/24/chris-murphy-texas-elementary-school-shooting-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 04:19:58+00:00

Sen. Chris Murphy (D-CT) reacts on the Senate floor after the deadly mass shooting at an elementary school in Uvalde, Texas.

## North Korea fires three missiles, including one with 'irregular trajectory'
 - [https://www.cnn.com/2022/05/24/asia/north-korea-missile-intl/index.html](https://www.cnn.com/2022/05/24/asia/north-korea-missile-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 04:10:46+00:00

North Korea has fired at least one ballistic missile in an easterly direction on Wednesday morning, according to South Korea's Joint Chiefs of Staff.

## Australians voted for stronger action on climate change. Will they get it?
 - [https://www.cnn.com/2022/05/25/australia/australia-election-climate-analysis-intl-hnk-dst/index.html](https://www.cnn.com/2022/05/25/australia/australia-election-climate-analysis-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 04:09:24+00:00

On his first full day on the job, Australia's new prime minister mentioned the words "climate change" four times within two minutes of his maiden international speech.

## This Chinese spirit is 53% alcohol. And now, it's being mixed into ice cream
 - [https://www.cnn.com/travel/article/moutai-ice-cream-hnk/index.html](https://www.cnn.com/travel/article/moutai-ice-cream-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 03:28:27+00:00

Moutai, a clear and potent spirit famed its incredibly strong taste, is known for being the drink-of-choice amongst many Chinese politicians and businesspeople looking to impress their colleagues.

## How airline ticket scalpers took over the Chinese travel market
 - [https://www.cnn.com/travel/article/china-airline-ticket-scalpers-cmb/index.html](https://www.cnn.com/travel/article/china-airline-ticket-scalpers-cmb/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 03:28:17+00:00

When I made up my mind to travel outside of Hong Kong in early March, the city's daily Covid-19 case count had just passed 50,000, with the highest fatality rate in the world.

## 'Pathetic!': NBA coach calls out politicians in wake of school shooting
 - [https://www.cnn.com/videos/sports/2022/05/25/steve-kerr-nba-golden-state-warriors-uvalde-texas-school-shooting-sot-vpx.nba-tnt](https://www.cnn.com/videos/sports/2022/05/25/steve-kerr-nba-golden-state-warriors-uvalde-texas-school-shooting-sot-vpx.nba-tnt)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 01:59:04+00:00

Golden State Warriors head coach Steve Kerr got emotional talking about the school shooting in Uvalde, Texas, and called on Senators to take action on legislation designed to protect kids from school shootings.

## Ex-Trump aide's TV appearance goes off the rails
 - [https://www.cnn.com/videos/business/2022/05/25/kellyanne-conway-alyssa-farah-griffin-the-view.cnn](https://www.cnn.com/videos/business/2022/05/25/kellyanne-conway-alyssa-farah-griffin-the-view.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-25 00:25:08+00:00

While touting her new book, former Trump aide Kellyanne Conway got into a heated exchange with former White House colleague Alyssa Farah Griffin on "The View."


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Monkeypox: The New Pandemic
 - [https://www.youtube.com/watch?v=-CY_SLEfvgg](https://www.youtube.com/watch?v=-CY_SLEfvgg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-05-26 00:00:00+00:00

Monkeypox! What is it? Did Bill Gates really predict it? Is it the next Covid-19? And is the media reaction to it legitimate or is monkeypox being used s a way of sustaining the last two years 
of government and Big Pharma control? #Monkeypox #BigPharma #Pandemic 

References
https://unherd.com/thepost/monkeypox-is-not-the-next-covid-19/
https://www.marca.com/en/lifestyle/world-news/2022/05/24/628c0ffaca4741d92a8b45ab.html
https://www.cnbc.com/2022/05/20/dr-scott-gottlieb-says-the-rising-monkeypox-cases-suggest-its-spread-pretty-wide-.html
https://www.theguardian.com/business/2022/may/03/pfizer-covid-sales-pricing-vaccine-paxlovid-pill
https://www.theguardian.com/commentisfree/2022/feb/08/big-pharma-global-vaccine-rollout-covid-pfizer

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## My Thoughts...
 - [https://www.youtube.com/watch?v=uFNYDVYxAuU](https://www.youtube.com/watch?v=uFNYDVYxAuU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-05-25 00:00:00+00:00

My thoughts on the tragic event at Robb Elementary School in Uvalde, Texas. 

Support The Families: https://www.gofundme.com/c/act/donate-to-texas-elementary-school-shooting-relief


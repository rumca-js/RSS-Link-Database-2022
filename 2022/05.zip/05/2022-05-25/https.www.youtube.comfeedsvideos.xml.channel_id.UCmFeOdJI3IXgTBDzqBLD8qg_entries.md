# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## YouTube Won't Exist In 5 Years. Here's Why.
 - [https://www.youtube.com/watch?v=QBJ9Zg_7XR8](https://www.youtube.com/watch?v=QBJ9Zg_7XR8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2022-05-25 00:00:00+00:00

Download Cleanfox today:  https://app.adjust.com/s90qrxp
@Cleanfoxapp (TikTok) #cleanfox #cleanyourmalbox #cleantok #techtok

YouTube might not exist in 5 or 10 years because of a few bad decisions, here's why.
Susan Wojcicki is ruining Youtube by some bad business decisions and selling lots of youtube's creativity for big profits at a big cost, making youtube bad and is why youtube is now trash. Here's why Youtube sucks nows, and the golden age of youtube is dead and tiktok is taking over youtube. Here's why youtube is dying. It all comes from Youtube's business strategy and business model making money from killing youtube's creativity. 

Inspired by:
- justmehibi's 'Susan Wojcicki is Ruining YouTube'
https://www.youtube.com/watch?v=Qbok9Aju0JA
- Jack Gordon's 'Tiktok is eating Youtube Alive'
https://www.youtube.com/watch?v=q-ycCiEw8BQ&t=155s

00:00 - Youtube Won't Exist In 5 Years
01:10 - The Origins
06:43 - Cleanfox
08:18 - The Golden Years
12:25 - The Turning Point
14:38 - The Decline
20:02 - Youtube v Tiktok


Support the channel here (all money goes straight back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT


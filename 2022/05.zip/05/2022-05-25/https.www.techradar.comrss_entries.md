# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Xiaomi 13: what we know so far and what we want to see
 - [https://www.techradar.com/news/xiaomi-13](https://www.techradar.com/news/xiaomi-13)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-05-25 17:00:54+00:00

Here's what we want to see in the Xiaomi 13, the next flagship phone from the Chinese tech giant.


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Absolutely everything went wrong - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=ip9Yy1dz5ew](https://www.youtube.com/watch?v=ip9Yy1dz5ew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-05-26 00:00:00+00:00

Thanks to Intel for continuing to sponsor this awesome series! Buy an Intel Core i7-9700K: https://geni.us/mJPM

Buy an ASUS ProArt 32" IPS Monitor: https://geni.us/Y8p0

Buy a kit of Corsair Vengeance LPX 32GB Memory: https://geni.us/Au3EV

Buy a Sabrent Rocket 4.0 1TB NVME: https://geni.us/LX9PA

Buy an RTX 3060 Ti FTW3 GAMING: https://geni.us/SutYvQ

Buy an NZXT H1 V2 Case: https://geni.us/HAf1

Buy a Seagate Exos 16TB Enterprise HDD: https://geni.us/rdHpA8

Buy a BenQ ScreenBar Halo e-Reading LED Lamp: https://geni.us/kL9aucE

Buy a Grovemade Matte Desk Pad: https://lmg.gg/ztyQO

Buy a Jarvis Monitor Arm: https://lmg.gg/Gj7zo

Buy an IKEA Besta Storage Unit: https://lmg.gg/7Tvj5

Buy an IKEA Evedal Lamp: https://lmg.gg/GrD7F

Buy a Kingston Workflow Station: https://geni.us/KO8o5

Buy some Kingston Workflow SD Readers: https://geni.us/9mu7

Buy a FilmGrade™ Flicker-Free A19 LED (6-Pack): https://lmg.gg/64Y9N

Buy a Steelcase Series 2: https://geni.us/wDmH

Buy a Eufy X8 Robovac: https://geni.us/ODJfp

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1433444-absolutely-everything-went-wrong-intel-5000-extreme-tech-upgrade/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Special Intro by MBarek Abdelwassaa
https://www.instagram.com/mbarek_abdel/

CHAPTERS
---------------------------------------------------
0:00 Intro
0:31 Photography Editing Setup
1:06 Tour
5:09 Unboxing
7:52 Shelf Assembly
10:08 Problems
12:51 Mesh WiFi
14:30 NAS
15:49 PC Build
18:19 Boot
20:07 ULTIMATE

## I’ve Never Had So Much FUN - Intel Development Center DEEP Dive
 - [https://www.youtube.com/watch?v=BtFdraQWVtM](https://www.youtube.com/watch?v=BtFdraQWVtM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-05-25 00:00:00+00:00

Check out the $14.99 Minnow set and the $19.99 Moray set at: https://www.ifixit.com/LTT

We're back at the Israel Design Center Intel Fab and this time it's a facility tour of the Validation Lab. I was like a kid in a candy store!

Discuss on the forum: https://linustechtips.com/topic/1433252-i%E2%80%99ve-never-had-so-much-fun/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:10 What is the Validation Lab?
2:05 Test Benches
2:44 PCIe Gen 5
5:40 FPGA
7:06 USB-C Test Rig
9:45 Display Testing
10:45 THE THERMAL DOODAD
13:14 Debug Lab
14:18 "the IREM"
15:04 Intel's biggest problem
16:45 Outro


# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Przypowieść o chciwym informatyku i dobrym szewcu
 - [https://www.youtube.com/watch?v=ZeP4i_zIi3Y](https://www.youtube.com/watch?v=ZeP4i_zIi3Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-05-26 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3M1MPtD
2. https://bit.ly/3LSHmox
3. https://bit.ly/3wOkK3k
4. https://bit.ly/3LMJ2Ae
---------------------------------------------------------------
💡 Tagi: #Morawiecki #polityka
--------------------------------------------------------------

## George Soros szczerze o końcu naszej cywilizacji! Co miał na myśli?
 - [https://www.youtube.com/watch?v=IRKTjKRKIc0](https://www.youtube.com/watch?v=IRKTjKRKIc0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-05-25 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/39TPrfo
2. https://cnb.cx/3NA30zh
3. https://bit.ly/38hQTb8
4. https://bwnews.pr/3LNTEij
5. https://on.doi.gov/3PTAIBY
6. https://bit.ly/3yZuiLE
7. https://bit.ly/3GkDsE7
8. https://bit.ly/3wO1SCs
9. https://bit.ly/3GniV1I
---------------------------------------------------------------
💡 Tagi: #Davos #Ukraina #Soros
--------------------------------------------------------------


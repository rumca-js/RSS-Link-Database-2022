# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Dehd - Bad Love (Live on KEXP)
 - [https://www.youtube.com/watch?v=J6YK3N1KxbU](https://www.youtube.com/watch?v=J6YK3N1KxbU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-26 00:00:00+00:00

http://KEXP.ORG presents Dehd performing “Bad Love” live in the KEXP studio. Recorded May 6, 2022.

Jason Balla - Guitar / Vocals
Emily Kempf - Bass / Vocals
Eric McGrady - Drums

Host: Larry Mizell, Jr.
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

http://www.dehd.horse
http://kexp.org

## Dehd - Control (Live on KEXP)
 - [https://www.youtube.com/watch?v=yNSMpD0PA28](https://www.youtube.com/watch?v=yNSMpD0PA28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-26 00:00:00+00:00

http://KEXP.ORG presents Dehd performing “Control” live in the KEXP studio. Recorded May 6, 2022.

Jason Balla - Guitar / Vocals
Emily Kempf - Bass / Vocals
Eric McGrady - Drums

Host: Larry Mizell, Jr.
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

http://www.dehd.horse
http://kexp.org

## Dehd - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=au4ihig0rbU](https://www.youtube.com/watch?v=au4ihig0rbU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-26 00:00:00+00:00

http://KEXP.ORG presents Dehd performing live in the KEXP studio. Recorded May 6, 2022.

Songs:
Control
Bad Love
Stars
Window

Jason Balla - Guitar / Vocals
Emily Kempf - Bass / Vocals
Eric McGrady - Drums

Host: Larry Mizell, Jr.
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

http://www.dehd.horse
http://kexp.org

## Dehd - Stars (Live on KEXP)
 - [https://www.youtube.com/watch?v=HcSdWCswbrI](https://www.youtube.com/watch?v=HcSdWCswbrI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-26 00:00:00+00:00

http://KEXP.ORG presents Dehd performing “Stars” live in the KEXP studio. Recorded May 6, 2022.

Jason Balla - Guitar / Vocals
Emily Kempf - Bass / Vocals
Eric McGrady - Drums

Host: Larry Mizell, Jr.
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

http://www.dehd.horse
http://kexp.org

## Dehd - Window (Live on KEXP)
 - [https://www.youtube.com/watch?v=Fuw03T4iavk](https://www.youtube.com/watch?v=Fuw03T4iavk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-26 00:00:00+00:00

http://KEXP.ORG presents Dehd performing “Window” live in the KEXP studio. Recorded May 6, 2022.

Jason Balla - Guitar / Vocals
Emily Kempf - Bass / Vocals
Eric McGrady - Drums

Host: Larry Mizell, Jr.
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

http://www.dehd.horse
http://kexp.org


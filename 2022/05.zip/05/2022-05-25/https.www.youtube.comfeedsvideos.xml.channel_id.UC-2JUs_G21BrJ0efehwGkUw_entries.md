# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## So Is Mine | David Ryan Harris (ft. Scary Pockets) - FUNK version
 - [https://www.youtube.com/watch?v=w7C82nDqd_Q](https://www.youtube.com/watch?v=w7C82nDqd_Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-05-26 00:00:00+00:00

Come see David Ryan Harris LIVE with Scary Goldings on 6/3/22 at The Troubadour in Los Angeles! Tickets on sale NOW: https://wl.seetickets.us/event/David-RyanHarris/470179?afflky=TheTroubadour

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of David Ryan Harris' "So Is Mine" by Scary Pockets & David Ryan Harris.

MUSICIAN CREDITS
Lead vocal: David Ryan Harris
Drums: Lemar Carter
Bass: Sean Hurley
Organ: Charles Jones
Keys: Will Gramling
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Nate Cuboi
Editor: Adam Kritzberg

Recorded Live at Scary Pockets HQ in Los Angeles, CA.

#ScaryPockets #Funk #DavidRyanHarris #SoIsMine


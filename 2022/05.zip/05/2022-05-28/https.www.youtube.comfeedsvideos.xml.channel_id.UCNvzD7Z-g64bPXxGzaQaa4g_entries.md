# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 WEIRD Gaming Stories of May 2022
 - [https://www.youtube.com/watch?v=y5uQb4ZQhpc](https://www.youtube.com/watch?v=y5uQb4ZQhpc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-05-29 00:00:00+00:00

May 2022 saw no shortage of weird and crazy video game news stories. Here are some of the strangest new things in gaming.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

https://www.pcgamesn.com/oculus/quest-2-breathing-add-on-looks-like-metal-gear-solid-cosplay
---
https://www.eurogamer.net/warzone-players-find-xp-glitch-in-king-kongs-testicles
---
https://youtu.be/QxwLNoyGx3Q
--
https://www.videogameschronicle.com/news/nft-sales-have-declined-92-since-their-peak/ + https://blog.playerauctions.com/featured/nft-crash-square-enix-continues-to-sell-legacy-franchises/
--
https://www.vice.com/en/article/n7nxxb/crypto-company-turns-games-it-doesnt-own-into-nfts-quickly-deletes-them
--
https://www.techspot.com/news/94684-ugly-sonic-makes-cameo-new-chip-n-dale.html
--
https://fortune.com/2022/05/11/ea-electronic-arts-loses-20-billion-fifa-video-game-franchise-licensing-spat/
https://www.gamespot.com/articles/ea-is-looking-to-sell-itself-or-merge-with-another-company-report/1100-6503720/
--
https://www.ign.com/articles/dead-by-daylight-dating-sim
--
https://finance.yahoo.com/news/gamefly-still-renting-ps2-games-140000947.html
--
https://www.gamesindustry.biz/articles/2022-05-16-microsoft-patent-application-hints-at-method-of-validating-discs-for-digital-only-consoles
--
https://www.gamespot.com/articles/assassins-creed-player-beats-all-12-main-games-without-taking-any-damage/1100-6503434/

## 10 Elden Ring Problems NOBODY WANTS TO ADMIT
 - [https://www.youtube.com/watch?v=hWZ1iEly2HI](https://www.youtube.com/watch?v=hWZ1iEly2HI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-05-28 00:00:00+00:00

Elden Ring is one of the greatest games of all time, but there a few small things that bothered us. Here are our complaints.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


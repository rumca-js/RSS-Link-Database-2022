# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## 12 Biggest Game Releases For June 2022
 - [https://www.youtube.com/watch?v=wsD7eNFxE1E](https://www.youtube.com/watch?v=wsD7eNFxE1E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-29 00:00:00+00:00

June may mean summertime for some, but with games like Mario Strikers: Battle League, Diablo Immortal and The Quarry coming out, June may start to mean hanging out indoors. Here are the biggest games releasing in June 2022.

## 24 MORE Things You STILL Didn't Know In Zelda Breath Of The Wild
 - [https://www.youtube.com/watch?v=1P7E99dcYqo](https://www.youtube.com/watch?v=1P7E99dcYqo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-05-28 00:00:00+00:00

This time in Breath of the Wild, we'll be trying to wake sleeping monks, cook eggs in unconventional ways, and uncover Nintendo's secret code names for Zelda projects.

In the video above, we cover 24 facts, tips and tricks that aren’t quite as well known, ranging from secrets to glitches, some that are pretty simple and others that are fairly complex. The Legend of Zelda: Breath of the Wild has been out for four years at this point, and players have found some amazing things, intended or not, that keep the game and its sense of discovery feeling fresh.

0:00 Intro
0:14 Lynels Teleporting To Attack
0:44 Teleporting With Lynels
0:51 Wake The Monks in Trial of the Sword
1:31 Monks Copy Seven Sages Poses
1:49 Monks Copy Triforce Symbol
1:56 Water Is Pulled Up For Lakes
2:09 Nintendo's Heightmap Editing Tools
2:31 Nintendo's Codenames For Zelda Games
3:00 Default Sunshroom Photo Exists
3:25 Pebblits Destroyed By Body Slam
3:41 Misplaced Log Near Hinox
3:56 Zelda's Secret Recipe
4:24 Hinox Can Swim
5:04 Weird Way to Cook Eggs
5:28 Sheikah Love the Rain
5:52 Food Heals Enemies
6:01 Guardians Follow Your Frontside
6:37 Guardians Can Team Up With You
6:51 Dodge A Talus' Punch
6:59 Secret Ice Patch in Lost Woods
7:27 Maz Koshia's Ninjutsu is in Sheikah
7:45 Maz Koshia Can Be Found Through Camera
7:59 Maz Koshia Loves Bananas
8:10 The Ultimate Final Battle
8:55 Outro


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Life of Eärendil | Tolkien Explained
 - [https://www.youtube.com/watch?v=BLDWm1eOTL0](https://www.youtube.com/watch?v=BLDWm1eOTL0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-05-28 00:00:00+00:00

Eärendil is among the greatest of Tolkien's characters. The father of Elrond and Elros, he would convince the Valar to intervene, resulting in Morgoth's defeat.  From that moment on, he would sail the skies of Middle-earth, with a silmaril upon his brow, and live on as a star - held in honor and reverence to many of the greatest heroes of Middle-earth.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri
Noe Leyva - https://twitter.com/NoeLeyvArt

Eärendil - Alystraea
Tulkas Chaining Morgoth - Kip Rasmussen
White Ships - Ted Nasmith
Armenelos - Ralph Damiani
Elrond - WETA
Aragorn - Adam Middleton
Galadriel - Alystraea
Earendil and Elwing - Aegeri
Beleriand Map - Lamaarcana
Turgon, Idril, and Maeglin - Catherine Karina Chmiel
Tuor & Idril - Jenny Dolfen
Descendants of Thingol - Jenny Dolfen
Tuor - Jenny Dolfen
The Siege of Gondolin - John Howe
Tuor, Idril, and Maeglin - Sara Morello
The Fall of Gondolin - Aronja Art
Maeglin laid hands on Idril and on Earendil - Catherine Karina Chmiel
Tuor and Maeglin - AnotherStrangerMe
The Siege of Gondolin - John Howe
Cirith Thoronath - Donato Giancola
Glorfindel's Bane - Ted Nasmith
Glorfindel Duels a Balrog of Morgoth - Kip Rasmussen
Ulmo Appears Before Tuor - Alan Lee
Men at Pool - Turner Mohan
Vinyamar - CK Goksoy
His heart was filled with longing - Jenny Dolfen
Elwing receives the survivors of Gondolin - Alan Lee
Haven of the Swans - Alystraea
Earendil's heraldic symbol above the sea - Alan Lee
Elrond, Elros, Earendil, & Elwing - Jenny Dolfen
And Maglor took pity upon them - Catherine Karina Chmiel
Earendil the Mariner - Ted Nasmith
Annuminas - Aegeri
The Hunt - Jenny Dolfen
Beren Recovers a Silmaril - Anke Eissmann
The Oath Has Been Awakened - Jenny Dolfen
Ulmo and Elwing - Aegeri
Ulmo and Elwing - Jenny Dolfen
Earendil and Elwing - Steamey
Flight of Elwing - Matej Cadil
New Star - Alystraea
Earendil and Elwing - Aegeri
Earendil - Jenny Dolfen
The Shores of Valinor - Ted Nasmith
Earendil Searches Tirion - Ted Nasmith
Tirion of the Crystal Stairs - Alystraea
Tuor First View of the Sea - Anke Eissmann
Manwe - Nahar Doa
Morgoth and the High King of the Noldor - Ted Nasmith
Vingilot - Aegeri
Manwe - Steamey
Breath of Arda, Manwe - Christina Kraus
Manwe Sulimo - Christina Kraus
Fall of Gondolin - CK Goksoy
The Grey Havens - John Howe
Earendil - John Howe
Dragon - Felix Englund
Ancalagon the Black - CK Goksoy
Ancalagon vs Earendil - Kip Rasmussen
The Scourge of Ancalagon - Ralph Damiani
Vingilot - Aegeri
Earendil - Alystraea
Stargazing - Anke Eissmann
Surely that is a Silmaril that shines now in the West - Alan Lee
Elros looking west from Numenor - Anke Eissmann
The Phial of Galadriel - Donato Giancola
The Phial of Galadriel - Anke Eissmann
Shelob's Retreat - Ted Nasmith
The Phial of Galadriel - John Howe
Earendil and Elwing approach Valinor - Donato Giancola
Frodo's Dream of Earendil - Anke Eissmann
New Star - Alystraea
Earendil - Alystraea
The White Flame - Ralph Damiani

#earendil #tolkien #silmarillion


# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Police inaction in Texas school shooting had catastrophic consequences, experts say
 - [https://www.cnn.com/2022/05/28/us/failure-by-uvalde-police-to-act-quickly-led-to-catastrophic-consequences/index.html](https://www.cnn.com/2022/05/28/us/failure-by-uvalde-police-to-act-quickly-led-to-catastrophic-consequences/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 23:28:09+00:00

• What we know about the victims
• Parents and children share heartbreaking voicemails

## Why Kylian Mbappé chose to stay at PSG
 - [https://www.cnn.com/2022/05/28/football/kylian-mbappe-contract-psg-real-madrid-spt-intl/index.html](https://www.cnn.com/2022/05/28/football/kylian-mbappe-contract-psg-real-madrid-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 22:56:15+00:00

Resplendent with a charismatic protagonist, politicians, two of the world's biggest football clubs, and hundreds of millions of dollars at stake, the Kylian Mbappé saga kept the football world gripped as he oscillated between signing for Real Madrid and staying at Paris-Saint-Germain.

## Flight cancellations kick off Memorial Day weekend
 - [https://www.cnn.com/2022/05/28/business/memorial-day-flight-cancellations/index.html](https://www.cnn.com/2022/05/28/business/memorial-day-flight-cancellations/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 20:10:49+00:00

It's another chaotic holiday weekend for Americans traveling by air.

## How one woman forever changed American cooking
 - [https://www.cnn.com/videos/us/2022/05/28/chef-julia-child-french-cooking-origseriesfilms-pkg.cnn](https://www.cnn.com/videos/us/2022/05/28/chef-julia-child-french-cooking-origseriesfilms-pkg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 16:29:57+00:00

The new CNN Film "Julia" tells the story of Julia Child, the legendary cookbook author and television superstar who changed the way Americans think about food, TV and women's roles in American life. Don't miss the premiere Monday, May 30, at 8 p.m. ET.

## Polish people take Ukrainian refugees fleeing war into their homes
 - [https://www.cnn.com/videos/tv/2022/05/28/polish-people-take-ukrainian-refugees-fleeing-war-into-their-homes.cnn](https://www.cnn.com/videos/tv/2022/05/28/polish-people-take-ukrainian-refugees-fleeing-war-into-their-homes.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 16:07:12+00:00

Michael Smerconish is in Warsaw speaking with John Lynch, the founder of Corporate Aid for Ukraine who says the support the Polish people have shown to Ukrainian refugees is one of the greatest shows of humanity in history.

## Eyes of the world on Paris rather than St. Petersburg for Champions League final
 - [https://www.cnn.com/2022/05/27/football/real-madrid-liverpool-champions-league-final-spt-intl/index.html](https://www.cnn.com/2022/05/27/football/real-madrid-liverpool-champions-league-final-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 15:58:25+00:00

Choose your color -- red or white. The bars and stands around Paris' Stade de France, the venue for Saturday's Champions League final, have certainly nailed their colors to the mast.

## Fact check: Debunking false viral tweets about Abbott and Cruz after Texas mass shooting
 - [https://www.cnn.com/2022/05/28/politics/fact-check-false-viral-tweets-texas-shooting-abbott-cruz/index.html](https://www.cnn.com/2022/05/28/politics/fact-check-false-viral-tweets-texas-shooting-abbott-cruz/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 15:58:21+00:00

In the wake of the Tuesday mass shooting at an elementary school in Texas, Twitter users went viral by making false claims about two of the state's most prominent politicians: Gov. Greg Abbott and Sen. Ted Cruz, both Republicans.

## 'Top Gun: Maverick' is about to give Tom Cruise his biggest opening ever
 - [https://www.cnn.com/2022/05/27/media/top-gun-maverick-opening-tom-cruise-box-office/index.html](https://www.cnn.com/2022/05/27/media/top-gun-maverick-opening-tom-cruise-box-office/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 15:31:28+00:00

Tom Cruise, one of the top movie stars in Hollywood, is about to have the biggest opening weekend of his career.

## Cardinal Angelo Sodano, longtime Vatican power broker, dies at 94
 - [https://www.cnn.com/2022/05/28/europe/angelo-sodano-death-intl/index.html](https://www.cnn.com/2022/05/28/europe/angelo-sodano-death-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 15:13:29+00:00

Cardinal Angelo Sodano died Friday at the age of 94 in Rome, according to Vatican News.

## Epcot needs a revamp. Marvel's Guardians of the Galaxy are here to save the day
 - [https://www.cnn.com/2022/05/28/media/guardians-of-the-galaxy-cosmic-rewind-disney/index.html](https://www.cnn.com/2022/05/28/media/guardians-of-the-galaxy-cosmic-rewind-disney/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 15:08:55+00:00

Disney World is the crown jewel of the company's Parks business, but even crown jewels need to be gussied up now and again. Epcot, one of the resort's most beloved parks since its 1982 opening, is in need of an update to attract a new generation of consumers.

## The world's largest bottle of whiskey sold for $1.4 million at auction
 - [https://www.cnn.com/style/article/largest-whiskey-bottle-auction-trnd/index.html](https://www.cnn.com/style/article/largest-whiskey-bottle-auction-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 14:02:21+00:00

The world's largest bottle of whiskey, called "The Intrepid," has sold for about $1.4 million, according to the auction house Lyon and Turnbull.

## More than 30 people, including children, killed in stampede at church event in Nigeria
 - [https://www.cnn.com/2022/05/28/africa/nigeria-stampede-intl/index.html](https://www.cnn.com/2022/05/28/africa/nigeria-stampede-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 13:55:32+00:00

More than 30 people were killed and others injured when a stampede broke out at a church event in the southeastern Nigerian city of Port Harcourt on Saturday, according to police and security officials.

## 'Stranger Things' season 4 delivers horror with an '80s nostalgia vibe
 - [https://www.cnn.com/2022/05/28/entertainment/stranger-things-new-season-plc/index.html](https://www.cnn.com/2022/05/28/entertainment/stranger-things-new-season-plc/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 13:10:03+00:00

Some days, I really miss being a kid.

## 'We had to literally unpolish them': 'Pistol' makeup artist on achieving the punk look
 - [https://www.cnn.com/style/article/disney-pistol-sex-pistols-makeup/index.html](https://www.cnn.com/style/article/disney-pistol-sex-pistols-makeup/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 10:06:19+00:00

As explored in the new Sex Pistols miniseries "Pistol," directed by Danny Boyle, the punk subculture flipped the script on fashion, music and especially beauty.

## Indiana police disclose cause of death of young boy found in a suitcase
 - [https://www.cnn.com/2022/05/28/us/indiana-boy-suitcase-death/index.html](https://www.cnn.com/2022/05/28/us/indiana-boy-suitcase-death/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 09:22:34+00:00

An unidentified child who was found dead in a suitcase last month in southern Indiana died from electrolyte imbalance, officials said Friday.

## 'Is there anything you need us to know?' Family worries over producer covering war
 - [https://www.cnn.com/2022/05/28/us/inside-cnn-newsletter-zahra-ullah-profile/index.html](https://www.cnn.com/2022/05/28/us/inside-cnn-newsletter-zahra-ullah-profile/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 09:03:00+00:00

CNN's Zahra Ullah says there are two moments from covering the war in Ukraine that she'll never forget: when she and her team got caught in crossfire, and the night Russia began its invasion.

## Zelensky promises Donbas will be 'Ukrainian again,' as Russian forces make gains
 - [https://www.cnn.com/europe/live-news/russia-ukraine-war-news-05-28-22/index.html](https://www.cnn.com/europe/live-news/russia-ukraine-war-news-05-28-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 08:51:51+00:00



## Shooter posted threats on social media app
 - [https://www.cnn.com/us/live-news/texas-elementary-school-shooting-05-28-22/index.html](https://www.cnn.com/us/live-news/texas-elementary-school-shooting-05-28-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 08:36:20+00:00



## Travel news: Supersonic jets, solar planes and underground railways
 - [https://www.cnn.com/travel/article/pandemic-travel-news-memorial-day-elizabeth-line/index.html](https://www.cnn.com/travel/article/pandemic-travel-news-memorial-day-elizabeth-line/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 08:17:12+00:00

This week in travel, London opened a $25 billion new metro line, Bombardier announced a supersonic breakthrough for its super-fast jet, and America's best beaches have been revealed.

## It turns out money may buy some happiness
 - [https://www.cnn.com/2022/05/28/health/money-happiness-wellness/index.html](https://www.cnn.com/2022/05/28/health/money-happiness-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 08:01:31+00:00

A few weeks ago, I found myself flying on a trapeze high above Manhattan. Why the heck was I there? Well, I was trying to answer an age-old question. Does money buy happiness?

## Two endangered Amur leopard cubs born at US zoo
 - [https://www.cnn.com/2022/05/28/us/saint-louis-amur-leopard-cubs-scn-trnd/index.html](https://www.cnn.com/2022/05/28/us/saint-louis-amur-leopard-cubs-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 06:00:05+00:00

The Saint Louis Zoo has welcomed two adorable -- and incredibly rare -- bundles of joy: Anya and Irina, critically endangered Amur leopard cubs.

## Boris Johnson has done huge damage to his reputation. His colleagues fear he will now cost them their jobs
 - [https://www.cnn.com/2022/05/28/uk/boris-johnson-survives-intl-gbr-cmd/index.html](https://www.cnn.com/2022/05/28/uk/boris-johnson-survives-intl-gbr-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 04:10:56+00:00

On Friday afternoon, a small but heated demonstration took place outside the gates of Downing Street.

## US intelligence assessing whether North Korea tested missile with properties not seen before
 - [https://www.cnn.com/2022/05/27/politics/us-assessment-north-korea-missiles/index.html](https://www.cnn.com/2022/05/27/politics/us-assessment-north-korea-missiles/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 03:12:09+00:00

The US intelligence community is trying to determine whether North Korea tested a ballistic missile with properties the US has not seen before earlier this week, according to three US officials.

## CNN tracks alleged war crimes committed by Russia's 64th brigade
 - [https://www.cnn.com/videos/world/2022/05/28/russia-64-brigade-ukraine-war-crimes-bucha-ebof-bell-pkg-vpx.cnn](https://www.cnn.com/videos/world/2022/05/28/russia-64-brigade-ukraine-war-crimes-bucha-ebof-bell-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 01:45:28+00:00

Ukrainian prosecutors' investigation into Russia's infamous 64th motor rifle brigade has led to the identification of 11 suspects accused of war crimes. CNN's Melissa Bell reports.

## Trump, other Republicans reject gun reforms at NRA convention
 - [https://www.cnn.com/2022/05/27/politics/uvalde-donald-trump-nra-convention/index.html](https://www.cnn.com/2022/05/27/politics/uvalde-donald-trump-nra-convention/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 01:44:43+00:00

Former President Donald Trump and other GOP leaders rejected efforts to overhaul gun laws and mocked Democrats and activists calling for change Friday at the National Rifle Association's annual convention.

## What we know about the victims of the Texas school shooting
 - [https://www.cnn.com/2022/05/25/us/victims-uvalde-texas-school-shooting/index.html](https://www.cnn.com/2022/05/25/us/victims-uvalde-texas-school-shooting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 00:51:44+00:00

One of the 10-year-olds aspired to be a lawyer someday. Another loved video games and anything with wheels. And another was saving up for a trip to Disney World.

## Imran Khan's claims of US conspiracy find a wide audience in Pakistan
 - [https://www.cnn.com/2022/05/27/asia/pakistan-imran-khan-us-conspiracy-intl-hnk/index.html](https://www.cnn.com/2022/05/27/asia/pakistan-imran-khan-us-conspiracy-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 00:09:34+00:00

Standing atop a truck, thronged by a huge crowd, a visibly enraged Imran Khan repeated the claim that has become a rallying cry for his millions of supporters.

## San Francisco Giants manager boycotts national anthem after school shooting
 - [https://www.cnn.com/2022/05/27/sport/gabe-kapler-uvalde-national-anthem/index.html](https://www.cnn.com/2022/05/27/sport/gabe-kapler-uvalde-national-anthem/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-28 00:07:16+00:00

San Francisco Giants manager Gabe Kapler told reporters ahead of his team's Friday game against the Cincinnati Reds that he intends to forgo the pregame US national anthem moving forward.


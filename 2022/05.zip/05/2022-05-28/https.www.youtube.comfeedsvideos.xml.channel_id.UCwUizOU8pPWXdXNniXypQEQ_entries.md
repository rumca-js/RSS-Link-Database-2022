# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## We Treat You Like a Moron: News Update!
 - [https://www.youtube.com/watch?v=f7dutCWo48I](https://www.youtube.com/watch?v=f7dutCWo48I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-05-28 00:00:00+00:00

Grab your Magnesium Breakthrough at https://magnesiumbreakthrough.com/jp
Use Code "AWAKEN" For a Deal

Check Out My Merch Here - https://awakenwithjp.com

See my LIVE Comedy Shows - https://awakenwithjp.com/pages/events

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

George W. Bush took a break from being forgotten about, monkeypox is here, Bill Maher is transphobic, fat is sexy, and more in this week's news update!  

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


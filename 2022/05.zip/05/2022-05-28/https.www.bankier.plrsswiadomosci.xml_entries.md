# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## "Jedni zazdroszczą drugim, inwestują i tak to się nakręca". O wydawaniu pieniędzy w grach rozmawiam ze swoim synem
 - [https://www.bankier.pl/wiadomosc/Mikroplatnosci-w-grach-Wywiad-z-dzieckiem-o-wydawaniu-pieniedzy-8340614.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mikroplatnosci-w-grach-Wywiad-z-dzieckiem-o-wydawaniu-pieniedzy-8340614.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-05-28 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/1/1cf84411145451-948-568-0-10-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />V-dolce czy G-Coiny? Skórka czy karnet bojowy? Kupić grę w pudełku, czy
tzw. cyfrę? Dziś gracze stają przed niemałym dylematem, a producenci gier
chętnie wyciągają rękę po ich pieniądze. O tym jak wygląda rynek gier z
perspektywy nastoletniego gracza rozmawiam ze swoim synem, 


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Oh No.
 - [https://www.youtube.com/watch?v=-i_LF543fB4](https://www.youtube.com/watch?v=-i_LF543fB4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-05-29 00:00:00+00:00

As Mastercard introduces a controversial biometric payment system that requires a face scan, is this another way in which the pandemic has been used to advance a dystopian future? #Mastercard #Cashless #FacePay

References
https://www.theguardian.com/technology/2022/may/17/mastercard-launches-smile-to-pay-amid-privacy-concerns?fbclid=IwAR2ixMXUYySPd0n5Wu48cy1lcx1YVztLutRZ5X7UCguxYEI0vQAho9sZN1s

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## LEAKED INFORMATION: They Are Trying To Delete This
 - [https://www.youtube.com/watch?v=RBTi3_GA_fA](https://www.youtube.com/watch?v=RBTi3_GA_fA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-05-28 00:00:00+00:00

A bombshell legal agreement shows that a Wuhan Iab can delete data in an arrangement with a U.S. lab – that doesn’t sound like it’ll help us understand COVID’s origins… #LabLeak #Wuhan #Pandemic #Covid19 

References
https://usrtk.org/biohazards-blog/wuhan-iab-can-delete-data/

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## 5 Ways Humans Are Influencing Species Evolution
 - [https://www.youtube.com/watch?v=EWkeQZ9SZXM](https://www.youtube.com/watch?v=EWkeQZ9SZXM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-05-29 00:00:00+00:00

Go to: https://thld.co/munkpack_scishow_0522 and use code SCISHOW to get 20% off your first purchase! Thanks to Munk Pack for sponsoring today’s video!


Evolution is a never ending process, but there are some cases where humanity has given it a big push.

Hosted by: Michael Aranda

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Sam Lutfi, Bryan Cloer, Kevin Bealer, Christoph Schwanke, Tomás Lagos González, Jason A Saslow, Tom Mosner, Jacob, Ash, Eric Jensen, Jeffrey Mckishen, Alex Hackman, Christopher R Boucher, Piya Shedden, Jeremy Mysliwiec, Chris Peters, Dr. Melvin Sanicas, charles george, Adam Brainard, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:
https://academic.oup.com/jue/article/6/1/juaa010/5828680
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0228881
https://www.smithsonianmag.com/smart-news/urban-coyotes-eat-lot-garbageand-cats-180974461/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7417218/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7417218/
https://research.uga.edu/news/when-country-ibis-become-city-ibis/
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5385025/
https://link.springer.com/article/10.1007/s10393-006-0064-2
https://www.researchgate.net/publication/347621322_Foraging_in_Urban_Environments_Increases_Bactericidal_Capacity_in_Plasma_and_Decreases_Corticosterone_Concentrations_in_White_Ibises
https://www.smithsonianmag.com/smart-news/london-underground-has-its-own-mosquito-subspecies-180958566/
https://www.nature.com/articles/6884120
https://www.science.org/content/article/when-humans-first-plied-deep-blue-sea
https://www.pnas.org/doi/full/10.1073/pnas.2009451118
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4831456/
https://phys.org/news/2016-01-intense-trophy-artificial-evolution-horn.html

https://www.storyblocks.com
https://en.wikipedia.org/wiki/File:C-144_crossing_street_(19896711640).jpg
https://commons.wikimedia.org/wiki/File:Coyote_expansion_by_decade.jpg
https://www.gettyimages.com/detail/photo/coyote-in-sequoia-national-park-royalty-free-image/1189310324?adppopup=true
https://www.gettyimages.com/detail/photo/white-ibis-in-the-grass-royalty-free-image/1379165636?adppopup=true
https://www.gettyimages.com/detail/photo/white-tropical-bird-walking-on-pavers-royalty-free-image/1387548796?adppopup=true
https://commons.wikimedia.org/wiki/File:Ibis-4.jpg
https://www.gettyimages.com/detail/photo/garbage-pile-in-trash-dump-or-landfill-pollution-royalty-free-image/845816364?adppopup=true
https://www.gettyimages.com/detail/photo/preening-ibis-royalty-free-image/144966909?adppopup=true
https://www.gettyimages.com/detail/video/pigeons-along-the-sumida-river-in-tokyo-japan-stock-footage/1169649771
https://en.wikipedia.org/wiki/File:Culex_Molestus.jpg
https://en.wikipedia.org/wiki/File:CulexPipiens.jpg
https://en.wikipedia.org/wiki/File:Blitz_West_End_Air_Shelter.jpg
https://www.gettyimages.com/detail/photo/london-underground-royalty-free-image/1170799912?adppopup=true
https://www.gettyimages.com/detail/photo/great-pyramids-at-giza-royalty-free-image/183274193?adppopup=true
https://www.storyblocks.com/video/stock/man-dumping-halibut-bucking-on-fishing-boat-msyclnp
https://www.gettyimages.com/detail/photo/fly-fishing-royalty-free-image/178508863?adppopup=true
https://en.wikipedia.org/wiki/File:Esox_lucius_ZOO_1.jpg
https://en.wikipedia.org/wiki/File:Northern_pike_caught_on_a_lure_in_lake_Finzula,_Croatia.jpg
https://www.gettyimages.com/detail/video/adventurous-close-up-footage-of-wild-pike-cryptically-stock-footage/1282951882?adppopup=true
https://commons.wikimedia.org/wiki/File:New_Mexico_Bighorn_Sheep.JPG
https://en.wikipedia.org/wiki/File:MAPElNorte023.JPG
https://en.wikipedia.org/wiki/File:Ovis_canadensis_0.jpg
https://www.gettyimages.com/detail/illustration/cartoon-urial-on-a-white-background-flat-royalty-free-illustration/1318619267?adppopup=true
https://www.gettyimages.com/detail/photo/steps-decorated-with-sheep-skulls-at-crete-island-royalty-free-image/1130069234?adppopup=true
https://www.gettyimages.com/detail/photo/trophy-and-horns-from-a-ram-royalty-free-image/1289007938?adppopup=true

## Not All Carnivores Eat Meat
 - [https://www.youtube.com/watch?v=XlAy-yfq-gg](https://www.youtube.com/watch?v=XlAy-yfq-gg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-05-28 00:00:00+00:00

Head to https://linode.com/scishow to get a $100 60-day credit on a new Linode account. Linode offers simple, affordable, and accessible Linux cloud solutions and services.

The name of the order Carnivora means "meat-eaters," and while most of the members of Carnivora live up to that name, there is at least one cute and curious exception.

Hosted by: Michael Aranda

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Sam Lutfi, Bryan Cloer, Kevin Bealer, Christoph Schwanke, Tomás Lagos González, Jason A Saslow, Tom Mosner, Jacob, Ash, Eric Jensen, Jeffrey Mckishen, Alex Hackman, Christopher R Boucher, Piya Shedden, Jeremy Mysliwiec, Chris Peters, Dr. Melvin Sanicas, charles george, Adam Brainard, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:
https://ucmp.berkeley.edu/mammal/carnivora/carnivoralh.html
https://www.sciencedirect.com/science/article/pii/S0960982219303951?via%3Dihub
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3912123
https://www.sciencedirect.com/science/article/pii/S1095643320300350
https://www.theatlantic.com/science/archive/2019/05/giant-panda-closet-carnivore/588553/
https://www.nationalgeographic.com/science/article/bears-and-bamboo-the-fossil-record-of-giant-pandas

Images:
https://www.gettyimages.com/detail/video/panda-cub-eats-bamboo-with-pleasure-stock-footage/1223452552?adppopup=true
https://www.gettyimages.com/detail/video/brown-bear-with-her-two-yearling-cubs-catches-a-sockeye-stock-footage/1331521367?adppopup=true
https://www.gettyimages.com/detail/video/baby-giant-panda-on-the-tree-stock-footage/1060923342?adppopup=true
https://www.gettyimages.com/detail/video/giant-panda-bear-cub-on-a-tree-stock-footage/1024194292?adppopup=true
https://www.gettyimages.com/detail/photo/lion-yawning-on-tree-lazy-lion-is-yawning-while-royalty-free-image/1349096107?adppopup=true
https://www.gettyimages.com/detail/video/closeup-of-giant-panda-stock-footage/473371827?adppopup=true
https://commons.wikimedia.org/wiki/File:Figure_34_01_05ab.jpg
https://www.gettyimages.com/detail/video/panda-cub-eats-bamboo-with-pleasure-stock-footage/1223452552?adppopup=true
https://www.gettyimages.com/detail/photo/cute-panda-biting-and-chewing-bamboo-branches-royalty-free-image/1308916465?adppopup=true
https://www.gettyimages.com/detail/video/capybara-grazing-on-fresh-green-grass-stock-footage/1214686835
https://commons.wikimedia.org/wiki/File:Arundinaria_fargesii_(Bashania_fargesii)_-_Wangjianglou_Park_-_Chengdu,_China_-_DSC05857.jpg
https://www.gettyimages.com/detail/video/video-of-panda-eating-bamboo-shoot-stock-footage/482674051?adppopup=true
https://www.gettyimages.com/detail/video/water-buffalo-on-water-pond-stock-footage/1388892563?adppopup=true
https://www.gettyimages.com/detail/photo/panda-eating-bamboo-royalty-free-image/460637863?adppopup=true
https://www.gettyimages.com/detail/photo/giant-panda-looking-into-camera-holding-green-royalty-free-image/93807916?adppopup=true
https://www.gettyimages.com/detail/video/unique-animal-giant-panda-eats-bamboo-stock-footage/1223452687?adppopup=true


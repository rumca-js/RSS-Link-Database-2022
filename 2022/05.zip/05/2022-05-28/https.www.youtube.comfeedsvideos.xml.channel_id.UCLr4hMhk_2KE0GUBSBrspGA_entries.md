# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Eksperyment na skalę światową i nowa kolekcja!
 - [https://www.youtube.com/watch?v=IgFrHuOsRDo](https://www.youtube.com/watch?v=IgFrHuOsRDo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-05-29 00:00:00+00:00

WIELKI TEST Samsunga Galaxy Z Flip 3 - 2 tura, 13.06.2022-19.06.2022 - https://bit.ly/3PJss7v (KALENDARZ AKTUALNY)
WIELKI TEST Samsunga Galaxy Z Flip 3 - 1 tura, 07.06.2022-12.06.2022 - https://bit.ly/3LWsZjm (KALENDARZ ZAPEŁNIONY)
Link do znosne.pl - https://znosne.pl - start sprzedaży w środę, 1 czerwca

Dziś w odcinku:
00:00 Dobry wieczór
00:25 Reklama nowej kolekcji Znośnych Ciuchów 
02:20 Kolorowe lata 90.
03:58 Mama, jest masakra w szkole
04:33 Afery NFT - Skradziona małpa Setha Green'a
06:00 WIELKI TEST składanych smartfonów!
11:10 Musk chce eliminować kierowców z samochodów
12:00 Pozywanie lepsze niż wychowanie
12:50 Chińczycy chcą strzelać do Starlinka
13:40 Aparaty od Leica w smartfonach Xiaomi
14:26 Śmierć Ray'a Liotty
14:42 Znośnego tygodnia!

Źródła:
Powódź 97 obraz nędzy i rozpaczy: https://bit.ly/3LRYtXT
We Are The World: https://youtu.be/4M7c-JOnPdw
Nic Nie Pomoże: https://youtu.be/f5hooj3qKM4
Skradziona małpa Setha Greena: https://bit.ly/3lVvgkg
https://bit.ly/3PTfIvc
Za rok Tesle bez kierowcy: https://bit.ly/3wZwLnT
Kalifornijscy rodzice będą mogli pozwać TikTok's i Insta: https://bit.ly/3MXDRi4
Chińczycy chcą strzelać do Starlinków: https://bit.ly/3LRTHcM
Xiaomi we współpracy z Leicą: https://bit.ly/38t0NH0
Ten aktor wziął i umarł: https://bbc.in/3N2xOJ2

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Has John Deere been breaking the law for two decades? Little known regulation  1039.125 says yes.
 - [https://www.youtube.com/watch?v=vjPQtZqGwq8](https://www.youtube.com/watch?v=vjPQtZqGwq8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-05-29 00:00:00+00:00

Willie Cade's channel, deerefacts: https://www.youtube.com/channel/UCL8mrwisvetDcBG7cy4wiSw?app=desktop

Regulation: https://www.govinfo.gov/content/pkg/CFR-2012-title40-vol34/pdf/CFR-2012-title40-vol34-sec1039-125.pdf

https://www.law.cornell.edu/cfr/text/40/1039.125

## New York Times contributes to poor Apple self-repair program coverage
 - [https://www.youtube.com/watch?v=YuX3VOGW4kA](https://www.youtube.com/watch?v=YuX3VOGW4kA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-05-28 00:00:00+00:00

https://www.nytimes.com/2022/05/25/technology/personaltech/apple-repair-program-iphone.html

## some time away :)
 - [https://www.youtube.com/watch?v=gfLspwlb0BQ](https://www.youtube.com/watch?v=gfLspwlb0BQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-05-28 00:00:00+00:00




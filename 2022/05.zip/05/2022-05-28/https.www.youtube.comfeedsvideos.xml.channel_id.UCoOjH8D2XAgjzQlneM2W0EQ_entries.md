# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## This is absolutely terrifying.
 - [https://www.youtube.com/watch?v=91UpPsAGoWE](https://www.youtube.com/watch?v=91UpPsAGoWE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2022-05-28 00:00:00+00:00

The first 1,000 people to use the link or my code jaketran will get a 1 month free trial of Skillshare: https://skl.sh/jaketran05221

Go to https://public.com/JakeTran to get a free stock. You’ll get a free stock worth anywhere from $3 to $1,000. 

Visit https://public.com/JakeTran to get a free stock!

✅ Buy our flagship masterclass ✅ Click here ➡️ https://evil.university/war 
😳 Learn the ONE SECRET that has made every giant corporation and government successful 
🤝 Make around $100 per referral with our Hustler's University-style affiliate program
Click here ➡️ https://evil.university/war 

😈 Watch exclusive documentaries that are too controversial to ever be released to the public: https://jake.yt/join 

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🎥 Business is complicated. Subscribe to curiosity: http://bit.ly/jt-sub
📸 Follow me on IG for a chance to win $1,000: @jaketran // http://bit.ly/jt-ig
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this: @jaketran
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this:@jaketran

🍔 Subscribe to our other channel @EvilFoodSupply, where we expose all the evils of our modern diet ➡️ https://jake.yt/evilfood

💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd
🎵 Get unlimited royalty-free music for your videos with Epidemic Sound! ➡️ https://share.epidemicsound.com/jaketran

🍿 OUR MOST VIRAL VIDEOS: 
Nestlé: The Most Evil Business in the World https://youtu.be/rj6JOKrL_vg
BlackRock: The Company that Owns the World https://youtu.be/1n4zkdfKUAE
Recycling is literally a scam https://youtu.be/LELvVUIz5pY
Why do Chinese Billionaires Keep Disappearing? https://youtu.be/qyMsrgI7-_s

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: 

-----------------------

-----------------------

This is a paid endorsement for Open to the Public Investing, member FINRA & SIPC. Not investment advice. Cryptocurrency trading offered by Apex Crypto LLC. Free stock offer for new customers only.  Other fees may apply. Full terms at Public.com/disclosures. Investing involves risk of loss.

Metadata: https://bit.ly/3MhEp21 

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2021 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.


# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Marathon Review
 - [https://www.youtube.com/watch?v=H9rMu1XYB98](https://www.youtube.com/watch?v=H9rMu1XYB98)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2022-05-28 11:04:03+00:00

Before Bungie made Halo, they made Marathon. Then they kept putting Marathon stuff into Halo. Now 343 just sprinkles it in here and there. Praise the Aleph One team for keeping it alive.
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/MandaloreGaming
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
0:00 - Intro
00:14 - Halo and Marathon
02:07 - Aleph One 
03:55 - Game Premise
05:44 - Visuals
07:13 - Music & Sound Design
09:49 - Gameplay Mechanics
20:52 - Story
22:39 - Story (SPOI𝘓ERS)
32:43 - Multiplayer
32:46 - Conclusions
33:38 - Credits
35:50 - Don't Pfhorget to Shoot

#Marathon #MarathonReview #MarathonPC #Bungie #MarathonGame


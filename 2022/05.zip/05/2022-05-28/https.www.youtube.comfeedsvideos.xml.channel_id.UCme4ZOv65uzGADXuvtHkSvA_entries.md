# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 2 Księga Kronik || Rozdział 30
 - [https://www.youtube.com/watch?v=HGVZAoFBCFc](https://www.youtube.com/watch?v=HGVZAoFBCFc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-05-29 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Historie potłuczone [#60] O Paulinie, co jej czaszkę rozłupali
 - [https://www.youtube.com/watch?v=A6La1UZNjZU](https://www.youtube.com/watch?v=A6La1UZNjZU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-05-29 00:00:00+00:00

Historie potłuczone to opowieści o córkach i synach Boga, pięknych i brzydkich, świętych i grzesznych, szczęśliwych i na skraju rozpaczy. To opowieści o drodze, którą idzie się do nieba i o zakrętach i chaszczach, które spychają do piekła. To opowieści o ludziach po prostu. Czyli o nas.

Muzyka: Kai Engel: Brand New World, https://freemusicarchive.org/music/Kai_Engel/Sustains/Kai_Engel_-_Sustains_-_01_Brand_New_World

@Langustanapalmie 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 2 Księga Kronik || Rozdział 29
 - [https://www.youtube.com/watch?v=QYd_TPe_1dw](https://www.youtube.com/watch?v=QYd_TPe_1dw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-05-28 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#290] 72 dziewice albo modlitewnik
 - [https://www.youtube.com/watch?v=jR1CsDibXA8](https://www.youtube.com/watch?v=jR1CsDibXA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-05-28 00:00:00+00:00

#cnn #dobrewiadomości     @Langustanapalmie 

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedziela, VII Tydzień Wielkanocny, Rok C, II
Uroczystość Wniebowstąpienia Pańskiego

1. czytanie (Dz 1, 1-11)

Pierwszą Księgę napisałem, Teofilu, o wszystkim, co Jezus czynił i czego nauczał od początku aż do dnia, w którym dał polecenia apostołom, których sobie wybrał przez Ducha Świętego, a potem został wzięty do nieba. Im też po swojej męce dał wiele dowodów, że żyje: ukazywał się im przez czterdzieści dni i mówił o królestwie Bożym.
A podczas wspólnego posiłku przykazał im nie odchodzić z Jerozolimy, ale oczekiwać obietnicy Ojca:
«Słyszeliście o niej ode Mnie – mówił – Jan chrzcił wodą, ale wy wkrótce zostaniecie ochrzczeni Duchem Świętym».
Zapytywali Go zebrani: «Panie, czy w tym czasie przywrócisz królestwo Izraela?» Odpowiedział im: «Nie wasza to rzecz znać czasy i chwile, które Ojciec ustalił swoją władzą, ale gdy Duch Święty zstąpi na was, otrzymacie Jego moc i będziecie moimi świadkami w Jeruzalem i w całej Judei, i w Samarii, i aż po krańce ziemi».
Po tych słowach uniósł się w ich obecności w górę i obłok zabrał Go im sprzed oczu. Kiedy jeszcze wpatrywali się w Niego, jak wstępował do nieba, przystąpili do nich dwaj mężowie w białych szatach. I rzekli: «Mężowie z Galilei, dlaczego stoicie i wpatrujecie się w niebo? Ten Jezus, wzięty od was do nieba, przyjdzie tak samo, jak widzieliście Go wstępującego do nieba».

2. czytanie (Hbr 9, 24-28; 10, 19-23)

Chrystus wszedł nie do świątyni zbudowanej rękami ludzkimi, będącej odbiciem prawdziwej świątyni, ale do samego nieba, aby teraz wstawiać się za nami przed obliczem Boga, ani nie po to, aby się wielekroć sam miał ofiarować, jak arcykapłan, który co roku wchodzi do świątyni z krwią cudzą, gdyż w takim przypadku musiałby cierpieć wiele razy od stworzenia świata. A tymczasem raz jeden ukazał się teraz na końcu wieków, aby zgładzić grzech przez ofiarę z samego siebie.
A jak postanowione ludziom raz umrzeć, potem zaś sąd, tak Chrystus raz jeden był ofiarowany dla zgładzenia grzechów wielu, drugi raz ukaże się nie w związku z grzechem, lecz dla zbawienia tych, którzy Go oczekują.
Mamy więc, bracia, pewność, iż wejdziemy do Miejsca Świętego przez krew Jezusa. On nam zapoczątkował drogę nową i żywą, przez zasłonę, to jest przez ciało swoje. Mając zaś kapłana wielkiego, który jest nad domem Bożym, przystąpmy z sercem prawym, z wiarą pełną, oczyszczeni na duszy od wszelkiego zła świadomego i obmyci na ciele wodą czystą. Trzymajmy się niewzruszenie nadziei, którą wyznajemy, bo godny jest zaufania Ten, który dał obietnicę.

Ewangelia (Łk 24, 46-53)

Jezus powiedział do swoich uczniów:
«Tak jest napisane: Mesjasz będzie cierpiał i trzeciego dnia zmartwychwstanie; w imię Jego głoszone będzie nawrócenie i odpuszczenie grzechów wszystkim narodom, począwszy od Jeruzalem. Wy jesteście świadkami tego.
Oto Ja ześlę na was obietnicę mojego Ojca. Wy zaś pozostańcie w mieście, aż będziecie przyobleczeni w moc z wysoka».
Potem wyprowadził ich ku Betanii i podniósłszy ręce, błogosławił ich. A kiedy ich błogosławił, rozstał się z nimi i został uniesiony do nieba.
Oni zaś oddali Mu pokłon i z wielką radością wrócili do Jeruzalem, gdzie stale przebywali w świątyni, wielbiąc i błogosławiąc Boga.

________________________________________

Niedzielnik*. Komentarze do czytań na uroczystości:
→ https://wdrodze.pl/produkt/niedzielnik-komentarze-do-czytan-na-uroczystosci/

________________________________________

Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

________________________________________

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1104] Korzyść
 - [https://www.youtube.com/watch?v=pLgQ2u2hG7s](https://www.youtube.com/watch?v=pLgQ2u2hG7s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-05-28 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP

________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Samsung, STOP CHEATING - S95B QD-OLED
 - [https://www.youtube.com/watch?v=v9nd4tAbz4E](https://www.youtube.com/watch?v=v9nd4tAbz4E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-05-29 00:00:00+00:00

Receive a $25 credit for Ting Mobile today when you sign up at https://linus.ting.com/

Get the Anycubic Photon M3 at their Official store for 21% OFF NOW at https://bit.ly/3LNaYE6 or on Amazon at https://amzn.to/38LSbvs

Will the TVs live up to the QD OLED hype? The first one is here, and it looks great but is Samsung fluffing up their numbers a little bit on the S95B?

Discuss on the forum: https://linustechtips.com/topic/1434013-samsung-stop-cheating/

Buy the Samsung S95B 65": https://geni.us/efBFjZ

Buy the LG G2 OLED 65": https://geni.us/1bvog

Buy the Sony A95K 65": https://lmg.gg/XeERs

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Why, Samsung?!?!
1:02 The Samsung scandal
3:23 How do you turn this off?
4:30 I/O
4:58 Samsung's TV interface sucks lol
6:03 Update!
6:39 This TV looks great
8:59 Audio is pretty good too
10:33 Does Samsung get a pass?
10:45 Gaming
14:38 Final Thoughts

## AMD Says You’re Doing it Wrong. - Best settings for AMD GPUs
 - [https://www.youtube.com/watch?v=RxjRyN-4VdI](https://www.youtube.com/watch?v=RxjRyN-4VdI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-05-28 00:00:00+00:00

Thanks to AMD for sponsoring this video! Learn more at https://lmg.gg/WAdzj

Buy an AMD Ryzen 7 5800X3D: https://geni.us/tnn0GBY

Buy an AMD Radeon RX 6950 XT: https://lmg.gg/brtnL

Buy an AMD Ryzen 7 5700X: https://geni.us/iIZeLJB

Buy an AMD Radeon RX 6750 XT: https://geni.us/DG0UoTU

Buy an AMD Ryzen 5 5600: https://geni.us/B6xE

Buy an AMD Radeon RX 6650 XT: https://geni.us/5Gz0n7

Buy an ROG Ryujin 240: https://geni.us/iIoj

Buy an ROG Thor 850W: https://geni.us/hm8kxQc

Buy a Corsair MP600: https://geni.us/hTIiyh

Buy a kit of Vengeance RGB 3600 16GB RAM: https://geni.us/epcOV

Buy an ROG Strix X570-E Gaming Wifi: https://geni.us/Z6oTluT

Buy a HYTE Y60 Mid-Tower: https://geni.us/8pV13t

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1433822-amd-says-you%E2%80%99re-doing-it-wrong/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:08 Undervolt
3:28 Smart Access Memory
4:16 Resize BAR
4:50 RSR
5:50 Benchmarking
8:41 Conclusion


# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Drogi ojcze, droga matko, czyli kiedy dzieci muszą płacić za rodziców
 - [https://tvn24.pl/premium/alimenty-na-rodzica-kiedy-dzieci-musza-je-placic-prawdziwe-historie-5676775?source=rss](https://tvn24.pl/premium/alimenty-na-rodzica-kiedy-dzieci-musza-je-placic-prawdziwe-historie-5676775?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-05-28 10:00:00+00:00

<img alt="Drogi ojcze, droga matko, czyli kiedy dzieci muszą płacić za rodziców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h592v7-img3582-5727739/alternates/LANDSCAPE_1280" />
    Co zwykle pisze się w listach pożegnalnych? - Nie wiem. Mi tata napisał: "tylko nie próbuj mi szkodzić!" i zapadł się pod ziemię. Ale to nie był ostatni list, jaki od niego dostałem. Dwadzieścia lat później przyszedł kolejny. Pozew o alimenty.


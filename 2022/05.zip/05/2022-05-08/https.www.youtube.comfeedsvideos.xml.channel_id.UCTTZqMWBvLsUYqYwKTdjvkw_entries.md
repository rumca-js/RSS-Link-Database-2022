# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Drama DuckDuckGo - czy nadal ufać?
 - [https://www.youtube.com/watch?v=x2HEm1k4388](https://www.youtube.com/watch?v=x2HEm1k4388)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2022-05-08 00:00:00+00:00

🦆 Według wielu DuckDuckGo miało być uniwersalną odpowiedzią na problem cenzury i braku prywatności w Internecie. Czy DuckDuckGo poszło w ślady innych, tworzących bańki informacyjne i polaryzujących społeczeństwo? A może to nadmuchana sztucznie aferka i nie mamy się czego obawiać?

Zapraszam!

Źródła:
🦆 Skąd @duckduckgo2597 bierze swoje wyniki?
https://bit.ly/3xS9lS4

🔄 Zmiany w DuckDuckGo walczące z dezinformacją irytują użytkowników
https://bit.ly/37FVzrc

💔 DuckDuckGo psuje wyniki wyszukiwania…
https://bit.ly/3EVmzyX

🔧 …a potem je naprawia.
https://bit.ly/38nYwMS

🌋 Usunięcie !bangs
https://bit.ly/3rSLuOo

🐘 @Vox recode o prawicowej obsesji związanej z DuckDuckGo
https://bit.ly/3kc6lb5

❓ Które wyszukiwarki mają najmniej ograniczeń?
https://bit.ly/38ulMZS

⚖️ Jak historia wyszukiwania może być użyta przeciw komuś
https://bit.ly/3rSqIhU

⚔️ DuckDuckGo walczy o prywatność
https://bit.ly/3LkXi3J

🍏 Przeglądarka DuckDuckGo dla macOS
https://bit.ly/36M7d34 / https://bit.ly/3ELCq36

📊 Prezentacja na @mediacccde o wpływie algorytmu Facebooka na społeczeństwo
https://bit.ly/3yqA602

Jeżeli nie ufasz skracanym linkom (bardzo dobrze!) to dodaj na ich końcu plusik ‘+’.
W ten sposób podejrzysz na stronie bit.ly dokąd prowadzą.

Relevant xkcd: https://xkcd.com/537/

© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.

Dziękuję za Waszą uwagę. ❤️

Znajdziecie mnie również na;
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok
Linkedinie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok
Podcasty na;
Anchor https://anchor.fm/mateusz-chrobok
Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR
Apple Podcasts https://apple.co/3OwjvOh

Rozdziały:
00:00 Intro
00:35 Historia
01:37 Google
03:46 Cenzura
05:01 Torrent
07:11 !bang
09:05 Ranking
10:57 Co Robić i Jak Żyć?

#cyberbezpieczeństwo


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Video Game Things You Weren't SUPPOSED TO DO
 - [https://www.youtube.com/watch?v=FYuXbRf0rq4](https://www.youtube.com/watch?v=FYuXbRf0rq4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-05-09 00:00:00+00:00

Some video games have things that you just should not do. Here are some fun examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 20 CRAZIEST INVISIBLE WALLS in Video Games
 - [https://www.youtube.com/watch?v=SCl4MaG2zGE](https://www.youtube.com/watch?v=SCl4MaG2zGE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-05-08 00:00:00+00:00

Invisible walls are a game developer's way of keeping you within a game's boundaries, and oftentimes they can be pretty clever.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


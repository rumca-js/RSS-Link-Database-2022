# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## OnePlus 11: what we want to see
 - [https://www.techradar.com/news/oneplus-11/](https://www.techradar.com/news/oneplus-11/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-05-08 05:00:02+00:00

Here's what we know, and what we want to see, in the OnePlus 11, which will likely be the company's top phone of 2023.

## OnePlus 11: what we want to see
 - [https://www.techradar.com/news/oneplus-11](https://www.techradar.com/news/oneplus-11)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-05-08 05:00:02+00:00

Here's what we know, and what we want to see, in the OnePlus 11, which will likely be the company's top phone of 2023.


## Hundreds of Suicidal Teens Sleep in Emergency Rooms. Every Night. - The New York Times
 - [https://www.nytimes.com/2022/05/08/health/emergency-rooms-teen-mental-health.html](https://www.nytimes.com/2022/05/08/health/emergency-rooms-teen-mental-health.html)
 - RSS feed: https://www.nytimes.com
 - date published: 2022-05-08 14:58:19.864834+00:00

With inpatient psychiatric services in short supply, adolescents are spending days, even weeks, in hospital emergency departments awaiting the help they desperately need.

## Amazon Fires Senior Managers Tied to Unionized Staten Island Warehouse - The New York Times
 - [https://www.nytimes.com/2022/05/06/technology/amazon-fires-managers-union-staten-island.html](https://www.nytimes.com/2022/05/06/technology/amazon-fires-managers-union-staten-island.html)
 - RSS feed: https://www.nytimes.com
 - date published: 2022-05-08 06:59:02.741911+00:00

Company officials said the terminations were the result of an internal review, while the fired managers saw it as a response to the recent union victory.


## Looking for a job while looking after yourself
 - [https://carol.gg/blog/looking-for-a-job/](https://carol.gg/blog/looking-for-a-job/)
 - RSS feed: https://carol.gg
 - date published: 2022-05-08 15:57:00.165179+00:00




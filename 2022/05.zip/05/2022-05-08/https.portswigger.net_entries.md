## WordPress sites getting hacked ‘within seconds’ of TLS certificates being issued | The Daily Swig
 - [https://portswigger.net/daily-swig/wordpress-sites-getting-hacked-within-seconds-of-tls-certificates-being-issued](https://portswigger.net/daily-swig/wordpress-sites-getting-hacked-within-seconds-of-tls-certificates-being-issued)
 - RSS feed: https://portswigger.net
 - date published: 2022-05-08 18:37:21.459129+00:00

Attackers pounce before site owners can activate the installation wizard


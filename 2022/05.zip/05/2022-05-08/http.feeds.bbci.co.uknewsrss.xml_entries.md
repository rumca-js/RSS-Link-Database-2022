# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Eurovision: How the song contest is bringing Europe together again
 - [https://www.bbc.co.uk/news/newsbeat-61325305?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-61325305?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 23:46:14+00:00

The 66th edition of the song contest is bringing fans and artists together in more ways than one.

## From handshakes to hostilities: How dangerous is the situation in North Korea?
 - [https://www.bbc.co.uk/news/world-asia-61331859?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-61331859?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 23:08:39+00:00

South Korea's incoming president promises to take a hard line on North Korea’s military escalations.

## 'I pull dirty nappies from people's recycling'
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-61262705?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-61262705?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 23:04:15+00:00

Staff at a £14m recycling facility help manually sort through 85,000 tonnes of waste each year.

## Ukraine war: Artist George Butler sketches conflict
 - [https://www.bbc.co.uk/news/entertainment-arts-61347805?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-61347805?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 23:01:23+00:00

Artist George Butler has recently returned to the UK after a month spent in Ukraine.

## Is it fair for fantasy football managers to rely on AI?
 - [https://www.bbc.co.uk/news/business-61257368?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61257368?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 22:49:29+00:00

Some managers think artificial intelligence helps remove their bias but others think it's cheating.

## 'Everyone supports Liverpool', says Manchester City boss Pep Guardiola
 - [https://www.bbc.co.uk/sport/football/61373787?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61373787?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 20:12:21+00:00

Pep Guardiola says "everyone in the country supports Liverpool" after Manchester City moved three points clear in the Premier League.

## Election results 2022: How the parties performed in maps and charts
 - [https://www.bbc.co.uk/news/uk-politics-61344176?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61344176?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 19:58:34+00:00

Party performance, seat gains, council changes and more all presented in maps and charts.

## Ukraine war: School hit and dignitaries - and Bono - in Kyiv - Sunday's round-up
 - [https://www.bbc.co.uk/news/world-europe-61372842?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61372842?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 19:32:32+00:00

Civilians sheltering at a school in Ukraine are targeted as Western leaders pledge more support for Ukraine - your round-up.

## Heineken Champions Cup: Premiership cap hinders English teams - Alex Sanderson
 - [https://www.bbc.co.uk/sport/rugby-union/61371950?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/61371950?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 19:30:57+00:00

Sale Sharks' Alex Sanderson says the lower Premiership salary cap is making it harder for English teams to compete with French sides in Europe.

## Bafta TV Awards 2022: The winners in full
 - [https://www.bbc.co.uk/news/entertainment-arts-60925307?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60925307?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 18:10:52+00:00

Find out if your favourite TV programmes and actors have won a Bafta at Sunday's ceremony.

## Ncuti Gatwa: BBC names actor as next Doctor Who star
 - [https://www.bbc.co.uk/news/uk-61371123?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61371123?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 17:49:54+00:00

The star of Netflix's Sex Education will replace Jodie Whittaker in the BBC science fiction show.

## NI election results 2022: Governments urge parties to reform executive
 - [https://www.bbc.co.uk/news/uk-northern-ireland-61367403?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-61367403?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 12:51:47+00:00

Northern Ireland Secretary Brandon Lewis plays down the prospect of an Irish border poll.

## EasyJet to take out seats so it can fly with fewer crew
 - [https://www.bbc.co.uk/news/business-61370175?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61370175?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 12:17:23+00:00

The airline plans to remove a row of seats so that it can fly with fewer cabin crew on board.

## Nothing off table over NI protocol - Raab
 - [https://www.bbc.co.uk/news/uk-61370346?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61370346?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 12:10:58+00:00

The deputy prime minister says the protocol agreed with the EU is an "obstacle to stability" in Northern Ireland.

## Keir Starmer guilty of hypocrisy over Durham lockdown event, says Dominic Raab
 - [https://www.bbc.co.uk/news/uk-politics-61369911?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61369911?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 11:00:08+00:00

But Labour's Lisa Nandy says it is "absurd" to compare Sir Keir's actions to the PM's "serial partying".

## Is Nato's Nordic expansion a threat or boost to Europe?
 - [https://www.bbc.co.uk/news/world-europe-61369963?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61369963?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 09:45:43+00:00

The BBC's security correspondent Frank Gardner looks at the case for and against Finland and Sweden joining Nato.

## Elections 2022: Boris Johnson's union headache just got worse
 - [https://www.bbc.co.uk/news/uk-politics-61367503?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61367503?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 08:10:26+00:00

Strains on the United Kingdom are laid bare by a remarkable set of election results, writes Chris Mason.

## Painting could be first 'genuine' image of Oliver Cromwell's mum
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-61347711?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-61347711?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 06:35:26+00:00

A portrait stored in an attic could be the first genuine image of the Civil War leader's mother.

## Covid: 'I'm blind in one eye after cancelled pandemic appointments'
 - [https://www.bbc.co.uk/news/uk-wales-61257996?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61257996?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 06:03:35+00:00

Janet Harris believes her sight could have been saved if appointments continued during the pandemic.

## Saul 'Canelo' Alvarez v Dmitry Bivol: Mexican superstar suffers shock defeat by Russian champion
 - [https://www.bbc.co.uk/sport/boxing/61369049?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/61369049?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 06:02:04+00:00

Mexican superstar Saul 'Canelo' Alvarez suffered a shock points decision defeat as Russia's Dmitry Bivol retained his WBA light-heavyweight title in Las Vegas.

## NI election results 2022: Who are the Alliance Party and what do they stand for?
 - [https://www.bbc.co.uk/news/uk-northern-ireland-61362593?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-61362593?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 05:36:42+00:00

The party has become the third biggest in the Northern Ireland Assembly for the first time.

## Why is the DUP against the Northern Ireland Protocol?
 - [https://www.bbc.co.uk/news/uk-northern-ireland-61366306?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-61366306?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 05:31:45+00:00

The party says it will not allow a new government to form unless changes are made to the Brexit deal.

## Ukraine war: Returning to the place my father was killed
 - [https://www.bbc.co.uk/news/world-europe-61351772?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61351772?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 05:01:00+00:00

As Vadim and his father tried to rescue their dogs, they were fired upon by a convoy they believe was Russian.

## Ukraine war: Rebuilt Kyiv railway bridge a symbol of hope
 - [https://www.bbc.co.uk/news/world-europe-61365365?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61365365?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 04:57:27+00:00

A railway bridge close to Kyiv has been rebuilt, just a month after it was destroyed by Russian attacks.

## Ukraine war: 'If this is true, then I am also a Nazi'
 - [https://www.bbc.co.uk/news/world-europe-61361827?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61361827?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 04:47:05+00:00

Holocaust survivors in the Ukrainian city of Uman feel insulted by Russian claims to be fighting Nazis.

## John Lee: The ex-security chief who became Hong Kong's leader
 - [https://www.bbc.co.uk/news/world-asia-china-61267490?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-61267490?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 04:32:03+00:00

Known for his pro-Beijing hardline views, he has hinted that he will prioritise security issues.

## New Mexico wildfire: Huge blaze could worsen this weekend
 - [https://www.bbc.co.uk/news/world-latin-america-61367797?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-61367797?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 03:26:58+00:00

"Historic" extreme weather likely to stoke New Mexico fire, which is already the size of Chicago.

## Miami Grand Prix: Max Verstappen criticises Red Bull reliability issues
 - [https://www.bbc.co.uk/sport/formula1/61367767?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/61367767?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 00:32:00+00:00

Max Verstappen criticises his Red Bull team's reliability struggles after qualifying at the Miami Grand Prix.

## How young entrepreneurs bounced back from Covid
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-61039233?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-61039233?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-08 00:16:06+00:00

How have young business people found the comeback from coronavirus lockdowns?


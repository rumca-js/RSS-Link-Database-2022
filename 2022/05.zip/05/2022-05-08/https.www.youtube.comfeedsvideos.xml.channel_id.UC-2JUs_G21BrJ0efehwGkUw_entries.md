# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Put Your Records On | Corrine Bailey Rae | FUNK cover ft. @louisism
 - [https://www.youtube.com/watch?v=7ZnUtNZbiwU](https://www.youtube.com/watch?v=7ZnUtNZbiwU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-05-09 00:00:00+00:00

Don't miss your only chance to get Frisky Business on vinyl! Sign up to Vinyl Club by May 31st to reserve your copy! http://modal.scarypocketsfunk.com/patreon

Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Corinne Bailey Rae's "Put Your Records On" by Scary Pockets & Louis Cato.

MUSICIAN CREDITS
Lead vocal, bgvs, tambo: Louis Cato
Keys: Jacob Collier & Jack Conte
Drums: Elizabeth Goodfellow
Bass: Joe Ayoub
Trombone: Josh Brown
Trumpet: CJ Camerieri
Saxophone: Jacob Scesney
Guitars: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Nate Cuboi
Editor: Adam Kritzberg

SKETCH CREDITS
Director/Production Designer: Ryan Wagner
Script: Luke Wagner
Lisa/Bride: Allison Spence Brown
Rabbi: James Gadson
DP: Matt Burke
Sound: Anthony Newen
Editor: Jude Smith

Recorded Live at Apogee Studio in Los Angeles, CA.

#ScaryPockets #Funk #LouisCato #JacobCollier #CorinneBaileyRae #PutYourRecordsOn


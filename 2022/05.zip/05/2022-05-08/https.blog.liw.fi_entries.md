## Unix command line conventions over time
 - [https://blog.liw.fi/posts/2022/05/07/unix-cli/](https://blog.liw.fi/posts/2022/05/07/unix-cli/)
 - RSS feed: https://blog.liw.fi
 - date published: 2022-05-08 08:01:25+00:00




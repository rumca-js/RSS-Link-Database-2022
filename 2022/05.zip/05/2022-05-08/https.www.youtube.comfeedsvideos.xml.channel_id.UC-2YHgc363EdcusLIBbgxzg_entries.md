# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Man With A 7-Second Memory | Answers With Joe
 - [https://www.youtube.com/watch?v=pcPFQ-daxlQ](https://www.youtube.com/watch?v=pcPFQ-daxlQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-05-09 00:00:00+00:00

Go to https://buyraycon.com/joescott for 15% off your order! Brought to you by Raycon.
Clive Wearing lives life 7 seconds at a time. That's because he has both retrograde and anterograde amnesia, which means he has no ability to form new memories and remembers nothing of his life before. It's hard to imagine what it's like to live like this, but his condition teaches us a lot about how we form memories and how the structure of the brain structures our lives.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPGzF
Apple Podcasts 👉 https://apple.co/3j94kfq
Google Podcasts 👉 https://bit.ly/3qZCo1V

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

Life Without Memory: The Case Of Clive Wearing
https://youtu.be/nFoUvF9PiWo

The Man With The 7-Second Memory
https://youtu.be/k_P7Y0-wgos

https://www.newyorker.com/magazine/2007/09/24/the-abyss

H.M. video:
https://youtu.be/SrmU8P3kBvM

https://en.wikipedia.org/wiki/Kent_Cochrane

https://www.sciencedirect.com/science/article/abs/pii/S0028393204002696?via%3Dihub

http://www.brainobservatory.org


TIMESTAMPS:
0:00 - Intro
2:05 - About Clive
6:50 - What Happened To Him
7:50 - Different Types Of Memory
9:19 - Tangent Cam
10:07 - His Musical Ability
12:25 - His Marriage
13:13 - H.M.
14:40 - Kent Cochrane
15:45 - Scott Bolzman
16:40 - Final Thoughts on Clive


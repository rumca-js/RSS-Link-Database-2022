## Apple's Director of Machine Learning Resigns Due to Return to Office Work - MacRumors
 - [https://www.macrumors.com/2022/05/07/apple-director-of-machine-learning-resigns/](https://www.macrumors.com/2022/05/07/apple-director-of-machine-learning-resigns/)
 - RSS feed: https://www.macrumors.com
 - date published: 2022-05-08 07:44:17.751855+00:00

Apple's director of machine learning, Ian Goodfellow, has resigned from his role a little over four years after he joined the company after...


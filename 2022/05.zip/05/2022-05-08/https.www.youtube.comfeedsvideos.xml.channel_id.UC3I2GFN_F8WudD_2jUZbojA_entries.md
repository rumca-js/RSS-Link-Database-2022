# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Yard Act - Dark Days (Live on KEXP)
 - [https://www.youtube.com/watch?v=uZpuliuQ3LA](https://www.youtube.com/watch?v=uZpuliuQ3LA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-09 00:00:00+00:00

http://KEXP.ORG presents Yard Act performing “Dark Days” live in the KEXP studio. Recorded April 18, 2022.

James Smith - Vocals
Ryan Needham - Bass
Sam Shjipstone - Guitar
Jay Russell - Drums

Host: Troy Nelson
Audio Engineers: Pete Flinton & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Alaia D’Alessandro
Editor: Jim Beckmann

https://yardactors.com
http://kexp.org

## Yard Act - Dead Horse (Live on KEXP)
 - [https://www.youtube.com/watch?v=EcGtT2_aCI0](https://www.youtube.com/watch?v=EcGtT2_aCI0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-09 00:00:00+00:00

http://KEXP.ORG presents Yard Act performing “Dead Horse” live in the KEXP studio. Recorded April 18, 2022.

James Smith - Vocals
Ryan Needham - Bass
Sam Shjipstone - Guitar
Jay Russell - Drums

Host: Troy Nelson
Audio Engineers: Pete Flinton & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Alaia D’Alessandro
Editor: Jim Beckmann

https://yardactors.com
http://kexp.org

## Yard Act - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=AuXV5ULX0RE](https://www.youtube.com/watch?v=AuXV5ULX0RE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-09 00:00:00+00:00

http://KEXP.ORG presents Yard Act performing live in the KEXP studio. Recorded April 18, 2022.

Songs:
Dead Horse
Dark Days
Rich
Land Of The Blind

James Smith - Vocals
Ryan Needham - Bass
Sam Shjipstone - Guitar
Jay Russell - Drums

Host: Troy Nelson
Audio Engineers: Pete Flinton & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Alaia D’Alessandro
Editor: Jim Beckmann

https://yardactors.com
http://kexp.org

## Yard Act - Land Of The Blind (Live on KEXP)
 - [https://www.youtube.com/watch?v=y-n5N8DrkZQ](https://www.youtube.com/watch?v=y-n5N8DrkZQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-09 00:00:00+00:00

http://KEXP.ORG presents Yard Act performing “Land Of The Blind” live in the KEXP studio. Recorded April 18, 2022.

James Smith - Vocals
Ryan Needham - Bass
Sam Shjipstone - Guitar
Jay Russell - Drums

Host: Troy Nelson
Audio Engineers: Pete Flinton & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Alaia D’Alessandro
Editor: Jim Beckmann

https://yardactors.com
http://kexp.org

## Yard Act - Rich (Live on KEXP)
 - [https://www.youtube.com/watch?v=VRKnMLf8ZJ4](https://www.youtube.com/watch?v=VRKnMLf8ZJ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-09 00:00:00+00:00

http://KEXP.ORG presents Yard Act performing “Rich” live in the KEXP studio. Recorded April 18, 2022.

James Smith - Vocals
Ryan Needham - Bass
Sam Shjipstone - Guitar
Jay Russell - Drums

Host: Troy Nelson
Audio Engineers: Pete Flinton & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Alaia D’Alessandro
Editor: Jim Beckmann

https://yardactors.com
http://kexp.org


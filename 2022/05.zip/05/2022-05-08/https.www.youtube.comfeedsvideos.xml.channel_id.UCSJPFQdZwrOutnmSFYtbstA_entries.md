# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Doctor Strange In The Multiverse Of Madness - It's A Bit Of A Mess
 - [https://www.youtube.com/watch?v=5zggDqLGCk8](https://www.youtube.com/watch?v=5zggDqLGCk8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-05-09 00:00:00+00:00

So now that I've seen Doctor Strange 2, I can say truthfully that it looked great, it had a great director and great actors. The only thing missing was a great script. 

Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker


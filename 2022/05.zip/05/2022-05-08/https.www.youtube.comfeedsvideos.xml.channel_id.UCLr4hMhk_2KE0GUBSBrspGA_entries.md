# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Pokaż mi swój smartfon, a powiem Ci jakim kierowcą jesteś
 - [https://www.youtube.com/watch?v=vpz9GoiF4Vc](https://www.youtube.com/watch?v=vpz9GoiF4Vc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-05-08 00:00:00+00:00

#TechWeek
Dziś w odcinku:
00:00 Wstęp
00:20 Dobry wieczór
00:25 Pokaż mi swój smartfon, a powiem Ci jakim kierowcą jesteś
00:45 iPhone a "negatywny penis"
01:22 Badania iOS vs Android
03:30 Launcher od Nothing
04:09 Drama Gates vs Musk
05:30 Saga Twittera Muska
07:32 Dlaczego Zarząd Sprzedał Twittera?
09:41 Przeszczep mikroorganizmów fekalnych pozwala odwrócić proces starzenia się
10:40 Nowe słuchawki od Sony: WH-1000XM5
11:04 Nowy dron od DJI
11:20 Dronik Pixy
11:36 Make latanie dronem Great Again
13:01 Pożegnanie
13:08 Znośnego tygodnia!

Źródła:
Właściciele smartfonów z androidem jeżdżą bezpieczniej: https://bit.ly/39PnGoB
Nothing Launcher: https://bit.ly/39MmEtm
Bill Gates vs Elon Musk: https://cnb.cx/3P84hPR
Gates w ciąży: https://bit.ly/3vTsqlz
Huragany jednak zagrażają tunelom: https://bit.ly/3vUfSdK
Jack Dorsey uważa, że Musk to najlepsze rozwiązanie dla Twittera: https://bit.ly/3kRnh76
Parag Agrawal (ten, co go wszystko cieszy): https://bit.ly/3MY3MFZ
Przeszczep mikroorganizmów fekalnych cofa proces starzenia: https://bit.ly/3P8dJCu
Tyle godzin powinno się spać: https://bit.ly/3Pa9tmm
Sony WH1000 XM5 przecieki: https://bit.ly/3kTcUQ8
DJI Mini 3 Pro pierwszy film: https://bit.ly/3KQYnPz
Dron Pixy recka The Verge: https://bit.ly/3kS2uAs
Drony przyszłości: https://bit.ly/3vSGICQ

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


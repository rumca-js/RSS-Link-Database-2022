# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Amiga Jungilism, Spot, tEiS & XSM - 1st Fracture (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=jZAKznHvlm8](https://www.youtube.com/watch?v=jZAKznHvlm8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-05-08 00:00:00+00:00

"1st Fracture" by Amiga Jungilism, Spot, tEiS & XSM/Up Rough, 6th at Gerp 2022. Art "Inner Fear" by Vasyl/Joker, 7th at Revision 2022.

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.

## IT music: Shake - Watashino Shiroi Usagi (AWE64 Gold)
 - [https://www.youtube.com/watch?v=Fe-Kk_F1MvM](https://www.youtube.com/watch?v=Fe-Kk_F1MvM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-05-08 00:00:00+00:00

"Watashino Shiroi Usagi" (1998) by Shake/Lactic Acid (Sakari Heikkilä). Art of unknown title (1993) by Walt/Melon Dezign, 5th at Saturne Party 1.

- Retro PC circa 2002. MS-DOS 7.1 (Win98SE), Athlon XP 2200+ etc.
- Impulse Tracker 2.14v5 and AWE64 Gold CT4390 (as SB16) analog out
- Maxed out channels (/L256)
- 32-bit interpolation and 45454 mixing rate, filter and feedback disabled
- MIXERSET.EXE treble and bass in neutral position (no fade or boost)


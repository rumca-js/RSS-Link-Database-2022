# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## An American woman stricken at a resort in the Bahamas is now hospitalized in Miami, official says
 - [https://www.cnn.com/2022/05/08/americas/sandals-resort-bahamas-american-deaths/index.html](https://www.cnn.com/2022/05/08/americas/sandals-resort-bahamas-american-deaths/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 21:36:34+00:00

An American woman hospitalized on Friday in the Bahamas, where three other Americans died of unknown causes at a Sandals resort, has since left the country and is now being treated at a hospital in Miami, Royal Bahamas Police Force Commissioner Paul Rolle said.

## Dozens feared dead after Russia bombs school where Ukrainians were sheltering, official says
 - [https://www.cnn.com/2022/05/08/europe/luhansk-school-bombing-ukraine-russia-intl/index.html](https://www.cnn.com/2022/05/08/europe/luhansk-school-bombing-ukraine-russia-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 20:46:22+00:00

About 60 people are feared dead after a Russian aircraft dropped a bomb on a school in Luhansk, eastern Ukraine, where civilians were sheltering on Saturday afternoon, a Ukrainian official said.

## Six new species of miniature frog have been discovered in Mexico
 - [https://www.cnn.com/2022/05/08/world/new-miniature-frog-species-scn-trnd/index.html](https://www.cnn.com/2022/05/08/world/new-miniature-frog-species-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 19:38:13+00:00

They're tiny, adorable and endangered: Six new species of miniature frog have been discovered in Mexico by researchers from the University of Cambridge, London's Natural History Museum and the University of Texas at Arlington.

## Manchester City thrash Newcastle to seize on Liverpool's slip-up in title race
 - [https://www.cnn.com/2022/05/08/football/manchester-city-newcastle-premier-league-spt-intl/index.html](https://www.cnn.com/2022/05/08/football/manchester-city-newcastle-premier-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 18:00:55+00:00

Manchester City licked the wounds of its heartbreaking Champions League exit by taking a step towards the Premier League title with a dominant 5-0 victory over Newcastle United on Sunday.

## Two suspects arrested after Israeli Independence Day attack leaves three dead
 - [https://www.cnn.com/2022/05/06/middleeast/israel-terror-attack-funerals-intl/index.html](https://www.cnn.com/2022/05/06/middleeast/israel-terror-attack-funerals-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 16:49:42+00:00

Israeli security services say they arrested two suspects Sunday following a gun and axe attack Thursday night in the central Israeli city of Elad, which left three people dead.

## 'Sex Education' actor Ncuti Gatwa named as next 'Doctor Who' lead
 - [https://www.cnn.com/2022/05/08/entertainment/doctor-who-ncuti-gatwa-intl-scli/index.html](https://www.cnn.com/2022/05/08/entertainment/doctor-who-ncuti-gatwa-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 16:34:10+00:00

Ncuti Gatwa, who is best known for his performance in Netflix's "Sex Education," will replace Jodie Whittaker as the next lead in "Doctor Who," the BBC announced Sunday.

## Bill Gates says preventing next pandemic will cost $1 billion a year
 - [https://www.cnn.com/videos/health/2022/05/08/bill-gates-germ-organization-next-pandemic-plan-gps-vpx.cnn](https://www.cnn.com/videos/health/2022/05/08/bill-gates-germ-organization-next-pandemic-plan-gps-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 16:04:44+00:00

CNN's Fareed Zakaria speaks with Microsoft founder and philanthropist Bill Gates about how his Global Epidemic Response and Mobilization plan could help prevent the next pandemic.

## Zelensky's iconic fleece sold for more than $100,000 at Ukraine fundraiser
 - [https://www.cnn.com/2022/05/08/world/zelensky-fleece-auction-fundraiser-trnd/index.html](https://www.cnn.com/2022/05/08/world/zelensky-fleece-auction-fundraiser-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 15:11:00+00:00

A fleece jacket worn and signed by Ukrainian President Volodymyr Zelensky sold for £90,000, or around $111,000, at a fundraiser for Ukraine in London on Thursday.

## 'SNL' takes on Roe v. Wade and abortion laws
 - [https://www.cnn.com/2022/05/08/media/snl-roe-v-wade-cold-open/index.html](https://www.cnn.com/2022/05/08/media/snl-roe-v-wade-cold-open/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 15:07:59+00:00

Heading into the final month of its season, "Saturday Night Live" took on the biggest story of the week: Politico obtaining a draft of a majority opinion written by Supreme Court Justice Samuel Alito that would overturn Roe v. Wade.

## First lady Jill Biden makes unannounced trip to Ukraine
 - [https://www.cnn.com/2022/05/08/politics/jill-biden-ukraine-visit/index.html](https://www.cnn.com/2022/05/08/politics/jill-biden-ukraine-visit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 15:03:28+00:00

First lady Jill Biden spent part of Mother's Day making a publicly unannounced trip to Uzhhorod, Ukraine, a small city in the far southwestern corner of Ukraine, a country that for the last 10 weeks has been under invasion by Russia.

## Rare case of monkeypox reported in England, UKHSA says
 - [https://www.cnn.com/2022/05/08/uk/uk-monkeypox-case/index.html](https://www.cnn.com/2022/05/08/uk/uk-monkeypox-case/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 14:07:15+00:00

A rare case of monkeypox has been diagnosed in a patient in England, the UK Health Security Agency said in a statement Saturday.

## 'Doctor Strange' offers a preview of Marvel's next big creative challenge -- and opportunity
 - [https://www.cnn.com/2022/05/08/entertainment/marvel-doctor-strange-next-challenges/index.html](https://www.cnn.com/2022/05/08/entertainment/marvel-doctor-strange-next-challenges/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 13:49:03+00:00

The best scene in "Doctor Strange in the Multiverse of Madness" takes place in an alternate universe, but it previews the biggest opportunities for Marvel in this one, as well as the major challenges at the top of its to-do list.

## Canelo Alvarez stunned by Russia's Dmitry Bivol as he suffers just second defeat of career
 - [https://www.cnn.com/2022/05/08/sport/canelo-alvarez-dmitry-bivol-boxing-spt-intl/index.html](https://www.cnn.com/2022/05/08/sport/canelo-alvarez-dmitry-bivol-boxing-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 13:30:41+00:00

Canelo Alvarez was stunned on Saturday night, as he was beaten by Russian fighter Dmitry Bivol in their light heavyweight title clash in Las Vegas.

## Teenager beats Djokovic in Madrid Open epic
 - [https://www.cnn.com/2022/05/08/tennis/carlos-alcaraz-real-madrid-open-djokovic-spt-intl/index.html](https://www.cnn.com/2022/05/08/tennis/carlos-alcaraz-real-madrid-open-djokovic-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 13:30:14+00:00

So strong is Carlos Alcaraz's affection for Real Madrid, even the Spanish teen sensation's tennis matches mirror his beloved football club's.

## The United States is in a maternal health crisis, Goldman Sachs wants to change that
 - [https://www.cnn.com/2022/05/08/business/mahmee-goldman-sachs-maternal-health/index.html](https://www.cnn.com/2022/05/08/business/mahmee-goldman-sachs-maternal-health/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 12:55:59+00:00

The United States is in a maternal health crisis.

## There are moms worse than you -- in the animal kingdom
 - [https://www.cnn.com/2022/05/08/world/moms-than-you-book-wellness-scn/index.html](https://www.cnn.com/2022/05/08/world/moms-than-you-book-wellness-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 12:25:23+00:00

If you're a mother, you have probably experienced the mental "what if" game on repeat since you found out you were becoming a parent.

## Warriors put in near-historic offensive display against Grizzlies as Bucks edge Celtics
 - [https://www.cnn.com/2022/05/08/sport/warriors-grizzlies-bucks-celtics-game-3-spt-intl/index.html](https://www.cnn.com/2022/05/08/sport/warriors-grizzlies-bucks-celtics-game-3-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 12:02:59+00:00

Before Saturday night, the Golden State Warriors' usual offensive fluidity had looked slightly out of sorts.

## Trump's trade war looms over soybean farmers 4 years later
 - [https://www.cnn.com/2022/05/08/politics/soybean-farmers-china-tariff-trump/index.html](https://www.cnn.com/2022/05/08/politics/soybean-farmers-china-tariff-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 12:02:53+00:00

It's been nearly four years since China put tariffs on American-grown soybeans during a tit-for-tat trade war with then-President Donald Trump -- and they remain in place despite the change in administrations.

## Son Heung-Min strikes heavy blow to Liverpool's quadruple dreams as stubborn Spurs frustrate Klopp
 - [https://www.cnn.com/2022/05/08/football/son-spurs-liverpool-klopp-premier-league-spt-intl/index.html](https://www.cnn.com/2022/05/08/football/son-spurs-liverpool-klopp-premier-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 12:02:01+00:00

Chasing the perfect season, Liverpool required a perfect run-in. Tottenham Hotspur had other ideas.

## Supreme Court mystery thickens
 - [https://www.cnn.com/2022/05/08/opinions/supreme-court-roe-v-wade-column-galant/index.html](https://www.cnn.com/2022/05/08/opinions/supreme-court-roe-v-wade-column-galant/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 12:00:55+00:00

In the mid-1990s, a law student at Columbia University spent his spare time writing a thriller about the inner workings of the US Supreme Court. Brad Meltzer's "The 10th Justice" told the story of Ben Addison, a clerk to one of the justices who is duped into revealing the court's forthcoming, but still confidential, ruling to people seeking to profit off the decision.

## Meet the Savannah Bananas, TikTok's favorite baseball team
 - [https://www.cnn.com/2022/05/08/us/savannah-bananas-baseball-tiktok-cec/index.html](https://www.cnn.com/2022/05/08/us/savannah-bananas-baseball-tiktok-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 11:45:02+00:00

It's the top of the third inning in Grayson Stadium, home of the Savannah Bananas. As the second batter gets set once again, the home team, clad in its customary yellow, crowds closer in the infield. A shimmer of excitement moves through the stands in anticipation of the next pitch.

## Missing Alabama inmate and his jailer leave few clues for investigators on their trail
 - [https://www.cnn.com/2022/05/08/us/vicky-white-casey-white-alabama-manhunt-sunday/index.html](https://www.cnn.com/2022/05/08/us/vicky-white-casey-white-alabama-manhunt-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 11:22:20+00:00

• Before he escaped, Alabama fugitive stood accused of killing a sweet, patriotic mom

## The strategy behind Biden's new language about Republicans
 - [https://www.cnn.com/2022/05/08/politics/biden-democrats-midterm-elections-new-strategy/index.html](https://www.cnn.com/2022/05/08/politics/biden-democrats-midterm-elections-new-strategy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 10:03:35+00:00

Last week's Supreme Court bombshell introduced two new terms into Joe Biden's presidential rhetoric. One was abortion; the other may shape his election-year prospects more.

## He tried to join the Marines. Then his life took a turn he never expected
 - [https://www.cnn.com/2022/05/08/entertainment/americano-musical-tony-valdovinos-cec/index.html](https://www.cnn.com/2022/05/08/entertainment/americano-musical-tony-valdovinos-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 10:01:20+00:00

Tony Valdovinos says it's hard for him to watch the musical about his life.

## Dan Ventrelle fired as Las Vegas Raiders president, alleges owner Mark Davis ignored complaints of a hostile work environment
 - [https://www.cnn.com/2022/05/08/sport/las-vegas-raiders-dan-ventrelle-fired/index.html](https://www.cnn.com/2022/05/08/sport/las-vegas-raiders-dan-ventrelle-fired/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 09:37:23+00:00

Las Vegas Raiders team president Dan Ventrelle has been fired, the team's owner Mark Davis said in a statement Friday.

## She kept her abortion private. Now this Tennessee woman says it's time to share her story
 - [https://www.cnn.com/2022/05/08/us/tennessee-woman-shares-abortion-story/index.html](https://www.cnn.com/2022/05/08/us/tennessee-woman-shares-abortion-story/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 08:02:46+00:00

When two pink vertical lines on a pregnancy test stared back at Taylor Esche last summer, she was contemplating her options before even leaving her bathroom.

## 'SNL': Benedict Cumberbatch celebrates mothers
 - [https://www.cnn.com/videos/media/2022/05/08/snl-benedict-cumberbatch-monologue-mothers-day-mgw-orig.cnn](https://www.cnn.com/videos/media/2022/05/08/snl-benedict-cumberbatch-monologue-mothers-day-mgw-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 07:32:02+00:00

Benedict Cumberbatch used his "Saturday Night Live" monologue to wish his mother and wife a happy Mother's Day.

## Before he escaped with his jailer, the Alabama fugitive stood accused of killing a sweet, patriotic mom who never forgot birthdays
 - [https://www.cnn.com/2022/05/08/us/connie-ridgeway-killing-casey-white/index.html](https://www.cnn.com/2022/05/08/us/connie-ridgeway-killing-casey-white/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 07:01:29+00:00

The last few Independence Days have been tough for Austin Williams. It's not only that his mother, Connie Ridgeway, loved America and collected anything bearing its flag, but July 4 was her birthday.

## With a rise in coronavirus cases, what precautions should you take for Mother's Day, graduations and other festivities?
 - [https://www.cnn.com/2022/05/08/health/omicron-masking-vaccines-coronavirus-gatherings-wellness/index.html](https://www.cnn.com/2022/05/08/health/omicron-masking-vaccines-coronavirus-gatherings-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 06:03:15+00:00

Cases of Covid-19 are rising again. Infections have increased by more than 50% compared with the previous week in at least eight US states. Parts of New York have moved into the "high" designation of Covid-19 community level, according to the US Centers for Disease Control and Prevention metrics.

## Nepali Sherpa breaks his own record again by scaling Everest 26 times, official says
 - [https://www.cnn.com/travel/article/everest-record-nepal-kami-rita-sherpa-intl-hnk/index.html](https://www.cnn.com/travel/article/everest-record-nepal-kami-rita-sherpa-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 05:38:00+00:00

A Nepali sherpa scaled Mount Everest for a record 26th time, beating his own previous record set last year, a government official said on Sunday.

## You will soon be able to use Bitcoin to buy Gucci
 - [https://www.cnn.com/2022/05/08/business/gucci-bitcoin-cryptocurrency-payments-trnd/index.html](https://www.cnn.com/2022/05/08/business/gucci-bitcoin-cryptocurrency-payments-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 05:01:50+00:00

Luxury brand Gucci has announced that it will accept cryptocurrency payments at select locations.

## Putin has put himself at the center of Russia's Victory Day. But he has little to celebrate
 - [https://www.cnn.com/collections/intl-ukraine-russia-0508/](https://www.cnn.com/collections/intl-ukraine-russia-0508/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 04:08:32+00:00



## Russia's failures in Ukraine will rain on Putin's Victory Day parade
 - [https://www.cnn.com/2022/05/08/europe/victory-day-russia-ukraine-war-analysis-cmd-intl/index.html](https://www.cnn.com/2022/05/08/europe/victory-day-russia-ukraine-war-analysis-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 04:04:22+00:00



## Gabby Petito's mother files wrongful death lawsuit against Brian Laundrie's estate
 - [https://www.cnn.com/2022/05/07/us/gabby-petito-wrongful-death-lawsuit-brian-laundrie/index.html](https://www.cnn.com/2022/05/07/us/gabby-petito-wrongful-death-lawsuit-brian-laundrie/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-08 01:36:39+00:00

Nichole Schmidt, the mother of Gabby Petito, has taken legal action against the estate of Brian Laundrie, by filing a complaint in Sarasota County Friday, in which she asks for monetary compensation for the "wrongful death" of her daughter.


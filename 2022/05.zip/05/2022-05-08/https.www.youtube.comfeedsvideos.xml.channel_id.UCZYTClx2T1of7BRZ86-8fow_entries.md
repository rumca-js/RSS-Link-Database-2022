# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Why Scientists Dumped a Bunch of Dead Alligators in the Ocean
 - [https://www.youtube.com/watch?v=DeRbsvWYRfs](https://www.youtube.com/watch?v=DeRbsvWYRfs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-05-09 00:00:00+00:00

Head to https://linode.com/scishow to get a $100 60-day credit on a new Linode account. Linode offers simple, affordable, and accessible Linux cloud solutions and services.

We still don't know a lot about the deep sea, but thanks to the help of three dead alligators, we know more about the diets of some of the creatures that live there.


Hosted by: Stefan Chin

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Sam Lutfi, Bryan Cloer, Kevin Bealer, Christoph Schwanke, Tomás Lagos González, Jason A Saslow, Tom Mosner, Jacob, Ash, Eric Jensen, Jeffrey Mckishen, Alex Hackman, Christopher R Boucher, Piya Shedden, Jeremy Mysliwiec, Chris Peters, Dr. Melvin Sanicas, charles george, Adam Brainard, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow #research #science
----------

Source
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0225345
https://www.soest.hawaii.edu/oceanography/faculty/csmith/Files/Smith%20and%20Baco%202003.pdf
https://hakaimagazine.com/features/bone-eating-worms-super-sized-isopods-and-other-surprises-from-dumping-alligators-in-the-sea/
https://ocean.si.edu/ocean-life/marine-mammals/life-after-whale-whale-falls

https://commons.wikimedia.org/wiki/File:Deinosuchus_hatcheri_-_Natural_History_Museum_of_Utah_-_DSC07251.JPG
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0225345
https://en.wikipedia.org/wiki/File:Giant_isopod.jpg
https://www.gettyimages.com/detail/photo/child-with-sow-bug-royalty-free-image/120725289?adppopup=true
https://oceanservice.noaa.gov/facts/whale-fall.html
https://commons.wikimedia.org/wiki/File:MBNMS_Whale_Fall_Octopuses_(49050941487).jpg
https://en.wikipedia.org/wiki/File:Whalefall_hires.jpg
https://oceantoday.noaa.gov/fullmoon-deepseadive/welcome.html
https://www.gettyimages.com/
https://www.storyblocks.com/

## 5 Strange Cases of Animal Rain
 - [https://www.youtube.com/watch?v=UFlVhTOR0zQ](https://www.youtube.com/watch?v=UFlVhTOR0zQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-05-08 00:00:00+00:00

Visit http://brilliant.org/scishow/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.

You might want a really sturdy umbrella to dig into this video, because we’re discussing 5 animals that have a tendency to rain down from the sky and the reasons we think this might be happening!

Hosted by: Stefan Chin

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Sam Lutfi, Bryan Cloer, Kevin Bealer, Christoph Schwanke, Tomás Lagos González, Jason A Saslow, Tom Mosner, Jacob, Ash, Eric Jensen, Jeffrey Mckishen, Alex Hackman, Christopher R Boucher, Piya Shedden, Jeremy Mysliwiec, Chris Peters, Dr. Melvin Sanicas, charles george, Adam Brainard, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:
https://www.livescience.com/44760-raining-frogs.html
https://gizmodo.com/when-it-rains-animals-the-science-of-true-weather-weir-5895116
https://www.theguardian.com/world/2009/jun/17/japan-rain-tadpoles 
https://www.cpr.org/2020/09/23/why-did-birds-fall-out-of-the-sky-in-september-colorado-new-mexico/
https://www.smithsonianmag.com/science-nature/strange-rain-why-fish-frogs-and-golf-balls-fall-skies-180956527/
https://www.jstor.org/stable/4163245
https://www.theguardian.com/uk-news/2020/jan/16/police-answer-mystery-of-hundreds-of-starlings-found-dead-on-road 
https://www.mirror.co.uk/news/world-news/two-hundred-birds-fall-dead-25605889
https://newsfeed.time.com/2011/01/03/why-did-thousands-of-birds-drop-dead-in-the-arkansas-sky/#:~:text=But%20for%20residents%20of%20Beebe,their%20lawns%2C%20streets%20and%20rooftops.
https://www.nationalgeographic.com/animals/article/110106-birds-falling-from-sky-bird-deaths-arkansas-science
https://www.researchgate.net/profile/Natalie-Claunch-2/publication/355416542_Florida's_Introduced_Reptiles_Green_Iguana_Iguana_iguana_WEC440UW485_72021/links/61784c07eef53e51e1ee89be/Floridas-Introduced-Reptiles-Green-Iguana-Iguana-iguana-WEC440-UW485-7-2021.pdf
https://www.bbc.com/news/world-us-canada-60090861
https://www.jstor.org/stable/1563404
https://www.daf.qld.gov.au/__data/assets/pdf_file/0006/61467/IPA-Green-Iguana-Risk-Assessment.pdf 
https://academic.oup.com/icb/article/51/6/944/614234?login=false
https://www.nature.com/articles/nature03254
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2880152/#RSPB20100170C19
https://www.european-arachnology.org/esa/wp-content/uploads/2015/08/187-191_Duffey.pdf
https://www.cell.com/current-biology/fulltext/S0960-9822(18)30693-6?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0960982218306936%3Fshowall%3Dtrue

Image Sources:
https://commons.wikimedia.org/wiki/File:FMIB_43713_Shower_of_Fishes.jpeg
https://commons.wikimedia.org/wiki/File:Rain_of_frogs.jpg
https://bit.ly/3KRihtK
https://commons.wikimedia.org/wiki/File:Gravure_de_pluie_de_poissons.jpg
https://bit.ly/390IHMj
https://bit.ly/3vSAYt0
https://bit.ly/3MUl0Ee
https://commons.wikimedia.org/wiki/File:Yellow-headed_Blackbirds,_Seedskadee_National_Wildlife_Refuge_(25786271705).jpg
https://bit.ly/3M8lKWx
https://bit.ly/3vNNmdF
https://bit.ly/3KLlafK
https://bit.ly/3LRBZag
https://bit.ly/38Wc8iI
https://bit.ly/3w7LRWF
https://bit.ly/3MUQR7D
https://commons.wikimedia.org/wiki/File:Iguana_iguana_distribution_map.png
https://bit.ly/3LXZePR
https://bit.ly/3kLnXee
https://bit.ly/3P02rAm
https://bit.ly/37sU2Vi
https://bit.ly/3MVKUHD
https://bit.ly/3MVEkAT
https://en.wikipedia.org/wiki/File:Red_Weaver_Ant,_Oecophylla_longinoda.jpg
https://commons.wikimedia.org/wiki/File:Weaver_ant_(Oecophylla_longinoda)_nest_2.jpg
https://commons.wikimedia.org/wiki/File:Cephalotes_Atratus.jpg
https://commons.wikimedia.org/wiki/File:Cephalotes_atratus_(18419740775).jpg
https://commons.wikimedia.org/wiki/File:Cephalotes_Atratus,.jpg
https://commons.wikimedia.org/wiki/File:Spiders_ballooning_at_B.K.Leach_(30267984256).jpg
https://commons.wikimedia.org/wiki/File:Ballooning_spider.png
https://commons.wikimedia.org/wiki/File:PSM_V57_D097_Hms_beagle_in_the_straits_of_magellan.png
https://bit.ly/3LR2ht2
https://bit.ly/3ygYYY7
https://commons.wikimedia.org/wiki/File:Threads_of_silk_following_a_mass_spider_ballooning.jpg
https://bit.ly/3OYBVHL
https://bit.ly/3shNBvt
https://commons.wikimedia.org/wiki/File:Young_spiders_in_Rain_spider_nest_(5280032594).jpg


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Send Me Your Prototypes - Eluktronics LPP
 - [https://www.youtube.com/watch?v=oH-x2Wgd-0c](https://www.youtube.com/watch?v=oH-x2Wgd-0c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-05-09 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Configure an AX dedicated root server without a setup fee with Hetzner at http://linustechtips.hetzner.com/en/seasonsspecial-0522

We were super disappointed the first time we checked out the Eluktronics Liquid Propulsion Package, but now they've fixed everything.. maybe.

Discuss on the forum: https://linustechtips.com/topic/1430073-send-me-your-prototypes/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 - Intro
1:00 - Hetzner
1:19 - The LPP
6:03 - Overclocking
7:35 - An Awks Sponsor Video
9:08 - 3DMark go Brrrrrr
10:49 - Should brands send us their stuff early?
12:25 - Why an RTX 3080Ti can use water cooling
14:50 - Why sending protypes might be a bad idea
18:43 - Squarespace
19:26 - Outro

## Please dont make me buy an xbox - DIY Multi-Zone Xbox
 - [https://www.youtube.com/watch?v=enBoNuS2VjU](https://www.youtube.com/watch?v=enBoNuS2VjU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-05-08 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Get 10% off all Jackery products with code LinusTechTips at https://www.jackery.com?aff=27

At the new house, we found a big problem! How can we be able to play Xbox and PC games in multiple parts of the house without having to buy multiples of them. Today we find out.

Discuss on the forum: https://linustechtips.com/topic/1429871-please-don%E2%80%99t-make-me-buy-an-xbox/

Buy an LG C1 48in OLED TV: https://geni.us/6Aet6K

Buy an Epson LS12000 projector: https://lmg.gg/pdq30

Buy a Klipsch RP-600M Bookshelf Speakers: https://geni.us/VRjbc6

Buy a Sonos Arc Soundbar: https://geni.us/Dv6Gje

Buy a HDMI 2.1 cables from Infinite Cables: https://lmg.gg/MEjRh

Buy a HDMI Active Optical 2.1 cables from Infinite Cables: https://lmg.gg/3XOnn

Buy a Denon AVR-X8500HA: https://lmg.gg/ZlJOt

Buy an NVIDIA RTX 3090:https://geni.us/IVFjs

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro


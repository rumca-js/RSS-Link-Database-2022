# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Jura Krakowsko-Częstochowska - rowerem wśród zamków i pustyń 🚴‍♂️💨 Szlak Orlich Gniazd Delux
 - [https://www.youtube.com/watch?v=cREj5qgv6iY](https://www.youtube.com/watch?v=cREj5qgv6iY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2022-05-08 07:09:22+00:00

Książka dostępna tutaj 👉 https://rowertojestswiat.pl/ 
zachęcam do środkowego pakietu - wersja elektroniczna podczas wyjazdu robi robotę :D 

Kontynuujemy podróże rowerowe po Polsce - dziś zabieram Was na Jurę Krakowsko Częstochowską, gdzie przejedziemy cały ten region bazując na Szlaku Orlich Gniazd, odbijając jednak w wielu miejscach w inne, ciekawe zakamarki Jury. Bez dwóch zdań Jura jest jednym z moich ulubionych miejsc na południu Polski i jeśli jeszcze tutaj nie byliście, no to wstyd! :)

►►Zachęcam do subskrypcji: http://bit.ly/2cmWbSO 

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Muzyka Artlist i Nevaeh

spis treści:
0:00 - Jura Krakowsko-częstochowska 
00:39 - zamek w Olsztynie
1:18 - Jura Krakowsko-częstochowska rowerem
1:37 - Pustynia Siedlecka
1:56 - Szlak Orlich Gniazd rowerem
2:55 - Złoty Potok, zamek Ostrężnik, miejscowość Żarki
3:42 - ruiny zamku w Mirowie
3:49 - zamek w Bobolicach
5:03 - Góra Zborów
7:35 - Zamek Bąkowiec, Okiennik Wielki
9:10 - Zamek Ogrodzieniec
9:50 - Góra Birów
10:12 - Pustynia Błędowska
11:55 - Zamek Rabsztyn
12:24 - Dolinki Krakowskie
13:17 - Dolina Będkowska
13:34 - trasy wspinaczkowe w Jurze
14:07 - dwa słowa o książce "Rower to jest Świat"


# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## You're not allowed in this cave. But there's a copy.
 - [https://www.youtube.com/watch?v=_zJbi9YatcA](https://www.youtube.com/watch?v=_zJbi9YatcA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-05-09 00:00:00+00:00

The Chauvet cave, in the south of France, is one of the most important archaeological sites in the world, filled with art that's tens of millennia old. No-one's allowed in, for very good reasons: but just a few kilometres away, there's a near-exact copy. Is that enough?

Camera: Simon Gillouin
Editor: Dave Stevenson http://davestevenson.co.uk
Producer: Axel Zeiliger https://block8production.com

More about Chauvet II: https://grottechauvet2ardeche.com/

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


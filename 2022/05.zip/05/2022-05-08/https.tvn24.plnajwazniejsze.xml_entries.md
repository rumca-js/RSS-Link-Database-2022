# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Największym wsparciem są ci, którzy rozumieją, że nic nie można zrobić"
 - [https://tvn24.pl/premium/muzyk-i-wokalista-bartosz-sosnowski-we-wspomnieniach-partnerki-aleksandry-goreckiej-5700036?source=rss](https://tvn24.pl/premium/muzyk-i-wokalista-bartosz-sosnowski-we-wspomnieniach-partnerki-aleksandry-goreckiej-5700036?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-05-08 10:44:15+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i7egbo-aleksandra-gorecka-bartek-byl-miloscia-mojego-zycia-5699991/alternates/LANDSCAPE_1280" />
    Był miłością mojego życia. Byliśmy razem 13 lat i przez cały ten czas zasypialiśmy i budziliśmy się przytuleni, i wiem, że on mnie kochał najbardziej na świecie. Nigdy o tym nie zapomnę - mówi reżyserka Aleksandra Górecka, wieloletnia partnerka Barta Sosnowskiego, artysty, który zmarł nagle we wrześniu 2021 roku. Żałoba to wciąż w Polsce tabu - ocenia i wyznaje: Uwielbiałam, kiedy ktoś ze mną płakał, bo przynajmniej dawało mi to poczucie, że nie tylko ja to wszystko przeżywam, że nie tylko ja tego nie rozumiem i na to się nie zgadzam.


## Lessons learned from the recent job hunt · Jamie Tanna | Software Engineer
 - [https://www.jvt.me/posts/2022/05/02/lessons-learned-job-hunt/](https://www.jvt.me/posts/2022/05/02/lessons-learned-job-hunt/)
 - RSS feed: https://www.jvt.me
 - date published: 2022-05-08 15:52:03+00:00

A recap of the recent interview process with several companies, what I learned, and what others should know.


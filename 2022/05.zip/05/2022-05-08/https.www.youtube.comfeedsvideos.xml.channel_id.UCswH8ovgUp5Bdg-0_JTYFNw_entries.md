# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Pfizer Don't Care About You, They Care About This
 - [https://www.youtube.com/watch?v=qe3UcJ0CAxI](https://www.youtube.com/watch?v=qe3UcJ0CAxI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-05-09 00:00:00+00:00

As Pfizer continues to make record profits at the start of the year – are we allowed to critique and criticise Big Pharma yet… or does that still make you an anti-vax conspiracy theorist? #Pfizer #BigPharma #Pandemic 

References
https://www.theguardian.com/business/2022/may/03/pfizer-covid-sales-pricing-vaccine-paxlovid-pill
https://www.theguardian.com/commentisfree/2022/feb/08/big-pharma-global-vaccine-rollout-covid-pfizer
https://thehill.com/policy/healthcare/598026-pfizer-ceo-says-a-fourth-booster-shot-is-necessary/
https://www.nytimes.com/2021/12/23/world/middleeast/israel-vaccine-4th-dose.html
https://theintercept.com/2021/11/29/pfizer-whistleblower-reform-corporate-fraud/
https://www.businessinsider.com/lawmakers-bought-sold-covid-19-related-stocks-during-pandemic-2021-12?r=US&IR=T

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Bill Gates: How To Predict The Next Pandemic
 - [https://www.youtube.com/watch?v=qLBsSpeTU1A](https://www.youtube.com/watch?v=qLBsSpeTU1A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-05-08 00:00:00+00:00

Bill Gates has called for a global surveillance team to spot future pandemic threats – and potentially enact lockdowns - and by coincidence, he’d be in charge. No issues there then. #BillGates #Pandemic #Covid 

References
https://www.ft.com/content/c8896c10-35da-46aa-957f-cf2b4e18cfce
https://www.politico.eu/article/bill-gates-who-most-powerful-doctor/
https://www.thenation.com/article/economy/bill-gates-investments-covid/

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


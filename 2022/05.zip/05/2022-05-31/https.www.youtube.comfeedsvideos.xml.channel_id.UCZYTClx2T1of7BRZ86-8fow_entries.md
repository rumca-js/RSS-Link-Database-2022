# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## The Absolute Worst Thing About Butterflies
 - [https://www.youtube.com/watch?v=GSyBginQAF8](https://www.youtube.com/watch?v=GSyBginQAF8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-06-01 00:00:00+00:00

Visit http://brilliant.org/scishow/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.

Who doesn’t love to gaze at a beautiful butterfly fluttering by? Aesthetically speaking, they are simply wonderful to watch. Wonderful, that is, unless you are getting a rare glimpse of pheromone laced coremata. 

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Sam Lutfi, Bryan Cloer, Kevin Bealer, Christoph Schwanke, Tomás Lagos González, Jason A Saslow, Tom Mosner, Jacob, Ash, Eric Jensen, Jeffrey Mckishen, Alex Hackman, Christopher R Boucher, Piya Shedden, Jeremy Mysliwiec, Chris Peters, Dr. Melvin Sanicas, charles george, Adam Brainard, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:
https://www.sciencedirect.com/science/article/abs/pii/0022519375901113?via%3Dihub
https://royalsocietypublishing.org/doi/10.1098/rspb.1996.0207
https://www.researchgate.net/publication/349161804_Scent_glands_in_Lepidoptera_Coremata
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2124467/

Image Sources:
https://www.gettyimages.com/detail/video/butterfly-flying-off-the-grass-in-sunshine-stock-footage/993253088?adppopup=true
https://www.gettyimages.com/detail/video/macro-of-a-big-brown-cockroach-stock-footage/1303483667?adppopup=true
https://www.gettyimages.com/detail/video/two-butterflies-gathering-pollen-on-the-petals-and-stock-footage/1334671387?adppopup=true
https://www.gettyimages.com/detail/video/two-butterflies-gathering-pollen-on-the-petals-and-stock-footage/1334671387?adppopup=true
https://www.gettyimages.com/detail/video/yellow-butterfly-on-pink-flower-super-slow-motion-stock-footage/1162753590?adppopup=true
https://www.gettyimages.com/detail/video/butterfly-flying-slow-motion-stock-footage/1246120588?adppopup=true
https://www.gettyimages.com/detail/photo/blue-butterfly-royalty-free-image/468989672?adppopup=true
https://www.gettyimages.com/sign-in?ReturnUrl=%2Fdetail%2Fphoto%2Fimage-of-butterfly-moth-on-green-leaves-insect-royalty-free-image%2F816042348%3Fadppopup%3Dtrue
https://www.gettyimages.com/detail/photo/aliens-creature-in-the-forest-royalty-free-image/1365094219?adppopup=true
https://commons.wikimedia.org/wiki/File:Androconia_Bicyclus_anynana_San-Martin.jpg
https://commons.wikimedia.org/wiki/File:Pterodecta_felderi_2.jpg
https://commons.wikimedia.org/wiki/File:Brown_King_Crow_Euploea_klugii_showing_hair_pencils_Alibag_by_Dr._Raju_Kasambe_(1).jpg
https://commons.wikimedia.org/wiki/File:Creatonotos_gangis_(7171776400).jpg
https://www.youtube.com/watch?v=x8hMY_P0Rec
https://commons.wikimedia.org/wiki/File:Monarch_butterfly_rush_2.jpg
https://www.gettyimages.com/detail/photo/peacock-royalty-free-image/180699358?adppopup=true
https://commons.wikimedia.org/wiki/File:Creatonotos_gangis_-_Hang_Dong_-_North_Thailand_(5923649050).jpg
https://www.gettyimages.com/detail/video/video-wild-greater-sage-grouse-display-on-colorado-lek-stock-footage/467829928?adppopup=true
https://commons.wikimedia.org/wiki/File:Moth-1235-yercaud-salem-India.jpg
https://www.inaturalist.org/observations/96549838
https://www.gettyimages.com/detail/photo/moth-royalty-free-image/521701065?adppopup=true

## How Did We Figure Out What a Heart Attack Was?
 - [https://www.youtube.com/watch?v=qUJ80HBsBdY](https://www.youtube.com/watch?v=qUJ80HBsBdY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-05-31 00:00:00+00:00

Head to https://linode.com/scishow to get a $100 60-day credit on a new Linode account. Linode offers simple, affordable, and accessible Linux cloud solutions and services.

Heart attacks are the number 1 cause of death worldwide in the 21st century, but we weren't sure what caused them until 1980.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Sam Lutfi, Bryan Cloer, Kevin Bealer, Christoph Schwanke, Tomás Lagos González, Jason A Saslow, Tom Mosner, Jacob, Ash, Eric Jensen, Jeffrey Mckishen, Alex Hackman, Christopher R Boucher, Piya Shedden, Jeremy Mysliwiec, Chris Peters, Dr. Melvin Sanicas, charles george, Adam Brainard, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:
https://www.sciencedirect.com/science/article/abs/pii/S0002934322000407 
http://www.epi.umn.edu/cvdepi/essay/history-of-heart-attack-diagnosis-and-understanding/ 
https://health.clevelandclinic.org/women-dont-ignore-3-subtle-heart-attack-symptoms/ 
https://www.heart.org/en/health-topics/heart-attack/warning-signs-of-a-heart-attack/heart-attack-symptoms-in-women 
https://www.mayoclinic.org/tests-procedures/ekg/about/pac-20384983 
https://www.mayoclinic.org/diseases-conditions/heart-attack/symptoms-causes/syc-20373106 
https://pubmed.ncbi.nlm.nih.gov/12766530/#:~:text=The%20first%20electrocardiogram%20(ECG)%20from,Mary's%20Hospital%2C%20London. 
https://www.britannica.com/biography/Hippocrates 
https://www.britannica.com/topic/autopsy 
https://www.mayoclinic.org/diseases-conditions/heart-attack/diagnosis-treatment/drc-20373112
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6124376/ 
https://ajph.aphapublications.org/doi/pdf/10.2105/AJPH.28.10.1165
https://pubmed.ncbi.nlm.nih.gov/7412821/ 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5501035/
https://www.nejm.org/doi/10.1056/NEJMra1112570?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200www.ncbi.nlm.nih.gov
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3143862/
https://medicine.yale.edu/news-article/what-kind-of-heart-attack/ 

Images:
https://commons.wikimedia.org/wiki/File:Tuts_Tomb_Opened.JPG
https://www.gettyimages.com/detail/photo/human-heart-royalty-free-image/450534929?adppopup=true
https://www.gettyimages.com/detail/photo/chest-x-ray-image-of-women-royalty-free-image/518845556?adppopup=true
https://commons.wikimedia.org/wiki/File:Nicolaus_Tulp_demonstrating_anatomy_to_seven_syndics_of_the_Wellcome_V0006684-2.jpg
https://commons.wikimedia.org/wiki/File:Edward_Jenner._Oil_painting._Wellcome_V0017944.jpg
https://www.gettyimages.com/detail/video/atherosclerosis-coronary-artery-disease-stock-footage/1094720150?adppopup=true
https://www.gettyimages.com/detail/photo/heart-with-arteries-and-veins-royalty-free-image/109721217?adppopup=true
https://www.gettyimages.com/detail/video/patients-condition-monitored-in-intensive-care-unit-stock-footage/613928326?adppopup=true
https://www.gettyimages.com/detail/illustration/set-lines-heartbeat-normal-arrhythmia-and-royalty-free-illustration/1310250309?adppopup=true
https://www.gettyimages.com/detail/video/echocardiography-coronary-angiography-stock-footage/930515010?adppopup=true
https://www.gettyimages.com/detail/photo/coronary-artery-stenosis-on-angiography-royalty-free-image/472954104?adppopup=true
https://www.gettyimages.com/detail/photo/3d-illustration-of-a-constricted-and-narrowed-royalty-free-image/1078217402?adppopup=true
https://www.gettyimages.com/detail/photo/flowing-bloodcells-royalty-free-image/538666628?adppopup=true
https://www.gettyimages.com/detail/video/blood-cells-pulsing-down-artery-hd-stock-footage/883866318?adppopup=true
https://www.gettyimages.com/detail/photo/clogged-arteries-cholesterol-plaque-in-artery-royalty-free-image/1255871988?adppopup=true
https://commons.wikimedia.org/wiki/File:Heart_attack_animation.ogv
https://www.gettyimages.com/detail/illustration/female-doctor-treats-her-patient-with-pain-royalty-free-illustration/1318809223?adppopup=true
https://www.gettyimages.com/detail/illustration/red-halftone-christmas-background-for-web-royalty-free-illustration/1356535359


## A decade of dotfiles
 - [https://evanhahn.com/a-decade-of-dotfiles/](https://evanhahn.com/a-decade-of-dotfiles/)
 - RSS feed: https://evanhahn.com
 - date published: 2022-05-31 06:54:09+00:00

Reflections on a decade of configuration files.


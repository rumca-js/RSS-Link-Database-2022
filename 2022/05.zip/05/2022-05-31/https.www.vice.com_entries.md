## Discord Is the World’s Most Important Financial Messenger, And a Hotbed for Scammers
 - [https://www.vice.com/en/article/n7n848/discord-is-the-worlds-most-important-financial-messenger-and-a-hotbed-for-scammers](https://www.vice.com/en/article/n7n848/discord-is-the-worlds-most-important-financial-messenger-and-a-hotbed-for-scammers)
 - RSS feed: https://www.vice.com
 - date published: 2022-05-31 14:56:24.767492+00:00

Rampant spam, phishing attacks, scammers, and malware—Discord has a lot of challenges securing crypto projects.


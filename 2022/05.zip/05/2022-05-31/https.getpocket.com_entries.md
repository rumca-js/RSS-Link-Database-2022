## Unknown Sender: The Mystery of the Circleville Letters
 - [https://getpocket.com/explore/item/unknown-sender-the-mystery-of-the-circleville-letters](https://getpocket.com/explore/item/unknown-sender-the-mystery-of-the-circleville-letters)
 - RSS feed: https://getpocket.com
 - date published: 2022-05-31 15:55:47.176341+00:00

For years, residents in and around Circleville, Ohio were plagued by a mysterious letter writer who seemed to know their darkest secrets. Death followed.


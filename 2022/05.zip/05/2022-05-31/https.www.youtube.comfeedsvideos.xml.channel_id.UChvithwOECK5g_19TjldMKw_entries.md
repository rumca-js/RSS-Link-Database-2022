# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## Xinjiang Police File Hack - Why China is Terrified
 - [https://www.youtube.com/watch?v=NIpxtYQxqxU](https://www.youtube.com/watch?v=NIpxtYQxqxU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2022-05-31 00:00:00+00:00

Get the best wallet in the world just in time for Father's Day (huge discount link): https://shop.ekster.com/Laowhy86

The Xinjiang Police Files were leaked after some government offices/police stations were hacked in western China. 10,000 documents and over 2800 mugshots confirm some of our worst suspicions. 

◘ Support me on Patreon to talk to me directly and support my work - http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts
China Fact Chasers - https://www.youtube.com/c/ChinaFactChasers

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Sources -
https://www.xinjiangpolicefiles.org
https://www.bbc.co.uk/news/resources/idt-8df450b3-5d6d-4ed8-bdcc-bd99137eadc3
https://www.spiegel.de/international/window-into-a-police-state-data-leak-provides-a-look-into-china-s-brutal-camp-system-a-b81a6538-369d-4511-ac94-9b11c28a1f5a
Thanks to the Victims of Communism memorial for the Dr. Adrian Zenz interview - https://victimsofcommunism.org/


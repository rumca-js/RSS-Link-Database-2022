# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Could Sound Waves Have Been Used to Build the Great Pyramids?
 - [https://www.youtube.com/watch?v=dKvFLwFSnlw](https://www.youtube.com/watch?v=dKvFLwFSnlw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-06-01 00:00:00+00:00

Taken from JRE #1827 w/Kristin Beck:
https://open.spotify.com/episode/1FLNuzVhrmOJD8vyawuTum

## The Military's Attempts to Make a Real Life Iron Man Suit
 - [https://www.youtube.com/watch?v=hJAwdBDJ2_Y](https://www.youtube.com/watch?v=hJAwdBDJ2_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-06-01 00:00:00+00:00

Taken from JRE #1827 w/Kristin Beck:
https://open.spotify.com/episode/1FLNuzVhrmOJD8vyawuTum

## Joe on Dave Attell's Legendary Status
 - [https://www.youtube.com/watch?v=DPEvWvcstxA](https://www.youtube.com/watch?v=DPEvWvcstxA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-05-31 00:00:00+00:00

Taken from JRE #1826 w/Fahim Anwar:
https://open.spotify.com/episode/0X2VD0o7wTQLlIqejxAvUr?si=111f5800e26540e3

Check out Fahim's new special "Hat Trick" here: https://youtu.be/HaTA-HVCo4w

## The Story Behind Kim Jong--il Getting 5 Hole-In-Ones in a Single Round of Golf
 - [https://www.youtube.com/watch?v=oGJWYobfX6c](https://www.youtube.com/watch?v=oGJWYobfX6c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-05-31 00:00:00+00:00

Taken from JRE #1826 w/Fahim Anwar:
https://open.spotify.com/episode/0X2VD0o7wTQLlIqejxAvUr?si=111f5800e26540e3

Check out Fahim's new special "Hat Trick" here: https://youtu.be/HaTA-HVCo4w


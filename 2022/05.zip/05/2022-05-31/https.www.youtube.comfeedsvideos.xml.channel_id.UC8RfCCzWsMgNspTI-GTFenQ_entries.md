# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## DARKTIDE LORE - EXCLUSIVE DEEP DIVE | Warhammer 40,000 Lore/History
 - [https://www.youtube.com/watch?v=VwLoEhgcyzc](https://www.youtube.com/watch?v=VwLoEhgcyzc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2022-06-01 00:00:00+00:00

Go to Steam: https://bit.ly/3GiidTm  [Click more for Xbox + Windows Store]
► Xbox: https://bit.ly/3lUe66B
► Windows Store: http://bit.ly/3AelBwN

► Subscribe: http://goo.gl/oeZMBS 
► Crystal Fortress Premium Storage: http://bit.ly/3oFuDf7
► Patreon: https://www.patreon.com/Luetin 
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

Timestamps:
0:00 Intro
1:54 Access Granted
12:22 The Moebian Domain / Stellar Exodus
18:50 M15-M30 DAOT / Age of Strife
23:52 M31 The Great Crusade
29:43 M31 Horus Heresy
31:04 M32 Recovery
31:53 M33-M35 Minimal Records 
36:00 M36 Expansion
38:14 M37-M41 Marking Time
39:14 M41 The Calm Before the Storm
41:35 Hive Cities
49:22 Inquisitors
01:00:36 Tertium’s Forlorn Hope
01:13:57 Outro

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.


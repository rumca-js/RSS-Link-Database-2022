# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## 15 AWESOME KDE Apps: I was WRONG about KDE applications!
 - [https://www.youtube.com/watch?v=hlDnOkZFN2g](https://www.youtube.com/watch?v=hlDnOkZFN2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-05-31 00:00:00+00:00

Use code LINUXEXPERIMENT to get 25% off your 2TB cloud storage plan on Internxt: https://internxt.com/pricing

Grad a brand new laptop or desktop running Linux:https://www.tuxedocomputers.com/


👏 SUPPORT THE CHANNEL:
Get access to an exclusive weekly podcast, vote on the next topics I cover, and get your name in the credits:

YOUTUBE: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join

Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

🏆 FOLLOW ME ELSEWHERE:
Linux news in Youtube Shorts format: https://www.youtube.com/channel/UCtZp0mK9IBrpS2-jNzMZmoA

Join us on our Discord server: https://discord.gg/xK7ukavWmQ

Twitter : http://twitter.com/thelinuxEXP

Mastodon: https://mastodon.social/web/@thelinuxEXP

Pixelfed: https://pixelfed.social/TLENick

My Gaming on Linux Channel: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw

📷 GEAR I USE:
Sony Alpha A6600 Mirrorless Camera: https://amzn.to/30zKyn7
Sigma 56mm Fixed Prime Lens: https://amzn.to/3aRvK5l
Logitech MX Master 3 Mouse: https://amzn.to/3BVI0Od
Bluetooth Space Grey Mac Keyboard: https://amzn.to/3jcJETZ
Logitech Brio 4K Webcam: https://amzn.to/3jgeTh9
LG Curved Ultrawide Monitor: https://amzn.to/3pcTVDH
Logitech White Speakers: https://amzn.to/3n6wSb0
Xbox Controller: https://amzn.to/3BWmIA3
*Amazon Links are affiliate codes and generate small commissions to support the channel*

This video is distributed under the Creative Commons Share Alike license.


00:00 Intro
00:45 Sponsor: Store your files securely and privately in the cloud with Internxt
01:53 Productivity
02:03 Kalendar: tasks and appointments
03:08 Plan: Project management
04:27 Calligra Suite: Office Suite
05:38 Skrooge: Personal Budgeting
06:43 Media Applications
06:49 Kdenlive: Video Editing
07:54 Krita: Digital Painting
08:43 Kolourpaint: Paint, but for KDE
09:22 Elisa: Local Music Player
09:55 Kasts: Podcast Player
10:48 Utilities
10:54 KDE Connect: Device integration
11:44 Subtitle Composer: create subtitles
12:08 Yakuake: drop down terminal
12:51 Sweeper: privacy and disk cleaner
13:12 Krusader: Power File Management
13:49 Falkon, KDE Itinerary, Marble, Artikulate, KAlgebra...
14:49 Sponsor: Get a laptop or desktop that runs Linux 100% with Tuxedo
15:55 If you have too much money...

Kalendar is an app to handle your calendars, but also your tasks. It integrates with your online accounts.

Plan is a project management application, that lets you handle tasks and subtasks, but it goes a lot deeper.

Calligra Suite is KDE's Office suite, great if you work on your own documents, and the ODF format.

For personal budgets, you have Skrooge.

For video editing, use Kdenlive. It's a full featured non linear video editor that lets you manage video and audio using tracks. It has tons of effects you can apply, transitions, and it can import and export to a TON of formats.

For artists, there is no better drawing tool on Linux than Krita. It's a digital painting appplication with tons of tools and brushes to let you create what you want. It's not only on Linux but also on Android, so you could even use it there, and it handles graphic tablets and their lovely styluses.

If, like me, you're no artist, but you still want a simple app to edit screenshots, or draw a few doodles here and there, Kolourpaint is going to be your go-to. It's basically MS Paint for KDE with anti aliasing, which of course you can disable if you like that pixel art look.

If you have a local music collection, and you're looking for a simple, but nice looking music player, then Elisa is the one for you.

Kasts is a small podcast app. You can add your own podcast feeds, or search for a specific podcast in the discover tab, and add it this way. You'll get a list of all episodes that you can then download and play.  

KDE Connect it basically lets you integrate your Android phone, or iPhone, with your desktop. You can send files to and from each device, use the phone as a remote for audio or presentations, or as a trackpad, and more.

Subtitle Composer lets you create subtitles for your videos, or for someone else's videos. You have tons of options to make them look like you want, open an existing file to modify it, select which language you're working on, and export your file.

With Yakuake, you just press F12, or any other key you prefer, and yo get a nice little terminal that drops down from the top of your screen.

Sweeper lets you clean a bunch of stuff that might take up space on your hard drive, like various caches, cookies, web history, recent documents, command history, and more.

Krusader is a file manage that handles archives in the file manager, FTP, has multiple panels to open folders side by side, sync folders, compare file contents, it can batch rename and is completely customizable, on top of having a super powerful search module.


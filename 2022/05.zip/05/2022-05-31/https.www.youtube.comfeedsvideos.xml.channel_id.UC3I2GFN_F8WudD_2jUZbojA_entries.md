# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## !!! (Chk Chk Chk) -  Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=tnAR6sVaIK8](https://www.youtube.com/watch?v=tnAR6sVaIK8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-31 00:00:00+00:00

http://KEXP.ORG presents !!! (Chk Chk Chk) performing live in the KEXP studio. Recorded May 13, 2022.

Songs:
This Is Pop 2
Panama Canal
Storm Around the World
Un Puente

Nic Offer - Vocals
Meah Pace - Vocals
Rafael Cohen - Guitar / Bass / Vocals
Daniel Gorman - Keys / Vocals
Chris Egan - Drums
Mario Andreoni - Bass / Guitar

Host: Cheryl Waters
Audio Engineers: Kyle Lawrence & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://chkchkchk.net
http://kexp.org

## !!! (chk chk chk) - Panama Canal (Live on KEXP)
 - [https://www.youtube.com/watch?v=ZQdq0KOACuE](https://www.youtube.com/watch?v=ZQdq0KOACuE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-31 00:00:00+00:00

http://KEXP.ORG presents !!! (Chk Chk Chk) performing “Panama Canal” live in the KEXP studio. Recorded May 13, 2022.

Nic Offer - Vocals
Meah Pace - Vocals
Rafael Cohen - Guitar / Bass / Vocals
Daniel Gorman - Keys / Vocals
Chris Egan - Drums
Mario Andreoni - Bass / Guitar


Host: Cheryl Waters
Audio Engineers: Kyle Lawrence & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://chkchkchk.net
http://kexp.org

## !!! (chk chk chk) - Storm Around The World (Live on KEXP)
 - [https://www.youtube.com/watch?v=LBORAG3PTG4](https://www.youtube.com/watch?v=LBORAG3PTG4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-31 00:00:00+00:00

http://KEXP.ORG presents !!! (Chk Chk Chk) performing “Storm Around The World” live in the KEXP studio. Recorded May 13, 2022.

Nic Offer - Vocals
Meah Pace - Vocals
Rafael Cohen - Guitar / Bass / Vocals
Daniel Gorman - Keys / Vocals
Chris Egan - Drums
Mario Andreoni - Bass / Guitar


Host: Cheryl Waters
Audio Engineers: Kyle Lawrence & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://chkchkchk.net
http://kexp.org

## !!! (chk chk chk) - This Is Pop 2 (Live on KEXP)
 - [https://www.youtube.com/watch?v=HNNcaSKolnU](https://www.youtube.com/watch?v=HNNcaSKolnU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-31 00:00:00+00:00

http://KEXP.ORG presents !!! (Chk Chk Chk) performing “This Is Pop 2” live in the KEXP studio. Recorded May 13, 2022.

Nic Offer - Vocals
Meah Pace - Vocals
Rafael Cohen - Guitar / Bass / Vocals
Daniel Gorman - Keys / Vocals
Chris Egan - Drums
Mario Andreoni - Bass / Guitar


Host: Cheryl Waters
Audio Engineers: Kyle Lawrence & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://chkchkchk.net
http://kexp.org

## !!! (chk chk chk) - Un Puente (Live on KEXP)
 - [https://www.youtube.com/watch?v=SdWXbmWc1j8](https://www.youtube.com/watch?v=SdWXbmWc1j8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-31 00:00:00+00:00

http://KEXP.ORG presents !!! (Chk Chk Chk) performing “Un Puente” live in the KEXP studio. Recorded May 13, 2022.

Nic Offer - Vocals
Meah Pace - Vocals
Rafael Cohen - Guitar / Bass / Vocals
Daniel Gorman - Keys / Vocals
Chris Egan - Drums
Mario Andreoni - Bass / Guitar


Host: Cheryl Waters
Audio Engineers: Kyle Lawrence & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://chkchkchk.net
http://kexp.org


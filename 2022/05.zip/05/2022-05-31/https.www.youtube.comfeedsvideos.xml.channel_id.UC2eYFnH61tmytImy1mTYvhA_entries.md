# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## Background and Direction of Our Cyberpunk Dystopia
 - [https://www.youtube.com/watch?v=N3Qlqv2vm0g](https://www.youtube.com/watch?v=N3Qlqv2vm0g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2022-06-01 00:00:00+00:00

This is a re-presentation of the talk that I did at Monerotopia. The native recording (which you can see here: https://www.youtube.com/watch?v=AVpeZMLaliE) was suboptimal in quality and part of it was missing, so I'm going through the whole thing with EXTENDED HECKIN' COMMENTARY here.

This was released first on my personal video site. See it here:
https://videos.lukesmith.xyz

My website: https://lukesmith.xyz
Classical books reprinted by me: https://lindypress.net
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz
BTC: bc1qw5w6pxsk3aj324tmqrhhpmpfprxcfxe6qhetuv
XMR: 48jewbtxe4jU3MnzJFjTs3gVFWh2nRrAMWdUuUd7Ubo375LL4SjLTnMRKBrXburvEh38QSNLrJy3EateykVCypnm6gcT9bh

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.

## Friend Simulator Livestream (feat. Buc-ee)
 - [https://www.youtube.com/watch?v=YtyHY9O3nK8](https://www.youtube.com/watch?v=YtyHY9O3nK8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2022-06-01 00:00:00+00:00

Reading donations: https://donate.lukesmith.xyz
Or superchat with Monero: https://xmr.lukesmith.xyz

## Superchats with Monero (Shadowchat)
 - [https://www.youtube.com/watch?v=AFbIIccVaAw](https://www.youtube.com/watch?v=AFbIIccVaAw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2022-06-01 00:00:00+00:00

I've been using shadowchat (https://github.com/lukesmithxyz/shadowchat) for a while to receive donations with messages (superchats) with Monero. It's just a simple program written in Go and doesn't need anything else too fancy to work.

It also works with OBS and shows notifications and sends notification emails if you want that as well.

My website: https://lukesmith.xyz
Classical books reprinted by me: https://lindypress.net
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz
BTC: bc1qw5w6pxsk3aj324tmqrhhpmpfprxcfxe6qhetuv
XMR: 48jewbtxe4jU3MnzJFjTs3gVFWh2nRrAMWdUuUd7Ubo375LL4SjLTnMRKBrXburvEh38QSNLrJy3EateykVCypnm6gcT9bh

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.

## I'll be at Linuxfest Southeast in Charlotte, NC (2022)
 - [https://www.youtube.com/watch?v=5M9IbeaBlmI](https://www.youtube.com/watch?v=5M9IbeaBlmI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2022-05-31 00:00:00+00:00

My previous presentation at Linuxfest (2018): https://www.youtube.com/watch?v=PnCXJn2cRf4
Southeast Linuxfest (SELF) website: https://southeastlinuxfest.org

My proposed talks this year will be:
"Private and Sound Global Currency with Free Software"

If libre and privacy-respecting software can run a personal computer, can it run a global financial system? How to store and exchange value has been a decades-long puzzle among cypherpunk and FLOSS circles, resulting in many payment processors, ecashes, Bitcoin, Monero, GNU Taler and many other projects. This talk overviews the core issues and solutions, and what hope we can place in free software to secure our privacy and access to sound money.

and possibly as well:
"Reject Modernity. Return to Web 1.0."

The once colorful and chaotic Internet was filtered into a small number convenient social media sites in the early 2000s. While this shift enabled microinteractions like "liking" and commenting and standardized user accounts, nearly all Internet traffic is oligopolized by several "Big Tech" sites are personal websites are now a rarity. This doesn't have to be inevitable. As public perception of social media sites has now soured, tools from faster Internet speeds, to static-site generators, federated software, even old RSS have given us a second chance at an Internet that is easy-to-use, powerful and controlled by the user.

My website: https://lukesmith.xyz
Classical books reprinted by me: https://lindypress.net
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz
BTC: bc1qw5w6pxsk3aj324tmqrhhpmpfprxcfxe6qhetuv
XMR: 48jewbtxe4jU3MnzJFjTs3gVFWh2nRrAMWdUuUd7Ubo375LL4SjLTnMRKBrXburvEh38QSNLrJy3EateykVCypnm6gcT9bh

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.


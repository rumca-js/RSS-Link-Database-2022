# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## ⚠️SEVERE NEW WINDOWS EXPLOIT⚠️ Do This Now! [Patch Update Now Available]
 - [https://www.youtube.com/watch?v=MV4xiw4rsvk](https://www.youtube.com/watch?v=MV4xiw4rsvk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-06-01 00:00:00+00:00

NOTE: A patch was released in the latest Windows update. Install the latest Windows update for the fix.


If you get an error about "access denied" or "cannot write file", you most likely are not running command prompt as Administrator. To do so, search the start menu for "command prompt", then right click it, then hit "Run as Administrator".

• Command to backup the registry key to C: drive:
reg export HKEY_CLASSES_ROOT\ms-msdt C:\msdt_regkey_backup.reg

• The Workaround Command: 
reg delete HKEY_CLASSES_ROOT\ms-msdt /f

• Command to Restore Registry Key (if you want to later):
reg import C:\msdt_regkey_backup.reg

Microsoft Post About the Workaround: https://msrc-blog.microsoft.com/2022/05/30/guidance-for-cve-2022-30190-microsoft-support-diagnostic-tool-vulnerability/

Good Writeup About the Exploit: https://doublepulsar.com/follina-a-microsoft-office-code-execution-vulnerability-1a47fce5629e

▼ Time Stamps: ▼
0:00 - Intro
0:52 - About the Exploit
2:51 - The Workaround / Fix
4:30 - More Extra Info

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


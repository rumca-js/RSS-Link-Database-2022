# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## God and Ayahuasca With Neal Brennan | A Bee Interview
 - [https://www.youtube.com/watch?v=K90x_Gc1Jas](https://www.youtube.com/watch?v=K90x_Gc1Jas)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-06-01 00:00:00+00:00

Comedian Neal Brennan, who co-created and co-wrote Chappelle's Show, joined The Babylon Bee to talk about doing comedy, believing in God after doing ayahuasca, and how cancel culture is totally fake-so stop crying about it.

You can check out Neal Brennan on his show Neal Brennan: Unacceptable: https://www.unacceptableshow.com/

Or his Netflix special 3 Mics: https://www.netflix.com/title/80117452

OR simply go to Neal Brennan’s website for upcoming shows: https://www.nealbrennan.com/

## What Is a Man? | A Babylon Bee Documentary
 - [https://www.youtube.com/watch?v=nqG_YE1x1sI](https://www.youtube.com/watch?v=nqG_YE1x1sI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-06-01 00:00:00+00:00

What makes a man? Do you even know? Over the course of this documentary, we explore this age-old question. Buckle up and get ready to learn.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Babylon Bee Confronts A Gen Zer On Why Their Generation Sucks
 - [https://www.youtube.com/watch?v=mBfxypfIG1o](https://www.youtube.com/watch?v=mBfxypfIG1o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-05-31 00:00:00+00:00

The Babylon Bee confronts a member of Gen Z to ask the pressing questions that Google auto-fills when someone types "Why Does Gen Z _________" such as why does Gen Z have anxiety and why does Gen Z love Shrek?

Watch the full podcast here: https://www.youtube.com/watch?v=W1wH-TfzaRc

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


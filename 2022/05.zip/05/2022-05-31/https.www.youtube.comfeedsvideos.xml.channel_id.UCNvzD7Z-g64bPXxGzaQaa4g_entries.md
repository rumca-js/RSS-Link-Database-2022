# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Things Video Games Did Without Telling You
 - [https://www.youtube.com/watch?v=ymUnMArNu1g](https://www.youtube.com/watch?v=ymUnMArNu1g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-01 00:00:00+00:00

Some games pull sneaky tricks without even telling the player. Here are some examples of gamings doing incredibly strange things in order to convince the player.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Genius Missions in FLOP Games
 - [https://www.youtube.com/watch?v=fIK28lZ06Z0](https://www.youtube.com/watch?v=fIK28lZ06Z0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-05-31 00:00:00+00:00

Some games don't quite land but they still have some incredible moments. Here are some of our favorite examples of killer moments in "meh" games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


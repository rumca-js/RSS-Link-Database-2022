# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I finally made it - House Theatre Room Build
 - [https://www.youtube.com/watch?v=M0Knct749io](https://www.youtube.com/watch?v=M0Knct749io)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-01 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Get 15% off your order and get dad something nice at https://www.ridge.com/LINUS

After nearly a year of planning, it's finally time to build up V1 of the home theatre setup in my new house featuring Epson's new flagship laser projector, and speakers from SVS. It's gonna be SICK!

Discuss on the forum: https://linustechtips.com/topic/1434635-new-house-home-theatre-setup/

Buy a SVS Ultra Speaker Surround System: https://lmg.gg/wGGrM
Buy Valencia Theatre Seating: https://lmg.gg/gEjtp
Buy an Elunevision Evo Nano Edge Projector Screen: https://lmg.gg/78NqW
Buy an Epson LS12000 Projector: https://lmg.gg/guOAb
Buy an Nvidia Shield TV Pro: https://geni.us/Ej2sUEA
Buy an Denon X8500hHA Receiver: https://lmg.gg/ifCMI
Buy a Peerless AV Projector Mount: https://lmg.gg/VXmcP
Buy Infinite Cables Active Optical HDMI: https://lmg.gg/chqqd

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:24 The Screen
4:00 The Speakers
7:57 NO Studs
8:37 Hanging Surrounds
11:12 Hanging the screen
11:56 Wiring
13:45 Mounting the Projector
16:04 The Receiver
17:12 The PC
18:33 Toe-in
18:55 The Cables
20:16 The Stage
20:45 Powering it on
22:36 Light Control
23:40 Sound Test
27:00 Crazy Pitch
28:42 Outro

## The All WALMART Gaming Setup
 - [https://www.youtube.com/watch?v=gqEUFZgLw_Y](https://www.youtube.com/watch?v=gqEUFZgLw_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-05-31 00:00:00+00:00

Answer your emails faster and with confidence using Grammarly! Go to https://grammarly.com/LTT to sign up for a FREE account and get 20% off Premium!

Get your NZXT BLD system today at: https://nzxt.co/LinusBLD

Walmart might not have the best reputation when it comes to gaming computers, but what about gaming PERIPHERALS? We searched through Walmart.com and bought all of their NEW ONN brand gaming peripherals, mice, monitors, and keyboards - OH MY!

Discuss on the forum: https://linustechtips.com/topic/1434442-the-all-walmart-gaming-setup/

Buy an onn. Lightwieght Gaming Mouse: https://geni.us/ifpg7

Buy an onn. Wireless Gaming Mouse: https://geni.us/k5NeON

Buy an onn. Webcam with Ring Light: https://geni.us/bByFrB

Buy an onn. 8 AC Outlets Surge Protector: https://geni.us/Lhet

Buy an onn. Gaming LED Mousepad: https://geni.us/AKRjnIg

Buy an Iridescent Office Chair: https://geni.us/6CmZsk8

Buy an onn. Desktop Speakers: https://geni.us/HBAOpF

Buy a Wireless Charging Lamp: https://geni.us/qeyq

Buy an onn. Gaming Mech Keyboard: https://geni.us/015lLXc

Buy an onn. 27 Inch Gaming Monitor: https://geni.us/NWpznV

Buy an X Rocker Play: https://geni.us/voUAw

Buy a Computer Desk: https://geni.us/ywBS0

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:46 Computer Desk
1:39 Mesh Back Office Chair
2:33 Onn Gaming Monitor
4:21 Onn Power Bar
5:21 Onn RGB Mech Keyboard
6:38 Wireless Gaming Mouse
7:45 Wired Lightweight Mouse
8:17 RGB Mousepad
8:42 Webcam w/ Ring Light
9:04 Wireless Charging Lamp
10:20 Onn Desktop Speakers
11:57 Gaming Headset
13:06 Sketchy Driver
13:50 Podcast Mic
14:10 Webcam Impressions
14:11 Mic(s) Impressions
16:30 Speaker Impressions
16:46 XRocker Play 2.0
19:06 Outtakes


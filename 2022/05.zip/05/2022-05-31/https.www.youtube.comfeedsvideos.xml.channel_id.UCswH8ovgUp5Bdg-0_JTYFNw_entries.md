# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## This Is A F*cking Joke!!
 - [https://www.youtube.com/watch?v=MLdebtxqsvw](https://www.youtube.com/watch?v=MLdebtxqsvw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-01 00:00:00+00:00

Nancy Pelosi's husband has been arrested on suspicion of driving under the influence. But in case you’re worried, he, his Porsche, Nancy, and their millions in big tech stock are fine. Phew.   
#PaulPelosi #NancyPelosi #arrest #stock #porsche

References
https://www.dailymail.co.uk/news/article-10870065/Nancy-Pelosis-husband-leaving-dinner-party-friends-house-arrested-DUI.html

--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## So... Hillary Was In On It!
 - [https://www.youtube.com/watch?v=AgnwZ4Wc2zA](https://www.youtube.com/watch?v=AgnwZ4Wc2zA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-05-31 00:00:00+00:00

The current trial of former Hillary Clinton campaign lawyer Michael Sussmann has revealed that Clinton personally approved serious election misinformation. So, is there an anti-Trump exception with regard to content moderation or should Hillary Clinton be banned from Twitter now?
#HillaryClinton #DonaldTrump #Russiagate #MichaelSussmann #trial

References
https://taibbi.substack.com/p/shouldnt-hillary-clinton-be-banned?s=r
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


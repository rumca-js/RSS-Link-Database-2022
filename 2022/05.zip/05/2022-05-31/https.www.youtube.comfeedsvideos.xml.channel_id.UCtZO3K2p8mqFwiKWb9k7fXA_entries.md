# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## The smartphone battery problem
 - [https://www.youtube.com/watch?v=oVFoHztPzX0](https://www.youtube.com/watch?v=oVFoHztPzX0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2022-05-31 09:33:47+00:00

Sponsored by Curiosity Stream. Sign up at https://curiositystream.com/techaltar and get access to Nebula for free with your subscription!

Once you have an account: 
Bonus video 1 (Fast charging): https://nebula.app/videos/techaltar-how-fast-charging-took-over
Bonus video 2 (Interview with Counterpoint): https://nebula.app/videos/techaltar-interview-with-peter-richardson-counterpoint-research

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

Lithium-Ion batteries were commercialized in the 1990s by Sony, and since then, very little has changed in the battery market. Capacity increases are slow and incremental, and only fast charging is improving at quick rates. Let's take a look at why.

The Story Behind - ep. 86

This video on Nebula: https://nebula.app/videos/techaltar-why-phone-batteries-arent-getting-better

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support TechAltar directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► Attributions ◄◄◄  

Music by Edemski: https://soundcloud.com/edemski


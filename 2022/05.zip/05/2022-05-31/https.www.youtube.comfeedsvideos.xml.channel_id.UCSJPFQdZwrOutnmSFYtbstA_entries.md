# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Why Modern Movies Suck - CGI Overload
 - [https://www.youtube.com/watch?v=DY-zg8Oo8p4](https://www.youtube.com/watch?v=DY-zg8Oo8p4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-05-31 00:00:00+00:00

CGI is everywhere now. Its tough to think of a single big budget film that doesn't have some kind of digital effects shot in there somewhere. And well, it's starting to get pretty tiresome.


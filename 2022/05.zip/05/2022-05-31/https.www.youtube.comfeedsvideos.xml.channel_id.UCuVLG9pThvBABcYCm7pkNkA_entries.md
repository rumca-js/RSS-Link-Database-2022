# Source:Climate Town, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA, language:en-US

## Who Actually Controls Gas Prices? | Climate Town
 - [https://www.youtube.com/watch?v=QnBqAzJXVGo](https://www.youtube.com/watch?v=QnBqAzJXVGo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA
 - date published: 2022-05-31 17:00:10+00:00

Gas prices are high again?!? Patreon: https://www.patreon.com/ClimateTown
sUbScRiBe FoR mOrE ViDeOs: https://www.youtube.com/c/climatetown?sub_confirmation=1

Join groups & Contact reps:
Urban Green: https://www.urbangreencouncil.org/content/projects/advancing-electrification
Sierra Club: https://www.sierraclub.org/articles/2019/12/building-electrification-action-plan-outlines-how-policymakers-can-equitably-phase
RMI: https://rmi.org/our-work/building-electrification/
Greenlining: http://greenlining.org/publications/reports/2019/equitable-building-electrification-a-framework-for-powering-resilient-communities/
Contact your senators: https://contactsenators.com/
Contact your representatives: https://www.house.gov/representatives/find-your-representative

Follow Climate Town on Instagram: https://www.instagram.com/climatetown/
Join the Climate Town subreddit y'all:  https://www.reddit.com/r/climatetown/

Organizations you can join right now:
Climate Change Makers: https://www.climatechangemakers.org/
Sunrise Movement: https://www.sunrisemovement.org/volunteer/
Extinction Rebellion: https://extinctionrebellion.us/get-involved/
Citizens Climate Lobby: https://citizensclimatelobby.org/
Climate Action Network: http://www.climatenetwork.org/
350.org - that one’s right in the name
Union of Concerned Scientists: https://www.ucsusa.org/

Some reading you can do:
This Changes Everything by Naomi Klein
Hot Mess by Matt Winning
Merchants of Doubt by Erik Conway & Naomi Oreskes
Overheated by Kate Aronoff
The Uninhabitable Earth by David Wallace-Wells
All We Can Save by a bunch of great writers
The Ministry for the Future by Kim Stanley Robinson
Drawdown by Paul Hawken

SOURCES AND FACTS:
The New Map: Energy, Climate, and the Clash of Nations by Daniel Yergin
The Energy System by Travis Bradford

Where U.S. Oil comes from: https://www.eia.gov/energyexplained/oil-and-petroleum-products/where-our-oil-comes-from.php
More U.S. Oil: https://www.eia.gov/tools/faqs/faq.php?id=709&amp;t=6/
U.S. Imports: 
https://www.eia.gov/energyexplained/oil-and-petroleum-products/imports-and-exports.php
https://www.afpm.org/sites/default/files/issue_resources/U.S.%20Imports%20of%20Oil%20%26%20Petroleum%20from%20Russia.pdf
https://www.forbes.com/sites/judeclemente/2020/02/12/the-us-still-imports-a-lot-of-oil/
https://www.americangeosciences.org/critical-issues/faq/how-much-oil-does-us-export-and-import/

Gasoline Standards: https://www.epa.gov/gasoline-standards/reformulated-gasoline
Gasoline Profit Margins: https://www.washingtonpost.com/business/on-small-business/grocery-stores-gas-stations-balking-at-the-proposed-swipe-fee-settlement/2012/08/01/gJQAqGsOPX_story.html
Crude Oil Historical Data: https://www.macrotrends.net/1369/crude-oil-price-history-chart
https://oilandenergyonline.com/articles/all/major-oil-market-crashes-history/
Negative Oil Prices: https://www.marketwatch.com/story/oil-prices-went-negative-a-year-ago-heres-what-traders-have-learned-since-11618863839
https://www.cnn.com/2021/04/20/investing/oil-prices-negative/index.html

OPEC
OPEC stats: https://www.opec.org/opec_web/en/press_room/5072.htm
OPEC v USA: https://www.forbes.com/sites/arielcohen/2021/11/09/opec-says-to-biden-if-you-want-more-oil-pump-it-yourself/
OPEC v Russia: https://www.nytimes.com/2020/03/09/business/energy-environment/oil-opec-saudi-russia.html
OPEC v Russia: https://en.wikipedia.org/wiki/2020_Russia%E2%80%93Saudi_Arabia_oil_price_war
OPEC+: https://www.forbes.com/sites/arielcohen/2018/06/29/opec-is-dead-long-live-opec/

US Oil Problems: https://www.reuters.com/article/us-usa-shale-bankruptcy-graphic/u-s-oil-producers-on-pace-for-most-bankruptcies-since-last-oil-downturn-idUSKBN26M7EM
Strategic Oil Reserves: https://www.cnn.com/2021/11/23/politics/biden-oil-reserves-gas-prices/index.html

Gas Industry Capital Expenditure: 
https://www.eia.gov/petroleum/weekly/archive/2021/211215/includes/analysis_print.php
https://www.reuters.com/business/energy/big-oil-keeps-brakes-spending-even-with-crude-rally-windfall-2021-07-12/
https://www.npr.org/2021/03/06/973649045/hold-that-drill-why-wall-street-wants-energy-companies-to-pump-less-oil-not-more
Gas Industry Revenue: https://www.statista.com/statistics/294614/revenue-of-the-gas-and-oil-industry-in-the-us/

Written by Rollie Williams and Matt Nelsen with help from Ben Boult and Nicole Conlan
Shot by Matt Nelsen, Nicole Conlan, pickups by Jesse Wilcoxen, Mark Vigeant, and Rollie Williams
Opening Graphics by Ian MK Cessna (https://ianhasawebsite.com/)
Theme music by Gratis (https://www.gratistheband.com/)
Color Correction by Brandon Pro at UptownWorks


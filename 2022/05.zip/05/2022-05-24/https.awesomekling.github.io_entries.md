## Memory safety for SerenityOS – Andreas Kling – I like computers!
 - [https://awesomekling.github.io/Memory-safety-for-SerenityOS/](https://awesomekling.github.io/Memory-safety-for-SerenityOS/)
 - RSS feed: https://awesomekling.github.io
 - date published: 2022-05-24 09:00:04+00:00

This post describes how we’re going to achieve memory safety in SerenityOS.


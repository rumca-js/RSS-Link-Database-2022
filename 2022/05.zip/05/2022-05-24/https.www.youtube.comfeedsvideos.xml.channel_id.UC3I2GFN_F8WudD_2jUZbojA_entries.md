# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Pom Pom Squad - Cake (Live on KEXP)
 - [https://www.youtube.com/watch?v=Ugew4xjrrhw](https://www.youtube.com/watch?v=Ugew4xjrrhw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-24 00:00:00+00:00

http://KEXP.ORG presents Pom Pom Squad performing “Cake” live in the KEXP studio. Recorded May 4, 2022.

Mia Berrin - Vocals / Guitar  
Alex Mercuri - Guitar
Alina Sloan - Bass
Shelby Keller - Drums
Camellia Hartman - Violin / Vocals

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Carlos Cruz

https://pompomsquad.lnk.to/DoaC
http://kexp.org

## Pom Pom Squad - Forever (Live on KEXP)
 - [https://www.youtube.com/watch?v=b6aaWrhlU04](https://www.youtube.com/watch?v=b6aaWrhlU04)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-24 00:00:00+00:00

http://KEXP.ORG presents Pom Pom Squad performing “Forever” live in the KEXP studio. Recorded May 4, 2022.

Mia Berrin - Vocals / Guitar 
Alex Mercuri - Guitar
Alina Sloan - Bass
Shelby Keller - Drums
Camellia Hartman - Violin / Vocals

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Carlos Cruz

https://pompomsquad.lnk.to/DoaC
http://kexp.org

## Pom Pom Squad - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=cVZle2Ip8aQ](https://www.youtube.com/watch?v=cVZle2Ip8aQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-24 00:00:00+00:00

http://KEXP.ORG presents Pom Pom Squad performing live in the KEXP studio. Recorded May 4, 2022.

Songs:
Head Cheerleader
Cake
Second That
Forever

Mia Berrin - Vocals / Guitar 
Alex Mercuri - Guitar
Alina Sloan - Bass
Shelby Keller - Drums
Camellia Hartman - Violin / Vocals

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Carlos Cruz

https://pompomsquad.lnk.to/DoaC
http://kexp.org

## Pom Pom Squad - Head Cheerleader (Live on KEXP)
 - [https://www.youtube.com/watch?v=Gpz-Ua2exUs](https://www.youtube.com/watch?v=Gpz-Ua2exUs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-24 00:00:00+00:00

http://KEXP.ORG presents Pom Pom Squad performing “Head Cheerleader” live in the KEXP studio. Recorded May 4, 2022.

Mia Berrin - Vocals / Guitar  
Alex Mercuri - Guitar
Alina Sloan - Bass
Shelby Keller - Drums
Camellia Hartman - Violin / Vocals

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Carlos Cruz

https://pompomsquad.lnk.to/DoaC
http://kexp.org

## Pom Pom Squad - Second That (Live on KEXP)
 - [https://www.youtube.com/watch?v=6FKmfuJSWPg](https://www.youtube.com/watch?v=6FKmfuJSWPg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-24 00:00:00+00:00

http://KEXP.ORG presents Pom Pom Squad performing “Second That” live in the KEXP studio. Recorded May 4, 2022.

Mia Berrin - Vocals / Guitar  
Alex Mercuri - Guitar
Alina Sloan - Bass
Shelby Keller - Drums
Camellia Hartman - Violin / Vocals

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Carlos Cruz

https://pompomsquad.lnk.to/DoaC
http://kexp.org


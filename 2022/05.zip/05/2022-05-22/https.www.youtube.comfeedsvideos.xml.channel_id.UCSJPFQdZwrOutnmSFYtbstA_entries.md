# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Drinker Recommends... Everything Everywhere All At Once
 - [https://www.youtube.com/watch?v=FmnzpHu2Tjc](https://www.youtube.com/watch?v=FmnzpHu2Tjc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-05-23 00:00:00+00:00

Wow, who knew we were still capable of making smart, funny, wildly creative and emotionally satisfying movies with talented casts and great direction? Everything Everywhere All At Once proves it can still be done.


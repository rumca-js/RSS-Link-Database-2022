# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Manchester City produces stunning comeback to secure English Premier League title on dramatic final day
 - [https://www.cnn.com/2022/05/22/football/manchester-city-aston-villa-premier-league-spt-intl/index.html](https://www.cnn.com/2022/05/22/football/manchester-city-aston-villa-premier-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 23:33:37+00:00

Manchester City produced a simply stunning comeback to beat Aston Villa 3-2 and win the English Premier League on Sunday.

## US military flies in baby formula from Germany
 - [https://www.cnn.com/2022/05/22/politics/baby-formula-us-military-aircraft/index.html](https://www.cnn.com/2022/05/22/politics/baby-formula-us-military-aircraft/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 23:32:31+00:00

A shipment of 35 tons of baby formula has arrived Sunday in Indianapolis on a US military aircraft from Germany to address a nationwide shortage.

## Why Insider's global editor-in-chief decided to publish the sexual harassment allegation against Elon Musk
 - [https://www.cnn.com/2022/05/22/media/elon-musk-insider-nicholas-carlson/index.html](https://www.cnn.com/2022/05/22/media/elon-musk-insider-nicholas-carlson/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 21:53:42+00:00

Elon Musk is going after Insider for publishing a story alleging he sexually harassed a flight attendant on a SpaceX corporate jet in 2016 — but the news outlet's global editor-in-chief Nicholas Carlson is standing by his team's reporting.

## Former defense secretary breaks down Putin's 'big mistake'
 - [https://www.cnn.com/videos/world/2022/05/22/putin-russia-ukraine-military-generals-william-cohen-newsroom-vpx.cnn](https://www.cnn.com/videos/world/2022/05/22/putin-russia-ukraine-military-generals-william-cohen-newsroom-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 19:55:56+00:00

Former US Defense Secretary William Cohen reacts to reports that Russian President Vladimir Putin has taken on more tactical decision-making in the Russian invasion into Ukraine.

## Netflix just released the first 8 chilling minutes of 'Stranger Things'
 - [https://www.cnn.com/videos/media/2022/05/22/stranger-things-netflix-season-four-release-orig-jc.cnn](https://www.cnn.com/videos/media/2022/05/22/stranger-things-netflix-season-four-release-orig-jc.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 18:21:05+00:00

Though Netflix has successful shows like "Bridgerton," company reps say they still lost over 200,000 subscribers earlier this year. This summer, they're looking to the release of the hit series "Stranger Things" Season 4 to win back Netflix fans.

## Liverpool agonizingly misses out on the Premier League title despite beating Wolves
 - [https://www.cnn.com/2022/05/22/football/liverpool-premier-league-wolves-spt-intl/index.html](https://www.cnn.com/2022/05/22/football/liverpool-premier-league-wolves-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 17:59:54+00:00

Liverpool agonizingly missed out on the Premier League title despite coming from behind to beat Wolves 3-1 at Anfield on Sunday.

## What to know about the 5th Circuit's latest controversial ruling
 - [https://www.cnn.com/2022/05/22/politics/5th-circuit-sec-administrative-process/index.html](https://www.cnn.com/2022/05/22/politics/5th-circuit-sec-administrative-process/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 17:53:26+00:00

The 5th Circuit is at it again.

## What a Nobel laureate's take on Donald Trump reveals about today
 - [https://www.cnn.com/2022/05/22/opinions/opinion-weekly-column-carr/index.html](https://www.cnn.com/2022/05/22/opinions/opinion-weekly-column-carr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 17:34:33+00:00

Shortly after Donald Trump was elected President of the United States, Nobel laureate Toni Morrison wrote in The New Yorker: "Unlike any nation in Europe, the United States holds whiteness as the unifying force. Here, for many people, the definition of 'Americanness' is color." Reflecting on efforts -- largely by White men -- to define themselves by sustaining that poisonous definition, Morrison argues that those "who are prepared to abandon their humanity out of fear of black men and women, suggest the true horror of lost status."

## The woman whose voice was heard in rubble of Surfside condo collapse has been identified. This is how it happened
 - [https://www.cnn.com/2022/05/22/us/surfside-collapse-voice-theresa-velasquez/index.html](https://www.cnn.com/2022/05/22/us/surfside-collapse-voice-theresa-velasquez/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 16:51:31+00:00

The faint and calm voice of a woman trapped in the hulking pile of concrete and twisted steel could be heard for several hours after the collapse of the Surfside, Florida, condominium last June.

## Max Verstappen leads Red Bull one-two at dramatic Spanish Grand Prix to leapfrog Charles Leclerc in F1 title fight
 - [https://www.cnn.com/2022/05/22/motorsport/f1-spanish-grand-prix-max-verstappen-leclerc-spt-intl/index.html](https://www.cnn.com/2022/05/22/motorsport/f1-spanish-grand-prix-max-verstappen-leclerc-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 15:48:33+00:00

Max Verstappen took advantage of Charles Leclerc's retirement to go top of the the drivers' standings after the Dutchman's third consecutive victory led Red Bull to a dream one-two at the Spanish Grand Prix.

## Arkansas's GOP governor says state's near-total abortion ban should be 'revisited' if Roe is reversed
 - [https://www.cnn.com/2022/05/22/politics/asa-hutchinson-abortion-ban-revisited-cnntv/index.html](https://www.cnn.com/2022/05/22/politics/asa-hutchinson-abortion-ban-revisited-cnntv/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 15:38:55+00:00

Arkansas' near-total abortion ban should be "revisited" to provide exceptions for instances of rape or incest should the Supreme Court overturn Roe v. Wade, the state's Republican governor said Sunday.

## Spain experiences record-breaking heatwave for May
 - [https://www.cnn.com/2022/05/22/europe/spain-record-heatwave-intl-scli/index.html](https://www.cnn.com/2022/05/22/europe/spain-record-heatwave-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 15:21:57+00:00

Parts of Spain have experienced a record heatwave for the month of May as temperatures reached 40.3 degrees Celsius (104.5 degrees Fahrenheit) in one city, according to the country's national weather agency AEMET.

## Afghanistan's new poor line up for aid to survive as food crisis bites
 - [https://www.cnn.com/2022/05/22/asia/afghanistan-hunger-new-poor-intl-cmd/index.html](https://www.cnn.com/2022/05/22/asia/afghanistan-hunger-new-poor-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 14:19:37+00:00

Two long lines -- one of men, another of women -- wind around a World Food Programme (WFP) aid distribution site in the Afghan capital, Kabul, in the heat of the mid-morning sun.

## Helicopter spots man stuck on 500-foot cliff
 - [https://www.cnn.com/videos/us/2022/05/22/helicopter-rescue-man-cliff-new-vpx.cnn](https://www.cnn.com/videos/us/2022/05/22/helicopter-rescue-man-cliff-new-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 13:02:18+00:00

A helicopter paramedic rescued a man stuck on a 500-foot cliff in California.

## Europe's tallest active volcano erupts lava into the night sky
 - [https://www.cnn.com/videos/world/2022/05/21/italy-mount-etna-volcano-erupts-orig-jc.cnn](https://www.cnn.com/videos/world/2022/05/21/italy-mount-etna-volcano-erupts-orig-jc.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 12:40:27+00:00

Mount Etna, Europe's tallest active volcano at about 3,330 meters, can erupt several times a year.

## Biden's succinct message to Kim Jong Un: 'Hello. Period.'
 - [https://www.cnn.com/2022/05/21/politics/joe-biden-south-korea-japan-sunday/index.html](https://www.cnn.com/2022/05/21/politics/joe-biden-south-korea-japan-sunday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 12:06:07+00:00

President Joe Biden will conclude a visit to South Korea on Sunday visiting with some of the nearly 30,000 American service members stationed here.

## Two Democrats viewed as rising stars are facing off in contentious Georgia primary
 - [https://www.cnn.com/2022/05/22/politics/georgia-democrats-7th-district-house-race/index.html](https://www.cnn.com/2022/05/22/politics/georgia-democrats-7th-district-house-race/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 12:05:13+00:00

A competitive primary for a Georgia House seat has locked two Democratic members of Congress -- Lucy McBath and Carolyn Bourdeaux -- in a tough fight for reelection.

## Woman drives truck to the front lines of Putin's invasion
 - [https://www.cnn.com/videos/world/2022/05/22/ukrainian-volunteer-driver-nr-malveaux-vpx.cnn](https://www.cnn.com/videos/world/2022/05/22/ukrainian-volunteer-driver-nr-malveaux-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 11:30:05+00:00

Uliana Hileta is a graphic designer turned volunteer driver who drives refitted donated cars to the Ukrainian resistance forces fighting on the front lines. CNN's Suzanne Malveaux reports.

## Satellite image leads to horrifying conclusion
 - [https://www.cnn.com/videos/business/2022/05/22/ukraine-satellite-images-russia-tuchman-pkg-newday-vpx.cnn](https://www.cnn.com/videos/business/2022/05/22/ukraine-satellite-images-russia-tuchman-pkg-newday-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 10:45:51+00:00

The US company Planet is taking revealing satellite images of the Russian invasion of Ukraine. CNN's Gary Tuchman reports.

## 'SNL' says goodbye to Kate McKinnon and Pete Davidson
 - [https://www.cnn.com/2022/05/22/media/snl-pete-davidson-kate-mckinnon-goodbyes/index.html](https://www.cnn.com/2022/05/22/media/snl-pete-davidson-kate-mckinnon-goodbyes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 10:13:01+00:00

"Saturday Night Live" closed out its 47th season by saying goodbye to two of its most beloved cast members.

## Pete Davidson, Kate McKinnon say goodbye to 'SNL'
 - [https://www.cnn.com/videos/media/2022/05/22/snl-pete-davidson-kate-mckinnon-aidy-bryant-goodbyes.cnn](https://www.cnn.com/videos/media/2022/05/22/snl-pete-davidson-kate-mckinnon-aidy-bryant-goodbyes.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 07:44:41+00:00

During the season finale of "Saturday Night Live" a number of long-time cast members said their goodbyes.

## Good news: Greater one-horned rhino population is on the way up
 - [https://www.cnn.com/2022/05/22/world/rhino-population-population-growth-scn-trnd/index.html](https://www.cnn.com/2022/05/22/world/rhino-population-population-growth-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 05:23:42+00:00

Things are looking up for the greater one-horned rhino.

## Ukraine's natural environment is another casualty of war. The damage could be felt for decades
 - [https://www.cnn.com/2022/05/22/europe/ukraine-russia-war-environment-intl-cmd/index.html](https://www.cnn.com/2022/05/22/europe/ukraine-russia-war-environment-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 05:00:59+00:00

The pine forests around Irpin are Oleh Bondarenko's happy place. He discovered them as a child, when his mom sent him to the area for summer camp, and he has been coming back ever since.

## Australian voters deliver strong message on climate, ending conservative government's 9-year rule
 - [https://www.cnn.com/2022/05/21/australia/australia-election-results-morrison-albanese-intl-hnk/index.html](https://www.cnn.com/2022/05/21/australia/australia-election-results-morrison-albanese-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 01:31:40+00:00

Labor Party leader Anthony Albanese will be Australia's next Prime Minister, according to projections by three major news networks

## Michigan governor declares state of emergency after powerful tornado rips through town
 - [https://www.cnn.com/2022/05/21/weather/gaylord-michigan-tornado-saturday/index.html](https://www.cnn.com/2022/05/21/weather/gaylord-michigan-tornado-saturday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 01:16:23+00:00

Two people are dead after a powerful tornado ripped roofs off buildings and flipped cars in a northern Michigan town on Friday, prompting the governor to declare a state of emergency for the area.

## Naomi Osaka: A year after her sudden withdrawal, four-time tennis grand slam champion partakes in French Open media session
 - [https://www.cnn.com/2022/05/21/tennis/naomi-osaka-french-open-media-spt-intl/index.html](https://www.cnn.com/2022/05/21/tennis/naomi-osaka-french-open-media-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 00:46:27+00:00

Four-time tennis grand slam champion Naomi Osaka returned to the French Open to meet the media on Friday -- a year after her sudden withdrawal from the major tournament.

## Biden offers message for Kim Jong Un as he prepares to wrap first leg of his Asia trip
 - [https://www.cnn.com/collections/biden-asia-trip-0522-intl-app/](https://www.cnn.com/collections/biden-asia-trip-0522-intl-app/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 00:45:07+00:00



## Days-long roadblocks, missiles and 'lots of blood': Civilians recall terrifying attempts to flee Russian-occupied cities
 - [https://www.cnn.com/collections/ukraine-0522-intl-app/](https://www.cnn.com/collections/ukraine-0522-intl-app/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 00:37:03+00:00



## Japan turns away from post-WWII pacifism as China threat grows
 - [https://www.cnn.com/2022/05/21/asia/japan-us-alliance-quad-summit-defense-hnk-dst-intl/index.html](https://www.cnn.com/2022/05/21/asia/japan-us-alliance-quad-summit-defense-hnk-dst-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-05-22 00:13:13+00:00

Japanese Prime Minister Fumio Kishida is a man on a mission.


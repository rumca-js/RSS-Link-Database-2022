# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Dlaczego zegarki pokazujące 10:10 sprzedają się lepiej?
 - [https://www.youtube.com/watch?v=gDuJnQn6DxI](https://www.youtube.com/watch?v=gDuJnQn6DxI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-05-22 00:00:00+00:00

#TechWeek
Darmowy fragment książki "Liczby nie kłamią", wyd. Insignis - https://bit.ly/3MC2scg
Dziś w odcinku:
00:00 Wstęp
00:19 Dobry wieczór!
00:23 Koty nas rozumieją
00:47 Ustawienie wskazówek zegarków wpływa na ich sprzedaż
01:40 Nowe zegarki Withings
02:07 Nowy MiBand od Xiaomi
02:36 Bankructwo Google w Rosji
02:48 Niewidzialne Rosyjskie lasery
03:20 Rosja zaczyna produkcję Łady
03:47 McDonald wychodzi z Rosji
04:18 Fragment sponsorowany książki wyd. Insignis
05:06 Nowa lodówka Samsung
05:30 Targi IFA
05:40 Okulary AR/VR od Apple
05:54 Okulary AR/VR od Metavers
06:47 Okulary AR od Qualcomm
06:55 Huawei Mate XS 2
07:20 Darmowe aplikacje w App Gallery Huawei
08:10 Nowa kolekcja Znośnych ciuchów niebawem! - Znosne.pl
08:52 Pożegnanko
09:09 Znośnego tygodnia!

Źródła:
Twój kot prawdopodobnie rozumie: https://bit.ly/39FXP2a
Dlaczego zegarki pokazujące 10:10 sprzedają się lepiej? https://bit.ly/3sSsgZQ
Nowy smart zegarek od Withings: https://bit.ly/3yRFdGR
Xiaomi Mi Band 7 nadchodzi: https://bit.ly/3ahCNr1
Google bankrutuje w Rosji: https://bit.ly/3MEHj12
Rosja twierdzi, że ma broń laserową: https://bit.ly/39DNHXH
Broń laserowa: https://bit.ly/3sPj2x8
Rosja będzie produkować Ladę: https://cnn.it/3LAppLC
McDonald's wynosi się z Rosji: https://cnb.cx/3wFfEGl
Lodówka Samsunga: https://bit.ly/3G8bV8u
Apple coraz dalej z produkcją okularów AR/VR: https://bit.ly/3wKhXIa
Mark Zuckerberg pokazuje okulary do VRu, ale je ukrywa: https://bit.ly/3wBbyAd
Qualcomm też ma nowe okulary: https://bit.ly/3yRoCDb
Globalna premiera składanego Huaweia: https://bit.ly/3wBAnMD
Płatne appki za darmo w Huaweiowym App Gallery: https://bit.ly/3MF56xE

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Babylon Bee Weak-ly News Update 5/23/2022: McDonalds Leaves Russia and Netflix Goes Unwoke
 - [https://www.youtube.com/watch?v=7FLYfwdIseQ](https://www.youtube.com/watch?v=7FLYfwdIseQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-05-23 00:00:00+00:00

Host Adam Yenser gives us the news of the week like Netflix trying to turn their woke ship around, McDonalds crushing Russia by packing up their McDoubles and going home, and America teetering on the brink of a revolt due to undelivered pizzas.

Watch the full podcast here: https://www.youtube.com/watch?v=OIDHpWnGEyE

Follow Adam on Youtube: https://www.youtube.com/user/adamyenser

Become a premium subscriber: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


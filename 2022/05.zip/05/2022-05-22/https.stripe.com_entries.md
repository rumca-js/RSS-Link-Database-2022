## Migrating millions of lines of code to TypeScript
 - [https://stripe.com/blog/migrating-to-typescript](https://stripe.com/blog/migrating-to-typescript)
 - RSS feed: https://stripe.com
 - date published: 2022-05-22 11:37:14.619363+00:00

On Sunday, March 6, we migrated we converted more than 3.7 million lines of code with a single pull request. The next day, hundreds of engineers came in to start writing TypeScript for their projects.


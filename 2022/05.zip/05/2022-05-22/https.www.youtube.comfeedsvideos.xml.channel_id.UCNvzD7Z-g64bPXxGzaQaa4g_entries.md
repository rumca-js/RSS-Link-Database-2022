# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Video Game Cutscenes You CAN ACTUALLY BREAK
 - [https://www.youtube.com/watch?v=ryLJo3O_c5s](https://www.youtube.com/watch?v=ryLJo3O_c5s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-05-23 00:00:00+00:00

Some game stories and moments can be changed in surprising ways. Here are some of our favorite deep-cut examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:13 Number 10
1:08 Number 9 
2:16 Number 8
3:34 Number 7
4:54 Number 6
6:19 Number 5
7:23 Number 4 
8:26 Number 3
9:41 Number 2
10:42 Number 1

## 10 Ridiculous BOSSES Someone NEEDS TO EXPLAIN
 - [https://www.youtube.com/watch?v=ANq7g3w9-mI](https://www.youtube.com/watch?v=ANq7g3w9-mI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-05-22 00:00:00+00:00

Some video game boss designs are truly out of this world. Here are some mind-bendingly strange ones.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:12 Number 10
1:49 Number 9 
3:19 Number 8
4:19 Number 7
5:19 Number 6
6:50 Number 5
7:50 Number 4 
8:46 Number 3
10:02 Number 2
11:03 Number 1


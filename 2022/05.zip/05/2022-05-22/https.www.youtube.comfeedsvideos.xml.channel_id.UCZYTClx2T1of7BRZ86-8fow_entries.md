# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Why Our Nights Are Getting Hot
 - [https://www.youtube.com/watch?v=kyxdjJD7t_0](https://www.youtube.com/watch?v=kyxdjJD7t_0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-05-23 00:00:00+00:00

Head to https://linode.com/scishow to get a $100 60-day credit on a new Linode account. Linode offers simple, affordable, and accessible Linux cloud solutions and services.

The average global temperature is on the rise, evidenced by the ten warmest years on record happening since 2005. But this isn’t just about greenhouse gases preventing heat from escaping. Another culprit comes in the form of…clouds. 

Hosted by: Stefan Chin

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Sam Lutfi, Bryan Cloer, Kevin Bealer, Christoph Schwanke, Tomás Lagos González, Jason A Saslow, Tom Mosner, Jacob, Ash, Eric Jensen, Jeffrey Mckishen, Alex Hackman, Christopher R Boucher, Piya Shedden, Jeremy Mysliwiec, Chris Peters, Dr. Melvin Sanicas, charles george, Adam Brainard, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:
https://news.un.org/en/story/2022/04/1116442
https://www.cabdirect.org/cabdirect/abstract/20103355550
https://www.mdpi.com/2072-4292/12/21/3604/pdf
https://www.usgs.gov/news/national-news-release/usgs-study-reveals-interactive-effects-climate-change-invasive-species
https://www.nps.gov/articles/000/wildlife-climateimpact.htm
https://www.eurekalert.org/news-releases/749962
https://www.usgs.gov/news/national-news-release/usgs-study-reveals-interactive-effects-climate-change-invasive-species
https://www.climate.gov/news-features/blogs/beyond-data/its-not-heat-its-humidity
https://www.climate.gov/news-features/understanding-climate/climate-change-global-temperature
https://ugc.berkeley.edu/background-content/re-radiation-of-heat/
https://isccp.giss.nasa.gov/role.html#SYSTEM_FEEDBACK
https://onlinelibrary.wiley.com/doi/full/10.1111/gcb.15336
https://rmets.onlinelibrary.wiley.com/doi/10.1002/joc.4688
https://www.climate.gov/news-features/understanding-climate/climate-change-global-temperature
https://earthobservatory.nasa.gov/world-of-change/global-temperatures

Image Sources:
https://commons.wikimedia.org/wiki/File:Global_Temperature_Anomaly.gif
https://www.gettyimages.com/detail/video/aerial-view-truck-forest-fire-burning-smoking-and-making-stock-footage/1299407782?adppopup=true
https://onlinelibrary.wiley.com/doi/full/10.1111/gcb.15336
https://www.gettyimages.com/detail/photo/red-rock-canyon-sunshine-royalty-free-image/1169181819?adppopup=true
https://www.gettyimages.com/detail/illustration/vector-layered-paper-cut-style-greenhouse-royalty-free-illustration/1194209537?adppopup=true
https://www.gettyimages.com/detail/video/time-lapse-footage-of-aerial-view-of-vibrant-yellow-stock-footage/1334913414?adppopup=true
https://www.gettyimages.com/detail/video/cell-structure-view-of-leaf-surface-showing-plant-cells-stock-footage/1273304299?adppopup=true
https://www.gettyimages.com/detail/video/owl-at-night-with-full-moon-stock-footage/512585854?adppopup=true
https://www.gettyimages.com/detail/video/corn-field-landscape-on-rainy-day-stock-footage/1341285115?adppopup=true
https://www.gettyimages.com/detail/video/macro-time-lapse-blooming-sunflower-head-close-up-stock-footage/1334458693?adppopup=true
https://www.gettyimages.com/detail/video/female-lions-drinks-from-a-waterhole-stock-footage/1308023252?adppopup=true
https://www.gettyimages.com/detail/photo/golden-wheat-field-and-sunny-day-royalty-free-image/1343164185?adppopup=true
https://www.gettyimages.com/detail/photo/ripe-rice-on-the-farm-in-autumn-season-royalty-free-image/1322226891?adppopup=true
https://www.gettyimages.com/detail/photo/libya-royalty-free-image/157313406?adppopup=true
https://www.gettyimages.com/detail/photo/family-harvesting-green-beans-royalty-free-image/1340311542?adppopup=true
https://www.gettyimages.com/detail/photo/prairie-storm-saskatchewan-canada-royalty-free-image/1172325528?adppopup=true


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I’m tired of winning (and it's awesome) - AMD COMPUTEX 2022
 - [https://www.youtube.com/watch?v=zTZuD4fVutc](https://www.youtube.com/watch?v=zTZuD4fVutc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-05-23 00:00:00+00:00

New Customers Exclusive – Get $50 off your purchase of select AMD CPUs: https://micro.center/93a4f6
Shop Micro Center’s New Motherboard and CPU Bundles: https://micro.center/460e92  

Check out Micro Center’s custom PC Builder: https://micro.center/7eec2c
Submit your Build to the Micro Center Build Showcase: https://micro.center/332cf8

Get 50% off (up to $200) your annual subscription when you sign up with Zoho Desk at: https://lmg.gg/zohodeskltt

AMD’s on a roll, and while Intel has successfully fired back, there’s more on the way. With competition alive and well in the CPU space, it’s time for a PC gaming renaissance not seen since the 2000s.

Discuss on the forum: https://linustechtips.com/topic/1432766-i%E2%80%99m-tired-of-winning-and-its-awesome/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:05 AMD Ryzen 7000 details
2:16 Ryzen 7000 performance
3:57 All APU All Day Long
4:26 Socket AM5 chipset features
5:16 Meet the new chipsets
6:08 AMD changed the industry
7:00 What? AMD laptops are evolving!
8:18 Odds & ends, availability, and conclusion

## The Desk Made of Radiators can cool ANYTHING
 - [https://www.youtube.com/watch?v=u6WDvzlmtSM](https://www.youtube.com/watch?v=u6WDvzlmtSM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-05-22 00:00:00+00:00

Happy 6th Anniversary, Celebrate FlexiSpot Tech Day on Sept 7-9, Up to $200 OFF! https://bit.ly/3Qn5W3c 
Don't miss the Flash Sale on FlexiSpot E7, Get $130 OFF on Sept 7th ONLY! https://bit.ly/3RnHyjm 

Check out the FlexiSpot Facebook group to win FREE standing desks:  https://www.facebook.com/groups/flexiblewfh
Check out the FlexiSpot brand anniversary event for sitewide sales:  https://www.flexispot.com/flexispot-day

Normally your desk just holds up a computer... But what if it cooled it too?

Discuss on the forum: https://linustechtips.com/topic/1432674-the-desk-made-of-radiators-can-cool-anything/

Check out Protocase: https://lmg.gg/2MK1L

Buy an Alphacool 560mm Radiator: https://geni.us/UEt8BgU
Buy an Alphacool Eisball RGB Reservoir: https://geni.us/AZbrO2
Buy an Intel Core i9-12900KS: https://geni.us/QcbZlJm
Buy an RTX 3090: https://geni.us/AoDLe

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 - Intro
0:27 - The Plan
3:10 - Assembly Begins
5:40 - Plumbing the Loop
8:03 - Desk Modification
9:53 - Filling the Loop
11:37 - Attaching the Rads to the Desk
13:00 - POST?
13:49 - Linus Reaction
18:27 - Jake Reaction
20:20 - Flexispot!
20:48 - Outro


# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The massive Fatigue Carousel helps keep roads safe
 - [https://www.youtube.com/watch?v=nGlhMk1hEZw](https://www.youtube.com/watch?v=nGlhMk1hEZw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-05-23 00:00:00+00:00

The "accelerated pavement testing facility" in Nantes can simulate decades of road traffic in a few months. Here's how. ■ More information: https://lames.univ-gustave-eiffel.fr/en/equipments/the-pavement-fatigue-carrousel

Editor: Dave Stevenson http://davestevenson.co.uk
Camera: Guillaume Juin https://www.guillaumejuin.fr
Producer: Axel Zeiliger at Block8 https://block8production.com

Thanks to Jérémie Chabot for the suggestion

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


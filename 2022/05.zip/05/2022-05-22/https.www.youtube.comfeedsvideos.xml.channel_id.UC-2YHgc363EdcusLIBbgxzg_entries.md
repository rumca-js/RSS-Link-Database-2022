# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Deadliest Company In Human History | Answers With Joe
 - [https://www.youtube.com/watch?v=NtCgZmdzWNE](https://www.youtube.com/watch?v=NtCgZmdzWNE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-05-23 00:00:00+00:00

Get a year of Nebula and Curiosity Stream for only $14.79 when you sign up at http://www.curiositystream.com/joescott
Spices might be the single thing in history that most shaped our world today. That sounds crazy, but spices once were as valuable as gold. It was an international currency that created and destroyed civilizations and great cities, and enslaved millions. And along the way created the very economy we live under today, by way of the most powerful corporation in human history.

This is a video about the Spice Trade. And the world it created.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPGzF
Apple Podcasts 👉 https://apple.co/3j94kfq
Google Podcasts 👉 https://bit.ly/3qZCo1V

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:
https://www.investopedia.com/ask/answers/08/first-company-issue-stock-dutch-east-india.asp
https://www.worldsfirststockexchange.com/2020/10/01/what-was-the-return-on-voc-shares/
https://kalamkopi.files.wordpress.com/2017/04/m-c-ricklefs-sejarah-indonesia-modern-1200.pdf 
https://oec.world/en/profile/hs/spices
https://en.wikipedia.org/wiki/Dutch_conquest_of_the_Banda_Islands

TIMESTAMPS:
0:00 - Intro
2:13 - The Spice Trade
6:04 - Spices As a Status Symbol
7:29 - The History of Spice
11:07 - New Sea Routes
13:45 - Tangent Cam
15:18 - The Dutch East India Company
18:03 - Sponsor
19:08 - The Island of Ran
20:30 - Final thoughts


# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Google Pixel Tablet: everything we know so far
 - [https://www.techradar.com/news/google-pixel-tablet](https://www.techradar.com/news/google-pixel-tablet)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-05-22 10:00:56+00:00

Google has teased a new slate. Here's everything that we know about the Google Pixel Tablet so far.


## The balance has shifted away from SPAs | Read the Tea Leaves
 - [https://nolanlawson.com/2022/05/21/the-balance-has-shifted-away-from-spas/](https://nolanlawson.com/2022/05/21/the-balance-has-shifted-away-from-spas/)
 - RSS feed: https://nolanlawson.com
 - date published: 2022-05-22 07:23:28.130339+00:00

There’s a feeling in the air. A zeitgeist. SPAs are no longer the cool kids they once were 10 years ago. Hip new frameworks like Astro, Qwik, and Elder.js are touting their MPA capabilities w…


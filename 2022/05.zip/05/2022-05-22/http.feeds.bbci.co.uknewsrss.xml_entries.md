# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Why is climate 'doomism' going viral – and who's fighting it?
 - [https://www.bbc.co.uk/news/blogs-trending-61495035?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-trending-61495035?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 23:16:59+00:00

Climate "doomers" believe it’s far too late to do anything about climate change - but they're wrong.

## 'I was repeatedly ignored' - report finds maternity racism
 - [https://www.bbc.co.uk/news/health-61497923?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-61497923?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 23:14:18+00:00

The charity Birthrights conducted a year-long investigation into "racial injustice" in maternity care.

## Palm oil firms depriving tribes of millions of dollars
 - [https://www.bbc.co.uk/news/world-61509744?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-61509744?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 23:07:20+00:00

Companies supplying major manufacturers fail to meet promises to share land, joint BBC investigation finds.

## Spaghetti Junction at 50: What lies beneath?
 - [https://www.bbc.co.uk/news/uk-england-birmingham-61482844?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-61482844?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 23:06:28+00:00

Images capture life below one of the UK's best known road structures on eve of its 50th birthday.

## The sci-fi technology tackling malarial mosquitos
 - [https://www.bbc.co.uk/news/business-61505102?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61505102?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 23:05:12+00:00

Gene drive development makes a genetically modified gene that spreads widely within populations.

## Match of the Day analysis: How Ilkay Gundogan won the Premier League for Manchester City
 - [https://www.bbc.co.uk/sport/av/football/61545620?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/61545620?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 23:02:19+00:00

Match of the Day pundits Ian Wright and Alan Shearer analyse Manchester City's stunning late comeback to win the Premier League title, highlighting the performance of Ilkay Gundogan, who scored two goals off the bench.

## Colonel in Iran Revolutionary Guards assassinated
 - [https://www.bbc.co.uk/news/world-middle-east-61546145?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-61546145?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 22:13:17+00:00

Sayad Khodai, a senior figure in the elite Quds force, was reportedly shot dead in his car by two gunmen.

## Manchester City boss Pep Guardiola says champions are 'legends'
 - [https://www.bbc.co.uk/sport/football/61543112?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61543112?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 20:02:32+00:00

Manchester City's manager says his side "are legends" after securing their fourth Premier League title in five seasons.

## Ukraine peace deal: Kyiv rules out ceding land to Russia
 - [https://www.bbc.co.uk/news/world-europe-61542090?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61542090?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 19:29:15+00:00

Zelensky adviser says Kyiv will not agree a peace deal with Russia that involves giving up territory.

## Pampered pooches ride Japan's Shinkansen in style
 - [https://www.bbc.co.uk/news/world-asia-61543052?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-61543052?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 14:46:31+00:00

Paws aboard! A pet-friendly service premiers on the iconic train as calls grow for easier pet travel.

## Harry Kane: Exhibition to explore England captain's rise to the top
 - [https://www.bbc.co.uk/news/uk-england-london-61393726?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-61393726?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 13:15:20+00:00

The England captain's golden boot and his MBE are among the items on display.

## Professor Brian Cox: Maybe humans are the Martians
 - [https://www.bbc.co.uk/news/science-environment-61540945?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-61540945?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 11:02:02+00:00

The renowned physicist reflects on whether civilisation, like us, exists in other galaxies.

## Manchester Arena attack: Events mark fifth anniversary
 - [https://www.bbc.co.uk/news/uk-england-manchester-61522046?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-61522046?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 10:43:27+00:00

Survivor Freya Lewis will start the Great Manchester Run as events mark the attack which killed 22 people.

## 'Welcome to Luton' stunt panics Gatwick Airport arrivals
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-61541224?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-61541224?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 10:37:56+00:00

YouTuber, Max Fosh, says the "prank" is to put smiles on faces and is sorry for any confusion caused.

## Afghanistan's female TV presenters cover their faces
 - [https://www.bbc.co.uk/news/world-asia-61541064?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-61541064?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 10:27:21+00:00

A day after defying a Taliban order, women on TV fell in line with face-covering veils.

## Deadline approaches for officials set to be named by Sue Gray
 - [https://www.bbc.co.uk/news/uk-61539326?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61539326?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 10:19:57+00:00

Those expected to be identified in the report on No 10 gatherings have until Sunday afternoon to respond.

## Monkeypox: Israel and Switzerland confirm cases
 - [https://www.bbc.co.uk/news/health-61540474?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-61540474?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 09:54:23+00:00

It means the viral outbreak has spread to 14 countries with more than 80 cases detected so far.

## World Rugby Sevens: England and Argentina criticised over two-minute try
 - [https://www.bbc.co.uk/sport/rugby-union/61540417?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/61540417?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 09:16:31+00:00

England and Argentina are criticised over a long delay before scoring a try that helps both sides progress from their World Rugby Sevens men's group in Toulouse.

## Floods in Bangladesh and India affect millions
 - [https://www.bbc.co.uk/news/world-asia-61540944?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-61540944?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 09:12:21+00:00

At least 50 people are dead after some areas are battered by widespread flooding and landslides.

## Australia election: Anthony Albanese signals climate policy change
 - [https://www.bbc.co.uk/news/world-australia-61539426?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-61539426?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 06:55:13+00:00

Anthony Albanese vows to take the nation in a new direction, creating a renewable energy superpower.

## Australia election: A great shock to the system
 - [https://www.bbc.co.uk/news/world-australia-61503380?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-61503380?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 06:41:06+00:00

Politics will now be greener, more feminine, and more emphatically Australian, writes Nick Bryant.

## UK charities call for menstrual leave for severe pain
 - [https://www.bbc.co.uk/news/health-61477168?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-61477168?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 05:22:31+00:00

It comes after a draft bill was approved in Spanish parliament to allow three days of leave a month.

## Ukraine war: Against the thud of artillery, miners struggle on
 - [https://www.bbc.co.uk/news/world-europe-61523010?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61523010?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 05:10:41+00:00

Miners in eastern Ukraine on how a difficult job has become even more dangerous.

## The Papers: PM 'to sacrifice top official' and free tuition plan
 - [https://www.bbc.co.uk/news/blogs-the-papers-61538941?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-61538941?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 04:53:36+00:00

The expected fallout from the Sue Gray report and plans to provide tuition to every pupil in need lead the papers.

## The Hacienda rises again: The Manchester nightclub raves on after 40 years
 - [https://www.bbc.co.uk/news/entertainment-arts-61506634?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-61506634?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 01:58:07+00:00

Forty years after it opened, the legendary nightclub is credited with changing music and Manchester.

## Future foods: What you could be eating by 2050
 - [https://www.bbc.co.uk/news/science-environment-61505548?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-61505548?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 00:30:47+00:00

Scientists say we need to future-proof our diets in a warming world by eating little-known plants.

## Governments should subsidise food and energy, says IMF boss
 - [https://www.bbc.co.uk/news/business-61523624?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61523624?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 00:27:05+00:00

Managing director Kristalina Georgieva says state subsidies can help with the cost of living.

## 'How the state tried to silence my abusive agent expose'
 - [https://www.bbc.co.uk/news/uk-61528286?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61528286?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 00:22:02+00:00

BBC News reporter Daniel De Simone on his courtroom fight to reveal how an MI5 agent abused women.

## Social media: Did the pandemic poison online politics?
 - [https://www.bbc.co.uk/news/uk-politics-61408745?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61408745?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 00:04:09+00:00

As the UK spent countless hours online during lockdown, how much has it changed us?

## 'My first court case: Prosecuting my father's killers'
 - [https://www.bbc.co.uk/news/world-south-asia-61507258?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-south-asia-61507258?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 00:03:17+00:00

Shagufta Ahmed's first job was to get justice for her father, a lecturer murdered after he blew the whistle on a colleague.

## ‘I’m a Rasta, I’m British, I’m an officer and a commando’
 - [https://www.bbc.co.uk/news/uk-61496548?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61496548?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-05-22 00:01:20+00:00

Capt Kidane Cousland is helping ensure Rastafarians can express their faith while serving in the military.


# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## breadwinner | Kacey Musgraves | funk cover ft. Caleb Hawley
 - [https://www.youtube.com/watch?v=SWW-tVxU2Ro](https://www.youtube.com/watch?v=SWW-tVxU2Ro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-05-23 00:00:00+00:00

Don't miss your last chance to get Frisky Business on vinyl! Sign up to Vinyl Club by May 31st to reserve your copy! http://modal.scarypocketsfunk.com/patreon

Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Kacey Musgraves' "breadwinner" by Scary Pockets & Caleb Hawley.

MUSICIAN CREDITS
Lead vocal/Guitar: Caleb Hawley
Guitar: Eric Krasno, Ryan Lerman
Drums: Otis McDonald
Bass: Nicole Row
Keys: Jack Conte

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engineer: Nicole Schmidt
Mixing/Mastering: Caleb Parker
Addt’l Production, Synth, Percussion: Jesse Singer

VIDEO CREDITS
DP: Ricky Chavez 
Editor: Adam Kritzberg

SKETCH CREDITS
Director/Production Designer: Ryan Wagner
Script: Luke Wagner
Lisa/Bride: Allison Spence Brown
Rabbi: James Gadson
DP: Matt Burke
Sound: Anthony Newen
Editor: Jude Smith

Recorded Live at The Village in Los Angeles, CA.

#ScaryPockets #Funk #KaceyMusgraves #CalebHawley #breadwinner


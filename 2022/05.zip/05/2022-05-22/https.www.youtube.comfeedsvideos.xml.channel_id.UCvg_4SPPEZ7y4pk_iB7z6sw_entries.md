# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## EA Is Gonna Get Bought Out (Probably)
 - [https://www.youtube.com/watch?v=yqAMRqUgntY](https://www.youtube.com/watch?v=yqAMRqUgntY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2022-05-23 00:00:00+00:00

Well, somebody's gonna buy EA. I think. Why else would I make a video on it.
Maybe Disney will give the next Battlefield some Tailspin DLC.

My other channel: https://www.youtube.com/channel/UC2_KC8lshtCyiLApy27raYw
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub

Additional Footage Credits:
Tech & Nostalgia Kingdom
IGN
Engadget


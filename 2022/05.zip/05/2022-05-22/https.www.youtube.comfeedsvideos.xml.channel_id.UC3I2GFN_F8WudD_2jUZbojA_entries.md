# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## St. Paul & The Broken Bones - 3000 AD Mass / The Last Dance (Live on KEXP)
 - [https://www.youtube.com/watch?v=6K1pWxj1cHo](https://www.youtube.com/watch?v=6K1pWxj1cHo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-23 00:00:00+00:00

http://KEXP.ORG presents St. Paul & The Broken Bones performing “3000 AD Mass” and "The Last Dance" live in the KEXP studio. Recorded May 3, 2022.

Paul Janeway - Vocals
Jesse Phillips - Bass
Browan Lollar - Guitar
Al Gamble - Keys
Allen Branstetter - Trumpet
Kevin Leon - Drums
Amari Ansari - Sax
Chad Fisher - Trombone

Host: Troy Nelson
Audio Engineers: David Liles & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://stpaulandthebrokenbones.com
http://kexp.org

## St. Paul & The Broken Bones - Apollo (Live on KEXP)
 - [https://www.youtube.com/watch?v=yugZx7BYGws](https://www.youtube.com/watch?v=yugZx7BYGws)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-23 00:00:00+00:00

http://KEXP.ORG presents St. Paul & The Broken Bones performing “Apollo” live in the KEXP studio. Recorded May 3, 2022.

Paul Janeway - Vocals
Jesse Phillips - Bass
Browan Lollar - Guitar
Al Gamble - Keys
Allen Branstetter - Trumpet
Kevin Leon - Drums
Amari Ansari - Sax
Chad Fisher - Trombone

Host: Troy Nelson
Audio Engineers: David Liles & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://stpaulandthebrokenbones.com
http://kexp.org

## St. Paul & The Broken Bones - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Z5JtVA87tXk](https://www.youtube.com/watch?v=Z5JtVA87tXk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-23 00:00:00+00:00

http://KEXP.ORG presents St. Paul & The Broken Bones performing live in the KEXP studio. Recorded May 3, 2022.

Songs:
3000 AD Mass / The Last Dance
Minotaur
Love Letter From A Red Roof Inn
Apollo

Paul Janeway - Vocals
Jesse Phillips - Bass
Browan Lollar - Guitar
Al Gamble - Keys
Allen Branstetter - Trumpet
Kevin Leon - Drums
Amari Ansari - Sax
Chad Fisher - Trombone

Host: Troy Nelson
Audio Engineers: David Liles & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://stpaulandthebrokenbones.com
http://kexp.org

## St. Paul & The Broken Bones - Love Letter From A Red Roof Inn (Live on KEXP)
 - [https://www.youtube.com/watch?v=IXaBNoafL_U](https://www.youtube.com/watch?v=IXaBNoafL_U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-23 00:00:00+00:00

http://KEXP.ORG presents St. Paul & The Broken Bones performing “Love Letter From A Red Roof Inn” live in the KEXP studio. Recorded May 3, 2022.

Paul Janeway - Vocals
Jesse Phillips - Bass
Browan Lollar - Guitar
Al Gamble - Keys
Allen Branstetter - Trumpet
Kevin Leon - Drums
Amari Ansari - Sax
Chad Fisher - Trombone

Host: Troy Nelson
Audio Engineers: David Liles & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://stpaulandthebrokenbones.com
http://kexp.org

## St. Paul & The Broken Bones - Minotaur (Live on KEXP)
 - [https://www.youtube.com/watch?v=AnSx4ihAqfA](https://www.youtube.com/watch?v=AnSx4ihAqfA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-05-23 00:00:00+00:00

http://KEXP.ORG presents St. Paul & The Broken Bones performing “Minotaur” live in the KEXP studio. Recorded May 3, 2022.

Paul Janeway - Vocals
Jesse Phillips - Bass
Browan Lollar - Guitar
Al Gamble - Keys
Allen Branstetter - Trumpet
Kevin Leon - Drums
Amari Ansari - Sax
Chad Fisher - Trombone

Host: Troy Nelson
Audio Engineers: David Liles & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://stpaulandthebrokenbones.com
http://kexp.org


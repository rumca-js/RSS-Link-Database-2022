# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Why You Can’t Smell Yourself (and Other Ways Your Senses Lie to You)
 - [https://www.youtube.com/watch?v=30vTc1SOt_w](https://www.youtube.com/watch?v=30vTc1SOt_w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2022-06-21 00:00:00+00:00

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 
We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart
↓↓↓ More info and sources below ↓↓↓

There is an absolutely weird, but surprisingly common phenomenon called sensory adaptation that you experience every day in countless ways without even realizing it. Without this very strange phenomenon, you would be lost, overwhelmed, and completely unable to navigate the external world. In this episode, we’ll explore the many ways your brain “tunes out” most of what’s going on around you so that you can be the high-functioning smart people that we know you are.

-----------

Special thanks to our Brain Trust Patrons:
Ali Freiburger
Mehdi Damou
Barbora Bei
Ken Board
Clinger-Hamilton Family
Attila Pix
Burt Humburg
DeliciousKashmiri
Roy Lasris
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Amy Sowada
Eric Meer
Dustin
Karen Haskell



Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/


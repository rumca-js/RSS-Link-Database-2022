# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Sledgehammer | @itspetergabriel | funk cover ft. @BenBarnesMusic
 - [https://www.youtube.com/watch?v=PMh-pZ1FrIs](https://www.youtube.com/watch?v=PMh-pZ1FrIs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-06-20 00:00:00+00:00

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Peter Gabriel's "Sledgehammer" by Scary Pockets & Ben Barnes.

MUSICIAN CREDITS
Lead vocal: Ben Barnes
Drums: Abe Laboriel Jr.
Bass: Nick Campbell
Keys: Carey Frank
Guitar: Ariel Posen
Guitar: Ryan Lerman
Background vocals: Mario Jose, Abe Laboriel Jr.

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
DP: Kenzo Le 
Editor: Adam Kritzberg

Recorded Live at East West Studios in Los Angeles, CA.

#ScaryPockets #Funk #benbarnes #petergabriel #sledgehammer


# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Roland AIRA Compact Series Walkthrough
 - [https://www.youtube.com/watch?v=K_SeNRRrMS0](https://www.youtube.com/watch?v=K_SeNRRrMS0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-06-21 00:00:00+00:00

Let's take a look at the 3 new AIRA Compact friends and make a little jam on them ok?

Check prices at perfect circuit: https://bit.ly/37AzOZN

Watch my jam with them: https://youtu.be/JdkLMm0j4Fo

the roland aira compact series is three units, the t-8 (a drum machine and bassline unit), j-6 (a chord unit), and the e-4 (a voice transformer unit). each works together via midi to allow you to make the stupidest fun music you've ever made. source? me. I'm the source of that quote. i said it. just now.

00:00 overview
02:40 t-8 drums
07:43 j-6 chords
14:48 t-8 bass
18:08 e-4 voice
21:22 jam
25:07 recap
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


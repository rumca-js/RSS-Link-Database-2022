# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## January 6th: THE MUSICAL
 - [https://www.youtube.com/watch?v=f8C-DetMIDs](https://www.youtube.com/watch?v=f8C-DetMIDs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-06-21 00:00:00+00:00

YouTube restricted this video the first time we uploaded it since they decided that footage from the BLM riots was too violent. So we toned it down a notch for all to enjoy free of age restriction. Enjoy our touching music video covering the 525,600 minutes of mainstream media hyping up the January 6 Capitol riots while downplaying the BLM riots. 

Our own parody inspired by Colbert's parody of Seasons of Love.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


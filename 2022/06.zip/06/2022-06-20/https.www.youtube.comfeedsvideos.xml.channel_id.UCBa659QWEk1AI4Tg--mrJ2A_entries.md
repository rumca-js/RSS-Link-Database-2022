# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## Can you really drive while facing backwards?
 - [https://www.youtube.com/watch?v=hSmtKMx1CB4](https://www.youtube.com/watch?v=hSmtKMx1CB4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-06-20 00:00:00+00:00

The team at Sparkmate (https://Spkm.co/Build) asked if I had any ideas for things to build. And I realised that, yes, I had a question to answer: and it all goes back to an old kids' television show called "Captain Scarlet and the Mysterons"...

This isn't an advert for Sparkmate. I've not been paid, and they had no control over the edit, the story, or whether it was published at all. However, they've obviously given a large amount of time, money and effort to put this together, and hopefully that's clear from the video!

They're also hiring: https://Spkm.co/JoinTheSpark
And on Instagram: https://Spkm.co/Insta

Edited by Isla McTear

Captain Scarlet and the Mysterons is a Century 21 Television / ITC Entertainment production, and the full series is available on Blu-Ray here: https://amzn.to/3OlIZgp (that's an affiliate link)

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


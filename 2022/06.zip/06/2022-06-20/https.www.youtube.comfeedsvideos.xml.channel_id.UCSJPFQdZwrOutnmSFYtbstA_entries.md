# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Jurassic World: Dominion - An Absolute Dumpster Fire
 - [https://www.youtube.com/watch?v=9o2S2UycbYM](https://www.youtube.com/watch?v=9o2S2UycbYM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-06-21 00:00:00+00:00

The Jurassic World trilogy hasn't exactly distinguished itself as a smart, thought provoking successor to Jurassic Park, and Dominion does absolutely nothing to change that. In fact, it may be the worst movie in the entire franchise. 

Want to help support my work? Then consider pre-ordering my new book, Dark Harvest, from Amazon: https://www.amazon.com/Dark-Harvest-Will-Jordan-ebook/dp/B09T3JHVPM/ref=sr_1_1?crid=DVERFMEW7FNX&keywords=dark+harvest+will+jordan&qid=1651578672&sprefix=dark+harvest+will+jordan%2Caps%2C140&sr=8-1


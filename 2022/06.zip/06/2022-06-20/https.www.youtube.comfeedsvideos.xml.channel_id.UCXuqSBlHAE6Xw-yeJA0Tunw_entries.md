# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Who's Buying These? - MinisForum Elitemini B550
 - [https://www.youtube.com/watch?v=ihcGnBjUAm4](https://www.youtube.com/watch?v=ihcGnBjUAm4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-21 00:00:00+00:00

Buy a Seasonic TX 1000 PSU: https://geni.us/aryiquT

Get your Crucial DDR5 RAM today at: https://crucial.gg/LTT_DDR5

ATX? That's too big. Mini ITX? Nah, still too big. How about an upgradable NUC-alike where you can install your own AM4 CPU and slot the whole system into a bracket that holds a super powerful desktop GPU? Big when you need big, small when you need small. It's the perfect package. Or is it?

Discuss on the forum: https://linustechtips.com/topic/1438596-this-was-cool-until-it-wasnt/

Check out the Minisforum Elitemini B550: https://bit.ly/3QOFf9g

Buy a Ryzen 3800X3D: https://geni.us/WDWDj36

Buy a Ryzen 5700G: https://geni.us/zyox9

Buy an AMD 6800XT: https://geni.us/JOgALCe

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:53 EliteMini B550
2:11 What makes it weird.
4:41 The Bracket
5:35 The Cables
7:14 The Big Moment
8:37 Testing and Thoughts
11:16 Outro

## I'm shocked how well this worked - Steam Deck Cooler Upgrade
 - [https://www.youtube.com/watch?v=-DUWTteit-0](https://www.youtube.com/watch?v=-DUWTteit-0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-20 00:00:00+00:00

Visit manscaped.com/TECH for 20% OFF + Free Shipping

PDQ.com: Start your FREE trial now! At https://lmg.gg/99Snl

I love the Steam Deck, but unfortunately it can be a bit loud and runs kinda hot.. well today we change that.

Discuss on the forum: https://linustechtips.com/topic/1438378-im-shocked-how-well-this-worked-hot-rodded-steam-deck/

3D Model: https://grabcad.com/library/steam-deck-m-2-heatsink-adapter-1

Check out the Steam Deck: https://lmg.gg/OazbI
Buy a Thermalright HR-09 2280 Heatsink :https://geni.us/krOO
Buy a Thermalright HR-09 2280 Pro Heatsink: https://geni.us/Ih0V
Buy a Noctua NF-A4x10 FLX: https://geni.us/xAgRLK

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 - Our crazy idea...
0:55 - PDQ!
1:20 - Why Linus wants this
4:25 - The Plan
8:19 - It... might actually work?
9:40 - Manufacturing
13:44 - Assembly, thermal pads
16:50 - Firing it up
19:30 - This looks awesome
20:50 - Fan?
22:40 - Manscaped!
23:15 - Outro


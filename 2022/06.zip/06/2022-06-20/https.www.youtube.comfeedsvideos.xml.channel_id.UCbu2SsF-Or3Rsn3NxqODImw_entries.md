# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Fire Emblem Warriors: Three Hopes Review
 - [https://www.youtube.com/watch?v=A5Ef3HbML8c](https://www.youtube.com/watch?v=A5Ef3HbML8c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-06-21 00:00:00+00:00

Three Hopes features the often repetitive combat style developer Omega Force is renowned for, but enough dedicated Fire Emblem mechanics exist to make it feel like something more than a simple spin-off.

## PS5 Products May Be Revealed Next Week | GameSpot News
 - [https://www.youtube.com/watch?v=2vMl9WizTEw](https://www.youtube.com/watch?v=2vMl9WizTEw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-06-21 00:00:00+00:00

Sony may reveal new hardware for the PS5 next week, Microsoft confirms there is a controller shortage and Call of Duty teases a Terminator collaboration. 
#GamingNews #PS5 #xbox 

Sony reportedly has more hardware in development, as it's claimed that new headsets and gaming monitors will be revealed in the coming weeks. This gear is said to be part of the new InZone line, and will feature three new headsets designed to cater to various price points.

Meanwhile, Microsoft has now confirmed that there is a shortage of Xbox Controllers.Speaking to VGC, the company has confirmed that "supply disruptions" are currently affecting stock, with a large number of big retailers completely sold out. Users on ResetEra recently shared their inability to acquire a new Xbox controller across Europe, and if there were any it was in very limited supply or through scalpers.

STAMPS
00:00 - Intro
00:06 - New PS5 Hardware
01:43 - Xbox Controllers
02:41 - COD Terminator

## Cyberpunk 2077 Gets Flying Cars Thanks To New Mod | GameSpot News
 - [https://www.youtube.com/watch?v=zUi6EUMcZSo](https://www.youtube.com/watch?v=zUi6EUMcZSo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-06-20 00:00:00+00:00

Cyberpunk 2077 gains flying cars and bikes thanks to a new mod, Blizzard details Overwatch 2’s newest hero Junker Queen and Nintendo announces a Xenoblade Chronicles 3 direct.
#GamingNews #Cyberpunk2077 #Overwatch3  

Jack Humbert has fulfilled my dreams and created a mod called “Let There Be Flight” that lets players fly cars and bikes around Night City. And these aren’t your standard GTA cheat code looking flying cars, this mod has an animation for the wheels that turns them into thrusters. 

Cyberpunk Mod - https://github.com/jackhumbert/let_there_be_flight/releases
LastKnownMeal -  https://youtu.be/9ydRogJCEpw 

A frontline tank, Junker Queen is all about getting up close and personal and dealing damage with her battle ax and scattergun shotgun. Melee attacks with the ax, as well as hits with her Carnage ability or ultimate ability, Rampage, will inflict wounds on enemies. Junker Queen will be playable in the second round of the Overwatch 2 beta, which starts on June 28.

Call of Duty Season 4 is being dubbed Mercenaries of Fortune and sees now-feuding operators from Vanguard battling over gold. The updates will be available to download at 9 AM PT / 12 PM PT on June 21 for Vanguard and 9 AM PT / 12 PM ET on June 22 for Warzone.

STAMPS
00:00 - Intro
00:06 - Cyberpunk 2077
00:46 - Overwatch 2
01:43 - Call of Duty
02:39 - Xenoblade Chronicles 3

## Starfield - Everything to Know
 - [https://www.youtube.com/watch?v=9UX-91HFxAE](https://www.youtube.com/watch?v=9UX-91HFxAE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-06-20 00:00:00+00:00

Here's everything you need to know about Starfield.
Announced back in 2018, Starfield is Bethesda's first new intellectual property in 25 years, and as such, there is a lot of hype surrounding the upcoming project--and perhaps just as many questions. In an attempt to answer at least a few of them and help you keep up to date with what's going on with Starfield, we've compiled everything we know about the game so far.

00:00 - Intro
00:30 - Platforms
01:10 - Release Date
01:25 - Trailers
02:39 - Into the Starfield
04:32 - A "Hardcore" RPG
06:15 - The Story So Far
08:27 - Engine Overhaul
09:23 - Starfield on Game Pass

#Starfield

## Warhammer 40k: Rogue Trader - How Do You Play As 40k's Most Powerful Explorers?
 - [https://www.youtube.com/watch?v=v5UMbPaqdO4](https://www.youtube.com/watch?v=v5UMbPaqdO4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-06-20 00:00:00+00:00

Warhammer 40,000: Rogue Trader is the first ever CRPG set in the Grimdark of the 41st millenia, with that comes the opportunity to explore parts of the Warhammer franchise that no other game has touched on. What is there in 40k beyond war? How will characters and player choices play a part in roleplay and exploration?
Our own Warhammer nerd Dave Jewitt caught up with Owlcat's Alexander Gusev to find out a little more about Rogue Trader, and asks what a game like this means for Warhammer games as a whole.

#RogueTrader


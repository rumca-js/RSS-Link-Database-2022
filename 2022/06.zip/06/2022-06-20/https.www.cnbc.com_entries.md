## ‘The situation is serious’: Germany plans to fire up coal plants as Russia throttles gas supplies
 - [https://www.cnbc.com/2022/06/20/ukraine-war-germany-turns-to-coal-as-russia-throttles-gas-supplies.html](https://www.cnbc.com/2022/06/20/ukraine-war-germany-turns-to-coal-as-russia-throttles-gas-supplies.html)
 - RSS feed: https://www.cnbc.com
 - date published: 2022-06-20 13:01:44+00:00

‘The situation is serious’: Germany plans to fire up coal plants as Russia throttles gas supplies


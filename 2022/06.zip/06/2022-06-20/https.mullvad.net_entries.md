## We are removing the option to create new subscriptions - Blog | Mullvad VPN
 - [https://mullvad.net/en/blog/2022/6/20/were-removing-the-option-to-create-new-subscriptions/](https://mullvad.net/en/blog/2022/6/20/were-removing-the-option-to-create-new-subscriptions/)
 - RSS feed: https://mullvad.net
 - date published: 2022-06-20 19:04:24.912447+00:00

In order to store less data we will no longer accept NEW PayPal and Credit card subscriptions (recurring payments). One-time payments are not affected.


# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Could nuclear desalination plants beat water scarcity?
 - [https://www.bbc.co.uk/news/business-61483491?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61483491?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-06-20 23:16:31+00:00

Engineers are developing mobile, floating nuclear desalination plants to help solve water shortages.

## New rules proposed for buy now pay later
 - [https://www.bbc.co.uk/news/technology-61784020?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-61784020?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-06-20 16:04:56+00:00

The loans are used by millions but ministers want checks on affordability and clearer advertising.

## Can crumbling cookies sweeten UK data-protection plans?
 - [https://www.bbc.co.uk/news/technology-61865575?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-61865575?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-06-20 15:46:44+00:00

Government proposals to move away from EU data-protection laws post-Brexit have had a mixed reaction.


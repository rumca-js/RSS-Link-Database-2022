# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Watch the Artemis moon rocket's final prelaunch test on the launchpad
 - [https://www.cnn.com/2022/06/20/world/nasa-artemis-monday-test-attempt-scn/index.html](https://www.cnn.com/2022/06/20/world/nasa-artemis-monday-test-attempt-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 21:06:26+00:00

The Artemis I mega moon rocket is ready to fuel up.

## Macron has suddenly become as constrained as Biden
 - [https://www.cnn.com/2022/06/20/opinions/macron-france-biden-andelman/index.html](https://www.cnn.com/2022/06/20/opinions/macron-france-biden-andelman/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 20:56:51+00:00

Suddenly, with a single stroke, from one of Europe's most powerful, unassailable leaders, Emmanuel Macron has become as constrained as President Joe Biden.

## Authorities find boat of slain British journalist and indigenous expert in Brazilian Amazon
 - [https://www.cnn.com/2022/06/20/americas/brazil-boat-found-dom-phillips-bruno-pereira-intl/index.html](https://www.cnn.com/2022/06/20/americas/brazil-boat-found-dom-phillips-bruno-pereira-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 20:43:42+00:00

The boat in which British journalist Dom Phillips and indigenous expert Bruno Pereira were traveling before they were killed was found Sunday evening, according to the police.

## A lot of young women worry about the end of Roe. I would celebrate it
 - [https://www.cnn.com/2022/06/20/opinions/supreme-court-roe-abortion-women-groves/index.html](https://www.cnn.com/2022/06/20/opinions/supreme-court-roe-abortion-women-groves/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 20:30:54+00:00

In the coming days, the US Supreme Court could hand down a decision overturning Roe v. Wade, if we are to believe a draft of the decision leaked to the media several weeks back.

## Lawmaker reacts to Trump asking for 'equal time' at January 6 hearings
 - [https://www.cnn.com/videos/politics/2022/06/20/rep-eric-swalwell-trump-january-6-hearings-equal-time-nr-vpx.cnn](https://www.cnn.com/videos/politics/2022/06/20/rep-eric-swalwell-trump-january-6-hearings-equal-time-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 19:59:47+00:00

CNN's Victor Blackwell talks to Rep. Eric Swalwell (D-CA) about the potential benefits and drawbacks of having former President Donald Trump speak under oath at the January 6 hearings after he publicly asked for "equal time" to share his side of the story.

## Colombia's new president aims to reset relations with US
 - [https://www.cnn.com/2022/06/20/americas/colombia-election-snap-analysis-intl/index.html](https://www.cnn.com/2022/06/20/americas/colombia-election-snap-analysis-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 19:49:18+00:00

Gustavo Petro's victory in Colombia's presidential elections on Sunday opens a new page in the history of the country's relations with the US.

## 6 people hospitalized after taxi jumps curb in New York City, NYPD says
 - [https://www.cnn.com/2022/06/20/us/new-york-taxi-crash/index.html](https://www.cnn.com/2022/06/20/us/new-york-taxi-crash/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 19:47:26+00:00

A New York taxi cab jumped the curb and struck several people in central Manhattan on Monday, sending six people to local hospitals, including three with life-threatening injuries, authorities said.

## How the 'boyfriend loophole' is stalling gun safety talks in the US
 - [https://www.cnn.com/videos/politics/2022/06/20/gun-reform-senate-boyfriend-loophole-domestic-violence-nr-brown-vpx.cnn](https://www.cnn.com/videos/politics/2022/06/20/gun-reform-senate-boyfriend-loophole-domestic-violence-nr-brown-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 19:39:42+00:00

CNN's Pamela Brown explains what the "boyfriend loophole" is and why it's holding up gun safety talks in the US Senate.

## Hear from Apple employees on union victory
 - [https://www.cnn.com/videos/business/2022/06/20/apple-employees-union-maryland-store-affil-dnt-vpx.cnnbusiness](https://www.cnn.com/videos/business/2022/06/20/apple-employees-union-maryland-store-affil-dnt-vpx.cnnbusiness)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 18:54:03+00:00

Apple workers in Towson, Maryland, have voted to form the first-ever labor union at one of the tech giant's US stores. CNN affiliate WBAL reports.

## Israel to dissolve government after attempts to stabilize coalition were 'exhausted'
 - [https://www.cnn.com/2022/06/20/middleeast/israel-government-dissolve-vote-intl/index.html](https://www.cnn.com/2022/06/20/middleeast/israel-government-dissolve-vote-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 17:16:14+00:00



## Todd and Julie Chrisley break silence after fraud convictions
 - [https://www.cnn.com/2022/06/20/entertainment/todd-julie-chrisley-podcast/index.html](https://www.cnn.com/2022/06/20/entertainment/todd-julie-chrisley-podcast/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 17:13:16+00:00

Todd and Julie Chrisley are speaking out about the "very sad, heartbreaking time" for their family after they were convicted of conspiracy to defraud banks of more than $30 million in loans.

## An ancient city emerges after an extreme drought
 - [https://www.cnn.com/2022/06/20/world/iraq-city-unearthed-drought-scn/index.html](https://www.cnn.com/2022/06/20/world/iraq-city-unearthed-drought-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 17:06:26+00:00

A sprawling 3,400-year-old city emerged in Iraq after a reservoir's water level swiftly dropped due to extreme drought.

## Daughter of Russian opposition leader Alexey Navalny speaks out
 - [https://www.cnn.com/videos/world/2022/06/20/dasha-navalnaya-alexey-navalny-daughter-russia-prison-conditions-nr-vpx.cnn](https://www.cnn.com/videos/world/2022/06/20/dasha-navalnaya-alexey-navalny-daughter-russia-prison-conditions-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 17:05:32+00:00

Dasha Navalnaya, the daughter of imprisoned Russian opposition leader Alexey Navalny, speaks with CNN's Jim Sciutto about the conditions her father faces after he was transferred to a maximum-security prison.

## Paul Haggis, Oscar-winning screenwriter and director, detained on sexual assault charges
 - [https://www.cnn.com/2022/06/20/entertainment/paul-haggis-italy-sexual-assault-intl-scli/index.html](https://www.cnn.com/2022/06/20/entertainment/paul-haggis-italy-sexual-assault-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 16:24:17+00:00

Oscar-winning filmmaker Paul Haggis has been detained in Italy over allegations of sexual assault and aggravated personal injury, according to a statement from local prosecutors and his legal team.

## Texas Republicans just proved (again) that this is Donald Trump's party
 - [https://www.cnn.com/2022/06/20/politics/texas-republican-convention-platform-trump/index.html](https://www.cnn.com/2022/06/20/politics/texas-republican-convention-platform-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 16:17:39+00:00

• Texas Republican Party adopts resolution rejecting 2020 election results

## 'We are determined to anchor Moldova in the free world:' Moldova's Prime Minister on joining the EU
 - [https://www.cnn.com/videos/tv/2022/06/20/amanpour-moldova-pm-natalia-gavrilia.cnn](https://www.cnn.com/videos/tv/2022/06/20/amanpour-moldova-pm-natalia-gavrilia.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 16:05:25+00:00

Natalia Gavrilița, Moldova's prime minister, speaks to Bianna Golodryga about the country's desire to join the EU and on facing the threat of Russia as the war in neighbouring Ukraine wages on.

## Texas Republicans just proved (again) that this is Donald Trump's party
 - [https://www.cnn.com/collections/texas-gop-intl-062022/](https://www.cnn.com/collections/texas-gop-intl-062022/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 15:56:50+00:00



## In photos: Juneteenth celebrations across America
 - [https://www.cnn.com/2022/06/19/us/gallery/juneteenth-holiday-2022/index.html](https://www.cnn.com/2022/06/19/us/gallery/juneteenth-holiday-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 15:46:39+00:00

People across the United States gather for parades, parties and performances to celebrate Juneteenth holiday weekend.

## Heaviest rain in 60 years hits southern China, as experts warn extreme weather will only get worse
 - [https://www.cnn.com/collections/intl-extreme-weather-062022/](https://www.cnn.com/collections/intl-extreme-weather-062022/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 15:22:21+00:00



## Flights returning to normal after difficult holiday weekend
 - [https://www.cnn.com/2022/06/20/business/flight-cancellations/index.html](https://www.cnn.com/2022/06/20/business/flight-cancellations/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 15:22:10+00:00

Air travel is returning to normal Monday after several days of widespread flight cancellations due to weather and staffing issues.

## Video shows scene in India and Bangladesh as historic flooding underway
 - [https://www.cnn.com/videos/world/2022/06/20/india-bangladesh-monsoon-flooding-sud-pkg-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2022/06/20/india-bangladesh-monsoon-flooding-sud-pkg-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 15:02:42+00:00

Authorities say millions of people in Bangladesh and northeastern India have been affected by some of the worst flooding in the region in nearly two decades. CNN's Vedika Sud reports.

## How to make a gravity-defying building
 - [https://www.cnn.com/travel/article/museum-of-the-future-dubai/index.html](https://www.cnn.com/travel/article/museum-of-the-future-dubai/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 14:41:54+00:00

When it finally opened in February 2022, Dubai's new Museum of the Future was already one of the city's favorite buildings. And how could it not be? For six years, residents and visitors alike had curiously watched every step of the construction process of this shimmering silver landmark located on Dubai's main highway, Sheikh Zayed Road.

## Jennifer Lopez introduces one of her twins with gender neutral pronouns
 - [https://www.cnn.com/2022/06/20/entertainment/jennifer-lopez-emme-gender/index.html](https://www.cnn.com/2022/06/20/entertainment/jennifer-lopez-emme-gender/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 14:35:26+00:00

Jennifer Lopez and her child Emme Maribel Muñiz, 14, are being praised for a recent duet, but not because of the music.

## Russian soldiers left behind undetonated bombs near Kyiv. See how Ukraine is getting rid of them
 - [https://www.cnn.com/videos/world/2022/06/20/ukraine-kyiv-bomb-disposal-abdelaziz-pkg-nr-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2022/06/20/ukraine-kyiv-bomb-disposal-abdelaziz-pkg-nr-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 14:18:33+00:00

Russian forces retreated from Ukraine's capital, Kyiv, weeks ago, but the air and land invasion left thousands of unexploded munitions scattered across the region, according to officials. CNN's Salma Abdelaziz spoke to troops working to neutralize the threat at a makeshift bomb disposal site.

## Libya's oil industry is in disarray right when the world needs it more than ever
 - [https://www.cnn.com/2022/06/20/business/libya-oil-control-mime-intl/index.html](https://www.cnn.com/2022/06/20/business/libya-oil-control-mime-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 14:14:47+00:00

Libya was thrust back into the spotlight last week when it announced that it is pumping a million fewer barrels of oil than it did last year.

## Russian-born tennis player changes nationality to avoid Wimbledon ban
 - [https://www.cnn.com/2022/06/20/tennis/natela-dzalamidze-wimbledon-nationality-change-spt-intl/index.html](https://www.cnn.com/2022/06/20/tennis/natela-dzalamidze-wimbledon-nationality-change-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 13:23:00+00:00

Russian-born tennis player Natela Dzalamidze has changed her nationality to Georgian to avoid the ban Wimbledon imposed on all Russian players following the country's invasion of Ukraine.

## A floating city for 20,000 people is being built in the Indian Ocean
 - [https://www.cnn.com/style/article/maldives-floating-city-spc-intl/index.html](https://www.cnn.com/style/article/maldives-floating-city-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 13:06:13+00:00

A city is rising from the waters of the Indian Ocean. In a turquoise lagoon, just 10 minutes by boat from Male, the Maldivian capital, a floating city, big enough to house 20,000 people, is being constructed.

## US Supreme Court rushes to end a term like no other
 - [https://www.cnn.com/2022/06/20/politics/supreme-court-june-preview/index.html](https://www.cnn.com/2022/06/20/politics/supreme-court-june-preview/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 12:57:24+00:00

Because of a blockbuster docket, an unprecedented leak, a fraught political atmosphere and Covid, everything has changed at the Supreme Court.

## For my community, a single soccer goal captures the life-giving joy of gender inclusivity
 - [https://www.cnn.com/2022/06/20/opinions/lgbtq-inclusivity-soccer-wellness-harvey/index.html](https://www.cnn.com/2022/06/20/opinions/lgbtq-inclusivity-soccer-wellness-harvey/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 12:36:55+00:00

After a long, tangly moment of 11-year-old feet and elbows frenetically knocking into each other, the ball broke through, soared and landed solidly in the back of the net. For a second, everything got quiet. Then every player on our team went wide-eyed. They erupted "Wait! We scored? .... Oh my god, we scored!"

## Will swimming's transgender ruling lead to wider change in sports?
 - [https://www.cnn.com/2022/06/20/sport/swimming-transgender-ruling-explainer-spt-intl/index.html](https://www.cnn.com/2022/06/20/sport/swimming-transgender-ruling-explainer-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 12:07:29+00:00

World swimming's governing body FINA on Sunday voted for new eligibility rules that restrict the participation of transgender athletes in elite women's competitions.

## Matt Fitzpatrick revels in 'special' US Open win and 'incredible' record he now shares with Jack Nicklaus
 - [https://www.cnn.com/2022/06/20/golf/matt-fitzpatrick-us-open-win-jack-nicklaus-spt-intl/index.html](https://www.cnn.com/2022/06/20/golf/matt-fitzpatrick-us-open-win-jack-nicklaus-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 10:52:29+00:00

English golfer Matt Fitzpatrick had always imagined what winning his first major would feel like, but the reality exceeded all expectations on Sunday as he clinched the 122nd US Open.

## China's imports of Russian crude oil hit record high
 - [https://www.cnn.com/2022/06/20/energy/china-russia-oil-imports-record/index.html](https://www.cnn.com/2022/06/20/energy/china-russia-oil-imports-record/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 10:46:37+00:00

China's crude oil imports from Russia soared 55% from a year earlier to a record level in May, displacing Saudi Arabia as the top supplier, as refiners cashed in on discounted supplies amid sanctions on Moscow over its invasion of Ukraine.

## Macao shuts most businesses as Covid cases surge, but casinos stay open
 - [https://www.cnn.com/2022/06/20/business/macao-covid-businesses-close-casinos-open-intl-hnk/index.html](https://www.cnn.com/2022/06/20/business/macao-covid-businesses-close-casinos-open-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 10:29:57+00:00

Macao, the world's biggest gambling hub, began its second day of mass Covid-19 testing on Monday after dozens of locally transmitted cases were discovered over the weekend.

## Boeing unveils new 777 'ecoDemonstrator' test jet
 - [https://www.cnn.com/travel/article/boeing-777-ecodemonstrator/index.html](https://www.cnn.com/travel/article/boeing-777-ecodemonstrator/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 09:25:06+00:00

US aircraft maker Boeing has just revealed its new 2022 ecoDemonstrator plane -- a converted, 20-year-old 777-200ER that will be tasked with testing new technologies aimed at making air travel more sustainable and safer.

## Anxious times for Sweden's Kurds as country attempts to join NATO
 - [https://www.cnn.com/2022/06/20/europe/sweden-finland-kurds-nato-application-cmd-intl/index.html](https://www.cnn.com/2022/06/20/europe/sweden-finland-kurds-nato-application-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 09:24:10+00:00

At the Kurdish Fine Arts Association on the outskirts of Gothenburg, Nawzad Bahir and his neighbors were preparing for their summer carnival.

## Crypto industry fears contagion as bitcoin slips back under $20,000
 - [https://www.cnn.com/2022/06/19/investing/bitcoin-price/index.html](https://www.cnn.com/2022/06/19/investing/bitcoin-price/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 09:24:10+00:00

The cryptocurrency industry was on edge on Monday as bitcoin struggled to stay above a key level, with investors fearing that problems at major crypto players could unleash a wider market shakeout.

## Speculation runs rampant about female victims of brutal restaurant attack in China
 - [https://www.cnn.com/2022/06/20/china/china-tangshan-attack-followup-intl-hnk-mic/index.html](https://www.cnn.com/2022/06/20/china/china-tangshan-attack-followup-intl-hnk-mic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 08:54:24+00:00

It's been ten days since a vicious attack on four female diners at a barbecue restaurant in China appalled and angered the country, but an information vacuum around the victims has kept the Chinese internet asking: "What really happened to those women?"

## An exploding industry on social media could be toxic to people's skin
 - [https://www.cnn.com/style/article/skin-whitening-products-social-media-as-equals-intl-cmd/index.html](https://www.cnn.com/style/article/skin-whitening-products-social-media-as-equals-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 08:15:44+00:00



## I gave up dieting for my kids. Here's why
 - [https://www.cnn.com/2022/06/20/health/no-dieting-for-my-kids-parenting-wellness/index.html](https://www.cnn.com/2022/06/20/health/no-dieting-for-my-kids-parenting-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 08:02:11+00:00

I came of age in a house of fat-free cookies, Weight Watchers' meetings and Denise Austin's eight-minute abs. There was plenty of pasta and ice cream but also a focus on being skinny. In the decades since, I've counted points, intermittently fasted and completed fitness challenges to make my body smaller.

## A new way to explore Australia's most mysterious region
 - [https://www.cnn.com/travel/article/indigenous-travel-torres-strait-australia-intl-hnk/index.html](https://www.cnn.com/travel/article/indigenous-travel-torres-strait-australia-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-20 03:37:57+00:00

At the far northern tip of Australia is one of the country's least-visited and least-understood regions.


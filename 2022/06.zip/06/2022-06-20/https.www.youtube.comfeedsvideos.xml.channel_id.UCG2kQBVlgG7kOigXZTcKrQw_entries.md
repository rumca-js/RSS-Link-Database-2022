# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Roztocze - perełka Wschodniej Polski 🚴‍♂️💨 Kraina spokojem i ciszą płynąca
 - [https://www.youtube.com/watch?v=AHzBx6wCfak](https://www.youtube.com/watch?v=AHzBx6wCfak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2022-06-20 16:15:00+00:00

Książka "Rower to jest Świat" https://rowertojestswiat.pl/

Roztocze, w naszej płaskiej jak naleśnik Ojczyźnie jawi się niczym Toskania. Tak też jest nazywane! Delikatne pagórki, niczym nieskażona natura, a nawet winnice. Wszystko to jest wręcz idealną krainą dla osób chcących nieco zwolnić, doświadczyć ciszy, spokoju, a także aktywnego wypoczynku. Zwłaszcza rowerowego, do którego szczególnie chciałem Was na Roztoczu zachęcić.

Roztocze jest dość wąskim regionem, ale bardzo długim. Ciągnie się przez 180 kilometrów od Kraśnika, aż po Lwów i podczas naszej wycieczki odwiedzimy sobie jego lubelską część, a dokładniej mówiąc – Roztocze Zachodnie oraz Środkowe, a na Roztocze Wschodnie przyjdzie jeszcze czas.

W filmie tym pokażę Wam wszystkie ciekawe miejsca na Roztoczu jakie udało nam się odkryć i podrzucę nieco sugestii dotyczących organizacji swoich własnych wycieczek rowerowych.

Więcej informacji o Centralnym Szlaku Roztocza znajdziecie na stronie https://roweloveroztocze.pl/

Partnerem relacji z regionu lubelskiego jest Województwo Lubelskie

#lubelskie #KierunekLubelskie #Roztocze 

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

0:00 - Roztocze
1:52 - Szczebrzeszyn
2:10 - kilka słów o Roztoczu
3:15 - szlaki rowerowe na Roztoczu
4:39 - co łączy Roztocze i Bałtyk?
5:10 - kiedy jechać na Roztocze?
5:36 - szlak w okolicy Gilowa
6:25 - Roztocze ciekawe miejsca
6:53 - moja książka
7:41 - roztoczańskie pola i winnice
8:58 - rzeka Wieprz
9:53 - w poszukiwaniu konika polskiego
12:08 - Szumy na Tanwi
13:17 - kamieniołomy i kamienne wieże
14:48 - Zamość


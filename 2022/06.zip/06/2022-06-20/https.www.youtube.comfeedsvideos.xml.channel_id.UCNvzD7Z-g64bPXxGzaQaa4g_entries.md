# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 CRAZY Elden Ring Builds That Are TRULY GENIUS
 - [https://www.youtube.com/watch?v=LjZc9-UsGPE](https://www.youtube.com/watch?v=LjZc9-UsGPE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-20 00:00:00+00:00

Elden Ring (PC, PS5, PS4, Xbox Series X/S/One) allows you to get creative with your character builds. Here are some of the goofier/crazier examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Tesla's Robot Revolution
 - [https://www.youtube.com/watch?v=Djp6_rh3_I0](https://www.youtube.com/watch?v=Djp6_rh3_I0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-06-20 00:00:00+00:00

Go to https://hensonshaving.com and enter "JOESCOTT" at checkout to get 100 free blades with your purchase. (Note: you must add both the 100 blade pack and the razor for the discount to apply.)
Humanoid robots have been in popular culture from the very beginning, and while robotics have come a long way, we still don't have the humanoid, walking, general purpose robots of our sci-fi imaginations. But some companies, including Tesla, claim to be on the verge of finally making it a reality. But how likely is it, really?

Watch this video ad-free on Nebula: https://nebula.tv/videos/joescott-teslas-robot-revolution

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPGzF
Apple Podcasts 👉 https://apple.co/3j94kfq
Google Podcasts 👉 https://bit.ly/3qZCo1V

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS - 
https://www.servicerobots.com/
https://www.army-technology.com/projects/petman/
https://www.bostondynamics.com/atlas
https://blog.bostondynamics.com/atlas-leaps-bounds-and-backflips
https://gizmodo.com/that-viral-video-of-a-robot-uprising-is-fake-because-th-1835575686
https://www.snopes.com/fact-check/armed-robot-video/
https://youtu.be/UEBndVLPzTY
https://www.bu.edu/bhr/2021/10/04/the-rise-of-service-robots-in-the-hospitality-industry-some-actionable-insights/
https://www.therobotreport.com/honda-asimo-robot-discontinued/
https://www.hansonrobotics.com/sophia/
https://www.bu.edu/bhr/2021/10/04/the-rise-of-service-robots-in-the-hospitality-industry-some-actionable-insights/
https://www.simplilearn.com/tutorials/artificial-intelligence-tutorial/humanoid-robots
https://blog.bostondynamics.com/atlas-leaps-bounds-and-backflips
https://www.sciencedaily.com/releases/2019/10/191030151155.htm
https://www.rampfesthudson.com/how-many-nerve-endings-are-in-your-hand/#How_many_nerve_endings_are_in_your_hand
https://www.nature.com/articles/d41586-018-05093-1
https://nikosuenderhauf.github.io/roboticvisionchallenges/
https://roboticsandautomationnews.com/2021/08/12/fedex-implements-berkshire-greys-robotic-system-for-small-package-processing/45459/
https://www.berkshiregrey.com/technologies/electromechanicals/
http://drc.mit.edu/
https://support.bostondynamics.com/s/article/Introduction-to-the-Spot-battery-and-charger
https://news.umich.edu/biomorphic-batteries-could-provide-72x-more-energy-for-robots/
https://www.weforum.org/agenda/2020/10/dont-fear-ai-it-will-lead-to-long-term-job-growth/
https://www.frontiersin.org/articles/10.3389/frobt.2021.748246/full
https://www.nature.com/articles/d41586-022-00072-z
https://www.theverge.com/2021/8/20/22633958/tesla-bot-elon-musk-ai-day
https://jonasmuthoni.com/blog/advantages-disadvantages-robots/

TIMESTAMPS -
0:00 - Robots In Pop Culture
3:00 - Why Humanoid Robots?
5:14 - Boston Dynamics
6:04 - Tangent Cam 
6:52 - Humanoids Are Personable
8:48 - Uncanny Valley
10:30 - Tesla Bot
11:43 - Where Are We Now?
13:18 - Balance
14:25 - Articulation
15:26 - Vision
16:37 - Battery Life
18:54 - Will They Take Our Jobs?
20:45 - Looking To The Future
21:28 - Sponsor - Henson Shaving


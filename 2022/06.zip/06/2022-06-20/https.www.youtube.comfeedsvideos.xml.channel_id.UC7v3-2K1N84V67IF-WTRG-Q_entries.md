# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Elvis - Movie Review
 - [https://www.youtube.com/watch?v=PexxV3DYJQk](https://www.youtube.com/watch?v=PexxV3DYJQk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-06-20 00:00:00+00:00

Thanks to Truebill for sponsoring! Go to https://truebill.com/jahns to start managing your personal finances today. #truebill #personalfinance

Baz Luhrmann takes on the story of the iconic "King". let's see what Uncle Jesse was hyping up for 8 seasons. Here's my review for ELVIS!


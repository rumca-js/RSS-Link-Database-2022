# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## NEW TOLKIEN BOOK - The Fall of Númenor - coming Nov 2022!
 - [https://www.youtube.com/watch?v=4OX3Ttxd_rU](https://www.youtube.com/watch?v=4OX3Ttxd_rU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-06-21 00:00:00+00:00

We have a NEW Tolkien book on the horizon! The Fall of Númenor is coming on November 10, 2022 and will collect all of Tolkien's stories from the Second Age.  Edited by Brian Sibley and featuring 11 new illustrations by Alan Lee!  Check out my interview with Brian about his work on the 1981 BBC Radio Adaptation of LOTR: https://youtu.be/VwuBLHSQpbE

Check out The Tolkien Collector's Guide on YouTube: https://www.youtube.com/c/TolkienCollectorsGuide

Standard Edition: https://amzn.to/3xH3HAI
Deluxe Edition: https://blackwells.co.uk/bookshop/product/9780008537845?a_aid=nerdoftherings&currency=USD&destination=US

(Affiliate links)

#Tolkien #fallofnumenor #lordoftherings

## ORCS Revealed from LOTR: Rings of Power!
 - [https://www.youtube.com/watch?v=r4RQpF9-I9Q](https://www.youtube.com/watch?v=r4RQpF9-I9Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-06-21 00:00:00+00:00

We just got our first up-close look at some orcs from The Lord of the Rings: The Rings of Power!  Let's check out these images and the accompanying article from IGN.

Article can be found here: https://www.ign.com/articles/the-lord-of-the-rings-the-rings-of-power-orcs-exclusive

#ringsofpower #lordoftherings #lotronprime

## Dragons & Ents Confirmed for Rings of Power? Nirnaeth Arnoediad flashback?
 - [https://www.youtube.com/watch?v=UKkoGP1UArg](https://www.youtube.com/watch?v=UKkoGP1UArg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-06-20 00:00:00+00:00

Prime Video just released a promo for their platform, focusing on Rings of Power.  In it, I think we see confirmation of both Dragons and Ents appearing in the show, as well as a HUGE Middle-earth battle from the First Age!

Original promo: https://youtu.be/Rcd0fsYahrA
John Howe book featured: https://amzn.to/3tO5se6

#ringsofpower #lordoftherings #tolkien


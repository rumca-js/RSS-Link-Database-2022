# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Mygg & Comatron - Dropzone (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=Q_xohUO71zo](https://www.youtube.com/watch?v=Q_xohUO71zo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-06-21 00:00:00+00:00

"Dropzone" by Mygg & Comatron (Jonas Sarvik & ?), 3rd at FieldFX 2020. Art "Albert 1953" by Louie/Insane^The Black Lotus, 1st at Remedy 1995. Original photo by Arthur Sasse (1951).

Made using real A1200 Rev. 1D.4 audio.

Visit my channel for more Amiga music.


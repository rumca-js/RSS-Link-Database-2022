# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## High Pulp - All Roads Lead To Los Angeles (Live on KEXP)
 - [https://www.youtube.com/watch?v=Xyjx62TSvTU](https://www.youtube.com/watch?v=Xyjx62TSvTU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-21 00:00:00+00:00

http://KEXP.ORG presents High Pulp performing “All Roads Lead To Los Angeles” live in the KEXP studio. Recorded June 1, 2022.

Andrew Morrill - Alto Saxophone
Antoine Martel - Modular + Synthesizers
Bobby Granfelt - Drums
Kaeli Earle - Bass
Rob Homan - Keyboards
Trevor Eulau - Guitar
Victory Nguyen - Tenor Saxophone & Flute

Host: Eva Walker
Audio Engineers: Julian Martlew & Drew Pine
Audio Mixer: Drew Pine
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://highpulpmusic.com
http://kexp.org

## High Pulp - Feral (Live on KEXP)
 - [https://www.youtube.com/watch?v=7Dd1wn7ydsQ](https://www.youtube.com/watch?v=7Dd1wn7ydsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-21 00:00:00+00:00

http://KEXP.ORG presents High Pulp covering Radiohead's “Feral” live in the KEXP studio. Recorded June 1, 2022.

Andrew Morrill - Alto Saxophone
Antoine Martel - Modular + Synthesizers
Bobby Granfelt - Drums
Kaeli Earle - Bass
Rob Homan - Keyboards
Trevor Eulau - Guitar
Victory Nguyen - Tenor Saxophone & Flute

Host: Eva Walker
Audio Engineers: Julian Martlew & Drew Pine
Audio Mixer: Drew Pine
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://highpulpmusic.com
http://kexp.org

## High Pulp - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=OjspcSFNXT8](https://www.youtube.com/watch?v=OjspcSFNXT8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-21 00:00:00+00:00

http://KEXP.ORG presents High Pulp performing live in the KEXP studio. Recorded June 1, 2022.

Songs:
Kamishinjo
All Roads Lead to Los Angeles
Hookai
Feral (Radiohead cover)

Andrew Morrill - Alto Saxophone
Antoine Martel - Modular + Synthesizers
Bobby Granfelt - Drums
Kaeli Earle - Bass
Rob Homan - Keyboards
Trevor Eulau - Guitar
Victory Nguyen - Tenor Saxophone & Flute

Host: Eva Walker
Audio Engineers: Julian Martlew & Drew Pine
Audio Mixer: Drew Pine
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://highpulpmusic.com
http://kexp.org

## High Pulp - Hookai (Live on KEXP)
 - [https://www.youtube.com/watch?v=j_4a9DerON8](https://www.youtube.com/watch?v=j_4a9DerON8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-21 00:00:00+00:00

http://KEXP.ORG presents High Pulp performing “Hookai” live in the KEXP studio. Recorded June 1, 2022.

Andrew Morrill - Alto Saxophone
Antoine Martel - Modular + Synthesizers
Bobby Granfelt - Drums
Kaeli Earle - Bass
Rob Homan - Keyboards
Trevor Eulau - Guitar
Victory Nguyen - Tenor Saxophone & Flute

Host: Eva Walker
Audio Engineers: Julian Martlew & Drew Pine
Audio Mixer: Drew Pine
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://highpulpmusic.com
http://kexp.org

## High Pulp - Kamishinjo (Live on KEXP)
 - [https://www.youtube.com/watch?v=3k_FQEwnT0k](https://www.youtube.com/watch?v=3k_FQEwnT0k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-21 00:00:00+00:00

http://KEXP.ORG presents High Pulp performing “Kamishinjo” live in the KEXP studio. Recorded June 1, 2022.

Andrew Morrill - Alto Saxophone
Antoine Martel - Modular + Synthesizers
Bobby Granfelt - Drums
Kaeli Earle - Bass
Rob Homan - Keyboards
Trevor Eulau - Guitar
Victory Nguyen - Tenor Saxophone & Flute

Host: Eva Walker
Audio Engineers: Julian Martlew & Drew Pine
Audio Mixer: Drew Pine
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://highpulpmusic.com
http://kexp.org


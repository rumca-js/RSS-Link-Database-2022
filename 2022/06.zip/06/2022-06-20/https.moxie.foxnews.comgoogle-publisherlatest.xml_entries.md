# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Benghazi legend Mark Geist presents K9 service dog to combat veteran in N.J.
 - [https://www.foxnews.com/lifestyle/benghazi-mark-geist-service-dog-combat-veteran-nj](https://www.foxnews.com/lifestyle/benghazi-mark-geist-service-dog-combat-veteran-nj)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-06-20 06:00:48+00:00

At N.J.&apos;s Barefoot Music Festival, Shadow Warriors Project, founded by Mark Geist, as well as Baden K9 group honored an American combat vet with the gift of a service dog.

## Postpartum depression among birth moms: How women are breaking the stigma
 - [https://www.foxnews.com/lifestyle/postpartum-depression-moms-women-breaking-stigma](https://www.foxnews.com/lifestyle/postpartum-depression-moms-women-breaking-stigma)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-06-20 02:00:56+00:00

Postpartum depression as experienced by new moms is more common than people think, experts told Fox News Digital — and they offered smart advice for handling it.


# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Jann - Do You Wanna Come Over? - live MUZO.FM
 - [https://www.youtube.com/watch?v=hLbVSmlobyM](https://www.youtube.com/watch?v=hLbVSmlobyM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-06-21 00:00:00+00:00

Jann - Do You Wanna Come Over? na żywo w MUZO.FM. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Jann: http://www.facebook.com/Jann.officialmusic
Instagram Jann: http://www.instagram.com/jann_music_
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


Jann - Do You Wanna Come Over? tekst

Please don’t get me wrong 
I don’t mean to blame anybody
For the way I feel
And for my tears

I just kinda wish somebody would ask me from time to time
Do you wanna come over
Do you wanna come over

I don’t even say that I’m lonely 
I don’ even say that I don’t have friends but

There’s always someone around 
There’s always someone who will 
Tell you that you’re not alone but

But please don’t get me wrong 
I don’t mean to blame anybody
For the way I feel
And for my tears

I just kinda wish somebody would ask me from time to time
Do you wanna come over
Do you wanna come over

I wanna stay up all night and joke around because I need a different reason to cry
I wanna have a bellyache 
And I want my jaw to hurt from stretching too much

I wanna fight over movie that we gonna watch
Over game that we gonna play 
And over food that we gonna get

But please don’t get me wrong 
I don’t mean to blame anybody
For the way I feel
And for my tears

I just kinda wish somebody would ask me from time to time
Do you wanna come over
Do you wanna come over

Oh I need somebody
Because I miss somebody
Because I lost somebody 

Oh I need somebody 
Because I hurt somebody
Because I turned down somebody

But please don’t get me wrong 
I don’t mean to blame anybody
For the way I feel
And for my tears

I just kinda wish somebody would ask me from time to time
Do you wanna come over
Do you wanna come over

## Myslovitz - Sprzedawcy marzeń - live MUZO FM
 - [https://www.youtube.com/watch?v=LZtLg2oxNRQ](https://www.youtube.com/watch?v=LZtLg2oxNRQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-06-21 00:00:00+00:00

Myslovitz - Sprzedawcy marzeń na żywo w MUZO.FM. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Myslovitz: http://www.facebook.com/Myslovitz
Instagram Myslovitz: http://www.instagram.com/myslovitz_official
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


#popolsku #myslovitz

## Rita Pax - Koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=Ul2KXNm_uZc](https://www.youtube.com/watch?v=Ul2KXNm_uZc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-06-20 00:00:00+00:00

Rita Pax na żywo w MUZO.FM. Zespół wykonał w naszym studiu wyjątkowe wersje utworów: Gdybyś kochał, hej, Piękno (feat. Igor Nikiforow) i Pomaluj moje sny. Piosenki pochodzą z płyty Piękno. Tribute to Breakout. 

0:00 Gdybyś kochał, hej!
03:55 Piękno
10:00 Pomaluj moje sny

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Rita Pax: http://www.facebook.com/ritapaxmusic
Instagram Rita Pax: http://www.instagram.com/ritapax
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm

Paulina Przybysz - wokal
Kasia Piszek - instr. klawiszowe
Paweł Zalewski - gitara
Piotr Zalewski - gitara basowa
Jerzy Markuszewki - perkusja
Rejestracja audio - Jacek Antosik

#popolsku


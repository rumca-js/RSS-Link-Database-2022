# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## This Is EPIC
 - [https://www.youtube.com/watch?v=EeeyDaBxVN8](https://www.youtube.com/watch?v=EeeyDaBxVN8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-21 00:00:00+00:00

The brilliant Jimmy Dore went on to Tucker last week, and his take down of the Democrat party was epic. 
#JimmyDore #Tucker #foxnews 

References
https://thehill.com/homenews/media/3528763-clinton-us-at-the-precipice-of-losing-democracy/
https://www.ft.com/content/2e667c3f-954d-49fa-8024-2c869789e32f
--------------------------------------------------------------------------------------------------------------------------
Tickets now on sale for my 1 day event COMMUNITY in Hay-on-Wye. I'm joined by Wim, Vandana Shiva for conversations on spirituality, wellness, healthy living and our environment. Get your tickets bit.ly/3xoHQPv

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## So THIS Is What Vaccine Passports Were Leading To
 - [https://www.youtube.com/watch?v=Z4dtwRfFErA](https://www.youtube.com/watch?v=Z4dtwRfFErA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-20 00:00:00+00:00

During the pandemic we were told that new digital tools being introduced would not be exploited by governments and private companies. But as more stories come to light about how our data is being abused, we ask, what else was done in the name of Covid? 
#covid #pandemic #data

References
https://reclaimthenet.org/covid-surveillance-tech-remains-open-to-exploitation/
https://www.reuters.com/world/china/china-bank-protest-stopped-by-health-codes-turning-red-depositors-say-2022-06-14/
https://www.bloomberg.com/news/articles/2022-06-17/meta-sued-over-claims-patient-data-secretly-sent-to-facebook
--------------------------------------------------------------------------------------------------------------------------
Tickets now on sale for my 1 day event COMMUNITY in Hay-on-Wye. I'm joined by Wim, Vandana Shiva for conversations on spirituality, wellness, healthy living and our environment. Get your tickets bit.ly/3xoHQPv

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


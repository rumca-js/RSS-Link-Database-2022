# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Reviewing the Video of Biden Falling Off a Bike
 - [https://www.youtube.com/watch?v=NAgIbpRudKM](https://www.youtube.com/watch?v=NAgIbpRudKM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-06-21 00:00:00+00:00

Taken from JRE #1834 - Protect Our Parks 4:
https://open.spotify.com/episode/3LMNxOGkuMA1mFqh7kcJ3F?si=f483ea9f3d974835


# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Babylon Bee Weak-ly News Update 6/17/2022: K-Pop BTS Breaks Up and Joe Biden in 2024?
 - [https://www.youtube.com/watch?v=0oF1BheQwGU](https://www.youtube.com/watch?v=0oF1BheQwGU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-06-17 00:00:00+00:00

Host Adam Yenser gives us the news of the week like the White House saying Biden will run again in 2024, Nancy Pelosi making an appearance on Ru Paul’s Drag Race, and, in a tragic loss to the whole world, Korean boy band BTS is breaking up.

Watch the full podcast here: https://youtu.be/Chs9nLVolxI

Follow Adam on Youtube: https://www.youtube.com/user/adamyenser

Become a premium subscriber: https://babylonbee.com/plans

The Official The Babylon Bee Store: https://shop.babylonbee.com/

Follow The Babylon Bee:Website: https://babylonbee.com/Twitter: https://twitter.com/thebabylonbeeFacebook: https://www.facebook.com/TheBabylonBeeInstagram: http://instagram.com/thebabylonbee

## The Bee Weekly: Grilling Authors And Our New Studio
 - [https://www.youtube.com/watch?v=Chs9nLVolxI](https://www.youtube.com/watch?v=Chs9nLVolxI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-06-17 00:00:00+00:00

Kyle and Adam welcome Joel Berry to the brand new podcast studio. It has a neon light and everything! The trio discuss gun control, sentient AI, and more! We've also got some more Bee Radio and Weakly News coming at you. And Travis hops in to quiz Kyle and Joel on their new book, The Postmodern Pilgrim’s Progress.

We also take the time to interview Penny Nance to find out how many Pennies her thoughts cost. (It's three)

Be sure to look into Concerned Women For America and their work: https://concernedwomen.org/

Subscribers, stick around for hate mail, subscriber headlines, and a dramatic discussion on which dinosaur is Joel’s favorite. The answer may shock you!

Be sure to check out our wonderful sponsors:

Alliance Defending Freedom: https://adflegal.org/bee

PublicSq: https://publicsq.com

Allegiance Gold: https://allegiancegold.com/bee

## Spelling Bee Contestant Asks The Definition of “Woman”
 - [https://www.youtube.com/watch?v=5mnQTzhVgl8](https://www.youtube.com/watch?v=5mnQTzhVgl8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-06-16 00:00:00+00:00

Judges at a school spelling bee are stumped and infuriated when a child dares to ask them for a definition of the word “woman.”

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


## How Price Shocks in Formative Years Scar Consumption for Life - Knowledge at Wharton
 - [https://knowledge.wharton.upenn.edu/article/how-price-shocks-in-formative-years-scar-consumption-for-life/](https://knowledge.wharton.upenn.edu/article/how-price-shocks-in-formative-years-scar-consumption-for-life/)
 - RSS feed: https://knowledge.wharton.upenn.edu
 - date published: 2022-06-16 05:54:59.662032+00:00

Teens who experienced gas price shocks of the 1970s drive less in later years, according to experts at Wharton and the Federal Reserve Bank of Philadelphia.…Read More


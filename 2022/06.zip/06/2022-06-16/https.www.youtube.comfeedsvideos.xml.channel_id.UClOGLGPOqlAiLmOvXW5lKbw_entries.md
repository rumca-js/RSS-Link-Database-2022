# Source:Mandalore Gaming, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw, language:en-US

## Pathways Into Darkness Review
 - [https://www.youtube.com/watch?v=MQKX07MlVjg](https://www.youtube.com/watch?v=MQKX07MlVjg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClOGLGPOqlAiLmOvXW5lKbw
 - date published: 2022-06-16 13:00:16+00:00

Pathways Into Darkness is a dungeon crawling FPS that takes you on a marathon inside an eldritch pyramid where you're tasked with destroying an elder god. That's the straightforward part.
Support the channel at: https://www.patreon.com/mandaloregaming or https://www.paypal.me/MandaloreGaming
Thanks to @tat2kid714 (Dakota Lee) for the thumbnail art!
I take video suggestions at mandaloremovies@gmail.com
Twitter: https://twitter.com/Lord_Mandalore
00:00 - Intro
00:10 - History of Pathways
01:21 - Game Premise
03:02 - Visuals
04:11 - Music & Sound Design
05:41 - Gameplay Mechanics
15:50 - Story (SPOI𝘓ERS)
23:14 - Conclusions
24:14 - Credits
25:50 - Boned

It was always 2552

#PathwaysIntoDarkness #PathwaysIntoDarknessPC #PathwaysIntoDarknessReview #Bungie #PiD #Marathon


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## It's Coming For Us... - WAN Show June 17, 2022
 - [https://www.youtube.com/watch?v=U5YOjLdfRZA](https://www.youtube.com/watch?v=U5YOjLdfRZA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-17 00:00:00+00:00

Try Vultr today with an exclusive 30-day $100 code for signing up at https://getvultr.com/LTT
Buy a Seasonic Prime TX 1000W PSU: https://geni.us/aryiquT
Save 10% on XSplit's video tools at https://lmg.gg/xsplit

Check out Ivan’s GPUs available for auction below. 

Star Wars Titan: https://www.ebay.ca/itm/175321698128
GTX 580: https://www.ebay.ca/itm/175321695907

All proceeds go to SOS Children’s Villages, more information at https://lmg.gg/sosabout 
Donate to SOS Children’s Villages today at https://lmg.gg/soscharity

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Its-Coming-For-Us------WAN-Show-June-17--2022-e1k6ola

Timestamps: (Courtesy of Bip Bop)
0:00 Welcome!
1:18 intro
1:50 Lab 2, yes, he complained, don't dox or harass people, Linus will take care of it his way.
10:15 Amazon turn over
15:50 Burn out
16:20 LMG vs FAANG Co. 
17:51 mobile game dev
19:08 LMG financial commitments
20:35 return to mobile game dev
21:58 sponsor segue
26:10 crypto winter
34:14 crypto GPUs aspect
36:30 scrapyard wars remote control, How famous Linus isn't according to Linus
38:36 crypto
40:00 Linus known in oil patches
42:20 crypto discussion 
47:22 product launch, Merch Messages
50:38 screwdriver silver and limited black
56:57 find the Linus in your life
1:00:10 Linus badminton & teachers
1:17:38 screwdriver Merch message question
1:18:16 Kaleidescape
1:28:56 absolute control of any tech company, pick one
1:30:08 most life impactful animated movie
1:33:26 favorite laptop
1:35:27 Daily reading
1:35:46 Lab in hindsight
1:36:49 any Steam Deck video plans?
1:39:07 Roku peeps
1:39:18 Framework transparency
1:39:37 Hydravion French for Floatplane Roku
1:40:13 TY all
1:40:22 outro
1:40:27 hydravienne clarification
1:40:55 outro
1:41:08 B4 we go 😆

## Is Buying More RAM a WASTE for Gamers? (2022)
 - [https://www.youtube.com/watch?v=H19_JKw4QN4](https://www.youtube.com/watch?v=H19_JKw4QN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-16 00:00:00+00:00

Thanks to Crucial for sponsoring this video! 
Check out Crucial's DDR5 RAM today at: https://crucial.gg/LTT_DDR5

Still gaming in 2022 on 8GB of RAM (hopefully) in dual channel? We tested some newer games to find out whether or not you'll benefit from an upgrade, or if you're good to go for a little while yet.

Discuss on the forum: https://linustechtips.com/topic/1437566-is-buying-more-ram-a-waste-for-gamers-2022-sponsored/

Buy a stick of Crucial DDR5 8GB RAM: https://geni.us/ZSZtDIN

Buy a kit of Crucial Ballistix DDR4 (2x8GB) RAM: https://geni.us/JQWiTPM

Buy an EK AIO 360 DRGB: https://geni.us/2imXioC

Buy an Intel Core i9-12900K: https://geni.us/ynspX

Buy a Samsung 980 Pro 2TB: https://geni.us/hkH7l

Buy an RTX 3080 Ti: https://geni.us/UNzq

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:47 Why RAM is important
1:36 How we tested
2:30 CS:GO
3:14 How DDR5 is different from DDR4
4:01 Far Cry 6
5:46 Tiny Tina's Wonderland
6:53 Why is DDR5 better now?
7:34 Warhammer 3
8:15 AC: Valhalla
8:28 So what should I buy?
9:16 Outro


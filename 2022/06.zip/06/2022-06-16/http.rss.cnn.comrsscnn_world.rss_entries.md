# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## After 40 days in a bomb shelter, two Ukrainian refugees and 17 dogs are ready to start a new life in Poland
 - [https://www.cnn.com/2022/06/16/world/ukraine-dog-rescue-poland-refugees-cnnheroes/index.html](https://www.cnn.com/2022/06/16/world/ukraine-dog-rescue-poland-refugees-cnnheroes/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-06-16 17:28:30+00:00

When CNN Hero Aaron Jackson welcomed the first group of dogs from Ukraine to the abandoned animal shelter he's reopened in Poland, he also took in two refugees who shared an amazing story of survival.


# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## MMYYKK - Sweetest Embrace (live at The Current)
 - [https://www.youtube.com/watch?v=NFSpvwped40](https://www.youtube.com/watch?v=NFSpvwped40)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-06-17 00:00:00+00:00

Blending soul, jazz, hip-hop and R&B, MMYYKK and The Blackbeat Theory perform "Sweetest Embrace" live in The Current studio in a session for The Local Show.

Personnel:
MMYYKK - keys, vocals
Jalyn Spencer - bass
LA Buckner - drums
Omar Abdulkarim - horn

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#mmyykk #theblackbeattheory

## Hippo Campus - Ashtray (live at The Current)
 - [https://www.youtube.com/watch?v=d0_F9yXbgp4](https://www.youtube.com/watch?v=d0_F9yXbgp4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-06-16 00:00:00+00:00

Watch Hippo Campus perform the song "Ashtray" from their album "LP3," in a session recorded in The Current studio. 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#hippocampus #thehalocline #hippocampusband

## Kurt Vile - studio session at The Current (music + interview)
 - [https://www.youtube.com/watch?v=4jq1Re1pCgI](https://www.youtube.com/watch?v=4jq1Re1pCgI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-06-16 00:00:00+00:00

Kurt Vile joins The Current to play songs from his new album 'Watch My Moves,' and catches up with Mac Wilson about working with John Prine, covering Springsteen, what he's been up to.

Songs Played:
00:00 Mount Airy Hill (Way Gone)
10:40 Like Exploding Stones
22:01 Peeping Tomboy

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#kurtvile


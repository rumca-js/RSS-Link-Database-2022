# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Jan. 6: They Don’t Want You To Know This
 - [https://www.youtube.com/watch?v=k2jsA3sk2H0](https://www.youtube.com/watch?v=k2jsA3sk2H0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-17 00:00:00+00:00

Whatever you think about events on Jan 6th 2020, are the current hearings just an excuse for more political theatre? And will anything actually be achieved other than more domestic terrorism laws that both sides of the political establishment want? 
#trump #january6 #capitolriots  

References
https://jacobin.com/2022/06/capitol-riot-trump-gop-democrats-hearings
https://jacobin.com/2021/01/us-capitol-riot-police-investigation
--------------------------------------------------------------------------------------------------------------------------
Tickets now on sale for my 1 day event COMMUNITY in Hay-on-Wye. I'm joined by Wim, Vandana Shiva for conversations on spirituality, wellness, healthy living and our environment. Get your tickets bit.ly/3xoHQPv

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## What The F*ck Is Going On?!
 - [https://www.youtube.com/watch?v=raBaCSwExbs](https://www.youtube.com/watch?v=raBaCSwExbs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-16 00:00:00+00:00

Nancy Pelosi appeared “RuPaul’s Drag Race” over the weekend to express her support for the drag community - and encourage Americans to vote. This, whilst the ban on politicians buying stocks stalls in Congress. Still, Drag Race eh! 
#nancypelosi #rupaulsdragrace #congress  

References
https://thehill.com/blogs/in-the-know/3520996-pelosi-encourages-americans-to-vote-during-rupauls-drag-race-reality-show-appearance/
https://www.businessinsider.com/ban-congress-stock-trading-stalls-merkley-spanberger-jayapal-ossoff-2022-5?r=US&IR=T
https://greenwald.substack.com/p/nancy-and-paul-pelosi-making-millions?s=r
https://unusualwhales.com/i_am_the_senate/congress
https://readsludge.com/2021/12/30/leading-congressional-stock-trading-ban-bill-has-spouse-loophole/
--------------------------------------------------------------------------------------------------------------------------
Tickets now on sale for my 1 day event COMMUNITY in Hay-on-Wye. I'm joined by Wim, Vandana Shiva for conversations on spirituality, wellness, healthy living and our environment. Get your tickets bit.ly/3xoHQPv

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


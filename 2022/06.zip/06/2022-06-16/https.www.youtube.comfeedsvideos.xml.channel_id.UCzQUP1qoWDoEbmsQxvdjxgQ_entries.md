# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Smelling Salts Moment - JRE Toons
 - [https://www.youtube.com/watch?v=0WXHQyOq1d4](https://www.youtube.com/watch?v=0WXHQyOq1d4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-06-17 00:00:00+00:00

Another hilarious moment animated by PaulyToon from the Joe Rogan Experience #1764 with the Protect Our Parks crew, Mark Normand, Shane Gills & Ari Shaffir.
https://open.spotify.com/episode/2NdZP4tbBXYPwvpo5cwcAP?si=uMIcFXJfS2WORPIjm_JZ7g

## Tim Kennedy on Witnessing the Fall of Afghanistan
 - [https://www.youtube.com/watch?v=WEHXfB8wwGk](https://www.youtube.com/watch?v=WEHXfB8wwGk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-06-16 00:00:00+00:00

Taken from JRE #1833 w/Tim Kennedy:
https://open.spotify.com/episode/6FQtrKt6hRRcEhhbABr2Ke?si=cc1f3144084e459b


# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## JON SNOW SHOW🐺 LotR ANIME CAST!⚔️ One Punch Man MOVIE!👊-FANTASY NEWS
 - [https://www.youtube.com/watch?v=KsUqXuTF67g](https://www.youtube.com/watch?v=KsUqXuTF67g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-06-17 00:00:00+00:00

LET'S JUMP INTO THE FANTASY NEWS! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 Fundraiser update: https://www.reddit.com/r/ProgressionFantasy/comments/vam2mv/more_than_5000_were_raised_for_the_victims_of_the/ 

00:39 War of the Rohirrim: https://twitter.com/discussingfilm/status/1537058843758407682?s=21&t=12eEkrJ2nkMeP-bGECxOLQ 

Voice Cast: https://deadline.com/2022/06/lord-of-the-rings-the-war-of-the-rohirrim-brian-cox-miranda-otto-1235045883/amp/ 

01:59 The Jon Snow Show: https://variety.com/2022/tv/news/game-of-thrones-jon-snow-series-kit-harington-hbo-1235297033/ 

03:20 AI Drawn Comic: https://bleedingcool.com/comics/abolition-of-man-first-comic-book-entirely-drawn-by-a-i-algorithm/ 

04:34 Legendborn Adaptation: https://deadline.com/2022/02/felicia-d-henderson-to-adapt-tracy-deonns-ya-fantasy-novel-legendborn-1234925007/ 

05:14 Gormenghast Trilogy: https://www.youtube.com/watch?v=58Bux5zvzBU&ab_channel=TheFolioSociety 

05:55 WoTCon: WoTCon.com

06:42 Scavengers Reign: https://twitter.com/AnimationOnMax/status/1537105012274483200

08:00 One Punch Man Live Action: https://deadline.com/2022/06/one-punch-man-manga-movie-sony-justin-lin-scott-rosenberg-jeff-pinkner-script-1235044549/ 

08:48 Avatar Movies: https://variety.com/2022/film/news/avatar-last-airbender-films-paramount-nickelodeon-1235295075/ 

09:05 Mad God Released: https://collider.com/mad-god-phil-tippett-horror-stop-motion-shudder/ 

09:49 Stranger things Record: https://variety.com/2022/tv/news/stranger-things-4-volume-1-netflix-top-10-ratings-1235294023/ 

10:41  Squid Game S2: https://www.insider.com/everything-we-know-so-far-about-squid-game-season-2-2022-6

## Penguin Random House Sent Me Something! ...Oops
 - [https://www.youtube.com/watch?v=LzQ82bdXadQ](https://www.youtube.com/watch?v=LzQ82bdXadQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-06-16 00:00:00+00:00

I got a box from a Penguin...
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Broken Binding First Law: https://www.thebrokenbinding.co.uk/product-page/the-blade-itself-joe-abercrombie

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


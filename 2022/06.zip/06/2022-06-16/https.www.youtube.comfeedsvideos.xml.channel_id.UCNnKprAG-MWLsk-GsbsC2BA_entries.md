# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Amber Heard destroys the world (cartoon)
 - [https://www.youtube.com/watch?v=3huYExmlxbo](https://www.youtube.com/watch?v=3huYExmlxbo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2022-06-16 16:02:19+00:00

Get your exclusive deal here! https://NordVPN.com/gitz - it's risk free with Nord's 30 day money-back guarantee!

Subscribe to the 2nd channel brother!
https://www.youtube.com/channel/UCBngnLwNNuEXwB6BvwZ0Ykw

Special thanks to our Patron Producers!

Albert Hutchins
Andrew Palmer
Adam Knopow

Created by ► 
Tom Hinchliffe & Don Greger

VO ► 
Jordan Peterson - Don 
Lobster King - Tom 

Boards ►
Ollie Kremer

Animation ►
Holly Gee
CalebJordan
Sandbag
Redminus

Backgrounds ►
Naav Draws https://www.instagram.com/naav_draws/
Adila Noor @taksesal
Soured Apple https://www.twitter.com/SouredApple

Ad Compositing ► 
Oddest of the Odd

Music ►
Zach Heyde https://youtube.com/playlist?list=PLXtP4ANq7nIUYo6VZEEHtd8H3HP_MthUC

Sound ► 
Justin Greger https://twitter.com/imadeasong

Instagram ►
https://www.instagram.com/flashgitz/
https://www.instagram.com/flashgitzdon
https://www.instagram.com/flashgitzt0m

Twitter ►
https://www.twitter.com/flashgitztom
https://www.twitter.com/flashgitzdon
https://www.twitter.com/flashgitzanims

Patreon ►
https://patreon.com/flashgitz

Merch ►
https://crowdmade.com/flashgitz

Discord ►
https://discord.gg/nJCcJj6


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW War Games of 2022
 - [https://www.youtube.com/watch?v=Zgz0w5RyK9c](https://www.youtube.com/watch?v=Zgz0w5RyK9c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-18 00:00:00+00:00

Games featuring warfare are never in short supply. Check out these new war games for PC, PS5, PS4, Xbox Series X/S/One, and beyond.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:16 Isonzo
1:11 Warno
2:02 Dune: Spice Wars 
3:03 Men of War II
3:49 Sniper Elite 5
4:40 Medic: Pacific War
5:21 Company of Heroes 3 
6:14 Expedition Rome
7:06 Ratten Reich
8:06 Call of Duty: Modern Warfare 2
9:22 BONUS 

Isonzo

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : TBA 2022 



Warno

Platform : PC 

Release Date : January 20, 2022



Dune: Spice Wars 

Platform : PC 

Release Date : April 26, 2022 



Men of War II

Platform : PC 

Release Date : 2022 



Sniper Elite 5

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : May 26, 2022



Medic: Pacific War

Platform : PC 

Release Date : 2022 



Company of Heroes 3 

Platform : PC 

Release Date : 2022 



Expedition Rome

Platform : PC 

Release Date : January 20, 2022 



Ratten Reich

Platform : PC 

Release Date : Sep 2022



Call of Duty: Modern Warfare 2

Platform : PC PS4 Xbox One PS5 XSX|S 

Release Date : October 28, 2022 



BONUS 



Warhammer 40,000: Darktide

Platform : PC XSX|S 

Release Date : September 13, 2022



War Hospital 

Platform : PC PS5 XSX|S

Release Date : Q4 2022



Lego Star Wars: The Skywalker Saga

Platform : PC PS4 PS5 XSX|S Xbox One Switch 

Release Date : April 5, 2022 



Regiments

Platform : PC 

Release Date : 2022



Starship Troopers – Terran Command

Platform : pc 

Release Date : June 16, 2022 



Diplomacy Is Not An Option

Platform : PC 

Release Date : February 9, 2022

## FALLOUT 5 CONFIRMED + ANOTHER OPEN WORLD RPG GETS SEQUEL
 - [https://www.youtube.com/watch?v=c5pIUTzOzeM](https://www.youtube.com/watch?v=c5pIUTzOzeM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-17 00:00:00+00:00

Sponsored by Dr. Squatch. New customers click https://bit.ly/32gaV2J and use my code DSQGAMERANX to get 20% off on orders of $20 or more.

Xbox Bethesda news, Resident Evil 4 remake updates, RE Village Third Person, Dragon's Dogma 2 appears, and more in a week FULL of gaming news.

Jake on Instagram: https://bit.ly/3uUh9Ot

Jake's other channel: https://youtu.be/5kauItwhEVE


 ~~~~STORIES~~~~


Xbox Bethesda announcements
https://youtu.be/KXDG_oZPD3Y


Fallout 5 Bethesda interview 
https://youtu.be/4j-PV-sSbXs

Final Fantasy 7 remake news:
https://www.theverge.com/2022/6/16/23170332/final-fantasy-vii-remake-part-2-rebirth-ps5
https://www.ign.com/articles/crisis-core-final-fantasy-7-remake-remaster-reboot

New RPG
Dragon’s Dogma 2
https://www.gameinformer.com/2022/06/16/dragons-dogma-2-has-been-announced-a-decade-after-its-predecessors-release

Sonic Frontiers
Footage via IGN: https://youtu.be/cxJ5_ovBC_g


Cool controller
https://www.theverge.com/2022/6/14/23166020/8bitdo-lite-se-accessible-gaming-controller-price-specs
PS5 Pro controler?
https://tryhardguides.com/official-playstation-5-pro-controllers-coming-soon-hardware-details/

Stalker Update
https://youtube.com/watch?v=RxcfxdG22pg…
New trailer: https://youtu.be/4PqR5OBb1Ys

Goldeneye inspired game Agent 64 Spies Never Die
https://youtu.be/UhU4PRfb5Go

TMNT Shredder’s Revenge 
https://youtu.be/tPnHrSDLZzU



Gran Turismo movie
https://deadline.com/2022/06/gran-turismo-movie-neill-blomkamp-video-game-adaptation-sony-playstation-1235033958/


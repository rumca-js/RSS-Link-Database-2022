# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## The $1500 Snapdragon disaster
 - [https://www.youtube.com/watch?v=8eHuTeNOTfU](https://www.youtube.com/watch?v=8eHuTeNOTfU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-06-17 00:00:00+00:00

Visit https://brilliant.org/TFC/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription - Sponsored by Brilliant.
 
 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► This video ◄◄◄  
 
This week Samsung announced the Samsung Wallet, Microsoft killed Internet Explorer, but didn't, and Qualcomm burned its biggest fans with the Snaprdragon for Insider phone. 
 
Episode 101
 
This video on Nebula: https://nebula.app/videos/the-friday-checkout-the-1500-snapdragon-disaster

Nothing video (Das Kann Was): https://youtu.be/-wxN-FhwMeY
 
 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► TechAltar links ◄◄◄  
 
Merch:  
http://enthusiast.store   
 
Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  
 
If you want to support my work directly:  https://flattr.com/@techaltar   
 
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 
►►► Attributions & Time stamps◄◄◄
 
Music by Edemski: https://soundcloud.com/edemski 
 
0:00 Intro
0:18 Release highlights
3:18 Samsung wallet
4:35 Internet Explorer can't die
6:36 Qualcomm messed up


## Don't Put All Your Code In Internal | Ido Perlmuter
 - [https://ido50.net/rants/dont-put-all-your-code-in-internal](https://ido50.net/rants/dont-put-all-your-code-in-internal)
 - RSS feed: https://ido50.net
 - date published: 2022-06-17 13:54:11.142802+00:00

Personal Website of Ido Perlmuter


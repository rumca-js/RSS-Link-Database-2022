# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Fallout 3 Is An Absolute Nightmare - This Is Why - Remake
 - [https://www.youtube.com/watch?v=4UOU1UHCd9k](https://www.youtube.com/watch?v=4UOU1UHCd9k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2022-06-17 21:00:11+00:00

Fallout 3 is back again! This time without the violence so that everyone can see it.

To receive a Sid pin join my Patreon at $10 here!
https://www.patreon.com/UpIsNotJump 

Or become a Member at $10 by clicking the "Join" button to the right of this description!

You gotta join by July 17th to receive a pin though :) Details on how to get one will be in the Patreon and Members area after you join!

AND my merch is here: https://www.pixelempire.com/pages/upisnotjump

Twitter-o-fish: https://twitter.com/UpIsNotJump 

Fallout 3 is one of my favourite games from my YOUTH. It still holds up, which is enough given how old it is, but I think even for the time it messed a few things up.

My current plan now is to do all the major Fallout games, so all that is left is Fallout New Vegas, Fallout 4, and maybe some other stragglers. This will take me years. 

Thumbnail Artwork by Skutch: https://twitter.com/skutchdraws?lang=en

A special thanks to my members!! 
Siberial :D


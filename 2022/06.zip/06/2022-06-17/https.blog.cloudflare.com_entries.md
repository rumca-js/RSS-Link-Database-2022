## Cloudflare mitigates 26 million request per second DDoS attack
 - [https://blog.cloudflare.com/26m-rps-ddos/](https://blog.cloudflare.com/26m-rps-ddos/)
 - RSS feed: https://blog.cloudflare.com
 - date published: 2022-06-17 08:25:29.320467+00:00

Last week, Cloudflare automatically detected and mitigated a 26 million request per second DDoS attack — the largest HTTPS DDoS attack on record


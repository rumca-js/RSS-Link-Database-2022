## ⚡️ The computers are fast, but you don't know it | 🌚 Computer Science After Dark
 - [http://shvbsle.in/computers-are-fast-but-you-dont-know-it-p1/](http://shvbsle.in/computers-are-fast-but-you-dont-know-it-p1/)
 - RSS feed: http://shvbsle.in
 - date published: 2022-06-17 08:40:37.912679+00:00

The computers are fast but you don't know it: Speeding up your Python functions with Cython & C++


## #16 Najważniejszy punkt naszej 2 miesięcznej wyprawy z @vlogcasha
 - [https://www.youtube.com/watch?v=quclN1ZkfGQ](https://www.youtube.com/watch?v=quclN1ZkfGQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIFlYVfPnvukmFOvC4JUfOg
 - date published: 2022-06-17 00:00:00+00:00

Dojechaliśmy do muzeum miejsca bez którego nasza podróż stała by pod dużym znakiem zapytania.
🧗🏻Wesprzyj moje przygody na patronite: https://patronite.pl/Nejtan
📷 Instagram: https://www.instagram.com/nejthan
📜 Napisz do mnie: swiatwedlugnejtana@gmail.com
🎵 Muzyka: https://share.epidemicsound.com/m7uq26

2022 Trip z  @vlogcasha    po Florydzie https://bit.ly/3uueZGV
2021 Trip z  @vlogcasha    po zachodzie Usa i Alaska
https://bit.ly/3D6ClpI
#swiatwedlugnejtana #nejtan


## Vaccine transparency case is still not closed, despite EC’s claim
 - [https://corporateeurope.org/en/2022/06/vaccine-transparency-case-still-not-closed-despite-ecs-claim](https://corporateeurope.org/en/2022/06/vaccine-transparency-case-still-not-closed-despite-ecs-claim)
 - RSS feed: https://corporateeurope.org
 - date published: 2022-06-17 19:15:04+00:00

Vaccine transparency case is still not closed, despite EC’s claim


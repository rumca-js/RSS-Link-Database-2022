# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## MMYYKK - Troubled Man (live at The Current)
 - [https://www.youtube.com/watch?v=Z_uufE4IdGw](https://www.youtube.com/watch?v=Z_uufE4IdGw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-06-18 00:00:00+00:00

Blending soul, jazz, hip-hop and R&B, MMYYKK and The Blackbeat Theory perform "Troubled Man" live in The Current studio in a session for The Local Show.

Personnel:
MMYYKK - keys, vocals
Jalyn Spencer - bass
LA Buckner - drums
Omar Abdulkarim - horn

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#mmyykk #theblackbeattheory

## MMYYKK - Sweetest Embrace (live at The Current)
 - [https://www.youtube.com/watch?v=NFSpvwped40](https://www.youtube.com/watch?v=NFSpvwped40)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-06-17 00:00:00+00:00

Blending soul, jazz, hip-hop and R&B, MMYYKK and The Blackbeat Theory perform "Sweetest Embrace" live in The Current studio in a session for The Local Show.

Personnel:
MMYYKK - keys, vocals
Jalyn Spencer - bass
LA Buckner - drums
Omar Abdulkarim - horn

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#mmyykk #theblackbeattheory


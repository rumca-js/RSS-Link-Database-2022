# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Girl Ultra - Cosas q Nadie Ve (Live on KEXP)
 - [https://www.youtube.com/watch?v=OiPGB1pMb6Y](https://www.youtube.com/watch?v=OiPGB1pMb6Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-17 00:00:00+00:00

http://KEXP.ORG presents Girl Ultra performing “Cosas q Nadie Ve” live in the KEXP studio. Recorded May 27, 2022.

Mariana de Miguel - Vocals 
Hector Rodriguez - Guitar
Andrea Martinez - Bass
Samuel Mendoza - Drums

Host: Albina Cabrera
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Alaia D’Alessandro, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://linktr.ee/girlultra
http://kexp.org

## Girl Ultra - DameLove (Live on KEXP)
 - [https://www.youtube.com/watch?v=wT09zjqXnrk](https://www.youtube.com/watch?v=wT09zjqXnrk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-17 00:00:00+00:00

http://KEXP.ORG presents Girl Ultra performing “DameLove” live in the KEXP studio. Recorded May 27, 2022.

Mariana de Miguel - Vocals 
Hector Rodriguez - Guitar
Andrea Martinez - Bass
Samuel Mendoza - Drums

Host: Albina Cabrera
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Alaia D’Alessandro, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://linktr.ee/girlultra
http://kexp.org

## Girl Ultra - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=3etGeg4BfIU](https://www.youtube.com/watch?v=3etGeg4BfIU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-17 00:00:00+00:00

http://KEXP.ORG presents Girl Ultra performing live in the KEXP studio. Recorded May 27, 2022.

Songs:
Cosas q Nadie Ve
Llama
Damelove
Punk

Mariana de Miguel - Vocals 
Hector Rodriguez - Guitar
Andrea Martinez - Bass
Samuel Mendoza - Drums

Host: Albina Cabrera
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Alaia D’Alessandro, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://linktr.ee/girlultra
http://kexp.org

## Girl Ultra - Llama (Live on KEXP)
 - [https://www.youtube.com/watch?v=ux9GlfmlQ-k](https://www.youtube.com/watch?v=ux9GlfmlQ-k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-17 00:00:00+00:00

http://KEXP.ORG presents Girl Ultra performing “Llama” live in the KEXP studio. Recorded May 27, 2022.

Mariana de Miguel - Vocals 
Hector Rodriguez - Guitar
Andrea Martinez - Bass
Samuel Mendoza - Drums

Host: Albina Cabrera
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Alaia D’Alessandro, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://linktr.ee/girlultra
http://kexp.org

## Girl Ultra - Punk (Live on KEXP)
 - [https://www.youtube.com/watch?v=ARamaOqunZ8](https://www.youtube.com/watch?v=ARamaOqunZ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-17 00:00:00+00:00

http://KEXP.ORG presents Girl Ultra performing “Punk” live in the KEXP studio. Recorded May 27, 2022.

Mariana de Miguel - Vocals 
Hector Rodriguez - Guitar
Andrea Martinez - Bass
Samuel Mendoza - Drums

Host: Albina Cabrera
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Alaia D’Alessandro, Carlos Cruz, Scott Holpainen & Ettie Wahl
Editor: Scott Holpainen

https://linktr.ee/girlultra
http://kexp.org


# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Dobijali swoich strzałem w głowę"
 - [https://tvn24.pl/go/programy,7/superwizjer-odcinki,10894/odcinek-1019,S00E1019,797940?source=rss](https://tvn24.pl/go/programy,7/superwizjer-odcinki,10894/odcinek-1019,S00E1019,797940?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-06-17 17:04:14+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-95e8sl-donbas-za-wolnosc-nasza-i-wasza-5754635/alternates/LANDSCAPE_1280" />
    Reportaż Michała Przedlackiego.

## Agnieszka Smoczyńska o byciu kobietą w świecie filmu
 - [https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-21,S00E21,797165?source=rss](https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-21,S00E21,797165?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-06-17 10:28:20+00:00

<img alt="Agnieszka Smoczyńska o byciu kobietą w świecie filmu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hmbzlk-olejnik-smoczynska-5754054/alternates/LANDSCAPE_1280" />
    Z reżyserką "Córek dancingu" i "The Silent Twins" rozmawia Monika Olejnik.


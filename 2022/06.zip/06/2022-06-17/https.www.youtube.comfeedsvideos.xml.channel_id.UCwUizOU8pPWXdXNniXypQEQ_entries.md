# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## What We DON’T Want You To Know! - News Update
 - [https://www.youtube.com/watch?v=uE3EFV5DE18](https://www.youtube.com/watch?v=uE3EFV5DE18)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-06-18 00:00:00+00:00

Grab your Blue Light Blocking Glasses at https://boncharge.com/jp Use Code "JP" for 15% Off!

Get your Freedom Merch here - https://awakenwithjp.com/shop

Upcoming LIVE Shows - https://awakenwithjp.com/tour

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

The most recent ratings for news channels are out! Where does We Lie To You News compare to CNN and Fox? Stay tuned to find out...

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://rumble.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


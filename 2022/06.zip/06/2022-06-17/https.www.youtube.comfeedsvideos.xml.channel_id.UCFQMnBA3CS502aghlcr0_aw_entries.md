# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## Why Celsius Fell Apart
 - [https://www.youtube.com/watch?v=1nVG8PF4ECU](https://www.youtube.com/watch?v=1nVG8PF4ECU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2022-06-18 00:00:00+00:00

Unbank yourself - not a great plan in hindsight

Follow upper Echelon Gamers: https://m.youtube.com/channel/UChI0q9a-ZcbZh7dAu_-J-hg
Follow Dirty Bubble Media: https://dirtybubblemedia.substack.com
Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://twitter.com/LeszczynskiEd
Video Editor: Harry Bagg  https://twitter.com/HarryRBagg
Virtual Production Software: Aximmetry https://aximmetry.com/

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Lab Leak: NOW It Makes Sense
 - [https://www.youtube.com/watch?v=QsM277rpmIM](https://www.youtube.com/watch?v=QsM277rpmIM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-18 00:00:00+00:00

You were called a conspiracy theorist for asking whether COVID19 came from a lab leak. Now, the WHO is finally asking the same questions. #LabLeak #WHO #CHINA 

References
https://apnews.com/article/covid-science-health-world-organization-government-and-politics-8662c2bc1784d3dea33f61caa6089ac2
--------------------------------------------------------------------------------------------------------------------------
Tickets now on sale for my 1 day event COMMUNITY in Hay-on-Wye. I'm joined by Wim, Vandana Shiva for conversations on spirituality, wellness, healthy living and our environment. Get your tickets bit.ly/3xoHQPv

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Jan. 6: They Don’t Want You To Know This
 - [https://www.youtube.com/watch?v=k2jsA3sk2H0](https://www.youtube.com/watch?v=k2jsA3sk2H0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-17 00:00:00+00:00

Whatever you think about events on Jan 6th 2020, are the current hearings just an excuse for more political theatre? And will anything actually be achieved other than more domestic terrorism laws that both sides of the political establishment want? 
#trump #january6 #capitolriots  

References
https://jacobin.com/2022/06/capitol-riot-trump-gop-democrats-hearings
https://jacobin.com/2021/01/us-capitol-riot-police-investigation
--------------------------------------------------------------------------------------------------------------------------
Tickets now on sale for my 1 day event COMMUNITY in Hay-on-Wye. I'm joined by Wim, Vandana Shiva for conversations on spirituality, wellness, healthy living and our environment. Get your tickets bit.ly/3xoHQPv

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The History of Minas Morgul | Tolkien Explained
 - [https://www.youtube.com/watch?v=sP1zQWvRVk8](https://www.youtube.com/watch?v=sP1zQWvRVk8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-06-18 00:00:00+00:00

Once the bright and beautiful city of Gondor, Minas Ithil (The Tower of the Moon),  would fall twice to Sauron's forces.  The second time, it is made into Minas Morgul - the home of the Witch-King.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri
Noe Leyva - https://twitter.com/NoeLeyvArt

To purchase artist work, check out these amazing artists!

Minas Ithil - Shadow of War
Minas Ithil Attack - Shadow of War
The Dark Tower - John Howe
Nazgul - Rui Goncalves
Minas Morgul - Shadow of War
Downfall of Numenor - Dracarysdrekkar7
Under Construction - Bryan Bitter
The White Tree - Ted Nasmith
Stealing the Fruit of Nimloth - Anke Eissmann
Sauron - Felix Englund
Sauron at Barad-dur - Shadow of War
Orcs - Angus McBride
The Last Alliance - Jenny Dolfen
Aegeri - Minas Tirith
The Meeting at Amon Sul - Anke Eissmann
Weathertop - Dracarysdrekkar7
A Palantir - Anke Eissmann
Gil-galad, Sauron, and Elendil - Tom Romain
Isildur's Bane - Andrea Piparo
Minas Ithil - Matej Cadil
Minas Tirith - Nahar_doa
Witch-king of Angmar - LOTRO
Witch-King in Battle - LOTRO
Annuminas - Ted Nasmith
Nazgul Bowing Before Sauron - Kip Rasmussen
Minas Ithil Destruction - Shadow of War
Orc Army - Bryan Bitter
Stalker - Skullb*st*rd
The Dark Tower - John Howe
Minas Morgul - Ralph Damiani
Minas Tirith - Aronja Art
Minas Morgul - Shadow of War
Witch-king - Weirling
After the Dream - Anke Eissmann
Boromir of Gondor - Catherine Karina Chmiel
Sauron Helmet - WETA
Throne of Gondor - Bryan Bitter
Boromir - Kuliszu
Strider - CK Goksoy
Minas Morgul - John Howe
The Uruk-hai - John Howe
Gorbag and Shagrat - Alan Lee
Defending Osgiliath - Anke Eissmann
Boromir Defending Osgiliath - Catherine Karina Chmiel
The Morgul Blade - Matej Cadil
Faramir's Burden - Elrodimus Flash
Endless Stair - John Howe
Riders at the Ford - Ted Nasmith
You Fool, No Man Can Kill Me - Bembiann
Witch-King - John Howe
Weak - Aegeri
Minas Morgul - John Howe
Battle of Pelennor Fields - Magdalena Katanska
Eowyn and Faramir - Ted Nasmith
Eowyn and Faramir - Jenny Dolfen
The Tower of the Moon - Ted Nasmith

#tolkien #lordoftherings #minasmorgul


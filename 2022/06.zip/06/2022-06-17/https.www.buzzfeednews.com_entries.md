## US TikTok User Data Has Been Repeatedly Accessed From China, Leaked Audio Shows
 - [https://www.buzzfeednews.com/article/emilybakerwhite/tiktok-tapes-us-user-data-china-bytedance-access](https://www.buzzfeednews.com/article/emilybakerwhite/tiktok-tapes-us-user-data-china-bytedance-access)
 - RSS feed: https://www.buzzfeednews.com
 - date published: 2022-06-17 21:11:37+00:00

US TikTok User Data Has Been Repeatedly Accessed From China, Leaked Audio Shows


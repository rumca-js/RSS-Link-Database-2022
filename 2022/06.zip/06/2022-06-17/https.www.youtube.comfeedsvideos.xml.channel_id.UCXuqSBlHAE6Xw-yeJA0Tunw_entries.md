# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## They told me I was stupid - heating my pool with computers
 - [https://www.youtube.com/watch?v=4ozYlgOuYis](https://www.youtube.com/watch?v=4ozYlgOuYis)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-18 00:00:00+00:00

Check out the NZXT H7 at series at: https://nzxt.co/LinusH7

The computers in my house generate a ton of heat, but why spend money to get rid of it, when you can USE it... in the pool.

Discuss on the forum: https://linustechtips.com/topic/1438005-they-told-me-i-was-stupid/

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro

## It's Coming For Us... - WAN Show June 17, 2022
 - [https://www.youtube.com/watch?v=U5YOjLdfRZA](https://www.youtube.com/watch?v=U5YOjLdfRZA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-17 00:00:00+00:00

Try Vultr today with an exclusive 30-day $100 code for signing up at https://getvultr.com/LTT
Buy a Seasonic Prime TX 1000W PSU: https://geni.us/aryiquT
Save 10% on XSplit's video tools at https://lmg.gg/xsplit

Check out Ivan’s GPUs available for auction below. 

Star Wars Titan: https://www.ebay.ca/itm/175321698128
GTX 580: https://www.ebay.ca/itm/175321695907

All proceeds go to SOS Children’s Villages, more information at https://lmg.gg/sosabout 
Donate to SOS Children’s Villages today at https://lmg.gg/soscharity

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Its-Coming-For-Us------WAN-Show-June-17--2022-e1k6ola

Timestamps: (Courtesy of Bip Bop)
0:00 Welcome!
1:18 intro
1:50 Lab 2, yes, he complained, don't dox or harass people, Linus will take care of it his way.
10:15 Amazon turn over
15:50 Burn out
16:20 LMG vs FAANG Co. 
17:51 mobile game dev
19:08 LMG financial commitments
20:35 return to mobile game dev
21:58 sponsor segue
26:10 crypto winter
34:14 crypto GPUs aspect
36:30 scrapyard wars remote control, How famous Linus isn't according to Linus
38:36 crypto
40:00 Linus known in oil patches
42:20 crypto discussion 
47:22 product launch, Merch Messages
50:38 screwdriver silver and limited black
56:57 find the Linus in your life
1:00:10 Linus badminton & teachers
1:17:38 screwdriver Merch message question
1:18:16 Kaleidescape
1:28:56 absolute control of any tech company, pick one
1:30:08 most life impactful animated movie
1:33:26 favorite laptop
1:35:27 Daily reading
1:35:46 Lab in hindsight
1:36:49 any Steam Deck video plans?
1:39:07 Roku peeps
1:39:18 Framework transparency
1:39:37 Hydravion French for Floatplane Roku
1:40:13 TY all
1:40:22 outro
1:40:27 hydravienne clarification
1:40:55 outro
1:41:08 B4 we go 😆


# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Rubens - Koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=t6-ZAtm_4c4](https://www.youtube.com/watch?v=t6-ZAtm_4c4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-06-18 00:00:00+00:00

Rubens na żywo w MUZO.FM. Artysta wykonał w naszym studiu wyjątkowe wersje utworów Wszystko OK?, Nie potrzeba nam i Jak dobrze znów Cię mieć. Piosenki pochodzą z debiutanckiej EPki Rubensa - Wynoszę się. 

00:00 Wszystko OK?
03:11 Nie potrzeba nam
06:24 Jak dobrze znów Cię mieć

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Rubens: http://www.facebook.com/rubenspoland
Instagram Rubens: http://www.instagram.com/rubens____
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


#popolsku


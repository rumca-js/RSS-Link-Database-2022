# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Elon Musk hints at layoffs in first meeting with Twitter employees
 - [https://www.bbc.co.uk/news/business-61836179?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61836179?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-06-17 05:27:16+00:00

The billionaire also discussed aliens in his first address to the social media firm's staff.


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## How Close Did Gina Carano Get to Fighting Ronda Rousey?
 - [https://www.youtube.com/watch?v=__t3rU0QjsE](https://www.youtube.com/watch?v=__t3rU0QjsE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-06-28 00:00:00+00:00

Taken from JRE #1837 w/Gina Carano:
https://open.spotify.com/episode/503ipERK7x0WHmrQxtDs5D?si=3a1ddd482de64675

## Joe Asks Gina Carano About Being a Pioneer of Women's MMA
 - [https://www.youtube.com/watch?v=Pk9EVrHVKko](https://www.youtube.com/watch?v=Pk9EVrHVKko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-06-28 00:00:00+00:00

Taken from JRE #1837 w/Gina Carano:
https://open.spotify.com/episode/503ipERK7x0WHmrQxtDs5D?si=80d89084bff745ed


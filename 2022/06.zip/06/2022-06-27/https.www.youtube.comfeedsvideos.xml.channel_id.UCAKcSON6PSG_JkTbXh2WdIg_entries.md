# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Grace Cummings - Two Little Birds (live at The Current)
 - [https://www.youtube.com/watch?v=pIrVgtLTdv8](https://www.youtube.com/watch?v=pIrVgtLTdv8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-06-28 00:00:00+00:00

Grace Cummings visited The Current studio in St. Paul, Minn., to play songs from her 2022 album, 'Storm Queen,' including this song, "Two Little Birds."

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#gracecummings


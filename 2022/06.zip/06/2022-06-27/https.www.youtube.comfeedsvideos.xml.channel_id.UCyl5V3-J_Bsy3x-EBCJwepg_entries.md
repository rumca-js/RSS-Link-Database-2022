# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## God, UFOs, and The Physics of Star Wars with Hugh Ross | A Bee Interview
 - [https://www.youtube.com/watch?v=7yX5iEACwrA](https://www.youtube.com/watch?v=7yX5iEACwrA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-06-28 00:00:00+00:00

Astrophysicist Hugh Ross, the founder of Reasons To Believe, talks to The Babylon Bee about extraterrestrial alien life, UFOs, and the reasons from science to believe in the God of the Bible. They also talk about how faster than light travel would completely kill you dead.

Check out Reasons To Believe at: http://reasons.org

Look for Dr. Ross’ new book coming out soon, Designed To The Core: http://reasons.org/tothecore

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Satan Responds To Roe v. Wade Overturn
 - [https://www.youtube.com/watch?v=0LI4UEHUvtM](https://www.youtube.com/watch?v=0LI4UEHUvtM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-06-28 00:00:00+00:00

Satan held a press conference today responding to the big loss of Roe v. Wade. He's doing his best to keep his chin up.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


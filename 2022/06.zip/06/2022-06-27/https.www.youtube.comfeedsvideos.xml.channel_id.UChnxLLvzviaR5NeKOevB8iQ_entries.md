# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Exploring XAOC Devices Timiszoara (FX) and Koszalin (Frequency Shifter)
 - [https://www.youtube.com/watch?v=HFJBKKmcG2s](https://www.youtube.com/watch?v=HFJBKKmcG2s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-06-27 00:00:00+00:00

In this video, we'll explore the two newest offerings from XAOC: the Koszalin stereo frequency shifter and the Timiszoara multi-effects unit. It's gonna get bleepy.

Get these modules for yourself at Perfect Circuit: 

XAOC Koszalin - https://bit.ly/3b89ebL
XAOC Timiszoara - https://bit.ly/3O1pJ85

00:00 intro
00:37 combo glitchy patch
02:08 Koszalin as a phaser
02:51 Timiszoara reverb bank 1
06:05 Timiszoara reverb bank 2
07:37 Timiszoara shimmers
09:48 Techno beats with Koszalin pings
14:14 Timiszoara tap tempo delays
16:58 Timiszoara stereo delays
18:17 Koszalin robot beats
19:43 Timiszoara Dual bank patch
20:41 final thoughts

Join the Patreon and get access to music, presets, samples, and a great community.
Join Patreon:  http://bit.ly/rmrpatreon

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

Join the Patreon and get access to music, presets, samples, and a great community.
Join Patreon:  http://bit.ly/rmrpatreon

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


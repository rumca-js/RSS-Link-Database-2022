# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## You’ve Gotta Be F*cking Kidding Me
 - [https://www.youtube.com/watch?v=j1taAqON5vY](https://www.youtube.com/watch?v=j1taAqON5vY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-28 00:00:00+00:00

As Joe Biden accidentally reveals a ‘cheat sheet’ and Nancy Pelosi appears to elbow a child in the ribs, we ask, how do your elected leaders even get out of bed in the morning, let alone run a country? #biden #pelosi #democrats

References
https://www.independent.co.uk/news/world/americas/us-politics/joe-biden-cheat-sheet-notes-putin-b2108539.html
https://nypost.com/2022/06/27/gop-rep-mayra-flores-accuses-speaker-nancy-pelosi-of-pushing-daughter-during-photo-op/
https://nypost.com/2022/06/23/a-very-specific-cheat-sheet-reminds-biden-how-to-act/
--------------------------------------------------------------------------------------------------------------------------
Tickets now on sale for my 1 day event COMMUNITY in Hay-on-Wye. I'm joined by Wim, Vandana Shiva for conversations on spirituality, wellness, healthy living and our environment. Get your tickets bit.ly/3xoHQPv

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Roe v Wade: You Need To Know This Now
 - [https://www.youtube.com/watch?v=ZGsFrk0MrwQ](https://www.youtube.com/watch?v=ZGsFrk0MrwQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-27 00:00:00+00:00

The US Supreme Court last week ruled to overturn Roe v. Wade. But what do Americans really think about abortion, and has it always been such a partisan issue or is it just another example of politicians using a complex situation for their own gain?  
#roevwade #supremecourt 

References
https://www.reuters.com/world/us/how-abortion-became-divisive-issue-us-politics-2022-06-24/
--------------------------------------------------------------------------------------------------------------------------
Tickets now on sale for my 1 day event COMMUNITY in Hay-on-Wye. I'm joined by Wim, Vandana Shiva for conversations on spirituality, wellness, healthy living and our environment. Get your tickets bit.ly/3xoHQPv

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## What if I had an unlimited budget…? - Sony A95K
 - [https://www.youtube.com/watch?v=1eALWqNZh1I](https://www.youtube.com/watch?v=1eALWqNZh1I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-28 00:00:00+00:00

Get your Grid Studio art frame today at: https://gridstudio.cc/linus
Enter for your chance to win your own frame at: https://lmg.gg/gridgiveaway

Our Sony Bravia A95K showed up and it looks STUNNING, but how much are you willing to spend chasing minor improvements over similarly beautiful displays? Is THIS the TV that ends up in my family room?

Discuss on the forum: https://linustechtips.com/topic/1439971-what-if-i-had-an-unlimited-budget%E2%80%A6-sony-a95k/

Buy a Sony A95K: https://lmg.gg/dvPqX

Buy an LG G2: https://geni.us/GG5EUDH
 
Buy a Samsung S95B:https://geni.us/pRFo5
 
Buy an Intel Core i9-12900K: https://geni.us/hw0jtIM

Buy an RTX 3080 Ti: https://geni.us/52P7uqm

Buy a kit of Crucial DDR5 2x8GB: https://geni.us/BfuKO

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:27 The Competition
3:00 A95K
5:00 Test Results
6:40 Best Settings
7:36 Features
8:50 The Remote
11:08 Panel Latency
12:24 Conclusion
14:20 Outro

## An Unconventional Upgrade - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=6sAu7CDwLiU](https://www.youtube.com/watch?v=6sAu7CDwLiU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-27 00:00:00+00:00

Thanks to Intel for continuing to sponsor this awesome series! Buy an Intel Core i7-12700K: https://geni.us/RPyj54U

Discuss on the forum: https://linustechtips.com/topic/1439783-an-unconventional-upgrade-intel-5000-extreme-tech-upgrade/

Buy dbrand Darkplates: https://lmg.gg/6PN8H

Buy an ASUS Prime Z690-P D4: https://geni.us/8AmNIja

Buy a Steelcase Night Owl Gesture: https://lmg.gg/OMP30

Buy a Corsair MP600 PRO LPX 1TB SSD: https://geni.us/coOQ

Buy an EVGA XC3 RTX 3080: https://geni.us/ejhr

Buy an Xbox Series X: https://geni.us/Ud5jX

Buy a Sony PS5 Disk Edition: https://geni.us/4iIkXx

Buy a TotalMounts PS5 Wall Stand: https://geni.us/Ubtnzl

Buy a Sony X85J 55": https://geni.us/piGL

Buy a Mounting Dream MD2379 55" Wall Mount: https://geni.us/FAfz0y6

Buy a Vitamix Ascent 2300: https://geni.us/FHZE

Buy Poly-fil Stuffing: https://lmg.gg/edQfU

Purchases made through some store links may provide some compensation to Linus Media Group.


► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Special Intro by MBarek Abdelwassaa
https://www.instagram.com/mbarek_abdel/

Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 - Intro
0:50 - Parts List
2:26 - Linus Cleaning Tips
3:59 - Building not one, but TWO PCs
10:47 - How many TVs do you need?!
14:43 - Linus gets maimed
15:46 - Back to building
17:50 - Linus Console Tips
19:12 - How long does it take to build two PCs?
22:50 - Building a PlayStation
24:10 - All that money and he didn't get a couch
25:10 - Testing the setups
26:51 - Conclusion


# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## META is making VR LOOK BETTER THAN REAL LIFE - Visual Turing Test
 - [https://www.youtube.com/watch?v=pwezau85VbY](https://www.youtube.com/watch?v=pwezau85VbY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-06-28 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire week's worth of VR news! Today we take a look at the Open Metaverse forum, metas crazy new VR headset prototypes, Valve Deckard leaks and so much more! 
Hope you enjoy!

Links for video:
Khronos Group Metaverse Forum:
https://metaverse-standards.org/

VAIL VR DISCORD: https://bit.ly/3y45ZtV
VAIL VR STEAM: https://bit.ly/3xKgsdB
TMG FORM: https://bit.ly/3OiCCuM

My links:
MY LINKS:
Discord:
https://discord.gg/2hCGM9BYez
Twitch:
https://www.twitch.tv/thrilluwu
Twitter:
https://twitter.com/Thrilluwu
Patreon:
https://www.patreon.com/Thrillseeker


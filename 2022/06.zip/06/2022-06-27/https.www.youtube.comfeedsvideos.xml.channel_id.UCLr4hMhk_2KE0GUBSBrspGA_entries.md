# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Jaki smartfon do zdjęć? Samsung S22 Ultra vs iPhone 13 Pro vs Sony Xperia I IV vs Vivo X80 Pro
 - [https://www.youtube.com/watch?v=ugEftmLknFs](https://www.youtube.com/watch?v=ugEftmLknFs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-06-28 00:00:00+00:00

W projekcie udział wzięli (za co bardzo dziękuję!):
Dominika Koszowska - https://instagram.com/dominika.koszowska_official
Kamil Filipiak - https://www.instagram.com/philipiakkamil
Błażej Jeliński - https://instagram.com/blazej_jelen
Przemek Zmarzły - https://instagram.com/zmarzly

Dziękujemy również kawiarni NA BANK - https://www.instagram.com/nabank_specialtycoffee/

Smartfony, którymi fotografowie robili zdjęcia:
Sony Xperia I IV - https://bit.ly/3u9n1We
Samsung S22 Ultra - https://bit.ly/3NquqY4
iPhone 13 Pro - https://bit.ly/3P58aUX 
Vivo X80 Pro - https://www.vivo.com/pl/products/x80pro

W odcinku:
00:00 Jaki smartfon do zdjęć?
01:08 Osoby biorące udział w teście
01:50 Reguły rywalizacji
02:07 Przebitki z dnia zdjęciowego
02:17 Przygotowanie wybranych zdjęć i głosowanie
03:30 Wyniki głosowania w kawiarni NABANK
03:58 Wyniki głosowania online
04:24 Zsumowane wyniki
05:56 Podsumowanie i podziękowania
06:32 Pożegnanie

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


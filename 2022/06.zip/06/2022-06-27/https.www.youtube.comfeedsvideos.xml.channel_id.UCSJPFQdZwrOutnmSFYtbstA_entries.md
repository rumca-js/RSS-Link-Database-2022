# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Obi-Wan Kenobi - Another One Bites The Dust
 - [https://www.youtube.com/watch?v=1jtSN4Q6MOg](https://www.youtube.com/watch?v=1jtSN4Q6MOg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-06-27 00:00:00+00:00

So we're finally at the end of Kenobi. Was it worth the wait? Did the "Rematch of the Century" live up to the hype? Are you kidding? 

Want to help support this channel? My new book, Dark Harvest, is now available to preorder: https://www.amazon.com/Dark-Harvest-Will-Jordan/dp/B09QHNR3LY


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Best Games of 2022 [FIRST HALF]
 - [https://www.youtube.com/watch?v=F-PRl-MZ1h8](https://www.youtube.com/watch?v=F-PRl-MZ1h8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-28 00:00:00+00:00

The first half of 2022 had some great games for PC, PS5, PS4, Xbox Series X/S/One, and Nintendo Switch.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


0:00 Intro 
0:22 Dying light 2 stay human 
1:42 Pokémon legends Arceus
2:27 The Quarry
3:42 TMNT Shredders revenge
4:39 Kirby and the Forgotten Land 
5:13 V Rising
6:07 Lego Star Wars the Skywalker Saga
7:26 Horizon Forbidden West
8:28 Sifu
9:37 Elden ring
10:54 Bonus

10 Dying light 2

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : February 4, 2022 



9 Pokémon legends Arceus

Platform : Switch 

Release Date : 28 January 2022 



8 The Quarry

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : 10 June 2022 



7 TMNT Shredders revenge

Platform : PC PS4 Xbox One Switch Linux 

Release Date : June 16, 2022  



6 Kirby and the Forgotten Land 

Platform : Switch 

Release Date : March 25, 2022 



5 V Rising

Platform : PC 

Release Date : May 17, 2022 



4 Lego Star Wars the Skywalker Saga

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : 5 April 2022 



3 Horizon Forbidden West

Platform : PS4 PS5 

Release Date : 18 February 2022 



2 Sifu

Platform : PC PS4 PS5 

Release Date : 8 February 2022



1 Elden ring

Platform : PC PS4 PS5 Xbox One XSX|S  

Release Date : February 25, 2022 



Bonus

Fire Emblem Warriors: Three Hopes 

Platform : SWITCH 

Release Date : June 24, 2022



Tiny Tina’s wonderlands 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : March 25, 2022 



EVIL DEAD: THE GAME

Platform : PC PS4 PS5 Xbox One XSX|S  

Release Date : May 13, 2022 



Cuphead dlc 

Platform : PC PS4 XBOX ONE SWITCH 

Release Date : June 30, 2022



God of War PC 

Platform : PC 

Release Date : 14 Jan, 2022



The Stanley Parable: Ultra Deluxe 

Platform : PC PS4 PS5 Xbox One XSX|S SWITCH 

Release Date : April 27, 2022

## 10 Big Brain Moves to CHEESE Hard Bosses
 - [https://www.youtube.com/watch?v=U50kOxZ6S-c](https://www.youtube.com/watch?v=U50kOxZ6S-c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-27 00:00:00+00:00

If a video game boss doesn't play fair, sometimes you have to fight fire with fire. Here are some dumb but brilliant cheese moves to conquer certain bosses.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Bangladesh floods: 'I have nothing left except my life'
 - [https://www.bbc.co.uk/news/world-asia-61949495?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-61949495?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 23:39:45+00:00

Khudeza survived the worst floods in north-east Bangladesh for a century but millions are homeless.

## El Salvador's abortion ban: 'I was sent to prison for suffering a miscarriage'
 - [https://www.bbc.co.uk/news/world-61798330?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-61798330?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 23:36:27+00:00

Elsy was sentenced to 30 years for aggravated homicide after losing her baby in a miscarriage in El Salvador.

## The abortion clues that can hide on your phone
 - [https://www.bbc.co.uk/news/technology-61952794?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-61952794?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 23:31:51+00:00

There are a number of concerns around data protection following the US Supreme Court's ruling on abortion.

## Hong Kong: ‘We don’t know where the red line is’
 - [https://www.bbc.co.uk/news/world-asia-china-61957394?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-61957394?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 23:03:39+00:00

China promised to protect democratic freedoms for 50 years but new laws have effectively silenced all criticism.

## Ukraine war: Russian fashion designers feel sanctions bite
 - [https://www.bbc.co.uk/news/world-europe-61956355?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61956355?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 16:39:07+00:00

Designers at Moscow Fashion Week wonder how they can stay in business without access to imported materials.

## Chris Mason: What is Boris Johnson's goal on Ukraine?
 - [https://www.bbc.co.uk/news/uk-politics-61954284?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61954284?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 12:58:14+00:00

The G7 and Nato summits are focused on Ukraine - and the PM is seeking to emphasise the UK's commitment.

## England v New Zealand: Tim Southee bowls Ollie Pope for 82 to give NZ early wicket
 - [https://www.bbc.co.uk/sport/av/cricket/61955240?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/61955240?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 12:51:56+00:00

Watch as Tim Southee bowls Ollie Pope for 82 to give New Zealand an early wicket on day five of the third Test at Headingley.

## Cavendish will not ride 2022 Tour de France
 - [https://www.bbc.co.uk/sport/cycling/61953009?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/61953009?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 12:49:50+00:00

Britain's Mark Cavendish will not ride the Tour de France, despite equalling the all-time record for stage wins last year.

## Plan to cut energy bills if you avoid peak-time use
 - [https://www.bbc.co.uk/news/business-61949246?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61949246?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 12:40:14+00:00

Some households could get discounts for using less energy at peak times under National Grid's scheme.

## Birmingham explosion: Woman found dead and man seriously hurt
 - [https://www.bbc.co.uk/news/uk-england-birmingham-61946915?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-61946915?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 12:31:41+00:00

The gas explosion completely destroyed one house and damaged others in north Birmingham.

## Nato plans huge upgrade in rapid reaction force
 - [https://www.bbc.co.uk/news/world-europe-61954516?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-61954516?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 12:25:34+00:00

Jens Stoltenberg said the increase followed a direct threat from Russia to European security.

## Barristers walk out of courts in strike over pay
 - [https://www.bbc.co.uk/news/uk-61946038?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61946038?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 12:01:38+00:00

Dominic Raab urged barristers to agree the pay rise but there are concerns junior lawyers will still leave the profession.

## Queen in Edinburgh for annual trip to Scotland
 - [https://www.bbc.co.uk/news/uk-scotland-61950569?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-61950569?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 11:55:48+00:00

She is pictured smiling during a ceremony to mark the beginning of the Royals' week in Edinburgh.

## Ukraine war: The price of freedom is worth paying, says Boris Johnson
 - [https://www.bbc.co.uk/news/uk-politics-61949714?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61949714?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 11:49:57+00:00

Boris Johnson argues letting Russia "get away with" invading Ukraine would have "chilling" consequences.

## Sir John Major calls contaminated blood scandal 'incredibly bad luck'
 - [https://www.bbc.co.uk/news/health-61929986?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-61929986?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 11:48:41+00:00

The ex-prime minister's description of the disaster drew gasps from families watching the public inquiry.

## South Africa police try to unravel mystery of tavern deaths
 - [https://www.bbc.co.uk/news/world-africa-61949878?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-61949878?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 11:09:18+00:00

Most of the 21 who died in the sudden and unexplained incident were teenagers, the police minister says.

## Prince Charles: Cash donation reports checked by watchdog
 - [https://www.bbc.co.uk/news/uk-61952106?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61952106?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 11:06:32+00:00

The Charity Commission is looking at whether it needs to act over donations to Prince Charles' charity.

## Adele Roberts: Radio 1 DJ reveals she's free from bowel cancer
 - [https://www.bbc.co.uk/news/newsbeat-61950848?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-61950848?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 10:29:22+00:00

The Radio 1 DJ wrote on Instagram to share the news, eight months after starting treatment.

## England captain Eoin Morgan set to retire from international cricket
 - [https://www.bbc.co.uk/sport/cricket/61951802?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/61951802?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 10:29:15+00:00

England's World Cup-winning captain Eoin Morgan is set to retire from international cricket this week.

## Euro 2022: Which countries are playing and where?
 - [https://www.bbc.co.uk/sport/football/61842685?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61842685?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 07:50:41+00:00

The Women's Euro 2022 Championship is taking place in England from 6-31 July. Take a look at which teams are playing at which stadiums.

## Glastonbury 2022: 11 weird and wonderful moments
 - [https://www.bbc.co.uk/news/entertainment-arts-61945263?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-61945263?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 07:31:20+00:00

Inflatable sausages, ear-splitting screams and surprise stars. All the moments you may have missed.

## Manchester United: The pre-season challenges that face new boss Erik ten Hag
 - [https://www.bbc.co.uk/sport/football/61941600?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/61941600?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 05:25:34+00:00

Pre-season looms for Manchester United and new boss Erik ten Hag will finally begin his journey as the club's fifth permanent manager since Sir Alex Ferguson retired in 2013.

## Anorexia: Woman fears she may die without specialist treatment
 - [https://www.bbc.co.uk/news/uk-wales-61910408?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61910408?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 05:16:38+00:00

Amy Ellis lives in Wales, but is trying to raise money to get the specialist treatment in England.

## Why do so many devastating earthquakes happen in Afghanistan?
 - [https://www.bbc.co.uk/news/world-61915349?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-61915349?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-27 00:04:26+00:00

At least 1,000 people have died in Afghanistan's worst earthquake in two decades


# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## This clock was famous, but the internet ruined it.
 - [https://www.youtube.com/watch?v=uAdmzyKagvE](https://www.youtube.com/watch?v=uAdmzyKagvE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-06-27 00:00:00+00:00

It feels like no-one's told the world about this yet. ■ AD: 👨‍💻 NordVPN's best deal is here: https://nordvpn.com/tomscott - with a 30-day money-back guarantee! ■ More: Royal FloraHolland's flower auction in Aalsmeer had a famous clock: a literal Dutch auction where the first person to press their button would win. But it's no more, and that's down to the internet. https://www.royalfloraholland.com/en/about-us/who-we-are/royal-floraholland/visit-the-auction  

Location camera: Dion Huiskes https://feedbuilders.nl
Editor: Michelle Martin https://twitter.com/mrsmmartin
Producer: Jasper Deelen https://fixer-netherlands.com

Footage via Open Images: https://www.openbeelden.nl/media/653209 and https://www.openbeelden.nl/media/43281/ is from Polygoon-Profilti (producer) / Netherlands Institute for Sound and Vision (curator), licensed under Creative Commons Attribution Share-Alike license 3.0 https://creativecommons.org/licenses/by-sa/3.0/deed.en (which does not extend to the larger video, see https://wiki.creativecommons.org/wiki/ShareAlike_interpretation )

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


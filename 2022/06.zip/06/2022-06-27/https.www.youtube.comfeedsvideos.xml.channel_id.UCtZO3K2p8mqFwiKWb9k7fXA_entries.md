# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## E-ink on Android. What could go wrong?
 - [https://www.youtube.com/watch?v=8uddZrJi9vQ](https://www.youtube.com/watch?v=8uddZrJi9vQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2022-06-27 16:05:16+00:00

The Huawei MatePad Paper is an E-ink tablet running HarmonyOS, which is a modified version of Android. It's both wonderful and weird. Here's a mini-review!

#shorts


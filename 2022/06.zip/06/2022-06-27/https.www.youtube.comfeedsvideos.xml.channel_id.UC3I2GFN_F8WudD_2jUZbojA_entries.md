# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Rochelle Jordan - ALL ALONG (Live on KEXP)
 - [https://www.youtube.com/watch?v=InQSHdqz0c0](https://www.youtube.com/watch?v=InQSHdqz0c0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-28 00:00:00+00:00

http://KEXP.ORG presents Rochelle Jordan performing “ALL ALONG” live in the KEXP studio. Recorded June 8, 2022.

with KLSH - Producer / DJ

Host: Larry Mizell, Jr.
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://www.rochellejordan.com
http://kexp.org

## Rochelle Jordan - ALREADY (Live on KEXP)
 - [https://www.youtube.com/watch?v=MXqYHVK9-EI](https://www.youtube.com/watch?v=MXqYHVK9-EI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-28 00:00:00+00:00

http://KEXP.ORG presents Rochelle Jordan performing “ALREADY” live in the KEXP studio. Recorded June 8, 2022.

with KLSH - Producer / DJ

Host: Larry Mizell, Jr.
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://www.rochellejordan.com
http://kexp.org

## Rochelle Jordan - DANCING ELEPHANTS (Live on KEXP)
 - [https://www.youtube.com/watch?v=SD_-lEgs6Pc](https://www.youtube.com/watch?v=SD_-lEgs6Pc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-28 00:00:00+00:00

http://KEXP.ORG presents Rochelle Jordan performing “DANCING ELEPHANTS” live in the KEXP studio. Recorded June 8, 2022.

with KLSH - Producer / DJ

Host: Larry Mizell, Jr.
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://www.rochellejordan.com
http://kexp.org

## Rochelle Jordan - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=y8GFxCkgTEo](https://www.youtube.com/watch?v=y8GFxCkgTEo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-28 00:00:00+00:00

http://KEXP.ORG presents Rochelle Jordan performing live in the KEXP studio. Recorded June 8, 2022.

Songs:
ALREADY
DANCING ELEPHANTS
LAY
ALL ALONG

with KLSH - Producer / DJ

Host: Larry Mizell, Jr.
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://www.rochellejordan.com
http://kexp.org

## Rochelle Jordan - LAY (Live on KEXP)
 - [https://www.youtube.com/watch?v=-Udbmjj0dNI](https://www.youtube.com/watch?v=-Udbmjj0dNI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-28 00:00:00+00:00

http://KEXP.ORG presents Rochelle Jordan performing “LAY” live in the KEXP studio. Recorded June 8, 2022.

with KLSH - Producer / DJ

Host: Larry Mizell, Jr.
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://www.rochellejordan.com
http://kexp.org

## Calexico - Caldera (Live on KEXP)
 - [https://www.youtube.com/watch?v=h3ipoeh6BD0](https://www.youtube.com/watch?v=h3ipoeh6BD0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-27 00:00:00+00:00

http://KEXP.ORG presents Calexico performing “Caldera” live in the KEXP studio. Recorded June 5, 2022.

Joey Burns - Guitar / Vocals
John Convertino - Drums
Brian Lopez - Guitar / Vocals
Sergio Mendoza - Keys / Vibraphone / Vocals
Jacob Valenzuela - Trumpet / Vocals
Rick Peron - Trumpet / Vibraphone
Scott Colberg - Bass / Vocals

Host: Miss Ashley
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

https://www.casadecalexico.com
http://kexp.org

## Calexico - Cumbia Del Polvo (Live on KEXP)
 - [https://www.youtube.com/watch?v=kPLx2qpkm0Y](https://www.youtube.com/watch?v=kPLx2qpkm0Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-27 00:00:00+00:00

http://KEXP.ORG presents Calexico performing “Cumbia Del Polvo” live in the KEXP studio. Recorded June 5, 2022.

Joey Burns - Guitar / Vocals
John Convertino - Drums
Brian Lopez - Guitar / Vocals
Sergio Mendoza - Keys / Vibraphone / Vocals
Jacob Valenzuela - Trumpet / Vocals
Rick Peron - Trumpet / Vibraphone
Scott Colberg - Bass / Vocals

Host: Miss Ashley
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

https://www.casadecalexico.com
http://kexp.org

## Calexico - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=cpstW749DJA](https://www.youtube.com/watch?v=cpstW749DJA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-27 00:00:00+00:00

http://KEXP.ORG presents Calexico performing live in the KEXP studio. Recorded June 5, 2022.

Songs:
Caldera
Then You Might See
Rancho Azul
Cumbia Del Polvo

Joey Burns - Guitar / Vocals
John Convertino - Drums
Brian Lopez - Guitar / Vocals
Sergio Mendoza - Keys / Vibraphone / Vocals
Jacob Valenzuela - Trumpet / Vocals
Rick Peron - Trumpet / Vibraphone
Scott Colberg - Bass / Vocals

Host: Miss Ashley
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

https://www.casadecalexico.com
http://kexp.org

## Calexico - Rancho Azul (Live on KEXP)
 - [https://www.youtube.com/watch?v=NPs8b6MGUHs](https://www.youtube.com/watch?v=NPs8b6MGUHs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-27 00:00:00+00:00

http://KEXP.ORG presents Calexico performing “Rancho Azul” live in the KEXP studio. Recorded June 5, 2022.

Joey Burns - Guitar / Vocals
John Convertino - Drums
Brian Lopez - Guitar / Vocals
Sergio Mendoza - Keys / Vibraphone / Vocals
Jacob Valenzuela - Trumpet / Vocals
Rick Peron - Trumpet / Vibraphone
Scott Colberg - Bass / Vocals

Host: Miss Ashley
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

https://www.casadecalexico.com
http://kexp.org

## Calexico - Then You Might See (Live on KEXP)
 - [https://www.youtube.com/watch?v=Figwv29sl40](https://www.youtube.com/watch?v=Figwv29sl40)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-27 00:00:00+00:00

http://KEXP.ORG presents Calexico performing “Then You Might See” live in the KEXP studio. Recorded June 5, 2022.

Joey Burns - Guitar / Vocals
John Convertino - Drums
Brian Lopez - Guitar / Vocals
Sergio Mendoza - Keys / Vibraphone / Vocals
Jacob Valenzuela - Trumpet / Vocals
Rick Peron - Trumpet / Vibraphone
Scott Colberg - Bass / Vocals

Host: Miss Ashley
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

https://www.casadecalexico.com
http://kexp.org


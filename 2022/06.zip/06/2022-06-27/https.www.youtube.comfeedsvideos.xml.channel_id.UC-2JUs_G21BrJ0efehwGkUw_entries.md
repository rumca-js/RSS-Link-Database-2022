# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Back to Black | @amywinehousevideo | funk cover ft. Madelyn Grant
 - [https://www.youtube.com/watch?v=Tvx3T66ZoIU](https://www.youtube.com/watch?v=Tvx3T66ZoIU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-06-27 00:00:00+00:00

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Amy Winehouse's "Back to Black" by Scary Pockets & Madelyn Grant.

MUSICIAN CREDITS
Lead vocal: Madelyn Grant
Drums: Rob Humphreys
Bass: Travis Carlton
Piano: Jake Sherman
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Ricky Chavez 
Editor: Adam Kritzberg

Recorded Live at Big Bad Sound in Los Angeles, CA.

#ScaryPockets #Funk #amywinehouse #madelyngrant #backtoblack


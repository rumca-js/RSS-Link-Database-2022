# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## What parents need to know to keep their kids safe online
 - [https://www.bbc.co.uk/news/business-61577187?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61577187?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-06-27 23:18:06+00:00

Teachers urgently want parents to understand the tech which could help to keep kids safer online.


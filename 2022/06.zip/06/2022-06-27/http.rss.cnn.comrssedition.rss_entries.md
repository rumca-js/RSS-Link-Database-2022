# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## US adds two countries to 'high' Covid-19 risk list
 - [https://www.cnn.com/travel/article/cdc-covid-travel-risk-destinations-june-27/index.html](https://www.cnn.com/travel/article/cdc-covid-travel-risk-destinations-june-27/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 23:19:23+00:00

The US Centers for Disease Control and Prevention has added two destinations to its "high" category for Covid-19 risk -- including a Caribbean nation popular for its beaches.

## Multiple people killed when Amtrak passenger train derails in Missouri after hitting dump truck
 - [https://www.cnn.com/2022/06/27/us/missouri-amtrak-train-derailment/index.html](https://www.cnn.com/2022/06/27/us/missouri-amtrak-train-derailment/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 22:12:24+00:00

Several people were hurt when an Amtrak train derailed in Missouri, according to the passenger rail company.

## Russian airstrike hits busy shopping mall in central Ukraine, sparking fears of mass casualties
 - [https://www.cnn.com/2022/06/27/europe/kremenchuk-shopping-mall-airstrike-ukraine-intl/index.html](https://www.cnn.com/2022/06/27/europe/kremenchuk-shopping-mall-airstrike-ukraine-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 22:07:00+00:00

A Russian airstrike struck a bustling shopping mall in Kremenchuk, central Ukraine on Monday, setting the building ablaze and prompting concerns of mass casualties.

## Kamala Harris reveals moment she found out about Supreme Court decision
 - [https://www.cnn.com/videos/politics/2022/06/27/kamala-harris-bash-intv-abortion-roe-wade-vpx.cnn](https://www.cnn.com/videos/politics/2022/06/27/kamala-harris-bash-intv-abortion-roe-wade-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 21:41:31+00:00

CNN's Dana Bash sits down with Vice President Kamala Harris about the Supreme Court's decision to overturn Roe v. Wade.

## Hear why John Oliver says Democratic leaders 'failed to meet the moment' after Supreme Court verdict
 - [https://www.cnn.com/videos/business/2022/06/27/john-oliver-criticize-democrats-reaction-roe-v-wade-orig-ht.cnn-business](https://www.cnn.com/videos/business/2022/06/27/john-oliver-criticize-democrats-reaction-roe-v-wade-orig-ht.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 21:06:16+00:00

"Last Week Tonight" host John Oliver criticized Democrat leaders' responses to Roe v. Wade being overturned, claiming that they "failed to meet the moment."

## 'They actually did it': Harris was shocked over Roe v. Wade decision
 - [https://www.cnn.com/collections/intl-abortion-ruling-0627/](https://www.cnn.com/collections/intl-abortion-ruling-0627/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 20:35:56+00:00



## Hear witness recount scene after Amtrak train derailed
 - [https://www.cnn.com/videos/us/2022/06/27/amtrak-train-derailed-crash-vpx.cnn](https://www.cnn.com/videos/us/2022/06/27/amtrak-train-derailed-crash-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 20:24:52+00:00

Robert Nightingale, a passenger on the Amtrak train that collided with a dump truck, describes the scene after the train derailed.

## A lawmaker spoke about 'White life' at a Trump rally. Things got worse from there
 - [https://www.cnn.com/2022/06/27/opinions/trump-rally-roe-white-life-miller-obeidallah/index.html](https://www.cnn.com/2022/06/27/opinions/trump-rally-roe-white-life-miller-obeidallah/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 19:32:40+00:00

At Donald Trump's "Save America" rally this weekend, Republican US Rep. Mary Miller of Illinois hailed the Supreme Court's decision to overturn Roe v. Wade as a "historic victory for White life."

## Novak Djokovic gets Wimbledon title defense off the ground with battling win
 - [https://www.cnn.com/collections/intl-wimbledon-0627/](https://www.cnn.com/collections/intl-wimbledon-0627/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 19:06:38+00:00



## 'Full House' star thrown to ground by police during abortion rights protest
 - [https://www.cnn.com/videos/us/2022/06/27/jodie-sweetin-full-house-actress-abortion-protests-la-orig-mg.cnn](https://www.cnn.com/videos/us/2022/06/27/jodie-sweetin-full-house-actress-abortion-protests-la-orig-mg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 19:02:44+00:00

Los Angeles police clashed with protesters during an abortion rights demonstration where actress Jodie Sweetin appeared to be pushed to the ground.

## Meal kit service under fire after influencers develop mysterious symptoms
 - [https://www.cnn.com/2022/06/27/tech/daily-harvest-recall-influencers/index.html](https://www.cnn.com/2022/06/27/tech/daily-harvest-recall-influencers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 18:57:53+00:00

Instagram-friendly meal kit service Daily Harvest is facing a firestorm of online backlash over the voluntary recall of one of its products, after a slew of people who consumed it reported becoming ill with mysterious symptoms, including extremely elevated liver enzymes.

## 'I would not at all bet on Russia': EU Commission President talks Ukraine war
 - [https://www.cnn.com/videos/tv/2022/06/27/ursula-von-der-leyen-amanpour-eu-us-ukraine-russia-war.cnn](https://www.cnn.com/videos/tv/2022/06/27/ursula-von-der-leyen-amanpour-eu-us-ukraine-russia-war.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 18:06:34+00:00

President of the European Commission Ursula von der Leyen talks to Christiane Amanpour on the sidelines of the G7 summit about how the EU will support Ukraine in its fight against Russia.

## Irish abortion rights activist: American women face future similar to Ireland's past where 'women did die and did suffer'
 - [https://www.cnn.com/videos/tv/2022/06/27/amanpour-abortion-america-roe-v-wade-supreme-court-ailbhe-smyth-ireland.cnn](https://www.cnn.com/videos/tv/2022/06/27/amanpour-abortion-america-roe-v-wade-supreme-court-ailbhe-smyth-ireland.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 18:02:57+00:00

Ailbhe Smyth played a central role in Ireland's campaign to legalize abortion in 2018 and reflecting on Ireland's past, says American women now face everyday anguish and worry in their lives

## Brittney Griner to attend preliminary court hearing behind closed doors, lawyer says
 - [https://www.cnn.com/2022/06/27/sport/brittney-griner-court-hearing-spt-intl/index.html](https://www.cnn.com/2022/06/27/sport/brittney-griner-court-hearing-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 17:40:50+00:00

WNBA star Brittney Griner will attend a preliminary court hearing in the Moscow region Monday, her lawyer Alexander Boykov told CNN.

## Lil Nas X talks 'painful and strained' relationship with BET
 - [https://www.cnn.com/2022/06/27/entertainment/lil-nas-x-talks-painful-and-strained-relationship-with-bet/index.html](https://www.cnn.com/2022/06/27/entertainment/lil-nas-x-talks-painful-and-strained-relationship-with-bet/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 17:37:18+00:00

Lil Nas X is calling out the BET Awards for a lack of inclusivity.

## As America outlaws abortion, this country in the Middle East is making access easier
 - [https://www.cnn.com/videos/world/2022/06/27/israel-abortion-regulations-ctw-intl-gold-lwe-vpx.cnn](https://www.cnn.com/videos/world/2022/06/27/israel-abortion-regulations-ctw-intl-gold-lwe-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 17:17:50+00:00

Women seeking an abortion in Israel will no longer be required to be physically present when requesting an abortion before hospital abortion committees. The application form will also be revised to remove "degrading questions." CNN's Hadas Gold has more.

## Michigan mother charged with murdering toddler son whose body was in freezer
 - [https://www.cnn.com/2022/06/27/us/detroit-mother-charged-childs-body-found-in-freezer/index.html](https://www.cnn.com/2022/06/27/us/detroit-mother-charged-childs-body-found-in-freezer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 17:05:00+00:00

A mother in Detroit has been charged with murder after the body of her 3-year-old son was found in a freezer Friday, according to the Wayne County Prosecutor's Office.

## How war in Ukraine is affecting one of the most vulnerable African countries
 - [https://www.cnn.com/videos/world/2022/06/27/somalia-africa-drought-climate-famine-malnourished-children-ukraine-pkg-ctw-vpx.cnn](https://www.cnn.com/videos/world/2022/06/27/somalia-africa-drought-climate-famine-malnourished-children-ukraine-pkg-ctw-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 16:58:02+00:00

Somalia is facing compounding concerns of a record-breaking drought and a lack of access to food due to the war in Ukraine, putting the country at risk of famine and an increase in malnourished children. CNN's Michael Holmes reports.

## 'Top Gun: Maverick' becomes the first $1 billion Tom Cruise film
 - [https://www.cnn.com/2022/06/27/media/top-gun-maverick-billion-box-office/index.html](https://www.cnn.com/2022/06/27/media/top-gun-maverick-billion-box-office/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 16:47:08+00:00

"Top Gun: Maverick" has flown to new heights.

## CNN reporter on return of 'Q': 'As dumb as it is dangerous'
 - [https://www.cnn.com/videos/business/2022/06/27/qanon-q-online-posts-osullivan-avlon-new-day-vpx.cnnbusiness](https://www.cnn.com/videos/business/2022/06/27/qanon-q-online-posts-osullivan-avlon-new-day-vpx.cnnbusiness)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 16:40:40+00:00

CNN's Donie O'Sullivan and John Avlon report that the "Q" persona at the center of the QAnon conspiracy theory movement, has posted online for the first time since December 2020, after Trump lost the election.

## US Supreme Court rules school district cannot prohibit high school football coach's prayers on field
 - [https://www.cnn.com/2022/06/27/politics/football-coach-prayer-high-school-supreme-court-kennedy/index.html](https://www.cnn.com/2022/06/27/politics/football-coach-prayer-high-school-supreme-court-kennedy/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 16:30:00+00:00

The Supreme Court said Monday that a Washington state school district violated the First Amendment rights of a high school football coach when he lost his job for praying at the 50-yard line after games.

## New double crater seen on the moon after mystery rocket impact
 - [https://www.cnn.com/2022/06/27/world/rocket-moon-impact-crater-scn/index.html](https://www.cnn.com/2022/06/27/world/rocket-moon-impact-crater-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 16:16:58+00:00

The moon has a new double crater after a rocket body collided with its surface on March 4.

## West pushes Russia into its first foreign debt default since 1918
 - [https://www.cnn.com/2022/06/27/economy/russia-debt-default-sanctions/index.html](https://www.cnn.com/2022/06/27/economy/russia-debt-default-sanctions/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 15:58:24+00:00

Russia has defaulted on its foreign debt for the first time since the Bolshevik revolution more than a century ago.

## Tennis star takes break from sport to focus on helping Ukraine
 - [https://www.cnn.com/2022/06/27/tennis/elina-svitolina-ukraine-united-24-spt-intl/index.html](https://www.cnn.com/2022/06/27/tennis/elina-svitolina-ukraine-united-24-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 15:58:18+00:00

Ukrainian tennis player Elina Svitolina says she has a "mission" to help her country and wants to use her platform to provide hope to the war-torn nation.

## Glastonbury makes a visually arresting return
 - [https://www.cnn.com/style/article/glastonbury-2022-highlights-photos/index.html](https://www.cnn.com/style/article/glastonbury-2022-highlights-photos/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 15:54:32+00:00

Glastonbury, the world-famous art and music festival set within 900 acres of the British countryside, made a sensational return this weekend after a two-year pandemic-induced hiatus. Boasting the title of the largest green-field festival in the world, it has long been an important pillar of the UK's art and culture scene. This year, Glastonbury celebrate its belated 50th anniversary (it turned 50 in 2020 while the live music industry was suffering  travel restrictions, lockdowns and social distancing mandates) with performances by former Beatle Paul McCartney and disco luminary Diana Ross.

## Georgia man who was sentenced to death in murder of 2 prison guards found dead in apparent suicide, officials say
 - [https://www.cnn.com/2022/06/27/us/georgia-prisoner-suicide/index.html](https://www.cnn.com/2022/06/27/us/georgia-prisoner-suicide/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 15:28:25+00:00

A Georgia man who was recently sentenced to death in the killing of two prison guards in 2017 died Sunday in an apparent suicide, according to a news release from the Georgia Department of Corrections.

## This Republican senator keeps changing his story on the fake electors scheme
 - [https://www.cnn.com/2022/06/27/politics/ron-johnson-fake-electors-wisconsin/index.html](https://www.cnn.com/2022/06/27/politics/ron-johnson-fake-electors-wisconsin/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 14:50:57+00:00

Ron Johnson can't seem to get his story straight.

## Crypto is crashing but the tech behind it could save luxury brands billions
 - [https://www.cnn.com/2022/06/26/business/aura-blockchain-luxury-counterfeit-hnk-spc-intl/index.html](https://www.cnn.com/2022/06/26/business/aura-blockchain-luxury-counterfeit-hnk-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 14:16:02+00:00

Counterfeits are a huge problem for high-end designers around the globe: luxury brands lost $98 billion worth of sales to counterfeits in 2017 alone.

## 'F**k the Supreme Court!' Musicians get mad at Roe v. Wade decision
 - [https://www.cnn.com/videos/entertainment/2022/06/27/olivia-rodrigo-roe-v-wade-glastonbury-orig-mss.cnn](https://www.cnn.com/videos/entertainment/2022/06/27/olivia-rodrigo-roe-v-wade-glastonbury-orig-mss.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 13:50:50+00:00

American stars Olivia Rodrigo, Megan Thee Stallion and Phoebe Bridgers shared their frustrations with the crowd on the Supreme Court overturning Roe v. Wade.

## Kanye West's surprise BET Awards appearance was to honor Sean 'Diddy' Combs
 - [https://www.cnn.com/2022/06/27/entertainment/kanye-west-bet-awards/index.html](https://www.cnn.com/2022/06/27/entertainment/kanye-west-bet-awards/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 13:39:36+00:00

His face couldn't be seen, but Kanye West showed up at the 2022 BET Awards to honor Sean "Diddy" Combs.

## Prince Charles accepted suitcase with 1 million euros from Qatari sheikh, Sunday Times reports
 - [https://www.cnn.com/2022/06/26/uk/prince-charles-qatari-sheikh-gbr-intl/index.html](https://www.cnn.com/2022/06/26/uk/prince-charles-qatari-sheikh-gbr-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 13:00:41+00:00

Clarence House said Prince Charles received charitable donations and the correct processes were followed regarding those donations after a British newspaper reported the Prince of Wales once accepted a suitcase containing €1 million ($1.05 million) in cash from a Qatari politician.

## GOP lawmaker, asked if he's OK with child rape victim carrying out pregnancy: 'You don't know you were raped for 2 months?'
 - [https://www.cnn.com/videos/politics/2022/06/27/warren-davidson-child-rape-victim-pregnancy-abortion-supreme-court-brown-nr-sot-vpx.cnn](https://www.cnn.com/videos/politics/2022/06/27/warren-davidson-child-rape-victim-pregnancy-abortion-supreme-court-brown-nr-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 12:12:22+00:00

Rep. Warren Davidson (R-OH) speaks with CNN's Pamela Brown to discuss the Supreme Court ruling that limits abortion access as well as Ohio's heartbeat bill, which survived an injunction. The bill bans abortions after six weeks and has no exceptions for rape or incest.

## Tide turns in Russia's favor as Moscow's troops make progress in eastern Ukraine
 - [https://www.cnn.com/2022/06/27/europe/russia-ukraine-war-tide-turning-lister-intl-hnk/index.html](https://www.cnn.com/2022/06/27/europe/russia-ukraine-war-tide-turning-lister-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 11:25:00+00:00

Russian forces are arguably having their best spell since the invasion of Ukraine began four months ago.

## Billie Joe Armstrong says he'll renounce his US citizenship over Roe v. Wade reversal
 - [https://www.cnn.com/2022/06/27/entertainment/billie-joe-armstrong-roe-v-wade-intl-scli/index.html](https://www.cnn.com/2022/06/27/entertainment/billie-joe-armstrong-roe-v-wade-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 11:06:11+00:00

Green Day frontman Billie Joe Armstrong has told fans at a concert that he intends to renounce his United States citizenship following the US Supreme Court's decision to overturn Roe v. Wade -- a controversial move that eliminates the federal constitutional right to abortion nationwide.

## Think you could land a plane in an emergency? Here's what the experts say
 - [https://www.cnn.com/travel/article/could-you-land-plane-emergency/index.html](https://www.cnn.com/travel/article/could-you-land-plane-emergency/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 10:54:45+00:00

It's a nightmare scenario: the pilot of your flight is incapacitated and someone has to get in their seat and land the plane. Could you do it?

## Some Ukrainians who fled to the UK now face homelessness
 - [https://www.cnn.com/2022/06/27/europe/ukrainian-refugees-uk-homeless-intl-cmd/index.html](https://www.cnn.com/2022/06/27/europe/ukrainian-refugees-uk-homeless-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 10:25:58+00:00

It starts with a raised eyebrow and ends with a door slammed shut. A detail lost in translation, a wrong way to load a dishwasher, an awkward silence followed by a polite request to pack your bags.

## Why Wimbledon's Russian and Belarusian player ban is the wrong call
 - [https://www.cnn.com/2022/06/27/opinions/wimbledon-russian-belarusian-player-ban-wrong-spt-mcenroe/index.html](https://www.cnn.com/2022/06/27/opinions/wimbledon-russian-belarusian-player-ban-wrong-spt-mcenroe/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 10:25:17+00:00

When I first heard back in February that the All England Lawn Tennis Club (AELTC) was considering banning Russian and Belarusian players from Wimbledon following Russia's invasion of Ukraine, I was surprised. After all, most other major leagues have allowed individual Russian athletes to continue to work in their respective sports -- whether it's the NHL in the US and Canada, European football leagues or the World Tennis Tour.

## US to announce purchase of missile defense system for Ukraine
 - [https://www.cnn.com/2022/06/26/politics/us-missile-defense-system-ukraine-coming-announcement/index.html](https://www.cnn.com/2022/06/26/politics/us-missile-defense-system-ukraine-coming-announcement/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 10:23:26+00:00

The US plans to announce as soon as this week that it has purchased an advanced, medium-to-long range surface-to-air missile defense system for Ukraine, a source familiar with the announcement tells CNN.

## Ray-Ban's billionaire owner Leonardo Del Vecchio dies
 - [https://www.cnn.com/2022/06/27/business/luxottica-leonardo-del-vecchio/index.html](https://www.cnn.com/2022/06/27/business/luxottica-leonardo-del-vecchio/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 10:17:46+00:00

Leonardo Del Vecchio, the chairman of spectacles maker EssilorLuxottica and one of Italy's wealthiest business figures, has died aged 87, his company said on Monday.

## Kendrick Lamar closes Glastonbury with blood-soaked plea for women's rights
 - [https://www.cnn.com/2022/06/27/entertainment/kendrick-lamar-glastonbury-plea-womens-rights-intl-scli-gbr/index.html](https://www.cnn.com/2022/06/27/entertainment/kendrick-lamar-glastonbury-plea-womens-rights-intl-scli-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 10:10:01+00:00

Hip-hop star Kendrick Lamar closed his headline Glastonbury set with an impassioned plea for women's rights.

## In 'zero-Covid' China, a daughter's struggle to get her father medicine hits a nerve
 - [https://www.cnn.com/2022/06/27/china/covid-lockdown-police-altercation-video-debate-intl-hnk-mic/index.html](https://www.cnn.com/2022/06/27/china/covid-lockdown-police-altercation-video-debate-intl-hnk-mic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 09:44:28+00:00

What was meant to be a simple errand, a daughter driving her aging father to the hospital to pick up his medicine, has pulled a small city on China's border with North Korea -- and its nearly two-month Covid-19 lockdown -- into the national spotlight, after the pair ran afoul of pandemic rules.

## At least 4 dead, hundreds injured after collapse at Colombia stadium during bullfight
 - [https://www.cnn.com/2022/06/26/americas/colombia-stadium-collapse/index.html](https://www.cnn.com/2022/06/26/americas/colombia-stadium-collapse/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 08:41:47+00:00

At least four people were killed and about 30 seriously injured after part of a stadium in El Espinal in Colombia's western state of Tolima collapsed during a bullfight Sunday, the state's governor said.

## Camouflaged figures lurking in the bush expose Australia's angst over climate activists
 - [https://www.cnn.com/2022/06/27/australia/australia-climate-protests-arrests-intl-hnk-dst/index.html](https://www.cnn.com/2022/06/27/australia/australia-climate-protests-arrests-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 08:02:18+00:00

Climate activists were sharing toast and coffee at a private campsite in mountains outside Sydney last Sunday when someone noticed movement on a nearby slope.

## Major transgender beauty contest crowns this year's queen
 - [https://www.cnn.com/style/article/miss-international-queen-2022-winner-philippines/index.html](https://www.cnn.com/style/article/miss-international-queen-2022-winner-philippines/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 06:30:10+00:00

Filipina beauty queen Fuschia Anne Ravena has been named winner of Miss International Queen 2022, a contest described by organizers as the world's largest beauty pageant for transgender women.

## NASA launches first rocket from Australian space center
 - [https://www.cnn.com/2022/06/27/australia/nasa-launch-first-space-rocket-alpha-centauri-australia-intl-hnk/index.html](https://www.cnn.com/2022/06/27/australia/nasa-launch-first-space-rocket-alpha-centauri-australia-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-27 04:56:53+00:00

NASA has successfully launched a rocket from Australia's remote Northern Territory, making history as the agency's first commercial spaceport launch outside the United States.


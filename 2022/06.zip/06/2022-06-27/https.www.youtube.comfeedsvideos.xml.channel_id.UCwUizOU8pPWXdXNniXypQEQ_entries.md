# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## When Your Doctor is a LEFTIST!
 - [https://www.youtube.com/watch?v=u1U5Bxe9D2g](https://www.youtube.com/watch?v=u1U5Bxe9D2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-06-28 00:00:00+00:00

Grab your Red/Blue Light Teeth Whitening Kit at https://naturalteethwhiteners.com/jp

Check out Tyler Fisher's YouTube Channel - @tythefisch 
All Tyler's Socials - @TyTheFisch

Brent's Channel - @brentpella 

Check Out My Merch Here - https://awakenwithjp.com

Upcoming LIVE Shows - https://awakenwithjp.com/tour

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Here's what it's like when your doctor is a leftist!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
https://rumble.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## I SOLVE ALL ISSUES (and PRs) IN ONE WEEK! (git on my level)
 - [https://www.youtube.com/watch?v=6YrKG4OGsE8](https://www.youtube.com/watch?v=6YrKG4OGsE8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2022-06-27 00:00:00+00:00

00:00 Solving ALL Issues and PRs
03:33 LARBS and my dotfiles (https://larbs.xyz and https://github.com/lukesmithxyz/voidrice)
08:05 LandChad.net and Based.Cooking
12:26 Suckless Software: dwm, st, dmenu, dwmblocks
15:17 mutt-wizard (https://github.com/lukesmithxyz/mutt-wizard)
18:03 emailwiz (https://github.com/lukesmithxyz/emailwiz)
20:00 shadowchat and go-webring (other people's go software)
20:27 Command-line Bibles: kjv, vul, grb
24:15 vimling
24:25 lib, R.I.P.
26:16 Closing

My Github with all projects: https://github.com/lukesmithxyz

My website: https://lukesmith.xyz
Classical books reprinted by me: https://lindypress.net
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz
BTC: bc1qw5w6pxsk3aj324tmqrhhpmpfprxcfxe6qhetuv
XMR: 48jewbtxe4jU3MnzJFjTs3gVFWh2nRrAMWdUuUd7Ubo375LL4SjLTnMRKBrXburvEh38QSNLrJy3EateykVCypnm6gcT9bh

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.


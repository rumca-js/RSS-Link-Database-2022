## The FBI Tried to Ambush My Source. Now I’m Telling the Whole Story.
 - [https://theintercept.com/2022/06/03/fbi-ambush-leak-reporter-source/](https://theintercept.com/2022/06/03/fbi-ambush-leak-reporter-source/)
 - RSS feed: https://theintercept.com
 - date published: 2022-06-04 21:04:31.669281+00:00

I’ve been reluctant to write what I know about the FBI’s scheme because the tale is so complicated that I’m still not sure I fully understand it.


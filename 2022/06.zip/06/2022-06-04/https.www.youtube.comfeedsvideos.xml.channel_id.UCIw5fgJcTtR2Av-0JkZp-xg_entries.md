# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## Making More Videos, More Often
 - [https://www.youtube.com/watch?v=J5IZSHUe8fY](https://www.youtube.com/watch?v=J5IZSHUe8fY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2022-06-04 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Support the music here: https://www.patreon.com/yuriwong

Transcript below:

So I’m starting a Patreon and here’s why.

I love making music, and I especially love making music that connects to you.
For the past decade, my music work has mostly been client-based: film scores, music for tv shows, ads, theme songs - client stuff. 

Although that’s fun too, what I found to be most fulfilling is creating music I personally connect with and to bring it to an audience directly - to you, and what I enjoy most is creating stuff that you connect with and me sharing that experience with you.

So the logic is, why don’t I make music I enjoy most for the people that enjoy it the most? Thats why I’m starting a Patreon - just for that. To consistently bring you more music and content that’s fun, groovy, positive - everything that brings us a good time.

I’m really thankful that you’re here to give me the privilege of your time and your attention, and I hope to bring you some great tunes and fun moments to share. 

I’d love for you to be a part of this - the Patreon will have have Q&As, voting on which movie lines to remix, exclusive downloads, livestreams and more. If you enjoy my stuff, I’m sure you’ll enjoy being a part of my community. I’ll be active there and I'd love to interact with you.

I’ll still be making music and remixes here on youtube, and some special content will be specific for patrons only. 

Click on the link and see if you dig anything, I hope you do.

But whether you do or not, I still appreciate you very much, the fact that you’re watching this, and that you enjoy being here and dig the music and videos, that means a lot to me

So take care, have a great day, and see you on Patreon :)


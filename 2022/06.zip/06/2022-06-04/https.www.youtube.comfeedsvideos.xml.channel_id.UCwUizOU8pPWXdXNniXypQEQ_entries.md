# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## We Want To Take Away Your Constitutional Rights! - News Update
 - [https://www.youtube.com/watch?v=lCOTZIF6G0U](https://www.youtube.com/watch?v=lCOTZIF6G0U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-06-04 00:00:00+00:00

Grab your Blue Light Blocking Glasses at https://blublox.com/jp
Use Code "JP" for 15% Off!

Check Out My Merch Here - https://awakenwithjp.com

See my LIVE Comedy Shows - https://awakenwithjp.com/pages/events

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

This week's news covers everything from Joe Biden's views on gay marriage to Tyrannical Trudeau! Here's everything you need to know...

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


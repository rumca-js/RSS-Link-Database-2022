# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 MOST WTF Moments We Saw in Video Games
 - [https://www.youtube.com/watch?v=N_gM6rr-6MY](https://www.youtube.com/watch?v=N_gM6rr-6MY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-05 00:00:00+00:00

Some games truly surprise us with WTF moments that come out of nowhere.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## Diablo Immortal - Before You Buy
 - [https://www.youtube.com/watch?v=Cs2QZtAEpOU](https://www.youtube.com/watch?v=Cs2QZtAEpOU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-04 00:00:00+00:00

Diablo Immortal (PC, iOS, Android) is the free-to-play mobile version of Diablo with all of the expected trappings. How is it? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼



Watch more 'Before You Buy': https://bit.ly/2kfdxI6


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## They Just Admitted This…
 - [https://www.youtube.com/watch?v=kXO0t-NvQA4](https://www.youtube.com/watch?v=kXO0t-NvQA4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-05 00:00:00+00:00

The Head of the World Economic Forum Klaus Schwab & The CEO of Pfizer Albert Bourla were at Davos 2022 this week, discussing numerous topics around vaccines & the pandemic. Is this something to be worried about? #pfizer #pandemic #davos2022 

References
https://www.theguardian.com/business/2022/may/03/pfizer-covid-sales-pricing-vaccine-paxlovid-pill
https://www.theguardian.com/commentisfree/2022/feb/08/big-pharma-global-vaccine-rollout-covid-pfizer
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## It Begins
 - [https://www.youtube.com/watch?v=OwF7MMj_wtE](https://www.youtube.com/watch?v=OwF7MMj_wtE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-04 00:00:00+00:00

Justin Trudeau wants “new tools” to tackle online “misinformation”. This, as Canada introduces national digital ID. So, is Trudeau right that the world is getting more dangerous, or is the real danger increased censorship and the capturing of your digital freedom? #trudeau #DigitalID #misinformation 

References
https://reclaimthenet.org/trudeau-wants-new-tools-to-tackle-online-misinformation/
https://reclaimthenet.org/canada-is-on-the-brink-of-a-digital-id-future/
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Dream has Too Much Money - Dream Server Build
 - [https://www.youtube.com/watch?v=Ti8scviDiYc](https://www.youtube.com/watch?v=Ti8scviDiYc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-05 00:00:00+00:00

Thanks to Kioxia for sponsoring this server build! Learn more about the Kioxia CM6 Enterprise SSD at https://lmg.gg/Kioxia_CM6

Discuss on the forum: https://linustechtips.com/topic/1435403-dream-has-too-much-money-sponsored/

Check out 45drives Storinator XL60: https://lmg.gg/iB5P7

Check out Ubiquiti's Enterprise 24 XG Network Switch: https://lmg.gg/CIDRn

Buy Seagate's 20tb HDD: https://geni.us/RBQupw

Check out AMD EPYC 75F3: https://lmg.gg/tt0Tt

Check out AMD EPYC 7402P: https://lmg.gg/CobrK

Check out Micron ECC DDR4 Memory: https://lmg.gg/dTlhL

Buy a Gigabyte R272-Z32 Server Rack: https://lmg.gg/i8E80

Buy an Intel 10GbE X540-T2 NIC: https://lmg.gg/ttRQo

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 - Intro and Face Reveal
0:59 - 1.2 Petabyte unbox and install 100% speedrun
3:20 - Replacing the NIC
3:52 - Short ppl problems
4:25 - The Kioxia CM6 Enterprise SSD
5:38 - Pain
6:57 - Building the SSD Server
9:40 - What's inside an Enterprise SSD?
12:06 - The Ubiquiti UniFi Switch
13:49 - Config time
14:50 - Who won the bet?
15:45 - Back to config
18:12 - The boys debate
19:07 - Wendell saves the day
20:32 - Testing
23:10 - Thanks Kioxia and friends! and Conclusion

## Smartifying My 25+ Year Old Garage - Z-Wave Garage Door Opener
 - [https://www.youtube.com/watch?v=ooEfsWZo4-g](https://www.youtube.com/watch?v=ooEfsWZo4-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-04 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Get 15% off your order and get dad something nice at https://www.ridge.com/LINUS

My garage may be dumb, but I can fix that! Or... Jake can fix that, WITHOUT bowing down to the dreaded Chamberlain Garage Door Overlords.


Discuss on the forum: https://linustechtips.com/topic/1435217-smartifying-my-horrible-garage/

Check out FortrezZ MIMO2+ Z-Wave Relay Sesnor Board: https://lmg.gg/eQAw6

Buy a Aeotec Z-Stick 7: https://lmg.gg/QJxla

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:44 Main Functionality
3:04 The Obvious Answer
4:44 Installing Magnets
6:05 Running Ethernet
8:55 Testing It
11:15 Wiring
14:40 Conclusion
16:32 Outro


## #12 (Trochę) polowaliśmy na (prawie) rekiny z @anitawu
 - [https://www.youtube.com/watch?v=WMHlz-GU5Xo](https://www.youtube.com/watch?v=WMHlz-GU5Xo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIFlYVfPnvukmFOvC4JUfOg
 - date published: 2022-06-04 00:00:00+00:00

​@vlogcasha  już nie ma ale jest plaża, są rekiny(prawie), śmigamy na motocyklach, weekend idealny!
🧗🏻Wesprzyj moje przygody na patronite: https://patronite.pl/Nejtan
📷 Instagram: https://www.instagram.com/nejthan
📜 Napisz do mnie: swiatwedlugnejtana@gmail.com
🎵 Muzyka: https://share.epidemicsound.com/m7uq26

2022 Trip z  @vlogcasha    po Florydzie https://bit.ly/3uueZGV
2021 Trip z  @vlogcasha    po zachodzie Usa i Alaska
https://bit.ly/3D6ClpI
#swiatwedlugnejtana #nejtan


# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Original Gerber Baby Ann Turner Cook, the familiar face on thousands of baby products, dies at 95
 - [https://www.cnn.com/2022/06/04/us/ann-turner-cook-original-gerber-baby-dies/index.html](https://www.cnn.com/2022/06/04/us/ann-turner-cook-original-gerber-baby-dies/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 22:57:16+00:00

Ann Turner Cook, the original Gerber Baby whose familiar face has been printed on thousands of products over generations, has died, the company announced on Instagram. Cook was 95.

## $1 billion has been lost in cryptocurrency scams since 2021, FTC warns
 - [https://www.cnn.com/2022/06/04/business/cryptocurrency-scammers-ftc-warning/index.html](https://www.cnn.com/2022/06/04/business/cryptocurrency-scammers-ftc-warning/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 19:12:04+00:00

Cryptocurrency scammers have stolen over $1 billion from 46,000 people since the start of 2021, a new Federal Trade Commission report says.

## Man breaks into Dallas Museum of Art and damages several artworks, including 2,000-year-old Greek vases
 - [https://www.cnn.com/style/article/dallas-museum-art-breakin-damage-trnd/index.html](https://www.cnn.com/style/article/dallas-museum-art-breakin-damage-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 19:07:32+00:00

Several ancient works of art at the Dallas Museum of Art, including Greek vessels crafted thousands of years ago, were damaged by an intruder Wednesday night.

## 6 mistakes that led to the 1972 Watergate burglars being caught
 - [https://www.cnn.com/2022/06/04/politics/watergate-scandal-burglars-break-in-mistakes-origseriesfilms/index.html](https://www.cnn.com/2022/06/04/politics/watergate-scandal-burglars-break-in-mistakes-origseriesfilms/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 19:03:33+00:00

Their mission was to break into the Democratic National Committee headquarters in Washington, bug the room and photograph documents. If everything had gone as planned, no one would have ever known.

## Biden's meeting with Saudi crown prince pushed back to July
 - [https://www.cnn.com/2022/06/04/politics/biden-mohammed-bin-salman-saudi-meeting/index.html](https://www.cnn.com/2022/06/04/politics/biden-mohammed-bin-salman-saudi-meeting/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 17:19:02+00:00

A meeting between President Joe Biden and Saudi Arabia's de facto ruler, Crown Prince Mohammed bin Salman, is now expected to happen next month, according to an administration official.

## Iga Swiatek wins second grand slam title with victory against Coco Gauff in French Open final
 - [https://www.cnn.com/2022/06/04/tennis/iga-swiatek-coco-gauff-french-open-final-spt-intl/index.html](https://www.cnn.com/2022/06/04/tennis/iga-swiatek-coco-gauff-french-open-final-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 16:21:13+00:00

Iga Swiatek has been nearly unstoppable this season -- and now she has a second grand slam title to prove it.

## Inside New Zealand's rehab center for sassy, endangered penguins
 - [https://www.cnn.com/2022/06/04/world/penguin-rehab-science-newsletter-wt-scn/index.html](https://www.cnn.com/2022/06/04/world/penguin-rehab-science-newsletter-wt-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 15:15:10+00:00

"The world is full of obvious things which nobody by any chance ever observes."

## Shakira and footballer Gerard Piqué announce split
 - [https://www.cnn.com/2022/06/04/celebrities/shakira-gerard-pique-split-intl-scli/index.html](https://www.cnn.com/2022/06/04/celebrities/shakira-gerard-pique-split-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 14:45:25+00:00

Colombian pop star Shakira and her longtime partner, Spanish footballer Gerard Piqué, are separating.

## 'I couldn't care less.' What some young Britons think of the Queen's Platinum Jubilee
 - [https://www.cnn.com/2022/06/04/uk/jubilee-young-britons-gbr-cmd-intl/index.html](https://www.cnn.com/2022/06/04/uk/jubilee-young-britons-gbr-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 13:59:01+00:00

This weekend, millions in towns and cities across the United Kingdom will mark Queen Elizabeth II's 70-year reign.

## 'Fire Island' heats up a Jane Austen classic
 - [https://www.cnn.com/2022/06/04/entertainment/fire-island-plc/index.html](https://www.cnn.com/2022/06/04/entertainment/fire-island-plc/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 13:12:30+00:00

The classics never get old, but that doesn't mean they can't serve as inspiration for something modern.

## Book banning in the US: These are the authors of color who censors are trying to silence
 - [https://www.cnn.com/2022/06/04/us/banned-book-authors/index.html](https://www.cnn.com/2022/06/04/us/banned-book-authors/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 12:34:33+00:00

Young adult authors of color are fed up with being targeted.

## 'I was close to death,' says ex-Liverpool star after Champions League final chaos
 - [https://www.cnn.com/2022/06/04/football/champions-league-final-liverpool-real-madrid-fans-spt-intl/index.html](https://www.cnn.com/2022/06/04/football/champions-league-final-liverpool-real-madrid-fans-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 11:21:24+00:00

For Liverpool and Real Madrid fans, last Saturday's Champions League final was supposed to be the magical conclusion to a long, arduous season.

## Mayhem predicted for travel this summer
 - [https://www.cnn.com/travel/article/travel-chaos-flight-cancellations-2022/index.html](https://www.cnn.com/travel/article/travel-chaos-flight-cancellations-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 11:11:25+00:00

Picture the scene. You're heading off on the vacation you've dreamed of since early 2020. Your bags are packed, you get to the airport with plenty of time -- only to find lines so long that you end up missing your longed-for flight.

## Frustration mounts in Uvalde over shifting narratives about school shooting. State senator says lack of clarity could hinder future safety measures
 - [https://www.cnn.com/2022/06/04/us/uvalde-texas-elementary-school-shooting-saturday/index.html](https://www.cnn.com/2022/06/04/us/uvalde-texas-elementary-school-shooting-saturday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 10:52:10+00:00

The lack of clarity surrounding authorities' response to the mass shooting at a South Texas elementary school could hinder efforts to prevent such massacres from happening again, a state lawmaker told CNN on Friday.

## A former judge was killed in his Wisconsin home in a targeted attack, officials say
 - [https://www.cnn.com/2022/06/04/us/wisconsin-judge-killed-targeted-attack/index.html](https://www.cnn.com/2022/06/04/us/wisconsin-judge-killed-targeted-attack/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 10:35:08+00:00

A former Wisconsin judge was killed Friday in what authorities are calling a targeted attack by a suspect who also had other government officials as targets, a source familiar with the investigation told CNN.

## Astronauts face mental and emotional challenges for deep space travel. Scientists are working on solutions
 - [https://www.cnn.com/2022/06/04/world/longterm-spaceflight-cognition-emotions-life-itself-scn/index.html](https://www.cnn.com/2022/06/04/world/longterm-spaceflight-cognition-emotions-life-itself-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 10:00:53+00:00

Astronauts have been venturing into space for 61 years to unlock the human potential for exploration.

## Myanmar junta says democracy activists' death sentences upheld, paving way for first executions in decades
 - [https://www.cnn.com/2022/06/04/asia/myanmar-junta-activists-death-sentences-upheld-intl/index.html](https://www.cnn.com/2022/06/04/asia/myanmar-junta-activists-death-sentences-upheld-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 09:30:05+00:00

Myanmar's military government said on Friday that appeals by two prominent democracy activists against their death sentences had been rejected, paving the way for the country's first executions in decades.

## A pilot was killed after US Navy fighter jet crashed in a desert area in Southern California
 - [https://www.cnn.com/2022/06/04/us/navy-pilot-killed-jet-fighter-crash/index.html](https://www.cnn.com/2022/06/04/us/navy-pilot-killed-jet-fighter-crash/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 08:43:41+00:00

A pilot died Friday after a fighter jet crashed in a desert community near Trona, California, officials said.

## One dead, 8 injured after high-speed train derails in southern China
 - [https://www.cnn.com/2022/06/04/china/china-train-derail-death-intl-hnk/index.html](https://www.cnn.com/2022/06/04/china/china-train-derail-death-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 08:40:19+00:00

A train conductor was killed and eight other people injured after a high-speed train  derailed in southern China on Saturday morning, state media CCTV reported.

## 'Nightmare airport' debuts new $4 billion terminal
 - [https://www.cnn.com/travel/article/pandemic-travel-news-la-guardia-hang-son-doong/index.html](https://www.cnn.com/travel/article/pandemic-travel-news-la-guardia-hang-son-doong/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 08:28:59+00:00

Life is a journey, not a destination, as the saying goes -- and this summer that's truer than ever, as flight delays and cancellations continue.

## California drought is pushing Latino farmers and workers to make difficult decisions
 - [https://www.cnn.com/2022/06/04/us/latinos-california-drought-farmers/index.html](https://www.cnn.com/2022/06/04/us/latinos-california-drought-farmers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 08:00:04+00:00

Joe Del Bosque roamed the 2,000 acres of his California farm knowing he couldn't touch nearly half of the land he's owned for decades.

## As drug cartels expand their reach across Latin America, Chile takes a hit
 - [https://www.cnn.com/2022/06/04/americas/chile-rising-violence-drugs-intl-latam-cmd/index.html](https://www.cnn.com/2022/06/04/americas/chile-rising-violence-drugs-intl-latam-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 07:05:58+00:00

On May 1, Francisca Sandoval, a young Chilean reporter, traveled to a commercial district of the capital, Santiago, to cover a union rally commemorating International Workers' Day. It would be her final report.

## Bond between Americans and Ukrainian forces they trained remains strong as war grinds on
 - [https://www.cnn.com/2022/06/04/politics/national-guard-ukrainian-forces/index.html](https://www.cnn.com/2022/06/04/politics/national-guard-ukrainian-forces/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 06:00:09+00:00

The war in Ukraine became real for Col. Robert Swertfager on day one.

## 3 employees stabbed at hospital in Los Angeles County
 - [https://www.cnn.com/2022/06/03/us/los-angeles-hospital-stabbing/index.html](https://www.cnn.com/2022/06/03/us/los-angeles-hospital-stabbing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 04:18:17+00:00

Three employees of a Los Angeles County area hospital were stabbed on Friday by a man who has now barricaded himself inside the hospital, the Los Angeles Police Department said during a news conference.

## Zoo welcomes birth of world's most endangered wolf
 - [https://www.cnn.com/2022/06/04/us/rhode-island-zoo-red-wolf-scn-trnd/index.html](https://www.cnn.com/2022/06/04/us/rhode-island-zoo-red-wolf-scn-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 04:03:34+00:00

A zoo in Rhode Island has welcomed the birth of a critically endangered red wolf pup.

## 83-year-old man becomes oldest person to sail solo across the Pacific
 - [https://www.cnn.com/travel/article/kenichi-horie-solo-pacific-sail-intl-hnk/index.html](https://www.cnn.com/travel/article/kenichi-horie-solo-pacific-sail-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 02:18:35+00:00

Sailing solo across the world's largest ocean once is enough of an achievement. But 83-year-old Japanese ocean adventurer Kenichi Horie has done it multiple times.

## Grand jury indicts former Trump adviser Peter Navarro for contempt of Congress
 - [https://www.cnn.com/2022/06/03/politics/peter-navarro-indicted/index.html](https://www.cnn.com/2022/06/03/politics/peter-navarro-indicted/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 02:08:33+00:00

A federal grand jury has indicted former Trump White House adviser Peter Navarro for contempt of Congress after he refused to cooperate in the House January 6 committee's investigation.

## 'Isn't image China wants': Video captures brutality of some Covid enforcers
 - [https://www.cnn.com/videos/world/2022/06/04/chinese-big-whites-covid-alleged-harrassment-wang-pkg-ac360-vpx.cnn](https://www.cnn.com/videos/world/2022/06/04/chinese-big-whites-covid-alleged-harrassment-wang-pkg-ac360-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 01:47:17+00:00

The symbol of Covid enforcement in China: workers wearing full-body white hazmat suits, with face masks, goggles and gloves. State media painted them as brave civil servants risking their lives to protect the people. But since Shanghai's lockdown, the "Big Whites" have turned into a symbol of brutality, as videos emerged of them allegedly beating residents, dragging people out of their homes to quarantine, mauling pets to deaths, and destroying private property. CNN's Selina Wang reports.

## Hong Kong police warn Tiananmen anniversary vigil could break the law
 - [https://www.cnn.com/2022/06/03/asia/hong-kong-june-4-tiananmen-nsl-intl-mic-hnk/index.html](https://www.cnn.com/2022/06/03/asia/hong-kong-june-4-tiananmen-nsl-intl-mic-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-04 01:42:10+00:00




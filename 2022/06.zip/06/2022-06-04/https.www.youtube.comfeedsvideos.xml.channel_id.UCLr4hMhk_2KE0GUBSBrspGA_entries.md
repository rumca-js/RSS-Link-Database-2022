# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Dlaczego Tech Week sprzed 7 lat pojawia Ci się na głównej?
 - [https://www.youtube.com/watch?v=ufXhdqNrl-E](https://www.youtube.com/watch?v=ufXhdqNrl-E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-06-05 00:00:00+00:00

Fragment sponsorowany Lemon.io - link dla deweloperów - https://l.lemon.io/klawiaturlink
Dziś w odcinku:
00:00 Afera Tech Weekowa
01:34 Dobry Wieczór
01:39 Gry komputerowe powodują gnicie mózgu
02:36 Wolfenstein The New Order za darmo 
03:10 Elon Musk wprowadza koniec pracy zdalnej
04:01 Dlaczego baletnice są zawsze uśmiechnięte - rozwiązanie tajemnicy
05:49 Konferencja Apple'a
06:30 Fragment sponsorowany Lemon.io
07:03 OnePlus to Oppo w przebraniu?
08:43 Smartfony niedługo zabiją aparaty fotograficzne 
09:34 Popularność podcastów emitujących biały szum
10:58 WIELKI TEST składanych smartfonów!
11:07 Szybkie newsy
11:44 Znośnego tygodnia!

Źródła:
Gry nie szkodzą: https://on.wsj.com/3tiPEQh
Wolfenstein za free: https://bit.ly/3tbQ0Z1
Koniec pracy zdalnej w Tesli: https://bit.ly/3x8YGjZ
Musk ma złe przeczucia dot. rynku: https://bit.ly/3Q4xRGo
Tańczą mimo, że boli: https://bit.ly/3NkAJgD
Co na WWDC 2022: https://bit.ly/3aHadiZ
OnePlus to Oppo w przebraniu: https://bit.ly/3mesve3
Smartfony zabiją aparaty foto w ciągu trzech lat: https://bit.ly/3x5Tptv
Podcasty z białym szumem: https://bloom.bg/3zg5v63
Satelity chińskiej firmy Geely: https://reut.rs/3Mj3U2g
Wirus, który uleczy raka: https://bit.ly/3xfWBE5
COO Mety odchodzi: https://bit.ly/3aoyjii

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


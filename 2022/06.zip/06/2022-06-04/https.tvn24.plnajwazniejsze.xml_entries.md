# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Kobiecy Punkt Widzenia
 - [https://tvn24.pl/go/programy,7/kobiecy-punkt-widzenia--odcinki,511634/odcinek-51,S00E51,824290?source=rss](https://tvn24.pl/go/programy,7/kobiecy-punkt-widzenia--odcinki,511634/odcinek-51,S00E51,824290?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-06-04 04:00:00+00:00

<img alt="Kobiecy Punkt Widzenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2rav3h-img4394-6123793/alternates/LANDSCAPE_1280" />
    undefined

## "Tak naprawdę to była improwizacja i każdy robił to, co potrafił zrobić najlepiej"
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-3,S00E03,32872?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-3,S00E03,32872?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-06-04 03:00:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4t5xi8-dokument-my-narod-5737297/alternates/LANDSCAPE_1280" />
    Od upadku Muru Berlińskiego po rozpad Związku Radzieckiego. Jak wybory czerwcowe z 1989 roku przyczyniły się do obalenia komunizmu w Polsce oraz zapoczątkowały reakcję łańcuchową w Europie Środkowo-Wschodniej.

## Miała cztery lata, gdy powiedziała: "Zosia umarła. Jestem Bartek"
 - [https://tvn24.pl/premium/mama-transseksualnego-dziecka-powiedzial-mi-zosi-nie-ma-zosia-umarla-ja-jestem-bartek-5735074?source=rss](https://tvn24.pl/premium/mama-transseksualnego-dziecka-powiedzial-mi-zosi-nie-ma-zosia-umarla-ja-jestem-bartek-5735074?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-06-04 00:46:20+00:00

<img alt="Miała cztery lata, gdy powiedziała: " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tgrp2v-bartek-poszedl-juz-do-szkoly-5736960/alternates/LANDSCAPE_1280" />
    Trzy lata temu było o nich głośno. O dziecku, które już w wieku trzech lat dało mamie do zrozumienia, że ciało nie pasuje, uwiera jak sukienka i przeszkadza jak długie włosy. Mama nie rozumiała, więc dziecko się złościło. Kilkanaście miesięcy zajęło dziecku i mamie wykluczenie u malca autyzmu i innych zaburzeń psychicznych. Aż trafili na pana lekarza, który powiedział, że Zosia nie utożsamia się ze swoją płcią i że mama - jedyne, co może - to je takim zaakceptować. Wtedy mama wzięła dziecko na kolana, przytuliła i powiedziała, że je bardzo kocha. I dziecko przestało się złościć.


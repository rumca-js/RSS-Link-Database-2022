# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Grond | Tolkien Explained
 - [https://www.youtube.com/watch?v=YhAZG-m0004](https://www.youtube.com/watch?v=YhAZG-m0004)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-06-04 00:00:00+00:00

GROND! Not only was it the name of the battering ram of Mordor, it was also the name of Morgoth's mace which he weilded in his duel with the High King Fingolfin.  We'll address the common question of whether these could be the same weapon while also looking at the history of both!

Go to www.LordofMaps.com and use the code NERDOFMAPS to save 15% off your order of great maps!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri
Noe Leyva - https://twitter.com/NoeLeyvArt

Grond - WETA
By the Gates of Angband - CK Goskoy
Morgoth and Fingolfin - Catherine Chmiel
Grond - John Howe
Grond sketch - John Howe
The Fall of Fingolfin - Dracarysdrekkar7
Grond - Ralph Damiani
Then Morgoth Came - Skullb*st*rd
The Coming of Glaurung - Alan Lee
Battle of Sudden Flame - Alan Lee
Fingolfin - Jenny Dolfen
Beleriand Map -Lamaarcana
Fingolfin's Wrath - Ted Nasmith
Fingolfin challenges Morgoth, The Gate of Angband - Pete Amachree
Gates of Angband - CK Goksoy
Morgoth - Weirling
Morgoth vs Fingolfin - Kip Rasmussen
Morgoth and the High King of the Noldor - Ted Nasmith
Fingolfin's Challenge - John Howe
Nolofinwe - Ralph Damiani
Orcs - Aegeri
Thrice He Rose - Jenny Dolfen
Fingolfin and Morgoth - MattLeese87
Fingolfin vs Morgoth - Kuliszu
Fingolfin and Morgoth - Aegeri
Fingolfin and Morgoth - Pete Amachree
Fingolfin - dracarysdrekkar7
The Witch King - Weirling
Cirith Gorgor - Ted Nasmith
Grond Leaves Mordor - Olanda Fong-Surdenas
In Rode the Lord of the Nazgul - Onirio
Fingolfin facing Morgoth - TolmanCotton
Knight of Dol Amroth - Dracarysdrekkar7
City Under Siege - Turner Mohan
The Siege of Gondor - Alan Lee
Siege of Helm's Deep - Weirling
Grond - WETA
Grond - WETA
Attack on Helm's Deep - Ivan Cavini
Witch-King - John Howe
The Witch King - John Howe
Gandalf vs Witch-king - Angus McBride
Minas Tirith - Aegeri
Minas Tirith - Ralph Damiani
Minas Tirith sketch - Alan Lee
Eowyn and the Witch-king - Aegeri
The Witch-king - John Howe
Witch King at Minas Morgul - Elrodimus Flash
Fingolfin vs Morgoth - Kuliszu
Mount Doom - Elrodimus Flash
Battle of the Pelennor Fields - Aegeri
Thus Came Aragorn - Ted Nasmith

#grond #lordoftherings #tolkien


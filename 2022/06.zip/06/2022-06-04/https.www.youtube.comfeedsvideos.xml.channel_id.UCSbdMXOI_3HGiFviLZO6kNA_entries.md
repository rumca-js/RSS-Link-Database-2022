# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## FINALLY! The NEWEST VR Omni-Directional Treadmill is HERE!
 - [https://www.youtube.com/watch?v=o6Nh05Qjs4o](https://www.youtube.com/watch?v=o6Nh05Qjs4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-06-05 00:00:00+00:00

Hello! I have been working on this video for a few weeks to get this JUST RIGHT! This is the KatWalk C2, the newest VR omni-directional treadmill allowing you to walk, swim (sort of), Run, Jump, and ride horses within VR pushing immersion to the absolute extreme. 

This is my review of the product, mind you I haven't had the chance to use it more than a couple weeks, so we'll have to see how well it does long term. 

Here's where you can check it out. Their kickstarter ends in a week: 
https://www.knoxlabs.com/pages/kat-walk-c2-series


MY OUTRO MUSIC:
https://youtu.be/u6JwgNQDVfI

MY LINKS:
My links:
Discord:
https://discord.gg/2hCGM9BYez
Twitch:
https://www.twitch.tv/thrilluwu
Twitter:
https://twitter.com/Thrilluwu
Patreon:
https://www.patreon.com/Thrillseeker


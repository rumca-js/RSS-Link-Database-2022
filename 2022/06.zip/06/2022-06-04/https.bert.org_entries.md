## Installing a payphone in my house | bertrand fan
 - [https://bert.org/2022/06/02/payphone/](https://bert.org/2022/06/02/payphone/)
 - RSS feed: https://bert.org
 - date published: 2022-06-04 11:44:42.428388+00:00

When I was growing up in the 90s, I remember wanting to get on the Internet. My parents weren’t going to help me, so I called up an ISP and said I wanted to set up an account. They asked for my name and I gave them a fake name. And then they asked for a credit card number and I told them I had to find my wallet and call them back.


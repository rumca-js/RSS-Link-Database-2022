## Dear Spotify. Can we just get a table of songs?
 - [https://neil.computer/notes/dear-spotify-can-we-just-get-table-of-songs/](https://neil.computer/notes/dear-spotify-can-we-just-get-table-of-songs/)
 - RSS feed: https://neil.computer
 - date published: 2022-06-04 08:56:58.168737+00:00

Dear Spotify. I tried to search for podcasts on your Desktop app. I know you're into fancy cross-platform Electron framework. I've come to terms with it. It's fine. It'll do. But, your understanding of interface design seems like it needs a bit of a history lesson. Back in iTunes Good


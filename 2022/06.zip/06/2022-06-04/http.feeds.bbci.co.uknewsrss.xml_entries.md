# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Platinum Party at the Palace: The royals were the real stars of the Jubilee concert
 - [https://www.bbc.co.uk/news/entertainment-arts-61689413?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-61689413?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 23:48:12+00:00

Alicia Keys, Diana Ross and Sam Ryder took to the stage, but the Royal Family were the real stars.

## Partygate: Will Boris Johnson survive June?
 - [https://www.bbc.co.uk/news/uk-politics-61693296?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-61693296?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 23:29:54+00:00

The PM wants us to know he plans to get on with the job - but some of his MPs have other ideas.

## Animatronic model workshop: 'Most people have never seen anything like it'
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-61484634?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-61484634?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 23:18:47+00:00

The owner of the Victorian Model Workshop believes it's the only shop of its kind open to the public.

## Platinum Jubilee Pageant: Dancer Janice Ho reflects on playing the Queen
 - [https://www.bbc.co.uk/news/uk-61645988?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61645988?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 23:12:16+00:00

Singaporean dancer Janice Ho speaks to the BBC about portraying the Queen at the Jubilee Pageant.

## Queen's Platinum Jubilee: The Nigerian boss who applied to be monarch's footman
 - [https://www.bbc.co.uk/news/world-africa-61649453?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-61649453?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 23:09:17+00:00

Nigeria is the biggest former British colony in Africa but not many people are celebrating the jubilee.

## Your pictures on the theme of 'exercise'
 - [https://www.bbc.co.uk/news/in-pictures-61607924?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-61607924?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 23:08:04+00:00

A selection of striking images from our readers around the world.

## Nykaa to Mamaearth: Start-ups fuel India's growing love for skincare
 - [https://www.bbc.co.uk/news/world-asia-india-61594179?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-61594179?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 23:07:13+00:00

Homegrown start-ups like Nykaa have disrupted the Indian skincare market with their wide range.

## COP26: Are nations on track to meet their climate goals?
 - [https://www.bbc.co.uk/news/science-environment-61494531?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-61494531?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 23:01:29+00:00

Governments are due to meet in Bonn to discuss progress on climate action since COP26.

## In pictures: Stars throw Party at the Palace for Queen's Platinum Jubilee
 - [https://www.bbc.co.uk/news/entertainment-arts-61693645?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-61693645?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 22:58:19+00:00

Performers from Diana Ross and Sir Rod Stewart to Jason Donovan and Sam Ryder played outside the palace.

## The Queen meets Paddington Bear for tea
 - [https://www.bbc.co.uk/news/uk-61692278?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61692278?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 19:23:57+00:00

The Queen and the animated children's character professed a shared love for marmalade sandwiches.

## Charlotte conducts orchestra at Cardiff rehearsal
 - [https://www.bbc.co.uk/news/uk-61692277?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61692277?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 17:33:03+00:00

The Duke and Duchess of Cambridge was in Cardiff with the princess and her brother, Prince George.

## Qatar World Cup 2022: Wales and Ukraine set for momentous play-off final in Cardiff
 - [https://www.bbc.co.uk/sport/football/60869800?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60869800?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 17:10:22+00:00

Wales aim to end their 64-year wait for World Cup qualification as they host Ukraine in Sunday's play-off final in Cardiff.

## French Open: Rafael Nadal bids for 14th Roland Garros title against Casper Ruud
 - [https://www.bbc.co.uk/sport/tennis/61690589?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/61690589?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 16:42:31+00:00

Rafael Nadal bids for a record-extending 14th French Open title against Casper Ruud on Sunday - in a meeting between master and "student".

## Platinum Jubilee: Festivities to continue with Party at the Palace
 - [https://www.bbc.co.uk/news/uk-61690149?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61690149?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 13:06:49+00:00

The star-studded concert will also see Prince Charles and Prince William pay tribute to the Queen.

## England v New Zealand: Parkinson removes Southee for first Test wicket
 - [https://www.bbc.co.uk/sport/av/cricket/61690624?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/61690624?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 12:14:24+00:00

Matt Parkinson picks up his first Test wicket with a lovely flighted delivery that Tim Southee edges straight to Joe Root at first slip to leave New Zealand all out for 285.

## Harry and Meghan: Royals wish Lilibet a happy first birthday
 - [https://www.bbc.co.uk/news/uk-61688835?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-61688835?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 11:54:56+00:00

The Queen met her great-granddaughter, who is turning one, for the first time this week.

## England v New Zealand: England take three wickets in three balls for team hat-trick
 - [https://www.bbc.co.uk/sport/av/cricket/61690621?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/61690621?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 11:26:49+00:00

England take three New Zealand wickets in a three balls for a stunning team hat-trick during day three of the first Test at Lord's.

## Champions League final: MP calls for retraction of fan 'smears'
 - [https://www.bbc.co.uk/news/uk-england-merseyside-61689650?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-61689650?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 11:19:16+00:00

Liverpool MP Ian Byrne wants "a full apology" for organisers' claims over chaos at the Paris event.

## Robbie Williams: Fame 'intoxicating but isolating'
 - [https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-61683092?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-61683092?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 10:43:08+00:00

The Angels singer reflects on his 30-year career ahead of a homecoming gig in Stoke-on-Trent.

## Met Office thunderstorm warning for most of Wales
 - [https://www.bbc.co.uk/news/uk-wales-61689831?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61689831?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 09:52:28+00:00

Forecasters warn of flooding and travel disruption on Sunday amid thunderstorm warning.

## Mariah Carey sued for copyright over 'All I want for Christmas is You'
 - [https://www.bbc.co.uk/news/world-us-canada-61688826?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-61688826?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 09:22:54+00:00

A US singer says he co-wrote a song called 'All I want for Christmas is You' five years before Carey's 1994 hit.

## Platinum Jubilee: What does Scotland think of the Queen?
 - [https://www.bbc.co.uk/news/uk-scotland-61685855?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-61685855?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 09:17:16+00:00

The BBC's Scotland editor James Cook examines how the country's view of the monarchy has evolved.

## Rapper Hypo stabbed to death at Jubilee party in east London
 - [https://www.bbc.co.uk/news/uk-england-london-61683840?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-61683840?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 08:18:35+00:00

Police believe the 39-year-old, real name Lamar Jackson, was the victim of the fatal London attack.

## Platinum Jubilee: How have we celebrated in the past?
 - [https://www.bbc.co.uk/news/uk-england-london-61308675?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-61308675?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 07:08:28+00:00

From food for the poor to Ozzy Osbourne and Kermit the Frog - the story of two centuries of jubilees.

## Shot dead by Sri Lankan police while trying to get fuel
 - [https://www.bbc.co.uk/news/world-asia-61667282?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-61667282?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 07:04:32+00:00

The UN and human rights groups have warned authorities in Sri Lanka against using excessive force.

## Tiananmen: Hong Kong students hide tiny "democracy goddesses" on campus
 - [https://www.bbc.co.uk/news/world-asia-china-61679435?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-61679435?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 06:48:36+00:00

The anonymous acts in Hong Kong defy a crackdown on public commemoration of the killings.

## How Henry the cat won the hearts of Addenbrooke's Hospital
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-61514688?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-61514688?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 06:42:54+00:00

Henry the cat has become popular with hospital patients and staff, despite not being allowed inside.

## Queen Mother's car revealed by couple's detective work
 - [https://www.bbc.co.uk/news/uk-wales-61664580?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-61664580?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 06:12:23+00:00

A car lover bought it for £2,000, before investigations with his wife uncovered its royal history.

## The Papers: 'We give thanks' and 'together... yet apart'
 - [https://www.bbc.co.uk/news/blogs-the-papers-61687526?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-61687526?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-06-04 04:40:01+00:00

Gratitude for the Queen and reported tensions between her grandsons lead the front pages.


# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## Ubuntu problems, Linux on iPad, System76 in Europe -  Linux and open source news
 - [https://www.youtube.com/watch?v=39PylALvQ3U](https://www.youtube.com/watch?v=39PylALvQ3U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-06-10 00:00:00+00:00

Get 100$ credit for your own Linux and gaming server: https://www.linode.com/linuxexperiment 
Grab a brand new laptop or desktop running Linux:https://www.tuxedocomputers.com/


👏 SUPPORT THE CHANNEL:
Get access to an exclusive weekly podcast, vote on the next topics I cover, and get your name in the credits:

YOUTUBE: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join

Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

🏆 FOLLOW ME ELSEWHERE:
Linux news in Youtube Shorts format: https://www.youtube.com/channel/UCtZp0mK9IBrpS2-jNzMZmoA

Join us on our Discord server: https://discord.gg/xK7ukavWmQ

Twitter : http://twitter.com/thelinuxEXP

Mastodon: https://mastodon.social/web/@thelinuxEXP

Pixelfed: https://pixelfed.social/TLENick

My Gaming on Linux Channel: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw

📷 GEAR I USE:
Sony Alpha A6600 Mirrorless Camera: https://amzn.to/30zKyn7
Sigma 56mm Fixed Prime Lens: https://amzn.to/3aRvK5l
Logitech MX Master 3 Mouse: https://amzn.to/3BVI0Od
Bluetooth Space Grey Mac Keyboard: https://amzn.to/3jcJETZ
Logitech Brio 4K Webcam: https://amzn.to/3jgeTh9
LG Curved Ultrawide Monitor: https://amzn.to/3pcTVDH
Logitech White Speakers: https://amzn.to/3n6wSb0
Xbox Controller: https://amzn.to/3BWmIA3
*Amazon Links are affiliate codes and generate small commissions to support the channel*

This video is distributed under the Creative Commons Share Alike license.


00:00 Intro
01:02 Sponsor: 100$ Free Credit on your Linux or Gaming Server
01:54 GNOME Updates
03:00 KDE Updates
04:05 Linux kernel runs on iPads
05:11 Ubuntu kills apps in the background
06:24 Peertube 4.2 brings cool improvements
07:45 x86 apps in Linux VMs on Apple Silicon
09:09 System76 to open a distribution HUB in Europe
10:22 HP Dev One with Linux is available
11:54 Unity features brought back to Ubuntu GNOME
13:37 Sponsor: Get a laptop or desktop that runs Linux from Tuxedo
14:38 Help me make more of these videos

GNOME developers published another update about what they've been working on. 
https://thisweek.gnome.org/posts/2022/06/twig-46/

KDE developers were also hard at work on their own stuff
https://pointieststick.com/2022/06/03/this-week-in-kde-fixing-bugs-and-lets-fix-more/

Developers managed to run Linux on iPads based on the A7 and A8 chips. 
https://arstechnica.com/gadgets/2022/06/developers-get-linux-up-and-running-on-old-ipad-air-2-hardware/

Ubuntu 22.04 kills off apps in the background too often
https://www.omgubuntu.co.uk/2022/06/ubuntu-22-04-systemd-oom-killing-apps

PeerTube 4.2 released
https://joinpeertube.org/news#release-4.2

Apple will allow Linux virtual machines to run x86 applications on the new Apple Silicon processors
https://apple.slashdot.org/story/22/06/07/208222/apple-will-allow-linux-vms-to-run-intel-apps-with-rosetta-in-macos-ventura?utm_source=feedly1.0mainlinkanon&utm_medium=feed

System76 is opening a distribution center in Europe in the coming months.
https://www.omgubuntu.co.uk/2022/06/system76-is-opening-a-european-distribution-center

The HP Dev One is now available, and I got a review unit
https://hpdevone.com/

Someone is working on bringing the "same window spread" from Unity to modern day Ubuntu
https://www.omgubuntu.co.uk/2022/06/dash-to-dock-window-spread-feature-proposal

Wine 7.10 is now out
https://www.winehq.org/announce/7.10


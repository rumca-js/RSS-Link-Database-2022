# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Brandon's 10 Most Honest Lies So Far...
 - [https://www.youtube.com/watch?v=FLBYSnMKRVo](https://www.youtube.com/watch?v=FLBYSnMKRVo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-06-11 00:00:00+00:00

Grab your Red/Blue Light Teeth Whitening Kit at https://naturalteethwhiteners.com/jp

All-New Freedom Merch here - https://awakenwithjp.com/shop

Upcoming LIVE Shows - https://awakenwithjp.com/tour

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Biden has had an incredible presidency up to this point. Here's President Biden's 10 most honest lies so far!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://rumble.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


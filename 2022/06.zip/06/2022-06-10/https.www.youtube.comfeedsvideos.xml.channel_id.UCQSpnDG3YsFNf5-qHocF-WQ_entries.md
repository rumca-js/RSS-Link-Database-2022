# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## The Most Useful Set of Free Programs EVER
 - [https://www.youtube.com/watch?v=6Fa8ObxmFKE](https://www.youtube.com/watch?v=6Fa8ObxmFKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-06-11 00:00:00+00:00

Do you know about these?

• Nirsoft: https://www.nirsoft.net/
• NirLauncher: https://launcher.nirsoft.net/

Other Things Mentioned:
• https://joeware.net/freetools/
• https://mitec.cz
• Sysinternals: https://docs.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite
IconViewer: https://www.botproductions.com/iconview/iconview.html

▼ Time Stamps: ▼
0:00 - Intro
1:19 - Section: My Favorites
1:37 - USBLogView
2:46 - IconsExtract
4:08 - ShellMenuView
5:18 - DevManView
6:10 - USBDeview
6:35 - Section: More Useful Tools
6:44 - CurrPorts
7:06 - SpecialFoldersView
7:34 - BlueScreenView
7:57 - RegistryChangesView
8:36 - LastActivityView
9:35 - AdvancedRun
10:04 - RunAsDate
10:28 - ControlMyMonitor
11:16 - Section: Other Sites With Useful Tools
11:36 - Joeware
11:56 - Mitec
12:23 - Sysinternals

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


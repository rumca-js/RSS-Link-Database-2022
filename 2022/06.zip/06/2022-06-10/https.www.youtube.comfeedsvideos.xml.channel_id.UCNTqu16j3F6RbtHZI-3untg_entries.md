# Source:Glink, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg, language:en-US

## Light Wave Event Trailer
 - [https://www.youtube.com/watch?v=PGwlAb-rUTE](https://www.youtube.com/watch?v=PGwlAb-rUTE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg
 - date published: 2022-06-11 00:00:00+00:00

Light Wave is an upcoming event Im hosting that brings together the greatest creators and artists of our time to a meeting space in real life, where their ideas can flourish into a brighter vision of the future. 

@lightwaveatx on all platforms 

TWITTER - https://twitter.com/LightWaveATX
INSTAGRAM - Light_Wave_atx
YOUTUBE -  https://www.youtube.com/channel/UCVukj7tpLLg6uAZ_Zr_9CyA/videos

SONGS
Wink - The Voidz
FBI - Gee Tee

Join channel members to get access to past streams and members only videos:
https://www.youtube.com/channel/UCNTqu16j3F6RbtHZI-3untg/join

The G-Links:

https://twitter.com/GlinkLive
Twitter, where I publish all my hot takes and dank memes

https://www.reddit.com/r/glink/
Reddit, nobody uses this, but you can post memes here

https://www.instagram.com/glink_between_worlds/
Instagram, this is where things get real  a e s t h e t i c 

https://discord.gg/xtwYypf
My Discord, only for REAL gamers

https://www.patreon.com/Glink
Support me on Patreon and be included in Q & As, audio updates, discord roles, and credits at the end of my videos 

https://www.shopglink.com/
Merch designed from handrawn art

https://www.youtube.com/channel/UChJT4Jg89AHMyybcXFeKp_A
My podcast with Slush


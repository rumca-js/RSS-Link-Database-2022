# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Fallout 3's DLC Is An Absolute Nightmare - This Is Why
 - [https://www.youtube.com/watch?v=NrG5olOLNOk](https://www.youtube.com/watch?v=NrG5olOLNOk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2022-06-10 20:53:10+00:00

Offset your carbon footprint on Wren: https://www.wren.co/start/upisnotjump The first 100 people who sign up will have 10 extra trees planted in their name!

Many thought it was Fallout: New Vegas next, but I am ready to get all I can out of the Fallout 3 train! This should be it before Fallout: New Vegas though, I wasss going to review some Fallout 3 mods but I may do that later on.

This video was sponsored by Wren :D ENJOY

Patreon bros: https://www.patreon.com/UpIsNotJump 

Merch-o-bros: https://www.pixelempire.com/pages/upisnotjump

Twitter-o-fish: https://twitter.com/UpIsNotJump 

Editing workflow partly by: https://twitter.com/MudanTV 

Thumbnail by: @skutchdraws


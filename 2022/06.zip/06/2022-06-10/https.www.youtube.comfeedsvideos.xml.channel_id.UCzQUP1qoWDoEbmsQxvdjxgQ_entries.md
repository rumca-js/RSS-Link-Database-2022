# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Tries "Mexican Moonshine" Raicilla
 - [https://www.youtube.com/watch?v=v15pSIpocGY](https://www.youtube.com/watch?v=v15pSIpocGY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-06-10 00:00:00+00:00

Taken from JRE #1830 w/Meghan Murphy:
https://open.spotify.com/episode/3ExVz6wwSvyRKCBUZqXZQz?si=6873c8f7f9764d85

## Twitter Bots and Elon Musk's Crusade Against Them
 - [https://www.youtube.com/watch?v=KALHESfO71c](https://www.youtube.com/watch?v=KALHESfO71c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-06-10 00:00:00+00:00

Taken from JRE #1830 w/Meghan Murphy:
https://open.spotify.com/episode/3ExVz6wwSvyRKCBUZqXZQz?si=6873c8f7f9764d85


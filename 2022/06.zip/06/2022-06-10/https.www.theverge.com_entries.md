## Firefox and Chrome are squaring off over ad-blocker extensions - The Verge
 - [https://www.theverge.com/2022/6/10/23131029/mozilla-ad-blocking-firefox-google-chrome-privacy-manifest-v3-web-request](https://www.theverge.com/2022/6/10/23131029/mozilla-ad-blocking-firefox-google-chrome-privacy-manifest-v3-web-request)
 - RSS feed: https://www.theverge.com
 - date published: 2022-06-10 17:16:24.457545+00:00

A browser privacy showdown has been brewing for a while.


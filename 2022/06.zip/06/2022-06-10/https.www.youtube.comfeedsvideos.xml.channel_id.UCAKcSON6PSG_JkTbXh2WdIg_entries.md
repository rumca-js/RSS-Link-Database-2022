# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Matt Andersen - Coal Mining Blues (live on Radio Heartland)
 - [https://www.youtube.com/watch?v=uEhs2TMsxnY](https://www.youtube.com/watch?v=uEhs2TMsxnY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-06-11 00:00:00+00:00

Matt Andersen performs "Coal Mining Blues" from his album "House to House" during a session in the Radio Heartland studio at The Current. 

Credits
Mike Pengra - host
Craig Thorson - audio engineer
Eric Romani - video & photo
Luke Taylor - digital production

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#mattandersen #mattandersenmusic


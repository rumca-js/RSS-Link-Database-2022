# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Xiaomi got in trouble in China...
 - [https://www.youtube.com/watch?v=6i1BIM008ew](https://www.youtube.com/watch?v=6i1BIM008ew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-06-10 00:00:00+00:00

Sponsored by Curiositystream. Get it & Nebula here: https://curiositystream.com/tfc

Nebula Bonus video (USB C deep dive with TLDR News: https://nebula.app/videos/tldrnewseu-discussing-the-eus-new-usbc-law-w-techaltar

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► This video ◄◄◄  

This week Apple announced a ton of new stuff at WWDC, Xiaomi got in trouble in China as well, and the EU ruled 3 times on tech, including USB C.

Episode 100

This video on Nebula: https://nebula.app/videos/the-friday-checkout-xiaomi-gets-in-trouble-even-in-china

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

XiJinping photo: Palácio do Planalto, via Wikipedia: https://commons.wikimedia.org/wiki/File:Xi_Jinping_2019_(49060546152)_2.jpg

0:00 Intro
0:26 Release highlights
2:31 WWDC highlights 
4:30 Xiaomi trouble in China
6:34 3 new EU Rulings


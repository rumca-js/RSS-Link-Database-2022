## Cooling the tube – Engineering heat out of the Underground
 - [https://www.ianvisits.co.uk/articles/cooling-the-tube-engineering-heat-out-of-the-underground-20873/](https://www.ianvisits.co.uk/articles/cooling-the-tube-engineering-heat-out-of-the-underground-20873/)
 - RSS feed: https://www.ianvisits.co.uk
 - date published: 2022-06-10 20:15:00.995127+00:00

On a summer's day a trip in a hot tube train is a dreadful experience, but how did we end up with such hot tube trains, and what's being done about it?


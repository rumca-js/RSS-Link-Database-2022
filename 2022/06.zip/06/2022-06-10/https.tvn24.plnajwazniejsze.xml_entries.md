# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Zaczęło się w środę po godzinie 14"
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-882,S00E882,442497?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-882,S00E882,442497?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-06-10 11:11:57+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4xxxd1-szturm-na-kapitol-5745904/alternates/LANDSCAPE_1280" />
    Unikatowe nagrania ze szturmu na Kapitol w 2021 roku.


## Mostly automatic Go dependency updates with GitHub Actions — brandur.org
 - [https://brandur.org/fragments/mostly-automatic-deps](https://brandur.org/fragments/mostly-automatic-deps)
 - RSS feed: https://brandur.org
 - date published: 2022-06-10 15:57:48.100519+00:00




# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Lost dog? How nose prints could help pet and owner reunite
 - [https://www.bbc.co.uk/news/technology-61759028?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-61759028?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-06-10 16:08:01+00:00

A face identification app could allow smartphone users to help owners find their missing animals.


# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Justin Bieber says he has facial paralysis due to Ramsay Hunt syndrome
 - [https://www.cnn.com/2022/06/10/entertainment/justin-bieber-paralysis-ramsay-hunt/index.html](https://www.cnn.com/2022/06/10/entertainment/justin-bieber-paralysis-ramsay-hunt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 22:58:53+00:00

Justin Bieber announced Friday that he is taking a break from performing because he is suffering from paralysis on one side of his face.

## Dow falls 800 points as inflation hits 40-year high
 - [https://www.cnn.com/2022/06/10/investing/markets-fall-drop/index.html](https://www.cnn.com/2022/06/10/investing/markets-fall-drop/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 20:43:16+00:00

The Dow dropped more than 700 points on Friday morning after a key inflation report missed estimates and showed a higher-than-anticipated increase in the price of consumer goods.

## UK judge allows first flight sending asylum-seekers to Rwanda to go ahead
 - [https://www.cnn.com/2022/06/10/uk/uk-rwanda-deportation-flight-high-court-ruling-intl-gbr/index.html](https://www.cnn.com/2022/06/10/uk/uk-rwanda-deportation-flight-high-court-ruling-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 19:14:02+00:00

The United Kingdom's controversial plan to send asylum-seekers to Rwanda as early as next week was green-lit on Friday, after the High Court in London denied an injunction to block the first flight.

## Watch how pro-Trump personalities covered the prime-time January 6 hearing
 - [https://www.cnn.com/videos/business/2022/06/10/january-6-committee-hearing-fox-news-pro-trump-media-coverage-orig-ht.cnn-business](https://www.cnn.com/videos/business/2022/06/10/january-6-committee-hearing-fox-news-pro-trump-media-coverage-orig-ht.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 18:29:23+00:00

Fox News chose not to carry the prime-time January 6 congressional hearing live Thursday night. Other conservative media, like Newsmax, aired the hearing but tried to spin the coverage. Here are some moments that highlight the splintering media landscape.

## Watch Putin shift his rhetoric over Russia's stated goal
 - [https://www.cnn.com/videos/world/2022/06/10/putin-peter-the-great-comparison-russian-invasion-ukraine-sot-ctw-vpx.cnn](https://www.cnn.com/videos/world/2022/06/10/putin-peter-the-great-comparison-russian-invasion-ukraine-sot-ctw-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 17:40:44+00:00

Russian President Vladimir Putin compared himself to the 18th century Russian czar, Peter the Great, to justify Russia's invasion of Ukraine. CNN's Fred Pleitgen joins Connect the World to discuss.

## Scientists designed a humanoid robotic finger with living humanlike skin
 - [https://www.cnn.com/2022/06/10/world/robot-finger-humanlike-skin-scn/index.html](https://www.cnn.com/2022/06/10/world/robot-finger-humanlike-skin-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 17:18:12+00:00

Skin has traditionally been reserved for animals -- until now.

## Emma Thompson on pleasure and reclaiming one's sexuality
 - [https://www.cnn.com/videos/tv/2022/06/09/emma-thompson-amanpour-daryl-mccormack-sophie-hyde-good-luck-to-you-leo-grande-film.cnn](https://www.cnn.com/videos/tv/2022/06/09/emma-thompson-amanpour-daryl-mccormack-sophie-hyde-good-luck-to-you-leo-grande-film.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 17:00:44+00:00

Dame Emma Thompson tells Amanpour about her new film "Good Luck to You, Leo Grande" and why she lays it all bare at 63.

## Exclusive: A crypto-based dossier could help prove Russia committed war crimes
 - [https://www.cnn.com/2022/06/10/tech/ukraine-war-crimes-blockchain/index.html](https://www.cnn.com/2022/06/10/tech/ukraine-war-crimes-blockchain/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 16:55:47+00:00

In early March, a Telegram user posted a photo of wreckage at a school in a suburb of Kharkiv, Ukraine. The photo showed the side of a classroom with a large blast hole and a pile of debris including desks and chairs.

## CNN correspondent says goodbye after 18 years
 - [https://www.cnn.com/videos/world/2022/06/10/arwa-damon-leaving-cnn-ctw-intv-vpx.cnn](https://www.cnn.com/videos/world/2022/06/10/arwa-damon-leaving-cnn-ctw-intv-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 16:46:31+00:00

CNN's Becky Anderson and Arwa Damon discuss Arwa's career on her final day at CNN.

## Students overpower suspect after stabbing at Germany university
 - [https://www.cnn.com/2022/06/10/europe/germany-stabbing-intl/index.html](https://www.cnn.com/2022/06/10/europe/germany-stabbing-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 16:36:07+00:00

Students overpowered a man suspected of stabbing several people at Hamm-Lippstadt University of Applied Sciences in the northwestern German city of Hamm, police said Friday.

## Must-watch videos of the week
 - [https://www.cnn.com/collections/videos-of-the-week-061022/](https://www.cnn.com/collections/videos-of-the-week-061022/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 16:25:52+00:00



## Another big name joins controversial Saudi-backed golf tour
 - [https://www.cnn.com/2022/06/10/sport/bryson-dechambeau-joins-liv-golf-series-spt-intl/index.html](https://www.cnn.com/2022/06/10/sport/bryson-dechambeau-joins-liv-golf-series-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 16:20:36+00:00

Bryson DeChambeau is the latest big name player to join the Saudi-backed LIV Golf series, the breakaway competition announced on Friday.

## Johnny Depp and Jeff Beck announce joint album
 - [https://www.cnn.com/2022/06/10/entertainment/johnny-depp-jeff-beck-album/index.html](https://www.cnn.com/2022/06/10/entertainment/johnny-depp-jeff-beck-album/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 16:15:07+00:00

Johnny Depp and Jeff Beck are deepening their professional relationship.

## Putin tells us exactly what his endgame is in Ukraine
 - [https://www.cnn.com/collections/intl-ukraine-10-6/](https://www.cnn.com/collections/intl-ukraine-10-6/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 16:06:17+00:00



## Trump claims daughter Ivanka 'checked out' and wasn't looking at election results
 - [https://www.cnn.com/collections/int-0610-jan6/](https://www.cnn.com/collections/int-0610-jan6/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 15:46:55+00:00



## Every day, 17 people die waiting for a donor organ. 3D printers could change that
 - [https://www.cnn.com/2022/06/10/health/3d-printed-organs-bioprinting-life-itself-wellness-scn/index.html](https://www.cnn.com/2022/06/10/health/3d-printed-organs-bioprinting-life-itself-wellness-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 15:31:19+00:00

What if doctors could just print a kidney, using cells from the patient, instead of having to find a donor match and hope the patient's body doesn't reject the transplanted kidney?

## Mariupol at risk of cholera outbreak as Russia struggles to provide basic services, says UK intelligence
 - [https://www.cnn.com/2022/06/10/europe/ukraine-mariupol-potential-cholera-outbreak-intl/index.html](https://www.cnn.com/2022/06/10/europe/ukraine-mariupol-potential-cholera-outbreak-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 15:23:35+00:00

Ukraine's southern city of Mariupol, now fully under Russian control, is at risk of a cholera outbreak, according to a British intelligence report published Friday, echoing concerns of Ukrainian officials as Russia struggles to provide basic public services to civilian populations in areas it has occupied.

## Saudi money, blockbuster names and a unique format: everything you need to know about the LIV Golf series
 - [https://www.cnn.com/2022/06/10/sport/liv-golf-tournament-explainer-spt-intl/index.html](https://www.cnn.com/2022/06/10/sport/liv-golf-tournament-explainer-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 15:18:15+00:00

It's the hottest topic in the sport of golf: the LIV Golf series is already making waves -- and it's just one day old.

## Financial disclosures reveal book projects from Justices Neil Gorsuch and Amy Coney Barrett
 - [https://www.cnn.com/2022/06/10/politics/neil-gorsuch-amy-coney-barrett-book-projects/index.html](https://www.cnn.com/2022/06/10/politics/neil-gorsuch-amy-coney-barrett-book-projects/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 14:48:28+00:00

Supreme Court Justices Neil Gorsuch and Amy Coney Barrett received six-figure book advances last year for upcoming book projects, financial disclosure forms made public Thursday revealed.

## US will end Covid-19 testing requirement for air travelers entering the country
 - [https://www.cnn.com/2022/06/10/politics/us-to-end-pre-departure-testing-requirement/index.html](https://www.cnn.com/2022/06/10/politics/us-to-end-pre-departure-testing-requirement/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 14:47:42+00:00

The Biden administration is expected to announce Friday that the US Centers for Disease Control and Prevention will lift its requirement for travelers to test negative for Covid-19 before entering the US, according to a senior administration official.

## Former Fox political editor says he will testify at January 6 committee hearing
 - [https://www.cnn.com/2022/06/10/politics/former-fox-editor-january-6-commitee-hearing/index.html](https://www.cnn.com/2022/06/10/politics/former-fox-editor-january-6-commitee-hearing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 14:33:32+00:00

Chris Stirewalt, the former Fox political editor, said Friday that he will be a witness during the House January 6 committee's next public hearing on Monday.

## Secrets of a prize-winning Sicilian gelateria
 - [https://www.cnn.com/travel/article/gelateria-randazzo-sicily-musumeci/index.html](https://www.cnn.com/travel/article/gelateria-randazzo-sicily-musumeci/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 14:12:54+00:00

Pizza, pasta and gelato: the holy trinity of Italian food. And while the first two have conquered the rest of the world, no other country yet has succeeded in making gelato quite like the Italians do. A more intense form of ice cream, containing less dairy and served slightly warge.. and spring... and winter.

## Prince William goes undercover to highlight a big issue
 - [https://www.cnn.com/2022/06/10/world/royal-news-newsletter-06-10-22-scli-gbr-cmd-intl/index.html](https://www.cnn.com/2022/06/10/world/royal-news-newsletter-06-10-22-scli-gbr-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 14:04:00+00:00

Homelessness and long-term unemployment aren't problems we generally associate with the royals, who've been born into a job for life and enjoy all the security, grand palaces and state dinners that come with privilege.

## Britney Spears' ex-husband is arrested for trespassing at pop star's home ahead of wedding
 - [https://www.cnn.com/2022/06/10/entertainment/britney-spears-jason-alexander-trespass-wedding/index.html](https://www.cnn.com/2022/06/10/entertainment/britney-spears-jason-alexander-trespass-wedding/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 13:33:46+00:00

Britney Spears' ex-husband was arrested and charged with trespassing and battery after crashing her wedding Thursday at her California home, police said.

## Sexy trash cans? This Swedish city is taking a risqué approach to garbage
 - [https://www.cnn.com/travel/article/sexy-trash-cans-malmo-sweden-rubbish-intl-scli/index.html](https://www.cnn.com/travel/article/sexy-trash-cans-malmo-sweden-rubbish-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 13:24:26+00:00

The Swedish city of Malmö is taking dirty talk to a whole new level in its latest effort to clean up the streets.

## Southern California preparing for 'hotter, drier' wildfire season amid workforce shortages
 - [https://www.cnn.com/2022/06/10/weather/southern-california-wildfire-season/index.html](https://www.cnn.com/2022/06/10/weather/southern-california-wildfire-season/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 13:14:11+00:00

As the extended drought has left vegetation dry, brittle and ripe for burning, fire officials in Southern California are bracing for another challenging summer and fall of wildfires amid a shortage of firefighting crews and increased workloads.

## US military service member in Germany is military's first case of monkeypox
 - [https://www.cnn.com/2022/06/10/politics/us-military-monkeypox/index.html](https://www.cnn.com/2022/06/10/politics/us-military-monkeypox/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 13:11:11+00:00

An active-duty member of the US military based in Stuttgart, Germany has been identified as having the military's first known case of monkeypox, a US European Command spokesperson told CNN in a statement.

## George Conway reacts to Liz Cheney's message to the GOP
 - [https://www.cnn.com/videos/politics/2022/06/10/jan-6-hearing-george-conway-reaction-newday-keilar-vpx.cnn](https://www.cnn.com/videos/politics/2022/06/10/jan-6-hearing-george-conway-reaction-newday-keilar-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 12:29:46+00:00

CNN's Brianna Keilar and George Conway discuss his analysis after watching the January 6 hearing.

## Blood found in suspect's boat as Brazil searches for missing pair in remote Amazon
 - [https://www.cnn.com/2022/06/09/americas/dom-phillips-bruno-pereira-missing-blood-intl-latam/index.html](https://www.cnn.com/2022/06/09/americas/dom-phillips-bruno-pereira-missing-blood-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 12:18:25+00:00

Blood has been found in a boat owned by a suspect in the disappearance of a British journalist and indigenous affairs expert in a remote region of the Amazon, Brazil's federal police said Thursday.

## How far will Operation Fly Formula shipments really go to fill America's store shelves?
 - [https://www.cnn.com/2022/06/10/health/operation-fly-formula-impact/index.html](https://www.cnn.com/2022/06/10/health/operation-fly-formula-impact/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 11:57:43+00:00

The first shipments from the federal government's Operation Fly Formula will bring a total of nearly 1 million pounds of baby formula powder into the United States. That's just a fraction of what the nation's families need -- about the same amount of formula typically sold over two days in the US -- but it is a jump-start to easing the shortage.

## Starbucks may close its bathrooms to the public again
 - [https://www.cnn.com/2022/06/10/business-food/howard-schultz-starbucks-bathrooms/index.html](https://www.cnn.com/2022/06/10/business-food/howard-schultz-starbucks-bathrooms/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 11:54:42+00:00

Starbucks CEO Howard Schultz says his company might not be able to keep its bathrooms open to the general public.

## Liz Cheney's huge moment
 - [https://www.cnn.com/2022/06/10/opinions/liz-cheney-january-6-committee-hearing-jennings/index.html](https://www.cnn.com/2022/06/10/opinions/liz-cheney-january-6-committee-hearing-jennings/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 11:14:03+00:00

I've been wondering who the House select committee investigating the January 6 riot sees as its primary audience. On Thursday night, it was pretty clear: Attorney General Merrick Garland. I am sure the committee members would love to change public opinion (which hardened fairly quickly in the weeks after the attack on the Capitol) and to convince Republicans that former President Donald Trump cannot be trusted again with the presidency.

## LeBron James sets his sights on owning an NBA team in Las Vegas
 - [https://www.cnn.com/2022/06/10/sport/lebron-james-nba-owner-las-vegas-spt-intl/index.html](https://www.cnn.com/2022/06/10/sport/lebron-james-nba-owner-las-vegas-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 09:56:21+00:00

Newly minted billionaire and basketball star LeBron James has long expressed an interest in becoming an NBA owner and he reveals his plans in the latest episode of the talk show "The Shop."

## Rebel Wilson says she's dating a woman after finding her 'Disney Princess'
 - [https://www.cnn.com/2022/06/10/entertainment/rebel-wilson-dating-ramona-agruma-intl-scli/index.html](https://www.cnn.com/2022/06/10/entertainment/rebel-wilson-dating-ramona-agruma-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 09:25:42+00:00

Rebel Wilson has revealed that she is a member of the LGBTQ community during Pride Month by introducing the world to her "Disney Princess."

## Why Russia is being accused of using food as a weapon of war
 - [https://www.cnn.com/2022/06/10/europe/food-grain-crisis-ukraine-russia-intl/index.html](https://www.cnn.com/2022/06/10/europe/food-grain-crisis-ukraine-russia-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 09:08:59+00:00

Russia's war in Ukraine could push up to 49 million people into famine or famine-like conditions because of its devastating impact on global food supply and prices, the United Nations has said, in the latest dire warning over food insecurity.

## China's economy is looking brighter but it's not in the clear yet
 - [https://www.cnn.com/2022/06/10/economy/china-economy-recovery-tech-trade-intl-hnk/index.html](https://www.cnn.com/2022/06/10/economy/china-economy-recovery-tech-trade-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 09:04:48+00:00

From big gains in tech stocks to robust trade data, China has had plenty of good news on the economic front this week.

## Shohei Ohtani's pitching and bat help Los Angeles Angels end 14-game losing run
 - [https://www.cnn.com/2022/06/10/sport/shohei-ohtani-los-angeles-angels-losing-run-spt-intl/index.html](https://www.cnn.com/2022/06/10/sport/shohei-ohtani-los-angeles-angels-losing-run-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 08:56:20+00:00

Led by Shohei Ohtani's pitching and bat, the Los Angeles Angels ended a 14-game losing streak as they defeated the Boston Red Sox 5-2 on Thursday.

## From the 'Clapper' to arsenic wallpaper, why objects go extinct
 - [https://www.cnn.com/style/article/extinct-obsolete-objects-design/index.html](https://www.cnn.com/style/article/extinct-obsolete-objects-design/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 08:34:41+00:00

The "Clapper", literal snail mail, anti-gravity underwear -- there are reasons why all of these objects are extinct. But now, a new book is exhuming them from the trash heap of history.

## Two ultra-athletes just ran the border of an entire country in 16 days
 - [https://www.cnn.com/2022/06/10/sport/navigate-lesotho-ultra-runners-ryan-sandes-ryno-griesel-spc-spt-intl/index.html](https://www.cnn.com/2022/06/10/sport/navigate-lesotho-ultra-runners-ryan-sandes-ryno-griesel-spc-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 07:42:52+00:00

There wasn't a hint of exhaustion on Ryan Sandes' face during a recent CNN interview with the decorated ultra-athlete in his Cape Town home. You'd never guess he had recently returned from an epic 16-day run along the mostly uncharted mountains of Lesotho's borders -- until he took off his shoes.

## Malaysia to abolish mandatory death penalty in move welcomed by rights campaigners
 - [https://www.cnn.com/2022/06/10/asia/malaysia-death-penalty-abolish-human-rights-intl-hnk/index.html](https://www.cnn.com/2022/06/10/asia/malaysia-death-penalty-abolish-human-rights-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 07:16:03+00:00

Malaysia will abolish the mandatory death penalty, the government said Friday, in a move cautiously welcomed by rights groups as a rare progressive step on the issue for the region.

## 'More work to be done': Key takeaways from the WHO report on origins of the Covid-19 pandemic
 - [https://www.cnn.com/2022/06/10/china/who-covid-pandemic-origins-report-intl-hnk/index.html](https://www.cnn.com/2022/06/10/china/who-covid-pandemic-origins-report-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 07:15:52+00:00

A team of international scientists tasked with understanding how the coronavirus pandemic began released their first report on Thursday, saying that all hypothesis remain on the table, including a possible laboratory incident.

## A missing child was found alive after more than 40 years. But the search continues for her parents' killers, police say
 - [https://www.cnn.com/2022/06/10/us/missing-daughter-found-alive-investigation/index.html](https://www.cnn.com/2022/06/10/us/missing-daughter-found-alive-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 06:54:15+00:00

A woman who was turned over to officials at an Arizona church as a baby more than four decades ago has been identified through DNA as the daughter of a Florida couple whose murdered bodies were found in Texas in 1981, officials said Thursday.

## Panic buying in Shanghai as mass testing notices spark fears of new lockdown
 - [https://www.cnn.com/2022/06/10/china/china-covid-shanghai-mass-testing-intl-hnk/index.html](https://www.cnn.com/2022/06/10/china/china-covid-shanghai-mass-testing-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 06:51:10+00:00

Shanghai will carry out Covid-19 testing on more than half of its 25 million residents this weekend, fueling fears of a return to more stringent restrictions just days after the financial hub emerged from two months of painful lockdown.

## The clearest case yet that Trump concocted a conspiracy
 - [https://www.cnn.com/2022/06/10/politics/january-6-hearing-donald-trump/index.html](https://www.cnn.com/2022/06/10/politics/january-6-hearing-donald-trump/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 05:35:37+00:00

Seventeen months fell away in an instant.

## Why Chinese warplanes are 'playing chicken' with US allies — and why they're doing it now
 - [https://www.cnn.com/2022/06/10/asia/shangri-la-dialogue-china-targeting-us-allies-intl-hnk-mic-ml/index.html](https://www.cnn.com/2022/06/10/asia/shangri-la-dialogue-china-targeting-us-allies-intl-hnk-mic-ml/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 04:46:38+00:00

• Naval base upgrade in Cambodia by China has the West worried

## Cheney shows testimony from Ivanka Trump, Bill Barr and Jason Miller
 - [https://www.cnn.com/videos/politics/2022/06/09/liz-cheney-opening-statement-trump-allies-testimony-clips-2022-january-6-hearings-vpx.cnn](https://www.cnn.com/videos/politics/2022/06/09/liz-cheney-opening-statement-trump-allies-testimony-clips-2022-january-6-hearings-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 03:03:41+00:00

Rep. Liz Cheney (R-WY) shows testimony from President Trump's allies, including his Attorney General Bill Barr and daughter Ivanka Trump, during the House January 6 select committee's first hearing.

## Committee plays never-before-seen Jan 6th video footage
 - [https://www.cnn.com/videos/politics/2022/06/09/new-produced-video-capitol-riot-2022-january-6-hearings-vpx.cnn](https://www.cnn.com/videos/politics/2022/06/09/new-produced-video-capitol-riot-2022-january-6-hearings-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 02:49:53+00:00

The January 6 committee presents a pre-produced, previously unseen video showing the day of Jan. 6, 2021 in chronological order, starting in the morning before the Capitol was breached.

## How glamping became China's hottest new travel trend
 - [https://www.cnn.com/travel/article/glamping-china-trend-cmb-intl-hnk/index.html](https://www.cnn.com/travel/article/glamping-china-trend-cmb-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 02:18:43+00:00

"Every grassland is covered with tents during weekends," says 26-year-old glamping enthusiast Yoga Song.

## Mysterious creature caught on camera has authorities asking for help
 - [https://www.cnn.com/videos/us/2022/06/09/strange-object-sighting-wolfman-on-the-prowl-moos-pkg-vpx.cnn](https://www.cnn.com/videos/us/2022/06/09/strange-object-sighting-wolfman-on-the-prowl-moos-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 00:08:59+00:00

What is this mystery creature? CNN's Jeanne Moos reports a Texas city is asking the public to help ID it.

## Perseverance rover has made a friend on Mars
 - [https://www.cnn.com/2022/06/09/world/perseverance-pet-rock-mars-scn/index.html](https://www.cnn.com/2022/06/09/world/perseverance-pet-rock-mars-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-10 00:06:31+00:00

The Perseverance rover made friends with a pet rock about four months ago, and the two have been inseparable ever since.


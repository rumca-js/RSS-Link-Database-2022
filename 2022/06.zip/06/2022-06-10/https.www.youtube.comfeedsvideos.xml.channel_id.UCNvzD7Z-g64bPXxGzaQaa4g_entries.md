# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Late Night Gamer CONFESSIONS We Finally Admitted
 - [https://www.youtube.com/watch?v=EkYYSkwL25c](https://www.youtube.com/watch?v=EkYYSkwL25c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-11 00:00:00+00:00

Playing games late at night is often more troublesome than you'd think.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## NEW SUMMER FEST GAME REVEALS, EA STICKING WITH BF2042, & MORE
 - [https://www.youtube.com/watch?v=jxMyt0H51j8](https://www.youtube.com/watch?v=jxMyt0H51j8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-10 00:00:00+00:00

Sponsored by Raycon. Go to https://buyraycon.com/gameranx for 15% off your order!

Summer Game Fest is in full swing with new game reveals, release date announcements, updates, and more. Featuring a special guest.

Follow SkillUp: https://www.youtube.com/c/SkillUp
Twitter: https://twitter.com/SkillUpYT?s=20&t=tyluBHlVMeyGEF0-YipVDA



~~~~STORIES~~~~~

Full Summer Game fest presentation: https://youtu.be/RFO4BJbdpPg

Devolver showcase: https://youtu.be/jzTFX8wyoLA

SUMMER GAME FEST SCHEDULE: https://www.videogameschronicle.com/news/summer-game-fest-schedule/


Cyberpunk Netflix anime
https://www.ign.com/articles/cyberpunk-edgerunners-anime-netflix-first-look

Halo co op campaign coming (next month)
https://kotaku.com/halo-infinite-campaign-co-op-network-beta-test-season-t-1849031399

Best video game soundtrack a Grammy category
https://www.grammy.com/news/2023-grammys-new-categories-songwriter-year-best-video-game-soundtrack-social-impact-special-merit-award-65th-grammy-awards?fs=e&s=cl&fs=e&s=cl

EA not abandoning BF 2042
https://www.eurogamer.net/ea-refutes-new-report-claiming-battlefield-2042-development-now-in-abandon-ship-mode

The Quarry before you buy 
https://youtu.be/TuMCrCj6lrk

E3 returns next year
https://www.gamespot.com/articles/e3-will-return-in-2023-as-a-physical-and-digital-show/1100-6504245/?ftag=CAD-01-10abi2f




#summergamefest2022


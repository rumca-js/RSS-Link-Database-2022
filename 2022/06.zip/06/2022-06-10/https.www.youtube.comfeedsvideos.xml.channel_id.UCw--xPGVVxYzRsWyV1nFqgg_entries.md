# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Gentlemen Bastards RETURNS!😲 Night Angel RETURNS!🥷 One Piece... Ending😔-FANTASY NEWS
 - [https://www.youtube.com/watch?v=NUbfLmdbU3E](https://www.youtube.com/watch?v=NUbfLmdbU3E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-06-10 00:00:00+00:00

LET'S JUMP INTO THE FANTASY NEWS! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


NEWS: 

00:00 intro

00:24 NIGHT ANGEL NEMESIS: https://twitter.com/brentweeks/status/1533891278051520514?s=21&t=RgBievUiH00ZOMDfKzBOYw 

01:09 Gentlemen Bastards Update: https://twitter.com/scottlynch78/status/1534812612155817984?s=20&t=MiZDNaTSEeekKvyyyQ7a5g  

02:50 Cyberpunk Edgerunners: https://www.youtube.com/watch?v=FPDJJIPuCgE&ab_channel=Netflix 

03:35 Warhammer interview: https://www.warhammer-community.com/2022/06/08/dan-abnett-interview-how-to-start-and-finish-the-most-epic-series-in-sci-fi/ 

04:11 Full Berserk Coverage: https://www.youtube.com/watch?v=w5cEAsMUYZk&ab_channel=DanielGreene 

04:46 One Piece’s Final Saga: https://twitter.com/newworldartur/status/1534493111669366784?s=20&t=Vga_mJVIKgexdHPdBwuWbQ 

05:57 One Piece Sets: https://www.youtube.com/watch?v=Y_zpkX3Z3hk&ab_channel=Netflix 

06:12 What We Do In The Shadows renewed for 5 & 6: https://tvline.com/2022/06/06/what-we-do-in-the-shadows-renewed-season-5-and-6-fx/ 

06:40 REBEL MOON: https://twitter.com/DiscussingFilm/status/1534598093689303040 

07:20 Joker Returns: https://www.instagram.com/p/CehX0rGPxQi/?igshid=YmMyMTA2M2Y%3D 

08:35 Prey Trailer: https://www.youtube.com/watch?v=wZ7LytagKlc&ab_channel=20thCenturyStudios 
https://twitter.com/lotronprime/status/1534220750311174144?s=21&t=LlYl4XVlil2EQ3RGDOYkcQ


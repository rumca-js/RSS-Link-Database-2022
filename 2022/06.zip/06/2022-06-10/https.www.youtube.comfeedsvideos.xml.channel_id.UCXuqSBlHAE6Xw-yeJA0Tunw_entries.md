# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This 3450W Power Supply is a Fire Hazard!
 - [https://www.youtube.com/watch?v=IGgafqmq7IE](https://www.youtube.com/watch?v=IGgafqmq7IE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-11 00:00:00+00:00

You can get 50% off your first month of KiwiCo at: http://kiwico.com/LTT

How sketchy is a 3450W PSU from Banggood? Shockingly bad.

Discuss on the forum: https://linustechtips.com/topic/1436588-this-banggood-psu-is-literally-a-fire-hazard/

Buy an ASUS TUF RTX 3080: https://geni.us/Bbxlo
Buy an ASUS STRIX RTX 3080: https://geni.us/Kz5TX
Buy an MSI Gaming X Trio RTX 3080: https://geni.us/4bDVt
Buy an Gigabyte AORUS RTX 3080: https://geni.us/B5LEb58
Buy an Zotac Trinity OC RTX 3080: https://geni.us/KgFTR

Purchases made through some store links may provide some compensation to Linus Media Group.


► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 - Fire Hazard? No this is the Intro.
1:08 - A little look at your big PSU
3:05 - Opening the PSU
5:55 - Missing Components
7:13 - Resoldering
9:00 - Alex's terrifying power meter
11:11 - Powering on
12:50 - Adding more GPUs
15:29 - Adding a Threadripper
17:11 - The Moment of Truth
18:45 - KiwiCo!
19:51 - Outro

## I Called It 12 Years Ago - WAN Show June 10, 2022
 - [https://www.youtube.com/watch?v=04aNA5rLXEk](https://www.youtube.com/watch?v=04aNA5rLXEk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-10 00:00:00+00:00

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off
Try Vultr today with an exclusive 30-day $100 code for signing up at https://getvultr.com/LTT
Save 10% on XSplit's video tools at https://lmg.gg/xsplit

Check out Ivan’s GPUs available for auction below. All proceeds will go to SOS Children’s Villages, Ukraine

All proceeds go to SOS Children’s Villages, more information at https://lmg.gg/sosabout 
Donate to SOS Children’s Villages today at https://lmg.gg/soscharity

Star Wars special edition TITAN Xp: https://www.ebay.ca/itm/175306445056
Turtle Beach Montego: https://www.ebay.ca/itm/175306436950
EVGA GTX 580: https://www.ebay.ca/itm/175306436691
ATI X850 XT: https://www.ebay.ca/itm/175306436043

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/I-Called-It-12-Years-Ago---WAN-Show-June-10--2022-e1jt4ro

Timestamps: (Courtesy of Bip Bop)
0:00 Greetings
1:17 Intro
1:39 sponsors
1:45 First topic SSD
12:20 Summer Game Fest
21:18 Dream NAS controversy
21:25 controversal collab list
22:25 Linus starts talking chair adjustments during Dream topic
23:42 return to Dream
35:00 segue from keep giving us feedback, like Dream to LMG is so big
36:17 Riley or Anthony's take on Dream
41:32 Merch message labs impact on sponsors 
41:40 screwdriver controversy 
46:35 Bill C11
49:20 screwdriver poll update
56:56 FP comment
1:00:14 screwdriver poll
1:05:10 pop up shop
1:07:50 Lab2 News Community LAN party
1:22:15 Sponsor Block
1:24:51 inquiry AC at LAN , AC, weather discussion
1:30:40 Linus echo
1:31:48 good now
1:31:52 Merch messages
1:33:16 Inflation impact on Creator Warehouse
1:38:31 gas prices impact on electric vehicles
1:40:46 Yvonne's LMG impact (don't miss this)
1:49:49 3D Printed Homes
1:50:21 iPad OS floating windows or anything announced
1:51:36 Gaming on Mac
1:53:51 Horst in dock about WWDC2022
1:57:06 Why LMG does YT Shorts
2:02:06 Ivan's Ukraine charity GPU auction
2:04:02 Merch Messages
2:04:08 New (future) LTT products
2:04:22 broken cap water bottle
2:04:42 New products
2:06:03 screwdriver shaft oxide coating?
2:06:27 Pool tech?
2:09:04 Floatplane:  Actman demonitized on YouTube
2:10:06 Pool, heat exchange HVAC
2:11:11 Jasco(sp?) update
2:11:30 2 mini unboxings? another time
2:11:38 m.m. concrete thermal conductivity? More pool cooling


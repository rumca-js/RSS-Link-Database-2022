# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "Emotional Damage!" (Instrumental)
 - [https://www.youtube.com/watch?v=DcXIJCcCrUM](https://www.youtube.com/watch?v=DcXIJCcCrUM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2022-06-11 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong 
Watch the remix: https://youtu.be/59QzKeb6lU8
Created on @teenageengineering OP-1
and completed in Logic Pro X using stock plugins and instruments.

## "Emotional Damage!" (Full Song)
 - [https://www.youtube.com/watch?v=492p1wTEpOw](https://www.youtube.com/watch?v=492p1wTEpOw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2022-06-10 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong 
Watch the remix: https://youtu.be/59QzKeb6lU8
Created on @teenageengineering OP-1
and completed in Logic Pro X using stock plugins and instruments.


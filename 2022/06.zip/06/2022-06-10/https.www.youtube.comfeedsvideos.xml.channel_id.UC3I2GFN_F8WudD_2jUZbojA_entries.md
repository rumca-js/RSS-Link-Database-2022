# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Charlotte Adigéry & Bolis Pupul - Blenda (Live on KEXP)
 - [https://www.youtube.com/watch?v=MQYS77PjnA0](https://www.youtube.com/watch?v=MQYS77PjnA0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-10 00:00:00+00:00

http://KEXP.ORG presents Charlotte Adigéry & Bolis Pupul performing “Blenda” live in the KEXP studio. Recorded May 20, 2022.

Charlotte Adigéry - Vocals
Bolis Pupul - Keys / Guitar / Vocals

Host: Larry Mizell, Jr.
Audio Engineers: Kevin Suggs & Nico Van Der Eeken
Audio Mixer: Nico Van Der Eeken
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://charlotteandbolis.com
http://kexp.org

## Charlotte Adigéry & Bolis Pupul - Ceci n'est pas un cliché (Live on KEXP)
 - [https://www.youtube.com/watch?v=M0sWDifk6zI](https://www.youtube.com/watch?v=M0sWDifk6zI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-10 00:00:00+00:00

http://KEXP.ORG presents Charlotte Adigéry & Bolis Pupul performing “Ceci n'est pas un cliché” live in the KEXP studio. Recorded May 20, 2022.

Charlotte Adigéry - Vocals
Bolis Pupul - Keys / Guitar / Vocals

Host: Larry Mizell, Jr.
Audio Engineers: Kevin Suggs & Nico Van Der Eeken
Audio Mixer: Nico Van Der Eeken
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://charlotteandbolis.com
http://kexp.org

## Charlotte Adigéry & Bolis Pupul - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=9poMU5bcE14](https://www.youtube.com/watch?v=9poMU5bcE14)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-10 00:00:00+00:00

http://KEXP.ORG presents Charlotte Adigéry & Bolis Pupul performing live in the KEXP studio. Recorded May 20, 2022.

Songs:
Blenda
Making Sense Stop
Haha
Ceci n’est pas un cliché

Charlotte Adigéry - Vocals
Bolis Pupul - Keys / Guitar / Vocals

Host: Larry Mizell, Jr.
Audio Engineers: Kevin Suggs & Nico Van Der Eeken
Audio Mixer: Nico Van Der Eeken
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://charlotteandbolis.com
http://kexp.org

## Charlotte Adigéry & Bolis Pupul - HAHA (Live on KEXP)
 - [https://www.youtube.com/watch?v=ZzR6Y0rcTCc](https://www.youtube.com/watch?v=ZzR6Y0rcTCc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-10 00:00:00+00:00

http://KEXP.ORG presents Charlotte Adigéry & Bolis Pupul performing “HAHA” live in the KEXP studio. Recorded May 20, 2022.

Charlotte Adigéry - Vocals
Bolis Pupul - Keys / Guitar / Vocals

Host: Larry Mizell, Jr.
Audio Engineers: Kevin Suggs & Nico Van Der Eeken
Audio Mixer: Nico Van Der Eeken
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://charlotteandbolis.com
http://kexp.org

## Charlotte Adigéry & Bolis Pupul - Making Sense Stop (Live on KEXP)
 - [https://www.youtube.com/watch?v=12a6kC_lf-4](https://www.youtube.com/watch?v=12a6kC_lf-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-10 00:00:00+00:00

http://KEXP.ORG presents Charlotte Adigéry & Bolis Pupul performing “Making Sense Stop” live in the KEXP studio. Recorded May 20, 2022.

Charlotte Adigéry - Vocals
Bolis Pupul - Keys / Guitar / Vocals

Host: Larry Mizell, Jr.
Audio Engineers: Kevin Suggs & Nico Van Der Eeken
Audio Mixer: Nico Van Der Eeken
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://charlotteandbolis.com
http://kexp.org


# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## This CNN Hero solves an often invisible problem by providing 'Undies for Everyone'
 - [https://www.cnn.com/2022/06/09/us/texas-rabbi-underwear-dignity-cnnheroes/index.html](https://www.cnn.com/2022/06/09/us/texas-rabbi-underwear-dignity-cnnheroes/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-06-10 00:19:05+00:00

It's not every day you meet a rabbi from Texas with a thing for underwear.


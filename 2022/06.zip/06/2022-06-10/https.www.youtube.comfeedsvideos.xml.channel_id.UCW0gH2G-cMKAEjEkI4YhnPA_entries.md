# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Life of Samwise Gamgee | Tolkien Explained
 - [https://www.youtube.com/watch?v=2DJV_39kaPw](https://www.youtube.com/watch?v=2DJV_39kaPw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-06-11 00:00:00+00:00

Tolkien called him the "chief hero" of The Lord of the Rings.  Samwise Gamgee journeys from being a humble servant to trusted companion to ringbearer and hero.   We cover his entire life beyond the War of the Ring - helping restore the Shire, serving as Mayor, and travels to Gondor.

Today's video is brought to you by SlideBelts!
Save 20% at https://slidebelts.com with the code: NERDOFTHERINGS

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri
Noe Leyva - https://twitter.com/NoeLeyvArt

Mount Doom - Tolman Cotton
Sam in the Garden - Tolman Cotton
Sam and Shelob - John Howe
Frodo and Sam in Mordor - Andrea Piparo
Sam and Rosie Cotton - Ted Nasmith
Hobbit Hole - 
Evening in the Shire - Kuliszu
Samwise Gamgee - Matthew Stewart
But I don't regret, nor will I forget - AnotherStrangerMe
Gaffer Gamgee - Catherine Karina Chmiel
A Hobbit's Garden - Emily Austin
In the Garden of Bag End - Matej Cadil
Bilbo's Tales - Tolman Cotton
Gandalf returns to Hobbiton - John Howe
Merry Brandybuck - Elrodimus Flash
Four Hobbits - Elrodimus Flash
Gandalf, Frodo, and the Ring - Elrodimus Flash
The Visitor - Aronja Art
Eavesdropping - Tolman Cotton
Shadows of the Past - Andrea Piparo
Gandalf, A Light in the Dark - Matthew Stewart
Shire Map - Maxime Plasse
Gildor, Sam, Pippin, Frodo, and Elves - Steamey
Three is Company - Kuliszu
Sam - Tolman Cotton
A Conspiracy Unmasked - Tolman Cotton
Three is Company - Anke Eissmann
Fatty Bolger - Tolman Cotton
Old Man Willow, Merry & Pippin - Elrodimus Flash
Hobbits and Tree - Andrea Piparo
Tom Bombadil - Anke Eissmann
In the house of Tom Bombadil - Anke Eissmann
Barrow Downs - Andrea Piparo
Strider - Anke Eissmann
At the Sign of the Prancing Pony - Ted Nasmith
Sam & Bill - Emily Austin
Sam and Bill - Elrodimus Flash
Gandalf and Frodo in Rivendell - Anke Eissmann
Hiding from Black Rider - Anke Eissmann
Council of Elrond - Alan Lee
The Fellowship of the Ring - Catherine Karina Chmiel
The Fellowship of the Ring - Kuliszu
Sam & Bill - Kuliszu
The Fellowship of the Ring - Anke Eissmann
Caradhras Pass - Ivan Cavini
Fellowship vs Wargs - Catherine Karina Chmiel
Door of Moria - Ralph Damiani
The West Gate of Moria - Alan Lee
Bill the Pony - Jenny Dolfen
The Watcher in the Water - Olanda Fong-Surdenas
Moria - Angus McBride
Galadriel - John Howe
The Mirror of Galadriel - Alan Lee
The Mirror of Galadriel - Aegeri
Galadriel - Aegeri
Mirror of Galadriel - Kuliszu
The Gifts of Galadriel - Kuliszu
Sam's Garden Box - Matej Cadil
The Anduin River - Ralph Damiani
Hobbits and Gollum - Andrea Piparo
The Black Gate is Closed - Alan Lee
Cooking Rabbit - Jenny Dolfen
Ithilien Ranger - Elrodimus Flash
An Oliphaunt - Alan Lee
The Fallen - Tolman Cotton
The Window on the West - Ted Nasmith
Faramir - Anke Eissmann
Faramir Bids Farewell - Anke Eissmann
Encounter with Faramir - Anke Eissmann
Courage - Olanda Fong-Surdenas
Sam vs Shelob - Matej Cadil
Shelob's Retreat - Ted Nasmith
Shelob - Ted Nasmith
The Choices of Master Samwise - Tolman Cotton
The Tower of Cirith Ungol - Matej Cadil
Cirith Ungol - Lida Holubova
I will not say the day is done - Matthew Stewart
Lorien - Ralph Damiani
Lorien at night - Ralph Damiani
Minas Morgul - Ralph Damiani
Stargazing - Anke Eissmann
Mount Doom - Olanda Fong-Surdenas
Mount Doom - Tolman Cotton
Gollum and Sam - Elrodimus Flash
Endgame on the Mountain - Ted Nasmith
At the Cracks of Doom - Ted Nasmith
At the Foot of Mount Doom - Ted Nasmith
The Field of Cormallen - Tolman Cotton
The Crowning of Elessar - Tolman Cotton
Arwen and Aragorn - Catherine Karina Chmiel
Homeward Bound - Tolman Cotton
The Scouring of the Shire - Tolman Cotton
Green Hill Morning - Ted Nasmith
The Birthday Speech - Matthew Stewart
Sam's Mallorn Tree - Matej Cadil
Sam and Rosie - Tolman Cotton
Mallorn - Ted Nasmith
The Grey Havens - Aronja Art
Bag End - Aronja Art
Library - Bryan Bitter
Strider - AnotherStrangerMe
Hobbiton - Catherine Karina Chmiel
Minas Tirith - Ralph Damiani
Epilogue - Sam & Rosie - Tolman Cotton
Bilbo Leaves Bag End - Elrodimus Flash
The Grey Havens - Matthew Stewart
The Shores of Valinor - Ted Nasmith

For more on Sam Gamgee, check out these great resources:
The Lord of the Rings
Tolkien Gateway
Encyclopedia of Arda

#samwise #lordoftherings #tolkien

## My Hopes and Fears for The Rings of Power
 - [https://www.youtube.com/watch?v=RlxLmkwcut4](https://www.youtube.com/watch?v=RlxLmkwcut4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-06-10 00:00:00+00:00

For some time, I've wanted to make a video discussing my hopes and fears for Rings of Power.  While I've mentioned nearly all of these in previous livestreams and breakdowns, I wanted to compile them for those who may not have caught my previous conversations.  With less than three months until it's premiere, and with the ability to talk more about what I heard and saw in London, I thought it would be a great time to dive into my hopes and fears for this series...

00:00-00:55 Intro
00:55-02:20 1) A Game of Rings
02:20-03:56 2) Time Compression
03:56-05:48 3)Politics
05:48-07:37 4) Durins's Folk
07:37-08:24 5) John Howe
08:24-09:51 6) The Look
09:51-11:30 7) Harfoots
11:30-14:32 8) Showrunners
14:32-16:22 9) Canon & Non-canon
16:22-17:04 10) Canon Moments
17:04-18:44 11) Galadriel
18:44-21:24 12) Marketing
21:24-24:00 Conclusion
24:00-24:52 Quick bits

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Kip Rasmussen - https://www.kiprasmussen.com/
Ralph Damiani - https://www.artstation.com/ralphdamiani

Imperial Numenorean - Turner Mohan
Numenorean Armor - Turner Mohan
Armenelos - Ralph Damiani
Ar-Pharazon - Turner Mohan
Durin I Discovers the Three Peaks - Ted Nasmith
Sauron the Deceiver - Skullb*st*rd
The Forging - Ralph Damiani
The Battle of the Five Armies - Alan Lee
Rivendell - Ivan Cavini
Andunie - Ralph Damiani
Sauron bows, submits to Ar-Pharazon - Kip Rasmussen
Isildur steals the Last Fruit of Nimloth - Sara M Morello
Drowning of Numenor - John Howe
Minas Tirith - Ralph Damiani
Minas Ithil - Shadow of War
Last Alliance - Skullb*st*rd
Gil-galad, Sauron, Elendil - Tom Romain
Isildur's Bane - Andrea Piparo
Doors of Durin - Ralph Damiani
Orthanc - Ralph Damiani
Artanis and Feanor - Tolman Cotton
The Oath of Feanor - Bella Bergolts

#lordoftherings #ringsofpower #tolkien


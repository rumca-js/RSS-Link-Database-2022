## #14 Może i wjechał w nas TIR ale zrobiliśmy 2 hajki z @vlogcasha
 - [https://www.youtube.com/watch?v=HJN7unYt-6I](https://www.youtube.com/watch?v=HJN7unYt-6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIFlYVfPnvukmFOvC4JUfOg
 - date published: 2022-06-11 00:00:00+00:00

Ten dzień za dobrze się nie zaczął ale jeżeli śledzicie ten kanał na bieżąco to wiecie, że to nic nowego, do pozytywów trzeba zaliczyć 2 udane hajki i przepyszne żeberka.
🧗🏻Wesprzyj moje przygody na patronite: https://patronite.pl/Nejtan
📷 Instagram: https://www.instagram.com/nejthan
📜 Napisz do mnie: swiatwedlugnejtana@gmail.com
🎵 Muzyka: https://share.epidemicsound.com/m7uq26

2022 Trip z  @vlogcasha    po Florydzie https://bit.ly/3uueZGV
2021 Trip z  @vlogcasha    po zachodzie Usa i Alaska
https://bit.ly/3D6ClpI
#swiatwedlugnejtana #nejtan


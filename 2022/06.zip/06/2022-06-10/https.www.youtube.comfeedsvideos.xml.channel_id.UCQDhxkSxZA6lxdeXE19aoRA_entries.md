# Source:Hugh Jeffreys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA, language:en-US

## Hilarious Fake Galaxy S22 Ultra With Sketchy Hidden Apps
 - [https://www.youtube.com/watch?v=mofiQ7EGBH8](https://www.youtube.com/watch?v=mofiQ7EGBH8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQDhxkSxZA6lxdeXE19aoRA
 - date published: 2022-06-11 00:00:00+00:00

I purchased an S22 Ultra from AliExpress and this is what I got. Hope you get a good laugh out of it
--------------------------------------Socials-------------------------------------
Website: https://www.hughjeffreys.com
Store: https://www.hughjeffreys.com/store
Instagram: http://instagram.com/hughjeffreys
---------------------------------------Links---------------------------------------
Get parts, tools and repair guides at iFixit:
Shop US: https://iFixit.com/hughjeffreys
Shop AU: https://ifix.gd/hughjeffreysau

Tools I Use: https://www.hughjeffreys.com/tools
---------------------------------------------------------------------------------------


(DISCLAIMER: This description contains affiliate links, which means that if you click on one of the product links, l will receive a small commission.)


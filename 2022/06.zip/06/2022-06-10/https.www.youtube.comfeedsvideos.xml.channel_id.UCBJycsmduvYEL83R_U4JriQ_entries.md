# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## This Was Ahead of its Time!
 - [https://www.youtube.com/watch?v=xcjZvAFBH_Y](https://www.youtube.com/watch?v=xcjZvAFBH_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-06-11 00:00:00+00:00

Top 3 Gadgets that were ahead of their time, and why they'll reappear in our future 👀

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro track: 1AM OMW by Ballpoint
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


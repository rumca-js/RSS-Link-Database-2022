# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## The REAL Reason We Locked Down
 - [https://www.youtube.com/watch?v=HpVTj9OMSgA](https://www.youtube.com/watch?v=HpVTj9OMSgA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-11 00:00:00+00:00

I recently had Matt Stoller on my podcast explaining how US policy makers only noticed covid when stocks went down & how money determines how we think about policy. #COVID #Pandemic #money 

Check Out Matt's New Book: Goliath - The 100-Year War Between Monopoly Power and Democracy 
https://www.barnesandnoble.com/w/goliath-matt-stoller/1131502306;jsessionid=DC6399804FB946115CD0CE3C13A2E7EF.prodny_store01-atgap14?ean=9781501182891&st=AFF&2sid=Simon%20&%20Schuster_7567305_NA&sourceId=AFFSimon%20&%20Schuster

Tickets now on sale for my 1 day event COMMUNITY in Hay-on-Wye. I'm joined by Wim, Vandana Shiva for conversations on spirituality, wellness, healthy living and our environment. Get your tickets bit.ly/3xoHQPv

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## If you thought DAVOS Was Scary - WATCH THIS Next Level SH*T!!!
 - [https://www.youtube.com/watch?v=P02GtDoqkJQ](https://www.youtube.com/watch?v=P02GtDoqkJQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-06-10 00:00:00+00:00

Original Davos, the Bilderberg Group is back after two-year pandemic gap. With elites from the world of politics, media, Big Tech, business in attendance, is this the time for yet another notoriously secret meeting between the world’s most powerful people? #bilderberg #davos #wef 

References
https://reclaimthenet.org/bilderberg-group-meets-in-secret-to-discuss-disinformation/
https://www.theguardian.com/world/2022/jun/04/bilderberg-reconvenes-in-person-after-two-year-pandemic-gap
--------------------------------------------------------------------------------------------------------------------------
Tickets now on sale for my 1 day event COMMUNITY in Hay-on-Wye. I'm joined by Wim, Vandana Shiva for conversations on spirituality, wellness, healthy living and our environment. Get your tickets bit.ly/3xoHQPv

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


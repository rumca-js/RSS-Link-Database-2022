# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Made on MASCHINE: A Musical Collection
 - [https://www.youtube.com/watch?v=gLb5szQVysg](https://www.youtube.com/watch?v=gLb5szQVysg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-06-10 00:00:00+00:00

A collection of tracks I made on Native Instruments MASCHINE + 
Some of these come from longer walkthroughs that were made for the Native Instruments YouTube channel. Check out my full playlist of MASCHINE + content, including my stuff and the stuff I made for NI, here: https://www.youtube.com/playlist?list=PLcaEIjiwaCmRd0yD8UU5To9aHab-PKFAW
Get yourself a MASCHINE + 
At Patchwerks: http://shrsl.com/3jy5j
At Perfect Circuit: https://bit.ly/3x1kkXm

00:00 bees
03:08 bombay (from lock states video)
06:08 euphorium (from polysynth video)
11:00 pandora (from scenes video)
13:33 holden (from eurorack + maschine video)
19:44 u get me (from tracklib vs maschine video)
23:58 aquarius earth (from 9 for 99 expansions video)
26:13 basement era (from 9 for 99 expansions video)
29:06 crate cuts (from 9 for 99 expansions video)
31:19 polar flare (from 9 for 99 expansions video)
34:11 rhythm source (from 9 for 99 expansions video)
35:38 indigo dust (from 9 for 99 expansions video)
37:17 faded reels (from 9 for 99 expansions video)
39:11 rising crescent (from 9 for 99 expansions video)
40:49 sierra grove (from 9 for 99 expansions video)
42:58 shadow on the oasis (from autosampler video)
------------------------------------
This channel is possible with the help of viewers like you.
Support me on Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


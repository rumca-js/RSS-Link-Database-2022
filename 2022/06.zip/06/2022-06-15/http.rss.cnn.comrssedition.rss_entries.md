# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Bill Gates mocks Bored Ape NFT's
 - [https://www.cnn.com/videos/business/2022/06/15/bill-gates-crypto-bored-ape-orig-dp.cnn](https://www.cnn.com/videos/business/2022/06/15/bill-gates-crypto-bored-ape-orig-dp.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 21:19:20+00:00

During a TechCrunch conference, Microsoft co-founder Bill Gates explained why he does not invest in cryptocurrency or NFTs.

## Ethiopian government and Tigrayan forces move towards negotiations
 - [https://www.cnn.com/2022/06/15/africa/ethiopia-negotiates-with-tigray-intl/index.html](https://www.cnn.com/2022/06/15/africa/ethiopia-negotiates-with-tigray-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 18:48:07+00:00

The Ethiopian government has formed a committee to negotiate with forces from the Tigray region, Prime Minister Abiy Ahmed said in a televised speech to parliament on Tuesday.

## Anti-Semitic church carving can stay, Germany's top appeal court rules
 - [https://www.cnn.com/style/article/antisemitic-church-carving-scli-intl-grm/index.html](https://www.cnn.com/style/article/antisemitic-church-carving-scli-intl-grm/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 18:35:47+00:00

Germany's highest appeal court has ruled that a medieval sculpture can remain on the outside of a church in Wittenberg, eastern Germany, despite acknowledging that it is anti-Semitic.

## South Carolina voters delivered vengeance for Trump, and other takeaways from Tuesday's primaries
 - [https://www.cnn.com/2022/06/15/politics/nevada-south-carolina-primary-takeaways/index.html](https://www.cnn.com/2022/06/15/politics/nevada-south-carolina-primary-takeaways/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 18:30:28+00:00

South Carolina voters delivered the vengeance that Donald Trump had sought as they ousted Rep. Tom Rice, one of the 10 House Republicans who had voted to impeach the former President, in a primary Tuesday.

## US imposes terrorist designation on man tied to Russian White supremacist group
 - [https://www.cnn.com/2022/06/15/politics/russian-imperial-movement-sanctions/index.html](https://www.cnn.com/2022/06/15/politics/russian-imperial-movement-sanctions/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 18:28:42+00:00

The United States government on Wednesday designated an individual connected to the Russian Imperial Movement (RIM) -- an ultranationalist, White supremacist organization -- as a terrorist and sanctioned two others for involvement with the group.

## Fed makes boldest move since 1994 to tame raging US inflation
 - [https://www.cnn.com/2022/06/15/economy/fed-rate-hike-decision-june/index.html](https://www.cnn.com/2022/06/15/economy/fed-rate-hike-decision-june/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 18:21:20+00:00

The Federal Reserve raised interest rates by three-quarters of a percentage point on Wednesday in an aggressive move to tackle white-hot inflation that is plaguing the economy, frustrating consumers and stifling the Biden administration.

## US announces $1 billion in new military aid for Ukraine
 - [https://www.cnn.com/2022/06/15/politics/biden-admin-ukraine-military-aid/index.html](https://www.cnn.com/2022/06/15/politics/biden-admin-ukraine-military-aid/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 18:15:23+00:00

The Biden administration is expected to announce on Wednesday an additional $1 billion in military aid to Ukraine to fight Russia, according to a US official.

## Two Ukrainian helicopter pilots recount their time in Russian captivity
 - [https://www.cnn.com/2022/06/15/europe/ukrainian-pilots-interview-intl/index.html](https://www.cnn.com/2022/06/15/europe/ukrainian-pilots-interview-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 17:40:24+00:00

On March 8, three Ukrainian military helicopters were shot down as they returned from a combat mission inside Russian-occupied territory. The only two pilots to survive were badly injured and taken prisoner by Russian forces.

## Tuesday was a dire political omen for Liz Cheney
 - [https://www.cnn.com/2022/06/15/politics/cheney-trump-rice-south-carolina-primary-impeach/index.html](https://www.cnn.com/2022/06/15/politics/cheney-trump-rice-south-carolina-primary-impeach/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 17:28:22+00:00

For Liz Cheney, Tuesday was a bad day for her political future.

## See Ukrainian troops try out US-supplied M4 rifles
 - [https://www.cnn.com/videos/world/2022/06/15/ukraine-us-weapon-rifle-drill-wedeman-pkg-nr-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2022/06/15/ukraine-us-weapon-rifle-drill-wedeman-pkg-nr-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 17:03:09+00:00

Amid going concern that Russia may expand its control beyond the region in east Ukraine, Ukrainian president Zelensky is pleading for more western weaponry. CNN's Ben Wedeman goes to a drill where Ukrainian troops are trying out the fresh US-supplied rifles.

## Triple-whammy for European gas supplies sends prices soaring
 - [https://www.cnn.com/2022/06/15/energy/european-gas-prices/index.html](https://www.cnn.com/2022/06/15/energy/european-gas-prices/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 17:02:10+00:00

Europe's natural gas supply has suffered its third blow in 48 hours, sending prices rocketing 42% higher from where they were at the start of the week.

## Jan. 6 committee releases video of Capitol tour before insurrection
 - [https://www.cnn.com/videos/politics/2022/06/15/barry-loudermilk-tour-video-january-6-nr-vpx.cnn](https://www.cnn.com/videos/politics/2022/06/15/barry-loudermilk-tour-video-january-6-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 16:57:46+00:00

The Jan. 6 committee is asking Rep. Barry Loudermilk (R-GA) for more information about a tour he led the day before the insurrection. The Capitol Police concluded there is no evidence that Loudermilk led a reconnaissance tour with Trump supporters.

## Suspect in custody after mass shooting threat prompts at least 8 Missouri school districts to cancel summer school classes
 - [https://www.cnn.com/2022/06/15/us/missouri-school-districts-close-threats/index.html](https://www.cnn.com/2022/06/15/us/missouri-school-districts-close-threats/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 16:25:17+00:00

At least eight school districts in the Kansas City, Missouri, area have canceled summer school activities on Wednesday after a local police department said it learned of a shooting threat, as communities across the US remain on edge following a series of high-profile mass shootings.

## India's Asia's richest man bets billions on the future of cricket
 - [https://www.cnn.com/2022/06/15/business/india-ipl-media-rights-deal-ambani-hnk-intl/index.html](https://www.cnn.com/2022/06/15/business/india-ipl-media-rights-deal-ambani-hnk-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 16:13:30+00:00

Indian billionaire Mukesh Ambani has now added a massive cricket deal to his empire.

## Internet Explorer is no more. CNN reported on the 'browser wars' it started in 1996
 - [https://www.cnn.com/videos/business/2022/06/15/microsoft-internet-explorer-shutdown-vault-orig-ht.cnn-business](https://www.cnn.com/videos/business/2022/06/15/microsoft-internet-explorer-shutdown-vault-orig-ht.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 16:11:57+00:00

After 27 years, Microsoft shut down its iconic web browser Internet Explorer. Watch CNN's coverage in 1996 on browser wars between Netscape and this once the most popular web browser.

## Origins of world's biggest pandemic identified in new study
 - [https://www.cnn.com/2022/06/15/health/black-death-plague-source-identified-scn/index.html](https://www.cnn.com/2022/06/15/health/black-death-plague-source-identified-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 16:11:21+00:00

Tombstones in what's now Kyrgyzstan have revealed tantalizing details about the origins of the Black Death, the world's most devastating plague outbreak that is estimated to have killed half of Europe's population in the space of seven years during the Middle Ages.

## Satellite spots world's 'largest' methane leak in a Russian coal mine
 - [https://www.cnn.com/2022/06/15/europe/methane-leak-biggest-ever-russia-intl/index.html](https://www.cnn.com/2022/06/15/europe/methane-leak-biggest-ever-russia-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 16:06:44+00:00

A coal mine in a remote part of Russia is spewing out huge amounts of a very potent greenhouse gas in what has been described as the "biggest" leak of methane ever detected from a single facility.

## Second suspect arrested over missing pair as Brazil's UK ambassador apologizes to family for incorrect claims
 - [https://www.cnn.com/2022/06/15/americas/apology-brazilian-ambassador-intl-gbr/index.html](https://www.cnn.com/2022/06/15/americas/apology-brazilian-ambassador-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 15:54:39+00:00

The Brazilian ambassador to the UK has apologized to the family of missing journalist Dom Phillips after they were wrongly told that two bodies had been found in the search operation.

## New report offers insight into autonomous vehicle crashes
 - [https://www.cnn.com/2022/06/15/cars/nhtsa-autopilot-robotaxi-crash-data/index.html](https://www.cnn.com/2022/06/15/cars/nhtsa-autopilot-robotaxi-crash-data/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 15:43:38+00:00

The National Highway Traffic Safety Administration released on Wednesday nine months of crash data from vehicles using driver-assist technologies like Tesla Autopilot as well as fully autonomous vehicles like Waymo's robotaxis.

## This classic Italian destination just limited tourist access
 - [https://www.cnn.com/travel/article/amalfi-coast-traffic-ban/index.html](https://www.cnn.com/travel/article/amalfi-coast-traffic-ban/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 15:16:14+00:00

With its cliff-chiseled road, dramatic curves and sheer drops towards the turquoise sea far below, the Amalfi Coast has become an iconic road trip destination.

## Why the world's largest tea importer is urging its citizens to consume less of the drink
 - [https://www.cnn.com/collections/intl-economy-inflation-061522/](https://www.cnn.com/collections/intl-economy-inflation-061522/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 14:52:54+00:00



## Amber Heard says she still loves Johnny Depp and knows she's not 'a perfect victim'
 - [https://www.cnn.com/2022/06/15/entertainment/amber-heard-part-2-interview/index.html](https://www.cnn.com/2022/06/15/entertainment/amber-heard-part-2-interview/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 14:51:45+00:00

Amber Heard is afraid of potentially being sued again by her ex-husband Johnny Depp - even as she admits to still loving him.

## Biden and Saudi have a lot to lose if talks are a bust
 - [https://www.cnn.com/2022/06/15/middleeast/us-saudi-relations-biden-mime-intl/index.html](https://www.cnn.com/2022/06/15/middleeast/us-saudi-relations-biden-mime-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 14:45:21+00:00

Most Saudi officials start any conversation about the United States with the preface, "a long and historic relationship." Some point proudly to photos of themselves with past US presidents.

## Bill Gates says crypto and NFTs are a sham
 - [https://www.cnn.com/collections/intl-crypto-nfts-061522/](https://www.cnn.com/collections/intl-crypto-nfts-061522/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 14:24:10+00:00



## Bradley Cooper shares how Will Arnett helped him get sober
 - [https://www.cnn.com/2022/06/15/entertainment/bradley-cooper-addiction/index.html](https://www.cnn.com/2022/06/15/entertainment/bradley-cooper-addiction/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 14:09:20+00:00

Bradley Cooper is opening up about his past drug and alcohol abuse and shared who helped him through some tough times.

## 'Floating' airplane cabin could be the future of travel
 - [https://www.cnn.com/travel/article/crystal-cabin-awards-2022-winners/index.html](https://www.cnn.com/travel/article/crystal-cabin-awards-2022-winners/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 14:02:46+00:00

A design for "floating" airplane furniture and a cabin concept that could give each passenger their own personal fridge are among the winners of this year's Crystal Cabin Awards.

## James Patterson apologizes for saying White men don't get writing jobs due to 'racism'
 - [https://www.cnn.com/style/article/james-patterson-white-men-racism-cec/index.html](https://www.cnn.com/style/article/james-patterson-white-men-racism-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 13:56:10+00:00

James Patterson, the best-selling crime and mystery novelist, apologized for saying that White men are kept from getting writing jobs due to "racism."

## Why a Pride parade in Idaho became a far-right target
 - [https://www.cnn.com/2022/06/15/opinions/idaho-patriot-front-pride-arrests-hemmer/index.html](https://www.cnn.com/2022/06/15/opinions/idaho-patriot-front-pride-arrests-hemmer/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 13:55:18+00:00

A Pride event in Coeur d'Alene, a small city in Idaho's panhandle, might seem like an odd target for one of the country's most active White supremacist groups. But on Saturday, 31 White men believed by authorities to be affiliated with the group Patriot Front huddled in the back of a U-Haul, allegedly planning to disrupt the gathering of LGBTQ people and allies in the city. (The men were charged with misdemeanor counts of conspiracy to riot.)

## Gwyneth Paltrow and Brad Pitt still 'love' each other 25 years after their split
 - [https://www.cnn.com/2022/06/15/entertainment/gwyneth-paltrow-brad-pitt-friendship/index.html](https://www.cnn.com/2022/06/15/entertainment/gwyneth-paltrow-brad-pitt-friendship/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 13:22:52+00:00

They may have ended their engagement decades ago, but Gwyneth Paltrow and Brad Pitt still have love for each other.

## Trump WH attorney to John Eastman: Get a good f****** criminal defense lawyer
 - [https://www.cnn.com/videos/politics/2022/06/15/cheney-releases-january-6-video-eric-herschmann-eastman-sot-ac-vpx.cnn](https://www.cnn.com/videos/politics/2022/06/15/cheney-releases-january-6-video-eric-herschmann-eastman-sot-ac-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 13:04:12+00:00

January 6 committee co-chair Rep. Liz Cheney (R-WY) released an extended clip of former White House lawyer Eric Herschmann's testimony in which he said he warned conservative attorney John Eastman who advised the Trump campaign to back off plans to file appeals in Georgia based on the election results after the events of January 6, 2021.

## MLS and Apple announce 10-year streaming deal
 - [https://www.cnn.com/2022/06/15/football/mls-apple-streaming-deal-spt-intl/index.html](https://www.cnn.com/2022/06/15/football/mls-apple-streaming-deal-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 12:59:50+00:00

Major League Soccer (MLS) has announced a 10-year deal with Apple to stream every US top-flight men's game worldwide in what is being described as a 'historic" day for the league.

## China's borders are closed, but it's building bridges to Russia
 - [https://www.cnn.com/2022/06/14/asia/china-russia-blagoveshchensk-heihe-highway-bridge-mic-intl-hnk/index.html](https://www.cnn.com/2022/06/14/asia/china-russia-blagoveshchensk-heihe-highway-bridge-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 12:50:16+00:00



## Ford recalls 2.9 million vehicles that could roll away when placed in park
 - [https://www.cnn.com/2022/06/15/business/ford-recall/index.html](https://www.cnn.com/2022/06/15/business/ford-recall/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 12:47:49+00:00

Ford is recalling 2.9 million vehicles that might not shift into the correct gear and could move in an unintended direction.

## Ryanair abandons controversial Afrikaans test for South African travelers
 - [https://www.cnn.com/travel/article/ryanair-drops-controversial-test-for-south-african-travelers/index.html](https://www.cnn.com/travel/article/ryanair-drops-controversial-test-for-south-african-travelers/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 12:05:23+00:00

Ryanair has confirmed that South Africans will no longer have to take an Afrikaans test to prove their nationality before boarding flights to the UK.

## Russia's war in Ukraine threatens one of England's most famous dishes
 - [https://www.cnn.com/videos/business/2022/06/14/fish-and-chips-uk-dishes-rising-food-prices-war-in-ukraine.cnnbusiness](https://www.cnn.com/videos/business/2022/06/14/fish-and-chips-uk-dishes-rising-food-prices-war-in-ukraine.cnnbusiness)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 11:34:17+00:00

CNN's Anna Stewart reports on how the war in Ukraine is impacting food prices, showing how cost increases are affecting various sectors, as well as fish & chips, the UK's "unofficial national dish."

## Vets want animal lovers to stop buying 'unhealthy' English bulldogs
 - [https://www.cnn.com/2022/06/15/health/english-bulldogs-scn-scli-intl-gbr/index.html](https://www.cnn.com/2022/06/15/health/english-bulldogs-scn-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 11:23:12+00:00

Veterinarians are calling on animal lovers to stop buying English bulldogs, because of "major" concerns about their health.

## Germany records first competitive victory against Italy, Hungary thrashes England in UEFA Nations League
 - [https://www.cnn.com/2022/06/15/football/uefa-nations-league-germany-england-spt-intl/index.html](https://www.cnn.com/2022/06/15/football/uefa-nations-league-germany-england-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 10:14:02+00:00

Germany's national team claimed a first ever competitive victory against Italy with a comprehensive 5-2 win on Tuesday, while England suffered a shock 4-0 defeat at home against Hungary in the UEFA Nations League.

## EU launches legal action against UK over post-Brexit deal on Northern Ireland
 - [https://www.cnn.com/2022/06/15/europe/eu-uk-legal-challenge-brexit-northern-ireland-protocol-intl/index.html](https://www.cnn.com/2022/06/15/europe/eu-uk-legal-challenge-brexit-northern-ireland-protocol-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 10:04:55+00:00

The European Union on Wednesday launched new legal proceedings against the United Kingdom over its failure to implement parts of the post-Brexit deal it agreed with the bloc.

## Sri Lanka announces four-day work week to curb food and fuel crisis
 - [https://www.cnn.com/2022/06/15/asia/sri-lanka-crisis-food-four-day-week-intl-hnk/index.html](https://www.cnn.com/2022/06/15/asia/sri-lanka-crisis-food-four-day-week-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 09:57:57+00:00

Shorter work weeks aimed at boosting worker productivity and happiness are catching on in parts of the world like Iceland and the United Kingdom.

## Russian and Belarusian players allowed to compete at the US Open
 - [https://www.cnn.com/2022/06/15/tennis/us-open-russia-belarus-spt-intl/index.html](https://www.cnn.com/2022/06/15/tennis/us-open-russia-belarus-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 09:37:08+00:00

Russian and Belarusian players will be allowed to compete at the 2022 US Open, the US Tennis Association (USTA) announced on Tuesday, despite Russia's ongoing invasion of Ukraine.

## This may be the most creative path to mental health you've never tried
 - [https://www.cnn.com/2022/06/15/health/poetry-life-itself-wellness/index.html](https://www.cnn.com/2022/06/15/health/poetry-life-itself-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 08:17:06+00:00

One of the best pieces of breakup advice my friend Genna gave me during a tumultuous end to a long-term relationship was to write poetry.

## He predicted US inflation would rise. Hear what he thinks about a recession
 - [https://www.cnn.com/videos/business/2022/06/15/larry-summers-recession-inflation-fed-rate-hike-dlt-vpx-sot.cnn](https://www.cnn.com/videos/business/2022/06/15/larry-summers-recession-inflation-fed-rate-hike-dlt-vpx-sot.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 05:53:17+00:00

Former US Treasury Secretary Larry Summers, who faced criticism from the Biden administration in 2021 for saying inflation would rise in the US, predicts that the US will likely see a recession in the next two years because of an "overheated" economy and says he expects interest rates will continue to rise.

## Watch retiree crowd surf his way to meeting rock star
 - [https://www.cnn.com/videos/world/2022/06/15/the-killers-crowdsurfer-brandon-flowers-orig-mss.cnn](https://www.cnn.com/videos/world/2022/06/15/the-killers-crowdsurfer-brandon-flowers-orig-mss.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 04:31:05+00:00

Doug James, a 67-year-old retiree, met the lead singer for "The Killers" after he crowd surfed all the way to the front of the show.

## Man's emu deterrent method has internet weighing in
 - [https://www.cnn.com/videos/us/2022/06/14/emu-pool-noodle-deterrent-moos-vpx.cnn](https://www.cnn.com/videos/us/2022/06/14/emu-pool-noodle-deterrent-moos-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-06-15 00:17:37+00:00

A Texas man's TikTok videos of his method for keeping his pet emu at bay while he mows the lawn delights the internet.  CNN's Jeanne Moos reports.


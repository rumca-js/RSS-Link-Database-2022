# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## 600K Subs, War of the Rohirrim, Rings of Power, Return to Moria, Open Q&A
 - [https://www.youtube.com/watch?v=uUyIbs2PG_g](https://www.youtube.com/watch?v=uUyIbs2PG_g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-06-16 00:00:00+00:00

Nerd of the Rings has surpassed the 600,000 subscriber mark!  To celebrate, we'll have a livestream with open Q&A from the chat, talk new video game adaptations and maybe have some prizes to give out - stay tuned and hit "Set Reminder"!

Enter the Giveaway: https://gleam.io/07WDx/nerd-of-the-rings-600k-giveaway

Topics:
Rings of Power, Gollum game, Return to Moria game, War of the Rohirrim, Open Q&A

#lordoftherings #tolkien #lotr


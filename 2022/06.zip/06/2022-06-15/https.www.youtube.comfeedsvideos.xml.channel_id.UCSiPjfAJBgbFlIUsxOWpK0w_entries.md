# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Big Brown Eyes // Benny Sings // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=iPDyg_TySk8](https://www.youtube.com/watch?v=iPDyg_TySk8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-06-16 00:00:00+00:00

Benny writes great songs. They all feel like summertime.

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Benny Sings' "Big Brown Eyes" by Pomplamoose & Benny Sings.

MUSICIAN CREDITS
Vocals/Guitar: Benny Sings
Vocals: Nataly Dawn
Background Vocals: Sarah Dugas
Keys: Jack Conte
Guitar: Brian Green
Bass: Nick Campbell
Drums: Ben Rose

AUDIO CREDITS
Audio Engineer: Tim Sonnefeld
Studio Engineer: Chris Sorem
Mixing/Mastering: Yianni AP

VIDEO CREDITS
Director: Dom Fera
DP: Christian Colwell 
Cam Op: Austin Hughes
Video Editor/Colorist: Dominic Mercurio

Recorded at Nest Recorders in Los Angeles.

LYRICS
Please help me out
There's something I can't explain
The innocence in your eyes is gone
Colors faded away
 
Please help me out
Something's different today
The silent spark in your smile is gone
What could have washed it away?

Did it just disappear?
Just a minute ago, it was here
Well, I guess I can't stop
The love disappearing from your eyes
 
Did it just disappear?
Just a minute ago, it was here
Well, I guess I can't stop
The love disappearing from your big, brown eyes
 
Please help me out
There's something I can't explain
Didn't we talk on the phone all night?
What did you want me to say?
 
Please help me out
Please explain to me again
Tell me, where did the fire go?
Tell me, what took it away?
 
Did it just disappear?
Just a minute ago, it was here
Well, I guess I can't stop
The love disappearing from your eyes
 
Did it just disappear?
Just a minute ago, it was here
Well, I guess I can't stop
The love disappearing from your big, brown eyes 
 
Did it just disappear?
Just a minute ago, it was here
Well, I guess I can't stop
The love disappearing from your eyes
 
Did it just disappear?
Just a minute ago, it was here
Well, I guess I can't stop
The love disappearing from your big, brown eyes


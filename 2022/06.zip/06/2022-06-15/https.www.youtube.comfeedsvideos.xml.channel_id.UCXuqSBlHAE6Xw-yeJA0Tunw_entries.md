# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Is Buying More RAM a WASTE for Gamers? (2022)
 - [https://www.youtube.com/watch?v=H19_JKw4QN4](https://www.youtube.com/watch?v=H19_JKw4QN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-16 00:00:00+00:00

Thanks to Crucial for sponsoring this video! 
Check out Crucial's DDR5 RAM today at: https://crucial.gg/LTT_DDR5

Still gaming in 2022 on 8GB of RAM (hopefully) in dual channel? We tested some newer games to find out whether or not you'll benefit from an upgrade, or if you're good to go for a little while yet.

Discuss on the forum: https://linustechtips.com/topic/1437566-is-buying-more-ram-a-waste-for-gamers-2022-sponsored/

Buy a stick of Crucial DDR5 8GB RAM: https://geni.us/ZSZtDIN

Buy a kit of Crucial Ballistix DDR4 (2x8GB) RAM: https://geni.us/JQWiTPM

Buy an EK AIO 360 DRGB: https://geni.us/2imXioC

Buy an Intel Core i9-12900K: https://geni.us/ynspX

Buy a Samsung 980 Pro 2TB: https://geni.us/hkH7l

Buy an RTX 3080 Ti: https://geni.us/UNzq

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:47 Why RAM is important
1:36 How we tested
2:30 CS:GO
3:14 How DDR5 is different from DDR4
4:01 Far Cry 6
5:46 Tiny Tina's Wonderland
6:53 Why is DDR5 better now?
7:34 Warhammer 3
8:15 AC: Valhalla
8:28 So what should I buy?
9:16 Outro

## Reacting to our Most PROFITABLE Videos!
 - [https://www.youtube.com/watch?v=Rh5hL47z2us](https://www.youtube.com/watch?v=Rh5hL47z2us)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-06-15 00:00:00+00:00

Check out the OnePlus 10 Pro 5G with 12GB RAM & 256GB of storage at https://bit.ly/LinusTechTipsOnePlus10Pro

SmartDeploy: Claim your FREE IT software (worth $580!) at https://www.smartdeploy.com/linus/?utm_source=linus&utm_campaign=2022q2&utm_medium=sp&utm_content=cloud

Linus and James look back at the LTT videos that made the most money and try to figure out the secret to their success.

Discuss on the forum: https://linustechtips.com/topic/1437361-reacting-to-our-most-profitable-videos-ever/

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:00 Number 10
3:00 9
4:11 8
5:07 What are CPMs?
6:09 7
7:59 6
9:07 5
10:44 IT'S NOT CLICKBAIT
11:54 3
13:17 NUMBA 2
14:45 Don't skip to the end you monster
16:00 Key Take-aways
18:12 Outro


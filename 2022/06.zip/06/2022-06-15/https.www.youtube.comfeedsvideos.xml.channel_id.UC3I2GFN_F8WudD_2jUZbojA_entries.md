# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Neal Francis - Alameda Apartments (Live on KEXP)
 - [https://www.youtube.com/watch?v=lX5ntBlj6Kc](https://www.youtube.com/watch?v=lX5ntBlj6Kc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-16 00:00:00+00:00

http://KEXP.ORG presents Neal Francis performing “Alameda Apartments” live in the KEXP studio. Recorded May 26, 2022.

Neal Francis - Keys / Vocals
Kellen Boersma - Guitar / Vocals
Mike Starr - Bass / Vocals
Collin O’Brien - Drums / Vocals

Host: Cheryl Waters
Audio Engineer: Julian Martlew
Audio Mixer: Sergio A. Rios
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://www.nealfrancis.com
http://kexp.org

## Neal Francis - Can’t Stop The Rain (Live on KEXP)
 - [https://www.youtube.com/watch?v=5MbqWkBIfvU](https://www.youtube.com/watch?v=5MbqWkBIfvU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-16 00:00:00+00:00

http://KEXP.ORG presents Neal Francis performing “Can’t Stop The Rain” live in the KEXP studio. Recorded May 26, 2022.

Neal Francis - Keys / Vocals
Kellen Boersma - Guitar / Vocals
Mike Starr - Bass / Vocals
Collin O’Brien - Drums / Vocals

Host: Cheryl Waters
Audio Engineer: Julian Martlew
Audio Mixer: Sergio A. Rios
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://www.nealfrancis.com
http://kexp.org

## Neal Francis - Changes, Pts. 1 & 2 (Live on KEXP)
 - [https://www.youtube.com/watch?v=KfI-VyGdj-8](https://www.youtube.com/watch?v=KfI-VyGdj-8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-16 00:00:00+00:00

http://KEXP.ORG presents Neal Francis performing “Changes, Pts. 1 & 2” live in the KEXP studio. Recorded May 26, 2022.

Neal Francis - Keys / Vocals
Kellen Boersma - Guitar / Vocals
Mike Starr - Bass / Vocals
Collin O’Brien - Drums / Vocals

Host: Cheryl Waters
Audio Engineer: Julian Martlew
Audio Mixer: Sergio A. Rios
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://www.nealfrancis.com
http://kexp.org

## Neal Francis - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=DHYHd6MXfVE](https://www.youtube.com/watch?v=DHYHd6MXfVE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-16 00:00:00+00:00

http://KEXP.ORG presents Neal Francis performing live in the KEXP studio. Recorded May 26, 2022.

Songs:
Can’t Stop The Rain
Alameda Apartments
Problems
Changes, Pts. 1 & 2

Neal Francis - Keys / Vocals
Kellen Boersma - Guitar / Vocals
Mike Starr - Bass / Vocals
Collin O’Brien - Drums / Vocals

Host: Cheryl Waters
Audio Engineer: Julian Martlew
Audio Mixer: Sergio A. Rios
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://www.nealfrancis.com
http://kexp.org

## Neal Francis - Problems (Live on KEXP)
 - [https://www.youtube.com/watch?v=HxRyFtLnIyA](https://www.youtube.com/watch?v=HxRyFtLnIyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-06-16 00:00:00+00:00

http://KEXP.ORG presents Neal Francis performing “Problems” live in the KEXP studio. Recorded May 26, 2022.

Neal Francis - Keys / Vocals
Kellen Boersma - Guitar / Vocals
Mike Starr - Bass / Vocals
Collin O’Brien - Drums / Vocals

Host: Cheryl Waters
Audio Engineer: Julian Martlew
Audio Mixer: Sergio A. Rios
Cameras: Jim Beckmann, Alaia D’Alessandro, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://www.nealfrancis.com
http://kexp.org


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Most Overpowered Weapons in Video Games
 - [https://www.youtube.com/watch?v=fVbD2iyQcUg](https://www.youtube.com/watch?v=fVbD2iyQcUg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-16 00:00:00+00:00

Some video game weapons are truly over the top and excessive. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## TMNT Shredder's Revenge - Before You Buy
 - [https://www.youtube.com/watch?v=tPnHrSDLZzU](https://www.youtube.com/watch?v=tPnHrSDLZzU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-06-15 00:00:00+00:00

Teenage Mutant Ninja Turtles: Shredder's Revenge (PC, PS5, PS4, Xbox Series X/S/One, Nintendo Switch) is an arcade style beat-em-up brawler with a lot of charm.
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy TMNT: https://www.shredders-revenge.com


Watch more 'Before You Buy': https://bit.ly/2kfdxI6

#tmnt #shreddersrevenge


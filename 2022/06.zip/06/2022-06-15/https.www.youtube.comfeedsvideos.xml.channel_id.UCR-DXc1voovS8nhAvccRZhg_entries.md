# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Why are Industrial Pis so expensive?
 - [https://www.youtube.com/watch?v=9MqJI_F-sz8](https://www.youtube.com/watch?v=9MqJI_F-sz8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2022-06-15 00:00:00+00:00

Find out more about PiBox and Kubesail: https://pibox.io/?ref=geerlingguy

Everything else I referenced in this video:

  - Entry form for PiBox Giveaway: https://www.jeffgeerling.com/pibox
  - Lincoln-Binns CM4 Enclosures: https://lincolnbinns.com/shop/internet-of-things-iot/compute-module-4-enclosures.html
  - Onlogic Factor 200 Series: https://www.onlogic.com/computers/industrial/fanless/factor-200/
  - fieldcloud SAS: https://fieldcloud.com

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Merch: https://redshirtjeff.com
2nd Channel: https://www.youtube.com/c/GeerlingEngineering

#RaspberryPi #IoT #sponsored 

Contents:

00:00 - Bomb-proof? Really?
01:15 - Industrial Pis cost more
02:05 - Lincoln-Binns CM4-Box
03:17 - What makes a Pi 'industrial'?
04:30 - Onlogic Factor 201
08:20 - Milü-X - explosive environments
14:38 - What goes into the final price
16:11 - Why use a Raspberry Pi?
17:54 - PiBox Giveaway


# Source:Roosevelt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg, language:en-US

## Roosevelt feat. Nile Rodgers - Passion (Official Video)
 - [https://www.youtube.com/watch?v=4byolRzsPmo](https://www.youtube.com/watch?v=4byolRzsPmo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg
 - date published: 2022-06-15 09:00:11+00:00

'POLYDANS' - my new album - out now! Stream / Purchase here: https://roosevelt.lnk.to/Polydans

FOLLOW Roosevelt on Facebook, Instagram and more https://roosevelt.lnk.to/follow​
Website: https://roosevelt.lnk.to/website​ 

This is the Official Youtube Channel for Roosevelt. 
SUBSCRIBE NOW to be kept up to date with the latest music, videos, tour dates, behind the scenes footage and more https://roosevelt.lnk.to/subscribe​


ANIMATION BY: https://www.meroestudio.tv/

MUSIC CREDITS

Nile Rodgers - Guitars 
Bim Amoako-Gyampah - Backing Vocals
Jakob Amr - Backing Vocals
Til Schneider - Brass Section
Nathan Boddy - Mix & Master

LYRICS

I was all run down
My heart was on the line
Heard you're leaving town
If we only had the time

Give me the feel of something new
All it that it takes for us to carry on
Send me your light to make it through
It's been fading for too long

Where's your
Passion
It's just about time to let it go
Open your eyes
Passion
There's something in you i got to know
Just realize 
oohh
Your love will keep us going strong
So i won't ever lose my
Passion
Ohhh

I was all run down
My heart was on the line
Heard you're leaving town
If we only had the time

Give me the feel of something new
All it that it takes for us to carry on
Send me your light to make it through
It's been fading for too long

Where's your
Passion
It's just about time to let it go
Open your eyes
Passion
There's something in you i got to know
Just realize 
oohh
Your love will keep us going strong
So i won't ever lose my
Passion
Ohhh

Passion
It's just about time to let it go
Passion
There's something in you i got to know
Passion
It's just about time to let it go
Passion
There's something in you i got to know 

#Roosevelt #NileRodgers #Disco #Passion #OfficialVideo


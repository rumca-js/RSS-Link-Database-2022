# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Onet ostrzega! Czekają nas lockdown'y energetyczne i racjonowanie energii!
 - [https://www.youtube.com/watch?v=ubuTT6Aq9FI](https://www.youtube.com/watch?v=ubuTT6Aq9FI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-06-16 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3zHxziQ
2. https://on.ft.com/3N4mWJY
3. https://on.ft.com/3Hu9q1c
4. https://bit.ly/3OdKaP2
---------------------------------------------------------------
💡 Tagi: #ZielonyŁad #energetyka 
--------------------------------------------------------------

## Syn Joe Bidena pomógł Chinom uzyskać kontrolę nad ogromnymi złożami kobaltu!
 - [https://www.youtube.com/watch?v=trl0fRNzitg](https://www.youtube.com/watch?v=trl0fRNzitg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-06-15 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://on.doi.gov/39tpNhK
2. https://nyti.ms/3MVg1CE
3. https://bit.ly/3zF6uwz
4. https://bit.ly/3b53q2R
5. https://bit.ly/3xR9YuS
6. https://bit.ly/3Hsq3dJ
7. https://bit.ly/3xpHxCK
8. https://prn.to/39p1QYY
9. https://fxn.ws/3mWNjqt
10. https://washex.am/3MWbjov
11. https://bit.ly/3zFKRMJ
---------------------------------------------------------------
💡 Tagi: #Biden #kobalt
--------------------------------------------------------------


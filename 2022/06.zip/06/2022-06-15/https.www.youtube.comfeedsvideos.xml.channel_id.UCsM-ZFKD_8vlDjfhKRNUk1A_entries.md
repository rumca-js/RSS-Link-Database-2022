# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Rubens - Jak dobrze znów Cię mieć - live MUZO.FM
 - [https://www.youtube.com/watch?v=c5lxKxL3EL8](https://www.youtube.com/watch?v=c5lxKxL3EL8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-06-15 00:00:00+00:00

Rubens - Jak dobrze znów Cię mieć na żywo w MUZO.FM. Kawłek pochodzi z debiutanckiej EPki Rubensa - Wynoszę się. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Rubens: http://www.facebook.com/rubenspoland
Instagram Rubens: http://www.instagram.com/rubens____
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm


#popolsku


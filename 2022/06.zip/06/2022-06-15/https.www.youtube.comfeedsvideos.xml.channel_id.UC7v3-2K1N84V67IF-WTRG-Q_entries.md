# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Obi-Wan Kenobi: Episode 5 - Review
 - [https://www.youtube.com/watch?v=PQrg631PnY8](https://www.youtube.com/watch?v=PQrg631PnY8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-06-15 00:00:00+00:00

We near the end of this Obi-Wan adventure, that started out with hints of promise. Now after 5 episodes, we've come so far....yet have gone nowhere. Here are my thoughts on OBI-WAN KENOBI: EPISODE 5!

#obiwankenobi


# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## Unboxing the RARE Apple Twentieth Anniversary Macintosh!
 - [https://www.youtube.com/watch?v=kjVfkSAqloU](https://www.youtube.com/watch?v=kjVfkSAqloU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2022-06-15 00:00:00+00:00

In 1997,  Steve Jobs returned to the near-bankrupt Apple as interim CEO. Expeditiously, he cleaned house. The fragmented product lineup was massively streamlined and a bunch of mid/upper-management found themselves in search of a new job. One of those products was the Twentieth Anniversary Macintosh—a nauseatingly self-congratulatory product in celebration of Apple's 20-years as a company. Jobs hated it and had planned to fire the designer, Jony Ive, but things took a different turn. Years later, the TAM was recognized for instituting many of the design cues that Apple would continue using for decades establishing itself as one of the world's most iconic industrial design brands.

Check out the G3 Molar Mac - https://www.youtube.com/watch?v=j5uu9rjW1hI
Read more about Jony Ive here - https://amzn.to/3NZruCU
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq


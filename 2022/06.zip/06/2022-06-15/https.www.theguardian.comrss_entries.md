# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## Hong Kong's Jumbo Floating Restaurant towed away after 46 years – video
 - [https://www.theguardian.com/world/video/2022/jun/15/hong-kongs-jumbo-floating-restaurant-towed-away-after-46-years-video](https://www.theguardian.com/world/video/2022/jun/15/hong-kongs-jumbo-floating-restaurant-towed-away-after-46-years-video)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2022-06-15 01:51:33+00:00

<p>Hong Kong's iconic Jumbo Floating Restaurant has been towed away from its Aberdeen harbour home after 46 years. The restaurant was styled like a Chinese imperial palace and was known for Cantonese and seafood dishes. It closed in 2020 due to the pandemic and never reopened. The restaurant was moved outside of Hong Kong though its next berth is yet to be determined</p> <a href="https://www.theguardian.com/world/video/2022/jun/15/hong-kongs-jumbo-floating-restaurant-towed-away-after-46-years-video">Continue reading...</a>


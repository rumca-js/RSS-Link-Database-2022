# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Spelling Bee Contestant Asks The Definition of “Woman”
 - [https://www.youtube.com/watch?v=5mnQTzhVgl8](https://www.youtube.com/watch?v=5mnQTzhVgl8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-06-16 00:00:00+00:00

Judges at a school spelling bee are stumped and infuriated when a child dares to ask them for a definition of the word “woman.”

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Toppling Queer Theory’s House Of Cards With Liz Wheeler | A Bee Interview
 - [https://www.youtube.com/watch?v=uF3fLzCjEc4](https://www.youtube.com/watch?v=uF3fLzCjEc4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-06-15 00:00:00+00:00

Political commentator Liz Wheeler joined The Babylon Bee to talk about reading all the founding documents of critical and queer theory, Mark Zuckerberg being a robot who may have swung the 2020 election, Ron DeSantis’ bid for 2024, and the hottest spots to buy chest binders and packing underwear.

You can check out Liz Wheeler on her podcast The Liz Wheeler Show: https://lizwheelershow.com/

Or read her book Tipping Points: How to Topple the Left's House of Cards: https://www.amazon.com/Tipping-Points-Topple-Lefts-House/dp/1621579255

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


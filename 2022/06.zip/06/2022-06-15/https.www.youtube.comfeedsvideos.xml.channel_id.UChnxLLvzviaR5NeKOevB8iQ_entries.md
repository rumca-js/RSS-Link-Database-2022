# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Filthy Nirvana with Knobula Kickain and Vult Freak
 - [https://www.youtube.com/watch?v=JkPMKHcIcAA](https://www.youtube.com/watch?v=JkPMKHcIcAA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-06-15 00:00:00+00:00

A filthy look at two fun modules.
The Knobula Kickain is a kick drum module with reverb and stereo spectral sidechaining.
The Vult Freak is a super multi-mode filter with a TON of awesome filter models.
We'll give them both a nasty workout with our good friend, the Modbap Osiris wavetable oscillator.
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


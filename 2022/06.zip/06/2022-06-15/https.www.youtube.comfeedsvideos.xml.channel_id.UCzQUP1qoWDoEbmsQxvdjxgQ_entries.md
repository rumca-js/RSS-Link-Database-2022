# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Tim Kennedy on Witnessing the Fall of Afghanistan
 - [https://www.youtube.com/watch?v=WEHXfB8wwGk](https://www.youtube.com/watch?v=WEHXfB8wwGk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-06-16 00:00:00+00:00

Taken from JRE #1833 w/Tim Kennedy:
https://open.spotify.com/episode/6FQtrKt6hRRcEhhbABr2Ke?si=cc1f3144084e459b

## Adventurer Charlie Walker Was Detained in a Russian Jail for 1 Month
 - [https://www.youtube.com/watch?v=Oqs-1UH1jlo](https://www.youtube.com/watch?v=Oqs-1UH1jlo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-06-15 00:00:00+00:00

Taken from JRE #1832 w/Charlie Walker:
https://open.spotify.com/episode/0s6MNrgR48HxhoZpLZaJUn?si=392885397d8f480f


# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Madison Cunningham – Hospital (live for The Current)
 - [https://www.youtube.com/watch?v=jx3tAAhpuNk](https://www.youtube.com/watch?v=jx3tAAhpuNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-08-25 00:00:00+00:00

Los Angeles singer-songwriter Madison Cunningham  is getting ready to release her new album, 'Revealer,' on September 9. In the run-up to the album release, Cunningham visited The Current studio to play songs from the new album, including the lead single, "Hospital." 

Personnel
Madison Cunningham – vocals, guitar
Philip Krohnengold – keys
Garret Lang – bass
Kyle Crane – drums

Credits
Host – Mac Wilson
Guest – Madison Cunningham
Director – Erik Stromstad
Camera Operators – Erik Stromstad, Peter Ecklund, Thor Cramer Bornemann
Audio – Cameron Wiley
Video Editor – Evan Clark
Producers – Derrick Stevens, Jesse Wiza
Digital Producer – Luke D. Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

#madisoncunningham @MadisonCunningham

## Coin – Getting Older (live for The Current)
 - [https://www.youtube.com/watch?v=ZMGoUfPDvuw](https://www.youtube.com/watch?v=ZMGoUfPDvuw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-08-24 00:00:00+00:00

Nashville-based COIN are currently on tour following the release of their latest album, "Uncanny Valley." Watch COIN perform the song "Getting Older" during a session recorded at The Current. 

COIN are:
Chase Lawrence – vocals, keys
Joe Memmel – guitar
Ryan Winnen – drums
Matt Martin – bass

Credits
Host – Ayisha Jaffer  
Guests – COIN 
Technical director – Erik Stromstad 
Audio – Evan Clark
Camera Operators – Erik Stromstad, Peter Ecklund, Thor Cramer Bornemann
Video Editor – Eric Xu Romani 
Producers – Derrick Stevens, Jesse Wiza 
Digital producer – Luke Taylor 

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

#coin @thisiscoinmusic #gettingolder


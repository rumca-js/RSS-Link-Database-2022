# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Inside and Out // Feist // POMPLAMOOSE ft. Sarah Dugas
 - [https://www.youtube.com/watch?v=z9A_cqmIU04](https://www.youtube.com/watch?v=z9A_cqmIU04)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-08-25 00:00:00+00:00

Sarah Dugas sings this Bee Gees / Feist tune like nobody’s business. @beegees @feist 

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Feist's "Inside and Out" by Pomplamoose & Sarah Dugas.

MUSICIAN CREDITS
Vocals: Sarah Dugas
Synth: Jack Conte, Swatkins, Dave Mackay
Drums: Kyle Crane

AUDIO CREDITS
Engineer: Bill Mims
Assistant Engineer: Jack Corbett
Mixing/Mastering: Yianni AP
Producer: Ben Rose

VIDEO CREDITS
Director: Dom Fera
DP: Ryan Blewett
Camera Operators: Austin Hughes, Jenna Huskisson
Video Editor/Colorist: Athena Wheaton
Production Assistant: Will Obst

Recorded at Vintage Synthesizer Museum in Los Angeles.

#pomplamoose #feist #beegees 

LYRICS
Baby, I can't figure it out, your kisses taste like honey
Sweet lies don't gimme no rise, oh, fool, what you trying to do?
Living on your cheating and the pain grows inside me, it's enough
To leave me crying in the rain
Love you forever but you're driving me insane, and I'm hanging on
Oh, oh, oh, oh
I'll wait, I'll never give in, our love has got the power
Too many lovers in one lifetime ain't good for you
You treat me like a vision in the night
Someone there to stand behind you when your world ain't working right

I ain't no vision, I'm the girl who

Loves you inside and out
Backwards to forwards with my heart hanging out
I love no other way
What are we gonna do if we lose that fire?

Wrap myself up and take me home again
Too many heartaches in my lifetime ain't good for me
You figure it's the love that keeps you warm
Let this moment be forever, we won't ever feel the storm

I ain't no vision, I'm the girl who

Loves you inside and out
Backwards to forwards with my heart hanging out
I love no other way
What are we gonna do if we lose that fire?

Don't try to tell me that it's over
I can't hear a word, I can't hear a line
No girl could love you more
And that's what I'm crying for
You can't change the way I feel inside
You are the reason for my laughter and my sorrow
Blow out the candle, I will burn again tomorrow
No man on earth could stand between my loving arms
And no matter how you hurt me, I will love you 'til I die

I ain't no vision, I'm the girl who

Loves you inside and out
Backwards to forwards with my heart hanging out
I love no other way
What are we gonna do if we lose that fire?

I ain't no vision, I'm the girl who

Loves you inside and out
Backwards and forwards with my heart hanging out
I love no other way
What are we gonna do if we lose that fire?

Inside and out
Inside and out
Inside and out
Inside and out
Inside and out
Inside and out


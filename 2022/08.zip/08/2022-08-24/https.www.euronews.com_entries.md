## German publisher pulls Winnetou books after accusations of racism | Euronews
 - [https://www.euronews.com/2022/08/24/german-publisher-pulls-winnetou-books-after-accusations-of-racism](https://www.euronews.com/2022/08/24/german-publisher-pulls-winnetou-books-after-accusations-of-racism)
 - RSS feed: https://www.euronews.com
 - date published: 2022-08-24 09:38:24+00:00

German publisher pulls Winnetou books after accusations of racism | Euronews


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Roasting the Worst PCs on Craigslist
 - [https://www.youtube.com/watch?v=vfOk6nPUtIc](https://www.youtube.com/watch?v=vfOk6nPUtIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-08-25 00:00:00+00:00

Get Up to 40% Off Pulseway's IT Management Software at https://lmg.gg/PulsewayLTT
Check out the Cel-Fi GO X Signal Booster from Waveform at https://lmg.gg/WaveformLTT

Buying and selling used PC gaming components has been around since the day after the first person upgraded their system… but despite all that time, there are still plenty of hilariously awful posts out there for us to roast!

Discuss on the forum: https://linustechtips.com/topic/1451513-no-one-is-going-to-buy-your-pc/

Buy a 32GB kit of G.Skill Trident Z Royal: https://geni.us/noBe
Buy the Razer Nommo Chroma: Custom Woven 3" Glass Fiber Drivers: https://geni.us/6Yvipnl
Buy the Redragon K618 Horus Wireless RGB Mechanical Keyboard: https://geni.us/ZVTz1D
Buy the ARCTIC Alpine 12: https://geni.us/SGbvBiU
Buy the LIAN LI Strimer Plus V2 Addressable RGB Power Extension Cable: https://geni.us/bfTDeST

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:09 Commence Roasting
7:10 EVERYTHING INCLUDED
10:15 Behind the Scenes
13:40 You Doxed Yourself
18:10 Outro

## The most EXPENSIVE thing I own.
 - [https://www.youtube.com/watch?v=b3x28s61q3c](https://www.youtube.com/watch?v=b3x28s61q3c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-08-24 00:00:00+00:00

Thanks to Seasonic for sponsoring the unboxing of our new Power Supply Tester, and helping us spec it out! Buy a Seasonic Prime Platinum PX-1300W: https://geni.us/R0aH6

To prep for our upcoming Labs initiative, we ordered something more expensive than BOTH of Linus' vehicles combined... a massive Power Supply Tester worth $133,000. We can't wait to test it out, but find out how it works now!

Discuss on the forum: https://linustechtips.com/topic/1451314-the-most-expensive-thing-i-own-sponsored/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:17 Unboxing the massive crate
3:24 The most expensive USB key ever?
3:49 Power Requirements
4:33 Inside the machine
5:26 Unboxing everything else
7:00 Going bottom to top
8:55 Where things get interesting
11:21 Kyle's pride and joy
13:59 Conclusion


# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## Rob & Ryan's First Trip to Wrexham
 - [https://www.youtube.com/watch?v=pyVm4SO2mCg](https://www.youtube.com/watch?v=pyVm4SO2mCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-08-24 00:00:00+00:00

Here's a clip of us being both happy and worried. Theme warning!
Watch #WelcomeToWrexham on FX, streaming on Hulu & Disney+


# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Ostatnie momenty przed najazdem Rosjan
 - [https://tvn24.pl/go/programy,7/superwizjer-odcinki,10894/odcinek-1007,S00E1007,728324?source=rss](https://tvn24.pl/go/programy,7/superwizjer-odcinki,10894/odcinek-1007,S00E1007,728324?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-08-24 09:12:28+00:00

<img alt="Ostatnie momenty przed najazdem Rosjan" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nkivxn-ucieczka-z-irpienia-6081926/alternates/LANDSCAPE_1280" />
    Reportaż Michała Przedlackiego "Ucieczka z Irpienia".


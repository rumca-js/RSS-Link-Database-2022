# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## The Hospital's IT Staff hates me
 - [https://www.youtube.com/watch?v=Y6zY-ofFcBg](https://www.youtube.com/watch?v=Y6zY-ofFcBg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2022-08-24 00:00:00+00:00

I always try to appreciate the neat little bits of technology that go unnoticed. In my hospital room there are dozens of neat things you might not even know exist, like the ability of the IV pump to detect how much resistance there is in the line!

Just keep Red Shirt Jeff away from that in-room zip-line!

Oh and, since I'm in the hospital right now, my normal videos are on hold—I'll be back soon!

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Merch: https://redshirtjeff.com
2nd Channel: https://www.youtube.com/c/GeerlingEngineering


# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## House of the Dragon GOOD?! 🐉 NEW Rings of Power Trailer 💍DUNE: Awakening | FANTASY NEWS
 - [https://www.youtube.com/watch?v=tphgJINNLwY](https://www.youtube.com/watch?v=tphgJINNLwY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-08-25 00:00:00+00:00

Hello Future Fantasy News!

Mary Robinette Kowal's The Spare Man! https://www.tor.com/2022/08/19/excerpts-the-spare-man-by-mary-robinette-kowal/

New Channel: https://www.youtube.com/channel/UC9tQ...
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/F... 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


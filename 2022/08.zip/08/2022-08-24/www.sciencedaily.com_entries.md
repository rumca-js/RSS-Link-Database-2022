## Computer scientists: We wouldn't be able to control super intelligent machines
 - [https://www.sciencedaily.com/releases/2021/01/210111112218.htm](https://www.sciencedaily.com/releases/2021/01/210111112218.htm)
 - RSS feed: www.sciencedaily.com
 - date published: 2022-08-24 12:04:50.221771+00:00




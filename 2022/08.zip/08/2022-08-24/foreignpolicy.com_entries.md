## ‘Smart’ Cities Are Surveilled Cities
 - [https://foreignpolicy.com/2021/04/17/smart-cities-surveillance-privacy-digital-threats-internet-of-things-5g/](https://foreignpolicy.com/2021/04/17/smart-cities-surveillance-privacy-digital-threats-internet-of-things-5g/)
 - RSS feed: foreignpolicy.com
 - date published: 2022-08-24 12:04:49.880646+00:00




# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Hospitals to stop testing for asymptomatic admissions
 - [https://www.youtube.com/watch?v=KrE9wkql6mk](https://www.youtube.com/watch?v=KrE9wkql6mk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-08-24 00:00:00+00:00

Link to free download of John’s 2 textbooks

http://159.69.48.3 (please cut and past this address into search engine and it will work)

UK Zoe data

https://health-study.joinzoe.com

New symptomatic cases per day, 108,841

Current symptomatic prevalence, 1,659,056

UK, ONS latest, 24th August

https://www.ons.gov.uk/peoplepopulationandcommunity/healthandsocialcare/conditionsanddiseases/articles/coronaviruscovid19/latestinsights

UK viral positive prevalence

2.63% in England (1 in 40 people)

2.39% in Wales (1 in 40 people) 

2.00% in Northern Ireland (1 in 50 people) 

3.12% in Scotland (1 in 30 people)

Risk of reinfection

Five times higher in the period when the Omicron variants common (20 December 2021 and onwards), 

compared with the period when the Delta variant common (17 May to 19 December 2021)

Risk of reinfection in earlier Omicron period, (March 2022) people were 10 times more likely to be reinfected

Overall UK hospital admissions with covid

Percentage of patients in acute hospitals with confirmed COVID-19 who are being treated primarily for COVID-19

UK official data

https://coronavirus.data.gov.uk

US variants nowcast

https://covid.cdc.gov/covid-data-tracker/#variant-proportions

BA.5  88.9%

BA.4.6 6.3%

BA.4  4.3%

BA.2  0%
BA.1s 0%
Delta 0%

US data, over past two weeks

https://www.nytimes.com/interactive/2021/us/covid-cases-deaths-tracker.html

Cases, down 16% (almost all states)

Test positivity, at 15% down slightly

Hospitalizations, down 8% (down in about half of the states)

Deaths, down 5% (below 500 per day)

Dr. Anthony Fauci (81)

https://www.reuters.com/world/us/fauci-step-down-president-bidens-chief-medical-adviser-2022-08-22/

Stepping down in December

Director of the U.S. National Institute of Allergy and Infectious Diseases (NIAID), (since 1984)

part of the National Institutes of Health (NIH)


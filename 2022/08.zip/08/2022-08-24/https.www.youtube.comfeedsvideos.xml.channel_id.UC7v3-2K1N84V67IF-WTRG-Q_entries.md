# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## BETTER CALL SAUL Is A MASTERFUL Character Drama!
 - [https://www.youtube.com/watch?v=tjUIkbZknjk](https://www.youtube.com/watch?v=tjUIkbZknjk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-08-25 00:00:00+00:00

Thank you Rocket Money for sponsoring! Check out http://rocketmoney.com/jahns to start managing your personal finances today. #rocketmoney #personalfinance

Better Call Saul has wrapped up, and stands apart as a masterfully crafted character drama, rather than being the usual "spin-off nostalgia bait". Here are my thoughts on BETTER CALL SAUL!

#BetterCallSaul #BreakingBad


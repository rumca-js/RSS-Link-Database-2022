# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Audio Damage Quanta 2: Granular Goodness
 - [https://www.youtube.com/watch?v=bjCgtVdtpGk](https://www.youtube.com/watch?v=bjCgtVdtpGk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-08-25 00:00:00+00:00

Get Quanta 2 here: https://www.audiodamage.com/collections/plugin-instruments/products/ad055-quanta-2

Join the Patreon and get access to music, presets, samples, and a great community.
Join Patreon:  http://bit.ly/rmrpatreon

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


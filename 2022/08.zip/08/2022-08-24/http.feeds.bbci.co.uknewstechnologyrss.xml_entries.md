# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Facebook feeds flooded with celebrity spam
 - [https://www.bbc.co.uk/news/technology-62659681?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62659681?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-08-24 12:27:20+00:00

Thousands of users reported issues on Wednesday as a glitch hit the social media site's homepage.

## Clip-on tech turns spectacles into smart audio glasses
 - [https://www.bbc.co.uk/news/technology-62506346?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62506346?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-08-24 10:33:44+00:00

BBC Click's Lara Lewington tries out audio glasses, a smart skipping rope and some other new technology.


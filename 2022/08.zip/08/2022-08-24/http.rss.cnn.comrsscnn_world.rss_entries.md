# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Nicole Kidman flexes for latest cover shoot
 - [https://www.cnn.com/style/article/nicole-kidman-perfect-magazine-fashion-ltw/index.html](https://www.cnn.com/style/article/nicole-kidman-perfect-magazine-fashion-ltw/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-08-24 18:25:23+00:00

Oscar-winning actor Nicole Kidman caught the Internet's attention this week with a new shoot for Perfect Magazine.


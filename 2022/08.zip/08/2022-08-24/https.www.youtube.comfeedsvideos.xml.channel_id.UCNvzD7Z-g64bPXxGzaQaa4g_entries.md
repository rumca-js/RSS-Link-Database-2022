# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW Games of September 2022
 - [https://www.youtube.com/watch?v=XX8ZJQ5--44](https://www.youtube.com/watch?v=XX8ZJQ5--44)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-08-25 00:00:00+00:00

Looking for new September 2022 game releases on PC, PS5, PS4, Xbox Series X/S/One, or Nintendo Switch? We've got you covered.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:15 Metal: Hellsinger 
1:23 No Place For Bravery 
2:34 The Last of Us Part I  
3:48 Valkyrie Elysium
4:47 The DioField Chronicle 
6:05 Splatoon 3
7:13 Soulstice
8:16 Isonzo  
9:00 Return to Monkey Island
10:18 Steelrising 
11:04 BONUS


10 Metal: Hellsinger 
Platfrom: PC PS4 XBOX ONE PS5 XSX|S 

Release Date: September 15, 2022



9 No Place For Bravery 

Platfrom: Switch PC

Release Date: September 22, 2022



8 The Last of Us Part I  

Platfrom: PS5 

Release Date: September 2, 2022 



7 Valkyrie Elysium

Platfrom: PS4 PS5 

Release Date: September 29, 2022



6 The DioField Chronicle 

Platfrom: PC PS4 XBOX ONE PS5 XSX|S Switch

Release Date: September 22, 2022



5 Splatoon 3

Platfrom: Switch

Release Date: September 9, 2022



4 Soulstice

Platfrom: PC PS5 XSX|S 

Release Date: September 20, 2022



3 Isonzo  

Platfrom: PC PS4 XBOX ONE PS5 XSX|S 

Release Date: September 13, 2022 



2 Return to Monkey Island

Platfrom: PC Switch

Release Date: September 19, 2022



1 Steelrising 

Platfrom: PC PS5 XSX|S

Release Date: September 8, 2022



BONUS



FIFA 23 

Platfrom: PC PS4 XBOX ONE PS5 XSX|S Switch Stadia

Release Date: September 30, 2022



Slime Rancher 2

Platfrom: PC XSX|S

Release Date: September 22, 2022(early access)



Moonscars

Platfrom: PC PS4 XBOX ONE PS5 Switch XSX|S

Release Date: September 27, 2022



NBA 2K23

Platfrom: PC PS4 XBOX ONE PS5 XSX|S Switch

Release Date: September 9, 2022



Outer Wilds 

Platfrom: PS5 XSX|S

Release Date: September 15, 2022



Temtem 

Platfrom: PS5 XSX|S Switch PC

Release Date: September 6, 2022

## Top 10 NEW Games of Gamescom 2022
 - [https://www.youtube.com/watch?v=FX8bCukmARM](https://www.youtube.com/watch?v=FX8bCukmARM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-08-24 00:00:00+00:00

Here are some cool brand new games announced at Gamescom 2022 for PC, PS5, PS4, Xbox Series X/S/One and Nintendo Switch.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:27 Dune Awakening
1:09 Everywhere
2:14 Moonbreaker  
3:19 Atlas Fallen
4:23 Lords of the fallen  
5:45 Killer Clowns From Outer Space The Game
6:39 Destiny 2 Lightfall
7:25 Where Winds Meet
8:28 Phantom Hellcat
9:09 Dead Island 2
10:04 BONUS


10 Dune Awakening

Platform: PC PS5 XSX|S

Release Date: TBA 



9 Everywhere

Platform: TBA 

Release Date: 2023 



8 Moonbreaker  

Platform: PC 



7 Atlas Fallen

Platform: PC PS5 XSX|S 

Release Date: TBA 2023



6 Lords of the fallen  

Platform: PC PS5 XSX|S

Release Date: TBA



5 Killer Clowns From Outer Space The Game

Platform: PC PS4 Xbox One PS5 XSX|S

Release Date: Q2 2023



4 Destiny 2 Lightfall

Platform: PC XSX|S Xbox One, PS5 PS4 Stadia

Release Date: February 28, 2023



3 Where Winds Meet

Platform: PC 

Release Date: TBA



2 Phantom Hellcat

Platform: PC PS4 Xbox One PS5 XSX|S 

Release Date: TBA



1 Dead Island 2

Platform: PC XSX|S Xbox One Stadia PS5 PS4 

Release Date: Feb 3, 2023 



BONUS



Moving Out 2 

Platform: PC XSX|S Xbox One Switch PS5 PS4 

Release Date: TBA 2023


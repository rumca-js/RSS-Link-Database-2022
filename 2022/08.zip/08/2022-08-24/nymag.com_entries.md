## How Much of the Internet Is Fake? Turns Out, a Lot of It, Actually
 - [https://nymag.com/intelligencer/2018/12/how-much-of-the-internet-is-fake.html](https://nymag.com/intelligencer/2018/12/how-much-of-the-internet-is-fake.html)
 - RSS feed: nymag.com
 - date published: 2022-08-24 12:04:49.992823+00:00




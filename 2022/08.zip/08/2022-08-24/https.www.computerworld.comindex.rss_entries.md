# Source:ComputerWorld, URL:https://www.computerworld.com/index.rss, language:en-US

## The new workplace will be distributed, digital — and full of purpose
 - [https://www.computerworld.com/article/3670738/the-new-workplace-will-be-distributed-digital-and-full-of-purpose.html#tk.rss_all](https://www.computerworld.com/article/3670738/the-new-workplace-will-be-distributed-digital-and-full-of-purpose.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-08-24 15:56:00+00:00

<article>
	<section class="page">
<p>On a stressed-out planet, employee wellbeing is becoming an important consideration in the workplace, and so it’s easy to sympathize with Apple employees rebelling (again) against the company’s <a href="https://www.computerworld.com/article/3669901/apple-fails-to-innovate-the-new-future-workplace.html">inflexible take on flexible work</a>.</p><h2><strong>Flexibility empowers employees and speaks of trust</strong></h2>
<p>Flexible work has not only already pro

## Microsoft OneNote cheat sheet
 - [https://www.computerworld.com/article/3406779/microsoft-onenote-cheat-sheet.html#tk.rss_all](https://www.computerworld.com/article/3406779/microsoft-onenote-cheat-sheet.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-08-24 11:50:00+00:00

<article>
	<section class="page">
<p>A note-taking app can be helpful, especially if it enables you and your co-workers to collaborate on ideas. <a href="https://www.microsoft.com/en-us/microsoft-365/onenote/digital-note-taking-app" rel="nofollow noopener" target="_blank">Microsoft OneNote</a> is an excellent tool for the job. It’s pre-installed on Windows 10 and 11 and is included with a Microsoft 365 subscription. But anyone can download the app and use it for free.</p><p>This guide walks you 

## 5 out-of-sight superpowers for Google Contacts on Android
 - [https://www.computerworld.com/article/3670635/google-contacts-android.html#tk.rss_all](https://www.computerworld.com/article/3670635/google-contacts-android.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-08-24 10:00:00+00:00

<article>
	<section class="page">
<p>Quick: What's the most exciting app on your Android phone right now?</p><p>Just a hunch here, but I'm gonna go out on a limb and say Google Contacts probably wasn't your answer. And why would it be? Your phone's virtual Rolodex is about as exhilarating as a trip to the endodontist. Plus, our mobile devices have had systems for managing our contacts since way back in the prehistoric days, so it certainly doesn't seem like something to celebrate.</p><p>Hold the


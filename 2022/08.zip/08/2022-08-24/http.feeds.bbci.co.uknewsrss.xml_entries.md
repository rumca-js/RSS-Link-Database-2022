# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Scott Mills on 24 years at Radio 1: 'Keep it simple and be kind'
 - [https://www.bbc.co.uk/news/newsbeat-62660072?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-62660072?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 23:59:24+00:00

The legendary DJ is leaving Radio 1, the station that has been his home since he joined in 1998.

## Flexible firms take break from fixed bank holidays
 - [https://www.bbc.co.uk/news/business-62491321?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62491321?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 23:25:45+00:00

Letting staff choose when to take bank holidays boosts work-life balance and productivity, some firms say.

## Rohingya: ‘Kill us, but don’t deport us to Myanmar’
 - [https://www.bbc.co.uk/news/world-asia-india-62658647?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-62658647?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 23:16:06+00:00

Five years after millions of Rohingyas fled genocide in Myanmar, they continue to live in perilous conditions.

## On call with Italy's horseback doctor
 - [https://www.bbc.co.uk/news/world-europe-62662429?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62662429?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 23:01:21+00:00

Dr Roberto Anfosso and Ambra make house calls around the village of La Morra in the Piedmont region.

## Champions League: 'Dogged Rangers fight way to place with big boys'
 - [https://www.bbc.co.uk/sport/football/62668954?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62668954?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 22:00:13+00:00

PSV were profligate, but that will matter little to resolute Rangers as they look forward to Champions League groups, writes Tom English.

## British-Belgian pilot, 17, becomes youngest to fly around the world solo
 - [https://www.bbc.co.uk/news/world-europe-62667543?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62667543?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 19:51:34+00:00

British-Belgian teen flew through sandstorms and spent the night on an uninhabited island to break record.

## Tiger Woods & Rory McIlroy launch 'high-tech golf league' aimed at younger fans
 - [https://www.bbc.co.uk/sport/golf/62665874?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/62665874?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 18:02:20+00:00

Tiger Woods and Rory McIlroy launch a new "high-tech golf league" intended to appeal to younger fans.

## Red Arrows: What is going wrong at the RAF?
 - [https://www.bbc.co.uk/news/uk-62664654?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62664654?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 15:27:56+00:00

The air force is investigating allegations of unacceptable behaviour within the Red Arrows.

## Whipsnade Zoo elephant's first steps pictured hours after birth
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-62665531?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-62665531?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 15:06:08+00:00

Keepers said the Asian elephant's arrival was a massive success for conservation of the species.

## England v South Africa: Ollie Robinson replaces Matthew Potts
 - [https://www.bbc.co.uk/sport/cricket/62660305?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62660305?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 11:48:45+00:00

England recall pace bowler Ollie Robinson to their XI for the second Test against South Africa at Old Trafford, starting on Thursday.

## Asda ends best before dates on 200 fresh products
 - [https://www.bbc.co.uk/news/uk-62658965?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62658965?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 11:38:49+00:00

The retailer becomes the latest UK supermarket to scrap best before dates on more than 200 products.

## More BTec students could face delays to results
 - [https://www.bbc.co.uk/news/education-62659051?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-62659051?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 11:23:28+00:00

Exam board Pearson says a team is in place and results will be provided "as quickly as possible".

## UK imports no fuel from Russia for first time
 - [https://www.bbc.co.uk/news/business-62659391?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62659391?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 11:15:30+00:00

Imports of goods from Russia fell to £33m in June, the lowest level since 1997, official figures show.

## Olympian Katie Archibald tried to save dying partner Rab Wardell
 - [https://www.bbc.co.uk/news/uk-scotland-62657986?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-62657986?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 11:11:59+00:00

The gold medallist could not revive Rab Wardell after he suffered a cardiac arrest in bed beside her.

## Women's World Cup qualifiers: England's Chloe Kelly and Fran Kirby out injured
 - [https://www.bbc.co.uk/sport/football/62659411?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62659411?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 11:07:26+00:00

Chloe Kelly, who scored the winner against Germany in the final of Euro 2022, is out of England's first squad since their historic Wembley triumph with injury.

## Target of Liverpool shooting that killed Olivia Pratt-Korbel, 9, arrested
 - [https://www.bbc.co.uk/news/uk-england-merseyside-62658221?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-62658221?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 10:49:34+00:00

A man who was shot by a gunman as he ran into Olivia Pratt-Korbel's home is detained in hospital.

## Eurotunnel Le Shuttle: Passengers stuck for hours inside tunnel
 - [https://www.bbc.co.uk/news/uk-62655148?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62655148?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 10:41:56+00:00

"Several people were freaking out," said one traveller, after a Calais to Folkestone train was evacuated.

## Minimum wage should rise to £15 for all workers, says TUC
 - [https://www.bbc.co.uk/news/business-62656500?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62656500?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 09:43:03+00:00

A higher rate should be paid to all workers, including under-23s, the Trades Union Congress says.

## Canelo Alvarez v Gennady Golovkin III: Mexican world champion aims to send rival into retirement
 - [https://www.bbc.co.uk/sport/boxing/62579265?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/62579265?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 09:22:24+00:00

Canelo Alvarez speaks to BBC Sport from inside his training camp before his trilogy fight against Gennady Golovkin.

## Chip shops face 'extinction' amid cost of living crisis
 - [https://www.bbc.co.uk/news/uk-england-somerset-62650572?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-somerset-62650572?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 08:46:29+00:00

The rising price of cod, sunflower oil and energy has left many shops struggling to survive.

## Elton gives diners preview of Britney comeback song
 - [https://www.bbc.co.uk/news/entertainment-arts-62658128?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62658128?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 08:45:33+00:00

Sir Elton John asks a French restaurant DJ to play his Britney Spears duet and streams the reactions.

## 'I haven't looked back since my first ballet class'
 - [https://www.bbc.co.uk/news/uk-england-essex-62652989?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-62652989?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 07:18:48+00:00

An 11-year-old boy describes his excitement at being picked for a prestigious dance school.

## Welcome to Wrexham: City in spotlight with Ryan Reynolds' new show
 - [https://www.bbc.co.uk/news/uk-wales-62623193?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-62623193?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 06:13:06+00:00

Fans praise Wrexham FC's celebrity owners ahead of reality show which puts "underdog" in spotlight.

## PSV Eindhoven v Rangers in Champions League: Can Antonio Colak be hero?
 - [https://www.bbc.co.uk/sport/football/62633428?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62633428?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 06:10:52+00:00

A year on from dumping Rangers out of the Champions League, can Antonio Colak fire his new club to the group stage in the absence of Alfredo Morelos?

## The pre-loved baby boxes being sent to Ukraine’s front line
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-62632269?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-62632269?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 05:13:18+00:00

The Scot Baby Box Appeal has been collecting aid for Ukrainians since the Russian invasion began.

## Thames Water hosepipe ban comes into force in England
 - [https://www.bbc.co.uk/news/uk-england-62643961?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-62643961?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 04:59:51+00:00

The Thames Water ban applies to 10 million customers in the Thames Valley and London.

## What China's worst drought on record looks like
 - [https://www.bbc.co.uk/news/world-asia-china-62644870?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-62644870?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-24 00:04:27+00:00

Satellite images show extent of severe drought along the Yangtze River in China


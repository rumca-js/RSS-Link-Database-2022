## The Age of Autonomous Killer Robots May Already Be Here
 - [https://gizmodo.com/flying-killer-robot-hunted-down-a-human-target-without-1847001471](https://gizmodo.com/flying-killer-robot-hunted-down-a-human-target-without-1847001471)
 - RSS feed: gizmodo.com
 - date published: 2022-08-24 12:04:49.923994+00:00




# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Farmers Protests Go Global - This Is Impossible To Ignore
 - [https://www.youtube.com/watch?v=Tr51Hz4p2sE](https://www.youtube.com/watch?v=Tr51Hz4p2sE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-08-25 00:00:00+00:00

Is the coverage of populist movements, like the uprising in Sri Lanka, smeared to appease a globalist agenda? That’s too much of a conspiracy theory, isn’t it!? I spoke with the journalist and former co-host of The Hills Kim Iversen about how some global agencies (WEF) seem to have an influence on the way that nations devise policy, for example, the font of the changes around fertilizer that would bankrupt farmers. #farmers #truckers #protest 

Check out Kim's YouTube channel: https://www.youtube.com/c/KimIversen/videos
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## You Aren’t Going To Like This
 - [https://www.youtube.com/watch?v=5QClLdrbkw8](https://www.youtube.com/watch?v=5QClLdrbkw8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-08-24 00:00:00+00:00

A recent study apparently shows 95% of pre-packaged baby food was contaminated with harmful & toxic heavy metals. Surely the FDA & the Government will step in to further regulate baby food? Or is there more behind this? #babyfood #poison #corruption 
 
References
https://www.commondreams.org/news/2022/08/12/94-pre-packaged-and-homemade-us-baby-foods-contain-toxic-heavy-metals-study
https://www.theguardian.com/commentisfree/2021/jun/17/why-are-there-dangerous-levels-of-arsenic-and-lead-in-american-baby-food
https://www.opensecrets.org/orgs/groupe-danone/summary?id=D000042446
https://www.nestle.com/aboutus/history/nestle-company-history/gerber
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


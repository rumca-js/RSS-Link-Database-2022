## Windows 11 Smart App Control to Require Clean Install of Windows
 - [https://www.extremetech.com/computing/333756-windows-11-smart-app-control-to-require-clean-install-of-windows](https://www.extremetech.com/computing/333756-windows-11-smart-app-control-to-require-clean-install-of-windows)
 - RSS feed: www.extremetech.com
 - date published: 2022-08-24 12:04:50.161522+00:00




## #29 Zwiedzamy Nowy Jork w 24 godziny cz.1
 - [https://www.youtube.com/watch?v=6Oe0TDuwUhs](https://www.youtube.com/watch?v=6Oe0TDuwUhs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIFlYVfPnvukmFOvC4JUfOg
 - date published: 2022-08-24 00:00:00+00:00

Mapka naszej trasy z części 1 https://www.google.com/maps/d/u/0/edit?mid=1Md7I6_PSbn9LY00MGFHfhLxKuzsLNdA&usp=sharing
Część 2 vloga https://youtu.be/EC2Q7blxAQI
🧗🏻Wesprzyj moje przygody na patronite: https://patronite.pl/Nejtan
📷 Instagram: https://www.instagram.com/nejthan
📜 Napisz do mnie: swiatwedlugnejtana@gmail.com
🎵 Muzyka: https://share.epidemicsound.com/m7uq26

2022 Trip z  @Vlog Casha   po Florydzie https://bit.ly/3uueZGV
2021 Trip z  @Vlog Casha   po zachodzie Usa i Alaska
https://bit.ly/3D6ClpI
#swiatwedlugnejtana #nejtan


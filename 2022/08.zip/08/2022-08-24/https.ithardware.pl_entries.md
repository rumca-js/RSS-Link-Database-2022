## Pakistan grozi odcięciem dysydentów od biometrycznego systemu cyfrowej identyfikacji
 - [https://ithardware.pl/aktualnosci/pakistan_grozi_odcieciem_dysydentow_od_biometrycznego_systemu_cyfrowej_identyfikacji-22922.html](https://ithardware.pl/aktualnosci/pakistan_grozi_odcieciem_dysydentow_od_biometrycznego_systemu_cyfrowej_identyfikacji-22922.html)
 - RSS feed: https://ithardware.pl
 - date published: 2022-08-24 21:03:40+00:00

Pakistan grozi odcięciem dysydentów od biometrycznego systemu cyfrowej identyfikacji


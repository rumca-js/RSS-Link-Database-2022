# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The Hyundai IONIQ 5: I Get It Now!
 - [https://www.youtube.com/watch?v=d7y9z7pjCRM](https://www.youtube.com/watch?v=d7y9z7pjCRM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-08-25 00:00:00+00:00

If the future of cars is electric, we need more EVs like this 👀
The new Auto Focus Channel! https://youtu.be/OKjyz7Jp4kA

MKBHD Merch: http://shop.MKBHD.com
Check out the Hyundai IONIQ 5 at https://geni.us/IONIQ5

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro track: http://youtube.com/Madeon
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Vehicle provided by Hyundai for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## YET ANOTHER package format, and Ubuntu might not get this GNOME feature - Linux & Open Source News
 - [https://www.youtube.com/watch?v=SrcupdKGvBs](https://www.youtube.com/watch?v=SrcupdKGvBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-08-25 00:00:00+00:00

Get 100$ credit for your own Linux and gaming server: https://www.linode.com/linuxexperiment 
Grab a brand new laptop or desktop running Linux:https://www.tuxedocomputers.com/


👏 SUPPORT THE CHANNEL:
Get access to a weekly podcast, vote on the next topics I cover, and get your name in the credits:

YouTube: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join
Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

📹 MORE VIDEOS FROM ME
Linux news in Shorts format: https://www.youtube.com/channel/UCtZp0mK9IBrpS2-jNzMZmoA
Gaming on Linux: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw
I'm also on ODYSEE: https://odysee.com/$/invite/@TheLinuxExperiment:e

🏆 FOLLOW ME ELSEWHERE:
Twitter : http://twitter.com/thelinuxEXP
Mastodon: https://mastodon.social/web/@thelinuxEXP
Pixelfed: https://pixelfed.social/TLENick
Discord: https://discord.gg/xK7ukavWmQ

📷 GEAR I USE:
Sony Alpha A6600 Mirrorless Camera: https://amzn.to/30zKyn7
Sigma 56mm Fixed Prime Lens: https://amzn.to/3aRvK5l
Logitech MX Master 3 Mouse: https://amzn.to/3BVI0Od
Bluetooth Space Grey Mac Keyboard: https://amzn.to/3jcJETZ
Logitech Brio 4K Webcam: https://amzn.to/3jgeTh9
LG Curved Ultrawide Monitor: https://amzn.to/3pcTVDH
Logitech White Speakers: https://amzn.to/3n6wSb0
Xbox Controller: https://amzn.to/3BWmIA3
*Amazon Links are affiliate codes and generate small commissions to support the channel*

This video is distributed under the Creative Commons Share Alike license.

#linux #news #opensource 

00:00 Intro
00:42 Sponsor: 100$ Free Credit on your own Linux or Gaming Server
01:41 Deepin introduces a new packaging format
03:31 KDE gets touchscreen improvements
04:47 KDE apps also get some great stable updates
06:04 GNOME apps are getting a ton of work done
07:20 The New File menu in Nautilus is getting a big revamp
08:26 Kdenlive 22.08 released, with much improved performance
09:33 New Linux laptops look promising
11:01 Ubuntu might not ship the Security Status feature of GNOME 43
12:26 Vermintide 2 on Linux with proton, SteamOS 3.4, Cemu goes open source...
13:51 Sponsor: Get a device that runs Linux perfectly, from Tuxedo
14:56 Support the channel

Deepin Creates yet another packaging format, called LingLong:

https://www.deepin.org/en/linux-system-distribution-deepin-23-preview-released/
https://store.linglong.dev/
https://linglong.dev/en/guide/ll-cli/install.html

KDE Developers add a touch friendly mode to Dolhpin, and update their apps:
https://pointieststick.com/2022/08/19/this-week-in-kde-dolphin-selection-mode/

KDE Gear Compilation 22.08 is out, with updates to Dolphin, Krita, Kwrite, Elisa,Spectacle, and more:
https://kde.org/announcements/gear/22.08.0/

GNOME apps also get some updates, for Newsflash, Bottles, Adwaita Manager, and more:
https://thisweek.gnome.org/posts/2022/08/twig-57/

The new "New file" menu for GNOME is coming, and it looks good!
https://ignapk.blogspot.com/2022/08/gsoc-2022-fourth-update-code.html

Kdenlive 22.08 brings performance enhancements, subtitles styling, and more:
https://kdenlive.org/en/2022/08/kdenlive-22-08-released/

The Tuxedo InfinityBook Pro 14 Gen 7, and the Starlabs StarBook Mk VI are available:

https://9to5linux.com/tuxedo-infinitybook-pro-14-gen7-linux-laptop-brings-alder-lake-cpus-new-colors

https://fr.starlabs.systems/pages/starbook?shpxid=194b636a-446e-4b29-84bc-e80cc4b32be5

Ubuntu might not ship the "security level" feature of GNOME 43:
https://www.omgubuntu.co.uk/2022/08/ubuntu-22-10-device-security-panel-disabled

Proton Experimental makes Vermintide 2 run on Linux
https://github.com/ValveSoftware/Proton/wiki/Changelog

Cemu 2.0, the Wii U emulator, is now open source and supports Linux:
https://www.reddit.com/r/cemu/comments/wwa22c/cemu_20_announcement_linux_builds_opensource_and/

SteamOS 3.4 will update the Arch base:
https://www.gamingonlinux.com/2022/08/steamos-34-beta-to-update-the-arch-linux-base-new-steam-deck-updates-out-now/


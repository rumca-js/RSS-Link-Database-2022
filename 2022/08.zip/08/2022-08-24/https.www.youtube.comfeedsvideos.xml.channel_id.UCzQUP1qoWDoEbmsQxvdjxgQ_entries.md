# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Mark Zuckerberg Answers to Facebook's Moderation of Controversial Content
 - [https://www.youtube.com/watch?v=BN3PIGLDscQ](https://www.youtube.com/watch?v=BN3PIGLDscQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-08-25 00:00:00+00:00

Taken from JRE #1863 w/Mark Zuckerberg:
https://open.spotify.com/episode/51gxrAActH18RGhKNza598?si=5456eb73d56d409f

## Joe Asks Former CIA Officer Mike Baker About the FBI Trump Raid
 - [https://www.youtube.com/watch?v=uPwlmwNQq8Y](https://www.youtube.com/watch?v=uPwlmwNQq8Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-08-24 00:00:00+00:00

Taken from JRE #1862 w/Mike Baker:
https://open.spotify.com/episode/0UKvqdwsLq3xfJLH6RQYpD?si=49b4e86f62684b61


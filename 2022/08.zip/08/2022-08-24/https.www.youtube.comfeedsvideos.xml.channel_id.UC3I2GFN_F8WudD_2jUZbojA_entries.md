# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Widowspeak - Everything Is Simple (Live on KEXP)
 - [https://www.youtube.com/watch?v=-J7c3SW74UQ](https://www.youtube.com/watch?v=-J7c3SW74UQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-25 00:00:00+00:00

http://KEXP.ORG presents Widowspeak performing “Everything Is Simple” live in the KEXP studio. Recorded July 28, 2022.

Molly Hamilton - Vocals / Guitar
Robert Earl Thomas - Guitar
John “Willy” Muse - Bass
Michael Stasiak - Drums

Host: Cheryl Waters
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://linktr.ee/widowspeakband
http://kexp.org

## Widowspeak - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=rQ1dGo6gYsY](https://www.youtube.com/watch?v=rQ1dGo6gYsY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-25 00:00:00+00:00

http://KEXP.ORG presents Widowspeak performing live in the KEXP studio. Recorded July 28, 2022.

Songs:
While You Wait
The Drive
True Blue
Everything Is Simple

Molly Hamilton - Vocals / Guitar
Robert Earl Thomas - Guitar
John “Willy” Muse - Bass
Michael Stasiak - Drums

Host: Cheryl Waters
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://linktr.ee/widowspeakband
http://kexp.org

## Widowspeak - The Drive (Live on KEXP)
 - [https://www.youtube.com/watch?v=B_OIuuKgC8k](https://www.youtube.com/watch?v=B_OIuuKgC8k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-25 00:00:00+00:00

http://KEXP.ORG presents Widowspeak performing “The Drive” live in the KEXP studio. Recorded July 28, 2022.

Molly Hamilton - Vocals / Guitar
Robert Earl Thomas - Guitar
John “Willy” Muse - Bass
Michael Stasiak - Drums

Host: Cheryl Waters
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://linktr.ee/widowspeakband
http://kexp.org

## Widowspeak - True Blue (Live on KEXP)
 - [https://www.youtube.com/watch?v=KC3y1wiHNYU](https://www.youtube.com/watch?v=KC3y1wiHNYU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-25 00:00:00+00:00

http://KEXP.ORG presents Widowspeak performing “True Blue” live in the KEXP studio. Recorded July 28, 2022.

Molly Hamilton - Vocals / Guitar
Robert Earl Thomas - Guitar
John “Willy” Muse - Bass
Michael Stasiak - Drums

Host: Cheryl Waters
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://linktr.ee/widowspeakband
http://kexp.org

## Widowspeak - While You Wait (Live on KEXP)
 - [https://www.youtube.com/watch?v=Ie3Wf-jq5a8](https://www.youtube.com/watch?v=Ie3Wf-jq5a8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-25 00:00:00+00:00

http://KEXP.ORG presents Widowspeak performing “While You Wait” live in the KEXP studio. Recorded July 28, 2022.

Molly Hamilton - Vocals / Guitar
Robert Earl Thomas - Guitar
John “Willy” Muse - Bass
Michael Stasiak - Drums

Host: Cheryl Waters
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://linktr.ee/widowspeakband
http://kexp.org

## Macklemore - Chant (Live on KEXP)
 - [https://www.youtube.com/watch?v=CtIdKxQXm5U](https://www.youtube.com/watch?v=CtIdKxQXm5U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-24 00:00:00+00:00

http://KEXP.ORG presents Macklemore performing “Chant” (featuring Tones and I) live in the KEXP studio. Recorded July 20, 2022.

Macklemore - Vocals
Tones And I - Vocals
Elan Wright - Guitar
Josh Rawlings - Piano

Choir:
Tanisha Brooks
Josephine Howell
Dana Jackson
Maelu Strange

Strings:
Andrew Joslyn - Violin
Christopher Foerstel - Violin
Maria Ritzenthaler - Viola
Rebecca Chung-Filice - Cello

Host: Kevin Cole
Audio Engineers: Julian Martlew, Jon Roberts & Jordan Santana
Audio Mixer: Jordan Santana
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Jonathan Jacobson
Editor: Scott Holpainen

https://macklemore.com
http://kexp.org

## Macklemore - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=dIQmUe-V008](https://www.youtube.com/watch?v=dIQmUe-V008)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-24 00:00:00+00:00

http://KEXP.ORG presents Macklemore performing live in the KEXP studio. Recorded July 20, 2022.

Songs:
Good Old Days
Otherside
Maniac
Chant

Macklemore - Vocals
Tones And I - Vocals (on "Good Old Days" and Chant")
Windser - Guitar / Vocals (on "Maniac")
Elan Wright - Guitar
Josh Rawlings - Piano

Choir:
Tanisha Brooks
Josephine Howell
Dana Jackson
Maelu Strange

Strings:
Andrew Joslyn - Violin
Christopher Foerstel - Violin
Maria Ritzenthaler - Viola
Rebecca Chung-Filice - Cello

Host: Kevin Cole
Audio Engineers: Julian Martlew, Jon Roberts & Jordan Santana
Audio Mixer: Jordan Santana
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Jonathan Jacobson
Editor: Scott Holpainen

https://macklemore.com
http://kexp.org

## Macklemore - Good Old Days (Live on KEXP)
 - [https://www.youtube.com/watch?v=QW4m45HTkE4](https://www.youtube.com/watch?v=QW4m45HTkE4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-24 00:00:00+00:00

http://KEXP.ORG presents Macklemore performing “Good Old Days” (featuring Tones and I) live in the KEXP studio. Recorded July 20, 2022.

Macklemore - Vocals
Tones and I - Vocals
Elan Wright - Guitar
Josh Rawlings - Piano

Choir:
Tanisha Brooks
Josephine Howell
Dana Jackson
Maelu Strange

Strings:
Andrew Joslyn - Violin
Christopher Foerstel - Violin
Maria Ritzenthaler - Viola
Rebecca Chung-Filice - Cello

Host: Kevin Cole
Audio Engineers: Julian Martlew, Jon Roberts & Jordan Santana
Audio Mixer: Jordan Santana
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Jonathan Jacobson
Editor: Scott Holpainen

https://macklemore.com
http://kexp.org

## Macklemore - Maniac (Live on KEXP)
 - [https://www.youtube.com/watch?v=nF-XorZaBSA](https://www.youtube.com/watch?v=nF-XorZaBSA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-24 00:00:00+00:00

http://KEXP.ORG presents Macklemore performing “Maniac” (featuring Windser) live in the KEXP studio. Recorded July 20, 2022.

Macklemore - Vocals
Windser - Guitar / Vocals
Elan Wright - Guitar
Josh Rawlings - Piano

Choir:
Tanisha Brooks
Josephine Howell
Dana Jackson
Maelu Strange

Strings:
Andrew Joslyn - Violin
Christopher Foerstel - Violin
Maria Ritzenthaler - Viola
Rebecca Chung-Filice - Cello

Host: Kevin Cole
Audio Engineers: Julian Martlew, Jon Roberts & Jordan Santana
Audio Mixer: Jordan Santana
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Jonathan Jacobson
Editor: Scott Holpainen

https://macklemore.com
http://kexp.org

## Macklemore - Otherside (Live on KEXP)
 - [https://www.youtube.com/watch?v=GcKrJ3AwL_U](https://www.youtube.com/watch?v=GcKrJ3AwL_U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-24 00:00:00+00:00

http://KEXP.ORG presents Macklemore performing “Otherside” live in the KEXP studio. Recorded July 20, 2022.

Macklemore - Vocals
Elan Wright - Guitar
Josh Rawlings - Piano

Choir:
Tanisha Brooks
Josephine Howell
Dana Jackson
Maelu Strange

Strings:
Andrew Joslyn - Violin
Christopher Foerstel - Violin
Maria Ritzenthaler - Viola
Rebecca Chung-Filice - Cello

Host: Kevin Cole
Audio Engineers: Julian Martlew, Jon Roberts & Jordan Santana
Audio Mixer: Jordan Santana
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Jonathan Jacobson
Editor: Scott Holpainen

https://macklemore.com
http://kexp.org


# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## The Billion Dollar Network No One Uses
 - [https://www.youtube.com/watch?v=LDhU295bUv4](https://www.youtube.com/watch?v=LDhU295bUv4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2022-08-25 00:00:00+00:00

Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
► Facebook: https://www.facebook.com/Coffeezilla-102981089132662
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://twitter.com/LeszczynskiEd
Video Editor: Harry Bagg  https://twitter.com/HarryRBagg
Virtual Production Software: Aximmetry https://aximmetry.com/

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.

## Youtuber Gets Sued By Crypto Millionaire
 - [https://www.youtube.com/watch?v=uPZOzWFr5KU](https://www.youtube.com/watch?v=uPZOzWFr5KU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2022-08-24 00:00:00+00:00

Read the full lawsuit here:
https://tokenist.com/wp-content/uploads/2022/08/https-ecf-gand-uscourts-gov-doc1-055114767957.pdf

Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
► Facebook: https://www.facebook.com/Coffeezilla-102981089132662
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://twitter.com/LeszczynskiEd
Video Editor: Harry Bagg  https://twitter.com/HarryRBagg
Virtual Production Software: Aximmetry https://aximmetry.com/

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.


# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## DJI Avata - wcale nie rozbiłem tego drona!
 - [https://www.youtube.com/watch?v=q5Js6m8TFrg](https://www.youtube.com/watch?v=q5Js6m8TFrg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-08-25 00:00:00+00:00

Ceny Avaty: https://bit.ly/3pHLyin
Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

W odcinku:
00:00 Gdzie zmieści się dron?
00:15 Misja
01:12 Misja - podejście drugie
03:59 Tor przeszkód - wersja łatwiejsza
04:09 Lot – Dawid
05:14 Lot – Patrycja
07:27 Sterowanie drążkiem - Patrycja
07:41 Sterowanie drążkiem – Dawid
08:08 Wideo z przelotu z komentarzem Kuby
11:59 Komentarz
12:12 Dlaczego DJI Avata to nie jest dron dla profesjonalistów?
13:46 Kamera i nagrywanie
15:14 Zasięg
15:39 Zestawy od DJI i ceny
16:18 DJI Avata – zabawka dla amatorów
16:49 Zakończenie


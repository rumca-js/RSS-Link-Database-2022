# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Coin – Brad Pitt (live for The Current)
 - [https://www.youtube.com/watch?v=7XuyxB4wh14](https://www.youtube.com/watch?v=7XuyxB4wh14)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-08-20 00:00:00+00:00

Nashville-based COIN are currently on tour following the release of their latest album, "Uncanny Valley." Watch COIN perform the song "Brad Pitt" during a session recorded at The Current. 

COIN are:
Chase Lawrence – vocals, keys
Joe Memmel – guitar
Ryan Winnen – drums
Matt Martin – bass

Credits
Host – Ayisha Jaffer  
Guests – COIN 
Technical director – Erik Stromstad 
Audio – Evan Clark
Camera Operators – Erik Stromstad, Peter Ecklund, Thor Cramer Bornemann
Video Editor – Eric Xu Romani 
Producers – Derrick Stevens, Jesse Wiza 
Digital producer – Luke Taylor 

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

#coin @thisiscoinmusic #chapstick


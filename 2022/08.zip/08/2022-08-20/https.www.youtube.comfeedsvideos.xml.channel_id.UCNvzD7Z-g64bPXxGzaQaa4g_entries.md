# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Ridiculous Video Game Cliff-Hangers That Never Got Resolved
 - [https://www.youtube.com/watch?v=JrJ2cdM1kUc](https://www.youtube.com/watch?v=JrJ2cdM1kUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-08-21 00:00:00+00:00

Some games end with serious cliffhanger endings that don't quite land, leave us beyond puzzled or even laughably unsatisfied.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:39 The Conduit 2
2:40 XIII
3:55 Dead Space 3 DLC
5:49 Shenmue 3
7:16 Condemned 2
8:08 Freedom Force vs. The Third Reich
9:10 Star Wars Force Unleashed 2
10:13 Darkness 2 
11:07 Mega Man Legends 2
11:56 Half-life 2

## Top 10 NEW Zombie Games of 2022
 - [https://www.youtube.com/watch?v=teQW8_m6Wuw](https://www.youtube.com/watch?v=teQW8_m6Wuw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-08-20 00:00:00+00:00

Looking for a new zombie game on PC, PS5, PS4, or Xbox Series X/S/One? We've got you covered with these upcoming game releases.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

10-Projekt Z 

Platform : PC

Release Date : TBA



9-REQUISITION VR

Platform : PC PS4

Release Date : Sep 22, 2022



8-Showa American Story

Platform : PC PS4 PS5

Release Date : TBA



7-No More Room in Hell 2 

Platform : PC

Release Date : October 31, 2022



6-Ill

Platform : PC

Release Date : TBA



5-Daymare: 1994 Sandcastle 

Platform : PC PS4 XBOX ONE PS5 XSX|S

Release Date : TBA 2022



4-Aftermath

Platform : PC PS4 XBOX ONE PS5 XSX|S

Release Date : TBA 2022



3-SurrounDead

Platform : PC 

Release Date : 24 Jun, 2022



2-Dying Light 2

Platform : PC PS4 XBOX ONE PS5 XSX|S 

Release Date : February 4, 2022



1-The Callisto Protocol

Platform : PC PS4 XBOX ONE PS5 XSX|S 

Release Date : December 2, 2022



Bonus:



Evil Dead the game

Platform : PC PS4 XBOX ONE PS5 XSX|S 

Release Date : May 13, 2022



Resident Evil Re:Verse

Platform : PC PS4 XBOX ONE PS5 XSX|S 

Release Date : Oct 28, 2022



Outbreak Island: Pendulum 

Platform : PC

Release Date : TBA


0:00 Intro
0:10 Projekt Z 
1:11 REQUISITION VR
2:13 Showa American Story
2:58 No More Room in Hell 2 
3:52 Ill
4:53 Daymare: 1994 Sandcastle 
5:42 Aftermath
6:37 SurrounDead
8:05 Dying Light 2
8:54 The Callisto Protocol
9:47 Bonus


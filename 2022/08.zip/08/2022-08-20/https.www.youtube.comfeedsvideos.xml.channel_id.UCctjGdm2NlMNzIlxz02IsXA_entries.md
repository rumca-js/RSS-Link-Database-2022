# Source:Chris Ray Gun, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA, language:en-US

## Better Than Breaking Bad?! - Ray Gun Retrospective (no spoilers)
 - [https://www.youtube.com/watch?v=moAz9DegY_4](https://www.youtube.com/watch?v=moAz9DegY_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCctjGdm2NlMNzIlxz02IsXA
 - date published: 2022-08-20 21:03:09+00:00

Go to https://buyraycon.com/raygun for 15% off your order! Brought to you by Raycon.

Breaking Bad was an S+ tier TV show. 

Social Media!
TWITTER ► https://twitter.com/ChrisRGun
INSTAGRAM ► https://www.instagram.com/chris_ray_gun/
TWITCH ► https://www.twitch.tv/chrisraygun
TIKTOK ► https://www.tiktok.com/@chrisraygun
SUBREDDIT ► https://www.reddit.com/r/ChrisRayGun/

Support Me Over Here!
MERCH ► https://teespring.com/stores/chris-ray-gun
PATREON ► https://www.patreon.com/ChrisRay

Podcasts!
SACRED SYMBOLS : A PLAYSTATION PODCAST ► https://apple.co/2Rqmklc
SNARK TANK ► https://www.youtube.com/c/TheSnarkTank


# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Fashion Police Squad | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=46hC07s9T-U](https://www.youtube.com/watch?v=46hC07s9T-U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-08-21 00:00:00+00:00

Jesse Galena reviews Fashion Police Squad, developed by Mopeful Games.

Fashion Police Squad on Steam: https://store.steampowered.com/app/1319460/Fashion_Police_Squad/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Path of Exile: The Lake of Kalandra | Newly Released with Amy and JM8
 - [https://www.youtube.com/watch?v=NGUqFcuJFEk](https://www.youtube.com/watch?v=NGUqFcuJFEk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-08-21 00:00:00+00:00

Welcome to our newest livestream series, "Newly Released", hosted by Amy Campbell. Each week Amy and a guest will be checking out the most interesting new game releases of the week from full game releases to early access game.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


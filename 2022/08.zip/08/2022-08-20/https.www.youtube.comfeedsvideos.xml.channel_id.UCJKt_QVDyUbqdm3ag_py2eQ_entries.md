# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: !Cube - Scotchman in a Skirt (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=wpmltu1NcMg](https://www.youtube.com/watch?v=wpmltu1NcMg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-08-20 00:00:00+00:00

"Scotchman in a Skirt" by !Cube/Trauma^SCS^TRC, 1st at Assembly 1998. C64 art "Technovikings" (2017) by iLKke/DataDoor^Funkenstört^RGCD.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 32 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does XM: Cactus - Encabeza Dura Mezo (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=VifRXIrWlA0](https://www.youtube.com/watch?v=VifRXIrWlA0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-08-20 00:00:00+00:00

"Encabeza Dura Mezo" (1998) by Cactus/HellTrot (Peter Kozak). Art "Dragon Eye" (1992?) by R.W.O./Kefrens.

Track name is Encabeza Dura Mezo, but sample data spells Mezo as Mazo.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 32 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does XM: Candybag - Gravity Drive (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=y9K4drMyOvw](https://www.youtube.com/watch?v=y9K4drMyOvw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-08-20 00:00:00+00:00

"Gravity Drive" (2000) by Candybag/Smeuch^Confine. C64 art "Medusa" (2019) by Fabs/Hokuto Force.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 32 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.


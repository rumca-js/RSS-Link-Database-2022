# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## I Wish We All Could Leave California (Beach Boys Parody)
 - [https://www.youtube.com/watch?v=huGXVJPjhl8](https://www.youtube.com/watch?v=huGXVJPjhl8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-08-20 00:00:00+00:00

The California Dream ain't what it used to be. In this parody of The Beach Boys' "California Girls", the Babylon Bee Boys express their yearning to leave the Golden State someday. #shorts 

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


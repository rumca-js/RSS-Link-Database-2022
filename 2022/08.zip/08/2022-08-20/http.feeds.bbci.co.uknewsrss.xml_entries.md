# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Why are bakers' fortunes on the rise?
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-61480259?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-61480259?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 23:58:51+00:00

What is helping purveyors of bread and cake bake back better?

## Tory leadership contest: Under-18s who get to pick the next PM
 - [https://www.bbc.co.uk/news/uk-politics-62585183?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62585183?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 23:58:36+00:00

They can't vote in general elections, but teen Tories are having a say on their next party leader.

## Cost of living: Help is coming, says Kwasi Kwarteng
 - [https://www.bbc.co.uk/news/uk-politics-62619761?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62619761?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 23:19:09+00:00

Kwasi Kwarteng, an ally of Tory leadership candidate Liz Truss, says the Treasury is "working on options".

## Inside Amapiano, the new sound of South Africa
 - [https://www.bbc.co.uk/news/world-africa-62552242?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-62552242?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 23:04:07+00:00

In Zulu, Amapiano literally means “the pianos” and it's a blend of house, kwaito, jazz, and lounge music.

## 'I broke the world record with my last ever run'
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-62470947?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-62470947?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 23:04:03+00:00

Kate Jayden, from Derbyshire, finished her final run on 15 April, despite suffering a broken knee.

## Demi Lovato is back, and this time she's angry
 - [https://www.bbc.co.uk/news/entertainment-arts-62603941?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62603941?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 23:00:48+00:00

"I'm owning my truths," says the star, whose new album takes aim at the press and the music business.

## Pondoland: South Africa's cannabis growers left behind by legalisation plans
 - [https://www.bbc.co.uk/news/world-africa-62524501?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-62524501?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 23:00:35+00:00

South Africa is on the brink of legalising cannabis, but many traditional growers feel left out.

## Greece promotes smaller islands over Mykonos and Corfu
 - [https://www.bbc.co.uk/news/business-62595814?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62595814?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 23:00:17+00:00

Greece promotes its lesser-known holiday destinations, but do locals embrace the trend?

## Jurgen Klopp: Liverpool should get points if Manchester United game postponed over protests
 - [https://www.bbc.co.uk/sport/football/62620170?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62620170?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 21:30:31+00:00

Jurgen Klopp believes Liverpool should be awarded the points if their Premier League match against Manchester United is postponed over fan protests.

## European Championships 2022: Keely Hodgkinson claims 800m gold
 - [https://www.bbc.co.uk/sport/athletics/62618928?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/62618928?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 21:03:13+00:00

Great Britain's Keely Hodgkinson wins her first major outdoor title as she claims gold in the women's 800m at the European Championships.

## Arsenal mentality shift 'crazy' - how far can Mikel Arteta's Gunners go?
 - [https://www.bbc.co.uk/sport/football/62620534?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62620534?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 20:28:30+00:00

Arsenal look like a team reborn as three straight wins send them top - with Aaron Ramsdale saying their change in mentality has been "crazy" - so just how far can the Gunners go?

## Zulu King Misuzulu ka Zwelithini crowned in South Africa
 - [https://www.bbc.co.uk/news/world-africa-62604497?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-62604497?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 15:30:00+00:00

Misuzulu ka Zwelithini takes the throne in spite of some relatives and royals launching legal challenges.

## European Championships Munich 2022: Great Britain's gymnasts claim stunning men's team gold
 - [https://www.bbc.co.uk/sport/gymnastics/62618597?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/gymnastics/62618597?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 15:17:43+00:00

Great Britain dominate with a stunning performance in the gymnastics men's team final at the European Championships in Munich.

## BTec delays: Exam board Pearson apologies to students waiting for results
 - [https://www.bbc.co.uk/news/education-62617693?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-62617693?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 14:34:40+00:00

Some students have still not received their BTec results which were due out on Thursday.

## Tottenham Hotspur 1-0 Wolverhampton Wanderers
 - [https://www.bbc.co.uk/sport/football/62529371?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62529371?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 14:32:39+00:00

Harry Kane scores his 250th goal for Tottenham as they move top of the Premier League with a hard-fought win over Wolves.

## European Aquatics Championships: Spendolini-Sirieix and Toulson win gold
 - [https://www.bbc.co.uk/sport/av/swimming/62617801?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/swimming/62617801?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 14:22:16+00:00

Watch GB's Andrea Spendolini-Sirieix and Lois Toulson win gold in the women's synchronised 10m at the European Aquatics Championships.

## Rail strikes: Passengers told not to travel by rail as disruption hits
 - [https://www.bbc.co.uk/news/business-62612433?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62612433?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 13:48:59+00:00

Rail passengers face further disruption amid the sixth one-day strike of the summer.

## Actor Stephen Tompkinson due in court charged with inflicting GBH
 - [https://www.bbc.co.uk/news/uk-england-tyne-62617439?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tyne-62617439?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 12:40:09+00:00

The CPS says DCI Banks star Stephen Tompkinson, who denies the charge, is due in court in September.

## UK record after Welsh man shears 902 sheep in nine hours
 - [https://www.bbc.co.uk/news/uk-wales-62615764?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-62615764?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 12:34:35+00:00

Lloyd Rees, 28, beat the previous record, set last week, by more than 20 sheep.

## Ukraine displays destroyed Russian tanks in Kyiv
 - [https://www.bbc.co.uk/news/world-europe-62617278?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62617278?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 11:54:21+00:00

Destroyed Russian military vehicles are on display in Kyiv, ahead of Ukraine's Independence Day.

## Jonah Hill to stop promoting films to protect his mental health
 - [https://www.bbc.co.uk/news/newsbeat-62605099?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-62605099?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 10:17:41+00:00

A psychologist says the Superbad actor "should be applauded" for opening up about anxiety attacks.

## Seized Russian superyacht to go under the hammer
 - [https://www.bbc.co.uk/news/world-europe-62615958?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62615958?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 09:32:39+00:00

The monster boat can sleep 12 guests and boasts a swimming pool, jacuzzi, spa and 3D cinema.

## Droylsden: Man charged after girl, 6, abducted and sexually assaulted
 - [https://www.bbc.co.uk/news/uk-england-manchester-62616385?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-62616385?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 08:55:02+00:00

A 23-year-old is charged after the abduction and sexual assault of a girl, who was later found.

## DJ Archie, aged seven, has hopes of playing Glastonbury
 - [https://www.bbc.co.uk/news/uk-england-essex-62605367?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-62605367?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 06:30:48+00:00

He became the world's youngest club DJ aged four and has since built a huge social media following.

## 250 rabbits to be given to activists as farm closes
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-62590106?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-62590106?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 06:19:19+00:00

Comedian Ricky Gervais is among those to have spoken out against T&amp;S Rabbits.

## Capturing Ireland's love of surfing
 - [https://www.bbc.co.uk/news/uk-northern-ireland-62574877?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-62574877?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 05:47:30+00:00

Ulster Transport Museum's new exhibition explores the sport's rich history here since the 1960s.

## Oleksandr Usyk v Anthony Joshua 2: Pundits and pros make predictions for heavyweight world title fight
 - [https://www.bbc.co.uk/sport/boxing/62570082?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/62570082?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 05:27:46+00:00

Can Anthony Joshua gain revenge over Oleksandr Usyk? Is the Ukrainian simply too good to beat? We have some predictions from the boxing world.

## Untreated sewage causes beaches to shut
 - [https://www.bbc.co.uk/news/uk-62614739?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62614739?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 03:33:32+00:00

Untreated wastewater has caused beaches across the South East to close due to a pollution risk.

## How students missing exams in pandemic felt 'stressed and alone'
 - [https://www.bbc.co.uk/news/uk-62593667?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62593667?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 00:12:46+00:00

Students receiving their A-level results speak about the struggles of studying during a pandemic.

## Train and Tube strikes: Salon owner says strikes make it feel like the pandemic
 - [https://www.bbc.co.uk/news/uk-62602410?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62602410?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 00:12:29+00:00

Cancellations and no-shows - how industrial action on transport is affecting the hospitality business.

## Aretha Franklin Prom will explore 'the core of who she was'
 - [https://www.bbc.co.uk/news/entertainment-arts-62565695?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62565695?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 00:11:05+00:00

Conductor Jules Buckley says the show will take a journey from the church to the top of the charts.

## UK drought: Why do the trees think it's autumn already?
 - [https://www.bbc.co.uk/news/science-environment-62582186?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62582186?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-20 00:07:31+00:00

Experts say the unusual weather has triggered a 'false autumn' as trees struggle to cope with drought.


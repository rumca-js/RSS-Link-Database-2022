# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Complete Travels of Elendil | Tolkien Explained
 - [https://www.youtube.com/watch?v=YZwNdFxnboQ](https://www.youtube.com/watch?v=YZwNdFxnboQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-08-20 00:00:00+00:00

Elendil is one of the greatest Kings of Men to ever walk Middle-earth. He is so revered that it's his heights to which Aragorn aspires over 3000 years later.  Today, we cover his early life in Númenor, exile from the Downfall, founding Arnor, writing the Akallabêth, and his final showdown with Sauron in the War of the Last Alliance.  Prep for a major character in The Rings of Power with the Complete Travels of Elendil!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Tulikoura - https://www.deviantart.com/tulikoura
Matthew Stewart - http://www.matthew-stewart.com/
BellaBergolts - https://www.deviantart.com/bellabergolts
Magdalena Katanska - https://www.artstation.com/magdalenakatanska/prints  https://www.instagram.com/qualiney
Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc
Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri
Noe Leyva - https://twitter.com/NoeLeyvArt
Clemence Morisseau - https://www.artstation.com/kahirie
Edvige Faini - www.edvigefaini.com , www.facebook.com/edvige.faini , www.instagram.com/edvige_faini

Elendil the Tall - Tolman Cotton
Elendil - Ralph Damiani
Strider - CK Goksoy
The Ships of the Faithful - Ted Nasmith
Annuminas - Ted Nasmith
Sauron faces Elendil and Gil-galad on Orodruin - Kip Rasmussen
Dark Omens - Ralph Damiani
Ar-Pharazon - Tom Romain
Adunakhori - Tom Romain
Arnor Borderguards - Tom Romain
Ar-Pharazon - Steamey
The Last Hunt - Turner Mohan
Andunie, Numenor - David Greset
Numenorean Armor - Turner Mohan
Ar-Pharazon in Armor - Skullb*st*rd
Romenna, Port of Numenor - David Greset
Sauron bows, submits to Ar-Pharazon - Kip Rasmussen
Armenelos - Skullb*st*rd
Numenor - Sarka Skorpikova
Annatar Chained - Skullb*st*rd
Ar-Pharazon, old - Skullb*st*rd
Ar-Pharazon's Ships - John Howe
Earendil's Ships - John Howe
Earendil - Jenny Dolfen
Numenorean - Matthew Stewart
Stranger in city - Felix Englund
Elendil - Ralph Damiani
Drakar - David Greset
Romenna - Matej Cadil
Dangerous Alliance - Anke Eissmann
Armenelos - Ralph Damiani
Eldalonde - Ralph Damiani
Andunie - Ralph Damiani
Eldalonde - David Greset
A Palantir - Anke Eissmann
Isildur with a sapling of the White Tree of Nimloth - Sara Morello
Aragorn - Matthew Stewart
Armenelos - Skullb*st*rd
Aldarion Returns from his First Voyage - Ted Nasmith
Ar-Pharazon - Dracarysdrekkar7
Iluvatar's Mighty Theme - Kuliszu
The Sundering - Ralph Damiani
Queen Tar-Miriel - Ted Nasmith
Fall of Numenor - Alan Lee
Earendil Searches Tirion - Ted Nasmith
Out of the Sea I am Come - Turner Mohan
The Construction of Orthanc - Ralph Damiani
Tower on the coast - David Greset
The End of the Age - Ted Nasmith
Cirdan, Lord of the Falathrim - Peter Xavier Price
Palantir of Elostirion - Matej Cadil
Sea Colors - David Greset
Under Construction - Bryan Bitter
Drowning of Andunie - John Howe
Aldarion and Erendis - Steamey
Minas Tirith - Alan Lee
Spirit of Sauron - Skullb*st*rd
Sauron - Shadow of War
Sauron's Armies - Shadow of War
Minas Ithil Destruction - Shadow of War
Dark Omens - Ralph Damiani
Weathertop - Dracarysdrekkar7
Rivendell - Jerry Vanderstelt
Gil-galad & the Last Alliance - Jenny Dolfen
Vanyar - Jenny Dolfen
The Meeting at Amon Sul - Anke Eissmann
The Black Gate - Ralph Damiani
The Dark Tower - Alan Lee
Isildur and Sauron - Tulikoura
Sauron and Mount Doom - Felix Englund
Sauron, War of the Last Alliance - Matt DeMino
Breaking of Narsil - John Howe
Isildur cuts the Ring - Denis Gordeev
Across Gorgoroth - Ted Nasmith
Gil-galad, Sauron, Elendil - Tom Romain
The Doom of Men - Ralph Damiani
Stalker - Skullb*st*rd
Isildur's Bane - Andrea Piparo
Minas Tirith - Ralph Damiani
The Path to Amon Anwar - Matej Cadil
Departure from Gondor - Anke Eissmann
Earnil I of Gondor - Matej Cadil
Symbelmyne - Anato Finnstark
The Oathtaking of Cirion and Eorl - Ted Nasmith
The Oath of Cirion and Eorl - Anke Eissmann
The Oathtaking of Cirion and Eorl - Ted Nasmith
Rath Dinen - Matej Cadil
Tower Hall of Denethor - Peter Xavier Price
Standing Silence - Catherine Karina Chmiel
Jerry Vanderstelt - Sauron
Strider reveals his identity - Anke Eissmann
Shard of Narsil, Aragorn - Matthew Stewart
The Shadow of Sauron - Ted Nasmith
The Crowning of Elessar - Tolman Cotton
Aragorn - Kuliszu
Out of the Sea I am Come - Turner Mohan
King Aragorn - Steve Airola

#elendil #tolkien #theringsofpower


# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## How Billionaires Will Act During The Apocalypse
 - [https://www.youtube.com/watch?v=pwJQEAI_KE0](https://www.youtube.com/watch?v=pwJQEAI_KE0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2022-08-20 00:00:00+00:00

Order "Survival of the Richest" by Douglas Rushkoff here-
U.S.: https://wwnorton.com/books/survival-of-the-richest
CANADA: https://amzn.to/3c2l0Fn

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge


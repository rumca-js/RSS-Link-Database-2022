# Source:Black Pidgeon Speaks, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmrLCXSDScliR7q8AxxjvXg, language:en-US

## Forget DEAD Internet: WEF & Google are DELETING It
 - [https://www.youtube.com/watch?v=aWhzHECM9is](https://www.youtube.com/watch?v=aWhzHECM9is)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmrLCXSDScliR7q8AxxjvXg
 - date published: 2022-08-20 18:07:46+00:00

Forget DEAD Internet: WEF & Google are DELETING It


# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Great questions on depression
 - [https://www.youtube.com/watch?v=nlmWDm8cRxw](https://www.youtube.com/watch?v=nlmWDm8cRxw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-08-20 00:00:00+00:00

Thanks to Neil Oliver and GB news for an excellent series of questions with massive implications for good health and health care.


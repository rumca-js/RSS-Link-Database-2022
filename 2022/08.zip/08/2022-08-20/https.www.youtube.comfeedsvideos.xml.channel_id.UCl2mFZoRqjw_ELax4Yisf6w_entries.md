# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## NYC district attorney reduces attempted murder to misdemeanor
 - [https://www.youtube.com/watch?v=qvn4AwQxJUQ](https://www.youtube.com/watch?v=qvn4AwQxJUQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-08-21 00:00:00+00:00

Article: https://nypost.com/2022/08/20/gov-hochul-blasts-district-attorneys-who-undercharge-perps/

Context: https://www.youtube.com/watch?v=ycULqJUydH0

More context: https://www.youtube.com/watch?v=ctv5JzDPWCE

This is not new: https://gothamist.com/news/councilwoman-knockout-attacks-triggered-by-resentment-of-jewish-success

This is not new: https://observer.com/2013/12/laurie-cumbo-apologizes-for-controversial-knockout-game-letter/

https://www.youtube.com/watch?v=15HTd4Um1m4


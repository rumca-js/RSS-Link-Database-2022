# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The BEST VR FPS Games Available NOW (Quest 2, PCVR)
 - [https://www.youtube.com/watch?v=o_VCBI74xhk](https://www.youtube.com/watch?v=o_VCBI74xhk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-08-20 00:00:00+00:00

Hello! Today we are going to take a look at 5 of the most highly played VR FPS games and compare them to find out which on is my favorite and maybe figure out which one is your favorite! It seems like I actually have found my new favorite... Doesn't matter whether you're QUest 2 or SteamVR, there's something for you!

Today we're looking at: 
Onward: 
https://www.oculus.com/experiences/quest/2677344882310094/
https://store.steampowered.com/a

Pavlov:
https://store.steampowered.com/a
Pavlov Shack on AppLab

Vail:
https://store.steampowered.com/a

Population One:
https://store.steampowered.com/app/691260/POPULATION_ONE/
https://www.oculus.com/experiences/quest/2564158073609422/

And my new personal favorite.. Contractors:
https://www.oculus.com/experiences/quest/2564158073609422/
https://www.oculus.com/experiences/quest/2436897736439055/


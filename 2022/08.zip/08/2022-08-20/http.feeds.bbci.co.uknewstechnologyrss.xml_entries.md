# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Is there a green solution to the vinyl record backlog?
 - [https://www.bbc.co.uk/news/technology-62426472?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62426472?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-08-20 23:10:58+00:00

Green Vinyl Records is taking the vinyl out of vinyl to offer more environmentally-friendly LPs.


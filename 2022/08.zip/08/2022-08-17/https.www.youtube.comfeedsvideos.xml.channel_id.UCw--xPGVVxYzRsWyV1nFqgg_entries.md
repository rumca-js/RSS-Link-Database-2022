# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## If Mimics Were Real (Skit)
 - [https://www.youtube.com/watch?v=-YJyC000NuY](https://www.youtube.com/watch?v=-YJyC000NuY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-08-18 00:00:00+00:00

Are mimics even attacking, or just very competitive at hide and go seek tag? 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## Holy Iron Chain Knights - Berserk Vol. 16 [Part 2] & Vol 17 [Part 1]
 - [https://www.youtube.com/watch?v=5y3Lgsebs2I](https://www.youtube.com/watch?v=5y3Lgsebs2I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-08-17 00:00:00+00:00

Let's talk about #Berserk and the Holy Iron Chain Knights! 
This video is about Deluxe Edition 6 - Vol. 16 [Part 2] and Vol 17 [Part 1], which includes chapters:
"The Holy Iron Chain Knights 1-" and "The Hollow Idol" as well as "The Unseen", "Night of Miracles", "Past and Future", and "Morning of Truth".

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## How to Run Windows From a USB Drive (Win 10 or 11)
 - [https://www.youtube.com/watch?v=w34x1kBZN6c](https://www.youtube.com/watch?v=w34x1kBZN6c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-08-17 00:00:00+00:00

Yes, it's possible, here's how!

⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

Rufus: https://rufus.ie/
Windows 11 ISO: https://www.microsoft.com/software-download/windows11
Windows 10 ISO: https://www.microsoft.com/en-us/software-download/windows10

▼ Time Stamps: ▼
0:00 - Intro & Requirements
0:44 - Downloading Rufus
1:02 - Obtaining Windows 11 ISO
1:43 - Obtaining Windows 10 ISO
2:18 - Burning the Bootable USB
4:50 - Booting Up the USB (Disabling Secure Boot)
6:26 - Booting Into Windows
7:30 - Limitations of Windows To Go

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


# Source:Climate Town, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA, language:en-US

## The Supreme Court Declares War On The Environment | Climate Town
 - [https://www.youtube.com/watch?v=4wvAwVwc6sY](https://www.youtube.com/watch?v=4wvAwVwc6sY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA
 - date published: 2022-08-17 18:30:09+00:00

Is the plan to buy more air? Patreon: https://www.patreon.com/ClimateTown
sUbScRiBe FoR mOrE ViDeOs: https://www.youtube.com/c/climatetown?sub_confirmation=1

Climate Changemakers
https://www.climatechangemakers.org/action-menu
https://www.climatechangemakers.org/blog/wv-epa
https://www.climatechangemakers.org/action-playbook-public-utilities
https://www.audubon.org/magazine/fall-2019/get-know-your-public-utility-commission-and

Local Action:
https://www.commoncause.org/find-your-representative/
Urban Green: https://www.urbangreencouncil.org/content/projects/advancing-electrification
Sierra Club: https://www.sierraclub.org/articles/2019/12/building-electrification-action-plan-outlines-how-policymakers-can-equitably-phase
RMI: https://rmi.org/our-work/building-electrification/
Greenlining: http://greenlining.org/publications/reports/2019/equitable-building-electrification-a-framework-for-powering-resilient-communities/
Contact your senators: https://contactsenators.com/
Contact your representatives: https://www.house.gov/representatives/find-your-representative

MAYORS
https://www.globalcovenantofmayors.org/
https://phys.org/news/2018-11-americans-elected-mayors-climate.html
https://weather.com/news/climate/video/who-has-a-climate-change-message-for-your-mayor
https://www.usmayors.org/mayors/meet-the-mayors/
https://www.c2es.org/document/mayors-leading-the-way-on-climate-2020/

Things to Google: 
“Find my local city council meeting” + [Your city/state or zip code]
“Public Utilities Commission” + [Your state]
“Mayor climate change policies” + [Your mayor’s name or city name] 
https://www.c2es.org/document/mayors-leading-the-way-on-climate-2020/

Discord Server: https://discord.gg/HFHgfMgchp

Climate Town episode on Zoning & Housing reform: https://youtu.be/SfsCniN7Nsc

https://podcasts.apple.com/us/podcast/west-virginia-v-epa-worst-case-scenario-and-what-comes-next/id1439735906?i=1000569674617
https://www.hottakepod.com/otherposts/battle-supreme-2/
https://www.theatlantic.com/science/archive/2022/06/scotus-epa-ruling-west-virginia/661448/

And if you’ve got some time and want to read the full text of the ruling, it’s right here:
https://www.supremecourt.gov/opinions/21pdf/20-1530_n758.pdf


SOURCES:
*Absolute huge credit to climate journalists like Amy Westervelt @amywestervelt, Emily Atkin @emorwee, Matthew Lewis @mateosfo and ⬇️ 
History:
Donora: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5922205/
Cuyahoga: https://www.smithsonianmag.com/history/cuyahoga-river-caught-fire-least-dozen-times-no-one-cared-until-1969-180972444/
Smog LA: https://timeline.com/la-smog-pollution-4ca4bc0cc95d
https://www.scientificamerican.com/article/the-epa-first-40-years/
https://www.epa.gov/sites/default/files/2016-03/documents/background_paper.pdf
https://www.google.com/books/edition/The_Air_Quality_Act_of_1967/tjMTf_X5hLoC?hl=en&amp;gbpv=1&amp;pg=PP1&amp;printsec=frontcover

EPA:
https://www.epa.gov/air-trends/air-quality-national-summary
https://news.bloomberglaw.com/environment-and-energy/states-adopt-california-car-rules-amid-national-standards-debate
Cars in Cities: https://nap.nationalacademies.org/resource/25334/interstate/assets/meeting6/1%20Travel%20Forecast/PolzinSteven.pdf

Clean Power Plan:
https://www.epa.gov/sites/default/files/2018-08/documents/ace_legal_bser.pdf
https://www.vox.com/2019/6/19/18684054/climate-change-clean-power-plan-repeal-affordable-emissions
https://www.washingtonpost.com/news/volokh-conspiracy/wp/2016/02/09/supreme-court-puts-the-brakes-on-the-epas-clean-power-plan/
https://staging1.epsa.org/power-sector-meets-clean-target-a-decade-early-thanks-to-competitive-markets/

West Virginia vs. EPA:
https://www.scotusblog.com/case-files/cases/west-virginia-v-environmental-protection-agency/
https://www.vox.com/2022/2/23/22937517/supreme-court-epa-west-virginia-clean-power-plan-climate-change
http://progressivereform.org/cpr-blog/major-questions-about-major-questions-doctrine/
https://en.wikipedia.org/wiki/West_Virginia_v._EPA
https://www.hottakepod.com/battle-supreme/
https://www.theenergymix.com/2022/07/04/climate-math-gets-harder-as-radicalized-supreme-court-upends-u-s-carbon-regulation/

RAGA:
https://www.drilledpodcast.com/guess-who-raga/
https://documented.net/reporting/new-filing-shows-massive-dark-money-support-from-judicial-crisis-network-to-republican-attorneys-general-association
https://documented.net/investigations/one-year-later-the-republican-attorneys-general-association-and-the-capitol-insurrection
https://www.washingtonpost.com/news/energy-environment/wp/2018/03/14/scott-pruitts-25000-soundproof-phone-booth-it-actually-cost-more-like-43000/

CHANNELS THAT ARE BOTH GREAT AND RELEVANT : 
Not Just Bikes - https://www.youtube.com/c/NotJustBikes 
City Beautiful - https://www.youtube.com/c/CityBeautiful

Written by Rollie Williams and Nicole Conlan editing by Ben Boult & Matt Nelsen 
Opening Graphics by Ian MK Cessna (https://ianhasawebsite.com/)
Theme music by Gratis (https://www.gratistheband.com/)


# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## She-Hulk - It's A "Comedy"
 - [https://www.youtube.com/watch?v=_In2SR4_k2E](https://www.youtube.com/watch?v=_In2SR4_k2E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-08-17 00:00:00+00:00

Since we're just a day or two out from the release of She-Hulk Attorney At Law, which I'm sure will be a hilariously entertaining legal comedy, I thought I'd take a look at some of the clips that have been released so far, so we can all bask in the glow of comedy gold.


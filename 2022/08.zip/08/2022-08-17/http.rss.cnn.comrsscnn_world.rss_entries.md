# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## The coworkers who fell in love when they shared a hotel room
 - [https://www.cnn.com/travel/article/chance-encounters-norwegian-hotel-coworkers/index.html](https://www.cnn.com/travel/article/chance-encounters-norwegian-hotel-coworkers/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-08-17 08:53:22+00:00

When Ida Skibenes pulled up outside the Solstrand Hotel, her stomach was in knots, flipping between nerves and excitement.


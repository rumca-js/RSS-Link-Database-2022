# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## So, It WAS All A Scam
 - [https://www.youtube.com/watch?v=Ub8BgowUE2M](https://www.youtube.com/watch?v=Ub8BgowUE2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-08-18 00:00:00+00:00

Private health care companies are scamming us. Today I'm joined by Dr Bob Gill who tells me all about the privatization of healthcare, how the pandemic response was about profit, big pharma's funding of the FDA and its biased medical research. You will LOVE this! 
#health #healthcare #pandemic 
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## This Is A Disgrace
 - [https://www.youtube.com/watch?v=O8A0gWznOIw](https://www.youtube.com/watch?v=O8A0gWznOIw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-08-17 00:00:00+00:00

As Pfizer announces the capture of Global Blood Therapeutics, should we really still view them as a pharmaceutical company that warrants our praise, or instead a monopolistic investment corporation that gives billions of dollars to its shareholders annually by buying up smaller firms?  
#pfizer #vaccine #covid 

References
https://www.wsj.com/articles/pfizer-reaches-5-4-billion-deal-for-global-blood-therapeutics-11659954601
https://www.theguardian.com/commentisfree/2022/feb/08/big-pharma-global-vaccine-rollout-covid-pfizer
https://theintercept.com/2022/08/03/pfizer-investors-drug-pricing/
https://www.commondreams.org/news/2022/01/13/after-year-vaccine-profiteering-pfizer-hikes-prices-125-drugs
https://www.opensecrets.org/news/2020/04/dc-lawmakers-stocks-pharmaceutical-tech/
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


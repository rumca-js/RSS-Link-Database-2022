# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## VLC BANNED in India, Pine64 troubles, and Linux is unstable? - Linux and Open Source News
 - [https://www.youtube.com/watch?v=MXlsgBNRTR4](https://www.youtube.com/watch?v=MXlsgBNRTR4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-08-18 00:00:00+00:00

Make sure your PHP applications stay relevant for longer: https://bit.ly/3djMBCj
Grab a brand new laptop or desktop running Linux:https://www.tuxedocomputers.com/


👏 SUPPORT THE CHANNEL:
Get access to a weekly podcast, vote on the next topics I cover, and get your name in the credits:

YouTube: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join
Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

📹 MORE VIDEOS FROM ME
Linux news in Shorts format: https://www.youtube.com/channel/UCtZp0mK9IBrpS2-jNzMZmoA
Gaming on Linux: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw
I'm also on ODYSEE: https://odysee.com/$/invite/@TheLinuxExperiment:e

🏆 FOLLOW ME ELSEWHERE:
Twitter : http://twitter.com/thelinuxEXP
Mastodon: https://mastodon.social/web/@thelinuxEXP
Pixelfed: https://pixelfed.social/TLENick
Discord: https://discord.gg/xK7ukavWmQ

📷 GEAR I USE:
Sony Alpha A6600 Mirrorless Camera: https://amzn.to/30zKyn7
Sigma 56mm Fixed Prime Lens: https://amzn.to/3aRvK5l
Logitech MX Master 3 Mouse: https://amzn.to/3BVI0Od
Bluetooth Space Grey Mac Keyboard: https://amzn.to/3jcJETZ
Logitech Brio 4K Webcam: https://amzn.to/3jgeTh9
LG Curved Ultrawide Monitor: https://amzn.to/3pcTVDH
Logitech White Speakers: https://amzn.to/3n6wSb0
Xbox Controller: https://amzn.to/3BWmIA3
*Amazon Links are affiliate codes and generate small commissions to support the channel*

This video is distributed under the Creative Commons Share Alike license.

#linux #opensource #news 


00:00 Intro
00:37 Sponsor: Extend the lifecycle of your PHP applications
01:26 VLC is still banned in India for a bogus reason
02:43 GNOME weekly updates 
04:11 Libadwaita isn't the theming nightmare people thought
05:15 GlibC update breaks gaming, raises questions about stability
06:39 elementary OS updates
07:54 KDE Weekly updates
09:10 Trouble in Pine64 land
10:48 GNOME 43 beta for GNOME's 25th Birthday
12:04 SteamOS rebase, Heroic, Proton and Wine updates
13:49 Sponsor: Get a device that runs Linux perfectly
14:58 Support the channel

VLC is banned in India because Windows security is terrible:
https://www.indiatoday.in/technology/news/story/vlc-media-player-banned-in-india-website-and-vlc-download-link-blocked-1987361-2022-08-12

GNOME Weekly updates:
https://thisweek.gnome.org/posts/2022/08/twig-56/

Libadwaita doesn't look like the theming nightmare we were expecting:
https://www.omgubuntu.co.uk/2022/08/nautilus-43-beta-arrives-in-ubuntu-22-10-daily-builds

GlibC update breaks linux gaming, raises questions about Linux stability:
https://github.com/ValveSoftware/Proton/issues/6051

https://twitter.com/Plagman2/status/1559683905904463873

https://blog.hiler.eu/win32-the-only-stable-abi/

elementary OS monthly updates:
https://blog.elementary.io/updates-for-july-2022/

KDE Weekly updates:
https://pointieststick.com/2022/08/12/this-week-in-kde-major-accessibility-improvements/

Troubles in Pine64 land:
https://blog.brixit.nl/why-i-left-pine64/

GNOME 43 Beta is out, with major Nautilus improvements:
https://www.phoronix.com/news/GNOME-43-Beta

https://www.omgubuntu.co.uk/2022/08/gnome-43-file-manager-improvements

SteamOS gets a rebase, Heroic Games Launcher has a big update, and Proton and Wine get some new stuff:
https://www.gamingonlinux.com/2022/08/heroic-games-launcher-v240-is-out-with-gog-cloud-save-support/

https://boilingsteam.com/steam-deck-full-overview/

https://github.com/ValveSoftware/Proton/releases/tag/proton-7.0-4

https://www.winehq.org/announce/7.15


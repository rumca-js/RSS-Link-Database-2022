## University Professor Explains Surprising Ties Between Abortion and ‘LGBT’ Identity
 - [https://dailycitizen.focusonthefamily.com/university-professor-explains-surprising-ties-between-abortion-and-lgbt-identity/](https://dailycitizen.focusonthefamily.com/university-professor-explains-surprising-ties-between-abortion-and-lgbt-identity/)
 - RSS feed: https://dailycitizen.focusonthefamily.com
 - date published: 2022-08-17 20:45:33+00:00

University Professor Explains Surprising Ties Between Abortion and ‘LGBT’ Identity


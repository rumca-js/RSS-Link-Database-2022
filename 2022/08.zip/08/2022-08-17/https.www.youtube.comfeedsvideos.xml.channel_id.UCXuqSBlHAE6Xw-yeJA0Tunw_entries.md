# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I’ve been waiting TOO long
 - [https://www.youtube.com/watch?v=bafzQBSktwk](https://www.youtube.com/watch?v=bafzQBSktwk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-08-18 00:00:00+00:00

Thanks to Samsung Display for sending us the MSI Raider GE67 to check out their 240Hz VRR OLED display! You can learn more about all the innovative OLED Display Tech that Samsung Display has developed at https://oledera.samsungdisplay.com

If you're interested in the MSI Raider GE67, you can purchase your own at https://msi.gm/3w2G2KQ or learn more about the product at https://msi.gm/3C8Wqxs

Samsung sent us this sweet MSI gaming laptop that contains a pleasant OLED surprise. It’s a world’s first for portable PC gaming and we’re so grateful to get a hands-on experience with it. Find out why we’re so excited for the future of OLED gaming laptops.

Discuss on the forum: https://linustechtips.com/topic/1450184-ive-been-waiting-too-long-sponsored/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:03 High Refresh Rate Advantages
2:22 Faster Response Time Advantages
4:10 Dark Colors on OLEDs
4:39 Resolution
5:59 Power Consumption and Eye Strain
6:51 Greater Contrast Available
8:39 Raider GE67 Overview
10:12 Credits

## I hope you don't need internet.... - PfSense Router Update
 - [https://www.youtube.com/watch?v=pnv87pW6d-U](https://www.youtube.com/watch?v=pnv87pW6d-U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-08-17 00:00:00+00:00

🌏Get Exclusive NordSecurity deals here ➼ https://nordsecurity.com/linus All products are risk-free with Nord's 30-day money-back guarantee!✌

Go to https://privacy.com/linus ​to get $5 off your first purchase!

We're upgrading our internet and figured it was the perfect time to upgrade our router too! I just hope no one at the office needs internet because there's gonna be a smidge of downtime... :P

Discuss on the forum: https://linustechtips.com/topic/1449999-i-hope-you-dont-need-internet/

Check out the SuperMicro IoT SuperServer: https://lmg.gg/rNliW
Check out Ubiquiti UniFi Network Switches: https://lmg.gg/GoTL5

Check out pfSense: https://lmg.gg/1zhyX
Check out OPNsense: https://lmg.gg/Maox4

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:07 UNBOXING
2:12 Linus breaks the internet & mini rack tour
6:45 Upgrading the new router
14:35 Booting & Installing
16:52 Configuration
18:49 Cable Hell
22:51 SPEED TEST
23:47 We switched to OPNSense

## This server lives underwater! - Hypertec Immersion Cooling
 - [https://www.youtube.com/watch?v=2Q0bLo5nSsU](https://www.youtube.com/watch?v=2Q0bLo5nSsU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-08-17 00:00:00+00:00

Learn more about MSI's back to school sale and giveaway here: https://msi.gm/3Q5BRWn

Cooling is an expensive business for servers and datacenters, often involving HVAC. As CPUs and GPUs pull more power, more exotic solutions are needed – Enter immersion cooling!

Discuss on the forum: https://linustechtips.com/topic/1449840-this-server-lives-underwater/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:52 Mineral oil? No...
2:19 Why dunk your server?
3:18 No HVAC and no fans means lower power and better reliability
4:05 We're gonna need it real soon
4:43 Nothing goes to waste
5:44 Dunk the ports, too, it's all good
6:21 What about dust, dirt, and other problems?
7:19 Conclusion - Who's this for?


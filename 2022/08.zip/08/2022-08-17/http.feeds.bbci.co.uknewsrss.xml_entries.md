# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## UK inflation rate calculator: How much are prices rising for you?
 - [https://www.bbc.co.uk/news/business-62558817?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62558817?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-17 06:39:38+00:00

Use our calculator to find out how much the cost of living is going up in your household.


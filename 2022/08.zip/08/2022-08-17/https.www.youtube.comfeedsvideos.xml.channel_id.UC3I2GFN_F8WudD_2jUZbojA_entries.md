# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## La Dame Blanche - A La Verita Tuya (Live on KEXP)
 - [https://www.youtube.com/watch?v=zr1YvEopCEs](https://www.youtube.com/watch?v=zr1YvEopCEs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-18 00:00:00+00:00

http://KEXP.ORG presents La Dame Blanche performing “ A La Verita Tuya” live in the KEXP studio. Recorded July 13, 2022.

Yaite Ramos Rodriguez aka La Dame Blanche - Vocals / Flute
Marc Damblé aka Babylotion - Guitar / Machines / Keys / Vocals
Valentin Provendier - Drums

Host: Albina Cabrera
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Alaia D’Alessandro

https://ladameblanche.bandcamp.com
http://kexp.org

## La Dame Blanche - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=-FNwZFRCscc](https://www.youtube.com/watch?v=-FNwZFRCscc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-18 00:00:00+00:00

http://KEXP.ORG presents La Dame Blanche performing live in the KEXP studio. Recorded July 13, 2022.

Songs:
La Incondicional
La Condenada
A La Verita Tuya
Veneno

Yaite Ramos Rodriguez aka La Dame Blanche - Vocals / Flute
Marc Damblé aka Babylotion - Guitar / Machines / Keys / Vocals
Valentin Provendier - Drums

Host: Albina Cabrera
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Alaia D’Alessandro

https://ladameblanche.bandcamp.com
http://kexp.org

## La Dame Blanche - La Condenada (Live on KEXP)
 - [https://www.youtube.com/watch?v=iSbjh1fHkvU](https://www.youtube.com/watch?v=iSbjh1fHkvU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-18 00:00:00+00:00

http://KEXP.ORG presents La Dame Blanche performing “La Condenada” live in the KEXP studio. Recorded July 13, 2022.

Yaite Ramos Rodriguez aka La Dame Blanche - Vocals / Flute
Marc Damblé aka Babylotion - Guitar / Machines / Keys / Vocals
Valentin Provendier - Drums

Host: Albina Cabrera
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Alaia D’Alessandro

https://ladameblanche.bandcamp.com
http://kexp.org

## La Dame Blanche - La Incondicional (Live on KEXP)
 - [https://www.youtube.com/watch?v=5_RKzNvooyY](https://www.youtube.com/watch?v=5_RKzNvooyY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-18 00:00:00+00:00

http://KEXP.ORG presents La Dame Blanche performing “La Incondicional” live in the KEXP studio. Recorded July 13, 2022.

Yaite Ramos Rodriguez aka La Dame Blanche - Vocals / Flute
Marc Damblé aka Babylotion - Guitar / Machines / Keys / Vocals
Valentin Provendier - Drums

Host: Albina Cabrera
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Alaia D’Alessandro

https://ladameblanche.bandcamp.com
http://kexp.org

## La Dame Blanche - Veneno (Live on KEXP)
 - [https://www.youtube.com/watch?v=F5kB5aTs3J4](https://www.youtube.com/watch?v=F5kB5aTs3J4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-18 00:00:00+00:00

http://KEXP.ORG presents La Dame Blanche performing “Veneno” live in the KEXP studio. Recorded July 13, 2022.

Yaite Ramos Rodriguez aka La Dame Blanche - Vocals / Flute
Marc Damblé aka Babylotion - Guitar / Machines / Keys / Vocals
Valentin Provendier - Drums

Host: Albina Cabrera
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Alaia D’Alessandro

https://ladameblanche.bandcamp.com
http://kexp.org

## SLANG - Chipped Tooth (Live on KEXP)
 - [https://www.youtube.com/watch?v=PA1e4JIWVeQ](https://www.youtube.com/watch?v=PA1e4JIWVeQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-17 00:00:00+00:00

http://KEXP.ORG presents SLANG performing “Chipped Tooth” live in the KEXP studio. Recorded July 21, 2022.

Drew Grow - Vocals / Guitar
Janet Weiss - Drums / Vocals
Kathy M. Foster - Bass / Vocals
Anita Lee Elliott - Guitar / Vocals

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://linktr.ee/theeslang
http://kexp.org

## SLANG - Cockroach In A Ghost Town (Live on KEXP)
 - [https://www.youtube.com/watch?v=AYLXbzskE5Q](https://www.youtube.com/watch?v=AYLXbzskE5Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-17 00:00:00+00:00

http://KEXP.ORG presents SLANG performing “Cockroach In A Ghost Town” live in the KEXP studio. Recorded July 21, 2022.

Drew Grow - Vocals / Guitar
Janet Weiss - Drums / Vocals
Kathy M. Foster - Bass / Vocals
Anita Lee Elliott - Guitar / Vocals

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://linktr.ee/theeslang
http://kexp.org

## SLANG - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=FGwGrmV5VNY](https://www.youtube.com/watch?v=FGwGrmV5VNY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-17 00:00:00+00:00

http://KEXP.ORG presents SLANG performing live in the KEXP studio. Recorded July 21, 2022.

Songs:
Wilder
Chipped Tooth
Cockroach In A Ghost Town
Kiss

Drew Grow - Vocals / Guitar
Janet Weiss - Drums / Vocals
Kathy M. Foster - Bass / Vocals
Anita Lee Elliott - Guitar / Vocals

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://linktr.ee/theeslang
http://kexp.org

## SLANG - Kiss (Live on KEXP)
 - [https://www.youtube.com/watch?v=LfQU708mhsU](https://www.youtube.com/watch?v=LfQU708mhsU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-17 00:00:00+00:00

http://KEXP.ORG presents SLANG performing “Kiss” live in the KEXP studio. Recorded July 21, 2022.

Drew Grow - Vocals / Guitar
Janet Weiss - Drums / Vocals
Kathy M. Foster - Bass / Vocals
Anita Lee Elliott - Guitar / Vocals

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://linktr.ee/theeslang
http://kexp.org

## SLANG - Wilder (Live on KEXP)
 - [https://www.youtube.com/watch?v=i2vW_h75J2Q](https://www.youtube.com/watch?v=i2vW_h75J2Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-17 00:00:00+00:00

http://KEXP.ORG presents SLANG performing “Wilder” live in the KEXP studio. Recorded July 21, 2022.

Drew Grow - Vocals / Guitar
Janet Weiss - Drums / Vocals
Kathy M. Foster - Bass / Vocals
Anita Lee Elliott - Guitar / Vocals

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://linktr.ee/theeslang
http://kexp.org


# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## a rant on USBC charging, part 2
 - [https://www.youtube.com/watch?v=AUADlRK4e1U](https://www.youtube.com/watch?v=AUADlRK4e1U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-08-17 00:00:00+00:00

grantapps@futo.org - message us about your project

https://youtu.be/rDPtcKycQeI


# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## HELLO WIRELESS VALVE INDEX, Goodbye Wired VR Headsets
 - [https://www.youtube.com/watch?v=QMMDaA6s3To](https://www.youtube.com/watch?v=QMMDaA6s3To)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-08-17 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news! Today we have a very special TN, I give my first impressions of the new Valve Index wireless adapter from Nofio- it's still an engineering prototype but it shows some massive promise and I'm super excited about its future. 

We're also looking at Quest 2 V43 update, Altair Breaker, a new headset from Lenovo, and so much more! Hope you enjoyed this week of VR news!

AFFILIATE LINK FOR NOFIO WIRELESS ADAPTER:
https://tinyurl.com/ThrillseekerNofio

GIVEAWAY LINKS: 
Giveaway:
https://bit.ly/3vyG90k
Discord:
Discord.gg/Thrill

My links:
Outro music:
https://www.youtube.com/watch?v=u6JwgNQDVfIZ

Meme break source: https://youtu.be/WOZwbA1Kv5Y


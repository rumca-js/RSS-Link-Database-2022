# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## I Wish We All Could Leave California (Beach Boys Parody)
 - [https://www.youtube.com/watch?v=ApfBvkql0lI](https://www.youtube.com/watch?v=ApfBvkql0lI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-08-18 00:00:00+00:00

The California Dream ain't what it used to be. In this parody of The Beach Boys' "California Girls", The Bee Boys express their yearning to leave the Golden State some day.

Listen to The Bee Boys' 2nd single: https://youtu.be/TwJlKw56l30

Be sure to listen to this song on other platforms: 
Apple Music: https://music.apple.com/us/album/i-wish-we-all-could-leave-california/1639644585?i=1639644706

Spotify: https://open.spotify.com/album/145XjJ2AGjpoAWbwAGdefO?si=f2d4185d353948d7

Amazon Music: https://amazon.com/music/player/albums/B0B9J9R728?marketplaceId=ATVPDKIKX0DER&musicTerritory=US&ref=dm_sh_IYa54qr2s0I1Qh3cG5QlNEe8t

Lyrics:
Well, SF's packed with feces,
You gotta watch your step up there,
And Los Angeles with all their homeless camps,
The tents and drugs are everywhereIn Napa Newsom drops some
15 thousand bucks on wine
But in the rest of the state with all the mask mandates,
They keep us all locked up real tightI wish we all could leave California, now
I wish we all could leave California,
I wish we all could leave California, nowWell, Texas has more freedom,
And pistol grips out there aren't banned
I'd dig a Florida place with no mask on my face,
And no income tax sounds grandI been all around this Commie state,
And my time here's about spent
Yeah, but I couldn't spot even one U-Haul lot
That had a single truck left to rentI wish we all could leave California, now
I wish we all could leave California,
I wish we all could leave California, now (edited)


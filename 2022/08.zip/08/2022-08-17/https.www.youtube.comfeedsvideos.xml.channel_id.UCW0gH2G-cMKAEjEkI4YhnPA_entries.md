# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Embracer acquires LOTR IP, Wētā Video Game, Magic Cards, Elrond & Maps | NERD MOOT
 - [https://www.youtube.com/watch?v=TntZNIpNHk8](https://www.youtube.com/watch?v=TntZNIpNHk8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-08-18 00:00:00+00:00

In this week's Nerd Moot, Yoystan and I will be chatting about LOTR rights being purchased, a new Middle-earth video game, and new maps and character pieces from Rings of Power!

This week's Tolkien news:
- Embracer Group announced they've entered an agreement to acquire Middle-earth Enterprises, which holds the IP rights to both Lord of the Rings & the Hobbit: https://bit.ly/3QxAKzm

- Private Division and Wētā Workshop are partnering to create a new Middle-earth Video Game: https://bit.ly/3QUaxKS

- Magic The Gathering Lord of the Rings: Tales of Middle-earth Game


## Why McDonald's McPlant Became a McFlop | Bon Appétit
 - [https://www.bonappetit.com/story/mcdonalds-ends-mcplant-test-us-stores](https://www.bonappetit.com/story/mcdonalds-ends-mcplant-test-us-stores)
 - RSS feed: https://www.bonappetit.com
 - date published: 2022-08-17 10:41:17.445784+00:00

The chain's plant-based burger reveals how fake meat at fast food restaurants is, as a whole, a grift.


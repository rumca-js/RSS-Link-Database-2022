# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## A Plague Tale: Requiem Official Gameplay Overview Trailer
 - [https://www.youtube.com/watch?v=cTEh-mbwC8s](https://www.youtube.com/watch?v=cTEh-mbwC8s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-08-18 00:00:00+00:00

Learn more about A Plague Tale: Requiem's gameplay in this latest overview trailer. We'll get to learn more about that game as well as it will be at gamescom 2022. It will also be part of Microsoft Xbox's live show.

A Plague Tale: Requiem, is the sequel to A Plague Tale: Innocence by Asobo Studio and Focus Entertainment. Hugo and Amicia’s head on a new journey and venture south of 14th century France, before setting sail to a mysterious island out in the Mediterranean Sea. Amicia has new resources to use including the use of alchemy to manipulate fire and the long-distance power of a crossbow. Use Amicia's cunning of terrain and her ability to wrestle out of an enemy’s grasp. Hugo also has new powers including perceiving surrounding enemies’ movements while moving stealthily, and to manipulate hordes of rats to decimate entire squads of soldiers.

A Plague Tale: Requiem will be releasing on PlayStation 5, Xbox Series S and X, PC, and Nintendo Switch.

#aplaguetalerequiem #gaming #gamespot

## Bringing Redfall to Life With Arkane Austin
 - [https://www.youtube.com/watch?v=xAGSK5ujABQ](https://www.youtube.com/watch?v=xAGSK5ujABQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-08-18 00:00:00+00:00

Get an insider look at Redfall with Arkane Austin. How the vampires were created? Weapons you can find? Find out what makes this game one of the most ambitious games made by the team and more.

Fight alone or squad up for up to 4 player co-op in Redfall, an open-world story-driven FPS game. The town of Redfall is under siege by a legion of vampires who have cut the island off from the outside world. Trapped with a handful of survivors, choose from a roster of heroes to create the perfect team of vampire slayers and take back Redfall. 

Redfall launches in 2023!

## GTA 6 DLC Plan Sounds Great… If It's True | GameSpot News
 - [https://www.youtube.com/watch?v=1L85QS7Eg34](https://www.youtube.com/watch?v=1L85QS7Eg34)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-08-18 00:00:00+00:00

GTA 6 could be heading back to single-player DLC and Diablo 4 is promising it won’t be pay-to-win.

Known GTA tipster Tez2 shared new rumors in a post on GTAForums in response to a comment about the reports of the world of GTA 6 "expanding over time." Tez2 said this means "Rockstar will go back to how they were planning future content before GTA Online success boomed."
In other words, Rockstar was allegedly working on single-player DLC for Grand Theft Auto V but the studio ended these projects and shifted its focus to GTA Online.

In a since deleted tweet, Tez2 urged Online players to dial 505-555-0175 in-game for “the first hint of GTA 6”. Unfortunately, as pointed out by Twitter user NoughtAFazeMom, the number simply leads to hold music. Which ironically fits the situation we’re all in anyway as we sit around on hold, waiting for Rockstar to drop a trailer or an information filled blog post.
#GTA #GTA6 #Grandtheftauto

## Midnight Fight Express Review
 - [https://www.youtube.com/watch?v=S5G-Fmr8hQ4](https://www.youtube.com/watch?v=S5G-Fmr8hQ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-08-18 00:00:00+00:00

Midnight Fight Express is a modern beat-'em-up with extensive motion-captured animations that bring its frenetic combat to life.

## Saints Row - Everything To Know
 - [https://www.youtube.com/watch?v=z636bnaEE10](https://www.youtube.com/watch?v=z636bnaEE10)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-08-18 00:00:00+00:00

The Saints Row series is back and looking to reinvent itself. Instead of picking up where part 4 left off, this new entry is taking you back to the beginning with an all new cast of characters causing mayhem in a brand new city. Here is everything you need to know about Saints Row.
#Gaming #saintsrow 

Similar to the rest of the series, Saints Row is being developed by Volition and published by Deep Silver. With this opportunity to start over, series developer Volition wanted to create criminals that were more relatable and one way of doing that was to show those goons starting from nothing. Each of the new criminals are just trying to make ends meet and head out on their own because they are tired of working for other gangs. Their goal is to get rich and take over the fictional city of Santo Ileso, a huge and vibrant sandbox in the American south west. 

Saints Row’s new cast of characters include: the business mastermind Eli, who cares more about making the money than how the money is made. The getaway driver, Neenah, who is a member of the muscle car and exercise obsessed Los Panteros. As well as the people-pleaser Kevin, who is a member of the anarchist nightclub owners known as the Idols. 

Saints Row is scheduled to launch on August 23, 2022. The game was originally set to release on February 25 before being delayed so that the team could do a little bit more fine tuning. The game will be released for both current and past generation consoles, as well as PC.

## Warzone 2 Release Date May Have Leaked | GameSpot News
 - [https://www.youtube.com/watch?v=yV7N2hO6-8o](https://www.youtube.com/watch?v=yV7N2hO6-8o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-08-17 00:00:00+00:00

Warzone 2 and World of Warcraft: Dragonflight Release dates may have leaked. Plus, a new Call of Duty skin is accused of copying art from Dr Disrespect’s Deadrop. 
#GamingNews #CallofDuty #Warzone2 

The since deleted image appeared to show internal documentation related to readiness for various upcoming Activision Blizzard launches, such as the recently announced release date of the pre-patch for WoW: Wrath of the Lich King Classic. If the image is indeed legitimate, WoW players can expect to have their hands on the game's next expansion, Dragonflight, on November 28, with the game's pre-patch arriving roughly a month earlier, on October 25. Meanwhile, Call of Duty: Warzone 2 could be launching November 16, several weeks after the release of Call of Duty: Modern Warfare II. In addition to Warzone 2, the document lists a release of October 27 for something called "COD Cortez," which may be the heavily rumored (and seemingly confirmed) DMZ mode for the upcoming shooter.

In other Call of Duty news, Activision has announced a new preorder bonus for Call of Duty: Modern Warfare II, and it's a first-of-its-kind offer for the franchise. Everyone who digitally preorders Modern Warfare II will get access to the game's campaign mode "up to" a week early, starting on October 20. The game releases officially on October 28. Preordering Modern Warfare II also gets you early access to the multiplayer beta, which begins September 16 on PlayStation before coming to Xbox and PC later.

Activision has released the new "Doomsayer" operator skin in Call of Duty: Warzone and Vanguard, but players are already pointing out major similarities with artwork from Dr Disrespect's upcoming Deadrop game.

STAMPS
00:00 - Intro
00:05 - Warzone 2
01:22 - Modern Warfare 2
01:51 - Call of Duty & Deadrop


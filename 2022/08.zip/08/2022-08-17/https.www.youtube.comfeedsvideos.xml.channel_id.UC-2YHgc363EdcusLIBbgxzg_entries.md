# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Electric Vs. Hydrogen With Robert Llewellyn | CWJ Clip
 - [https://www.youtube.com/watch?v=HvWwrfRqbIA](https://www.youtube.com/watch?v=HvWwrfRqbIA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-08-18 00:00:00+00:00

I sat down with the one and only Robert Llewellyn recently to talk about EVs, what drives his interest in electric cars (see what I did there?) and a bunch of random things. This is a clip from that conversation. You can find the whole interview on my podcast channel, Conversations With Joe:
https://youtu.be/oTqCJPRz0C4


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPGzF
Apple Podcasts 👉 https://apple.co/3j94kfq
Google Podcasts 👉 https://bit.ly/3qZCo1V

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe


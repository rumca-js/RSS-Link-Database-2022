# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Derrick Hamilton Spent Over 20 Years in Jail Over False Murder Conviction
 - [https://www.youtube.com/watch?v=4p1Da0NIp0w](https://www.youtube.com/watch?v=4p1Da0NIp0w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-08-17 00:00:00+00:00

Taken from JRE #1858 w/Josh Dubin & Derrick Hamilton:
https://open.spotify.com/episode/6UeUIxBVH2DnDSv9lH6qFF?si=868c3e101ff6484c


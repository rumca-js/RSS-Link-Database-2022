# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## American Boy | Estelle & Kanye West | funk cover ft. @StaceyRyanMusic + LELAND SKLAR
 - [https://www.youtube.com/watch?v=4Mk_hGfIWIc](https://www.youtube.com/watch?v=4Mk_hGfIWIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-08-15 00:00:00+00:00

FREE SHOW coming up! 8/27/22 at Oshkosh Jazz Festival in Oshkosh, WI. The Show Band: Antwaun Stanley, Mario Jose, Therese Curatolo, JJ Johnson, Nick Campbell, Neara Russell, Ryan Lerman.

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of @EstelleDarlings & @kanyewest's "American Boy" by Scary Pockets & Stacey Ryan.

MUSICIAN CREDITS
Vocals: Stacey Ryan
Drums: Tamir Barzilay
Bass: Leland Sklar
Synth: Zac Rae
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
Director: Dom Fera
DP: Nate Cuboi
Editor: Adam Kritzberg

Recorded Live at East West Studios in Los Angeles, CA.

#ScaryPockets #Funk #kanyewest #staceyryan #estelle #americanboy


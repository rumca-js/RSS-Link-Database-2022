## How I Hacked my Car Part 3: Making Software :: Programming With Style
 - [https://programmingwithstyle.com/posts/howihackedmycarpart3/](https://programmingwithstyle.com/posts/howihackedmycarpart3/)
 - RSS feed: https://programmingwithstyle.com
 - date published: 2022-08-14 07:07:39.767879+00:00

If you haven&rsquo;t read Part 1 and Part 2 please do so. Making Software I am a programmer by nature. I now had root access to a cool new linux box so now I must develop software for it. The Goal While looking through many of the IVI&rsquo;s files, I found tons of really cool C++ header files relating to ccOS in /usr/include. ccOS is the Connected Car Operating System, an OS developed by Nvidia and Hyundai which is supposed to power all Hyundai vehicles from 2022 onwards, but I guess some of the underlying system was in previous Hyundai vehicles for quite some time.

## How I Hacked my Car Part 2: Making a Backdoor :: Programming With Style
 - [https://programmingwithstyle.com/posts/howihackedmycarpart2/](https://programmingwithstyle.com/posts/howihackedmycarpart2/)
 - RSS feed: https://programmingwithstyle.com
 - date published: 2022-08-14 06:58:33.347892+00:00

If you haven’t read Part 1 please do so. No More Waiting On April 28, 2022 a new round of Display Audio firmware updates was released for Hyundai and Kia vehicles. Luckily, it included my car. I wasted no time in developing my own firmware update with a backdoor. Firmware Security Through the linux_envsetup.sh script I learned exactly how a D-Audio2V encrypted firmware update is made:  First, all of the various binary files are sorted into the correct directories.

## How I Hacked my Car :: Programming With Style
 - [https://programmingwithstyle.com/posts/howihackedmycar/](https://programmingwithstyle.com/posts/howihackedmycar/)
 - RSS feed: https://programmingwithstyle.com
 - date published: 2022-08-14 06:53:55.188520+00:00

The Car Last summer I bought a 2021 Hyundai Ioniq SEL. It is a nice fuel-efficient hybrid with a decent amount of features like wireless Android Auto/Apple CarPlay, wireless phone charging, heated seats, &amp; a sunroof. One thing I particularly liked about this vehicle was the In-Vehicle Infotainment (IVI) system. As I mentioned before it had wireless Android Auto which seemed to be uncommon in this price range, and it had pretty nice, smooth animations in its menus which told me the CPU/GPU in it wasn&rsquo;t completely underpowered, or at least the software it was running wasn&rsquo;t super bloated.


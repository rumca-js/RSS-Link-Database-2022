# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## The Ecosystem Inside of a Plant
 - [https://www.youtube.com/watch?v=9CMl0boDUKU](https://www.youtube.com/watch?v=9CMl0boDUKU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-08-15 00:00:00+00:00

Thank you Helix for sponsoring! Visit https://helixsleep.com/scishow to get up to $200 off your Helix mattress, plus two free pillows #helixsleep

Human microbiomes have become quite famous in recent years, but did you know that plants have them too?

Hosted by: Stefan Chin

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Matt Curls, Alisa Sherbow, Dr. Melvin Sanicas, Harrison Mills, Adam Brainard, Chris Peters, charles george, Piya Shedden, Alex Hackman, Christopher R, Boucher, Jeffrey Mckishen, Ash, Silas Emrys, Eric Jensen, Kevin Bealer, Jason A Saslow, Tom Mosner, Tomás Lagos González, Jacob, Christoph Schwanke, Sam Lutfi, Bryan Cloer
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow #science #education
----------
Sources:
https://www.frontiersin.org/articles/10.3389/fmicb.2016.01538/full
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4488371/
https://academic.oup.com/femsec/article/92/8/fiw114/2470051
https://www.sciencedirect.com/science/article/pii/S1319562X20303387
https://www.journals.uchicago.edu/doi/10.1086/342161
https://link.springer.com/article/10.1007/s00425-015-2337-x
https://sfamjournals.onlinelibrary.wiley.com/doi/10.1111/jam.15111
https://annalsmicrobiology.biomedcentral.com/articles/10.1007/s13213-010-0120-6
https://www.sciencedirect.com/topics/chemistry/nitrogen-fixation
https://dtp.cancer.gov/timeline/flash/success_stories/s2_taxol.htm
https://www.sciencedirect.com/science/article/pii/B9780128210062000042
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5748579/
https://www.sciencedirect.com/science/article/pii/S0966842X08001923

Image Sources:
https://commons.wikimedia.org/wiki/File:Microbiome_Sites_%2827058471125%29.jpg
https://commons.wikimedia.org/wiki/File:The_plant_microbiome.jpg
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5041141/
https://commons.wikimedia.org/wiki/File:Introducing_plant_beneficial_bacteria_into_plant_seed_2.jpg
https://www.gettyimages.com/detail/photo/rotten-root-system-in-soil-of-plant-royalty-free-image/1353814453?adppopup=true
https://commons.wikimedia.org/wiki/File:Root-nodule01.jpg
https://www.gettyimages.com/detail/photo/trees-are-growing-in-dry-ground-concept-forest-and-royalty-free-image/1169774981?adppopup=true
https://www.gettyimages.com/detail/video/seed-germination-and-time-lapse-with-lens-flare-macro-stock-footage/1164177646?adppopup=true
https://www.gettyimages.com/detail/photo/petrified-fossil-crinoids-royalty-free-image/954317720?adppopup=true
https://commons.wikimedia.org/wiki/File:Natural_Selection_and_Coevolution_%282%29.svg
https://commons.wikimedia.org/wiki/File:Plant_microbiota.png
https://commons.wikimedia.org/wiki/File:Representative_microbial_networks_in_different_plant_habitats.webp


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Hang On, Is This A Joke?
 - [https://www.youtube.com/watch?v=jVUqK6ta6no](https://www.youtube.com/watch?v=jVUqK6ta6no)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-08-15 00:00:00+00:00

As the FBI’s raid on Donald Trump could potentially see him charged with the Espionage Act, how has a law historically condemned by liberalism suddenly become championed? I spoke to the brilliant Kim Iversen all about this. Check out her YouTube channel - link below. 
#donaldtrump #FBI #raid #spy #espionage #julianassange 

Kim’s Channel: https://youtube.com/c/KimIversen

Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


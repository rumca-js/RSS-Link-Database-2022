# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Tutaj pogrzebali dzieci"
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1176,S00E1176,840138?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1176,S00E1176,840138?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-08-14 16:14:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9e2mw0-nieslubne-wstydliwa-historia-irlandzkiego-kosciola-dokument-w-tvn24-go-6069213/alternates/LANDSCAPE_1280" />
    Wstydliwa historia irlandzkiego Kościoła.


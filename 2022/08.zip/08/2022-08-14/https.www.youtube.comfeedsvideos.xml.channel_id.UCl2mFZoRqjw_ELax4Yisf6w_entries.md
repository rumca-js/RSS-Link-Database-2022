# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## USB-C charging is not as universal as you think
 - [https://www.youtube.com/watch?v=rDPtcKycQeI](https://www.youtube.com/watch?v=rDPtcKycQeI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-08-15 00:00:00+00:00




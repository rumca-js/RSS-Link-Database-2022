# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Saints Row: 10 Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=Vj9vsJ43cYo](https://www.youtube.com/watch?v=Vj9vsJ43cYo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-08-15 00:00:00+00:00

The 2022 reboot of Saints Row (PC, PS5, PS4, Xbox Series X/S/One) is almost upon us so here's everything you need to know.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:19 Gameplay
1:41 Story
2:51 Open World
4:22 Customizing
5:41 Weapons
7:28 Side Activities
9:01 Co-Op
9:59 Enemies
10:59 Progression
12:04 Info

Sources referenced:

Weapons: https://www.techradar.com/how-to/saints-row-weapons-your-arsenal-in-the-upcoming-game
Skills: https://youtu.be/a7hA2xmR7Ko
Official customization trailer: https://www.youtube.com/watch?v=Z3QcEQ2G2AA&t=243s
https://www.youtube.com/watch?v=Z3QcEQ2G2AA&t=243s
https://www.gameinformer.com/saintsrow

## 10 BRAND NEW RPGs That Are Trying Something NEW
 - [https://www.youtube.com/watch?v=E2nu20rEbAU](https://www.youtube.com/watch?v=E2nu20rEbAU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-08-14 00:00:00+00:00

Looking for a unique new Role Playing Game that isn't a sequel to something else? We've got you covered with these new games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:22 Lost Soul Aside
1:28 Mercyful Flames
2:32 Flintlock: The Siege of Dawn
3:25 Showa American Story
4:19 Pixel Noir
5:12 Arise of Awakener
6:12 Project Eve
7:17 Forspoken
8:42 Lies of P
9:42 Black Myth: Wukong


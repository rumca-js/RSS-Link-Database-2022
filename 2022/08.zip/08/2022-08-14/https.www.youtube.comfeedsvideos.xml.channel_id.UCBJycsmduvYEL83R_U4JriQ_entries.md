# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Dope Tech: The Most Extreme Gaming Monitor!
 - [https://www.youtube.com/watch?v=MEiq0oCUb_8](https://www.youtube.com/watch?v=MEiq0oCUb_8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-08-15 00:00:00+00:00

Dope Tech is back! Transparent batteries, massive curved monitors and swiveling webcams 🤓

Thanks Samsung for sponsoring a portion of dope tech! Check out the Oydssey Ark at https://geni.us/4Hby

Shargeek Storm2: https://geni.us/uurob
Shargeek Storm2 slim: https://geni.us/evpu
Insta360 Link: https://geni.us/2T1mknp
The USB-C Power Display Cable: https://geni.us/YEX8d9E

MKBHD Merch: http://shop.MKBHD.com

Intro Track: Jordyn Edmonds: https://lnk.to/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


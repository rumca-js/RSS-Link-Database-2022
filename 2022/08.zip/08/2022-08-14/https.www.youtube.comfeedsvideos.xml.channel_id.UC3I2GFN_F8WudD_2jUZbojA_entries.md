# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Jarv Dee - Clouds (Live on KEXP)
 - [https://www.youtube.com/watch?v=no87fzoDkCk](https://www.youtube.com/watch?v=no87fzoDkCk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-15 00:00:00+00:00

http://KEXP.ORG presents Jarv Dee performing “Clouds" (orig ft. Shabazz Palaces) live in the KEXP studio. Recorded July 19, 2022.

Jarv Dee - Vocals
Gerson Zaragoza - Bass
Joseph Phillips - Drums
Clifton “Scooter” Maxie - Keys

Host: Gabriel Teodros
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Jonathan Jacobson
Editor: Carlos Cruz

https://jarvdee.bandcamp.com
http://kexp.org

## Jarv Dee - Feelin' Like (Live on KEXP)
 - [https://www.youtube.com/watch?v=C7I9Xv0nfOg](https://www.youtube.com/watch?v=C7I9Xv0nfOg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-15 00:00:00+00:00

http://KEXP.ORG presents Jarv Dee performing “Feelin' Like" (orig. Bad Colours ft. Jarv Dee) live in the KEXP studio. Recorded July 19, 2022.

Jarv Dee - Vocals
Gerson Zaragoza - Bass
Joseph Phillips - Drums
Clifton “Scooter” Maxie - Keys

Host: Gabriel Teodros
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Jonathan Jacobson
Editor: Carlos Cruz

https://jarvdee.bandcamp.com
http://kexp.org

## Jarv Dee - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=XZuA9OdYLwU](https://www.youtube.com/watch?v=XZuA9OdYLwU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-15 00:00:00+00:00

http://KEXP.ORG presents Jarv Dee performing live in the KEXP studio. Recorded July 19, 2022.

Songs:
Feelin' Like (orig. Bad Colours ft. Jarv Dee)
Got You
Clouds (orig ft. Shabazz Palaces)
I Just Wanna

Jarv Dee - Vocals
Gerson Zaragoza - Bass
Joseph Phillips - Drums
Clifton “Scooter” Maxie - Keys

Host: Gabriel Teodros
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Jonathan Jacobson
Editor: Carlos Cruz

https://jarvdee.bandcamp.com
http://kexp.org

## Jarv Dee - Got You (Live on KEXP)
 - [https://www.youtube.com/watch?v=_Uf_J5bwzCs](https://www.youtube.com/watch?v=_Uf_J5bwzCs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-15 00:00:00+00:00

http://KEXP.ORG presents Jarv Dee performing “Got You” live in the KEXP studio. Recorded July 19, 2022.

Jarv Dee - Vocals
Gerson Zaragoza - Bass
Joseph Phillips - Drums
Clifton “Scooter” Maxie - Keys

Host: Gabriel Teodros
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Jonathan Jacobson
Editor: Carlos Cruz

https://jarvdee.bandcamp.com
http://kexp.org

## Jarv Dee - I Just Wanna (Live on KEXP)
 - [https://www.youtube.com/watch?v=-3WCRatsRVY](https://www.youtube.com/watch?v=-3WCRatsRVY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-15 00:00:00+00:00

http://KEXP.ORG presents Jarv Dee performing “I Just Wanna” live in the KEXP studio. Recorded July 19, 2022.

Jarv Dee - Vocals
Gerson Zaragoza - Bass
Joseph Phillips - Drums
Clifton “Scooter” Maxie - Keys

Host: Gabriel Teodros
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen & Jonathan Jacobson
Editor: Carlos Cruz

https://jarvdee.bandcamp.com
http://kexp.org


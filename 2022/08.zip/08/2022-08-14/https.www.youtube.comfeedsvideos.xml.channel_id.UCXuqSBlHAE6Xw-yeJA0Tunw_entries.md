# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The Personal Gaming Theater - HOLY $H!T Samsung Odyssey Ark
 - [https://www.youtube.com/watch?v=CsoKWsZ-Tyw](https://www.youtube.com/watch?v=CsoKWsZ-Tyw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-08-15 00:00:00+00:00

Thanks to Samsung for sponsoring this video! 

Check out the Samsung Odyssey Ark at https://lmg.gg/SJVoQ

Discuss on the forum: https://linustechtips.com/topic/1449580-the-personal-gaming-theater-holy-ht-sponsored/

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:04 Unboxing
3:57 Swivel Showoff
5:00 Wiring It Up
6:45 Dat Peel
7:37 Powering it on
9:35 Ark Dial
10:50 Time to play a game
15:15 Gaming vertically
17:39 Multi View
19:15 Conclusion

## Almost EVERYONE is Wasting Money on Dash Cams.
 - [https://www.youtube.com/watch?v=4AnyhHl3_tE](https://www.youtube.com/watch?v=4AnyhHl3_tE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-08-14 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Create your build at https://www.buildredux.com/linus

It’s been YEARS since dash cams hit the market, but it feels like we’ve been stuck at a standstill. Why is it that camera quality is so lacking? Are there really no good options when shopping for a dash cam to attach to the windshield of your car? (The second half of this video is pretty stunning!)

Discuss on the forum: https://linustechtips.com/topic/1449409-almost-everyone-is-wasting-money-on-dash-cams/

Buy a Thinkware F70: https://geni.us/ORAo
Buy a Biuone A20: https://geni.us/PK2Ch
Buy a Chortau B-T13: https://geni.us/oiFwAUr
Buy an Iiwey T1: https://geni.us/1QZkry
Buy a Pruveeo D30H: https://geni.us/sl2dqAc
Buy a Rexing V1-4K: https://geni.us/sOG6
Buy a Garmin Dash Cam Mini 2: https://geni.us/TN9q
Buy a Rove R2-4K: https://geni.us/n8xqqeE
Buy a BlackVue DR750X Plus: https://geni.us/L83rlR
Buy a Thinkware U1000: https://geni.us/Qwk85TK
Buy a Viofo A119 V3: https://geni.us/eNBHc
Buy a Viofo A129 Plus Duo: https://geni.us/yPJli
Buy a Viofo A129 Pro Duo: https://geni.us/ygAAc
Buy a BlackVue External 4G/LTE Module: https://geni.us/AIIy2
Buy a Thinkware Multiplexer Box: https://geni.us/P0bzYvN
Buy a Thinkware Multiplexer Kit: https://geni.us/IZGz

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

English
This video has been dubbed using an artificial voice via https://aloud.area120.google.com to increase accessibility. You can change the audio track language in the Settings menu.

Spanish
Este video ha sido doblado al español con voz artificial con https://aloud.area120.google.com para aumentar la accesibilidad. Puede cambiar el idioma de la pista de audio en el menú Configuración.

CHAPTERS
---------------------------------------------------
0:00 Intro
1:07 The Back-story
2:37 Thinkware F70
3:26  Biuone A20
3:55 Chortau B-T13
5:00 Iiwey T1 and Pruveeo D30H
6:16 Rexing V1-4K
6:57 Garmin Dash Cam Mini 2
7:34 Rove R2-4K
8:05 Viofo A119 V3
9:12 BlackVue DR750X and Thinkware U1000
10:30 THE REASON THEY'RE SO BAD
15:04 tldr;
17:04 outro


# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Chastity Brown performs three songs from 'Sing to the Walls'  (Live for The Current)
 - [https://www.youtube.com/watch?v=qgLaE5os0s4](https://www.youtube.com/watch?v=qgLaE5os0s4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-08-14 00:00:00+00:00

Chastity Brown joins The Current to perform three songs from her new record "Sing to the Walls". Local Show host Diane follows up with interview with Brown and drummer Greg Schutte. 

Songs Played:
00:00 Like The Sun
04:54 Boston
08:15 Wonderment
13:41 Chastity Brown and Greg Schutte talk to host Diane

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Vocals, Piano, Guitar - Chastity Brown
Guitar - Luke Enyeart
Drums - Greg Schutte
Bass - Trevor Peterson
Host & Producer - Diane
Video Director - Erik Stromstad
Camera Op - Erik Stromstad, Peter Ecklund
Audio - Evan Clark

This activity is made possible in part by the Minnesota Legacy Amendment's Arts & Cultural Heritage Fund.

#chastitybrown @chastitybrownmusic9385


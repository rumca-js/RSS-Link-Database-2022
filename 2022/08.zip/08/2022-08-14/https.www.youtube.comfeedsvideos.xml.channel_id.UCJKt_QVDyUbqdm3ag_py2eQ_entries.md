# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga music: Bonefish, Mygg & JosSs - Nasty Ways (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=KAFUwRqqjGg](https://www.youtube.com/watch?v=KAFUwRqqjGg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-08-14 00:00:00+00:00

"Nasty Ways" by Bonefish, Mygg & JosSs, 1st at Assembly Summer 2022. C64 art "Shocker" (2021) by Fabs/Hokuto Force^Onslaught.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Normal mixing with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Standard 4 channel Protracker module

Visit my channel for more Amiga music.


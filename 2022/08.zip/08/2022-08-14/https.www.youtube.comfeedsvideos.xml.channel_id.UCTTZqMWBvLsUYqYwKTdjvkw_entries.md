# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Jak zhakowano Starlinka? #BlackHat
 - [https://www.youtube.com/watch?v=xdiu-ZsvWJI](https://www.youtube.com/watch?v=xdiu-ZsvWJI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2022-08-14 00:00:00+00:00

📡 Opowiem Wam dzisiaj o Starlinku, a w sumie tak bardziej konkretnie to o tym, w jaki sposób udało się złamać zabezpieczenia ich urządzeń.

Źródła:
Prezentacja Lennerta z BlackHata 2022
https://bit.ly/3zQuVFY

Repozytorium SpaceX na Githubie
https://bit.ly/3durP35

siliconpr0n.org czyli fotki rentgenowskie elektroniki
https://siliconpr0n.org/

My other car is your car (...), L. Wouters, B. Gierlichs and B. Preneel
https://bit.ly/3QLokDJ

Strona Lennerta Woutersa
https://bit.ly/3SKxC4J

Jeżeli nie ufasz skracanym linkom (bardzo dobrze!) to dodaj na ich końcu plusik ‘+’.
W ten sposób podejrzysz na stronie bit.ly dokąd prowadzą.

Relevant xkcd: https://xkcd.com/1337/

© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.

Dziękuję za Waszą uwagę. ❤️

Znajdziecie mnie również na;
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok
Podcasty na;
Anchor https://anchor.fm/mateusz-chrobok
Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR
Apple Podcasts https://apple.co/3OwjvOh

Rozdziały:
00:00 Intro
00:30 Stolik
01:19 Starlink
02:13 Atak
07:13 Zgłoszenie
08:09 Konsekwencje
08:51 Co Robić i Jak Żyć?

#starlink #cyberbezpieczeństwo


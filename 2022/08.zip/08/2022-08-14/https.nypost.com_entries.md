## Facebook spied on private messages of Americans who questioned 2020 election
 - [https://nypost.com/2022/09/14/facebook-spied-on-private-messages-of-americans-who-questioned-2020-election/](https://nypost.com/2022/09/14/facebook-spied-on-private-messages-of-americans-who-questioned-2020-election/)
 - RSS feed: https://nypost.com
 - date published: 2022-08-14 20:36:44+00:00

Facebook spied on private messages of Americans who questioned 2020 election


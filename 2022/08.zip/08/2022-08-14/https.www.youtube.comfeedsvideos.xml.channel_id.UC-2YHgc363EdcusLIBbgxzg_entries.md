# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Full Plan For Artemis Part 2: Back To The Moon | Answers With Joe
 - [https://www.youtube.com/watch?v=7a_GtR9wt4I](https://www.youtube.com/watch?v=7a_GtR9wt4I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-08-15 00:00:00+00:00

Go to https://hensonshaving.com and enter "JOESCOTT" at checkout to get 100 free blades with your purchase. (Note: you must add both the 100 blade pack and the razor for the discount to apply.)
With the upcoming launch of Artemis I, NASA is officially on the way back to the moon for the first time in 50 years. Recently I posted the first of 3 videos designed to cover the entire Artemis program. The last video focused on the uncrewed missions, today we're looking at the human missions, the ones that will finally put boots on the moon again.

See the previous video here: https://youtu.be/MHMTq24rQeI

Real Engineering's video on the moon suits:
https://www.youtube.com/watch?v=0k9wIsKKgqo

And watch this video ad-free on Nebula: https://nebula.tv/videos/joescott-the-full-plan-for-artemis-part-ii-back-to-the-moon

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPGzF
Apple Podcasts 👉 https://apple.co/3j94kfq
Google Podcasts 👉 https://bit.ly/3qZCo1V

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS -
https://www.nasa.gov/feature/boldly-go-nasa-s-new-space-toilet-offers-more-comfort-improved-efficiency-for-deep-space
https://www.nasa.gov/sls/multimedia/gallery/sls-infographic3.html
https://www.nasa.gov/press-release/nasa-space-launch-system-s-first-flight-to-send-small-sci-tech-satellites-into-space
https://www.nasa.gov/content/artemis-partners
https://www.nasa.gov/sls/interim_cryogenic_propulsion_stage_141030.html
https://www.nasa.gov/artemis-1
https://www.nasa.gov/content/artemis-i-overview
https://www.nasa.gov/sites/default/files/thumbnails/image/artemis_i_3_28_22.jpg
https://www.nasa.gov/sites/default/files/atoms/files/sls_lift_capabilities_configurations_04292020_woleo.pdf
https://www.youtube.com/watch?v=C_Ku7BnP6hs
https://www.nasa.gov/feature/nasa-completes-wet-dress-rehearsal-moves-forward-toward-launch
https://www.nasa.gov/directorates/heo/scan/services/networks/deep_space_network/about
http://www.collectspace.com/review/orion_em2_trajectory01.jpg
https://www.nasa.gov/feature/nasa-s-first-flight-with-crew-important-step-on-long-term-return-to-the-moon-missions-to
https://www.nasa.gov/feature/boldly-go-nasa-s-new-space-toilet-offers-more-comfort-improved-efficiency-for-deep-space
https://en.wikipedia.org/wiki/Artemis_2
https://www.nasa.gov/feature/around-the-moon-with-nasa-s-first-launch-of-sls-with-orion
https://www.nasa.gov/specials/artemis-team/
https://preview.redd.it/whzqnavsqlp71.jpg?auto=webp&s=4b10bc977b4041b0861c4d3d632ba16a7c9223cc

TIMESTAMPS - 
0:00 Humans and the Artemis Program
1:00 Orion Capsule
2:58 European Service Module
3:38 Tangent Cam
4:16 SLS
6:12 Artemis I
7:52 Artemis II
8:50 Deep Space Network
9:49 Human Landing System
12:42 Artemis III
13:57 Artemis IV
14:24 Artemis V
14:49 The Future of the Artemis Program
18:50 Sponsor - Henson Shaving


# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## Delivering mail by jumping from a moving boat
 - [https://www.youtube.com/watch?v=2vd8Wfk9im0](https://www.youtube.com/watch?v=2vd8Wfk9im0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-08-15 00:00:00+00:00

On Lake Geneva, Wisconsin, there's a summer tradition: "mail jumping". It's a bit dangerous, a bit ridiculous, and would never be allowed to start today. But it's a tradition. ■ Thanks to the Lake Geneva Cruise Line: https://www.cruiselakegeneva.com/

Edited by Michelle Martin https://twitter.com/mrsmmartin

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This is my Endgame - Mother Vault Server Room Update
 - [https://www.youtube.com/watch?v=pLC0FUnko-M](https://www.youtube.com/watch?v=pLC0FUnko-M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-08-04 00:00:00+00:00

Check out the Manta toolkit at: https://www.iFixit.com/LTT 

The JBODs and the head server are here which means it's FINALLY time to deploy the mother of all archival storage solutions, housing up to 270 hard drives. EEEEK.

Discuss on the forum: https://linustechtips.com/topic/1447503-this-is-my-endgame/

Check out Supermicro JBODs: https://lmg.gg/ztt2P
Check out Supermicro A+ Servers: https://lmg.gg/8G7vz
Check out Kioxia CM6 Enterprise NVMe SSDs: https://lmg.gg/xESWf
Check out Micron Registered ECC DDR4: https://lmg.gg/RXyzo
Check out Mellanox ConnectX-6 Network Cards: https://lmg.gg/YCwI2
Check out AMD EPYC 74F3 CPUs: https://lmg.gg/Gm7ql

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
2:15 The head server
8:24 Going on a storage adventure
9:40 Last parts
10:58 Nightmare fuel
11:10 ITS LOUD... sort of
12:10 Does the head server work?
12:58 The game plan
14:13 They lied to us
15:44 Linus & Jake start a moving company
20:13 Pressing the button
21:09 IT'S ALIVE
23:58 Testing it

## The Glaring Problem with Gaming Monitors - Dough Spectrum
 - [https://www.youtube.com/watch?v=MuzwlZi7FP8](https://www.youtube.com/watch?v=MuzwlZi7FP8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-08-03 00:00:00+00:00

Check out Storyblocks and sign up for their Unlimited All Access Plan at https://www.storyblocks.com/linustechtips

Check out Storyblocks at https://www.storyblocks.com/linustechtips

The glossy version of the Eve Spectrum 4K gaming monitor showed up and we had to find out not only which one we like more, but if this company has improved at all since the last product we got. Considering they changed their name to Dough before we could publish and some of the issues we had, maybe not so much...

Discuss on the forum: https://linustechtips.com/topic/1447264-the-glaring-problem-with-gaming-monitors/


Buy a GIGABYTE G34WQC A 34": https://geni.us/It0bv

Buy an Alienware AW3423DW: https://lmg.gg/VRdGJ

Buy an Apple Studio Display: https://lmg.gg/1R5uA

Buy an ROG Strix XG43UQ: https://geni.us/umgq

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:39 PSA
2:21 Side by Side
4:10 Lights Off
4:55 Specs
5:50 Why?
7:50 Is Eve Trustworthy?
8:30 Issues
10:35 Conclusion
13:32 Outro


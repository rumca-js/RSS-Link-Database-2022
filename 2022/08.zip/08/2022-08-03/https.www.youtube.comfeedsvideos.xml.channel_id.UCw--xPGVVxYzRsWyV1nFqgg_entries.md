# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## LORD OF THE RINGS JEOPARDY!
 - [https://www.youtube.com/watch?v=KB9W-GOksF0](https://www.youtube.com/watch?v=KB9W-GOksF0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-08-04 00:00:00+00:00

Fundraiser: https://www.32auctions.com/AuthorsForAbortion
Man Carrying: https://www.youtube.com/c/ManCarryingThing
Quinn's Ideas: https://www.youtube.com/c/QuinnsIdeas 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## Twists Of Darkness - Berserk Vol. 15 [Part 1]
 - [https://www.youtube.com/watch?v=hNKkZRcwm9w](https://www.youtube.com/watch?v=hNKkZRcwm9w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-08-04 00:00:00+00:00

Okay, but Jill is in the top three badasses of #Berserk already! 
This video covers Berserk Deluxe Edition 5 - Volume 15, which includes the chapters:
"Queen", "Elf Fire", "Red-Eyed Peekaf", and "The Recollected Girl".

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## ULTIMATE DELUXE BOOK BUYER'S GUIDE!
 - [https://www.youtube.com/watch?v=9gBS8aUBneE](https://www.youtube.com/watch?v=9gBS8aUBneE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-08-03 00:00:00+00:00

The ultimate buyer's guide for deluxe editions of books!


New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene


Merch: https://www.designbyhumans.com/shop/FantasyNews/ 


Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p


Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  


P.O. Box: PO Box 7874 Henrico, VA 23231


Discworld Emporium: https://www.discworldemporium.com/ 


The broken Binding: https://www.thebrokenbinding.co.uk/ 


Juniper Books: https://www.juniperbooks.com/?gclid=CjwKCAjwlqOXBhBqEiwA-hhitBwXag66cQO3cNA1TPY70yhhLgw22ED2QBsStuSQb2wlW_IT6sidfxoCfkIQAvD_BwE 


A Mark Of Kings: https://amok-limitededition.backerkit.com/hosted_preorders


Folio society: https://www.foliosociety.com/ 


DUNE: Deluxe Edition: https://amzn.to/3Shkofo


Eye of the World POS Edition: https://amzn.to/3bjRvid 


Leviathan Wakes Anniversary Edition: https://amzn.to/3bncyQH 


Hitchhiker’s Guide To The Galaxy: https://amzn.to/3d44DZj


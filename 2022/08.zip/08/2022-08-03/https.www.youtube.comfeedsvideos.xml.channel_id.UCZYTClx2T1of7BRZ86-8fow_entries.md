# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Underwater Sculptures Ended Illegal Fishing
 - [https://www.youtube.com/watch?v=wY1MjISW3xQ](https://www.youtube.com/watch?v=wY1MjISW3xQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-08-04 00:00:00+00:00

The first 100 people to download Endel by clicking the link below will get a free week of audio experiences! https://app.adjust.com/b8wxub6?campaign=scishow_august&adgroup=youtube

Though shipwrecks can often be deadly for the mariners aboard the vessels, once they sink they become new habitats for all sorts of marine life. But with the ship often comes nasty chemicals and toxins, so some countries are looking to fix this issue with art.

Hosted by: Michael Aranda

Thumbnail credit: Enrico Strocchi

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Matt Curls, Alisa Sherbow, Dr. Melvin Sanicas, Harrison Mills, Adam Brainard, Chris Peters, charles george, Piya Shedden, Alex Hackman, Christopher R, Boucher, Jeffrey Mckishen, Ash, Silas Emrys, Eric Jensen, Kevin Bealer, Jason A Saslow, Tom Mosner, Tomás Lagos González, Jacob, Christoph Schwanke, Sam Lutfi, Bryan Cloer


----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow
----------
Sources:
https://www.researchgate.net/publication/340094523
https://www.researchgate.net/publication/286163402
https://www.casadeipesci.it/index.php?option=com_k2&view=itemlist&layout=category&task=category&id=4&Itemid=608 
https://www.researchgate.net/publication/271515279
https://paoloilpescatore.it/lacasadeipesci.php 
https://www.mundusmaris.org/index.php/en/projects/2021/2529-casa-en 

Are Shipwrecks Good for Fish?
https://www.moua.com.au/project-update 
https://www.academia.edu/79662295/Are_shipwrecks_a_real_hazard_for_the_ecosystem_in_the_Mediterranean_Sea
https://link.springer.com/article/10.1007/s00227-021-03917-9 

Image Sources:
https://www.gettyimages.com/detail/video/wreck-underwater-shipwreck-on-seabed-sea-floor-standing-stock-footage/1384865322?adppopup=true
https://commons.wikimedia.org/wiki/File:Sienna,_Grenada_Underwater_Sculptures_(SunCat)_-_Flickr.jpg
https://www.gettyimages.com/detail/video/drone-shots-of-sinking-ship-stranded-ship-old-rusty-ship-stock-footage/1172537406?adppopup=true
https://commons.m.wikimedia.org/wiki/File:Graveyard_of_ships_near_Serebryanskay_road_in_Teriberka.jpg
https://commons.wikimedia.org/wiki/File:MNMS_Sand_Tiger_Shark_USS_Tarpon_(48783007938).jpg
https://commons.wikimedia.org/wiki/File:Mero_(Epinephelus_marginatus),_Madeira,_Portugal,_2019-05-31,_DD_24.jpg
https://commons.wikimedia.org/wiki/File:Grouper1.JPG
https://www.gettyimages.com/detail/photo/wreck-of-steamship-vis-royalty-free-image/526828908?adppopup=true
https://commons.wikimedia.org/wiki/File:Marconi_operator_aboard_ship_%27Deutschland%27,_at_his_instruments_LCCN2014683102-edited.jpg
https://commons.wikimedia.org/wiki/File:Grouper3.JPG
https://www.gettyimages.com/detail/video/shipwreck-stock-footage/472949337?adppopup=true
https://commons.wikimedia.org/wiki/File:Ocean_atlas_clifton_2018.jpg
https://www.gettyimages.com/detail/photo/stone-statue-standing-on-sea-sandy-bottom-royalty-free-image/940330284?adppopup=true
https://www.gettyimages.com/detail/photo/seascape-of-great-barrier-reef-in-queensland-royalty-free-image/1328414536?adppopup=true
https://www.gettyimages.com/detail/video/groups-of-large-predatory-fish-prey-on-schools-of-stock-footage/1344129064?adppopup=true
https://www.flickr.com/photos/strocchi/49615256547


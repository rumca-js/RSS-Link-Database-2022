# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Microsoft's wasted potential: Windows on ARM
 - [https://www.youtube.com/watch?v=9WgG2sGEhzo](https://www.youtube.com/watch?v=9WgG2sGEhzo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2022-08-03 00:00:00+00:00

Thanks to Apcsilmic for sending the Dot 1 Mini PC so I could test Windows 11 Pro on ARM!

(Apcsilmic did not pay for this video or have any input into the content of the video, but they did send me this device for testing, therefore I've added the sponsorship disclaimer.)

You can find out more about the Dot 1 Mini PC here: https://www.apcsilmic.com/products/dot-mini-pc?variant=42469270552825

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Merch: https://redshirtjeff.com
2nd Channel: https://www.youtube.com/c/GeerlingEngineering

#Microsoft #ARM #Windows

Contents:

00:00 - Microsoft's problem
00:27 - A Snapdragon Mini PC
02:04 - Windows on ARM
04:45 - Performance
06:18 - Power consumption, clock speeds, thermals
08:44 - What about Linux?
09:35 - Microsoft can do better


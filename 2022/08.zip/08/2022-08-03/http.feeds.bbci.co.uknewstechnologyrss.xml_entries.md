# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## UK Parliament closes TikTok account after China data warning
 - [https://www.bbc.co.uk/news/uk-politics-62410234?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62410234?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-08-03 14:37:11+00:00

Senior MPs had raised data security concerns and had called for the account to be taken down.

## Booking.com scam: Tourists descend on north London private home
 - [https://www.bbc.co.uk/news/uk-england-london-62407046?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62407046?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-08-03 10:29:24+00:00

A woman says she feels vulnerable after dozens of tourists arrived at her private home throughout July.

## Tinder: CEO Renate Nyborg to leave dating app after one year
 - [https://www.bbc.co.uk/news/business-62402874?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62402874?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-08-03 09:01:48+00:00

Renate Nyborg's exit is part of a major shake-up of the dating app's management and strategy.


# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## The "New" File System in Windows: ReFS
 - [https://www.youtube.com/watch?v=lxrF9FzxeTU](https://www.youtube.com/watch?v=lxrF9FzxeTU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-08-03 00:00:00+00:00

Well it's not exactly new, but it's still rare!
⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

Better explanation of Sparse VDL: https://www.osr.com/nt-insider/2015-issue1/logical-physical-file-sizes-windows/

▼ Time Stamps: ▼
0:00 - Intro
1:48 - How is it Resilient?
3:32 - ReFS Features
3:38 - Block Cloning
4:26 - Sparse VDL
5:28 - Mirror Accelerated Parity
7:17 - File Level Snapshots
8:06 - Features NOT in ReFS
10:32 - Are You Missing Out?

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


## How I Used DALL·E 2 to Generate The Logo for OctoSQL | Jacob Martin
 - [https://jacobmartins.com/posts/how-i-used-dalle2-to-generate-the-logo-for-octosql/](https://jacobmartins.com/posts/how-i-used-dalle2-to-generate-the-logo-for-octosql/)
 - RSS feed: https://jacobmartins.com
 - date published: 2022-08-03 09:18:32+00:00

Everybody has heard about the latest cool thing™, which is DALL·E 2 (henceforth called Dall-e). A few months ago, when the first previews started, it was basically everywhere. Now, a few weeks ago, the floodgates have been opened and lots of people on the waitlist got access - that group included me. I’ve spent a day playing around with it, learned some basics (like the fact that adding “artstation” to the end of your phrase automatically makes the output much better…), and generated a bunch of (even a few nice-looking) images.


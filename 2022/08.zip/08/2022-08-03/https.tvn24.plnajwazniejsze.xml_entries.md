# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Chce być premierem. Krytycy ostrzegają przed "drugimi Węgrami"
 - [https://tvn24.pl/go/audio,14/podcast-o-zagranicy-odcinki,663543/odcinek-32,S00E32,832217?source=rss](https://tvn24.pl/go/audio,14/podcast-o-zagranicy-odcinki,663543/odcinek-32,S00E32,832217?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-08-03 04:00:00+00:00

<img alt="Chce być premierem. Krytycy ostrzegają przed " src="https://tvn24.pl/najnowsze/cdn-zdjecie-0c3if7-giorgia-meloni-podcast-o-zagranicy-w-tvn24-go-6025769/alternates/LANDSCAPE_1280" />
    Może być pierwszą w historii Włoch kobietą na stanowisku szefa rządu.


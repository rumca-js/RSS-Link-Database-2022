## Fotomat History | Mental Floss
 - [https://www.mentalfloss.com/article/626991/overexposed-history-fotomat](https://www.mentalfloss.com/article/626991/overexposed-history-fotomat)
 - RSS feed: https://www.mentalfloss.com
 - date published: 2022-08-03 10:58:23.872114+00:00

The tiny photo processing kiosks could be found everywhere in the 1970s and 1980s. And that was the problem.


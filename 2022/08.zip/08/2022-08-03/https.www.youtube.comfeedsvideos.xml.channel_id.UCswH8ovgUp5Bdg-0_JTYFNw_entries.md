# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## You Won't Believe THIS
 - [https://www.youtube.com/watch?v=4LEkPYTT3Mw](https://www.youtube.com/watch?v=4LEkPYTT3Mw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-08-04 00:00:00+00:00

I spoke with journalist Matt Taibbi about how the American defense budget is at a record $840 billion; $60 billion above what the President and Pentagon asked for, how the Americans have been selling fighter jets all over Europe and how a never ending feeling of anxiety is used to keep the population in check. #ukraine #russia #military 

Visit Matt's Substack Here: https://taibbi.substack.com/
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


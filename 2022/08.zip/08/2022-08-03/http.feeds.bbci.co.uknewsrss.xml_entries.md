# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Afra Rafeeq: India teen who died but raised millions to save her brother
 - [https://www.bbc.co.uk/news/world-asia-india-62403456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-62403456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 23:20:48+00:00

Afra Rafeeq, who died this week, had raised millions of rupees to help get a crucial drug for her baby brother.

## Fatima Payman: Meet Australia's first hijab-wearing senator
 - [https://www.bbc.co.uk/news/world-australia-62374371?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-62374371?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 23:04:45+00:00

Fatima Payman arrived in Australia as the child of an Afghan refugee - now she's making history.

## Birds nesting in rubbish discarded by humans
 - [https://www.bbc.co.uk/news/science-environment-62407026?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62407026?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 23:01:38+00:00

Photographs from every continent except Antarctica show birds nesting or tangled in rubbish.

## Banned Russian oligarchs exploited UK secrecy loophole
 - [https://www.bbc.co.uk/news/uk-62410715?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62410715?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 21:34:23+00:00

A BBC investigation links a little-known type of company to fraud, terrorism and money laundering.

## Viktor Orban alone in Europe but among friends in Texas
 - [https://www.bbc.co.uk/news/world-europe-62408368?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62408368?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 21:23:52+00:00

The controversial Hungarian leader will be warmly received when he addresses US Republicans.

## Commonwealth Games 2022: 'Incredible' Eilish McColgan wins 10,000m gold
 - [https://www.bbc.co.uk/sport/av/commonwealth-games/62415787?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/commonwealth-games/62415787?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 20:51:28+00:00

Scotland's Eilish McColgan wins gold in the 10,000m, holding off the challenge of Kenya's Irine Cheptai in an "incredible" final lap at the 2022 Commonwealth Games in Birmingham.

## After Kansas defeat, what's next for abortion bans?
 - [https://www.bbc.co.uk/news/world-us-canada-62413578?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62413578?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 19:51:24+00:00

While the battle to ban abortion in Kansas may have been lost, the fight continues across the US.

## Zawahiri's victims: What it feels like to hear he's gone
 - [https://www.bbc.co.uk/news/world-us-canada-62412408?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62412408?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 19:27:05+00:00

The al-Qaeda leader's death hits home to those he robbed of a husband, a wife, or their eyesight.

## London Zoo's crocodile skin handbag display goes viral
 - [https://www.bbc.co.uk/news/uk-62412328?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62412328?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 19:22:14+00:00

The bag was seized by UK Border Force and given to the zoo to showcase the reality of the illegal trade.

## Commonwealth Games 2022: Scotland's Duncan Scott beats England's Tom Dean to 200m gold
 - [https://www.bbc.co.uk/sport/av/commonwealth-games/62415092?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/commonwealth-games/62415092?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 18:49:14+00:00

Scotland's Duncan Scott finishes the 200m individual medley in first place ahead of England's Tom Dean who took the silver at the 2022 Commonwealth Games in Birmingham.

## Space debris Australia: Piece of SpaceX capsule crashes to Earth in field
 - [https://www.bbc.co.uk/news/world-australia-62414438?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-62414438?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 18:09:23+00:00

This may become more common as the number of rockets sent to space increases, an expert said.

## Stockport twins share secret to long life on 103rd birthday
 - [https://www.bbc.co.uk/news/uk-england-manchester-62409933?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-62409933?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 17:50:45+00:00

Sisters Elma and Thelma are thought to be Britain's oldest twins and celebrated with a party.

## Southend United to rename 'Rose West' stand
 - [https://www.bbc.co.uk/news/uk-england-essex-62405123?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-62405123?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 15:07:01+00:00

Fans are quick to point out that the full name of Southend's new stand includes the name of a serial killer.

## Lina Nielsen: British 400m hurdler reveals multiple sclerosis diagnosis before Commonwealths debut
 - [https://www.bbc.co.uk/sport/athletics/62408650?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/62408650?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 13:48:32+00:00

British 400m hurdler Lina Nielsen, who will compete at the Commonwealth Games, reveals she has multiple sclerosis.

## Bristol bus boycott campaigner Roy Hackett dies
 - [https://www.bbc.co.uk/news/uk-england-bristol-62397167?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-62397167?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 12:46:13+00:00

Tributes are paid to "humble freedom fighter" Mr Hackett, one of the Bristol Bus Boycott organisers.

## Commonwealth Games 2022: 'You're too tall for the camera' - Watch Ovie Soko react to basketball gold
 - [https://www.bbc.co.uk/sport/av/commonwealth-games/62410429?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/commonwealth-games/62410429?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 12:44:18+00:00

Watch Ovie Soko and BBC Sport's Ayo Akinwolere react as England score a buzzer-beater to win gold in the men's 3x3 basketball at the Commonwealth Games.

## Man guilty of killing stranger by pushing her off Helensburgh Pier
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-62406025?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-62406025?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 12:36:28+00:00

Jacob Foster is found guilty of killing Charmaine O'Donnell by pushing her off Helensburgh Pier last year.

## Commonwealth Games 2022: Charlie Aldridge crashes in mountain bike
 - [https://www.bbc.co.uk/sport/av/commonwealth-games/62408767?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/commonwealth-games/62408767?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 12:26:01+00:00

Scotland's Charlie Aldridge see his hopes of cross country cycling bronze disappear after he crashes and breaks his bike at the Commonwealth Games.

## Kent and Sussex hosepipe ban announced from 12 August
 - [https://www.bbc.co.uk/news/uk-england-kent-62404637?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-62404637?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 12:20:47+00:00

South East Water is restricting usage from 12 August, affecting at least one million people.

## Taiwan: Pelosi leaves Taipei to sound of Chinese fury
 - [https://www.bbc.co.uk/news/world-asia-62405680?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62405680?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 12:12:05+00:00

"Those who play with fire will not come to a good end," warns China's foreign minister after the visit.

## Batgirl movie scrapped months before planned release
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-62406098?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-62406098?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 12:10:33+00:00

The movie, which had a reported budget of $70m, was filmed entirely in Glasgow.

## Archie Battersbee: Parents take case to European Court of Human Rights
 - [https://www.bbc.co.uk/news/uk-england-essex-62403993?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-62403993?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 11:49:56+00:00

The 12-year-old's life support was due to be withdrawn on Wednesday morning.

## England set out to inspire the nation, says winning goalscorer Chloe Kelly
 - [https://www.bbc.co.uk/sport/football/62404195?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62404195?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 11:40:21+00:00

England's winning goalscorer Chloe Kelly says the Lionesses set out to "inspire the nation" and did so by becoming European champions.

## Safe to swim in sea, says expert after suspected shark attack
 - [https://www.bbc.co.uk/news/uk-england-cornwall-62404667?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cornwall-62404667?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 11:08:34+00:00

Enjoy the sea, says a marine biologist after a suspected shark attack off Cornwall.

## Dev Patel: Actor breaks up knife fight in Australia
 - [https://www.bbc.co.uk/news/entertainment-arts-62407444?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62407444?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 10:37:35+00:00

The Slumdog Millionaire star successfully broke up an altercation in Adelaide on Monday.

## Premier League players to limit taking a knee
 - [https://www.bbc.co.uk/sport/football/62404611?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62404611?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 10:35:40+00:00

Premier League players will stop the pre-match anti-racism gesture of taking the knee before every match for the 2022-23 season.

## China-Taiwan: As China broods, Taiwan is in a 'Pelosi lovefest'
 - [https://www.bbc.co.uk/news/world-asia-62407868?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62407868?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 10:26:14+00:00

The US Speaker's visit is celebrated in Taipei, but could it spark a major US-China crisis?

## Lizelle Lee: Batter felt forced out of South Africa 'because of my weight'
 - [https://www.bbc.co.uk/sport/africa/62394578?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/africa/62394578?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 10:13:13+00:00

South African batter Lizelle Lee says failing a weight test was key to her shock decision to retire from international cricket.

## Arizona Primary: Rusty Bowers, who defied Trump, loses re-election bid
 - [https://www.bbc.co.uk/news/world-us-canada-62405677?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62405677?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 09:45:43+00:00

Rusty Bowers, who testified against Donald Trump in June, loses to an ally of the ex-president.

## Russo: After school I would tag along with a boys' team
 - [https://www.bbc.co.uk/news/uk-62404698?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62404698?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 08:41:19+00:00

The Euro 2022 winner says girls who want to play football should have equal opportunities.

## Premier League predictions: Who will finish where in 2022-23?
 - [https://www.bbc.co.uk/sport/football/62391593?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62391593?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 08:00:22+00:00

BBC Sport chief football writer Phil McNulty makes his annual predictions for who will finish where in the English top flight.

## Gender and dance music: D-LISH talks about female DJ experiences
 - [https://www.bbc.co.uk/news/newsbeat-62398830?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-62398830?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 06:58:26+00:00

DJ D-LISH talks about the prejudice she's experienced as a female DJ in a male-dominated field.

## Emma Raducanu reaches Washington Open second round
 - [https://www.bbc.co.uk/sport/tennis/62404189?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62404189?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 06:29:47+00:00

Emma Raducanu's preparations to defend her US Open title get under way with a win over Louisa Chirico at the Washington Open.

## Taiwan: Nancy Pelosi meets President Tsai to Beijing's fury
 - [https://www.bbc.co.uk/news/world-asia-62398029?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62398029?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 05:46:29+00:00

The highest-ranking US politician to visit Taiwan in 25 years arrives despite warnings from China.

## Pelosi visit: Taiwan puts the ball firmly in Xi Jinping's court
 - [https://www.bbc.co.uk/news/world-asia-62402935?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62402935?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 05:24:26+00:00

Nancy Pelosi's visit to Taipei has put an increasingly assertive China on the back foot.

## Original Lionesses: We had to really fight
 - [https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-62384197?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-62384197?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 05:19:59+00:00

They are still campaigning for official caps but the original Lionesses are proud of their achievements.

## The Hundred 2022: Who is playing, what's new, who the favourites are and how to follow
 - [https://www.bbc.co.uk/sport/cricket/62390337?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62390337?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 05:08:26+00:00

Who is playing, what's new, who the favourites are and how to follow - all you need to know as The Hundred returns for 2022.

## Newbury council plans for 'hedgehog highways' rejected
 - [https://www.bbc.co.uk/news/uk-england-berkshire-62393204?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-berkshire-62393204?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 04:58:13+00:00

Council rejects proposal for holes in fences to allow the creatures to move freely.

## Ayman al-Zawahiri: How US strike could kill al-Qaeda leader - but not his family
 - [https://www.bbc.co.uk/news/world-us-canada-62400923?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62400923?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 03:29:02+00:00

Extremely precise missile use and study of Zawahiri's habits were key to the targeted US killing.

## Oscars 2023: Harry Styles has two films hoping for awards glory
 - [https://www.bbc.co.uk/news/entertainment-arts-62341771?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62341771?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 01:03:48+00:00

Don't Worry Darling and My Policeman are among 23 movies hoping for awards in 2023.

## Assam: Muslims falsely accused of waging ‘flood jihad’
 - [https://www.bbc.co.uk/news/world-asia-india-62378520?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-62378520?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 01:02:59+00:00

Why have members of Assam’s Muslim community been blamed for recent floods in the state?

## The Nigerians worried about a bill to outlaw cross-dressing
 - [https://www.bbc.co.uk/news/world-africa-61646540?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-61646540?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 00:56:15+00:00

LGBTQ+ Nigerians fear what might happen if a proposal to ban cross-dressing is adopted by parliament.

## 'I was chased by skinheads when I arrived in Leicester'
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-62306155?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-62306155?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 00:27:24+00:00

A Ugandan Asian who settled in Leicester recalls the racism she experienced in the city in the 1970s.

## Sixth-form students use art to explore the future of the planet
 - [https://www.bbc.co.uk/news/in-pictures-61969406?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-61969406?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-08-03 00:01:40+00:00

Sixth-formers from 64 colleges show their creative work, in an online exhibition.


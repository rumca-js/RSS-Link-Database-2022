# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Poliça - Blood (Live on KEXP)
 - [https://www.youtube.com/watch?v=IEJ2K7I6XtM](https://www.youtube.com/watch?v=IEJ2K7I6XtM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-03 00:00:00+00:00

http://KEXP.ORG presents Poliça performing “Blood” live in the KEXP studio. Recorded July 7, 2022.

Channy Leaneagh - Vocals
Chris Bierden - Bass / Vocals
Drew Christopherson - Drums
Ben Ivascu - Drums

Host: Cheryl Waters
Audio Engineers: Justin Andersen & Julian Martlew
Audio Mixer: Justin Andersen
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.thisispolica.com
http://kexp.org

## Poliça - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=--0ClVdiZjE](https://www.youtube.com/watch?v=--0ClVdiZjE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-03 00:00:00+00:00

http://KEXP.ORG presents Poliça performing live in the KEXP studio. Recorded July 7, 2022.

Songs:
Sweet Memz
Blood 
Madness
Amongster

Channy Leaneagh - Vocals
Chris Bierden - Bass / Vocals
Drew Christopherson - Drums
Ben Ivascu - Drums

Host: Cheryl Waters
Audio Engineers: Justin Andersen & Julian Martlew
Audio Mixer: Justin Andersen
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.thisispolica.com
http://kexp.org

## Poliça - Madness / Amongster (Live on KEXP)
 - [https://www.youtube.com/watch?v=egCkG7-gjRY](https://www.youtube.com/watch?v=egCkG7-gjRY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-03 00:00:00+00:00

http://KEXP.ORG presents Poliça performing “Madness" and "Amongster” live in the KEXP studio. Recorded July 7, 2022.

Channy Leaneagh - Vocals
Chris Bierden - Bass / Vocals
Drew Christopherson - Drums
Ben Ivascu - Drums

Host: Cheryl Waters
Audio Engineers: Justin Andersen & Julian Martlew
Audio Mixer: Justin Andersen
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.thisispolica.com
http://kexp.org

## Poliça - Sweet Memz (Live on KEXP)
 - [https://www.youtube.com/watch?v=eqq-ERZoRXQ](https://www.youtube.com/watch?v=eqq-ERZoRXQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-03 00:00:00+00:00

http://KEXP.ORG presents Poliça performing “Sweet Memz” live in the KEXP studio. Recorded July 7, 2022.

Channy Leaneagh - Vocals
Chris Bierden - Bass / Vocals
Drew Christopherson - Drums
Ben Ivascu - Drums

Host: Cheryl Waters
Audio Engineers: Justin Andersen & Julian Martlew
Audio Mixer: Justin Andersen
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.thisispolica.com
http://kexp.org


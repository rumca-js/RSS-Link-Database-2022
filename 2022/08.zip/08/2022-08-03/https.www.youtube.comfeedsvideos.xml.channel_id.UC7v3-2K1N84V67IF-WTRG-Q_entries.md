# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Prey - Movie Review
 - [https://www.youtube.com/watch?v=J-RkZUitNyc](https://www.youtube.com/watch?v=J-RkZUitNyc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-08-04 00:00:00+00:00

Thanks to Dr. Squatch for sponsoring! New customers can go to https://bit.ly/3QbT4x6 and use promo code  DSQJAHNS at checkout to save 20% off your purchase of $20 or more!

A new Predator movie that looks to go into a direction that might just do a Predator sequel justice? Here's my review for PREY!

#PreyMovie #Predator


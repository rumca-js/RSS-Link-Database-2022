# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## Roblox: The Most Evil Business In The World
 - [https://www.youtube.com/watch?v=JtStWxDh-KQ](https://www.youtube.com/watch?v=JtStWxDh-KQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2022-08-03 00:00:00+00:00

Check out Kible.io today: https://kible.io/  @kible.io

 "Image in thumbnail by https://www.youtube.com/c/LOGinHDi"


🟢 Get exclusive access for my private unfiltered controversial videos that can't be released to the public: https://www.youtube.com/c/Moon-Real/join

Support the channel here (all money goes straight back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT


Roblox and Roblox money is a very evil business model. Roblox developers who make Roblox games are done very badly. With roblox targeting Roblox kids are being targeted which is why roblox is bad and roblox has become trash. This is the dark side of roblox.


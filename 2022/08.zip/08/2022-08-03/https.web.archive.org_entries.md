## Please stop citing TIOBE
 - [https://web.archive.org/web/20220802174107/https://blog.nindalf.com/posts/stop-citing-tiobe/](https://web.archive.org/web/20220802174107/https://blog.nindalf.com/posts/stop-citing-tiobe/)
 - RSS feed: https://web.archive.org
 - date published: 2022-08-03 11:08:41.200824+00:00

Krishna's personal blog


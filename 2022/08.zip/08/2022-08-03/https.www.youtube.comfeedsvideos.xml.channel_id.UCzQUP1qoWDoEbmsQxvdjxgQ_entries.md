# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Jeremey Corbell Defends Bob Lazar's Story
 - [https://www.youtube.com/watch?v=L98U3mO38gQ](https://www.youtube.com/watch?v=L98U3mO38gQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-08-04 00:00:00+00:00

Taken from JRE #1853 w/Jeremey Corbell:
https://open.spotify.com/episode/0gYVutFOYsHaklxO0DLcS7?si=f531b19fff9b4118

## Sam Tripoli on Operation Highjump: Nazi's, Aliens, and Antarctica
 - [https://www.youtube.com/watch?v=jn5p-fExsL0](https://www.youtube.com/watch?v=jn5p-fExsL0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-08-03 00:00:00+00:00

Taken from JRE #1852 w/Sam Tripoli:
https://open.spotify.com/episode/4UrZzFP5G06maV8iUzLak2?si=af912afafe9f45bd

## The Strange Reason Ben Franklin's Basement Was Filled with Skeletons
 - [https://www.youtube.com/watch?v=nMBFf1SIBRs](https://www.youtube.com/watch?v=nMBFf1SIBRs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-08-03 00:00:00+00:00

Taken from JRE #1852 w/Sam Tripoli:
https://open.spotify.com/episode/4UrZzFP5G06maV8iUzLak2?si=af912afafe9f45bd


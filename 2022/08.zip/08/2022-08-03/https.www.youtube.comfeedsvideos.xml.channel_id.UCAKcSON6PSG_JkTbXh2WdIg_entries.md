# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Matthew French - live at Radio Heartland (full session + interview)
 - [https://www.youtube.com/watch?v=3En9oHiZ5mo](https://www.youtube.com/watch?v=3En9oHiZ5mo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-08-04 00:00:00+00:00

Matthew French had an album in mind a few years ago that was a mix of ballad-like songs and more up-tempo rockers, and he’d release them at two different times. But as the songs unfolded and were recorded, he decided the two formats were split in a different way … by their subject matter. Hence, Matthew’s two releases: Two Sides: Side One, and Two Sides: Side Two. The first side was released earlier this year, and Side Two just came out at the end of July, and each “side” has a slightly different feel due to the lyrics.

Matthew is a guy who’s used to sitting down to sing and play his songs accompanied by his acoustic guitar. But this album called for something different. And to talk about the album and play some of the songs for us, he brought in a local “A Team” of players to support him.

Segments
00:00 Some Days
03:30 Interview with host Mike Pengra, part 1
08:58 A Heart Needs a Place
12:00 Interview with host Mike Pengra, part 2
17:02 You Got Me

Personnel
Matthew French - vocals, guitar
Steve Bosmans - lead guitar
Richard Medek - drums
Sarah Morris - backing vocals
Nick Salisbury - bass

Guest - Matthew French
Host - Mike Pengra
Video - Evan Clark
Audio - Eric Xu Romani
Camera Operator - Thor Cramer Bornemann

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

This activity is made possible in part by the Minnesota Legacy Amendment's Arts & Cultural Heritage Fund.

#matthewfrench #matthewfrenchmusic #mfrenchmusic


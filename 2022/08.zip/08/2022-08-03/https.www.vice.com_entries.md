## Widely Mocked Anti-Piracy Ads Made People Pirate More, Study Finds
 - [https://www.vice.com/en/article/93aan8/widely-mocked-anti-piracy-ads-made-people-pirate-more-study-finds](https://www.vice.com/en/article/93aan8/widely-mocked-anti-piracy-ads-made-people-pirate-more-study-finds)
 - RSS feed: https://www.vice.com
 - date published: 2022-08-03 11:04:23.121197+00:00

A behavioral economics study of anti-piracy ads reveals that they’re largely ineffective and often encourage piracy.


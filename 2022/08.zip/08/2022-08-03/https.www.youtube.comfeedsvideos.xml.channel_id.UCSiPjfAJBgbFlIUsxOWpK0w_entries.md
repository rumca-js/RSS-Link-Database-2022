# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## RESPECT MY ART // Nick Campbell Destroys // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=eiAha2FLxC0](https://www.youtube.com/watch?v=eiAha2FLxC0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-08-04 00:00:00+00:00

Presenting, the one and only, Nick Campbell DESTROYS!!!!!!! “Fancy Jeans” is available in all the places.

Save this song on Spotify: https://open.spotify.com/track/6OnEp43ne1pffeUKM4kqVG?si=5de3ee9775ff4648
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

MUSICIAN CREDITS
Lead Vocals/Keys: Jacob Luttrell
Bass: Nick Campbell Destroys
Keys: Jack Conte
Keys/Talkbox Vocals: Swatkins
Drums: Chaun Horton
Bongos/Percussion: Ben Rose

AUDIO CREDITS
Engineer: Tim Sonnefeld
Assistant Engineer: Tyler Karmen
Mixing/Mastering: Yianni AP

VIDEO CREDITS
Director: Dom Fera
DP: Merlin Showalter
Gaffer: Arjay Ancheta
Production Designer: Katie Theel
Video Editor/Colorist: Athena Wheaton

Recorded at 64 Sound in Los Angeles.


## #25 Nowa przygoda zaczęła się grubo, Karolina północna
 - [https://www.youtube.com/watch?v=dfbKxwl-d08](https://www.youtube.com/watch?v=dfbKxwl-d08)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIFlYVfPnvukmFOvC4JUfOg
 - date published: 2022-08-03 00:00:00+00:00

Czas na Solo vlogi a zaczynamy z grubej, Karolina północna, wodospady i cała zabawa z tym związana. Czasami dźwięk może być gorszy od wody i obraz szwankować bo lekko gopro się pobiło.
🧗🏻Wesprzyj moje przygody na patronite: https://patronite.pl/Nejtan
📷 Instagram: https://www.instagram.com/nejthan
📜 Napisz do mnie: swiatwedlugnejtana@gmail.com
🎵 Muzyka: https://share.epidemicsound.com/m7uq26

2022 Trip z  @vlogcasha    po Florydzie https://bit.ly/3uueZGV
2021 Trip z  @vlogcasha    po zachodzie Usa i Alaska
https://bit.ly/3D6ClpI
#swiatwedlugnejtana #nejtan


# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Batgirl Cancelled - A Sign Of Things To Come?
 - [https://www.youtube.com/watch?v=qbUio8oV5u8](https://www.youtube.com/watch?v=qbUio8oV5u8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-08-04 00:00:00+00:00

The recent announcement by Warner Discovery that Batgirl, a movie costing almost $100 Million was being cancelled due to disastrous test screenings caught everyone by surprise. Was this really a case of a studio wisely sparing us from a terrible film, or was this part of a bigger change at the studio and Hollywood at large? Are we seeing the beginning of the end of The Message in our films?


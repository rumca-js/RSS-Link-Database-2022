# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## OnePlus 10T Impressions: Somebody That You Used to Know
 - [https://www.youtube.com/watch?v=4SHlY9AoXzc](https://www.youtube.com/watch?v=4SHlY9AoXzc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-08-03 00:00:00+00:00

OnePlus 10T is looking more generic than ever. And that's by design.

OnePlus 10 Pro: https://youtu.be/7IaYSxDp88s
On fast charging: https://youtu.be/UpqaQR4ikig

Check out the OnePlus 10 T at https://geni.us/V4i3tH
Buy the OnePlus 10 Pro at https://geni.us/DBPOB4Q

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds: https://lnk.to/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by OnePlus for video.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


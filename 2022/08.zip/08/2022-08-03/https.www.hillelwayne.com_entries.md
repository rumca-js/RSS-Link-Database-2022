## Crimes with Python's Pattern Matching • Hillel Wayne
 - [https://www.hillelwayne.com/post/python-abc/](https://www.hillelwayne.com/post/python-abc/)
 - RSS feed: https://www.hillelwayne.com
 - date published: 2022-08-03 21:48:07+00:00

Let's make the CPython team regret adding pattern matching to Python!


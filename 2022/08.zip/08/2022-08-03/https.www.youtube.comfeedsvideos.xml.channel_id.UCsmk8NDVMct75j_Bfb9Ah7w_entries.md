# Source:Virtual Reality Oasis, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsmk8NDVMct75j_Bfb9Ah7w, language:en-US

## Red Matter 2 - I Can't Believe It Looks This GOOD on Quest 2!
 - [https://www.youtube.com/watch?v=VrffXY2JjLE](https://www.youtube.com/watch?v=VrffXY2JjLE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsmk8NDVMct75j_Bfb9Ah7w
 - date published: 2022-08-03 17:00:18+00:00

Red Matter 2 is coming to Quest 2 on the 18th August. I've been provided early access to give you this early preview of Red Matter 2 gameplay captured directly from the Quest 2...

Check out Red Matter 2 on Quest 2 here ($29.99 / £22.99);
https://www.oculus.com/experiences/quest/3682089508520212

Let me know if you're excited for Red Matter 2 on Quest 2 in the comments below...

Thanks for watching []-) 

VR HEADSETS:
Oculus Quest 2: https://bit.ly/3iHPFWs
Valve Index: http://bit.ly/2v8hZhi

VR ACCESSORIES:
VR Cover: https://bit.ly/3okrLmq
Mamut VR Grips: http://bit.ly/3aE3G32
Widmo Prescription Lenses: http://bit.ly/2W0BTGf
ProTube: http://bit.ly/2sujHb3

FOLLOW ME: 
Subscribe: http://bit.ly/2VeBqfJ
Memberships: http://bit.ly/2MVWxRl
Discord: https://discord.gg/NN9TGrv
Twitter: https://twitter.com/vr_oasis
Instagram: https://instagram.com/virtualrealityoasis
Facebook: https://facebook.com/virtualrealityoasis
FReality Podcast: http://bit.ly/39HdVUj
Website: http://virtualrealityoasis.com/
Email: contact@virtualrealityoasis.com

#RedMatter2 #Quest2 #VR


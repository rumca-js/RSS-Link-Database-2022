# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 HARDEST Video Game Choices That Made Us Sweat [Pt 2]
 - [https://www.youtube.com/watch?v=uJeqWhvRaIA](https://www.youtube.com/watch?v=uJeqWhvRaIA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-08-04 00:00:00+00:00

Some choices in video games are truly agonizing. Here are the tough in-game choices that make us sweat.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
1:03 Wolfenstein: The New Order - The branching timeline
2:21 Saints Row the Third - The Ending Choice
4:02 Pokemon - Picking your starter
5:33 Black Ops: Cold War - lie or tell the truth
7:52 Detroit: Become Human - Pacifism vs. Violence with Markus
8:55 Fallout: New Vegas - Vault 34
10:11 Witcher 3 - Kill the tree Spirit
11:10 Infamous 2 - Make everyone Conduits or kill all Conduits
12:15 Dragon Age: Origins - Go with Morrigan's Plan or Sacrifice yourself
13:29 Nier - Save Kaine (Kain-aye) or Don't

## 10 Ridiculous Trophies That Take FOREVER
 - [https://www.youtube.com/watch?v=LkedqmNJ-RY](https://www.youtube.com/watch?v=LkedqmNJ-RY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-08-03 00:00:00+00:00

Some video game trophies and achievements take an immense amount of time to earn. Here are some extreme examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:12 Number 10
1:27 Number 9
3:04 Number 8
4:01 Number 7
4:53 Number 6
5:57 Number 5
7:51 Number 4
9:03 Number 3
10:10 Number 2
11:17 Number 1


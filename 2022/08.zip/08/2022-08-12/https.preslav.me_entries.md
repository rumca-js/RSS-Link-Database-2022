## I Don’t Like Go’s Default HTTP Handlers · Preslav Rachev
 - [https://preslav.me/2022/08/09/i-dont-like-golang-default-http-handlers/](https://preslav.me/2022/08/09/i-dont-like-golang-default-http-handlers/)
 - RSS feed: https://preslav.me
 - date published: 2022-08-12 15:52:21.262919+00:00

Explicit > Implicit


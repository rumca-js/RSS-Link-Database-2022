# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Neos VR: The Untold Story of a Metaverse Tragedy
 - [https://www.youtube.com/watch?v=0rvAKRWC82g](https://www.youtube.com/watch?v=0rvAKRWC82g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-08-13 00:00:00+00:00

Hello. Today I have a full on documentary of probably the most tragic story within the entire VR industry. Developers shafted, a $500,000,000 market cap shriveled into nothing, and a community left torn. 

But there is still hope. 

Actually something interesting I came across, Neos had a Quest/ Quest 2 and Oculus go version in development as well. Interesting addition. Basically though, crypto tore Neos apart from the inside out, no matter how compelling the technology. 

Thank you to everyone that participated in my dozens of interviews. This is one of the largest "journalistic" videos I have ever done and it took a lot of work, but I hope you enjoyed it. 

Much Love, Thrill

My links:
Twitter: https://twitter.com/Thrilluwu
Discord: https://discord.gg/2hCGM9BYez
Twitch: https://www.twitch.tv/thrilluwu

Neos discord: https://discord.gg/eNYu4xbhVF


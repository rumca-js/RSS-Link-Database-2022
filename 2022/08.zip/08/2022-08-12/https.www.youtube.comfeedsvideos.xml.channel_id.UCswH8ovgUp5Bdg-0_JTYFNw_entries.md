# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## I Can’t Believe He Just DID THIS
 - [https://www.youtube.com/watch?v=B15zpf_6T4c](https://www.youtube.com/watch?v=B15zpf_6T4c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-08-12 00:00:00+00:00

As Justin Trudeau now joins the Netherlands, Germany and Sri Lanka in making applying pressure to farmers over emissions, do politicians and their rich friends they give tax cuts to follow the same climate goals? 
#justintrudeau #canada #farmersprotest #climatechange 

References
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "You Shall Not Pass!" (Full Song)
 - [https://www.youtube.com/watch?v=T7o9J65b6b0](https://www.youtube.com/watch?v=T7o9J65b6b0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2022-08-12 12:00:26+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong 
Watch the remix: https://youtu.be/SAWxWaFenXk
Created on @teenageengineering OP-1
and completed in Logic Pro X using stock plugins and instruments.


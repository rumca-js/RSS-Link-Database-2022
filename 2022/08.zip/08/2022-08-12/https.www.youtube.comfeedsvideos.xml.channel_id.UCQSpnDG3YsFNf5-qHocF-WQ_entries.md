# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## 10 Computer Security Myths to Stop Believing
 - [https://www.youtube.com/watch?v=rIVeisk_G1M](https://www.youtube.com/watch?v=rIVeisk_G1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-08-13 00:00:00+00:00

Get up to 83% off Private Internet Access VPN! ⇨ https://privateinternetaccess.com/TJ (Sponsored)

Links to Yubico physical security keys (affiliate links):
• Yubico Security Key ⇨ https://geni.us/SecurityKey
• Yubico "Yubikey 5" ⇨ https://geni.us/Yubikey5Key

▼ Time Stamps: ▼
0:00 - Intro
0:14 - Myth 1
1:12 - Myth 2
2:33 - Myth 3
3:24 - Very Important Thing
4:20 - Myth 4
6:50 - Myth 5
9:15 - Myths 6 and 7
11:10 - Myth 8
12:22 - Myth 9
14:28 - Myth 10

Note: The links above are Amazon affiliate links, which means I'll probably get a small (usually ~1-2%) commission that helps support the channel if you decide to buy the item. The commission does not come out of your pocket, but rather from Amazon's.

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


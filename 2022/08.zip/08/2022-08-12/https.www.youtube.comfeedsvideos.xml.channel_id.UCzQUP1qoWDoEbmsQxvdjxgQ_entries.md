# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Chris Rock's Comedy Post Will Smith Incident
 - [https://www.youtube.com/watch?v=Q7_3IVK7Q7E](https://www.youtube.com/watch?v=Q7_3IVK7Q7E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-08-12 00:00:00+00:00

Taken from JRE #1856 w/Nate Bargatze:
https://open.spotify.com/episode/42Z5fbeH5YoXIGK45A6kMq?si=e4f115f5d3aa4442

## Will We See Aliens In Our Lifetime?
 - [https://www.youtube.com/watch?v=5fZTX14IsNA](https://www.youtube.com/watch?v=5fZTX14IsNA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-08-12 00:00:00+00:00

Taken from JRE #1856 w/Nate Bargatze:
https://open.spotify.com/episode/42Z5fbeH5YoXIGK45A6kMq?si=e4f115f5d3aa4442


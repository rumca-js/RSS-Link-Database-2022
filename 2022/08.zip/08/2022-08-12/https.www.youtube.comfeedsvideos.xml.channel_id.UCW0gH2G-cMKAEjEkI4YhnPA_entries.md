# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Life of Tar-Míriel | Tolkien Explained
 - [https://www.youtube.com/watch?v=_zcV0pAGKM0](https://www.youtube.com/watch?v=_zcV0pAGKM0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-08-13 00:00:00+00:00

By rights, she should have been the fourth Ruling Queen of Númenor.  However, Tar-Míriel, daughter of the last Faithful King Tar-Palantir, would be usurped by, and forced to marry, her cousin Ar-Pharazôn.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Tulikoura - https://www.deviantart.com/tulikoura
Matthew Stewart - http://www.matthew-stewart.com/
BellaBergolts - https://www.deviantart.com/bellabergolts
Magdalena Katanska - https://www.artstation.com/magdalenakatanska/prints  https://www.instagram.com/qualiney
Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc
Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri
Noe Leyva - https://twitter.com/NoeLeyvArt
Clemence Morisseau - https://www.artstation.com/kahirie
Edvige Faini - www.edvigefaini.com , www.facebook.com/edvige.faini , www.instagram.com/edvige_faini

Guinevere - Jenny Dolfen
Waiting, Nerdanel - Marya Filatova
Ar-Pharazon and Tar-Miriel - Skullb*st*rd
Queen Tar-Miriel and the Great Wave - Ted Nasmith
White Ships from Valinor - Ted Nasmith
Numenorean Armor - Turner Mohan
Numenor, Aldarion & Erendis - David Greset
Numenor, Atlantis - Pete Amachree
Numenorean Armor, Color - Turner Mohan
Old Tree The Father - David Greset
Elros Looking West From Numenor - Anke Eissmann
Ar-Cyriatur - Tom Romain
Eldalonde - David Greset
Faramir and Child - Anke Eissmann
The White Tree - Aegeri
The White Tree - Ted Nasmith
Romenna - Matej Cadil
Romenna - David Greset
Ar-Pharazon - Steamey
The Destroying Wave Over Numenor - Kip Rasmussen
Numenor's Legion - Sam McKinnon
Ar-Pharazon - Turner Mohan
Waiting, Nerdanel - Marya Filatova
Ar-Pharazon - DracarysDrekkar7
Ar-Pharazon the Golden - Skullb*st*rd
Andreth - Marya Filatova
Waiting, Anaire - Marya Filatova
Ar-Pharazon in Armor - Skullb*st*rd
Andunie - David Greset
Sauron Surrenders to the Numenoreans - Alan Lee
Annatar Chained - Skullb*st*rd
Ar-Pharazon and the White Tree - Edvige Faini
Armenelos - Skullb*st*rd
Odin visits Volsung's Hall - Alan Lee
Ar-Pharazon - Clemence Morisseau
Eru Iluvatar - Janka Lateckova
Drowning of Andunie - John Howe
Downfall of Numenor - Dracarysdrekkar7
The Fall of Numenor - Darrell Sweet
Drowning of Numenor - MattLeese87
The Fall of Numenor - Alan Lee
The Destroying Wave Over Numenor - Kip Rasmussen
The Ships of the Faithful - Ted Nasmith
Out of the Sea I am Come - Turner Mohan
Elendil the Tall - Tolman Cotton

For more on Tar-Míriel, check out these great resources:
The Silmarillion
Unfinished Tales
The Peoples of Middle-earth
Tolkien Gateway
Encyclopedia of Arda

#tolkien #silmarillion #ringsofpower


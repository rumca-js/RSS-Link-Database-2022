## This 17-Year-Old Designed a Motor That Could Potentially Transform the Electric Car Industry | Innovation| Smithsonian Magazine
 - [https://www.smithsonianmag.com/innovation/this-17-year-old-designed-a-motor-that-could-potentially-transform-the-electric-car-industry-180980550/](https://www.smithsonianmag.com/innovation/this-17-year-old-designed-a-motor-that-could-potentially-transform-the-electric-car-industry-180980550/)
 - RSS feed: https://www.smithsonianmag.com
 - date published: 2022-08-12 10:08:23.849261+00:00

Robert Sansone's research could pave the way for the sustainable manufacturing of electric vehicles that do not require rare-earth magnets


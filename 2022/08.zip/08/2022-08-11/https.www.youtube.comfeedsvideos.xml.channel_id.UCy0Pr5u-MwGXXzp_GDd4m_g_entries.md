# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## How they come up with dreams
 - [https://www.youtube.com/watch?v=mycsFa898PQ](https://www.youtube.com/watch?v=mycsFa898PQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2022-08-11 00:00:00+00:00

Ever wonder how dreams are made? Answers here! Thank you to BetterHelp for sponsoring today's video. Get 10% off your first month here: https://BetterHelp.com/nolke

Written, performed and edited by: Julie Nolke
Camera: Sam Larson
Production Assistant: Jill Agopsowicz

Support the channel by liking and subscribing! 
Join my Patreon for behind the scenes videos and early access to videos here: https://www.patreon.com/julienolke


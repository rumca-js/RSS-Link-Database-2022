# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Spider-Man (PC) - Before You Buy
 - [https://www.youtube.com/watch?v=CHy9eNt_2Sg](https://www.youtube.com/watch?v=CHy9eNt_2Sg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-08-12 00:00:00+00:00

Sony and Insomniac's Spider-Man is now on PC (Steam, Epic). How is it? Let's talk!
Subscribe for more: http://youtube.com/gameranxtv ▼▼



Watch more 'Before You Buy': https://bit.ly/2kfdxI6

#spiderman #spidermanpc

## XBOX ACCUSES SONY, CLASSIC HORROR GAME RETURNS & MORE
 - [https://www.youtube.com/watch?v=uJCRv494eJw](https://www.youtube.com/watch?v=uJCRv494eJw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-08-12 00:00:00+00:00

Sponsored by Raycon. Go to https://buyraycon.com/gameranx for 15% off your order! Brought to you by Raycon.

Xbox talks about Sony impeding Game Pass, Nintendo details Splatoon 3, a new horror game is revealed, and MORE in a week full of gaming news.

Jake on Instagram: https://bit.ly/3uUh9Ot

Jake on twitter: https://bit.ly/3gdkPqD​​​​



 ~~~~STORIES~~~~


Xbox Sony
https://www.videogameschronicle.com/news/xbox-has-accused-sony-of-paying-developers-game-pass-block-fees/
+
https://www.videogameschronicle.com/news/microsoft-claims-it-wouldnt-be-profitable-to-make-call-of-duty-xbox-exclusive/

Deus Ex returns?
https://www.forbes.com/sites/paultassi/2022/08/06/new-deus-ex-wants-to-do-what-cyberpunk-2077-couldnt-says-report/?sh=e9549762fb40

Alone in the Dark leak
https://twitter.com/aestheticgamer1/status/1557997673038303232?s=21



Skyrim mod - Nemesis System (via Syclonix)
https://www.ign.com/articles/someone-added-shadow-of-mordors-nemesis-system-to-skyrim


Cult of the Lamb
https://youtu.be/1JPe32JQYro

Spider-Man PC
https://youtu.be/Tsf5Wjb1uAM

Platoon 3 Nintendo direct
https://youtu.be/aiuIZN0KDFQ

Midnight Suns delayed
https://www.polygon.com/23297371/marvels-midnight-suns-release-date-delay-take-two-firaxis

Hogwarts Legacy delayed
https://twitter.com/hogwartslegacy/status/1558121248814759939?s=21


New game from Subnautica devs
https://twitter.com/geoffkeighley/status/1557003768369143813?s=21Gamescom ONL tues AUG 23


Squirrel with a gun
https://youtu.be/HHYBiYbEz1E

## 10 LEGENDARY MISSIONS In Video Games We NEVER FORGOT
 - [https://www.youtube.com/watch?v=S2WHd7DtSd4](https://www.youtube.com/watch?v=S2WHd7DtSd4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-08-11 00:00:00+00:00

Some missions in games truly push things to the limit. Here are some unforgettable gaming mission moments.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:22 Number 10
1:51 Number 9
3:30 Number 8
5:11 Number 7
6:44 Number 6
8:22 Number 5
10:04 Number 4
11:34 Number 3
13:14 Number 2
14:30 Number 1


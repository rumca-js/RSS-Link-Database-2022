# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Horsegirl - Anti-glory (Live on KEXP)
 - [https://www.youtube.com/watch?v=qfkEK6MeD0U](https://www.youtube.com/watch?v=qfkEK6MeD0U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-12 00:00:00+00:00

http://KEXP.ORG presents Horsegirl performing “Anti-glory” live in the KEXP studio. Recorded July 16, 2022.

Nora Cheng - Guitar / Vocals
Penelope Lowenstein - Guitar / Vocals
Genevieve Reece - Drums

Host: Troy Nelson
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

https://horsegirlmusic.com
http://kexp.org

## Horsegirl - Ballroom Dance Scene (Live on KEXP)
 - [https://www.youtube.com/watch?v=NClkZI9QIlI](https://www.youtube.com/watch?v=NClkZI9QIlI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-12 00:00:00+00:00

http://KEXP.ORG presents Horsegirl performing “Ballroom Dance Scene” live in the KEXP studio. Recorded July 16, 2022.

Nora Cheng - Guitar / Vocals
Penelope Lowenstein - Guitar / Vocals
Genevieve Reece - Drums

Host: Troy Nelson
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

https://horsegirlmusic.com
http://kexp.org

## Horsegirl - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=4gj65udESGw](https://www.youtube.com/watch?v=4gj65udESGw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-12 00:00:00+00:00

http://KEXP.ORG presents Horsegirl performing live in the KEXP studio. Recorded July 16, 2022.

Songs:
World of Pots and Pans
Option 8
Ballroom Dance Scene
Anti-glory

Nora Cheng - Guitar / Vocals
Penelope Lowenstein - Guitar / Vocals
Genevieve Reece - Drums

Host: Troy Nelson
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

https://horsegirlmusic.com
http://kexp.org

## Horsegirl - Option 8 (Live on KEXP)
 - [https://www.youtube.com/watch?v=wgkYmDLD27k](https://www.youtube.com/watch?v=wgkYmDLD27k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-12 00:00:00+00:00

http://KEXP.ORG presents Horsegirl performing “Option 8” live in the KEXP studio. Recorded July 16, 2022.

Nora Cheng - Guitar / Vocals
Penelope Lowenstein - Guitar / Vocals
Genevieve Reece - Drums

Host: Troy Nelson
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

https://horsegirlmusic.com
http://kexp.org

## Horsegirl - World Of Pots And Pans (Live on KEXP)
 - [https://www.youtube.com/watch?v=lh6ojldXM1E](https://www.youtube.com/watch?v=lh6ojldXM1E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-12 00:00:00+00:00

http://KEXP.ORG presents Horsegirl performing “World Of Pots And Pans” live in the KEXP studio. Recorded July 16, 2022.

Nora Cheng - Guitar / Vocals
Penelope Lowenstein - Guitar / Vocals
Genevieve Reece - Drums

Host: Troy Nelson
Audio Engineer: Julian Martlew
Mastering: Ian Davidson
Cameras: Jim Beckmann, Carlos Cruz & Ettie Wahl
Editor: Jim Beckmann

https://horsegirlmusic.com
http://kexp.org

## Meatbodies - Cancer (Live on KEXP)
 - [https://www.youtube.com/watch?v=w34UpgkyuJs](https://www.youtube.com/watch?v=w34UpgkyuJs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-11 00:00:00+00:00

http://KEXP.ORG presents Meatbodies performing “Cancer” live in the KEXP studio. Recorded July 14, 2022.

Chad Ubovich - Guitar / Vocals
Casey Hansen - Guitar / Vocals
Noah Guevara - Bass
Dylan Fujioka - Drums / Vocals

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://www.instagram.com/meatbodiesofficialauthentic
http://kexp.org

## Meatbodies - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=yvyQ_sUddO0](https://www.youtube.com/watch?v=yvyQ_sUddO0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-11 00:00:00+00:00

http://KEXP.ORG presents Meatbodies performing live in the KEXP studio. Recorded July 14, 2022.

Songs:
Reach For The Sunn
Cancer
Night Time Hidden Faces
Let Go (333)

Chad Ubovich - Guitar / Vocals
Casey Hansen - Guitar / Vocals
Noah Guevara - Bass
Dylan Fujioka - Drums / Vocals

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://www.instagram.com/meatbodiesofficialauthentic
http://kexp.org

## Meatbodies - Night Time Hidden Faces / Let Go (333) (Live on KEXP)
 - [https://www.youtube.com/watch?v=_7WBH2UlPlI](https://www.youtube.com/watch?v=_7WBH2UlPlI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-11 00:00:00+00:00

http://KEXP.ORG presents Meatbodies performing “Night Time Hidden Faces" and "Let Go (333)” live in the KEXP studio. Recorded July 14, 2022.

Chad Ubovich - Guitar / Vocals
Casey Hansen - Guitar / Vocals
Noah Guevara - Bass
Dylan Fujioka - Drums / Vocals

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://www.instagram.com/meatbodiesofficialauthentic
http://kexp.org

## Meatbodies - Reach For The Sunn (Live on KEXP)
 - [https://www.youtube.com/watch?v=5us5B7Pczv8](https://www.youtube.com/watch?v=5us5B7Pczv8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-08-11 00:00:00+00:00

http://KEXP.ORG presents Meatbodies performing “Reach For The Sunn” live in the KEXP studio. Recorded July 14, 2022.

Chad Ubovich - Guitar / Vocals
Casey Hansen - Guitar / Vocals
Noah Guevara - Bass
Dylan Fujioka - Drums / Vocals

Host: Eva Walker
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Jim Beckmann

https://www.instagram.com/meatbodiesofficialauthentic
http://kexp.org


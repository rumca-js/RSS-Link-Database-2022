# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## From battlefields in Iraq to the Nashville music scene, how a Marine veteran is using art to heal
 - [https://www.cnn.com/2022/08/11/us/nashville-music-art-veterans-therapeutic-cnnheroes/index.html](https://www.cnn.com/2022/08/11/us/nashville-music-art-veterans-therapeutic-cnnheroes/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-08-11 22:51:02+00:00

Growing up, Richard Casper always knew he wanted to serve others. When he was a junior in high school, the 9/11 terrorist attacks happened, and he realized how he would fulfill that calling.


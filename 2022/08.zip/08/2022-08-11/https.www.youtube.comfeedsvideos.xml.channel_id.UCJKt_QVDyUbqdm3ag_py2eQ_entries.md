# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Traymuss - Illegal World (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=umKAlh00FRw](https://www.youtube.com/watch?v=umKAlh00FRw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-08-12 00:00:00+00:00

"Illegal World" by Traymuss (Remigiusz Trzcionka), 2nd at Breeze 2007. C64 art "Sunset at Sea" (2010?) by DocJM.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 32 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does XM: Karsten Koch - Astaris (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=yBQAM69zlq8](https://www.youtube.com/watch?v=yBQAM69zlq8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-08-11 00:00:00+00:00

"Astaris" (1997) by Karsten Koch. Art "Live Flame" (1993) by Axel D/Illusion.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 30 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.


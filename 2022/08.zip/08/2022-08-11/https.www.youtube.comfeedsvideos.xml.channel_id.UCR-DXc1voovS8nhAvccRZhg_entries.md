# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## I FINALLY had time to upgrade my PC
 - [https://www.youtube.com/watch?v=a3fJ5WlZ1TQ](https://www.youtube.com/watch?v=a3fJ5WlZ1TQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2022-08-12 00:00:00+00:00

The Prednisone kicked in and I'm feeling a little bit better, so I finally upgraded my PC so I can record Pi and server footage through a capture card!

I'll also talk about another major upgrade I made, and give a shout out to all my viewers, my Wife, and my Mom, who all helped me get through a very challenging couple of weeks!

Noctua sent me the NH-U12A cooler for review a few months ago. I paid for everything else you see in this video.

  - AVerMedia GC573 Live Gamer 4K Capture Card: https://amzn.to/3w147BG
  - Noctua NH-U12A chromax.Black CPU Cooler: https://amzn.to/3C3Nut1
  - AMD Ryzen 5 5600x CPU: https://amzn.to/3QHuCnO
  - DeskPi Super6C Pi Cluster Board: https://deskpi.com/collections/deskpi-super6c

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Merch: https://redshirtjeff.com
2nd Channel: https://www.youtube.com/c/GeerlingEngineering

#Noctua #AVerMedia #Upgrade

Contents:

00:00 - Three things
00:56 - Massive CPU Cooler upgrade
02:34 - AVerMedia 4K capture card install
05:28 - Testing out the upgrade
08:01 - Thank you!


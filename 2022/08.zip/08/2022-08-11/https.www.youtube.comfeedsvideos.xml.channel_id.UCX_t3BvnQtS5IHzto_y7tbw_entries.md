# Source:Coreteks, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCX_t3BvnQtS5IHzto_y7tbw, language:en-US

## How NVIDIA missed the AMD KRAKEN
 - [https://www.youtube.com/watch?v=1GvUdPn5QLg](https://www.youtube.com/watch?v=1GvUdPn5QLg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCX_t3BvnQtS5IHzto_y7tbw
 - date published: 2022-08-11 00:09:37+00:00

20% coupon code: C30
win11 professional 1pc : https://www.ucdkeys.com/product/windows-11-pro-cd-key-global/
Office2021 Professional Plus CD Key:https://www.ucdkeys.com/product/office2021-professional-plus-cd-key-global/
Windows11Pro+Office2021Pro Global Bundle: https://www.ucdkeys.com/product/windows-11-pro-office-2021-pro-key-global-bundle/
Windows 11 Home CD KEY GLOBAL ：https://www.ucdkeys.com/product/windows-11-home-cd-key-global/
office 19 pp：https://www.ucdkeys.com/office-2019-Professional-Plus-CD-Key-Global
win10 pro：https://www.ucdkeys.com/Windows-10-Pro-1-License-KEY-GLOBAL
365 account: https://www.ucdkeys.com/Office-365-Pro-Plus-2019-Lifetime-Account-5-Pc-5-Mac-5TB-Fast-Delivery-Office-365-Pro-Plus-5-Edition-Account

Support me on Patreon: https://www.patreon.com/coreteks

Buy a mug: https://teespring.com/stores/coreteks
Bookmark: https://coreteks.tech

My channel on Odysee: https://odysee.com/@coreteks

I now stream at:​​
https://www.twitch.tv/coreteks_youtube

Follow me on Twitter: https://twitter.com/coreteks
And Instagram: https://www.instagram.com/hellocoreteks

Footage from various sources including official youtube channels from AMD, Intel, NVidia, Samsung, etc, as well as other creators are used for educational purposes, in a transformative manner. If you'd like to be credited please contact me

#nvidia #rtx4090 #amd


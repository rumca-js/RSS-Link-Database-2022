# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Why This Tree Is Like a Salmon
 - [https://www.youtube.com/watch?v=qxZ16zVQ6JM](https://www.youtube.com/watch?v=qxZ16zVQ6JM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-08-11 00:00:00+00:00

Not all trees will yield a bountiful harvest every year. These trees will only do it once in their whole lifetime.

Hosted by: Stefan Chin

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Matt Curls, Alisa Sherbow, Dr. Melvin Sanicas, Harrison Mills, Adam Brainard, Chris Peters, charles george, Piya Shedden, Alex Hackman, Christopher R, Boucher, Jeffrey Mckishen, Ash, Silas Emrys, Eric Jensen, Kevin Bealer, Jason A Saslow, Tom Mosner, Tomás Lagos González, Jacob, Christoph Schwanke, Sam Lutfi, Bryan Cloer
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow #science #education
----------
Sources:
https://besjournals.onlinelibrary.wiley.com/doi/10.1111/j.1365-2745.2005.00958.x
https://www.nature.com/articles/6883530#further-reading
https://www.researchgate.net/publication/49753026_Ecology_and_evolution_of_long-lived_semelparous_plants
https://esajournals.onlinelibrary.wiley.com/doi/abs/10.2307/2937114
https://esajournals.onlinelibrary.wiley.com/doi/abs/10.1890/0012-9658(2006)87[2755:APFRIM]2.0.CO;2 
https://www.ncbi.nlm.nih.gov/books/NBK214876/  

Image Sources:
https://www.gettyimages.com/detail/video/leaf-in-forest-with-sunshine-stock-footage/1316762996 
https://www.gettyimages.com/detail/video/apple-trees-in-the-orchard-in-4k-stock-footage/1317397312 
https://www.gettyimages.com/detail/video/rich-green-leaves-of-a-tree-waving-in-wind-the-sun-stock-footage/1337197013 
https://www.gettyimages.com/detail/video/the-sun-casts-its-beautiful-rays-into-the-fresh-green-stock-footage/1168431157 
https://www.gettyimages.com/detail/photo/sparkling-salmon-royalty-free-image/1355486698 
https://www.inaturalist.org/observations/56704408
https://www.gettyimages.com/detail/video/dark-thick-cypress-tree-forest-covered-in-spanish-moss-stock-footage/1089931554 
https://www.gettyimages.com/detail/video/giant-sequoia-trees-in-kings-canyon-national-park-stock-footage/1338565287 
https://www.gettyimages.com/detail/video/plum-flower-blooming-against-blue-background-in-a-time-stock-footage/1142846357 
https://www.gettyimages.com/detail/video/close-up-footage-of-yellow-seabuckthorn-during-autumn-stock-footage/1286585453 
https://www.gettyimages.com/detail/video/howler-monkey-stock-footage/1305120088 
https://www.gettyimages.com/detail/video/close-up-at-red-ants-walking-on-the-ground-working-stock-footage/1394378905 
https://www.gettyimages.com/detail/video/video-footage-of-the-cicadas-buzzing-hard-stock-footage/1311276419 
https://www.gettyimages.com/detail/video/poplar-fluff-falls-from-a-tree-against-the-backdrop-of-stock-footage/1347674885 
https://commons.wikimedia.org/wiki/File:Flickr_-_Jo%C3%A3o_de_Deus_Medeiros_-_Tachigali_subvelutina_(1).jpg
https://www.gettyimages.com/detail/video/beautiful-summer-morning-in-the-forest-sun-rays-break-stock-footage/1253263447 
https://www.gettyimages.com/detail/video/blooming-popplar-trees-stock-footage/960068786 
https://www.gettyimages.com/detail/video/aerial-top-view-of-rainforest-and-wind-stock-footage/1171740209 
https://www.gettyimages.com/detail/video/wood-texture-dolly-shot-stock-footage/1319225641 
https://www.gettyimages.com/detail/video/several-pink-or-red-salmon-swimming-up-stream-stock-footage/1334365136


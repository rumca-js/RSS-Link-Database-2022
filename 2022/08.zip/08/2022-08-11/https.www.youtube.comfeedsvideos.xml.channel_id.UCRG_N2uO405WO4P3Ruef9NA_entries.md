# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## OnePlus & OPPO officially got banned
 - [https://www.youtube.com/watch?v=hHV6-JamISQ](https://www.youtube.com/watch?v=hHV6-JamISQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-08-12 00:00:00+00:00

Sponsored by Morning Brew. Sign up for free today: https://morningbrewdaily.com/fridaycheckout

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This week a lack of competition hurt the foldable phone market, with Samsung releasing a lazy update to the Galaxy Flip 4 and Fold 4, OPPO and OnePlus got banned in Germany by Nokia, and India might ban Chinese phones under $150 as well.

Episode 109

This video on Nebula: https://nebula.app/videos/the-friday-checkout-oneplus-oppo-officially-got-banned

Kilian's hands-on with the Flip 4 and Fold 4: https://www.youtube.com/watch?v=Ovi9Ptggozc

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► TechAltar links ◄◄◄  
 
Merch:  
http://enthusiast.store   
 
Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  
 
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 
►►► Attributions & Time stamps◄◄◄
 
Writing & Research: Tristan Rayner
Music by Edemski: https://soundcloud.com/edemski 
 
0:00 Intro
0:24 Release highlights
2:13 Foldable madness
5:04 OnePlus & OPPO ban
7:04 India bans Chinese phones?


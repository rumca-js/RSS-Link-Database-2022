# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## The shape that changed our world forever
 - [https://www.youtube.com/watch?v=4iY8JqHN-kI](https://www.youtube.com/watch?v=4iY8JqHN-kI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2022-08-11 00:00:00+00:00

Retroreflection just might be the coolest thing ever!
Thanks to 3M for sponsoring this episode and letting me explore their facility & technology https://bit.ly/ASAPx3M

Join our science mailing list: https://bit.ly/34fWU27

FOLLOW US!
Instagram: https://instagram.com/asapscience​​
Facebook: https://facebook.com/asapscience​​
Twitter: https://twitter.com/asapscience​​
TikTok: @AsapSCIENCE 

Written by: Mitchell Moffit 
Edited by: Luka Šarlija


# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Symptomatic covid plummets
 - [https://www.youtube.com/watch?v=rU_jvsRa5YA](https://www.youtube.com/watch?v=rU_jvsRa5YA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-08-12 00:00:00+00:00

Covid infections plummet

Link to report from Uganda,

https://www.youtube.com/watch?v=MOBlGKQd6pU&t=73s

Covid infections plummet

https://www.youtube.com/watch?v=yYH8l9f9eo4

R = 0.8

Cases, + 120,946

Prevalence, 2,232,757 

Down, all age groups, all UK regions

Past 2 weeks, down 46%

Prevalence, 1 in 26, down from 1 in 16

https://health-study.joinzoe.com/data

UK official data

https://coronavirus.data.gov.uk

Case numbers, irrelevant (down 23.7% on the week)

Hospital admissions, 6,697 over past week

(Down 14.9% on the week)

Deaths, 827 over past week (deaths within 28 days of a positive test)

(Down 22.9% on the week)

List of covid (mostly BA.5) symptoms

Sore throat, 57%

Headache, 47%

Cough, no phlegm 41%

Blocked nose, 37%

Runny nose, 36%

Cough with phlegm, 35%

Hoarse, 34%

Sneezing, 28%

Fatigue, 28%

Muscle pains 25%

Dizzy, 18%

Swollen neck glands, 14%

Fever, 13%

Altered smell, 13%

Sore eyes, 13%

Chest pain / tightness, 11%

Hot flushes, 11%

Chills or shivers, 10%

Loss of smell, 9%

Some get recurrence of symptoms a few weeks after the initial symptoms

United states, covid

https://www.cdc.gov/coronavirus/2019-ncov/covid-data/covidview/index.html

Daily new cases 103,614

(Down 13.8% on the week)

Wastewater Surveillance

SARS-CoV-2 viral RNA in wastewater

Over 1,000 testing sites

Most of the country, moderate to high levels

About half of sites reporting

Currently seeing some of the highest levels since December 1, 2021

Sites reporting an increase, 41%

Variant nowcast

https://covid.cdc.gov/covid-data-tracker/#variant-proportions

BA.5  88.8%

BA.4  5.3%

BA.4.6  5.1%

BA.2.12.1  0.8%

BA.2  0%

BA.1s  0%

Delta  0%

Others  0%

BA.2.75  not listed

New Hospital Admissions, daily average 6,003

(Down 2.6% on the week)

Deaths

The current 7-day daily average, 400

(Down 6.7% on the week)

Official death number

1,030,777

Poliomyelitis, New York, D of H

https://www.health.ny.gov/press/releases/2022/2022-08-04_polio_detected_nys.htm

Polio, early June wastewater samples

Seven positive samples (Rockland and Orange County) genetically linked to case of paralytic polio in Rockland County

Transmission of a polio virus that can cause paralysis and potential community spread,

underscoring the urgency of every New York adult and child getting immunized, 

especially those in the greater New York metropolitan area.


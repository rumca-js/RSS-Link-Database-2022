# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## I Can’t Believe He Just DID THIS
 - [https://www.youtube.com/watch?v=B15zpf_6T4c](https://www.youtube.com/watch?v=B15zpf_6T4c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-08-12 00:00:00+00:00

As Justin Trudeau now joins the Netherlands, Germany and Sri Lanka in making applying pressure to farmers over emissions, do politicians and their rich friends they give tax cuts to follow the same climate goals? 
#justintrudeau #canada #farmersprotest #climatechange 

References
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## THE GREAT RESET IS REAL!
 - [https://www.youtube.com/watch?v=bv4FlhIHt5g](https://www.youtube.com/watch?v=bv4FlhIHt5g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-08-11 00:00:00+00:00

The financial crash in 2008 was real or was it part of the Great Reset… that’s just another conspiracy theory! I spoke with journalist Matt Taibbi about how he spotted rage in people following the crash in 2008 during the Obama years and how Trump capitalized on that by feeling the audience. “When he saw vets in the crowd, he would say we have to do something about these endless wars, because they're not getting us anywhere.” #obama #thegreatreset #WEF
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:Technology Connections, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0tKL1T7wFoYcxCe0xjN6Q, language:en-US

## Drip Coffee Makers — super simple, super cheap
 - [https://www.youtube.com/watch?v=Sp9H0MO-qS8](https://www.youtube.com/watch?v=Sp9H0MO-qS8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0tKL1T7wFoYcxCe0xjN6Q
 - date published: 2022-08-11 13:25:55+00:00

Gather 'round the fire with some delicious cups of hot brown as I tell you the story of American hot brown.

The Engineer Guy's video on the coffee maker's Bubble Pump
https://www.youtube.com/watch?v=4j4Q_YBRJEI

My percolator video
https://youtu.be/E9avjD9ugXc

The infamous Kettle video (which I have a feeling inspired the even more infamous New York Times article...)
https://youtu.be/_yMMTVVJI4c

Technology Connections on Twitter:
https://twitter.com/TechConnectify
The TC Subreddit
https://www.reddit.com/r/technologyconnections

This channel is supported through viewer contributions on Patreon. Thanks to the generous support of people like you, Technology Connections has remained independent and possible. If you'd like to join the amazing people who've pledged their support, check out the link below. Thank you for your consideration!
https://www.patreon.com/technologyconnections

Oh, and look at these wonderful patrons!
Bob D'Errico, Bill Wert, Brian Lalonde, John Kuras, Alabammy Skwirl, Joshua Shearer, Justin Ward, Marco Eberhard, Benjamin Mitchell, VerySerious, TecknicGamer, ARadioGurl, Jonathan Reilly, Schuyler Thompson, Nick Evans, Vojtech Trefny, Ben Maron, Nick Dawson, Morerandom, Kendric Evans, Dean Gallea, Christian Löwel, Sathale, Scott Stokes, Eric Shalosky, Krzysztof Parzyszek, Connor Nicholson, רועי סיני, Dan ''Spiffy'' Neuman, Justin Voss, Richard Ertel, Eric Bridgeford, Andrew Swab, Tibor Kovács, Lori Reeder, Colm Byrne, Hector Martin, Xyon of Calhoun, William Hilton, Matt Barber, Brian Zimmerman, Clinton Peterson, Kenneth Garrett, Phil Roberts, Rob C, Hannah Ward, Tiziano Santoro, Aubron Wood, Tyler Nichols, Eric Wood, Christian Pionke, Zach, Andreas G, Trevers Astheimer, Tommy D, Russell Peto, Bruce Petty, Myles Johnson, Eric Barch, Carlo B, Tim Turner, Scott Reynolds, augs, Random Jones, thoughtdreams, Hexapuma, Ryan McQuillen, Jordan Byron, Christy Ramsey, Nick Wharff, Harrison Diamond, Pat Stahl, Natalie Cummins, PAC, Eelke, Jason White, Anthony Gargiulo, Tommy Hetrick, Zach Hartman, Paul Stoetzer, Austin Crawford, Microwaive, Andrew Conner, Keith Burzinski, Owen Lane, Anton Markov, KH, Peter Hing, Kyle Cuzzort, Ross Vegas, Donovan Smith, Robert Bouchoux, Wes Brown, Matt Wright, John Kelley, Nathan M, Christopher Meszaros, Ryan, Michael Latham, Scott Kemp, Luke Hess, Dipak Patel, Pablo Fernández, Evan Minsk, Matt Tatum, nsqueen119, Devin Swenson, Eric Christensen, Torstein , Gareth Molyneux, Alan Nash, Ricky Munroe, Kenneth M Lorthioir Jr., Michael Goulding, Doug Johnson Productions, Camron H., Abdiel Salazar, Joe Mitchell, Wayno Guerrini, Olav , Dennis Schubert, Richard Clayton, dee, Roy Hines, Olle Kelderman, Michel van den Brink, Leah & Tyler Moser, Thomas Winget, Joshua Doades, Anthony Brownmoore, Duncan Brown, Kelsair, Robert Thurston, Christopher Osborn, Haruka Takahashi, Chris Lomond, chylex , John Lee, Ryan Everett, Archjelly, Lixun Chen, KodiTheFox, Michael Haugaard, Eric Hoch, Bob Cross, Salanth , Michael Gregg, Ryan Helinski, Joshua T Corbin, Robert Sanges, Robert L. O'Hagan, Zachary Wander, Stefan, Jason and Gena, Michael Kobb, Ryan Tranchilla, Narien, Adrian's Digital Basement, John Weeks, lego_met, Adam Ruth, Tom Seago

00:00 Intro
01:05 Kettles are Confusing
02:20 Why kettles don't make our coffee
04:51 Introducing Mr. Coffee
08:12 Exploring a vintage Mr. Coffee machine
10:57 Brewing Temperature and Control
16:19 Modern design and theory of operation
21:25 Speed comparison and taste test
23:20 Coffee Saver feature test
26:37 The cost-saving hot plate
28:59 These things are stinkin' cheap
30:21 Coffee Pragmatism
31:21 Some advice for cheap drip brewers
32:08 More Pragmatism and the Flavor to Effort Ratio
33:23 The drip brewer's reliability weakness
34:27 Conclusion
35:22 Bloopers


# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## The Power Of Love - Huey Lewis (New Orleans Blues Cover) ft. Sarah Potenza
 - [https://www.youtube.com/watch?v=roh7bM3QAXc](https://www.youtube.com/watch?v=roh7bM3QAXc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2022-08-11 16:00:58+00:00

PMJ's Huey Lewis cover of "The Power Of Love" (New Orleans Blues style) ft. Sarah Potenza.
Get this song: http://pmjlive.com/thepoweroflove. | Live Show Tix: http://pmjtour.com 
Subscribe: http://bit.ly/subPMJ | Stream PMJ Radio on Spotify: http://smarturl.it/pmjcomplete |

Modern-day Nashville blues belter and songwriter Sarah Potenza makes her powerful PMJ debut! This 1920s New Orleans-style remake of the definitive soundtrack for skateboarding to school after assisting in time travel experimentation: "The Power Of Love" by Huey Lewis and The News.

See Postmodern Jukebox LIVE! Tickets On Sale NOW for the US/Canada, UK, Europe, Australia/NZ, Asia — find over 100 dates on sale here: http://smarturl.it/tourpmjyt

Follow Postmodern Jukebox:
Facebook: https://facebook.com/postmodernjukebox
Instagram: https://instagram.com/pmjofficial/
Twitter: https://twitter.com/pmjofficial

Watch More Postmodern Jukebox:
Newest Videos: https://youtube.com/playlist?list=PL7A4D9C100657150E&amp;playnext=1&amp;index=2
Popular Videos: https://youtube.com/playlist?list=PLJZH8sevmMq5rnnzsmkbteoFOWCdBx24u&amp;playnext=1&amp;index=2
Watch by Genre: https://youtube.com/user/ScottBradleeLovesYa/playlists?shelf_id=217&amp;sort=dd&amp;view=50
Watch by Decade: https://youtube.com/user/ScottBradleeLovesYa/playlists?sort=dd&amp;shelf_id=218&amp;view=50
Watch by Mood: https://youtube.com/user/ScottBradleeLovesYa/playlists?sort=dd&amp;shelf_id=219&amp;view=50

Listen to Postmodern Jukebox on:
iTunes: http://bit.ly/itunesPMJ
Spotify: http://bit.ly/spotifyPMJ
Google Play: http://bit.ly/googlePMJ
____________________________________________

Follow The Musicians:
SARAH POTENZA (Vocals)
YouTube: https://youtube.com/c/SarahPotenzaMusic
Instagram: https://instagram.com/iamsarahpotenza/
Facebook: https://facebook.com/sarahpotenzamusic
Twitter: https://twitter.com/sarahpotenza
TikTok: https://tiktok.com/@sarahpotenzamusic
Website: https://sarahpotenza.net
Spotify: https://open.spotify.com/artist/4o3TLYc44160Nc57XrTZrd?si=xdGso284RkOqVjETEooyIw

ANTHONY CASTAGNA (Banjo)
Facebook: https://facebook.com/BoogieWoogieCastagna
Instagram: https://instagram.com/anthonycastagna88

JARED MANZO (Upright Bass)
Facebook: https://facebook.com/jared.manzo
Instagram: https://instagram.com/jaredmanzo

JASPER TWIGG (Drums):
Facebook: https://facebook.com/jasper.twigg
Instagram: https://instagram.com/jay_twiggles/?hl=en

CASEY BREFKA (Trumpet):
Facebook:https://facebook.com/casey.brefka
Instagram:https://instagram.com/caseybrefkamusic/?hl=en
Twitter: https://twitter.com/caseybrefkatpt
http://www.caseybrefka.com/

ROLAND BARBER (Trombone)
Facebook: https://facebook.com/RolandJBarber

JACOB SCESNEY (Clarinet)
Facebook: https://facebook.com/Sceswho
Twitter: https://twitter.com/jsaysknee

Scott Bradlee (Piano)
YouTube: http://youtube.com/scottbradlee
http://scottbradlee.substack.com
Arrangement by: Scott Bradlee
Audio Engineer: Thai Long  
Videography: Andrew Rozario & Mike Stryker 
Styling by: Jon Steinick
____________________________________________

More Links:
LIVE tickets to PMJ : http://smarturl.it/tourpmjyt
Official PMJ Website: http://smarturl.it/pmjwebyt 
Join the PMJ Inner circle! New Videos, Tour Dates & More: http://smarturl.it/pmjsignupyt 
Shop our Vintage Swag: http://smarturl.it/shoppmjyt

#HueyLewis #ThePowerOfLove #Cover


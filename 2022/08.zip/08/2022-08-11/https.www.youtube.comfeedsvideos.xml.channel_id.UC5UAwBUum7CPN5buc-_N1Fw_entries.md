# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## More NVIDIA OPEN SOURCE, Cutefish is ALIVE, and Duck Duck Go fixes tracking: Linux + opensource news
 - [https://www.youtube.com/watch?v=DMiD2guxKpA](https://www.youtube.com/watch?v=DMiD2guxKpA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-08-11 00:00:00+00:00

Get 100$ credit for your own Linux and gaming server: https://www.linode.com/linuxexperiment 

Grab a brand new laptop or desktop running Linux:https://www.tuxedocomputers.com/


👏 SUPPORT THE CHANNEL:
Get access to a weekly podcast, vote on the next topics I cover, and get your name in the credits:

YouTube: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join
Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

📹 MORE VIDEOS FROM ME
Linux news in Shorts format: https://www.youtube.com/channel/UCtZp0mK9IBrpS2-jNzMZmoA
Gaming on Linux: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw
I'm also on ODYSEE: https://odysee.com/$/invite/@TheLinuxExperiment:e

🏆 FOLLOW ME ELSEWHERE:
Twitter : http://twitter.com/thelinuxEXP
Mastodon: https://mastodon.social/web/@thelinuxEXP
Pixelfed: https://pixelfed.social/TLENick
Discord: https://discord.gg/xK7ukavWmQ

📷 GEAR I USE:
Sony Alpha A6600 Mirrorless Camera: https://amzn.to/30zKyn7
Sigma 56mm Fixed Prime Lens: https://amzn.to/3aRvK5l
Logitech MX Master 3 Mouse: https://amzn.to/3BVI0Od
Bluetooth Space Grey Mac Keyboard: https://amzn.to/3jcJETZ
Logitech Brio 4K Webcam: https://amzn.to/3jgeTh9
LG Curved Ultrawide Monitor: https://amzn.to/3pcTVDH
Logitech White Speakers: https://amzn.to/3n6wSb0
Xbox Controller: https://amzn.to/3BWmIA3
*Amazon Links are affiliate codes and generate small commissions to support the channel*

This video is distributed under the Creative Commons Share Alike license.

#linux #news #opensource

00:00 Intro
00:46 Sponsor: 100$ credit for your own Linux or Gaming server
01:39 Gitlab backs down on inactive projects removal policy
02:54 Nvidia open sources massive parts of their GPU documentation
04:17 Dolphin might finally get graphical root access
05:33 Microsoft prevents Tutanota users from signing up for Teams
07:10 Cutefish might still be alive after all
08:21 GNOME improves the shell performance, + weekly updates
09:40 KDE weekly updates
11:04 Duck Duck Go will now also block Microsoft trackers
12:19 DreamWorks open sources their renderer, MoonRay
13:13 Steam Deck goes to Asia, Proton 7.0-4, and 4500 games certified
14:36 Sponsor: Get a device that supports Linux, from Tuxedo
15:44 Support the channel

GitLab backtracks on its plan to remove inactive projects

https://www.theregister.com/2022/08/04/gitlab_data_retention_policy/

https://news.itsfoss.com/gitlab-inactive-projects-policy/

Nvidia open sources 73 000 lines of GPU documentation

https://www.phoronix.com/news/NVIDIA-3D-Headers-Fermi-Ampere

Dolphin might finally get graphical root access

https://apachelog.wordpress.com/2022/08/04/kio-admin/

Microsoft takes 1.5 years to even look at an issue affecting Tutanota users on Teams

https://techcrunch.com/2022/08/04/tutanota-cries-antitrust-foul-over-microsoft-teams-blocking-sign-ups-for-its-email-users

The Cutefish project is seeing some more work done after everyone though it was dead

https://thenewstack.io/the-mysterious-disappearance-and-possible-return-of-cutefishos/

GNOME improves the performance of GNOME Shell, and updates their apps

https://thisweek.gnome.org/posts/2022/08/twig-55/

KDE developers fix a ton of bugs, and update the experience again

https://pointieststick.com/2022/08/05/this-week-in-kde-easier-samba-sharing-setup/

Duck Duck Go finally will block Microsoft trackers, except ad-related ones

https://www.theverge.com/2022/8/5/23292280/duckduckgo-microsoft-third-party-ad-tracker-script-blocking

DreamWorks open sources their 3D renderer, called MoonRay

https://www.engadget.com/dreamworks-animation-open-source-moonray-renderer-191328980.html

The Steam Deck is now in Asia, passes 4500 games certified, and Proton 7.0-4 beta looks like a big update

https://www.gamingonlinux.com/2022/08/steam-deck-hits-4500-games-officially-verified-or-playable/

https://www.gamingonlinux.com/2022/08/proton-70-4-is-coming-to-bring-more-compatibility-to-linux-and-steam-deck/

https://www.shacknews.com/article/131695/steam-deck-asia-japan-korea-tokyo-game-show


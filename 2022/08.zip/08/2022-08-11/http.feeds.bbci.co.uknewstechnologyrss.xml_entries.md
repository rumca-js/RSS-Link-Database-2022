# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## High and low-tech ways to tackle India's water crisis
 - [https://www.bbc.co.uk/news/business-61965419?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-61965419?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-08-11 23:02:54+00:00

India's water situation requires a big investment in tech and many small projects on the ground.

## NHS IT supplier held to ransom by hackers
 - [https://www.bbc.co.uk/news/technology-62506039?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62506039?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-08-11 12:28:38+00:00

Its IT provider says it may take three or four weeks to fully recover from the cyber-attack.

## Disney adds subscribers but warns over cricket loss
 - [https://www.bbc.co.uk/news/business-62500520?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62500520?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-08-11 06:53:34+00:00

The media giant is gaining subscribers as it details plans to launch an ad-supported service in December.

## Meta's chatbot says the company 'exploits people'
 - [https://www.bbc.co.uk/news/technology-62497674?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62497674?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-08-11 00:50:51+00:00

The new prototype doesn't think much of the company's CEO, Mark Zuckerberg, either.


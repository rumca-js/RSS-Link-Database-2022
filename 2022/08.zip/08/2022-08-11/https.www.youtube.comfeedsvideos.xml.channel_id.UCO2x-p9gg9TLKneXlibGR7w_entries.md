# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## The Definitive M2 MacBook Air Review
 - [https://www.youtube.com/watch?v=oCtYBqcN7QE](https://www.youtube.com/watch?v=oCtYBqcN7QE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2022-08-12 00:00:00+00:00

It’s been nearly a month since the M2 MacBook Air launched and we’ve spent hours putting it through its paces. Is it all it’s cracked up to be?
Get 15% off your first CUTS order at https://cuts.team/snazzy or use code ‘SNAZZY’ at checkout!

Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

The M2 MacBook Air launched to a lot of dramatic hullabaloo—reports of thermal throttling and a slow SSD were just a few of the controversies that befell the redesigned fan-favorite. We’ve found some of the complaints to be credible, many to be false, and generally find ourselves in love with this little machine. But there’s one problem… the price.


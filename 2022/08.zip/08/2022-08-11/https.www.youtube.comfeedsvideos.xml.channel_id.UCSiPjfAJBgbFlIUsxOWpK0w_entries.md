# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Afternoon Tea // Gardenview // Nataly Dawn (of Pomplamoose)
 - [https://www.youtube.com/watch?v=RKUdd-BOqoE](https://www.youtube.com/watch?v=RKUdd-BOqoE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-08-11 00:00:00+00:00

Afternoon Tea is me channeling Paul McCartney the best I can. Vinyl for “Gardenview” has finally arrived!!! We only pressed a couple hundred, just in time for TOUR :D Vinyl and tickets at http://NatalyDawnMusic.com Merci et beaucoup de bisous!

Save this song on Spotify: https://sptfy.com/gardenview
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

"Afternoon Tea" is an original song by Nataly Dawn

MUSICIAN CREDITS
Vocals/Guitar: Nataly Dawn
Guitar:  John Schroeder
Bass: Eliana Athayde
Drums: Julian Rodriguez
Keys/Vibraphone: Ross Garren

AUDIO CREDITS
Playback Engineer: Jimmy Dixon
Recording Engineer/Mix: Caleb Parker
Master: Will Borza
Producers: John Schroeder & Ross Garren

VIDEO CREDITS
Director: Dom Fera
DP: Austin Hughes
Camera Operator: Riley Donavan
Gaffer: Nash White
Production Designer: Katie Theel 
Video Editor/Colorist: Dominic Mercurio

Recorded at 64 Sound & KingSized Soundlabs in Los Angeles.

LYRICS
Oh glorious afternoon tea
You pull me out of the ground
You turn my shadow around
To la-di-da-di-da-di-dee

Oh glorious silver-blue sky
Heaven is still taking calls
Nothing the rain can’t resolve
To la-di-da-di-da-di-dee

Hallelu
Hats off to you
If you’re making it through

Oh glorious telephone ring
Bring me a friendly hello
Tell me a story I already know
To la-di-da-di-da-di-dee

Hallelu
Hats off to you
If you’re makin’ it through

Oh glorious afternoon tea
How do you part the dead sea
Where is the glory in me
Is there any glory in me
Everywhere glory
To la-di-da-di-da-di-dee


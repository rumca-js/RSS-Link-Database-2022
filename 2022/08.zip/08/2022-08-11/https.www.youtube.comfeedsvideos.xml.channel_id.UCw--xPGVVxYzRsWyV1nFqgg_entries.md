# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Rings of Power "Ghosts" Peter Jackson?👻 New WoT Edition📖 Prey Breaks Hulu Record👽 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=nyH17t-kztg](https://www.youtube.com/watch?v=nyH17t-kztg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-08-12 00:00:00+00:00

Let's jump into the Fantasy News! 
Check out the Campfire today: https://www.campfirewriting.com/write/for-novelists?utm_source=youtube&utm_medium=video&utm_campaign=DG_Q3_22 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

NEWS: 

00:00 intro

01:02 Rings of Power Jackson debacle: https://www.hollywoodreporter.com/tv/tv-news/peter-jackson-amazon-lord-of-the-rings-tv-series-1235193692/ 

05:08 Cosmere Figures: https://www.brotherwisegames.com/stormlight-miniatures 

05:45 Prey’s Success: https://variety.com/2022/digital/news/hulu-prey-biggest-premiere-ever-1235337279/ 

07:00 Arcane Animation Test: https://www.youtube.com/watch?v=RHElv9Kk9gY&ab_channel=LeagueofLegends 

07:55 The Sandman season 2: https://twitter.com/IGN/status/1557702372599599104

08:33 New Wheel of Time Companion: https://twitter.com/binding_broken/status/1556701790061662209

## SANDMAN: REVIEW ~ Success with Failures
 - [https://www.youtube.com/watch?v=_JI1n4QVnUE](https://www.youtube.com/watch?v=_JI1n4QVnUE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-08-12 00:00:00+00:00

Kayla and I sit down to talk about the recent #Sandman show! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## End Of Lost Children Arc - Berserk Vol. 15 [Part 2] & Vol. 16 [Part 1]
 - [https://www.youtube.com/watch?v=SRUvfAldkIo](https://www.youtube.com/watch?v=SRUvfAldkIo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-08-11 00:00:00+00:00

Today we wrapped up #berserk's Lost Children Story! 
This video covers Berserk Deluxe Edition 5 - Vol. 15 [Part 2] and Vol. 16 [Part 1], which includes chapters:
"The Recollected Girl", "The World of Winged Things", "Guardians 1-2", "The Pursuers", "The Misty Valley 1-2", and "Cocoons" as well as "Monster", "Sky Demon", "A Bloody Night Sky", "The Space Between Demon and Man", "Firefly", "The Way Home", "Blue Sky Elf", and "The Beast of Darkness". 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


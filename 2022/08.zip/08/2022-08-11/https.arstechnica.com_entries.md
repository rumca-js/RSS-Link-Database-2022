## Man who built ISP instead of paying Comcast $50K expands to hundreds of homes | Ars Technica
 - [https://arstechnica.com/tech-policy/2022/08/man-who-built-isp-instead-of-paying-comcast-50k-expands-to-hundreds-of-homes/](https://arstechnica.com/tech-policy/2022/08/man-who-built-isp-instead-of-paying-comcast-50k-expands-to-hundreds-of-homes/)
 - RSS feed: https://arstechnica.com
 - date published: 2022-08-11 08:20:49.126928+00:00

Jared Mauch gets $2.6 million from gov't to expand fiber ISP in rural Michigan.


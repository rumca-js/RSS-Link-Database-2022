# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Rings of Power Images & Art, New Tolkien Calendar, & NOTR now in Spanish!
 - [https://www.youtube.com/watch?v=_rQPV9dMu5o](https://www.youtube.com/watch?v=_rQPV9dMu5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-08-11 00:00:00+00:00

New Tolkien Calendar 2023: https://amzn.to/3QzR0iM

Nerd of the Rings Español (Nerd de los Anillos): https://www.youtube.com/channel/UCmMs2gC2jJIeP22SdFaqcbg

#lordoftherings #ringsofpower #theringsofpower


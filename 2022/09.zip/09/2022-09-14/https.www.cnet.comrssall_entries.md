# Source:CNET, URL:https://www.cnet.com/rss/all/, language:en-US

## The Ethereum Merge is Imminent. Here's Why It Matters     - CNET
 - [https://www.cnet.com/personal-finance/crypto/the-ethereum-merge-is-imminent-heres-why-it-matters/#ftag=CADf328eec](https://www.cnet.com/personal-finance/crypto/the-ethereum-merge-is-imminent-heres-why-it-matters/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 23:37:00+00:00

The Merge will see the second biggest blockchain, ethereum, adopt a proof of stake model. It's estimated to reduce the blockchain's energy use by over 99%.

## Patagonia Reportedly Giving Away All Profits to Help Fight Climate Change     - CNET
 - [https://www.cnet.com/science/climate/patagonia-reportedly-giving-away-all-profits-to-help-fight-climate-change/#ftag=CADf328eec](https://www.cnet.com/science/climate/patagonia-reportedly-giving-away-all-profits-to-help-fight-climate-change/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 23:25:44+00:00

The company's founder says he's "dead serious" about saving the planet.

## NASA's James Webb Telescope Sees Cosmic Clouds of Hot Sand on Mysterious World     - CNET
 - [https://www.cnet.com/science/space/nasas-james-webb-telescope-sees-cosmic-clouds-of-hot-sand-on-mysterious-world/#ftag=CADf328eec](https://www.cnet.com/science/space/nasas-james-webb-telescope-sees-cosmic-clouds-of-hot-sand-on-mysterious-world/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 23:15:00+00:00

The new high-powered observatory peeked at a place where weather is cloudy with a chance of silicates.

## NASA Rover Delivers Most Detailed View of Mars Surface Ever     - CNET
 - [https://www.cnet.com/science/space/nasa-rover-delivers-most-detailed-view-of-mars-surface-ever/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-rover-delivers-most-detailed-view-of-mars-surface-ever/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 23:10:03+00:00

Perseverance eyeballed a sumptuous 2.5 billion pixels of Martian goodness.

## D23 Everything Announced: Marvel, Star Wars, Indiana Jones, Avatar, Disney and More     - CNET
 - [https://www.cnet.com/culture/entertainment/d23-everything-announced-marvel-star-wars-indiana-jones-avatar-disney-and-more/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/d23-everything-announced-marvel-star-wars-indiana-jones-avatar-disney-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 22:35:31+00:00

Disney showcased heaps of upcoming movies and shows from Marvel, Lucasfilm, its live-action and animated studios, along with theme parks updates.

## Starbucks Drink Recalled Over Concerns About Metal Fragments     - CNET
 - [https://www.cnet.com/health/starbucks-vanilla-espresso-recall-metal-fragments/#ftag=CADf328eec](https://www.cnet.com/health/starbucks-vanilla-espresso-recall-metal-fragments/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 22:29:00+00:00

Impacted cans of Starbucks Vanilla Espresso Triple Shot drinks were sold across seven states, according to the FDA.

## Apple's iPhone 14 vs. Samsung Galaxy S22 vs. Google Pixel 6 vs. OnePlus 10T: Comparing Flagships, Spec by Spec     - CNET
 - [https://www.cnet.com/tech/mobile/apples-iphone-14-vs-samsung-galaxy-s22-vs-google-pixel-6-vs-oneplus-10t-comparing-flagships-spec-by-spec/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/apples-iphone-14-vs-samsung-galaxy-s22-vs-google-pixel-6-vs-oneplus-10t-comparing-flagships-spec-by-spec/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 22:15:00+00:00

How Apple's new $799 flagship compares against similarly priced Android phones.

## 2023 Chrysler 300C Is a V8-Powered Goodbye     - CNET
 - [https://www.cnet.com/roadshow/pictures/2023-chrysler-300c-sedan/#ftag=CADf328eec](https://www.cnet.com/roadshow/pictures/2023-chrysler-300c-sedan/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 22:00:01+00:00

Chrysler says goodbye to its 300 sedan with a limited-edition V8 model.

## NASA Eyes Target Date for Next Artemis I Rocket Launch, But Hurdles Remain     - CNET
 - [https://www.cnet.com/science/space/nasa-eyes-target-date-for-next-artemis-i-rocket-launch-but-hurdles-remain/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-eyes-target-date-for-next-artemis-i-rocket-launch-but-hurdles-remain/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 21:46:00+00:00

The mighty Space Launch System sprung a leak ahead of its debut, but the agency is hoping it's fully repaired and ready to go later this month.

## 'Mysterious' Space Diamonds May Be Tougher Than Gems on Earth     - CNET
 - [https://www.cnet.com/science/space/mysterious-space-diamonds-may-be-tougher-than-gems-on-earth/#ftag=CADf328eec](https://www.cnet.com/science/space/mysterious-space-diamonds-may-be-tougher-than-gems-on-earth/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 21:31:00+00:00

The cosmic gem might have formed after a long-ago collision.

## Fossilized Vomit From 150 Million Years Ago Reveals Ancient Predator     - CNET
 - [https://www.cnet.com/science/biology/fossilized-vomit-from-150-million-years-ago-reveals-ancient-predator/#ftag=CADf328eec](https://www.cnet.com/science/biology/fossilized-vomit-from-150-million-years-ago-reveals-ancient-predator/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 21:27:00+00:00

Jurassic Barf.

## Xbox PC App Adds New Feature to Help with Backlogs     - CNET
 - [https://www.cnet.com/tech/gaming/xbox-pc-app-adds-new-feature-to-help-with-backlogs/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/xbox-pc-app-adds-new-feature-to-help-with-backlogs/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 21:11:00+00:00

See how long it will take to beat a PC game before playing.

## Best Phone Deals: Carrier Sales and Unlocked Phone Discounts     - CNET
 - [https://www.cnet.com/deals/best-phone-deals/#ftag=CADf328eec](https://www.cnet.com/deals/best-phone-deals/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 21:00:05+00:00

Whether you're looking to upgrade your current phone or add a line to your plan, here are all the best phone deals to take advantage of today.

## 3 Iranians Indicted for Allegedly Hacking US Targets     - CNET
 - [https://www.cnet.com/tech/services-and-software/3-iranians-indicted-for-hacking-us-targets/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/3-iranians-indicted-for-hacking-us-targets/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 21:00:00+00:00

The indictment unsealed Wednesday says the men attempted to extort hundreds of millions of dollars from their victims.

## Three Iranians Indicted for Allegedly Hacking US Targets     - CNET
 - [https://www.cnet.com/tech/services-and-software/three-iranians-indicted-for-hacking-us-targets/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/three-iranians-indicted-for-hacking-us-targets/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 21:00:00+00:00

The indictment unsealed Wednesday says the men attempted to extort hundreds of millions of dollars from their victims.

## Alex Jones Sandy Hook Trial: Jury Hears Opening Arguments in Second Trial     - CNET
 - [https://www.cnet.com/culture/internet/alex-jones-sandy-hook-trial-jury-hears-opening-arguments-in-second-trial/#ftag=CADf328eec](https://www.cnet.com/culture/internet/alex-jones-sandy-hook-trial-jury-hears-opening-arguments-in-second-trial/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 20:50:19+00:00

A Connecticut jury will decide if the conspiracy theorist defamed the families of the school shooting victims.

## Best Pillow Top Mattresses for 2022     - CNET
 - [https://www.cnet.com/health/sleep/best-pillow-top-mattress/#ftag=CADf328eec](https://www.cnet.com/health/sleep/best-pillow-top-mattress/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 20:49:10+00:00

A pillow top mattress gives the support of an innerspring bed with the comfort of a thick, soft cushion. Here are the best ones you can buy.

## iPhone 14 Review: A Good Upgrade for Most People     - CNET
 - [https://www.cnet.com/tech/mobile/iphone-14-review-good-upgrade-for-most-people/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/iphone-14-review-good-upgrade-for-most-people/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 20:42:48+00:00

Apple's newest iPhone is reassuringly familiar.

## HelloFresh Meat Linked to E. coli Outbreak     - CNET
 - [https://www.cnet.com/health/hellofresh-meat-linked-to-e-coli-outbreak/#ftag=CADf328eec](https://www.cnet.com/health/hellofresh-meat-linked-to-e-coli-outbreak/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 20:33:03+00:00

So far, six people have been hospitalized after eating ground beef from the meal kit company.

## Monkeypox Claims First US Victim: What You Need to Know     - CNET
 - [https://www.cnet.com/health/monkeypox-what-gay-and-bisexual-men-need-to-know/#ftag=CADf328eec](https://www.cnet.com/health/monkeypox-what-gay-and-bisexual-men-need-to-know/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 20:30:02+00:00

As experts debate whether to refer to monkeypox as a sexually transmitted infection, the US has reported its first fatality linked to the outbreak.

## California Files Suit Against Amazon Over 'Anticompetitive' Merchant Contracts     - CNET
 - [https://www.cnet.com/news/california-files-suit-against-amazon-over-anticompetitive-merchant-contracts/#ftag=CADf328eec](https://www.cnet.com/news/california-files-suit-against-amazon-over-anticompetitive-merchant-contracts/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 20:22:07+00:00

Amazon's contracts make "other e-commerce platforms unable to compete," says California's attorney general.

## These Daring Aircraft Designs Paved the Way for the US Air Force     - CNET
 - [https://www.cnet.com/pictures/these-daring-aircraft-designs-paved-the-way-for-the-us-air-force/#ftag=CADf328eec](https://www.cnet.com/pictures/these-daring-aircraft-designs-paved-the-way-for-the-us-air-force/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 20:08:00+00:00

The US Army was flying airplanes for four decades before it gave birth to the Air Force in 1947. We take a look back at those early years.

## Twitter Shareholders Vote to Approve $44 Billion Musk Deal     - CNET
 - [https://www.cnet.com/news/social-media/twitter-shareholders-vote-to-approve-44-billion-musk-deal/#ftag=CADf328eec](https://www.cnet.com/news/social-media/twitter-shareholders-vote-to-approve-44-billion-musk-deal/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 20:01:00+00:00

A tabulation of shareholder votes shows Twitter stock owners want to sell to billionaire Elon Musk, who himself is still trying to back out of buying the company.

## Here's What to Know if You're Still Short on Baby Formula     - CNET
 - [https://www.cnet.com/health/parenting/heres-what-to-know-if-youre-still-short-on-baby-formula/#ftag=CADf328eec](https://www.cnet.com/health/parenting/heres-what-to-know-if-youre-still-short-on-baby-formula/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 20:00:12+00:00

Learn about safe formula substitutes and more.

## Catch Unwanted Pests: 3 DIY Bug Traps for Mosquitos, Flies and More     - CNET
 - [https://www.cnet.com/how-to/catch-unwanted-pests-3-diy-bug-traps-for-mosquitos-flies-and-more/#ftag=CADf328eec](https://www.cnet.com/how-to/catch-unwanted-pests-3-diy-bug-traps-for-mosquitos-flies-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 20:00:08+00:00

Easily trap hornets, gnats, and other flying and stinging bugs with a few household materials.

## High Inflation Persists Despite Drop in Gas Prices. Here's Everything You Need to Know     - CNET
 - [https://www.cnet.com/personal-finance/banking/high-inflation-persists-despite-drop-in-gas-prices-heres-everything-you-need-to-know/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/high-inflation-persists-despite-drop-in-gas-prices-heres-everything-you-need-to-know/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 19:48:37+00:00

Despite a slight slowdown, inflation remains at record highs.

## Best USB-C Car Charger for Your iPhone or Android Phone     - CNET
 - [https://www.cnet.com/tech/mobile/best-usb-car-charger/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/best-usb-car-charger/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 19:48:00+00:00

These two-port car chargers will keep your phone topped up and recharge other devices quickly.

## Mad at iPhone's New Search Button in iOS 16? Here's How to Get Rid of It     - CNET
 - [https://www.cnet.com/tech/services-and-software/mad-at-iphones-new-search-button-in-ios-16-heres-how-to-get-rid-of-it/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/mad-at-iphones-new-search-button-in-ios-16-heres-how-to-get-rid-of-it/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 19:30:02+00:00

Remove the sometimes irritating home screen feature with a single toggle.

## Best Game Pass and Xbox Live Deals     - CNET
 - [https://www.cnet.com/deals/best-game-pass-and-xbox-live-deals/#ftag=CADf328eec](https://www.cnet.com/deals/best-game-pass-and-xbox-live-deals/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 19:30:00+00:00

The best places to get an Xbox gaming subscription at a bargain.

## Best TV Streaming Service Deals     - CNET
 - [https://www.cnet.com/deals/best-streaming-service-deals/#ftag=CADf328eec](https://www.cnet.com/deals/best-streaming-service-deals/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 19:15:05+00:00

Take advantage of savings from HBO Max, Hulu, Paramount Plus and more with these streaming service discounts.

## How iPhone 14 Pro and Galaxy Z Fold Are Changing the Phone Game     - CNET
 - [https://www.cnet.com/tech/mobile/how-iphone-14-pro-and-galaxy-z-fold-are-changing-the-phone-game/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/how-iphone-14-pro-and-galaxy-z-fold-are-changing-the-phone-game/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 18:36:02+00:00

Commentary: Apple's Dynamic Island and Samsung's foldables underline how these companies are trying to change the way we interact with our devices.

## 'Quantum Leap' Trailer Jumps Straight Into An Explosive Reboot     - CNET
 - [https://www.cnet.com/culture/entertainment/quantum-leap-trailer-jumps-straight-into-explosive-reboot/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/quantum-leap-trailer-jumps-straight-into-explosive-reboot/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 18:30:32+00:00

The classic '90s time travel adventure gets an action-packed makeover on NBC and Peacock.

## Ferrari Purosangue SUV Revealed     - CNET
 - [https://www.cnet.com/roadshow/pictures/ferrari-purosangue-suv-revealed/#ftag=CADf328eec](https://www.cnet.com/roadshow/pictures/ferrari-purosangue-suv-revealed/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 18:20:16+00:00

Ferrari's first SUV will hit the road in 2023.

## Here's What Happens When You Ask the Internet to Name a Uranus Mission     - CNET
 - [https://www.cnet.com/science/space/heres-what-happens-when-you-ask-the-internet-to-name-a-uranus-mission/#ftag=CADf328eec](https://www.cnet.com/science/space/heres-what-happens-when-you-ask-the-internet-to-name-a-uranus-mission/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 18:07:00+00:00

Sorry, NASA would never name a Uranus mission Seymore Butts.

## NASA Fixes Artemis I Rocket Leak, Sets Target Date for Next Launch Try     - CNET
 - [https://www.cnet.com/science/space/nasa-fixes-artemis-i-rocket-leak-sets-target-date-for-next-launch-try/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-fixes-artemis-i-rocket-leak-sets-target-date-for-next-launch-try/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 17:55:00+00:00

But hurdles remain.

## 2022 Emmy Awards: The Complete List of Winners     - CNET
 - [https://www.cnet.com/culture/entertainment/2022-emmy-awards-the-complete-list-of-winners/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/2022-emmy-awards-the-complete-list-of-winners/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 17:45:00+00:00

Succession, Ted Lasso and The White Lotus picked up major awards on Monday night. Here's the full list of 74th Emmy Award winners.

## Jurassic Barf: Scientists Find Fossilized Vomit From 150 Million Years Ago     - CNET
 - [https://www.cnet.com/science/biology/jurassic-barf-scientists-find-fossilized-vomit-from-150-million-years-ago/#ftag=CADf328eec](https://www.cnet.com/science/biology/jurassic-barf-scientists-find-fossilized-vomit-from-150-million-years-ago/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 17:34:00+00:00

Turns out you can dust for vomit, after a fashion.

## Nike Sneaker-Cleaning Robot Looks Like a Car Wash for Shoes     - CNET
 - [https://www.cnet.com/culture/fashion/nike-sneaker-cleaning-robot-looks-like-a-car-wash-for-shoes/#ftag=CADf328eec](https://www.cnet.com/culture/fashion/nike-sneaker-cleaning-robot-looks-like-a-car-wash-for-shoes/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 17:21:00+00:00

Say hello to the Bot Initiated Longevity Lab, or BILL, that's stepping up to deep-clean your kicks.

## Sims 4 Base Game Will Be Free to Download Starting Oct. 18     - CNET
 - [https://www.cnet.com/tech/gaming/sims-4-base-game-will-be-free-to-download-starting-oct-18/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/sims-4-base-game-will-be-free-to-download-starting-oct-18/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 17:18:46+00:00

Planning on buying The Sims 4? Wait until next month and thank us later.

## NASA's James Webb Telescope Sees Clouds of Sand on Mysterious Cosmic World     - CNET
 - [https://www.cnet.com/science/space/nasas-james-webb-telescope-sees-clouds-of-sand-on-mysterious-cosmic-world/#ftag=CADf328eec](https://www.cnet.com/science/space/nasas-james-webb-telescope-sees-clouds-of-sand-on-mysterious-cosmic-world/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 17:18:00+00:00

The new high-powered observatory peeked at a place where weather is cloudy with a chance of silicates.

## Best iPad Deals: Save $49 on Latest iPad, $40 on iPad Air and More     - CNET
 - [https://www.cnet.com/deals/best-ipad-deals/#ftag=CADf328eec](https://www.cnet.com/deals/best-ipad-deals/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 17:03:14+00:00

The latest, 9th-gen iPad is selling at its lowest price yet at Amazon, Best Buy and Target right now.

## NASA Wants to Rocket Even More Private Astronauts to Space     - CNET
 - [https://www.cnet.com/science/space/nasa-wants-to-rocket-even-more-private-astronauts-to-space/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-wants-to-rocket-even-more-private-astronauts-to-space/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 17:03:00+00:00

Got a spare $55 million laying around?

## Best Ellipticals For Low-Impact Workouts     - CNET
 - [https://www.cnet.com/health/fitness/best-elliptical/#ftag=CADf328eec](https://www.cnet.com/health/fitness/best-elliptical/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 17:00:04+00:00

Get the most effective workout with these cardio machines.

## Astronaut's Star Trail Images Snapped From ISS Are True Showstoppers     - CNET
 - [https://www.cnet.com/science/space/astronauts-star-trail-images-snapped-from-iss-are-true-showstoppers/#ftag=CADf328eec](https://www.cnet.com/science/space/astronauts-star-trail-images-snapped-from-iss-are-true-showstoppers/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:59:00+00:00

If Van Gogh were an astrophotographer...

## iPhone 14 Pro, Galaxy Z Fold Show How Apple, Samsung Are Changing How We Use Phones     - CNET
 - [https://www.cnet.com/tech/mobile/iphone-14-pro-galaxy-z-fold-show-how-apple-samsung-are-changing-how-we-use-phones/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/iphone-14-pro-galaxy-z-fold-show-how-apple-samsung-are-changing-how-we-use-phones/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:55:16+00:00

Commentary: Apple's Dynamic Island and Samsung's foldables underline how these companies are trying to change the way we interact with our devices.

## iPhone's Buy Now, Pay Later Plan: How Apple Pay Later Will Work on iOS 16     - CNET
 - [https://www.cnet.com/tech/services-and-software/iphones-buy-now-pay-later-plan-how-apple-pay-later-will-work-on-ios-16/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/iphones-buy-now-pay-later-plan-how-apple-pay-later-will-work-on-ios-16/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:48:03+00:00

Apple will soon offer BNPL options in Apple Pay, but it's not on iPhones yet.

## Apple Arcade: How to Get It for Free, Best Games to Play and More     - CNET
 - [https://www.cnet.com/tech/gaming/apple-arcade-how-to-get-it-for-free-best-games-to-play-and-more/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/apple-arcade-how-to-get-it-for-free-best-games-to-play-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:48:00+00:00

We'll tell you everything you need to know about Apple's mobile gaming service before you subscribe.

## Explosive Sent to VR Lab in Boston Included Note Criticizing Mark Zuckerberg, Report Says     - CNET
 - [https://www.cnet.com/tech/gaming/explosive-sent-to-vr-lab-in-boston-included-note-criticizing-mark-zuckerberg-report-says/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/explosive-sent-to-vr-lab-in-boston-included-note-criticizing-mark-zuckerberg-report-says/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:36:29+00:00

A Northeastern University employee suffered minor hand injuries in the incident, and the campus reopened Wednesday.

## 2023 Maserati GranTurismo Reveals Sharp Design     - CNET
 - [https://www.cnet.com/roadshow/news/2023-maserati-granturismo-design-revealed/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2023-maserati-granturismo-design-revealed/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:35:00+00:00

Specs are still light, but we know it will be available with both gas and electric propulsion.

## Nintendo Switch Online: GoldenEye 007 Will Join N64 Retro Library     - CNET
 - [https://www.cnet.com/tech/gaming/nintendo-switch-online-goldeneye-007-will-join-n64-retro-library/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/nintendo-switch-online-goldeneye-007-will-join-n64-retro-library/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:35:00+00:00

Tuesday's Nintendo Direct revealed the N64 games coming in 2022 and 2023, and they include a bunch of Mario Party and Pokemon Stadium titles, along with the James Bond classic.

## 2023 Maserati GranTurismo Picks Up Plenty of MC20 Influence     - CNET
 - [https://www.cnet.com/roadshow/pictures/2023-maserati-granturismo-design-revealed/#ftag=CADf328eec](https://www.cnet.com/roadshow/pictures/2023-maserati-granturismo-design-revealed/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:34:00+00:00

It also relies on the MC20's 3.0-liter Nettuno V6 gas engine.

## Netflix's Tudum Fan Event Teases 'Bridgerton,' 'The Witcher,' 'Money Heist' and More     - CNET
 - [https://www.cnet.com/culture/entertainment/netflixs-tudum-fan-event-teases-bridgerton-the-witcher-money-heist-and-more/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/netflixs-tudum-fan-event-teases-bridgerton-the-witcher-money-heist-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:32:00+00:00

The global fan celebration includes a massive lineup of shows, actors and exclusive announcements.

## Google Photos Update Highlights More Memories, Adds Music and Graphics     - CNET
 - [https://www.cnet.com/tech/services-and-software/google-photos-update-highlights-more-memories-adds-music-and-graphics/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/google-photos-update-highlights-more-memories-adds-music-and-graphics/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:30:02+00:00

Google Photos is getting some fun upgrades.

## iPhone 14 Pro and 14 Pro Max Review: Welcome to Apple's Dynamic Island     - CNET
 - [https://www.cnet.com/tech/mobile/iphone-14-pro-max-review-welcome-to-apples-dynamic-island/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/iphone-14-pro-max-review-welcome-to-apples-dynamic-island/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:26:00+00:00

Apple upgraded its new Pro iPhones in ways both large and small without raising the price.

## PlayStation VR 2: Everything We Know So Far About the PS5's Biggest Accessory     - CNET
 - [https://www.cnet.com/tech/gaming/playstation-vr-2-ps5-everything-we-know-so-far/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/playstation-vr-2-ps5-everything-we-know-so-far/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 16:16:00+00:00

Sony's VR headset for the PS5 will arrive in 2023. Here's what we know after trying it.

## The US Air Force Is Turning 75: Take a Look at the Aircraft It's Flown     - CNET
 - [https://www.cnet.com/pictures/the-us-air-force-is-turning-75-take-a-look-at-the-aircraft-its-flown/#ftag=CADf328eec](https://www.cnet.com/pictures/the-us-air-force-is-turning-75-take-a-look-at-the-aircraft-its-flown/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 15:34:19+00:00

In honor of the Air Force's 75th anniversary, here are its high-flying aircraft, from the sound barrier-shattering X-1 and the long-serving C-130 all the way to today's cutting-edge F-35 and the upcoming B-21.

## Apple TV Plus: Every New TV Show Arriving in September     - CNET
 - [https://www.cnet.com/culture/entertainment/apple-tv-plus-new-tv-shows-to-watch-now-in-september/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/apple-tv-plus-new-tv-shows-to-watch-now-in-september/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 15:31:13+00:00

Here's a complete list of shows coming in September.

## iOS 16 Won't Run on Every iPhone. Will It Work on Yours?     - CNET
 - [https://www.cnet.com/tech/mobile/ios-16-wont-run-on-every-iphone-will-it-work-on-yours/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/ios-16-wont-run-on-every-iphone-will-it-work-on-yours/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 15:29:03+00:00

Find out if your iPhone is compatible with Apple's newest operating system.

## Apple's iPhone 14 Isn't Flashy, but It'll Hit the Spot     - CNET
 - [https://www.cnet.com/tech/mobile/apple-iphone-14-review-it-isnt-flashy-but-itll-hit-the-spot/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/apple-iphone-14-review-it-isnt-flashy-but-itll-hit-the-spot/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 15:27:00+00:00

Apple's newest iPhone is reassuringly familiar.

## The Absolute Best Sci-Fi TV Shows on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/the-absolute-best-sci-fi-tv-shows-to-stream-on-netflix-now/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-absolute-best-sci-fi-tv-shows-to-stream-on-netflix-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 15:23:18+00:00

These are the best of the sci-fi series on Netflix.

## Einstein's General Relativity Theory Passes Yet Another Massive Test     - CNET
 - [https://www.cnet.com/science/space/einsteins-general-relativity-theory-passes-yet-another-massive-test/#ftag=CADf328eec](https://www.cnet.com/science/space/einsteins-general-relativity-theory-passes-yet-another-massive-test/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 15:09:00+00:00

A space satellite has conducted the 'most precise test' of a major aspect of the mind-bending theory.

## Score 60% Off Joann's Entire Halloween and Fall Stock Today     - CNET
 - [https://www.cnet.com/deals/score-60-off-joanns-entire-halloween-and-fall-stock-today/#ftag=CADf328eec](https://www.cnet.com/deals/score-60-off-joanns-entire-halloween-and-fall-stock-today/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 15:04:00+00:00

Start off spooky season right with these decorative deals for less.

## iOS 16 Cheat Sheet: The One Guide You Need For the New iPhone OS     - CNET
 - [https://www.cnet.com/tech/services-and-software/ios-16-cheat-sheet-the-one-guide-you-need-for-the-new-os/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/ios-16-cheat-sheet-the-one-guide-you-need-for-the-new-os/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 14:58:41+00:00

What's in iOS 16? How do you get it? Any hidden features? CNET is here to answer those questions and more.

## 2023 Honda Pilot TrailSport Teasers Offer the Best Preview Yet     - CNET
 - [https://www.cnet.com/roadshow/news/2023-honda-pilot-trailsport-teasers/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2023-honda-pilot-trailsport-teasers/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 14:56:00+00:00

The camouflage is gone and the redesigned three-row Pilot is looking sharp.

## Fire TV Adds New Alexa Perks for Thursday Night Football Fans     - CNET
 - [https://www.cnet.com/tech/services-and-software/fire-tv-adds-new-alexa-perks-for-thursday-night-football-fans/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/fire-tv-adds-new-alexa-perks-for-thursday-night-football-fans/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 14:50:00+00:00

Viewers watching games on Prime Video can now tap Alexa for a host of tasks.

## Save $150 on Samsung's Sleek M7 Smart Monitor Today Only at B&H     - CNET
 - [https://www.cnet.com/deals/save-150-on-samsungs-sleek-m7-smart-monitor-today-only-at-b-h/#ftag=CADf328eec](https://www.cnet.com/deals/save-150-on-samsungs-sleek-m7-smart-monitor-today-only-at-b-h/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 14:07:00+00:00

Snag a 4K monitor that can run Microsoft 365 and streaming apps without a computer for just $220.

## National Cheeseburger Day 2022: McDonald's, Smashburger, Dairy Queen Offer Sizzling Deals     - CNET
 - [https://www.cnet.com/culture/national-cheeseburger-day-2022-mcdonalds-smashburger-dairy-queen/#ftag=CADf328eec](https://www.cnet.com/culture/national-cheeseburger-day-2022-mcdonalds-smashburger-dairy-queen/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 14:05:57+00:00

Find out where you can get free cheeseburgers, BOGO deals and more on Sept. 18.

## Discounted RAK Pro Tools Can Make Your Next Project Even Easier (and Cheaper)     - CNET
 - [https://www.cnet.com/deals/discounted-rak-pro-tools-and-make-your-next-project-even-easier/#ftag=CADf328eec](https://www.cnet.com/deals/discounted-rak-pro-tools-and-make-your-next-project-even-easier/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 14:01:00+00:00

Save an additional 20% on already discounted tools that are perfect for everyone.

## 2023 Chevy Tahoe RST Adds Police Parts for New Performance Edition     - CNET
 - [https://www.cnet.com/roadshow/news/2023-chevy-tahoe-rst-performance-edition-reveal/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2023-chevy-tahoe-rst-performance-edition-reveal/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 14:00:13+00:00

The Performance Edition gives the Tahoe a small power bump, as well.

## Best Workout Shorts for Women     - CNET
 - [https://www.cnet.com/health/fitness/best-workout-shorts-for-women/#ftag=CADf328eec](https://www.cnet.com/health/fitness/best-workout-shorts-for-women/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 14:00:10+00:00

Stay dry, comfortable and secure during the warmest temps with our top picks.

## 2023 Chevy Tahoe RST Performance Edition Is the Fastest Tahoe Yet     - CNET
 - [https://www.cnet.com/roadshow/pictures/2023-chevy-tahoe-rst-performance-edition/#ftag=CADf328eec](https://www.cnet.com/roadshow/pictures/2023-chevy-tahoe-rst-performance-edition/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 14:00:01+00:00

More power plus pursuit-rated chassis and suspension upgrades make the RST Performance Edition the fastest version of Chevy's full-size Tahoe SUV.

## Apple iPhone 14 Review: Like an iPhone 13 Pro, but Cheaper     - CNET
 - [https://www.cnet.com/tech/mobile/apple-iphone-14-review-like-an-iphone-13-pro-but-cheaper/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/apple-iphone-14-review-like-an-iphone-13-pro-but-cheaper/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:58:00+00:00

Apple's newest iPhone is like comfort food and it'll hit the spot for most people.

## Catch Your Next Fish for Less With This Bargain Fishing Gear at Cabela's     - CNET
 - [https://www.cnet.com/deals/catch-your-next-fish-for-less-with-this-bargain-fishing-gear-at-cabelas/#ftag=CADf328eec](https://www.cnet.com/deals/catch-your-next-fish-for-less-with-this-bargain-fishing-gear-at-cabelas/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:51:00+00:00

There are hooks, yarn, bait and other essentials to lure your dinner right in starting at $2.

## GoPro Hero 11 Black Hands-On: A Super-Sized Sensor Adds Value for Everyone     - CNET
 - [https://www.cnet.com/tech/computing/gopro-hero-11-black-hands-on-a-super-sized-sensor-adds-value-for-everyone/#ftag=CADf328eec](https://www.cnet.com/tech/computing/gopro-hero-11-black-hands-on-a-super-sized-sensor-adds-value-for-everyone/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:09:00+00:00

With a bigger sensor, better battery and some new editing tricks, the Hero 11 is ready for all the shooting and sharing.

## Chase Ink Business Preferred Credit Card: Transfer Points or Redeem for Travel     - CNET
 - [https://www.cnet.com/personal-finance/credit-cards/chase-ink-business-preferred-credit-card-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/credit-cards/chase-ink-business-preferred-credit-card-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:03:17+00:00

This card offers business owners the opportunity to save money on their business trips through point transfers and a redemption bonus.

## Apple's iPhone 14 Steps Up the Camera, Keeps Familiar Design     - CNET
 - [https://www.cnet.com/pictures/apples-iphone-14-steps-up-the-camera-keeps-familiar-design/#ftag=CADf328eec](https://www.cnet.com/pictures/apples-iphone-14-steps-up-the-camera-keeps-familiar-design/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:01:10+00:00

Apple's iPhone 14 looks a lot like the iPhone 13, but it steps up with camera improvements and new safety features.

## GoPro Hero 11 Black Hands-on: Super-sized Sensor for All Your Socials video     - CNET
 - [https://www.cnet.com/videos/gopro-hero-11-black-hands-on-super-sized-sensor-for-all-your-socials/#ftag=CADf328eec](https://www.cnet.com/videos/gopro-hero-11-black-hands-on-super-sized-sensor-for-all-your-socials/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:00:07+00:00

Shoot once and edit for all.

## Mortgage Rates on Sept. 14, 2022: Rates Move Higher     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/mortgage-rates-on-sep-14-2022-rates-move-higher/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/mortgage-rates-on-sep-14-2022-rates-move-higher/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:00:00+00:00

Today a handful of key mortgage rates crept higher. If you're in the market for a home loan, see how your payments might be affected by inflation.

## Mortgage Refinance Rates on Sept. 14, 2022: Rates Trend Higher     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/mortgage-refinance-rates-on-sep-14-2022-rates-trend-higher/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/mortgage-refinance-rates-on-sep-14-2022-rates-trend-higher/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:00:00+00:00

Multiple important refinance rates moved higher today. Though refinance rates change daily, experts expect rates to climb this year.

## Our iPhone 14 Video Review video     - CNET
 - [https://www.cnet.com/videos/our-iphone-14-video-review/#ftag=CADf328eec](https://www.cnet.com/videos/our-iphone-14-video-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:00:00+00:00

The iPhone 14 is quite lovely and a good upgrade for most people.

## We Reviewed the iPhone 14 Pro and 14 Pro Max video     - CNET
 - [https://www.cnet.com/videos/we-reviewed-the-iphone-14-pro-and-14-pro-max/#ftag=CADf328eec](https://www.cnet.com/videos/we-reviewed-the-iphone-14-pro-and-14-pro-max/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:00:00+00:00

Nearly every aspect of the new Pro iPhones have been upgraded in large or small ways. Yet the price remains the same.

## iPhone 14 Pro and 14 Pro Max Review: Welcome to the Dynamic Island     - CNET
 - [https://www.cnet.com/tech/mobile/iphone-14-pro-and-14-pro-max-review-welcome-to-the-dynamic-island/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/iphone-14-pro-and-14-pro-max-review-welcome-to-the-dynamic-island/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:00:00+00:00

Apple upgraded its new Pro iPhones in both large and small ways without raising the price.

## iPhone 14 Pro and 14 Pro Max Review: Welcoming Apple's Dynamic Island     - CNET
 - [https://www.cnet.com/tech/mobile/iphone-14-pro-and-14-pro-max-review-welcoming-apple-dynamic-island/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/iphone-14-pro-and-14-pro-max-review-welcoming-apple-dynamic-island/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:00:00+00:00

Apple upgraded its new Pro iPhones in both large and small ways without raising the price.

## iPhone 14 Review: Like an iPhone 13 Pro, but Cheaper     - CNET
 - [https://www.cnet.com/tech/mobile/iphone-14-review-like-an-iphone-13-pro-but-cheaper/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/iphone-14-review-like-an-iphone-13-pro-but-cheaper/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 13:00:00+00:00

Apple's newest iPhone is like comfort food and it'll hit the spot for most people.

## Anker's Already Affordable Noise-Canceling Headphones Are Up to 30% Off Today     - CNET
 - [https://www.cnet.com/deals/anker-headphone-sale-at-amazon-today-only/#ftag=CADf328eec](https://www.cnet.com/deals/anker-headphone-sale-at-amazon-today-only/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 12:59:00+00:00

Save up to $45 on select Anker headphones, including one of our overall favorite pairs on the market right now.

## 2023 Jeep Wrangler 4xe PHEV Gains New Willys Trim     - CNET
 - [https://www.cnet.com/roadshow/news/2023-jeep-wrangler-4xe-phev-detroit-auto-show-debut/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2023-jeep-wrangler-4xe-phev-detroit-auto-show-debut/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 12:30:08+00:00

The Willys brings some retro graphics and design cues to Jeep's plug-in-hybrid off-roader.

## Jeep Wrangler Willys 4xe Plug-In Hybrid Has Retro Design Cues     - CNET
 - [https://www.cnet.com/roadshow/pictures/2023-jeep-wrangler-willys-4xe-phev/#ftag=CADf328eec](https://www.cnet.com/roadshow/pictures/2023-jeep-wrangler-willys-4xe-phev/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 12:30:07+00:00

The Willys gets blue-accented stickers, a black grille and more.

## 2023 Jeep Grand Cherokee 4xe 30th Anniversary Edition Brings It Back Home     - CNET
 - [https://www.cnet.com/roadshow/news/2023-jeep-grand-cherokee-4xe-30th-anniversary-edition-detroit-auto-show/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2023-jeep-grand-cherokee-4xe-30th-anniversary-edition-detroit-auto-show/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 12:30:02+00:00

The original Grand Cherokee made its debut in Detroit by crashing through a window.

## Could 5G Home Internet Be the Solution to Your Broadband Needs?     - CNET
 - [https://www.cnet.com/news/what-is-5g-home-internet/#ftag=CADf328eec](https://www.cnet.com/news/what-is-5g-home-internet/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 12:00:03+00:00

Mobile carriers rave about its potential, but 5G also offers appealing speeds and straightforward pricing for household internet connections.

## DJI Osmo Action 3's Best Feature Isn't What You'd Expect     - CNET
 - [https://www.cnet.com/tech/computing/dji-osmo-action-3s-best-feature-isnt-what-youd-expect/#ftag=CADf328eec](https://www.cnet.com/tech/computing/dji-osmo-action-3s-best-feature-isnt-what-youd-expect/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 12:00:00+00:00

The 4K action cam adds power in more ways than one.

## How Netflix and 'Squid Game' Broke the Emmys' Language Barrier     - CNET
 - [https://www.cnet.com/culture/entertainment/how-netflix-and-squid-game-broke-the-emmys-language-barrier/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/how-netflix-and-squid-game-broke-the-emmys-language-barrier/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 12:00:00+00:00

The Emmys had never even nominated a non-English show for a major award. Then Netflix and Korean pop culture took over the globe -- and won.

## PSVR 2 Hands-On: Why the Upcoming PS5 VR Headset Wows Me     - CNET
 - [https://www.cnet.com/tech/gaming/psvr-2-hands-on-why-the-upcoming-ps5-vr-headset-wowed-us/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/psvr-2-hands-on-why-the-upcoming-ps5-vr-headset-wowed-us/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 12:00:00+00:00

Sony's new display and controllers for its 2023 VR headset make a great first impression.

## These Clothes Could Be a Cool Response to a Warming Climate     - CNET
 - [https://www.cnet.com/culture/fashion/these-cool-clothes-could-help-fight-global-warming/#ftag=CADf328eec](https://www.cnet.com/culture/fashion/these-cool-clothes-could-help-fight-global-warming/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 12:00:00+00:00

Startup LifeLabs has developed fabric that lets your body heat escape in the summer and reflect back during the winter.

## We Played PlayStation VR 2 on the PlayStation 5 video     - CNET
 - [https://www.cnet.com/videos/we-played-playstation-vr-2-on-the-playstation-5/#ftag=CADf328eec](https://www.cnet.com/videos/we-played-playstation-vr-2-on-the-playstation-5/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 12:00:00+00:00

Here's a close-up look at the 2023 headset and what it was like to play four games at Sony's PlayStation headquarters.

## 'Babylon' Trailer: Margot Robbie and Brad Pitt In More Hollywood Madness     - CNET
 - [https://www.cnet.com/culture/entertainment/babylon-trailer-throws-margot-robbie-and-brad-pitt-into-hollywood-madness/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/babylon-trailer-throws-margot-robbie-and-brad-pitt-into-hollywood-madness/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 11:57:10+00:00

Damien Chazelle's star-studded Tinseltown epic promises sex, drugs and jazz in a frenzied teaser.

## Logitech's Circle View Doorbell Falls to a New All-Time Low Price at Amazon     - CNET
 - [https://www.cnet.com/deals/logitechs-circle-view-video-doorbell-falls-174/#ftag=CADf328eec](https://www.cnet.com/deals/logitechs-circle-view-video-doorbell-falls-174/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 11:30:14+00:00

Your video doorbell options are limited if you use Apple's HomeKit, so don't miss your chance to snag this one while it's on sale.

## 'She-Hulk' Release Schedule: Here's Exactly When Episode 5 Hits Disney Plus     - CNET
 - [https://www.cnet.com/culture/entertainment/she-hulk-release-schedule-heres-exactly-when-episode-5-hits-disney-plus/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/she-hulk-release-schedule-heres-exactly-when-episode-5-hits-disney-plus/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 11:00:24+00:00

The latest Marvel series is well underway on Disney Plus. Here's the exact release day and time for the next episode...

## 2023 Toyota GR Corolla First Drive Review: Impressively Balanced     - CNET
 - [https://www.cnet.com/roadshow/news/2023-toyota-gr-corolla-first-drive-review/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2023-toyota-gr-corolla-first-drive-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 11:00:18+00:00

Toyota's first true hot hatch for the US is everything we'd hoped it'd be, and then some.

## The Best Documentaries on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/the-best-documentaries-on-netflix/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-best-documentaries-on-netflix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 04:44:00+00:00

Check out our picks for the best documentaries on Netflix.

## The Absolute Best Games on Nintendo Switch     - CNET
 - [https://www.cnet.com/pictures/the-absolute-best-games-on-nintendo-switch/#ftag=CADf328eec](https://www.cnet.com/pictures/the-absolute-best-games-on-nintendo-switch/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 03:51:00+00:00

Our picks for the best video games on the Nintendo Switch.

## Google Must Face Most of Texas' Antitrust Lawsuit on Ads     - CNET
 - [https://www.cnet.com/tech/services-and-software/google-must-face-most-of-texas-antitrust-lawsuit-on-ads/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/google-must-face-most-of-texas-antitrust-lawsuit-on-ads/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 02:25:00+00:00

Lawsuit alleges the search giant entered into an illegal deal with Facebook.

## 'House of the Dragon' Episode 4 Recap: Daemon and Rhaenyra's Night Out     - CNET
 - [https://www.cnet.com/culture/entertainment/house-of-the-dragon-episode-4-recap-daemon-and-rhaenyras-night-out/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/house-of-the-dragon-episode-4-recap-daemon-and-rhaenyras-night-out/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 02:01:00+00:00

With the prospect of a royal marriage weighing her down, Rhaenyra just wants to feel like a normal girl for one night. Daemon is here to help.

## The Best Sci-Fi Movies on HBO Max     - CNET
 - [https://www.cnet.com/culture/entertainment/the-best-sci-fi-movies-to-catch-on-hbo-max-tonight/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-best-sci-fi-movies-to-catch-on-hbo-max-tonight/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 01:29:22+00:00

HBO Max has a huge range of quality sci-fi flicks.

## 'The Rings of Power': All the Tolkien Terminology Explained     - CNET
 - [https://www.cnet.com/culture/entertainment/the-rings-of-power-all-the-tolkien-terminology-explained/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-rings-of-power-all-the-tolkien-terminology-explained/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 01:20:00+00:00

Need help with some of the terminology in Rings of Power? Help is here.

## The Best Sci-Fi TV Shows on Prime Video     - CNET
 - [https://www.cnet.com/culture/entertainment/prime-video-the-best-sci-fi-tv-shows-to-binge-watch-tonight/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/prime-video-the-best-sci-fi-tv-shows-to-binge-watch-tonight/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 01:17:00+00:00

Prime Video is sitting on a ton of excellent sci-fi series well worth committing a binge to.

## 'House of the Dragon': When Episode 5 Lands in Your Timezone     - CNET
 - [https://www.cnet.com/culture/entertainment/house-of-the-dragon-when-episode-5-lands-in-your-timezone/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/house-of-the-dragon-when-episode-5-lands-in-your-timezone/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 01:08:00+00:00

Thirsting after episode 5? Here's when you can watch.

## CNET Wellness Editors Share Their Favorite Sleep Tips     - CNET
 - [https://www.cnet.com/health/sleep/cnet-wellness-editors-share-their-favorite-sleep-tips/#ftag=CADf328eec](https://www.cnet.com/health/sleep/cnet-wellness-editors-share-their-favorite-sleep-tips/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 01:00:12+00:00

Here's how you can tackle poor sleep when a good night's rest comes few and far between.

## Plucky Cockatoos Clash With Humans in 'Arms Race' to Win the Garbage Bin War     - CNET
 - [https://www.cnet.com/science/biology/plucky-cockatoos-clash-with-humans-in-arms-race-to-win-the-garbage-bin-war/#ftag=CADf328eec](https://www.cnet.com/science/biology/plucky-cockatoos-clash-with-humans-in-arms-race-to-win-the-garbage-bin-war/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 00:34:33+00:00

A wheelie big battle brews in the suburbs of Australia.

## Nike's Sneaker-Cleaning Robot Is Like a Car Wash for Shoes     - CNET
 - [https://www.cnet.com/culture/fashion/nikes-sneaker-cleaning-robot-is-like-a-car-wash-for-shoes/#ftag=CADf328eec](https://www.cnet.com/culture/fashion/nikes-sneaker-cleaning-robot-is-like-a-car-wash-for-shoes/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 00:33:00+00:00

Say hello to the Bot Initiated Longevity Lab, or BILL, that's stepping up to deep-clean your kicks.

## You Shouldn't Rinse Your Teeth With Water After Brushing. Here's Why     - CNET
 - [https://www.cnet.com/health/personal-care/you-shouldnt-rinse-your-teeth-with-water-after-brushing-heres-why/#ftag=CADf328eec](https://www.cnet.com/health/personal-care/you-shouldnt-rinse-your-teeth-with-water-after-brushing-heres-why/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-09-14 00:15:03+00:00

Your teeth can actually benefit from you leaving a small amount of toothpaste residue on them.


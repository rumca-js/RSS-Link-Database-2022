# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Gol Milika, dwie pomyłki Zielińskiego z karnych. Polska huśtawka nastrojów
 - [https://eurosport.tvn24.pl/gol-milika--dwie-pomy-ki-zieli-skiego-z-karnych--polska-hu-tawka-nastroj-w-w-lidze-mistrz-w,1118569.html?source=rss](https://eurosport.tvn24.pl/gol-milika--dwie-pomy-ki-zieli-skiego-z-karnych--polska-hu-tawka-nastroj-w-w-lidze-mistrz-w,1118569.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 21:26:00+00:00

<img alt="Gol Milika, dwie pomyłki Zielińskiego z karnych. Polska huśtawka nastrojów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yhjdjj-arkadiusz-milik-wyrasta-na-nowa-gwiazde-juventusu/alternates/LANDSCAPE_1280" />
    Szalony wieczór Biało-Czerwonych piłkarzy w Lidze Mistrzów.

## Kapitan koszykarzy w przerwie pisał do żony. "Jeszcze 20 minut tu i zostaje"
 - [https://eurosport.tvn24.pl/kapitan-koszykarzy-w-przerwie-pisa--do--ony---jeszcze-20-minut-tu-i-zostaje-,1118566.html?source=rss](https://eurosport.tvn24.pl/kapitan-koszykarzy-w-przerwie-pisa--do--ony---jeszcze-20-minut-tu-i-zostaje-,1118566.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 21:05:00+00:00

<img alt="Kapitan koszykarzy w przerwie pisał do żony. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-cj3r8e-mateusz-ponitka-wprowadzil-polakow-do-polfinalu-eurobasketu-6113279/alternates/LANDSCAPE_1280" />
    Mateusz Ponitka rozegrał jeden z najlepszych meczów w kadrze w karierze.

## Wzruszony trener Polaków. "Ta drużyna ma jaja jak arbuzy, serce jak księżyc"
 - [https://eurosport.tvn24.pl/wzruszony-trener-polak-w---ta-dru-yna-ma-jaja-jak-arbuzy--serce-jak-ksi--yc-,1118567.html?source=rss](https://eurosport.tvn24.pl/wzruszony-trener-polak-w---ta-dru-yna-ma-jaja-jak-arbuzy--serce-jak-ksi--yc-,1118567.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 21:03:44+00:00

<img alt="Wzruszony trener Polaków. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-38w8lp-igor-milicic-6113268/alternates/LANDSCAPE_1280" />
    Polscy koszykarze dokonali niemożliwego podczas mistrzostw Europy.

## Fenomenalny występ Mateusza Ponitki. "MVP! MVP!"
 - [https://eurosport.tvn24.pl/fenomenalny-wyst-p-mateusza-ponitki-przeciwko-obro-com-tytu-u---mvp--mvp--,1118565.html?source=rss](https://eurosport.tvn24.pl/fenomenalny-wyst-p-mateusza-ponitki-przeciwko-obro-com-tytu-u---mvp--mvp--,1118565.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 20:57:00+00:00

<img alt="Fenomenalny występ Mateusza Ponitki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-32hai0-mateusz-ponitka-najlepszym-graczem-meczu-ze-slowenia-6113230/alternates/LANDSCAPE_1280" />
    Jedno z największych zwycięstw w historii polskiej koszykówki stało się faktem!

## To był prawdziwy dreszczowiec! Polacy wyeliminowali mistrzów Europy
 - [https://eurosport.tvn24.pl/wielki-mecz-polak-w--obro-cy-tytu-u-wyeliminowani-z-eurobasketu,1118564.html?source=rss](https://eurosport.tvn24.pl/wielki-mecz-polak-w--obro-cy-tytu-u-wyeliminowani-z-eurobasketu,1118564.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 20:30:00+00:00

<img alt="To był prawdziwy dreszczowiec! Polacy wyeliminowali mistrzów Europy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v1khy2-radosc-polskich-koszykarzy-6113094/alternates/LANDSCAPE_1280" />
    Ten przejdzie do historii polskiej koszykówki! Biało-Czerwoni awansowali do półfinału mistrzostw Europy.

## Szachtar zremisował z Celtikiem
 - [https://eurosport.tvn24.pl/liga-mistrz-w-wr-ci-a-do-warszawy--szachtar-zremisowa--z-celtikiem,1118542.html?source=rss](https://eurosport.tvn24.pl/liga-mistrz-w-wr-ci-a-do-warszawy--szachtar-zremisowa--z-celtikiem,1118542.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 18:41:00+00:00

<img alt="Szachtar zremisował z Celtikiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0ahq80-mychajlo-mudryk-strzela-na-bramke-celticu/alternates/LANDSCAPE_1280" />
    Liga Mistrzów wróciła do Warszawy.

## "Przygoda z Pegasusem jest zakończona. Polskim władzom zabrakło wyobraźni"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2307,S00E2307,864649?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2307,S00E2307,864649?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 18:38:01+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4euofd-nso-group-sprzedaje-pegasusa-reportaz-czarno-na-bialym-6112571/alternates/LANDSCAPE_1280" />
    Mówi dr Tamara Rud z Polsko–Izraelskiego Konsorcjum na rzecz Cyberbezpieczeństwa.

## "Nigdy sobie nie wyobrażałam, że dożyję takich czasów"
 - [https://fakty.tvn24.pl/dodatek-w-glowy-b-dzie-ni-szy---wprowadzamy-zasad--jeden-adres--jeden-dodatek-,1118528.html?source=rss](https://fakty.tvn24.pl/dodatek-w-glowy-b-dzie-ni-szy---wprowadzamy-zasad--jeden-adres--jeden-dodatek-,1118528.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 17:14:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zs082y-14-1900-fakty-0001-6112595/alternates/LANDSCAPE_1280" />
    Wszyscy, którzy złożyli wnioski o dodatek węglowy, mogą być zawiedzeni. Jest duże ryzyko, że wyniesie mniej niż 3000 złotych. To dlatego, że wniosków jest więcej, niż zakładał rząd. Ministerstwo Klimatu i Środowiska podejrzewa, że wiele wniosków dotyczy tego samego pieca, i przekonuje, że nowelizacja przepisów i załatanie luk załatwi sprawę.

## Płakali na widok żołnierzy. "Podeszłam i spytałam: a można was dotknąć?"
 - [https://fakty.tvn24.pl/mieszka-cy-wyzwolonej-ba-akliji-p-akali---podesz-am-i-spyta-am--a-mo-na-was-dotkn----,1118530.html?source=rss](https://fakty.tvn24.pl/mieszka-cy-wyzwolonej-ba-akliji-p-akali---podesz-am-i-spyta-am--a-mo-na-was-dotkn----,1118530.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 17:11:00+00:00

<img alt="Płakali na widok żołnierzy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7sbou6-mieszkancy-wyzwolonej-balakliji-plakali-podeszlam-i-spytalam-a-mozna-was-dotknac/alternates/LANDSCAPE_1280" />
    Mieszkańcy wyzwolonej Bałakliji opowiedzieli o torturach, jakich doznali z rąk rosyjskich okupantów.

## Genialna gra Polaków w Berlinie. Mistrzowie Europy zaskoczeni w ćwierćfinale
 - [https://eurosport.tvn24.pl/polska---s-owenia-w--wier-finale-eurobasketu--wynik-i-relacja-na--ywo,1118521.html?source=rss](https://eurosport.tvn24.pl/polska---s-owenia-w--wier-finale-eurobasketu--wynik-i-relacja-na--ywo,1118521.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 17:00:00+00:00

<img alt="Genialna gra Polaków w Berlinie. Mistrzowie Europy zaskoczeni w ćwierćfinale" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cma6ek-polscy-koszykarze-walcza-w-eurobaskecie/alternates/LANDSCAPE_1280" />
    Wynik meczu i relacja na żywo w eurosport.pl. Zapraszamy!

## Kierowca F1 opuścił szpital
 - [https://eurosport.tvn24.pl/kierowca-f1-opu-ci--szpital-po-komplikacjach-pooperacyjnych,1118496.html?source=rss](https://eurosport.tvn24.pl/kierowca-f1-opu-ci--szpital-po-komplikacjach-pooperacyjnych,1118496.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 16:27:00+00:00

<img alt="Kierowca F1 opuścił szpital " src="https://tvn24.pl/najnowsze/cdn-zdjecie-es74ap-albon-wraca-do-scigania/alternates/LANDSCAPE_1280" />
    Po komplikacjach pooperacyjnych.

## "Zarabiam w dwa dni tyle co w szkole w miesiąc"
 - [https://tvn24.pl/go/programy,7/polska-i-swiat-odcinki,10854/odcinek-2282,S00E2282,864630?source=rss](https://tvn24.pl/go/programy,7/polska-i-swiat-odcinki,10854/odcinek-2282,S00E2282,864630?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 15:49:49+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-730y7c-katarzyna-fligier-po-28-latach-zrezygnowala-z-pracy-w-szkole-6112366/alternates/LANDSCAPE_1280" />
    Nauczycielka po 28 latach odeszła z oświaty.

## Kadra Walijczyków na mecz z Polską
 - [https://eurosport.tvn24.pl/znane-nazwiska-pomini-te--kadra-walijczyk-w-na-mecz-z-polsk-,1118505.html?source=rss](https://eurosport.tvn24.pl/znane-nazwiska-pomini-te--kadra-walijczyk-w-na-mecz-z-polsk-,1118505.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 15:16:23+00:00

<img alt="Kadra Walijczyków na mecz z Polską" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u67ahe-walijczycy-zmierza-sie-z-polakami-25-wrzesnia/alternates/LANDSCAPE_1280" />
    Znane nazwiska pominięte.

## Ważna rola Majki
 - [https://eurosport.tvn24.pl/trentin-najsprytniejszy-na-finiszu-w-luksemburgu--wa-na-rola-majki,1118511.html?source=rss](https://eurosport.tvn24.pl/trentin-najsprytniejszy-na-finiszu-w-luksemburgu--wa-na-rola-majki,1118511.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 14:31:00+00:00

<img alt="Ważna rola Majki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kwcdjk-matteo-trentin-wygral-drugi-etap-tour-de-luxembourg/alternates/LANDSCAPE_1280" />
    Trentin najsprytniejszy na finiszu w Luksemburgu.

## "Jedna z najlepszych kontrofensyw od czasów II wojny światowej"
 - [https://tvn24.pl/swiat/ukraina-ekspert-ukraincy-przeprowadzili-jedna-z-najlepszych-kontrofensyw-od-czasu-ii-wojny-swiatowej-6111901?source=rss](https://tvn24.pl/swiat/ukraina-ekspert-ukraincy-przeprowadzili-jedna-z-najlepszych-kontrofensyw-od-czasu-ii-wojny-swiatowej-6111901?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 12:07:45+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pcbsdd-drv-6112019/alternates/LANDSCAPE_1280" />
    A zarazem "jedna z największych porażek sił rosyjskich" od dekad.

## Oderwał się fragment lodowca. To, jak runął, nagrał turysta
 - [https://tvn24.pl/tvnmeteo/swiat/oderwal-sie-fragment-lodowca-to-jak-runal-nagral-turysta-6111809?source=rss](https://tvn24.pl/tvnmeteo/swiat/oderwal-sie-fragment-lodowca-to-jak-runal-nagral-turysta-6111809?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 12:03:33+00:00

<img alt="Oderwał się fragment lodowca. To, jak runął, nagrał turysta" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-3qrmlz-chile-6111968/alternates/LANDSCAPE_1280" />
    W parku narodowym w Patagonii.

## Nadchodzi zima, a oni nie mają żadnych zapasów. Najnowsze badanie
 - [https://tvn24.pl/biznes/z-kraju/energetyka-cbos-40-proc-ogrzewajacych-domy-weglem-nie-ma-zapasow-surowca-na-sezon-grzewczy-6111879?source=rss](https://tvn24.pl/biznes/z-kraju/energetyka-cbos-40-proc-ogrzewajacych-domy-weglem-nie-ma-zapasow-surowca-na-sezon-grzewczy-6111879?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 11:42:10+00:00

<img alt="Nadchodzi zima, a oni nie mają żadnych zapasów. Najnowsze badanie" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie555b99c00b79fe6a70bc444d73b0a250-kopalnia-wegiel-4212625/alternates/LANDSCAPE_1280" />
    Problemy mogą dotknąć głównie mieszkańców wsi.

## Morawiecki porównuje "główną część środków unijnych" z tymi na odbudowę po pandemii. O ile się myli
 - [https://konkret24.tvn24.pl/r/morawiecki-por-wnuje--g--wn--cz-----rodk-w-unijnych--z-tymi-na-odbudow--po-pandemii---o-ile-si--myli,1118384.html?source=rss](https://konkret24.tvn24.pl/r/morawiecki-por-wnuje--g--wn--cz-----rodk-w-unijnych--z-tymi-na-odbudow--po-pandemii---o-ile-si--myli,1118384.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 11:40:35+00:00

<img alt="Morawiecki porównuje " src="https://tvn24.pl/najnowsze/cdn-zdjecie-sgvd0g-shutterstock368582903jpg-6111956/alternates/LANDSCAPE_1280" />
    Policzyliśmy. Premier nie ma racji.

## Szachtar prosi o wsparcie
 - [https://eurosport.tvn24.pl/szachtar-prosi-o-wsparcie---liczymy---e-w-warszawie-nie-b-dzie-wolnych-miejsc-,1118492.html?source=rss](https://eurosport.tvn24.pl/szachtar-prosi-o-wsparcie---liczymy---e-w-warszawie-nie-b-dzie-wolnych-miejsc-,1118492.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 11:35:19+00:00

<img alt="Szachtar prosi o wsparcie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a2wy2v-pilkarze-szachtara-przygotowuja-sie-do-spotkan-ligi-mistrzow-w-warszawie/alternates/LANDSCAPE_1280" />
    Przed meczem Ligi Mistrzów na stadionie Legii.

## Walki między Armenią i Azerbejdżanem
 - [https://tvn24.pl/swiat/armenia-azerbejdzan-trwa-wzajemny-ostrzal-pozycji-6111810?source=rss](https://tvn24.pl/swiat/armenia-azerbejdzan-trwa-wzajemny-ostrzal-pozycji-6111810?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 11:33:17+00:00

<img alt="Walki między Armenią i Azerbejdżanem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yhleyu-armia-azerbejdzanu-6111841/alternates/LANDSCAPE_1280" />
    Trwa wzajemny ostrzał pozycji.

## Media: Pociąg z ukraińskim zbożem wykoleił się w Rumunii
 - [https://tvn24.pl/swiat/rumunia-marusza-pociag-z-ukrainskim-zbozem-wykoleilsie-policja-nie-wyklucza-sabotazu-6111817?source=rss](https://tvn24.pl/swiat/rumunia-marusza-pociag-z-ukrainskim-zbozem-wykoleilsie-policja-nie-wyklucza-sabotazu-6111817?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 11:27:07+00:00

<img alt="Media: Pociąg z ukraińskim zbożem wykoleił się w Rumunii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9girb3-pociag-towarowy-ktory-przewozil-ukrainskie-zboze-wykoleilsiew-okregu-marusza-w-srodkowej-rumunii-i-6111868/alternates/LANDSCAPE_1280" />
    Policja nie wyklucza sabotażu.

## Macierewicz twierdzi, że rząd PO "nie wystosował pism o zwrot wraku". MSZ potwierdził, że było inaczej
 - [https://tvn24.pl/polska/katastrofa-smolenska-reportaz-czarno-na-bialym-macierewicz-twierdzi-ze-rzad-po-nie-domagal-sie-od-rosjan-zwrotu-wraku-tupolewa-bylo-inaczej-6111736?source=rss](https://tvn24.pl/polska/katastrofa-smolenska-reportaz-czarno-na-bialym-macierewicz-twierdzi-ze-rzad-po-nie-domagal-sie-od-rosjan-zwrotu-wraku-tupolewa-bylo-inaczej-6111736?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 11:22:00+00:00

<img alt="Macierewicz twierdzi, że rząd PO " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fryr9y-macierewicz-2-6111838/alternates/LANDSCAPE_1280" />
    W rzeczywistości przesłano 11 not dyplomatycznych w tej sprawie.

## Wielomilionowa kara za obrażanie pracowników
 - [https://eurosport.tvn24.pl/wielomilionowa-kara-za-obra-anie-pracownik-w---przepraszam--spowodowa-em-b-l-,1118487.html?source=rss](https://eurosport.tvn24.pl/wielomilionowa-kara-za-obra-anie-pracownik-w---przepraszam--spowodowa-em-b-l-,1118487.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 11:16:31+00:00

<img alt="Wielomilionowa kara za obrażanie pracowników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l4tawb-roberto-sarver-jest-wlascicielem-dwoch-klubow-z-phoenix/alternates/LANDSCAPE_1280" />
    Dobiegło końca wielomiesięczne dochodzenie.

## Strajk i apel o rezygnację z połowy lotów
 - [https://tvn24.pl/biznes/ze-swiata/francja-strajk-i-apel-o-rezygnacje-z-polowy-lotow-mozliwe-duze-utrudnienia-dla-podroznych-6111666?source=rss](https://tvn24.pl/biznes/ze-swiata/francja-strajk-i-apel-o-rezygnacje-z-polowy-lotow-mozliwe-duze-utrudnienia-dla-podroznych-6111666?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 11:02:43+00:00

<img alt="Strajk i apel o rezygnację z połowy lotów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wn24tz-paryskie-lotnisko-paryz-charles-de-gaulle-jest-drugim-najbardziej-obciazonym-portem-lotniczym-europy-6111839/alternates/LANDSCAPE_1280" />
    Możliwe duże utrudnienia dla podróżnych.

## "To jest duch Europy"
 - [https://tvn24.pl/swiat/unia-europejska-ursula-von-der-leyen-zaprosila-polki-ktore-pomagaly-uchodzcom-z-ukrainy-6111767?source=rss](https://tvn24.pl/swiat/unia-europejska-ursula-von-der-leyen-zaprosila-polki-ktore-pomagaly-uchodzcom-z-ukrainy-6111767?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 10:58:40+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c1mb2y-szefowa-ke-zaprosila-do-parlamentu-europejskiego-polki-ktore-pomagaly-uchodzcom-z-ukrainy-6111779/alternates/LANDSCAPE_1280" />
    Von der Leyen zaprosiła Polki, które pomagały uchodźcom z Ukrainy.

## Monarchowie, prezydenci, premierzy. Kto pojawi się na pogrzebie królowej Elżbiety II
 - [https://tvn24.pl/swiat/pogrzeb-krolowej-elzbiety-ii-lista-gosci-ktorzy-przywodcy-przyleca-do-londynu-6111697?source=rss](https://tvn24.pl/swiat/pogrzeb-krolowej-elzbiety-ii-lista-gosci-ktorzy-przywodcy-przyleca-do-londynu-6111697?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 10:37:43+00:00

<img alt="Monarchowie, prezydenci, premierzy. Kto pojawi się na pogrzebie królowej Elżbiety II" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u3o4ei-krolowa-wielkiej-brytanii-elzbieta-ii-sklada-wizyte-na-wyspach-normandzkich-27-lipca-1957-r-6105429/alternates/LANDSCAPE_1280" />
    Udział potwierdzają kolejni przywódcy.

## Amerykańska prognoza na zimę dla Polski. Co mówią najnowsze przewidywania
 - [https://tvn24.pl/tvnmeteo/prognoza/amerykanska-prognoza-na-zime-dla-polski-co-mowia-najnowsze-przewidywania-6111533?source=rss](https://tvn24.pl/tvnmeteo/prognoza/amerykanska-prognoza-na-zime-dla-polski-co-mowia-najnowsze-przewidywania-6111533?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 10:34:40+00:00

<img alt="Amerykańska prognoza na zimę dla Polski. Co mówią najnowsze przewidywania" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-3dlrsj-okres-jesienno-zimowym-w-polsce-6111727/alternates/LANDSCAPE_1280" />
    Dla wielu osób są to dobre wiadomości.

## Premier o "twórcach inflacji": chcą podnieść wynagrodzenia o 20 procent. Teraz podwyższa płacę minimalną
 - [https://tvn24.pl/biznes/z-kraju/premier-o-tworcach-inflacji-chca-podniesc-wynagrodzenia-o-20-procent-teraz-podwyzsza-place-minimalna-6111519?source=rss](https://tvn24.pl/biznes/z-kraju/premier-o-tworcach-inflacji-chca-podniesc-wynagrodzenia-o-20-procent-teraz-podwyzsza-place-minimalna-6111519?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 10:19:47+00:00

<img alt="Premier o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-623ze3-pap2022042508r-6111792/alternates/LANDSCAPE_1280" />
    O podwyżkach przyczyniających się do wzrostu inflacji mówił premier w kwietniu na Europejskim Kongresie Gospodarczym.

## Papież o "niewinnej ofierze" i "szczekającym NATO". To nie prorosyjskość, a niechęć do USA
 - [https://tvn24.pl/premium/papiez-franciszek-postawa-papieza-wobec-wojny-i-niechec-wobec-stanow-zjednoczonych-skad-sie-bierze-analiza-tomasza-terlikowskiego-6111280?source=rss](https://tvn24.pl/premium/papiez-franciszek-postawa-papieza-wobec-wojny-i-niechec-wobec-stanow-zjednoczonych-skad-sie-bierze-analiza-tomasza-terlikowskiego-6111280?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 09:46:17+00:00

<img alt="Papież o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qs945s-papiez-6111534/alternates/LANDSCAPE_1280" />
    Im dłużej trwa wojna w Ukrainie, tym lepiej widać, że u podstaw myślenia Franciszka leży nie tyle prorosyjskość, ile głęboko uwewnętrzniona niechęć do Stanów Zjednoczonych. To ona jest źródłem myślenia i działania papieża - pisze dla tvn24.pl publicysta Tomasz Terlikowski.

## Wyciek, sztuczna mgła, terroryści, trotyl. Jak zmieniała się narracja PiS w sprawie Tu-154M
 - [https://tvn24.pl/polska/katastrofa-smolenska-co-o-tragedii-tu-154-mowil-pis-i-prorzadowe-media-6110439?source=rss](https://tvn24.pl/polska/katastrofa-smolenska-co-o-tragedii-tu-154-mowil-pis-i-prorzadowe-media-6110439?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 09:37:38+00:00

<img alt="Wyciek, sztuczna mgła, terroryści, trotyl. Jak zmieniała się narracja PiS w sprawie Tu-154M" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jm2kf5-1209n370x-cnb-swierczek-sila-klamstwa-0005-6109603/alternates/LANDSCAPE_1280" />
    Przypominamy wypowiedzi przedstawicieli PiS, i nie tylko, na przestrzeni lat.

## Sellin: Niemcy wymyślają jakiś podatek. Nie, o tym podatku mówili też inni
 - [https://konkret24.tvn24.pl/r/sellin---niemcy-wymy-laj--jaki--podatek---nie--o-tym-podatku-m-wili-te--inni,1118489.html?source=rss](https://konkret24.tvn24.pl/r/sellin---niemcy-wymy-laj--jaki--podatek---nie--o-tym-podatku-m-wili-te--inni,1118489.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 09:32:00+00:00

<img alt="Sellin: Niemcy wymyślają jakiś podatek. Nie, o tym podatku mówili też inni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l35aaa-pap2016022606njpg/alternates/LANDSCAPE_1280" />
    Wiceminister kultury Jarosław Sellin sprzeciwia się specjalnemu podatkowi od zysków firm energetycznych.

## Grał z Barceloną, rabusie okradali jego dom
 - [https://eurosport.tvn24.pl/gra--z-barcelon---rabusie-okradali-jego-dom,1118485.html?source=rss](https://eurosport.tvn24.pl/gra--z-barcelon---rabusie-okradali-jego-dom,1118485.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 09:19:09+00:00

<img alt="Grał z Barceloną, rabusie okradali jego dom" src="https://tvn24.pl/najnowsze/cdn-zdjecie-14w53s-mueller-zakonczyl-wystep-z-barcelona-bez-gola/alternates/LANDSCAPE_1280" />
    Przykre wiadomości dla Thomasa Muellera.

## Sto osób z personelu Karola III może stracić pracę. "Wszyscy są absolutnie wściekli"
 - [https://tvn24.pl/swiat/krol-karol-iii-przenosi-sie-do-palacu-buckingham-posady-nawet-100-osob-zagrozone-6111416?source=rss](https://tvn24.pl/swiat/krol-karol-iii-przenosi-sie-do-palacu-buckingham-posady-nawet-100-osob-zagrozone-6111416?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 09:13:13+00:00

<img alt="Sto osób z personelu Karola III może stracić pracę. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2izy6y-krol-karol-ii-i-krolowa-malzonka-kamila-6106395/alternates/LANDSCAPE_1280" />
    Wśród zagrożonych pracowników są m.in. prywatne sekretarki.

## W tym kraju import rosyjskiego gazu wzrósł ponad dwukrotnie
 - [https://tvn24.pl/biznes/ze-swiata/hiszpania-gaz-ziemny-z-rosji-kraj-podwoil-w-sierpniu-import-surowca-6111269?source=rss](https://tvn24.pl/biznes/ze-swiata/hiszpania-gaz-ziemny-z-rosji-kraj-podwoil-w-sierpniu-import-surowca-6111269?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 09:05:57+00:00

<img alt="W tym kraju import rosyjskiego gazu wzrósł ponad dwukrotnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f0y8yc-madryt-5716753/alternates/LANDSCAPE_1280" />
    Dane za sierpień.

## Marszałek Witek anulowała przerwę, bo Kaczyński chciał przemówić. Wygłosił dwa zdania
 - [https://tvn24.pl/polska/jaroslaw-kaczynski-chcial-przemowic-marszalek-elzbieta-witek-wznowila-obrady-mimo-zarzadzonej-chwile-wczesniej-przerwy-6111493?source=rss](https://tvn24.pl/polska/jaroslaw-kaczynski-chcial-przemowic-marszalek-elzbieta-witek-wznowila-obrady-mimo-zarzadzonej-chwile-wczesniej-przerwy-6111493?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 09:03:53+00:00

<img alt="Marszałek Witek anulowała przerwę, bo Kaczyński chciał przemówić. Wygłosił dwa zdania" src="https://tvn24.pl/polska/cdn-zdjecie-ud99dm-kaczynski-6111522/alternates/LANDSCAPE_1280" />
    Na początku środowego posiedzenia w Sejmie wybuchła dyskusja związana z katastrofą smoleńską i podkomisją Antoniego Macierewicza.

## "Hańba na wieki". Gorąca dyskusja wokół ukrywania dowodów przez podkomisję smoleńską
 - [https://tvn24.pl/polska/reportaz-czarno-na-bialym-podkomisja-macierewicza-ukrywala-dowody-niezgodne-z-teza-o-zamachu-dyskusja-w-sejmie-z-udzialem-barbary-nowackiej-i-antoniego-macierewicza-6111477?source=rss](https://tvn24.pl/polska/reportaz-czarno-na-bialym-podkomisja-macierewicza-ukrywala-dowody-niezgodne-z-teza-o-zamachu-dyskusja-w-sejmie-z-udzialem-barbary-nowackiej-i-antoniego-macierewicza-6111477?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 08:55:47+00:00

<img alt="" src="https://tvn24.pl/polska/cdn-zdjecie-xowaag-macierewicz-6111576/alternates/LANDSCAPE_1280" />
    W Sejmie.

## Putin potrzebuje ochrony w mediach, wpływy Rosji w byłym ZSRR słabną
 - [https://tvn24.pl/swiat/rosja-wladimir-putin-amerykanscy-eksperci-propagandysci-musza-go-chronic-wplywy-rosji-w-regionie-bylego-zsrr-slabna-6111303?source=rss](https://tvn24.pl/swiat/rosja-wladimir-putin-amerykanscy-eksperci-propagandysci-musza-go-chronic-wplywy-rosji-w-regionie-bylego-zsrr-slabna-6111303?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 08:38:41+00:00

<img alt="Putin potrzebuje ochrony w mediach, wpływy Rosji w byłym ZSRR słabną" src="https://tvn24.pl/najnowsze/cdn-zdjecie-andcht-putin-w-dniu-moskwy-6107316/alternates/LANDSCAPE_1280" />
    Analiza amerykańskich ekspertów z ISW.

## Zginęła czteroosobowa rodzina, wracali z wakacji. Podejrzany o spowodowanie wypadku nie trafi do aresztu
 - [https://tvn24.pl/pomorze/emilianowo-czteroosobowa-rodzina-zginela-w-wypadku-sprawca-pozostaje-na-wolnosci-6111307?source=rss](https://tvn24.pl/pomorze/emilianowo-czteroosobowa-rodzina-zginela-w-wypadku-sprawca-pozostaje-na-wolnosci-6111307?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 08:05:52+00:00

<img alt="Zginęła czteroosobowa rodzina, wracali z wakacji. Podejrzany o spowodowanie wypadku nie trafi do aresztu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f64d7n-emilianowo-tragiczny-wypadek-na-dk10-6067901/alternates/LANDSCAPE_1280" />
    Decyzja sądu jest już ostateczna.

## Szefowa KE: Mamy nauczkę. Trzeba było się wsłuchać w głosy z Polski i krajów bałtyckich
 - [https://tvn24.pl/swiat/ursula-von-der-leyen-mamy-nauczke-trzeba-bylo-sie-wsluchac-w-glosy-z-polski-i-krajow-baltyckich-6111358?source=rss](https://tvn24.pl/swiat/ursula-von-der-leyen-mamy-nauczke-trzeba-bylo-sie-wsluchac-w-glosy-z-polski-i-krajow-baltyckich-6111358?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 07:46:42+00:00

<img alt="Szefowa KE: Mamy nauczkę. Trzeba było się wsłuchać w głosy z Polski i krajów bałtyckich" src="https://tvn24.pl/polska/cdn-zdjecie-u73sgg-ursula-von-der-leyen-6111429/alternates/LANDSCAPE_1280" />
    Ursula von der Leyen w czasie debaty o stanie Unii Europejskiej.

## Aktor Bartłomiej M. oskarżony o odurzanie i gwałty na nastolatkach
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-aktor-serialowy-bartlomiej-m-oskarzony-odurzal-i-gwalcil-nastolatki-6111308?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-aktor-serialowy-bartlomiej-m-oskarzony-odurzal-i-gwalcil-nastolatki-6111308?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 07:44:08+00:00

<img alt="Aktor Bartłomiej M. oskarżony o odurzanie i gwałty na nastolatkach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ovls38-aktor-oskarzony-o-zgwalcenie-kilku-nastolatek-6111363/alternates/LANDSCAPE_1280" />
    Mężczyźnie zarzucono między innymi dziewięć gwałtów.

## Gigant, który na parkiecie potrafi wszystko
 - [https://eurosport.tvn24.pl/gigant--kt-ry-na-parkiecie-potrafi-wszystko--polacy-zapami-taj--to-spotkanie-na-ca-e--ycie,1118432.html?source=rss](https://eurosport.tvn24.pl/gigant--kt-ry-na-parkiecie-potrafi-wszystko--polacy-zapami-taj--to-spotkanie-na-ca-e--ycie,1118432.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 06:52:12+00:00

<img alt="Gigant, który na parkiecie potrafi wszystko" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v3zbxf-luka-donczic/alternates/LANDSCAPE_1280" />
    Luka Donczić w środę stanie na drodze reprezentacji Polski w ćwierćfinale koszykarskich mistrzostw Europy.

## Zagrasz w Rosji, wylecisz z reprezentacji. Związek ostrzega
 - [https://eurosport.tvn24.pl/zagrasz-w-rosji--wylecisz-z-reprezentacji--zwi-zek-ostrzega,1118476.html?source=rss](https://eurosport.tvn24.pl/zagrasz-w-rosji--wylecisz-z-reprezentacji--zwi-zek-ostrzega,1118476.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 05:45:51+00:00

<img alt="Zagrasz w Rosji, wylecisz z reprezentacji. Związek ostrzega" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2rxvm9-reprezentacja-szwecji/alternates/LANDSCAPE_1280" />
    Szwedzkich piłkarzy.

## "Bayern ukarał Lewandowskiego". Niemcy bezlitośni
 - [https://eurosport.tvn24.pl/-bayern-ukara--lewandowskiego---niemcy-bezlito-ni,1118472.html?source=rss](https://eurosport.tvn24.pl/-bayern-ukara--lewandowskiego---niemcy-bezlito-ni,1118472.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 05:34:50+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-umbpe5-lewandowski-mial-wiele-okazji-by-wrocic-z-monachium-do-barcelony-z-golem/alternates/LANDSCAPE_1280" />
    Dziennikarze wyliczają mu niewykorzystane sytuacje. "Oszczędził swój poprzedni klub" - komentują.

## Tylko jedno zdanie do dziennikarzy. Lewandowski opuszczał stadion w pośpiechu
 - [https://eurosport.tvn24.pl/tylko-jedno-zdanie-do-dziennikarzy--lewandowski-opuszcza--stadion-w-po-piechu,1118474.html?source=rss](https://eurosport.tvn24.pl/tylko-jedno-zdanie-do-dziennikarzy--lewandowski-opuszcza--stadion-w-po-piechu,1118474.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 05:18:37+00:00

<img alt="Tylko jedno zdanie do dziennikarzy. Lewandowski opuszczał stadion w pośpiechu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oegkss-robert-lewandowski-6111189/alternates/LANDSCAPE_1280" />
    Trudno nazwać jego powrót do Monachium wymarzonym. On bez gola, Barcelona bez punktów.

## "Powinien strzelić przynajmniej jednego gola"
 - [https://eurosport.tvn24.pl/-powinien-strzeli--przynajmniej-jednego-gola---hiszpanie-ocenili-lewandowskiego,1118470.html?source=rss](https://eurosport.tvn24.pl/-powinien-strzeli--przynajmniej-jednego-gola---hiszpanie-ocenili-lewandowskiego,1118470.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 04:44:10+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tnfeee-es-skl-1jpg/alternates/LANDSCAPE_1280" />
    Hiszpanie ocenili Lewandowskiego.

## Trener Barcelony wściekły po porażce. "Byliśmy lepsi"
 - [https://eurosport.tvn24.pl/trener-barcelony-w-ciek-y-po-pora-ce---byli-my-lepsi-,1118468.html?source=rss](https://eurosport.tvn24.pl/trener-barcelony-w-ciek-y-po-pora-ce---byli-my-lepsi-,1118468.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 04:35:09+00:00

<img alt="Trener Barcelony wściekły po porażce. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nvnhec-trener-barcelony-zalowal-niewykorzystanych-sytuacji/alternates/LANDSCAPE_1280" />
    To krok w tył - podkreślił po porażce z Bayernem Xavi Hernandez.

## Czy Niemcy chcą być mocarstwem? Czeka je kolejne wyzwanie
 - [https://tvn24.pl/go/audio,14/podcast-o-zagranicy-odcinki,663543/odcinek-36,S00E36,863839?source=rss](https://tvn24.pl/go/audio,14/podcast-o-zagranicy-odcinki,663543/odcinek-36,S00E36,863839?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-14 04:00:00+00:00

<img alt="Czy Niemcy chcą być mocarstwem? Czeka je kolejne wyzwanie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fp2a5s-1409-podcast-o-zagranicy-6110323/alternates/LANDSCAPE_1280" />
    Maciej Tomaszewski rozmawia z Lidią Gibadło z Ośrodka Studiów Wschodnich.


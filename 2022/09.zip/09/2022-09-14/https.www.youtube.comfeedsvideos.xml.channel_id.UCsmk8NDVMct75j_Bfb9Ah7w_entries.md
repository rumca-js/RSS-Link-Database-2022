# Source:Virtual Reality Oasis, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsmk8NDVMct75j_Bfb9Ah7w, language:en-US

## PSVR 2 Hands On - VR Just Leveled Up!
 - [https://www.youtube.com/watch?v=PxUXWpj11fw](https://www.youtube.com/watch?v=PxUXWpj11fw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsmk8NDVMct75j_Bfb9Ah7w
 - date published: 2022-09-14 12:00:15+00:00

I got hands on with the upcoming PSVR 2 headset at an exclusive event at PlayStation's offices in London. In this video I give you my hands on first impressions of the new PSVR 2 headset along with a selection of exciting VR games coming to the PlayStation VR2 platform next year.

Follow the official PlayStation blog for the most up to date information on the upcoming PS VR2 headset;
https://blog.playstation.com

Thanks so much to PlayStation for inviting me to this exclusive event!

Let me know what you think of the PSVR 2 headset and it's features in the comments below?

Thanks for watching []-) 

Camera work by Marshall Creative Media; 
https://www.marshallcreativemedia.co.uk

Thanks for watching []-) 

VR HEADSETS:
Oculus Quest 2: https://bit.ly/3iHPFWs
Valve Index: http://bit.ly/2v8hZhi

VR ACCESSORIES:
VR Cover: https://bit.ly/3okrLmq
Mamut VR Grips: http://bit.ly/3aE3G32
Widmo Prescription Lenses: http://bit.ly/2W0BTGf
ProTube: http://bit.ly/2sujHb3

FOLLOW ME: 
Subscribe: http://bit.ly/2VeBqfJ
Memberships: http://bit.ly/2MVWxRl
Discord: https://discord.gg/NN9TGrv
Twitter: https://twitter.com/vr_oasis
Instagram: https://instagram.com/virtualrealityoasis
Facebook: https://facebook.com/virtualrealityoasis
FReality Podcast: http://bit.ly/39HdVUj
Website: http://virtualrealityoasis.com/
Email: contact@virtualrealityoasis.com

#PSVR2 #PlayStationVR2 #VR


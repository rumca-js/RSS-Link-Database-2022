# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Nie żyje Olga Simonowa. Historia Rosjanki, która walczyła dla Ukrainy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nie-zyje-olga-simonowa-historia-rosjanki-ktora-walczyla-dla-,nId,6285338](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nie-zyje-olga-simonowa-historia-rosjanki-ktora-walczyla-dla-,nId,6285338)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2022-09-14 10:44:09+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nie-zyje-olga-simonowa-historia-rosjanki-ktora-walczyla-dla-,nId,6285338"><img align="left" alt="Nie żyje Olga Simonowa. Historia Rosjanki, która walczyła dla Ukrainy" src="https://i.iplsc.com/nie-zyje-olga-simonowa-historia-rosjanki-ktora-walczyla-dla/000G2FHSUUSDG9UJ-C321.jpg" /></a>Rosyjski paszport spakowała i odesłała do Rosji. Chciała służyć Ukrainie, otrzymała obywatelstwo tego kraju i walczyła na fron

## Stolica Kazachstanu otrzyma poprzednią nazwę
 - [https://wydarzenia.interia.pl/news-stolica-kazachstanu-otrzyma-poprzednia-nazwe,nId,6285320](https://wydarzenia.interia.pl/news-stolica-kazachstanu-otrzyma-poprzednia-nazwe,nId,6285320)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2022-09-14 10:26:03+00:00

<p><a href="https://wydarzenia.interia.pl/news-stolica-kazachstanu-otrzyma-poprzednia-nazwe,nId,6285320"><img align="left" alt="Stolica Kazachstanu otrzyma poprzednią nazwę" src="https://i.iplsc.com/stolica-kazachstanu-otrzyma-poprzednia-nazwe/000G2FEO67GP9643-C321.jpg" /></a>Kazachstan przywraca poprzednią nazwę stolicy. Trzy lata temu, kiedy prezydent kraju Kasym-Żomart Tokajew objął rządy, zmienił nazwę stolicy z Astany na Nur-Sułtan na cześć swojego poprzednika. Jak przekazuje rzecznik prezy

## Nie żyje naczelny ulubionej gazety Putina. "Był w podróży"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nie-zyje-naczelny-ulubionej-gazety-putina-byl-w-podrozy,nId,6285303](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nie-zyje-naczelny-ulubionej-gazety-putina-byl-w-podrozy,nId,6285303)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2022-09-14 10:13:43+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nie-zyje-naczelny-ulubionej-gazety-putina-byl-w-podrozy,nId,6285303"><img align="left" alt="Nie żyje naczelny ulubionej gazety Putina. &quot;Był w podróży&quot;" src="https://i.iplsc.com/nie-zyje-naczelny-ulubionej-gazety-putina-byl-w-podrozy/000G2FD5VFG45GV4-C321.jpg" /></a>Jak donoszą zagraniczne media, nie żyje Władimir Sungorkin - redaktor naczelny ulubionej gazety Władimira Putina &quot;Komsomolskiej Pra


# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Accuser sues former New York Gov. Cuomo for sexual harassment and discrimination
 - [https://www.cnn.com/2022/09/14/politics/cuomo-sued-by-accuser/index.html](https://www.cnn.com/2022/09/14/politics/cuomo-sued-by-accuser/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 23:44:14+00:00

One of the first women to accuse former New York Gov. Andrew Cuomo of sexual harassment filed a federal lawsuit against him this week.

## TikTok won't commit to stopping US data flows to China
 - [https://www.cnn.com/2022/09/14/tech/tiktok-china-data/index.html](https://www.cnn.com/2022/09/14/tech/tiktok-china-data/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 23:29:34+00:00

TikTok repeatedly declined to commit to US lawmakers on Wednesday that the short-form video app will cut off flows of US user data to China, instead promising that the outcome of its negotiations with the US government "will satisfy all national security concerns."

## R. Kelly convicted of multiple child pornography and enticement charges
 - [https://www.cnn.com/2022/09/14/us/r-kelly-chicago-federal-trial/index.html](https://www.cnn.com/2022/09/14/us/r-kelly-chicago-federal-trial/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 22:51:09+00:00

R. Kelly was convicted of multiple child pornography charges at a Chicago federal trial and acquitted on others, according to the Chicago Tribune.

## Why Trump's former aide says he's 'wholly unfit' for office
 - [https://www.cnn.com/videos/politics/2022/09/14/sarah-matthews-trump-unfit-for-office-griffin-tapper-sot-lead-vpx.cnn](https://www.cnn.com/videos/politics/2022/09/14/sarah-matthews-trump-unfit-for-office-griffin-tapper-sot-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 22:17:49+00:00

President Trump's former deputy press secretary Sarah Matthews tells CNN's Jake Tapper why she believes Trump is "wholly unfit" to serve in office.

## Lawyer explains the DOJ subpoena 'blitzkrieg' ahead of midterm elections
 - [https://www.cnn.com/videos/politics/2022/09/14/mike-lindell-phone-seized-colorado-investigation-new-day-vpx.cnn](https://www.cnn.com/videos/politics/2022/09/14/mike-lindell-phone-seized-colorado-investigation-new-day-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 22:17:43+00:00

Mike Lindell, CEO of MyPillow and prominent supporter of former President Donald Trump's false voter fraud claims, said the FBI served him with a grand jury subpoena for the contents of his phone as part of an investigation into a Colorado election security breach. Dave Aronberg, State Attorney for Palm Beach County, Florida weighs in on CNN's New Day.

## Gisele Bündchen and Tom Brady are 'living separately,' source tells CNN
 - [https://www.cnn.com/2022/09/14/entertainment/tom-brady-gisele-bundchen/index.html](https://www.cnn.com/2022/09/14/entertainment/tom-brady-gisele-bundchen/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 21:14:13+00:00

Superstar couple Gisele Bündchen and Tom Brady, who wed in 2009, are going through a difficult period.

## 'You're blowing this': Book reveals Melania Trump criticized husband's handling of Covid
 - [https://www.cnn.com/2022/09/14/politics/donald-trump-book/index.html](https://www.cnn.com/2022/09/14/politics/donald-trump-book/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 21:03:28+00:00

Former President Donald Trump's top general feared he would authorize a strike on Iran as his presidency ended. His intelligence chief wondered what Russia had on him. A billionaire friend convinced him to try buying Greenland. A half-dozen top officials considered resigning en masse.

## Watch: Delivery robot rolls through crime scene
 - [https://www.cnn.com/videos/business/2022/09/14/delivery-robot-crime-scene-orig-fj.cnn-business](https://www.cnn.com/videos/business/2022/09/14/delivery-robot-crime-scene-orig-fj.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 20:29:44+00:00

Serve Robotics has teamed with several companies including Uber, Domino's and Amazon to launch a pilot program for robot delivery. When one of its robots encountered crime scene tape, it was able to sneak by with a little help from a nearby TV cameraman.

## Ryan Reynolds and Rob McElhenney get colonoscopies on camera to raise awareness
 - [https://www.cnn.com/2022/09/14/entertainment/ryan-reynolds-rob-mcelhenney-colonoscopy-video-wellness/index.html](https://www.cnn.com/2022/09/14/entertainment/ryan-reynolds-rob-mcelhenney-colonoscopy-video-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 20:15:05+00:00

It was a first for actor Ryan Reynolds, who allowed a video crew to capture his colonoscopy screening on camera to raise awareness of the increase in colon cancer diagnoses among people under 50. Colorectal cancer is the third most frequently diagnosed cancer in the United States, according to the American Cancer Society.

## Mother of three children found drowned on NYC beach charged with murder
 - [https://www.cnn.com/2022/09/14/us/brooklyn-coney-island-three-children-dead-wednesday/index.html](https://www.cnn.com/2022/09/14/us/brooklyn-coney-island-three-children-dead-wednesday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 20:13:10+00:00

The 30-year-old mother of three children found unresponsive on the Coney Island shoreline in Brooklyn has been arrested and charged in their deaths, a law enforcement official told CNN.

## 2022 Golden Goose Awards: 3 obscure scientific discoveries with outsize impact on society
 - [https://www.cnn.com/2022/09/14/world/golden-goose-science-awards-scn/index.html](https://www.cnn.com/2022/09/14/world/golden-goose-science-awards-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 20:10:53+00:00

Discoveries involving a lab accident, venomous snails and a scientific instrument made from paper are some of the obscure, quirky or convoluted advances honored Wednesday with awards that celebrate research that ultimately had a big, if unexpected, impact on society.

## Oath Keepers lawyer and federal judge in screaming match over Capitol riot case
 - [https://www.cnn.com/2022/09/14/politics/oath-keepers-judge-mehta-argument/index.html](https://www.cnn.com/2022/09/14/politics/oath-keepers-judge-mehta-argument/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 19:41:49+00:00

A conversation between a federal judge and a lawyer for one of the Oath Keepers charged with seditious conspiracy ended in a screaming match on Wednesday, when the lawyer suggested she would argue at trial that her client deleted evidence after the riot because he was directed to by another lawyer.

## End of Covid-19 pandemic is in sight, WHO chief says
 - [https://www.cnn.com/2022/09/14/health/pandemic-end-in-sight-who/index.html](https://www.cnn.com/2022/09/14/health/pandemic-end-in-sight-who/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 19:26:10+00:00

The world has never been in a better position to end the Covid-19 pandemic, Tedros Adhanom Ghebreyesus, director-general of the World Health Organization, said in a news briefing in Geneva on Wednesday.

## Former Putin aide: Russian political system in state of shock
 - [https://www.cnn.com/videos/tv/2022/09/14/amanpour-gallayamov-putin-ukraine.cnn](https://www.cnn.com/videos/tv/2022/09/14/amanpour-gallayamov-putin-ukraine.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 18:14:35+00:00

Abbas Gallyamov, who was a Putin speechwriter, predicts Russia's elites will begin looking to replace Putin within the next several months

## Observing the universe with the James Webb Space Telescope
 - [https://www.cnn.com/2022/07/12/world/gallery/james-webb-telescope-first-images-space/index.html](https://www.cnn.com/2022/07/12/world/gallery/james-webb-telescope-first-images-space/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 18:11:16+00:00

After releasing its first high-resolution images in July, the James Webb Space Telescope continues to share new images that provide unprecedented views of the universe.

## Disney's new Israeli superhero film hits a raw nerve with Arabs
 - [https://www.cnn.com/2022/09/14/middleeast/marvel-israeli-superhero-mime-intl/index.html](https://www.cnn.com/2022/09/14/middleeast/marvel-israeli-superhero-mime-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 17:33:56+00:00

The classic 1981 Marvel comic page shows the giant green Hulk, tears streaming down his face as he yells at Sabra, an Israeli superhero and agent of the country's Mossad spy agency. The corpse of a young Palestinian boy, killed in an explosion by apparently Arab "terrorists" at his feet.

## 4 ways Twitter and Musk court battle could end, explained
 - [https://www.cnn.com/videos/business/2022/09/14/twitter-elon-musk-4-court-case-scenarios-orig.cnn-business](https://www.cnn.com/videos/business/2022/09/14/twitter-elon-musk-4-court-case-scenarios-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 17:28:49+00:00

Can the Twitter whistleblower save Elon Musk from buying Twitter for $44B? Dan Ives, senior director at Wedbush Securities, explains 4 possible scenarios for how Twitter and Musk's legal battle could play out in court.

## Serena Williams teases return to competitive tennis
 - [https://www.cnn.com/2022/09/14/tennis/serena-williams-tennis-retirement-return-spt-intl/index.html](https://www.cnn.com/2022/09/14/tennis/serena-williams-tennis-retirement-return-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 15:57:47+00:00

Little more than two weeks after she was knocked out of the US Open -- a moment many thought would be the last act of her tennis career -- Serena Williams has teased her potential return to the sport.

## The MAGA-fication of the GOP is in overdrive
 - [https://www.cnn.com/2022/09/14/politics/primary-elections-maga-gop-what-matters/index.html](https://www.cnn.com/2022/09/14/politics/primary-elections-maga-gop-what-matters/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 15:41:15+00:00

The final 2022 primary elections, conducted Tuesday, saw more clear victories for the "Make America Great Again" wing of the GOP.

## Meet the winner of the London Design Festival's Emerging Talent award
 - [https://www.cnn.com/style/article/london-design-festival-emerging-talent-medal-joycelyn-longdon/index.html](https://www.cnn.com/style/article/london-design-festival-emerging-talent-medal-joycelyn-longdon/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 15:36:05+00:00

Every September, the London Design Festival spotlights a new, up-and-coming name set to make waves in the industry with its Emerging Talent Medal. Previous winners of the design award include trailblazing menswear designer Grace Wales Bonner -- whose work is currently displayed in London's Victoria and Albert Museum -- and color-obsessed artist and designer Yinka Ilori, who designed the stage and trophy for the Brit Awards last year.

## 'Every stinking time': See what got King Charles flustered
 - [https://www.cnn.com/videos/world/2022/09/14/king-charles-pesky-pens-moos-orig-bdk.cnn](https://www.cnn.com/videos/world/2022/09/14/king-charles-pesky-pens-moos-orig-bdk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 15:35:48+00:00

King Charles III gets really peeved at his pen ... "every stinking time." CNN's Jeanne Moos reports on the royal rant.

## Britney Spears wishes sons happy birthday amidst family drama
 - [https://www.cnn.com/2022/09/14/entertainment/britney-spears-sons-birthday/index.html](https://www.cnn.com/2022/09/14/entertainment/britney-spears-sons-birthday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 15:23:21+00:00

Britney Spears shared a birthday message for her estranged sons.

## US charges 3 Iranians for hacking and extortion scheme against range of US organizations
 - [https://www.cnn.com/2022/09/14/politics/us-charges-iranians-hacking/index.html](https://www.cnn.com/2022/09/14/politics/us-charges-iranians-hacking/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 15:20:55+00:00

Three Iranian nationals carried out a scheme to hack hundreds of organizations in the US and around the world, in some cases extorting them for personal monetary gain, the Justice Department alleged in an indictment unsealed on Wednesday.

## Watch Mexican navy intercept boat full of drugs
 - [https://www.cnn.com/videos/world/2022/09/14/mexico-navy-boat-drugs-lon-orig-bg.cnn](https://www.cnn.com/videos/world/2022/09/14/mexico-navy-boat-drugs-lon-orig-bg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 15:10:23+00:00

Eight people were detained and around 1,700 kilograms (3,748 pounds) of cocaine seized in a high-speed chase off the coast of Chiapas, according to Reuters.

## FBI agent gets emotional during Alex Jones defamation trial
 - [https://www.cnn.com/videos/media/2022/09/14/alex-jones-connecticut-trial-testimony-darcy-earlystart-vpx.cnn](https://www.cnn.com/videos/media/2022/09/14/alex-jones-connecticut-trial-testimony-darcy-earlystart-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 14:52:35+00:00

A Connecticut jury is set to determine how much Alex Jones will have to pay families of students killed in the 2012 Sandy Hook shooting. Jones baselessly said in the aftermath of the shooting that the incident was staged. CNN's Oliver Darcy reports.

## The Fed could crash the housing market
 - [https://www.cnn.com/2022/09/14/investing/premarket-stocks-trading/index.html](https://www.cnn.com/2022/09/14/investing/premarket-stocks-trading/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 14:50:44+00:00

Investors are getting spooked that the Federal Reserve's aggressive interest rate hikes could damage the US economy (just look at Tuesday's selloff).

## Another bad day for Senate Republicans' 2022 chances
 - [https://www.cnn.com/2022/09/14/politics/don-bolduc-new-hampshire-senate-republican/index.html](https://www.cnn.com/2022/09/14/politics/don-bolduc-new-hampshire-senate-republican/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 14:44:04+00:00



## Why Princes Harry and Andrew aren't wearing military uniforms during the Queen's funeral processions
 - [https://www.cnn.com/2022/09/14/uk/prince-harry-andrew-uniforms-queen-funeral-intl-gbr/index.html](https://www.cnn.com/2022/09/14/uk/prince-harry-andrew-uniforms-queen-funeral-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 14:39:29+00:00

Prince Harry and Prince Andrew might be the only living members of Queen Elizabeth II's immediate family to have served in the military in war time, but strict royal protocols mandate they will not be wearing a uniform during the monarch's funeral.

## Watch shark jump onto fishing boat in Maine
 - [https://www.cnn.com/videos/us/2022/09/14/shark-fishing-boat-maine-pkg-affil-ldn-vpx.wgme](https://www.cnn.com/videos/us/2022/09/14/shark-fishing-boat-maine-pkg-affil-ldn-vpx.wgme)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 14:36:32+00:00

A seven-foot mako shark shocked people on a fishing boat after it jumped on board during a search for sharks to observe and tag.

## Demi Lovato says her current tour will be her last
 - [https://www.cnn.com/2022/09/14/entertainment/demi-lovato-current-tour-last/index.html](https://www.cnn.com/2022/09/14/entertainment/demi-lovato-current-tour-last/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 14:36:11+00:00

Demi Lovato has announced that her current tour will be her last.

## PnB Rock talked about being a target shortly before he was killed
 - [https://www.cnn.com/2022/09/14/entertainment/pnb-rock-robbery-interview/index.html](https://www.cnn.com/2022/09/14/entertainment/pnb-rock-robbery-interview/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 13:54:01+00:00

Days before he was gunned down in Los Angeles, rapper PnB Rock talked about fellow artists feeling targeted for robbery.

## Queen to lie in state from today, after King Charles III follows coffin to Westminster Hall
 - [https://edition.cnn.com/uk/live-news/queen-elizabeth-westminster-news-intl/index.html](https://edition.cnn.com/uk/live-news/queen-elizabeth-westminster-news-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 13:50:34.393956+00:00

• William and Harry to join King Charles in silent procession behind Queen's coffin
• Analysis: William and Harry's show of unity for the Queen

## Here's a look at the territory reclaimed by Ukraine through its counteroffensive
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-09-14-22/index.html](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-09-14-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 13:50:34.375025+00:00



## The Queen will lie in state from today, after King Charles III follows her coffin through London
 - [https://edition.cnn.com/webview/uk/live-news/queen-elizabeth-westminster-news-intl/index.html](https://edition.cnn.com/webview/uk/live-news/queen-elizabeth-westminster-news-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 13:50:34.212627+00:00



## Zelensky visits newly liberated city of Izium in Kharkiv, following months of Russian occupation
 - [https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-09-14-22/index.html](https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-09-14-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 13:50:34.193133+00:00



## Archbishop of Canterbury describes 'huge privilege' of saying goodbye to the Queen
 - [https://www.cnn.com/videos/world/2022/09/14/archbishop-of-canterbury-ward-vpx.cnn](https://www.cnn.com/videos/world/2022/09/14/archbishop-of-canterbury-ward-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 13:49:18+00:00

CNN's Clarissa Ward caught up with the Archbishop of Canterbury ahead of Queen Elizabeth II's procession to the Palace of Westminster.

## EU proposes $140 billion windfall tax on energy companies
 - [https://www.cnn.com/2022/09/14/business/eu-energy-crisis-windfall-tax/index.html](https://www.cnn.com/2022/09/14/business/eu-energy-crisis-windfall-tax/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 13:33:59+00:00

The European Union wants to raise €140 billion ($140 billion) by tapping the windfall profits of some energy companies to help households and businesses pay eye-watering gas and electricity bills.

## McDonald's is closing all its UK restaurants Monday for the Queen's funeral
 - [https://www.cnn.com/2022/09/14/business/mcdonalds-uk-queens-funeral-closure/index.html](https://www.cnn.com/2022/09/14/business/mcdonalds-uk-queens-funeral-closure/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 13:27:53+00:00

McDonald's roughly 1,200 locations across the United Kingdom will close for most of the day Monday for Queen Elizabeth's funeral.

## Zelensky 'shocked' by destruction in newly liberated city of Izium
 - [https://www.cnn.com/2022/09/14/europe/russia-ukraine-zelensky-izium-kharkiv-intl/index.html](https://www.cnn.com/2022/09/14/europe/russia-ukraine-zelensky-izium-kharkiv-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 13:01:10+00:00

Ukrainian President Volodymyr Zelensky visited newly liberated Izium in the northeastern region of Kharkiv on Wednesday, five days after the country's forces recaptured the city.

## William Klein, photographer who brought high fashion into the streets, has died aged 96
 - [https://www.cnn.com/style/article/william-klein-fashion-photographer-death-tan/index.html](https://www.cnn.com/style/article/william-klein-fashion-photographer-death-tan/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 13:00:45+00:00

The photographer, filmmaker and multi-disciplinary artist William Klein has died aged 96, according to the International Center of Photography, where a retrospective of his work is currently on show. In a statement, the ICP said he passed away on Saturday in Paris. No cause of death was given.

## Tom Brady hints at retirement as Gisele Bündchen says she has 'concerns' about him playing
 - [https://www.cnn.com/2022/09/14/sport/tom-brady-hint-retirement-nfl-spt-intl/index.html](https://www.cnn.com/2022/09/14/sport/tom-brady-hint-retirement-nfl-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 12:53:37+00:00

Tom Brady remarked on his latest podcast appearance that he is "close to the end" of his NFL career as he continued to hint at his retirement.

## These Turkish artisans make tiles using 16th century techniques
 - [https://www.cnn.com/travel/article/iznik-tiles-turkey-spc/index.html](https://www.cnn.com/travel/article/iznik-tiles-turkey-spc/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 12:51:09+00:00



## 'The Handmaid's Tale' zeroes in on June and Serena as its end comes into view
 - [https://www.cnn.com/2022/09/14/entertainment/the-handmaids-tale-season-5-review/index.html](https://www.cnn.com/2022/09/14/entertainment/the-handmaids-tale-season-5-review/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 12:37:14+00:00

"The Handmaid's Tale" would appear to be returning at an auspicious time, as the overturning of Roe v. Wade has thrust Margaret Atwood's dystopian vision into the spotlight. But the arc of this fifth season is ill-suited to the moment, more narrowly focused on the bond of hatred between June and Serena, at the expense of almost everything else.

## What the Queen's death means for tourists to the UK right now
 - [https://www.cnn.com/travel/article/queen-elizabeth-death-london-tourists/index.html](https://www.cnn.com/travel/article/queen-elizabeth-death-london-tourists/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 12:35:56+00:00

The death of Queen Elizabeth II, the longest-reigning monarch in British history, has led to astonishing scenes in the UK.

## Analysis: William and Harry's show of unity for the Queen
 - [https://www.cnn.com/2022/09/14/uk/royal-news-newsletter-09-14-22-scli-gbr-cmd-intl/index.html](https://www.cnn.com/2022/09/14/uk/royal-news-newsletter-09-14-22-scli-gbr-cmd-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 11:54:28+00:00

Two brothers reunited in grief. Royal-watchers have been relieved to see the Prince of Wales and the Duke of Sussex standing side-by-side once more as they mourn the death of their beloved grandmother.

## Women describe life under Russian occupation for six months
 - [https://www.cnn.com/videos/world/2022/09/14/ukraine-liberated-residents-respond-pkg-bell-ovn-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2022/09/14/ukraine-liberated-residents-respond-pkg-bell-ovn-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 11:53:19+00:00

More than 300 Ukrainian villages and towns have been liberated in four days of Ukraine's counteroffensive, according to Ukrainian officials. CNN's Melissa Bell speaks to residents about their experiences under Russia's six-month occupation.

## Champions League: Mixed fortunes for English teams as Liverpool snatches victory, but Tottenham loses late
 - [https://www.cnn.com/2022/09/14/football/liverpool-ajax-tottenham-sporting-champions-league-spt-intl/index.html](https://www.cnn.com/2022/09/14/football/liverpool-ajax-tottenham-sporting-champions-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 11:12:49+00:00

Liverpool secured a much-needed victory as Joel Matip's late header against Ajax earned Jurgen Klopp's side a 2-1 win and its first three points of the Champions League campaign.

## Xi Jinping arrives in Central Asia in first trip outside China since pandemic
 - [https://www.cnn.com/2022/09/14/china/china-xi-kazakhstan-central-asia-trip-intl-hnk/index.html](https://www.cnn.com/2022/09/14/china/china-xi-kazakhstan-central-asia-trip-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 11:06:58+00:00

Chinese leader Xi Jinping has arrived in Central Asia in his first overseas trip in almost 1,000 days, returning to the world stage in an attempt to reassert Beijing's global influence during a time of increased friction with the West.

## Study finds potential link between daily multivitamin and improved cognition in older adults
 - [https://www.cnn.com/2022/09/14/health/daily-multivitamin-cognitive-function-study-wellness/index.html](https://www.cnn.com/2022/09/14/health/daily-multivitamin-cognitive-function-study-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 11:00:38+00:00

Taking a daily multivitamin might be associated with improved brain function in older adults, a new study says, and the benefit appears to be greater for those with a history of cardiovascular disease.

## A'Ja Wilson powers Las Vegas Aces past Connecticut Sun, 85-71, to close in on first WNBA title
 - [https://www.cnn.com/2022/09/14/sport/las-vegas-aces-connecticut-sun-wnba-finals-game-2-spt-intl/index.html](https://www.cnn.com/2022/09/14/sport/las-vegas-aces-connecticut-sun-wnba-finals-game-2-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 10:54:48+00:00

The Las Vegas Aces moved one win away from securing the franchise's first WNBA title with a 85-71 victory over the Connecticut Sun on Tuesday in Nevada.

## William and Harry to join King Charles in silent procession behind Queen's coffin
 - [https://www.cnn.com/2022/09/14/uk/queen-elizabeth-silent-procession-intl-gbr/index.html](https://www.cnn.com/2022/09/14/uk/queen-elizabeth-silent-procession-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 10:51:34+00:00

Queen Elizabeth II's coffin is set to move in a silent procession from Buckingham Palace to Westminster Hall in central London on Wednesday, where it will lie in state until her funeral.

## Extreme weather could push food prices even higher
 - [https://www.cnn.com/2022/09/14/economy/heat-inflation-economy-drought/index.html](https://www.cnn.com/2022/09/14/economy/heat-inflation-economy-drought/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 10:44:40+00:00

Weather has long been a fickle farmhand, devastating fields one year while delivering bountiful harvests the next.

## Google loses appeal against record $4 billion EU fine
 - [https://www.cnn.com/2022/09/14/tech/google-loses-eu-fine-appeal/index.html](https://www.cnn.com/2022/09/14/tech/google-loses-eu-fine-appeal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 10:07:22+00:00

Google suffered one of its biggest setbacks on Wednesday when a top European court fined it 4.125 billion euros ($4.13 billion) for using its Android mobile operating system to thwart rivals, offering a precedent for other regulators to ratchet up pressure.

## Seven takeaways from the 2022 primary season
 - [https://www.cnn.com/2022/09/14/politics/midterm-primaries-2022-takeaways/index.html](https://www.cnn.com/2022/09/14/politics/midterm-primaries-2022-takeaways/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 10:00:15+00:00

Voting in the 2022 midterm primaries is over. The countdown to Election Day is on. And after a year of factional clashes within both parties, Democrats and Republicans are now focused on each other -- and scores of hotly contested races up and down the ballot that could reshape the American political landscape.

## US sets up fund that could transfer frozen billions to Afghanistan if conditions are met
 - [https://www.cnn.com/2022/09/14/politics/afghan-funds-biden-administration/index.html](https://www.cnn.com/2022/09/14/politics/afghan-funds-biden-administration/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 09:09:30+00:00

The Biden administration has worked with Switzerland and Afghan economists to set up a new fund that could eventually serve as a mechanism to put billions of dollars in frozen Afghan money to use to promote economic stability in the country, according to two senior US officials.

## Oleksandr Usyk: Boxing world champion shares images from family home in Ukrainian area previously held by Russians
 - [https://www.cnn.com/2022/09/14/sport/oleksandr-usyk-ukraine-house-photos-spt-intl/index.html](https://www.cnn.com/2022/09/14/sport/oleksandr-usyk-ukraine-house-photos-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 09:08:44+00:00

Oleksandr Usyk has shared photos of himself at his family home in Ukraine -- the first time the boxing world champion has explicitly posted from Vorzel, near Bucha, since the house was taken by Russian forces earlier this year.

## US returns 'exceedingly rare' coin worth $1 million to Israel
 - [https://www.cnn.com/style/article/quarter-shekel-coin-returned-israel/index.html](https://www.cnn.com/style/article/quarter-shekel-coin-returned-israel/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 08:55:52+00:00

A coin dating back to a Jewish rebellion against Roman rule almost 2,000 years ago has been returned by the US to Israel following a joint smuggling investigation.

## Barcelona left to rue missed chances as Bayern Munich comes out on top 2-0 in Champions League clash
 - [https://www.cnn.com/2022/09/14/football/bayern-munich-barcelona-champions-league-spt-intl/index.html](https://www.cnn.com/2022/09/14/football/bayern-munich-barcelona-champions-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 08:37:00+00:00

For eight seasons, Bayern Munich fans had become accustomed to watching Robert Lewandowski find the back of the net on almost a weekly basis.

## Photographer captures the unseen side of Dubai
 - [https://www.cnn.com/travel/gallery/photographer-nostalgia-dubai-now-spc-intl/index.html](https://www.cnn.com/travel/gallery/photographer-nostalgia-dubai-now-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 08:24:39+00:00

Many photographers choose to illustrate the luxury and scale that Dubai is known for, but Preet Uday shows a different side of the city.

## How to live without chronic back pain, according to an expert
 - [https://www.cnn.com/2022/09/14/health/chronic-back-pain-prevention-wellness/index.html](https://www.cnn.com/2022/09/14/health/chronic-back-pain-prevention-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 08:20:36+00:00

Too often, after fruitless searches for a single magic bullet to eradicate chronic back pain, people decide that living with discomfort is a normal fact of life. But living with back pain is not normal, nor is it necessary. This last installment in our back pain series will empower you to create your own, personalized long-term strategy for maintaining back health and living an active, pain-free lifestyle.

## This photographer shows a Dubai you've never seen before
 - [https://www.cnn.com/travel/article/photographer-nostalgia-dubai-now-spc-intl/index.html](https://www.cnn.com/travel/article/photographer-nostalgia-dubai-now-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 07:59:45+00:00

With their cornflower blues, candy floss pinks, and pumpkin oranges, photographer Preet Uday's images of Dubai conjure a bittersweet nostalgia.

## In memory of Queen Elizabeth II
 - [https://www.cnn.com/collections/elizabeth-ii-video-collection/](https://www.cnn.com/collections/elizabeth-ii-video-collection/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 07:57:10+00:00



## Man arrested after climbing through airport baggage carousel
 - [https://www.cnn.com/videos/us/2022/09/14/airport-baggage-arrest-orig-llr.cnn](https://www.cnn.com/videos/us/2022/09/14/airport-baggage-arrest-orig-llr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 04:37:01+00:00

Surveillance and bodycam video show a man entering the Cleveland Hopkins International Airport baggage carousel and into a restricted area.

## Putin needs Xi Jinping's help more than ever after his setbacks in Ukraine
 - [https://www.cnn.com/2022/09/14/asia/putin-xi-help-uzbekistan-summit-intl-cmd/index.html](https://www.cnn.com/2022/09/14/asia/putin-xi-help-uzbekistan-summit-intl-cmd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 04:29:03+00:00

In early February, Russian President Vladimir Putin touched down in Beijing to a warm welcome from Chinese leader Xi Jinping, as the two strongmen put on a show of unity for the world at the Winter Olympics.

## Biden's victory lap marred by stock slump on inflation fears
 - [https://www.cnn.com/2022/09/14/politics/biden-victory-lap-inflation-fears-analysis/index.html](https://www.cnn.com/2022/09/14/politics/biden-victory-lap-inflation-fears-analysis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 04:11:26+00:00

It was an unfortunate moment for Joe Biden to be celebrating.

## RAF plane carrying Queen Elizabeth's coffin sets all-time flight tracking record
 - [https://www.cnn.com/travel/article/queen-elizabeth-raf-plane-most-tracked-flight-ever/index.html](https://www.cnn.com/travel/article/queen-elizabeth-raf-plane-most-tracked-flight-ever/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 03:41:30+00:00

The plane carrying Queen Elizabeth II's coffin has broken records to become the most-tracked flight ever.

## Analysis: The curtain protecting the dignity of Russia's military has been pulled back
 - [https://www.cnn.com/2022/09/13/europe/russia-kharkiv-withdrawal-analysis-npw-intl/index.html](https://www.cnn.com/2022/09/13/europe/russia-kharkiv-withdrawal-analysis-npw-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 02:51:17+00:00

The tsar suddenly might have no clothes. It has been a startling week on both sides of the Ukraine and Russia border.

## Australia is asking its people one question and it's not whether to keep the King
 - [https://www.cnn.com/2022/09/13/australia/australia-queen-king-republic-referendum-intl-hnk-dst/index.html](https://www.cnn.com/2022/09/13/australia/australia-queen-king-republic-referendum-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 02:23:58+00:00

• Prince William inherits 685-year-old estate worth $1 billion
• Video: Former New Zealand PM on the major hurdle for country to become a republic

## Royals had dinner together at Buckingham Palace
 - [https://www.cnn.com/2022/09/13/europe/royals-dine-together-buckingham-palace-intl/index.html](https://www.cnn.com/2022/09/13/europe/royals-dine-together-buckingham-palace-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 02:09:36+00:00

The Royal family had dinner together at Buckingham Palace on Tuesday after receiving the Queen's coffin, a source exclusively told CNN.

## Prince William: From 'heartthrob' to first in line to the throne
 - [https://www.cnn.com/videos/world/2022/09/14/prince-william-wales-throne-kate-middleton-journey-ac360-foster-pkg-vpx.cnn](https://www.cnn.com/videos/world/2022/09/14/prince-william-wales-throne-kate-middleton-journey-ac360-foster-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 02:01:34+00:00

When King Charles III ascended to the throne, he announced his son William will be given the title of Prince of Wales. CNN's Max Foster shows us the evolution of the first in line to the British throne.

## Australia is asking its people one question and it's not whether to keep the King
 - [https://www.cnn.com/collections/int-0914-queen/](https://www.cnn.com/collections/int-0914-queen/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 01:46:33+00:00



## The still-blinding whiteness of tennis
 - [https://www.cnn.com/2022/09/13/opinions/black-athletes-tennis-sports-tiafoe-edwards/index.html](https://www.cnn.com/2022/09/13/opinions/black-athletes-tennis-sports-tiafoe-edwards/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 01:45:25+00:00

If you watched Frances Tiafoe play at the US Open last week in hopes of seeing the next chapter in the evolution of a gifted tennis talent, then you were richly rewarded. But if you were looking for evidence of efforts by officials in the sport to ensure that there are more Tiafoes who follow in his footsteps, you may have to keep waiting.

## Congressional commission recommends the US Navy rename two ships with names tied to the Confederacy
 - [https://www.cnn.com/2022/09/13/politics/us-navy-ships-rename-uss-chancellorsville-usns-maury/index.html](https://www.cnn.com/2022/09/13/politics/us-navy-ships-rename-uss-chancellorsville-usns-maury/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 01:30:15+00:00

The US Congressional Naming Commission is recommending the US Navy rename two ships whose names have ties to the Confederacy: the USS Chancellorsville and the USNS Maury, commissioners said Tuesday.

## Three January 6 rioters charged in assault on officers found guilty of multiple offenses
 - [https://www.cnn.com/2022/09/13/politics/january-6-rioters-guilty-felony/index.html](https://www.cnn.com/2022/09/13/politics/january-6-rioters-guilty-felony/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 01:14:55+00:00

Three January 6, 2021, rioters involved in one of the most brutal assaults on police during the attack at the US Capitol were found guilty on Tuesday of several felonies following a bench trial before a federal judge.

## Russian businessman's body found in latest mysterious death
 - [https://www.cnn.com/2022/09/13/business/ivan-pechorin-death-russia-intl/index.html](https://www.cnn.com/2022/09/13/business/ivan-pechorin-death-russia-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 00:00:23+00:00

Russian businessman Ivan Pechorin, the top manager for the Corporation for the Development of the Far East and the Arctic, has been found dead in Vladivostok, the latest in a string of mysterious deaths among Russian executives.

## The Fed's war on inflation may take the US economy down with it
 - [https://www.cnn.com/2022/09/13/business/nightcap-inflation-economy-fed/index.html](https://www.cnn.com/2022/09/13/business/nightcap-inflation-economy-fed/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-09-14 00:00:14+00:00

Tuesday's inflation reading wasn't what anyone was hoping for.


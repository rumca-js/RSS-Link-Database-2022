# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Wuthering Waves is an Open-World ARPG with an emphasis on the action
 - [https://www.pcgamer.com/wuthering-waves-is-an-open-world-arpg-with-an-emphasis-on-the-action](https://www.pcgamer.com/wuthering-waves-is-an-open-world-arpg-with-an-emphasis-on-the-action)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-15 00:00:00+00:00

Dive into this open-world ARPG set in a vast and mysterious post-apocalyptic world.

## I'm shocked how quickly I became a murderous opium addict in this saloon management sim
 - [https://www.pcgamer.com/im-shocked-how-quickly-i-became-a-murderous-opium-addict-in-this-saloon-management-sim](https://www.pcgamer.com/im-shocked-how-quickly-i-became-a-murderous-opium-addict-in-this-saloon-management-sim)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 23:30:16+00:00

One minute I'm serving firewater and squirrel soup, the next I'm huffing the midnight oil and trying to clip a shopkeeper.

## Welp, the Cyberpunk 2077 anime made me want to give the game another shot
 - [https://www.pcgamer.com/welp-the-cyberpunk-2077-anime-made-me-want-to-give-the-game-another-shot](https://www.pcgamer.com/welp-the-cyberpunk-2077-anime-made-me-want-to-give-the-game-another-shot)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 22:29:51+00:00

Cyberpunk: Edgerunners is stylish and gory, but also a surprisingly compelling gutter-level view of Night City.

## Overwatch loot box hoarders say goodbye
 - [https://www.pcgamer.com/overwatch-loot-box-hoarders-say-goodbye](https://www.pcgamer.com/overwatch-loot-box-hoarders-say-goodbye)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 22:28:52+00:00

Players held unboxing streams to send off Overwatch's controversial monetization system.

## The best PC joysticks in 2022
 - [https://www.pcgamer.com/the-best-pc-joysticks](https://www.pcgamer.com/the-best-pc-joysticks)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 22:27:55+00:00

The best PC joysticks take you to new heights.

## Best mouse pads for gaming in 2022
 - [https://www.pcgamer.com/best-mouse-pad-for-gaming](https://www.pcgamer.com/best-mouse-pad-for-gaming)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 22:13:24+00:00

The best mouse pads offer pinpoint control and awesome aesthetics, no matter what surface you prefer.

## Hackers are improving phishing attacks by having you chat with 'sock puppets'
 - [https://www.pcgamer.com/hackers-are-improving-phishing-attacks-by-having-you-chat-with-sock-puppets](https://www.pcgamer.com/hackers-are-improving-phishing-attacks-by-having-you-chat-with-sock-puppets)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 22:09:21+00:00

Now would be a good time to brush up on your phishing training.

## The best gaming TV in 2022
 - [https://www.pcgamer.com/best-4k-tv-for-gaming](https://www.pcgamer.com/best-4k-tv-for-gaming)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 22:04:39+00:00

Grab the best gaming TV and immerse yourself in the big-screen PC experience.

## Call of Duty: Modern Warfare 2 beta dates and times
 - [https://www.pcgamer.com/modern-warfare-2-beta-access](https://www.pcgamer.com/modern-warfare-2-beta-access)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 21:57:35+00:00

The Modern Warfare 2 beta starts at the end of September for PC players.

## Best capture cards for PC gaming
 - [https://www.pcgamer.com/best-capture-card-for-pc-gaming](https://www.pcgamer.com/best-capture-card-for-pc-gaming)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 21:54:07+00:00

Show off your greatest gaming moments with the best capture cards.

## It's almost impossible not to laugh when you see this guy snipe someone with a flute in Warzone
 - [https://www.pcgamer.com/warzone-flute-clip](https://www.pcgamer.com/warzone-flute-clip)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 20:07:39+00:00

It's instantly obvious how this 20 second Call of Duty clip will end, but it doesn't matter.

## Huh, Hideo Kojima announced a VR game
 - [https://www.pcgamer.com/huh-hideo-kojima-announced-a-vr-game](https://www.pcgamer.com/huh-hideo-kojima-announced-a-vr-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 19:07:22+00:00

Apparently it will make you look out of a window with a headset on.

## What's the Nightfall weapon this week in Destiny 2?
 - [https://www.pcgamer.com/destiny-2-nightfall-weapon-this-week](https://www.pcgamer.com/destiny-2-nightfall-weapon-this-week)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 17:32:01+00:00

Complete the latest Nightfall Strike to claim its unique gun.

## Why Destiny 2's 'elites' vs 'casuals' balance drama missed the point
 - [https://www.pcgamer.com/why-destiny-2s-elites-vs-casuals-balance-drama-missed-the-point](https://www.pcgamer.com/why-destiny-2s-elites-vs-casuals-balance-drama-missed-the-point)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 17:24:20+00:00

The reaction to a raid champ's Divinity take showed there's a long way to go before players of different skill levels understand each other.

## You'll soon be able to play The Sims 4 for free
 - [https://www.pcgamer.com/youll-soon-be-able-to-play-the-sims-4-for-free](https://www.pcgamer.com/youll-soon-be-able-to-play-the-sims-4-for-free)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 16:55:55+00:00

It's just the base game, but it's a surprise move from EA.

## How to wield godly power with Valheim cheats and console commands
 - [https://www.pcgamer.com/valheim-cheats-console-commands](https://www.pcgamer.com/valheim-cheats-console-commands)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 16:47:05+00:00

These Valheim cheats let you enable god mode, build without workbenches, and more.

## Rebuild civilisation on the back of a giant dinosaur in The Wandering Village
 - [https://www.pcgamer.com/rebuild-civilisation-on-the-back-of-a-giant-dinosaur-in-the-wandering-village](https://www.pcgamer.com/rebuild-civilisation-on-the-back-of-a-giant-dinosaur-in-the-wandering-village)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 16:27:00+00:00

This one certainly lives up to the name.

## After killing internet forums, Discord is bringing them back
 - [https://www.pcgamer.com/after-killing-internet-forums-discord-is-bringing-them-back](https://www.pcgamer.com/after-killing-internet-forums-discord-is-bringing-them-back)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 15:59:03+00:00

Forum Channels close the loop on Discord's forum takeover.

## Samsung QN90B Neo QLED
 - [https://www.pcgamer.com/samsung-qn90b-neo-qled](https://www.pcgamer.com/samsung-qn90b-neo-qled)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 14:53:19+00:00

The best non-OLED gaming TV out there.

## COD Modern Warfare 2 wants your phone number before you can play on PC
 - [https://www.pcgamer.com/cod-modern-warfare-2-wants-your-phone-number-before-you-can-play-on-pc](https://www.pcgamer.com/cod-modern-warfare-2-wants-your-phone-number-before-you-can-play-on-pc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 14:09:43+00:00

Operator?

## Yakuza spin-offs Judgment and Lost Judgment just released on Steam
 - [https://www.pcgamer.com/yakuza-spin-offs-judgment-and-lost-judgment-just-released-on-steam](https://www.pcgamer.com/yakuza-spin-offs-judgment-and-lost-judgment-just-released-on-steam)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 13:32:54+00:00

The games see you play a grizzled PI instead of an honourable gangster.

## Wil Wheaton is trying to become a god in Star Trek Online
 - [https://www.pcgamer.com/wil-wheaton-is-trying-to-become-a-god-in-star-trek-online](https://www.pcgamer.com/wil-wheaton-is-trying-to-become-a-god-in-star-trek-online)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 12:56:35+00:00

Shut up, Wesley!

## Star Wars Galaxies revival approaches 1.0 with a 'secretive Jedi unlock system'
 - [https://www.pcgamer.com/star-wars-galaxies-revival-approaches-10-with-a-secretive-jedi-unlock-system](https://www.pcgamer.com/star-wars-galaxies-revival-approaches-10-with-a-secretive-jedi-unlock-system)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 12:30:00+00:00

"You must unlearn what you have learned."

## Like A Dragon Gaiden: The Man Who Erased His Name will tell Kiryu's story between Yakuza 6 and 8
 - [https://www.pcgamer.com/like-a-dragon-gaiden-the-man-who-erased-his-name-will-tell-kiryus-story-between-yakuza-6-and-8](https://www.pcgamer.com/like-a-dragon-gaiden-the-man-who-erased-his-name-will-tell-kiryus-story-between-yakuza-6-and-8)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 12:25:11+00:00

The trailer shows Kiryu getting hit with sticks in a monastery, which seems like a bad way to spend a game.

## Yakuza 8's first official trailer reveals Kiryu, Ichiban, and that it's not called Yakuza 8
 - [https://www.pcgamer.com/yakuza-8s-first-official-trailer-reveals-kiryu-ichiban-and-that-its-not-called-yakuza-8](https://www.pcgamer.com/yakuza-8s-first-official-trailer-reveals-kiryu-ichiban-and-that-its-not-called-yakuza-8)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 11:36:44+00:00

Devs say the game will explore the theme of Kiryu's past and Ichiban's future.

## Chairman of FromSoftware's parent company arrested in Olympic bribery case
 - [https://www.pcgamer.com/chairman-of-fromsoftwares-parent-company-arrested-in-olympic-bribery-case](https://www.pcgamer.com/chairman-of-fromsoftwares-parent-company-arrested-in-olympic-bribery-case)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 10:26:30+00:00

Prosecutors suspect the chairman of handing out millions of yen for preferential treatment by Olympic organisers.

## Today's Wordle 452 answer and hint: Wednesday, September 14
 - [https://www.pcgamer.com/todays-wordle-452-answer-hint](https://www.pcgamer.com/todays-wordle-452-answer-hint)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 07:01:28+00:00

Wordle today: The solution and a hint for Wednesday's puzzle.

## Google scraps its Pixelbook laptop range
 - [https://www.pcgamer.com/google-scraps-its-pixelbook-laptop-range](https://www.pcgamer.com/google-scraps-its-pixelbook-laptop-range)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 03:17:01+00:00

No more Google laptops?

## Exclusive Magic: The Gathering Warhammer 40,000 card reveal: Keeper of Secrets
 - [https://www.pcgamer.com/exclusive-magic-the-gathering-warhammer-40000-card-reveal-keeper-of-secrets](https://www.pcgamer.com/exclusive-magic-the-gathering-warhammer-40000-card-reveal-keeper-of-secrets)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-14 01:46:27+00:00

The Lost and the Damned.


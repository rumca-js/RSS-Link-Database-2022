# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## The Secret New Windows Tool Nobody Is Talking About
 - [https://www.youtube.com/watch?v=--cHILkVUtw](https://www.youtube.com/watch?v=--cHILkVUtw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-09-15 00:00:00+00:00

Thanks to Mine for Sponsoring: Find out which companies have your data and reclaim it 😤 by visiting ⇨ https://bit.ly/ThioJoeSayMine

Here is the text version of the flow I made: https://files.thiojoe.com/Flow_Check_MS_Store.txt
Power Automate in the Microsoft Store: https://apps.microsoft.com/store/detail/power-automate/9NFTCH6J7FHV

▼ Time Stamps: ▼
0:00 - Intro
2:42 - What I Wanted to Do
3:13 - Explaining the Interface
3:53 - How My Flow Works
6:00 - Making It Even More Advanced
6:36 - Dumb Things About It
7:36 - Final Notes

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


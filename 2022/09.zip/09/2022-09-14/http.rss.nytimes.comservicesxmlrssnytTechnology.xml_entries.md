# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Lawmakers Grill TikTok Executive About Ties to China
 - [https://www.nytimes.com/2022/09/14/technology/tiktok-china-senate.html](https://www.nytimes.com/2022/09/14/technology/tiktok-china-senate.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-14 22:53:07+00:00

TikTok’s chief operating officer, Vanessa Pappas, faced questions about whether the company would ever hand over user data to Chinese officials.

## California Files Antitrust Lawsuit Against Amazon
 - [https://www.nytimes.com/2022/09/14/technology/california-files-antitrust-lawsuit-against-amazon.html](https://www.nytimes.com/2022/09/14/technology/california-files-antitrust-lawsuit-against-amazon.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-14 18:09:03+00:00

Rob Bonta, California’s attorney general, said the retailer punishes companies that offer lower prices on other websites.

## E.U. Scores Major Legal Victory Against Google
 - [https://www.nytimes.com/2022/09/14/business/eu-google-antitrust-fine.html](https://www.nytimes.com/2022/09/14/business/eu-google-antitrust-fine.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-14 10:32:21+00:00

A court rejected Google’s appeal of a record-setting antitrust fine related to Android and online search.

## How a Spreader of Voter Fraud Conspiracy Theories Became a Star
 - [https://www.nytimes.com/2022/09/14/technology/catherine-engelbrecht-voter-fraud-conspiracy-theories.html](https://www.nytimes.com/2022/09/14/technology/catherine-engelbrecht-voter-fraud-conspiracy-theories.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-14 09:00:42+00:00

For more than a decade, Catherine Engelbrecht, a Texas mom turned election-fraud crusader, has sown doubts about ballots and voting. Her patience has paid off.

## Text Messaging Is Cool. But Where Are Its Boundaries?
 - [https://www.nytimes.com/2022/09/14/technology/personaltech/texting-ios-android.html](https://www.nytimes.com/2022/09/14/technology/personaltech/texting-ios-android.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-14 09:00:24+00:00

Apple and Google have added useful features to texting apps, yet the apps still lack a major component: an effective way to set limits.


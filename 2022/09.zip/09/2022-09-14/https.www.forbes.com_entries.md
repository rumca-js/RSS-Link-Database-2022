## Disney’s ‘Little Mermaid’ Backlash Has Reached Insane Heights
 - [https://www.forbes.com/sites/danidiplacido/2022/09/14/disneys-little-mermaid-backlash-has-reached-insane-heights/](https://www.forbes.com/sites/danidiplacido/2022/09/14/disneys-little-mermaid-backlash-has-reached-insane-heights/)
 - RSS feed: https://www.forbes.com
 - date published: 2022-09-14 08:05:23+00:00

Disney’s ‘Little Mermaid’ Backlash Has Reached Insane Heights


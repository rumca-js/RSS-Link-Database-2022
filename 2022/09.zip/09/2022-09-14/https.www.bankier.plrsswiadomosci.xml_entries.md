# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## PO proponuje: zamiast wydłużać kadencję samorządów, skrócić kadencję Sejmu
 - [https://www.bankier.pl/wiadomosc/PO-proponuje-zamiast-wydluzac-kadencje-samorzadow-skrocic-kadencje-Sejmu-8406103.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PO-proponuje-zamiast-wydluzac-kadencje-samorzadow-skrocic-kadencje-Sejmu-8406103.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 21:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/0d21443520da33-948-568-10-130-3990-2393.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zamiast wydłużać kadencję samorządów należałoby skrócić kadencję Sejmu i przeprowadzić wybory parlamentarne wiosną 2023 roku, wcześniej odszedłby skompromitowany rząd - mówił w środę szef klubu KO Borys Budka.</p>

## Na Wall Street niewielkie odreagowanie po wtorkowej wyprzedaży
 - [https://www.bankier.pl/wiadomosc/Na-Wall-Street-niewielie-odreagowanie-po-wtorkowej-wyprzedazy-8406097.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Na-Wall-Street-niewielie-odreagowanie-po-wtorkowej-wyprzedazy-8406097.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 21:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/1/17a8bdf702b3ff-948-568-115-250-1885-1130.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Środowa sesja na Wall Street przyniosła niewielkie odreagowanie po mocnej wyprzedaży dzień wcześniej, kiedy główne indeksy potraciły po 4-5 proc. </p>

## Portugalia dzięki tzw. złotym wizom zyskała blisko 6,5 mld euro
 - [https://www.bankier.pl/wiadomosc/Portugalia-dzieki-tzw-zlotym-wizom-zyskala-blisko-6-5-mld-euro-8406059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Portugalia-dzieki-tzw-zlotym-wizom-zyskala-blisko-6-5-mld-euro-8406059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 18:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/1/216a34faf8288a-948-568-0-60-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wydawane od blisko dekady przez władze Portugalii tzw. złote wizy przyniosły temu krajowi wpływy na poziomie prawie 6,5 mld euro - oszacowało ministerstwo spraw wewnętrznych w Lizbonie. Od 2012 r. uzyskało je ponad 11 tys. osób. - podano.</p>

## Wniosek o wypłatę dodatku energetycznego. Jest projekt i wzór
 - [https://www.bankier.pl/wiadomosc/Wniosek-o-wyplate-dodatku-energetycznego-wzor-8406051.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wniosek-o-wyplate-dodatku-energetycznego-wzor-8406051.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 18:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/cae2c9ea4106fc-945-560-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W środę na stronach Rządowego Centrum Legislacji (RCL) opublikowano projekt rozporządzenia ze wzorem wniosku o wypłatę dodatku energetycznego. Dodatek będą mogli otrzymać ogrzewający swoje domy m.in. drewnem, LPG, czy olejem opałowym.</p>

## Enea miała w II kw. 244,1 mln zł zysku netto j.d., zgodnie z szacunkami
 - [https://www.bankier.pl/wiadomosc/Enea-miala-w-II-kw-244-1-mln-zl-zysku-netto-j-d-zgodnie-z-szacunkami-opis-8406041.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Enea-miala-w-II-kw-244-1-mln-zl-zysku-netto-j-d-zgodnie-z-szacunkami-opis-8406041.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 18:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/2/33be7fa2284af7-945-567-45-562-3093-1856.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa Enea miała w drugim kwartale 2022 roku 244,1 mln zł zysku netto jednostki dominującej oraz 7,465 mld zł przychodów - podała spółka w raporcie półrocznym. Wyniki są zgodne z wcześniejszymi szacunkami.</p>

## Szefowa MFW: Sroga zima może doprowadzić do niepokojów społecznych w Europie
 - [https://www.bankier.pl/wiadomosc/Szefowa-MFW-Sroga-zima-moze-doprowadzic-do-niepokojow-spolecznych-w-Europie-8406014.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szefowa-MFW-Sroga-zima-moze-doprowadzic-do-niepokojow-spolecznych-w-Europie-8406014.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 17:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/c/95876f2fc6f264-948-568-20-0-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sroga zima może doprowadzić do niepokojów społecznych w Europie, gdzie inwazja Rosji na Ukrainę już doprowadziła do "strasznych" konsekwencji gospodarczych i podsyca obawy przed recesją - oświadczyła w środę szefowa Międzynarodowego Funduszu Walutowego Kristalina Georgiewa.</p

## Ropa w środę wieczorem drożała o blisko 2 proc.
 - [https://www.bankier.pl/wiadomosc/Ropa-w-srode-wieczorem-drozala-o-blisko-2-proc-8406009.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ropa-w-srode-wieczorem-drozala-o-blisko-2-proc-8406009.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 17:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/2/39a28fc8a9bb02-948-568-10-270-3983-2390.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W środę wieczorem ropa Brent drożała o blisko 2 proc. i była wyceniana na blisko 95 dol. za baryłkę. O ponad 2 proc. rosły także walory ropy WTI, która kosztowała ponad 89 dol.</p>

## USA ogłosiły ustanowienie specjalnego funduszu dla Afganistanu
 - [https://www.bankier.pl/wiadomosc/USA-oglosily-ustanowienie-specjalnego-funduszu-dla-Afganistanu-8406000.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-oglosily-ustanowienie-specjalnego-funduszu-dla-Afganistanu-8406000.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 17:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/c/489be029eab24b-948-568-0-11-2200-1319.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Administracja USA wraz ze szwajcarskimi władzami ogłosiła w środę utworzenie specjalnego funduszu dla Afganistanu z pieniędzy skonfiskowanych z afgańskiego banku centralnego DAB. Pieniądze - 3,5 mld dolarów - mają być przeznaczone m.in. na spłatę długów oraz import prądu i klu

## Sejm w uchwale wzywa Niemcy do przyjęcia odpowiedzialności za skutki rozpętania II wojny światowej
 - [https://www.bankier.pl/wiadomosc/Sejm-w-uchwale-wzywa-Niemcy-do-przyjecia-odpowiedzialnosci-za-skutki-rozpetania-II-wojny-swiatowej-8405999.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sejm-w-uchwale-wzywa-Niemcy-do-przyjecia-odpowiedzialnosci-za-skutki-rozpetania-II-wojny-swiatowej-8405999.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 17:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/5/fd1a00d8cd3651-948-568-8-105-3491-2094.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Państwo polskie nigdy nie zrzekło się roszczeń wobec państwa niemieckiego; Sejm RP wzywa rząd Niemiec do przyjęcia odpowiedzialności politycznej, historycznej, prawnej oraz finansowej za wszystkie skutki spowodowane w wyniku rozpętania II wojny światowej – głosi przyjęta w śr

## GPW z przewagą wzrostów. Kurs węglowego Coal Energy zyskał 205 proc. w trzy sesje
 - [https://www.bankier.pl/wiadomosc/GPW-z-przewaga-wzrostow-Kurs-weglowego-Coal-Energy-zyskal-205-proc-w-trzy-sesje-8405958.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/GPW-z-przewaga-wzrostow-Kurs-weglowego-Coal-Energy-zyskal-205-proc-w-trzy-sesje-8405958.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 16:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/1/12904f258c9cd4-948-568-12-52-983-590.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sesja w środę przyniosła ostudzenie emocji i przewagę wzrostów na głównych indeksach. Po wyprzedaży na Wall Street handel na GPW przebiegł zastanawiająco spokojnie i bez większej zmienności. Popłochu wśród inwestorów nie wywołała też krystalizacja planów KE co do interwencji na

## Francja ograniczy do 15 proc. podwyżki cen gazu i prądu w styczniu 2023 r.
 - [https://www.bankier.pl/wiadomosc/Francja-ograniczy-do-15-proc-podwyzki-cen-gazu-i-pradu-w-styczniu-2023-r-8405938.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Francja-ograniczy-do-15-proc-podwyzki-cen-gazu-i-pradu-w-styczniu-2023-r-8405938.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 16:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/9/3664c214d987be-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Premier Francji Elisabeth Borne poinformowała w środę na konferencji prasowej w Paryżu o ograniczeniu przez rząd podwyżki cen energii i gazu do 15 proc. na początku 2023 r. dla gospodarstw domowych, małych przedsiębiorstw i gmin.</p>

## Wysoka inflacja czy brak węgla. Te tematy ma przykryć sprawa reparacji od Niemiec
 - [https://www.bankier.pl/wiadomosc/Wysoka-inflacja-czy-brak-wegla-Te-tematy-ma-przykryc-sprawa-reparacji-od-Niemiec-8405928.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wysoka-inflacja-czy-brak-wegla-Te-tematy-ma-przykryc-sprawa-reparacji-od-Niemiec-8405928.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 15:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/8/8317e44489375c-945-560-8-346-1639-983.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Koła: Konfederacji, Polski 2050, Porozumienia i PPS uważają, że PiS chce instrumentalnie wykorzystać temat reparacji wojennych od Niemiec w kampanii wyborczej i przykryć tym tematem wysoką inflację, czy brak węgla.</p>

## Zełenski w miastach wyzwolonych spod rosyjskiej okupacji: to powtórka Buczy
 - [https://www.bankier.pl/wiadomosc/Zelenski-w-miastach-wyzwolonych-spod-rosyjskiej-okupacji-to-powtorka-Buczy-8405899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zelenski-w-miastach-wyzwolonych-spod-rosyjskiej-okupacji-to-powtorka-Buczy-8405899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 15:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/53339ea2bb83d8-948-568-0-70-1042-625.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />To powtórka Buczy – oświadczył w środę prezydent Ukrainy Wołodymyr Zełenski podczas wizyty w Iziumie i Bałaklii, miastach wyzwolonych spod rosyjskiej okupacji w obwodzie charkowskim na północnym wschodzie kraju. „Znów widzimy tortury, znów widzimy ruiny” – powiedział.</p>

## Gospodarka cyfrowa w Polsce warta 44 mld euro - najwięcej w regionie. Raport McKinsey
 - [https://www.bankier.pl/wiadomosc/Gospodarka-cyfrowa-w-Polsce-warta-44-mld-euro-najwiecej-w-regionie-Raport-McKinsey-8405894.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gospodarka-cyfrowa-w-Polsce-warta-44-mld-euro-najwiecej-w-regionie-Raport-McKinsey-8405894.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 15:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/2/a4d8c9221144e6-948-568-0-0-3861-2317.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska ma największą gospodarkę cyfrową w Europie Środkowo Wschodniej; w 2021 r. jej wartość wyniosła 44 mld euro - wynika z opublikowanego w środę badania firmy doradczej McKinsey. Polska ma też największy rynek e-commerce, który w ubiegłym roku był warty 27 mld euro.</p>

## Szefowa PE: Finansowanie zagranicznych partii przez Rosję może mieć wpływ na zmianę wyników wyborów
 - [https://www.bankier.pl/wiadomosc/Szefowa-PE-Finansowanie-zagranicznych-partii-przez-Rosje-moze-miec-wplyw-na-zmiane-wynikow-wyborow-8405891.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szefowa-PE-Finansowanie-zagranicznych-partii-przez-Rosje-moze-miec-wplyw-na-zmiane-wynikow-wyborow-8405891.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 15:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/6/44d182af2faa91-948-568-0-0-3911-2346.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Finansowanie zagranicznych partii politycznych przez Rosję to ogromny problem. Może to potencjalnie mieć wpływ na zmianę wyników wyborów w krajach Europy - powiedziała w rozmowie z kilkoma agencjami, w tym PAP, szefowa Parlamentu Europejskiego Roberta Metsola.</p>

## KE proponuje interwencję na rynku energii w celu obniżenia rachunków Europejczyków
 - [https://www.bankier.pl/wiadomosc/KE-proponuje-interwencje-na-rynku-energii-w-celu-obnizenia-rachunkow-Europejczykow-8405852.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KE-proponuje-interwencje-na-rynku-energii-w-celu-obnizenia-rachunkow-Europejczykow-8405852.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 14:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/ea9b6fd93f5c8f-948-568-2-67-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Obowiązkowe ograniczenie zużycia energii elektrycznej, ograniczenie dochodów producentów energii elektrycznej oraz opłata solidarnościowa od nadwyżek zysków pochodzących z działalności prowadzonej w sektorach ropy naftowej, gazu, węgla i rafinerii to przedstawione w środę pomysł

## Związkowcy z ArcelorMittal Poland chcą gwarancji ponownego uruchomienia wielkiego pieca
 - [https://www.bankier.pl/wiadomosc/Zwiazkowcy-z-ArcelorMittal-Poland-chca-gwarancji-ponownego-uruchomienia-wielkiego-pieca-8405825.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zwiazkowcy-z-ArcelorMittal-Poland-chca-gwarancji-ponownego-uruchomienia-wielkiego-pieca-8405825.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 13:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/0/cc611f49635982-945-567-0-0-3500-2100.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Związkowcy z ArcelorMittal Poland (AMP) w Dąbrowie Górniczej wystąpili do zarządu spółki o pisemne gwarancje ponownego uruchomienia w tym zakładzie wielkiego pieca, który ma zostać czasowo wyłączony z końcem września. Związki chcą też utrzymania stabilności zatrudnienia i wynag

## Ceny producentów w USA spadły drugi miesiąc z rzędu
 - [https://www.bankier.pl/wiadomosc/Inflacja-PPI-w-USA-sierpien-2022-8405788.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-PPI-w-USA-sierpien-2022-8405788.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 13:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/7e4b4dfdd0ce51-945-567-0-67-1493-896.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sierpień przyniósł drugi z rzędu spadek inflacji
producenckiej w Stanach Zjednoczonych.</p>

## Parlament Europejski uchwalił przepisy o minimalnym wynagrodzeniu pracowników w UE
 - [https://www.bankier.pl/wiadomosc/Placa-minimalna-w-UE-Parlament-Europejski-uchwalil-przepisy-8405816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Placa-minimalna-w-UE-Parlament-Europejski-uchwalil-przepisy-8405816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 13:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/fb613921406d10-948-568-0-10-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Minimalne wynagrodzenia we wszystkich państwach Unii mają zapewnić godny poziom życia i pracy. Państwa członkowskie mają propagować ustalanie wynagrodzeń w drodze negocjacji zbiorowych - zdecydował w środę Parlament Europejski w Strasburgu.</p>

## Brakuje pieniędzy na podręczniki w podstawówkach. Rząd zwiększy limit
 - [https://www.bankier.pl/wiadomosc/Brakuje-pieniedzy-na-podreczniki-w-podstawowkach-Rzad-zwiekszy-limit-8405798.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brakuje-pieniedzy-na-podreczniki-w-podstawowkach-Rzad-zwiekszy-limit-8405798.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 13:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/4/63abb229f2c8bc-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Z uwagi na obecność ukraińskich uczniów w polskich szkołach nastąpiło pewne niedoszacowanie dotacji podręcznikowej. W tym momencie procedowany jest przepis ustawy, który zwiększa limit tych wydatków - poinformował w środę minister edukacji i nauki Przemysław Czarnek.</p>

## PiS zgłosił do swojego projektu uchwały ws. reparacji poprawkę o stratach wyrządzonych przez ZSRR
 - [https://www.bankier.pl/wiadomosc/Sejmowa-komisja-spraw-zagranicznych-przyjela-projekt-uchwaly-ws-reparacji-od-Niemiec-8405777.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sejmowa-komisja-spraw-zagranicznych-przyjela-projekt-uchwaly-ws-reparacji-od-Niemiec-8405777.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 12:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/b5d46c44066e34-948-568-0-102-4096-2457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejmowa Komisja Spraw Zagranicznych przyjęła w środę projekt uchwały ws. reparacji wojennych od Niemiec; jako projekt wiodący przyjęto projekt PiS. Do projektu PiS wprowadził poprawkę, mówiącą, że Polska nie otrzymała nigdy żadnego zadośćuczynienia za straty w wyniku agresji 

## "Skrajnie bezduszne". Karol III zapowiada zwolnienia grupowe w pałacu
 - [https://www.bankier.pl/wiadomosc/Skrajnie-bezduszne-Karol-III-zapowiada-zwolnienia-grupowe-w-palacu-8405705.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Skrajnie-bezduszne-Karol-III-zapowiada-zwolnienia-grupowe-w-palacu-8405705.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 12:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/8/7fa8f6a9e83370-948-568-40-45-1960-1175.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nawet 100 osób z personelu zatrudnionego przez jeszcze księcia Karola straci pracę po tym, jak został on Karolem III. "Skrajnie bezduszne" komentują osoby objęte redukcjami, wśród których znajdują się sekretarze czy doradcy finansowi. "Cztery dni temu pracowaliśmy do późnej n

## Nowy przedmiot w szkołach. Czym biznes i zarządzanie różni się od podstaw przedsiębiorczości?
 - [https://www.bankier.pl/wiadomosc/Nowy-przedmiot-w-szkolach-Czym-biznes-i-zarzadzanie-rozni-sie-od-podstaw-przedsiebiorczosci-8405754.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowy-przedmiot-w-szkolach-Czym-biznes-i-zarzadzanie-rozni-sie-od-podstaw-przedsiebiorczosci-8405754.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 12:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/c/f0d763532c7a55-948-568-8-80-3192-1915.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po nowym przedmiocie biznes i zarządzanie można spodziewać się bardziej praktycznego nauczania przedsiębiorczości na każdej płaszczyźnie życia – zapewnił w środę w Warszawie szef MEiN Przemysław Czarnek.</p>

## 40 proc. ogrzewających domy węglem nie ma zapasów surowca na sezon grzewczy
 - [https://www.bankier.pl/wiadomosc/40-proc-ogrzewajacych-domy-weglem-nie-ma-zapasow-surowca-na-sezon-grzewczy-8405723.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/40-proc-ogrzewajacych-domy-weglem-nie-ma-zapasow-surowca-na-sezon-grzewczy-8405723.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 11:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/58c4e257eddf46-945-560-9-340-3429-2057.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />40 proc. wszystkich ogrzewających domy węglem nie posiada żadnych zapasów tego surowca na nadchodzący sezon grzewczy, a 79 proc. przewiduje problemy z zaopatrzeniem. Z pieców węglowych korzysta m.in. 77 proc. mieszkańców wsi - wynika z badania CBOS.</p>

## Gliński: Polska zażąda od Rosji zwrotu zrabowanych dzieł sztuki
 - [https://www.bankier.pl/wiadomosc/Glinski-Polska-zazada-od-Rosji-zwrotu-zrabowanych-dziel-sztuki-8405709.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Glinski-Polska-zazada-od-Rosji-zwrotu-zrabowanych-dziel-sztuki-8405709.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 11:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/2/4a387a13d2a286-945-560-0-75-1176-705.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska przekaże Rosji kolejnych siedem wniosków restytucyjnych dot. dzieł sztuki wywiezionych do ZSRR w czasie II wojny światowej - poinformował wicepremier, szef MKiDN Piotr Gliński. Zapewnił, że Polska nigdy nie przestanie poszukiwać i odzyskiwać zagrabionych w czasie wojny d

## Trwają walki między Armenią i Azerbejdżanem. Strony oskarżają się wzajemnie o eskalację
 - [https://www.bankier.pl/wiadomosc/Trwaja-walki-miedzy-Armenia-i-Azerbejdzanem-Strony-oskarzaja-sie-wzajemnie-o-eskalacje-8405690.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trwaja-walki-miedzy-Armenia-i-Azerbejdzanem-Strony-oskarzaja-sie-wzajemnie-o-eskalacje-8405690.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 11:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/c/47f5221c6c7294-948-568-543-360-956-573.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W środę rano doszło do wznowienia walk i ostrzałów między Armenią a Azerbejdżanem. Według władz obu państw w walkach, które wybuchły w nocy z poniedziałku na wtorek zginęło 99 osób. To największa intensyfikacja konfliktu między tymi krajami od 2020 roku. Oba państwa wzajemnie

## Kowalczyk: Uruchamiamy nabór wniosków dla rolników w ramach KPO
 - [https://www.bankier.pl/wiadomosc/Kowalczyk-Uruchamiamy-nabor-wnioskow-dla-rolnikow-w-ramach-KPO-8405678.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kowalczyk-Uruchamiamy-nabor-wnioskow-dla-rolnikow-w-ramach-KPO-8405678.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/0/f5cb821cde4aa5-948-567-0-62-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W połowie października rozpocznie się nabór wniosków dla rolników i przetwórców w ramach Krajowego Planu Odbudowy. Wnioski będzie przyjmowała Agencja Restrukturyzacji i Modernizacji Rolnictwa - poinformował środę na konferencji prasowej wicepremier, minister rolnictwa Henryk Ko

## Maciej Rudnicki zrezygnował z kandydowania do Rady Polityki Pieniężnej
 - [https://www.bankier.pl/wiadomosc/Maciej-Rudnicki-zrezygnowal-z-kandydowania-do-Rady-Polityki-Pienieznej-8405673.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Maciej-Rudnicki-zrezygnowal-z-kandydowania-do-Rady-Polityki-Pienieznej-8405673.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 10:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/f/ce042fad88af4b-945-560-3-56-1496-897.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />13 września Maciej Rudnicki zrezygnował z kandydowania do Rady Polityki Pieniężnej - podano na stronach internetowych Sejmu. Rudnicki został 28 lutego zgłoszony jako kandydat do RPP przez grupę posłów PiS.</p>

## KE nie ma litości dla węgla. Leyen: Musimy przyspieszyć przejście na czystą energię
 - [https://www.bankier.pl/wiadomosc/KE-nie-ma-litosci-dla-wegla-Leyen-Musimy-przyspieszyc-przejscie-na-czysta-energie-8405653.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KE-nie-ma-litosci-dla-wegla-Leyen-Musimy-przyspieszyc-przejscie-na-czysta-energie-8405653.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 10:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/16bc54fc8c09ed-945-567-0-0-3485-2091.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zmniejszenie ogólnego popytu na paliwa kopalne musi nastąpić w sposób konsekwentny i przyszłościowy. Pakiet Europejskiego Zielonego Ładu i Fit for 55 prowadzi nas w tym kierunku, musimy jednak przyspieszyć przejście na czystą energię - napisała szefowa KE w odpowiedzi na przyję

## Taka sama pensja dla Ukraińca oraz Polaka. MRiPS przygotowało propozycję zmian w zatrudnieniu cudzoziemca
 - [https://www.bankier.pl/wiadomosc/Taka-sama-pensja-dla-Ukrainca-oraz-Polaka-MRiPS-przygotowalo-propozycje-zmian-w-zatrudnieniu-cudzoziemca-8405651.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Taka-sama-pensja-dla-Ukrainca-oraz-Polaka-MRiPS-przygotowalo-propozycje-zmian-w-zatrudnieniu-cudzoziemca-8405651.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 10:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/b/392d5cd57c2738-945-560-0-7-1528-916.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zrównanie płac cudzoziemców z wynagrodzeniem Polaków i zmniejszenie biurokracji podczas zatrudnienia obywateli spoza UE – takie główne cele ma nowy projekt ustawy przygotowany przez MRiPS. Cały proces ma zostać zelektryfikowany i ułatwić wysiłki zarówno pracodawców, jak i pracow

## UOKiK przyjrzy się emisji tokenów. Firmę Selfmaker wychwalał premier Morawiecki
 - [https://www.bankier.pl/wiadomosc/UOKiK-przyjrzy-sie-emisji-tokenow-8405637.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UOKiK-przyjrzy-sie-emisji-tokenow-8405637.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 10:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/6/7dd09d026269c6-945-560-0-48-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezes UOKiK Tomasz Chróstny wszczął postępowania przeciwko spółkom Selfmaker Smart Solutions z siedzibą w ZEA, która odpowiada za emisję tokenów oraz Selfmaker Technology z Łodzi i jej prezesowi - podał Urząd. Wątpliwości budzą m.in. bezpodstawne zapewnienia o generowanych zys

## Drożyzna drenuje portfele studentów. Rosną wydatki, topnieją oszczędności
 - [https://www.bankier.pl/wiadomosc/Drozyzna-drenuje-portfele-studentow-Rosna-wydatki-topnieja-oszczednosci-8405605.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Drozyzna-drenuje-portfele-studentow-Rosna-wydatki-topnieja-oszczednosci-8405605.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 09:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/1/9c6d1834497603-948-568-0-0-1687-1012.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Problemy finansowe zaczynają dotykać niemal całą grupę społeczną polskich studentek i studentów. Żacy wydają coraz więcej, a oszczędzają coraz mniej – wynika z raportu „Portfel Studenta 2022” opublikowanego przez Warszawski Instytut Bankowości we współpracy ze Związkiem Banków 

## Prezes Bogdanki może stracić stanowisko. Sasin RN rozpatrzy wniosek
 - [https://www.bankier.pl/wiadomosc/Prezes-Bogdanki-moze-stracic-stanowisko-Sasin-RN-rozpatrzy-wniosek-8405601.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezes-Bogdanki-moze-stracic-stanowisko-Sasin-RN-rozpatrzy-wniosek-8405601.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 09:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/e/7680446cd49800-948-568-0-69-3497-2098.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W piątek, podczas posiedzenia rady nadzorczej Lubelskiego Węgla "Bogdanka" rozpatrzony zostanie punkt o odwołanie prezesa Artura Wasila - poinformował w środę wicepremier, minister aktywów państwowych Jacek Sasin.</p>

## Rośnie liczba uczniów z Ukrainy. Nawet o kilka tysięcy w Warszawie i Wrocławiu
 - [https://www.bankier.pl/wiadomosc/Rosnie-liczba-uczniow-z-Ukrainy-Nawet-o-kilka-tysiecy-w-Warszawie-i-Wroclawiu-8405553.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosnie-liczba-uczniow-z-Ukrainy-Nawet-o-kilka-tysiecy-w-Warszawie-i-Wroclawiu-8405553.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 09:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/b/3d830c4ec78832-948-568-0-187-3120-1871.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />We Wrocławiu liczba ukraińskich dzieci w szkołach i przedszkolach wzrosła o 4 tys. w porównaniu z czerwcem br. Z kolei w Poznaniu liczba uczniów zza wschodniej granicy zmniejszyła się o ponad 500 osób – podaje portalsamorzadowy.pl.</p>

## Finansowe walkowery pracujących matek. Ten poradnik ma im zapobiec
 - [https://www.bankier.pl/wiadomosc/Finansowy-poradnik-pracujacych-matek-ebook-Prawo-pracy-przepisy-8402213.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Finansowy-poradnik-pracujacych-matek-ebook-Prawo-pracy-przepisy-8402213.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/f/1b861ee0105f92-948-568-11-7-1487-892.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przegapione premie, niesłusznie opóźniane podwyżki, zbyt niskie zasiłki i
 fikcyjne likwidacje stanowisk - to realia wielu kobiet zatrudnionych na
 polskim rynku pracy, które wynikają z nieznajomości prawa pracy. "Finansowy poradnik pracujących mam" to nowy e-book od Bankier.pl

## Leyen: Sankcje Zachodu na Rosję zostaną utrzymane
 - [https://www.bankier.pl/wiadomosc/Leyen-sankcje-Zachodu-na-Rosje-zostana-utrzymane-8405570.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Leyen-sankcje-Zachodu-na-Rosje-zostana-utrzymane-8405570.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 08:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/6/d019aca6f5700c-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sankcje Zachodu nałożone na Rosję mają na nią realny wpływ i zostaną utrzymane - powiedziała w środę przewodnicząca Komisji Europejskiej Ursula von der Leyen, podkreślając, że solidarność Unii Europejskiej z Ukrainą będzie „niezachwiana".</p>

## Bogdanka wyprodukuje mniej węgla w 2022 r.
 - [https://www.bankier.pl/wiadomosc/Bogdanka-obniza-do-8-3-mln-ton-z-9-2-mln-ton-plan-produkcyjny-wegla-handlowego-w-2022-roku-8405548.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bogdanka-obniza-do-8-3-mln-ton-z-9-2-mln-ton-plan-produkcyjny-wegla-handlowego-w-2022-roku-8405548.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 08:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/836ad5be90943a-948-567-0-2-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bogdanka zaktualizowała cel produkcyjny na 2022 rok do ok. 8,3 mln ton z ok. 9,2 mln ton węgla handlowego zakładanych wcześniej - podała spółka w komunikacie.</p>

## Grupa PHN poprawiła wyniki w I półroczu, chociaż sytuacja na rynku pogarsza się
 - [https://www.bankier.pl/wiadomosc/Grupa-PHN-poprawila-wyniki-w-I-polroczu-chociaz-sytuacja-na-rynku-pogarsza-sie-8405550.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Grupa-PHN-poprawila-wyniki-w-I-polroczu-chociaz-sytuacja-na-rynku-pogarsza-sie-8405550.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 08:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/a/e51c89a015c692-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa PHN w pierwszej połowie 2022 r. poprawiła wyniki finansowe dzięki dywersyfikacji działalności i kontroli kosztów własnych. Zysk netto wyniósł 47,8 mln zł wobec 33,2 mln zł przed rokiem, a wynik EBITDA wzrósł o 86 proc., do 101,5 mln zł - poinformowała spółka w komunikac

## Ukraina chce otworzyć lotniska. Lwów mógłby być pierwszy
 - [https://www.bankier.pl/wiadomosc/Ukraina-chce-otworzyc-lotniska-Lwow-moglby-byc-pierwszy-8405546.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraina-chce-otworzyc-lotniska-Lwow-moglby-byc-pierwszy-8405546.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 08:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/8/0d31e899dbf02d-948-568-0-191-3838-2302.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraina mogłaby wznowić  wstrzymany na początku wojny z Rosją pasażerski ruch lotniczy, jeśli otrzymałaby międzynarodowe gwarancje bezpieczeństwa. Pierwszym otwartym lotniskiem mógłby być Lwów – oświadczył minister infrastruktury Ołeksandr Kubrakow.</p>

## Zysk netto Bogdanki w I półroczu '22 zgodny z szacunkami
 - [https://www.bankier.pl/wiadomosc/Zysk-netto-Bogdanki-w-I-polroczu-22-wyniosl-zgodnie-z-szacunkami-336-mln-zl-8405541.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zysk-netto-Bogdanki-w-I-polroczu-22-wyniosl-zgodnie-z-szacunkami-336-mln-zl-8405541.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 07:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/f/a1b863de20af70-948-568-39-0-1050-630.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />LW Bogdanka miała w pierwszym półroczu 2022 roku 1.462,6 mln zł skonsolidowanych przychodów, 615,4 mln zł EBITDA, 412 mln zł EBIT i 336 mln zł zysku netto - poinformowała spółka w raporcie. Wyniki były zgodne z podanymi wcześniej szacunkami.</p>

## Dębica odnotowała stratę netto w II kw. 2022 r
 - [https://www.bankier.pl/wiadomosc/Debica-odnotowala-6-7-mln-zl-straty-netto-w-II-kw-2022-r-8405534.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Debica-odnotowala-6-7-mln-zl-straty-netto-w-II-kw-2022-r-8405534.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 07:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/8/adf19d5e8cffad-945-560-0-116-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Firma Oponiarska Dębica w drugim kwartale 2022 r. zwiększyła przychody ze sprzedaży o 40 proc. rdr do 799,1 mln zł. Strata netto wyniosła 6,7 mln zł, wobec 14,6 mln zł zysku netto rok wcześniej - podała spółka w komunikacie prasowym.</p>

## Podatek od zysków nadzwyczajnych. PKO BP o skali korzyści
 - [https://www.bankier.pl/wiadomosc/Podatek-od-zyskow-nadzwyczajnych-PKO-BP-o-skali-korzysci-8405524.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podatek-od-zyskow-nadzwyczajnych-PKO-BP-o-skali-korzysci-8405524.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 07:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/5e1e3a056a074a-945-560-7-42-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Planowany przez Komisję Europejską podatek od zysków nadzwyczajnych dla firm z sektora wydobycia i produkcji energii, surowców energetycznych i paliw może dać w Polsce w 2023 roku około 0,5-1,0 proc. PKB dodatkowych dochodów budżetowych - wynika z szacunków ekonomistów PKO BP.</

## Szefernaker: Wybory samorządowe będą najprawdopodobniej 7 lub 14 kwietnia 2024 roku
 - [https://www.bankier.pl/wiadomosc/Szefernaker-Wybory-samorzadowe-beda-najprawdopodobniej-7-lub-14-kwietnia-2024-roku-8405519.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szefernaker-Wybory-samorzadowe-beda-najprawdopodobniej-7-lub-14-kwietnia-2024-roku-8405519.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 07:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/a/f40d131b5db391-948-568-0-71-2042-1225.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zgodnie z propozycją Prawa i Sprawiedliwości najbardziej prawdopodobne terminy wyborów samorządowych to 7 lub 14 kwietnia 2024 roku - poinformował wiceszef ministerstwa spraw wewnętrznych i administracji Paweł Szefernaker.</p>

## KNF: Wzrost składek OC to wina polityki obniżania marż przez ubezpieczycieli
 - [https://www.bankier.pl/wiadomosc/KNF-Wzrost-skladek-OC-to-wina-polityki-obnizania-marz-przez-ubezpieczycieli-8405514.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KNF-Wzrost-skladek-OC-to-wina-polityki-obnizania-marz-przez-ubezpieczycieli-8405514.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/c/aaff06c9e32683-945-560-0-116-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny składek OC ustalają samodzielnie zarządy zakładów ubezpieczeń, zaś działania Komisji Nadzoru Finansowego w tym zakresie nakierowane są na wyegzekwowanie stosowania się do przepisów prawa, a nie na regulację wysokości cen ubezpieczeń OC – wskazuje Krystian Wiercioch, zast

## Ceny ropy w USA w dół. Zapasy surowca wzrosły o 6 mln baryłek
 - [https://www.bankier.pl/wiadomosc/Ceny-ropy-w-USA-w-dol-Zapasy-surowca-wzrosly-o-6-mln-barylek-8405512.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-ropy-w-USA-w-dol-Zapasy-surowca-wzrosly-o-6-mln-barylek-8405512.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 06:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/6/297e659c27e5bd-948-568-0-69-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku spadają podczas porannego handlu w środę. Amerykańskie zapasy surowca mocno wzrosły w ubiegłym tygodniu, a  administracja prezydenta Joe Bidena rozważa uzupełnienie strategicznych rezerw ropy, gdy ceny surowca spadną poniżej 80 USD za 

## Reuters: strzelanina na granicy Kirgistanu i Tadżykistanu
 - [https://www.bankier.pl/wiadomosc/Reuters-strzelanina-na-granicy-Kirgistanu-i-Tadzykistanu-8405510.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Reuters-strzelanina-na-granicy-Kirgistanu-i-Tadzykistanu-8405510.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 06:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/33c6442e690f4c-948-568-0-303-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na granicy Kirgistanu i Tadżykistanu doszło w środę do strzelaniny między strażnikami granicznymi tych dwóch państw - poinformowała agencja Reutera opierająca się na mediach rosyjskich cytujących kirgiską straż graniczną.</p>

## Brytyjski MON: Rosja zwiększa zakupy broni od Iranu i Korei Płn.
 - [https://www.bankier.pl/wiadomosc/Brytyjski-MON-Rosja-zwieksza-zakupy-broni-od-Iranu-i-Korei-Pln-8405507.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjski-MON-Rosja-zwieksza-zakupy-broni-od-Iranu-i-Korei-Pln-8405507.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 06:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/3/d25789267d12ee-948-568-55-110-1945-1166.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W obliczu topniejących zapasów uzbrojenia Rosja najpewniej sprowadza coraz więcej broni z innych krajów obłożonych sankcjami, takich jak Iran i Korea Płn. – ocenił w środę brytyjski resort obrony, komentując strącenie irańskiego drona przez siły ukraińskie.</p>

## Coraz większe pieniądze na ochronę zdrowia, ale... rzadziej chodzimy do lekarza. I krócej żyjemy
 - [https://www.bankier.pl/wiadomosc/Coraz-wieksze-pieniadze-na-ochrone-zdrowia-ale-rzadziej-chodzimy-do-lekarza-I-krocej-zyjemy-8405498.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-wieksze-pieniadze-na-ochrone-zdrowia-ale-rzadziej-chodzimy-do-lekarza-I-krocej-zyjemy-8405498.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 06:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/4/d58362c65a04c3-945-560-4-17-1767-1060.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zwiększanie nakładów na ochronę zdrowia nie przekłada się na wzrost liczby świadczeń – wynika z analizy, którą przytacza środowy "Dziennik Gazeta Prawna". Wydatki na służbę zdrowia w 2021 r. wzrosły w porównaniu z nakładami w 2016 o niemal 50 proc. Tymczasem liczba świadczeń j

## Mikropłatności od dzieci napędzają cyfrową rozrywkę
 - [https://www.bankier.pl/wiadomosc/Mikroplatnosci-od-dzieci-napedzaja-cyfrowa-rozrywke-8405497.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mikroplatnosci-od-dzieci-napedzaja-cyfrowa-rozrywke-8405497.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 06:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/8/155a2e7bc62de3-948-568-2-10-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Małoletni Polacy szastają pieniędzmi na gry – co czwarty kupił w tym roku przynajmniej jeden tytuł na swój smartfon lub tablet, a niemal co trzeci dokonał zakupu dodatku lub płatności w samej grze - pisze w środę "Rzeczpospolita".</p>

## Wyniki ewaluacji pod ostrzałem. Uczelnie masowo się odwołują
 - [https://www.bankier.pl/wiadomosc/Wyniki-ewaluacji-pod-ostrzalem-Uczelnie-masowo-sie-odwoluja-8405488.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wyniki-ewaluacji-pod-ostrzalem-Uczelnie-masowo-sie-odwoluja-8405488.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/d0d3ce6b961ef1-948-568-0-168-2500-1499.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad połowa uczelni i instytutów zakwestionowała przyznaną ocenę poziomu badań naukowych. Jeżeli resort nauki nie uwzględni ich argumentów, będą się sądzić – podaje w środę "Dziennik Gazeta Prawna".</p>

## Kryzys demograficzny w Bułgarii. 600 wiosek całkowicie wyludnionych
 - [https://www.bankier.pl/wiadomosc/Kryzys-demograficzny-w-Bulgarii-600-wiosek-calkowicie-wyludnionych-8405486.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kryzys-demograficzny-w-Bulgarii-600-wiosek-calkowicie-wyludnionych-8405486.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/b/87fcc49ad5d651-945-560-127-0-1759-1055.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kryzys demograficzny w Bułgarii rozpoczął się w połowie lat 80. ubiegłego wieku. Cały kraj oczekiwał narodzin 9-milionowego mieszkańca, lecz szybko okazało się, że liczba zgonów zaczyna dominować nad narodzinami. W 2020 r. ONZ podała, że liczba Bułgarów spadła poniżej 7 mln, 

## Komunikacja miejska podrożeje przez ceny energii i paliw
 - [https://www.bankier.pl/wiadomosc/Komunikacja-miejska-podrozeje-przez-ceny-energii-i-paliw-8405482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Komunikacja-miejska-podrozeje-przez-ceny-energii-i-paliw-8405482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/1/3a7193c41f5e66-948-568-3-0-1205-723.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wobec galopujących kosztów zakupu prądu i diesla eksploatacja tramwajów, trolejbusów czy autobusów elektrycznych staje się kompletnie nieopłacalna - pisze w środę "Rzeczpospolita".</p>

## Milionowe nagrody w Ministerstwie Finansów. "Za szczególne osiągnięcia"
 - [https://www.bankier.pl/wiadomosc/Milionowe-nagrody-w-Ministerstwie-Finansow-Za-szczegolne-osiagniecia-8405480.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Milionowe-nagrody-w-Ministerstwie-Finansow-Za-szczegolne-osiagniecia-8405480.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/4/3b3bc682c72215-945-560-7-78-1492-895.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od stycznia do sierpnia Ministerstwo Finansów przeznaczyło 23 mln zł na premie dla urzędników – podaje środowy "Fakt", podkreślając, że resort zasłynął w tym roku szczególnie jedną reformą – podatkową.</p>

## Paprocka: Korekt do ustawy o Sądzie Najwyższym nie będzie
 - [https://www.bankier.pl/wiadomosc/Paprocka-Korekt-do-ustawy-o-Sadzie-Najwyzszym-nie-bedzie-8405479.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Paprocka-Korekt-do-ustawy-o-Sadzie-Najwyzszym-nie-bedzie-8405479.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/f/3acd507d9e8ff1-948-568-35-29-1965-1178.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ursula von der Leyen postawiła żądanie niespełnialne w żadnym demokratycznym państwie – powiedziała w wywiadzie dla "Rzeczpospolitej" sekretarz stanu w Kancelarii Prezydenta Małgorzata Paprocka, odnosząc się m.in. do braku kompromisu w sprawie KPO.</p>

## Morską energetykę wiatrową na Bałtyku czeka potężny skok rozwojowy. Polska wśród liderów
 - [https://www.bankier.pl/wiadomosc/Morska-energetyke-wiatrowa-na-Baltyku-czeka-potezny-skok-rozwojowy-Polska-wsrod-liderow-8405467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Morska-energetyke-wiatrowa-na-Baltyku-czeka-potezny-skok-rozwojowy-Polska-wsrod-liderow-8405467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/322a7bcab9e725-948-568-48-0-1809-1085.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Aby UE mogła osiągnąć neutralność klimatyczną, moc zainstalowana w sektorze offshore musi wzrosnąć z obecnych 15 do 300 GW do 2050 roku, ale potencjał morskiej energetyki wiatrowej jest znacznie większy. Jak wskazuje WindEurope,...</p>

## Średnia wartość koszyka zakupowego wzrosła o 30 zł rdr
 - [https://www.bankier.pl/wiadomosc/Raport-srednia-wartosc-koszyka-zakupowego-wzrosla-o-30-zl-rdr-8405465.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Raport-srednia-wartosc-koszyka-zakupowego-wzrosla-o-30-zl-rdr-8405465.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/2/17a0e5ad925c31-920-552-10-9-920-552.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Średnia wartość koszyka zakupowego w sierpniu tego roku wzrosła - w ujęciu rocznym - o ponad 13 proc., czyli o 30 zł – wynika z raportu przygotowanego przez ASM Sales Force Agency.</p>

## Co trzeci Polak szuka w dyskontach promocji na mięso
 - [https://www.bankier.pl/wiadomosc/Co-trzeci-Polak-szuka-w-dyskontach-promocji-na-mieso-8405456.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Co-trzeci-Polak-szuka-w-dyskontach-promocji-na-mieso-8405456.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/8/5dd90310d84e50-948-568-0-67-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 33 proc. Polaków szuka w dyskontach promocji na mięso, 29 proc. poluje na olej, masło i margarynę w promocji, a tańszego cukru czy mąki poszukuje 27 proc. pytanych - wynika z przekazanego PAP badania. Co piąty Polak zamierza zrezygnować z kupna mocnych alkoholi i przekąse

## Hiszpania podwoiła w sierpniu import rosyjskiego gazu
 - [https://www.bankier.pl/wiadomosc/Hiszpania-podwoila-w-sierpniu-import-rosyjskiego-gazu-8405457.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hiszpania-podwoila-w-sierpniu-import-rosyjskiego-gazu-8405457.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/21d5d615c0fd96-948-568-0-8-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Hiszpania sprowadziła w sierpniu br. ponad dwukrotnie więcej gazu ziemnego z Rosji niż w analogicznym miesiącu 2021 roku - wynika z danych spółki Enagas, operatora hiszpańskich gazociągów.</p>

## 2,5 tys. zł na życie dla najzdolniejszych i najbiedniejszych. Sprawdziliśmy stypendia studentów uczelni ekonomicznych
 - [https://www.bankier.pl/wiadomosc/Stypendium-na-studia-2-5-tys-zl-na-zycie-dla-najzdolniejszych-i-najbiedniejszy-8405091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stypendium-na-studia-2-5-tys-zl-na-zycie-dla-najzdolniejszych-i-najbiedniejszy-8405091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/b/98fa916f4b23af-948-568-0-0-1504-902.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stypendium może wynieść blisko 2,5 tys. zł miesięcznie. Studenci mogą otrzymać dodatkowe pieniądze m.in. za dobre wyniki w nauce lub inne osiągnięcia. Na wparcie podczas kształcenia mogą liczyć żacy z mniej zamożnych rodzin. Przeanalizowaliśmy kwoty stypendiów na uczelniach ekon

## Hipoteka na 3 proc. i spokój na lata? Skorzystało niewielu
 - [https://www.bankier.pl/wiadomosc/Hipoteka-na-3-proc-i-spokoj-na-lata-Skorzystalo-niewielu-8405198.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hipoteka-na-3-proc-i-spokoj-na-lata-Skorzystalo-niewielu-8405198.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/7/ab046eddd7d58b-948-567-0-347-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeszcze rok temu można było zaciągnąć kredyt hipoteczny ze
stałym oprocentowaniem i stawką nieco ponad 3 proc. Takie rozwiązanie wybierała
jednak wówczas nieliczna grupa kredytobiorców. Sprawdzamy, ile zyskali ci,
którzy trafili na odpowiedni moment.</p>

## Magazynier: praca dostępna od zaraz. Jakie zarobki oferuje branża?
 - [https://www.bankier.pl/wiadomosc/Co-czeka-branze-magazynowa-Praca-dla-magazynierow-8402049.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Co-czeka-branze-magazynowa-Praca-dla-magazynierow-8402049.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/5/2230a591807475-948-568-0-80-1274-764.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rynek magazynowy w Polsce rozwija się w bardzo 
szybkim tempie, na co wpływ mają także wzrosty odnotowywane przez sektor
 logistyczny i branżę e-commerce. Paradoksalnie: gospodarcze 
konsekwencje pandemii koronawirusa okazały się dla tych branż pozytywne,
 jednak również one mo

## Kanada wesprze najmniej zarabiających w czasie wyższej inflacji
 - [https://www.bankier.pl/wiadomosc/Kanada-wesprze-najmniej-zarabiajacych-w-czasie-wyzszej-inflacji-8405442.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kanada-wesprze-najmniej-zarabiajacych-w-czasie-wyzszej-inflacji-8405442.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-14 03:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/9d07cef9bf9484-948-568-0-26-1776-1065.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dodatkowe świadczenia i dopłaty do czynszu będą formą pomocy dla najmniej zarabiających w okresie wyższej inflacji - poinformował we wtorek premier Kanady Justin Trudeau.</p>


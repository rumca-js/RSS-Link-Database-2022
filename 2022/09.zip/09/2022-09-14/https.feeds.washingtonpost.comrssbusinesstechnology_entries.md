# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## California sues Amazon for anticompetitive behavior
 - [https://www.washingtonpost.com/technology/2022/09/14/california-amazon-antitrust-lawsuit/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/09/14/california-amazon-antitrust-lawsuit/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-14 14:33:46+00:00

California filed an antitrust suit against e-commerce giant Amazon on Wednesday.

## Apple’s iPhone 14: Dependable and boring, and that’s okay
 - [https://www.washingtonpost.com/technology/2022/09/14/iphone-14-review/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/09/14/iphone-14-review/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-14 09:00:00+00:00

The iPhone 14 is better than the iPhones that have come before it. But you’re going to have to look really, really close to even notice.

## I tried the new PlayStation VR2. It’s immersive, and a joy to wear.
 - [https://www.washingtonpost.com/video-games/2022/09/14/psvr2-ps5-horizon/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2022/09/14/psvr2-ps5-horizon/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-14 08:00:00+00:00

From the headset to the new "Horizon" game, Sony's latest VR tech feels more immersive than ever.

## VR developers accuse Facebook of withholding the keys to metaverse success
 - [https://www.washingtonpost.com/technology/2022/09/14/facebook-meta-virtual-reality-vr-competition/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/09/14/facebook-meta-virtual-reality-vr-competition/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-14 06:00:36+00:00

Since buying the small virtual reality startup Oculus eight years ago, Meta has become the dominant player in the space, claiming 90 percent of all virtual reality headset sales. The FTC has noticed.

## A tiny, unmanned plane could land almost anywhere for military intel
 - [https://www.washingtonpost.com/technology/2022/09/14/darpa-ancillary-vertical-takeoff-plane/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/09/14/darpa-ancillary-vertical-takeoff-plane/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-14 06:00:27+00:00

DARPA wants to create a tiny unmanned plane that could take off and land nearly anywhere in the world.


# Source:Jeff Gerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## I put a computer in my computer
 - [https://www.youtube.com/watch?v=cVWF3u-y-Zg](https://www.youtube.com/watch?v=cVWF3u-y-Zg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2022-09-15 00:00:00+00:00

The BliKVM PCIe lets you put a computer in your computer so you can control it from any computer.

Currently it's only for sale via AliExpress: https://www.aliexpress.com/item/3256804386522898.html

My other Pi-based KVM videos:

  - TinyPilot and PiKVM v3: https://www.youtube.com/watch?v=TIrkEr2AeDY
  - BliKVM: https://www.youtube.com/watch?v=3OPd7svT3bE

Support me on Patreon: https://www.patreon.com/geerlingguy
Sponsor me on GitHub: https://github.com/sponsors/geerlingguy
Merch: https://redshirtjeff.com
2nd Channel: https://www.youtube.com/c/GeerlingEngineering

#RaspberryPi #Homelab

Contents:

00:00 - A computer in my computer
01:34 - PCI Express... sorta
02:59 - Installation
03:47 - Intro to PiKVM
07:43 - Remote FPS Gaming?
09:34 - Better Call... PAUL?
10:43 - They thought of everything!
11:43 - Other Pi-based KVMs


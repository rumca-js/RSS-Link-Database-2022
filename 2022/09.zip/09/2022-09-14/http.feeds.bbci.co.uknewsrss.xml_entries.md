# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Patagonia: Billionaire boss of fashion retailer gives company away
 - [https://www.bbc.co.uk/news/business-62906853?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62906853?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 23:58:47+00:00

Yvon Chouinard will give all of the fashion company's profits to a charity fighting climate change.

## The Papers: 'Nation says farewell' in 'the long goodbye'
 - [https://www.bbc.co.uk/news/blogs-the-papers-62909782?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-62909782?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 23:54:55+00:00

The front pages focus on the Queen's coffin being taken to Westminster Hall where the public are paying their respects.

## Adnan Syed: Prosecutors seek new trial in Serial podcast case
 - [https://www.bbc.co.uk/news/world-us-canada-62909702?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62909702?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 23:54:41+00:00

A Baltimore prosecutor says an investigation of the case now points to two other possible suspects.

## Ukraine's President Zelensky involved in car accident
 - [https://www.bbc.co.uk/news/world-europe-62910236?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62910236?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 23:23:41+00:00

A passenger car collided with the Ukrainian president's vehicle in Kyiv, a spokesman says.

## Pakistan floods: Dengue cases soaring after record monsoon
 - [https://www.bbc.co.uk/news/world-asia-62907449?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62907449?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 23:18:00+00:00

Health officials warn of a looming crisis as deaths from dengue and other diseases rise by the day.

## Queen Elizabeth II: Hong Kong's grief sends message to Beijing
 - [https://www.bbc.co.uk/news/world-asia-china-62898660?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-62898660?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 23:10:34+00:00

The display of affection is also a way to express unhappiness at the situation in the former colony.

## Man City 2-1 Borussia Dortmund: The night Erling Haaland emulated Cruyff in Champions League
 - [https://www.bbc.co.uk/sport/football/62909920?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62909920?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 22:37:44+00:00

Manchester City beat Borussia Dortmund thanks to a sensational goal from Erling Haaland - one reminiscent of Johan Cruyff

## R. Kelly: Disgraced R&B star guilty of child abuse
 - [https://www.bbc.co.uk/news/world-us-canada-62909703?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62909703?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 22:37:39+00:00

The sex offender is convicted on six out of 13 counts after a four-week trial in Chicago.

## Kwasi Kwarteng considers scrapping bankers’ bonus cap to boost City
 - [https://www.bbc.co.uk/news/business-62906854?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62906854?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 21:58:00+00:00

The new chancellor believes removing a cap on bankers' bonuses could boost growth in the City.

## Shakhtar Donetsk 1-1 Celtic: Is there more to come in Champions League for Celtic?
 - [https://www.bbc.co.uk/sport/football/62896425?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62896425?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 21:57:43+00:00

Celtic just have a point from their first two Champions League games, but is there more to come from them?

## Manchester City 2-1 Borussia Dortmund: Erling Haaland scores winner as hosts come from behind
 - [https://www.bbc.co.uk/sport/football/62894559?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62894559?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 21:22:32+00:00

Erling Haaland scores winner as Man City come from behind to beat Borussia Dortmund in Champions League.

## Chelsea 1-1 FC Red Bull Salzburg: Hosts held to draw on Potter's first outing as manager
 - [https://www.bbc.co.uk/sport/football/62895693?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62895693?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 21:14:55+00:00

Graham Potter begins his Chelsea reign with a draw against RB Salzburg, which leaves his side with an uphill task to qualify for the Champions League knockout stages.

## Rangers 0-3 Napoli: Serie A leaders claim victory against 10-man hosts
 - [https://www.bbc.co.uk/sport/football/62863101?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62863101?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 20:58:30+00:00

Ten-man Rangers fall to their third straight heavy defeat despite a more encouraging performance against Napoli on a dramatic night in the Champions League.

## England 73-7 Wales: Red Roses win world record 25th consecutive Test
 - [https://www.bbc.co.uk/sport/rugby-union/62887874?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/62887874?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 20:39:49+00:00

England become the first team in history to win 25 Tests in a row as they finish their World Cup preparations with an 11-try win against Wales at Bristol's Ashton Gate.

## Citi offers junior bankers sun with Malaga office
 - [https://www.bbc.co.uk/news/business-62908411?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62908411?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 20:28:58+00:00

The US investment bank has opened a new office on the Costa del Sol to help recruit junior staff.

## Magdalena Andersson: Swedish PM resigns as right-wing parties win vote
 - [https://www.bbc.co.uk/news/world-europe-62908902?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62908902?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 20:26:09+00:00

The nation's first elected female leader is narrowly defeated in a major shift for Sweden.

## Round-up: Zelensky in freed city, while Scholz says Putin remains undaunted
 - [https://www.bbc.co.uk/news/world-europe-62908530?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62908530?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 20:10:07+00:00

Ukraine's president visits Izyum - while the German chancellor says President Putin does not think the invasion was a mistake.

## Rangers play national anthem before Napoli game; no silence in Poland for Celtic
 - [https://www.bbc.co.uk/sport/football/62899804?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62899804?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 19:01:15+00:00

Rangers play the national anthem and hold a minute's silence before their Champions League tie with Napoli to mark the death of Queen Elizabeth.

## Lying-in-state: The dazzling crown resting on top of the Queen’s coffin
 - [https://www.bbc.co.uk/news/uk-england-62906194?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-62906194?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 18:53:49+00:00

What’s the story behind the most iconic item in the Crown Jewels?

## Shakhtar Donetsk 1-1 Celtic: Scottish champions held in Warsaw by Ukrainians
 - [https://www.bbc.co.uk/sport/football/62863118?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62863118?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 18:50:41+00:00

Celtic endure a frustrating night as a resolute Shakhtar Donetsk side hold them to a Champions League draw in Warsaw.

## Police take to rooftops and manholes ahead of funeral for massive security operation
 - [https://www.bbc.co.uk/news/uk-62905786?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62905786?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 18:44:07+00:00

As emperors, kings, queens and presidents descend on London, police have embarked on a huge operation.

## Davis Cup: Great Britain trail United States 1-0 in opening group tie
 - [https://www.bbc.co.uk/sport/tennis/62904254?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62904254?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 18:17:43+00:00

Dan Evans narrowly loses to Tommy Paul to leave Great Britain trailing the United States 1-0 after the opening singles match of their Davis Cup group tie.

## Queen Elizabeth II: First night trains for mourners set to depart
 - [https://www.bbc.co.uk/news/business-62906851?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62906851?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 18:14:36+00:00

Night services will start on Wednesday after a busy day on London's trains and tubes.

## Lying-in-state: Viewing Queen's coffin 'gave me such pride'
 - [https://www.bbc.co.uk/news/uk-62907358?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62907358?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 17:53:05+00:00

Mourners speak of seeing the Queen lying in state, as thousands more wait to pay their respects.

## Armenia says 105 troops killed in Azerbaijan border clashes
 - [https://www.bbc.co.uk/news/world-europe-62828239?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62828239?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 17:17:24+00:00

World leaders are intensifying diplomatic efforts to stop a full-blown war.

## Ukraine war: Olaf Scholz says Vladimir Putin does not see war as mistake
 - [https://www.bbc.co.uk/news/world-europe-62907923?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62907923?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 17:12:21+00:00

The German chancellor spoke to the Russian president on the phone on Tuesday.

## Watch: How Queen Elizabeth's journey to lying-in-state unfolded
 - [https://www.bbc.co.uk/news/uk-62901409?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62901409?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 16:59:28+00:00

Queen Elizabeth's coffin is brought to Parliament to lie in state, so the public can pay their respects.

## Center Parcs: Further backlash against closure plan
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-62906112?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-62906112?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 15:40:05+00:00

Guests already on holiday can now stay on site but will not be able to use facilities.

## France must reconsider ban on IS members' return
 - [https://www.bbc.co.uk/news/world-europe-62905237?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62905237?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 15:37:15+00:00

The decision could create a political headache for a number of European governments.

## YouTuber guilty of Oval pitch invasion during England game
 - [https://www.bbc.co.uk/news/uk-england-london-62902808?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62902808?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 15:21:26+00:00

Daniel Jarvis ran into England batter Jonny Bairstow after entering the field during a Test.

## Ashley Dale: Murder arrests over woman shot in back garden
 - [https://www.bbc.co.uk/news/uk-england-merseyside-62906462?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-62906462?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 15:15:16+00:00

Three men are held on suspicion of murdering 28-year-old Ashley Dale in Liverpool.

## Asda limits sales of Just Essentials budget range
 - [https://www.bbc.co.uk/news/business-62905806?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62905806?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 14:56:25+00:00

The supermarket temporarily limits purchases in its Just Essentials range, blaming soaring demand.

## In Pictures: Royals follow Queen on sombre final journey
 - [https://www.bbc.co.uk/news/in-pictures-62905962?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-62905962?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 14:41:33+00:00

Royals follow in procession as Queen Elizabeth II leaves Buckingham Palace for the last time.

## Premier League: Minute's silence and national anthem part of tributes to Queen
 - [https://www.bbc.co.uk/sport/football/62905776?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62905776?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 14:30:13+00:00

All Premier League matches will begin with a minute's silence this weekend as part of tributes to the Queen.

## Brendon McCullum: James Anderson and Stuart Broad will be selected in England’s 2023 Ashes squad
 - [https://www.bbc.co.uk/sport/cricket/62892799?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62892799?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 14:00:05+00:00

England’s all-time leading Test wicket-takers James Anderson and Stuart Broad will be selected for the Ashes series against Australia next year, says head coach Brendon McCullum.

## Queen Elizabeth II leaves Buckingham Palace for the final time
 - [https://www.bbc.co.uk/news/uk-62903683?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62903683?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 13:41:42+00:00

Queen Elizabeth II leaves Buckingham Palace for the final time as her coffin makes its way to Westminster Hall.

## Ukraine war: President Zelensky visits city recaptured in rapid counter-offensive
 - [https://www.bbc.co.uk/news/world-europe-62899474?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62899474?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 13:30:28+00:00

Kyiv's troops are targeting towns in the Donbas region, the main focus of Russia's invasion.

## William and Harry side by side behind Queen's coffin
 - [https://www.bbc.co.uk/news/uk-62866247?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62866247?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 13:25:35+00:00

King Charles, Prince William and Prince Harry walk in procession together in a symbol of family unity.

## BBC to stream Queen Elizabeth II lying in state
 - [https://www.bbc.co.uk/news/uk-62900500?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62900500?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 13:17:51+00:00

The global streaming is for those wanting to pay their respects but are unable to travel to London.

## McDonald's to close for Queen's funeral on Monday
 - [https://www.bbc.co.uk/news/business-62903404?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62903404?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 13:14:17+00:00

The fast food chain will shut all its restaurants until 5pm on 19 September.

## New Hampshire primary race too close to call as Don Bolduc holds narrow lead
 - [https://www.bbc.co.uk/news/world-us-canada-62879464?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62879464?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 12:36:19+00:00

Republicans hope the race could be their path to winning back control of the Senate in November.

## Gavi: Midfielder signs new Barcelona contract until 2026 with 1bn euros release clause
 - [https://www.bbc.co.uk/sport/football/62892796?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62892796?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 12:11:34+00:00

Spain midfielder Gavi signs a new contract with Barcelona until 2026 with a 1bn euros (£865m) release clause.

## Lyra McKee: Niall Sheerin jailed for having gun used to kill journalist
 - [https://www.bbc.co.uk/news/uk-northern-ireland-60060498?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-60060498?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 12:09:28+00:00

Niall Sheerin was an associate of a "serious terrorist gang", says the judge at a court in Belfast.

## Camping overnight to see Queen's lying-in-state
 - [https://www.bbc.co.uk/news/uk-62902930?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62902930?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 11:27:44+00:00

Hundreds of people braved wet weather to be among the first people to see the Queen's coffin.

## Queen's funeral: Routine hospital care being postponed
 - [https://www.bbc.co.uk/news/health-62902341?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-62902341?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 10:56:14+00:00

Appointments, including for surgery and outpatient clinics, rescheduled because of Queen's funeral.

## London Marathon allows mass-participation runners to define as non-binary
 - [https://www.bbc.co.uk/sport/athletics/62900507?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/62900507?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 10:54:12+00:00

People entering next year's London Marathon mass participation event will be able to register as non-binary, rather than male or female.

## Ukraine war: EU moves to cut peak electricity use by 5%
 - [https://www.bbc.co.uk/news/world-europe-62899940?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62899940?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 10:35:16+00:00

EU chief Ursula von der Leyen also calls for windfall taxes on energy companies in a keynote speech.

## In Pictures: The people waiting to pay respects
 - [https://www.bbc.co.uk/news/in-pictures-62900732?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-62900732?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 10:27:37+00:00

Large queues are forming in London, as people wait for the Queen's lying-in-state to begin

## Liverpool manager Jurgen Klopp unimpressed with Todd Boehly's 'All-Star Premier League game' idea
 - [https://www.bbc.co.uk/sport/football/62899010?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62899010?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 09:53:45+00:00

Liverpool manager Jurgen Klopp is left non-plussed by new Chelsea owner Todd Boehly's idea of an US style All-Star game in the Premier League.

## Olivia Pratt-Korbel: Reward of £50k offered in hunt for girl's killer
 - [https://www.bbc.co.uk/news/uk-england-merseyside-62901060?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-62901060?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 09:51:06+00:00

The money has been put up for information leading to the conviction of Olivia Pratt-Korbel's killer.

## Queen Elizabeth II: Flight carrying coffin most tracked plane in history
 - [https://www.bbc.co.uk/news/uk-62900494?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62900494?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 09:36:04+00:00

Nearly six million people tried to follow the plane's route, causing the Flightradar24 site to crash.

## WATCH: Leaking pen bothers King Charles III at signing
 - [https://www.bbc.co.uk/news/uk-62901408?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62901408?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 09:33:58+00:00

The King was signing a book at Hillsborough Castle, a royal residence in Northern Ireland.

## Danny Schofield: Huddersfield Town sack head coach after nine games
 - [https://www.bbc.co.uk/sport/football/62901280?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62901280?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 09:33:27+00:00

Huddersfield Town sack head coach Danny Schofield after just one win from his nine games in charge.

## Claire Foy: The Crown actress 'honoured' to have played the Queen
 - [https://www.bbc.co.uk/news/entertainment-arts-62899950?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62899950?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 08:45:42+00:00

The Crown actress says the late monarch was "a massive symbol of continuity and dignity and grace".

## Robert Sarver: Suns owner suspended and fined $10m for misconduct
 - [https://www.bbc.co.uk/sport/basketball/62899194?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/basketball/62899194?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 07:06:10+00:00

Robert Sarver, owner of the Phoenix Suns, is suspended for a year and fined $10m after an NBA investigation into claims of workplace racism and misogyny.

## UK inflation rate eases but still near 40-year high
 - [https://www.bbc.co.uk/news/uk-62891168?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62891168?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 06:43:09+00:00

Price rises slow slightly in August but the pace of inflation is still near a 40-year high.

## Iowa teen who killed alleged rapist sentenced and fined
 - [https://www.bbc.co.uk/news/world-us-canada-62898366?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62898366?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 05:58:09+00:00

Pieper Lewis, now 17, is put on probation for five years over the deadly stabbing in Iowa in 2020.

## Queen lying in state: Queuing through the night to 'say hello and goodbye'
 - [https://www.bbc.co.uk/news/uk-62898548?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62898548?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 05:56:02+00:00

People are queuing through the night for the chance to walk past the Queen's coffin in Westminster.

## Queen Elizabeth II: Woolly postbox topper tributes appear across England
 - [https://www.bbc.co.uk/news/uk-england-62893596?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-62893596?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 05:04:26+00:00

The Royal Mail says it admires the "creativity" that has gone into producing the toppers.

## Welsh breeder's dog fathered Queen's corgi
 - [https://www.bbc.co.uk/news/uk-wales-42337986?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-42337986?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-14 05:04:17+00:00

A Welsh corgi breeder recalls a special appointment with the Queen to help with her pet project.


# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## ‘No Religious Group Is Safe From Government Control’: SCOTUS Makes Yeshiva University Return To NY Court, Forces Acceptance Of LGBTQ Club
 - [https://www.dailywire.com/news/no-religious-group-is-safe-from-government-control-scotus-makes-yeshiva-university-return-to-ny-court-forces-acceptance-of-lgbtq-club](https://www.dailywire.com/news/no-religious-group-is-safe-from-government-control-scotus-makes-yeshiva-university-return-to-ny-court-forces-acceptance-of-lgbtq-club)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 22:27:14+00:00

The Supreme Court has temporarily forced Yeshiva University (YU), the famed Orthodox Jewish university in New York, to accept an LGBTQ club against its wishes. The university had asked for a stay of a Manhattan judge’s order YU grant recognition to the Yeshiva University Pride Alliance; on Friday, Justice Sonia Sotomayor granted the emergency petition, ...

## Tucker Carlson Teases Interview With Gina Carano On Trans Pronouns, Mask Mandates, Star’s Return To The Screen
 - [https://www.dailywire.com/news/tucker-carlson-teases-interview-with-gina-carano-on-trans-pronouns-mask-mandates-stars-return-to-the-screen](https://www.dailywire.com/news/tucker-carlson-teases-interview-with-gina-carano-on-trans-pronouns-mask-mandates-stars-return-to-the-screen)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 22:05:10+00:00

Gina Carano, star of The Daily Wire’s “Terror on the Prairie,” joined Tucker Carlson for a long-form interview that will air Thursday morning, and the Fox News host gave his audience a teaser Wednesday night of what to expect from the actress. In the short clip of the interview played by Fox News, Carano discussed ...

## McConnell Rips Dems For Blocking GOP Railroad Bill That Would Avoid Nationwide Strike
 - [https://www.dailywire.com/news/mcconnell-rips-dems-for-blocking-gop-railroad-bill-that-would-avoid-nationwide-strike](https://www.dailywire.com/news/mcconnell-rips-dems-for-blocking-gop-railroad-bill-that-would-avoid-nationwide-strike)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 21:42:09+00:00

On Wednesday, Senator Bernie Sanders (I-VT) blocked a resolution offered by Republicans to resolve the stalemate that could lead to a crippling railroad strike that could savage the U.S. economy. The resolution, introduced by GOP Senators Richard M. Burr of North Carolina and Roger Wicker of Mississippi, would force unions and freight railroads to accept ...

## WATCH: Queen’s Guard Collapses In Front Of Her Coffin
 - [https://www.dailywire.com/news/watch-queens-guard-collapses-in-front-of-her-coffin](https://www.dailywire.com/news/watch-queens-guard-collapses-in-front-of-her-coffin)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 21:28:04+00:00

A guard fainted on Wednesday while standing on a stage where the coffin of Queen Elizabeth II was being displayed. Videos of the incident that quickly went viral online showed the man wobbling and struggling to stand on the stage for several moments before he ultimately collapsed. The Daily Mail reported that the livestream feed ...

## More Than 100 House Republicans Demand Answers From Credit Card Giants Categorizing Sales At Gun Stores
 - [https://www.dailywire.com/news/more-than-100-house-republicans-demand-answers-from-credit-card-giants-categorizing-sales-at-gun-stores](https://www.dailywire.com/news/more-than-100-house-republicans-demand-answers-from-credit-card-giants-categorizing-sales-at-gun-stores)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 20:33:10+00:00

More than 100 House Republicans are demanding answers from major credit card companies over the controversial decision to categorize gun sales. In letters to the CEOs of Visa, MasterCard, and American Express, Rep. Elise Stefanik (R-NY) and House Republicans demanded the companies answer questions about their decision to adopt new Merchant Category Codes (MCCs) set ...

## Ron DeSantis Flies Planes Full Of Illegal Immigrants To Martha’s Vineyard, Report Says
 - [https://www.dailywire.com/news/breaking-ron-desantis-flies-planes-full-of-illegal-immigrants-to-marthas-vineyard-report-says](https://www.dailywire.com/news/breaking-ron-desantis-flies-planes-full-of-illegal-immigrants-to-marthas-vineyard-report-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 20:01:45+00:00

Florida Republican Governor Ron DeSantis followed through Wednesday on a promise to send illegal immigrants to Democrat-controlled areas by sending two planes of illegal immigrants to Martha&#8217;s Vineyard, a Massachusetts island, that is home to wealthy progressives like former President Barack Obama (D). &#8220;Yes, Florida can confirm the two planes with illegal immigrants that arrived ...

## Superstar Actor Almost Missed His Own Wedding After Being Rushed To The Emergency Room
 - [https://www.dailywire.com/news/superstar-actor-almost-missed-his-own-wedding-after-being-rushed-to-the-emergency-room](https://www.dailywire.com/news/superstar-actor-almost-missed-his-own-wedding-after-being-rushed-to-the-emergency-room)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 19:25:11+00:00

Superstar Josh Duhamel was hours away from walking down the aisle to marry former pageant queen Audra Mari when he had to be rushed to the emergency room after he had a bit too much fun dancing the night before. The 28-year-old model said the 49-year-old actor was partying the night before the couple&#8217;s big ...

## Democrat Charlie Crist’s Running Mate Effectively Mocks Special Needs Children As ‘Dysfunctional’
 - [https://www.dailywire.com/news/democrat-charlie-crists-running-mate-effectively-mocks-special-needs-children-as-dysfunctional](https://www.dailywire.com/news/democrat-charlie-crists-running-mate-effectively-mocks-special-needs-children-as-dysfunctional)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 19:20:54+00:00

Karla Hernandez-Mats, the running mate of Florida gubernatorial candidate Charlie Crist (D), is facing backlash after videos surfaced showing her effectively mocking special needs students as &#8220;dysfunctional.&#8221; Hernandez-Mats suggested during a campaign event in Cape Coral that she was qualified to be state&#8217;s next lieutenant governor because she used to be a special education teacher. ...

## Report: Crop Shipments To Stop At Some Railroads Thursday
 - [https://www.dailywire.com/news/report-crop-shipments-to-stop-at-some-railroads-thursday](https://www.dailywire.com/news/report-crop-shipments-to-stop-at-some-railroads-thursday)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 19:14:48+00:00

Some railroads are going to stop shipping crops on Thursday in anticipation of a possible railway strike, according to sources via Reuters.  Upsets in shipping could lend to the already steep inflation as farmers are beginning to harvest and send fall crops to producers. Farmers are also reportedly set to put fertilizer on their land ...

## R. Kelly Convicted On Multiple Charges, Including Child Pornography
 - [https://www.dailywire.com/news/r-kelly-convicted-on-multiple-charges-including-child-pornography](https://www.dailywire.com/news/r-kelly-convicted-on-multiple-charges-including-child-pornography)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 18:39:13+00:00

Disgraced singer R. Kelly has been convicted on multiple charges in his ongoing trial in his hometown of Chicago, including several counts of child pornography. The 55-year-old performer was found guilty on three of four counts of child pornography by a federal jury after they deliberated for two days over 11 hours, the Associated Press ...

## Senator Hirono Calls Fighting Pro-Lifers ‘Literally’ A ‘Call To Arms’ After Pro-Life Centers Attacked
 - [https://www.dailywire.com/news/senator-hirono-calls-fighting-pro-lifers-literally-a-call-to-arms-after-pro-life-centers-attacked](https://www.dailywire.com/news/senator-hirono-calls-fighting-pro-lifers-literally-a-call-to-arms-after-pro-life-centers-attacked)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 18:26:59+00:00

Sen. Mazie Hirono (D-HI) called the political Left&#8217;s opposition to Republicans&#8217; pro-life agenda &#8220;literally&#8221; a &#8220;call to arms in our country&#8221; during remarks Wednesday on the Senate floor. Hirono&#8217;s remarks come after churches and pro-life pregnancy centers and organizations came under attack following the overturning of Roe v. Wade. Data compiled by the Susan B. Anthony ...

## Michigan School District Removes LGBTQ-Themed Books From Public Schools After Parents Complain
 - [https://www.dailywire.com/news/michigan-school-district-removes-lgbtq-themed-books-from-public-schools-after-parents-complain](https://www.dailywire.com/news/michigan-school-district-removes-lgbtq-themed-books-from-public-schools-after-parents-complain)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 18:18:07+00:00

The Dearborn, Michigan, school district has pulled seven books from its schools’ libraries, including titles with LGBTQ themes, after parents complained. Dearborn Public Schools said the removal is temporary as it reviews the books that children can access at school libraries. One mother was shocked by some of the books’ contents after she told her ...

## Casey DeSantis: Parents ‘Should Be Skeptical’ Of Health Officials Who Lied During The Pandemic
 - [https://www.dailywire.com/news/casey-desantis-parents-should-be-skeptical-of-health-officials-who-lied-during-the-pandemic](https://www.dailywire.com/news/casey-desantis-parents-should-be-skeptical-of-health-officials-who-lied-during-the-pandemic)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 18:16:22+00:00

CORAL GABLES, Fla. — Florida&#8217;s first lady Casey DeSantis doesn&#8217;t blame parents for being skeptical of health officials who repeatedly flip-flopped on coronavirus guidance throughout the pandemic. In an August interview with The Daily Wire following a &#8220;Mamas for DeSantis&#8221; event, DeSantis discussed how the coronavirus pandemic has changed the way that parents look at political ...

## Manchin’s Permitting Reform Side Deal Collapsing As Republicans Blast Bill And Propose Their Own
 - [https://www.dailywire.com/news/manchins-permitting-reform-side-deal-collapsing-as-republicans-blast-bill-and-propose-their-own](https://www.dailywire.com/news/manchins-permitting-reform-side-deal-collapsing-as-republicans-blast-bill-and-propose-their-own)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 18:08:10+00:00

Sen. Joe Manchin&#8217;s (D-WV) side deal with Democrats on permitting reform is continuing to break down, as Republicans are now signaling their opposition. In exchange for his vote on the Inflation Reduction Act, Manchin struck a deal with Democratic leadership to include a bill reforming the energy permitting system in a stopgap government funding bill. ...

## Christian Nationalism: America’s Traditional Political Order
 - [https://www.dailywire.com/news/christian-nationalism-americas-traditional-political-order](https://www.dailywire.com/news/christian-nationalism-americas-traditional-political-order)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 17:53:26+00:00

The following remarks were delivered on Tuesday, September 13, 2022, at the third annual National Conservatism Conference in Miami. It is such a pleasure to be with all of you “semi-fascists” and “extreme threats to our democracy,” as the President affectionately calls you. And not just you, of course. When Biden refers to “semi-fascists” and ...

## California Sues Amazon
 - [https://www.dailywire.com/news/california-sues-amazon](https://www.dailywire.com/news/california-sues-amazon)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 17:41:55+00:00

California filed a lawsuit against Amazon on Wednesday, claiming that the company limits price competition through its practices. California Attorney General Rob Bonta filed an antitrust suit against the company. The lawsuit only applies to California, but if it is successful, it could have a major effect on the rest of the country. “If you ...

## MIDTERM EXAM: All The Latest On The 2022 Elections (Part One)
 - [https://www.dailywire.com/news/midterm-exam-all-the-latest-on-the-2022-elections-part-one-5](https://www.dailywire.com/news/midterm-exam-all-the-latest-on-the-2022-elections-part-one-5)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 17:26:06+00:00

Happy Wednesday, welcome to this week&#8217;s first edition of the Midterm Exam. We&#8217;ll start by going over some of the latest data in the Senate polls, then jump into some juicy tidbits out of Nevada, Arizona, Wisconsin, North Carolina, and Colorado. If there is a major story we don&#8217;t have covered in this exam, it ...

## ‘Too Enthusiastic And Fiery’: Nursing Home Issues Apology After Video Goes Viral Of Stripper Hired To Entertain Residents
 - [https://www.dailywire.com/news/too-enthusiastic-and-fiery-nursing-home-issues-apology-after-video-goes-viral-of-stripper-hired-to-entertain-residents](https://www.dailywire.com/news/too-enthusiastic-and-fiery-nursing-home-issues-apology-after-video-goes-viral-of-stripper-hired-to-entertain-residents)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 17:24:55+00:00

A nursing home has issued an apology after video went viral of a stripper hired to entertain wheel-chair bound senior citizens at a veteran home for retired army personnel. A spokesperson for the state-run Taoyuan Veterans Home in Taiwan explained that the exotic dancer was brought in to lift the spirits of the seniors was ...

## ‘Nobody Is Coming’: How A Dangerous Afghan Rescue Mission Became A 21st Century Underground Railroad
 - [https://www.dailywire.com/news/nobody-is-coming-how-a-dangerous-afghan-rescue-mission-became-a-21st-century-underground-railroad](https://www.dailywire.com/news/nobody-is-coming-how-a-dangerous-afghan-rescue-mission-became-a-21st-century-underground-railroad)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 17:13:24+00:00

For two decades in Iraq and Afghanistan, the American military fought for the freedom of a nation, created bonds of brotherhood between two countries, and made promises on the ground to our soldiers. But last August, with the withdrawal of U.S. troops from the region, 20 years of relationships were squandered in the blink of ...

## ‘These Are My Children, And We Fight For Them’: Florida’s First Lady Rallies Mamas To The Polls
 - [https://www.dailywire.com/news/these-are-my-children-and-we-fight-for-them-floridas-first-lady-rallies-mamas-to-the-polls](https://www.dailywire.com/news/these-are-my-children-and-we-fight-for-them-floridas-first-lady-rallies-mamas-to-the-polls)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 17:03:31+00:00

CORAL GABLES, Fla. — Spurred by leftist culture wars to protect their children, mamas, grandmas, abuelas, and nanas may be some of the most pivotal voters in the Florida&#8217;s upcoming midterm elections, according to Florida&#8217;s first lady, Casey DeSantis. Virginia&#8217;s recent gubernatorial race proved to the country just how vital a role mothers and grandmothers ...

## ‘I’m Not Delusional’: Stacey Abrams Claims She ‘Never Denied’ Losing In 2018
 - [https://www.dailywire.com/news/im-not-delusional-stacey-abrams-claims-she-never-denied-losing-in-2018](https://www.dailywire.com/news/im-not-delusional-stacey-abrams-claims-she-never-denied-losing-in-2018)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 16:36:28+00:00

Democratic Georgia gubernatorial candidate Stacey Abrams claimed Wednesday that she had &#8220;never denied&#8221; losing the 2018 gubernatorial race to current Governor Brian Kemp (R-GA). Abrams made the claim on ABC&#8217;s midday talk show &#8220;The View,&#8221; saying that she was &#8220;not delusional&#8221; and would likely have noticed had she been living in the Georgia governor&#8217;s mansion all ...

## Amtrak Cancels All Long-Distance Travel Ahead Of Possible Nationwide Railroad Strike
 - [https://www.dailywire.com/news/amtrak-cancels-all-long-distance-travel-ahead-of-possible-nationwide-railroad-strike](https://www.dailywire.com/news/amtrak-cancels-all-long-distance-travel-ahead-of-possible-nationwide-railroad-strike)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 16:27:07+00:00

Amtrak announced cancellations of all long-distance train routes this week ahead of a nationwide railroad strike that could begin as soon as Friday. BNSF, CSX, Norfolk Southern, and Union Pacific announced embargoes on certain shipments earlier this week as negotiations continue with multiple rail unions. Amtrak, whose employees are not involved with the negotiations, operates ...

## Dem Rep Joins Jill Biden Slamming Parents Protesting At School Board Meetings, Compares Them To Jan 6
 - [https://www.dailywire.com/news/dem-rep-joins-jill-biden-slamming-parents-protesting-at-school-board-meetings-compares-them-to-jan-6](https://www.dailywire.com/news/dem-rep-joins-jill-biden-slamming-parents-protesting-at-school-board-meetings-compares-them-to-jan-6)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 16:20:40+00:00

In yet another attempt by Democrats to link those who acted terribly on January 6, 2021, with conservatives standing up on other issues, Rep. Hank Johnson (D-GA) compared conservative parents who have protested at school board meetings to the miscreants of January 6. Johnson’s comments dovetailed with first lady Jill Biden implicitly criticizing parents who ...

## ‘We’re Going To Change The Rules’: Rand Paul Threatens Fauci In Testy Senate Spat
 - [https://www.dailywire.com/news/were-going-to-change-the-rules-rand-paul-threatens-fauci-in-testy-senate-spat](https://www.dailywire.com/news/were-going-to-change-the-rules-rand-paul-threatens-fauci-in-testy-senate-spat)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 15:54:35+00:00

Senator Rand Paul (R-KY) threatened Dr. Anthony Fauci during a testy hearing on Wednesday, making it abundantly clear that things would be different if Republicans were to gain control of Congress in the fast-approaching midterm elections. Fauci, who was on Capitol Hill to discuss the federal government&#8217;s response to monkeypox, has sparred with the Kentucky ...

## Ben Shapiro, Candace Owens On Kim Kardashian And A Sinister Threat To American Families
 - [https://www.dailywire.com/news/ben-shapiro-candace-owens-on-kim-kardashian-and-a-sinister-threat-to-american-families](https://www.dailywire.com/news/ben-shapiro-candace-owens-on-kim-kardashian-and-a-sinister-threat-to-american-families)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 15:49:50+00:00

A book Ben Shapiro wrote nearly 20 years ago about the danger of normalizing pornography proved prescient as the Daily Wire co-founder chatted Wednesday with Candace Owens on his podcast and radio show. The book, “Porn Generation,” explored the mainstream embrace of socially destructive pornography, which has only gotten much worse, agreed the author and Owens, ...

## Explicit Images Sent To Parents On Hacked School Messaging App
 - [https://www.dailywire.com/news/explicit-images-sent-to-parents-on-hacked-school-messaging-app](https://www.dailywire.com/news/explicit-images-sent-to-parents-on-hacked-school-messaging-app)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 15:45:56+00:00

A hacker sent explicit images to parents and teachers over a popular school messaging app, the company said Wednesday. Parents and teachers received the explicit photo in private chats on Seesaw, a student engagement platform, districts in Illinois, New York, Oklahoma, and Texas said Wednesday. The explicit photo was sent through a &#8220;bit.ly&#8221; link. Bit.ly is a popular ...

## TV Review Says Hillary Clinton Series Lacks ‘Depth,’ ‘Personality,’ And More
 - [https://www.dailywire.com/news/tv-review-says-hillary-clinton-series-lacks-depth-personality-and-more](https://www.dailywire.com/news/tv-review-says-hillary-clinton-series-lacks-depth-personality-and-more)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 15:38:51+00:00

TV reviewers wrote that Hillary and Chelsea Clinton&#8217;s new Apple TV series &#8220;Gutsy&#8221; lacks &#8220;depth,&#8221; &#8220;personality,&#8221; and more. In one recent review from The Hollywood Reporter titled, &#8220;&#8216;Gutsy&#8217; Review: Hillary and Chelsea Clinton&#8217;s Blandly Uplifting Apple TV+ Docuseries,&#8221; the reviewer said even &#8220;pro-Clinton viewers&#8221; might struggle with the fact that both &#8220;Clintons are lackluster as ...

## Judge Shoots Down Twitter’s Attempt To Access Elon Musk’s Emails
 - [https://www.dailywire.com/news/judge-shoots-down-twitters-attempt-to-access-elon-musks-emails](https://www.dailywire.com/news/judge-shoots-down-twitters-attempt-to-access-elon-musks-emails)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 15:30:03+00:00

Tesla and SpaceX CEO Elon Musk will not have to surrender his corporate emails amid a legal battle with Twitter, the judge overseeing the case decided on Tuesday. Twitter is currently battling Musk in court over his attempt to cancel a previous offer to buy the social media platform for $44 billion. Lawyers representing Twitter ...

## Pelosi’s Pitiful Plea For Applause Was Pathetically Perfect
 - [https://www.dailywire.com/news/pelosis-pitiful-plea-for-applause-was-pathetically-perfect](https://www.dailywire.com/news/pelosis-pitiful-plea-for-applause-was-pathetically-perfect)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 15:17:58+00:00

Put your hands together for Nancy Pelosi! But first, a brief history of applause. Clapping our hands is a human social gesture &#8212; born thousands of years ago &#8212; to show approval and admiration. While there is the polite golf clap for a well-struck shot, nearly all other types of applause come from the heart ...

## Americans Are Getting Raises That Fail To Keep Up With Record Inflation
 - [https://www.dailywire.com/news/americans-are-getting-raises-that-fail-to-keep-up-with-record-inflation](https://www.dailywire.com/news/americans-are-getting-raises-that-fail-to-keep-up-with-record-inflation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 15:01:24+00:00

Americans report receiving wage increases that fail to keep pace with record inflation, according to a Wednesday survey from Bankrate. Price levels between August 2021 and August 2022 rose 8.3%, according to data from the Bureau of Labor Statistics. The reading marked a decline from the 8.5% rate seen in July 2022 and the 9.1% ...

## Ryan Reynolds Says A Bet Lead To Him Undergoing ‘Life-Saving’ Procedure
 - [https://www.dailywire.com/news/ryan-reynolds-says-a-bet-lead-to-him-undergoing-life-saving-procedure](https://www.dailywire.com/news/ryan-reynolds-says-a-bet-lead-to-him-undergoing-life-saving-procedure)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 14:54:08+00:00

Superstar Ryan Reynolds said a bet with fellow actor Rob McElhenney lead to him undergo a colonoscopy — which a doctor said turned out to be a &#8220;life-saving&#8221; procedure after they discovered a polyp. In a video the 45-year-old actor posted on YouTube Tuesday, the &#8220;Deadpool&#8221; star and his fellow Wrexham soccer club co-chairman — ...

## Man In Reflective Vest And Clown Wig Storms Dairy Queen To Restore ‘President King’ Trump
 - [https://www.dailywire.com/news/man-in-reflective-vest-and-clown-wig-storms-dairy-queen-to-restore-president-king-trump](https://www.dailywire.com/news/man-in-reflective-vest-and-clown-wig-storms-dairy-queen-to-restore-president-king-trump)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 14:48:16+00:00

A man wearing a reflective vest and a rainbow-colored clown wig stormed a Dairy Queen in Pennsylvania on Saturday, carrying a loaded gun and telling police that he was working &#8220;undercover&#8221; and planned to &#8220;restore Trump to president king of the United States.&#8221; According to the Delmont police, the Westmoreland County man is now facing ...

## The American Proposition: What Honest Abe’s Warnings Can Teach Us This Constitution Day
 - [https://www.dailywire.com/news/the-american-proposition-what-honest-abes-warnings-can-teach-us-this-constitution-day](https://www.dailywire.com/news/the-american-proposition-what-honest-abes-warnings-can-teach-us-this-constitution-day)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 14:38:06+00:00

It is no coincidence that as America has become more ignorant, it has also become more cynical, more factional, and less confident. As Constitution Day approaches, learn what it means to be an American and what everyday citizens can do about it. Most Americans are somewhat familiar with the hagiographic version of Abraham Lincoln: the ...

## ‘I Love The Corvette’: Biden Revs, Praises Gas-Powered Sports Car While Touting Electric Vehicles
 - [https://www.dailywire.com/news/i-love-the-corvette-biden-revs-praises-gas-powered-sports-car-while-touting-electric-vehicles](https://www.dailywire.com/news/i-love-the-corvette-biden-revs-praises-gas-powered-sports-car-while-touting-electric-vehicles)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 14:23:49+00:00

Even President Joe Biden may prefer gas-powered cars to electric vehicles. On Wednesday, the president flew the gas-guzzling Air Force 1 to Michigan for a tour of the 2022 North American International Auto Show at Huntington Place Convention Center in Detroit, Michigan. The field trip was billed as an effort to promote electric vehicles. Once there, Biden ...

## ‘The View’ Host Falsely Claims There Is ‘No Such Thing’ As People Having Late-Term Abortions
 - [https://www.dailywire.com/news/the-view-host-falsely-claims-there-is-no-such-thing-as-people-having-late-term-abortions](https://www.dailywire.com/news/the-view-host-falsely-claims-there-is-no-such-thing-as-people-having-late-term-abortions)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 14:21:13+00:00

&#8220;The View&#8221; host Sara Haines falsely claimed on Wednesday that there was &#8220;no such thing&#8221; as people having late-term abortions — and then immediately noted exactly how many people were actually having late-term abortions. Haines joined her cohosts on the ABC midday talk show to discuss the legislation that would ban all abortions federally after ...

## Rail Union Rejects Labor Deal As White House Scrambles To Avoid Nationwide Railroad Strike
 - [https://www.dailywire.com/news/rail-union-rejects-labor-deal-as-white-house-scrambles-to-avoid-nationwide-railroad-strike](https://www.dailywire.com/news/rail-union-rejects-labor-deal-as-white-house-scrambles-to-avoid-nationwide-railroad-strike)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 14:11:39+00:00

The International Association of Machinists and Aerospace Workers (IAM) said on Wednesday that its members rejected a tentative deal by its leaders intended to avoid a nationwide railroad strike. BNSF, CSX, Norfolk Southern, and Union Pacific — four of the nation’s largest rail lines — announced embargoes on certain shipments earlier this week as negotiations ...

## This Year’s Emmy Awards Viewership Hit A New Record Low
 - [https://www.dailywire.com/news/this-years-emmy-awards-viewership-hit-a-new-record-low](https://www.dailywire.com/news/this-years-emmy-awards-viewership-hit-a-new-record-low)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 13:42:27+00:00

Following the trend of many other awards shows, the 74th Annual Emmy Awards saw a steep decline in viewership, delivering its lowest ratings yet. Per The New York Post, a mere 5.9 million people tuned in for “television’s biggest night,” representing a 25% decrease compared to last year. The outlet also reported that this year’s ...

## Convicted Of A Murder She Allegedly Committed When She Was 13, Angel Bumpass Now Gets A New Trial
 - [https://www.dailywire.com/news/convicted-of-a-murder-she-allegedly-committed-when-she-was-13-angel-bumpass-now-gets-a-new-trial](https://www.dailywire.com/news/convicted-of-a-murder-she-allegedly-committed-when-she-was-13-angel-bumpass-now-gets-a-new-trial)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 13:29:56+00:00

On January 16, 2009, Franklin Bonner’s wife Linda found him tied to a table and chair in their Chattanooga, Tennessee home, apparently murdered during a robbery attempt. When officers arrived at Bonner’s home, they found the house had been ransacked, but very little to suggest who was responsible, Law &amp; Crime reported. For 10 years, ...

## Woman Accused Of Killing Woman To Steal Her Unborn Baby Goes On Trial
 - [https://www.dailywire.com/news/woman-accused-of-killing-woman-to-steal-her-unborn-baby-goes-on-trial](https://www.dailywire.com/news/woman-accused-of-killing-woman-to-steal-her-unborn-baby-goes-on-trial)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 13:27:26+00:00

A Texas woman who allegedly killed another woman in order to steal that woman’s unborn baby went on trial Monday in a case that’s eerily familiar. Taylor Rene Parker, 29, allegedly killed Regan Michelle Simmons-Hancock, 21, and her unborn daughter in New Boston on October 9, 2020. Parker has pleaded not guilty to capital murder ...

## Tragedy At CNN As Legal Commentator, Noted Defense Attorney Drowns Off Georgia Island
 - [https://www.dailywire.com/news/cnn-legal-commentator-noted-defense-attorney-drowns-off-georgia-island](https://www.dailywire.com/news/cnn-legal-commentator-noted-defense-attorney-drowns-off-georgia-island)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 13:17:02+00:00

A prominent defense attorney and CNN legal contributor drowned after being swept out to sea while swimming off the coast of a Georgia island. Page Pate, 55, was swimming with his teenage son off St. Simons Island, Georgia, Sunday when the current pulled him out, according to The Brunswick News. The Atlanta-based trial attorney and ...

## Ohio Teachers Can Now Carry Guns In Classrooms
 - [https://www.dailywire.com/news/ohio-teachers-can-now-carry-guns-in-classrooms](https://www.dailywire.com/news/ohio-teachers-can-now-carry-guns-in-classrooms)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 12:29:24+00:00

An Ohio law allowing teachers to carry guns in the classroom is now in effect. House Bill 99, the legislation that permits teachers and staff to carry firearms on campus after 24 hours of training and eight annual training hours, was signed in June and became law on Monday. “My office worked with the General ...

## Candace Owens Says Kim Kardashian Is A ‘Prostitute,’ Mother A ‘Pimp’ Over New Ray J Allegations About Infamous Sex Tape
 - [https://www.dailywire.com/news/candace-owens-says-kim-kardashian-is-a-prostitute-mother-a-pimp-over-new-ray-j-allegations-about-infamous-sex-tape](https://www.dailywire.com/news/candace-owens-says-kim-kardashian-is-a-prostitute-mother-a-pimp-over-new-ray-j-allegations-about-infamous-sex-tape)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 12:18:37+00:00

Daily Wire host Candace Owens said Tuesday on her new daily podcast that Kim Kardashian is a &#8220;prostitute&#8221; and her mother, Kris Jenner, is a &#8220;pimp&#8221; for allegedly being in on the infamous sex tape featuring Kardashian and her ex-boyfriend Ray J. Ray J, full name William Ray Norwood Jr., claimed over the weekend that ...

## ‘All Books Should Be In The Library’: Jill Biden Takes Shot At Parents Concerned About Inappropriate Books In School Libraries
 - [https://www.dailywire.com/news/all-books-should-be-in-the-library-jill-biden-takes-shot-at-parents-concerned-about-inappropriate-books-in-school-libraries](https://www.dailywire.com/news/all-books-should-be-in-the-library-jill-biden-takes-shot-at-parents-concerned-about-inappropriate-books-in-school-libraries)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 12:10:33+00:00

First Lady Jill Biden, who got her doctoral degree in educational from the University of Delaware, implicitly criticized American parents who feel inappropriate books are lying on the bookshelves of the children’s school libraries. In recent years, many parents have stood up to school boards and denounced schools for their inclusion of books they feel ...

## White House Grapples To Avoid Nationwide Railroad Strike That Could Send Gas Prices Soaring, Hamstring Supply Chain
 - [https://www.dailywire.com/news/white-house-grapples-to-avoid-nationwide-railroad-strike-that-could-send-gas-prices-soaring-hamstring-supply-chain](https://www.dailywire.com/news/white-house-grapples-to-avoid-nationwide-railroad-strike-that-could-send-gas-prices-soaring-hamstring-supply-chain)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 12:07:36+00:00

The White House is seeking to prevent a nationwide railroad strike that could worsen supply chain bottlenecks and increase gas prices. BNSF, CSX, Norfolk Southern, and Union Pacific announced embargoes on certain shipments earlier this week as negotiations continue with two of the nation’s largest rail unions — the Brotherhood of Locomotive Engineers and Trainmen ...

## Watchdog To Probe IRS After Hundreds Of Employees Failed To Pay Taxes
 - [https://www.dailywire.com/news/watchdog-to-probe-irs-after-hundreds-of-employees-failed-to-pay-taxes](https://www.dailywire.com/news/watchdog-to-probe-irs-after-hundreds-of-employees-failed-to-pay-taxes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 11:55:03+00:00

The audit was initiated at the request of Sen. Joni Ernst (R-IA) following a Democrat plan that could hire 87,000 new employees at the tax enforcement agency. The Treasury Inspector General for Tax Administration has previously found that hundreds of IRS employees may have failed to pay their own taxes, with some offering excuses such as they didn&#8217;t know how.

## Leftist Lena Dunham Debuts Film Targeting Young Adults, Critics Rave
 - [https://www.dailywire.com/news/leftist-lena-dunham-debuts-film-targeting-young-adults-critics-rave](https://www.dailywire.com/news/leftist-lena-dunham-debuts-film-targeting-young-adults-critics-rave)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 11:53:18+00:00

Outspoken feminist and leftist actress Lena Dunham is debuting a coming-of-age story aimed at young adults, and critics are already fawning over the medieval comedy. Dunham is best known for the HBO series “Girls,” which was full of sex, nudity, and drugs. But now the 36-year-old creator is focusing on messaging targeting a younger crowd. ...

## The Pampered Prince Becomes King: All The Rumors About King Charles’ Fussy Demands
 - [https://www.dailywire.com/news/the-pampered-prince-becomes-king-all-the-rumors-about-king-charles-fussy-demands](https://www.dailywire.com/news/the-pampered-prince-becomes-king-all-the-rumors-about-king-charles-fussy-demands)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 11:25:09+00:00

It’s been less than a week since King Charles III ascended the throne and already the new monarch is getting some negative press. The first incident occurred when cameras caught Charles making an overly annoyed face when a staff member didn’t remove a pen tray that was in his way quickly enough. The caption of ...

## Don Bolduc Claims Victory In New Hampshire Senate Primary, Chuck Morse Concedes
 - [https://www.dailywire.com/news/don-bolduc-claims-victory-in-new-hampshire-senate-primary-chuck-morse-concedes](https://www.dailywire.com/news/don-bolduc-claims-victory-in-new-hampshire-senate-primary-chuck-morse-concedes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 11:06:30+00:00

Don Bolduc has claimed victory in New Hampshire&#8217;s Republican primary for Senate. The Associated Press has not yet called the race for Bolduc, but he leads his opponent, state Senator Chuck Morse, by about one percentage point. The retired Army general garnered 37% of the vote to Morse&#8217;s 36%, a lead of only about 1,300 ...

## European Union ‘Social Market Economy’ Might Redistribute Fossil Fuel Profits
 - [https://www.dailywire.com/news/european-union-social-market-economy-might-redistribute-fossil-fuel-profits](https://www.dailywire.com/news/european-union-social-market-economy-might-redistribute-fossil-fuel-profits)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 10:55:34+00:00

European Commission President Ursula von der Leyen said on Wednesday that the European Union might redistribute profits from fossil fuel companies and impose energy consumption limits. The bloc is currently weighing various measures to help member states cope with a freeze in Russian energy exports — including natural gas shipments through the Nord Stream 1 ...

## Grammy-Nominated R&B Artist Jesse Powell Dead At 51
 - [https://www.dailywire.com/news/grammy-nominated-rb-artist-jesse-powell-dead-at-51](https://www.dailywire.com/news/grammy-nominated-rb-artist-jesse-powell-dead-at-51)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 10:54:11+00:00

Grammy-nominated R&amp;B artist Jesse Powell has died at the age of 51, according to an announcement by his sister on Wednesday. Tamara Powell shared the news in an Instagram post that did not provide a cause of death. &#8220;It is with a heavy heart that we announce the passing of our beloved son, brother, and ...

## Gisele Bündchen Breaks Silence On Tom Brady’s Return to Football: ‘I Would Like Him To Be More Present’
 - [https://www.dailywire.com/news/gisele-bundchen-breaks-silence-on-tom-bradys-return-to-football-i-would-like-him-to-be-more-present](https://www.dailywire.com/news/gisele-bundchen-breaks-silence-on-tom-bradys-return-to-football-i-would-like-him-to-be-more-present)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 10:27:16+00:00

Supermodel Gisele Bündchen recently opened up about her husband Tom Brady coming out of retirement and returning to the NFL. Rumors are swirling that their marriage is in trouble because Bündchen wants Brady to spend more time at home with his three kids. She was allegedly a major reason the star quarterback retired in the ...

## MAGA Republican Wins NH Primary, Could Become Youngest Woman Ever Elected To Congress
 - [https://www.dailywire.com/news/maga-republican-wins-nh-primary-could-become-youngest-woman-ever-elected-to-congress](https://www.dailywire.com/news/maga-republican-wins-nh-primary-could-become-youngest-woman-ever-elected-to-congress)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 10:12:19+00:00

Underdog Trump-Republican Karoline Leavitt won the GOP primary for New Hampshire&#8217;s First Congressional District on Tuesday. Leavitt, who worked in former President Donald Trump&#8217;s press shop and then for Rep. Elise Stefanik (R-NY), could become the youngest woman ever elected to Congress if she pulls out a win in November. She turned 25 years old ...

## West Virginia Passes New Law Banning Most Abortions
 - [https://www.dailywire.com/news/west-virginia-passes-new-law-banning-most-abortions](https://www.dailywire.com/news/west-virginia-passes-new-law-banning-most-abortions)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 09:59:25+00:00

West Virginia lawmakers passed a bill on Tuesday that bans abortion with limited exceptions. The legislation passed the state&#8217;s Senate 22-7 and the House 77-17, now moving to the desk of Republican Gov. Jim Justice, who is expected to sign the bill into law. It bans abortion except for cases where the embryo or fetus ...

## Forgetting 9/11
 - [https://www.dailywire.com/news/forgetting-9-11](https://www.dailywire.com/news/forgetting-9-11)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 09:45:53+00:00

On the twenty-first anniversary of September 11, President Joe Biden repeated the same tired nostrums we have heard for the past several years on the anniversary of the worst terror attack in American history: “We will never forget, we will never give up. Our commitment to preventing another attack on the United States is without ...

## FBI Had Suspected Russian Operative, Source For Trump Dossier On Payroll, Durham Charges
 - [https://www.dailywire.com/news/fbi-had-suspected-russian-operative-source-for-trump-dossier-on-payroll-durham-charges](https://www.dailywire.com/news/fbi-had-suspected-russian-operative-source-for-trump-dossier-on-payroll-durham-charges)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 09:28:54+00:00

The shadowy Russian operative who was allegedly the key source for the discredited Steele dossier that may have led to the FBI’s Trump-Russia collusion probe was put on the bureau’s payroll despite prior concerns he was an agent of Moscow, according to Special Counsel John Durham. Durham revealed the explosive claim about Igor Danchenko in ...

## Sex-Trafficked Teen Who Killed Her Alleged Rapist Sentenced And Fined
 - [https://www.dailywire.com/news/sex-trafficked-teen-who-killed-her-alleged-rapist-sentenced-and-fined](https://www.dailywire.com/news/sex-trafficked-teen-who-killed-her-alleged-rapist-sentenced-and-fined)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 09:21:17+00:00

A sex trafficking victim who killed her alleged rapist was sentenced Tuesday in an Iowa court to five years supervised probation, 1,200 hours of community service, and was ordered to pay $150,000 restitution to the family of the alleged rapist. Pieper Lewis, who is now 17 years old, killed 37-year-old Zachary Brooks of Des Moines, ...

## Forbes Pulls Controversial Attack On Outspoken Detransitioner Activist
 - [https://www.dailywire.com/news/forbes-pulls-controversial-attack-on-outspoken-detransitioner-activist](https://www.dailywire.com/news/forbes-pulls-controversial-attack-on-outspoken-detransitioner-activist)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 09:05:40+00:00

An article by an ex-ABC News journalist &#8212; who has changed sex identities multiple times &#8212; attacking a detransitioned woman-turned activist against radical gender theory was taken down by Forbes one day after publication. The article, by Dawn Ennis, a biological male who identifies as transgender, originally ran as an opinion piece in the Los Angeles ...

## Bill Gates Praises China: ‘They’ve Done A Very Good Job’
 - [https://www.dailywire.com/news/bill-gates-praises-china-theyve-done-a-very-good-job](https://www.dailywire.com/news/bill-gates-praises-china-theyve-done-a-very-good-job)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 09:01:31+00:00

Microsoft co-founder Bill Gates, the world’s fifth-richest man, thinks that Communist China should be praised for the way it has handled poverty. New York Times Magazine columnist David Wallace-Wells, the author of “The Uninhabitable Earth,” opined that progress on poverty around the globe “has been really remarkable.” Asserting that said progress reflected “progress in China,” ...

## Man Who Fired First Shot As Rioters Chased Rittenhouse Arrested On New Charges
 - [https://www.dailywire.com/news/man-seen-firing-first-shot-as-rioters-chased-rittenhouse-reportedly-arrested-on-new-charges](https://www.dailywire.com/news/man-seen-firing-first-shot-as-rioters-chased-rittenhouse-reportedly-arrested-on-new-charges)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 08:35:35+00:00

The man who was caught on video firing a gun moments before Kyle Rittenhouse shot and killed two assailants during the 2020 riot in Kenosha, WI., has been charged with armed robbery and other alleged crimes, according to a report. Joshua Ziminski and his wife, Kelly Ziminski, both of whom took part in the August ...

## Democratic Senator Bucks His Party Over Border Crisis: ‘We Need The Wall And A Lot More’
 - [https://www.dailywire.com/news/democratic-senator-bucks-his-party-over-border-crisis-we-need-the-wall-and-a-lot-more](https://www.dailywire.com/news/democratic-senator-bucks-his-party-over-border-crisis-we-need-the-wall-and-a-lot-more)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-14 07:15:00+00:00

Sen. Joe Manchin (D-WV) bucked many in his party over the immigration crisis on the U.S. southern border during an interview this week, saying that the U.S. needs &#8220;the wall and a lot more.&#8221; Manchin made the remarks during a Fox News interview after anchor Bret Baier asked him about Vice President Kamala Harris&#8217; claim ...


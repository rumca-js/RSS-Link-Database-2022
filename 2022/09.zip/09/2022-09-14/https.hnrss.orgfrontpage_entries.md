# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Google employees alarmed that the company suddenly expects them to do work
 - [https://futurism.com/the-byte/google-employees-work-mandate](https://futurism.com/the-byte/google-employees-work-mandate)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 23:12:57+00:00

<p>Article URL: <a href="https://futurism.com/the-byte/google-employees-work-mandate">https://futurism.com/the-byte/google-employees-work-mandate</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32844740">https://news.ycombinator.com/item?id=32844740</a></p>
<p>Points: 49</p>
<p># Comments: 39</p>

## Dick the Birthday Boy: The Legacy Continues [video]
 - [https://www.youtube.com/watch?v=hwu1427MUIE](https://www.youtube.com/watch?v=hwu1427MUIE)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 23:04:21+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=hwu1427MUIE">https://www.youtube.com/watch?v=hwu1427MUIE</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32844663">https://news.ycombinator.com/item?id=32844663</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Suspected counterfeit components found in ejection seat after fatal F-16 crash
 - [https://www.airforcetimes.com/news/your-air-force/2022/09/13/an-f-16-pilot-died-when-his-ejection-seat-failed-was-it-counterfeit/](https://www.airforcetimes.com/news/your-air-force/2022/09/13/an-f-16-pilot-died-when-his-ejection-seat-failed-was-it-counterfeit/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 22:45:18+00:00

<p>Article URL: <a href="https://www.airforcetimes.com/news/your-air-force/2022/09/13/an-f-16-pilot-died-when-his-ejection-seat-failed-was-it-counterfeit/">https://www.airforcetimes.com/news/your-air-force/2022/09/13/an-f-16-pilot-died-when-his-ejection-seat-failed-was-it-counterfeit/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32844485">https://news.ycombinator.com/item?id=32844485</a></p>
<p>Points: 70</p>
<p># Comments: 14</p>

## Head-On Crash: 2009 Chevrolet Malibu vs. 1959 Bel Air
 - [https://www.thecarconnection.com/news/1035359_head-on-crash-2009-chevrolet-malibu-vs-59-bel-air](https://www.thecarconnection.com/news/1035359_head-on-crash-2009-chevrolet-malibu-vs-59-bel-air)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 22:35:10+00:00

<p>Article URL: <a href="https://www.thecarconnection.com/news/1035359_head-on-crash-2009-chevrolet-malibu-vs-59-bel-air">https://www.thecarconnection.com/news/1035359_head-on-crash-2009-chevrolet-malibu-vs-59-bel-air</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32844368">https://news.ycombinator.com/item?id=32844368</a></p>
<p>Points: 13</p>
<p># Comments: 5</p>

## Ethereum Classic hashrate doubled this month ahead of ETH merge
 - [https://2miners.com/etc-network-hashrate](https://2miners.com/etc-network-hashrate)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 22:34:00+00:00

<p>Article URL: <a href="https://2miners.com/etc-network-hashrate">https://2miners.com/etc-network-hashrate</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32844350">https://news.ycombinator.com/item?id=32844350</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## GraphBLAS
 - [https://people.engr.tamu.edu/davis/GraphBLAS.html](https://people.engr.tamu.edu/davis/GraphBLAS.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 22:13:12+00:00

<p>Article URL: <a href="https://people.engr.tamu.edu/davis/GraphBLAS.html">https://people.engr.tamu.edu/davis/GraphBLAS.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32844130">https://news.ycombinator.com/item?id=32844130</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Crazy Thin ‘Deep Insert’ ATM Skimmers
 - [https://krebsonsecurity.com/2022/09/say-hello-to-crazy-thin-deep-insert-atm-skimmers/](https://krebsonsecurity.com/2022/09/say-hello-to-crazy-thin-deep-insert-atm-skimmers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 21:56:00+00:00

<p>Article URL: <a href="https://krebsonsecurity.com/2022/09/say-hello-to-crazy-thin-deep-insert-atm-skimmers/">https://krebsonsecurity.com/2022/09/say-hello-to-crazy-thin-deep-insert-atm-skimmers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32843961">https://news.ycombinator.com/item?id=32843961</a></p>
<p>Points: 70</p>
<p># Comments: 33</p>

## iPhone 14 Pro Camera Review: Scotland
 - [https://www.austinmann.com/trek/iphone-14-pro-camera-review-scotland](https://www.austinmann.com/trek/iphone-14-pro-camera-review-scotland)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 21:50:25+00:00

<p>Article URL: <a href="https://www.austinmann.com/trek/iphone-14-pro-camera-review-scotland">https://www.austinmann.com/trek/iphone-14-pro-camera-review-scotland</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32843892">https://news.ycombinator.com/item?id=32843892</a></p>
<p>Points: 28</p>
<p># Comments: 10</p>

## Dolphin Progress July and August 2022
 - [https://dolphin-emu.org/blog/2022/09/13/dolphin-progress-report-july-and-august-2022/](https://dolphin-emu.org/blog/2022/09/13/dolphin-progress-report-july-and-august-2022/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 21:46:40+00:00

<p>Article URL: <a href="https://dolphin-emu.org/blog/2022/09/13/dolphin-progress-report-july-and-august-2022/">https://dolphin-emu.org/blog/2022/09/13/dolphin-progress-report-july-and-august-2022/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32843841">https://news.ycombinator.com/item?id=32843841</a></p>
<p>Points: 21</p>
<p># Comments: 0</p>

## Search 5.8B images used to train popular AI art models
 - [https://haveibeentrained.com/](https://haveibeentrained.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 21:17:50+00:00

<p>Article URL: <a href="https://haveibeentrained.com/">https://haveibeentrained.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32843477">https://news.ycombinator.com/item?id=32843477</a></p>
<p>Points: 28</p>
<p># Comments: 21</p>

## Denmark no longer offering Covid vaccinations to healthy adults under 50
 - [https://www.sst.dk/en/english/corona-eng/vaccination-against-covid-19](https://www.sst.dk/en/english/corona-eng/vaccination-against-covid-19)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 21:05:31+00:00

<p>Article URL: <a href="https://www.sst.dk/en/english/corona-eng/vaccination-against-covid-19">https://www.sst.dk/en/english/corona-eng/vaccination-against-covid-19</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32843348">https://news.ycombinator.com/item?id=32843348</a></p>
<p>Points: 115</p>
<p># Comments: 143</p>

## Mandelbrot Generation in Rust
 - [https://blocr.github.io/posts/fractal_generation.html](https://blocr.github.io/posts/fractal_generation.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 20:48:39+00:00

<p>Article URL: <a href="https://blocr.github.io/posts/fractal_generation.html">https://blocr.github.io/posts/fractal_generation.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32843145">https://news.ycombinator.com/item?id=32843145</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Act-1: Transformer for Actions
 - [https://www.adept.ai/act](https://www.adept.ai/act)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 20:24:53+00:00

<p>Article URL: <a href="https://www.adept.ai/act">https://www.adept.ai/act</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32842860">https://news.ycombinator.com/item?id=32842860</a></p>
<p>Points: 41</p>
<p># Comments: 12</p>

## Rocks, Air, and Memory (2006)
 - [https://uh.edu/engines/epi2204.htm](https://uh.edu/engines/epi2204.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 20:21:32+00:00

<p>Article URL: <a href="https://uh.edu/engines/epi2204.htm">https://uh.edu/engines/epi2204.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32842814">https://news.ycombinator.com/item?id=32842814</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## About Lockdown Mode
 - [https://support.apple.com/en-us/HT212650](https://support.apple.com/en-us/HT212650)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 20:15:13+00:00

<p>Article URL: <a href="https://support.apple.com/en-us/HT212650">https://support.apple.com/en-us/HT212650</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32842749">https://news.ycombinator.com/item?id=32842749</a></p>
<p>Points: 49</p>
<p># Comments: 4</p>

## Escaping strings faster with AVX-512
 - [https://lemire.me/blog/2022/09/14/escaping-strings-faster-with-avx-512/](https://lemire.me/blog/2022/09/14/escaping-strings-faster-with-avx-512/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 20:06:58+00:00

<p>Article URL: <a href="https://lemire.me/blog/2022/09/14/escaping-strings-faster-with-avx-512/">https://lemire.me/blog/2022/09/14/escaping-strings-faster-with-avx-512/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32842651">https://news.ycombinator.com/item?id=32842651</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## Unicode 15 Released
 - [https://lwn.net/Articles/908032/](https://lwn.net/Articles/908032/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 19:35:13+00:00

<p>Article URL: <a href="https://lwn.net/Articles/908032/">https://lwn.net/Articles/908032/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32842207">https://news.ycombinator.com/item?id=32842207</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## Just What Is It That Makes Today’s Homes So Different, So Appealing?
 - [https://smarthistory.org/richard-hamilton-just-what-is-it/](https://smarthistory.org/richard-hamilton-just-what-is-it/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 19:34:03+00:00

<p>Article URL: <a href="https://smarthistory.org/richard-hamilton-just-what-is-it/">https://smarthistory.org/richard-hamilton-just-what-is-it/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32842192">https://news.ycombinator.com/item?id=32842192</a></p>
<p>Points: 7</p>
<p># Comments: 3</p>

## FLAC 1.4.0 released – added support for 32-bit audio
 - [https://xiph.org/flac/2022/09/09/flac-1-4-0-released.html](https://xiph.org/flac/2022/09/09/flac-1-4-0-released.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 19:02:48+00:00

<p>Article URL: <a href="https://xiph.org/flac/2022/09/09/flac-1-4-0-released.html">https://xiph.org/flac/2022/09/09/flac-1-4-0-released.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32841737">https://news.ycombinator.com/item?id=32841737</a></p>
<p>Points: 16</p>
<p># Comments: 8</p>

## Worldwide Rail Network Map
 - [https://www.openrailwaymap.org/?style=standard&lat=51.58248&lon=15.6501&zoom=3](https://www.openrailwaymap.org/?style=standard&lat=51.58248&lon=15.6501&zoom=3)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 18:17:55+00:00

<p>Article URL: <a href="https://www.openrailwaymap.org/?style=standard&amp;lat=51.58248&amp;lon=15.6501&amp;zoom=3">https://www.openrailwaymap.org/?style=standard&amp;lat=51.58248&amp;lon=15.6501&amp;zoom=3</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32841069">https://news.ycombinator.com/item?id=32841069</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Cachegrand – a modern OSS Key-Value store built for today's hardware
 - [https://github.com/danielealbano/cachegrand](https://github.com/danielealbano/cachegrand)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 17:57:18+00:00

<p>Article URL: <a href="https://github.com/danielealbano/cachegrand">https://github.com/danielealbano/cachegrand</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32840783">https://news.ycombinator.com/item?id=32840783</a></p>
<p>Points: 24</p>
<p># Comments: 2</p>

## San Francisco Makes It Insanely Hard to Build Housing
 - [https://sfstandard.com/housing-development/how-san-francisco-makes-it-insanely-hard-to-build-housing/](https://sfstandard.com/housing-development/how-san-francisco-makes-it-insanely-hard-to-build-housing/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 17:41:02+00:00

<p>Article URL: <a href="https://sfstandard.com/housing-development/how-san-francisco-makes-it-insanely-hard-to-build-housing/">https://sfstandard.com/housing-development/how-san-francisco-makes-it-insanely-hard-to-build-housing/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32840583">https://news.ycombinator.com/item?id=32840583</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## A closer look at child marriage in California (2021)
 - [https://www.uscannenbergmedia.com/2021/11/12/a-closer-look-at-child-marriage-in-california/](https://www.uscannenbergmedia.com/2021/11/12/a-closer-look-at-child-marriage-in-california/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 17:29:22+00:00

<p>Article URL: <a href="https://www.uscannenbergmedia.com/2021/11/12/a-closer-look-at-child-marriage-in-california/">https://www.uscannenbergmedia.com/2021/11/12/a-closer-look-at-child-marriage-in-california/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32840408">https://news.ycombinator.com/item?id=32840408</a></p>
<p>Points: 36</p>
<p># Comments: 13</p>

## Why is every podcast sponsored by a VPN company?
 - [https://girdley.substack.com/p/why-is-every-podcast-sponsored-by](https://girdley.substack.com/p/why-is-every-podcast-sponsored-by)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 17:27:10+00:00

<p>Article URL: <a href="https://girdley.substack.com/p/why-is-every-podcast-sponsored-by">https://girdley.substack.com/p/why-is-every-podcast-sponsored-by</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32840369">https://news.ycombinator.com/item?id=32840369</a></p>
<p>Points: 28</p>
<p># Comments: 8</p>

## Once again so many people are led to think Wikipedia is broke and must be saved
 - [https://twitter.com/Wikiland/status/1570072717931552770](https://twitter.com/Wikiland/status/1570072717931552770)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 17:08:53+00:00

<p>Article URL: <a href="https://twitter.com/Wikiland/status/1570072717931552770">https://twitter.com/Wikiland/status/1570072717931552770</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32840097">https://news.ycombinator.com/item?id=32840097</a></p>
<p>Points: 75</p>
<p># Comments: 24</p>

## The spam on Twitter is appalling
 - [https://twitter.com/paulg/status/1570094327338274823](https://twitter.com/paulg/status/1570094327338274823)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 17:05:57+00:00

<p>Article URL: <a href="https://twitter.com/paulg/status/1570094327338274823">https://twitter.com/paulg/status/1570094327338274823</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32840060">https://news.ycombinator.com/item?id=32840060</a></p>
<p>Points: 34</p>
<p># Comments: 18</p>

## Patterns (YC S21) Is hiring devs to help us build the Figma for data
 - [https://patterns.app/](https://patterns.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 17:00:03+00:00

<p>Article URL: <a href="https://patterns.app/">https://patterns.app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32839972">https://news.ycombinator.com/item?id=32839972</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## DVD Bouncing Logo
 - [https://www.google.com/search?q=dvd+bouncing+logo](https://www.google.com/search?q=dvd+bouncing+logo)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 16:57:18+00:00

<p>Article URL: <a href="https://www.google.com/search?q=dvd+bouncing+logo">https://www.google.com/search?q=dvd+bouncing+logo</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32839943">https://news.ycombinator.com/item?id=32839943</a></p>
<p>Points: 42</p>
<p># Comments: 13</p>

## Saturated fat: villain and bogeyman in development of cardiovascular disease?
 - [https://academic.oup.com/eurjpc/advance-article-abstract/doi/10.1093/eurjpc/zwac194/6691821](https://academic.oup.com/eurjpc/advance-article-abstract/doi/10.1093/eurjpc/zwac194/6691821)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 16:48:34+00:00

<p>Article URL: <a href="https://academic.oup.com/eurjpc/advance-article-abstract/doi/10.1093/eurjpc/zwac194/6691821">https://academic.oup.com/eurjpc/advance-article-abstract/doi/10.1093/eurjpc/zwac194/6691821</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32839796">https://news.ycombinator.com/item?id=32839796</a></p>
<p>Points: 20</p>
<p># Comments: 19</p>

## Discord adds new “Forum” channels
 - [https://discord.com/blog/forum-channels-space-for-organized-conversation](https://discord.com/blog/forum-channels-space-for-organized-conversation)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 16:36:24+00:00

<p>Article URL: <a href="https://discord.com/blog/forum-channels-space-for-organized-conversation">https://discord.com/blog/forum-channels-space-for-organized-conversation</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32839626">https://news.ycombinator.com/item?id=32839626</a></p>
<p>Points: 69</p>
<p># Comments: 46</p>

## Why Racket? Why Lisp?
 - [https://beautifulracket.com/appendix/why-racket-why-lisp.html](https://beautifulracket.com/appendix/why-racket-why-lisp.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 16:30:03+00:00

<p>Article URL: <a href="https://beautifulracket.com/appendix/why-racket-why-lisp.html">https://beautifulracket.com/appendix/why-racket-why-lisp.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32839542">https://news.ycombinator.com/item?id=32839542</a></p>
<p>Points: 31</p>
<p># Comments: 6</p>

## Carbon Footprint of Unwanted Data-Use by Smartphones
 - [https://branch.climateaction.tech/issues/issue-3/carbon-footprint-of-unwanted-data-use-by-smartphones/](https://branch.climateaction.tech/issues/issue-3/carbon-footprint-of-unwanted-data-use-by-smartphones/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 16:26:50+00:00

<p>Article URL: <a href="https://branch.climateaction.tech/issues/issue-3/carbon-footprint-of-unwanted-data-use-by-smartphones/">https://branch.climateaction.tech/issues/issue-3/carbon-footprint-of-unwanted-data-use-by-smartphones/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32839493">https://news.ycombinator.com/item?id=32839493</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## Starlink is now on all seven continents, enabled by its space laser network
 - [https://twitter.com/SpaceX/status/1570073223005622274](https://twitter.com/SpaceX/status/1570073223005622274)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 16:09:46+00:00

<p>Article URL: <a href="https://twitter.com/SpaceX/status/1570073223005622274">https://twitter.com/SpaceX/status/1570073223005622274</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32839193">https://news.ycombinator.com/item?id=32839193</a></p>
<p>Points: 28</p>
<p># Comments: 3</p>

## Dabbling with Dagster vs. Airflow
 - [https://davidsj.substack.com/p/dabbling-with-dagster-part-1](https://davidsj.substack.com/p/dabbling-with-dagster-part-1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 16:06:13+00:00

<p>Article URL: <a href="https://davidsj.substack.com/p/dabbling-with-dagster-part-1">https://davidsj.substack.com/p/dabbling-with-dagster-part-1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32839147">https://news.ycombinator.com/item?id=32839147</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## Show HN: Rentaflop – Render your Blender projects without sacrificing quality
 - [https://news.ycombinator.com/item?id=32838673](https://news.ycombinator.com/item?id=32838673)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 15:34:40+00:00

<p>Hi HN,<p>My name is David Sokol, and I'm the founder of rentaflop (https://rentaflop.com). We're a crowdsourced render farm aimed at making Blender rendering fast and affordable.<p>If you've used Blender, then I'm sure you've experienced the pain of waiting around for your animations to render. You've probably even had to sacrifice the quality of your work to reduce your render times. I've been there too.<p>If you're like me, then you're also disappointed with the alternative solutions: spend

## H-m-m (hackers mind map)
 - [https://github.com/nadrad/h-m-m](https://github.com/nadrad/h-m-m)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 15:21:44+00:00

<p>Article URL: <a href="https://github.com/nadrad/h-m-m">https://github.com/nadrad/h-m-m</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32838475">https://news.ycombinator.com/item?id=32838475</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Child Porn Allegations at Patreon After Security Team Fired
 - [https://www.secjuice.com/patreon-fired-security-team-amid-child-porn-allegations/](https://www.secjuice.com/patreon-fired-security-team-amid-child-porn-allegations/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 15:19:55+00:00

<p>Article URL: <a href="https://www.secjuice.com/patreon-fired-security-team-amid-child-porn-allegations/">https://www.secjuice.com/patreon-fired-security-team-amid-child-porn-allegations/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32838454">https://news.ycombinator.com/item?id=32838454</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## What's New in Jakarta EE 10?
 - [https://blog.payara.fish/whats-new-in-jakarta-ee-10](https://blog.payara.fish/whats-new-in-jakarta-ee-10)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 15:08:49+00:00

<p>Article URL: <a href="https://blog.payara.fish/whats-new-in-jakarta-ee-10">https://blog.payara.fish/whats-new-in-jakarta-ee-10</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32838321">https://news.ycombinator.com/item?id=32838321</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Ask HN: How do I write a Linux driver for my 15 year old photo printer?
 - [https://news.ycombinator.com/item?id=32838225](https://news.ycombinator.com/item?id=32838225)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 15:01:10+00:00

<p>I'm interested in writing a x86_64 Linux driver for my 15 year old photo printer.<p>It looks like someone out there maintains 32 bit drivers for this printer, but I'd like low-hassle native support for my 64-bit install.<p>https://askubuntu.com/questions/1324015/how-to-install-printer-canon-pixma-ip1800-on-xubuntu-20-04<p>Where do I get started with this? What's the toolchain for sniffing USB data and that sort of thing?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?i

## Notes: Fast note-taking app, open-source, without Electron, built in Qt C++
 - [https://github.com/nuttyartist/notes](https://github.com/nuttyartist/notes)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 14:42:23+00:00

<p>Article URL: <a href="https://github.com/nuttyartist/notes">https://github.com/nuttyartist/notes</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32837942">https://news.ycombinator.com/item?id=32837942</a></p>
<p>Points: 55</p>
<p># Comments: 11</p>

## Show HN: StackAid – fund 100s of open source dependencies with one subscription
 - [https://www.stackaid.us](https://www.stackaid.us)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 14:35:11+00:00

<p>We strongly believe working on open source software should be a viable source of income for many more developers. Unfortunately, the following barriers limit the extent of open source funding:<p>- Only a small fraction of open source projects are funded, and most money goes to a few notable projects.<p>- Each project has to market is self to get significant funding.<p>- Large corporate donations provide the bulk of the funding, making it unreliable and unattainable for many.<p>- Finding and s

## Twilio to lay off 11% of workforce
 - [https://www.cnbc.com/2022/09/14/twilio-to-lay-of-11percent-of-workforce.html](https://www.cnbc.com/2022/09/14/twilio-to-lay-of-11percent-of-workforce.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 14:33:27+00:00

<p>Article URL: <a href="https://www.cnbc.com/2022/09/14/twilio-to-lay-of-11percent-of-workforce.html">https://www.cnbc.com/2022/09/14/twilio-to-lay-of-11percent-of-workforce.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32837802">https://news.ycombinator.com/item?id=32837802</a></p>
<p>Points: 69</p>
<p># Comments: 46</p>

## Ask HN: Where are the good platforms for contract work?
 - [https://news.ycombinator.com/item?id=32837800](https://news.ycombinator.com/item?id=32837800)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 14:33:22+00:00

<p>I've been looking for contract work for the past couple months, and it's been dire. All the job boards are looking for full time employees, and on Hacker News the only recommendation is Toptal.<p>Is there really no other platform for decently paid contract work that's not a complete race to the bottom? I find I'm close to having to abandon 10 years of consulting because I have no idea where to find anything else than full-time employment.<p>The other two job boards I've been keeping an eye on

## Ever wondered how a QR code works?
 - [https://typefully.com/DanHollick/qr-codes-T7tLlNi](https://typefully.com/DanHollick/qr-codes-T7tLlNi)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 14:17:43+00:00

<p>Article URL: <a href="https://typefully.com/DanHollick/qr-codes-T7tLlNi">https://typefully.com/DanHollick/qr-codes-T7tLlNi</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32837565">https://news.ycombinator.com/item?id=32837565</a></p>
<p>Points: 25</p>
<p># Comments: 11</p>

## Ask HN: Why is Disney+ UX so bad?
 - [https://news.ycombinator.com/item?id=32837397](https://news.ycombinator.com/item?id=32837397)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 14:07:31+00:00

<p>A few weeks ago I bought a one month Disney+ subscription to check it out. I have all kinds of problems when using their web player compared to Netflix and YouTube:<p>- subtitle settings get reset every time I close the website.<p>- the button for changing subtitles is in the upper right corner. Once you open the menu the button for closing it appears in the upper left corner. You can't close the menu by clicking outside of it, despite the fact that you can still see the blurred video in the 

## A message from Twilio CEO Jeff Lawson: 11% workforce cut
 - [https://www.twilio.com/blog/a-message-from-twilio-ceo-jeff-lawson](https://www.twilio.com/blog/a-message-from-twilio-ceo-jeff-lawson)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 14:03:32+00:00

<p>Article URL: <a href="https://www.twilio.com/blog/a-message-from-twilio-ceo-jeff-lawson">https://www.twilio.com/blog/a-message-from-twilio-ceo-jeff-lawson</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32837345">https://news.ycombinator.com/item?id=32837345</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## My First BillG Review (2006)
 - [https://www.joelonsoftware.com/2006/06/16/my-first-billg-review/](https://www.joelonsoftware.com/2006/06/16/my-first-billg-review/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 13:55:43+00:00

<p>Article URL: <a href="https://www.joelonsoftware.com/2006/06/16/my-first-billg-review/">https://www.joelonsoftware.com/2006/06/16/my-first-billg-review/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32837249">https://news.ycombinator.com/item?id=32837249</a></p>
<p>Points: 29</p>
<p># Comments: 7</p>

## DuckDuckGo, Proton, Mozilla back bill targeting Big Tech ‘surveillance’
 - [https://www.techradar.com/news/duckduckgo-proton-mozilla-throw-weight-behind-bill-targeting-big-tech-surveillance](https://www.techradar.com/news/duckduckgo-proton-mozilla-throw-weight-behind-bill-targeting-big-tech-surveillance)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 13:54:51+00:00

<p>Article URL: <a href="https://www.techradar.com/news/duckduckgo-proton-mozilla-throw-weight-behind-bill-targeting-big-tech-surveillance">https://www.techradar.com/news/duckduckgo-proton-mozilla-throw-weight-behind-bill-targeting-big-tech-surveillance</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32837233">https://news.ycombinator.com/item?id=32837233</a></p>
<p>Points: 44</p>
<p># Comments: 5</p>

## Think Prometheus, but for logs (not metrics). Simple, efficient, fast log store
 - [https://www.parseable.io/docs/introduction](https://www.parseable.io/docs/introduction)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 13:54:04+00:00

<p>Article URL: <a href="https://www.parseable.io/docs/introduction">https://www.parseable.io/docs/introduction</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32837222">https://news.ycombinator.com/item?id=32837222</a></p>
<p>Points: 28</p>
<p># Comments: 15</p>

## Tornado Cash and bullets
 - [https://blog.yossarian.net/2022/09/14/Tornado-Cash-and-bullets](https://blog.yossarian.net/2022/09/14/Tornado-Cash-and-bullets)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 13:20:43+00:00

<p>Article URL: <a href="https://blog.yossarian.net/2022/09/14/Tornado-Cash-and-bullets">https://blog.yossarian.net/2022/09/14/Tornado-Cash-and-bullets</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32836785">https://news.ycombinator.com/item?id=32836785</a></p>
<p>Points: 29</p>
<p># Comments: 42</p>

## Pingora, the proxy that connects Cloudflare to the Internet
 - [https://blog.cloudflare.com/how-we-built-pingora-the-proxy-that-connects-cloudflare-to-the-internet/](https://blog.cloudflare.com/how-we-built-pingora-the-proxy-that-connects-cloudflare-to-the-internet/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 13:11:50+00:00

<p>Article URL: <a href="https://blog.cloudflare.com/how-we-built-pingora-the-proxy-that-connects-cloudflare-to-the-internet/">https://blog.cloudflare.com/how-we-built-pingora-the-proxy-that-connects-cloudflare-to-the-internet/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32836661">https://news.ycombinator.com/item?id=32836661</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## The B-52 was designed in a hotel room over one weekend
 - [https://www.sandboxx.us/blog/the-b-52-was-designed-in-a-hotel-room-over-one-weekend-and-will-probably-fly-for-100-years/](https://www.sandboxx.us/blog/the-b-52-was-designed-in-a-hotel-room-over-one-weekend-and-will-probably-fly-for-100-years/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 13:01:42+00:00

<p>Article URL: <a href="https://www.sandboxx.us/blog/the-b-52-was-designed-in-a-hotel-room-over-one-weekend-and-will-probably-fly-for-100-years/">https://www.sandboxx.us/blog/the-b-52-was-designed-in-a-hotel-room-over-one-weekend-and-will-probably-fly-for-100-years/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32836552">https://news.ycombinator.com/item?id=32836552</a></p>
<p>Points: 25</p>
<p># Comments: 11</p>

## Hacktoberfest 2022
 - [https://hacktoberfest.com](https://hacktoberfest.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 12:57:00+00:00

<p>Article URL: <a href="https://hacktoberfest.com">https://hacktoberfest.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32836500">https://news.ycombinator.com/item?id=32836500</a></p>
<p>Points: 40</p>
<p># Comments: 19</p>

## io_uring_spawn: Launching New Processes with io_uring
 - [https://www.phoronix.com/news/Linux-LPC2022-io_uring_spawn](https://www.phoronix.com/news/Linux-LPC2022-io_uring_spawn)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 12:52:03+00:00

<p>Article URL: <a href="https://www.phoronix.com/news/Linux-LPC2022-io_uring_spawn">https://www.phoronix.com/news/Linux-LPC2022-io_uring_spawn</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32836446">https://news.ycombinator.com/item?id=32836446</a></p>
<p>Points: 21</p>
<p># Comments: 2</p>

## Ask HN: What is the coding exercise you use to explore a new language?
 - [https://news.ycombinator.com/item?id=32836113](https://news.ycombinator.com/item?id=32836113)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 12:19:49+00:00

<p>What is a good sample program or project to work on to explore the primary aspects of a programming language? Something that can be worked on for a couple hours or days. Something that will give exposure to most of the basics of a particular language. Would love to know how people go about trying out a new language in this way.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32836113">https://news.ycombinator.com/item?id=32836113</a></p>
<p>Points: 21</p>
<p># Commen

## Privacy vs. “I have nothing to hide” (2019)
 - [https://kevquirk.com/privacy-vs-i-have-nothing-to-hide/](https://kevquirk.com/privacy-vs-i-have-nothing-to-hide/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 12:02:00+00:00

<p>Article URL: <a href="https://kevquirk.com/privacy-vs-i-have-nothing-to-hide/">https://kevquirk.com/privacy-vs-i-have-nothing-to-hide/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32835966">https://news.ycombinator.com/item?id=32835966</a></p>
<p>Points: 109</p>
<p># Comments: 103</p>

## Pachyderm Is Hiring Sales Engineers and Solutions Architects
 - [https://www.pachyderm.com/careers/#positions](https://www.pachyderm.com/careers/#positions)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 12:00:54+00:00

<p>Article URL: <a href="https://www.pachyderm.com/careers/#positions">https://www.pachyderm.com/careers/#positions</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32835956">https://news.ycombinator.com/item?id=32835956</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Color Fonts
 - [https://material.io/blog/color-fonts-are-here](https://material.io/blog/color-fonts-are-here)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 11:43:45+00:00

<p>Article URL: <a href="https://material.io/blog/color-fonts-are-here">https://material.io/blog/color-fonts-are-here</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32835806">https://news.ycombinator.com/item?id=32835806</a></p>
<p>Points: 92</p>
<p># Comments: 51</p>

## Woman holds up Lebanese bank for $13k of her own money
 - [https://www.reuters.com/world/middle-east/woman-holds-up-lebanese-bank-13000-her-own-money-advocacy-group-says-2022-09-14/](https://www.reuters.com/world/middle-east/woman-holds-up-lebanese-bank-13000-her-own-money-advocacy-group-says-2022-09-14/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 11:42:33+00:00

<p>Article URL: <a href="https://www.reuters.com/world/middle-east/woman-holds-up-lebanese-bank-13000-her-own-money-advocacy-group-says-2022-09-14/">https://www.reuters.com/world/middle-east/woman-holds-up-lebanese-bank-13000-her-own-money-advocacy-group-says-2022-09-14/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32835794">https://news.ycombinator.com/item?id=32835794</a></p>
<p>Points: 35</p>
<p># Comments: 27</p>

## Apache NetBeans 15
 - [https://blogs.apache.org/netbeans/entry/announce-apache-netbeans-15-released](https://blogs.apache.org/netbeans/entry/announce-apache-netbeans-15-released)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 11:33:59+00:00

<p>Article URL: <a href="https://blogs.apache.org/netbeans/entry/announce-apache-netbeans-15-released">https://blogs.apache.org/netbeans/entry/announce-apache-netbeans-15-released</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32835722">https://news.ycombinator.com/item?id=32835722</a></p>
<p>Points: 40</p>
<p># Comments: 17</p>

## JavaFX 19
 - [https://openjfx.io/#ZgotmplZ](https://openjfx.io/#ZgotmplZ)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 11:32:08+00:00

<p>Article URL: <a href="https://openjfx.io/#ZgotmplZ">https://openjfx.io/#ZgotmplZ</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32835711">https://news.ycombinator.com/item?id=32835711</a></p>
<p>Points: 55</p>
<p># Comments: 31</p>

## Selecting Meaningful Metrics with Goals and Signals
 - [https://abseil.io/resources/swe-book/html/ch07.html#selecting_meaningful_metrics_with_goals](https://abseil.io/resources/swe-book/html/ch07.html#selecting_meaningful_metrics_with_goals)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 11:13:45+00:00

<p>Article URL: <a href="https://abseil.io/resources/swe-book/html/ch07.html#selecting_meaningful_metrics_with_goals">https://abseil.io/resources/swe-book/html/ch07.html#selecting_meaningful_metrics_with_goals</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32835576">https://news.ycombinator.com/item?id=32835576</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## It's been a little over 3 weeks since Google randomly sent me $249,999
 - [https://twitter.com/samwcyo/status/1569897392560050178](https://twitter.com/samwcyo/status/1569897392560050178)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 10:15:37+00:00

<p>Article URL: <a href="https://twitter.com/samwcyo/status/1569897392560050178">https://twitter.com/samwcyo/status/1569897392560050178</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32835190">https://news.ycombinator.com/item?id=32835190</a></p>
<p>Points: 89</p>
<p># Comments: 57</p>

## Demystifying tables (cells inside; borders outside)
 - [https://lakesare.brick.do/formalizing-tables-q0P4PEa2WqRg](https://lakesare.brick.do/formalizing-tables-q0P4PEa2WqRg)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 09:51:43+00:00

<p>Article URL: <a href="https://lakesare.brick.do/formalizing-tables-q0P4PEa2WqRg">https://lakesare.brick.do/formalizing-tables-q0P4PEa2WqRg</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32835052">https://news.ycombinator.com/item?id=32835052</a></p>
<p>Points: 35</p>
<p># Comments: 14</p>

## Google loses challenge against EU antitrust decision, wins 5% fine cut
 - [https://www.reuters.com/technology/eu-courts-wed-ruling-record-44-bln-google-fine-may-set-precedent-2022-09-14/](https://www.reuters.com/technology/eu-courts-wed-ruling-record-44-bln-google-fine-may-set-precedent-2022-09-14/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 09:43:49+00:00

<p>Article URL: <a href="https://www.reuters.com/technology/eu-courts-wed-ruling-record-44-bln-google-fine-may-set-precedent-2022-09-14/">https://www.reuters.com/technology/eu-courts-wed-ruling-record-44-bln-google-fine-may-set-precedent-2022-09-14/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32835000">https://news.ycombinator.com/item?id=32835000</a></p>
<p>Points: 63</p>
<p># Comments: 45</p>

## National Rail Network Map
 - [https://www.arcgis.com/apps/mapviewer/index.html?webmap=96ec03e4fc8546bd8a864e39a2c3fc41](https://www.arcgis.com/apps/mapviewer/index.html?webmap=96ec03e4fc8546bd8a864e39a2c3fc41)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 08:12:09+00:00

<p>Article URL: <a href="https://www.arcgis.com/apps/mapviewer/index.html?webmap=96ec03e4fc8546bd8a864e39a2c3fc41">https://www.arcgis.com/apps/mapviewer/index.html?webmap=96ec03e4fc8546bd8a864e39a2c3fc41</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32834484">https://news.ycombinator.com/item?id=32834484</a></p>
<p>Points: 43</p>
<p># Comments: 31</p>

## One year on, El Salvador’s Bitcoin experiment has proven a failure
 - [https://theconversation.com/one-year-on-el-salvadors-bitcoin-experiment-has-proven-a-spectacular-failure-190229](https://theconversation.com/one-year-on-el-salvadors-bitcoin-experiment-has-proven-a-spectacular-failure-190229)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 08:09:33+00:00

<p>Article URL: <a href="https://theconversation.com/one-year-on-el-salvadors-bitcoin-experiment-has-proven-a-spectacular-failure-190229">https://theconversation.com/one-year-on-el-salvadors-bitcoin-experiment-has-proven-a-spectacular-failure-190229</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32834469">https://news.ycombinator.com/item?id=32834469</a></p>
<p>Points: 71</p>
<p># Comments: 101</p>

## The UX of Porn Tube Sites Are Designed for the Ultimate Money Shot
 - [https://eyeondesign.aiga.org/the-ux-of-porn-tubes-are-designed-for-the-ultimate-money-shot/](https://eyeondesign.aiga.org/the-ux-of-porn-tubes-are-designed-for-the-ultimate-money-shot/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 08:05:07+00:00

<p>Article URL: <a href="https://eyeondesign.aiga.org/the-ux-of-porn-tubes-are-designed-for-the-ultimate-money-shot/">https://eyeondesign.aiga.org/the-ux-of-porn-tubes-are-designed-for-the-ultimate-money-shot/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32834441">https://news.ycombinator.com/item?id=32834441</a></p>
<p>Points: 68</p>
<p># Comments: 36</p>

## Countersteering
 - [https://en.wikipedia.org/wiki/Countersteering](https://en.wikipedia.org/wiki/Countersteering)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 08:04:08+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Countersteering">https://en.wikipedia.org/wiki/Countersteering</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32834433">https://news.ycombinator.com/item?id=32834433</a></p>
<p>Points: 64</p>
<p># Comments: 75</p>

## Tab (YC W15) Is Hiring a Full Stack Developer in London
 - [https://tab.recruitee.com/o/full-stack-developer-3](https://tab.recruitee.com/o/full-stack-developer-3)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 07:01:39+00:00

<p>Article URL: <a href="https://tab.recruitee.com/o/full-stack-developer-3">https://tab.recruitee.com/o/full-stack-developer-3</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32834105">https://news.ycombinator.com/item?id=32834105</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Ask HN: Is there any “PBS Kids” alternatives these days?
 - [https://news.ycombinator.com/item?id=32833581](https://news.ycombinator.com/item?id=32833581)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 05:19:41+00:00

<p>I think that was the only channel that had the perfect mix of education and being attractive for children, that got discontinued.<p>Any other alternative’s?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32833581">https://news.ycombinator.com/item?id=32833581</a></p>
<p>Points: 16</p>
<p># Comments: 9</p>

## Finley (YC W21) is hiring across all teams to build fintech infrastructure
 - [https://www.finleycms.com/careers/](https://www.finleycms.com/careers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 04:53:16+00:00

<p>Article URL: <a href="https://www.finleycms.com/careers/">https://www.finleycms.com/careers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32833451">https://news.ycombinator.com/item?id=32833451</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Mudge is a cyber activist, not a business executive
 - [https://cybersect.substack.com/p/re-mudge-v-twitter](https://cybersect.substack.com/p/re-mudge-v-twitter)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 03:49:47+00:00

<p>Article URL: <a href="https://cybersect.substack.com/p/re-mudge-v-twitter">https://cybersect.substack.com/p/re-mudge-v-twitter</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32833138">https://news.ycombinator.com/item?id=32833138</a></p>
<p>Points: 26</p>
<p># Comments: 8</p>

## Why Car Wheels Are So Flat These Days
 - [https://www.theautopian.com/heres-why-car-wheels-are-so-flat-these-days-and-no-its-not-just-aerodynamics-and-styling/](https://www.theautopian.com/heres-why-car-wheels-are-so-flat-these-days-and-no-its-not-just-aerodynamics-and-styling/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 03:40:31+00:00

<p>Article URL: <a href="https://www.theautopian.com/heres-why-car-wheels-are-so-flat-these-days-and-no-its-not-just-aerodynamics-and-styling/">https://www.theautopian.com/heres-why-car-wheels-are-so-flat-these-days-and-no-its-not-just-aerodynamics-and-styling/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32833097">https://news.ycombinator.com/item?id=32833097</a></p>
<p>Points: 19</p>
<p># Comments: 8</p>

## Sudden disturbing moves for IT in large companies, mandated by CEOs
 - [https://old.reddit.com/r/sysadmin/comments/xda3jr/sudden_disturbing_moves_for_it_in_very_large/](https://old.reddit.com/r/sysadmin/comments/xda3jr/sudden_disturbing_moves_for_it_in_very_large/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 03:24:36+00:00

<p>Article URL: <a href="https://old.reddit.com/r/sysadmin/comments/xda3jr/sudden_disturbing_moves_for_it_in_very_large/">https://old.reddit.com/r/sysadmin/comments/xda3jr/sudden_disturbing_moves_for_it_in_very_large/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32832999">https://news.ycombinator.com/item?id=32832999</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Death by Hockey Sticks
 - [https://dothemath.ucsd.edu/2022/09/death-by-hockey-sticks/](https://dothemath.ucsd.edu/2022/09/death-by-hockey-sticks/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 01:19:19+00:00

<p>Article URL: <a href="https://dothemath.ucsd.edu/2022/09/death-by-hockey-sticks/">https://dothemath.ucsd.edu/2022/09/death-by-hockey-sticks/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32832177">https://news.ycombinator.com/item?id=32832177</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## The transistor – or 25 miles on a hunk of Germanium (1953)
 - [https://www.robkalmeijer.nl/techniek/electronica/radiotechniek/hambladen/qst/1953/03/page13/index.html](https://www.robkalmeijer.nl/techniek/electronica/radiotechniek/hambladen/qst/1953/03/page13/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 00:14:12+00:00

<p>Article URL: <a href="https://www.robkalmeijer.nl/techniek/electronica/radiotechniek/hambladen/qst/1953/03/page13/index.html">https://www.robkalmeijer.nl/techniek/electronica/radiotechniek/hambladen/qst/1953/03/page13/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32831757">https://news.ycombinator.com/item?id=32831757</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## Signing Git Commits with Your SSH Key
 - [https://calebhearth.com/sign-git-with-ssh](https://calebhearth.com/sign-git-with-ssh)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 00:10:15+00:00

<p>Article URL: <a href="https://calebhearth.com/sign-git-with-ssh">https://calebhearth.com/sign-git-with-ssh</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32831731">https://news.ycombinator.com/item?id=32831731</a></p>
<p>Points: 10</p>
<p># Comments: 4</p>

## Ask HN: What are examples of companies dying due to many people quitting?
 - [https://news.ycombinator.com/item?id=32831701](https://news.ycombinator.com/item?id=32831701)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 00:05:12+00:00

<p>Curious what are some notable examples of companies being forced to shut down due to many people leaving within a short timeframe?<p>I imagine if half the staff left a nursing home, it would be forced to shut down.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32831701">https://news.ycombinator.com/item?id=32831701</a></p>
<p>Points: 36</p>
<p># Comments: 37</p>

## W3.css – A Minimal Alternative to Bootstrap
 - [https://www.w3schools.com/w3css/default.asp](https://www.w3schools.com/w3css/default.asp)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 00:02:13+00:00

<p>Article URL: <a href="https://www.w3schools.com/w3css/default.asp">https://www.w3schools.com/w3css/default.asp</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32831679">https://news.ycombinator.com/item?id=32831679</a></p>
<p>Points: 25</p>
<p># Comments: 20</p>

## What Gödel Discovered (in Lisp)
 - [https://stopa.io/post/269](https://stopa.io/post/269)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-14 00:01:31+00:00

<p>Article URL: <a href="https://stopa.io/post/269">https://stopa.io/post/269</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32831673">https://news.ycombinator.com/item?id=32831673</a></p>
<p>Points: 10</p>
<p># Comments: 4</p>


# Source:Luke Smith - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, language:en-US

## I Will Be Throwing Away My Computers.
 - [https://www.youtube.com/watch?v=HAGWOx2dw1Y](https://www.youtube.com/watch?v=HAGWOx2dw1Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2022-09-14 16:24:46+00:00

If you want your computing to be as efficient as possible, you should have as little as possible. Here I plan downsizing and ask for a way to do everything more efficiently. Is there actually a decent computer with a trackpoint, ultrabase or dock which can handle livestreams and is still easily repairable?... I.e. without planned obsolescence?

Coreboot, 1080p screens, MSATA and a decent on-board mic and webcam are pluses, but the goal is to totally eradicate the need for two computers.

My website: https://lukesmith.xyz
Classical books reprinted by me: https://lindypress.net
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz
BTC: bc1qd20r7phdct3t0e0z6jqs55ulectg25pngt7hyl
XMR: 89yML3AtqnTNdo3wNuoaW44D94Zx1kBZNSBc9SyNxGdaKEZwZNdVzvy9zpbzJMzysiWZEU3b5LwjQ3XwWuQsknCF8JK73yv

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.


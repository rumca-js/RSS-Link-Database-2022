# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Disney Parks' Halloween Parties Scare Up Fun Tricks and Treats
 - [https://gizmodo.com/disney-parks-halloween-disneyland-walt-disney-world-1849531310](https://gizmodo.com/disney-parks-halloween-disneyland-walt-disney-world-1849531310)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 23:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--BAO0Y2tM--/c_fit,fl_progressive,q_80,w_636/2e452365e5266d78ba397c9bacbbd2f0.jpg" /><p>Fun and festive frights can be found at <a href="https://disneyland.disney.go.com/events-tours/disney-california-adventure/oogie-boogie-bash-halloween-party/" rel="noopener noreferrer" target="_blank">Oogie Boogie Bash at Disney California Adventure</a> during Halloween time, as well as at <a href="https://disneyworld.disney.go.com/events-tours/magi

## Avengers: The Kang Dynasty Snags Ant-Man: Quantumania Writer
 - [https://gizmodo.com/avengers-kang-dynasty-snags-ant-man-quantumania-writer-1849537343](https://gizmodo.com/avengers-kang-dynasty-snags-ant-man-quantumania-writer-1849537343)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 22:25:06+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--WCNTd5UH--/c_fit,fl_progressive,q_80,w_636/6d0ba3801d133631d5883408bd4a25f4.jpg" /><p>Jeff Loveness—the screenwriter who penned <a href="https://gizmodo.com/ant-man-and-the-wasp-should-be-called-the-wasp-and-ant-1827141863"><em>Ant-Man and the Wasp</em></a><em>: <a href="https://gizmodo.com/ant-man-3-quantumania-cassie-lang-stature-costume-1849325463">Quantumania</a></em>, which features Kang as its villain—is keeping on the beat of 

## Amazon Stifles Competitors and Makes Lots of Stuff More Expensive, California Attorney General Alleges
 - [https://gizmodo.com/amazon-sued-california-attorney-general-antitrust-1849536154](https://gizmodo.com/amazon-sued-california-attorney-general-antitrust-1849536154)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 22:22:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--jwiuvqvT--/c_fit,fl_progressive,q_80,w_636/8721ba487c4df9de9a0fbaa51b72c00d.jpg" /><p>California is suing Amazon, the state’s attorney general announced  Wednesday in <a href="https://oag.ca.gov/news/press-releases/attorney-general-bonta-announces-lawsuit-against-amazon-blocking-price" rel="noopener noreferrer" target="_blank">a press release</a>. The focus of <a href="https://oag.ca.gov/system/files/attachments/press-docs/2022-09-14

## Social Media Companies Now Have to Tell California What Their Hate Speech and Disinfo Policies Are
 - [https://gizmodo.com/social-media-transparency-law-california-hate-speech-1849535993](https://gizmodo.com/social-media-transparency-law-california-hate-speech-1849535993)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 21:44:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--R7HHcNNS--/c_fit,fl_progressive,q_80,w_636/c57058d34aacc6667089b06d60eb38fb.jpg" /><p>California Gov. Gavin Newsom <a href="https://www.gov.ca.gov/2022/09/13/governor-newsom-signs-nation-leading-social-media-transparency-measure/" rel="noopener noreferrer" target="_blank">announced</a> late Tuesday that he’d signed a “first-of-its-kind” bill into law designed to “protect Californians from hate and disinformation spread online.” <br /

## Lord of the Rings' Wizards, Explained
 - [https://gizmodo.com/lord-of-the-rings-wizards-rings-of-power-stranger-1849536723](https://gizmodo.com/lord-of-the-rings-wizards-rings-of-power-stranger-1849536723)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--IiyyGHCm--/c_fit,fl_progressive,q_80,w_636/81752901a24ac7904941300ecfac617c.png" /><p>In a world full of fantastical mysteries, there are few things more mysterious in Middle-earth than the Istari: the powerful sorcerers who helped, in ways big and small, shape the very fate of the world. But for all we know of Gandalf and Saruman, the wider world of <a href="https://gizmodo.com/the-lord-of-the-rings-studio-wanted-to-kill-off-one-of-

## Samantha Cristoforetti Will Be the First European Woman to Command the ISS
 - [https://gizmodo.com/samantha-cristoforetti-first-european-woman-command-iss-1849536571](https://gizmodo.com/samantha-cristoforetti-first-european-woman-command-iss-1849536571)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 21:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--sF9ShURY--/c_fit,fl_progressive,q_80,w_636/49d621b0395f802ff2bf7511b183a9af.jpg" /><p>After making the first TikTok video while aboard the International Space Station, Samantha Cristoforetti is making history once again as she’s been chosen to command the orbital outpost, making her the first European woman to do so. </p><p><a href="https://gizmodo.com/samantha-cristoforetti-first-european-woman-command-iss-1849536571">Read more...</

## Carnegie Mellon Professor Who Wished Queen Elizabeth II 'Excruciating' Death Says Her Job Is Safe
 - [https://gizmodo.com/carnegie-mellon-uju-anya-queen-excruciating-pain-safe-1849536603](https://gizmodo.com/carnegie-mellon-uju-anya-queen-excruciating-pain-safe-1849536603)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 20:51:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--HhG7K28I--/c_fit,fl_progressive,q_80,w_636/b2e0be9dc138d54a461123ba669b13bf.jpg" /><p>Carnegie Mellon professor Uju Anya, who <a href="https://gizmodo.com/students-letter-supports-professors-queen-tweets-1849526713">unleashed a social media storm</a> last week when she wished the late Queen Elizabeth II “excruciating pain” in death in a tweet, is back on Twitter. In an update, she thanked the people who supported her, and assured the

## Avenue 5's Season 2 Trailer Promises Complete Anarchy in Outer Space
 - [https://gizmodo.com/avenue-5s-season-2-trailer-promises-complete-anarchy-in-1849535910](https://gizmodo.com/avenue-5s-season-2-trailer-promises-complete-anarchy-in-1849535910)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 20:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Me7DQjgF--/c_fit,fl_progressive,q_80,w_636/752a70a098f4ebfec6338a38ca9b8a0e.jpg" /><p>It’s been so long since <a href="https://gizmodo.com/avenue-5-contains-all-the-absurd-chaos-we-hope-to-never-1841528494"><em>Avenue 5</em></a>'s <a href="https://gizmodo.com/5-things-we-want-from-avenue-5-season-2-1842297436">first season</a> aired (and a <em>lot</em> has happened in the world since March 2020), but we do remember a) we enjoyed the 

## Charmin Tops List of Toilet Papers That Are Destroying Sensitive Forests
 - [https://gizmodo.com/toilet-paper-sustainable-nrdc-charmin-procter-gamble-1849535507](https://gizmodo.com/toilet-paper-sustainable-nrdc-charmin-procter-gamble-1849535507)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 20:44:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--xooQ8h-R--/c_fit,fl_progressive,q_80,w_636/832c23c972be43d2436677008a8eb705.jpg" /><p>Major household brands are ensuring that we flush an important climate resource down the toilet. The Natural Resource Defense Council recently released its <a href="https://www.nrdc.org/experts/ashley-jordan/2022-tissue-scorecard-tps-future-lies-sustainability" rel="noopener noreferrer" target="_blank">Issue with Tissue</a> report and scorecard, rat

## Flo Period-Tracking App Releases ‘Anonymous Mode,' but Users Should Still Be Cautious
 - [https://gizmodo.com/flo-app-releases-anonymous-mode-period-abortion-bans-1849536742](https://gizmodo.com/flo-app-releases-anonymous-mode-period-abortion-bans-1849536742)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 20:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s---DurOGCQ--/c_fit,fl_progressive,q_80,w_636/16eabe15029a1cca36c3ab6b06223020.jpg" /><p>Period tracking app <a href="https://gizmodo.com/these-apps-reportedly-shared-sensitive-personal-informa-1832827887">Flo</a> is hoping its newly released “Anonymous Mode” will give users the confidence to continue using their product even as state law enforcement authorities around the country appear increasingly interested in soliciting data from a

## A Virus That Can Cause Polio-Like Paralysis in Children Has Returned
 - [https://gizmodo.com/acute-flaccid-myelitis-enterovirus-d-68-cdc-2022-1849536384](https://gizmodo.com/acute-flaccid-myelitis-enterovirus-d-68-cdc-2022-1849536384)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--XCjgK95_--/c_fit,fl_progressive,q_80,w_636/adfec5e9c0a0815d9b512468716907b7.jpg" /><p>A virus that can rarely cause a polio-like paralysis in children has resurfaced in the U.S. after mostly disappearing during the covid-19 pandemic. The Centers for Disease Control and Prevention reports that it has spotted a surge of cases linked to enterovirus D-68. Based on recent past outbreaks, officials expect…</p><p><a href="https://gizmodo.co

## Feds Accuse Hacking Trio Tied to Iranian Military of Hundreds of Ransomware Attacks on U.S.
 - [https://gizmodo.com/iran-hacker-ransomware-hundreds-doj-ahmadi-aghda-ravari-1849535294](https://gizmodo.com/iran-hacker-ransomware-hundreds-doj-ahmadi-aghda-ravari-1849535294)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 20:27:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--VxNEqbU3--/c_fit,fl_progressive,q_80,w_636/29bcb6a15648c3c33add6a618ad07a96.jpg" /><p><a href="https://gizmodo.com/iranian-hackers-left-5-hours-worth-of-hacking-how-tos-c-1844421276">Iranian hackers</a> with ties to the  nation’s military are responsible for carrying out “hundreds” of ransomware attacks on victims in the U.S. and other countries over multiple years, U.S. federal authorities said Wednesday. The attacks are said to hav

## Biden Announces $900 Million to Boost Electric Vehicle Charging
 - [https://gizmodo.com/biden-electric-vehicle-chargers-900-million-funding-1849535629](https://gizmodo.com/biden-electric-vehicle-chargers-900-million-funding-1849535629)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 20:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ajU6Ltn2--/c_fit,fl_progressive,q_80,w_636/5de5e7791908a4a74ce9f41479eee409.jpg" /><p>President Joe Biden announced<strong> </strong>in a speech today that $900 million of federal funding will go toward increasing the number of <a href="https://gizmodo.com/tesla-supercharger-charging-stations-twitter-1849516689">electric vehicle chargers</a> nationwide. This funding is the first chunk of money allocated to building EV chargers from a

## Google Assistant May Soon Allow Custom Quick Phrases
 - [https://gizmodo.com/google-assistant-custom-quick-phrases-hey-google-smart-1849536205](https://gizmodo.com/google-assistant-custom-quick-phrases-hey-google-smart-1849536205)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--MhUSpBjq--/c_fit,fl_progressive,q_80,w_636/5309805b1baa39bd536b3c007a8c709c.jpg" /><p>I am so over yelling in complete sentences to the Google Assistant. Although I run all the digital assistants—it’s my job, you know—Google primarily controls my smart home. There’s nothing more frustrating than trying to yell out a complete command while strapping down your toddler during a full-blown meltdown.…</p><p><a href="https://gizmodo.com/go

## Thousands Still Without Stable Housing in Eastern Kentucky, and FEMA Aid Is Slow to Materialize
 - [https://gizmodo.com/thousands-without-stable-housing-in-kentucky-flooding-1849535123](https://gizmodo.com/thousands-without-stable-housing-in-kentucky-flooding-1849535123)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--D2Ty5tPF--/c_fit,fl_progressive,q_80,w_636/c1e6d28ba76ac98750e2d5986aabde3b.jpg" /><p>It’s been a month and a half since <a href="https://gizmodo.com/kentucky-gov-were-going-to-be-finding-bodies-for-weeks-1849354284/slides/2">devastating floods</a> tore through Eastern Kentucky. A historic, so-called <a href="https://gizmodo.com/death-valley-climate-change-thousand-year-rainfall-1849399962">thousand-year rainfall</a> overflowed river

## Rail Workers Authorize Strike That Could Upend Supply Chains
 - [https://gizmodo.com/rail-workers-authorize-strike-that-could-upend-supply-c-1849536151](https://gizmodo.com/rail-workers-authorize-strike-that-could-upend-supply-c-1849536151)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 19:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--AIgshGCC--/c_fit,fl_progressive,q_80,w_636/2019b13a6c3654ba27440b0738973cfa.jpg" /><p>Rail workers could be going on strike soon for the first time <a href="https://www.barrons.com/articles/railroad-workers-union-strike-shut-down-51663100305" rel="noopener noreferrer" target="_blank">in nearly 30 years</a>, which could result in enormous impacts on the wider economy and supply chains.</p><p><a href="https://gizmodo.com/rail-workers-a

## The Scarlet Witch Is Alive, Redeemed, and Ready to Help
 - [https://gizmodo.com/scarlet-witch-marvel-comics-solo-series-wanda-maximoff-1849534785](https://gizmodo.com/scarlet-witch-marvel-comics-solo-series-wanda-maximoff-1849534785)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 19:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--TvNWD0JY--/c_fit,fl_progressive,q_80,w_636/74d164cbc20992c65f85be59a95a38b4.jpg" /><p>Fans of the <a href="https://gizmodo.com/doctor-strange-2-scarlet-witch-madness-comics-sexism-1848919397">Scarlet Witch</a> might still be bummed that the Wanda Maximoff of the Marvel Cinematic Universe turned evil, killed a lot of people, and buried herself under a mountain at the end of <a href="https://gizmodo.com/doctor-strange-in-the-multiverse

## The UK Government Is Directing Mourners to North Carolina to Stand in Line for Queen Elizabeth
 - [https://gizmodo.com/queen-elizabeth-ii-westminster-queue-line-what3words-uk-1849536290](https://gizmodo.com/queen-elizabeth-ii-westminster-queue-line-what3words-uk-1849536290)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 19:07:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ZCSnSkQf--/c_fit,fl_progressive,q_80,w_636/8d55a65c7ac647194ea1f135929a0c51.jpg" /><p>It’s a well-known fact that British people love queueing – and millions of them are expected to try to tackle the boss level of queueing as Queen Elizabeth II lies in state in the Palace of Westminster in London today.<br /></p><p><a href="https://gizmodo.com/queen-elizabeth-ii-westminster-queue-line-what3words-uk-1849536290">Read more...</a></p>

## The Bad Boy of Karate Speaks! We Chatted With Cobra Kai's Sean Kanan
 - [https://gizmodo.com/cobra-kai-5-netflix-mike-barnes-sean-kanan-interview-1849531557](https://gizmodo.com/cobra-kai-5-netflix-mike-barnes-sean-kanan-interview-1849531557)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vjcNVuwr--/c_fit,fl_progressive,q_80,w_636/b6b53b8c5527218d05441d03e0cf46ec.jpg" /><p>In a show about the villain of the first <a href="https://gizmodo.com/cobra-kai-is-the-awesome-karate-kid-sequel-you-may-or-m-1825427386"><em>Karate Kid</em> movie</a> that features the villain from the <em>Karate Kid</em> sequel, you just knew <a href="https://gizmodo.com/cobra-kai-5-netflix-interview-terry-silver-karate-kid-3-1849481760">the villa

## FAA Grounds Bezos After New Shepard Booster Goes Up in Flames
 - [https://gizmodo.com/blue-origin-faa-new-shepard-booster-failure-1849535838](https://gizmodo.com/blue-origin-faa-new-shepard-booster-failure-1849535838)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 18:23:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--aG2_FlKy--/c_fit,fl_progressive,q_80,w_636/ce90e5fdde6a412debacc86466a5a162.jpg" /><p>Suborbital flights of Blue Origin’s space tourism rocket are suspended pending a Federal Aviation Administration review of Monday’s in-flight anomaly. No passengers were aboard at the time, but the apparent booster failure triggered the vehicle’s capsule escape system. </p><p><a href="https://gizmodo.com/blue-origin-faa-new-shepard-booster-failure-1

## The 'MVP of Serial Murder' Returns in Chucky's Season 2 Trailer
 - [https://gizmodo.com/chucky-s2-trailer-jennifer-tilly-glen-and-glenda-murder-1849535148](https://gizmodo.com/chucky-s2-trailer-jennifer-tilly-glen-and-glenda-murder-1849535148)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 17:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s---QZvGVvw--/c_fit,fl_progressive,q_80,w_636/cb76939e385c0ee4ea24163c5353fe98.png" /><p>We got a glimpse of <a href="https://gizmodo.com/chucky-gets-a-season-2-lives-to-slay-another-day-1848134450"><em>Chucky </em>season two</a> thanks to a <a href="https://gizmodo.com/chucky-season-2-horror-trailer-san-diego-comic-con-2022-1849183326">San Diego Comic-Con teaser</a>, but the killer doll now has a full trailer ahead of the much-anticipa

## Chevron Is Using Captain Planet and Batman Returns to Deflect Blame for Its Climate Denial
 - [https://gizmodo.com/chevron-legal-defense-captain-planet-batman-climate-cha-1849535353](https://gizmodo.com/chevron-legal-defense-captain-planet-batman-climate-cha-1849535353)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 17:43:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--kdoob3Hg--/c_fit,fl_progressive,q_80,w_636/514689a285331d4a9ae42cfcccd61c79.jpg" /><p>Big Oil wants you to believe that, because climate change was mentioned in children’s cartoons and a Batman movie in the 1990s, companies like Chevron hold no responsibilities for the current climate crisis.<br /></p><p><a href="https://gizmodo.com/chevron-legal-defense-captain-planet-batman-climate-cha-1849535353">Read more...</a></p>

## Twitter Bans Weirdo Who Shared Racist Video Changing Halle Bailey's Ariel From Black to White
 - [https://gizmodo.com/little-mermaid-halle-bailey-ariel-twitter-white-ban-1849535257](https://gizmodo.com/little-mermaid-halle-bailey-ariel-twitter-white-ban-1849535257)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 17:21:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--huiIhleg--/c_fit,fl_progressive,q_80,w_636/fccb25e52960d667bfe597405071c44e.png" /><p>Twitter banned a user who shared a modified, racist clip from Disney’s new live action <em>The Little Mermaid </em>Wednesday.<em> </em>The tweaked video turned the skin of singer and actress Halle Bailey, who plays Ariel, from Black to white. <br /></p><p><a href="https://gizmodo.com/little-mermaid-halle-bailey-ariel-twitter-white-ban-1849535257">Re

## Arianespace Reaches Deal With OneWeb, Setting Stage for Resumption of Suspended Launches
 - [https://gizmodo.com/arianespace-oneweb-poised-resume-suspended-launches-1849534913](https://gizmodo.com/arianespace-oneweb-poised-resume-suspended-launches-1849534913)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 17:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ymy1ybK3--/c_fit,fl_progressive,q_80,w_636/88df0e2faf0cecbb5ca1e6f8be506c1a.jpg" /><p>After having to cancel launches aboard Russian Soyuz rockets, British satellite company OneWeb has reached a settlement agreement with Arianespace that could see a resumption of the suspended launches. <br /></p><p><a href="https://gizmodo.com/arianespace-oneweb-poised-resume-suspended-launches-1849534913">Read more...</a></p>

## An Unauthorized Joker Film Debuted Last Night and You May Never Get to See It
 - [https://gizmodo.com/the-peoples-joker-vera-drew-toronto-dc-warner-bros-disc-1849535125](https://gizmodo.com/the-peoples-joker-vera-drew-toronto-dc-warner-bros-disc-1849535125)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--RnLuYUEP--/c_fit,fl_progressive,q_80,w_636/717b847b8111a179846fe0367f4d3196.jpg" /><p>A brand new <a href="https://gizmodo.com/io9-discusses-todd-phillips-polarizing-joker-a-movie-w-1838857776"><em>Joker</em> film</a> made its world premiere last night but that might be the only time it ever plays. It’s called <em>The People’s Joker</em> and is described as “a queer coming-of-age story complete with a copyright-defying array of villa

## An Uber Eats Delivery Robot Crashed a Crime Scene
 - [https://gizmodo.com/uber-eat-food-delivery-robot-hollywood-high-crime-scene-1849534839](https://gizmodo.com/uber-eat-food-delivery-robot-hollywood-high-crime-scene-1849534839)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 16:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--bGD08OLr--/c_fit,fl_progressive,q_80,w_636/c65bb9f48296c5dd073bef4bd132dd83.jpg" /><p>One of Uber’s <a href="https://gizmodo.com/cruise-confuse-self-driving-cars-san-francisco-street-1849134076">self-driving</a> food delivery robots did not take kindly to the yellow caution tape surrounding a crime scene in Los Angeles as it plowed through the area, according to a video shared on Twitter Tuesday. <br /></p><p><a href="https://gizmodo

## Amazon Is Giving Raises to Delivery Drivers (But Not the Ones Who Protested)
 - [https://gizmodo.com/amazon-is-giving-raises-to-delivery-drivers-but-not-th-1849534163](https://gizmodo.com/amazon-is-giving-raises-to-delivery-drivers-but-not-th-1849534163)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 16:47:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--4XnOAPcM--/c_fit,fl_progressive,q_80,w_636/5816b73ef2f5250129e1013aa26ed449.jpg" /><p>Amazon is trotting out new benefits and higher pay for some of its drivers, the company announced in a Tuesday afternoon <a href="https://press.aboutamazon.com/news-releases/news-release-details/amazon-deepens-commitment-delivery-service-partners-and-drivers" rel="noopener noreferrer" target="_blank">press release</a>. Specifically, it is putting mo

## Guess How Much Crypto's Been Stolen Lately? Part 1
 - [https://gizmodo.com/guess-how-much-cryptos-been-stolen-lately-part-1-1849534790](https://gizmodo.com/guess-how-much-cryptos-been-stolen-lately-part-1-1849534790)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 16:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--iHp4sY_8--/c_fit,fl_progressive,q_80,w_636/fb995e81e7cd101ff870fe843998f6a0.jpg" /><p><a href="https://gizmodo.com/guess-how-much-cryptos-been-stolen-lately-part-1-1849534790">Read more...</a></p>

## Thanko's Cup Noodle Machine Saves You the Hassle of *Checks Notes* Boiling Water
 - [https://gizmodo.com/thanko-cup-noodle-machine-electric-kettle-keurig-ramen-1849535103](https://gizmodo.com/thanko-cup-noodle-machine-electric-kettle-keurig-ramen-1849535103)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 16:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--E-ur0gl4--/c_fit,fl_progressive,q_80,w_636/6a16c172825953c2bfee58609a0bdcaa.jpg" /><p>Where I’m from, there are really just two reasons to eat a cup of instant noodles: you’re either a cash-strapped student who can’t afford to eat better, or you’re too tired to make anything more elaborate to eat. It’s just about the easiest meal to prep, but the gadget wizards at <a href="https://www.thanko.jp/view/item/000000003439" rel="noopener n

## Mike Mignola Gets Seasonally Spooky for Not One, But 2 Holidays
 - [https://gizmodo.com/mike-mignola-leonide-the-vampyre-halloween-christmas-1849535078](https://gizmodo.com/mike-mignola-leonide-the-vampyre-halloween-christmas-1849535078)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--tLFJ949I--/c_fit,fl_progressive,q_80,w_636/bd0b3c00eaf5939564d7d68aefb8d45b.png" /><p>Is there a comic writer who possibly loves <a href="https://gizmodo.com/mike-mignola-hellboy-drawing-monsters-documentary-1849141978">spooky season</a> as much as <a href="https://gizmodo.com/mike-mignolas-next-fantasy-adventure-journeys-into-a-be-1847629595"><em>Hellboy</em></a>’s <a href="https://gizmodo.com/mike-mignola-reflects-on-25-hellishly-g

## Orbital Debris Threatens Our Future in Space, so NASA Is Seeking Solutions
 - [https://gizmodo.com/nasa-funds-projects-study-orbital-debris-1849534307](https://gizmodo.com/nasa-funds-projects-study-orbital-debris-1849534307)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 15:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--TtMeJjkW--/c_fit,fl_progressive,q_80,w_636/b23a0020400398e7074c94db37170d27.jpg" /><p>NASA needs to know what’s going on with all of the junk that’s orbiting our planet. The space agency announced yesterday that it would be funding three proposals from various universities to better understand orbital debris and sustainability in space.<br /></p><p><a href="https://gizmodo.com/nasa-funds-projects-study-orbital-debris-1849534307">Read

## Police Issue Arrest Warrant for Crypto CEO Do Kwon Following Implosion of TerraUSD
 - [https://gizmodo.com/police-issue-arrest-warrant-for-crypto-ceo-do-kwon-1849534780](https://gizmodo.com/police-issue-arrest-warrant-for-crypto-ceo-do-kwon-1849534780)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 15:46:02+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--f16nSxjv--/c_fit,fl_progressive,q_80,w_636/ac315bc2ca1bbad50ecb0f7d5d787182.png" /><p>Over four months after the collapse of TerraUSD tore down the crypto marketplace, South Korean police are currently on the hunt for Do Kwon (and other top people behind Terraform Labs) over allegations of fraud and tax evasion.</p><p><a href="https://gizmodo.com/police-issue-arrest-warrant-for-crypto-ceo-do-kwon-1849534780">Read more...</a></p>

## This Startup's Free Software Could Prevent Satellite Collisions
 - [https://gizmodo.com/this-startups-free-software-could-prevent-satellite-col-1849531806](https://gizmodo.com/this-startups-free-software-could-prevent-satellite-col-1849531806)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 15:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--04jXYp5o--/c_fit,fl_progressive,q_80,w_636/6bbe82051bbb9540ad2bb6a5b009e664.jpg" /><p>Space is getting a little too crowded, increasing the <a href="https://gizmodo.com/swarm-satellite-dodges-space-junk-1849177595">risk of orbital collisions</a>. Slingshot Aerospace, a company specializing in space data analytics, is now offering a solution to regulate some of the traffic up there. The company announced on Tuesday that it is rolling 

## 12 Marvel Villains Who Should Have Been in Thunderbolts
 - [https://gizmodo.com/thunderbolts-movie-marvel-villains-zemo-bullseye-agatha-1849531283](https://gizmodo.com/thunderbolts-movie-marvel-villains-zemo-bullseye-agatha-1849531283)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 15:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--gx_jiJQ7--/c_fit,fl_progressive,q_80,w_636/60484d722f1f2c871dbb7957e12a7557.jpg" /><p>Marvel’s line-up for the <a href="https://gizmodo.com/marvel-thunderbolts-cast-reveal-1849521585"><em>Thunderbolts</em> is weird</a>. It’s been bugging me ever since it was announced this past weekend. <a href="https://gizmodo.com/the-falcon-and-the-winter-soldier-ended-what-now-1846747970">U.S. Agent <em>and</em> Bucky Barnes</a>? <em>Three</em> ch

## South Korea Hits Google, Meta With Record-Setting Fines Over Privacy Violations
 - [https://gizmodo.com/google-meta-hit-with-record-setting-fines-over-privacy-1849534472](https://gizmodo.com/google-meta-hit-with-record-setting-fines-over-privacy-1849534472)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 14:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Z-PPp1Lv--/c_fit,fl_progressive,q_80,w_636/b03bfb74d6132bb1e400e13b05e8871d.jpg" /><p>Google and Meta have <a href="https://gizmodo.com/google-fined-57-million-for-burying-privacy-terms-wher-1831929411">yet</a> <a href="https://gizmodo.com/heres-why-google-just-got-hit-with-a-record-5-billion-1827683622">another</a> <a href="https://gizmodo.com/facebook-and-google-accused-of-violating-gdpr-on-first-1826321323">privacy</a> <a href="ht

## Then and Now: Our Earliest Close-Ups of the Planets Compared to Today's Best Shots
 - [https://gizmodo.com/best-images-of-the-planets-earliest-close-ups-1849507579](https://gizmodo.com/best-images-of-the-planets-earliest-close-ups-1849507579)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 14:42:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--4O9cLXsj--/c_fit,fl_progressive,q_80,w_636/6bf4bc31ee296f329d38671d6b2c0573.jpg" /><p>For centuries, astronomers were limited to ground-based observations of the planets, but now we use spacecraft to capture close-up views of our neighboring worlds. Excitingly, our views of solar system planets have been getting progressively better over the decades, as these images attest.</p><p><a href="https://gizmodo.com/best-images-of-the-planet

## HP Made a Robot That Prints Blueprints Onto a Construction Site
 - [https://gizmodo.com/hp-construction-site-blueprints-robot-siteprint-roomba-1849534309](https://gizmodo.com/hp-construction-site-blueprints-robot-siteprint-roomba-1849534309)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 14:40:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--7R9zd-FB--/c_fit,fl_progressive,q_80,w_636/852b940357c585ecb804f83f102822a3.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--PaDmKAj6--/c_fit,fl_progressive,q_80,w_636/852b940357c585ecb804f83f102822a3.mp4" type="video/mp4" /></video><p>There are lots of <a href="https://gizmodo.com/watching-a-robot-slip-and-fall-is-way-more-entertaining-1847556442">incredibly capable robots in research labs</a> arou

## The Museum of Modern Art Is Selling a Picasso Painting to Help Fund Potential Push Into NFTs
 - [https://gizmodo.com/moma-is-selling-a-picasso-to-help-fund-nft-purchases-1849534341](https://gizmodo.com/moma-is-selling-a-picasso-to-help-fund-nft-purchases-1849534341)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 14:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--arXZW4lN--/c_fit,fl_progressive,q_80,w_636/c4990ed437ac168869a32c9ba7ec4316.jpg" /><p>The Museum of Modern Art mission statement is to “connect people from around the world to the art of our time.” Unfortunately, it seems like New York’s most prominent purveyor of “<a href="https://www.moma.org/about/" rel="noopener noreferrer" target="_blank">thought-provoking art</a>” has some abstract reasons for considering snapping up a few digi

## Joker: Folie à Deux Adds a Mystery Arkham Inmate
 - [https://gizmodo.com/joker-folie-a-deux-jacob-lofland-arkham-asylum-1849533491](https://gizmodo.com/joker-folie-a-deux-jacob-lofland-arkham-asylum-1849533491)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 13:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--87OJEp7X--/c_fit,fl_progressive,q_80,w_636/08a51aa0b3f5419271982f9e7cae7879.png" /><p><em>Superman &amp; Lois</em> gives Clark a supersuit upgrade in season three. Titania takes New York in new <em>She-Hulk</em> ads. Plus, what’s coming on <em>Archer</em> and the return of <em>Kung Fu</em>. Spoilers, away!<br /></p><p><a href="https://gizmodo.com/joker-folie-a-deux-jacob-lofland-arkham-asylum-1849533491">Read more...</a></p>

## Goodbye to San Francisco, Self-Driving Cars, and Solitude
 - [https://gizmodo.com/goodbye-to-san-francisco-self-driving-cars-and-solitude-1849531992](https://gizmodo.com/goodbye-to-san-francisco-self-driving-cars-and-solitude-1849531992)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 13:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--es4sCOpb--/c_fit,fl_progressive,q_80,w_636/4ae545d7d2e087369842e57e879fa04a.png" /><p>There is a loneliness to San Francisco. During the day, life bustles about in busy exercise. At night, the city abandons itself. The streets empty out. San Francisco is a city that sleeps—an early to bed, early to yoga city. If you are inclined to stay awake in the darkened hours, you will find yourself often in…</p><p><a href="https://gizmodo.com/g

## Apple's iPhone 14 Pro Makes Ditching Android More Tempting Than Ever
 - [https://gizmodo.com/apple-iphone-14-pro-review-max-google-android-pixel-13-1849532287](https://gizmodo.com/apple-iphone-14-pro-review-max-google-android-pixel-13-1849532287)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--asC7T5SK--/c_fit,fl_progressive,q_80,w_636/dfd26d9e4e39fb2d2c392859dceffd0a.png" /><p>Before we get into this, you should know that this is my first time reviewing an iPhone. I’ve long established myself as “the Android girl,” because I started my smartphone journey with that mobile platform and eventually grew to prefer it over my initial experience with the iPhone. The last time I wielded one of…</p><p><a href="https://gizmodo.com/

## GoPro's Hero 11 Black is a Great Reintroduction to the Outdoors
 - [https://gizmodo.com/gopro-hero-11-black-hands-on-review-10-black-worth-it-1849531827](https://gizmodo.com/gopro-hero-11-black-hands-on-review-10-black-worth-it-1849531827)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--EjdYUy_S--/c_fit,fl_progressive,q_80,w_636/26b5a4592b3de467ac3830e69d9fc21b.jpg" /><p>GoPro’s Hero 11 Black is here, bringing with it not just a generational tech upgrade, but also new features like auto-highlight reels, which make capturing great looking footage easier than ever before.</p><p><a href="https://gizmodo.com/gopro-hero-11-black-hands-on-review-10-black-worth-it-1849531827">Read more...</a></p>

## DJI Returns to a Familiar Design for Its Third Action Camera
 - [https://gizmodo.com/dji-osmo-action-3-cam-vs-gopro-hero-black-all-in-one-1849500864](https://gizmodo.com/dji-osmo-action-3-cam-vs-gopro-hero-black-all-in-one-1849500864)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 12:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--laNh8QJo--/c_fit,fl_progressive,q_80,w_636/a2a380fdf49cbfd6a0ad294634cb98cc.jpg" /><p>Although GoPro has strongly cemented itself as the defacto brand name when it comes to tiny mountable cameras that can take a beating, <a href="https://gizmodo.com/gopro-better-watch-its-back-1835152372">DJI has delivered some stiff competition</a> in this space over the past few years, and with its new Osmo Action 3, it’s returning to a tried and t

## Northeastern Bomber Targeted Virtual Reality Club on Campus: Report
 - [https://gizmodo.com/facebook-meta-northeastern-bomb-virtual-reality-zuck-1849533437](https://gizmodo.com/facebook-meta-northeastern-bomb-virtual-reality-zuck-1849533437)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 10:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--0ZESdvtG--/c_fit,fl_progressive,q_80,w_636/4cc84fade5259efac8c1c184aed6b690.jpg" /><p>Police discovered a note railing against virtual reality and Meta CEO Mark Zuckerberg on the scene of a package explosion at Northeastern University in Boston on Tuesday night, according to CBS Boston. An unnamed 45-year-old man at the university suffered “minor hand injuries” from the explosion and a second package…</p><p><a href="https://gizmodo.c

## Jordan Peele's Nope Is Coming Home This Halloween—But You Can Watch It First on the Cloud
 - [https://gizmodo.com/jordan-peele-nope-blu-ray-universal-pictures-monkeypaw-1849532852](https://gizmodo.com/jordan-peele-nope-blu-ray-universal-pictures-monkeypaw-1849532852)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-14 00:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--T6ai9c42--/c_fit,fl_progressive,q_80,w_636/0d098920474b1a2e8cc198ccff2130c1.png" /><p>Bring Jean Jacket home with the Blu-ray and 4K release of <a href="https://gizmodo.com/nope-spoilers-jordan-peele-gordys-home-keke-palmer-yeun-1849332974"><em>Nope</em></a><em>—</em>the latest from the mind of modern horror master Jordan Peele, who’s made looking up at the sky a whole lot scarier lately. </p><p><a href="https://gizmodo.com/jordan-pe


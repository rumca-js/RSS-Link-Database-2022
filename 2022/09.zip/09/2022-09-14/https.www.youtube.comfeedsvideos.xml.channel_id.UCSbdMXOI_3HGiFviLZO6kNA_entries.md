# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## These NEW VR Headsets are INSANE - TRUE NEXT GEN
 - [https://www.youtube.com/watch?v=tUecNPuKSCk](https://www.youtube.com/watch?v=tUecNPuKSCk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-09-14 19:30:03+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news! HOLY COW, this week is looking crazy. The Quest Pro was leaked, Quest 2 gets a big update, we got to see PSVR 2 in hands, AND Pico is prepping for their big launch/ announcement. PLUS we got to see a brand new headset, the Somnium One taking its next steps. BUCKLE UP! This is a very packed week. 

Project SCHISM Link:
https://discord.gg/mWctWQhTbv

IRL SAN DIEGO TWITCH CON VR MEETUP:
https://forms.gle/DPeZbcXG8xZzcpG59

My Links:
My links:
https://www.twitch.tv/thrilluwu
My discord: 
https://discord.gg/2hCGM9BYez
Patreon link:
https://www.patreon.com/Thrillseeker

Music Channel: 
https://www.youtube.com/watch?v=u6JwgNQDVfI&amp;t=0s&amp;ab_channel=thrill.


# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Grudziądz. W drzewie znaleziono ciało noworodka. Zatrzymany 18-latek wyszedł na wolność
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28912602,grudziadz-w-drzewie-znaleziono-cialo-noworodka-zatrzymany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28912602,grudziadz-w-drzewie-znaleziono-cialo-noworodka-zatrzymany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-14 19:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/39/13/1b/z28389945M,Sad--zdjecie-ilustracyjne-.jpg" vspace="2" />W sierpniu w Grudziądzu znaleziono ciało noworodka - początkowo jednak nie podano, że było one umieszczone w drzewie. Zatrzymano wtedy 17-latkę oraz jej 18-letniego partnera, którzy prawdopodobnie są biologicznymi rodzicami dziecka. Po miesiącu nastolatek wyszedł na wolność.

## "Wiadomości" TVP ruszyły na odsiecz Macierewiczowi. O reportażu TVN: "Zmasowany atak na polski rząd"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28912639,zmasowany-atak-wiadomosci-tvp-ruszyly-na-odsiecz-macierewiczowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28912639,zmasowany-atak-wiadomosci-tvp-ruszyly-na-odsiecz-macierewiczowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-14 19:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6e/92/1b/z28912750M,-Wiadomosci--TVP.jpg" vspace="2" />W "Wiadomościach" TVP jeden z materiałów poświęcono niedawnemu reportażowi TVN24, z którego wynika, że podkomisja smoleńska nie ujawniła danych podważających tezę o zamachu. "Wiadomości" nazywają materiał TVN24 "atakiem" na Antoniego Macierewicza i łączą go z zaangażowaniem Polski w pomoc Ukrainie.

## Wypadek Beaty Szydło. Biegli o zeznaniach świadków: Są niewiarygodne i nieprzydatne
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28911949,wypadek-beaty-szydlo-biegli-o-zeznaniach-swiadkow-sa-niewiarygodne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28911949,wypadek-beaty-szydlo-biegli-o-zeznaniach-swiadkow-sa-niewiarygodne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-14 16:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/83/49/1b/z28613507M,Beata-Szydlo.jpg" vspace="2" />Wypadek Beaty Szydło od kilku lat jest badany przez prokuraturę. Według najnowszych ustaleń biegłych zeznania sześciorga świadków "są nie tylko niewiarygodne z psychologicznego punktu widzenia, ale są nieprzydatne w tej sprawie". - Świadkowie opowiadają o rzeczach, których nie wiedzieli i nie słyszeli. Które zobaczyli albo o których usłyszeli w telewizji i o których rozmawiali ze sobą - pow

## Wyrok ws. "Skóry". Były policjant o skazanym: Pierwszy tom akt. Idealnie pasował do portretu psychologicznego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28912033,wyrok-ws-skory-byly-policjant-wspomina-lekarz-powiedzial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28912033,wyrok-ws-skory-byly-policjant-wspomina-lekarz-powiedzial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-14 15:51:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4d/92/1b/z28912205M,Proces-Roberta-J-.jpg" vspace="2" />- Zadzwonił lekarz, który robił sekcję zwłok i powiedział: "Panowie, jest problem, mamy do czynienia z czymś makabrycznym". Powiedział, że rzeczywiście jest to fragment ludzkiej skóry, ale skóry, która została precyzyjnie oddzielona od ciała - relacjonował w RMF FM Dariusz Nowak. Były rzecznik małopolskiej policji opowiedział o jednej z najgłośniejszych zbrodni w Polsce, w sprawie któr

## Inowrocław. Policjanci użyli gazu po wizycie Kaczyńskiego. Prokuratura odmawia wszczęcia śledztwa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28911224,inowroclaw-prokuratura-odmowila-wszczecia-sledztwa-ws-uzycia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28911224,inowroclaw-prokuratura-odmowila-wszczecia-sledztwa-ws-uzycia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-14 14:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0a/92/1b/z28911882M,Inowroclaw--Prokuratura-odmowila-wszczecia-sledztw.jpg" vspace="2" />Po czerwcowym spotkaniu Jarosława Kaczyńskiego z mieszkańcami Inowrocławia policjanci użyli gazu łzawiącego wobec protestujących. Prokuratura Okręgowa w Słupsku odmówiła wszczęcia śledztwa w tej sprawie. Jakie jest uzasadnienie tej decyzji?

## Przemysław Czarnek i pomysł na przedmiot BiZ oraz maturę... w grupach. "Nowość na skalę niespotykaną"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28911333,przemyslaw-czarnek-i-pomysl-na-przedmiot-biz-oraz-mature.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28911333,przemyslaw-czarnek-i-pomysl-na-przedmiot-biz-oraz-mature.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-14 13:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/17/8e/1b/z28893207M,Przemyslaw-Czarnek---zdjecie-ilustracyjne.jpg" vspace="2" />przedPrzemysław Czarnek zapowiedział nowy przedmiot, który pojawi się w szkołach ponadpodstawowych. W przyszłości do HiT-u dołączy jeszcze BiZ - biznes i zarządzanie. Warto dodać, że w wielu szkołach uczniowie mieli już zajęcia z podstaw przedsiębiorczości.

## Pożar w Stoczni Gdańskiej. Ewakuowano kilkaset osób, na miejscu 10 zastępów straży pożarnej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28911071,pozar-w-stoczni-gdanskiej-ewakuowano-kilkaset-osob-na-miejscu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28911071,pozar-w-stoczni-gdanskiej-ewakuowano-kilkaset-osob-na-miejscu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-14 12:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c5/8b/1b/z28881605M,Straz-Pozarna---zdjecie-ilustracyjne.jpg" vspace="2" />Strażacy z Gdańska poinformowali o pożarze, jaki wybuchł na dachu jeden z hal w Stoczni Gdańsku. Jeszcze przed przyjazdem służb z budynku ewakuowało się około 300 pracowników.

## Akt oskarżenia przeciwko aktorowi Bartłomiejowi M. Miał gwałcić nastolatki. Był związany z PiS
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28909050,akt-oskarzenia-przeciwko-aktorowi-bartlomiejowi-m-mial-gwalcic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28909050,akt-oskarzenia-przeciwko-aktorowi-bartlomiejowi-m-mial-gwalcic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-14 09:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/fb/1a/z28291383M,Sad--zdjecie-ilustracyjne-.jpg" vspace="2" />Bartłomiej M. odpowie przed sądem. Prokuratura zarzuca mu popełnienie 14 przestępstw przeciw wolności seksualnej - w tym wobec małoletnich. Miał zwabiać do mieszkania ofiary, udając wpływowego fotografa. Mężczyzna w przeszłości występował w spotach reklamowych Prawa i Sprawiedliwości. Startował także do Sejmu.

## "Kuśnierz z Krakowa" skazany na dożywocie. Jest wyrok ws. jednej z najgłośniejszych zbrodni w Polsce
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28909647,kusnierz-z-krakowa-skazany-na-dozywocie-jest-wyrok-ws-jednej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28909647,kusnierz-z-krakowa-skazany-na-dozywocie-jest-wyrok-ws-jednej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-14 09:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c8/92/1b/z28910024M,Proces-Robert-J-.jpg" vspace="2" />"Kuśnierz z Krakowa", a właściwie Robert J., został uznany winnym zabójstwa studentki, której fragmenty skóry i ciała pod koniec lat 90. wyłowiono z Wisły.

## Podręcznik do HiT-u. Prof. Wojciech Roszkowski: Stałem się chłopcem do bicia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28908191,podrecznik-do-hit-u-prof-wojciech-roszkowski-stalem-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28908191,podrecznik-do-hit-u-prof-wojciech-roszkowski-stalem-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-14 08:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/90/85/1b/z28859024M,Podrecznik-HiT----Historia-i-Terazniejszosc-.jpg" vspace="2" />Profesor Wojciech Roszkowski w ostatnim czasie wsławił się podręcznikiem do Historii i Teraźniejszości, który od samego początku budzi wiele emocji i kontrowersji. Nauczyciele i historycy krytykują publikację przede wszystkim za tendencyjność, błędy i treści dyskryminujące wiele grup społecznych (m.in. lewicę, feministki, LGBT+, dzieci z in vitro, ateistów). 

## Pogoda długoterminowa do końca września. Napływ chłodnego powietrza, przymrozki, a nawet lekki mróz
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28908088,pogoda-dlugoterminowa-do-konca-wrzesnia-naplyw-chlodnego-powietrza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28908088,pogoda-dlugoterminowa-do-konca-wrzesnia-naplyw-chlodnego-powietrza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-14 06:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f7/85/1b/z28859639M,Przymrozek--zdjecie-ilustracyjne-.jpg" vspace="2" />Pogoda w ostatnich dniach nie przynosi pięknej, złotej jesieni. W najbliższym czasie też nie można na nią liczyć, co pokazują najnowsze modele synoptyczne. Czeka nas zmiana aury i spore ochłodzenie.


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Rings of Power Episode 4 WATCH PARTY
 - [https://www.youtube.com/watch?v=1lv8EsUOTGc](https://www.youtube.com/watch?v=1lv8EsUOTGc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-09-15 00:00:00+00:00

Continuing this new journey through Middle-earth with episode 4 of The Lord of the Rings: The Rings of Power!

HOW IT WORKS:
1) Pull up Rings of Power on your Prime Video account on your tv, computer screen, or whatever device you want to watch on.
2) Use a second screen, phone, tablet, or whatever to pull up this stream.
3) We all start playing the film at the same time, watching together, then discussing afterwards

#theringsofpower #ringsofpower #lordoftherings


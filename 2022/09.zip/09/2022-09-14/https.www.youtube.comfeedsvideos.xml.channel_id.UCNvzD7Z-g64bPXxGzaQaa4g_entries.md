# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Sonic Frontiers Suddenly Looks Like A DIFFERENT GAME
 - [https://www.youtube.com/watch?v=XG02qtsZK94](https://www.youtube.com/watch?v=XG02qtsZK94)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-09-15 00:00:00+00:00

We've gotten more information and a closer look at Sonic Frontiers and it's not as bad as it initially looked. Has Sonic Team finally cracked the code? Let's speculate.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 BIG NEW PlayStation State of Play Announcements
 - [https://www.youtube.com/watch?v=TKLnbvzwrhI](https://www.youtube.com/watch?v=TKLnbvzwrhI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-09-14 00:00:00+00:00

Sony held a new State of Play streaming event this September 2022 revealing new games and release dates. Let's talk.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:15 Tekken 8
2:11 Like A Dragon Ishin
3:54 Star Wars Tales of The Galaxy Enhanced Edtition
5:07 Pacific Drive
6:23 Exclusive Hogwarts Legacy Quest
7:06 Playstation Stars
8:09 Synduality
9:16 God of War Ragnarok Controller
10:22 Stellar Blade
11:43 Rise of the Ronin


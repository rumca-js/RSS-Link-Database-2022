# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## Arista rolls out new routing capabilities for cloud-first companies
 - [https://www.zdnet.com/home-and-office/networking/arista-rolls-out-new-routing-capabilities-for-cloud-first-companies/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/networking/arista-rolls-out-new-routing-capabilities-for-cloud-first-companies/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 23:03:51+00:00

New cloud routing protocols combine functions across cloud, carrier, and enterprise networks.

## One bad experience is all it takes to lose a customer
 - [https://www.zdnet.com/article/one-bad-experience-is-all-it-takes-to-lose-a-customer/#ftag=RSSbaffb68](https://www.zdnet.com/article/one-bad-experience-is-all-it-takes-to-lose-a-customer/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 22:28:15+00:00

Companies that embrace a "whole office" product strategy will break down organizational barriers and create compelling customer experiences, according to research on how consumers define brand loyalty in today's digital-first economy.

## AirPods deal: Apple AirPods Max are $120 off on Amazon
 - [https://www.zdnet.com/article/apple-airpods-max-deal-coupon-promo-code-sale/#ftag=RSSbaffb68](https://www.zdnet.com/article/apple-airpods-max-deal-coupon-promo-code-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 22:07:00+00:00

Want to pair your latest iPhone with new Apple AirPods Max headphones? This is the lowest price we've seen since the start of summer.

## Gaming monitor deal: Samsung Odyssey Neo G9 is $500 off
 - [https://www.zdnet.com/home-and-office/home-entertainment/samsung-odyssey-neo-g9-gaming-monitor-deal-coupon-promo-code-sale/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/samsung-odyssey-neo-g9-gaming-monitor-deal-coupon-promo-code-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 22:03:37+00:00

Samsung's Odyssey Neo G9 gaming monitor is gorgeous, and it's on sale right now. You can save $500 on it right now, thanks to Discover Samsung week.

## Watch a robot excavator controlled like a videogame
 - [https://www.zdnet.com/article/watch-robot-excavator-controlled-like-a-videogame/#ftag=RSSbaffb68](https://www.zdnet.com/article/watch-robot-excavator-controlled-like-a-videogame/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 21:16:09+00:00

I could watch this robot excavator dig all day. Remote control could also make excavation safer and more economical.

## Is this the ultimate Windows docking station? Meet the Accell Thunderbolt 4
 - [https://www.zdnet.com/home-and-office/smart-office/accell-thunderbolt-4-docking-station-extreme-convenience-but-best-for-windows-users/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-office/accell-thunderbolt-4-docking-station-extreme-convenience-but-best-for-windows-users/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 20:54:00+00:00

The convenience provided by this tiny desktop companion is hard to overstate. It's great for Macs, too, except for one thing.

## How Cockpit can help you more easily manage your Linux machines
 - [https://www.zdnet.com/article/how-cockpit-can-help-you-more-easily-manage-your-linux-machines/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-cockpit-can-help-you-more-easily-manage-your-linux-machines/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 20:48:01+00:00

This Linux web-based GUI helps make admin tasks a breeze.

## How to switch to a Prime Student membership
 - [https://www.zdnet.com/article/how-to-switch-to-a-prime-student-membership/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-switch-to-a-prime-student-membership/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 20:43:00+00:00

If you're a student wanting to save money during the school year, here are the steps to switch an Amazon Prime membership to the Student version.

## OpenWallet seeks to open-source your digital wallet
 - [https://www.zdnet.com/finance/openwallet-seeks-to-open-source-your-digital-wallet/#ftag=RSSbaffb68](https://www.zdnet.com/finance/openwallet-seeks-to-open-source-your-digital-wallet/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 20:33:13+00:00

Do you use a digital wallet? Would you like to use only one wallet instead of several of them? Then, the newly launched OpenWallet Foundation deserves your attention.

## How to use Adobe Lightroom: Everything beginners should know
 - [https://www.zdnet.com/education/how-to-use-adobe-lightroom-everything-beginners-should-know/#ftag=RSSbaffb68](https://www.zdnet.com/education/how-to-use-adobe-lightroom-everything-beginners-should-know/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 20:14:01+00:00

Are you wondering how to fix an under-exposed image or blur the background in a street shoot? ZDNET has you covered.

## Linus Torvalds talks Rust on Linux, his work schedule, and life with his M2 MacBook Air
 - [https://www.zdnet.com/article/linus-torvalds-talks-rust-on-linux-his-work-schedule-and-life-with-his-m2-macbook-air/#ftag=RSSbaffb68](https://www.zdnet.com/article/linus-torvalds-talks-rust-on-linux-his-work-schedule-and-life-with-his-m2-macbook-air/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 20:02:15+00:00

At the 2022 Linux Plumbers Conference, Torvalds and I have a chance to sit down and talk again about life, Linux, and scuba diving.

## Sony WH-1000XM5 deal: Save $146 on the wireless headphones
 - [https://www.zdnet.com/article/sony-wh-1000xm5-wireless-headphones-deal-promo-code-coupon/#ftag=RSSbaffb68](https://www.zdnet.com/article/sony-wh-1000xm5-wireless-headphones-deal-promo-code-coupon/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 19:08:00+00:00

One of the best noise canceling headphones can be yours for only $253 if you're open to ordering a certified refurbished pair.

## How to rename your Android phone for easier Bluetooth management
 - [https://www.zdnet.com/article/how-to-rename-your-android-phone-for-easier-bluetooth-management/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-rename-your-android-phone-for-easier-bluetooth-management/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 19:07:00+00:00

Jack Wallen shows you how you can remove some possible confusion with Bluetooth on Android by renaming your device.

## Looking for wireless gaming earbuds? The EPOS GTW 270 are next level
 - [https://www.zdnet.com/home-and-office/home-entertainment/epos-gtw-270-review/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/epos-gtw-270-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 17:55:00+00:00

Review: The hybrid design of Bluetooth and 2.4Ghz pairing make this one of the most pleasant earbuds I've ever tested.

## How to change Siri's voice
 - [https://www.zdnet.com/article/how-to-change-siris-voice/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-change-siris-voice/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 16:35:34+00:00

Siri can be a roadblock in your to-do list, or your go-to, depending on how you use it. But changing its voice can make the voice assistant more inclusive and, let's admit it, more fun.

## The HomePod mini is for Sirious Apple users only
 - [https://www.zdnet.com/home-and-office/smart-home/homepod-mini-review/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/homepod-mini-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 15:48:00+00:00

Review: The death of the HomePod gave way to the success of the HomePod mini -- a must for an Apple ecosystem smart home, but just a cute, overpriced speaker for anyone else.

## Save up to $1,500 on a Samsung 85-inch 8K smart TV
 - [https://www.zdnet.com/home-and-office/samsung-8k-smart-tv-deal-coupon-promo-code-sale/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/samsung-8k-smart-tv-deal-coupon-promo-code-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 13:51:00+00:00

If you're in the market for a massive, future-proof TV with beautiful, crisp picture and an Infinity Screen, this is the deal for you.

## The best GoPro accessory? It's not what you'd think
 - [https://www.zdnet.com/home-and-office/the-best-gopro-accessory-its-not-what-youd-think/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/the-best-gopro-accessory-its-not-what-youd-think/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 13:19:00+00:00

No, it's not a gimbal or lights or a different lens. It's a replacement battery door. But it has a super handy feature.

## Save up to $1,500 on a new Samsung 85" 8K smart TV
 - [https://www.zdnet.com/home-and-office/save-on-a-new-samsung-8k-smart-tv/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/save-on-a-new-samsung-8k-smart-tv/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 13:11:08+00:00

If you're in the market for a massive, future-proof TV, this might be the deal for you.

## The future of the web will need a different sort of software developer
 - [https://www.zdnet.com/article/the-future-of-the-web-will-need-a-different-sort-of-software-developer/#ftag=RSSbaffb68](https://www.zdnet.com/article/the-future-of-the-web-will-need-a-different-sort-of-software-developer/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 13:04:00+00:00

Web3, ambient computing and the Metaverse all sound exciting, but they will be matched by changes to what developers do, too.

## GoPro HERO11 Black first look: The world's best action camera gets even better
 - [https://www.zdnet.com/home-and-office/first-look-at-the-gopro-hero11-black/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/first-look-at-the-gopro-hero11-black/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 13:01:48+00:00

GoPro released three new cameras in the HERO11 Black line today.

## Microsoft expands its Azure Space satellite-connectivity options
 - [https://www.zdnet.com/article/microsoft-expands-its-azure-space-satellite-connectivity-options/#ftag=RSSbaffb68](https://www.zdnet.com/article/microsoft-expands-its-azure-space-satellite-connectivity-options/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 12:22:29+00:00

Microsoft is continuing its push to bring the Azure cloud to space to address the needs of satellite vendors and enterprise customers, both.

## Exhausted by software updates? These Microsoft apps can now update even when your PC is locked
 - [https://www.zdnet.com/article/exhausted-by-software-updates-these-microsoft-apps-can-now-update-even-when-your-pc-is-locked/#ftag=RSSbaffb68](https://www.zdnet.com/article/exhausted-by-software-updates-these-microsoft-apps-can-now-update-even-when-your-pc-is-locked/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 11:00:00+00:00

Microsoft streamlines app updates to minimize disruptions for users and cut down on update notifications.

## NASA says space junk is one of the great challenges of our time. Here's why
 - [https://www.zdnet.com/article/nasa-says-space-junk-is-one-of-the-great-challenges-of-our-time-heres-why/#ftag=RSSbaffb68](https://www.zdnet.com/article/nasa-says-space-junk-is-one-of-the-great-challenges-of-our-time-heres-why/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 10:30:00+00:00

As low-Earth orbit gets crowded, NASA takes the threat of orbital debris seriously.

## Logitech's new Brio 500 webcam is smarter and cheaper than the competition
 - [https://www.zdnet.com/article/logitechs-new-brio-500-webcam-is-smarter-and-cheaper-than-the-competition/#ftag=RSSbaffb68](https://www.zdnet.com/article/logitechs-new-brio-500-webcam-is-smarter-and-cheaper-than-the-competition/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 07:01:00+00:00

Autoframing via an ultra-wide lens, Show Mode for top-down demos, and a $129 price tag, just in time for the hybrid era of work.

## Logitech's new Brio 505 webcam is smarter and cheaper than the competition
 - [https://www.zdnet.com/article/logitechs-new-brio-505-webcam-is-smarter-and-cheaper-than-the-competition/#ftag=RSSbaffb68](https://www.zdnet.com/article/logitechs-new-brio-505-webcam-is-smarter-and-cheaper-than-the-competition/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 07:01:00+00:00

Autoframing via an ultra-wide lens, Show Mode for top-down demos, and a $129 price tag, just in time for the hybrid era of work.

## Canva Docs gives you an easy way to add more visuals to your documents
 - [https://www.zdnet.com/article/canva-docs-gives-you-an-easy-way-to-add-more-visuals-to-your-documents/#ftag=RSSbaffb68](https://www.zdnet.com/article/canva-docs-gives-you-an-easy-way-to-add-more-visuals-to-your-documents/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-09-14 05:00:02+00:00

Canva is already a popular design platform. Its newest product is competing with ubiquitous workplace programs like Microsoft Word and Google Docs.


# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Inikep - Bi-Location (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=IJwqP2u6lbY](https://www.youtube.com/watch?v=IJwqP2u6lbY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-09-15 00:00:00+00:00

"Bi-Location" by Inikep/Suspend, 9th at Rush Hours 1998. Art "Train to Nowhere" by Slayer/Ghostown, 4th at Revision 2012.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 24 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga Paula does XM: Skyrunner - Curryqueen (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=f7ROK7JxYds](https://www.youtube.com/watch?v=f7ROK7JxYds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-09-15 00:00:00+00:00

"Curryqueen" by Skyrunner/Brain Control (Frank Scheffel), 2nd at Revision 2016. C64 art from "Recollection #2" diskmag (2006) by Mirage/Focus.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 32 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.


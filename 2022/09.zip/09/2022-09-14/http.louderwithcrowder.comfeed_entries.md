# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## 'They know they're liars': Crowder discusses the globalist radical left with Alex Jones
 - [https://www.louderwithcrowder.com/alex-jones-globalist-radical-left](https://www.louderwithcrowder.com/alex-jones-globalist-radical-left)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 21:02:18+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31711280&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p><em>"The Democratic Party is cancer."</em></p><p>Alex Jones comes in, guns a-blazin'! I think we can all agree with that little tidbit, though. There's nothing good coming out of the Democratic Party. The policies being pushed in places like <a href="https://www.louderwithcrowder.com/california-electric-vehicles" target="_blank">California<

## 'I'll kick your a**': Cashier is ready to fight bear as it repeatedly steals snacks from store, or die trying
 - [https://www.louderwithcrowder.com/bear-steals-snacks-7-eleven](https://www.louderwithcrowder.com/bear-steals-snacks-7-eleven)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 19:58:14+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31709580&amp;width=1245&amp;height=700&amp;coordinates=0%2C59%2C0%2C59" /><br /><br /><p>California is ground zero for petty theft.<a href="https://www.louderwithcrowder.com/flash-mob-los-angeles" target="_blank"> It happens all the time</a>. It happens so often, it would seem even the wildlife has discovered how easy it is to get away with taking whatever you want. At least one black bear seems to have learned this, and it d

## Put this Democrat rant attacking angry parents as 'MAGA Republican' insurrectionists in every GOP ad
 - [https://www.louderwithcrowder.com/hank-johnson-school-board-maga](https://www.louderwithcrowder.com/hank-johnson-school-board-maga)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 19:56:04+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31708755&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C196" /><br /><br /><p>Add me to the chorus of conservatives saying that if this Rep. Hank Johnson (D-Guam) clip isn't made into an ad and aired in every suburb in America, the GOP deserves to lose.</p><p>If you're keeping score at home, the "MAGA Republicans" Joe Biden calls a <a href="https://www.louderwithcrowder.com/desantis-responds-biden-speech" target="_

## Enjoy the latest in body positivity: Don't shame donuts, but blame white people for your fatness
 - [https://www.louderwithcrowder.com/body-positivity-donuts-spices](https://www.louderwithcrowder.com/body-positivity-donuts-spices)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 18:28:07+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31706061&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>I regret to inform you that the progressive fatties are it again. It's not enough to celebrate bad decisions. Now they're being proactive in saying there is no such thing as a bad decision. YOU'RE the one at fault for calling something a bad decision. Also, because your ancestors are white. Welcome to today's additions to the <a href="htt

## Police investigating after video of white kid brutally beaten in school bathroom goes viral
 - [https://www.louderwithcrowder.com/boy-beaten-at-school](https://www.louderwithcrowder.com/boy-beaten-at-school)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 16:47:07+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31704636&amp;width=1245&amp;height=700&amp;coordinates=0%2C59%2C0%2C59" /><br /><br /><p>There are numerous problems leading to the decline of Western civilization. One of those problems is the inability of parents to raise their children with any semblance of morals. Secular, leftist education doesn't help that issue, either. So, forgive me if I'm not surprised when <a href="https://www.louderwithcrowder.com/chair-middle-sch

## 'How are they allowing this?' Patreon fires entire security team to protect 'Minor Attracted Persons'
 - [https://www.louderwithcrowder.com/patreon-fires-entire-security-team](https://www.louderwithcrowder.com/patreon-fires-entire-security-team)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 15:36:36+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31704486&amp;width=1245&amp;height=700&amp;coordinates=0%2C59%2C0%2C59" /><br /><br /><p>First--and it pains me to do this--but I have to give a shoutout to the feminist site <a href="https://reduxx.info/patreon-fires-security-staff-amid-allegations-of-protecting-maps/" target="_blank">Reduxx </a>for this story. A former member of the Patreon security team posted to<a href="https://www.linkedin.com/feed/update/urn:li:activity

## Elon Musk helps spread rumor that chess grandmaster cheated his way to victory with wireless anal beads
 - [https://www.louderwithcrowder.com/chess-grandmaster-beads-elon](https://www.louderwithcrowder.com/chess-grandmaster-beads-elon)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 15:34:38+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31704330&amp;width=1245&amp;height=700&amp;coordinates=0%2C59%2C0%2C59" /><br /><br /><p>There's a rumor going around that a new grand Chessmaster cheated by sticking wireless anal beads up his hiney hole. For context's sake, this is a rumor being presented without evidence. But it's a rumor that was helped to spread by <a href="https://www.louderwithcrowder.com/search/?q=elon+musk" target="_blank">Elon Musk</a>. Because for 

## Alex Jones TELLS ALL: His Lawsuit, the Great Reset & Cover-ups
 - [https://www.louderwithcrowder.com/alex-jones-breaks-silence](https://www.louderwithcrowder.com/alex-jones-breaks-silence)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 14:41:47+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31704164&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C1" /><br /><br /><p>Alex Jones is in the studio for a long-form conversation and cigars. The elites are out to censor and silence him. He talks about all of it and exactly why his story should scare the hell out of everyone.</p>
<p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<

## Latino cop being labeled as 'racist' for only arresting Latino drug dealers, and he could get fired
 - [https://www.louderwithcrowder.com/latino-cop-san-francisco-fired](https://www.louderwithcrowder.com/latino-cop-san-francisco-fired)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 14:30:44+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31704024&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>Sgt. Daniel Solorzano has fourteen years on the job, twelve of which were spent in the Hispanic San Franciso district of Tenderloin. The Mexican and Nicaraguan officer, whose first language is Spanish, is being accused of racially profiling because all of the drug dealers he arrests in this Hispanic district are Hispanic.</p><p>Or they ma

## Brit Journalist savages Americans mocking the Queen, invokes Joe Biden and George Floyd to do so
 - [https://www.louderwithcrowder.com/queen-brit-journalist-mock](https://www.louderwithcrowder.com/queen-brit-journalist-mock)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 13:48:59+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31703874&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C124" /><br /><br /><p>America broke up with England for a reason, and we are never, ever, ever getting back together. But I hate to admit it, these shots from British journalist <a href="https://www.louderwithcrowder.com/lockdown-mask-mandate-young-generation" target="_blank">Sophie Corcoran</a> are begrudgingly fair. I'm not someone who has strong opinions ab

## 'It’s f***ed up': Jake Paul DROPS BOMBS about Big Tech working with White House to censor Americans
 - [https://www.louderwithcrowder.com/jake-paul-free-speech](https://www.louderwithcrowder.com/jake-paul-free-speech)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 13:02:58+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31703655&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>Jake Paul is dominating the boxing industry just like his brother Logan Paul is dominating sports entertainment. But Jake has also been more and more outspoken about politics. Maybe he grew a little based when he was accused of being racist for *checks notes* <a href="https://www.louderwithcrowder.com/racist-jake-paul-boxing" target="_bla

## Middle school students create 'pedo database' to track creepy teacher and the teacher was just put on leave
 - [https://www.louderwithcrowder.com/middle-school-students-create-database](https://www.louderwithcrowder.com/middle-school-students-create-database)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-14 12:25:19+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31703443&amp;width=1245&amp;height=700&amp;coordinates=0%2C59%2C0%2C59" /><br /><br /><p>Chivalry is not dead and a Rhode Island middle school teacher is put on leave thanks to a student-created "<a href="https://www.louderwithcrowder.com/teacher-hawaii-arrested" target="_blank">pedo</a> database" tracking him creeping on twelve-year-old girls. </p><p>Starting in sixth grade, <a href="https://news.yahoo.com/rhode-island-teach


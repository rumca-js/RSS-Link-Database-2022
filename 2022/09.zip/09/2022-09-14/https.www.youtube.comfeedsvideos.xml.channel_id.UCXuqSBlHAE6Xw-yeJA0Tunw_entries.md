# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The Prepper PC
 - [https://www.youtube.com/watch?v=nFDBxBUfE74](https://www.youtube.com/watch?v=nFDBxBUfE74)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-09-15 00:00:00+00:00

Thanks to Jackery for sponsoring today's video! Check out Jackery's Solar Generator 2000 Pro and get 10% off with code LinusTechTips at https://lmg.gg/SG2000PROLTT

These days, you can game almost anywhere on the planet, anytime. But what if that planet was in the middle of an apocalypse? After you’ve stashed years of food, water, and toilet paper away, how will you pass the time? With this PC, you can be prepared to game until the whole mess to sort itself out. 

Discuss on the forum: https://linustechtips.com/topic/1455447-the-prepper-pc-sponsored/

Buy a Jackery Solar Generator 2000 Pro: https://geni.us/034L

Buy a Jackery Explorer 2000 Pro: https://lmg.gg/1dyF4

Buy a Seasonic Fanless TX: https://geni.us/S0Wt76G

Buy an Intel Core i3 (12th Gen) i3-12100: https://geni.us/hLZvxa

Buy an RTX 3050: https://geni.us/6A6hl

Buy an RX 6500XT: https://geni.us/fUF1p

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:42 The PC Built for Super Efficiency
2:41 Our BURIAL ENCLOSURE?!
3:31 Our Power Solution (Thanks Jackery!)
4:47 Diggin' Holes
5:30 Colonoscopy?
7:04 Diggin' like a man
8:29 The world's worst woodsman
9:03 Backyard cable management
10:02 Time to bury this boy
10:46 Solar Power Generation
11:37 Issues
12:08 First Play Test
13:20 Conclusion

## This Is So Embarrassing! - Building a PC with My Sister
 - [https://www.youtube.com/watch?v=AOdp09SYhCc](https://www.youtube.com/watch?v=AOdp09SYhCc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-09-14 00:00:00+00:00

Check out Corsair's new K70 Pro Mini Wireless Keyboard at https://lmg.gg/K70ProMiniLTT

Save 10% and Free Worldwide Shipping at Ridge Wallet by using offer code LINUS at https://www.ridge.com/LINUS

Linus' sister is playing The Sims 4 on an old Macbook. He'd like to change that and see if she can be converted to the glorious ways of the mighty PC, but it comes at the cost of some embarrassing childhood stories.

Discuss on the forum: https://linustechtips.com/topic/1455257-this-is-so-embarrassing/

Buy an RTX 3060 Ti: https://geni.us/AnUl0L

Buy an MSI Pro Z690 A WiFi: https://geni.us/Cqmdts

Buy a Core i5 12400: https://geni.us/7Mn6

Buy a Crucial P5+ 1TB: https://geni.us/VuMHnuG

Buy a G.Skill Ripjaws V 2x8GB 3600MHz CL18: https://geni.us/200UOC

Buy a Noctua NH U12S: https://geni.us/tWdjLS

Buy Fractal Pop Air: https://geni.us/cH9T9

Buy a RM750X Gold: https://geni.us/Y9HOh

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:02 The Deal
2:05 Stories
4:30 Motherboard
5:25 CPU
7:22 More Stories
10:05 Linus the Troublemaker
12:34 GPU
14:00 Boot
14:55 Conclusion
17:33 Outro


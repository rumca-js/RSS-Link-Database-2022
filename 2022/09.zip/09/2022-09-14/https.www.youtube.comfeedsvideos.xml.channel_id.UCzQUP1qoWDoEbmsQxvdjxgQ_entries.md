# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Jon Peters on Becoming Barbara Streisand's Hairdresser, Having a Bullet in His Chest
 - [https://www.youtube.com/watch?v=nf2zqYUAOwg](https://www.youtube.com/watch?v=nf2zqYUAOwg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-09-15 00:00:00+00:00

Taken from JRE #1871 w/Jon Peters:
https://open.spotify.com/episode/4m03MPlUulKnSScfQbfgZt?si=8df2a2d76d4b4b28

## Jon Peters on Producing Batman, Casting Michael Keaton, and Jack Nicholson
 - [https://www.youtube.com/watch?v=J17H6X5tBwQ](https://www.youtube.com/watch?v=J17H6X5tBwQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-09-15 00:00:00+00:00

Taken from JRE #1871 w/Jon Peters:
https://open.spotify.com/episode/4m03MPlUulKnSScfQbfgZt?si=8df2a2d76d4b4b28

## Legendary Film Producer Jon Peters on Meeting Elvis and Michael Jackson
 - [https://www.youtube.com/watch?v=W637AJp3mNU](https://www.youtube.com/watch?v=W637AJp3mNU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-09-15 00:00:00+00:00

Taken from JRE #1871 w/Jon Peters:
https://open.spotify.com/episode/4m03MPlUulKnSScfQbfgZt?si=8df2a2d76d4b4b28

## Max Lugavere on Controversial Alzheimer's Drugs and Studies
 - [https://www.youtube.com/watch?v=hR2vPB5b20Y](https://www.youtube.com/watch?v=hR2vPB5b20Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-09-14 00:00:00+00:00

Taken from JRE #1870 w/Max Lugavere:
https://open.spotify.com/episode/7fkDRpWn7bVWDDsDaOEy5y?si=f623c319b9494d57


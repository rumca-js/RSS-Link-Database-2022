# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Ka Lia Universe – Losin' U, Losin' Me (live for The Current)
 - [https://www.youtube.com/watch?v=WKF17iiJV3c](https://www.youtube.com/watch?v=WKF17iiJV3c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-09-15 00:00:00+00:00

Ka Lia Universe performed at the MPR Booth at the 2022 Minnesota State Fair. The Hmong-American pop singer is from St Paul and put on a lively set for fairgoers on a bright, sunny day. Watch Ka Lia Universe's performance of "Losin' U, Losin' Me," recorded live at the State Fair. 

Host – Diane
Guests – Ka Lia Universe
Producer – Tom Campbell
Camera Operators – Evan Clark and Tom Campbell
Audio – Eric Xu Romani

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

This activity is made possible in part by the Minnesota Legacy Amendment's Arts & Cultural Heritage Fund.

#kaliauniverse #losingulosingme #mnstatefair

## Ka Lia Universe – Dej Txias Cold Water (live for The Current)
 - [https://www.youtube.com/watch?v=NQBybn3gijI](https://www.youtube.com/watch?v=NQBybn3gijI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-09-14 00:00:00+00:00

Ka Lia Universe performed at the MPR Booth at the 2022 Minnesota State Fair. The Hmong-American pop singer is from St Paul and put on a lively set for fairgoers on a bright, sunny day. Watch Ka Lia Universe's performance of "Dej Txias Cold Water," recorded live at the State Fair. 

Host – Diane
Guests – Ka Lia Universe
Producer – Tom Campbell
Camera Operators – Evan Clark and Tom Campbell
Audio – Eric Xu Romani

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

This activity is made possible in part by the Minnesota Legacy Amendment's Arts & Cultural Heritage Fund.

#kaliauniverse #losingulosingme #dejtxias #fairytale #hmongamerican #hmong #popmusic #stpaulmusic #mnstatefair


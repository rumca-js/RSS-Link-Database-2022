# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Ceny węgla biją rekordy: Za tonę nawet 7 tys. zł. Polacy znaleźli sposób, jak kupić taniej
 - [https://wydarzenia.interia.pl/kraj/news-ceny-wegla-bija-rekordy-za-tone-nawet-7-tys-zl-polacy-znalez,nId,6285243](https://wydarzenia.interia.pl/kraj/news-ceny-wegla-bija-rekordy-za-tone-nawet-7-tys-zl-polacy-znalez,nId,6285243)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-09-14 09:27:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ceny-wegla-bija-rekordy-za-tone-nawet-7-tys-zl-polacy-znalez,nId,6285243"><img align="left" alt="Ceny węgla biją rekordy: Za tonę nawet 7 tys. zł. Polacy znaleźli sposób, jak kupić taniej" src="https://i.iplsc.com/ceny-wegla-bija-rekordy-za-tone-nawet-7-tys-zl-polacy-znalez/000G0PCQYS45EKPT-C321.jpg" /></a>Polska Grupa Górnicza po niespełna miesiącu od ostatnich podwyżek cen węgla ogłosiła kolejny wzrost. Tym razem za tonę surowca zapłacimy o o

## Nowe przepisy ruchu drogowego od 21 września. Duże zmiany dla pieszych: Pojawi się nowość
 - [https://wydarzenia.interia.pl/kraj/news-nowe-przepisy-ruchu-drogowego-od-21-wrzesnia-duze-zmiany-dla,nId,6283192](https://wydarzenia.interia.pl/kraj/news-nowe-przepisy-ruchu-drogowego-od-21-wrzesnia-duze-zmiany-dla,nId,6283192)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-09-14 09:09:35+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowe-przepisy-ruchu-drogowego-od-21-wrzesnia-duze-zmiany-dla,nId,6283192"><img align="left" alt="Nowe przepisy ruchu drogowego od 21 września. Duże zmiany dla pieszych: Pojawi się nowość  " src="https://i.iplsc.com/nowe-przepisy-ruchu-drogowego-od-21-wrzesnia-duze-zmiany-dla/000G2BV2VLCXNINO-C321.jpg" /></a>Nowe przepisy ruchu drogowego wchodzą w życie 21 września. W znowelizowanym prawie jest mowa o tak zwanych przejściach sugerowanych, czyli 

## Robert J. skazany za zamordowanie i oskórowanie studentki
 - [https://wydarzenia.interia.pl/malopolskie/news-robert-j-skazany-za-zamordowanie-i-oskorowanie-studentki,nId,6285095](https://wydarzenia.interia.pl/malopolskie/news-robert-j-skazany-za-zamordowanie-i-oskorowanie-studentki,nId,6285095)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-09-14 08:51:59+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-robert-j-skazany-za-zamordowanie-i-oskorowanie-studentki,nId,6285095"><img align="left" alt="Robert J. skazany za zamordowanie i oskórowanie studentki" src="https://i.iplsc.com/robert-j-skazany-za-zamordowanie-i-oskorowanie-studentki/000G2E5QUGN13EPD-C321.jpg" /></a>Robert J. został skazany na dożywocie za zamordowanie i oskórowanie krakowskiej studentki Katarzyny Z. Tak zdecydował Sąd Okręgowy w Krakowie. Uzasadnienie ustne wyroku będzi

## Fogiel krytykuje projekt PO ws. reparacji. Mówi o "rozmywaniu" tematu
 - [https://wydarzenia.interia.pl/kraj/news-fogiel-krytykuje-projekt-po-ws-reparacji-mowi-o-rozmywaniu-t,nId,6285165](https://wydarzenia.interia.pl/kraj/news-fogiel-krytykuje-projekt-po-ws-reparacji-mowi-o-rozmywaniu-t,nId,6285165)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-09-14 08:49:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-fogiel-krytykuje-projekt-po-ws-reparacji-mowi-o-rozmywaniu-t,nId,6285165"><img align="left" alt="Fogiel krytykuje projekt PO ws. reparacji. Mówi o &quot;rozmywaniu&quot; tematu" src="https://i.iplsc.com/fogiel-krytykuje-projekt-po-ws-reparacji-mowi-o-rozmywaniu-t/000G2EISU69R35J8-C321.jpg" /></a>Platforma Obywatelska złożyła w Sejmie projekt uchwały, w którym, podobnie jak PiS, domaga się reparacji od Niemiec. PO chce odszkodowania również od R

## Tygodniowy raport zakażeń koronawirusem. Ministerstwo Zdrowia podało dane
 - [https://wydarzenia.interia.pl/kraj/news-tygodniowy-raport-zakazen-koronawirusem-ministerstwo-zdrowia,nId,6285192](https://wydarzenia.interia.pl/kraj/news-tygodniowy-raport-zakazen-koronawirusem-ministerstwo-zdrowia,nId,6285192)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-09-14 08:34:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tygodniowy-raport-zakazen-koronawirusem-ministerstwo-zdrowia,nId,6285192"><img align="left" alt="Tygodniowy raport zakażeń koronawirusem. Ministerstwo Zdrowia podało dane" src="https://i.iplsc.com/tygodniowy-raport-zakazen-koronawirusem-ministerstwo-zdrowia/000G2EMQWD3EN6TQ-C321.jpg" /></a>Od 8 do 14 września odnotowano w Polsce 29 056 zakażeń koronawirusem. Zmarło 105 osób - poinformowało Ministerstwo Zdrowia w tygodniowym raporcie. W zeszłym 

## Jarosław Kaczyński w Sejmie: Wiedziałem, że tu jest agentura Putina
 - [https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-w-sejmie-wiedzialem-ze-tu-jest-agentura-p,nId,6285211](https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-w-sejmie-wiedzialem-ze-tu-jest-agentura-p,nId,6285211)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-09-14 08:30:16+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-w-sejmie-wiedzialem-ze-tu-jest-agentura-p,nId,6285211"><img align="left" alt="Jarosław Kaczyński w Sejmie: Wiedziałem, że tu jest agentura Putina" src="https://i.iplsc.com/jaroslaw-kaczynski-w-sejmie-wiedzialem-ze-tu-jest-agentura-p/000G2ESL35KD5MOK-C321.jpg" /></a>W Sejmie doszło do kolejnej awantury. Posłowie kłócili się o podkomisję smoleńską. Głos na sali obrad postanowił zabrać Jarosław Kaczyński. - Ja bardzo krótko. Wie

## Jaka będzie zima 2022/2023? Prognoza długoterminowa. Wiadomo, kiedy śnieg
 - [https://wydarzenia.interia.pl/kraj/news-jaka-bedzie-zima-2022-2023-prognoza-dlugoterminowa-wiadomo-k,nId,6285137](https://wydarzenia.interia.pl/kraj/news-jaka-bedzie-zima-2022-2023-prognoza-dlugoterminowa-wiadomo-k,nId,6285137)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-09-14 08:03:31+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jaka-bedzie-zima-2022-2023-prognoza-dlugoterminowa-wiadomo-k,nId,6285137"><img align="left" alt="Jaka będzie zima 2022/2023? Prognoza długoterminowa. Wiadomo, kiedy śnieg" src="https://i.iplsc.com/jaka-bedzie-zima-2022-2023-prognoza-dlugoterminowa-wiadomo-k/000G2ED1WVOQO83R-C321.jpg" /></a>Zima sroga czy raczej łagodna? Jaka pogoda czeka nas w nadchodzących miesiącach? Radosław Droździoł z Centrum Modelowania Meteorologicznego IMGW-PIB przedsta

## Norbert Kaczmarczyk komentuje dymisję: To polityczno-medialna intryga
 - [https://wydarzenia.interia.pl/kraj/news-norbert-kaczmarczyk-komentuje-dymisje-to-polityczno-medialna,nId,6285142](https://wydarzenia.interia.pl/kraj/news-norbert-kaczmarczyk-komentuje-dymisje-to-polityczno-medialna,nId,6285142)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-09-14 07:19:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-norbert-kaczmarczyk-komentuje-dymisje-to-polityczno-medialna,nId,6285142"><img align="left" alt="Norbert Kaczmarczyk komentuje dymisję: To polityczno-medialna intryga" src="https://i.iplsc.com/norbert-kaczmarczyk-komentuje-dymisje-to-polityczno-medialna/000G2ED2QIEEVAOL-C321.jpg" /></a>Były wiceminister rolnictwa Norbert Kaczmarczyk skomentował w mediach społecznościowych decyzję o jego odwołaniu. Polityk podkreślił, że  &quot;wszystko, co ma, 

## Ceny energii za wysokie dla łódzkiej Filmówki. Odwołano zajęcia w styczniu
 - [https://wydarzenia.interia.pl/lodzkie/news-ceny-energii-za-wysokie-dla-lodzkiej-filmowki-odwolano-zajec,nId,6285112](https://wydarzenia.interia.pl/lodzkie/news-ceny-energii-za-wysokie-dla-lodzkiej-filmowki-odwolano-zajec,nId,6285112)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-09-14 07:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-ceny-energii-za-wysokie-dla-lodzkiej-filmowki-odwolano-zajec,nId,6285112"><img align="left" alt="Ceny energii za wysokie dla łódzkiej Filmówki. Odwołano zajęcia w styczniu" src="https://i.iplsc.com/ceny-energii-za-wysokie-dla-lodzkiej-filmowki-odwolano-zajec/000G2E8LMNF8UKAQ-C321.jpg" /></a>Drastyczny wzrost cen za gaz i prąd bardzo uderza w polskie szkoły wyższe, które żeby przetrwać, będą musiały zdecydować się na poważne cięcia. Pierwsze 


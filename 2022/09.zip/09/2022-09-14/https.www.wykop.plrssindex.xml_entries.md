## Szpital otrzymał symulacje opłat za prąd. Mają wzrosnąć o 500%. Co dalej?
 - [https://www.wykop.pl/link/6816037/szpital-otrzymal-symulacje-oplat-za-prad-maja-wzrosnac-o-500-co-dalej/](https://www.wykop.pl/link/6816037/szpital-otrzymal-symulacje-oplat-za-prad-maja-wzrosnac-o-500-co-dalej/)
 - RSS feed: https://www.wykop.pl/rss/index.xml/
 - date published: 2022-09-14 09:43:02+00:00

<img src="https://www.wykop.pl/cdn/c3397993/link_16631259314xcWB0cAVkzNyudny17hXo,w104h74.jpg" /><br />
		 Nie tylko klienci indywidualni patrzą z trwogą w przyszłość. Także szpitale obawiają się prognozowanych faktur za energię elektryczną. Według tej, która dotarła do jednego z tarnowskich szpitali rachunki za prąd mają tam wzrosnąć o 500 proc.


# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Koronawirus. WHO: Najmniej przypadków zgonów z powodu COVID-19 od marca 2020 roku
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/koronawirus-who-najmniej-przypadkow-zgonow-z-powodu-covid-19-od-marca-2020-roku/](https://www.polsatnews.pl/wiadomosc/2022-09-14/koronawirus-who-najmniej-przypadkow-zgonow-z-powodu-covid-19-od-marca-2020-roku/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 19:51:00+00:00

Liczba zgonów spowodowanych COVID-19 w ostatnim tygodniu była najniższą od marca 2020 roku - wynika z danych Światowej Organizacji Zdrowia (WHO). To może oznaczać punkt zwrotny w trwającej pandemii koronawirusa.

## Wielka Brytania. Setki tysięcy osób w wielokilometrowej kolejce, by pożegnać Elżbietę II
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/wielka-brytania-setki-tysiecy-osob-w-wielokilometrowej-kolejce-by-pozegnac-elzbiete-ii/](https://www.polsatnews.pl/wiadomosc/2022-09-14/wielka-brytania-setki-tysiecy-osob-w-wielokilometrowej-kolejce-by-pozegnac-elzbiete-ii/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 19:33:00+00:00

Ponad czterokilometrowa kolejka utworzyła się w kierunku wejścia do Westminster Hall, gdzie wystawiono trumnę z ciałem Elżbiety II. Ci na końcu będą musieli poczekać ok. 30 godzin, by pożegnać królową. Poddani będą mogli składać hołd monarchini do poniedziałku. Tego dnia odbędzie się pogrzeb.

## Wielka Brytania. Sondaż poparcia dla króla Karola III
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/wielka-brytania-sondaz-poparcia-dla-krola-karola-iii/](https://www.polsatnews.pl/wiadomosc/2022-09-14/wielka-brytania-sondaz-poparcia-dla-krola-karola-iii/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 16:44:00+00:00

Prawie dwukrotny skok poparcia zaliczył po wstąpieniu na tron król Karol III - wynika z badania przeprowadzonego przez YouGov. The Sun podaje, że 94 proc. respondentów pozytywnie oceniło też pierwsze przemówienie nowego monarchy.

## USA: Nowa metoda uśmiercania więźniów. Adwokat skazanego walczy, by jej nie stosować
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/usa-nowa-metoda-usmiercania-wiezniow-adwokat-skazanego-walczy-by-jej-nie-stosowac/](https://www.polsatnews.pl/wiadomosc/2022-09-14/usa-nowa-metoda-usmiercania-wiezniow-adwokat-skazanego-walczy-by-jej-nie-stosowac/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 15:16:00+00:00

Alan Eugen Miller z amerykańskiego stanu Alabama to mężczyzna skazany na karę śmierci za potrójne morderstwo. Może być on pierwszą osobą straconą przy użyciu nowej metody - niedotlenienia w wyniku odessania tlenu i zwiększenia stężenia azotu w powietrzu. Adwokat nie zgadza się na to, aby jego klient był królikiem doświadczalnym.

## Białoruś. Aleksandr Łukaszenka rąbie drewno na nagraniu. "Nie pozwolimy Europie zamarznąć"
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/bialorus-aleksandr-lukaszenka-rabie-drewno-na-nagraniu-nie-pozwolimy-europie-zamarznac/](https://www.polsatnews.pl/wiadomosc/2022-09-14/bialorus-aleksandr-lukaszenka-rabie-drewno-na-nagraniu-nie-pozwolimy-europie-zamarznac/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 14:08:00+00:00

Białoruski reżim opublikował propagandowe nagranie, na którym Alaksandr Łukaszenka osobiście rąbie drewno. - Nie pozwolimy Europie zamarznąć. Pomożemy naszym braciom, może oni kiedyś pomogą nam - mówi polityk. Wspomina także polskiego prezydenta i premiera.

## Szefowa KE Ursula von der Leyen: Jesteśmy w stanie zastąpić ten gaz, który odciął Putin
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/szefowa-ke-ursula-von-der-leyen-jestesmy-w-stanie-zastapic-ten-gaz-ktory-odcial-putin/](https://www.polsatnews.pl/wiadomosc/2022-09-14/szefowa-ke-ursula-von-der-leyen-jestesmy-w-stanie-zastapic-ten-gaz-ktory-odcial-putin/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 13:13:00+00:00

Mamy wspólne magazyny gazu, których zapełnienie wynosi 84 proc. W ciągu ostatnich miesięcy mocno pracowaliśmy nad uniezależnieniem się od Rosji. Mamy innych, godnych zaufania dostawców i jesteśmy w stanie zastąpić ten gaz, który odciął Putin - powiedziała Ursula von der Leyen. Wspomniała również o warunkach wypłaty Polsce środków z KPO.

## Wielka Brytania. Kondukt z ciałem królowej Elżbiety II dotarł do Pałacu Westminsterskiego
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/wielka-brytania-kondukt-z-cialem-krolowej-elzbiety-ii-do-palacu-westminsterskiego/](https://www.polsatnews.pl/wiadomosc/2022-09-14/wielka-brytania-kondukt-z-cialem-krolowej-elzbiety-ii-do-palacu-westminsterskiego/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 13:05:00+00:00

W środę po godz. 16 do Pałacu Westminsterskiego dotarł kondukt z ciałem królowej Elżbiety II. Za trumną szli członkowie rodziny królewskiej na czele z Karolem III, a licznie zgromadzeni na ulicach londyńczycy żegnali zmarłą monarchinię.

## Rosja. Dmitrij Pieskow: Projekt gwarancji bezpieczeństwa Ukrainy jest zagrożeniem dla Rosji
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/rosja-dmitrij-pieskow-projekt-gwarancji-bezpieczenstwa-ukrainy-jest-zagrozeniem-dla-rosji/](https://www.polsatnews.pl/wiadomosc/2022-09-14/rosja-dmitrij-pieskow-projekt-gwarancji-bezpieczenstwa-ukrainy-jest-zagrozeniem-dla-rosji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 12:49:00+00:00

Przedstawiony przez Kijów projekt gwarancji bezpieczeństwa dla Ukrainy potwierdza, że niezbędne było rozpoczęcie operacji wojennej - przekazał rzecznik prasowy prezydenta Rosji Dmitrij Pieskow, cytowany przez prokremlowską agencję Ria Nowosti. Według rzecznika,wynikające z dokumentu konsekwencje są zagrożeniem dla Rosji.

## Wojna w Ukrainie. Reuters: Było porozumienie spełniające żądania Kremla. Rosja je odrzuciła
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/wojna-w-ukrainie-reuters-bylo-porozumienie-spelniajace-zadania-kremla-rosja-je-odrzucila/](https://www.polsatnews.pl/wiadomosc/2022-09-14/wojna-w-ukrainie-reuters-bylo-porozumienie-spelniajace-zadania-kremla-rosja-je-odrzucila/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 12:31:00+00:00

W pierwszych dniach wojny delegat Władimira Putina w Ukrainie przekazał rosyjskiemu przywódcy, że wypracował porozumienie z władzami w Kijowie, które zaspokaja żądania Rosji w sprawie rozszerzenia NATO. Putin miał je odrzucić i kontynuować specjalną operację - donosi w środę Reuters, powołując się na swoje źródła. Wysłannikiem na Ukrainę, miał być Dmitrij Kozak, z pochodzenia Ukrainiec.

## Bloomberg: UE planuje ograniczyć finansowanie Węgier
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/bloomberg-ue-planuje-ograniczyc-finansowanie-wegier/](https://www.polsatnews.pl/wiadomosc/2022-09-14/bloomberg-ue-planuje-ograniczyc-finansowanie-wegier/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 12:04:00+00:00

Organ wykonawczy Unii Europejskiej planuje zalecić ograniczenie finansowania administracji premiera Viktora Orbana w związku z obawami o powszechną korupcję w rządzie - przekazała agencja Bloomberg. Orban ma mieć maksymalnie trzy miesiące na wywiązanie się z obietnic o powstrzymaniu korupcji.

## Rosja. Propagandyści potwierdzają porażkę Rosji. "Głowy powinny leżeć na biurku Putina"
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/rosja-propagandysci-potwierdzaja-porazke-rosji-glowy-powinny-lezec-na-biurku-putina/](https://www.polsatnews.pl/wiadomosc/2022-09-14/rosja-propagandysci-potwierdzaja-porazke-rosji-glowy-powinny-lezec-na-biurku-putina/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 11:15:00+00:00

Rosyjscy eksperci w propagandowych programach telewizyjnych zaczęli przyznawać, że ich wojska ponoszą porażkę w Ukrainie. - Gdzie był nasz cholerny wywiad? Wszystkie głowy powinny leżeć na biurku Putina - mówił jeden z propagandystów Kremla. W rosyjskiej telewizji dyskutowano także na temat historii Ukrainy. - Każdy historyk Panu powie, że Ukraina nie istniała - mówił rosyjski analityk.

## Rosja. Nie żyje Władimir Sungorkin. Był redaktorem naczelnym prokremlowskiej gazety
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/rosja-nie-zyje-wladimir-sungorkin-byl-redaktorem-naczelnym-prokremlowskiej-gazety/](https://www.polsatnews.pl/wiadomosc/2022-09-14/rosja-nie-zyje-wladimir-sungorkin-byl-redaktorem-naczelnym-prokremlowskiej-gazety/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 10:32:00+00:00

Nie żyje Władimir Sungorkin. Redaktor naczelny Komsomolskiej Prawdy, nazywanej ulubioną gazetą Władimira Putina. W rosyjskich mediach pojawiają się jednak rozbieżności co do przyczyny śmierci.

## Kaukaz. Wymiana ognia na granicy Azerbejdżanu i Armenii
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/kaukaz-wymiana-ognia-na-granicy-azerbejdzanu-i-armenii/](https://www.polsatnews.pl/wiadomosc/2022-09-14/kaukaz-wymiana-ognia-na-granicy-azerbejdzanu-i-armenii/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 09:55:00+00:00

Co najmniej 49 armeńskich i 50 azerskich żołnierzy zginęło we wtorek w starciach na granicy pomiędzy państwami. Obie strony oskarżają się wzajemnie o prowokację i eskalację konfliktu.

## Ukraina. Wyzwolona Bałaklija. "Rosjanie pytali, gdzie mają uciekać"
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/ukraina-wyzwolona-balaklija-rosjanie-pytali-gdzie-maja-uciekac/](https://www.polsatnews.pl/wiadomosc/2022-09-14/ukraina-wyzwolona-balaklija-rosjanie-pytali-gdzie-maja-uciekac/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 09:44:00+00:00

Rosjanie po wejściu ukraińskiej armii, uciekali bardzo szybko, jak kot. Była tu jedna starsza pani, która w tym czasie uciekała przed ostrzałem, Rosjanie zatrzymali ją i pytali, dokąd mają uciekać (…) Oni nawet nie wiedzieli, gdzie mają uciekać - mówi mieszkaniec wyzwolonego miasta Bałaklija w rozmowie z dziennikarzami Ukraińskiej Prawy. Bałaklija została wyzwolona na początku września.

## "Mówili od lat, że Putin się nie zatrzyma". Szefowa KE: trzeba było wsłuchać się w głos m.in Polski
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/mowili-od-lat-ze-putin-sie-nie-zatrzyma-szefowa-ke-trzeba-bylo-wsluchac-sie-w-glos-m-in-polski/](https://www.polsatnews.pl/wiadomosc/2022-09-14/mowili-od-lat-ze-putin-sie-nie-zatrzyma-szefowa-ke-trzeba-bylo-wsluchac-sie-w-glos-m-in-polski/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 08:11:00+00:00

Trzeba było wsłuchać się w głosy wewnątrz UE, w Polsce, krajach bałtyckich, w całej Europie Środkowo-Wschodniej - powiedziała w środę szefowa Komisji Europejskiej Ursula von der Leyen podczas corocznego wystąpienia o stanie Unii Europejskiej. - Oni od lat nam mówili, że Putin się nie zatrzyma - dodała.

## Wojna w Ukrainie. Ukraina chwali polskie Kraby. "To najszybsze stworzenia"
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/wojna-w-ukrainie-ukraina-chwali-polskie-kraby-to-najszybsze-stworzenia/](https://www.polsatnews.pl/wiadomosc/2022-09-14/wojna-w-ukrainie-ukraina-chwali-polskie-kraby-to-najszybsze-stworzenia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 07:17:00+00:00

Wiedzieliście, że polskie Kraby to najszybsze stworzenia? Wystarczy spojrzeć, jak sprawnie poruszają się po wyzwolonej części obwodu charkowskiego! - napisało w mediach społecznościowych Ministerstwo Obrony Ukrainy. AHS Krab potrafią atakować z zaskoczenia i obezwładnić wroga. Są szybkie i niezawodne. Jak polskie samobieżne armatnohaubice pomagają w Ukrainie? Wyjaśniamy.

## Rosja: Dmitrij Miedwiediew o "prologu do III wojny światowej"
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/rosja-dmitrij-miedwiediew-o-prologu-do-iii-wojny-swiatowej/](https://www.polsatnews.pl/wiadomosc/2022-09-14/rosja-dmitrij-miedwiediew-o-prologu-do-iii-wojny-swiatowej/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 07:06:00+00:00

Kijowska klika przygotowała projekt gwarancji bezpieczeństwa, który w zasadzie jest prologiem do III wojny światowej. Nikt nie da gwarancji ukraińskim nazistom - napisał wiceprzewodniczący Rady Bezpieczeństwa Federacji Rosyjskiej, Dmitrij Miedwiediew. Jak dodał, zgodnie z kremlowską propagandą, dalsze przekazywanie broni Ukrainie doprowadzi do tego, że wojna przejdzie na inny etap.

## Wielka Brytania. Irytacja Karola III. Tym razem zezłościł się na pióro
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/wielka-brytania-irytacja-karola-iii-tym-razem-zezloscil-sie-na-pioro/](https://www.polsatnews.pl/wiadomosc/2022-09-14/wielka-brytania-irytacja-karola-iii-tym-razem-zezloscil-sie-na-pioro/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 05:54:00+00:00

- Nie znoszę tego cholerstwa - wściekał się Król Karol III podczas ceremonii złożenia podpisów w zamku Hillsborough w Irlandii Północnej. Odchodząc od stołu, nowy monarcha ze złością próbował zetrzeć z rąk atrament.

## Wojna w Ukrainie. W mieście Bałaklija odkryto salę tortur. "Elektrowstrząsy były najlżejsze"
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/wojna-w-ukrainie-w-miescie-balaklija-odkryto-sale-tortur-elektrowstrzasy-byly-najlzejsze/](https://www.polsatnews.pl/wiadomosc/2022-09-14/wojna-w-ukrainie-w-miescie-balaklija-odkryto-sale-tortur-elektrowstrzasy-byly-najlzejsze/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 05:23:00+00:00

Z relacji świadków wynika, że byli torturowani na różne sposoby. Nie będę opisywał wszystkich. Mogę powiedzieć tylko, że elektrowstrząsy były najlżejszą z nich - poinformował Serhij Bołwinow, szef policji niedawno odzyskanej przez ukraińskie siły zbrojne miejscowości w obwodzie charkowskim. Rosjanie mieli zorganizować tam salę tortur w piwnicach komisariatu.

## Wojna w Ukrainie. Ukraińskie media: Kreml chce negocjować. Prosi Kijów o rozmowy pokojowe
 - [https://www.polsatnews.pl/wiadomosc/2022-09-14/wojna-w-ukrainie-kreml-chce-negocjowac-prosi-kijow-o-rozmowy-pokojowe/](https://www.polsatnews.pl/wiadomosc/2022-09-14/wojna-w-ukrainie-kreml-chce-negocjowac-prosi-kijow-o-rozmowy-pokojowe/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-14 04:21:00+00:00

Rosyjscy urzędnicy zwrócili się do Ukrainy z propozycją wznowienia negocjacji. Na ten moment Kijów nie wyraził na to zgody - informuje ukraiński portal hromadske, powołując się na wypowiedź wicepremier Ukrainy Olgi Stefaniszyny. Polityk zdradziła też, kiedy Kijów przystanie na propozycję Kremla.


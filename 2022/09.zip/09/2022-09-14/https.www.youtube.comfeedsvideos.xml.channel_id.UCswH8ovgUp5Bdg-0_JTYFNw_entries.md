# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## You've Gotta Be F*cking Kidding Me
 - [https://www.youtube.com/watch?v=m_VxecAWFxA](https://www.youtube.com/watch?v=m_VxecAWFxA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-09-15 00:00:00+00:00

As it’s revealed that Democrats have spent $53 million to boost “far-right” GOP candidates – what’s with all the rhetoric about the dangers of MAGA extremists and Donald Trump? 
#joebiden #donaldtrump #democrats #maga 

References
https://nypost.com/2022/09/12/democrats-spend-53m-to-boost-far-right-gop-candidates/
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Oh F*ck, He's At It Again
 - [https://www.youtube.com/watch?v=mJ3IdmlD9Mw](https://www.youtube.com/watch?v=mJ3IdmlD9Mw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-09-14 00:00:00+00:00

As Bill Gates buys up yet more farmland, are we seeing the systematic transfer of land from farmers to oligarchs happening in real time? 
#billgates #farmers #farmland 

References
https://www.newsweek.com/bill-gates-north-dakota-land-purchase-sparks-questions-online-1722660
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


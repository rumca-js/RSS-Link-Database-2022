# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Nie za bardzo wiemy czym jest żyrafa...
 - [https://www.youtube.com/watch?v=1ShWZ1s9ZPE](https://www.youtube.com/watch?v=1ShWZ1s9ZPE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2022-09-15 00:00:00+00:00

📚 Kup moją najnowszą książkę ► https://siedem.alt.pl

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Żyrafa? A co to takiego?

===
Rozkład jazdy:

0:00 Przewracanie probówek
0:14 Ludzie lubią nazywać rzeczy
3:52 Typologiczne pułapki
5:08 Szkolna definicja nie działa
8:00 Gdzie jest koniec pierścienia?
9:25 Wincyj definicji
11:55 A teraz wchodzi żyrafa
13:38 Żyrafa to nie pies
15:28 Po co ten film?
17:22 Ale bioróżnorodność to ty szanuj!

===
Źródła (wybrane):

D. Futuyma - Ewolucja
M. D. Laplante - Superlative: The Biology of Extremes
M. Agaba i in. - Giraffe genome sequence reveals clues to its unique morphology and physiology
J. Fennessy i in. - Mitochondrial DNA analyses show that Zambia's South Luangwa Valley giraffe are genetically isolated
A. Petzold i in. - A comparative approach for species elimination based on multiple methods of multi-locus DNA analysis: A case study of genus Giraffe
J. Fennessy i in. - Multi-locus Analyses Reveal Four Giraffe Species
D. Brown I in. - Extensive population genetic structure in the giraffe
R. Coimbra i in. - Whole-genome analysis of giraffe supports four distinct species


# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## JANE FRYER meets the mourners who are braving the elements to pay their last respects to Her Majesty
 - [https://www.dailymail.co.uk/news/article-11213579/JANE-FRYER-meets-mourners-braving-elements-pay-respects-Majesty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213579/JANE-FRYER-meets-mourners-braving-elements-pay-respects-Majesty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 23:54:42+00:00

JANE FRYER: Tuesday's sad little queue waiting to see the Queen lying in state the evening before her coffin was brought to Westminster Hall has been transformed. Not just in size but in cheeriness.

## Lily van de Putte: Buxton crash victim's dad John calls for stricter P-plate laws
 - [https://www.dailymail.co.uk/news/article-11213087/Lily-van-Putte-Buxton-crash-victims-dad-John-calls-stricter-P-plate-laws.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213087/Lily-van-Putte-Buxton-crash-victims-dad-John-calls-stricter-P-plate-laws.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 23:49:39+00:00

The father of one of the Buxton crash victims plans to lobby the NSW government to enforce stronger laws governing P-plate drivers and harsher penalties for those who break the rules.

## Drama as guard FAINTS off the podium while holding vigil beside Queen's coffin in Westminster Hall
 - [https://www.dailymail.co.uk/news/article-11213613/Drama-guard-FAINTS-podium-holding-vigil-Queens-coffin-Westminster-Hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213613/Drama-guard-FAINTS-podium-holding-vigil-Queens-coffin-Westminster-Hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 23:46:24+00:00

Hundreds of thousands of mourners have been queuing to pay their final respects to the monarch following her death at Balmoral on Thursday.

## One Nation's Pauline Hanson goes after Greens deputy Mehreen Faruqi again over Queen tweet
 - [https://www.dailymail.co.uk/news/article-11213529/One-Nations-Pauline-Hanson-goes-Greens-deputy-Mehreen-Faruqi-Queen-tweet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213529/One-Nations-Pauline-Hanson-goes-Greens-deputy-Mehreen-Faruqi-Queen-tweet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 23:44:16+00:00

One Nation leader Pauline Hanson took offence to Pakistani-born Greens deputy leader Mehreen  Faruqi tweeting that she would not mourn the death of The Queen because or her 'racist empire'.

## Australia's dumbest criminal? Thief crashes his $250,000 stolen car into cop wagon in Victoria
 - [https://www.dailymail.co.uk/news/article-11213405/Australias-dumbest-criminal-Thief-crashes-250-000-stolen-car-cop-wagon-Victoria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213405/Australias-dumbest-criminal-Thief-crashes-250-000-stolen-car-cop-wagon-Victoria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 23:40:05+00:00

A 20-year-old man has become a serious contender for Australia's dumbest criminal after allegedly stealing a $250,000 car and then crashing into a police vehicle.

## Becki Townsend Gun killed by a train near Clarence Park Train Station in Black Forest, Adelaide
 - [https://www.dailymail.co.uk/news/article-11213205/Becki-Townsend-Gun-killed-train-near-Clarence-Park-Train-Station-Black-Forest-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213205/Becki-Townsend-Gun-killed-train-near-Clarence-Park-Train-Station-Black-Forest-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 23:39:33+00:00

63-year-old retiree Becki Townsend Gun has been identified as the victim of an Adelaide train collision. Ms Townsend Gun was struck and killed by a train on Tuesday while trying to rescue her beloved dog.

## Every facet of humanity flocks to experience magic minutes at Queen's casket, writes ROBERT HARDMAN
 - [https://www.dailymail.co.uk/news/article-11213455/Every-facet-humanity-flocks-experience-magic-minutes-Queens-casket-writes-ROBERT-HARDMAN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213455/Every-facet-humanity-flocks-experience-magic-minutes-Queens-casket-writes-ROBERT-HARDMAN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 23:37:59+00:00

ROBERT HARDMAN: Majesty. No other word does justice to the spellbinding sight which awaits those lucky enough to reach the end of what will be one of the longest queues in living memory.

## Harry and Meghan 'angry as it emerges Archie and Lilibet will not get HRH titles'
 - [https://www.dailymail.co.uk/news/article-11213369/Harry-Meghan-angry-emerges-Archie-Lilibet-not-HRH-titles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213369/Harry-Meghan-angry-emerges-Archie-Lilibet-not-HRH-titles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 23:29:45+00:00

Archie, three, and Lilibet, one, are expected to be officially made prince and princess in the near future as Charles has agreed to issue a Letters Patent to grant the titles.

## Royal Family wants 'minimum disruption' to public life for Queen's funeral, source says
 - [https://www.dailymail.co.uk/news/article-11213451/Royal-Family-wants-minimum-disruption-public-life-Queens-funeral-source-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213451/Royal-Family-wants-minimum-disruption-public-life-Queens-funeral-source-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 23:29:13+00:00

King Charles and the Royal Family want there to be 'minimum disruption' for the public on the day of the Queen's funeral, a source has told the Daily Mail.

## MPs join growing demands for Queen's funeral route to be made longer so more people can pay respects
 - [https://www.dailymail.co.uk/news/article-11213515/MPs-join-growing-demands-Queens-funeral-route-longer-people-pay-respects.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213515/MPs-join-growing-demands-Queens-funeral-route-longer-people-pay-respects.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 23:27:52+00:00

Calls are growing for the Queen's funeral route from Westminster Abbey on Monday to be lengthened so that many more people can pay their final respects on Monday as senior MPs joined in the calls.

## Police deal 'devastating blow' to Kinahan cartel after arrest of one of their seven 'key members'
 - [https://www.dailymail.co.uk/news/article-11213103/Police-deal-devastating-blow-Kinahan-cartel-arrest-one-seven-key-members.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213103/Police-deal-devastating-blow-Kinahan-cartel-arrest-one-seven-key-members.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 23:01:46+00:00

Detectives from police forces including the Spanish Civil Guard, Garda and US DEA law enforcement agency participated in the operation which snared Johnny Morrissey.

## President Zelensky in Kyiv car crash - 'not seriously hurt'
 - [https://www.dailymail.co.uk/news/article-11213473/President-Zelensky-Kyiv-car-crash-not-seriously-hurt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213473/President-Zelensky-Kyiv-car-crash-not-seriously-hurt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 22:46:55+00:00

President Zelensky of Ukraine was involved in a car crash tonight but was 'not seriously hurt', his spokesman said.

## Where do I join the queue and is there a fast-track option? Your questions answered
 - [https://www.dailymail.co.uk/news/article-11213461/Where-join-queue-fast-track-option-questions-answered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213461/Where-join-queue-fast-track-option-questions-answered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 22:44:23+00:00

How long is the queue?
Last night it was already some 2.5 miles, meaning a wait of 12 hours. Ministers warn people could have to wait 30 hours or more.

## LA school district is slammed for posting woke video that says calling junk food bad is wrong
 - [https://www.dailymail.co.uk/news/article-11213171/LA-school-district-slammed-posting-woke-video-says-calling-junk-food-bad-wrong.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213171/LA-school-district-slammed-posting-woke-video-says-calling-junk-food-bad-wrong.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 22:42:06+00:00

The Los Angeles Unified School District posted a video on Instagram condemning negative attitudes towards junk food and claiming diet culture is based on oppression.

## The Cut launches attack on King Charles for being a 'big, fussy baby and a jerk to his staff'
 - [https://www.dailymail.co.uk/news/article-11213241/The-Cut-launches-attack-King-Charles-big-fussy-baby-jerk-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213241/The-Cut-launches-attack-King-Charles-big-fussy-baby-jerk-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 22:40:00+00:00

The Cut, the liberal magazine that published an in-depth interview with Meghan Markle, in August, has targeted King Charles in a new piece that was published online on Wednesday.

## Funny moment Channel 4 newsreader who thinks he is off camera angrily waves script
 - [https://www.dailymail.co.uk/news/article-11212857/Funny-moment-Channel-4-newsreader-thinks-camera-angrily-waves-script.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212857/Funny-moment-Channel-4-newsreader-thinks-camera-angrily-waves-script.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 22:32:54+00:00

As he thanked his interviewee Dan Snow, Krishnan Guru-Murthy, who was reporting from Westminster, began reading the next story link, which was not meant for him.

## Detroit cop resigns after the department discovered her OnlyFans page with pornographic photos
 - [https://www.dailymail.co.uk/news/article-11213181/Detroit-cop-resigns-department-discovered-OnlyFans-page-pornographic-photos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213181/Detroit-cop-resigns-department-discovered-OnlyFans-page-pornographic-photos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 22:31:02+00:00

Janelle Zielinski, a Detroit police officer, resigned after the department discovered her explicit OnlyFans page with porn. An investigation was launched and officers found her explicit videos.

## REBECCA ENGLISH watches the determination of the royal ladies with red-rimmed eyes in mourning
 - [https://www.dailymail.co.uk/news/article-11213207/REBECCA-ENGLISH-watches-determination-royal-ladies-red-rimmed-eyes-mourning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213207/REBECCA-ENGLISH-watches-determination-royal-ladies-red-rimmed-eyes-mourning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 22:00:16+00:00

REBECCA ENGLISH: The sight of four royal women waiting for Her Majesty's coffin at the entrance to historic Westminster Hall sparked memories of 'the three Queens' mourning King George VI in 1952.

## Giant meteor spotted over Scotland as space object crashes to earth in a yet unidentified location
 - [https://www.dailymail.co.uk/news/article-11213269/Giant-meteor-spotted-Scotland-space-object-crashes-earth-unidentified-location.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213269/Giant-meteor-spotted-Scotland-space-object-crashes-earth-unidentified-location.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:50:33+00:00

Video shot form a back garden in Motherwell shows  large bright object flying from let to right an a downwards angle followed by a long tail.

## Lucchese soldier and five associates are charged in illegal gambling operation
 - [https://www.dailymail.co.uk/news/article-11212859/Lucchese-soldier-five-associates-charged-illegal-gambling-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212859/Lucchese-soldier-five-associates-charged-illegal-gambling-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:50:10+00:00

An indictment unsealed in Brooklyn federal court Tuesday revealed the business 'Rhino Sports' used an offshore website and dozens of bookmakers in the New York area for the scheme.

## Bodies in suitcases: Woman arrested in South Korea on two murder charges, faces extradition
 - [https://www.dailymail.co.uk/news/article-11213271/Bodies-suitcases-Woman-arrested-South-Korea-two-murder-charges-faces-extradition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213271/Bodies-suitcases-Woman-arrested-South-Korea-two-murder-charges-faces-extradition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:49:09+00:00

A woman has been arrested in South Korea over the deaths of two children discovered inside suitcases in south Auckland.

## The Royals: Will Harry seize the opportunity for reconciliation his brother and father have given?
 - [https://www.dailymail.co.uk/news/article-11213193/The-Royals-Harry-seize-opportunity-reconciliation-brother-father-given.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213193/The-Royals-Harry-seize-opportunity-reconciliation-brother-father-given.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:47:38+00:00

RICHARD KAY: Just as it had 25 years ago, the sun shone down on William and Harry as they walked side by side behind their grandmother's coffin through London on Wednesday.

## Double murder mystery that fueled America's obsession with true crime is re-examined in new book
 - [https://www.dailymail.co.uk/news/article-11211735/Double-murder-mystery-fueled-Americas-obsession-true-crime-examined-new-book.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211735/Double-murder-mystery-fueled-Americas-obsession-true-crime-examined-new-book.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:43:39+00:00

The murder case is revisited in Blood and Ink: The Scandalous Jazz Age Double Murder That Hooked America on True Crime by journalist Joe Pompeo.

## Las Vegas Dem official 'throttled wife in drunken Bellagio casino brawl' court documents reveal
 - [https://www.dailymail.co.uk/news/article-11213035/Las-Vegas-Dem-official-throttled-wife-drunken-Bellagio-casino-brawl-court-documents-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213035/Las-Vegas-Dem-official-throttled-wife-drunken-Bellagio-casino-brawl-court-documents-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:42:07+00:00

Robert Telles, 45, was arrested on March 1, 2020 for domestic battery and resisting arrest after a drunken brawl at the Bellagio casino two years before he was arrested on a murder charge.

## Police find living Asian relatives of children found dead in New Zealand suitcase
 - [https://www.dailymail.co.uk/news/article-11129387/Police-living-Asian-relatives-children-dead-New-Zealand-suitcase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11129387/Police-living-Asian-relatives-children-dead-New-Zealand-suitcase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:39:37+00:00

New Zealand police said it is also expanding their homicide probe after a family from Auckland made the shocking discovery of human remains in Auckland.

## The formidable ladies-in-waiting whose service to the Queen has finally ended
 - [https://www.dailymail.co.uk/news/article-11212619/The-formidable-ladies-waiting-service-Queen-finally-ended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212619/The-formidable-ladies-waiting-service-Queen-finally-ended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:36:18+00:00

Known as 'the Head Girls', the Queen's ladies-in-waiting were constantly by her side, some, astonishingly, for more than 60 years.

## Arkansas dad amputated his OWN LEG in front of his five-year-old daughter after saying he was Satan
 - [https://www.dailymail.co.uk/news/article-11212951/Arkansas-dad-amputated-LEG-five-year-old-daughter-saying-Satan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212951/Arkansas-dad-amputated-LEG-five-year-old-daughter-saying-Satan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:34:40+00:00

Shannon Cox, 48, sawed off his own leg in front of his five-year-old daughter after raving to his wife that he was Jesus Christ and Satan, and threatened to twist her head off leading to her fleeing the house.

## Queue to see Queen could CLOSE on Saturday night
 - [https://www.dailymail.co.uk/news/article-11213125/Queue-Queen-CLOSE-Saturday-night.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213125/Queue-Queen-CLOSE-Saturday-night.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:29:21+00:00

With Culture Secretary Michelle Donelan warning that queue times could hit 30 hours, this could mean the line being closed to new entrants in the early hours of Sunday, or even late on Saturday night.

## Anger as MPs get four extra passes to jump the queue to see the Queen lying in state in Westminster
 - [https://www.dailymail.co.uk/news/article-11213185/Anger-MPs-four-extra-passes-jump-queue-Queen-lying-state-Westminster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213185/Anger-MPs-four-extra-passes-jump-queue-Queen-lying-state-Westminster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:28:13+00:00

MPs can jump the queue to see the Queen's coffin and bring in up to four guests, to the anger of those being forced to wait.

## White House calls for sides to stay at the bargaining table to avert freight rail shutdown
 - [https://www.dailymail.co.uk/news/article-11213025/White-House-calls-sides-stay-bargaining-table-avert-freight-rail-shutdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213025/White-House-calls-sides-stay-bargaining-table-avert-freight-rail-shutdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:27:07+00:00

White House Press Secretary Karine Jean-PIerre on Wednesday called for all parties in talks between freight rails and unions to act 'in good faith' and come to an agreement.

## Brazil amusement park ride plummeted to platform and left three people injured
 - [https://www.dailymail.co.uk/news/article-11212697/Brazil-amusement-park-ride-plummeted-platform-left-three-people-injured.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212697/Brazil-amusement-park-ride-plummeted-platform-left-three-people-injured.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:24:53+00:00

A four-year old boy, who was among three people hurt in an amusement park accident in Brazil on Sunday night, may have to undergo surgery after suffering spinal and abdominal injuries.

## Poignant moment Prince Harry is overcome with emotion during lying in state service for the Queen
 - [https://www.dailymail.co.uk/news/article-11212851/Poignant-moment-Prince-Harry-overcome-emotion-lying-state-service-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212851/Poignant-moment-Prince-Harry-overcome-emotion-lying-state-service-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:24:24+00:00

As the late monarch's coffin was placed in the hall, photos captured a poignant moment for the Duke of Sussex as he held his head in his hand, shielding his eyes, and looked down.

## Ex-Governor Andrew Cuomo and top aides sued by woman who accused him of sexual harassment in 2021
 - [https://www.dailymail.co.uk/news/article-11212525/Ex-Governor-Andrew-Cuomo-aides-sued-woman-accused-sexual-harassment-2021.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212525/Ex-Governor-Andrew-Cuomo-aides-sued-woman-accused-sexual-harassment-2021.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:15:20+00:00

One of the first young women who came forward with accusations of harassment against ex-Governor Andrew Cuomo filed a federal lawsuit against him Wednesday.

## EU officials scrap plans to choke off funds for Ukraine war with price cap on Russian gas
 - [https://www.dailymail.co.uk/news/article-11213059/EU-officials-scrap-plans-choke-funds-Ukraine-war-price-cap-Russian-gas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213059/EU-officials-scrap-plans-choke-funds-Ukraine-war-price-cap-Russian-gas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:10:15+00:00

Eurocrats last night scrapped plans to choke off funds for Vladimir Putin's war in Ukraine when they ditched a proposed price cap on Russian gas.

## Matchless! Classic Lowry painting showing football crowd scene is set to fetch £8million at auction
 - [https://www.dailymail.co.uk/news/article-11213045/Matchless-Classic-Lowry-painting-showing-football-crowd-scene-set-fetch-8million-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11213045/Matchless-Classic-Lowry-painting-showing-football-crowd-scene-set-fetch-8million-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 21:02:00+00:00

The 1953 work Going To The Match is being sold at Christie's in London next month by The Players Foundation charity and is set to break records at auction.

## MoMA benefactor will auction $100M of masterpieces to fund digital endowment
 - [https://www.dailymail.co.uk/news/article-11212503/MoMA-benefactor-auction-70M-masterpieces-fund-digital-endowment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212503/MoMA-benefactor-auction-70M-masterpieces-fund-digital-endowment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 20:46:42+00:00

The artworks, owned by the foundation of late CBS founder William S. Paley, are expected to bring in upwards of $70 million total at a series of Sotheby's auctions in the coming months.

## The Queen: Body language expert reveals royals' emotions at sombre lying-in-state
 - [https://www.dailymail.co.uk/news/article-11212607/The-Queen-Body-language-expert-reveals-royals-emotions-sombre-lying-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212607/The-Queen-Body-language-expert-reveals-royals-emotions-sombre-lying-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 20:46:00+00:00

The women of the Royal Family all showed their grief in different ways on Wednesday as they joined the procession escorting Queen Elizabeth II's coffin from Buckingham Palace to Westminster Hall.

## Melania Trump rolls out 'American Christmas' ornaments, NFTs to help fund scholarships
 - [https://www.dailymail.co.uk/news/article-11212959/Melania-Trump-rolls-American-Christmas-ornaments-NFTs-help-fund-scholarships.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212959/Melania-Trump-rolls-American-Christmas-ornaments-NFTs-help-fund-scholarships.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 20:39:52+00:00

Former First Lady Melania Trump is rolling out her own Christmas ornaments that come with its own NFT.

## 'Two Buck Chuck' wine Fred Franzia dies aged 79
 - [https://www.dailymail.co.uk/news/article-11212395/Two-Buck-Chuck-wine-Fred-Franzia-dies-aged-79.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212395/Two-Buck-Chuck-wine-Fred-Franzia-dies-aged-79.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 20:34:46+00:00

Wine titan Fred Franzia, creator of the iconic 'Two Buck Chuck' blend died at his home in Denair, California. He was 79

## REVEALED Trump toured his golf course in DC because he is planning upgrades - not to meet lawyers
 - [https://www.dailymail.co.uk/news/article-11212829/REVEALED-Trump-toured-golf-course-DC-planning-upgrades-not-meet-lawyers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212829/REVEALED-Trump-toured-golf-course-DC-planning-upgrades-not-meet-lawyers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 20:24:55+00:00

'This is probably the funniest story I've heard in years. His family owns and operates golf courses and hotels all around the world,' said a source familiar with the visit.

## Colorado sheriff's deputy, 29, who's accused of shooting man, 22 dead after he called 911 for help
 - [https://www.dailymail.co.uk/news/article-11212681/Colorado-sheriffs-deputy-29-whos-accused-shooting-man-22-dead-called-911-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212681/Colorado-sheriffs-deputy-29-whos-accused-shooting-man-22-dead-called-911-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 20:20:40+00:00

Andrew Buen, 29, shot and killed Christian Glass, 22, after he pulled out a knife and refused to get out of his vehicle on June 11 in Denver, Colorado.

## Walmart teases plans to become America's biggest BANK: Retail giant will trial accounts for staff
 - [https://www.dailymail.co.uk/news/article-11212725/Walmart-teases-plans-Americas-biggest-BANK-Retail-giant-trial-accounts-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212725/Walmart-teases-plans-Americas-biggest-BANK-Retail-giant-trial-accounts-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 20:15:29+00:00

Walmart offer checking accounts to several thousand of its employees in the coming weeks as a part of a beta test. It hopes to roll out banking options to its 1.6million employees within a year.

## William and Harry joined other rouals for  royals after receiving the Queen's Coffin
 - [https://www.dailymail.co.uk/news/article-11212771/William-Harry-joined-rouals-royals-receiving-Queens-Coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212771/William-Harry-joined-rouals-royals-receiving-Queens-Coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 19:53:03+00:00

Kate and Meghan were also present for the dinner as the Queen spent a final night in the palace's Bow Room before being moved to the Palace of Westminster this afternoon to lie in state for four days.

## California is suing Amazon alleging the company contributed to high costs of products state-wide
 - [https://www.dailymail.co.uk/news/article-11212837/California-suing-Amazon-alleging-company-contributed-high-costs-products-state-wide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212837/California-suing-Amazon-alleging-company-contributed-high-costs-products-state-wide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 19:49:52+00:00

California officials sued Amazon on Wednesday alleging the company contributed to high costs products across the state.

## Charles and Camilla land at her Wiltshire estate as the royals go their separate ways after service
 - [https://www.dailymail.co.uk/news/article-11212531/Charles-Camilla-land-Wiltshire-estate-royals-separate-ways-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212531/Charles-Camilla-land-Wiltshire-estate-royals-separate-ways-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 19:46:56+00:00

King Charles and the Queen Consort's helicopter landed in Wiltshire this afternoon, an hour after leaving the the late Queen's procession from Buckingham Place to the Palace of Westminster.

## Biden lauds his Inflation Reduction Act  as he announces $900M to build electric vehicle chargers
 - [https://www.dailymail.co.uk/news/article-11212649/Biden-lauds-Inflation-Reduction-Act-announces-900M-build-electric-vehicle-chargers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212649/Biden-lauds-Inflation-Reduction-Act-announces-900M-build-electric-vehicle-chargers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 19:44:21+00:00

Biden lauded the green energy provisions of his Inflation Reduction Act as he announced the first $900 million in funding toward electric vehicle charging stations.

## Rand Paul clashes with Anthony Fauci in Congress again
 - [https://www.dailymail.co.uk/news/article-11212643/Rand-Paul-clashes-Anthony-Fauci-Congress-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212643/Rand-Paul-clashes-Anthony-Fauci-Congress-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 19:18:12+00:00

The Fauci-Paul show returned to Congress on Wednesday, when the world-renowned scientist and his libertarian tormentor went at it over COVID instead of discussing monkeypox.

## Plane with pilot's body still inside is stuck in tree branches 120 feet UNDERWATER after it crashed
 - [https://www.dailymail.co.uk/news/article-11212341/Plane-pilots-body-inside-stuck-tree-branches-120-feet-UNDERWATER-crashed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212341/Plane-pilots-body-inside-stuck-tree-branches-120-feet-UNDERWATER-crashed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 18:48:57+00:00

A plane with the pilot dead inside is stuck underwater in a Georgia lake and tangled in a mass of tree branches, making it difficult for authorities to retrieve the plane and the body from the lake.

## Military heroes are invited to Queen's funeral
 - [https://www.dailymail.co.uk/news/article-11211771/Military-heroes-invited-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211771/Military-heroes-invited-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 18:43:06+00:00

British military heroes who hold the Victoria Cross - including an RAF ace who sunk a German U-boat then landed his damaged plane while wounded - will be invited to the Queen's funeral on Monday.

## Baltimore prosecutors call for Adnan Syed's murder conviction to be vacated
 - [https://www.dailymail.co.uk/news/article-11212657/Baltimore-prosecutors-call-Adnan-Syeds-murder-conviction-vacated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212657/Baltimore-prosecutors-call-Adnan-Syeds-murder-conviction-vacated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 18:37:29+00:00

Prosecutors in Baltimore are asking for Adnan Syed to be re-tried for the 1999 murder of Hae Min Lee, a case that gripped the nation after it was featured on the podcast Serial.

## Patreon slashes a fifth of its workforce and closes two European offices
 - [https://www.dailymail.co.uk/news/article-11212233/Patreon-slashes-fifth-workforce-closes-two-European-offices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212233/Patreon-slashes-fifth-workforce-closes-two-European-offices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 18:34:35+00:00

Jack Conte, Patreon CEO, announced mass layoffs and the closure of two European offices on Tuesday as the company experiences an unforeseen economic shift post pandemic.

## Biden was exercising his 'sacred' right when he flew to Delaware for ONE HOUR Tuesday
 - [https://www.dailymail.co.uk/news/article-11212489/Biden-exercising-sacred-right-flew-Delaware-ONE-HOUR-Tuesday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212489/Biden-exercising-sacred-right-flew-Delaware-ONE-HOUR-Tuesday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 18:13:11+00:00

The White House defended President Joe Biden's decision to fly to Wilmington on Air Force One to cast his ballot in Delaware's Democratic primary elections.

## Greggs joins the long list of businesses CLOSING for Queen's funeral
 - [https://www.dailymail.co.uk/news/article-11212517/Greggs-joins-long-list-businesses-CLOSING-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212517/Greggs-joins-long-list-businesses-CLOSING-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 18:12:37+00:00

Greggs is the latest major retailer to say they will not be opening on Monday to allow staff time off to commemorate the Queen's passing, following the likes of McDonald's.

## Christianity is set to become a MINORITY faith as soon as 2060 as millions switch to secularism
 - [https://www.dailymail.co.uk/news/article-11211575/Christianity-set-MINORITY-faith-soon-2060-millions-switch-secularism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211575/Christianity-set-MINORITY-faith-soon-2060-millions-switch-secularism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 17:55:49+00:00

The drift away from Christianity is a trend across much of the developed world, hastened by a slew of damaging sex abuse scandals in the Catholic, Mormon and other churches.

## Manchester City star Benjamin Mendy's 'fixer' friend 'raped woman after her 19th birthday party'
 - [https://www.dailymail.co.uk/news/article-11212409/Manchester-City-star-Benjamin-Mendys-fixer-friend-raped-woman-19th-birthday-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212409/Manchester-City-star-Benjamin-Mendys-fixer-friend-raped-woman-19th-birthday-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 17:54:37+00:00

The woman, who is now 20, told the Benjamin Mendy rape trial yesterday that she was raped by the star's co accused Louis Saha Matturie (pictured) after going to his flat in March last year.

## Putin's limousine is 'hit by loud bang' in possible 'attack'
 - [https://www.dailymail.co.uk/news/article-11212515/Putins-limousine-hit-loud-bang-possible-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212515/Putins-limousine-hit-loud-bang-possible-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 17:47:55+00:00

The car drove to safety with Putin unharmed but there have been multiple arrests from his security service - while other bodyguards have vanished.

## Rail union REJECTS deal to prevent strike
 - [https://www.dailymail.co.uk/news/article-11212119/Rail-union-REJECTS-deal-prevent-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212119/Rail-union-REJECTS-deal-prevent-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 17:45:16+00:00

The International Association of Machinists and Aerospace Workers announced on Wednesday that its 4,900 members voted to reject a deal its leaders reached with freight railroad companies

## Trump congratulates Karoline Leavitt, 25, who might become youngest woman ever to serve in Congress
 - [https://www.dailymail.co.uk/news/article-11212213/Trump-congratulates-Karoline-Leavitt-25-youngest-woman-serve-Congress.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212213/Trump-congratulates-Karoline-Leavitt-25-youngest-woman-serve-Congress.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 17:44:58+00:00

Trump is pleased with GOP youngster Karoline Leavitt's win in her NH Republican primary, claiming the 25-year-old victor has 'wisdom', despite not wading into the water of the race.

## Inflation is hitting Dem-run cities hardest, with Phoenix suffering 13% rise in prices
 - [https://www.dailymail.co.uk/news/article-11212293/Inflation-hitting-Dem-run-cities-hardest-Phoenix-suffering-13-rise-prices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212293/Inflation-hitting-Dem-run-cities-hardest-Phoenix-suffering-13-rise-prices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 17:31:26+00:00

Inflation has soared in Democrat run cities with new figures showing an increases of  up to 13 per cent. Cities that grow faster can see more spending power, which then pushes prices up.

## Influencer gets 90 months under house arrest for plotting jailed congresswoman mother's escape
 - [https://www.dailymail.co.uk/news/article-11211741/Influencer-gets-90-months-house-arrest-plotting-jailed-congresswoman-mothers-escape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211741/Influencer-gets-90-months-house-arrest-plotting-jailed-congresswoman-mothers-escape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 17:14:45+00:00

Colombian influencer Aida Victoria Merlano will be serving a 90-month sentence at her high-end home in Barranquilla for helping her fugitive Senator mother escape from her jail guards.

## Prince Harry's memoir 'won't be published until next year'
 - [https://www.dailymail.co.uk/news/article-11211729/Prince-Harrys-memoir-wont-published-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211729/Prince-Harrys-memoir-wont-published-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 17:11:22+00:00

The book, which has cast a long shadow over the Royal family for months,  was originally scheduled for release in 'late 2022', possibly around Thanksgiving.

## Four teens found overdosing on fentanyl-laced Percocet near Hollywood high school where Glee filmed
 - [https://www.dailymail.co.uk/news/article-11212167/Four-teens-overdosing-fentanyl-laced-Percocet-near-Hollywood-high-school-Glee-filmed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212167/Four-teens-overdosing-fentanyl-laced-Percocet-near-Hollywood-high-school-Glee-filmed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 17:01:40+00:00

A 15-year old girl died and three more teens were hospitalized Tuesday after suffering overdoses at a high school in Hollywood.

## Hunter Biden demands his support payments for love child be lowered due to change in income
 - [https://www.dailymail.co.uk/news/article-11212023/Hunter-Biden-demands-support-payments-love-child-lowered-change-income.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212023/Hunter-Biden-demands-support-payments-love-child-lowered-change-income.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 17:00:24+00:00

Hunter Biden is seeking to lower his child support payments for four-year-old love child Navy Joan who he fathered with Lunden Roberts.

## NT Outback towns at war as man  shot dead in crossbow attack: Peppimenarti, Wadeye
 - [https://www.dailymail.co.uk/news/article-11211593/NT-Outback-towns-war-man-shot-dead-crossbow-attack-Peppimenarti-Wadeye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211593/NT-Outback-towns-war-man-shot-dead-crossbow-attack-Peppimenarti-Wadeye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 16:49:21+00:00

A troubled Outback region plagued by out-of-control gangs and warring families has descended into further chaos this week after a man was shot dead with a crossbow.

## SAS hero Chris Ryan warns that 'anti-royalist idiots' could target Queen's funeral
 - [https://www.dailymail.co.uk/news/article-11212109/SAS-hero-Chris-Ryan-warns-anti-royalist-idiots-target-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212109/SAS-hero-Chris-Ryan-warns-anti-royalist-idiots-target-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 16:46:34+00:00

The famed author said terrorists would struggle to penetrate the unprecedented levels of security but feared royal-hating yobs could try to hijack the historic occasion.

## Top State Department official DENIES existence of Havana Syndrome reported by 1,100 diplomats
 - [https://www.dailymail.co.uk/news/article-11211801/Top-State-Department-official-DENIES-existence-Havana-Syndrome-reported-1-100-diplomats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211801/Top-State-Department-official-DENIES-existence-Havana-Syndrome-reported-1-100-diplomats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 16:45:54+00:00

A top State Department official said there was no evidence that an external cause lay behind so-called 'Havana Syndrome,' and that it was wrong to link mysterious ailments to the Cuban capital.

## Pennsylvania warehouse worker demoted and forced to take 50% pay cut due to medical marijuana card
 - [https://www.dailymail.co.uk/news/article-11211725/Pennsylvania-warehouse-worker-demoted-forced-50-pay-cut-medical-marijuana-card.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211725/Pennsylvania-warehouse-worker-demoted-forced-50-pay-cut-medical-marijuana-card.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 16:41:52+00:00

Blake Longenecker, a warehouse worker was punished by its employer with a demotion and a 50% pay cut after it was discovered that he was taking medical marijuana.

## Police constable Claudia Pastina to face trial as she denies assaulting man during work call out
 - [https://www.dailymail.co.uk/news/article-11211845/Police-constable-Claudia-Pastina-face-trial-denies-assaulting-man-work-call-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211845/Police-constable-Claudia-Pastina-face-trial-denies-assaulting-man-work-call-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 16:28:33+00:00

PC Claudia Pastina, 30, confronted Augustine Amatta at an address in Brixton Road, Brixton, southwest London , on 19 February this year.

## Rubbish collectors announce fresh two-week strike in dispute - to start day after Queen's funeral
 - [https://www.dailymail.co.uk/news/article-11212207/Rubbish-collectors-announce-fresh-two-week-strike-dispute-start-day-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212207/Rubbish-collectors-announce-fresh-two-week-strike-dispute-start-day-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 16:23:48+00:00

Members of Unite in the borough of Newham, east London, will walk out on September 20, it was confirmed today - just weeks after a previous walkout left bins lying unemptied.

## Four men arrested over death of Liverpool council worker Ashley Dale found shot dead in back garden
 - [https://www.dailymail.co.uk/news/article-11212225/Four-men-arrested-death-Liverpool-council-worker-Ashley-Dale-shot-dead-garden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212225/Four-men-arrested-death-Liverpool-council-worker-Ashley-Dale-shot-dead-garden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 16:13:39+00:00

Ashley Dale, 28, was found with gunshot wounds in her back garden in Old Swan, Liverpool, on August 21. On Wednesday, police said four men had been arrested.

## Shane Warne: Cricket great daughter Brooke Warne hits out at Channel 9 telemovie
 - [https://www.dailymail.co.uk/news/article-11211817/Shane-Warne-Cricket-great-daughter-Brooke-Warne-hits-Channel-9-telemovie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211817/Shane-Warne-Cricket-great-daughter-Brooke-Warne-hits-Channel-9-telemovie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 16:05:24+00:00

Brooke Warne, 24, the Australian cricket icon's eldest daughter, wrote to Instagram on Wednesday night asking the network's bosses: 'Do any of you have any respect for Dad? Or his family?'.

## Kumanjayi Walker inquest: Zachary Rolfe 'racist' text messages revealed
 - [https://www.dailymail.co.uk/news/article-11211773/Kumanjayi-Walker-inquest-Zachary-Rolfe-racist-text-messages-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211773/Kumanjayi-Walker-inquest-Zachary-Rolfe-racist-text-messages-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 16:04:37+00:00

The messages were retrieved from the phone of Constable Zachary Rolfe, who was initially charged with the murder of Kumanjayi Walker, 19, during an arrest attempt at Yuendumu in 2019.

## Northlakes High School puts gender-neutral 'they' pronouns on toilets: NSW
 - [https://www.dailymail.co.uk/news/article-11211407/Northlakes-High-School-puts-gender-neutral-pronouns-toilets-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211407/Northlakes-High-School-puts-gender-neutral-pronouns-toilets-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 16:04:07+00:00

Northlakes High School on the NSW Central Coast has put up the new 'inclusive' signage reading 'He/They' and 'She/They' but some parents are furious.

## Queen's procession: Prince Andrew and Harry are excluded from a royal salute
 - [https://www.dailymail.co.uk/news/article-11212059/Queens-procession-Prince-Andrew-Harry-excluded-royal-salute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11212059/Queens-procession-Prince-Andrew-Harry-excluded-royal-salute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:58:22+00:00

Andrew and Harry were both banned from saluting during the Queen's coffin procession - while other royals including Charles, William and Anne all performed the gesture.

## Britain grinds to a halt to watch Queen leave her palace for the last time
 - [https://www.dailymail.co.uk/news/article-11211869/Britain-grinds-halt-watch-Queen-leave-palace-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211869/Britain-grinds-halt-watch-Queen-leave-palace-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:49:52+00:00

Mourners have packed out Hyde Park while others crammed into pubs and stood in silence in stores to watch the Queen's coffin leave Buckingham Palace for the final time

## Two thirds of San Franciscans say city is going DOWNHILL due to vagrants, crime and living costs
 - [https://www.dailymail.co.uk/news/article-11211565/Two-thirds-San-Franciscans-say-city-going-DOWNHILL-vagrants-crime-living-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211565/Two-thirds-San-Franciscans-say-city-going-DOWNHILL-vagrants-crime-living-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:49:36+00:00

The survey paints a bleak portrait of a city famed for its Golden Gate Bridge and colorful 'Painted Ladies' homes being wracked by poor leadership, crime, homelessness and drugs.

## Biden criticized by usually loyal media for inflation speech
 - [https://www.dailymail.co.uk/news/article-11211723/Biden-criticized-usually-loyal-media-inflation-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211723/Biden-criticized-usually-loyal-media-inflation-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:46:30+00:00

Biden celebrated a slight reduction in inflation Tuesday, but a smattering of headlines from mainstream media outlets suggest the president's words were ill-timed.

## Imperial State Crown laid upon the Queen's coffin as it lies in state at Westminster Hall
 - [https://www.dailymail.co.uk/femail/article-11211839/Imperial-State-Crown-laid-Queens-coffin-lies-state-Westminster-Hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11211839/Imperial-State-Crown-laid-Queens-coffin-lies-state-Westminster-Hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:44:24+00:00

The Imperial State Crown is one of the Crown Jewels and represents the sovereignty of the monarch. The Queen wore it after her coronation in 1953.

## Florida couple get married on Brightline TRAIN after using it to meet one another for dates
 - [https://www.dailymail.co.uk/news/article-11211743/Florida-couple-married-Brightline-TRAIN-using-meet-one-dates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211743/Florida-couple-married-Brightline-TRAIN-using-meet-one-dates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:43:34+00:00

Megan Michelle Gabelman and Jean-Phillipe Charles said 'I do' on Wednesday while onboard a Florida Brightline train traveling from West Palm Beach to Fort Lauderdale.

## Pubs begin closing during the daytime due to spiralling energy costs
 - [https://www.dailymail.co.uk/news/article-11211153/Pubs-begin-closing-daytime-spiralling-energy-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211153/Pubs-begin-closing-daytime-spiralling-energy-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:43:07+00:00

The landlord of a pub in Devon says he is closing his doors in the daytime two days a week because of spiralling energy costs and slow trade.

## British athlete is arrested in Thailand for wakeboarding on a flooded road
 - [https://www.dailymail.co.uk/news/article-11211889/British-athlete-arrested-Thailand-wakeboarding-flooded-road.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211889/British-athlete-arrested-Thailand-wakeboarding-flooded-road.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:40:36+00:00

The thrillseeker, who in 2010 set the record for the youngest professional world champion in wakeboarding, was slapped with a 5,000 baht fine (£120) and a one-month suspended jail term

## How King Charles III led Queen's coffin procession while flanked by Andrew, Anne and Edward
 - [https://www.dailymail.co.uk/news/article-11211879/How-King-Charles-III-led-Queens-coffin-procession-flanked-Andrew-Anne-Edward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211879/How-King-Charles-III-led-Queens-coffin-procession-flanked-Andrew-Anne-Edward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:36:11+00:00

His Majesty walked behind the gun carriage bearing his beloved mother's casket as he was flanked by Princess Anne, Prince Andrew and Prince Edward.

## Diver who found missing California teen Kiely Rodni says death 'reeks of foul play'
 - [https://www.dailymail.co.uk/news/article-11211737/Diver-missing-California-teen-Kiely-Rodni-says-death-reeks-foul-play.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211737/Diver-missing-California-teen-Kiely-Rodni-says-death-reeks-foul-play.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:29:55+00:00

Diver Doug Bishop, who found the body of missing California teen Kiely Rodni in the backseat of her car submerged in a reservoir, has doubled down on his claims that he believes her death is suspicious.

## Gay rights group say 'anti-lesbian prejudice' is making teens think they have gender identity issues
 - [https://www.dailymail.co.uk/news/article-11211525/Gay-rights-group-say-anti-lesbian-prejudice-making-teens-think-gender-identity-issues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211525/Gay-rights-group-say-anti-lesbian-prejudice-making-teens-think-gender-identity-issues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:27:38+00:00

The co-founder of the LGB Alliance said 'anti-lesbian prejudice and fear' is making teenagers wrongly believe they have 'gender identity issues', a London hearing was told today.

## Queen's funeral guest list: Who's NOT invited?
 - [https://www.dailymail.co.uk/news/article-11211715/Queens-funeral-guest-list-Whos-NOT-invited.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211715/Queens-funeral-guest-list-Whos-NOT-invited.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:24:56+00:00

As the world mourns Her Majesty's death at the age of 96, the globe's most powerful men and women are scrambling for the exclusive seats for the late Queen's state funeral in London.

## Video shows rowdy teen girls screaming abuse at McDonald's staff in Kent
 - [https://www.dailymail.co.uk/news/article-11211461/Video-shows-rowdy-teen-girls-screaming-abuse-McDonalds-staff-Kent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211461/Video-shows-rowdy-teen-girls-screaming-abuse-McDonalds-staff-Kent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:15:48+00:00

The teenagers were allegedly seen assaulting staff and screaming vile abuse at customers, which occurred about 5.40pm on Sunday inside the Maidstone, Kent, branch.

## Pub landlord who bombarded ex with messages and accused her of abuse in harassment effort is jailed
 - [https://www.dailymail.co.uk/news/article-11211345/Pub-landlord-bombarded-ex-messages-accused-abuse-harassment-effort-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211345/Pub-landlord-bombarded-ex-messages-accused-abuse-harassment-effort-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:05:55+00:00

Gareth Slattery, 53, Barry, Wales, launched a campaign of 'calculated and deliberate' harassment against his former partner after their eight-month romance ended in 2021.

## King Charles III's hunky kilt-clad equerry joins procession for the Queen
 - [https://www.dailymail.co.uk/news/article-11211933/King-Charles-IIIs-hunky-kilt-clad-equerry-joins-procession-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211933/King-Charles-IIIs-hunky-kilt-clad-equerry-joins-procession-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 15:02:12+00:00

King Charles III's equerry - the 'hunky' Scottish Army officer who leaves royal fans swooning whenever he appears - accompanied the Queen as she left Buckingham Palace for the final time.

## Massive 400-pound, 11-foot-long alligator is seen prowling Texas neighborhood
 - [https://www.dailymail.co.uk/news/article-11211641/Massive-400-pound-11-foot-long-alligator-seen-prowling-Texas-neighborhood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211641/Massive-400-pound-11-foot-long-alligator-seen-prowling-Texas-neighborhood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:57:37+00:00

An enormous 400-pound, 11-foot-long alligator prowled through a Texas neighborhood on Monday before being quickly captured and sent to a sanctuary by licensed trappers and authorities.

## Prince Harry and Meghan Markle stand behind Prince William and Kate Middleton in Westminster Hall
 - [https://www.dailymail.co.uk/news/article-11211891/Prince-Harry-Meghan-Markle-Prince-William-Kate-Middleton-Westminster-Hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211891/Prince-Harry-Meghan-Markle-Prince-William-Kate-Middleton-Westminster-Hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:46:38+00:00

At 2.22pm Her Majesty was carried down The Mall on a gun carriage - a tradition dating back to the death of her great-grandmother Queen Victoria in 1901.

## Sylvester Stallone covers up a SECOND tattoo of his estranged wife Jennifer Flavin
 - [https://www.dailymail.co.uk/news/article-11206791/Sylvester-Stallone-covers-SECOND-tattoo-estranged-wife-Jennifer-Flavin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206791/Sylvester-Stallone-covers-SECOND-tattoo-estranged-wife-Jennifer-Flavin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:43:17+00:00

This tattoo on the actor's left tricep was of Jennifer's eyes, which has now been covered up with the face of a leopard.

## Professor who wished Queen 'excruciating death' says it's racist that Irish people are humored
 - [https://www.dailymail.co.uk/news/article-11211663/Professor-wished-Queen-excruciating-death-says-racist-Irish-people-humored.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211663/Professor-wished-Queen-excruciating-death-says-racist-Irish-people-humored.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:43:03+00:00

Ujo Anya, a black applied-linguistics professor, said it is 'telling' that she received backlash for her tweet wishing the Queen an 'excruciating death' while a video of Irish people river dancing goes viral.

## Dog owner left with $19,500 vet bill after pitbull DIES from porcupine quill attack
 - [https://www.dailymail.co.uk/news/article-11211665/Dog-owner-left-19-500-vet-bill-pitbull-DIES-porcupine-quill-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211665/Dog-owner-left-19-500-vet-bill-pitbull-DIES-porcupine-quill-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:42:43+00:00

A poor pup in New Jersey died following a battle with a porcupine that left him skewered with quills all over his body.

## Queen's coffin arrives at Westminster where she will rest for four days before funeral on Monday
 - [https://www.dailymail.co.uk/news/article-11211977/Queens-coffin-arrives-Westminster-rest-four-days-funeral-Monday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211977/Queens-coffin-arrives-Westminster-rest-four-days-funeral-Monday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:42:08+00:00

The Queen's coffin entered Westminster Hall as the choir of Westminster Abbey and the choir of His Majesty's Chapel Royal, St James's Palace, sang Psalm 139.

## Joe Biden speaks to King Charles III for the first time
 - [https://www.dailymail.co.uk/news/article-11211971/Joe-Biden-speaks-King-Charles-III-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211971/Joe-Biden-speaks-King-Charles-III-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:41:54+00:00

Biden spoke to King Charles III for the first time on Wednesday, paying tribute to his late mother Queen Elizabeth II and her hospitality, while saying he wanted to continue their close relationship.

## Queen's funeral set to become the world's most watched broadcast of all time with 4.1BILLION viewers
 - [https://www.dailymail.co.uk/news/article-11211739/Queens-funeral-set-worlds-watched-broadcast-time-4-1BILLION-viewers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211739/Queens-funeral-set-worlds-watched-broadcast-time-4-1BILLION-viewers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:41:30+00:00

More than 4billion people across the world are expected to tune in on Monday to watch the final chapter of the Second Elizabethan Age draw to a poignant close.

## Distressed motorist shot dead by cops had alcohol, cannabis and amphetamines in his system
 - [https://www.dailymail.co.uk/news/article-11211747/Distressed-motorist-shot-dead-cops-alcohol-cannabis-amphetamines-system.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211747/Distressed-motorist-shot-dead-cops-alcohol-cannabis-amphetamines-system.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:41:03+00:00

Christian Glass, 22, had even tried to make heart-shaped signals for help when he was tasered and shot by officers six times in Denver, Colorado, after they said he became 'argumentative'.

## Sydney free train: Rail, Tram and Bus Union will deactivate Opal readers and gates: NSW Gov
 - [https://www.dailymail.co.uk/news/article-11211457/Sydney-free-train-Rail-Tram-Bus-Union-deactivate-Opal-readers-gates-NSW-Gov.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211457/Sydney-free-train-Rail-Tram-Bus-Union-deactivate-Opal-readers-gates-NSW-Gov.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:37:41+00:00

The Rail, Tram and Bus Union will deactivate Opal readers and gates from September 21, indefinitely, until a resolution is reached, NSW secretary Alex Claassens said.

## Queen Consort Camilla arrives at Buckingham Palace with Sophie Densham
 - [https://www.dailymail.co.uk/femail/article-11211473/Queen-Consort-Camilla-funeral-procession-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11211473/Queen-Consort-Camilla-funeral-procession-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:31:53+00:00

The supportive Queen Consort Camilla, 75, looked pensive as she took part in the late Queen's funeral procession from Buckingham Palace to Westminster Abbey today.

## Leaflet from George VI's funeral falls out of Bible in service for Queen's death
 - [https://www.dailymail.co.uk/news/article-11211541/Leaflet-George-VIs-funeral-falls-Bible-service-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211541/Leaflet-George-VIs-funeral-falls-Bible-service-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:30:32+00:00

Nick Danks was shocked when the historic item was discovered at St Genny's Church, near Crackington Haven, in Cornwall, before Sunday's Evensong.

## El Paso's border crisis deepens as 1,000 migrants are left to sleep on the streets
 - [https://www.dailymail.co.uk/news/article-11211527/El-Pasos-border-crisis-deepens-1-000-migrants-left-sleep-streets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211527/El-Pasos-border-crisis-deepens-1-000-migrants-left-sleep-streets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:21:46+00:00

Following a large influx of migrants, primarily from Venezuela, Border Patrol facilities and shelters in the west Texas town have been overwhelmed in recent days, leading to a flood of 'street releases'.

## 'God guides us away from war', says the Pope as he appears to condemn Russia's invasion of Ukraine
 - [https://www.dailymail.co.uk/news/article-11211861/God-guides-away-war-says-Pope-appears-condemn-Russias-invasion-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211861/God-guides-away-war-says-Pope-appears-condemn-Russias-invasion-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:16:02+00:00

The Pope, 85, said those in powerful religious positions must 'never be a prop for power', in an implicit criticism of Patriarch Kirill, who backs Vladimir Putin's war in Ukraine.

## Ukrainian mother weeps and jumps for joy as she is reunited with her son as her town is liberated
 - [https://www.dailymail.co.uk/news/article-11211685/Ukrainian-mother-weeps-jumps-joy-reunited-son-town-liberated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211685/Ukrainian-mother-weeps-jumps-joy-reunited-son-town-liberated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:02:59+00:00

Footage shows Vyacheslav Zadorenko, the mayor of Derhachi District in Kharkiv Oblast near the Russian border,  hugging his relieved mother/

## Father of two who denies abusing and murdering girlfriend's 15-month-old son remanded in custody
 - [https://www.dailymail.co.uk/news/article-11211413/Father-two-denies-abusing-murdering-girlfriends-15-month-old-son-remanded-custody.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211413/Father-two-denies-abusing-murdering-girlfriends-15-month-old-son-remanded-custody.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 14:01:57+00:00

Jacob Lennon, 15 months old, died after he was rushed to hospital from the family home in Putney, southwest London, with serious head injuries in August 2019.

## Queen Consort looks grave as she follows funeral procession for late Monarch
 - [https://www.dailymail.co.uk/femail/article-11211473/Queen-Consort-looks-grave-follows-funeral-procession-late-Monarch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11211473/Queen-Consort-looks-grave-follows-funeral-procession-late-Monarch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:50:26+00:00

The supportive Queen Consort Camilla, 75, looked pensive as she took part in the late Queen's funeral procession from Buckingham Palace to Westminster Abbey today.

## King Charles, Prince Andrew, William, Harry, Princess Anne and Edward lead procession
 - [https://www.dailymail.co.uk/news/article-11211697/King-Charles-Prince-Andrew-William-Harry-Princess-Anne-Edward-lead-procession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211697/King-Charles-Prince-Andrew-William-Harry-Princess-Anne-Edward-lead-procession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:50:13+00:00

At 2.22pm Her Majesty was carried down The Mall on a gun carriage  - a tradition dating back to the death of her great-grandmother Queen Victoria in 1901.

## Prince William and Prince Harry are reunited for Queen's procession
 - [https://www.dailymail.co.uk/news/article-11211765/Prince-William-Prince-Harry-reunited-Queens-procession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211765/Prince-William-Prince-Harry-reunited-Queens-procession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:49:48+00:00

Prince William and Prince Harry walked together behind their father King Charles III in a show of unity today as they followed the Queen's coffin from Buckingham Palace.

## Queen's coffin procession LIVE: Royals head to Buckingham Palace
 - [https://www.dailymail.co.uk/news/live/article-11210555/Queen-funeral-news-live-King-Charles-III-coffin-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11210555/Queen-funeral-news-live-King-Charles-III-coffin-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:49:46+00:00

MAILONLINE LIVEBLOG: On day five of national mourning, the Queen 's coffin is taken from Buckingham Palace to Westminster Hall and her lying-in-state begins on September 14, 2022:

## Northeastern University letter bomb had note railing against Mark Zuckerberg and virtual reality
 - [https://www.dailymail.co.uk/news/article-11211667/Northeastern-University-letter-bomb-note-railing-against-Mark-Zuckerberg-virtual-reality.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211667/Northeastern-University-letter-bomb-note-railing-against-Mark-Zuckerberg-virtual-reality.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:49:43+00:00

The bomb detonated inside Northeastern university's virtual reality center and injured a 45-year-old staff member. The staff member was hospitalized with minor injuries to their hands.

## Princess Eugenie is elegant in a black as she leaves Clarence House
 - [https://www.dailymail.co.uk/femail/article-11211523/Princess-Eugenie-elegant-black-leaves-Clarence-House.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11211523/Princess-Eugenie-elegant-black-leaves-Clarence-House.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:49:12+00:00

The Duke of York's daughters looked elegant in a black long-sleeved dress, hat and veil as she made her way by car with their husbands ahead of the procession in London.

## Tens of thousands fall silent as Queen's coffin passes by in historic procession
 - [https://www.dailymail.co.uk/news/article-11211661/Tens-thousands-fall-silent-Queens-coffin-passes-historic-procession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211661/Tens-thousands-fall-silent-Queens-coffin-passes-historic-procession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:48:56+00:00

Tears filled the eyes of the tens of thousands of public mourners as the Queen's coffin made her final journey from Buckingham Palace this afternoon.

## Prince Andrew has his military medals pinned to his morning suit as he follows Queen's coffin
 - [https://www.dailymail.co.uk/news/article-11211755/Prince-Andrew-coffin-Queen-historic-procession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211755/Prince-Andrew-coffin-Queen-historic-procession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:47:07+00:00

Silence fell among the thousands-strong crowd as a muffled drum draped in black was beaten at 75 paces per minute.

## Defiant property developer who ripped down dozens of historic oak trees is fined more than £65,000
 - [https://www.dailymail.co.uk/news/article-11210695/Defiant-property-developer-ripped-dozens-historic-oak-trees-fined-65-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210695/Defiant-property-developer-ripped-dozens-historic-oak-trees-fined-65-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:45:36+00:00

James Barney, 35, ignored a protection order on the trees, using diggers to tear down dozens of oaks in an area of woodland at Scoreys Copse, Horton Heath, Hampshire.

## Horrifying moment female office worker is forced to fight off a PYTHON
 - [https://www.dailymail.co.uk/news/article-11211475/Horrifying-moment-female-office-worker-forced-fight-PYTHON.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211475/Horrifying-moment-female-office-worker-forced-fight-PYTHON.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:44:55+00:00

Incredible footage shows the killer reptile diving out from its hiding place to attack the admin worker as she walked through a hall in a government building in Bangkok, Thailand on September 12

## A&E nurse who helped Manchester Arena bombing victims struck off for having child sex abuse videos
 - [https://www.dailymail.co.uk/news/article-11211481/A-E-nurse-helped-Manchester-Arena-bombing-victims-struck-having-child-sex-abuse-videos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211481/A-E-nurse-helped-Manchester-Arena-bombing-victims-struck-having-child-sex-abuse-videos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:44:31+00:00

John Wadeson (pictured), 31, worked at Aintree University Hospital in Liverpool when he was found with child pornography after police raided his house in June 2020.

## Progressives who turned San Fran into a hellhole are begging for ideas to save city: DAVID MARCUS
 - [https://www.dailymail.co.uk/news/article-11206757/Progressives-turned-San-Fran-hellhole-begging-ideas-save-city-DAVID-MARCUS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206757/Progressives-turned-San-Fran-hellhole-begging-ideas-save-city-DAVID-MARCUS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:44:20+00:00

MARCUS: San Francisco is sunk in a rancid drug-ravaged pit of human misery and city leaders have no idea how to pull themselves out of it. Here's an idea - quit digging.

## London Marathon will include non-binary gender option for mass-participation runners next year
 - [https://www.dailymail.co.uk/news/article-11211619/London-Marathon-include-non-binary-gender-option-mass-participation-runners-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211619/London-Marathon-include-non-binary-gender-option-mass-participation-runners-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:42:07+00:00

Runners planning to take part in next year's London Marathon will be offered an option to identify themselves as non-binary for the first time in their ballot application.

## Margot Robbie looks VERY distressed after leaving friend Cara Delevingne's house
 - [https://www.dailymail.co.uk/news/article-11208999/Margot-Robbie-looks-distressed-leaving-friend-Cara-Delevingnes-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208999/Margot-Robbie-looks-distressed-leaving-friend-Cara-Delevingnes-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:41:37+00:00

Actress Margo Robbie has offered support to her close friend Cara Delevingne, after the British supermodel sparked health concerns with a series of disheveled  appearances in public.

## No10 says business energy bailout will be backdated to October 1
 - [https://www.dailymail.co.uk/news/article-11211587/No10-says-business-energy-bailout-backdated-October-1.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211587/No10-says-business-energy-bailout-backdated-October-1.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:34:16+00:00

Liz Truss vowed that industry will get a bailout equivalent to that for households, which will see bills frozen at £2,500. Kwasi Kwarteng (pictured) could give more details next week.

## Enormous brown bear wanders in to a California 7-Eleven and feasts on candy bars
 - [https://www.dailymail.co.uk/news/article-11211199/Enormous-brown-bear-wanders-California-7-Eleven-feasts-candy-bars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211199/Enormous-brown-bear-wanders-California-7-Eleven-feasts-candy-bars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:27:18+00:00

Cashier Christopher Kinson, 54, was working a nightshift at the store in Olympic Valley, California when looked down and spotted the brown bear helping itself to late-night snacks.

## Mike Pence BACKS federal abortion ban efforts after Graham gets mixed reception
 - [https://www.dailymail.co.uk/news/article-11211567/Mike-Pence-BACKS-federal-abortion-ban-efforts-Graham-gets-mixed-reception.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211567/Mike-Pence-BACKS-federal-abortion-ban-efforts-Graham-gets-mixed-reception.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:21:36+00:00

Pence on Tuesday stated his support for 'any and all efforts to advance the cause of life' - even as senior Republicans are keeping distance from Lindsey Graham's new 15-week ban.

## Manslaughter charge for 'drunk' golf cart driver after 18-year-old dies during joy ride
 - [https://www.dailymail.co.uk/news/article-11211347/Manslaughter-charge-drunk-golf-cart-driver-18-year-old-dies-joy-ride.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211347/Manslaughter-charge-drunk-golf-cart-driver-18-year-old-dies-joy-ride.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:21:23+00:00

Gabby Carrigan, 18, was found unconscious and not breathing when first responders arrived at the scene.

## King Charles III waves to crowds as he heads to Buckingham Palace
 - [https://www.dailymail.co.uk/news/article-11211095/King-Charles-III-waves-crowds-heads-Buckingham-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211095/King-Charles-III-waves-crowds-heads-Buckingham-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:21:12+00:00

King Charles III waved to the crowds outside Buckingham Palace before he and his sons walk behind the Queen's coffin as she leaves her London home for the final time

## 'Newlywed' couple blasted for holding photoshoot in front of Windsor Castle as mourners laid flowers
 - [https://www.dailymail.co.uk/news/article-11211463/Newlywed-couple-blasted-holding-photoshoot-Windsor-Castle-mourners-laid-flowers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211463/Newlywed-couple-blasted-holding-photoshoot-Windsor-Castle-mourners-laid-flowers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:20:11+00:00

A 'newlywed' couple have been slammed for staging an insensitive wedding photoshoot in front of the flowers and tributes laid for the Queen outside Windsor Castle on Monday

## Brisbane gang '13 Kings' believed to be behind Mansfield stabbing of Comanchero Levi Johnson
 - [https://www.dailymail.co.uk/news/article-11210887/Brisbane-gang-13-Kings-believed-Mansfield-stabbing-Comanchero-Levi-Johnson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210887/Brisbane-gang-13-Kings-believed-Mansfield-stabbing-Comanchero-Levi-Johnson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:20:02+00:00

Queensland Police revealed little is known about the street gang believed to be responsible for the hit on bikie associate Levi Johnson.

## King Charles III: New Zealand man gets royal fist bump
 - [https://www.dailymail.co.uk/news/article-11210745/King-Charles-III-New-Zealand-man-gets-royal-fist-bump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210745/King-Charles-III-New-Zealand-man-gets-royal-fist-bump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:19:49+00:00

A hilarious resurfaced video from 2019 may hold the answer as to what kind of monarch King Charles III will be with the then-Prince of Wales fist-bumping a well-wisher in New Zealand.

## London comes to a standstill ahead of the Queen's funeral
 - [https://www.dailymail.co.uk/news/article-11210761/London-comes-standstill-ahead-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210761/London-comes-standstill-ahead-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:18:21+00:00

The unprecedented demand has sparked a huge logistical operation involving the Met, MI5 and the Armed Forces with Whitehall insiders fearing that central London could actually be 'full'.

## Why 2.22pm? Experts suggest reason Queen's coffin is being moved at specific time
 - [https://www.dailymail.co.uk/news/article-11211477/Experts-suggest-reasons-Queens-coffin-moved-Westminster-Hall-precisely-2-22pm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211477/Experts-suggest-reasons-Queens-coffin-moved-Westminster-Hall-precisely-2-22pm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:17:08+00:00

Royal biographer Robert Lacey told MailOnline that the simple reason of ensuring the procession arrives at Westminster Hall at 3pm is likely to be behind the timing.

## 'Putin must be feeling to do something dramatic - possibly nuclear': US general issues stark warning
 - [https://www.dailymail.co.uk/news/article-11210709/Putin-feeling-dramatic-possibly-nuclear-general-issues-stark-warning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210709/Putin-feeling-dramatic-possibly-nuclear-general-issues-stark-warning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:10:10+00:00

Retired US Army Brigadier General Kevin Ryan said Putin may resort to using nuclear weapons in the face of a rapid Ukrainian counter-attack that is continuing to gain ground.

## ITV cancels FIVE daytime shows to make way for rolling news coverage of the late Queen
 - [https://www.dailymail.co.uk/tvshowbiz/article-11206395/ITV-cancels-FIVE-daytime-shows-make-way-rolling-news-coverage-late-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11206395/ITV-cancels-FIVE-daytime-shows-make-way-rolling-news-coverage-late-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:08:46+00:00

ITV have cancelled five major daytime TV shows on Wednesday to make way for rolling news coverage of  the Queen's coffin being moved from Buckingham Palace to Westminster Hall.

## Prominent Georgia attorney and CNN legal contributor drowns while swimming off the coast of Georgia
 - [https://www.dailymail.co.uk/news/article-11211351/Prominent-Georgia-attorney-CNN-legal-contributor-drowns-swimming-coast-Georgia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211351/Prominent-Georgia-attorney-CNN-legal-contributor-drowns-swimming-coast-Georgia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 13:01:32+00:00

Page Pate, 55, died after being swept out into a rip current off the cost of St. Simons Island, Georgia, on Sunday afternoon. He had been swimming with his teenage son who managed to get to safety,

## Pet awareness week is postponed, cinema bans POPCORN and even a PHONE BOOTH has gone into mourning
 - [https://www.dailymail.co.uk/news/article-11210719/Pet-awareness-week-postponed-cinema-bans-POPCORN-PHONE-BOOTH-gone-mourning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210719/Pet-awareness-week-postponed-cinema-bans-POPCORN-PHONE-BOOTH-gone-mourning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:57:46+00:00

While the closures of supermarkets and the scrapping of hospital appointments will impact millions, many have taken joy in pointing out some of the more niche examples of 'marks of respect'.

## 'Queen Elizabeth II Day': Petition calling for annual Bank Holiday reaches 100k signatures
 - [https://www.dailymail.co.uk/news/article-11211247/Petition-calling-Queen-Elizabeth-II-Day-bank-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211247/Petition-calling-Queen-Elizabeth-II-Day-bank-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:56:29+00:00

A campaigner is calling for an additional bank holiday every year, on September 8, to mark the late monarch's passing and her record-breaking reign.

## McDonald's will shut all restaurants for Queen's funeral on Bank Holiday Monday
 - [https://www.dailymail.co.uk/news/article-11211427/McDonalds-shut-restaurants-Queen-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211427/McDonalds-shut-restaurants-Queen-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:55:22+00:00

The fast food chain said in a statement posted on Twitter that all its restaurants in the UK would close to allow staff to 'pay their respects'. The venues will reopen at 5pm on Monday.

## Russians 'begin quietly fleeing Crimea' as Ukrainian counter-attack gathers pace
 - [https://www.dailymail.co.uk/news/article-11211099/Russians-begin-quietly-fleeing-Crimea-Ukrainian-counter-attack-gathers-pace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211099/Russians-begin-quietly-fleeing-Crimea-Ukrainian-counter-attack-gathers-pace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:44:39+00:00

Russian FSB agents and those working for the occupation government in Crimea have also begun quietly trying to move their families back home, according to Ukraine's military intelligence.

## Jen Psaki makes first MSNBC appearance since hiring as she warns Trump will 'energize' Dem voters
 - [https://www.dailymail.co.uk/news/article-11210591/Jen-Psaki-makes-MSNBC-appearance-hiring-warns-Trump-energize-Dem-voters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210591/Jen-Psaki-makes-MSNBC-appearance-hiring-warns-Trump-energize-Dem-voters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:38:31+00:00

The ex-Joe Biden official, 43, appeared on last night's Alex Wagner Tonight in her first job since she was replaced by Karine Jean-Pierre in May.

## Did chess grandmaster use anal beads to beat world No.1 Magnus Carlsen? Bizarre rumour sweeps sport
 - [https://www.dailymail.co.uk/news/article-11211325/Did-chess-grandmaster-use-anal-beads-beat-world-No-1-Magnus-Carlsen-Bizarre-rumour-sweeps-sport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211325/Did-chess-grandmaster-use-anal-beads-beat-world-No-1-Magnus-Carlsen-Bizarre-rumour-sweeps-sport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:32:48+00:00

Speculation has grown online that Hans Niemann inserted wireless anal beads into his body before his victorious match against World No. 1 grandmaster Magnus Carlsen, 31, last week.

## Pensioner died after she was run over by daughter who accidentally reversed into her, inquest hears
 - [https://www.dailymail.co.uk/news/article-11211161/Pensioner-died-run-daughter-accidentally-reversed-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211161/Pensioner-died-run-daughter-accidentally-reversed-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:20:59+00:00

Doris Breen, from Walesby, near Newark suffered a traumatic brain injury after she was knocked to the ground outside her daughter Hazel Smith's house in Eckington, Derbyshire.

## Aussie who claims he is Charles and Camilla's lovechild upset at William being named Prince of Wales
 - [https://www.dailymail.co.uk/news/article-11210803/Aussie-claims-Charles-Camillas-lovechild-upset-William-named-Prince-Wales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210803/Aussie-claims-Charles-Camillas-lovechild-upset-William-named-Prince-Wales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:18:58+00:00

Queensland-based engineer Simon Charles Dorante-Day, 56, maintains that his adoptive grandmother told him on her deathbed that he was the 'secret son' of Charles and Camilla

## Migrant crossings hit record a total of 29,099 with 538 people intercepted in the Channel on Tuesday
 - [https://www.dailymail.co.uk/news/article-11211107/Migrant-crossings-hit-record-total-29-099-538-people-intercepted-Channel-Tuesday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211107/Migrant-crossings-hit-record-total-29-099-538-people-intercepted-Channel-Tuesday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:18:45+00:00

Records have once again tumbled with more people crossing the English Channel this year than ever before - with figures hitting 29,099 so far.

## Queen's coffin: What time is the procession in London today?
 - [https://www.dailymail.co.uk/news/article-11209433/Princes-William-Prince-Harry-walk-King-Charles-III-Queens-coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209433/Princes-William-Prince-Harry-walk-King-Charles-III-Queens-coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:18:40+00:00

The Queen is staying in Buckingham Palace overnight before she is transported to lie in state ahead of her funeral. Prince William and Prince Harry will escort the coffin to Westminster.

## Cinemas to screen Queen's funeral for FREE on Monday at Curzon, Vue and Arc movie theatres
 - [https://www.dailymail.co.uk/news/article-11211253/Cinemas-screen-Queens-funeral-FREE-Monday-Curzon-Vue-Arc-movie-theatres.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211253/Cinemas-screen-Queens-funeral-FREE-Monday-Curzon-Vue-Arc-movie-theatres.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:13:45+00:00

Movie theatre chains Curzon, Vue and Arc have all confirmed they will show Her Majesty's state funeral live on September 19, with free entry for those who wish to watch it.

## Taxi driver jailed for life for murdering pregnant girlfriend, 16, has second parole bid rejected
 - [https://www.dailymail.co.uk/news/article-11211391/Taxi-driver-jailed-life-murdering-pregnant-girlfriend-16-second-parole-bid-rejected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211391/Taxi-driver-jailed-life-murdering-pregnant-girlfriend-16-second-parole-bid-rejected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:13:12+00:00

EXCLUSIVE: Azhar Ali Mehmood, now 47, was jailed for life 21 years ago for starting a house fire in Telford in August 2000. It claimed the life of Lucy Lowe (pictured), 16, her sister, 17, and mother, 49.

## How Brits queued to see George VI lying in state in Westminster Hall in 1952
 - [https://www.dailymail.co.uk/news/article-11210961/How-thousands-Britons-queued-George-VI-lying-state-Westminster-Hall-1952.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210961/How-thousands-Britons-queued-George-VI-lying-state-Westminster-Hall-1952.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:13:09+00:00

In the space of just three days up to February 15, 1952, just over 301,000 people queued for nearly four miles to pay their respects to King George VI. Above: The queue opposite Parliament.

## Little girl's tear-jerking letter to the Queen telling her to look out for her great grandma
 - [https://www.dailymail.co.uk/news/article-11210759/Little-girls-tear-jerking-letter-Queen-telling-look-great-grandma.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210759/Little-girls-tear-jerking-letter-Queen-telling-look-great-grandma.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:05:43+00:00

A little girl, 8, has written a letter to the Queen, telling her 'if you see a lady with short curly hair, then that is my great grandma'. The tribute was laid down in memory of her late gran in Green Park, London

## Biden to announce plan to build $900m of EV chargers across the US at Detroit Auto Show
 - [https://www.dailymail.co.uk/news/article-11208821/Biden-announce-plan-build-900m-EV-chargers-Detroit-Auto-Show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208821/Biden-announce-plan-build-900m-EV-chargers-Detroit-Auto-Show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 12:02:10+00:00

President Joe Biden will tour the Detroit Auto Show and announce that $900 million in Bipartisan Infrastructure Law funding will go toward building electric vehicle chargers across 53,000 miles.

## Nursing home apologises for 'strippers and bingo' party after woman lap-dances on seniors in Taiwan
 - [https://www.dailymail.co.uk/news/article-11210981/Nursing-home-apologises-strippers-bingo-party-woman-lap-dances-seniors-Taiwan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210981/Nursing-home-apologises-strippers-bingo-party-woman-lap-dances-seniors-Taiwan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:58:33+00:00

The Taoyuan Veterans Home, a state-run facility in Taoyuan City, Taiwan, for retired army personnel, paid for the dancer to entertain at least 12 wheel-chair bound seniors.

## Ukraine war: Zelensky raises flag over re-captured Russian stronghold of Izyum
 - [https://www.dailymail.co.uk/news/article-11210639/Ukraine-war-Zelensky-speaks-victory-Russian-propagandists-admit-defeat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210639/Ukraine-war-Zelensky-speaks-victory-Russian-propagandists-admit-defeat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:55:45+00:00

Volodymyr Zelensky made an unexpected trip to the frontline today to help raise the Ukrainian flag over the recaptured city of Izyum, which until last week had served as a Russian stronghold.

## Who is Kim Jong Un's mystery woman?
 - [https://www.dailymail.co.uk/news/article-11211073/Who-Kim-Jong-Uns-mystery-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211073/Who-Kim-Jong-Uns-mystery-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:53:45+00:00

The unidentified woman was snapped standing close to Kim in several images, typically wearing a plain dark suit and clutching a handbag. Some believe she may be Kim's half sister.

## Brandon Woolven sentenced to 11 years jail after raping woman in woodland at random in daylight
 - [https://www.dailymail.co.uk/news/article-11211175/Brandon-Woolven-sentenced-11-years-jail-raping-woman-woodland-random-daylight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211175/Brandon-Woolven-sentenced-11-years-jail-raping-woman-woodland-random-daylight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:46:26+00:00

Brandon Woolven, 22, pleaded guilty to rape, two counts of sexual assault, and two counts of assault occasioning actual bodily harm after the 'horrifying' attack in South Yorkshire in April 2022.

## Princess of Wales wore the Queen's delicate earrings to Buckingham Palace
 - [https://www.dailymail.co.uk/femail/article-11211307/Princess-Wales-wore-Queens-delicate-earrings-Buckingham-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11211307/Princess-Wales-wore-Queens-delicate-earrings-Buckingham-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:41:00+00:00

Kate, 40, donned a simple pair of pearl and diamond earrings as she joined her husband Prince William and other senior royals at Buckingham Palace last night.

## Britney's ex Jason Alexander wanted after failing to appear in court over 'theft of bracelet'
 - [https://www.dailymail.co.uk/news/article-11211081/Britneys-ex-Jason-Alexander-wanted-failing-appear-court-theft-bracelet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211081/Britneys-ex-Jason-Alexander-wanted-failing-appear-court-theft-bracelet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:38:28+00:00

The 40-year-old, who was married to the popstar for three days in 2004, was due to appear in court yesterday over the theft charge but did not show up.

## Vegetarian Bristol restaurant becomes first in Britain to add carbon emissions count to its menu
 - [https://www.dailymail.co.uk/news/article-11211131/Vegetarian-Bristol-restaurant-Britain-add-carbon-emissions-count-menu.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211131/Vegetarian-Bristol-restaurant-Britain-add-carbon-emissions-count-menu.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:35:15+00:00

Vegetarian restaurant The Canteen in Bristol is stretching its green muscles by being the first in Britain to add carbon emissions to its menu - showing the environmental cost of every meal.

## Arrest warrant for millionaire's son, 29, who failed to do community service for fake gun threats
 - [https://www.dailymail.co.uk/news/article-11211127/Arrest-warrant-millionaires-son-29-failed-community-service-fake-gun-threats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211127/Arrest-warrant-millionaires-son-29-failed-community-service-fake-gun-threats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:31:18+00:00

Oliver George, 29, has carried out just 27 hours and 15 minutes of his 200 hours unpaid work after threatening bar staff at a yacht club in Poole with a  fake gun in September 2019.

## Fracking industry 'lobbies Government to allow it to cause BIGGER EARTHQUAKES under homes'
 - [https://www.dailymail.co.uk/news/article-11211243/Fracking-industry-lobbies-Government-allow-cause-BIGGER-EARTHQUAKES-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211243/Fracking-industry-lobbies-Government-allow-cause-BIGGER-EARTHQUAKES-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:28:31+00:00

Liz Truss announced she plans to relax the ban on new UK drilling sites after taking over as Prime Minister as the nation faces an energy price crunch.

## Queen's tattoo tributes: Artists reveal body art in memory of the late monarch
 - [https://www.dailymail.co.uk/news/article-11210837/Queens-tattoo-tributes-Artists-reveal-body-art-memory-late-monarch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210837/Queens-tattoo-tributes-Artists-reveal-body-art-memory-late-monarch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:15:45+00:00

One tattoo shop in Windsor said that they have had numerous requests from Coldstream Guards, many of whom are stationed nearby, to 'immortalise' the monarch with body art.

## Trains to London for Queen's funeral: Which rail services are running on Bank Holiday Monday?
 - [https://www.dailymail.co.uk/news/article-11211025/Trains-London-Queens-funeral-rail-running-Bank-Holiday-Monday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211025/Trains-London-Queens-funeral-rail-running-Bank-Holiday-Monday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:15:38+00:00

Southeastern, Chiltern Railways, Great Western Railway confirmed they will all run overnight services to and from London Victoria, Marylebone and Paddington stations.

## Prince Harry's book 'is a timebomb which King Charles III and Prince William wanted to defuse'
 - [https://www.dailymail.co.uk/news/article-11211049/Prince-Harrys-book-timebomb-King-Charles-III-Prince-William.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211049/Prince-Harrys-book-timebomb-King-Charles-III-Prince-William.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 11:06:41+00:00

Tom Bower, whose biography of Meghan Markle was released earlier this year, said the book would be printed at Clays in Bungay, Suffolk, under great secrecy.

## Melissa Caddick: Cop who interviewed Sydney conwoman's husband Anthony Koletti said he acted strange
 - [https://www.dailymail.co.uk/news/article-11210973/Melissa-Caddick-Cop-interviewed-Sydney-conwomans-husband-Anthony-Koletti-said-acted-strange.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210973/Melissa-Caddick-Cop-interviewed-Sydney-conwomans-husband-Anthony-Koletti-said-acted-strange.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:59:45+00:00

One of the first police officers to interview Melissa Caddick's husband said he acted strangely and faked crying after waiting nearly two days to report her disappearance.

## Teacher who waved a prosthetic penis and made suggestive movements at colleagues is struck off
 - [https://www.dailymail.co.uk/news/article-11210991/Teacher-waved-prosthetic-penis-suggestive-movements-colleagues-struck-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210991/Teacher-waved-prosthetic-penis-suggestive-movements-colleagues-struck-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:58:57+00:00

Derek Turkington (pictured) was found unfit to teach yesterday after the incident at Newbattle Community High School in Dalkeith, Scotland which occurred between August 2017 and 2018.

## Police union supports 'brave' officer involved in fatal shooting of rapper Chris Kaba in London
 - [https://www.dailymail.co.uk/news/article-11210939/Police-union-supports-brave-officer-involved-fatal-shooting-rapper-Chris-Kaba-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210939/Police-union-supports-brave-officer-involved-fatal-shooting-rapper-Chris-Kaba-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:56:32+00:00

Mr Kaba, 24, was shot in Streatham Hill, London, by armed police after a chase on September 5. The officer involved has been suspended, with his colleagues threatening to hand in their guns.

## Hollywood-owned Wrexham condemn their own fans for booing the minute's silence for the Queen
 - [https://www.dailymail.co.uk/sport/sportsnews/article-11211057/Hollywood-owned-Wrexham-condemn-fans-booing-minutes-silence-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/sportsnews/article-11211057/Hollywood-owned-Wrexham-condemn-fans-booing-minutes-silence-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:47:30+00:00

The minute's silence was disturbed from the outset with a number of supporters in the Kop end choosing to jeer during the solemn moment with others heard trying to shush them down.

## Teenage girls left 'in tears' after being put in ISOLATION because their skirts were too short
 - [https://www.dailymail.co.uk/news/article-11210999/Teenage-girls-left-tears-ISOLATION-skirts-short.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210999/Teenage-girls-left-tears-ISOLATION-skirts-short.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:46:32+00:00

Angry parents have complained their daughters were forced to line up and had their skirts measured by staff at South Wigston High School, in Leicestershire, on Monday.

## At least 11 killed and 29 injured after overcrowded school bus plunges down steep gorge in India
 - [https://www.dailymail.co.uk/news/article-11210997/At-11-killed-29-injured-overcrowded-school-bus-plunges-steep-gorge-India.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210997/At-11-killed-29-injured-overcrowded-school-bus-plunges-steep-gorge-India.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:44:48+00:00

Nearly 40 people were crammed into the minibus when the accident occurred in Indian-controlled Kashmir on Wednesday morning.

## Will Center Parcs close on Queen's funeral bank holiday?
 - [https://www.dailymail.co.uk/news/article-11210645/Will-Center-Parcs-close-Queens-funeral-bank-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210645/Will-Center-Parcs-close-Queens-funeral-bank-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:44:45+00:00

Center Parcs was forced into an embarrassing U-turn after being contacted by thousands of furious families whose holiday plans were left in tatters by the company's plan to turf them out at 10am Monday.

## The Queen's circle of trust: How the monarch relied on a select number of women throughout her life
 - [https://www.dailymail.co.uk/femail/article-10708169/The-Queens-circle-trust-monarch-relied-select-number-women-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-10708169/The-Queens-circle-trust-monarch-relied-select-number-women-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:26:38+00:00

Throughout her life as Britain's longest-reigning monarch, the Queen surrounded herself with a tight circle of friends upon whom she could trust and rely.

## US couple make 'terrifying' journey through war-torn Ukraine to meet their pregnant surrogate
 - [https://www.dailymail.co.uk/news/article-11211027/US-couple-make-terrifying-journey-war-torn-Ukraine-meet-pregnant-surrogate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11211027/US-couple-make-terrifying-journey-war-torn-Ukraine-meet-pregnant-surrogate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:13:40+00:00

After struggling to fall pregnant naturally as well as four unsuccessful years of fertility treatments, Audrey and George, from Atlanta, decided to go down the route of surrogacy - in Ukraine.

## Liz Truss accused of 'personally' ordering the sacking of top Treasury mandarin Sir Tom Scholar
 - [https://www.dailymail.co.uk/news/article-11210941/Liz-Truss-accused-personally-ordering-sacking-Treasury-mandarin-Sir-Tom-Scholar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210941/Liz-Truss-accused-personally-ordering-sacking-Treasury-mandarin-Sir-Tom-Scholar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:13:38+00:00

Sir Tom Scholar was removed as the Treasury's permanent secretary last week in one of the first acts of Liz Truss's incoming Government.

## King Charles III's 'swollen fingers' prompts New Zealand butcher to sell 'King Charles sausages'
 - [https://www.dailymail.co.uk/news/article-11210525/King-Charles-IIIs-swollen-fingers-prompts-New-Zealand-butcher-sell-King-Charles-sausages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210525/King-Charles-IIIs-swollen-fingers-prompts-New-Zealand-butcher-sell-King-Charles-sausages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:13:36+00:00

Avon's Butchery in Auckland announced in a series of posts to social media on Wednesday that they'd be stocking the specially-named sausages for a limited time.

## Indigenous protest on Queen's national day of mourning in Brisbane: Warriors Aboriginal Resistance
 - [https://www.dailymail.co.uk/news/article-11210495/Indigenous-protest-Queens-national-day-mourning-Brisbane-Warriors-Aboriginal-Resistance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210495/Indigenous-protest-Queens-national-day-mourning-Brisbane-Warriors-Aboriginal-Resistance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 10:11:32+00:00

An Indigenous group will protest in the streets of Brisbane for Australia's day of national mourning for Queen Elizabeth II on September 22.

## Perfumer 'sacked for sending 'suspicious' work emails to her personal account with secret formulas'
 - [https://www.dailymail.co.uk/news/article-11210893/Perfumer-sacked-sending-suspicious-work-emails-personal-account-secret-formulas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210893/Perfumer-sacked-sending-suspicious-work-emails-personal-account-secret-formulas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 09:58:03+00:00

Madly Massengo, who worked at CPL Aromas in Bishops Stortford, Herts, sent messages from work to a personal email with details including materials, formulas and pricing, a tribunal heard.

## Kumanjayi Walker inquest: Former NT cop Zachary Rolfe sent racist texts to colleagues
 - [https://www.dailymail.co.uk/news/article-11210535/Kumanjayi-Walker-inquest-Former-NT-cop-Zachary-Rolfe-sent-racist-texts-colleagues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210535/Kumanjayi-Walker-inquest-Former-NT-cop-Zachary-Rolfe-sent-racist-texts-colleagues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 09:50:42+00:00

Indigenous teenager Kumanjayi Walker was shot by former NT cop Zachary Rolfe, with an inquest hearing a series of racist text he sent colleagues in the months leading up.

## Legendary director Jean-Luc Godard died by assisted suicide in Switzerland
 - [https://www.dailymail.co.uk/news/article-11210579/Legendary-director-Jean-Luc-Godard-died-assisted-suicide-Switzerland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210579/Legendary-director-Jean-Luc-Godard-died-assisted-suicide-Switzerland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 09:49:40+00:00

The legendary Franco-Swiss movie-maker's lawyer confirmed this morning that Godard chose to end his life aged 91 after a long battle with 'multiple invalidating illnesses'

## David Davis writes to police to express concern after anti-royal protester charged in Edinburgh
 - [https://www.dailymail.co.uk/news/article-11210661/David-Davis-writes-police-express-concern-anti-royal-protester-charged-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210661/David-Davis-writes-police-express-concern-anti-royal-protester-charged-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 09:39:47+00:00

A 22-year-old woman was arrested after holding up an anti-monarchy placard (pictured) in Edinburgh on Sunday and was subsequently charged 'in connection with a breach of the pace'.

## Amateur football teams under investigation for playing friendly game on weekend after Queen's death
 - [https://www.dailymail.co.uk/news/article-11210715/Amateur-football-teams-investigation-playing-friendly-game-weekend-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210715/Amateur-football-teams-investigation-playing-friendly-game-weekend-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 09:35:10+00:00

Sheffield International FC and Byron House, who both compete in the Sheffield and District Fair Play League, had been due to play a match on Saturday, September 10.

## EY death: Australian CEO David Larocca is trolled on LinkedIn over Aishwarya Venkatachalam suicide
 - [https://www.dailymail.co.uk/news/article-11209917/EY-death-Australian-CEO-David-Larocca-trolled-LinkedIn-Aishwarya-Venkatachalam-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209917/EY-death-Australian-CEO-David-Larocca-trolled-LinkedIn-Aishwarya-Venkatachalam-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 09:19:30+00:00

David Larocca has come under fire for his firm's reaction to the tragedy  after Aishwarya Venkatachalam, 27, plunged to her death from the 11th floor.

## Sophie, Countess of Wessex, in line to be Duchess of Edinburgh
 - [https://www.dailymail.co.uk/news/article-11209691/Sophie-Countess-Wessex-line-Duchess-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209691/Sophie-Countess-Wessex-line-Duchess-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 08:51:44+00:00

Sophie the Countess of Wessex (pictured) is now in line to be elevated to become Duchess of Edinburgh if her husband Prince Edward takes his late father's title as Duke of Edinburgh as expected.

## Liz Truss due to meet Irish premier Micheal Martin to talk Brexit after Queen's funeral on Monday
 - [https://www.dailymail.co.uk/news/article-11210857/Liz-Truss-meet-Irish-premier-Micheal-Martin-talk-Brexit-Queens-funeral-Monday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210857/Liz-Truss-meet-Irish-premier-Micheal-Martin-talk-Brexit-Queens-funeral-Monday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 08:44:18+00:00

They are expected to meet after the Taoiseach represents Ireland at the Westminster Abbey ceremony on Monday.

## Teacher jailed following refusal to use gender-neutral pronouns at school appears in court today
 - [https://www.dailymail.co.uk/news/article-11210569/Teacher-jailed-following-refusal-use-gender-neutral-pronouns-school-appears-court-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210569/Teacher-jailed-following-refusal-use-gender-neutral-pronouns-school-appears-court-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 08:19:44+00:00

Enoch Burke, an evangelical Christian, has spent more than a week in Mounjoy jail in Dublin after he refused to comply with an injunction that forbade him to teach at his Irish school.

## Australia won't become republic for another generation BECAUSE of Queen's death, Mark Latham argues
 - [https://www.dailymail.co.uk/news/article-11210149/Australia-wont-republic-generation-Queens-death-Mark-Latham-argues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210149/Australia-wont-republic-generation-Queens-death-Mark-Latham-argues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 08:19:01+00:00

Australia is at least a generation away from becoming a republic due to the great love shown for the monarchy after the Queen's death, according to One Nation NSW MP Mark Latham.

## Why an overwhelming majority of Australians want to REMAIN under the Monarchy
 - [https://www.dailymail.co.uk/news/article-11205341/Why-overwhelming-majority-Australians-want-REMAIN-Monarchy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205341/Why-overwhelming-majority-Australians-want-REMAIN-Monarchy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 08:12:57+00:00

An increasing majority of Australians wish to remain under the Monarchy following the death of Queen Elizabeth II - according to a recent survey.

## Daily Mail appeals Erin Molan's defamation win over 'hooka looka mooka hooka fooka' comments
 - [https://www.dailymail.co.uk/news/article-11210231/Daily-Mail-appeals-Erin-Molans-defamation-win-hooka-looka-mooka-hooka-fooka-comments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210231/Daily-Mail-appeals-Erin-Molans-defamation-win-hooka-looka-mooka-hooka-fooka-comments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 07:40:32+00:00

Erin Molan's $150,000 payout is  under threat as Daily Mail Australia launches an appeal against her  defamation win.

## Golf mind coach Sean Lynch 'manipulated girl' before engaging in indecent acts, court heard
 - [https://www.dailymail.co.uk/news/article-11210453/Golf-mind-coach-Sean-Lynch-manipulated-girl-engaging-indecent-acts-court-heard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210453/Golf-mind-coach-Sean-Lynch-manipulated-girl-engaging-indecent-acts-court-heard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 07:15:10+00:00

A successful mind coach and golf mentor Sean Patrick Lynch is accused of using the skills once shared with a world No.1 golfer to manipulate a girl before engaging in  indecent acts.

## LifeFlight helicopter rescue Queensland: Watch moment man who plunged down 30 metre cliff is rescued
 - [https://www.dailymail.co.uk/news/article-11210347/LifeFlight-helicopter-rescue-Queensland-Watch-moment-man-plunged-30-metre-cliff-rescued.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210347/LifeFlight-helicopter-rescue-Queensland-Watch-moment-man-plunged-30-metre-cliff-rescued.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 06:58:35+00:00

Queensland emergency services had to mount a dramatic clifftop rescue after a young man working on trees at Coolum suffered a medical episode and fell 30 metres onto rocks below.

## Adelaide special needs dentist Trudy Lin 'incredibly humbled' after invite to Queen's Funeral
 - [https://www.dailymail.co.uk/news/article-11210317/Adelaide-special-needs-dentist-Trudy-Lin-incredibly-humbled-invite-Queens-Funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210317/Adelaide-special-needs-dentist-Trudy-Lin-incredibly-humbled-invite-Queens-Funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 06:32:41+00:00

A South Australian special needs dentist who will be attending the Queen's funeral was 'incredibly humbled' by the invitation and hopes it will bring recognition to those who work in her field.

## Sydney's Royal National Park: Horror black sludge pollution discovered in a creek
 - [https://www.dailymail.co.uk/news/article-11209777/Sydneys-Royal-National-Park-Horror-black-sludge-pollution-discovered-creek.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209777/Sydneys-Royal-National-Park-Horror-black-sludge-pollution-discovered-creek.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 06:20:31+00:00

Idyllic creeks and rivers in Sydney's Royal National Park have turned black, horrifying visitors after a US mining company allegedly allowed coal waste into waterways after heavy rain.

## Wide Bay Region Queensland residents warned to vaccinate against Q Fever
 - [https://www.dailymail.co.uk/news/article-11210195/Wide-Bay-Region-Queensland-residents-warned-vaccinate-against-Q-Fever.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210195/Wide-Bay-Region-Queensland-residents-warned-vaccinate-against-Q-Fever.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 06:16:05+00:00

A rare bacterial disease spread by animal particles has doubled its average transmission this year with residents in affected areas warned to vaccinate and wear a P2 face mask while mowing.

## 2GB broadcaster Ben Fordham claims solar panels have environmental issues
 - [https://www.dailymail.co.uk/news/article-11209977/2GB-broadcaster-Ben-Fordham-claims-solar-panels-environmental-issues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209977/2GB-broadcaster-Ben-Fordham-claims-solar-panels-environmental-issues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 06:15:00+00:00

Solar power is expected to make up 50 per cent of Australia's energy capacity by 2030. But one Sydney broadcaster has raised raised questions over the 'fragile' and 'flawed' business case for them.

## Dozens of illegal immigrants dressed in camouflage use rope to scale the border wall
 - [https://www.dailymail.co.uk/news/article-11210203/Dozens-illegal-immigrants-dressed-camouflage-use-rope-scale-border-wall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210203/Dozens-illegal-immigrants-dressed-camouflage-use-rope-scale-border-wall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 05:53:51+00:00

Dozens of immigrants crossed into Naco, Arizona illegally while dress in camouflage on Tuesday as they scaled a border wall and maneuvered past barbed wire fencing.

## Tennessee man, 39, accused of beating his new bride to death on Fijian honeymoon is denied bail
 - [https://www.dailymail.co.uk/news/article-11210171/Tennessee-man-39-accused-beating-new-bride-death-Fijian-honeymoon-denied-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210171/Tennessee-man-39-accused-beating-new-bride-death-Fijian-honeymoon-denied-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 05:49:11+00:00

Bradley Dawson, 39, appeared in the High Court in Fiji's second-largest city, Lautoka, on Wednesday afternoon, and was denied bail by Judge Riyaz Hamza.

## Prisoners made to watch a newborn baby die inside Dame Phyllis Frost to give evidence in Melbourne
 - [https://www.dailymail.co.uk/news/article-11209899/Prisoners-watch-newborn-baby-die-inside-Dame-Phyllis-Frost-evidence-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209899/Prisoners-watch-newborn-baby-die-inside-Dame-Phyllis-Frost-evidence-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 05:48:53+00:00

Four new mothers forced to watch a fellow mum beg for help as prison staff refused to help her child are set to front an inquest into the baby's death.

## Lily van de Putte: Buxton crash victim's dad John tells of final kiss goodbye
 - [https://www.dailymail.co.uk/news/article-11209791/Lily-van-Putte-Buxton-crash-victims-dad-John-tells-final-kiss-goodbye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209791/Lily-van-Putte-Buxton-crash-victims-dad-John-tells-final-kiss-goodbye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 04:57:55+00:00

Lily van de Putte, 15, was so worried her wheelchair-bound father wouldn't come home after surgery that she ran out into the driveway to say goodbye. That evening, she died in Buxton, NSW, that night.

## Kelly's Hotel in Cranbourne, Melbourne hits back at outrage over posts about Queen's death
 - [https://www.dailymail.co.uk/news/article-11209395/Kellys-Hotel-Cranbourne-Melbourne-hits-outrage-posts-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209395/Kellys-Hotel-Cranbourne-Melbourne-hits-outrage-posts-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 04:53:09+00:00

Kelly's Hotel in Cranbourne in Melbourne's south-east has hit back at the backlash over its posts about the Queen, which the manager claims was a big misunderstanding.

## Melissa Caddick inquest hears Anthony Koletti told police his wife was at Meriton Bondi Junction
 - [https://www.dailymail.co.uk/news/article-11210121/Melissa-Caddick-inquest-hears-Anthony-Koletti-told-police-wife-Meriton-Bondi-Junction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210121/Melissa-Caddick-inquest-hears-Anthony-Koletti-told-police-wife-Meriton-Bondi-Junction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 04:51:01+00:00

A coronial inquest into the disappearance of conwoman Melissa Caddick was read a police interview transcript where her husband, Anthony Koletti, said she could be hiding at a hotel in Bondi

## Huge fire erupts at car wrecking yard in Brendale, Queensland
 - [https://www.dailymail.co.uk/news/article-11210215/Huge-fire-erupts-car-wrecking-yard-Brendale-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210215/Huge-fire-erupts-car-wrecking-yard-Brendale-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 04:48:01+00:00

A huge fire has erupted at a car wrecking yard with nearby residents told to close their windows and plumes of smoke fly into the sky.

## Former First Daughter Sasha Obama is nearly unrecognizable in glasses and low slung jeans
 - [https://www.dailymail.co.uk/news/article-11210099/Former-Daughter-Sasha-Obama-nearly-unrecognizable-glasses-low-slung-jeans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210099/Former-Daughter-Sasha-Obama-nearly-unrecognizable-glasses-low-slung-jeans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 04:26:09+00:00

The youngest daughter of former President Barack Obama was seen with a pink top and ripped jean shorts, which hung low enough to reveal a bit of white underwear while walking around campus.

## Wild theory erupts about a 'device' hidden in Meghan Markle's outfit at Windsor Castle
 - [https://www.dailymail.co.uk/news/article-11209771/Wild-theory-erupts-device-hidden-Meghan-Markles-outfit-Windsor-Castle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209771/Wild-theory-erupts-device-hidden-Meghan-Markles-outfit-Windsor-Castle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 04:25:27+00:00

A wild theory that Meghan Markle was wearing a 'recording device' underneath her dress has been shut down.

## Adelaide teenager dies in car crash, just minutes after fleeing from a police stop
 - [https://www.dailymail.co.uk/news/article-11209841/Adelaide-teenager-dies-car-crash-just-minutes-fleeing-police-stop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209841/Adelaide-teenager-dies-car-crash-just-minutes-fleeing-police-stop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 04:15:23+00:00

A teenager has died in a road crash, just minutes after police tried to stop the car he was travelling in. Three people were seen running from the scene and the teen was found lying on the ground.

## Man is rushed to hospital after being bit by a brown snake in Western Sydney Parklands
 - [https://www.dailymail.co.uk/news/article-11210167/Man-rushed-hospital-bit-brown-snake-Western-Sydney-Parklands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11210167/Man-rushed-hospital-bit-brown-snake-Western-Sydney-Parklands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 03:56:32+00:00

A man has been bitten on the ankle by a brown snake while at a popular nature reserve in Sydney's west.

## Is Gladys Berejiklian about to take her relationship with Arthur Moses to the next level?
 - [https://www.dailymail.co.uk/news/article-11209643/Is-Gladys-Berejiklian-relationship-Arthur-Moses-level.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209643/Is-Gladys-Berejiklian-relationship-Arthur-Moses-level.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 03:43:59+00:00

Former NSW premier Gladys Berejiklian's romance with Arthur Moses, the barrister who represented her at a corruption inquiry, is rumoured to have moved to a new level.

## Thomas Myler and Kyle Martin wanted by police over the murder of Comanchero associate Levi Johnson
 - [https://www.dailymail.co.uk/news/article-11209967/Thomas-Myler-Kyle-Martin-wanted-police-murder-Comanchero-associate-Levi-Johnson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209967/Thomas-Myler-Kyle-Martin-wanted-police-murder-Comanchero-associate-Levi-Johnson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 03:21:24+00:00

Police are hunting for two men Thomas Myler, 35, and Kyle Martin, 24, in connection with the murder of Comancheros associate Levi Maurice Johnson in Brisbane on Monday.

## American man fly to Australia to meet online girlfriend of two years
 - [https://www.dailymail.co.uk/news/article-11209583/American-man-fly-Australia-meet-online-girlfriend-two-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209583/American-man-fly-Australia-meet-online-girlfriend-two-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 02:54:32+00:00

An American man that flew 20 hours to meet his girlfriend of two years in person for the first time left the country just a few days after arriving.

## Anthony Albanese blows up AGAIN over Queen on $5 note question
 - [https://www.dailymail.co.uk/news/article-11209911/Anthony-Albanese-blows-Queen-5-note-question.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209911/Anthony-Albanese-blows-Queen-5-note-question.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 02:54:14+00:00

Anthony Albanese has told off another journalist for asking who will replace Queen Elizabeth II on the Australian $5 while announcing extended Covid sick leave payments.

## Shooting inside Chicago's Washington Park during a baseball game leaves multiple people hospitalized
 - [https://www.dailymail.co.uk/news/article-11209933/Shooting-inside-Chicagos-Washington-Park-baseball-game-leaves-multiple-people-hospitalized.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209933/Shooting-inside-Chicagos-Washington-Park-baseball-game-leaves-multiple-people-hospitalized.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 02:47:18+00:00

At least four people were shot in Chicago's Washington Park during a baseball game on Tuesday night around 8 pm.

## Aurelio Gallo suffers second major blow over emails to Victoria's Secret model Bridget Malcolm
 - [https://www.dailymail.co.uk/news/article-11209515/Aurelio-Gallo-suffers-second-major-blow-emails-Victorias-Secret-model-Bridget-Malcolm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209515/Aurelio-Gallo-suffers-second-major-blow-emails-Victorias-Secret-model-Bridget-Malcolm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 02:35:07+00:00

A music teacher at a prestigious Australian high school has had his licence suspended after sending a series of inappropriate emails to former student and ex Victoria Secret Model Bridget Malcolm.

## Authorities say terrorism is a possibility after package explodes at a Boston University
 - [https://www.dailymail.co.uk/news/article-11209811/Authorities-say-terrorism-possibility-two-packages-exploded-Boston-University.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209811/Authorities-say-terrorism-possibility-two-packages-exploded-Boston-University.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 01:53:42+00:00

Terrorism cannot be ruled out by authorities after a package exploded at Boston's Northeastern University, leaving at least one person injured and taken to hospital.

## Juliana Castrillon vanishes from Orin Aya festival after hiking through Far North Queensland
 - [https://www.dailymail.co.uk/news/article-11209629/Juliana-Castrillon-vanishes-Orin-Aya-festival-hiking-Far-North-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209629/Juliana-Castrillon-vanishes-Orin-Aya-festival-hiking-Far-North-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 01:45:24+00:00

Juliana Jaramillo Castrillon, 36, was last seen on a hike from Cedar Bay to Home Rule, near Rossville, north of Cairns, on Saturday morning.

## KFC secret recipe: Uproar after additive in fried chicken seasoning is exposed
 - [https://www.dailymail.co.uk/news/article-11209485/KFC-secret-recipe-Uproar-additive-fried-chicken-seasoning-exposed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209485/KFC-secret-recipe-Uproar-additive-fried-chicken-seasoning-exposed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 01:40:11+00:00

A KFC customer found a controversial ingredient used in the fast food chain's seasoning and questioned why it was used - but Australian food groups say the additive is safe.

## Man who 'beheaded his ex-girlfriend with sword' is in the US legally, despite previous reports
 - [https://www.dailymail.co.uk/news/article-11209477/Man-beheaded-ex-girlfriend-sword-legally-despite-previous-reports.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209477/Man-beheaded-ex-girlfriend-sword-legally-despite-previous-reports.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 01:35:49+00:00

Jose Raphael Solano Landaeta, 33, accused of beheading his ex-girlfriend Karina Castro, 27, in broad daylight is a US citizen despite previous reports claiming he was in America illegally.

## Mourners wanting to use West Coast Main Line to pay respects to the Queen face chaos
 - [https://www.dailymail.co.uk/news/article-11209703/Mourners-wanting-use-West-Coast-Main-Line-pay-respects-Queen-face-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209703/Mourners-wanting-use-West-Coast-Main-Line-pay-respects-Queen-face-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 01:30:08+00:00

A long-running row over pay and working conditions on the 399-mile Avanti west coast mainline is set to impact mourners attempting to travel to the capital over the weekend to pay respects to Queen.

## Sophie in line to be Duchess of Edinburgh as daughter-in-law who called Queen 'mama' takes new role
 - [https://www.dailymail.co.uk/news/article-11209691/Sophie-line-Duchess-Edinburgh-daughter-law-called-Queen-mama-takes-new-role.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209691/Sophie-line-Duchess-Edinburgh-daughter-law-called-Queen-mama-takes-new-role.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 01:26:16+00:00

Sophie the Countess of Wessex (pictured) is now in line to be elevated to become Duchess of Edinburgh if her husband Prince Edward takes his late father's title as Duke of Edinburgh as expected.

## A third of Britain's reservoirs are STILL exceptionally low meaning water restrictions on the cards
 - [https://www.dailymail.co.uk/news/article-11209767/A-Britains-reservoirs-exceptionally-low-meaning-water-restrictions-cards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209767/A-Britains-reservoirs-exceptionally-low-meaning-water-restrictions-cards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 01:17:12+00:00

Reservoirs across the UK dropped far below their normal levels during weeks of dry and hot weather as temperatures hit a record-breaking 40C. Water companies could now introduce new restrictions.

## Humiliation for Putin's troops continues as they now begin to abandon major city Melitopol
 - [https://www.dailymail.co.uk/news/article-11209751/Humiliation-Putins-troops-continues-begin-abandon-major-city-Melitopol.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209751/Humiliation-Putins-troops-continues-begin-abandon-major-city-Melitopol.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 01:11:08+00:00

The city's pre-occupation mayor said that Russian troops were pulling out of the area in Ukraine's southern Zaporizhzhia region.

## Police appeal for information into the death of Tiffani Scholten on April 18 in Coomera, Queensland
 - [https://www.dailymail.co.uk/news/article-11209665/Police-appeal-information-death-Tiffani-Scholten-April-18-Coomera-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209665/Police-appeal-information-death-Tiffani-Scholten-April-18-Coomera-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 01:09:34+00:00

Police are seeking public assistance as they investigate the sudden death of 12-year-old girl Tiffany Scholten, who was found unresponsive at a home in Coomera, Queensland on April 18.

## NYPD officer who 'wasn't happy in patrol' kills himself by jumping from a Bronx bridge
 - [https://www.dailymail.co.uk/news/article-11209639/NYPD-officer-wasnt-happy-patrol-kills-jumping-Bronx-bridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209639/NYPD-officer-wasnt-happy-patrol-kills-jumping-Bronx-bridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 01:09:10+00:00

Scott Cohn, an officer with the 90th police precinct in Brooklyn, left his car on the Throgs Neck Bridge in the Bronx and jumped to his death. His body was found on Tuesday.

## 97 members of Congress or families bought or sold stock that may have been a conflict of interest
 - [https://www.dailymail.co.uk/news/article-11209689/97-members-Congress-families-bought-sold-stock-conflict-interest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209689/97-members-Congress-families-bought-sold-stock-conflict-interest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:59:29+00:00

Nearly 100 members of Congress bought or sold financial assets that intersected with the work of the committees they sit on, according to a New York Times report.

## EPHRAIM HARDCASTLE: Did Labour MP dodge allegiance to the King?
 - [https://www.dailymail.co.uk/news/article-11209647/EPHRAIM-HARDCASTLE-Did-Labour-MP-dodge-allegiance-King.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209647/EPHRAIM-HARDCASTLE-Did-Labour-MP-dodge-allegiance-King.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:58:48+00:00

EPHRAIM HARDCASTLE: Charles Moore spotted one Labour MP who crossed his fingers behind his back while taking the oath in an attempt to avoid swearing allegiance to King Charles.

## Duke of Marlborough is ordered to hand back the keys of his £132k Porsche Cayenne
 - [https://www.dailymail.co.uk/news/article-11209723/Duke-Marlborough-ordered-hand-keys-132k-Porsche-Cayenne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209723/Duke-Marlborough-ordered-hand-keys-132k-Porsche-Cayenne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:56:56+00:00

The 12th Duke of Marlborough, Charles James Spencer Churchill, pictured, paid £68,000 towards a Porsche Cayenne in 2018 and agreed to settle the balance by installments.

## Albany WA: Killer kangaroo kept paramedics from saving alpaca breeder Peter Eades
 - [https://www.dailymail.co.uk/news/article-11209605/Albany-WA-Killer-kangaroo-kept-paramedics-saving-alpaca-breeder-Peter-Eades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209605/Albany-WA-Killer-kangaroo-kept-paramedics-saving-alpaca-breeder-Peter-Eades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:55:01+00:00

Alpaca breeder Peter Eades, 77, was killed when his pet roo suddenly turned on him, unleashing a violent attack which left the elderly man mortally wounded.

## Nancy Pelosi has her own 'please clap' moment at event celebrating Biden's Inflation Reduction Act
 - [https://www.dailymail.co.uk/news/article-11209555/Nancy-Pelosi-clap-moment-event-celebrating-Bidens-Inflation-Reduction-Act.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209555/Nancy-Pelosi-clap-moment-event-celebrating-Bidens-Inflation-Reduction-Act.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:54:52+00:00

Nancy Pelosi awkwardly asked an audience to clap for her praises of Joe Biden and his Inflation Reduction Act on Tuesday, in a moment evocative of Jeb Bush's 'please clap' incident.

## ASX plunges with billions wiped off sharemarket in minutes after Barefoot Investor prediction
 - [https://www.dailymail.co.uk/news/article-11205443/Barefoot-Investor-Scott-Pape-warns-overdue-ASX-stock-market-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205443/Barefoot-Investor-Scott-Pape-warns-overdue-ASX-stock-market-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:53:53+00:00

Scott Pape, also known as the Barefoot Investor, cautions Australia is overdue for a share market crash because the Global Financial Crisis was more than a decade ago in 2008.

## Fresh tax row as activists call for the King to pay £148m on inheritance from Queen's estate
 - [https://www.dailymail.co.uk/news/article-11209621/Fresh-tax-row-activists-call-King-pay-148m-inheritance-Queens-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209621/Fresh-tax-row-activists-call-King-pay-148m-inheritance-Queens-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:49:04+00:00

Some members of the public agreed with tax campaigners that it was a 'joke' that ordinary, middle-class families are forced to pay inheritance tax on their wealth while the King is exempt.

## Disney Cruises are coming to Australia and New Zealand
 - [https://www.dailymail.co.uk/news/article-11209251/Disney-Cruises-coming-Australia-New-Zealand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209251/Disney-Cruises-coming-Australia-New-Zealand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:35:26+00:00

The famous Disney Cruise Line is coming to Australia and New Zealand for the first time. Cruises will set sail from four major ports over four months from October next year.

## DAILY MAIL COMMENT: No second chance for this greatest farewell
 - [https://www.dailymail.co.uk/news/article-11209641/DAILY-MAIL-COMMENT-No-second-chance-greatest-farewell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209641/DAILY-MAIL-COMMENT-No-second-chance-greatest-farewell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:32:31+00:00

DAILY MAIL COMMENT: A homecoming, but the most sorrowful sort. Under shroud-black skies last night, the Queen arrived at Buckingham Palace for the final time.

## Penny Lancaster spotted wearing police uniform at RAF Northolt in front of Queen's coffin
 - [https://www.dailymail.co.uk/femail/article-11206603/Penny-Lancaster-spotted-wearing-police-uniform-RAF-Northolt-Queens-coffin-arrive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11206603/Penny-Lancaster-spotted-wearing-police-uniform-RAF-Northolt-Queens-coffin-arrive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:21:40+00:00

Penny Lancaster was spotted in her police uniform at RAF Northolt, where the Queen's coffin will arrive this evening after leaving Edinburgh earlier today.

## Petition launched for annual 'Queen Elizabeth Day' bank holiday
 - [https://www.dailymail.co.uk/news/article-11209563/Petition-launched-annual-Queen-Elizabeth-Day-bank-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209563/Petition-launched-annual-Queen-Elizabeth-Day-bank-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:15:50+00:00

The petition was started by John Harris on Change.org and proposes that September 8, the day she died, is made into a Queen Elizabeth II Day to honour her each year.

## Queensland issues warning about massive 'problem' crocodiles stalking boats and fishermen
 - [https://www.dailymail.co.uk/news/article-11209505/Queensland-issues-warning-massive-problem-crocodiles-stalking-boats-fishermen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209505/Queensland-issues-warning-massive-problem-crocodiles-stalking-boats-fishermen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-14 00:14:11+00:00

The capture of two huge crocodiles in northern Australia has led the Queensland government to renew warnings to the public including advising people not to camp near their habitats.


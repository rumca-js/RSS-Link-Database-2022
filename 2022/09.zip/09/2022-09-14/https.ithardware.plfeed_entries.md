# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Podsumowanie newsów ITHardware - tydzień 74. Sprawdź co Cię ominęło
 - [https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_siedemdziesiaty_czwarty_wrzesien_2022-23285.html](https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_siedemdziesiaty_czwarty_wrzesien_2022-23285.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 20:10:00+00:00

<img src="https://ithardware.pl/artykuly/min/23285_1.jpg" />            Jak co tydzień zapraszamy naszych czytelnik&oacute;w do odwiedzenia kanału&nbsp;ITHardware na YouTube i do zapoznania się z materiałem prezentującym najważniejsze wydarzenia minionych 7 dni.

Za powstanie wideo odpowiada&nbsp;nasz redakcyjny...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_siedemdziesiaty_czwarty_wrzesien_2022-23285.html">https://ithardware.pl/aktual

## vivo prezentuje smartfon z najnowszym procesorem Qualcomma
 - [https://ithardware.pl/aktualnosci/vivo_iqoo_z6_lite_z_procesorem_snapdragon_4_gen_1_zaprezentowany-23294.html](https://ithardware.pl/aktualnosci/vivo_iqoo_z6_lite_z_procesorem_snapdragon_4_gen_1_zaprezentowany-23294.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 19:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/23294_1.jpg" />            iQOO Z6 Lite to najnowszy budżetowy smartfon vivo, kt&oacute;ry posiada procesor Qualcomm&nbsp;Snapdragon 4 Gen 1. Co takiego jeszcze oferuje telefon, kt&oacute;ry demonem prędkości nie zostanie?

vivo&nbsp;iQOO Z6 Lite jest smartfonem skierowanym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/vivo_iqoo_z6_lite_z_procesorem_snapdragon_4_gen_1_zaprezentowany-23294.html">https://ithardware.pl/

## The Sims 4 będzie dostępne za darmo od października
 - [https://ithardware.pl/aktualnosci/the_sims_4_przechodzi_na_free_to_play_i_bedzie_dostepne_za_darmo_od_pazdziernika-23293.html](https://ithardware.pl/aktualnosci/the_sims_4_przechodzi_na_free_to_play_i_bedzie_dostepne_za_darmo_od_pazdziernika-23293.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 16:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/23293_1.jpg" />            Electronic Arts potwierdziło plotkę i ogłosiło, że The Sims 4 przechodzi na model dystrybucji free-to-play i będzie oferowane za darmo na PC, Mac i konsolach od przyszłego miesiąca. Dla graczy, kt&oacute;rzy kupili grę przewidziano bonus.

The...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/the_sims_4_przechodzi_na_free_to_play_i_bedzie_dostepne_za_darmo_od_pazdziernika-23293.html">https://it

## W PS Store trwa wyprzedaż "Największe hity". Prezentujemy ciekawsze okazje
 - [https://ithardware.pl/aktualnosci/w_ps_store_trwa_wyprzedaz_najwieksze_hity_prezentujemy_ciekawsze_okazje-23292.html](https://ithardware.pl/aktualnosci/w_ps_store_trwa_wyprzedaz_najwieksze_hity_prezentujemy_ciekawsze_okazje-23292.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 14:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/23292_1.jpg" />            PS Store wystartował z nową wyprzedażą &quot;Największe hity&quot;, w kt&oacute;rej udział mogą wziąć posiadacze konsol PlayStation 4 i PS5. Warto się pospieszyć, gdyż akcja pozostaje ograniczona czasowo.

W PS Store trwa wyprzedaż...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/w_ps_store_trwa_wyprzedaz_najwieksze_hity_prezentujemy_ciekawsze_okazje-23292.html">https://ithardware.pl/aktualnos

## Twórcy Call of Duty walczą z toksycznymi graczami. Wiemy ile kont zbanowano
 - [https://ithardware.pl/aktualnosci/tworcy_call_of_duty_walcza_z_toksycznymi_graczami_wiemy_ile_kont_zbanowano-23291.html](https://ithardware.pl/aktualnosci/tworcy_call_of_duty_walcza_z_toksycznymi_graczami_wiemy_ile_kont_zbanowano-23291.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 13:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/23291_1.jpg" />            Cheaterzy oraz&nbsp;toksyczni gracze to zmora gier sieciowych, kt&oacute;rych nie brakuje m.in. w Call of Duty. Deweloperzy odpowiedzialni za markę walczą z taką społecznością i rozdają kolejne bany.

Oszuści i gracze negatywnie nastawieni do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tworcy_call_of_duty_walcza_z_toksycznymi_graczami_wiemy_ile_kont_zbanowano-23291.html">https://ithardwar

## Test soundbara Creative Stage 360 z Dolby Atmos. Sprawdzi się podczas mundialu?
 - [https://ithardware.pl/testyirecenzje/test_soundbara_creative_stage_360_sprawdzi_sie_podczas_mundialu-23289.html](https://ithardware.pl/testyirecenzje/test_soundbara_creative_stage_360_sprawdzi_sie_podczas_mundialu-23289.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 12:22:00+00:00

<img src="https://ithardware.pl/artykuly/min/23289_1.jpg" />            Test soundbara Creative Stage 360. Sprawdzi się podczas mundialu?

Firmy Creative nie trzeba przedstawiać żadnemu pecetowcowi, kt&oacute;ry posiadał komputer w latach 90. ubiegłego wieku, ponieważ w karty dźwiękowe tego singapurskiego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/test_soundbara_creative_stage_360_sprawdzi_sie_podczas_mundialu-23289.html">https://ithardware.pl/testyirecen

## Społeczności artystyczne banują grafiki tworzone za pomocą sztucznej inteligencji. Problem narasta
 - [https://ithardware.pl/aktualnosci/spolecznosci_artystyczne_banuja_grafiki_tworzone_za_pomoca_sztucznej_inteligencji_problem_narasta-23286.html](https://ithardware.pl/aktualnosci/spolecznosci_artystyczne_banuja_grafiki_tworzone_za_pomoca_sztucznej_inteligencji_problem_narasta-23286.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 12:06:01+00:00

<img src="https://ithardware.pl/artykuly/min/23286_1.jpg" />            Sieć ostatnimi czasy zalewana jest grafikami generowanymi przez sztuczną inteligencję, co skłania niekt&oacute;re portale do podjęcia krok&oacute;w w celu spowolnienia ich rozprzestrzeniania się lub nawet całkowitego zbanowania. Andy Baio z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/spolecznosci_artystyczne_banuja_grafiki_tworzone_za_pomoca_sztucznej_inteligencji_problem_narasta-23286.ht

## Były CEO Google ostrzega: Chiny mogą wygrać globalny wyścig technologiczny
 - [https://ithardware.pl/aktualnosci/byly_ceo_google_ostrzega_chiny_moga_wygrac_globalny_wyscig_technologiczny-23290.html](https://ithardware.pl/aktualnosci/byly_ceo_google_ostrzega_chiny_moga_wygrac_globalny_wyscig_technologiczny-23290.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 10:57:30+00:00

<img src="https://ithardware.pl/artykuly/min/23290_1.jpg" />            Amerykański think tank Special Competitive Studies Project, kt&oacute;ry powstał bazując na Komisji Bezpieczeństwa Narodowego ds. Sztucznej Inteligencji, ostrzegł, że okres między 2025 a 2030 rokiem będzie czasem, w kt&oacute;rym rozstrzygnie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/byly_ceo_google_ostrzega_chiny_moga_wygrac_globalny_wyscig_technologiczny-23290.html">https://ithardware

## Nowy Thunderbolt od Intela pozwoli na prędkości rzędu 80 Gb/s
 - [https://ithardware.pl/aktualnosci/nowy_thunderbolt_od_intela_pozwoli_na_predkosci_rzedu_80_gb_s-23282.html](https://ithardware.pl/aktualnosci/nowy_thunderbolt_od_intela_pozwoli_na_predkosci_rzedu_80_gb_s-23282.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 10:34:01+00:00

<img src="https://ithardware.pl/artykuly/min/23282_1.jpg" />            Wrzesień przyni&oacute;sł nam nie tylko zapowiedź nowej wersji USB, ale i Thunderbolt, kt&oacute;rą właśnie pochwalił się Intel. Obie technologie mają wiele wsp&oacute;lnego, ponieważ nowe standardy połączeń podwoją przepustowość w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowy_thunderbolt_od_intela_pozwoli_na_predkosci_rzedu_80_gb_s-23282.html">https://ithardware.pl/aktualnosci/nowy_th

## Centrum danych Twittera nie wytrzymało upałów podczas Święta Pracy
 - [https://ithardware.pl/aktualnosci/centrum_danych_twittera_nie_wytrzymalo_upalow_podczas_swieta_pracy-23288.html](https://ithardware.pl/aktualnosci/centrum_danych_twittera_nie_wytrzymalo_upalow_podczas_swieta_pracy-23288.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 10:28:50+00:00

<img src="https://ithardware.pl/artykuly/min/23288_1.jpg" />            Na początku tego miesiąca ekstremalne upały doprowadziły do awarii centrum danych Twittera w Kalifornii podczas Święta Pracy, pozostawiając stronę internetową i aplikację działającą na ograniczonej&nbsp;infrastrukturze.

CNN weszło w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/centrum_danych_twittera_nie_wytrzymalo_upalow_podczas_swieta_pracy-23288.html">https://ithardware.pl/aktualnosci/

## Kontynuacja jednej z najlepszych gier dekady z datą premiery i nowym zwiastunem
 - [https://ithardware.pl/aktualnosci/kontynuacja_genialnego_jednej_z_najlepszych_gier_dekady_z_data_premiery_i_nowym_zwastunem-23281.html](https://ithardware.pl/aktualnosci/kontynuacja_genialnego_jednej_z_najlepszych_gier_dekady_z_data_premiery_i_nowym_zwastunem-23281.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 09:56:30+00:00

<img src="https://ithardware.pl/artykuly/min/23281_1.jpg" />            Długo wyczekiwana kontynuacja The Legend of Zelda: Breath of the Wild, czyli jednego z najlepiej ocenianych tytuł&oacute;w w historii, wreszcie doczekała się daty premiery. Przy okazji otrzymaliśmy też nowy materiał z gry.&nbsp;

Big N...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kontynuacja_genialnego_jednej_z_najlepszych_gier_dekady_z_data_premiery_i_nowym_zwastunem-23281.html">https://i

## Tesla może oszukiwać w testach zderzeniowych. Wykryto specjalne tryby do Euro NCAP, ANCAP i innych
 - [https://ithardware.pl/aktualnosci/tesla_moze_oszukiwac_w_testach_zderzeniowych_wykryto_specjalne_tryby_do_euro_ncap_ancap_i_innych-23287.html](https://ithardware.pl/aktualnosci/tesla_moze_oszukiwac_w_testach_zderzeniowych_wykryto_specjalne_tryby_do_euro_ncap_ancap_i_innych-23287.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 08:30:10+00:00

<img src="https://ithardware.pl/artykuly/min/23287_1.jpg" />            Ostatnie wyniki test&oacute;w&nbsp;Euro NCAP i australijskiego ANCAP samochodu&nbsp;Tesla Model Y&nbsp;budzą podziw.&nbsp; Pojazd elektryczny osiągnął najwyższy og&oacute;lny wynik Euro NCAP, jednak nowe odkrycia podważają wiarygodność...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tesla_moze_oszukiwac_w_testach_zderzeniowych_wykryto_specjalne_tryby_do_euro_ncap_ancap_i_innych-23287.html">ht

## EA wypowiada wojnę oszustom. Nowa technologia anti-cheat zadebiutuje w FIFA 23
 - [https://ithardware.pl/aktualnosci/ea_wypowiada_wojne_oszustom_nowa_technologia_anti_cheat_zadebiutuje_w_fifa_23-23280.html](https://ithardware.pl/aktualnosci/ea_wypowiada_wojne_oszustom_nowa_technologia_anti_cheat_zadebiutuje_w_fifa_23-23280.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 08:11:30+00:00

<img src="https://ithardware.pl/artykuly/min/23280_1.jpg" />            Electronic Arts wypowiada wojnę oszustom. Firma opracowała własny system anti-cheaterski na poziomie kernela, kt&oacute;ry wdrożony będzie na PC. Jako pierwszy wykorzystany zostanie wraz z FIFA 23, już w momencie premiery gry, 30...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ea_wypowiada_wojne_oszustom_nowa_technologia_anti_cheat_zadebiutuje_w_fifa_23-23280.html">https://ithardware.pl/aktua

## Apple S8 napędzający nowe smartwatche marki posiada to samo CPU, co starsze S7, a nawet S6
 - [https://ithardware.pl/aktualnosci/apple_s8_napedzajacy_nowe_smartwatche_marki_posiada_to_samo_cpu_co_starsze_s7_a_nawet_s6-23278.html](https://ithardware.pl/aktualnosci/apple_s8_napedzajacy_nowe_smartwatche_marki_posiada_to_samo_cpu_co_starsze_s7_a_nawet_s6-23278.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 07:49:30+00:00

<img src="https://ithardware.pl/artykuly/min/23278_1.jpg" />            Dotarły do nas informacje, że&nbsp;układ&nbsp;S8, kt&oacute;ry napędza najnowsze smartwatche od Apple jest w rzeczywistości tą samą jednostką, co S7 oraz S6. Jeden z zagranicznych serwis&oacute;w odkrył, że S8 ma ten sam identyfikator...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_s8_napedzajacy_nowe_smartwatche_marki_posiada_to_samo_cpu_co_starsze_s7_a_nawet_s6-23278.html">https://ith

## Nowy podstawowy Kindle (2022) pozytywnie zaskakuje. Zobaczcie co ma do zaoferowania
 - [https://ithardware.pl/aktualnosci/nowy_podstawowy_kindle_2022_pozytywnie_zaskakuje_zobaczcie_co_ma_do_zaoferowania-23283.html](https://ithardware.pl/aktualnosci/nowy_podstawowy_kindle_2022_pozytywnie_zaskakuje_zobaczcie_co_ma_do_zaoferowania-23283.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 07:23:34+00:00

<img src="https://ithardware.pl/artykuly/min/23283_1.jpg" />            Amazon ogłosił nową edycję swojego podstawowego e-czytnika Kindle, doczekała się ona dużego upgrade'u i wielu element&oacute;w znanych z droższych modeli firmy. Dla przykładu nowy Kindle (2022) oferuje 6-calowy wyświetlacz o wysokiej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowy_podstawowy_kindle_2022_pozytywnie_zaskakuje_zobaczcie_co_ma_do_zaoferowania-23283.html">https://ithardware.p

## Rise of the Ronin to nowa gra twórców Nioh. Zapowiada się kapitalnie
 - [https://ithardware.pl/aktualnosci/rise_of_the_ronin_to_nowa_gra_tworcow_nioh_zapowiada_sie_kapitalnie-23279.html](https://ithardware.pl/aktualnosci/rise_of_the_ronin_to_nowa_gra_tworcow_nioh_zapowiada_sie_kapitalnie-23279.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 06:52:51+00:00

<img src="https://ithardware.pl/artykuly/min/23279_1.jpg" />            Dzisiejsze State of Play, na kt&oacute;rym zaprezentowano aż 10 gier zmierzających na PlayStation, przyniosło sporo niespodzianek, a jedną z największych jest Rise of the Ronin, czyli nowa gra tw&oacute;rc&oacute;w Nioh, kt&oacute;ra zapowiada się...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rise_of_the_ronin_to_nowa_gra_tworcow_nioh_zapowiada_sie_kapitalnie-23279.html">https://ithardware.

## God of War: Ragnarok na nowym zwiastunie. To nie może się nie udać
 - [https://ithardware.pl/aktualnosci/god_of_war_ragnarok_na_nowym_zwiastunie_to_nie_moze_sie_nie_udac-23277.html](https://ithardware.pl/aktualnosci/god_of_war_ragnarok_na_nowym_zwiastunie_to_nie_moze_sie_nie_udac-23277.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-14 06:08:49+00:00

<img src="https://ithardware.pl/artykuly/min/23277_1.jpg" />            Minęło trochę czasu, odkąd Sony pochwaliło się jakimś nowym materiałem z kolejnej odsłony przyg&oacute;d Kratosa. Na odbywającym się dziś w nocy State of Play firma postanowiła więc nieco osłodzić nam oczekiwanie na God of War: Ragnarok i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/god_of_war_ragnarok_na_nowym_zwiastunie_to_nie_moze_sie_nie_udac-23277.html">https://ithardware.pl/aktualnos


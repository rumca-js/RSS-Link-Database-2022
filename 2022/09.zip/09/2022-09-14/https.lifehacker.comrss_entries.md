# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## Throw Away This HelloFresh Ground Beef, CDC Says
 - [https://lifehacker.com/throw-away-this-hellofresh-ground-beef-cdc-says-1849536302](https://lifehacker.com/throw-away-this-hellofresh-ground-beef-cdc-says-1849536302)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 22:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vXJR8FJ4--/c_fit,fl_progressive,q_80,w_636/7e7070d4caa3df12ddc44c94f2b1dd8c.jpg" /><p>The Centers for Disease Control and Prevention (CDC) is currently <a href="https://www.cdc.gov/ecoli/2022/o157h7-09-22/details.html" rel="noopener noreferrer" target="_blank">investigating a multi-state E.coli outbreak</a> that has made at least seven people sick—six of whom have been hospitalized. The link between the cases of the foodborne illness

## Lock Down Your Kid’s iPhone With These New Parental Controls
 - [https://lifehacker.com/lock-down-your-kid-s-iphone-with-these-new-parental-con-1849534487](https://lifehacker.com/lock-down-your-kid-s-iphone-with-these-new-parental-con-1849534487)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--p6Ydht6f--/c_fit,fl_progressive,q_80,w_636/b8bbc9951e89d3ce0ebd853fcf823160.jpg" /><p>Whether you like it or not, it is now the norm for kids to have their own iPhones. That can be a terrifying thought: An iPhone is a window into the entirety of the internet through apps, Safari, messaging, what have you. Luckily, <em>your </em>child’s iPhone won’t be that. Instead, you can set things up to make sure their…</p><p><a href="https://lif

## How to Tell if You’re Being 'Quiet Fired'
 - [https://lifehacker.com/how-to-tell-if-you-re-being-quiet-fired-1849536863](https://lifehacker.com/how-to-tell-if-you-re-being-quiet-fired-1849536863)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 21:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--zaXT5AUX--/c_fit,fl_progressive,q_80,w_636/2124dd1a608fb486441a3b629742271e.png" /><p><a href="https://lifehacker.com/how-to-tell-if-you-re-being-quiet-fired-1849536863">Read more...</a></p>

## Give Your Coleslaw the Wedge Salad Treatment
 - [https://lifehacker.com/give-your-coleslaw-the-wedge-salad-treatment-1849536527](https://lifehacker.com/give-your-coleslaw-the-wedge-salad-treatment-1849536527)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--PmKNa7eu--/c_fit,fl_progressive,q_80,w_636/34bace15c66d6a38756565b114db58fd.jpg" /><p>Ever since I read that Ina Garten puts blue cheese in <a href="https://www.foodnetwork.com/recipes/ina-garten/blue-cheese-cole-slaw-2103385" rel="noopener noreferrer" target="_blank">her coleslaw</a>, I have been obsessed with a concept I’ve decided to call “wedgeslaw,” a coleslaw made with all the usual wedge salad accoutrement. Today I finally mad

## How to Reduce Your Screen Time Without Apps, According to Reddit
 - [https://lifehacker.com/how-to-reduce-your-screen-time-without-apps-according-1849536443](https://lifehacker.com/how-to-reduce-your-screen-time-without-apps-according-1849536443)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--n__rz-d4--/c_fit,fl_progressive,q_80,w_636/08ab63a74d2ed67abdce281735265f28.jpg" /><p>There are <a href="https://lifehacker.com/9-screen-time-features-everyone-should-be-using-1848430914">loads of features</a> that help report your screen time, but just like knowing how often you <a href="https://lifehacker.com/how-to-really-tell-if-your-headphone-volume-is-destroyi-1849406930">exceed volume recommendations</a>, knowledge isn’t reall

## How to Adjust Paint If It’s Just a Shade Off
 - [https://lifehacker.com/how-to-adjust-paint-if-it-s-just-a-shade-off-1849534891](https://lifehacker.com/how-to-adjust-paint-if-it-s-just-a-shade-off-1849534891)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--twRvtVBj--/c_fit,fl_progressive,q_80,w_636/7832e8d01f56323d5743b88ac371ebbd.jpg" /><p>It happens all too often: You do some light renovation or some unexpected repair work that requires you to replace just a section of drywall, or your wall gets stained or scuffed in some way that requires a <a href="https://lifehacker.com/how-to-pick-the-right-wall-paint-and-buy-the-right-amou-1829396064">few coats of paint</a>. You don’t have any p

## Editing Your iMessages Won’t Make Your Mistakes Go Away
 - [https://lifehacker.com/you-can-finally-edit-and-undo-sent-messages-on-iphone-1849167883](https://lifehacker.com/you-can-finally-edit-and-undo-sent-messages-on-iphone-1849167883)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 19:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--zbFvjxXd--/c_fit,fl_progressive,q_80,w_636/f90df7efc96b26f8e31be2d7620628a2.jpg" /><p>Messaging apps like <a href="https://lifehacker.com/why-you-probably-shouldnt-pay-for-telegram-premium-1849104588">Telegram</a> and <a href="https://lifehacker.com/how-to-finally-hide-your-whatsapp-last-seen-status-from-1849092145">WhatsApp</a> are regularly updated with new features, but Apple’s Messages app gets major updates only once a year, whe

## The Best Ways to Take Notes so You Actually Remember Information
 - [https://lifehacker.com/the-best-ways-to-take-notes-so-you-actually-remember-in-1849535943](https://lifehacker.com/the-best-ways-to-take-notes-so-you-actually-remember-in-1849535943)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 19:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--sAzugJLm--/c_fit,fl_progressive,q_80,w_636/d7f7a4ea5d316c84285a3c79af773909.jpg" /><p>In class and in meetings, note-taking is  important. You want to be able to review what was said, commit it to memory, and use it going forward, whether on tests or in your job. It <em>sounds</em> easy, but can be pretty hard. Think of all the times you’ve looked back on your notes only to find they’re filled with …</p><p><a href="https://lifehacker

## How to Put Your Baby Down Without Waking Them Up
 - [https://lifehacker.com/how-to-put-your-baby-down-without-waking-them-up-1849535970](https://lifehacker.com/how-to-put-your-baby-down-without-waking-them-up-1849535970)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--2qqCRzZC--/c_fit,fl_progressive,q_80,w_636/f5dde0e78996b8f41464136ccad788f3.jpg" /><p>My three children were each difficult to get to sleep, for different reasons. One would never fall asleep in a crib, only with a parent. The others fell asleep more easily, but if you were holding them at the time, good luck getting them into bed without waking them up. Now, a group of scientists <a href="https://www.cell.com/current-biology/fulltex

## The Differences Between Anxiety and Depression (and When to Get Help)
 - [https://lifehacker.com/the-differences-between-anxiety-and-depression-and-whe-1849528175](https://lifehacker.com/the-differences-between-anxiety-and-depression-and-whe-1849528175)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--4D3YVqDL--/c_fit,fl_progressive,q_80,w_636/32e5d34ba7612a7dad02bcc453804f95.png" /><p>Even though we’ve made strides in the fight against mental health stigma, it can still be a struggle for people to get the help they need when it comes to depression and anxiety. Part of that is because of the lack of mental health literacy in the U.S. A <a href="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8582339/" rel="noopener noreferrer" target

## How to Drain Greasy Food When You're Out of Paper Towels
 - [https://lifehacker.com/how-to-drain-greasy-food-when-youre-out-of-paper-towels-1849535418](https://lifehacker.com/how-to-drain-greasy-food-when-youre-out-of-paper-towels-1849535418)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 18:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--89_s0nY_--/c_fit,fl_progressive,q_80,w_636/edc355fe6ead5927f20f40cb7cca0def.jpg" /><p>Fried foods are comfort foods. But holding onto that just-fried crunch is a precarious dance of wicking off oil and allowing the food to cool on a rack without steaming itself soggy before dinnertime. The conventional method is to use half a roll of paper towels to absorb excess oil, but what if your roll just ran…</p><p><a href="https://lifehacker.

## How Many Steps You Really Need to Take Each Day, According to Science
 - [https://lifehacker.com/how-many-steps-you-really-need-to-take-each-day-accord-1849535168](https://lifehacker.com/how-many-steps-you-really-need-to-take-each-day-accord-1849535168)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 17:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--yvVsFauu--/c_fit,fl_progressive,q_80,w_636/fc0d50ae3c4da7734f8661be042585fa.jpg" /><p>The more you walk, the lower your risk of all-cause and cancer mortality, <a href="https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2796058" rel="noopener noreferrer" target="_blank">according to a new study</a>, with the benefits leveling out once you reach 10,000 steps per day. So clearly, that is the number of steps to aim for—or

## How to Stain Your Boring Concrete Patio
 - [https://lifehacker.com/how-to-stain-your-boring-concrete-patio-1849532297](https://lifehacker.com/how-to-stain-your-boring-concrete-patio-1849532297)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--dE-EI6W1--/c_fit,fl_progressive,q_80,w_636/12c0449181af7d06124011785b55b72e.jpg" /><p>If your patio is looking the worse for wear, or if you just want a new look, you can stain concrete floors to give them new life. Using stain on concrete has the added bonus of allowing the surface to breathe, preventing moisture buildup that can cause cracking and other damage, while still freshening it up. The…</p><p><a href="https://lifehacker.co

## How to Make Your Apple Watch Last for Days on a Single Charge
 - [https://lifehacker.com/how-to-make-your-apple-watch-last-for-days-on-a-single-1849533531](https://lifehacker.com/how-to-make-your-apple-watch-last-for-days-on-a-single-1849533531)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ck_jBhFG--/c_fit,fl_progressive,q_80,w_636/64d491723aac38745a600d35dc0f77de.jpg" /><p>When it comes to the Apple Watch, “all-day battery life” is Apple’s party line—but what that <em>really</em> means is an 18-hour battery cycle. If you want to push it over a day, you need to stick to light use (and not wear it to bed). But now, with <a href="https://lifehacker.com/the-best-new-features-in-watchos-9-1849027953">watchOS 9</a>, Apple i

## 13 Classic Stories We Can’t Stop Adapting Into Movies
 - [https://lifehacker.com/13-classic-stories-we-can-t-stop-adapting-into-movies-1849524899](https://lifehacker.com/13-classic-stories-we-can-t-stop-adapting-into-movies-1849524899)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--OWlbIZlO--/c_fit,fl_progressive,q_80,w_636/c7a808963f0bf53a929c67898ef6e8e3.png" /><p>Born from Carlo Collodi’s 1883 novel, <em>Pinocchio</em> is both an easy pop-culture reference point, as well as the star of any number of movies and TV cartoons. The 1940 Disney animated version is certainly the best known and best loved, but the lying little puppet is having quite a year, seeing no fewer than three…</p><p><a href="https://lifehack

## What Shoes Should I Wear to Exercise?
 - [https://lifehacker.com/what-shoes-should-i-wear-to-exercise-1849534543](https://lifehacker.com/what-shoes-should-i-wear-to-exercise-1849534543)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 15:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--3MFra2BF--/c_fit,fl_progressive,q_80,w_636/b5cbf9ee1446024f56cf4933e0ed6bb9.png" /><p><a href="https://lifehacker.com/what-shoes-should-i-wear-to-exercise-1849534543">Read more...</a></p>

## Everything We Know About the iPhone 14's Battery Life
 - [https://lifehacker.com/everything-we-know-about-the-iphone-14s-battery-life-1849532742](https://lifehacker.com/everything-we-know-about-the-iphone-14s-battery-life-1849532742)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--zlEaHd4Q--/c_fit,fl_progressive,q_80,w_636/2ce27d51a9577d96ff35aad7f80b351d.png" /><p>One of the most pressing questions when Apple reveals a new iPhone is: What’s the battery like? Apple doesn’t normally share granular battery specs, so it can be hard to judge battery life without hands-on testing, especially since the <a href="https://lifehacker.com/should-you-buy-the-iphone-14-or-14-pro-1849506382">iPhone 14 Pro and Pro Max’s</a> 

## Make Brigadeiro Your New Cake Frosting
 - [https://lifehacker.com/make-brigadeiro-your-new-cake-frosting-1849532365](https://lifehacker.com/make-brigadeiro-your-new-cake-frosting-1849532365)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--iFFYsu3q--/c_fit,fl_progressive,q_80,w_636/f1bc9205b558dca8b960767d0e8e5991.jpg" /><p>Brazil is home to many wonderful things, not least of which is <a href="https://www.iheartbrazil.com/brigadeiro-recipe/" rel="noopener noreferrer" target="_blank">the brigadeiro</a>. Constructed almost entirely of sweetened condensed milk, the mixture is cooked until thick, and can easily be portioned into acorn-sized balls and covered with sprinkle

## Clever Ways to Display All the Art Your Kid Makes This Year
 - [https://lifehacker.com/clever-ways-to-display-all-the-art-your-kid-makes-this-1849530453](https://lifehacker.com/clever-ways-to-display-all-the-art-your-kid-makes-this-1849530453)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 13:32:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--RBl2a7zY--/c_fit,fl_progressive,q_80,w_636/c3f48e78e0d007bf8d016165ec2f33ef.jpg" /><p>My daughter discovered her love of painting on the first day of kindergarten. She came home with several large masterpieces. She installed them on her bedroom wall using non-paint safe tape and declared the exhibit, “Art-tastic!” We were so proud (and had to later repaint the whole room when we moved). Her love has…</p><p><a href="https://lifehacker

## What You Need to Do Now to Prep Your Garden for Winter
 - [https://lifehacker.com/what-you-need-to-do-now-to-prep-your-garden-for-winter-1849530291](https://lifehacker.com/what-you-need-to-do-now-to-prep-your-garden-for-winter-1849530291)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-09-14 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--TcUW_2hE--/c_fit,fl_progressive,q_80,w_636/d6391435f13655d47ad70ef28e6e672c.jpg" /><p>With cooler weather on its way, harvesting and cleaning up your garden beds should be on your fall agenda. While your garden might not be actively producing over the winter, there’s still plenty to do now to make next season more successful. Taking some time to properly prepare for the garden’s dormant season will…</p><p><a href="https://lifehacker.


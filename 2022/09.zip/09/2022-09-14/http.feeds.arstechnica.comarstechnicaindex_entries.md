# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## In mice, the new BA.5 booster works about the same as BA.1 shot FDA passed up
 - [https://arstechnica.com/?p=1881544](https://arstechnica.com/?p=1881544)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 23:23:50+00:00

Sans human data, mouse study offers first direct comparison of the two omicron boosters.

## Our biggest remaining PlayStation VR2 questions have been answered
 - [https://arstechnica.com/?p=1881340](https://arstechnica.com/?p=1881340)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 22:48:58+00:00

Plus, a wrap-up of Sony's TGS 2022 biggies: <em>God of War: Ragnarok</em>, <em>Tekken 8</em>.

## Iranians hacked US companies, sent ransom demands to printers, indictment says
 - [https://arstechnica.com/?p=1881431](https://arstechnica.com/?p=1881431)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 21:42:38+00:00

Alleged victims include domestic violence shelter that paid hackers $13,000.

## Regulators put the brakes on Microsoft’s Activision acquisition
 - [https://arstechnica.com/?p=1881530](https://arstechnica.com/?p=1881530)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 21:39:57+00:00

Microsoft faces prolonged competition investigation into $75 billion acquisition.

## China’s most advanced AI image generator already blocks political content
 - [https://arstechnica.com/?p=1881321](https://arstechnica.com/?p=1881321)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 21:31:08+00:00

Baidu's ERNIE-ViLG text-to-image model prevents users from creating political images.

## California says Amazon ruined online shopping, sues it for driving up prices
 - [https://arstechnica.com/?p=1881446](https://arstechnica.com/?p=1881446)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 21:07:03+00:00

Lawsuit mirrors DC's case dismissed in April. Now, DOJ backs DC's appeal.

## Ford gives dealers 2 months to accept new rules or stop selling EVs
 - [https://arstechnica.com/?p=1881373](https://arstechnica.com/?p=1881373)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 19:38:02+00:00

From 2024, Ford EVs will only be sold at Model e-certified dealerships.

## San Francisco sued by woman who says her rape-kit DNA was used to arrest her
 - [https://arstechnica.com/?p=1881324](https://arstechnica.com/?p=1881324)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 18:05:03+00:00

Jane Doe "was re-victimized by this unconstitutional practice," lawsuit says.

## HP to pay EU printer customers $1.35 million for disabling third-party ink
 - [https://arstechnica.com/?p=1881175](https://arstechnica.com/?p=1881175)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 17:34:35+00:00

New printers still block non-HP ink, but HP is compensating for lack of advance notice.

## AT&T won’t upgrade “older” phones for new 5G bands
 - [https://arstechnica.com/?p=1881162](https://arstechnica.com/?p=1881162)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 17:25:58+00:00

Only the very latest Apple and Samsung devices can ride the 3.45 GHz wave.

## Today’s best deals: Anker noise-canceling headphones, USB-C chargers, and more
 - [https://arstechnica.com/?p=1881118](https://arstechnica.com/?p=1881118)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 17:09:08+00:00

Dealmaster also has LG OLED TVs, MacBooks, and gaming accessories.

## Big Tech must prove content moderation works or pay $15K daily fines in Calif.
 - [https://arstechnica.com/?p=1881219](https://arstechnica.com/?p=1881219)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 16:54:22+00:00

New law responds to concerns over Big Tech's alleged role in US Capitol riot.

## EA’s new anti-cheat tools dip into the dreaded “kernel mode”
 - [https://arstechnica.com/?p=1881224](https://arstechnica.com/?p=1881224)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 16:39:18+00:00

Publisher promises robust privacy and system security efforts to protect users.

## Five years of data show that SSDs are more reliable than HDDs over the long haul
 - [https://arstechnica.com/?p=1881156](https://arstechnica.com/?p=1881156)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 16:06:41+00:00

Backblaze tracks reliability for thousands of HDDs and SSDs in its data centers.

## Human trafficking’s newest abuse: Forcing victims into cyberscamming
 - [https://arstechnica.com/?p=1881183](https://arstechnica.com/?p=1881183)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 16:05:21+00:00

Thousands of people from across Asia have been coerced into defrauding people everywhere.

## EU upholds Google’s 4.1B euro fine for bundling search with Android
 - [https://arstechnica.com/?p=1881150](https://arstechnica.com/?p=1881150)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 15:10:13+00:00

Google will have to pay the EU's biggest fine ever.

## Sampling BMW’s greatest hits shows what’s missing from its modern cars
 - [https://arstechnica.com/?p=1880534](https://arstechnica.com/?p=1880534)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-14 11:45:27+00:00

Driving M cars from 2001, 2013, and 2022 shows some lessons for the future.


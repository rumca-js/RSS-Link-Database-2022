# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Ethereum Merge: A cryptocurrency 'going green'
 - [https://www.bbc.co.uk/news/world-62899880?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-62899880?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-09-14 13:08:09+00:00

The second biggest cryptocurrency is to switch to a new operating model that it says uses 99.9% less energy.

## Google loses appeal over record EU anti-trust Android fine
 - [https://www.bbc.co.uk/news/technology-62888137?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62888137?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-09-14 10:49:31+00:00

An EU court has largely upheld a £3.5bn fine against Google over its Android platform.


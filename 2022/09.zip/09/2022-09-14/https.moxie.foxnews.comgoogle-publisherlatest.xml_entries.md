# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## What makes fentanyl a 'weapon of mass destruction': Texas sheriff
 - [https://www.foxnews.com/media/fentanyl-weapon-mass-destruction-texas-sheriff](https://www.foxnews.com/media/fentanyl-weapon-mass-destruction-texas-sheriff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 23:26:16+00:00

Montgomery County, Texas sheriff Rand Henderson weighed in on the damage that fentanyl has done as a crisis sweeps the United States on "Your World."

## Greg Gutfeld: We are very pro-immigrant, we are against illegal immigration and line-cutting
 - [https://www.foxnews.com/media/greg-gutfeld-very-pro-immigrant-against-illegal-immigration-line-cutting](https://www.foxnews.com/media/greg-gutfeld-very-pro-immigrant-against-illegal-immigration-line-cutting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 23:17:15+00:00

Fox News host Greg Gutfeld slammed illegal immigration as "line-cutting" and the media's coverage of the U.S. border crisis as being based on "optics" on "The Five."

## Yahoo News investigation finds 'mounting skepticism' about Havana syndrome link to foreign 'attacks'
 - [https://www.foxnews.com/media/yahoo-news-investigation-finds-mounting-skepticism-about-havana-syndrome-link-foreign-attacks](https://www.foxnews.com/media/yahoo-news-investigation-finds-mounting-skepticism-about-havana-syndrome-link-foreign-attacks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 23:14:38+00:00

Yahoo News reported Wednesday that there was "mounting skepticism" coming from senior officials about Havana syndrome being tied to foreign, "hostile attacks."

## Ron DeSantis sends two planes of illegal immigrants to Martha's Vineyard
 - [https://www.foxnews.com/politics/ron-desantis-sends-two-planes-illegal-immigrants-marthas-vineyard](https://www.foxnews.com/politics/ron-desantis-sends-two-planes-illegal-immigrants-marthas-vineyard)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 23:10:55+00:00

Florida Republican Gov. Ron DeSantis sent two planes carrying illegal immigrants to Martha’s Vineyard, Massachusetts, on Wednesday, his office has confirmed.

## Country should brace for economic 'disaster' if rail strike moves forward, manufacturer group warns
 - [https://www.foxnews.com/media/country-should-brace-economic-disaster-rail-strike-moves-forward-manufacturer-group-warns](https://www.foxnews.com/media/country-should-brace-economic-disaster-rail-strike-moves-forward-manufacturer-group-warns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 23:09:59+00:00

President and CEO of the National Association of Manufacturers said a rail strike would disrupt the supply chain even further and have devastating consequences on the economy.

## Erling Haaland's ridiculous goal leads Manchester City over Dortmund in UEFA Champions League match
 - [https://www.foxnews.com/sports/erling-haalands-ridiculous-goal-leads-manchester-city-over-dortmund-in-uefa-champions-league-match](https://www.foxnews.com/sports/erling-haalands-ridiculous-goal-leads-manchester-city-over-dortmund-in-uefa-champions-league-match)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 23:01:52+00:00

Manchester City star Erling Haaland's acrobatic, game-winning finish baffled Dortmund in their 2-1 UEFA Champions League win on Wednesday.

## Ex-aide to Andrew Cuomo sues, alleges former gov and top aides created 'sexually hostile work environment'
 - [https://www.foxnews.com/politics/ex-aide-andrew-cuomo-sues-alleges-former-gov-top-aides-created-sexually-hostile-work-environment](https://www.foxnews.com/politics/ex-aide-andrew-cuomo-sues-alleges-former-gov-top-aides-created-sexually-hostile-work-environment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:57:48+00:00

A former aide to ex-New York Gov. Andrew Cuomo filed a lawsuit against him, alleging that he and his aides created a "sexually hostile" work environment.

## Cruz clashes with Murphy on school safety, says if Dem 'just shut his mouth' both their bills would be law
 - [https://www.foxnews.com/politics/cruz-clashes-murphy-school-safety-says-dem-shut-mouth-both-bills-would-be-law](https://www.foxnews.com/politics/cruz-clashes-murphy-school-safety-says-dem-shut-mouth-both-bills-would-be-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:52:47+00:00

Senators Ted Cruz, R-Texas, and Chris Murphy, D-Conn., clashed on the Senate floor after the Connecticut Democrat blocked bringing Cruz's school safety bill up for a vote.

## Kamala Harris roasted for traveling to promote climate policy: ‘Hope you’re flying coach’
 - [https://www.foxnews.com/media/kamala-harris-roasted-traveling-promote-climate-policy-hope-youre-flying-coach](https://www.foxnews.com/media/kamala-harris-roasted-traveling-promote-climate-policy-hope-youre-flying-coach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:51:33+00:00

Vice President Kamala Harris announced that she was traveling to discuss climate action, but many users skewered her for being hypocritical.

## Washington DC post office worker robbed at gunpoint while making deliveries
 - [https://www.foxnews.com/us/washington-dc-post-office-worker-robbed-gunpoint-making-deliveries](https://www.foxnews.com/us/washington-dc-post-office-worker-robbed-gunpoint-making-deliveries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:48:05+00:00

A Washington, D.C., postal carrier was robbed Monday at gunpoint by a suspect who took his keys and fled, authorities said.

## Senate advances $4.5B in aid to Taiwan as China threat intensifies
 - [https://www.foxnews.com/politics/senate-advances-aid-taiwan-china-threat-intensifies](https://www.foxnews.com/politics/senate-advances-aid-taiwan-china-threat-intensifies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:30:01+00:00

The vote could ramp up tensions between the U.S. and China, which has repeatedly urged America stay away from internal Chinese matters.

## Prince William is 'prioritizing stability' and keeping royal kids in school while mourning Queen Elizabeth II
 - [https://www.foxnews.com/entertainment/prince-william-prioritizing-stability-keeping-royal-kids-school-mourning-queen-elizabeth-ii](https://www.foxnews.com/entertainment/prince-william-prioritizing-stability-keeping-royal-kids-school-mourning-queen-elizabeth-ii)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:29:58+00:00

King Charles III began Wednesday's procession leading Queen Elizabeth II's coffin to Westminster Hall, where he was followed by Prince William and Prince Harry.

## Bill Gates says 'the scariest thing of all' is Ukraine war because it is a 'distraction' from climate change
 - [https://www.foxnews.com/media/bill-gates-says-scariest-thing-war-ukraine-because-distraction-from-climate-change](https://www.foxnews.com/media/bill-gates-says-scariest-thing-war-ukraine-because-distraction-from-climate-change)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:26:32+00:00

New York Times published an interview with Bill Gates in which he said that the war in Ukraine is "the scariest thing of all" because it distracts from climate change.

## Oklahoma's games against soon-to-be SEC rivals postponed
 - [https://www.foxnews.com/sports/oklahomas-games-against-soon-sec-rivals-postponed](https://www.foxnews.com/sports/oklahomas-games-against-soon-sec-rivals-postponed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:26:12+00:00

The Oklahoma Sooners were set to battle against soon-to-be SEC rivals, but the SEC told Tennessee and Georgia to nix their games in 2023 and 2024.

## Donovan Mitchell thought Knicks would trade for him before Cavaliers deal
 - [https://www.foxnews.com/sports/donovan-mitchell-thought-knicks-would-trade-before-cavaliers-deal](https://www.foxnews.com/sports/donovan-mitchell-thought-knicks-would-trade-before-cavaliers-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:25:30+00:00

New Cleveland Cavalier Donovan Mitchell admitted that he thought he would be heading to New York this summer before he got word that he was heading to Ohio.

## Indiana drug trafficker arrested, fentanyl and grenade launcher found during search
 - [https://www.foxnews.com/us/indiana-drug-trafficker-arrested-fentanyl-grenade-launcher-found-search](https://www.foxnews.com/us/indiana-drug-trafficker-arrested-fentanyl-grenade-launcher-found-search)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:23:26+00:00

Indiana authorities last week conducted a drug raid of a couple's home and found illegal narcotics, drug paraphernalia, and multiple firearms including a grenade launcher.

## Michelle Obama partners with climate organizations to mobilize young voters ahead of the midterms
 - [https://www.foxnews.com/politics/michelle-obama-partners-climate-organizations-mobilize-young-voters-ahead-midterms](https://www.foxnews.com/politics/michelle-obama-partners-climate-organizations-mobilize-young-voters-ahead-midterms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:19:13+00:00

Former first lady Michelle Obama's voting initiative announced a new effort spurred by the Inflation Reduction Act to boost voter participation ahead of the midterm elections.

## NYC street corner is renamed Jimmy Neary Way in honor of beloved Irish immigrant restaurateur
 - [https://www.foxnews.com/lifestyle/nyc-street-corner-renamed-jimmy-neary-way](https://www.foxnews.com/lifestyle/nyc-street-corner-renamed-jimmy-neary-way)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:16:39+00:00

New York City renames a Manhattan intersection Jimmy Neary Way in honor of an Irish immigrant restaurateur who counted celebrities, power brokers and everyday neighbors among his loyal customers.

## New York City mother charged with murder in her three children's Coney Island drowning deaths
 - [https://www.foxnews.com/us/new-york-city-mother-charged-murder-three-childrens-coney-island-drowning-deaths](https://www.foxnews.com/us/new-york-city-mother-charged-murder-three-childrens-coney-island-drowning-deaths)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:10:39+00:00

Erin Merdy, 30, of New York City was arrested on murder charges Wednesday after her three kids were found drowned to death near Coney Island early Monday morning.

## NYC police groups donate funds for 1,000+ new ballistic vests for detectives amid nationwide violence 'crisis'
 - [https://www.foxnews.com/us/nyc-police-groups-donate-funds-1000-new-ballistic-vests-detectives-amid-nationwide-violence-crisis](https://www.foxnews.com/us/nyc-police-groups-donate-funds-1000-new-ballistic-vests-detectives-amid-nationwide-violence-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 22:09:58+00:00

Over 1,000 more New York City detectives will be outfitted with newly designed ballistics vests to be better protected as the nation grapples with violence "crisis."

## Robert Kraft upset with Kendrick Bourne's lack of playing time: report
 - [https://www.foxnews.com/sports/robert-kraft-upset-kendrick-bournes-lack-playing-time-report](https://www.foxnews.com/sports/robert-kraft-upset-kendrick-bournes-lack-playing-time-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 21:41:40+00:00

The New England Patriots wide receiver Kendrick Bourne is making $5 million this year, which puts him currently on track to make over $147,000 per snap he is on the field this season.

## MSNBC's Joy Reid claims late-term abortion is a 'made up term'
 - [https://www.foxnews.com/media/msnbcs-joy-reid-claims-late-term-abortion-made-up-term](https://www.foxnews.com/media/msnbcs-joy-reid-claims-late-term-abortion-made-up-term)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 21:38:40+00:00

MSNBC host Joy Reid suggested the phrase “late-term abortion" is not a legitimate term when discussing Sen. Lindsey Graham's, R-S.C., new bill.

## Boston, federal officials probing whether Northeastern University 'detonation' incident was staged by employee
 - [https://www.foxnews.com/us/boston-federal-officials-probing-northeastern-university-detonation-incident-staged-employee](https://www.foxnews.com/us/boston-federal-officials-probing-northeastern-university-detonation-incident-staged-employee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 21:24:21+00:00

Boston and federal authorities are investigating whether the alleged detonation at Northeastern University Tuesday evening was staged by the sole victim.

## Los Angeles girl dead, another hospitalized, after suspected fentanyl overdose at Hollywood high school
 - [https://www.foxnews.com/us/los-angeles-girl-dead-another-hospitalized-suspected-fentanyl-overdose-hollywood-high-school](https://www.foxnews.com/us/los-angeles-girl-dead-another-hospitalized-suspected-fentanyl-overdose-hollywood-high-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 21:22:03+00:00

A Los Angeles high school student died and another girl was hospitalized after they overdosed on pills possibly laced with fentanyl, officials said.

## Rory McIlroy takes hard line against LIV players at Ryder Cup: 'I've said it a hundred times'
 - [https://www.foxnews.com/sports/rory-mcilroy-takes-hard-line-against-liv-players-ryder-cup-ive-said-it-a-hundred-times](https://www.foxnews.com/sports/rory-mcilroy-takes-hard-line-against-liv-players-ryder-cup-ive-said-it-a-hundred-times)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 21:17:33+00:00

Rory McIlroy made it clear ahead of this week's Italian Open he does not believe LIV golfers should be included in next year's Ryder Cup championship.

## MSNBC, CNN, ABC's 'The View' slam Lindsey Graham over 15 week abortion ban, call it political 'suicide'
 - [https://www.foxnews.com/media/msnbc-cnn-abc-view-slam-lindsey-graham-15-week-abortion-ban-political-suicide](https://www.foxnews.com/media/msnbc-cnn-abc-view-slam-lindsey-graham-15-week-abortion-ban-political-suicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 21:11:04+00:00

Left-leaning media figures called Lindsey Graham's abortion bill announcement a 'desperate' and 'ugly' move to drum up support from the Republican base.

## CBP chief announces probe of official Twitter account that retweeted criticism of Biden's border 'eradication'
 - [https://www.foxnews.com/politics/cbp-chief-announces-probe-official-twitter-account-retweeted-criticism-bidens-border-eradication](https://www.foxnews.com/politics/cbp-chief-announces-probe-official-twitter-account-retweeted-criticism-bidens-border-eradication)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 21:10:33+00:00

CBP Commissioner Chris Magnus is promising an investigation into retweets of criticism of the Biden administration's border policies by an official CBP account.

## Britney Spears and Prince William had a 'cyber relationship' before he met Kate Middleton
 - [https://www.foxnews.com/entertainment/britney-spears-prince-william-cyber-relationship-before-kate-middleton](https://www.foxnews.com/entertainment/britney-spears-prince-william-cyber-relationship-before-kate-middleton)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 21:01:37+00:00

Britney Spears and Prince William reportedly shared a "cyber relationship" where they communicated via email in the early 2000s. The pair never took their relationship offline.

## Nationals player sends girl baseball after incident where grown man robbed one from her at game
 - [https://www.foxnews.com/sports/nationals-player-sends-girl-baseball-incident-grown-man-robbed-one](https://www.foxnews.com/sports/nationals-player-sends-girl-baseball-incident-grown-man-robbed-one)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 21:00:05+00:00

Washington Nationals' Joey Meneses made good on the team's promise to make up for an incident where a young girl had a ball snatched from her by a grown man at a recent game.

## NYC Mayor Adams says city is at 'breaking point' with arrival of migrants sent from Texas
 - [https://www.foxnews.com/us/nyc-mayor-adams-city-breaking-point-arrival-migrants-sent-texas](https://www.foxnews.com/us/nyc-mayor-adams-city-breaking-point-arrival-migrants-sent-texas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 20:54:08+00:00

More than 2,200 migrants have been bused to New York City from Texas since last month, prompting Mayor Eric Adams to say the city is at a "breaking point."

## Karoline Leavitt, who could become the youngest elected congresswoman, calls out 'extreme' Democrats
 - [https://www.foxnews.com/media/karoline-leavitt-become-youngest-elected-congresswoman-calls-out-extreme-democrats](https://www.foxnews.com/media/karoline-leavitt-become-youngest-elected-congresswoman-calls-out-extreme-democrats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 20:49:47+00:00

Trump-aligned Karoline Leavitt of New Hampshire called out 'extreme' Democrats and praised her supporters and volunteers who put her over the top in the primary.

## Rep. Hank Johnson compares protesting parents at school boards to January 6 rioters
 - [https://www.foxnews.com/media/rep-hank-johnson-compares-protesting-parents-school-boards-maga-republicans-jan-6](https://www.foxnews.com/media/rep-hank-johnson-compares-protesting-parents-school-boards-maga-republicans-jan-6)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 20:40:26+00:00

Rep. Hank Johnson, D-Ga., claimed that parents who protested school boards over the past year are examples of “MAGA extremists” condemned by President Biden.

## Rand Paul threatens to investigate royalties to Fauci, other officials, if GOP takes Senate
 - [https://www.foxnews.com/politics/rand-paul-threatens-investigate-royalties-fauci-officials-gop-takes-senate](https://www.foxnews.com/politics/rand-paul-threatens-investigate-royalties-fauci-officials-gop-takes-senate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 20:35:32+00:00

Senator Rand Paul said that if and when Republicans take control of the Senate, he will make sure officials like Dr. Anthony Fauci have to disclose any royalties they receive.

## Russia 'likely' deployed Iran drones in Ukraine for the first time, British intelligence says
 - [https://www.foxnews.com/world/russia-deployed-iran-drones-ukraine-british-intelligence-says](https://www.foxnews.com/world/russia-deployed-iran-drones-ukraine-british-intelligence-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 20:34:21+00:00

The use of Iranian drones in Ukraine further solidifies ties between Russia and Iran as rogue nations suffering under Western sanctions find new partnerships with each other.

## Aaron Judge doesn't rule out signing with Red Sox, calls their fans 'some of the best in baseball'
 - [https://www.foxnews.com/sports/aaron-judge-doesnt-rule-out-signing-red-sox-calls-fans-best-baseball](https://www.foxnews.com/sports/aaron-judge-doesnt-rule-out-signing-red-sox-calls-fans-best-baseball)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 20:31:16+00:00

Aaron Judge currently plays for the Boston Red Sox' bitter rival. But if the Sox offer the Yankee enough money, he may have a tough choice on his hands.

## Senate, governor races in Georgia tighten; inflation and abortion are issues of top concern to voters: poll
 - [https://www.foxnews.com/politics/senate-governor-races-georgia-inflation-abortion-issues-concern-voters-poll](https://www.foxnews.com/politics/senate-governor-races-georgia-inflation-abortion-issues-concern-voters-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 20:31:02+00:00

A new Quinnipiac University poll suggests Sen. Raphael Warnock is leading the Senate race in Georgia, while Stacey Abrams trails by just two points behind Gov. Brian Kemp.

## FBI arrests GOP upstate New York election official over alleged absentee ballot fraud scheme
 - [https://www.foxnews.com/us/fbi-arrests-gop-upstate-new-york-election-official-alleged-absentee-ballot-fraud-scheme](https://www.foxnews.com/us/fbi-arrests-gop-upstate-new-york-election-official-alleged-absentee-ballot-fraud-scheme)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 20:27:29+00:00

Jason Schofield, elections commissioner at the Rensselaer County Board of Elections in upstate New York, was arrested by the FBI over an alleged absentee ballot fraud scheme.

## Shaq calls NBA legend the worst teammate he played with
 - [https://www.foxnews.com/sports/shaq-calls-nba-legend-worst-teammates-played-with](https://www.foxnews.com/sports/shaq-calls-nba-legend-worst-teammates-played-with)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 20:26:05+00:00

Four-time NBA champion Shaquille O’Neal said Dennis Rodman was the worst teammate he's ever had. The two were teammates on the Los Angeles Lakers during the 1998-1999 season.

## Tropical Depression Seven forms in Atlantic Ocean, could strengthen into a tropical storm
 - [https://www.foxnews.com/us/tropical-depression-seven-forms-atlantic-ocean-strengthen-tropical-storm](https://www.foxnews.com/us/tropical-depression-seven-forms-atlantic-ocean-strengthen-tropical-storm)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 20:23:24+00:00

Tropical Depression Seven formed in the Atlantic Ocean on Wednesday. It was located about 800 miles east of the Leeward Islands. Forecasters fear it may turn into a tropical storm.

## Connecticut parents enraged over high school teacher's 'woke' worksheet: 'Underserving the students'
 - [https://www.foxnews.com/media/connecticut-parents-enraged-high-school-teachers-woke-worksheet-underserving-students](https://www.foxnews.com/media/connecticut-parents-enraged-high-school-teachers-woke-worksheet-underserving-students)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 20:21:31+00:00

Connecticut father of five Michael Kryzanski argues the school is focusing on teaching the wrong things after a "woke" worksheet is distributed to students.

## Federal judge says Alabama must stop being vague about use of nitrogen hypoxia in next week's execution
 - [https://www.foxnews.com/us/federal-judge-says-alabama-must-stop-being-vague-about-use-nitrogen-hypoxia-next-weeks-execution](https://www.foxnews.com/us/federal-judge-says-alabama-must-stop-being-vague-about-use-nitrogen-hypoxia-next-weeks-execution)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 19:34:03+00:00

A federal judge has ruled that Alabama must be clear about the prison system's plan to use nitrogen hypoxia at next week's execution. The execution method is untested.

## Lydia York wins Delaware's Democratic primary for state auditor
 - [https://www.foxnews.com/us/lydia-york-wins-delawares-democratic-primary-state-auditor](https://www.foxnews.com/us/lydia-york-wins-delawares-democratic-primary-state-auditor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 19:33:13+00:00

Political newcomer Lydia York won Delaware's Democratic primary for state auditor on Tuesday. York will face Republican Janice Lorrah in the November general election.

## Ohio school board meeting gets heated over 'woke' policy keeping parents in dark about kids’ gender changes
 - [https://www.foxnews.com/politics/ohio-school-board-meeting-gets-heated-policy-keeping-parents-dark-students-name-pronoun-change](https://www.foxnews.com/politics/ohio-school-board-meeting-gets-heated-policy-keeping-parents-dark-students-name-pronoun-change)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 19:28:12+00:00

Community members accused the Mentor Public Schools Board of Education of trampling on parents' rights with a policy regarding students' name and pronoun changes.

## Indiana police search for teens who allegedly stole puppies from pet store
 - [https://www.foxnews.com/us/indiana-police-search-teens-allegedly-stole-puppies-pet-store](https://www.foxnews.com/us/indiana-police-search-teens-allegedly-stole-puppies-pet-store)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 19:27:09+00:00

Indiana police are searching for two teenagers who they say took 10 puppies from a pet store on late Sunday night into early Monday morning.

## Stephen Curry regrets not boycotting playoff game amid former Clippers owner's racist comments
 - [https://www.foxnews.com/sports/stephen-curry-regrets-not-boycotting-playoff-game-amid-former-clippers-owners-racist-comments](https://www.foxnews.com/sports/stephen-curry-regrets-not-boycotting-playoff-game-amid-former-clippers-owners-racist-comments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 19:20:15+00:00

In 2014, it was revealed that then-Clippers owner Donald Sterling had used racial slurs. That prompted discussions for them and the Warriors to boycott a playoff game.

## Arizona police group calls on Dem Katie Hobbs to condemn pro-choice groups that support defunding the police
 - [https://www.foxnews.com/politics/arizona-police-group-calls-democrat-katie-hobbs-condemn-pro-choice-groups-support-defunding-police](https://www.foxnews.com/politics/arizona-police-group-calls-democrat-katie-hobbs-condemn-pro-choice-groups-support-defunding-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 19:19:22+00:00

The Arizona Police Association is calling on Katie Hobbs to condemn two pro-choice organizations who have endorsed her over their support for defunding the police.

## Fishing boat sinks off New England coast, NTSB calls for stricter safety inspections
 - [https://www.foxnews.com/us/fishing-boat-sinks-new-england-coast-ntsb-calls-stricter-safety-inspections](https://www.foxnews.com/us/fishing-boat-sinks-new-england-coast-ntsb-calls-stricter-safety-inspections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 19:18:34+00:00

A fishing boat capsized off of New England, claiming the lives of all four fishermen aboard. The NTSB is now calling for stricter safety inspections after the tragedy.

## Biden inflation bill celebration: Mainstream media takes notice of ‘unfortunate’ timing as market plunged
 - [https://www.foxnews.com/media/biden-inflation-celebration-mainstream-media-takes-notice-unfortunate-timing-market-plunged](https://www.foxnews.com/media/biden-inflation-celebration-mainstream-media-takes-notice-unfortunate-timing-market-plunged)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 19:18:16+00:00

President Biden celebrated the Inflation Reduction Act Tuesday as inflation rose 8.3% in August, grocery costs remained high and the stock market plunged.

## Abortion ban in Indiana set to take effect on Thursday
 - [https://www.foxnews.com/us/abortion-ban-indiana-set-take-effect-thursday](https://www.foxnews.com/us/abortion-ban-indiana-set-take-effect-thursday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 19:08:25+00:00

An abortion ban is set to take effect in Indiana on Thursday, following the Supreme Court's decision to overturn Roe v. Wade. Indiana will join over a dozen states with abortion bans.

## 'Serial' podcast subject Adnan Syed's conviction should be vacated, prosecutors reportedly argue
 - [https://www.foxnews.com/us/serial-podcast-subject-adnan-syeds-conviction-should-vacated-prosecutors-argue-report](https://www.foxnews.com/us/serial-podcast-subject-adnan-syeds-conviction-should-vacated-prosecutors-argue-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 18:41:53+00:00

Baltimore prosecutors reportedly filed a motion on Wednesday saying new evidence has been discovered in Adnan Syed's murder case and requested that his conviction be vacated.

## House Dems won't say when Inflation Reduction Act will reduce inflation as US families struggle
 - [https://www.foxnews.com/politics/house-dems-wont-say-when-inflation-reduction-act-will-reduce-inflation-us-families-struggle](https://www.foxnews.com/politics/house-dems-wont-say-when-inflation-reduction-act-will-reduce-inflation-us-families-struggle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 18:36:21+00:00

A couple House Democrats would not answer questions from Fox News Digital on when the Inflation Reduction Act, which was signed by President Biden, will reduce inflation.

## Law enforcement turns to new tech solutions to help cops in the field
 - [https://www.foxnews.com/tech/law-enforcement-turns-to-new-tech-solutions-to-help-cops-in-the-field](https://www.foxnews.com/tech/law-enforcement-turns-to-new-tech-solutions-to-help-cops-in-the-field)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 18:36:15+00:00

A growing number of police departments are turning to new mobile apps to help cops streamline the job, allowing them to better serve their communities.

## New Philippines president fighting back against China's incursions
 - [https://www.foxnews.com/world/new-philippines-president-fighting-back-against-chinas-incursions](https://www.foxnews.com/world/new-philippines-president-fighting-back-against-chinas-incursions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 18:34:13+00:00

Philippine President Ferdinand 'Bongbong' Marcos is pushing back against Chinese incursions into the South China Sea, which the Philippines have called called an 'illegal presence.'

## Democrats reject GOP inquiry into DHS ‘disinformation’ board
 - [https://www.foxnews.com/us/democrats-reject-gop-inquiry-into-dhs-disinformation-board](https://www.foxnews.com/us/democrats-reject-gop-inquiry-into-dhs-disinformation-board)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 18:29:05+00:00

House Democrats made it clear they would not support GOP efforts to get to the bottom of how the controversial Disinformation Governance Board was established.

## Chiefs' Patrick Mahomes provides update on wrist injury suffered in Week 1
 - [https://www.foxnews.com/sports/chiefs-patrick-mahomes-provides-update-wrist-injury-suffered-week-1](https://www.foxnews.com/sports/chiefs-patrick-mahomes-provides-update-wrist-injury-suffered-week-1)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 18:11:26+00:00

Kansas City Chiefs quarterback Patrick Mahomes told reporters Tuesday that he should be "good to go" against the Los Angeles Chargers on Thursday after injuring his wrist in Week 1.

## 'Pike County Massacre' trial: Ohio man recounts loss of 8 family members in one day
 - [https://www.foxnews.com/us/pike-county-massacre-trial-ohio-man-recounts-loss-8-family-members-one-day](https://www.foxnews.com/us/pike-county-massacre-trial-ohio-man-recounts-loss-8-family-members-one-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 18:09:26+00:00

An Ohio logger spoke publicly for the first time about the massacre of eight members of his family by another family when he testified Tuesday at the trial of one of the alleged killers.

## California teacher busted for being drunk at school in front of students
 - [https://www.foxnews.com/us/california-teacher-busted-being-drunk-school-front-students](https://www.foxnews.com/us/california-teacher-busted-being-drunk-school-front-students)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 18:07:18+00:00

A California teacher was arrested and charged after school officials caught him allegedly instructing children while drunk and with alcohol on the property, authorities said.

## Ben Domenech on 'Kilmeade Show': GOP candidates need to focus on the border and crime
 - [https://www.foxnews.com/media/ben-domenech-kilmeade-show-gop-candidates-need-focus-border-crime](https://www.foxnews.com/media/ben-domenech-kilmeade-show-gop-candidates-need-focus-border-crime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 18:03:53+00:00

Ben Domenech explains that Republicans need to focus on crime and the crisis on the border and not just economic issues if they want to win midterm elections.

## Harry is 'terrified' that Meghan will leave him alone to attend funeral: royal expert
 - [https://www.foxnews.com/entertainment/harry-terrified-meghan-leave-him-alone-attend-funeral-royal-expert](https://www.foxnews.com/entertainment/harry-terrified-meghan-leave-him-alone-attend-funeral-royal-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 18:03:48+00:00

Royal expert Neil Sean on the latest on Prince Harry and Meghan as they continue to attract headlines in the U.K. and around the world. Could Meghan go back to California before the funeral?

## 'The View' host slams Sen. Graham's abortion bill: 'There is no such thing' as late-term abortion
 - [https://www.foxnews.com/media/the-view-host-slams-sen-grahams-abortion-bill-theres-no-such-thing-late-term-abortion](https://www.foxnews.com/media/the-view-host-slams-sen-grahams-abortion-bill-theres-no-such-thing-late-term-abortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 17:33:57+00:00

On Wednesday, "The View" host Sara Haines claimed "there is no such thing" as "late-term abortions" while slamming the GOP's proposed federal abortion ban.

## Stacey Abrams praised on 'The View' for not conceding election, defends saying she 'won' Georgia race in 2018
 - [https://www.foxnews.com/media/stacey-abrams-praised-view-conceding-election-defends-saying-she-won-georgia-race-2018](https://www.foxnews.com/media/stacey-abrams-praised-view-conceding-election-defends-saying-she-won-georgia-race-2018)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 17:33:36+00:00

"The View" co-host Sunny Hostin praised Stacey Abrams on "The View" on Wednesday for not conceding the 2018 gubernatorial election to Gov. Brian Kemp.

## Former Twitter engineer admits access to user data under grilling from Sen. Josh Hawley: 'Yes or no?'
 - [https://www.foxnews.com/politics/former-twitter-engineer-admits-access-user-data-under-grilling-sen-josh-hawley-yes-no](https://www.foxnews.com/politics/former-twitter-engineer-admits-access-user-data-under-grilling-sen-josh-hawley-yes-no)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 17:31:54+00:00

Sen. Josh Hawley squeezed an admission out of a former Twitter executive that he did have access to private user data during his time at the company Wednesday.

## Kayleigh McEnany calls out Karine Jean-Pierre for border security 'lie' on 'Outnumbered'
 - [https://www.foxnews.com/media/kayleigh-mcenany-calls-karine-jean-pierre-border-security-lie-outnumbered](https://www.foxnews.com/media/kayleigh-mcenany-calls-karine-jean-pierre-border-security-lie-outnumbered)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 17:30:27+00:00

White House Press Secretary Karine Jean-Pierre argued Biden has done 'more' to secure the southern border than Trump despite the ongoing influx of migrants

## First Alaska native sworn in Congress
 - [https://www.foxnews.com/us/first-alaska-native-sworn-congress](https://www.foxnews.com/us/first-alaska-native-sworn-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 17:30:05+00:00

Democrat Mary Peltola was sworn in Congress as the first Alaska native. Peltola will finish out the remaining months of the term of late Rep. Don Young, who died in March.

## Wolf population increasing in Oregon, wildlife officials say
 - [https://www.foxnews.com/us/wolf-population-increasing-oregon-wildlife-officials-say](https://www.foxnews.com/us/wolf-population-increasing-oregon-wildlife-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 17:28:46+00:00

Oregon officials identified a new family of wolves in the northern Cascade Mountains. They now have three wolf groups, which suggests wolves are recovering in the state.

## Fetterman agrees to a live debate with Oz in late October
 - [https://www.foxnews.com/politics/fetterman-agrees-live-debate-oz-late-october](https://www.foxnews.com/politics/fetterman-agrees-live-debate-oz-late-october)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 17:27:21+00:00

Pennsylvania Democratic Senate nominee John Fetterman has committed to a televised debate against Dr. Mehmet Oz on October 25.

## A'ja Wilson's message to Kelsey Plum helped Aces to WNBA Finals Game 2 win
 - [https://www.foxnews.com/sports/aja-wilsons-message-kelsey-plum-helped-aces-wnba-finals-game-2-win](https://www.foxnews.com/sports/aja-wilsons-message-kelsey-plum-helped-aces-wnba-finals-game-2-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 17:26:21+00:00

The Las Vegas Aces received an inspired performance from Kelsey Plum and A'ja Wilson to defeat the Connecticut Sun in Game 2 of the WNBA playoffs.

## Ramaswamy: Elon Musk paved the way for Twitter shareholders to speak out against censorship practices
 - [https://www.foxnews.com/media/ramaswamy-elon-musk-paved-way-twitter-shareholders-speak-censorship-practices](https://www.foxnews.com/media/ramaswamy-elon-musk-paved-way-twitter-shareholders-speak-censorship-practices)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 17:24:38+00:00

"Nation of Victims" author Vivek Ramaswamy says social media shareholders are mostly everyday American citizens who can stand up for free speech principles.

## Minnesota man sentenced to life for selling fentanyl from 'China-based drug suppliers' that killed 11 people
 - [https://www.foxnews.com/us/minnesota-man-sentenced-life-selling-fentanyl-china-based-drug-suppliers-killed-11-people](https://www.foxnews.com/us/minnesota-man-sentenced-life-selling-fentanyl-china-based-drug-suppliers-killed-11-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 17:23:56+00:00

A Minnesota drug dealer who sold what he thought was knock-off Adderall was sentenced to life for not warning U.S. customers upon discovering the Chinese shipment was actually fentanyl.

## Parkland shooting trial: Judge lashes out at defense lawyers after they rested their case
 - [https://www.foxnews.com/us/parkland-shooting-trial-judge-lashes-defense-team-resting-case](https://www.foxnews.com/us/parkland-shooting-trial-judge-lashes-defense-team-resting-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 16:36:00+00:00

Florida school shooter Nikolas Cruz's defense team abruptly rested their case Tuesday with no advance warning, eliciting a spirited scolding from the judge for wasting the court's time.

## Jason Chaffetz roasts Biden admin for holding inflation bill 'party' while Americans struggle
 - [https://www.foxnews.com/media/jason-chaffetz-roasts-biden-admin-holding-inflation-bill-party-americans-struggle](https://www.foxnews.com/media/jason-chaffetz-roasts-biden-admin-holding-inflation-bill-party-americans-struggle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 16:34:40+00:00

Fox News contributor Jason Chaffetz rips Democrats for passing the Green New Deal under the guise of the Inflation Reduction Act.

## WHO director-general says 'the end is in sight' for COVID pandemic
 - [https://www.foxnews.com/health/who-director-general-says-end-sight-covid-pandemic](https://www.foxnews.com/health/who-director-general-says-end-sight-covid-pandemic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 16:29:05+00:00

WHO Director-General Tedros Adhanom Ghebreyesus believes that the world is in a great position to end the COVID pandemic and that "the end is in sight."

## Israel plans on offering updated coronavirus booster by September
 - [https://www.foxnews.com/health/israel-plans-offering-updated-coronavirus-booster-september](https://www.foxnews.com/health/israel-plans-offering-updated-coronavirus-booster-september)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 16:27:03+00:00

Israel plans on offering Phizer and BioNtechs' updated COVID booster by September, which offers protection from the Omicron BA.4/5 subvariants.

## LIV golfers to compete for $50 million purse in end-of-season team championship event: report
 - [https://www.foxnews.com/sports/liv-golfers-to-compete-50-million-purse-end-season-team-championship-event-report](https://www.foxnews.com/sports/liv-golfers-to-compete-50-million-purse-end-season-team-championship-event-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 16:23:16+00:00

LIV Golf's season-ending team championship event will offer a $50 million purse, the richest purse in the history of the sport. There will be 12 four-man teams competing.

## Pentagon accused of 'ideological litmus test' over vaccine mandate: 'Probably breaking the law'
 - [https://www.foxnews.com/media/pentagon-accused-ideological-litmus-test-vaccine-mandate-probably-breaking-law](https://www.foxnews.com/media/pentagon-accused-ideological-litmus-test-vaccine-mandate-probably-breaking-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 16:20:54+00:00

First Liberty's senior counsel Mike Berry slammed the Department of Defense's vaccine mandate, warning it is an 'ideological litmus test' on 'Fox & Friends'

## Wichita City Council votes to decriminalize possession of small amounts of marijuana, fentanyl test kits
 - [https://www.foxnews.com/us/wichita-city-council-votes-decriminalize-possession-small-amounts-marijuana-fentanyl-test-kits](https://www.foxnews.com/us/wichita-city-council-votes-decriminalize-possession-small-amounts-marijuana-fentanyl-test-kits)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 16:19:49+00:00

The Wichita City Council voted to decriminalize fentanyl test kits and the possession of small amounts of marijuana. This is expected to eliminate up to 850 prosecutions a year.

## MSU president acknowledges 'moment of uncertainty' on campus, some call for his departure
 - [https://www.foxnews.com/us/msu-president-acknowledges-moment-uncertainty-campus-call-departure](https://www.foxnews.com/us/msu-president-acknowledges-moment-uncertainty-campus-call-departure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 16:13:51+00:00

Michigan State University's president Samuel Stanley Jr. acknowledged a "moment of uncertainty" on campus. This comes as some are calling for the president's departure.

## King Charles III takes ownership of Britain's swans
 - [https://www.foxnews.com/lifestyle/king-charles-iii-takes-ownership-britains-swans](https://www.foxnews.com/lifestyle/king-charles-iii-takes-ownership-britains-swans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 16:12:11+00:00

King Charles III has inherited ownership of Britain’s swans from the late Queen Elizabeth II, following a tradition that dates back to medieval times.

## Queen Elizabeth II tributes planned as Premier League returns to play
 - [https://www.foxnews.com/sports/queen-elizabeth-ii-tributes-planned-premier-league-returns-play](https://www.foxnews.com/sports/queen-elizabeth-ii-tributes-planned-premier-league-returns-play)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 16:10:33+00:00

The Premier League will return to the pitch this weekend with plenty of tributes planned in order to honor Queen Elizabeth II who died last week.

## 9/11 memorial speaker warns Democrats: Don't 'forget history' by backing soft-on-crime, 'open border' policies
 - [https://www.foxnews.com/politics/9-11-memorial-speaker-warns-democrats-dont-forget-history-backing-soft-crime-open-border-policies](https://www.foxnews.com/politics/9-11-memorial-speaker-warns-democrats-dont-forget-history-backing-soft-crime-open-border-policies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 16:07:16+00:00

A relative of a 9/11 victim told Fox News Digital that Democrat-backed soft-on-crime and open border policies put citizens in danger, warning politicians not to "repeat history."

## Gingrich on New Hampshire Senate race: 'Very real likelihood' Bolduc will beat Hassan
 - [https://www.foxnews.com/media/gingrich-new-hampshire-senate-race-real-likelihood-bolduc-beat-hassan](https://www.foxnews.com/media/gingrich-new-hampshire-senate-race-real-likelihood-bolduc-beat-hassan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 15:32:47+00:00

Former Speaker of the House Newt Gingrich sounds off on the "hypocrisy" of Democrat PACs funding "MAGA Republicans" in midterm races on "America's Newsroom."

## Southern California mudslides damage homes, carry away cars
 - [https://www.foxnews.com/us/southern-california-mudslides-damage-homes-carry-away-cars](https://www.foxnews.com/us/southern-california-mudslides-damage-homes-carry-away-cars)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 15:31:05+00:00

Mudslides in Southern California have damaged homes and carried away cars. Residents in the area are prompted to evacuate as cleanup efforts are underway.

## Trump stayed neutral, but MAGA candidates still swept fiery GOP primaries in battleground New Hampshire
 - [https://www.foxnews.com/politics/trump-stayed-neutral-maga-candidates-still-swept-fiery-gop-primaries-battleground-new-hampshire](https://www.foxnews.com/politics/trump-stayed-neutral-maga-candidates-still-swept-fiery-gop-primaries-battleground-new-hampshire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 15:28:04+00:00

A trio of MAGA style, outsider and populist Republican candidates edged out more mainstream GOP rivals in key primaries in battleground New Hampshire, even as Trump stayed neutral

## Paralyzed Minnesota HS football comes off ventilator, utters first words
 - [https://www.foxnews.com/sports/paralyzed-minnesota-hs-football-comes-off-ventilator-utters-first-words](https://www.foxnews.com/sports/paralyzed-minnesota-hs-football-comes-off-ventilator-utters-first-words)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 15:23:10+00:00

A Minnesota high school football quarterback uttered his first words after coming off a ventilator and had an Alabama spin. The family updated his condition this week.

## FBI charges three Iranians in cyber attacks targeting local US governments, power companies
 - [https://www.foxnews.com/politics/fbi-charges-three-iranians-cyber-attacks-targeting-local-us-governments-power-companies](https://www.foxnews.com/politics/fbi-charges-three-iranians-cyber-attacks-targeting-local-us-governments-power-companies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 15:21:50+00:00

Senior officials from the Department of Justice and the FBI told reporters Wednesday that three Iranian individuals have been indicted on cyber-related crimes after attacking U.S. infrastructure.

## Detroit cop resigns after racy OnlyFans page discovered by department
 - [https://www.foxnews.com/us/detroit-cop-resigns-racy-onlyfans-page-discovered-department](https://www.foxnews.com/us/detroit-cop-resigns-racy-onlyfans-page-discovered-department)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 15:21:26+00:00

Former Detroit police officer Janelle Zielinski resigned after the department discovered an OnlyFans page she was running, which prompted an investigation.

## Emmys reach record-low audience with 5.9 million people
 - [https://www.foxnews.com/entertainment/emmys-reach-record-low-audience-5-9-million-people](https://www.foxnews.com/entertainment/emmys-reach-record-low-audience-5-9-million-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 15:17:21+00:00

The Emmy Awards viewership was down to an all-time low, with an estimated audience of 5.9 million people. This is even lower than the 2020 ceremony, which was disrupted by COVID.

## Homeland Security sells home of Boston couple illegally doing business with Syrian company
 - [https://www.foxnews.com/us/us-sells-home-boston-couple-illegally-doing-business-syrian-company](https://www.foxnews.com/us/us-sells-home-boston-couple-illegally-doing-business-syrian-company)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 15:09:23+00:00

A Boston couple doing business with a Syrian company that makes Improvised explosive devices has had their home sold by Homeland Security.

## Education Dept. says 'clerical error' deleted thousands of comments on Title IX 'gender identity' proposal
 - [https://www.foxnews.com/politics/education-department-says-clerical-error-deleted-thousands-comments-gender-identity-proposal](https://www.foxnews.com/politics/education-department-says-clerical-error-deleted-thousands-comments-gender-identity-proposal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 15:07:20+00:00

Officials say a "clerical error" has caused hundreds of thousands of responses regarding President Biden's update to Title IX rule to disappear from the Federal Register.

## Alyssa Farah Griffin says Lindsey Graham consumed 'the whole news cycle' with 15-week abortion ban bill
 - [https://www.foxnews.com/media/alyssa-farah-griffin-says-lindsey-graham-consumed-whole-news-cycle-15-week-abortion-ban-bill](https://www.foxnews.com/media/alyssa-farah-griffin-says-lindsey-graham-consumed-whole-news-cycle-15-week-abortion-ban-bill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 15:03:55+00:00

CNN's Alyssa Farah Griffin said Wednesday that Sen. Lindsey Graham, R-S.C., drew attention away from inflation with his abortion policy announcement on Tuesday.

## Lions, Browns bucking the betting trends ahead of Week 2 matchups
 - [https://www.foxnews.com/sports/lions-browns-bucking-betting-trends-ahead-week-2-matchups](https://www.foxnews.com/sports/lions-browns-bucking-betting-trends-ahead-week-2-matchups)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 14:42:59+00:00

The Cleveland Browns are favored to start the season 2-0 for the first time since 1993 while the Detroit Lions are favored to win a game for the first time in 24 tries.

## Ex-Chiefs coach's plea deal in 2021 crash 'slap on the wrist,' mom of seriously injured girl says
 - [https://www.foxnews.com/sports/ex-chiefs-coachs-plea-deal-2021-crash-slap-wrist-mom-seriously-injured-girl-says](https://www.foxnews.com/sports/ex-chiefs-coachs-plea-deal-2021-crash-slap-wrist-mom-seriously-injured-girl-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 14:39:41+00:00

Felicia Miller, the mother of a girl who was seriously injured in a February 2021 crash involving former Chiefs coach Britt Reid slammed a plea deal agreement.

## School board member rejects Connecticut teacher's worksheet on White privilege, systemic racism
 - [https://www.foxnews.com/media/school-board-member-rejects-connecticut-teachers-worksheet-white-privilege-systemic-racism](https://www.foxnews.com/media/school-board-member-rejects-connecticut-teachers-worksheet-white-privilege-systemic-racism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 14:36:01+00:00

Southington school board vice-chairman Joseph Baczewski on "Fox & Friends First" Wednesday reacts to a school pushing woke curriculum including lessons about "white privilege."

## Hawley to introduce bill to create select committee investigating Afghanistan withdrawal
 - [https://www.foxnews.com/politics/hawley-introduce-bill-create-select-committee-investigating-afghanistan-withdrawal](https://www.foxnews.com/politics/hawley-introduce-bill-create-select-committee-investigating-afghanistan-withdrawal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 14:31:43+00:00

Republican Missouri Senator Josh Hawley is introducing legislation to establish a select committee on President Biden's deadly and botched Afghanistan withdrawal.

## West Virginia Interstate 77 bridge reopens following repairs
 - [https://www.foxnews.com/us/west-virginia-interstate-77-bridge-reopens-following-repairs](https://www.foxnews.com/us/west-virginia-interstate-77-bridge-reopens-following-repairs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 14:25:16+00:00

Interstate 77 bridge in West Virginia has been repaired and is now fully open. The bridge had been hit by heavy trucks multiple times over the years prior to the repair.

## The 2023 Chevrolet Tahoe RST Performance Edition is a pricey police truck for everyone
 - [https://www.foxnews.com/auto/chevrolet-tahoe-rst-performance-edition-police-truck](https://www.foxnews.com/auto/chevrolet-tahoe-rst-performance-edition-police-truck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 14:25:10+00:00

The 2023 Chevrolet Tahoe RST Performance Edition borrows features from the Tahoe Police Pursuit Vehicle to improve the full-size SUV's speed and handling.

## Death toll from Kentucky flood reaches 40, latest victim died during cleanup effort
 - [https://www.foxnews.com/us/death-toll-kentucky-flood-reaches-40-latest-victim-died-cleanup-effort](https://www.foxnews.com/us/death-toll-kentucky-flood-reaches-40-latest-victim-died-cleanup-effort)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 14:24:53+00:00

The death toll from the Kentucky floods that hit the state in July has risen to 40 after a person died during a cleanup effort in Pike County.

## Washington Post column says Democrats cannot ‘wish away’ inflation before midterms, could get worse next year
 - [https://www.foxnews.com/media/washington-post-column-democrats-cannot-wish-away-inflation-before-midterms-could-get-worse-next-year](https://www.foxnews.com/media/washington-post-column-democrats-cannot-wish-away-inflation-before-midterms-could-get-worse-next-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 14:17:28+00:00

Washington Post columnist Henry Olsen wrote inflation could have negative political implications for Democrats in the midterms and in the 2024 election.

## Illinois mayor demands apology from Gov. Pritzker over migrant bussing remark: 'Don't ever call us xenophobic'
 - [https://www.foxnews.com/media/illinois-mayor-demands-apology-pritzker-migrant-bussing-ever-call-xenophobic](https://www.foxnews.com/media/illinois-mayor-demands-apology-pritzker-migrant-bussing-ever-call-xenophobic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 14:13:26+00:00

Elk Grove Village Mayor Craig Johnson said Gov. Pritzker owes an apology to the residents in his community who have welcomed the migrants and worked to accommodate them.

## Ukraine-Russia war: Zelenskyy visits newly liberated Izium, officials decry signs of torture
 - [https://www.foxnews.com/world/ukraine-russia-war-zelenskyy-visits-newly-liberated-izium-officials-decry-signs-torture](https://www.foxnews.com/world/ukraine-russia-war-zelenskyy-visits-newly-liberated-izium-officials-decry-signs-torture)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 14:05:30+00:00

Ukrainian President Volodymyr Zelenskyy traveled to the liberated town of Izium to thank his troops and see what Russia left in its wake after its forces withdrew last week.

## President Biden used taxpayer-funded jet, motorcades to vote in person rather than casting absentee ballot
 - [https://www.foxnews.com/politics/president-biden-used-taxpayer-funded-jet-motorcades-vote-person-rather-than-casting-absentee-ballot](https://www.foxnews.com/politics/president-biden-used-taxpayer-funded-jet-motorcades-vote-person-rather-than-casting-absentee-ballot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 13:31:43+00:00

President Biden enlisted Air Force One, motorcades and police protection to vote in-person in Delaware. The White House has not clarified why he didn't file an absentee ballot.

## Tony Robbins, life strategist and philanthropist, aims to feed one billion hungry people
 - [https://www.foxnews.com/lifestyle/tony-robbins-life-strategist-philanthropist-aims-feed-billion-hungry-people](https://www.foxnews.com/lifestyle/tony-robbins-life-strategist-philanthropist-aims-feed-billion-hungry-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 13:31:38+00:00

Tony Robbins, author, philanthropist and life and business strategist, is aiming to provide 1 billion meals to the food insecure in the U.S., with Feeding America. He spoke to Fox News Digital.

## Justices Kagan, Gorsuch hint Supreme Court leak update could come by end of September
 - [https://www.foxnews.com/politics/justices-kagan-gorsuch-hint-supreme-court-leak-update-could-come-end-september](https://www.foxnews.com/politics/justices-kagan-gorsuch-hint-supreme-court-leak-update-could-come-end-september)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 13:29:53+00:00

Supreme Court Justices Elena Kagan and Neil Gorsuch have suggested there could soon be an update into the Dobbs v. Jackson leak investigation. The inquiry has lasted months.

## Valerie Bertinelli selling items worn by her during wedding to ex husband Tom Vitale: 'bad memories attached'
 - [https://www.foxnews.com/entertainment/valerie-bertinelli-selling-items-worn-by-her-during-wedding-ex-husband-tom-vitale-bad-memories-attached](https://www.foxnews.com/entertainment/valerie-bertinelli-selling-items-worn-by-her-during-wedding-ex-husband-tom-vitale-bad-memories-attached)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 13:29:39+00:00

Valerie Bertinelli is selling off personal clothing items she wore at her wedding to ex husband Tom Vitale, revealing that "bad memories [are] attached."

## Clay Travis hammers Biden's inflation bill celebration: Everyone involved 'should be fired immediately'
 - [https://www.foxnews.com/media/clay-travis-hammers-biden-inflation-bill-celebration-everyone-involved-fired-immediately](https://www.foxnews.com/media/clay-travis-hammers-biden-inflation-bill-celebration-everyone-involved-fired-immediately)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 13:29:31+00:00

OutKick founder Clay Travis warned everyone involved in the White House's celebration of the Inflation Reduction Act should be 'immediately fired'

## The 2023 Jeep Wrangler Willys 4xe is a retro hybrid SUV
 - [https://www.foxnews.com/auto/2023-jeep-wrangler-willys-4xe-retro-hybrid-suv](https://www.foxnews.com/auto/2023-jeep-wrangler-willys-4xe-retro-hybrid-suv)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 13:17:56+00:00

The 2023 Jeep Wrangler Willys 4xe is a new version of the plug-in hybrid SUV that features throwback touches inspired by the original Jeep and new off-road gear.

## Virginia county supervisors vote to change names of highways named after Confederate generals
 - [https://www.foxnews.com/us/virginia-county-supervisors-vote-change-names-highways-named-confederate-generals](https://www.foxnews.com/us/virginia-county-supervisors-vote-change-names-highways-named-confederate-generals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 13:13:31+00:00

Supervisors in Fairfax County voted to change the name of two highways named after Robert E. Lee and Stonewall Jackson. The board's lone Republican was the sole vote against the change.

## Iowa Republican’s new six-figure ad buy gives Biden ‘the Bird’
 - [https://www.foxnews.com/politics/iowa-republicans-six-figure-ad-buy-gives-biden-bird](https://www.foxnews.com/politics/iowa-republicans-six-figure-ad-buy-gives-biden-bird)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 13:12:35+00:00

Brenna Bird, the GOP candidate for Iowa's attorney general, released a new ad encouraging Hawkeye State voters to give President Biden "the Bird" by electing her.

## Steelers rookie has Mike Tomlin looking on bright side for strange reason
 - [https://www.foxnews.com/sports/steelers-rookie-mike-tomlin-looking-bright-side-strange-reason](https://www.foxnews.com/sports/steelers-rookie-mike-tomlin-looking-bright-side-strange-reason)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 13:07:43+00:00

Jaylen Warren found himself on the Pittsburgh Steelers' roster to start the 2022 NFL season and though he didn't make that big of an impact in Week 1, Mike Tomlin is still encouraged.

## Good teachers should cross picket lines to teach kids
 - [https://www.foxnews.com/opinion/good-teachers-should-cross-picket-lines-teach-kids](https://www.foxnews.com/opinion/good-teachers-should-cross-picket-lines-teach-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 13:00:24+00:00

Teachers unions need some way to keep the COVID mayhem going, so strikes are happening across America.

## Gleyber Torres' bases-clearing double gives Yankees win over Red Sox in 10 innings
 - [https://www.foxnews.com/sports/gleyber-torres-bases-clearing-double-gives-yankees-win-red-sox-10-innings](https://www.foxnews.com/sports/gleyber-torres-bases-clearing-double-gives-yankees-win-red-sox-10-innings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 07:17:25+00:00

Aaron Judge hit his 56th and 57th home runs of the season, while Gleyber Torres' bases-clearing double proved to be the game-winner over the Red Sox on Tuesday.

## Twins pull Joe Ryan from no-hit bid after 7 innings
 - [https://www.foxnews.com/sports/twins-pull-joe-ryan-no-hit-bid-7-innings](https://www.foxnews.com/sports/twins-pull-joe-ryan-no-hit-bid-7-innings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 07:02:38+00:00

The Minnesota Twins decided to pull pitcher Joe Ryan from a potential no-hitter after seven innings. The bullpen ended up blowing the combined chance in the ninth inning.

## A revolt against America’s Queen Elizabeth coverage is building, but cable news can’t stay away
 - [https://www.foxnews.com/media/revolt-against-americas-queen-elizabeth-coverage-building-cable-news-cant-stay-away](https://www.foxnews.com/media/revolt-against-americas-queen-elizabeth-coverage-building-cable-news-cant-stay-away)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 06:59:31+00:00

Queen Elizabeth II's death has garnered mountains of media coverage. Some wish for coverage to turn back to former President Trump while others can't get enough of the royals.

## New York City homeless man sleeps on sidewalk with toaster oven, crisis worst 'since Great Depression'
 - [https://www.foxnews.com/lifestyle/new-york-city-homeless-man-sleeps-sidewalk-toaster-oven-crisis-great-depression](https://www.foxnews.com/lifestyle/new-york-city-homeless-man-sleeps-sidewalk-toaster-oven-crisis-great-depression)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 06:17:53+00:00

Fox News Digital discovered shocking new examples this week of the humanitarian crisis of homelessness in broad daylight in the heart of Midtown Manhattan, where tourists crowd the streets.

## Kiely Rodni: The volunteer dive team that found her remains suspects foul play
 - [https://www.foxnews.com/us/kiely-rodni-volunteer-dive-team-found-remains-suspects-foul-play](https://www.foxnews.com/us/kiely-rodni-volunteer-dive-team-found-remains-suspects-foul-play)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 06:00:55+00:00

The lead investigator of a for-profit search and rescue team that located the remains of California missing teen Kiely Rodni doesn't think her death was an accident.

## Republicans think Trump will be a midterm kingmaker. Democrats like me think he may be a spoiler
 - [https://www.foxnews.com/opinion/republicans-think-trump-midterm-kingmaker-democrats-think-spoiler](https://www.foxnews.com/opinion/republicans-think-trump-midterm-kingmaker-democrats-think-spoiler)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 06:00:47+00:00

Former President Donald Trump has seen a string of successes for his candidates in primary battles. But independent voters may be turned off by his endorsement and it could hurt.

## Pennsylvania voters reveal what will tip the state red or blue in November
 - [https://www.foxnews.com/politics/pennsylvania-voters-reveal-tip-state-red-blue-november](https://www.foxnews.com/politics/pennsylvania-voters-reveal-tip-state-red-blue-november)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 06:00:26+00:00

People in Allentown, Pennsylvania, shared which party they are leaning towards for the midterm elections and explained their reasons behind their decision.

## Prince Harry's tell-all book: What will he reveal, and could memoir destroy relationship with royal family?
 - [https://www.foxnews.com/entertainment/prince-harry-tell-all-book-what-will-he-reveal-could-memoir-destroy-relationship-royal-family](https://www.foxnews.com/entertainment/prince-harry-tell-all-book-what-will-he-reveal-could-memoir-destroy-relationship-royal-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 06:00:26+00:00

Prince Harry is releasing a book about his life, which may include the death of his mother, Princess Diana, his marriage to Meghan Markle, and becoming a father.

## Slanted abortion media coverage through the years has sown distrust on the right
 - [https://www.foxnews.com/media/slanted-abortion-media-coverage-through-years-sown-distrust-right](https://www.foxnews.com/media/slanted-abortion-media-coverage-through-years-sown-distrust-right)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 06:00:08+00:00

Conservatives don’t believe mainstream media treats the polarizing issue of abortion with the nuance required to give the pro-life argument a fair shake.

## Zero arrests in at least 16 Jane's Revenge attacks on pro-life organizations
 - [https://www.foxnews.com/politics/zero-arrests-16-janes-revenge-attacks-pro-life-organizations](https://www.foxnews.com/politics/zero-arrests-16-janes-revenge-attacks-pro-life-organizations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 06:00:01+00:00

Jane's Revenge's wave of pro-abortion vandalism and threats against pro-life organizations across the country has resulted in zero arrests, Fox News Digital has found.

## Vivek Ramaswamy: The New York Times might be better off having people work from home
 - [https://www.foxnews.com/media/vivek-ramaswamy-new-york-times-better-off-having-people-work-from-home](https://www.foxnews.com/media/vivek-ramaswamy-new-york-times-better-off-having-people-work-from-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 04:44:29+00:00

Vivek Ramaswamy discussed with Greg Gutfeld and guests how NYT employees are not happy about being asked to come back into the office on "Gutfeld!"

## Robert Dawson, accused of killing wife on Fiji honeymoon ordered held with no bail
 - [https://www.foxnews.com/us/robert-dawson-accused-killing-wife-fiji-honeymoon-ordered-held-with-no-bail](https://www.foxnews.com/us/robert-dawson-accused-killing-wife-fiji-honeymoon-ordered-held-with-no-bail)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 04:24:06+00:00

Tennessee newlywed Bradley Dawson, who is accused of killing his wife Christe Chen on their honeymoon at the exclusive Turtle Island Resort, was denied bail by a judge on Wednesday.

## GREG GUTFELD: Democrats think you're the real enemy
 - [https://www.foxnews.com/opinion/greg-gutfeld-democrats-think-youre-real-enemy](https://www.foxnews.com/opinion/greg-gutfeld-democrats-think-youre-real-enemy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 04:04:44+00:00

Greg Gutfeld discusses what issues the Democrats and progressives ignore and what issue they're running on for the 2022 midterm elections on "Gutfeld!"

## On this day in history, Sept. 14, 1814, American 'flag was still there' after attack on Fort McHenry
 - [https://www.foxnews.com/lifestyle/this-day-history-sept-14-1814-american-flag-still-there-attack-fort-mchenry](https://www.foxnews.com/lifestyle/this-day-history-sept-14-1814-american-flag-still-there-attack-fort-mchenry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 04:02:38+00:00

American Francis Scott Key awoke on the morning of Sept. 14, 1814, to find that "our flag was still there" after horrific 25-hour British naval bombardment of Fort McHenry in Baltimore.

## GOP lawmaker says Biden is the 'best thing that ever happened' to Putin
 - [https://www.foxnews.com/media/gop-lawmaker-says-biden-best-thing-ever-happened-putin](https://www.foxnews.com/media/gop-lawmaker-says-biden-best-thing-ever-happened-putin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 03:58:57+00:00

Fox News host Laura Ingraham spoke with Rep. Jim Banks and Victor Davis Hanson about the war in Ukraine and Chinese President Xi Jinping's meeting with Russian President Vladimir Putin.

## Karoline Leavitt projected winner in fierce GOP congressional primary in battleground New Hampshire
 - [https://www.foxnews.com/politics/karoline-leavitt-projected-winner-fierce-gop-congressional-primary-battleground-new-hampshire](https://www.foxnews.com/politics/karoline-leavitt-projected-winner-fierce-gop-congressional-primary-battleground-new-hampshire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 03:55:22+00:00

The AP projects that Karoline Leavitt will win the Republican primary in New Hampshire's First Congressional District, which has long been a highly contested swing House district.

## LAURA INGRAHAM: The numbers do not lie
 - [https://www.foxnews.com/media/laura-ingraham-numbers-do-not-lie](https://www.foxnews.com/media/laura-ingraham-numbers-do-not-lie)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 03:46:19+00:00

Laura Ingraham discusses how the U.S. economy has completely tanked under President Biden and highlights the numbers proving it on "The Ingraham Angle."

## Queen Elizabeth's funeral to delay formal rollout of House GOP agenda
 - [https://www.foxnews.com/politics/queen-elizabeths-funeral-delay-formal-rollout-house-gop-agenda](https://www.foxnews.com/politics/queen-elizabeths-funeral-delay-formal-rollout-house-gop-agenda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 03:37:32+00:00

Queen Elizabeth II's death is impacting American politics. House Republicans will delay the rollout of their agenda for the November election to avoid a conflict with her funeral.

## Chris Hayes warns ‘MAGA authoritarian lackeys’ will weaponize the DOJ for ‘Trump’s personal use and power’
 - [https://www.foxnews.com/media/chris-hayes-warns-maga-authoritarian-lackeys-weaponize-doj-trumps-personal-use-power](https://www.foxnews.com/media/chris-hayes-warns-maga-authoritarian-lackeys-weaponize-doj-trumps-personal-use-power)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 03:34:19+00:00

Chris Hayes claimed Tuesday that Trump regaining the presidency would corrupt the Department of Justice and turn it into his personal weapon.

## Kellyanne Conway: The Biden presidency is a 'split-screen presidency'
 - [https://www.foxnews.com/media/hannity-kellyanne-conway-biden-inflation-presidency](https://www.foxnews.com/media/hannity-kellyanne-conway-biden-inflation-presidency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 03:15:05+00:00

Kellyanne Conway says on "Hannity" that the American people know their financial situation after President Biden is celebrating how great everything is.

## What makes Ohio US Senate candidate Tim Ryan a 'lying fraud': Senate candidate JD Vance
 - [https://www.foxnews.com/media/ohio-us-senate-candidate-tim-ryan-lying-fraud-senate-candidate-jd-vance](https://www.foxnews.com/media/ohio-us-senate-candidate-tim-ryan-lying-fraud-senate-candidate-jd-vance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 03:08:52+00:00

Ohio U.S. Senate candidate J.D. Vance sounded off on his opponent Tim Ryan and Google's allegedly nefarious role in the midterm elections on "Hannity."

## TUCKER CARLSON: We're looking at a war on the population
 - [https://www.foxnews.com/opinion/tucker-carlson-looking-war-population](https://www.foxnews.com/opinion/tucker-carlson-looking-war-population)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 02:56:59+00:00

Fox News host Tucker Carlson voices his concerns over the increase in violent crime across U.S. cities and says it needs to change on "Tucker Carlson Tonight."

## Newt Gingrich outlines top issues Republicans should hit for midterms
 - [https://www.foxnews.com/media/newt-gingrich-top-issues-republicans-midterms](https://www.foxnews.com/media/newt-gingrich-top-issues-republicans-midterms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 02:45:47+00:00

Former House speaker Newt Gingrich joined "Hannity" to make the case for how Republicans can secure a majority in the 2022 midterm elections.

## SEAN HANNITY: The midterms can't come fast enough
 - [https://www.foxnews.com/media/sean-hannity-midterms-cant-come-fast-enough](https://www.foxnews.com/media/sean-hannity-midterms-cant-come-fast-enough)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 02:39:32+00:00

Sean Hannity discussed how the president attempted to celebrate his inflation bill as the latest report shows inflation still on the rise on "Hannity."

## Politico suggests Graham abortion bill saved Biden from day of embarrassment over economy
 - [https://www.foxnews.com/media/politico-suggests-graham-abortion-bill-saved-biden-day-embarrassment-over-economy](https://www.foxnews.com/media/politico-suggests-graham-abortion-bill-saved-biden-day-embarrassment-over-economy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 02:35:25+00:00

Politico reported that by revealing a new bill to restrict abortion, Senator Graham helped save Democrats and commentators from having to discuss the sinking economy.

## Candace Owens tells residents of Democrat-run inner cities: 'Don't wait for it to be you ... get out'
 - [https://www.foxnews.com/media/candace-owens-residents-democrat-run-inner-cities-dont-wait-get-out](https://www.foxnews.com/media/candace-owens-residents-democrat-run-inner-cities-dont-wait-get-out)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:55:46+00:00

Conservative commentator Candace Owens said Americans living in Democrat-run inner city communities should relocate as crime runs rampant across the U.S.

## Chicago shooting leaves 'multiple' injured: police
 - [https://www.foxnews.com/us/chicago-shooting-leaves-multiple-injured-police](https://www.foxnews.com/us/chicago-shooting-leaves-multiple-injured-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:55:31+00:00

A shooting in Chicago has left "multiple" people injured, police said Tuesday. It was not immediately clear exactly how many people were injured.

## Rubio riffs on Biden's inflation celebration: 'I'm embarrassed for James Taylor'
 - [https://www.foxnews.com/media/rubio-riffs-biden-inflation-celebration-embarrassed-james-taylor](https://www.foxnews.com/media/rubio-riffs-biden-inflation-celebration-embarrassed-james-taylor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:54:13+00:00

Sen. Marco Rubio snarked at James Taylor performing "America the Beautiful" as well as "Fire & Rain" at the White House during a ceremony on "Jesse Watters Primetime."

## 'Young Turks' host Cenk Uygur denounces 'defund the police' rhetoric as 'wildly counterproductive'
 - [https://www.foxnews.com/media/young-turks-host-cenk-uygur-denounces-defund-police-rhetoric-wildly-counterproductive](https://www.foxnews.com/media/young-turks-host-cenk-uygur-denounces-defund-police-rhetoric-wildly-counterproductive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:51:51+00:00

Cenk Uygur is one of many public figures who have radically changed their rhetoric on law-enforcement and police since the George Floyd riots raged across the US in 2020.

## Alabama prison escape: Inmate Casey White, guard Vicky White shared nearly 1,000 phone calls
 - [https://www.foxnews.com/us/alabama-prison-escape-inmate-casey-white-guard-vicky-white-shared-phone-calls](https://www.foxnews.com/us/alabama-prison-escape-inmate-casey-white-guard-vicky-white-shared-phone-calls)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:42:45+00:00

An Alabama prison inmate and jail guard reportedly shared 949 phone calls in the months leading up to his escape that initiated a large-scale manhunt.

## New York City children's drowning deaths at Coney Island ruled homicide, medical examiner says
 - [https://www.foxnews.com/us/three-new-york-city-childrens-drowning-deaths-ruled-homicide-medical-examiner-says](https://www.foxnews.com/us/three-new-york-city-childrens-drowning-deaths-ruled-homicide-medical-examiner-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:36:49+00:00

The drowning deaths of three children on a Coney Island beach early Monday morning were ruled homicides by the New York City Medical Examiner on Tuesday.

## Aaron Judge hits two home runs to inch closer to history
 - [https://www.foxnews.com/sports/aaron-judge-hits-two-home-runs-to-inch-closer-to-history](https://www.foxnews.com/sports/aaron-judge-hits-two-home-runs-to-inch-closer-to-history)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:34:18+00:00

The big man is at it again — Aaron Judge inched closer to breaking Roger Maris' 61 home runs in a single season with his 56th and 57th against the Boston Red Sox on Tuesday.

## Aaron Judge inches closer to history with 56th home run of season
 - [https://www.foxnews.com/sports/aaron-judge-inches-closer-history-with-56th-home-run-season](https://www.foxnews.com/sports/aaron-judge-inches-closer-history-with-56th-home-run-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:34:18+00:00

The big man is at it again — Aaron Judge inched closer to breaking Roger Maris' 61 home runs with his 56th against the Boston Red Sox on Tuesday.

## MSNBC's Stephanie Ruhle admits 'your raises mean nothing' because of rising inflation
 - [https://www.foxnews.com/media/msnbcs-stephanie-ruhle-admits-your-raises-mean-nothing-because-rising-inflation](https://www.foxnews.com/media/msnbcs-stephanie-ruhle-admits-your-raises-mean-nothing-because-rising-inflation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:29:51+00:00

MSNBC host Stephanie Ruhle who previously downplayed inflation, attacked the massive inflation rates that were released on Tuesday while appearing on “José Díaz-Balart Reports.”

## James Patterson on how spy novels differ from real-world politics
 - [https://www.foxnews.com/media/james-patterson-spy-novels-differ-real-world-politics](https://www.foxnews.com/media/james-patterson-spy-novels-differ-real-world-politics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:13:11+00:00

Bestselling author James Patterson joins "Jesse Watters Primetime" to promote the release of his new political thriller "Blowback" and compares it to what's really happening in politics.

## Eagles fans file lawsuit against Commanders claiming injuries when railing collapsed at FedEx Field
 - [https://www.foxnews.com/sports/eagles-fans-file-lawsuit-against-commanders-claiming-injuries-when-railing-collapsed-fedex-field](https://www.foxnews.com/sports/eagles-fans-file-lawsuit-against-commanders-claiming-injuries-when-railing-collapsed-fedex-field)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:09:57+00:00

Four Philadelphia Eagles fans have filed a lawsuit against the Washington Commanders seeking money for injuries they say they suffered after a game last season.

## 'Delusional elite' show their mismanagement in wake of Biden inflation bill party: Blake Masters
 - [https://www.foxnews.com/media/delusional-elite-show-mismanagement-wake-biden-inflation-bill-party-blake-masters](https://www.foxnews.com/media/delusional-elite-show-mismanagement-wake-biden-inflation-bill-party-blake-masters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 01:06:07+00:00

Arizona U.S. Senate candidate Blake Masters sounded off on President Biden and Democrats' dealings on inflation and the state of the economy on "Jesse Watters Primetime."

## JESSE WATTERS: Biden's entire presidency is a cover-up built on lies
 - [https://www.foxnews.com/media/jesse-watters-bidens-entire-presidency-cover-up-built-lies](https://www.foxnews.com/media/jesse-watters-bidens-entire-presidency-cover-up-built-lies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 00:54:31+00:00

Fox News host Jesse Watters calls out President Biden’s leadership as he celebrates the Inflation Reduction Act in a rough economy on “Jesse Watters Primetime.”

## Tom Brady on emotions about returning for Year 23: 'It's not like I have 10 years left'
 - [https://www.foxnews.com/sports/tom-brady-emotions-returning-year-23-its-not-like-have-10-years-left](https://www.foxnews.com/sports/tom-brady-emotions-returning-year-23-its-not-like-have-10-years-left)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 00:40:40+00:00

Tampa Bay Buccaneers quarterback Tom Brady discussed his intense emotions with Year 23 in the NFL underway, which stems from the fact that his time is limited in the NFL.

## Colts' Jonathan Taylor takes solace in tie but admits OT rule change 'might be nice,' talks fantasy football
 - [https://www.foxnews.com/sports/colts-jonathan-taylor-takes-solace-tie-admits-ot-rule-change-might-be-nice-talks-fantasy-football](https://www.foxnews.com/sports/colts-jonathan-taylor-takes-solace-tie-admits-ot-rule-change-might-be-nice-talks-fantasy-football)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 00:36:58+00:00

Colts running back Jonathan Taylor explained to Fox News Digital why he's seeing the bright side of Week 1's tie, what he's learned from each QB he's been with and more.

## CNN cuts from coverage of Biden’s Inflation Reduction Act speech as Dow plummets: 'Hard to be celebratory'
 - [https://www.foxnews.com/media/cnn-cuts-coverage-bidens-inflation-reduction-act-speech-dow-plummets-hard-celebratory](https://www.foxnews.com/media/cnn-cuts-coverage-bidens-inflation-reduction-act-speech-dow-plummets-hard-celebratory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 00:32:26+00:00

Multiple networks cut away from Biden's speech that took place a few weeks after the passage of the Inflation Reduction Act. Commentators on Twitter were quick to notice.

## Boston authorities respond to reports of object 'detonated' at Northeastern University; 1 injured
 - [https://www.foxnews.com/us/boston-authorities-respond-object-detonated-northeastern-university](https://www.foxnews.com/us/boston-authorities-respond-object-detonated-northeastern-university)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 00:28:24+00:00

Boston police and other agencies are on the scene of Northeastern University campus where they say a package detonated Tuesday evening, injuring one person.

## Virginia parents protest critical race theory outside Loudoun County School Board meeting
 - [https://www.foxnews.com/politics/virginia-parents-protest-critical-race-theory-loudoun-county-school-board](https://www.foxnews.com/politics/virginia-parents-protest-critical-race-theory-loudoun-county-school-board)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 00:24:56+00:00

Parent advocacy groups gathered outside a Loudoun County School Board meeting in Virginia on Tuesday to protest against critical race theory in schools.

## Charlie Crist's running mate: Being 'sp-ed teacher' 'qualifies me to deal with the dysfunctional legislature'
 - [https://www.foxnews.com/media/charlie-crists-running-mate-being-sp-ed-teacher-qualifies-me-deal-with-dysfunctional-legislature](https://www.foxnews.com/media/charlie-crists-running-mate-being-sp-ed-teacher-qualifies-me-deal-with-dysfunctional-legislature)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 00:24:44+00:00

Charlie Crist's running mate Karla Hernández-Mats suggests her background as a special education teacher makes her qualified to be Florida's lieutenant governor to handle "dysfunction."

## Andrew Cuomo files ethics complaint against NY AG Letitia James over sexual harassment probe
 - [https://www.foxnews.com/politics/andrew-cuomo-files-ethics-complaint-against-ny-ag-letitia-james-sexual-harassment-probe](https://www.foxnews.com/politics/andrew-cuomo-files-ethics-complaint-against-ny-ag-letitia-james-sexual-harassment-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 00:18:01+00:00

Andrew Cuomo has filed an ethics complaint against New York Attorney General Letitia James claiming she violated rules of conduct while investigating him.

## Giannis Antetokounmpo ejected from EuroBasket quarterfinal after hitting player in the face
 - [https://www.foxnews.com/sports/giannis-antetokounmpo-ejected-eurobasket-quarterfinal-hitting-player-face](https://www.foxnews.com/sports/giannis-antetokounmpo-ejected-eurobasket-quarterfinal-hitting-player-face)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 00:12:21+00:00

Milwaukee Bucks All-Star Giannis Antetokounmpo was ejected from Greece's quarterfinal matchup against Germany in FIBA EuroBasket 2022 after hitting a player in the face.

## White House doesn't know how to deal with inflation: Ben Domenech
 - [https://www.foxnews.com/media/ben-domenech-white-house-doesnt-know-deal-inflation](https://www.foxnews.com/media/ben-domenech-white-house-doesnt-know-deal-inflation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 00:11:11+00:00

Bret Baier spoke with Ben Domenech on "Special Report" about the sprint to the midterms and how big a role inflation and abortion rights will play come November.

## Top House Republican roasts 'fool' Joe Biden for celebrating passage of spending bill as inflation rises
 - [https://www.foxnews.com/politics/top-house-republican-roasts-fool-joe-biden-celebrating-passage-spending-bill-inflation-rises](https://www.foxnews.com/politics/top-house-republican-roasts-fool-joe-biden-celebrating-passage-spending-bill-inflation-rises)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-14 00:10:42+00:00

NRCC chairman Rep. Tom Emmer, D-Minn., blasted President Biden for his White House celebration of the Inflation Reduction Act's passage amid an uptick in inflation in August.


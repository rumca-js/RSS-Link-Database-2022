# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Over 280,000 WordPress sites may have been hijacked by zero-day hiding in popular plugin
 - [https://www.techradar.com/news/over-280000-wordpress-sites-may-have-been-hijacked-by-zero-day-hiding-in-popular-plugin/](https://www.techradar.com/news/over-280000-wordpress-sites-may-have-been-hijacked-by-zero-day-hiding-in-popular-plugin/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 20:09:22+00:00

Over 280,000 WordPress sites may have been taken over thanks to zero-day in popular plugin.

## Leak suggests Intel's new Xeon CPUs suffer from more than just delays
 - [https://www.techradar.com/news/leak-suggests-intels-new-xeon-cpus-suffer-from-more-than-just-delays/](https://www.techradar.com/news/leak-suggests-intels-new-xeon-cpus-suffer-from-more-than-just-delays/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 19:18:26+00:00

Leaked data suggests Intel’s new Xeon chips fail to match the level of performance available elsewhere.

## Nvidia RTX 4060: everything we know about Nvidia's next-gen 'budget' graphics card
 - [https://www.techradar.com/news/nvidia-rtx-4060/](https://www.techradar.com/news/nvidia-rtx-4060/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 18:38:36+00:00

The Nvidia RTX 4060 may be released as soon as 2023, but what do we know about it so far?

## Nvidia RTX 4060: everything we know about Nvidia's next-gen 'budget' graphics card
 - [https://www.techradar.com/news/nvidia-rtx-4060](https://www.techradar.com/news/nvidia-rtx-4060)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 18:38:36+00:00

The Nvidia RTX 4060 may be released as soon as 2023, but what do we know about it so far?

## The Linux Foundation wants to tackle digital wallets next
 - [https://www.techradar.com/news/the-linux-foundation-wants-to-tackle-digital-wallets-next/](https://www.techradar.com/news/the-linux-foundation-wants-to-tackle-digital-wallets-next/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 18:22:17+00:00

Linux’s newly-announced OpenWallet Foundation hopes to provide interoperable OSS for the digital wallet.

## Microsoft 365 apps will now update themselves as if by magic
 - [https://www.techradar.com/news/microsoft-365-apps-will-now-update-themselves-as-if-by-magic/](https://www.techradar.com/news/microsoft-365-apps-will-now-update-themselves-as-if-by-magic/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 17:32:47+00:00

Microsoft 365 updates will now install even when your device is powered down.

## Google Photos update is set to transform your Memories
 - [https://www.techradar.com/news/google-photos-update-is-set-to-transform-your-memories/](https://www.techradar.com/news/google-photos-update-is-set-to-transform-your-memories/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 16:31:24+00:00

Rolling out to users today, some of the changes include a collage editing tool and improved cinematic photos.

## PS5 console exclusive Deathloop has appeared on the Xbox Series X
 - [https://www.techradar.com/news/ps5-console-exclusive-deathloop-has-appeared-on-the-xbox-series-x/](https://www.techradar.com/news/ps5-console-exclusive-deathloop-has-appeared-on-the-xbox-series-x/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 16:00:00+00:00

Arkane's FPS Deathloop looks set to jump over to Xbox consoles soon.

## Nvidia RTX 4070 may not show up this year – but the replacement GPU could surprise you
 - [https://www.techradar.com/news/nvidia-rtx-4070-may-not-show-up-this-year-but-the-replacement-gpu-could-surprise-you/](https://www.techradar.com/news/nvidia-rtx-4070-may-not-show-up-this-year-but-the-replacement-gpu-could-surprise-you/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 15:44:43+00:00

Rumor has it that the RTX 4070 isn’t on the horizon – but a pair of RTX 4080 GPUs are instead.

## You could soon control your VPN through Microsoft Edge
 - [https://www.techradar.com/news/you-could-soon-control-your-vpn-through-microsoft-edge/](https://www.techradar.com/news/you-could-soon-control-your-vpn-through-microsoft-edge/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 15:02:04+00:00

Microsoft Edge Secure Network VPN controls appear for some users.

## Nokia’s new phone is like a 3310 with earbuds built into the back – and I love it
 - [https://www.techradar.com/news/nokias-new-phone-is-like-a-3310-with-earbuds-built-into-the-back-and-i-love-it/](https://www.techradar.com/news/nokias-new-phone-is-like-a-3310-with-earbuds-built-into-the-back-and-i-love-it/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 14:53:02+00:00

Nokia's 5710 XpressAudio phone has FM radio and built-in Bluetooth earbuds for an oddly futuristic-but-retro experience.

## McAfee is combining all your most-needed security products into one package
 - [https://www.techradar.com/news/mcafee-is-combining-all-your-most-needed-security-products-into-one-package/](https://www.techradar.com/news/mcafee-is-combining-all-your-most-needed-security-products-into-one-package/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 14:32:53+00:00

McAfee+ wants to make cybersecurity simple, whether you're alone or with your family.

## Linux users can now secure their data with this leading VPN
 - [https://www.techradar.com/news/leading-vpn-is-now-supporting-linux/](https://www.techradar.com/news/leading-vpn-is-now-supporting-linux/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 14:06:38+00:00

Already available for most operating systems around, Atlas VPN is now offering online privacy protection also to Linux users.

## Microsoft has launched a new CDN for businesses
 - [https://www.techradar.com/news/microsoft-has-launched-a-new-cdn-for-businesses/](https://www.techradar.com/news/microsoft-has-launched-a-new-cdn-for-businesses/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 14:00:37+00:00

Improved network reliability and ease of adoption are two of Microsoft’s promises for its new eCDN.

## Stranger Things and Squid Game set to lead thrilling reveals at Netflix Tudum 2022
 - [https://www.techradar.com/news/stranger-things-and-squid-game-set-to-lead-thrilling-netflix-tudum-announcements/](https://www.techradar.com/news/stranger-things-and-squid-game-set-to-lead-thrilling-netflix-tudum-announcements/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 14:00:00+00:00

The official trailer for Tudum 2022, Netflix's annual global fan event, has revealed what we can expect from this year's entry.

## DuckDuckGo, Proton, Mozilla throw weight behind bill targeting Big Tech ‘surveillance’
 - [https://www.techradar.com/news/duckduckgo-proton-mozilla-throw-weight-behind-bill-targeting-big-tech-surveillance/](https://www.techradar.com/news/duckduckgo-proton-mozilla-throw-weight-behind-bill-targeting-big-tech-surveillance/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 13:38:37+00:00

A dozen companies leading on the issue of data privacy take their fight to Congress.

## You can soon fill your iOS 16 lock screen with Google Maps and Gmail widgets
 - [https://www.techradar.com/news/you-can-soon-fill-your-ios-16-lock-screen-with-google-maps-and-gmail-widgets/](https://www.techradar.com/news/you-can-soon-fill-your-ios-16-lock-screen-with-google-maps-and-gmail-widgets/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 13:03:14+00:00

Google Maps and Gmail will soon get lock screen widgets on your iPhone running iOS 16.

## Microsoft just fixed a whole load of serious security flaws, so patch now
 - [https://www.techradar.com/news/microsoft-just-fixed-a-whole-load-of-security-flaws-so-patch-now/](https://www.techradar.com/news/microsoft-just-fixed-a-whole-load-of-security-flaws-so-patch-now/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 13:01:15+00:00

Microsoft warns several of the fixed flaws are zero-days, one of which is being actively exploited.

## iOS 16 makes it easier to customize your AirPods, but there's more to do
 - [https://www.techradar.com/news/ios-16-makes-it-easier-to-customize-your-airpods-but-theres-more-to-do/](https://www.techradar.com/news/ios-16-makes-it-easier-to-customize-your-airpods-but-theres-more-to-do/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 11:59:11+00:00

The iOS 16 update for iPhone finally puts key AirPods settings just a tap away… but there's more customization access that we want.

## Phishing attackers are now using multiple email accounts to start group conversations with you
 - [https://www.techradar.com/news/phishing-attackers-are-now-using-multiple-email-accounts-to-start-group-conversations-with-you/](https://www.techradar.com/news/phishing-attackers-are-now-using-multiple-email-accounts-to-start-group-conversations-with-you/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 11:51:42+00:00

Hackers are dragging victims into fake email conversations to lure them into downloading malware.

## Nvidia RTX 4090 GPU appears in another photo, suggesting launch is imminent
 - [https://www.techradar.com/news/nvidia-rtx-4090-gpu-appears-in-another-photo-suggesting-launch-is-imminent/](https://www.techradar.com/news/nvidia-rtx-4090-gpu-appears-in-another-photo-suggesting-launch-is-imminent/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 11:41:38+00:00

More pics have been spilled of the flagship graphics card, and this time it’s a Gigabyte model.

## This security firm claims to have the right tool for your privacy, and it's not a VPN
 - [https://www.techradar.com/news/this-security-firm-claims-to-have-the-right-tool-for-your-privacy-and-its-not-a-vpn/](https://www.techradar.com/news/this-security-firm-claims-to-have-the-right-tool-for-your-privacy-and-its-not-a-vpn/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 11:31:44+00:00

Here, we explore INVISV's Multi-Party Relay, and whether it can offer a genuine privacy alternative to traditional VPNs.

## Leaked Nvidia RTX 4090 price practically confirms our worst fears
 - [https://www.techradar.com/news/leaked-nvidia-rtx-4090-price-practically-confirms-our-worst-fears/](https://www.techradar.com/news/leaked-nvidia-rtx-4090-price-practically-confirms-our-worst-fears/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 11:08:04+00:00

A Vietnamese retailer has put Nvidia’s new flagship GPU up for pre-order with an eye-watering price tag.

## GoldenEye on Xbox Game Pass won’t include online multiplayer
 - [https://www.techradar.com/news/goldeneye-on-xbox-game-pass-wont-include-multiplayer/](https://www.techradar.com/news/goldeneye-on-xbox-game-pass-wont-include-multiplayer/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 11:00:07+00:00

The Xbox Game Pass version of GoldenEye won’t be the full game.

## NordPass will now sound the alarm if you're caught up in a data breach
 - [https://www.techradar.com/news/nordpass-will-now-sound-the-alarm-if-youre-caught-up-in-a-data-breach/](https://www.techradar.com/news/nordpass-will-now-sound-the-alarm-if-youre-caught-up-in-a-data-breach/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 10:49:06+00:00

Password manager scans the internet for new data breaches and alerts users.

## GoPro Hero 11 Black launch live: it's new action camera day for GoPro and DJI
 - [https://www.techradar.com/news/live/gopro-hero-11-black-launch-live-its-new-action-camera-day-for-gopro-and-dji/](https://www.techradar.com/news/live/gopro-hero-11-black-launch-live-its-new-action-camera-day-for-gopro-and-dji/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 10:31:25+00:00

The GoPro Hero 11 Black and DJI Osmo Action 3 are both expected to launch today. But which one should you buy?

## The iPhone 14 Pro's best feature can be turned into a game
 - [https://www.techradar.com/news/the-iphone-14-pros-best-feature-can-be-turned-into-a-game/](https://www.techradar.com/news/the-iphone-14-pros-best-feature-can-be-turned-into-a-game/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 10:20:21+00:00

Developers are already looking into how games could work with the Dynamic Island feature on iPhone 14 Pro and Pro Max.

## Not even Cobra Kai can cancel out Netflix's current dry spell
 - [https://www.techradar.com/news/not-even-cobra-kai-can-cancel-out-netflixs-current-dry-spell/](https://www.techradar.com/news/not-even-cobra-kai-can-cancel-out-netflixs-current-dry-spell/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 10:13:29+00:00

Netflix's September 2022 performance hasn't inspired confidence for a quick turnaround in the streamer's fortunes.

## Google Pixel 7 Pro colors confirmed in weird potato chip tweet
 - [https://www.techradar.com/news/google-pixel-7-pro-colors-confirmed-in-weird-potato-chip-tweet/](https://www.techradar.com/news/google-pixel-7-pro-colors-confirmed-in-weird-potato-chip-tweet/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 09:31:48+00:00

Google has tweeted an image showing four Pixel 7 variants along with potato chip flavors that correspond.

## Now is a great time to buy a second-hand or older Amazon Kindle
 - [https://www.techradar.com/news/now-is-a-great-time-to-buy-a-second-hand-or-older-amazon-kindle/](https://www.techradar.com/news/now-is-a-great-time-to-buy-a-second-hand-or-older-amazon-kindle/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 04:00:49+00:00

Amazon's Kindle ereaders are getting pricier, but there are ways to avoid the high costs of newer models.

## A hit Xbox Game Pass adventure game is coming to Nintendo Switch and PS5
 - [https://www.techradar.com/news/a-hit-xbox-game-pass-adventure-game-is-coming-to-nintendo-switch-and-ps5/](https://www.techradar.com/news/a-hit-xbox-game-pass-adventure-game-is-coming-to-nintendo-switch-and-ps5/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-14 04:00:48+00:00

Tunic is hopping over to Nintendo and PlayStation consoles later this year.


## How Bill Gates and partners used their clout to control the global Covid response — with little oversight
 - [https://www.politico.com/news/2022/09/14/global-covid-pandemic-response-bill-gates-partners-00053969](https://www.politico.com/news/2022/09/14/global-covid-pandemic-response-bill-gates-partners-00053969)
 - RSS feed: https://www.politico.com
 - date published: 2022-09-14 20:25:38+00:00

How Bill Gates and partners used their clout to control the global Covid response — with little oversight


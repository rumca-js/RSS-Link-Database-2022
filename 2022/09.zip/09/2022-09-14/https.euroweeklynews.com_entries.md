## European Commission’s EU digital identity wallet pilot program proposed by six countries « Euro Weekly News
 - [https://euroweeklynews.com/2022/09/14/eu-digital-identity-wallet/](https://euroweeklynews.com/2022/09/14/eu-digital-identity-wallet/)
 - RSS feed: https://euroweeklynews.com
 - date published: 2022-09-14 15:26:50+00:00

European Commission’s EU digital identity wallet pilot program proposed by six countries « Euro Weekly News


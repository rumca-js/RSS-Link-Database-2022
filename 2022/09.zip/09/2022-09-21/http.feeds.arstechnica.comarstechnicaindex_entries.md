# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Andor first impressions: Star Wars inches toward the best of modern adult TV
 - [https://arstechnica.com/?p=1883626](https://arstechnica.com/?p=1883626)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 23:26:55+00:00

The darkest <em>Star Wars</em> series yet takes too long to establish positive momentum.

## Fearing copyright issues, Getty Images bans AI-generated artwork
 - [https://arstechnica.com/?p=1883513](https://arstechnica.com/?p=1883513)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 22:32:35+00:00

Getty sidesteps potential legal problems from unresolved rights and ethics issues.

## Logitech builds Android-powered Steam Deck clone for portable cloud gaming
 - [https://arstechnica.com/?p=1883453](https://arstechnica.com/?p=1883453)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 20:26:48+00:00

Is your local Wi-Fi infrastructure ready for a portable cloud gaming device?

## Einstein wins again: Space satellite confirms weak equivalence principle
 - [https://arstechnica.com/?p=1882442](https://arstechnica.com/?p=1882442)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 20:13:08+00:00

MICROSCOPE experiment measured accelerations of free-falling objects in space.

## US installs record solar capacity as prices keep falling
 - [https://arstechnica.com/?p=1883512](https://arstechnica.com/?p=1883512)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 19:57:42+00:00

It's often cheaper to build and run solar than to buy gas for an existing plant.

## UN chief asks wealthy nations to impose windfall taxes on fossil fuel industry
 - [https://arstechnica.com/?p=1883452](https://arstechnica.com/?p=1883452)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 19:32:08+00:00

UN wants companies to help fund recovery in nations hit worst by climate change.

## The record-setting DDoSes keep coming, with no end in sight
 - [https://arstechnica.com/?p=1883481](https://arstechnica.com/?p=1883481)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 19:15:20+00:00

As DDoSes continue to innovate, their attacks grow ever bigger.

## iPhone 14 and 14 Pro review: A picture is worth a thousand dollars
 - [https://arstechnica.com/?p=1882974](https://arstechnica.com/?p=1882974)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 17:35:30+00:00

These updates are iterative as ever, but the cameras and Dynamic Island shine.

## Today’s best deals: Apple MacBook Air, Ring Fit Adventure, and more
 - [https://arstechnica.com/?p=1883071](https://arstechnica.com/?p=1883071)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 16:57:50+00:00

Dealmaster also has Anker charging gear, Google's Nest Hub, and portable SSDs.

## Razer’s new soundbar works with USB-C and Bluetooth, costs $100
 - [https://arstechnica.com/?p=1883318](https://arstechnica.com/?p=1883318)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 16:45:40+00:00

Up to 90 dB volume output, Razer claims.

## NTSB wants alcohol detection systems installed in all new cars in US
 - [https://arstechnica.com/?p=1883361](https://arstechnica.com/?p=1883361)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 16:34:48+00:00

Proposed requirement would prevent or limit vehicle operation if driver is drunk.

## OnePlus takes just one month to update to Android 13
 - [https://arstechnica.com/?p=1883310](https://arstechnica.com/?p=1883310)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 16:23:46+00:00

OnePlus wins the title of "fastest Android updater," even with a heavy skin.

## As streamers threaten boycott, Twitch takes action on some gambling content
 - [https://arstechnica.com/?p=1883333](https://arstechnica.com/?p=1883333)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 15:57:55+00:00

Unlicensed "slots, roulette, or dice games" will no longer be allowed on-stream.

## Artist finds private medical record photos in popular AI training data set
 - [https://arstechnica.com/?p=1882591](https://arstechnica.com/?p=1882591)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 15:43:09+00:00

LAION scraped medical photos for AI research use. Who's responsible for taking them down?

## Repairable, upgradeable Framework Laptop will also be available as a Chromebook
 - [https://arstechnica.com/?p=1883228](https://arstechnica.com/?p=1883228)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 15:00:18+00:00

Chromebook Edition hardware is mostly identical to the standard Framework Laptop.

## Telegram has a serious doxxing problem
 - [https://arstechnica.com/?p=1883287](https://arstechnica.com/?p=1883287)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 14:24:47+00:00

Telegram users are increasingly bringing threats to targets’ doorsteps.

## New JWST image reveals full glory of Neptune, its moons, and rings
 - [https://arstechnica.com/?p=1883221](https://arstechnica.com/?p=1883221)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 13:18:33+00:00

"It has been three decades since we last saw these faint, dusty rings."

## 2022 Amazon Fire 8 HD tablet sports 30 percent faster CPU
 - [https://arstechnica.com/?p=1882836](https://arstechnica.com/?p=1882836)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 13:00:42+00:00

Amazon updates its 8-inch tablets after two years.

## US lawmakers escalate pressure on Chinese chipmaker YMTC
 - [https://arstechnica.com/?p=1883231](https://arstechnica.com/?p=1883231)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 13:00:38+00:00

YMTC is alleged to have violated export controls by supplying NAND chips to Huawei.

## Why do car companies build concepts? We ask Audi’s product planner
 - [https://arstechnica.com/?p=1883205](https://arstechnica.com/?p=1883205)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 12:41:38+00:00

Designers don't run car companies, so what's the business reason behind it?

## World’s oldest heart preserved in 380 million-year-old armored fish
 - [https://arstechnica.com/?p=1882477](https://arstechnica.com/?p=1882477)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-09-21 11:30:15+00:00

"These fish literally have their hearts in their mouths and under their gills."


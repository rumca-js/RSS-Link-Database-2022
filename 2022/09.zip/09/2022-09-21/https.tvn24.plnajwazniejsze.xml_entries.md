# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Media: Ponitka osiągnął porozumienie z greckim potentatem
 - [https://eurosport.tvn24.pl/media--ponitka-osi-gn---porozumienie-z-greckim-potentatem,1119262.html?source=rss](https://eurosport.tvn24.pl/media--ponitka-osi-gn---porozumienie-z-greckim-potentatem,1119262.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 20:35:00+00:00

<img alt="Media: Ponitka osiągnął porozumienie z greckim potentatem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1rbrkw-mateusz-ponitka-jest-kapitanem-reprezentacji-polski/alternates/LANDSCAPE_1280" />
    Nie ustają spekulacje na temat przyszłości reprezentanta Polski.

## Kamil Syprzak pogrążył swój były zespół
 - [https://eurosport.tvn24.pl/kamil-syprzak-pogr--y--sw-j-by-y-zesp----orlen-wis-a-p-ock-pokonana-w-pary-u,1119259.html?source=rss](https://eurosport.tvn24.pl/kamil-syprzak-pogr--y--sw-j-by-y-zesp----orlen-wis-a-p-ock-pokonana-w-pary-u,1119259.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 20:25:19+00:00

<img alt="Kamil Syprzak pogrążył swój były zespół" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5dz1c3-kamil-syprzak-byl-niema-bezbledny-w-meczu-z-orlen-wisla-plock/alternates/LANDSCAPE_1280" />
    W meczu Ligi Mistrzów.

## Holendrzy nie mogą nachwalić się Lewandowskiego. "Wielki test"
 - [https://eurosport.tvn24.pl/holendrzy-nie-mog--nachwali--si--lewandowskiego---wielki-test-,1119239.html?source=rss](https://eurosport.tvn24.pl/holendrzy-nie-mog--nachwali--si--lewandowskiego---wielki-test-,1119239.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 18:44:39+00:00

<img alt="Holendrzy nie mogą nachwalić się Lewandowskiego. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4h1uj1-polacy-grali-juz-z-holandia-louisa-van-gaala/alternates/LANDSCAPE_1280" />
    Trener Louis van Gaal do meczu Ligi Narodów podchodzi bardzo poważnie.

## Pilot tragicznego lotu piłkarza mówił o "podejrzanym" samolocie. Ujawniono nagranie
 - [https://eurosport.tvn24.pl/pilot-tragicznego-lotu-pi-karza-m-wi--o--podejrzanym--samolocie--ujawniono-nagranie,1119221.html?source=rss](https://eurosport.tvn24.pl/pilot-tragicznego-lotu-pi-karza-m-wi--o--podejrzanym--samolocie--ujawniono-nagranie,1119221.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 17:12:00+00:00

<img alt="Pilot tragicznego lotu piłkarza mówił o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-cgkm7d-emiliano-sala-wrak-samolotu-piper-malibu/alternates/LANDSCAPE_1280" />
    "Zwykle mam kamizelkę ratunkową między siedzeniami, ale jutro będę miał ją na sobie, to na pewno".

## Izba Odpowiedzialności Zawodowej SN uderza w ministra sprawiedliwości, ale to nie usuwa problemów
 - [https://fakty.tvn24.pl/izba-odpowiedzialno-ci-zawodowej-sn-uderza-w-ministra-sprawiedliwo-ci--ale-to-nie-usuwa-problem-w-z-izb-,1119236.html?source=rss](https://fakty.tvn24.pl/izba-odpowiedzialno-ci-zawodowej-sn-uderza-w-ministra-sprawiedliwo-ci--ale-to-nie-usuwa-problem-w-z-izb-,1119236.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 17:10:00+00:00

<img alt="Izba Odpowiedzialności Zawodowej SN uderza w ministra sprawiedliwości, ale to nie usuwa problemów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uxk7g5-izba-odpowiedzialnosci-zawodowej-sn-uderza-w-ministra-sprawiedliwosci-ale-to-nie-usuwa-problemow-z-izba/alternates/LANDSCAPE_1280" />
    To może być przełom w sprawach innych zamieszonych sędziów.

## Są wyniki zeszłorocznego spisu powszechnego. Zmiana na podium
 - [https://fakty.tvn24.pl/wroc-aw-trzecim-miastem-w-polsce--s--wyniki-zesz-orocznego-spisu-powszechnego,1119222.html?source=rss](https://fakty.tvn24.pl/wroc-aw-trzecim-miastem-w-polsce--s--wyniki-zesz-orocznego-spisu-powszechnego,1119222.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 17:08:00+00:00

<img alt="Są wyniki zeszłorocznego spisu powszechnego. Zmiana na podium" src="https://tvn24.pl/najnowsze/cdn-zdjecie-scl67n-wroclaw-trzecim-miastem-w-polsce-sa-wyniki-spisu-powszechnego-z-zeszlego-roku/alternates/LANDSCAPE_1280" />
    GUS opublikował wyniki.

## Holenderska gwiazda złamała rękę, ale ma nadzieję na start
 - [https://eurosport.tvn24.pl/annemiek-van-vleuten-opu-ci-a-szpital--wyst-p-faworytki-pod-znakiem-zapytania,1119215.html?source=rss](https://eurosport.tvn24.pl/annemiek-van-vleuten-opu-ci-a-szpital--wyst-p-faworytki-pod-znakiem-zapytania,1119215.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 16:35:00+00:00

<img alt="Holenderska gwiazda złamała rękę, ale ma nadzieję na start" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5gvqas-annemiek-van-vleuten-ucierpiala-w-kraksie-w-mistrzostwach-swiata/alternates/LANDSCAPE_1280" />
    Annemiek van Vleuten opuściła szpital.

## Cały wywiad Marcina Wrony z prezydentem Andrzejem Dudą
 - [https://tvn24.pl/go/programy,7/tak-jest-odcinki,10840/odcinek-1649,S00E1649,870168?source=rss](https://tvn24.pl/go/programy,7/tak-jest-odcinki,10840/odcinek-1649,S00E1649,870168?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 16:19:14+00:00

<img alt="Cały wywiad Marcina Wrony z prezydentem Andrzejem Dudą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wprcls-andrzej-duda-6124127/alternates/LANDSCAPE_1280" />
    Prezydent z wizytą w Stanach Zjednoczonych.

## Loża, miliony za sam podpis, prywatny lot. Ujawniono wymagania Messiego wobec Barcelony
 - [https://eurosport.tvn24.pl/lo-a--miliony-za-sam-podpis--prywatny-lot--ujawniono-wymagania-messiego-wobec-barcelony,1119201.html?source=rss](https://eurosport.tvn24.pl/lo-a--miliony-za-sam-podpis--prywatny-lot--ujawniono-wymagania-messiego-wobec-barcelony,1119201.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 15:57:43+00:00

<img alt="Loża, miliony za sam podpis, prywatny lot. Ujawniono wymagania Messiego wobec Barcelony" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hk1o9r-leo-messi-z-fc-barcelona-zegnal-sie-ze-lzami-w-oczach/alternates/LANDSCAPE_1280" />
    "Mundo Deportivo" dotarło do zaskakujących informacji na temat kontraktowych wymagań piłkarza.

## "Kawałki węgla w błocie"? "Kupujemy każdy węgiel, który chcą nam sprzedać"
 - [https://konkret24.tvn24.pl/r/-kawa-ki-w-gla-w-b-ocie---kupujemy-ka-dy-w-giel--kt-ry-chc--nam-sprzeda-,1119154.html?source=rss](https://konkret24.tvn24.pl/r/-kawa-ki-w-gla-w-b-ocie---kupujemy-ka-dy-w-giel--kt-ry-chc--nam-sprzeda-,1119154.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 15:43:57+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rtsj87-skljpg/alternates/LANDSCAPE_1280" />
    Popularne w sieci nagranie, na którym widać "tony węglowego błota" w jednym z portów, wywołało reakcję ministerstwa.

## Glik nie spodziewa się powtórki z pierwszego meczu z Holandią
 - [https://eurosport.tvn24.pl/glik-nie-spodziewa-si--powt-rki-z-pierwszego-meczu-z-holandi-,1119199.html?source=rss](https://eurosport.tvn24.pl/glik-nie-spodziewa-si--powt-rki-z-pierwszego-meczu-z-holandi-,1119199.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 15:35:56+00:00

<img alt="Glik nie spodziewa się powtórki z pierwszego meczu z Holandią" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i25b5n-kamil-glik-na-srodowej-konferencji-prasowej-przed-meczem-z-holandia-w-lidze-narodow/alternates/LANDSCAPE_1280" />
    "Wróci Virgil van Dijk, co da im dodatkową jakość".

## Urazy dwóch kadrowiczów, ich występy zagrożone. "Musimy pamiętać o mundialu"
 - [https://eurosport.tvn24.pl/urazy-dw-ch-kadrowicz-w--ich-wyst-py-zagro-one---musimy-pami-ta--o-mundialu-,1119193.html?source=rss](https://eurosport.tvn24.pl/urazy-dw-ch-kadrowicz-w--ich-wyst-py-zagro-one---musimy-pami-ta--o-mundialu-,1119193.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 14:58:00+00:00

<img alt="Urazy dwóch kadrowiczów, ich występy zagrożone. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-aul3vz-selekcjoner-czeslaw-michniewicz-przygotowuje-reprezentacje-polski-do-mundialu-w-katarze/alternates/LANDSCAPE_1280" />
    Czesław Michniewicz na konferencji prasowej przed meczem z Holandią.

## Mecz z Hurkaczem horrorem Federera
 - [https://eurosport.tvn24.pl/mecz-z-hurkaczem-horrorem-federera--w-a-nie-wtedy-pomy-la----e--to-koniec-,1119187.html?source=rss](https://eurosport.tvn24.pl/mecz-z-hurkaczem-horrorem-federera--w-a-nie-wtedy-pomy-la----e--to-koniec-,1119187.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 14:51:00+00:00

<img alt="Mecz z Hurkaczem horrorem Federera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xt7li3-roger-federer-i-huber-hurkacz/alternates/LANDSCAPE_1280" />
    Właśnie wtedy pomyślał, że "to koniec".

## Czarnek: ZNP nie protestował przed 2016 rokiem, gdy nie było podwyżek. A jednak protestował
 - [https://konkret24.tvn24.pl/r/czarnek--znp-nie-protestowa--przed-2016-rokiem--gdy-nie-by-o-podwy-ek--a-jednak-protestowa-,1119076.html?source=rss](https://konkret24.tvn24.pl/r/czarnek--znp-nie-protestowa--przed-2016-rokiem--gdy-nie-by-o-podwy-ek--a-jednak-protestowa-,1119076.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 13:06:57+00:00

<img alt="Czarnek: ZNP nie protestował przed 2016 rokiem, gdy nie było podwyżek. A jednak protestował" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ur88pe-gettyimages-1242515346jpg/alternates/LANDSCAPE_1280" />
    Konkret24 sprawdził słowa ministra.

## Gwiazdy Bayernu zakażone koronawirusem. Zgrupowanie kadry już bez nich
 - [https://eurosport.tvn24.pl/gwiazdy-bayernu-zaka-one-koronawirusem--zgrupowanie-kadry-ju--bez-nich,1119184.html?source=rss](https://eurosport.tvn24.pl/gwiazdy-bayernu-zaka-one-koronawirusem--zgrupowanie-kadry-ju--bez-nich,1119184.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 13:00:00+00:00

<img alt="Gwiazdy Bayernu zakażone koronawirusem. Zgrupowanie kadry już bez nich" src="https://tvn24.pl/najnowsze/cdn-zdjecie-25rtr9-manuel-neuer-i-leon-goretzka-sa-kluczowymi-pilkarzami-bayernu/alternates/LANDSCAPE_1280" />
    Manuel Neuer oraz Leon Goretzka otrzymali pozytywne wyniki testu.

## Setki milionów rezerwy. Real Madryt gotowy na ewentualne wykluczenie z Ligi Mistrzów
 - [https://eurosport.tvn24.pl/setki-milion-w-rezerwy--real-madryt-gotowy-na-ewentualne-wykluczenie-z-ligi-mistrz-w,1119158.html?source=rss](https://eurosport.tvn24.pl/setki-milion-w-rezerwy--real-madryt-gotowy-na-ewentualne-wykluczenie-z-ligi-mistrz-w,1119158.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 12:46:00+00:00

<img alt="Setki milionów rezerwy. Real Madryt gotowy na ewentualne wykluczenie z Ligi Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lca4r8-real-madryt-triumfowal-w-lidze-mistrzow-w-sezonie-202122/alternates/LANDSCAPE_1280" />
    Hiszpańskie media przekazały ciekawe informacje.

## Aleja Gwiazd przed Narodowym powiększyła się
 - [https://eurosport.tvn24.pl/aleja-gwiazd-przed-narodowym-powi-kszy-a-si---kolejne-legendy-odcisn--y-stopy,1119167.html?source=rss](https://eurosport.tvn24.pl/aleja-gwiazd-przed-narodowym-powi-kszy-a-si---kolejne-legendy-odcisn--y-stopy,1119167.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 11:16:00+00:00

<img alt="Aleja Gwiazd przed Narodowym powiększyła się" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ngn2fy-lewandowski-dudek-i-piszczek-maja-swoje-tablice-na-alei-gwiazd-na-pge-narodowym/alternates/LANDSCAPE_1280" />
    Tablice przed stadionem w Warszawie odsłonili Robert Lewandowski, Jerzy Dudek i Łukasz Piszczek.

## Laver Cup 2022 pod znakiem pożegnania Federera
 - [https://eurosport.tvn24.pl/laver-cup-2022-pod-znakiem-po-egania-federera--kiedy-turniej-i-gdzie-ogl-da--transmisje-,1119155.html?source=rss](https://eurosport.tvn24.pl/laver-cup-2022-pod-znakiem-po-egania-federera--kiedy-turniej-i-gdzie-ogl-da--transmisje-,1119155.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 08:15:30+00:00

<img alt="Laver Cup 2022 pod znakiem pożegnania Federera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3tw7xi-laver-cup-bedzie-pozegnalnym-turniejem-rogera-federera-6123027/alternates/LANDSCAPE_1280" />
    Kiedy turniej i gdzie oglądać transmisje?

## W co gra Francja? "Im dłużej trwa wojna, tym mniej się zmieniło"
 - [https://tvn24.pl/go/audio,14/podcast-o-zagranicy-odcinki,663543/odcinek-37,S00E37,870153?source=rss](https://tvn24.pl/go/audio,14/podcast-o-zagranicy-odcinki,663543/odcinek-37,S00E37,870153?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 07:20:52+00:00

<img alt="W co gra Francja? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-x8jxhx-pap20220626178-1-6122812/alternates/LANDSCAPE_1280" />
    Rozmowa Macieja Tomaszewskiego z Łukaszem Maślanką z Polskiego Instytutu Spraw Międzynarodowych.

## Federer zdradził szczegóły pożegnania z tenisem
 - [https://eurosport.tvn24.pl/federer-zdradzi--szczeg--y-po-egnania-z-tenisem---nie-b-d--w-stanie-gra--w-singlu-,1119149.html?source=rss](https://eurosport.tvn24.pl/federer-zdradzi--szczeg--y-po-egnania-z-tenisem---nie-b-d--w-stanie-gra--w-singlu-,1119149.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 06:25:01+00:00

<img alt="Federer zdradził szczegóły pożegnania z tenisem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kv8k27-federer-konczy-kariere/alternates/LANDSCAPE_1280" />
     "Nie będę w stanie grać w singlu"

## Linette gra dalej w Seulu
 - [https://eurosport.tvn24.pl/linette-gra-dalej-w-seulu--awans-po-nerwowej-ko-c-wce,1119146.html?source=rss](https://eurosport.tvn24.pl/linette-gra-dalej-w-seulu--awans-po-nerwowej-ko-c-wce,1119146.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 05:26:00+00:00

<img alt="Linette gra dalej w Seulu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vdnwql-magda-linette-ma-za-soba-kolejny-udany-mecz/alternates/LANDSCAPE_1280" />
    Awans po nerwowej końcówce.

## Ruszył sezon na grzybobranie. Pochwalcie się swoimi zbiorami
 - [https://kontakt24.tvn24.pl/ruszyl-sezon-na-grzybobranie-pochwalcie-sie-swoimi-zbiorami,1520,gt?source=rss](https://kontakt24.tvn24.pl/ruszyl-sezon-na-grzybobranie-pochwalcie-sie-swoimi-zbiorami,1520,gt?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 05:01:55+00:00

<img alt="Ruszył sezon na grzybobranie. Pochwalcie się swoimi zbiorami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r5drwi-pokazcie-wasze-tegoroczne-zbiory-6122773/alternates/LANDSCAPE_1280" />
    Czekamy na Wasze zdjęcia w naszym gorącym temacie.

## "Chcemy przejść do historii"
 - [https://eurosport.tvn24.pl/rewan--za-fina--ligi-mistrz-w---chcemy-przej---do-historii-,1119127.html?source=rss](https://eurosport.tvn24.pl/rewan--za-fina--ligi-mistrz-w---chcemy-przej---do-historii-,1119127.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 04:29:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iexvkp-zespoly-z-kielc-i-barcelony-zawsze-tocza-ze-soba-zaciete-mecze/alternates/LANDSCAPE_1280" />
    Rewanż za finał Ligi Mistrzów.

## "Zobaczyłam strach w jej oczach. Zapytała mnie: naprawdę nikt pani nie powiedział?"
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-2282,S00E2282,869380?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-2282,S00E2282,869380?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-21 04:00:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lyhtfi-usg-6122208/alternates/LANDSCAPE_1280" />
    Marina o wadzie letalnej swojego dziecka dowiedziała się dopiero u progu 30. tygodnia ciąży. Jak do tego doszło? Reportaż Marty Warchoł.


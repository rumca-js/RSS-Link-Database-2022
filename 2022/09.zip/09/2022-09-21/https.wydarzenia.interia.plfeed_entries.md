# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Zełenski w ONZ: Żądamy kary za rosyjskie zbrodnie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-w-onz-zadamy-kary-za-rosyjskie-zbrodnie,nId,6299974](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-w-onz-zadamy-kary-za-rosyjskie-zbrodnie,nId,6299974)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 22:04:18+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-w-onz-zadamy-kary-za-rosyjskie-zbrodnie,nId,6299974"><img align="left" alt="Zełenski w ONZ: Żądamy kary za rosyjskie zbrodnie" src="https://i.iplsc.com/zelenski-w-onz-zadamy-kary-za-rosyjskie-zbrodnie/000G3NCK4MVJ3RKM-C321.jpg" /></a>Ukraina padła ofiarą zbrodni i żądamy za nią kary - powiedział w środę Wołodymyr Zełenski. Prezydent Ukrainy dodał, że powinien powstać specjalny trybunał, który ukarze 

## Policjant z Minneapolis skazany na trzy lata za zabójstwo George'a Floyda
 - [https://wydarzenia.interia.pl/zagranica/news-policjant-z-minneapolis-skazany-na-trzy-lata-za-zabojstwo-ge,nId,6299960](https://wydarzenia.interia.pl/zagranica/news-policjant-z-minneapolis-skazany-na-trzy-lata-za-zabojstwo-ge,nId,6299960)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 20:24:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-policjant-z-minneapolis-skazany-na-trzy-lata-za-zabojstwo-ge,nId,6299960"><img align="left" alt="Policjant z Minneapolis skazany na trzy lata za zabójstwo George'a Floyda" src="https://i.iplsc.com/policjant-z-minneapolis-skazany-na-trzy-lata-za-zabojstwo-ge/000G3N4VM5SNT9PV-C321.jpg" /></a>Thomas Lane, były oficer policji, został skazany na trzy lata za zabójstwo George'a Floyda - poinformowały media. Funkcjonariusz brał udział w zatrzyman

## Załużny: Zniszczymy wszystkich, którzy przyjdą na naszą ziemię z bronią
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zaluzny-zniszczymy-wszystkich-ktorzy-przyjda-na-nasza-ziemie,nId,6299957](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zaluzny-zniszczymy-wszystkich-ktorzy-przyjda-na-nasza-ziemie,nId,6299957)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 20:13:56+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zaluzny-zniszczymy-wszystkich-ktorzy-przyjda-na-nasza-ziemie,nId,6299957"><img align="left" alt="Załużny: Zniszczymy wszystkich, którzy przyjdą na naszą ziemię z bronią" src="https://i.iplsc.com/zaluzny-zniszczymy-wszystkich-ktorzy-przyjda-na-nasza-ziemie/000FKUVA767KBRYJ-C321.jpg" /></a>- Zniszczymy wszystkich, którzy przyjadą na naszą ziemię z bronią w ręku, czy to dobrowolnie, czy w ramach mobilizacji - oś

## Do Polski zbliża się antycyklon Stefan. Pogoda spłata figla
 - [https://wydarzenia.interia.pl/kraj/news-do-polski-zbliza-sie-antycyklon-stefan-pogoda-splata-figla,nId,6299952](https://wydarzenia.interia.pl/kraj/news-do-polski-zbliza-sie-antycyklon-stefan-pogoda-splata-figla,nId,6299952)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 19:47:34+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-do-polski-zbliza-sie-antycyklon-stefan-pogoda-splata-figla,nId,6299952"><img align="left" alt="Do Polski zbliża się antycyklon Stefan. Pogoda spłata figla" src="https://i.iplsc.com/do-polski-zbliza-sie-antycyklon-stefan-pogoda-splata-figla/000G3N165QCG91AE-C321.jpg" /></a>W drugiej połowie tygodnia czekają nas radykalne zmiany w pogodzie, ponieważ nad Polskę nadciąga antycyklon Stefan. Miejscami temperatura może spaść poniżej zera, kierowcy mus

## Tragedia w Tatrach. Małżeństwo przewodników zginęło pod śniegiem
 - [https://wydarzenia.interia.pl/zagranica/news-tragedia-w-tatrach-malzenstwo-przewodnikow-zginelo-pod-snieg,nId,6299943](https://wydarzenia.interia.pl/zagranica/news-tragedia-w-tatrach-malzenstwo-przewodnikow-zginelo-pod-snieg,nId,6299943)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 19:20:33+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tragedia-w-tatrach-malzenstwo-przewodnikow-zginelo-pod-snieg,nId,6299943"><img align="left" alt="Tragedia w Tatrach. Małżeństwo przewodników zginęło pod śniegiem" src="https://i.iplsc.com/tragedia-w-tatrach-malzenstwo-przewodnikow-zginelo-pod-snieg/000FZ899M2IC99HN-C321.jpg" /></a>W Tatrach Słowackich doszło do śmiertelnego wypadku z udziałem polskich przewodników górskich. Pod śniegiem zginęli Andrzej Sokołowski i Roksana Knapik - poinfor

## Rosjanie dostają wezwania do wojska. "Boję się o swoje życie"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-dostaja-wezwania-do-wojska-boje-sie-o-swoje-zycie,nId,6299912](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-dostaja-wezwania-do-wojska-boje-sie-o-swoje-zycie,nId,6299912)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 19:08:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-dostaja-wezwania-do-wojska-boje-sie-o-swoje-zycie,nId,6299912"><img align="left" alt="Rosjanie dostają wezwania do wojska. &quot;Boję się o swoje życie&quot;" src="https://i.iplsc.com/rosjanie-dostaja-wezwania-do-wojska-boje-sie-o-swoje-zycie/000G3MUKCDWGKISI-C321.jpg" /></a>Do wielu Rosjan dotarły już wezwania do komisji wojskowych w związku z ogłoszoną przez prezydenta Putina mobilizacją. &quot;Boj

## Putin: Nie będzie więcej błędów. Rosjanie muszą chronić ojczyznę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-nie-bedzie-wiecej-bledow-rosjanie-musza-chronic-ojczyz,nId,6299923](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-nie-bedzie-wiecej-bledow-rosjanie-musza-chronic-ojczyz,nId,6299923)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 19:03:28+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-nie-bedzie-wiecej-bledow-rosjanie-musza-chronic-ojczyz,nId,6299923"><img align="left" alt="Putin: Nie będzie więcej błędów. Rosjanie muszą chronić ojczyznę" src="https://i.iplsc.com/putin-nie-bedzie-wiecej-bledow-rosjanie-musza-chronic-ojczyz/000G3MTCAE7SFPCJ-C321.jpg" /></a>- Nawet chwilowe osłabienie suwerenności jest błędem, więcej takich błędów nie będzie - powiedział w środę prezydent Rosji Władimi

## SN: Komisja ds. pedofilii może występować jako strona w postępowaniu
 - [https://wydarzenia.interia.pl/kraj/news-sn-komisja-ds-pedofilii-moze-wystepowac-jako-strona-w-postep,nId,6299907](https://wydarzenia.interia.pl/kraj/news-sn-komisja-ds-pedofilii-moze-wystepowac-jako-strona-w-postep,nId,6299907)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 18:11:03+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sn-komisja-ds-pedofilii-moze-wystepowac-jako-strona-w-postep,nId,6299907"><img align="left" alt="SN: Komisja ds. pedofilii może występować jako strona w postępowaniu" src="https://i.iplsc.com/sn-komisja-ds-pedofilii-moze-wystepowac-jako-strona-w-postep/000FSTF1P5I59UKB-C321.jpg" /></a>Państwowa Komisja ds. pedofilii może występować w postępowaniu karnym jako strona; komisja korzysta z praw przysługujących oskarżycielowi posiłkowemu - wynika z u

## Jarosław Kaczyński: Mamy w Polsce niebywałą ofensywę kłamstwa
 - [https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-mamy-w-polsce-niebywala-ofensywe-klamstwa,nId,6299896](https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-mamy-w-polsce-niebywala-ofensywe-klamstwa,nId,6299896)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 17:35:31+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-mamy-w-polsce-niebywala-ofensywe-klamstwa,nId,6299896"><img align="left" alt="Jarosław Kaczyński: Mamy w Polsce niebywałą ofensywę kłamstwa" src="https://i.iplsc.com/jaroslaw-kaczynski-mamy-w-polsce-niebywala-ofensywe-klamstwa/000G3MHJQDM1AD0U-C321.jpg" /></a>- Przede wszystkim musimy nie pozwolić się okłamywać i przekonać tych, którzy dają się okłamywać, żeby się okłamywać nie dali - powiedział prezes PiS Jarosław Kaczyński.

## Rosjanie wychodzą na ulice. Starcia z policją, wielu zatrzymanych
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-wychodza-na-ulice-starcia-z-policja-wielu-zatrzyman,nId,6299892](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-wychodza-na-ulice-starcia-z-policja-wielu-zatrzyman,nId,6299892)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 17:25:55+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-wychodza-na-ulice-starcia-z-policja-wielu-zatrzyman,nId,6299892"><img align="left" alt="Rosjanie wychodzą na ulice. Starcia z policją, wielu zatrzymanych" src="https://i.iplsc.com/rosjanie-wychodza-na-ulice-starcia-z-policja-wielu-zatrzyman/000G3MGN4LMDYPPG-C321.jpg" /></a>Do ponad 400 wzrósł bilans zatrzymanych uczestników środowych demonstracji w Rosji przeciwko mobilizacji na wojnę z Ukrainą - pod

## Duda: Rosyjskie referenda to lipa. Nie mają one nic wspólnego z demokracją
 - [https://wydarzenia.interia.pl/kraj/news-duda-rosyjskie-referenda-to-lipa-nie-maja-one-nic-wspolnego-,nId,6299879](https://wydarzenia.interia.pl/kraj/news-duda-rosyjskie-referenda-to-lipa-nie-maja-one-nic-wspolnego-,nId,6299879)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 17:25:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-duda-rosyjskie-referenda-to-lipa-nie-maja-one-nic-wspolnego-,nId,6299879"><img align="left" alt="Duda: Rosyjskie referenda to lipa. Nie mają one nic wspólnego z demokracją" src="https://i.iplsc.com/duda-rosyjskie-referenda-to-lipa-nie-maja-one-nic-wspolnego/000G3M9Q7K79S6GS-C321.jpg" /></a>Prezydent Andrzej Duda podczas pobytu w Nowym Jorku udzielił wywiadu, w którym skomentował sytuację międzynarodową, w tym wojnę w Ukrainie. Prezydent stwierd

## Gangster w potrzasku. Imperialne marzenie Putina umiera na jego oczach [ANALIZA]
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-gangster-w-potrzasku-imperialne-marzenie-putina-umiera-na-je,nId,6299651](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-gangster-w-potrzasku-imperialne-marzenie-putina-umiera-na-je,nId,6299651)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 17:00:49+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-gangster-w-potrzasku-imperialne-marzenie-putina-umiera-na-je,nId,6299651"><img align="left" alt="Gangster w potrzasku. Imperialne marzenie Putina umiera na jego oczach [ANALIZA]" src="https://i.iplsc.com/gangster-w-potrzasku-imperialne-marzenie-putina-umiera-na-je/000G3LHA28Y5W5W8-C321.jpg" /></a>Długo wyczekiwane orędzie Władimira Putina do Rosjan pokazuje, że Kreml jest coraz mocniej przyparty do muru w kwe

## "Załatwię to na innym szczeblu". Syn Pieskowa odmawia dołączenia do armii
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zalatwie-to-na-innym-szczeblu-syn-pieskowa-odmawia-dolaczeni,nId,6299717](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zalatwie-to-na-innym-szczeblu-syn-pieskowa-odmawia-dolaczeni,nId,6299717)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 16:20:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zalatwie-to-na-innym-szczeblu-syn-pieskowa-odmawia-dolaczeni,nId,6299717"><img align="left" alt="&quot;Załatwię to na innym szczeblu&quot;. Syn Pieskowa odmawia dołączenia do armii" src="https://i.iplsc.com/zalatwie-to-na-innym-szczeblu-syn-pieskowa-odmawia-dolaczeni/000G3LVTQTVY9D4F-C321.jpg" /></a>Jeden z współpracowników Aleksieja Nawalnego podszył się pod żołnierza z wojskowej komendy uzupełnień i zadzwon

## Donald Trump pozwany. Wniosek prokuratora stanu Nowy Jork
 - [https://wydarzenia.interia.pl/zagranica/news-donald-trump-pozwany-wniosek-prokuratora-stanu-nowy-jork,nId,6299718](https://wydarzenia.interia.pl/zagranica/news-donald-trump-pozwany-wniosek-prokuratora-stanu-nowy-jork,nId,6299718)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 15:59:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-donald-trump-pozwany-wniosek-prokuratora-stanu-nowy-jork,nId,6299718"><img align="left" alt="Donald Trump pozwany. Wniosek prokuratora stanu Nowy Jork" src="https://i.iplsc.com/donald-trump-pozwany-wniosek-prokuratora-stanu-nowy-jork/000G3M717Q24EPES-C321.jpg" /></a>Prokurator Generalny z Nowego Jorku wniosła pozew cywilny przeciwko Donaldowi Trumpowi, trójce jego dzieci i osobom z kierownictwa Trump Organization - podało CNN. Pozew licząc

## Biden uderza w Putina. Mówi, jaki jest jego cel
 - [https://wydarzenia.interia.pl/zagranica/news-biden-uderza-w-putina-mowi-jaki-jest-jego-cel,nId,6299712](https://wydarzenia.interia.pl/zagranica/news-biden-uderza-w-putina-mowi-jaki-jest-jego-cel,nId,6299712)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 15:46:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-biden-uderza-w-putina-mowi-jaki-jest-jego-cel,nId,6299712"><img align="left" alt="Biden uderza w Putina. Mówi, jaki jest jego cel" src="https://i.iplsc.com/biden-uderza-w-putina-mowi-jaki-jest-jego-cel/000G3MBL6EHB181I-C321.jpg" /></a>Stały członek Rady Bezpieczeństwa ONZ najechał na swojego sąsiada, próbując wymazać suwerenne państwo z mapy świata - powiedział prezydent USA Joe Biden podczas środowego wystąpienia na sesji Zgromadzenia Ogó

## Pobiła i okradła mężczyznę. Policja zatrzymała niepozorną 51-latkę
 - [https://wydarzenia.interia.pl/lubelskie/news-pobila-i-okradla-mezczyzne-policja-zatrzymala-niepozorna-51-,nId,6299683](https://wydarzenia.interia.pl/lubelskie/news-pobila-i-okradla-mezczyzne-policja-zatrzymala-niepozorna-51-,nId,6299683)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 15:00:29+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-pobila-i-okradla-mezczyzne-policja-zatrzymala-niepozorna-51-,nId,6299683"><img align="left" alt="Pobiła i okradła mężczyznę. Policja zatrzymała niepozorną 51-latkę" src="https://i.iplsc.com/pobila-i-okradla-mezczyzne-policja-zatrzymala-niepozorna-51/000G3LNA1EYOHFO4-C321.jpg" /></a>Policja w Lublinie zatrzymała 51-latkę, która jest podejrzana o napad na mężczyznę. Kobieta miała zaatakować i okraść na ulicy mieszkańca Lublina. Za ten czyn g

## Chiny o wojnie w Ukrainie: Należy szanować integralność terytorialną obu krajów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-chiny-o-wojnie-w-ukrainie-nalezy-szanowac-integralnosc-teryt,nId,6299675](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-chiny-o-wojnie-w-ukrainie-nalezy-szanowac-integralnosc-teryt,nId,6299675)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 14:55:51+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-chiny-o-wojnie-w-ukrainie-nalezy-szanowac-integralnosc-teryt,nId,6299675"><img align="left" alt="Chiny o wojnie w Ukrainie: Należy szanować integralność terytorialną obu krajów" src="https://i.iplsc.com/chiny-o-wojnie-w-ukrainie-nalezy-szanowac-integralnosc-teryt/000G3LOASI56HX9E-C321.jpg" /></a>Chiny wezwały do zawieszenia broni w wojnie Rosji z Ukrainą po tym, jak prezydent Władimir Putin ogłosił częściową 

## Przeszukano posiadłości powiązane z Usmanowem. Oligarcha wspiera Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przeszukano-posiadlosci-powiazane-z-usmanowem-oligarcha-wspi,nId,6299649](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przeszukano-posiadlosci-powiazane-z-usmanowem-oligarcha-wspi,nId,6299649)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 14:33:26+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przeszukano-posiadlosci-powiazane-z-usmanowem-oligarcha-wspi,nId,6299649"><img align="left" alt="Przeszukano posiadłości powiązane z Usmanowem. Oligarcha wspiera Putina" src="https://i.iplsc.com/przeszukano-posiadlosci-powiazane-z-usmanowem-oligarcha-wspi/000G3LGEN3G45CCQ-C321.jpg" /></a>W Niemczech w 24 nieruchomościach powiązanych z rosyjskim oligarchą, Aliszerem Usmanowem, odbyły się rewizje - przekazały m

## Eksperci: Mobilizacja jest de facto powszechna. Dekret częściowo utajniony
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-eksperci-mobilizacja-jest-de-facto-powszechna-dekret-czescio,nId,6299596](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-eksperci-mobilizacja-jest-de-facto-powszechna-dekret-czescio,nId,6299596)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 13:56:35+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-eksperci-mobilizacja-jest-de-facto-powszechna-dekret-czescio,nId,6299596"><img align="left" alt="Eksperci: Mobilizacja jest de facto powszechna. Dekret częściowo utajniony" src="https://i.iplsc.com/eksperci-mobilizacja-jest-de-facto-powszechna-dekret-czescio/000G3KFHKPV9NKTG-C321.jpg" /></a>Rosyjscy eksperci uważają, że ogłoszona w Rosji częściowa mobilizacja do armii jest tak naprawdę mobilizacją powszechna.

## Kobiety palą hidżaby w Iranie. Masowe protesty po śmierci 22-latki
 - [https://wydarzenia.interia.pl/zagranica/news-kobiety-pala-hidzaby-w-iranie-masowe-protesty-po-smierci-22-,nId,6299635](https://wydarzenia.interia.pl/zagranica/news-kobiety-pala-hidzaby-w-iranie-masowe-protesty-po-smierci-22-,nId,6299635)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 13:55:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kobiety-pala-hidzaby-w-iranie-masowe-protesty-po-smierci-22-,nId,6299635"><img align="left" alt="Kobiety palą hidżaby w Iranie. Masowe protesty po śmierci 22-latki" src="https://i.iplsc.com/kobiety-pala-hidzaby-w-iranie-masowe-protesty-po-smierci-22/000G3L9QSLL9FEQI-C321.jpg" /></a>W Iranie trwają protesty po śmierci 22-letniej Mahasy Amini, które ogarnęły 16 z 31 prowincji kraju. Kobieta zapadła w śpiączkę i zmarła po tym, jak została zat

## Była posłanka PO szefową związkowców w Senacie
 - [https://wydarzenia.interia.pl/autor/jakub-szczepanski/news-byla-poslanka-po-szefowa-zwiazkowcow-w-senacie,nId,6299573](https://wydarzenia.interia.pl/autor/jakub-szczepanski/news-byla-poslanka-po-szefowa-zwiazkowcow-w-senacie,nId,6299573)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 13:43:40+00:00

<p><a href="https://wydarzenia.interia.pl/autor/jakub-szczepanski/news-byla-poslanka-po-szefowa-zwiazkowcow-w-senacie,nId,6299573"><img align="left" alt="Była posłanka PO szefową związkowców w Senacie" src="https://i.iplsc.com/byla-poslanka-po-szefowa-zwiazkowcow-w-senacie/000G3KER7SI43237-C321.jpg" /></a>Jak ustaliła Interia, OPZZ Konfederacja Pracy w Kancelarii Senatu ma nową przewodniczącą. Szefową związku zawodowego została Joanna Augustynowska, była posłanka Platformy Obywatelskiej. Pikante

## Rosjanie przeciwni mobilizacji. Protesty w miastach
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-przeciwni-mobilizacji-protesty-w-miastach,nId,6299610](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-przeciwni-mobilizacji-protesty-w-miastach,nId,6299610)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 13:31:05+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-przeciwni-mobilizacji-protesty-w-miastach,nId,6299610"><img align="left" alt="Rosjanie przeciwni mobilizacji. Protesty w miastach" src="https://i.iplsc.com/rosjanie-przeciwni-mobilizacji-protesty-w-miastach/000G3KJ54B88IX3N-C321.jpg" /></a>W kilku miastach Rosji w środę zatrzymano uczestników protestów przeciwko ogłoszonej tego dnia przez prezydenta Władimira Putina częściowej mobilizacji - relacjonu

## Tajemnicza śmierć rosyjskiego naukowca. "Spadł z dużej wysokości"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tajemnicza-smierc-rosyjskiego-naukowca-spadl-z-duzej-wysokos,nId,6299598](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tajemnicza-smierc-rosyjskiego-naukowca-spadl-z-duzej-wysokos,nId,6299598)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 13:20:10+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tajemnicza-smierc-rosyjskiego-naukowca-spadl-z-duzej-wysokos,nId,6299598"><img align="left" alt="Tajemnicza śmierć rosyjskiego naukowca. &quot;Spadł z dużej wysokości&quot;" src="https://i.iplsc.com/tajemnicza-smierc-rosyjskiego-naukowca-spadl-z-duzej-wysokos/000G3KEWV3RNWME6-C321.jpg" /></a>Były rektor Moskiewskiego Instytutu Lotnictwa profesor Anatolij Geraszczenko zmarł w wyniku wypadku - twierdzi służba p

## Przez okno wyrzucił nawet wannę. Sąsiedzi w szoku
 - [https://wydarzenia.interia.pl/malopolskie/news-przez-okno-wyrzucil-nawet-wanne-sasiedzi-w-szoku,nId,6299500](https://wydarzenia.interia.pl/malopolskie/news-przez-okno-wyrzucil-nawet-wanne-sasiedzi-w-szoku,nId,6299500)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 13:13:19+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-przez-okno-wyrzucil-nawet-wanne-sasiedzi-w-szoku,nId,6299500"><img align="left" alt="Przez okno wyrzucił nawet wannę. Sąsiedzi w szoku" src="https://i.iplsc.com/przez-okno-wyrzucil-nawet-wanne-sasiedzi-w-szoku/000G3JWE4O7W099I-C321.jpg" /></a>Zakrwawiony nagi mężczyzna wyrzucił przez balkon zlew, piekarnik, pralkę, lodówkę, a nawet wannę, po czym zaczął uciekać. Takie sceny w środowy poranek zszokowały najbliższych sąsiadów i mieszkańców

## Czekasz na dodatek węglowy? Przez nowe zasady 3 tys. zł dostaniesz później. Jest nowy termin
 - [https://wydarzenia.interia.pl/kraj/news-czekasz-na-dodatek-weglowy-przez-nowe-zasady-3-tys-zl-dostan,nId,6299419](https://wydarzenia.interia.pl/kraj/news-czekasz-na-dodatek-weglowy-przez-nowe-zasady-3-tys-zl-dostan,nId,6299419)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 13:01:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-czekasz-na-dodatek-weglowy-przez-nowe-zasady-3-tys-zl-dostan,nId,6299419"><img align="left" alt="Czekasz na dodatek węglowy? Przez nowe zasady 3 tys. zł dostaniesz później. Jest nowy termin" src="https://i.iplsc.com/czekasz-na-dodatek-weglowy-przez-nowe-zasady-3-tys-zl-dostan/000DSUUAHRGYINPN-C321.jpg" /></a>Dodatek węglowy po nowemu. Opublikowana we wtorek ustawa o wsparciu odbiorców ciepła już obowiązuje i wprowadza sporo zmian. Między innymi

## Ogromny wzrost liczby chorych na Alzheimera w Niemczech
 - [https://wydarzenia.interia.pl/zagranica/news-ogromny-wzrost-liczby-chorych-na-alzheimera-w-niemczech,nId,6299529](https://wydarzenia.interia.pl/zagranica/news-ogromny-wzrost-liczby-chorych-na-alzheimera-w-niemczech,nId,6299529)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 12:50:29+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ogromny-wzrost-liczby-chorych-na-alzheimera-w-niemczech,nId,6299529"><img align="left" alt="Ogromny wzrost liczby chorych na Alzheimera w Niemczech" src="https://i.iplsc.com/ogromny-wzrost-liczby-chorych-na-alzheimera-w-niemczech/000AO5GOCU9QWD7T-C321.jpg" /></a>Liczba Niemców przyjętych do szpitali z powodu choroby Alzheimera wzrosła w ostatnich dwóch dekadach ponad dwukrotnie. Opublikowano nowe dane Federalnego Urzędu Statystycznego.</p>

## Rosjanie masowo wykupują bilety lotnicze. Skutki orędzia Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-masowo-wykupuja-bilety-lotnicze-skutki-oredzia-puti,nId,6299485](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-masowo-wykupuja-bilety-lotnicze-skutki-oredzia-puti,nId,6299485)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 12:47:40+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-masowo-wykupuja-bilety-lotnicze-skutki-oredzia-puti,nId,6299485"><img align="left" alt="Rosjanie masowo wykupują bilety lotnicze. Skutki orędzia Putina" src="https://i.iplsc.com/rosjanie-masowo-wykupuja-bilety-lotnicze-skutki-oredzia-puti/000G3KARVPVBVIX5-C321.jpg" /></a>Tuż po ogłoszeniu przez Władimira Putina &quot;częściowej mobilizacji&quot; wykupiono wszystkie bezpośrednie bilety na dzisiejsze l

## Zatrzymany dziennikarz Radosław M. usłyszał pedofilskie zarzuty
 - [https://wydarzenia.interia.pl/mazowieckie/news-zatrzymany-dziennikarz-radoslaw-m-uslyszal-pedofilskie-zarzu,nId,6299564](https://wydarzenia.interia.pl/mazowieckie/news-zatrzymany-dziennikarz-radoslaw-m-uslyszal-pedofilskie-zarzu,nId,6299564)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 12:45:41+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-zatrzymany-dziennikarz-radoslaw-m-uslyszal-pedofilskie-zarzu,nId,6299564"><img align="left" alt="Zatrzymany dziennikarz Radosław M. usłyszał pedofilskie zarzuty" src="https://i.iplsc.com/zatrzymany-dziennikarz-radoslaw-m-uslyszal-pedofilskie-zarzu/000G3K9RLGH57LD4-C321.jpg" /></a>Zatrzymany w środę Radosław M. usłyszał dzisiaj zarzuty z czterech paragrafów dotyczące pedofilii. To były dziennikarz TVP i Polskiego Radia. Prokurator zawnios

## Gowin odpowiada politykom Lewicy: Też nie widzę się z nimi na liście
 - [https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-gowin-odpowiada-politykom-lewicy-tez-nie-widze-sie-z-nimi-na,nId,6299539](https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-gowin-odpowiada-politykom-lewicy-tez-nie-widze-sie-z-nimi-na,nId,6299539)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 12:35:22+00:00

<p><a href="https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-gowin-odpowiada-politykom-lewicy-tez-nie-widze-sie-z-nimi-na,nId,6299539"><img align="left" alt="Gowin odpowiada politykom Lewicy: Też nie widzę się z nimi na liście" src="https://i.iplsc.com/gowin-odpowiada-politykom-lewicy-tez-nie-widze-sie-z-nimi-na/000G3K4WB4O3EQJG-C321.jpg" /></a>Po wtorkowym spotkaniu liderów opozycji część polityków Lewicy i Platformy Obywatelskiej deklaruje, że nie chce współpracować z liderem Porozumien

## Ktoś postrzelił żubra. Zwierzę nie przeżyło
 - [https://wydarzenia.interia.pl/zachodniopomorskie/news-ktos-postrzelil-zubra-zwierze-nie-przezylo,nId,6299545](https://wydarzenia.interia.pl/zachodniopomorskie/news-ktos-postrzelil-zubra-zwierze-nie-przezylo,nId,6299545)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 12:29:55+00:00

<p><a href="https://wydarzenia.interia.pl/zachodniopomorskie/news-ktos-postrzelil-zubra-zwierze-nie-przezylo,nId,6299545"><img align="left" alt="Ktoś postrzelił żubra. Zwierzę nie przeżyło" src="https://i.iplsc.com/ktos-postrzelil-zubra-zwierze-nie-przezylo/000G3K64FBBOF6H1-C321.jpg" /></a>W okolicy Dębna (woj. zachodniopomorskie) znaleziono postrzelonego żubra, zwierzęcia nie udało się uratować. Przyrodnicy alarmują, że jest to kolejny przypadek kłusownictwa w regionie. Sprawa została zgłoszona

## Potężna eksplozja w kabinie ciężarówki. Wstrząsnęła budynkami
 - [https://wydarzenia.interia.pl/zagranica/news-potezna-eksplozja-w-kabinie-ciezarowki-wstrzasnela-budynkami,nId,6299541](https://wydarzenia.interia.pl/zagranica/news-potezna-eksplozja-w-kabinie-ciezarowki-wstrzasnela-budynkami,nId,6299541)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 12:26:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-potezna-eksplozja-w-kabinie-ciezarowki-wstrzasnela-budynkami,nId,6299541"><img align="left" alt="Potężna eksplozja w kabinie ciężarówki. Wstrząsnęła budynkami" src="https://i.iplsc.com/potezna-eksplozja-w-kabinie-ciezarowki-wstrzasnela-budynkami/000G3K60GYJSDHB5-C321.jpg" /></a>Okolicą w holenderskim Geleen wstrząsnął potężny wybuch. W jednej z zaparkowanej ciężarówek doszło do eksplozji butli z gazem. Kierowca pojazdu został ciężko ranny.

## Trzebinia: Nie będzie ekshumacji ciał z zapadliska na cmentarzu
 - [https://wydarzenia.interia.pl/wiadomosci-lokalne/news-trzebinia-nie-bedzie-ekshumacji-cial-z-zapadliska-na-cmentar,nId,6299503](https://wydarzenia.interia.pl/wiadomosci-lokalne/news-trzebinia-nie-bedzie-ekshumacji-cial-z-zapadliska-na-cmentar,nId,6299503)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 11:46:00+00:00

<p><a href="https://wydarzenia.interia.pl/wiadomosci-lokalne/news-trzebinia-nie-bedzie-ekshumacji-cial-z-zapadliska-na-cmentar,nId,6299503"><img align="left" alt="Trzebinia: Nie będzie ekshumacji ciał z zapadliska na cmentarzu" src="https://i.iplsc.com/trzebinia-nie-bedzie-ekshumacji-cial-z-zapadliska-na-cmentar/000G3JXPBBKY71LV-C321.jpg" /></a>Nie będzie ekshumacji zmarłych pochowanych w grobach na cmentarzu w Trzebini, gdzie we wtorek zapadła się ziemia. Jako powód podano zagrożenie dla zdrowi

## Niemcy. Szykuje się duża amerykańska inwestycja niedaleko Polski
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-szykuje-sie-duza-amerykanska-inwestycja-niedaleko-pol,nId,6299496](https://wydarzenia.interia.pl/zagranica/news-niemcy-szykuje-sie-duza-amerykanska-inwestycja-niedaleko-pol,nId,6299496)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 11:41:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-szykuje-sie-duza-amerykanska-inwestycja-niedaleko-pol,nId,6299496"><img align="left" alt="Niemcy. Szykuje się duża amerykańska inwestycja niedaleko Polski" src="https://i.iplsc.com/niemcy-szykuje-sie-duza-amerykanska-inwestycja-niedaleko-pol/000G3JZ92PF21WK3-C321.jpg" /></a>Władze graniczącej z Polską Brandenburgii mocno zaangażowały się w poszukiwanie dużych zagranicznych firm, które miałyby zainwestować w regionie. Ten niemiecki l

## Ważne zmiany w ruchu drogowym dla pieszych i kierowców. Uwaga, mogą posypać się mandaty
 - [https://wydarzenia.interia.pl/kraj/news-wazne-zmiany-w-ruchu-drogowym-dla-pieszych-i-kierowcow-uwaga,nId,6299369](https://wydarzenia.interia.pl/kraj/news-wazne-zmiany-w-ruchu-drogowym-dla-pieszych-i-kierowcow-uwaga,nId,6299369)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 11:26:16+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wazne-zmiany-w-ruchu-drogowym-dla-pieszych-i-kierowcow-uwaga,nId,6299369"><img align="left" alt="Ważne zmiany w ruchu drogowym dla pieszych i kierowców. Uwaga, mogą posypać się mandaty" src="https://i.iplsc.com/wazne-zmiany-w-ruchu-drogowym-dla-pieszych-i-kierowcow-uwaga/000G3J9BEXHNUC4J-C321.jpg" /></a>21 września wchodzą w życie nowe przepisy ruchu drogowego. Dotyczą one nie tylko kierowców, ale przede wszystkim pieszych i rowerzystów. Wprowa

## Mobilizacja w Rosji. Gen. Pacek: Putin ma dwa cele
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-mobilizacja-w-rosji-gen-pacek-putin-ma-dwa-cele,nId,6299434](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-mobilizacja-w-rosji-gen-pacek-putin-ma-dwa-cele,nId,6299434)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 11:23:28+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-mobilizacja-w-rosji-gen-pacek-putin-ma-dwa-cele,nId,6299434"><img align="left" alt="Mobilizacja w Rosji. Gen. Pacek: Putin ma dwa cele " src="https://i.iplsc.com/mobilizacja-w-rosji-gen-pacek-putin-ma-dwa-cele/000G3JW1B4MS7J69-C321.jpg" /></a>Od środy w Rosji rozpoczyna się mobilizacja. Do armii zostanie powołanych 300 tys. żołnierzy z doświadczeniem bojowym. - To bardzo ważny moment w tej wojnie - mówi Inter

## Chicago: Trzylatek wyciągnięty z jeziora Michigan. Został popchnięty
 - [https://wydarzenia.interia.pl/zagranica/news-chicago-trzylatek-wyciagniety-z-jeziora-michigan-zostal-popc,nId,6299431](https://wydarzenia.interia.pl/zagranica/news-chicago-trzylatek-wyciagniety-z-jeziora-michigan-zostal-popc,nId,6299431)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 11:20:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chicago-trzylatek-wyciagniety-z-jeziora-michigan-zostal-popc,nId,6299431"><img align="left" alt="Chicago: Trzylatek wyciągnięty z jeziora Michigan. Został popchnięty" src="https://i.iplsc.com/chicago-trzylatek-wyciagniety-z-jeziora-michigan-zostal-popc/000G3JVXWL8GKJY9-C321.jpg" /></a>Do groźnej sytuacji doszło na Navy Pier (molo) w Chicago. Trzyletni chłopiec został wepchnięty do jeziora Michigan przez jedną z krewnych. W stanie krytyczny

## "To będzie nieodwracalne". Miedwiediew pisze o transformacji Rosji
 - [https://wydarzenia.interia.pl/zagranica/news-to-bedzie-nieodwracalne-miedwiediew-pisze-o-transformacji-ro,nId,6299467](https://wydarzenia.interia.pl/zagranica/news-to-bedzie-nieodwracalne-miedwiediew-pisze-o-transformacji-ro,nId,6299467)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 11:18:02+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-to-bedzie-nieodwracalne-miedwiediew-pisze-o-transformacji-ro,nId,6299467"><img align="left" alt="&quot;To będzie nieodwracalne&quot;. Miedwiediew pisze o transformacji Rosji" src="https://i.iplsc.com/to-bedzie-nieodwracalne-miedwiediew-pisze-o-transformacji-ro/000G3JRWEO7X88J0-C321.jpg" /></a>&quot;Po wdrożeniu referendów i przyjęciu nowych terytoriów do Rosji, geopolityczna transformacja na świecie stanie się nieodwracalna&quot; - stwierd

## Znęcał się nad pięcioletnimi bliźniaczkami, matka nie reagowała. Oboje usłyszeli wyroki
 - [https://wydarzenia.interia.pl/pomorskie/news-znecal-sie-nad-piecioletnimi-blizniaczkami-matka-nie-reagowa,nId,6299456](https://wydarzenia.interia.pl/pomorskie/news-znecal-sie-nad-piecioletnimi-blizniaczkami-matka-nie-reagowa,nId,6299456)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 11:07:36+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-znecal-sie-nad-piecioletnimi-blizniaczkami-matka-nie-reagowa,nId,6299456"><img align="left" alt="Znęcał się nad pięcioletnimi bliźniaczkami, matka nie reagowała. Oboje usłyszeli wyroki" src="https://i.iplsc.com/znecal-sie-nad-piecioletnimi-blizniaczkami-matka-nie-reagowa/000DI0ORFQJHUQ8U-C321.jpg" /></a>12 lat więzienia dla 29-letniego Daniela P. i 1,5 roku dla jego partnerki, 26-letniej Klaudii K. Taki wyrok wydał Sąd Okręgowy w Słupsku d

## Tusk: Morawiecki był moim doradcą. Bardzo się za niego wstydzę
 - [https://wydarzenia.interia.pl/kraj/news-tusk-morawiecki-byl-moim-doradca-bardzo-sie-za-niego-wstydze,nId,6299449](https://wydarzenia.interia.pl/kraj/news-tusk-morawiecki-byl-moim-doradca-bardzo-sie-za-niego-wstydze,nId,6299449)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 10:58:48+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-morawiecki-byl-moim-doradca-bardzo-sie-za-niego-wstydze,nId,6299449"><img align="left" alt="Tusk: Morawiecki był moim doradcą. Bardzo się za niego wstydzę" src="https://i.iplsc.com/tusk-morawiecki-byl-moim-doradca-bardzo-sie-za-niego-wstydze/000G3JMYJK9JY9BW-C321.jpg" /></a>Premier opublikował film podsumowany hasłem &quot;Donald nie kłam&quot;. Tusk postanowił skomentować produkcję Morawieckiego. - Powiem szczerze, ponieważ był kiedyś moi

## Policjanci chcieli sprowokować kierowcę do popełnienia wykroczenia? Komenda wyjaśnia
 - [https://wydarzenia.interia.pl/slaskie/news-policjanci-chcieli-sprowokowac-kierowce-do-popelnienia-wykro,nId,6299426](https://wydarzenia.interia.pl/slaskie/news-policjanci-chcieli-sprowokowac-kierowce-do-popelnienia-wykro,nId,6299426)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 10:36:37+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-policjanci-chcieli-sprowokowac-kierowce-do-popelnienia-wykro,nId,6299426"><img align="left" alt="Policjanci chcieli sprowokować kierowcę do popełnienia wykroczenia? Komenda wyjaśnia" src="https://i.iplsc.com/policjanci-chcieli-sprowokowac-kierowce-do-popelnienia-wykro/000G3JLN393PCKTF-C321.jpg" /></a>Kilka dni temu portal bielskiedrogi.pl opublikował nagranie, na którym policjanci w nieoznakowanym BMW &quot;patrolują ulice w poszukiwaniu pir

## "Żegnaj religio!". Furgonetka z apelem do rodziców jeździ po Polsce
 - [https://wydarzenia.interia.pl/kraj/news-zegnaj-religio-furgonetka-z-apelem-do-rodzicow-jezdzi-po-pol,nId,6299414](https://wydarzenia.interia.pl/kraj/news-zegnaj-religio-furgonetka-z-apelem-do-rodzicow-jezdzi-po-pol,nId,6299414)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 10:20:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zegnaj-religio-furgonetka-z-apelem-do-rodzicow-jezdzi-po-pol,nId,6299414"><img align="left" alt="&quot;Żegnaj religio!&quot;. Furgonetka z apelem do rodziców jeździ po Polsce" src="https://i.iplsc.com/zegnaj-religio-furgonetka-z-apelem-do-rodzicow-jezdzi-po-pol/000G3JH3EXM9GKGJ-C321.jpg" /></a>Projekt Same Plusy ruszył z akcją informującą, jak wypisać się z lekcji religii w szkole. Na trasie furgonetki z napisem &quot;Żegnaj religio!&quot; znal

## Papież nazwał Ukraińców "szlachetnymi męczennikami". Nie wspomniał o Rosji
 - [https://wydarzenia.interia.pl/zagranica/news-papiez-nazwal-ukraincow-szlachetnymi-meczennikami-nie-wspomn,nId,6299324](https://wydarzenia.interia.pl/zagranica/news-papiez-nazwal-ukraincow-szlachetnymi-meczennikami-nie-wspomn,nId,6299324)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 10:10:56+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-papiez-nazwal-ukraincow-szlachetnymi-meczennikami-nie-wspomn,nId,6299324"><img align="left" alt="Papież nazwał Ukraińców &quot;szlachetnymi męczennikami&quot;. Nie wspomniał o Rosji" src="https://i.iplsc.com/papiez-nazwal-ukraincow-szlachetnymi-meczennikami-nie-wspomn/000G3JF6YDXOM4O5-C321.jpg" /></a>- Ukraińcy poddawani są bestialskiemu traktowaniu i torturom - stwierdził papież Franciszek, nazywając ten naród &quot;szlachetnymi&quot; męc

## Ojca zastrzelono na ulicy. Jego 2-letnie dziecko zmarło w nagrzanym aucie
 - [https://wydarzenia.interia.pl/zagranica/news-ojca-zastrzelono-na-ulicy-jego-2-letnie-dziecko-zmarlo-w-nag,nId,6299356](https://wydarzenia.interia.pl/zagranica/news-ojca-zastrzelono-na-ulicy-jego-2-letnie-dziecko-zmarlo-w-nag,nId,6299356)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 09:22:07+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ojca-zastrzelono-na-ulicy-jego-2-letnie-dziecko-zmarlo-w-nag,nId,6299356"><img align="left" alt="Ojca zastrzelono na ulicy. Jego 2-letnie dziecko zmarło w nagrzanym aucie" src="https://i.iplsc.com/ojca-zastrzelono-na-ulicy-jego-2-letnie-dziecko-zmarlo-w-nag/000G3J6SCT30OJNM-C321.jpg" /></a>Do podwójnej tragedii doszło w Houston w Teksasie. 38-letni mężczyzna zmarł w wyniku strzelaniny. Samochód ofiary został skradziony, a następnie porzuco

## "Przyznanie się do porażki". Światowi liderzy o wystąpieniu Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przyznanie-sie-do-porazki-swiatowi-liderzy-o-wystapieniu-put,nId,6299342](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przyznanie-sie-do-porazki-swiatowi-liderzy-o-wystapieniu-put,nId,6299342)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 09:08:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-przyznanie-sie-do-porazki-swiatowi-liderzy-o-wystapieniu-put,nId,6299342"><img align="left" alt="&quot;Przyznanie się do porażki&quot;. Światowi liderzy o wystąpieniu Putina" src="https://i.iplsc.com/przyznanie-sie-do-porazki-swiatowi-liderzy-o-wystapieniu-put/000G3J4UGGXCVFJF-C321.jpg" /></a>Europejscy politycy komentują wystąpienie Władimira Putina, który ogłosił częściową mobilizację w Rosji. Brytyjski min

## Morawiecki: Rosja będzie kontynuować dzieło zniszczenia
 - [https://wydarzenia.interia.pl/kraj/news-morawiecki-rosja-bedzie-kontynuowac-dzielo-zniszczenia,nId,6299264](https://wydarzenia.interia.pl/kraj/news-morawiecki-rosja-bedzie-kontynuowac-dzielo-zniszczenia,nId,6299264)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 09:05:31+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-morawiecki-rosja-bedzie-kontynuowac-dzielo-zniszczenia,nId,6299264"><img align="left" alt="Morawiecki: Rosja będzie kontynuować dzieło zniszczenia " src="https://i.iplsc.com/morawiecki-rosja-bedzie-kontynuowac-dzielo-zniszczenia/000G3ISPBM9D5KHN-C321.jpg" /></a>Rosja będzie kontynuować swoje dzieło zniszczenia - powiedział premier Mateusz Morawiecki, który osobiście obserwuje trwające manewry &quot;Niedźwiedź - 22&quot; w Nowej Dębie. Jego słow

## Tomasz Wołek nie żyje. Dziennikarz miał 74 lata
 - [https://wydarzenia.interia.pl/kraj/news-tomasz-wolek-nie-zyje-dziennikarz-mial-74-lata,nId,6299336](https://wydarzenia.interia.pl/kraj/news-tomasz-wolek-nie-zyje-dziennikarz-mial-74-lata,nId,6299336)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 09:02:09+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tomasz-wolek-nie-zyje-dziennikarz-mial-74-lata,nId,6299336"><img align="left" alt="Tomasz Wołek nie żyje. Dziennikarz miał 74 lata" src="https://i.iplsc.com/tomasz-wolek-nie-zyje-dziennikarz-mial-74-lata/000G3J4HIFN180CO-C321.jpg" /></a>Nie żyje Tomasz Wołek - dziennikarz, publicysta, działacz opozycji w okresie PRL. Zmarł w wieku 74 lat. - Dobry dziennikarz powinien mieć kręgosłup, w przeciwnym razie staje się funkcjonariuszem danej partii. Ni

## Katastrofa u wybrzeży Tasmanii. Dziesiątki martwych wielorybów
 - [https://wydarzenia.interia.pl/zagranica/news-katastrofa-u-wybrzezy-tasmanii-dziesiatki-martwych-wielorybo,nId,6299335](https://wydarzenia.interia.pl/zagranica/news-katastrofa-u-wybrzezy-tasmanii-dziesiatki-martwych-wielorybo,nId,6299335)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 09:01:21+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-katastrofa-u-wybrzezy-tasmanii-dziesiatki-martwych-wielorybo,nId,6299335"><img align="left" alt="Katastrofa u wybrzeży Tasmanii. Dziesiątki martwych wielorybów" src="https://i.iplsc.com/katastrofa-u-wybrzezy-tasmanii-dziesiatki-martwych-wielorybo/000G3JHY0PN3IDBF-C321.jpg" /></a>Ponad dwieście wielorybów utknęło w pobliżu Strahan na zachodnim wybrzeżu Tasmanii, wyspy, która jest zarazem najmniejszym stanem Australii. Służby informują, że o

## Serwis eFaktura padł ofiarą ataku hakerów? Były dostępne treści erotyczne
 - [https://wydarzenia.interia.pl/kraj/news-serwis-efaktura-padl-ofiara-ataku-hakerow-byly-dostepne-tres,nId,6299312](https://wydarzenia.interia.pl/kraj/news-serwis-efaktura-padl-ofiara-ataku-hakerow-byly-dostepne-tres,nId,6299312)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 08:37:53+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-serwis-efaktura-padl-ofiara-ataku-hakerow-byly-dostepne-tres,nId,6299312"><img align="left" alt="Serwis eFaktura padł ofiarą ataku hakerów? Były dostępne treści erotyczne" src="https://i.iplsc.com/serwis-efaktura-padl-ofiara-ataku-hakerow-byly-dostepne-tres/000G3IXVB4O281HB-C321.jpg" /></a>Treści dla dorosłych i portale randkowe - w serwisie efaktura.gov.pl było dostępnych kilkaset artykułów o takiej tematyce. Było, bo strona została tymczasowo

## Koronawirus w Polsce. Tygodniowy raport Ministerstwa Zdrowia
 - [https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-koronawirus-w-polsce-tygodniowy-raport-ministerstwa-zdrowia,nId,6299188](https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-koronawirus-w-polsce-tygodniowy-raport-ministerstwa-zdrowia,nId,6299188)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 08:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-koronawirus-w-polsce-tygodniowy-raport-ministerstwa-zdrowia,nId,6299188"><img align="left" alt="Koronawirus w Polsce. Tygodniowy raport Ministerstwa Zdrowia" src="https://i.iplsc.com/koronawirus-w-polsce-tygodniowy-raport-ministerstwa-zdrowia/000FLLI7W9K3PBHI-C321.jpg" /></a>W ciągu ostatniego tygodnia wykryto w Polsce 31 425 zakażeń koronawirusem, w tym 6 457 ponownych - poinformowało Ministerstwo Zdrowia w t

## Wyskoczył za burtę, bo nie zdążył wysiąść. Na Bałtyku doszło do tragedii
 - [https://wydarzenia.interia.pl/pomorskie/news-wyskoczyl-za-burte-bo-nie-zdazyl-wysiasc-na-baltyku-doszlo-d,nId,6299298](https://wydarzenia.interia.pl/pomorskie/news-wyskoczyl-za-burte-bo-nie-zdazyl-wysiasc-na-baltyku-doszlo-d,nId,6299298)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 08:21:05+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-wyskoczyl-za-burte-bo-nie-zdazyl-wysiasc-na-baltyku-doszlo-d,nId,6299298"><img align="left" alt="Wyskoczył za burtę, bo nie zdążył wysiąść. Na Bałtyku doszło do tragedii" src="https://i.iplsc.com/wyskoczyl-za-burte-bo-nie-zdazyl-wysiasc-na-baltyku-doszlo-d/000G3IS9U6C6W0AH-C321.jpg" /></a>Pojawiają się nowe, zaskakujące ustalenia dotyczące tragedii, do której doszło na Bałtyku. Z pierwszych informacji wynikało, że mężczyzna pełniący na sta

## Właściciel psa oskarżony. Zwierzę terroryzowało mieszkańców i pogryzło kobietę
 - [https://wydarzenia.interia.pl/mazowieckie/news-wlasciciel-psa-oskarzony-zwierze-terroryzowalo-mieszkancow-i,nId,6299292](https://wydarzenia.interia.pl/mazowieckie/news-wlasciciel-psa-oskarzony-zwierze-terroryzowalo-mieszkancow-i,nId,6299292)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 08:13:05+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-wlasciciel-psa-oskarzony-zwierze-terroryzowalo-mieszkancow-i,nId,6299292"><img align="left" alt="Właściciel psa oskarżony. Zwierzę terroryzowało mieszkańców i pogryzło kobietę" src="https://i.iplsc.com/wlasciciel-psa-oskarzony-zwierze-terroryzowalo-mieszkancow-i/000G3IVX281HDF2X-C321.jpg" /></a>Właściciel mieszańca pitbula z amstafem, wabiącego się &quot;Burbon&quot;, odpowie za to, że jego pies ugryzł kobietę w czoło. Piotr P. miał takż

## Zdrowy rozsądek monarchii zastąpi terror popkultury
 - [https://wydarzenia.interia.pl/felietony/swietlik/news-zdrowy-rozsadek-monarchii-zastapi-terror-popkultury,nId,6299289](https://wydarzenia.interia.pl/felietony/swietlik/news-zdrowy-rozsadek-monarchii-zastapi-terror-popkultury,nId,6299289)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 08:01:55+00:00

<p><a href="https://wydarzenia.interia.pl/felietony/swietlik/news-zdrowy-rozsadek-monarchii-zastapi-terror-popkultury,nId,6299289"><img align="left" alt="Zdrowy rozsądek monarchii zastąpi terror popkultury" src="https://i.iplsc.com/zdrowy-rozsadek-monarchii-zastapi-terror-popkultury/000G241G758MGGYI-C321.jpg" /></a>Jest w tym coś symbolicznego, że nowy król Wielkiej Brytanii Karol III stworzył ciasteczkowe królestwo, czyli firmę wartą setki milionów funtów. Bo wraz ze śmiercią jego matki nieuchr

## Niemcy: Polak zniszczył 11 samochodów. Potem uciekł do lasu
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-polak-zniszczyl-11-samochodow-potem-uciekl-do-lasu,nId,6299258](https://wydarzenia.interia.pl/zagranica/news-niemcy-polak-zniszczyl-11-samochodow-potem-uciekl-do-lasu,nId,6299258)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 07:58:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-polak-zniszczyl-11-samochodow-potem-uciekl-do-lasu,nId,6299258"><img align="left" alt="Niemcy: Polak zniszczył 11 samochodów. Potem uciekł do lasu" src="https://i.iplsc.com/niemcy-polak-zniszczyl-11-samochodow-potem-uciekl-do-lasu/000G3IO6GXE4EPFW-C321.jpg" /></a>Jedenaście uszkodzonych samochodów i dziesięć skradzionych tablic rejestracyjnych - to bilans ataku Polaka w firmie byłego pracodawcy na terenie Niemiec. 38-latka schwytano

## Ukraina reaguje na decyzję Putina o mobilizacji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-reaguje-na-decyzje-putina-o-mobilizacji-wszystko-zgo,nId,6299276](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-reaguje-na-decyzje-putina-o-mobilizacji-wszystko-zgo,nId,6299276)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 07:49:03+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-reaguje-na-decyzje-putina-o-mobilizacji-wszystko-zgo,nId,6299276"><img align="left" alt="Ukraina reaguje na decyzję Putina o mobilizacji" src="https://i.iplsc.com/ukraina-reaguje-na-decyzje-putina-o-mobilizacji/000G3ILKWK67EH8O-C321.jpg" /></a>- Ta decyzja pokazuje, że agresja Rosji na Ukrainę nie przebiega po myśli Kremla - powiedział agencji Reutera doradca prezydenta Ukrainy Wołodymyra Zełenskiego 

## Ekspert: Rosja może dokonać sabotażu europejskich sieci energetycznych
 - [https://wydarzenia.interia.pl/kraj/news-ekspert-rosja-moze-dokonac-sabotazu-europejskich-sieci-energ,nId,6297737](https://wydarzenia.interia.pl/kraj/news-ekspert-rosja-moze-dokonac-sabotazu-europejskich-sieci-energ,nId,6297737)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 07:46:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ekspert-rosja-moze-dokonac-sabotazu-europejskich-sieci-energ,nId,6297737"><img align="left" alt="Ekspert: Rosja może dokonać sabotażu europejskich sieci energetycznych" src="https://i.iplsc.com/ekspert-rosja-moze-dokonac-sabotazu-europejskich-sieci-energ/000G2U1TFYINQTW2-C321.jpg" /></a>- Niestety Rosja jest zdolna do uderzenia w unijną infrastrukturę. Już raz to przecież zrobiła w Czechach, gdzie komórka GRU dokonała ataku na składy amunicji. 

## Katastrofa wisi w powietrzu. Rosjanie atakują tamę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-katastrofa-wisi-w-powietrzu-rosjanie-atakuja-tame,nId,6299265](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-katastrofa-wisi-w-powietrzu-rosjanie-atakuja-tame,nId,6299265)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 07:29:44+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-katastrofa-wisi-w-powietrzu-rosjanie-atakuja-tame,nId,6299265"><img align="left" alt="Katastrofa wisi w powietrzu. Rosjanie atakują tamę" src="https://i.iplsc.com/katastrofa-wisi-w-powietrzu-rosjanie-atakuja-tame/000G3IF428Y74YIN-C321.jpg" /></a>Rosyjskie wojska w ostatnich dniach regularnie ostrzeliwują tamę na Zbiorniku Pieczeńskim znajdującym się w górnym biegu rzeki Doniec. Eksperci uprzedzają, że jej usz

## Rosja powołuje 300 tysięcy żołnierzy. Szojgu tłumaczy "częściową mobilizację"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-powoluje-300-tysiecy-zolnierzy-szojgu-tlumaczy-czescio,nId,6299259](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-powoluje-300-tysiecy-zolnierzy-szojgu-tlumaczy-czescio,nId,6299259)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 07:22:57+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-powoluje-300-tysiecy-zolnierzy-szojgu-tlumaczy-czescio,nId,6299259"><img align="left" alt="Rosja powołuje 300 tysięcy żołnierzy. Szojgu tłumaczy &quot;częściową mobilizację&quot;" src="https://i.iplsc.com/rosja-powoluje-300-tysiecy-zolnierzy-szojgu-tlumaczy-czescio/000G3IDJTO114JC3-C321.jpg" /></a>Rosyjscy studenci i zwyczajni poborowi mogą spać spokojnie - na razie nie otrzymają wezwania do wojska. Jak

## Drogi z maseczek i rękawiczek. Drugie życie pandemicznych odpadów
 - [https://wydarzenia.interia.pl/zagranica/news-drogi-z-maseczek-i-rekawiczek-drugie-zycie-pandemicznych-odp,nId,6299245](https://wydarzenia.interia.pl/zagranica/news-drogi-z-maseczek-i-rekawiczek-drugie-zycie-pandemicznych-odp,nId,6299245)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 07:02:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-drogi-z-maseczek-i-rekawiczek-drugie-zycie-pandemicznych-odp,nId,6299245"><img align="left" alt="Drogi z maseczek i rękawiczek. Drugie życie pandemicznych odpadów" src="https://i.iplsc.com/drogi-z-maseczek-i-rekawiczek-drugie-zycie-pandemicznych-odp/000F8F2NEIDEU57H-C321.jpg" /></a>Asfalt wyższej jakości można uzyskać dzięki wykorzystaniu zużytych maseczek i jednorazowych rękawiczek wykorzystanych w związku z pandemią - to wnioski do jakic

## Rosyjski politolog o "buncie Pugaczowej": Kreml może mieć problem
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjski-politolog-o-buncie-pugaczowej-kreml-moze-miec-probl,nId,6299237](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjski-politolog-o-buncie-pugaczowej-kreml-moze-miec-probl,nId,6299237)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 06:46:58+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjski-politolog-o-buncie-pugaczowej-kreml-moze-miec-probl,nId,6299237"><img align="left" alt="Rosyjski politolog o &quot;buncie Pugaczowej&quot;: Kreml może mieć problem" src="https://i.iplsc.com/rosyjski-politolog-o-buncie-pugaczowej-kreml-moze-miec-probl/000G3I5H81HA3IDC-C321.jpg" /></a>- Jeśli Kreml tego nie wyciszy, to może mieć problem - mówi przebywający na emigracji rosyjski politolog Iwan Prieobraż

## Polak zabił żonę na oczach dzieci. W Niemczech ruszył proces
 - [https://wydarzenia.interia.pl/zagranica/news-polak-zabil-zone-na-oczach-dzieci-w-niemczech-ruszyl-proces,nId,6299226](https://wydarzenia.interia.pl/zagranica/news-polak-zabil-zone-na-oczach-dzieci-w-niemczech-ruszyl-proces,nId,6299226)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 06:31:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-polak-zabil-zone-na-oczach-dzieci-w-niemczech-ruszyl-proces,nId,6299226"><img align="left" alt="Polak zabił żonę na oczach dzieci. W Niemczech ruszył proces " src="https://i.iplsc.com/polak-zabil-zone-na-oczach-dzieci-w-niemczech-ruszyl-proces/000CTNH6W657NM87-C321.jpg" /></a>Śmiertelnie godził nożem żonę w ich mieszkaniu we Frankfurcie nad Odrą. Wszystko działo się na oczach dzieci pary. Sprawa wstrząsnęła opinią publiczną. Przed niemieck

## "Jak wyjechać" i "mobilizacja". Panika jeszcze przed orędziem Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-jak-wyjechac-i-mobilizacja-panika-jeszcze-przed-oredziem-put,nId,6299222](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-jak-wyjechac-i-mobilizacja-panika-jeszcze-przed-oredziem-put,nId,6299222)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 06:26:51+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-jak-wyjechac-i-mobilizacja-panika-jeszcze-przed-oredziem-put,nId,6299222"><img align="left" alt="&quot;Jak wyjechać&quot; i &quot;mobilizacja&quot;. Panika jeszcze przed orędziem Putina" src="https://i.iplsc.com/jak-wyjechac-i-mobilizacja-panika-jeszcze-przed-oredziem-put/000G3I2II43238UN-C321.jpg" /></a>W ostatnich godzinach jednymi z najpopularniejszych haseł wpisywanych przez Rosjan w Google, były &quot;ja

## Putin ogłasza częściową mobilizację. "Zachód nie chce pokoju"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-oglasza-czesciowa-mobilizacje-zachod-nie-chce-pokoju,nId,6297769](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-oglasza-czesciowa-mobilizacje-zachod-nie-chce-pokoju,nId,6297769)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 06:08:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-oglasza-czesciowa-mobilizacje-zachod-nie-chce-pokoju,nId,6297769"><img align="left" alt="Putin ogłasza częściową mobilizację. &quot;Zachód nie chce pokoju&quot;" src="https://i.iplsc.com/putin-oglasza-czesciowa-mobilizacje-zachod-nie-chce-pokoju/000G3I3WMIP112A6-C321.jpg" /></a>Prezydent Rosji Władimir Putin wygłosił orędzie w sprawie przyłączenia okupowanych ukraińskich terytoriów do Rosji. - Zachód ni

## ISW o aneksji okupowanych terytoriów i planach Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-o-aneksji-okupowanych-terytoriow-i-planach-putina,nId,6299210](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-o-aneksji-okupowanych-terytoriow-i-planach-putina,nId,6299210)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 05:59:39+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-o-aneksji-okupowanych-terytoriow-i-planach-putina,nId,6299210"><img align="left" alt="ISW o aneksji okupowanych terytoriów i planach Putina" src="https://i.iplsc.com/isw-o-aneksji-okupowanych-terytoriow-i-planach-putina/000FA82UC6VUNQSS-C321.jpg" /></a>Według ISW Putin i jego otoczenie uświadomili sobie, że siły, którymi obecnie dysponuje Rosja, nie są wystarczające do zdobycia Ukrainy. Plany aneksyjne są

## Tragiczne skutki huraganu Fiona
 - [https://wydarzenia.interia.pl/galerie/swiat/zdjecie,iId,3258909,iAId,440746](https://wydarzenia.interia.pl/galerie/swiat/zdjecie,iId,3258909,iAId,440746)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 05:32:05+00:00

<p><a href="https://wydarzenia.interia.pl/galerie/swiat/zdjecie,iId,3258909,iAId,440746"><img align="left" alt="Tragiczne skutki huraganu Fiona" src="https://i.iplsc.com/tragiczne-skutki-huraganu-fiona/000G3HSYVFFV51RT-C321.jpg" /></a>Huragan Fiona, z czterema ofiarami śmiertelnymi, pozostawił spustoszenia, w wyniku których ponad milion osób w Dominikanie jest bez bieżącej wody, a większość z 3,1 mln Portorykańczyków - bez prądu. Huragan może się wzmocnić do kategorii nr 4 z prędkością wiatru 21

## Pisarka oskarża Trumpa o gwałt. Zapowiada złożenie pozwu
 - [https://wydarzenia.interia.pl/zagranica/news-pisarka-oskarza-trumpa-o-gwalt-zapowiada-zlozenie-pozwu,nId,6299175](https://wydarzenia.interia.pl/zagranica/news-pisarka-oskarza-trumpa-o-gwalt-zapowiada-zlozenie-pozwu,nId,6299175)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 04:57:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pisarka-oskarza-trumpa-o-gwalt-zapowiada-zlozenie-pozwu,nId,6299175"><img align="left" alt="Pisarka oskarża Trumpa o gwałt. Zapowiada złożenie pozwu" src="https://i.iplsc.com/pisarka-oskarza-trumpa-o-gwalt-zapowiada-zlozenie-pozwu/000G3HQEIMKY5UWW-C321.jpg" /></a>Pisarka i felietonistka Jean Carroll zapowiada złożenie nowego pozwu przeciwko Donaldowi Trumpowi. Kobieta twierdzi, że były prezydent USA zgwałcił ją ponad ćwierć wieku temu. Ten

## Zełenski: Wyzwalamy nasz kraj i nie okazujemy słabości
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-wyzwalamy-nasz-kraj-i-nie-okazujemy-slabosci,nId,6299173](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-wyzwalamy-nasz-kraj-i-nie-okazujemy-slabosci,nId,6299173)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 04:48:52+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-wyzwalamy-nasz-kraj-i-nie-okazujemy-slabosci,nId,6299173"><img align="left" alt="Zełenski: Wyzwalamy nasz kraj i nie okazujemy słabości" src="https://i.iplsc.com/zelenski-wyzwalamy-nasz-kraj-i-nie-okazujemy-slabosci/000EUHB8CT435EN4-C321.jpg" /></a>- Bronimy Ukrainy, wyzwalamy nasz kraj i nie okazujemy przede wszystkim żadnej słabości - mówił prezydent Ukrainy Wołodymyr Zełenski w swoim wieczornym or

## "Imperialne ambicje" Kremla. Scholz ocenił, kiedy Putin odpuści
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-imperialne-ambicje-kremla-scholz-ocenil-kiedy-putin-odpusci,nId,6299168](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-imperialne-ambicje-kremla-scholz-ocenil-kiedy-putin-odpusci,nId,6299168)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 04:29:11+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-imperialne-ambicje-kremla-scholz-ocenil-kiedy-putin-odpusci,nId,6299168"><img align="left" alt="&quot;Imperialne ambicje&quot; Kremla. Scholz ocenił, kiedy Putin odpuści " src="https://i.iplsc.com/imperialne-ambicje-kremla-scholz-ocenil-kiedy-putin-odpusci/000G3HP0WSA3H9UH-C321.jpg" /></a>Rosyjski prezydent Władimir Putin zrezygnuje ze swoich &quot;imperialnych ambicji&quot;, tylko wtedy, gdy zrozumie, że nie

## USA i UE ostrzegają Rosję o konsekwencjach pseudoreferendów. "Mamy szereg narzędzi"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-usa-i-ue-ostrzegaja-rosje-o-konsekwencjach-pseudoreferendow-,nId,6299167](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-usa-i-ue-ostrzegaja-rosje-o-konsekwencjach-pseudoreferendow-,nId,6299167)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 04:24:34+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-usa-i-ue-ostrzegaja-rosje-o-konsekwencjach-pseudoreferendow-,nId,6299167"><img align="left" alt="USA i UE ostrzegają Rosję o konsekwencjach pseudoreferendów. &quot;Mamy szereg narzędzi&quot;" src="https://i.iplsc.com/usa-i-ue-ostrzegaja-rosje-o-konsekwencjach-pseudoreferendow/000B3IUMQ4CDT0L0-C321.jpg" /></a>O &quot;zwiększonych konsekwencjach&quot; ostrzegał Rosję Amerykański Departament Stanu we wtorek. Mia

## Wojna w Ukrainie. 210. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210539](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210539)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 03:31:21+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210539"><img align="left" alt="Wojna w Ukrainie. 210. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo/000FO6PP95X9K0AG-C321.jpg" /></a>Najważniejsze i najnowsze informacje dotyczące sytuacji w Ukrainie w jednym miejscu. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 210. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210636](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210636)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 03:31:21+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210636"><img align="left" alt="Wojna w Ukrainie. 210. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo/000FO6PP95X9K0AG-C321.jpg" /></a>Najważniejsze i najnowsze informacje dotyczące sytuacji w Ukrainie w jednym miejscu. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 210. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210731](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210731)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 03:31:21+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210731"><img align="left" alt="Wojna w Ukrainie. 210. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo/000FO6PP95X9K0AG-C321.jpg" /></a>Najważniejsze i najnowsze informacje dotyczące sytuacji w Ukrainie w jednym miejscu. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 210. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210821](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210821)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-21 03:31:21+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo,nzId,3043,akt,210821"><img align="left" alt="Wojna w Ukrainie. 210. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-210-dzien-inwazji-rosji-relacja-na-zywo/000FO6PP95X9K0AG-C321.jpg" /></a>Najważniejsze i najnowsze informacje dotyczące sytuacji w Ukrainie w jednym miejscu. Śledź naszą relację na żywo.</p><br clear="all" />


## Pod presją USA tureckie banki odcinają rosyjski system płatności Mir
 - [https://www.wykop.pl/link/6825921/pod-presja-usa-tureckie-banki-odcinaja-rosyjski-system-platnosci-mir/](https://www.wykop.pl/link/6825921/pod-presja-usa-tureckie-banki-odcinaja-rosyjski-system-platnosci-mir/)
 - RSS feed: https://www.wykop.pl/rss/index.xml/
 - date published: 2022-09-21 08:26:01+00:00

<img src="https://www.wykop.pl/cdn/c3397993/link_1663701116DAjOfsX00ftzdoygIjC8W2,w104h74.jpg" /><br />
		 Wysokiej rangi urzędnik administracji USA powiedział, że kroki dwóch tureckich banków Isbank i Denizbank podjęte w celu zawieszenia rosyjskiego systemu płatności Mir mają wiele sensu, i dodał, że USA oczekują, że więcej banków odetnie Mir ze względu na ryzyko objęcia sankcjami za interesy z Rosją.


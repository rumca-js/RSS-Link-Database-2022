# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Reuniting With Diego Luna
 - [https://gizmodo.com/reuniting-with-diego-luna-1849461566](https://gizmodo.com/reuniting-with-diego-luna-1849461566)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 23:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--8EjVEoD2--/c_fit,fl_progressive,q_80,w_636/36d41479b616b4c28e7311ed804121f4.jpg" /><p><a href="https://gizmodo.com/reuniting-with-diego-luna-1849461566">Read more...</a></p>

## Andor Proves Once Again That Star Wars' Heroes Are Their Best at Their Messiest
 - [https://gizmodo.com/andor-star-wars-messy-heroes-disney-plus-1849565311](https://gizmodo.com/andor-star-wars-messy-heroes-disney-plus-1849565311)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 22:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--tyxJYgCf--/c_fit,fl_progressive,q_80,w_636/d3781aab5efe70560551dbcb310ebb9b.jpg" /><p>The Cassian Andor we meet in the <a href="https://gizmodo.com/star-wars-andor-rogue-one-re-release-1849410429">earliest parts of <em>Rogue One</em></a> was already hardly the most prim-and-proper sort of person, even for <em>Star Wars</em>’ ragtag Rebel Alliance. But the one we meet <a href="https://gizmodo.com/star-wars-andor-diego-luna-disney-plus

## It’s Billionaire Baby Season: Mark Zuckerberg Is Welcoming His Third Child
 - [https://gizmodo.com/mark-zuckerberg-third-baby-priscilla-chan-meta-facebook-1849565532](https://gizmodo.com/mark-zuckerberg-third-baby-priscilla-chan-meta-facebook-1849565532)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 22:12:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--QrIf8Tqi--/c_fit,fl_progressive,q_80,w_636/18f39292a9876fc17e81801110ae5e10.png" /><p>It seems like all the billionaires are having babies right now. First, Tesla CEO <a href="https://gizmodo.com/grimes-and-elon-musk-had-a-surprise-second-kid-called-y-1848634652">Elon Musk</a> suddenly announces <a href="https://gizmodo.com/elon-musk-secret-twins-neuralink-shivon-zilis-1849151351">secret twins</a>. Now it’s Meta CEO Mark Zuckerberg’s

## Whistleblower: Pentagon Purchased Mass Surveillance Tool Collecting Americans' Web Browsing Data
 - [https://gizmodo.com/ncis-whistleblower-military-data-broker-cymru-wyden-1849564984](https://gizmodo.com/ncis-whistleblower-military-data-broker-cymru-wyden-1849564984)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 21:58:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--yzCJLIVt--/c_fit,fl_progressive,q_80,w_636/b5985f83fa01dba08970795ec043a459.jpg" /><p>Multiple military intelligence offices have paid a data broker for access to internet traffic logs, which could reveal the online browsing histories of U.S. citizens, Sen. Ron Wyden said in a letter Wednesday, citing an anonymous whistleblower that had contacted his office.</p><p><a href="https://gizmodo.com/ncis-whistleblower-military-data-broker-c

## NASA Declares Tanking Test of SLS Megarocket a Success
 - [https://gizmodo.com/sls-tanking-test-success-nasa-artemis-1-1849565384](https://gizmodo.com/sls-tanking-test-success-nasa-artemis-1-1849565384)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 21:44:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--F9kd1K1H--/c_fit,fl_progressive,q_80,w_636/687ac0efafd92fb17d865090d891ad74.jpg" /><p>A demonstration to confirm a repaired hydrogen leak appears to have gone well, with NASA declaring Wednesday’s cryogenic tanking test a success. Engineers still need to review the results, but the space agency could be on track to perform its third launch attempt of its SLS megarocket in just six days—a mission that…</p><p><a href="https://gizmodo.c

## The Gang Behind LA's School District Hack Is Demanding Ransom Two Weeks Later
 - [https://gizmodo.com/vice-society-lausd-hack-demands-ransom-1849565148](https://gizmodo.com/vice-society-lausd-hack-demands-ransom-1849565148)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 21:13:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--V0C6pVSe--/c_fit,fl_progressive,q_80,w_636/00734be053b59ea40aa980473455f9b6.jpg" /><p>The ransomware gang that hacked the Los Angeles Unified School District—paralyzing the computer systems of the second-largest school district in the country—is demanding a ransom two weeks after the attack. </p><p><a href="https://gizmodo.com/vice-society-lausd-hack-demands-ransom-1849565148">Read more...</a></p>

## House of the Dragon's Aged-Up Cast, Including the Older Princess Rhaenyra, Debuts in a New Clip
 - [https://gizmodo.com/house-of-the-dragon-princess-rhaenyra-emma-darcy-hbo-1849563998](https://gizmodo.com/house-of-the-dragon-princess-rhaenyra-emma-darcy-hbo-1849563998)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--PnrxgtlC--/c_fit,fl_progressive,q_80,w_636/3aadc31ecfce3e90664083e4abc9a6a1.png" /><p><a href="https://gizmodo.com/house-of-the-dragon-recap-we-light-the-way-episode-5-1849540836">Last week’s very bloody, very on-brand <em>Game of Thrones </em>wedding</a> marked a turn for the series to jump ahead in time on <a href="https://gizmodo.com/everything-we-know-about-house-of-the-dragon-1847808778"><em>House of the Dragon</em></a>. On Sund

## Teens Are Getting Into Vapes and Weed, Losing Interest in Booze and Other Drugs
 - [https://gizmodo.com/teenage-drug-use-trends-cannabis-vaping-alcohol-1849564770](https://gizmodo.com/teenage-drug-use-trends-cannabis-vaping-alcohol-1849564770)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 20:34:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vP5v_vTK--/c_fit,fl_progressive,q_80,w_636/3cae6373397b9a07bf0d3cc28e749644.jpg" /><p>Teens have been using less and less drugs over the past few decades, with two important exceptions, new research this week suggests. Reported levels of drug use have declined for most substances since the early 1990s, the study found, but rates of cannabis use and vaping have gone up. The findings also indicate that…</p><p><a href="https://gizmodo.c

## Marvel Studios Enlists Jeff Kaplan and Ian Springer to Write Fantastic Four
 - [https://gizmodo.com/mcu-fantastic-four-writers-jeff-kaplan-ian-springer-1849564896](https://gizmodo.com/mcu-fantastic-four-writers-jeff-kaplan-ian-springer-1849564896)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--GuQWW4Hb--/c_fit,fl_progressive,q_80,w_636/c3d770893c06371c137a2ef03d52ac85.jpg" /><p>The highly anticipated debut of Marvel’s first family into the <a href="https://gizmodo.com/marvel-release-dates-when-to-see-upcoming-mcu-movies-a-1848196856">MCU</a> didn’t come away with any major news at <a href="https://gizmodo.com/avengers-campus-disney-parks-marvel-studios-d23-expo-1849522907">D23 Expo 2022</a>—however, <a href="https://deadli

## Air Taxi Company Kittyhawk Calls It Quits
 - [https://gizmodo.com/kittyhawk-air-taxi-larry-page-1849564831](https://gizmodo.com/kittyhawk-air-taxi-larry-page-1849564831)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 20:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--hZeVqUKk--/c_fit,fl_progressive,q_80,w_636/2b30fdfd731736bafa22d3536ccfbe49.jpg" /><p>Kittyhawk, the company named for the green hills where the Wright brothers made their first controlled winged flight, has struggled to get off the ground. Now it seems the folks behind the air taxi company are ready to throw in the towel, offering little fanfare while they dive their little bird into the ground on…</p><p><a href="https://gizmodo.com

## Photos: Monster Typhoon Smashes Into Japan
 - [https://gizmodo.com/japan-typhoon-nanmadol-1849564730](https://gizmodo.com/japan-typhoon-nanmadol-1849564730)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 19:58:04+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Yx7DbWRc--/c_fit,fl_progressive,q_80,w_636/4a6d963603fa1de1aeef0404f137baa3.jpg" /><p>At least two people are dead after a powerful typhoon hit Japan this week, covering parts of the country with record amounts of rain and putting more than 9 million people under evacuation orders.</p><p><a href="https://gizmodo.com/japan-typhoon-nanmadol-1849564730">Read more...</a></p>

## How Does Walmart's New AR Virtual Try-on Work?
 - [https://gizmodo.com/walmart-be-your-own-model-virtual-clothes-try-on-1849544866](https://gizmodo.com/walmart-be-your-own-model-virtual-clothes-try-on-1849544866)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 19:57:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--n70zuy7u--/c_fit,fl_progressive,q_80,w_636/34dec6ce64ae61ff849df266d2c29bbb.jpg" /><p>Returning clothes I bought online because they weren’t what I was expecting is one of the few things in this world that <em>really</em> wracks me with guilt, mainly because I start thinking about the <a href="https://gizmodo.com/taylor-swift-private-jet-climate-change-1849359387">damage</a> <a href="https://gizmodo.com/you-can-eat-a-burger-and-still

## America’s Oldest Black Town Is Trapped Between Rebuilding and Retreating
 - [https://gizmodo.com/america-s-oldest-black-town-is-trapped-between-rebuildi-1849559546](https://gizmodo.com/america-s-oldest-black-town-is-trapped-between-rebuildi-1849559546)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 19:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--9VWiYvxA--/c_fit,fl_progressive,q_80,w_636/7a2e6f24c1a1fb5f83a1cda21b03ce88.jpg" /><p><em>This story was originally published by <a href="https://grist.org/" rel="noopener noreferrer" target="_blank">Grist</a>. You can <a href="https://go.grist.org/signup/weekly?utm_campaign=signup-page&amp;utm_medium=web&amp;utm_source=grist&amp;utm_content=weekly" rel="noopener noreferrer" target="_blank">subscribe to its weekly newsletter here</a>

## With War Raging in Ukraine, NASA Astronaut Flies to ISS Aboard Russian Rocket
 - [https://gizmodo.com/nasa-astronaut-flies-iss-russian-rocket-war-ukraine-1849564318](https://gizmodo.com/nasa-astronaut-flies-iss-russian-rocket-war-ukraine-1849564318)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 19:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--JR3y2kA5--/c_fit,fl_progressive,q_80,w_636/b2a3989a5b7fecf1f036a775d147e501.jpg" /><p>A new crew has successfully reached the International Space Station 
following the successful launch and docking of the Soyuz MS-22 spacecraft. 
The Expedition 68 crew will spend the next six months in low Earth orbit
 running science experiments and maintaining the orbital outpost, despite political tensions on the…</p><p><a href="https://gizmodo.c

## Bobby Moynihan | First Fandoms
 - [https://gizmodo.com/bobby-moynihan-first-fandoms-1849564163](https://gizmodo.com/bobby-moynihan-first-fandoms-1849564163)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 19:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--SMXNrUfw--/c_fit,fl_progressive,q_80,w_636/7b0b946c4a078559d74fb9a6c7b4e317.jpg" /><p><a href="https://gizmodo.com/bobby-moynihan-first-fandoms-1849564163">Read more...</a></p>

## Bezos's 'Orbital Reef' Space Station Is Set to Be Hollywood's Newest Star
 - [https://gizmodo.com/bezos-orbital-reef-space-station-feature-hollywood-film-1849563402](https://gizmodo.com/bezos-orbital-reef-space-station-feature-hollywood-film-1849563402)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 19:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--JTrcL8YU--/c_fit,fl_progressive,q_80,w_636/4ec8a9578d79764c37fa16a4d0064e60.png" /><p>Orbital Reef, a yet-to-be-constructed space station from Blue Origin and Sierra Space, will appear in the forthcoming sci-fi movie titled <em>HELIOS</em>, which is set in the year 2030. </p><p><a href="https://gizmodo.com/bezos-orbital-reef-space-station-feature-hollywood-film-1849563402">Read more...</a></p>

## Puerto Ricans Now Face Heat Wave After Days Without Power and Water
 - [https://gizmodo.com/puerto-rico-hurricane-fiona-heat-wave-blackout-1849563984](https://gizmodo.com/puerto-rico-hurricane-fiona-heat-wave-blackout-1849563984)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 19:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--yGs8nwrI--/c_fit,fl_progressive,q_80,w_636/497495cc37a65e1a98e9ff45eec6d798.jpg" /><p>Hurricane Fiona has caused widespread damage across Puerto Rico, and now the island is under a heat advisory. Most residents currently do not have electricity or running water.</p><p><a href="https://gizmodo.com/puerto-rico-hurricane-fiona-heat-wave-blackout-1849563984">Read more...</a></p>

## Beyond Meat's COO (Allegedly) Bit a Guy's Nose at the Worst Possible Time
 - [https://gizmodo.com/beyond-meat-nose-bite-taco-bell-plant-based-1849563464](https://gizmodo.com/beyond-meat-nose-bite-taco-bell-plant-based-1849563464)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--F8iT3Fl3--/c_fit,fl_progressive,q_80,w_636/7b3f3f8ba391633e1611f094efeb1183.jpg" /><p>Thoughts and prayers for Beyond Meat in this trying time. The plant-based burger replacement company is currently swimming in struggle sauce. Doug Ramsey, Beyond’s chief operating officer, <a href="https://www.prnewswire.com/news-releases/beyond-meat-issues-statement-301628925.html" rel="noopener noreferrer" target="_blank">has been suspended</a> fr

## Hellraiser's Director and New Pinhead on What Makes the Hulu Film Feel Fresh—and Scary
 - [https://gizmodo.com/hellraiser-hulu-pinhead-horror-interview-star-director-1849560720](https://gizmodo.com/hellraiser-hulu-pinhead-horror-interview-star-director-1849560720)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 18:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--swOv-Vx2--/c_fit,fl_progressive,q_80,w_636/be26e3d29f85a11507bff8b0d549c1c2.png" /><p>The <a href="https://gizmodo.com/hulu-hellraiser-horror-trailer-clive-barker-new-pinhead-1849558361">new <em>Hellraiser</em></a> arrives on Hulu next month, and fans of Clive Barker’s horror franchise are eagerly waiting to see what <a href="https://gizmodo.com/hellraiser-hulu-horror-david-bruckner-clive-barker-1849559114">director David Bruckner</a

## Getty Says ‘No’ to AI-Generated Images Because it Doesn't Want Any(more) Copyright Headaches
 - [https://gizmodo.com/getty-ai-art-dall-e-getty-images-ai-art-generators-1849563869](https://gizmodo.com/getty-ai-art-dall-e-getty-images-ai-art-generators-1849563869)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 18:05:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--PiQgn8Zv--/c_fit,fl_progressive,q_80,w_636/60534132a77f0b01917eb14b051e9cd5.jpg" /><p>Deepfakes are no longer desired, fakes are now forlorn, and any AI-originated content will be ostracized from image hosting website Getty Images.</p><p><a href="https://gizmodo.com/getty-ai-art-dall-e-getty-images-ai-art-generators-1849563869">Read more...</a></p>

## Jodie Whittaker's Doctor Who Era Ends With The Power of the Doctor
 - [https://gizmodo.com/doctor-who-jodie-whittaker-power-of-the-doctor-bbc-1849563840](https://gizmodo.com/doctor-who-jodie-whittaker-power-of-the-doctor-bbc-1849563840)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 18:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vA9mX54o--/c_fit,fl_progressive,q_80,w_636/d24d0de3a215d396fb4e0c3b66ff640a.png" /><p>This October, <em>Doctor Who</em>’s <a href="https://gizmodo.com/doctor-who-legend-of-the-sea-devils-recap-1848804342">Thirteenth Doctor, Jodie Whittaker</a>, will take her final bow. Current showrunner Chris Chibnall will also be departing the series before David Tennant and Russell T. Davies return for the series’ <a href="https://gizmodo.com/doct

## The 21 Wildest, Coolest, and Most Unique Films We Can't Wait to See at Fantastic Fest 2022
 - [https://gizmodo.com/fantastic-fest-2022-preview-aliens-vampires-clowns-demo-1849553756](https://gizmodo.com/fantastic-fest-2022-preview-aliens-vampires-clowns-demo-1849553756)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 17:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--LQ6mUfwO--/c_fit,fl_progressive,q_80,w_636/66379133b2e95a9e466ed71244942557.jpg" /><p>Three years have passed since io9 traveled to Austin, Texas for a week of <a href="https://gizmodo.com/time-travel-monsters-aliens-butts-our-10-favorite-f-1838464131">fun, fucked up films</a>. The event is Fantastic Fest, one of the <a href="https://gizmodo.com/the-20-wildest-coolest-and-most-unique-films-we-cant-1838075972">coolest, most unique gen

## The World’s Largest Four-Day Work Week Experiment Reveals Increase in Employee Wellbeing
 - [https://gizmodo.com/four-day-work-week-work-from-home-return-to-office-1849562791](https://gizmodo.com/four-day-work-week-work-from-home-return-to-office-1849562791)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 17:25:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--gmCFP_EC--/c_fit,fl_progressive,q_80,w_636/853a29c36f30f1b63aa3e6771ca791d1.jpg" /><p>The five-day work week has long been a staple of the world’s workforce, but a massive experiment testing a <a href="https://gizmodo.com/four-day-work-week-wfh-remote-work-return-to-office-1849022441">four-day work week</a> in the United Kingdom, which began three months ago, is already seeing some incredibly promising results.<br /></p><p><a href="h

## Chicago’s Tap Water Contaminated With Lead, Analysis Finds
 - [https://gizmodo.com/chicago-tap-water-lead-1849562931](https://gizmodo.com/chicago-tap-water-lead-1849562931)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 17:17:06+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--115Ya0wX--/c_fit,fl_progressive,q_80,w_636/a01885381c7f365b085ff21f5c4b1578.jpg" /><p>Chicago residents are being exposed to lead through their tap water.<br /></p><p><a href="https://gizmodo.com/chicago-tap-water-lead-1849562931">Read more...</a></p>

## Saudi Arabia Buys Two Tickets to the ISS Aboard a SpaceX Falcon 9 Rocket
 - [https://gizmodo.com/saudi-arabia-buys-two-tickets-iss-spacex-falcon-9-1849563085](https://gizmodo.com/saudi-arabia-buys-two-tickets-iss-spacex-falcon-9-1849563085)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 17:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--KJN7FHLy--/c_fit,fl_progressive,q_80,w_636/ecf3afe2ea2ef39157f476806db35ffe.png" /><p>Saudi Arabia has reportedly signed a deal with private space company Axiom Space to fly two of its astronauts to the International Space Station as part of the second privately funded trip to the orbital lab.</p><p><a href="https://gizmodo.com/saudi-arabia-buys-two-tickets-iss-spacex-falcon-9-1849563085">Read more...</a></p>

## Chinese 'Tank Cake' Streamer Back Online After 3 Month Internet Disappearance
 - [https://gizmodo.com/china-lipstick-king-live-streamer-tank-cake-1849563066](https://gizmodo.com/china-lipstick-king-live-streamer-tank-cake-1849563066)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 16:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--LTS-4FYZ--/c_fit,fl_progressive,q_80,w_636/dd0bde02115873052bfff016edcc9803.jpg" /><p>A prominent Chinese live streamer who may have drawn government scrutiny for showing off a tank-shaped cake ahead of the 33-year anniversary of the <a href="https://gizmodo.com/the-declassified-history-of-the-tiananmen-square-prote-1586509043">Tiananmen Square massacre</a> suddenly reappeared this week following a three-month digital disappearance.<

## Logitech's $350 G Cloud Game Streaming Handheld Promises an Impressive 12 Hours of Battery Life
 - [https://gizmodo.com/logitech-g-cloud-game-streaming-handheld-xbox-game-pass-1849563155](https://gizmodo.com/logitech-g-cloud-game-streaming-handheld-xbox-game-pass-1849563155)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 16:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Y1Qcs7Xl--/c_fit,fl_progressive,q_80,w_636/60cba829c086b03333801b778e61f272.jpg" /><p>Nintendo started a renaissance in handheld gaming with the Switch, but it was the advent of game streaming that has reshaped what portable gaming can be. Big budget AAA titles, once relegated to powerful consoles, can be now be played anywhere, and it’s ushering in a new wave of handhelds designed specifically for…</p><p><a href="https://gizmodo.com

## Evangelion 3.0+1.0 Is Finally Coming to U.S. Theaters This December
 - [https://gizmodo.com/evangelion-thrice-upon-a-time-us-theatrical-release-1849563431](https://gizmodo.com/evangelion-thrice-upon-a-time-us-theatrical-release-1849563431)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 16:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--hNQjJ7gj--/c_fit,fl_progressive,q_80,w_636/3607a2e2a94a5eecd6bdd41d00415ab2.png" /><p><a href="https://gizmodo.com/the-radical-sincerity-of-evangelions-final-end-1847498562">The final chapter</a> in the <em>Rebuild of Evangelion</em> movies—perhaps even the final chapter of<a href="https://gizmodo.com/the-quick-and-easy-guide-to-watching-evangelion-1847483815"> <em>Neon Genesis Evangelion</em> at large</a>—made <a href="https://gizmo

## The Star Wars Universe Finds a Radical New Stride With Andor
 - [https://gizmodo.com/star-wars-andor-diego-luna-disney-plus-lucasfilm-1849555939](https://gizmodo.com/star-wars-andor-diego-luna-disney-plus-lucasfilm-1849555939)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--tPqQStNr--/c_fit,fl_progressive,q_80,w_636/275698135406783735bd083bd6259740.jpg" /><p>With <em>Andor</em>, showrunner <a href="https://gizmodo.com/star-wars-directors-tony-gilroy-andor-rogue-one-jj-abra-1849553354">Tony Gilroy</a> masterfully sets up a new <em>Star Wars</em> universe that drops us on the ground level pre-Rebellion and explores the lives of the disenfranchised in the shadow of the Empire. No need for space wizardry he

## Who Made Brian Baumgartner Break Character on The Office?
 - [https://gizmodo.com/who-made-brian-baumgarten-break-character-on-the-office-1849540682](https://gizmodo.com/who-made-brian-baumgarten-break-character-on-the-office-1849540682)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 15:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--wld3Yf8R--/c_fit,fl_progressive,q_80,w_636/516d3bce7be3519aab1ae0fc3f35b8f9.jpg" /><p><a href="https://gizmodo.com/who-made-brian-baumgarten-break-character-on-the-office-1849540682">Read more...</a></p>

## Giant Centrifuge Startup That Wants to Hurl Things Into Space Raises $71 Mil
 - [https://gizmodo.com/spinlaunch-funding-centrifuge-orbit-1849562787](https://gizmodo.com/spinlaunch-funding-centrifuge-orbit-1849562787)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 15:31:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--MHQaDFNO--/c_fit,fl_progressive,q_80,w_636/3a2cd0cb2c8e9559ecdbc8c65b75d266.png" /><p>SpinLaunch said on Tuesday that it raised $71 million in funding during its second round of financing. The California-based company said it will use the funds to further develop an unconventional system for launching small payloads to Earth orbit. </p><p><a href="https://gizmodo.com/spinlaunch-funding-centrifuge-orbit-1849562787">Read more...</a></p

## You've Never Seen Neptune Look Like This
 - [https://gizmodo.com/webb-image-of-neptune-rings-1849562471](https://gizmodo.com/webb-image-of-neptune-rings-1849562471)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 15:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--E0zOWM1V--/c_fit,fl_progressive,q_80,w_636/a548f33c64f9419e59dd6c0c03c4d94d.jpg" /><p>The Webb Space Telescope has produced yet another view of a <a href="https://gizmodo.com/webb-telescope-first-mars-images-1849552719">solar system planet</a>, and you may not be able to guess the world from the image alone. The new portrait of Neptune shows its dramatic and often overlooked rings, and the European Space Agency says this is the clear

## Framework's Chromebook Is Bringing Modularity to ChromeOS
 - [https://gizmodo.com/framework-laptop-chromebook-chromeos-google-modular-1849559649](https://gizmodo.com/framework-laptop-chromebook-chromeos-google-modular-1849559649)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--rUUOmOuB--/c_fit,fl_progressive,q_80,w_636/b7e9487f1acd59b974bba3a3f0cac3ec.png" /><p>Who knows if Google will ever make another Pixelbook? But ChromeOS is getting something better: modularity. Framework, the company behind the swappable modular laptop, has <a href="https://frame.work/blog" rel="noopener noreferrer" target="_blank">announced</a> the Framework Laptop Chromebook Edition. It costs $1000 for the base model and features t

## Strange World's New Trailer Shows Off Its Pulpy Sci-Fi Roots
 - [https://gizmodo.com/strange-world-trailer-disney-animated-jake-gyllenhaal-1849562248](https://gizmodo.com/strange-world-trailer-disney-animated-jake-gyllenhaal-1849562248)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--sNs-rjuA--/c_fit,fl_progressive,q_80,w_636/0eaab2a87c6ef86aa55b511838eafd30.jpg" /><p>Disney’s newest (fully) <a href="https://gizmodo.com/sonic-prime-trailer-netflix-hedgehog-multiverse-1849557950">animated feature</a>, <a href="https://gizmodo.com/disney-strange-world-trailer-jake-gyllenhaal-retro-sci-1849022675"><em>Strange World</em></a>, has finally gotten a full length trailer. <em>Strange World</em> follows the Clades, a famil

## Twitch Cuts Off Streamers' Unlicensed Gambling Gains While Planning to Limit Top Creators’ Revenue
 - [https://gizmodo.com/twitch-creators-gaming-gambling-betting-itssliker-1849562643](https://gizmodo.com/twitch-creators-gaming-gambling-betting-itssliker-1849562643)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 14:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--WradRrMT--/c_fit,fl_progressive,q_80,w_636/cf77bca2871372dce6b5f8a35054dac8.jpg" /><p>Twitch is making big changes to its platform. The streaming platform has moved to counter overseas gambling companies from leeching off of Twitch users, but almost in the same breath announced they were cutting the top pay of the biggest Twitch streamers.</p><p><a href="https://gizmodo.com/twitch-creators-gaming-gambling-betting-itssliker-1849562643

## TikTok Cracks Down on Political Content
 - [https://gizmodo.com/tiktok-midterms-politics-influencers-social-media-1849562186](https://gizmodo.com/tiktok-midterms-politics-influencers-social-media-1849562186)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 14:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--avFqTtmr--/c_fit,fl_progressive,q_80,w_636/bf0fbe765a5ccb00dfe310621fb50665.jpg" /><p>Ahead of the U.S. midterm elections, TikTok announced some changes to its content policy. The social media giant is now barring videos that contain political fundraising and mandating verification for U.S.-based <a href="https://support.tiktok.com/en/using-tiktok/growing-your-audience/government-politician-and-political-party-accounts" rel="noopener

## The Flash's Final Season Will Bring Back Another Member of the Rogues
 - [https://gizmodo.com/the-flash-season-9-captain-boomerang-set-pictures-1849551411](https://gizmodo.com/the-flash-season-9-captain-boomerang-set-pictures-1849551411)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 14:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--7JrqsI15--/c_fit,fl_progressive,q_80,w_636/42c8efa94559af6cad240bcb0a99881c.png" /><p>The Sanderson sisters tell you why you should watch <em>Hocus Pocus 2</em>. <em>Stargirl</em> and <em>Titans</em> could be teaming up<em>. </em>Plus, Khary Payton teases what to expect from <em>Invincible</em>’s future, what’s coming on <em>Quantum Leap,</em> and more info about the return of <em>Chucky</em>. Spoilers now!<br /></p><p><a href="https

## This Electric Car Ad From 1921 Asked Drivers To Be Brutally Honest With Themselves
 - [https://gizmodo.com/electric-car-ad-1921-drivers-brutally-honest-rauch-lang-1849543806](https://gizmodo.com/electric-car-ad-1921-drivers-brutally-honest-rauch-lang-1849543806)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 11:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--7er92pI0--/c_fit,fl_progressive,q_80,w_636/9970378ee7eb73d611c4d5dc422e9fe9.jpg" /><p>At the turn of the 20th century, one-third of all cars produced in the U.S. were electric. By the 1920s, gasoline-powered cars had grown to dominate the market because they offered greater range and speed. But one electric car company asked newspaper readers in 1921 to be brutally honest with themselves about what…</p><p><a href="https://gizmodo.com

## Watch Live as Russia Launches the Next ISS Crew—Including a U.S. Astronaut—to Space
 - [https://gizmodo.com/russia-launch-iss-crew-expedition-68-nasa-astronaut-1849559787](https://gizmodo.com/russia-launch-iss-crew-expedition-68-nasa-astronaut-1849559787)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 11:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--2kX8aLpS--/c_fit,fl_progressive,q_80,w_636/ab12e33657efbdd30e98018e2608b6da.jpg" /><p>The International Space Station is gearing up to host a new crew. NASA astronaut Frank Rubio, along with Roscosmos astronauts Sergey Prokopyev and Dmitri Petelin, are launching on board a Soyuz MS-22 crew ship on Wednesday to spend six months on the orbiting space station. You can catch the action live right here. <br /></p><p><a href="https://gizmo

## 23-Year-Old 'Crypto King' Has Luxury Cars Seized After $35 Million of Investor Money Vanishes
 - [https://gizmodo.com/crypto-king-bitcoin-price-luxury-cars-seized-35-million-1849561634](https://gizmodo.com/crypto-king-bitcoin-price-luxury-cars-seized-35-million-1849561634)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 10:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Xi3DEzpW--/c_fit,fl_progressive,q_80,w_636/f3f2798de2c8d71b47c839574275e91f.jpg" /><p>Five luxury cars, including two BMWs, two McLarens, and a Lamborghini, have been seized from 23-year-old Aiden Pleterski, the self-described “crypto king” of Canada, during bankruptcy proceedings according to a new report from the <a href="https://www.cbc.ca/news/canada/toronto/luxury-cars-seized-crypto-king-investors-try-recoup-millions-1.6583982" 

## James Cameron Was Worried Avatar 2 Might Have Taken Too Long
 - [https://gizmodo.com/james-cameron-avatar-2-release-date-disney-fox-pandora-1849559989](https://gizmodo.com/james-cameron-avatar-2-release-date-disney-fox-pandora-1849559989)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-21 00:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--f_RwVut9--/c_fit,fl_progressive,q_80,w_636/f4dd5f6259b959e2259574ca8ecabc00.jpg" /><p>After a film grosses almost <a href="https://gizmodo.com/avatar-re-release-spells-trouble-for-avengers-endgames-1846441767">$3 billion at the global box office</a>, you have to imagine <a href="https://gizmodo.com/film-from-studio-acquired-by-walt-disney-finally-beats-1836581329">the studio behind it would want</a> to cash in immediately. Get a sequ


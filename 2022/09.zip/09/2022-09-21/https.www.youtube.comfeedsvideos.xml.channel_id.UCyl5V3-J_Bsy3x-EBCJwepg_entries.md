# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## FBI Gets Great Night's Sleep After Raiding MyPillow Guy
 - [https://www.youtube.com/watch?v=ucXNO2D9EpU](https://www.youtube.com/watch?v=ucXNO2D9EpU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-09-22 00:00:00+00:00

The FBI raided Mike Lindell looking for evidence of a crime, but what they found instead was a good night's sleep.

Show your support for our favorite mustachioed pillow salesman by using discount code BEE1 and picking up the FBI's favorite pillow here: https://mypillow.com/bee1

## The Fakest News In Podcasting: Watch The Babylon Bee Podcast Every Week!
 - [https://www.youtube.com/watch?v=nEjk1JzWYI8](https://www.youtube.com/watch?v=nEjk1JzWYI8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-09-22 00:00:00+00:00

Follow our podcast channel and see this great content here: https://www.youtube.com/c/TheBabylonBeePodcast

Watch your trusted team of fake news journalists every week talk about the news, the crazy things going on at The Babylon Bee, and also eternal truths like The Last Jedi being the worst movie ever made.


# Source:The Guardian - International, URL:https://www.theguardian.com/international/rss, language:en-US

## Iranians: share your views on the protests following Mahsa Amini’s death
 - [https://www.theguardian.com/world/2022/sep/21/iranians-share-your-views-on-the-protests-following-mahsa-aminis-death](https://www.theguardian.com/world/2022/sep/21/iranians-share-your-views-on-the-protests-following-mahsa-aminis-death)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2022-09-21 11:12:02+00:00

<p>We’d like to hear from people in Iran how they feel about the protests following the death of Mahsa Amini in custody</p><p>We’d like to hear how Iranians feel about the protests taking place in Iran after <a href="https://www.theguardian.com/global-development/2022/sep/16/iranian-woman-dies-after-being-beaten-by-morality-police-over-hijab-law">Mahsa Amini’s death in custody in Tehran</a>.</p><p>Whether you have witnessed street protests directly or just want to share your views on the situation in Iran, we’re interested to hear from you.</p> <a href="https://www.theguardian.com/world/2022/sep/21/iranians-share-your-views-on-the-protests-following-mahsa-aminis-death">Continue reading...</a>

## Russians: tell us what you think about Putin’s escalation of war in Ukraine
 - [https://www.theguardian.com/world/2022/sep/21/russians-tell-us-what-you-think-about-putins-escalation-of-war-in-ukraine](https://www.theguardian.com/world/2022/sep/21/russians-tell-us-what-you-think-about-putins-escalation-of-war-in-ukraine)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2022-09-21 10:33:21+00:00

<p>We would like to hear views and opinions from Russians at this stage of the Russia-Ukraine war</p><p>Russia has announced a <a href="https://www.theguardian.com/world/2022/sep/21/putin-announces-partial-mobilisation-in-russia-in-escalation-of-ukraine-war">partial mobilisation</a> in a major escalation that places the country’s people and economy on a wartime footing.</p><p>With president Vladimir Putin also threatening nuclear retaliation, we would like to hear from Russians about how ordinary people are reacting to the latest developments in the war on Ukraine.</p> <a href="https://www.theguardian.com/world/2022/sep/21/russians-tell-us-what-you-think-about-putins-escalation-of-war-in-ukraine">Continue reading...</a>


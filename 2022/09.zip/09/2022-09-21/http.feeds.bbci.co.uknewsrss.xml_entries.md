# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Universal Credit rules to be tightened under chancellor's plans
 - [https://www.bbc.co.uk/news/business-62989572?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62989572?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 23:39:50+00:00

Chancellor Kwasi Kwarteng is expected to announce a welfare shake-up to 'get Britain working again'.

## Queen Elizabeth II: 16 moments from 16 tours of Australia
 - [https://www.bbc.co.uk/news/world-australia-62977862?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-62977862?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 23:25:36+00:00

As Australians hold a day of mourning, we look back on memorable moments from her trips down under.

## Scotland 3-0 Ukraine: How Steve Clarke's side spurred on by summer of hurt
 - [https://www.bbc.co.uk/sport/football/62990002?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62990002?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 23:13:02+00:00

Scotland's players took out the hurt from a disappointing June on Ukraine with a stunning performance at Hampden.

## UK interest rates: Rise expected and what that means for you
 - [https://www.bbc.co.uk/news/business-57764601?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-57764601?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 23:07:48+00:00

The Bank of England will announce its decision later with a seventh consecutive rise expected.

## The fake sex chats fuelled by an elaborate scam
 - [https://www.bbc.co.uk/news/world-africa-62230304?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-62230304?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 23:06:32+00:00

The erotic messages supposedly sent from women on some adult websites are often actually from men.

## Real Living Wage rises to £10.90 an hour
 - [https://www.bbc.co.uk/news/business-62976711?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62976711?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 23:06:26+00:00

A rate increase for the voluntary scheme has been brought forward due to the rising cost of living.

## 'We blew the doors off' - the inside story of the poker boom
 - [https://www.bbc.co.uk/sport/62908116?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/62908116?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 23:04:00+00:00

Poker's rapid growth during the 2000s took the card game to new heights. Antonio Esfandiari was among its 'rock stars'.

## Ukraine war: The Russians risking freedom to protest Putin's invasion
 - [https://www.bbc.co.uk/news/world-europe-62969778?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62969778?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 23:03:07+00:00

Activists describe the conflict as "horrific" and don masks to spray messages on Russian streets.

## Pet perks tempt staff back into the office
 - [https://www.bbc.co.uk/news/business-62912862?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62912862?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 23:02:09+00:00

Some businesses are giving staff incentives to get them back into the workplace.

## The men behind a record-breaking menstrual campaign
 - [https://www.bbc.co.uk/news/world-asia-india-62971516?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-62971516?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 22:58:36+00:00

An Indian initiative seeking to break down taboos has been simulating period pain in men.

## The Papers: 'Putin's nuclear threat' and 'Russians see red'
 - [https://www.bbc.co.uk/news/blogs-the-papers-62989911?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-62989911?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 22:52:57+00:00

Russia's mobilisation of 300,000 reservists and threats to use nuclear weapons dominate the front pages.

## Huddersfield stabbing: Boy, 15, dies after attack outside school
 - [https://www.bbc.co.uk/news/uk-england-leeds-62990101?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-62990101?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 22:28:46+00:00

Police in Huddersfield begin a murder investigation after the incident on Wednesday afternoon.

## Ukraine war: Foreign secretary to confront Russia over atrocities at UN meeting
 - [https://www.bbc.co.uk/news/uk-politics-62989500?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62989500?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 22:19:10+00:00

The foreign secretary will demand justice in a meeting with his Russian counterpart Sergei Lavrov.

## Watch: Sportscene - Scotland v Ukraine highlights
 - [https://www.bbc.co.uk/sport/av/football/62960690?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/62960690?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 21:37:57+00:00

Watch highlights of Scotland's Nations League meeting with Ukraine on BBC Scotland's Sportscene.

## Britons held by Russian forces in Ukraine released
 - [https://www.bbc.co.uk/news/uk-62988234?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62988234?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 21:18:01+00:00

Three men captured while fighting with Ukraine's military are among the five released.

## 'Truly remarkable' drug helps motor neurone disease
 - [https://www.bbc.co.uk/news/health-62851186?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-62851186?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 21:07:30+00:00

Scientists say they have slowed and partially reversed damage, marking a "new era" in the disease.

## Scotland 3-0 Ukraine: John McGinn & Lyndon Dykes double earn vital Nations League win
 - [https://www.bbc.co.uk/sport/football/62897957?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62897957?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 21:02:40+00:00

Scotland go some way to compensating for their World Cup play-off heartache by claiming a crucial Nations League victory over Ukraine at Hampden to move top of Group B1.

## England v India: Amy Jones warns of inconsistency from young side after series loss
 - [https://www.bbc.co.uk/sport/cricket/62989750?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62989750?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 20:36:44+00:00

England captain Amy Jones warns "with youth comes inconsistency" after her side slumps to a one-day international series defeat by India.

## Brazil election: Why it matters so much to the US
 - [https://www.bbc.co.uk/news/world-us-canada-62981625?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62981625?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 20:31:59+00:00

The US has been taking a keen interest in who Brazil picks as its next president. Why?

## England v India: Harmanpreet Kaur hits masterful century to lead India to ODI series win
 - [https://www.bbc.co.uk/sport/cricket/62983394?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62983394?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 19:58:51+00:00

Harmanpreet Kaur hits a sublime 143 not out from 111 balls to guide India to an 88-run victory over England in the second one-day international at Canterbury.

## Wasps: Premiership club to appoint administrators to 'protect club's interests'
 - [https://www.bbc.co.uk/sport/rugby-union/62986407?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/62986407?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 19:11:37+00:00

Premiership club Wasps says the move "does not mean the business is in administration" but will provide "a crucial period of grace".

## Ukraine conflict: Russia arrests hundreds at anti-war protests
 - [https://www.bbc.co.uk/news/world-europe-62981293?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62981293?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 18:48:23+00:00

Russia's partial military call-up triggers protests - and a rush for flights to foreign destinations.

## US interest rates hit 14-year high in inflation battle
 - [https://www.bbc.co.uk/news/business-62973376?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62973376?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 18:25:30+00:00

The US unveils another sharp rate rise as it fights to bring soaring prices under control.

## Chris Kaba family views police body-cam footage
 - [https://www.bbc.co.uk/news/uk-england-london-62983769?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62983769?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 17:58:06+00:00

The mother of the 24-year-old shot dead by the Met says watching the footage was "very hard".

## Tax cut 'gamble' will make debt unsustainable, says IFS
 - [https://www.bbc.co.uk/news/business-62984023?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62984023?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 17:37:47+00:00

The Institute for Fiscal Studies says UK borrowing is on an "unsustainable" path.

## Huddersfield school attack: Boy, 15, critically injured
 - [https://www.bbc.co.uk/news/uk-england-leeds-62984349?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-62984349?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 17:30:04+00:00

Police say the teenager was found seriously injured following the attack in Huddersfield.

## Prince William 'comforted' by support for his environmental work
 - [https://www.bbc.co.uk/news/uk-62986077?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62986077?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 16:47:47+00:00

He praised the passion of people supporting the Earthshot environmental prize he helped set up.

## Premier League: Clubs agree minimum one-year bans for supporters
 - [https://www.bbc.co.uk/sport/football/62986231?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62986231?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 16:38:18+00:00

Supporters found to be taking part in anti-social or criminal behaviour at Premier League grounds now face a minimum one-year ban following a club ruling.

## Donald Trump sued for fraud over family business
 - [https://www.bbc.co.uk/news/world-us-canada-62986812?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62986812?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 16:22:43+00:00

Mr Trump and the Trump Organization are accused of falsely inflating his net worth by "billions".

## England v India: Harmanpreet Kaur's 'sensational' 143 not out - best shots
 - [https://www.bbc.co.uk/sport/av/cricket/62984172?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/62984172?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 16:21:39+00:00

Watch the best shots from Harmanpreet Kaur's "sensational" century as she closes the innings on 143 not out for India in their second ODI match against England at The Spitfire Ground in Canterbury.

## Ukraine war: Putin orders partial mobilisation after facing setbacks
 - [https://www.bbc.co.uk/news/world-europe-62984985?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62984985?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 15:37:48+00:00

The partial mobilisation comes after Russia faced a number of setbacks on the battlefield.

## Wayne Couzens: PCs in WhatsApp group with Sarah Everard killer found guilty
 - [https://www.bbc.co.uk/news/uk-england-surrey-62981675?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-surrey-62981675?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 15:18:13+00:00

Two Met PCs shared grossly offensive messages on WhatsApp with Sarah Everard's killer Wayne Couzens.

## Floyd Mayweather: Retired undefeated boxer plots rematch with Conor McGregor in 2023
 - [https://www.bbc.co.uk/sport/boxing/62986197?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/62986197?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 15:15:37+00:00

Retired boxer Floyd Mayweather says he is in talks to fight Conor McGregor again, potentially in an exhibition match next year.

## England v India: Harmanpreet Kaur hits six off Charlie Dean to reach half-century
 - [https://www.bbc.co.uk/sport/av/cricket/62984168?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/62984168?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 15:11:11+00:00

Watch India's Harmanpreet Kaur hit Charlie Dean for a six to bring up her half-century against England during the second ODI at The Spitfire Ground in Canterbury.

## Ukraine war: Putin raises the stakes in a dangerous game
 - [https://www.bbc.co.uk/news/world-europe-62984728?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62984728?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 14:42:16+00:00

When faced with a choice, Vladimir Putin always seems to choose escalation, writes the BBC's Russia editor.

## Iran protests: Mahsa Amini's death puts morality police under spotlight
 - [https://www.bbc.co.uk/news/world-middle-east-62984076?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-62984076?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 14:34:24+00:00

The death of a woman detained by Iran's morality police has sparked angry protests, but who are they?

## Lancashire bowl out Essex for 59 to claim incredible win
 - [https://www.bbc.co.uk/sport/cricket/62983079?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62983079?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 14:25:36+00:00

George Balderson takes a hat-trick as Lancashire bowl out Essex for 59 to claim a remarkable victory.

## Olivia Pratt-Korbel: Record £200k reward in hunt for girl's killer
 - [https://www.bbc.co.uk/news/uk-england-merseyside-62981651?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-62981651?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 13:38:17+00:00

The money has been put up for information leading to the conviction of Olivia Pratt-Korbel's killer.

## Mini-budget: When is it and what could be in it?
 - [https://www.bbc.co.uk/news/business-62920969?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62920969?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 13:30:26+00:00

The chancellor is expected to announce tax cuts and help for people struggling with rising costs.

## In her own words - Molly Russell's secret Twitter account
 - [https://www.bbc.co.uk/news/uk-62892636?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62892636?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 13:26:57+00:00

The schoolgirl who took her own life aged 14 had a secret Twitter account which reveals her thoughts.

## Ringed Neptune captured by James Webb telescope
 - [https://www.bbc.co.uk/news/science-environment-62984658?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62984658?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 13:22:44+00:00

The super space observatory returns spectacular imagery of the Solar System's most distant planet.

## 'Energy bills are still ridiculous at our pub'
 - [https://www.bbc.co.uk/news/business-62980637?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62980637?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 12:52:37+00:00

Some companies warn the six-month cap on gas and electricity costs will not provide long-term security.

## Putin speech clear admission of Ukraine failure, says Downing Street
 - [https://www.bbc.co.uk/news/uk-politics-62983754?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62983754?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 12:45:31+00:00

Downing Street condemns the Russian president's mobilisation of reservists and pledges continued support for Ukraine.

## England v India: Kate Cross dismisses Shafali Verma with 'beautiful delivery'
 - [https://www.bbc.co.uk/sport/av/cricket/62984165?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/62984165?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 12:36:37+00:00

Watch as England's Kate Cross bowls a "beautiful delivery" to dismiss India's Shafali Verma for eight runs in the second ODI at The Spitfire Ground in Canterbury.

## Leicester disorder: Fear lingers among city's Muslims and Hindus
 - [https://www.bbc.co.uk/news/uk-62982239?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62982239?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 12:36:20+00:00

Disorder broke out at the weekend, between people from parts of the Muslim and Hindu communities.

## Energy bills: New law will force landlords to pass on £400 rebate
 - [https://www.bbc.co.uk/news/uk-politics-62978908?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62978908?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 12:14:51+00:00

Charities had raised concerns tenants with all-inclusive bills could miss out on the support.

## Roger Federer to bow out on Friday in Laver Cup doubles
 - [https://www.bbc.co.uk/sport/tennis/62982357?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62982357?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 12:14:04+00:00

Roger Federer says he will play one final doubles match, in the Laver Cup on Friday evening, before ending his illustrious career.

## Putin warning: What does Russian military call-up mean for Ukraine?
 - [https://www.bbc.co.uk/news/world-europe-62981289?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62981289?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 12:09:39+00:00

Ukraine's advances prompt Russia to launch a partial military mobilisation, raising the stakes.

## Danish queen tests positive for Covid day after Queen Elizabeth II's funeral
 - [https://www.bbc.co.uk/news/world-europe-62982315?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62982315?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 11:49:39+00:00

Queen Margrethe II attended Queen Elizabeth's funeral and is now Europe's longest-serving head of state.

## Putin threats: How many nuclear weapons does Russia have?
 - [https://www.bbc.co.uk/news/world-europe-60564123?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60564123?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 11:05:43+00:00

A look at Russia's nuclear arsenal and basic guide to nuclear weapons and their destructive power.

## Rugby World Cup: Siwan Lillicrap to lead Wales women in New Zealand
 - [https://www.bbc.co.uk/sport/rugby-union/62979886?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/62979886?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 11:00:32+00:00

Number eight Siwan Lillicrap will captain Wales' squad for the Rugby World Cup in New Zealand.

## Oxford Street's US-themed sweet shops to face stricter rules
 - [https://www.bbc.co.uk/news/uk-england-london-62972510?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62972510?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 10:42:42+00:00

Westminster City Council expresses concern the area's shops are being used for "dirty money".

## Molly Russell inquest: Father says daughter was full of love and hope
 - [https://www.bbc.co.uk/news/uk-england-london-62981964?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62981964?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 10:37:38+00:00

The 14-year-old girl viewed material about self harm and suicide before she died in 2017.

## Germany nationalises gas giant amid energy crisis
 - [https://www.bbc.co.uk/news/world-europe-62980158?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62980158?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 10:34:27+00:00

The German government is taking a 98.5% stake in Uniper, one of the country's biggest suppliers.

## Chelsea sack commercial director Willoughby after he sent 'inappropriate messages' to football finance agent
 - [https://www.bbc.co.uk/sport/football/62980647?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62980647?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 10:21:29+00:00

Chelsea sack commercial director Damian Willoughby after he sent "inappropriate messages" to a football finance agent.

## War in Ukraine: Fact-checking Russian claims that Nato troops are fighting in Ukraine
 - [https://www.bbc.co.uk/news/62974506?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/62974506?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 09:40:43+00:00

President Putin has said Western military advisors are actively involved in Ukraine.

## Ashes 2023: England v Australia series dates, times and venues announced
 - [https://www.bbc.co.uk/sport/cricket/62978006?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62978006?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 09:23:31+00:00

England will host Australia in the men's and women's Ashes series in 2023, with next year's dates, times and venues confirmed.

## Korea Open: Emma Raducanu beats Moyuka Uchijima in first round in Seoul
 - [https://www.bbc.co.uk/sport/tennis/62978009?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62978009?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 08:55:26+00:00

Britain's Emma Raducanu completes a convincing win over Japan's Moyuka Uchijima in the first round of the Korea Open in Seoul.

## Whale stranding: 230 whales stranded on Tasmanian beach
 - [https://www.bbc.co.uk/news/world-australia-62976749?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-62976749?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 08:53:50+00:00

It is the second mass whale stranding reported in Tasmania in two days.

## Jack Grealish says criticism of England boss Gareth Southgate was 'very harsh'
 - [https://www.bbc.co.uk/sport/football/62977820?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62977820?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 07:50:02+00:00

Manchester City winger Jack Grealish says the criticism of England manager Gareth Southgate during the summer was "very harsh".

## Prince and Princess of Wales: William and Kate's Anglesey 'refuge'
 - [https://www.bbc.co.uk/news/uk-wales-62878958?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-62878958?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 07:37:00+00:00

Why a quiet corner of Wales gave William and Catherine a taste of relatively normal life for a time.

## Jeremy Vine: My jailed stalker Alex Belfield says he'll be back
 - [https://www.bbc.co.uk/news/uk-62977842?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62977842?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 07:27:01+00:00

The Radio 2 presenter says he is "disgusted" at social media giants after experience left him "broken".

## Antoine Griezmann: The story behind why the Atletico Madrid forward is only playing 30 minutes per game
 - [https://www.bbc.co.uk/sport/football/62970313?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62970313?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 07:06:35+00:00

Despite Atletico Madrid being better with Antoine Griezmann in their starting line-up, Guillem Balague questions why the France forward is appearing for the last 30 minutes of all games.

## Inflation pushes UK debt interest costs to August record
 - [https://www.bbc.co.uk/news/business-62977832?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62977832?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 06:28:22+00:00

Government borrowing reached £11.8bn in August, according to the Office for National Statistics.

## Hawthorn Football Club hit by 'harrowing' racism, bullying claims
 - [https://www.bbc.co.uk/news/world-australia-62976740?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-62976740?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 05:55:17+00:00

Aboriginal players from The Hawthorn Football Club have alleged bullying by senior coaching staff.

## Roger Federer 'stopped believing' he could continue playing amid injury problems
 - [https://www.bbc.co.uk/sport/tennis/62975292?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62975292?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 05:54:52+00:00

Roger Federer says his decision to retire came after he "stopped believing" he could continue playing because of injuries.

## Roger Federer on 'overachieving', retirement and his future
 - [https://www.bbc.co.uk/sport/av/tennis/62976151?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/tennis/62976151?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 05:43:35+00:00

Roger Federer, the 20-time Grand Slam champion, speaks to BBC Breakfast after announcing he will retire after the Laver Cup in London this month.

## Grantham's Ross Edgley attempts longest non-stop swim in Loch Ness
 - [https://www.bbc.co.uk/news/uk-england-lincolnshire-62970800?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lincolnshire-62970800?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 05:11:01+00:00

Edgley is bidding to swim 100 miles (160km) in support of a sea kelp conservation project.

## Many English maternity units not meeting safety standards
 - [https://www.bbc.co.uk/news/health-62569344?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-62569344?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 05:09:47+00:00

More than half of England's maternity units require improvements in safety, BBC analysis finds.

## Shaunagh Brown column: England prop on why World Cup selection seemed unlikely
 - [https://www.bbc.co.uk/sport/rugby-union/62958272?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/62958272?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 05:07:38+00:00

England prop Shaunagh Brown says on paper there is not much going for her, but she's made it to a World Cup.

## Joe Biden to tell Liz Truss to negotiate with EU over NI protocol
 - [https://www.bbc.co.uk/news/uk-62976595?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62976595?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 03:42:28+00:00

The US president will urge the PM to resolve tensions with the EU and protect peace in Northern Ireland.

## Ukraine war: West condemns Russian plans for 'sham' Ukraine vote
 - [https://www.bbc.co.uk/news/world-europe-62976560?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62976560?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 02:53:52+00:00

Kyiv's allies say they will never recognise the results of votes run by Moscow-backed authorities.

## Firms join forces to combat racism in chemistry
 - [https://www.bbc.co.uk/news/science-environment-62824163?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62824163?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 00:40:06+00:00

Leading firms launch a scheme to help black and minority ethnic students get jobs as chemistry researchers.

## Golden Globes returning to TV in 2023 after diversity row
 - [https://www.bbc.co.uk/news/world-us-canada-62976650?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62976650?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 00:25:12+00:00

The award show was also dropped by its US broadcaster last year over conflict-of-interest concerns.

## Royal Shakespeare Company appoints first female artistic director
 - [https://www.bbc.co.uk/news/entertainment-arts-62972411?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62972411?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-21 00:16:18+00:00

Tamara Harvey and Daniel Evans will be joint artistic directors of the Royal Shakespeare Company.


# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Bill Barr Reveals What He Thinks Will Happen Next In Letitia James’ Civil Lawsuit Against The Trump Family
 - [https://www.dailywire.com/news/bill-barr-reveals-what-he-thinks-will-happen-next-in-letitia-james-civil-lawsuit-against-the-trump-family](https://www.dailywire.com/news/bill-barr-reveals-what-he-thinks-will-happen-next-in-letitia-james-civil-lawsuit-against-the-trump-family)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 21:44:35+00:00

Former U.S. Attorney General William Barr said Wednesday that he does not believe that New York Attorney General Letitia James’ civil lawsuit against the Trump family is going to go anywhere, and what convinced him that she overreached on the case was that she decided to go after his children as well. The lawsuit targets the former president, ...

## Bill Barr Reveals What He Thinks Will Happen Next In Letitia James’ Civil Lawsuit Against The Trump Family
 - [https://www-preprod.dailywire.com/news/bill-barr-reveals-what-he-thinks-will-happen-next-in-letitia-james-civil-lawsuit-against-the-trump-family](https://www-preprod.dailywire.com/news/bill-barr-reveals-what-he-thinks-will-happen-next-in-letitia-james-civil-lawsuit-against-the-trump-family)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 21:44:35+00:00

Former U.S. Attorney General William Barr said Wednesday that he does not believe that New York Attorney General Letitia James’ civil lawsuit against the Trump family is going to go anywhere, and what convinced him that she overreached on the case was that she decided to go after his children as well. The lawsuit targets the former president, ...

## ‘It’s Unthinkable’: Matt Walsh Discusses Shocking Revelation About Vanderbilt University Medical Center With Tucker Carlson
 - [https://www.dailywire.com/news/its-unthinkable-matt-walsh-discusses-shocking-revelation-about-vanderbilt-university-medical-center-with-tucker-carlson](https://www.dailywire.com/news/its-unthinkable-matt-walsh-discusses-shocking-revelation-about-vanderbilt-university-medical-center-with-tucker-carlson)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 21:20:24+00:00

Tucker Carlson used his opening monologue Wednesday night to report on Matt Walsh’s revelation about Vanderbilt University Medical Center (VUMC), and later interviewed The Daily Wire host about his findings on the hospital’s transgender “care.” Walsh revealed in one video Tuesday that a VUMC doctor openly discussed how lucrative transgender surgeries are for the hospital. ...

## ‘It’s Unthinkable’: Matt Walsh Discusses Shocking Revelation About Vanderbilt University Medical Center With Tucker Carlson
 - [https://www-preprod.dailywire.com/news/its-unthinkable-matt-walsh-discusses-shocking-revelation-about-vanderbilt-university-medical-center-with-tucker-carlson](https://www-preprod.dailywire.com/news/its-unthinkable-matt-walsh-discusses-shocking-revelation-about-vanderbilt-university-medical-center-with-tucker-carlson)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 21:20:24+00:00

Tucker Carlson used his opening monologue Wednesday night to report on Matt Walsh’s revelation about Vanderbilt University Medical Center (VUMC), and later interviewed The Daily Wire host about his findings on the hospital’s transgender “care.” Walsh revealed in one video Tuesday that a VUMC doctor openly discussed how lucrative transgender surgeries are for the hospital. ...

## Rashida Tlaib Faces Backlash From Top Democrats Over ‘Outrageous’ Anti-Semitic Test, Critics Skeptical Of Democrats’ Outrage
 - [https://www.dailywire.com/news/rashida-tlaib-faces-backlash-from-top-democrats-over-outrageous-anti-semitic-test-critics-skeptical-of-democrats-outrage](https://www.dailywire.com/news/rashida-tlaib-faces-backlash-from-top-democrats-over-outrageous-anti-semitic-test-critics-skeptical-of-democrats-outrage)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 19:44:47+00:00

Far-left Rep. Rashida Tlaib (D-MI) faced backlash Wednesday for comments she made this week when she said that Democrats could not be considered &#8220;progressive&#8221; if they supported Israel&#8217;s government. Tlaib has an extensive history of anti-Semitism and has spoken at events where far-left activists have called for the elimination of Israel. Speaking at an online ...

## Rashida Tlaib Faces Backlash From Top Democrats Over ‘Outrageous’ Anti-Semitic Test, Critics Skeptical Of Democrats’ Outrage
 - [https://www-preprod.dailywire.com/news/rashida-tlaib-faces-backlash-from-top-democrats-over-outrageous-anti-semitic-test-critics-skeptical-of-democrats-outrage](https://www-preprod.dailywire.com/news/rashida-tlaib-faces-backlash-from-top-democrats-over-outrageous-anti-semitic-test-critics-skeptical-of-democrats-outrage)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 19:44:47+00:00

Far-left Rep. Rashida Tlaib (D-MI) faced backlash Wednesday for comments she made this week when she said that Democrats could not be considered &#8220;progressive&#8221; if they supported Israel&#8217;s government. Tlaib has an extensive history of anti-Semitism and has spoken at events where far-left activists have called for the elimination of Israel. Speaking at an online ...

## America’s Top Bank Executive Nukes Rashida Tlaib When She Pushes Climate Alarmism: ‘Absolutely Not’
 - [https://www.dailywire.com/news/americas-top-bank-executive-nukes-rashida-tlaib-when-she-pushes-climate-alarmism-absolutely-not](https://www.dailywire.com/news/americas-top-bank-executive-nukes-rashida-tlaib-when-she-pushes-climate-alarmism-absolutely-not)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 19:19:45+00:00

Far-left Rep. Rashida Tlaib (D-MI) lectured top bank executives during a House Financial Services Committee hearing on regulatory and oversight matters in the banking industry Wednesday afternoon, but she did not expect the response that she received from the most powerful executive in attendance. CEOs from America&#8217;s six largest banks were asked to address serious issues ...

## America’s Top Bank Executive Nukes Rashida Tlaib When She Pushes Climate Alarmism: ‘Absolutely Not’
 - [https://www-preprod.dailywire.com/news/americas-top-bank-executive-nukes-rashida-tlaib-when-she-pushes-climate-alarmism-absolutely-not](https://www-preprod.dailywire.com/news/americas-top-bank-executive-nukes-rashida-tlaib-when-she-pushes-climate-alarmism-absolutely-not)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 19:19:45+00:00

Far-left Rep. Rashida Tlaib (D-MI) lectured top bank executives during a House Financial Services Committee hearing on regulatory and oversight matters in the banking industry Wednesday afternoon, but she did not expect the response that she received from the most powerful executive in attendance. CEOs from America&#8217;s six largest banks were asked to address serious issues ...

## Child Sex Abuse Lawsuit Dropped Against Tiffany Haddish And Aries Spears, Plaintiff Releases Statement
 - [https://www.dailywire.com/news/child-sex-abuse-lawsuit-dropped-against-tiffany-haddish-and-aries-spears-plaintiff-releases-statement](https://www.dailywire.com/news/child-sex-abuse-lawsuit-dropped-against-tiffany-haddish-and-aries-spears-plaintiff-releases-statement)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 18:41:41+00:00

A child sex abuse lawsuit has been dropped against comedians Tiffany Haddish and Aries Spears. The former plaintiff, a young woman known only as Jane Doe, filed a notice of dismissal with prejudice on Tuesday. “My family and I have known Tiffany Haddish for many years – and we now know that she would never ...

## Child Sex Abuse Lawsuit Dropped Against Tiffany Haddish And Aries Spears, Plaintiff Releases Statement
 - [https://www-preprod.dailywire.com/news/child-sex-abuse-lawsuit-dropped-against-tiffany-haddish-and-aries-spears-plaintiff-releases-statement](https://www-preprod.dailywire.com/news/child-sex-abuse-lawsuit-dropped-against-tiffany-haddish-and-aries-spears-plaintiff-releases-statement)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 18:41:41+00:00

A child sex abuse lawsuit has been dropped against comedians Tiffany Haddish and Aries Spears. The former plaintiff, a young woman known only as Jane Doe, filed a notice of dismissal with prejudice on Tuesday. “My family and I have known Tiffany Haddish for many years – and we now know that she would never ...

## California Needed Natural Gas During Heat Wave
 - [https://www.dailywire.com/news/california-needed-natural-gas-during-heat-wave](https://www.dailywire.com/news/california-needed-natural-gas-during-heat-wave)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 18:09:45+00:00

During California’s recent heat wave, the state intensely relied on natural gas to keep the lights on despite the state’s quick promotion of renewable energy sources. According to the U.S. Energy Information Administration (EIA), the state’s electric grid counted on natural gas for nearly half of its electricity production to reach peak demand levels. During ...

## California Needed Natural Gas During Heat Wave
 - [https://www-preprod.dailywire.com/news/california-needed-natural-gas-during-heat-wave](https://www-preprod.dailywire.com/news/california-needed-natural-gas-during-heat-wave)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 18:09:45+00:00

During California’s recent heat wave, the state intensely relied on natural gas to keep the lights on despite the state’s quick promotion of renewable energy sources. According to the U.S. Energy Information Administration (EIA), the state’s electric grid counted on natural gas for nearly half of its electricity production to reach peak demand levels. During ...

## Andrew Cuomo Trashes ‘Political Friends’ Pelosi And Biden Who ‘Fell Like Dominoes’ When Things Got Tough
 - [https://www.dailywire.com/news/andrew-cuomo-trashes-political-friends-pelosi-and-biden-who-fell-like-dominoes-when-things-got-tough](https://www.dailywire.com/news/andrew-cuomo-trashes-political-friends-pelosi-and-biden-who-fell-like-dominoes-when-things-got-tough)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 18:07:27+00:00

Former New York Governor Andrew Cuomo (D) lashed out at some he had considered his &#8220;political friends&#8221; before scandal brought an early end to his time in office. Cuomo sat for an interview with the New York Post, and he said that even those he expected to have his back seemed to wash their hands ...

## Andrew Cuomo Trashes ‘Political Friends’ Pelosi And Biden Who ‘Fell Like Dominoes’ When Things Got Tough
 - [https://www-preprod.dailywire.com/news/andrew-cuomo-trashes-political-friends-pelosi-and-biden-who-fell-like-dominoes-when-things-got-tough](https://www-preprod.dailywire.com/news/andrew-cuomo-trashes-political-friends-pelosi-and-biden-who-fell-like-dominoes-when-things-got-tough)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 18:07:27+00:00

Former New York Governor Andrew Cuomo (D) lashed out at some he had considered his &#8220;political friends&#8221; before scandal brought an early end to his time in office. Cuomo sat for an interview with the New York Post, and he said that even those he expected to have his back seemed to wash their hands ...

## Two Americans Captured Fighting For Ukraine Dodge Russian Firing Squad
 - [https://www.dailywire.com/news/two-americans-captured-fighting-for-ukraine-dodge-russian-firing-squad](https://www.dailywire.com/news/two-americans-captured-fighting-for-ukraine-dodge-russian-firing-squad)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 18:06:00+00:00

Two U.S. veterans from Alabama branded “soldiers of fortune” by Moscow after being captured fighting for Ukraine have been spared their date with a firing squad after a Saudi-brokered prisoner swap. Alexander Drueke, 39, and Andy Huynh, 27, who were captured in June while defending Kharkiv, were at the U.S. Embassy in Saudi Arabia after ...

## Two Americans Captured Fighting For Ukraine Dodge Russian Firing Squad
 - [https://www-preprod.dailywire.com/news/two-americans-captured-fighting-for-ukraine-dodge-russian-firing-squad](https://www-preprod.dailywire.com/news/two-americans-captured-fighting-for-ukraine-dodge-russian-firing-squad)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 18:06:00+00:00

Two U.S. veterans from Alabama branded “soldiers of fortune” by Moscow after being captured fighting for Ukraine have been spared their date with a firing squad after a Saudi-brokered prisoner swap. Alexander Drueke, 39, and Andy Huynh, 27, who were captured in June while defending Kharkiv, were at the U.S. Embassy in Saudi Arabia after ...

## Chris Pratt Has Message For ‘Rabid Fans’ Of ‘The Terminal List’ About Whether Another Season Is Happening
 - [https://www.dailywire.com/news/chris-pratt-has-message-for-rabid-fans-of-the-terminal-list-about-whether-another-season-is-happening](https://www.dailywire.com/news/chris-pratt-has-message-for-rabid-fans-of-the-terminal-list-about-whether-another-season-is-happening)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 18:03:32+00:00

Chris Pratt definitely got everyone&#8217;s attention Wednesday when it seemed he did a whole lot more than just hint at a second season for the monster hit &#8220;The Terminal List.&#8221; During the 43-year-old actor&#8217;s appearance on the &#8220;Danger Close&#8221; podcast hosted by Former Navy SEAL and &#8220;The Terminal List&#8221; author Jack Carr, the two talked ...

## Chris Pratt Has Message For ‘Rabid Fans’ Of ‘The Terminal List’ About Whether Another Season Is Happening
 - [https://www-preprod.dailywire.com/news/chris-pratt-has-message-for-rabid-fans-of-the-terminal-list-about-whether-another-season-is-happening](https://www-preprod.dailywire.com/news/chris-pratt-has-message-for-rabid-fans-of-the-terminal-list-about-whether-another-season-is-happening)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 18:03:32+00:00

Chris Pratt definitely got everyone&#8217;s attention Wednesday when it seemed he did a whole lot more than just hint at a second season for the monster hit &#8220;The Terminal List.&#8221; During the 43-year-old actor&#8217;s appearance on the &#8220;Danger Close&#8221; podcast hosted by Former Navy SEAL and &#8220;The Terminal List&#8221; author Jack Carr, the two talked ...

## MIDTERM EXAM: All The Latest On The 2022 Elections
 - [https://www.dailywire.com/news/midterm-exam-all-the-latest-on-the-2022-elections](https://www.dailywire.com/news/midterm-exam-all-the-latest-on-the-2022-elections)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 17:48:13+00:00

Happy Wednesday. Congrats, you made it to the middle of the week and another Midterm Exam. In this week&#8217;s first exam, we&#8217;ll go over some tidbits out of Michigan, Colorado, Oregon, and Wisconsin. On Thursday, we will go over smaller stories out of Ohio, Pennsylvania, Georgia, Arizona, and Nevada. If there is a major story ...

## MIDTERM EXAM: All The Latest On The 2022 Elections
 - [https://www-preprod.dailywire.com/news/midterm-exam-all-the-latest-on-the-2022-elections](https://www-preprod.dailywire.com/news/midterm-exam-all-the-latest-on-the-2022-elections)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 17:48:13+00:00

Happy Wednesday. Congrats, you made it to the middle of the week and another Midterm Exam. In this week&#8217;s first exam, we&#8217;ll go over some tidbits out of Michigan, Colorado, Oregon, and Wisconsin. On Thursday, we will go over smaller stories out of Ohio, Pennsylvania, Georgia, Arizona, and Nevada. If there is a major story ...

## Conservatives List Eight Policies To Restart The Economy Under A Republican Congress
 - [https://www.dailywire.com/news/conservatives-list-eight-policies-to-restart-the-economy-under-a-republican-congress](https://www.dailywire.com/news/conservatives-list-eight-policies-to-restart-the-economy-under-a-republican-congress)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 17:39:07+00:00

Current and former conservative officials outlined an eight-pronged plan on Wednesday to encourage economic development under a Republican Congress. The United States witnessed two consecutive quarters of negative output growth, while recent data from the Federal Reserve indicate that the economy will likely remain stagnant in the third quarter. The American Small Business Prosperity Plan, ...

## Conservatives List Eight Policies To Restart The Economy Under A Republican Congress
 - [https://www-preprod.dailywire.com/news/conservatives-list-eight-policies-to-restart-the-economy-under-a-republican-congress](https://www-preprod.dailywire.com/news/conservatives-list-eight-policies-to-restart-the-economy-under-a-republican-congress)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 17:39:07+00:00

Current and former conservative officials outlined an eight-pronged plan on Wednesday to encourage economic development under a Republican Congress. The United States witnessed two consecutive quarters of negative output growth, while recent data from the Federal Reserve indicate that the economy will likely remain stagnant in the third quarter. The American Small Business Prosperity Plan, ...

## Man Who Admitted To Murdering Republican Teenager Over Politics Is Freed From Prison, Report Says
 - [https://www.dailywire.com/news/man-who-admitted-to-murdering-republican-teenager-over-politics-is-freed-from-prison-report-says](https://www.dailywire.com/news/man-who-admitted-to-murdering-republican-teenager-over-politics-is-freed-from-prison-report-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 17:29:30+00:00

The 41-year-old man who allegedly admitted to murdering a Republican teenager over politics has been released from jail after posting $50,000 bond. Shannon Brandt only spent a few days in a Stutsman County Jail after being charged with vehicular homicide and leaving the scene of a crash involving a death after he allegedly hit and ...

## Man Who Admitted To Murdering Republican Teenager Over Politics Is Freed From Prison, Report Says
 - [https://www-preprod.dailywire.com/news/man-who-admitted-to-murdering-republican-teenager-over-politics-is-freed-from-prison-report-says](https://www-preprod.dailywire.com/news/man-who-admitted-to-murdering-republican-teenager-over-politics-is-freed-from-prison-report-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 17:29:30+00:00

The 41-year-old man who allegedly admitted to murdering a Republican teenager over politics has been released from jail after posting $50,000 bond. Shannon Brandt only spent a few days in a Stutsman County Jail after being charged with vehicular homicide and leaving the scene of a crash involving a death after he allegedly hit and ...

## For Irish Catholic Americans, The Queen’s Passing Is Complicated
 - [https://www.dailywire.com/news/for-irish-catholic-americans-the-queens-passing-is-complicated](https://www.dailywire.com/news/for-irish-catholic-americans-the-queens-passing-is-complicated)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 17:05:23+00:00

It didn’t take long for the culture vultures to begin feasting on the recently deceased Queen Elizabeth II. Articles in newspapers, tweets from professors and chatter from TV talking heads all emerged decrying the Queen and her nation’s history of colonization. But one group remained conspicuously, and unusually, quiet about the death of a British ...

## For Irish Catholic Americans, The Queen’s Passing Is Complicated
 - [https://www-preprod.dailywire.com/news/for-irish-catholic-americans-the-queens-passing-is-complicated](https://www-preprod.dailywire.com/news/for-irish-catholic-americans-the-queens-passing-is-complicated)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 17:05:23+00:00

It didn’t take long for the culture vultures to begin feasting on the recently deceased Queen Elizabeth II. Articles in newspapers, tweets from professors and chatter from TV talking heads all emerged decrying the Queen and her nation’s history of colonization. But one group remained conspicuously, and unusually, quiet about the death of a British ...

## Ex-Democrat Mayor Of 3rd Largest Blue County In Florida Endorses DeSantis: ‘I Will Not Remain Silent’
 - [https://www.dailywire.com/news/ex-democrat-mayor-of-3rd-largest-blue-county-in-florida-endorses-desantis-i-will-not-remain-silent](https://www.dailywire.com/news/ex-democrat-mayor-of-3rd-largest-blue-county-in-florida-endorses-desantis-i-will-not-remain-silent)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:54:39+00:00

Palm Beach County Commissioner David Kerner (D) announced this week that he will campaign every day between now and November 8 to re-elect Florida Governor Ron DeSantis (R). Kerner previously served as the mayor of Palm Beach County, the third largest county in the state. It is also a deep blue county. &#8220;Every day until ...

## Ex-Democrat Mayor Of 3rd Largest Blue County In Florida Endorses DeSantis: ‘I Will Not Remain Silent’
 - [https://www-preprod.dailywire.com/news/ex-democrat-mayor-of-3rd-largest-blue-county-in-florida-endorses-desantis-i-will-not-remain-silent](https://www-preprod.dailywire.com/news/ex-democrat-mayor-of-3rd-largest-blue-county-in-florida-endorses-desantis-i-will-not-remain-silent)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:54:39+00:00

Palm Beach County Commissioner David Kerner (D) announced this week that he will campaign every day between now and November 8 to re-elect Florida Governor Ron DeSantis (R). Kerner previously served as the mayor of Palm Beach County, the third largest county in the state. It is also a deep blue county. &#8220;Every day until ...

## ‘Your Kids Have A F***ing Terrible Mom’: Broadcaster Fired For Unleashing Sexist Tirade On Co-Host In Leaked Audio
 - [https://www.dailywire.com/news/your-kids-have-a-fing-terrible-mom-broadcaster-fired-for-unleashing-sexist-tirade-on-co-host-in-leaked-audio](https://www.dailywire.com/news/your-kids-have-a-fing-terrible-mom-broadcaster-fired-for-unleashing-sexist-tirade-on-co-host-in-leaked-audio)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:42:52+00:00

Broadcaster Vic Faust was fired from his job as a television news anchor after he unleashed a vicious, expletive-laden tirade on a female coworker, according to leaked audio that was published by the St. Louis Post Dispatch on Monday. &#8220;Vic Faust no longer works for Fox 2, KPLR (Channel 11) or Nexstar Media,&#8221; station general manager ...

## ‘Your Kids Have A F***ing Terrible Mom’: Broadcaster Fired For Unleashing Sexist Tirade On Co-Host In Leaked Audio
 - [https://www-preprod.dailywire.com/news/your-kids-have-a-fing-terrible-mom-broadcaster-fired-for-unleashing-sexist-tirade-on-co-host-in-leaked-audio](https://www-preprod.dailywire.com/news/your-kids-have-a-fing-terrible-mom-broadcaster-fired-for-unleashing-sexist-tirade-on-co-host-in-leaked-audio)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:42:52+00:00

Broadcaster Vic Faust was fired from his job as a television news anchor after he unleashed a vicious, expletive-laden tirade on a female coworker, according to leaked audio that was published by the St. Louis Post Dispatch on Monday. &#8220;Vic Faust no longer works for Fox 2, KPLR (Channel 11) or Nexstar Media,&#8221; station general manager ...

## ‘Climate Risk Is Investment Risk’: Bill Clinton And BlackRock CEO Larry Fink Make Bold Claims About Woke Investing
 - [https://www.dailywire.com/news/climate-risk-is-investment-risk-bill-clinton-and-blackrock-ceo-larry-fink-make-bold-claims-about-woke-investing](https://www.dailywire.com/news/climate-risk-is-investment-risk-bill-clinton-and-blackrock-ceo-larry-fink-make-bold-claims-about-woke-investing)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:41:51+00:00

Former President Bill Clinton and BlackRock CEO Larry Fink discussed the Environmental, Social, and Governance (ESG) movement during a meeting of the Clinton Global Initiative. A panel event featuring Clinton and Fink, as well as Unilever CEO Alan Jope and United Nations energy co-chair Damilola Ogunbiyi, highlighted the role of corporations in advancing a pivot ...

## ‘Climate Risk Is Investment Risk’: Bill Clinton And BlackRock CEO Larry Fink Make Bold Claims About Woke Investing
 - [https://www-preprod.dailywire.com/news/climate-risk-is-investment-risk-bill-clinton-and-blackrock-ceo-larry-fink-make-bold-claims-about-woke-investing](https://www-preprod.dailywire.com/news/climate-risk-is-investment-risk-bill-clinton-and-blackrock-ceo-larry-fink-make-bold-claims-about-woke-investing)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:41:51+00:00

Former President Bill Clinton and BlackRock CEO Larry Fink discussed the Environmental, Social, and Governance (ESG) movement during a meeting of the Clinton Global Initiative. A panel event featuring Clinton and Fink, as well as Unilever CEO Alan Jope and United Nations energy co-chair Damilola Ogunbiyi, highlighted the role of corporations in advancing a pivot ...

## A Man Killed A Teenager For Being A ‘Republican Extremist,’ Police Say. Is The President Still Responsible For Political Violence?
 - [https://www.dailywire.com/news/a-man-killed-a-teenager-for-being-a-republican-extremist-police-say-is-the-president-still-responsible-for-political-violence](https://www.dailywire.com/news/a-man-killed-a-teenager-for-being-a-republican-extremist-police-say-is-the-president-still-responsible-for-political-violence)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:32:43+00:00

Per the rules of the Left and legacy media, the president is responsible for any violence committed by supporters of his ideology. At least that was the rule imposed by the Left during the Trump administration. Under President Joe Biden, his allies in the press and politics have no desire in enforcing that idea. Perhaps ...

## A Man Killed A Teenager For Being A ‘Republican Extremist,’ Police Say. Is The President Still Responsible For Political Violence?
 - [https://www-preprod.dailywire.com/news/a-man-killed-a-teenager-for-being-a-republican-extremist-police-say-is-the-president-still-responsible-for-political-violence](https://www-preprod.dailywire.com/news/a-man-killed-a-teenager-for-being-a-republican-extremist-police-say-is-the-president-still-responsible-for-political-violence)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:32:43+00:00

Per the rules of the Left and legacy media, the president is responsible for any violence committed by supporters of his ideology. At least that was the rule imposed by the Left during the Trump administration. Under President Joe Biden, his allies in the press and politics have no desire in enforcing that idea. Perhaps ...

## Matt Gaetz Calls For Bombing Mexico: ‘Not Kidding’
 - [https://www.dailywire.com/news/matt-gaetz-calls-for-bombing-mexico-not-kidding](https://www.dailywire.com/news/matt-gaetz-calls-for-bombing-mexico-not-kidding)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:18:32+00:00

Rep. Matt Gaetz (R-FL) called for bombing Mexico Wednesday afternoon over the fentanyl crisis that is killing tens of thousands of Americans every year. Gaetz made the call for bombing Sinaloa, Mexico, home of the notorious Sinaloa drug cartel, on Twitter in response to remarks that he made during a House Judiciary Committee hearing on ...

## Matt Gaetz Calls For Bombing Mexico: ‘Not Kidding’
 - [https://www-preprod.dailywire.com/news/matt-gaetz-calls-for-bombing-mexico-not-kidding](https://www-preprod.dailywire.com/news/matt-gaetz-calls-for-bombing-mexico-not-kidding)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:18:32+00:00

Rep. Matt Gaetz (R-FL) called for bombing Mexico Wednesday afternoon over the fentanyl crisis that is killing tens of thousands of Americans every year. Gaetz made the call for bombing Sinaloa, Mexico, home of the notorious Sinaloa drug cartel, on Twitter in response to remarks that he made during a House Judiciary Committee hearing on ...

## School District Lets Teachers Wear ‘Safe Space’ Badge Leading To Sexually Explicit Content
 - [https://www.dailywire.com/news/school-district-lets-teachers-wear-safe-space-badge-leading-to-sexually-explicit-content](https://www.dailywire.com/news/school-district-lets-teachers-wear-safe-space-badge-leading-to-sexually-explicit-content)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:14:13+00:00

Some Ohio parents have expressed their anger that their local school district permits teachers to wear a “safe space” badge with a QR code that when scanned, leads to websites containing sexually explicit content. “Teachers K through 12 can wear the badge that says, ‘I’m here. Safe person, safe space.’ The district says the message ...

## School District Lets Teachers Wear ‘Safe Space’ Badge Leading To Sexually Explicit Content
 - [https://www-preprod.dailywire.com/news/school-district-lets-teachers-wear-safe-space-badge-leading-to-sexually-explicit-content](https://www-preprod.dailywire.com/news/school-district-lets-teachers-wear-safe-space-badge-leading-to-sexually-explicit-content)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:14:13+00:00

Some Ohio parents have expressed their anger that their local school district permits teachers to wear a “safe space” badge with a QR code that when scanned, leads to websites containing sexually explicit content. “Teachers K through 12 can wear the badge that says, ‘I’m here. Safe person, safe space.’ The district says the message ...

## Golf Superstar And Newlywed Gets Asked Awkward Question About Wife Paulina Gretzky
 - [https://www.dailywire.com/news/golf-superstar-and-newlywed-gets-asked-awkward-question-about-wife-paulina-gretzky](https://www.dailywire.com/news/golf-superstar-and-newlywed-gets-asked-awkward-question-about-wife-paulina-gretzky)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:11:52+00:00

Golf superstar and newlywed Dustin Johnson opted out of answering an awkward question about his wife Paulina Gretzky during a recent LIV press conference. The former PGA star took one question during the event from golf social media company &#8220;Drunk by the Turn,&#8221; and it was a deserted island question that involved his wife, Sports ...

## Golf Superstar And Newlywed Gets Asked Awkward Question About Wife Paulina Gretzky
 - [https://www-preprod.dailywire.com/news/golf-superstar-and-newlywed-gets-asked-awkward-question-about-wife-paulina-gretzky](https://www-preprod.dailywire.com/news/golf-superstar-and-newlywed-gets-asked-awkward-question-about-wife-paulina-gretzky)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:11:52+00:00

Golf superstar and newlywed Dustin Johnson opted out of answering an awkward question about his wife Paulina Gretzky during a recent LIV press conference. The former PGA star took one question during the event from golf social media company &#8220;Drunk by the Turn,&#8221; and it was a deserted island question that involved his wife, Sports ...

## Bill Barr Blasts Letitia James’ Civil Lawsuit Against The Trump Family: ‘It’s A Political Hit Job’
 - [https://www.dailywire.com/news/bill-barr-blasts-letitia-james-civil-lawsuit-against-the-trump-family-its-a-political-hit-job](https://www.dailywire.com/news/bill-barr-blasts-letitia-james-civil-lawsuit-against-the-trump-family-its-a-political-hit-job)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:06:00+00:00

Former U.S. Attorney General William Barr slammed New York Attorney General Letitia James’ civil lawsuit against the Trump family on Wednesday, saying that it was hard for him &#8220;not to conclude it&#8217;s a political hit job.&#8221; The lawsuit targets the former president, his business, and many associates. In addition to the former president, the lawsuit targets ...

## Bill Barr Blasts Letitia James’ Civil Lawsuit Against The Trump Family: ‘It’s A Political Hit Job’
 - [https://www-preprod.dailywire.com/news/bill-barr-blasts-letitia-james-civil-lawsuit-against-the-trump-family-its-a-political-hit-job](https://www-preprod.dailywire.com/news/bill-barr-blasts-letitia-james-civil-lawsuit-against-the-trump-family-its-a-political-hit-job)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 16:06:00+00:00

Former U.S. Attorney General William Barr slammed New York Attorney General Letitia James’ civil lawsuit against the Trump family on Wednesday, saying that it was hard for him &#8220;not to conclude it&#8217;s a political hit job.&#8221; The lawsuit targets the former president, his business, and many associates. In addition to the former president, the lawsuit targets ...

## It’s Not Just Leonardo DiCaprio: Here Are Seven Other Celebrity Couples With Big Age Gaps
 - [https://www.dailywire.com/news/its-not-just-leonardo-dicaprio-here-are-seven-other-celebrity-couples-with-big-age-gaps](https://www.dailywire.com/news/its-not-just-leonardo-dicaprio-here-are-seven-other-celebrity-couples-with-big-age-gaps)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:52:58+00:00

Leonardo DiCaprio shocked the world by hanging out with Gigi Hadid, 27, although he has been mocked mercilessly for never dating a woman over the age of 25. The 47-year-old actor probably had something to prove to all his detractors. For him, even a gap of two decades is an improvement over a dating history ...

## It’s Not Just Leonardo DiCaprio: Here Are Seven Other Celebrity Couples With Big Age Gaps
 - [https://www-preprod.dailywire.com/news/its-not-just-leonardo-dicaprio-here-are-seven-other-celebrity-couples-with-big-age-gaps](https://www-preprod.dailywire.com/news/its-not-just-leonardo-dicaprio-here-are-seven-other-celebrity-couples-with-big-age-gaps)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:52:58+00:00

Leonardo DiCaprio shocked the world by hanging out with Gigi Hadid, 27, although he has been mocked mercilessly for never dating a woman over the age of 25. The 47-year-old actor probably had something to prove to all his detractors. For him, even a gap of two decades is an improvement over a dating history ...

## We’re Going To Be Investigating Pandemic Fraud For The Next Century
 - [https://www.dailywire.com/news/were-going-to-be-investigating-pandemic-fraud-for-the-next-century](https://www.dailywire.com/news/were-going-to-be-investigating-pandemic-fraud-for-the-next-century)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:34:08+00:00

Have you ever looked at the scandals involved in President Ulysses S. Grant&#8217;s administration and wondered how such corruption occurred? Well, it&#8217;s time to check your arrogance at the door because future generations are going to view the past two and a half years with the same disbelief. The United States just experienced billions of dollars ...

## We’re Going To Be Investigating Pandemic Fraud For The Next Century
 - [https://www-preprod.dailywire.com/news/were-going-to-be-investigating-pandemic-fraud-for-the-next-century](https://www-preprod.dailywire.com/news/were-going-to-be-investigating-pandemic-fraud-for-the-next-century)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:34:08+00:00

Have you ever looked at the scandals involved in President Ulysses S. Grant&#8217;s administration and wondered how such corruption occurred? Well, it&#8217;s time to check your arrogance at the door because future generations are going to view the past two and a half years with the same disbelief. The United States just experienced billions of dollars ...

## ‘I Did It For Her’: Actress Ana De Armas Says She Did Things In ‘Blonde’ She ‘Would Have Never Done For Anyone Else’
 - [https://www.dailywire.com/news/i-did-it-for-her-actress-ana-de-armas-says-she-did-things-in-blonde-she-would-have-never-done-for-anyone-else](https://www.dailywire.com/news/i-did-it-for-her-actress-ana-de-armas-says-she-did-things-in-blonde-she-would-have-never-done-for-anyone-else)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:27:23+00:00

Superstar Ana de Armas said she did things she &#8220;would have never done for anyone else&#8221; in her portrayal of the late Marilyn Monroe in her upcoming film &#8220;Blonde.&#8221; During the 34-year-old actress&#8217; interview with Variety magazine, the &#8220;Knives Out&#8221; star talked about her portrayal of the screen legend&#8217;s short life, including depictions of sexual violence ...

## ‘I Did It For Her’: Actress Ana De Armas Says She Did Things In ‘Blonde’ She ‘Would Have Never Done For Anyone Else’
 - [https://www-preprod.dailywire.com/news/i-did-it-for-her-actress-ana-de-armas-says-she-did-things-in-blonde-she-would-have-never-done-for-anyone-else](https://www-preprod.dailywire.com/news/i-did-it-for-her-actress-ana-de-armas-says-she-did-things-in-blonde-she-would-have-never-done-for-anyone-else)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:27:23+00:00

Superstar Ana de Armas said she did things she &#8220;would have never done for anyone else&#8221; in her portrayal of the late Marilyn Monroe in her upcoming film &#8220;Blonde.&#8221; During the 34-year-old actress&#8217; interview with Variety magazine, the &#8220;Knives Out&#8221; star talked about her portrayal of the screen legend&#8217;s short life, including depictions of sexual violence ...

## U.S. Marine Vet Disarmed Pistol-Wielding Attacker. Now He’s Facing Jail Time
 - [https://www.dailywire.com/news/u-s-marine-vet-disarmed-pistol-wielding-attacker-now-hes-facing-jail-time](https://www.dailywire.com/news/u-s-marine-vet-disarmed-pistol-wielding-attacker-now-hes-facing-jail-time)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:26:09+00:00

A U.S. Marine veteran is reportedly facing up to a year of jail time after thwarting an armed male attacker during an incident on July 4, in Baltimore, Maryland. Though Lloyd Muldrow was thanked by police for his efforts in stopping the attacker, the 57-year-old has been charged with violating a city ordinance that bans handguns ...

## U.S. Marine Vet Disarmed Pistol-Wielding Attacker. Now He’s Facing Jail Time
 - [https://www-preprod.dailywire.com/news/u-s-marine-vet-disarmed-pistol-wielding-attacker-now-hes-facing-jail-time](https://www-preprod.dailywire.com/news/u-s-marine-vet-disarmed-pistol-wielding-attacker-now-hes-facing-jail-time)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:26:09+00:00

A U.S. Marine veteran is reportedly facing up to a year of jail time after thwarting an armed male attacker during an incident on July 4, in Baltimore, Maryland. Though Lloyd Muldrow was thanked by police for his efforts in stopping the attacker, the 57-year-old has been charged with violating a city ordinance that bans handguns ...

## Poll: DeSantis Reverses Lead Trump Held In Florida, Now Leads By 8
 - [https://www.dailywire.com/news/poll-desantis-reverses-lead-trump-held-in-florida-now-leads-by-8](https://www.dailywire.com/news/poll-desantis-reverses-lead-trump-held-in-florida-now-leads-by-8)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:24:34+00:00

A new poll finds that since January, Republicans in Florida have significantly changed their presidential preference, with Florida Governor Ron DeSantis now holding virtually the same lead over former President Donald Trump that Trump held over him then. In January, Trump led DeSantis in the USA Today/Suffolk University poll of 2024 presidential prospective candidates 47%-40%, ...

## Poll: DeSantis Reverses Lead Trump Held In Florida, Now Leads By 8
 - [https://www-preprod.dailywire.com/news/poll-desantis-reverses-lead-trump-held-in-florida-now-leads-by-8](https://www-preprod.dailywire.com/news/poll-desantis-reverses-lead-trump-held-in-florida-now-leads-by-8)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:24:34+00:00

A new poll finds that since January, Republicans in Florida have significantly changed their presidential preference, with Florida Governor Ron DeSantis now holding virtually the same lead over former President Donald Trump that Trump held over him then. In January, Trump led DeSantis in the USA Today/Suffolk University poll of 2024 presidential prospective candidates 47%-40%, ...

## Democratic Congresswoman Wants To Move 128 Military Bases Closer To Abortion Clinics
 - [https://www.dailywire.com/news/democratic-congresswoman-wants-to-move-128-military-bases-closer-to-abortion-clinics](https://www.dailywire.com/news/democratic-congresswoman-wants-to-move-128-military-bases-closer-to-abortion-clinics)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:20:09+00:00

Congresswoman Jackie Speier (D-CA) suggested moving 128 military bases solely because they were located in red states that banned abortion. Speier took to the House floor on Tuesday with a color-coded map showing which states had already moved to further restrict abortion or ban it entirely following the recent Supreme Court decision in Dobbs v. Jackson ...

## Democratic Congresswoman Wants To Move 128 Military Bases Closer To Abortion Clinics
 - [https://www-preprod.dailywire.com/news/democratic-congresswoman-wants-to-move-128-military-bases-closer-to-abortion-clinics](https://www-preprod.dailywire.com/news/democratic-congresswoman-wants-to-move-128-military-bases-closer-to-abortion-clinics)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:20:09+00:00

Congresswoman Jackie Speier (D-CA) suggested moving 128 military bases solely because they were located in red states that banned abortion. Speier took to the House floor on Tuesday with a color-coded map showing which states had already moved to further restrict abortion or ban it entirely following the recent Supreme Court decision in Dobbs v. Jackson ...

## Official In Switzerland Suggests That Residents ‘Shower Together’ To Conserve Energy
 - [https://www.dailywire.com/news/official-in-switzerland-suggests-that-residents-shower-together-to-conserve-energy](https://www.dailywire.com/news/official-in-switzerland-suggests-that-residents-shower-together-to-conserve-energy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:05:20+00:00

Swiss energy and transportation minister Simonetta Sommaruga advised that residents “shower together” in the interest of reducing power consumption. Russia severed natural gas flow through the Nord Stream 1 pipeline earlier this month in apparent retaliation against Western Europe for supporting Ukraine. As Sommaruga pushes fellow citizens to reduce energy consumption by 15% to conserve ...

## Official In Switzerland Suggests That Residents ‘Shower Together’ To Conserve Energy
 - [https://www-preprod.dailywire.com/news/official-in-switzerland-suggests-that-residents-shower-together-to-conserve-energy](https://www-preprod.dailywire.com/news/official-in-switzerland-suggests-that-residents-shower-together-to-conserve-energy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:05:20+00:00

Swiss energy and transportation minister Simonetta Sommaruga advised that residents “shower together” in the interest of reducing power consumption. Russia severed natural gas flow through the Nord Stream 1 pipeline earlier this month in apparent retaliation against Western Europe for supporting Ukraine. As Sommaruga pushes fellow citizens to reduce energy consumption by 15% to conserve ...

## ‘Shell-Shocked’: ‘Venom’ Star Secretly Enters Martial Arts Fighting Competition, Wins The Whole Thing
 - [https://www.dailywire.com/news/shell-shocked-venom-star-secretly-enters-martial-arts-fighting-competition-wins-the-whole-thing](https://www.dailywire.com/news/shell-shocked-venom-star-secretly-enters-martial-arts-fighting-competition-wins-the-whole-thing)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:04:32+00:00

Tom Hardy literally shocked opponents at a martial arts fighting competition in England when he secretly entered the Brazilian jiu-jitsu event and walked away winning the whole thing. The 45-year-old actor didn&#8217;t enter the 2022 Brazilian Jiu-Jitsu Open Championship over the weekend using his stage name, but his real name, &#8220;Edward,&#8221; the Guardian reported. No ...

## ‘Shell-Shocked’: ‘Venom’ Star Secretly Enters Martial Arts Fighting Competition, Wins The Whole Thing
 - [https://www-preprod.dailywire.com/news/shell-shocked-venom-star-secretly-enters-martial-arts-fighting-competition-wins-the-whole-thing](https://www-preprod.dailywire.com/news/shell-shocked-venom-star-secretly-enters-martial-arts-fighting-competition-wins-the-whole-thing)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 15:04:32+00:00

Tom Hardy literally shocked opponents at a martial arts fighting competition in England when he secretly entered the Brazilian jiu-jitsu event and walked away winning the whole thing. The 45-year-old actor didn&#8217;t enter the 2022 Brazilian Jiu-Jitsu Open Championship over the weekend using his stage name, but his real name, &#8220;Edward,&#8221; the Guardian reported. No ...

## Democrats’ Dilemma: How To Dump Kamala Harris And Not Seem Racist, Sexist
 - [https://www.dailywire.com/news/democrats-dilemma-how-to-dump-kamala-harris-and-not-seem-racist-sexist](https://www.dailywire.com/news/democrats-dilemma-how-to-dump-kamala-harris-and-not-seem-racist-sexist)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:55:03+00:00

Ever since Kamala Harris joined the 2020 Democratic presidential ticket, top members of the party have been trying to figure out what to do with her in 2024 (or 2028 at the latest). Very early on in the Biden-Harris administration, her approval rating cratered &#8212; and it has never rebounded. She elicits so little fear in ...

## Democrats’ Dilemma: How To Dump Kamala Harris And Not Seem Racist, Sexist
 - [https://www-preprod.dailywire.com/news/democrats-dilemma-how-to-dump-kamala-harris-and-not-seem-racist-sexist](https://www-preprod.dailywire.com/news/democrats-dilemma-how-to-dump-kamala-harris-and-not-seem-racist-sexist)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:55:03+00:00

Ever since Kamala Harris joined the 2020 Democratic presidential ticket, top members of the party have been trying to figure out what to do with her in 2024 (or 2028 at the latest). Very early on in the Biden-Harris administration, her approval rating cratered &#8212; and it has never rebounded. She elicits so little fear in ...

## It Sure Sounds Like Biden Wants World War Over Ukraine
 - [https://www.dailywire.com/news/it-sure-sounds-like-biden-wants-world-war-over-ukraine](https://www.dailywire.com/news/it-sure-sounds-like-biden-wants-world-war-over-ukraine)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:50:18+00:00

President Joe Biden addressed the United Nations on Wednesday and reiterated his commitment to helping Ukraine and Russia find a peaceful, diplomatic resolution to the ongoing war. Just kidding, that sort of rhetoric has been coming from Henry Kissinger and Pope Francis. Biden instead used his international pulpit to inch the entire globe closer to ...

## It Sure Sounds Like Biden Wants World War Over Ukraine
 - [https://www-preprod.dailywire.com/news/it-sure-sounds-like-biden-wants-world-war-over-ukraine](https://www-preprod.dailywire.com/news/it-sure-sounds-like-biden-wants-world-war-over-ukraine)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:50:18+00:00

President Joe Biden addressed the United Nations on Wednesday and reiterated his commitment to helping Ukraine and Russia find a peaceful, diplomatic resolution to the ongoing war. Just kidding, that sort of rhetoric has been coming from Henry Kissinger and Pope Francis. Biden instead used his international pulpit to inch the entire globe closer to ...

## ‘For The First Time In My Life, I Was A Minority’: What Immigrating To America Taught Me About Race Relations
 - [https://www.dailywire.com/news/for-the-first-time-in-my-life-i-was-a-minority-what-immigrating-to-america-taught-me-about-race-relations](https://www.dailywire.com/news/for-the-first-time-in-my-life-i-was-a-minority-what-immigrating-to-america-taught-me-about-race-relations)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:48:21+00:00

On May 6th, 2003, I arrived in the United States for the first time as a missionary for my church. My 23-hour flight from Accra, Ghana landed at LAX around noon, and I was plunged right into the heart of the Los Angeles Metropolitan Area. It was my first time on a plane and my ...

## ‘For The First Time In My Life, I Was A Minority’: What Immigrating To America Taught Me About Race Relations
 - [https://www-preprod.dailywire.com/news/for-the-first-time-in-my-life-i-was-a-minority-what-immigrating-to-america-taught-me-about-race-relations](https://www-preprod.dailywire.com/news/for-the-first-time-in-my-life-i-was-a-minority-what-immigrating-to-america-taught-me-about-race-relations)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:48:21+00:00

On May 6th, 2003, I arrived in the United States for the first time as a missionary for my church. My 23-hour flight from Accra, Ghana landed at LAX around noon, and I was plunged right into the heart of the Los Angeles Metropolitan Area. It was my first time on a plane and my ...

## Dow Dives As Fed Hikes Key Rate Three-Quarters Of A Point
 - [https://www-preprod.dailywire.com/news/federal-reserve-announces-rate-hike-of-0-75](https://www-preprod.dailywire.com/news/federal-reserve-announces-rate-hike-of-0-75)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:22:38+00:00

The Federal Reserve announced raised the key federal funds interest rate three-quarters of a point Wednesday afternoon, sending the Dow tumbling more than 500 points. As inflation remains elevated and core inflation — the price level increase for all items except for food and energy — continues to rise, the central bank’s decision signals that officials are ...

## Federal Reserve Announces Rate Hike Of 0.75%
 - [https://www.dailywire.com/news/federal-reserve-announces-rate-hike-of-0-75](https://www.dailywire.com/news/federal-reserve-announces-rate-hike-of-0-75)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:22:38+00:00

The Federal Reserve announced an interest rate hike of 0.75% on Wednesday afternoon. As inflation remains elevated and core inflation — the price level increase for all items except for food and energy — continues to rise, the central bank’s decision signals that officials are prioritizing a cooldown in cost pressures, even with potential declines ...

## American Economy Shrank In The First Two Quarters And Will Likely Stagnate In The Third
 - [https://www.dailywire.com/news/american-economy-shrank-in-the-first-two-quarters-and-will-likely-stagnate-in-the-third](https://www.dailywire.com/news/american-economy-shrank-in-the-first-two-quarters-and-will-likely-stagnate-in-the-third)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:17:28+00:00

The American economy is expected to grow at a paltry 0.3% annualized rate in the third quarter of 2022, according to data from the Federal Reserve Bank of Atlanta. The regional bank’s GDPNow tracker, which calculates a running estimate of real output growth, correctly predicted that the economy would contract in both the first and ...

## American Economy Shrank In The First Two Quarters And Will Likely Stagnate In The Third
 - [https://www-preprod.dailywire.com/news/american-economy-shrank-in-the-first-two-quarters-and-will-likely-stagnate-in-the-third](https://www-preprod.dailywire.com/news/american-economy-shrank-in-the-first-two-quarters-and-will-likely-stagnate-in-the-third)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:17:28+00:00

The American economy is expected to grow at a paltry 0.3% annualized rate in the third quarter of 2022, according to data from the Federal Reserve Bank of Atlanta. The regional bank’s GDPNow tracker, which calculates a running estimate of real output growth, correctly predicted that the economy would contract in both the first and ...

## Sharon Osbourne Says She Was Ousted From ‘The Talk’ After Privately Slamming Not ‘Genuine’ Oprah Royals Interview
 - [https://www.dailywire.com/news/sharon-osbourne-says-she-was-ousted-from-the-talk-after-privately-slamming-not-genuine-oprah-royals-interview](https://www.dailywire.com/news/sharon-osbourne-says-she-was-ousted-from-the-talk-after-privately-slamming-not-genuine-oprah-royals-interview)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:17:20+00:00

Sharon Osbourne talked about her ousting from CBS&#8217;s &#8220;The Talk&#8221; and said it came after she privately slammed Oprah Winfrey&#8217;s royals&#8217; interview as not &#8220;genuine.&#8221; The 69-year-old TV personality said her exit from the daytime talk show wasn&#8217;t just about her support of Piers Morgan over his comments about Meghan Markle in the Oprah interview. ...

## Sharon Osbourne Says She Was Ousted From ‘The Talk’ After Privately Slamming Not ‘Genuine’ Oprah Royals Interview
 - [https://www-preprod.dailywire.com/news/sharon-osbourne-says-she-was-ousted-from-the-talk-after-privately-slamming-not-genuine-oprah-royals-interview](https://www-preprod.dailywire.com/news/sharon-osbourne-says-she-was-ousted-from-the-talk-after-privately-slamming-not-genuine-oprah-royals-interview)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:17:20+00:00

Sharon Osbourne talked about her ousting from CBS&#8217;s &#8220;The Talk&#8221; and said it came after she privately slammed Oprah Winfrey&#8217;s royals&#8217; interview as not &#8220;genuine.&#8221; The 69-year-old TV personality said her exit from the daytime talk show wasn&#8217;t just about her support of Piers Morgan over his comments about Meghan Markle in the Oprah interview. ...

## Energy Crisis Threatens European Countries Ahead Of Winter
 - [https://www.dailywire.com/news/energy-crisis-threatens-european-countries-ahead-of-winter](https://www.dailywire.com/news/energy-crisis-threatens-european-countries-ahead-of-winter)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:17:15+00:00

Europe is heading toward an energy crisis, and some economists are even predicting the continent will experience a serious recession.  “My best guess is we’ll have a recession in the United States but I’m much more confident that there’s going to be a recession and an element of stagflation in Europe that comes as a ...

## Energy Crisis Threatens European Countries Ahead Of Winter
 - [https://www-preprod.dailywire.com/news/energy-crisis-threatens-european-countries-ahead-of-winter](https://www-preprod.dailywire.com/news/energy-crisis-threatens-european-countries-ahead-of-winter)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:17:15+00:00

Europe is heading toward an energy crisis, and some economists are even predicting the continent will experience a serious recession.  “My best guess is we’ll have a recession in the United States but I’m much more confident that there’s going to be a recession and an element of stagflation in Europe that comes as a ...

## Wave Of Lawmakers Demanding Investigation Into Vanderbilt Pediatric Gender Clinic
 - [https://www.dailywire.com/news/wave-of-lawmakers-demanding-investigation-into-vanderbilt-pediatric-gender-clinic](https://www.dailywire.com/news/wave-of-lawmakers-demanding-investigation-into-vanderbilt-pediatric-gender-clinic)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:06:30+00:00

A groundswell of lawmakers are demanding an investigation into a Nashville pediatric gender clinic after shocking videos showed a doctor calling certain transgender surgeries &#8220;huge money makers&#8221; and a health law expert saying conscientious objections to the surgeries are &#8220;problematic.&#8221; The Pediatric Transgender Clinic at Vanderbilt University Medical Center (VUMC) performs &#8220;gender-affirming&#8221; double mastectomies on minor girls ...

## Wave Of Lawmakers Demanding Investigation Into Vanderbilt Pediatric Gender Clinic
 - [https://www-preprod.dailywire.com/news/wave-of-lawmakers-demanding-investigation-into-vanderbilt-pediatric-gender-clinic](https://www-preprod.dailywire.com/news/wave-of-lawmakers-demanding-investigation-into-vanderbilt-pediatric-gender-clinic)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 14:06:30+00:00

A groundswell of lawmakers are demanding an investigation into a Nashville pediatric gender clinic after shocking videos showed a doctor calling certain transgender surgeries &#8220;huge money makers&#8221; and a health law expert saying conscientious objections to the surgeries are &#8220;problematic.&#8221; The Pediatric Transgender Clinic at Vanderbilt University Medical Center (VUMC) performs &#8220;gender-affirming&#8221; double mastectomies on minor girls ...

## ‘Dancing With The Stars’ Debuts First Ever Drag Queen Contestant, Shangela, This Season
 - [https://www.dailywire.com/news/dancing-with-the-stars-debuts-first-ever-drag-queen-contestant-shangela-this-season](https://www.dailywire.com/news/dancing-with-the-stars-debuts-first-ever-drag-queen-contestant-shangela-this-season)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 13:59:00+00:00

Season 31 of “Dancing With the Stars” premiered Monday, showcasing its first-ever male same-sex dancing pair as drag queen Shangela joined the cast alongside professional dancer Gleb Savchenko. The media had nothing but glowing reviews for the former “RuPaul’s Drag Race” contestant, who completed his performance in drag. Born D.J. Pierce, the 40-year-old performer told ...

## ‘Dancing With The Stars’ Debuts First Ever Drag Queen Contestant, Shangela, This Season
 - [https://www-preprod.dailywire.com/news/dancing-with-the-stars-debuts-first-ever-drag-queen-contestant-shangela-this-season](https://www-preprod.dailywire.com/news/dancing-with-the-stars-debuts-first-ever-drag-queen-contestant-shangela-this-season)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 13:59:00+00:00

Season 31 of “Dancing With the Stars” premiered Monday, showcasing its first-ever male same-sex dancing pair as drag queen Shangela joined the cast alongside professional dancer Gleb Savchenko. The media had nothing but glowing reviews for the former “RuPaul’s Drag Race” contestant, who completed his performance in drag. Born D.J. Pierce, the 40-year-old performer told ...

## ‘Far Left Woke Ideology’: House Republicans Introduce Bill To Prohibit ‘Political Tests’ At Colleges
 - [https://www.dailywire.com/news/far-left-woke-ideology-house-republicans-introduce-bill-to-prohibit-political-tests-at-colleges](https://www.dailywire.com/news/far-left-woke-ideology-house-republicans-introduce-bill-to-prohibit-political-tests-at-colleges)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 13:44:40+00:00

A group of House Republicans has introduced a new bill to prohibit &#8220;political tests&#8221; in the admission, hiring, and promotion of college students and staff to fight against &#8220;woke ideology&#8221; on American university campuses. Reps. Elise Stefanik (NY), Fred Keller (PA), and Glenn Grothman (WI) presented the &#8220;Restoring Academic Freedom on Campus Act of 2022’’ ...

## ‘Far Left Woke Ideology’: House Republicans Introduce Bill To Prohibit ‘Political Tests’ At Colleges
 - [https://www-preprod.dailywire.com/news/far-left-woke-ideology-house-republicans-introduce-bill-to-prohibit-political-tests-at-colleges](https://www-preprod.dailywire.com/news/far-left-woke-ideology-house-republicans-introduce-bill-to-prohibit-political-tests-at-colleges)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 13:44:40+00:00

A group of House Republicans has introduced a new bill to prohibit &#8220;political tests&#8221; in the admission, hiring, and promotion of college students and staff to fight against &#8220;woke ideology&#8221; on American university campuses. Reps. Elise Stefanik (NY), Fred Keller (PA), and Glenn Grothman (WI) presented the &#8220;Restoring Academic Freedom on Campus Act of 2022’’ ...

## Mom Who Sent Chilling Text Before Death Was Found With Severe Burn Marks On Body
 - [https://www.dailywire.com/news/mom-who-sent-chilling-text-before-death-was-found-with-severe-burn-marks-on-body](https://www.dailywire.com/news/mom-who-sent-chilling-text-before-death-was-found-with-severe-burn-marks-on-body)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 13:42:08+00:00

The Georgia mom who sent her daughter thousands of dollars and a chilling text before her death was found with severe burn marks on her body. Debbie Collier, 59, was found dead in a ravine on September 11, just a day after she was reported missing by her daughter, who received a text from her ...

## Mom Who Sent Chilling Text Before Death Was Found With Severe Burn Marks On Body
 - [https://www-preprod.dailywire.com/news/mom-who-sent-chilling-text-before-death-was-found-with-severe-burn-marks-on-body](https://www-preprod.dailywire.com/news/mom-who-sent-chilling-text-before-death-was-found-with-severe-burn-marks-on-body)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 13:42:08+00:00

The Georgia mom who sent her daughter thousands of dollars and a chilling text before her death was found with severe burn marks on her body. Debbie Collier, 59, was found dead in a ravine on September 11, just a day after she was reported missing by her daughter, who received a text from her ...

## ‘We Won’t See An Apology’: Nikki Haley Doubles Down After Dust-Up With ‘The View’
 - [https://www.dailywire.com/news/we-wont-see-an-apology-nikki-haley-doubles-down-after-dust-up-with-the-view](https://www.dailywire.com/news/we-wont-see-an-apology-nikki-haley-doubles-down-after-dust-up-with-the-view)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 13:20:52+00:00

Former South Carolina Governor Nikki Haley (R) made it clear on Wednesday that she was not expecting an apology for racist remarks &#8220;The View&#8221; host Sunny Hostin made with regard to her name. Haley made an appearance on Fox News&#8217; &#8220;The Faulkner Focus&#8221; with anchor Harris Faulkner, and she outlined the double standard that would ...

## ‘We Won’t See An Apology’: Nikki Haley Doubles Down After Dust-Up With ‘The View’
 - [https://www-preprod.dailywire.com/news/we-wont-see-an-apology-nikki-haley-doubles-down-after-dust-up-with-the-view](https://www-preprod.dailywire.com/news/we-wont-see-an-apology-nikki-haley-doubles-down-after-dust-up-with-the-view)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 13:20:52+00:00

Former South Carolina Governor Nikki Haley (R) made it clear on Wednesday that she was not expecting an apology for racist remarks &#8220;The View&#8221; host Sunny Hostin made with regard to her name. Haley made an appearance on Fox News&#8217; &#8220;The Faulkner Focus&#8221; with anchor Harris Faulkner, and she outlined the double standard that would ...

## 17-Year-Old Charged After Two North Carolina Teenagers Found Shot Dead
 - [https://www.dailywire.com/news/17-year-old-charged-after-two-north-carolina-teenagers-found-shot-dead](https://www.dailywire.com/news/17-year-old-charged-after-two-north-carolina-teenagers-found-shot-dead)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:53:37+00:00

A 17-year-old has been charged with first-degree murder in the brutal killings of two North Carolina teenagers, whose bodies were found with numerous bullet wounds. Lyric Woods, 14, and her friend Devin Clark, 18, were separately reported missing by their families over the weekend, the New York Post reported. Their bodies were found earlier this ...

## 17-Year-Old Charged After Two North Carolina Teenagers Found Shot Dead
 - [https://www-preprod.dailywire.com/news/17-year-old-charged-after-two-north-carolina-teenagers-found-shot-dead](https://www-preprod.dailywire.com/news/17-year-old-charged-after-two-north-carolina-teenagers-found-shot-dead)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:53:37+00:00

A 17-year-old has been charged with first-degree murder in the brutal killings of two North Carolina teenagers, whose bodies were found with numerous bullet wounds. Lyric Woods, 14, and her friend Devin Clark, 18, were separately reported missing by their families over the weekend, the New York Post reported. Their bodies were found earlier this ...

## American Christian Population Projected To Drop Below 50% By 2070
 - [https://www.dailywire.com/news/american-christian-population-projected-to-drop-below-50-by-2070](https://www.dailywire.com/news/american-christian-population-projected-to-drop-below-50-by-2070)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:47:15+00:00

A Pew Research study has projected that America&#8217;s Christian population could drop below 50% by 2070 based on current trends. The study modeled four scenarios representing different rates of change to predict that the nation&#8217;s most-common religion could represent less than half the nation&#8217;s population over the next generation. &#8220;Depending on whether religious switching continues ...

## American Christian Population Projected To Drop Below 50% By 2070
 - [https://www-preprod.dailywire.com/news/american-christian-population-projected-to-drop-below-50-by-2070](https://www-preprod.dailywire.com/news/american-christian-population-projected-to-drop-below-50-by-2070)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:47:15+00:00

A Pew Research study has projected that America&#8217;s Christian population could drop below 50% by 2070 based on current trends. The study modeled four scenarios representing different rates of change to predict that the nation&#8217;s most-common religion could represent less than half the nation&#8217;s population over the next generation. &#8220;Depending on whether religious switching continues ...

## It Appears I Have White Privilege. How Do I Know? I Took A Test.
 - [https://www.dailywire.com/news/it-appears-i-have-white-privilege-how-do-i-know-i-took-a-test](https://www.dailywire.com/news/it-appears-i-have-white-privilege-how-do-i-know-i-took-a-test)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:46:07+00:00

According to a test provided to students and teachers by a Wisconsin school district, it appears I have white privilege. This comes as a surprise to me too, for various reasons, but the most obvious being that I am not white. I am black. I thought it’d be fitting to take one of these “white ...

## It Appears I Have White Privilege. How Do I Know? I Took A Test.
 - [https://www-preprod.dailywire.com/news/it-appears-i-have-white-privilege-how-do-i-know-i-took-a-test](https://www-preprod.dailywire.com/news/it-appears-i-have-white-privilege-how-do-i-know-i-took-a-test)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:46:07+00:00

According to a test provided to students and teachers by a Wisconsin school district, it appears I have white privilege. This comes as a surprise to me too, for various reasons, but the most obvious being that I am not white. I am black. I thought it’d be fitting to take one of these “white ...

## Aaron Judge Ties The Babe With 60th Homer, On Verge Of Passing Roger Maris
 - [https://www.dailywire.com/news/aaron-judge-ties-the-babe-with-60th-homer-on-verge-of-passing-roger-maris](https://www.dailywire.com/news/aaron-judge-ties-the-babe-with-60th-homer-on-verge-of-passing-roger-maris)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:42:56+00:00

New York Yankees star Aaron Judge, rewriting the baseball record book, tied the legendary Babe Ruth’s American League home run record which he set in 1927 before Yankees star Roger Maris eclipsed it in 1961, slugging his 60th home run of the season. No. 60 ties The Sultan of Swat for 2nd all-time in American League ...

## Aaron Judge Ties The Babe With 60th Homer, On Verge Of Passing Roger Maris
 - [https://www-preprod.dailywire.com/news/aaron-judge-ties-the-babe-with-60th-homer-on-verge-of-passing-roger-maris](https://www-preprod.dailywire.com/news/aaron-judge-ties-the-babe-with-60th-homer-on-verge-of-passing-roger-maris)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:42:56+00:00

New York Yankees star Aaron Judge, rewriting the baseball record book, tied the legendary Babe Ruth’s American League home run record which he set in 1927 before Yankees star Roger Maris eclipsed it in 1961, slugging his 60th home run of the season. No. 60 ties The Sultan of Swat for 2nd all-time in American League ...

## ‘Apologizing Just Leads To More Apologizing’: Adam Carolla Defies The Left’s Bullying
 - [https://www.dailywire.com/news/apologizing-just-leads-to-more-apologizing-adam-carolla-defies-the-lefts-bullying](https://www.dailywire.com/news/apologizing-just-leads-to-more-apologizing-adam-carolla-defies-the-lefts-bullying)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:08:08+00:00

Comedian Adam Carolla, who has made his career on speaking what he regards as the unvarnished truth, damn the consequences, spoke to veteran reporter John Stossel, doubling down on his mockery of Rep. Alexandria Ocasio-Cortez while shrugging off the idea of capitulating to leftists demanding apologies. “You said, ‘If AOC were fat and in her ...

## ‘Apologizing Just Leads To More Apologizing’: Adam Carolla Defies The Left’s Bullying
 - [https://www-preprod.dailywire.com/news/apologizing-just-leads-to-more-apologizing-adam-carolla-defies-the-lefts-bullying](https://www-preprod.dailywire.com/news/apologizing-just-leads-to-more-apologizing-adam-carolla-defies-the-lefts-bullying)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:08:08+00:00

Comedian Adam Carolla, who has made his career on speaking what he regards as the unvarnished truth, damn the consequences, spoke to veteran reporter John Stossel, doubling down on his mockery of Rep. Alexandria Ocasio-Cortez while shrugging off the idea of capitulating to leftists demanding apologies. “You said, ‘If AOC were fat and in her ...

## ‘It Was The Only Way’: Tennis Legend Reveals The Decision He Made After Having Kids
 - [https://www.dailywire.com/news/it-was-the-only-way-tennis-legend-reveals-the-decision-he-made-after-having-kids](https://www.dailywire.com/news/it-was-the-only-way-tennis-legend-reveals-the-decision-he-made-after-having-kids)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:01:09+00:00

Tennis legend Roger Federer, 41, revealed ahead of his last match that he would have retired years ago if he couldn&#8217;t take his kids on the road with him. Federer, who has won 20 grand slam titles, homeschools and travels with his young kids — two boys and two girls — whenever he plays. When ...

## ‘It Was The Only Way’: Tennis Legend Reveals The Decision He Made After Having Kids
 - [https://www-preprod.dailywire.com/news/it-was-the-only-way-tennis-legend-reveals-the-decision-he-made-after-having-kids](https://www-preprod.dailywire.com/news/it-was-the-only-way-tennis-legend-reveals-the-decision-he-made-after-having-kids)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 12:01:09+00:00

Tennis legend Roger Federer, 41, revealed ahead of his last match that he would have retired years ago if he couldn&#8217;t take his kids on the road with him. Federer, who has won 20 grand slam titles, homeschools and travels with his young kids — two boys and two girls — whenever he plays. When ...

## BREAKING: NY AG Files Fraud Suit Against Donald Trump, Children
 - [https://www.dailywire.com/news/breaking-ny-ag-files-fraud-suit-against-donald-trump-children](https://www.dailywire.com/news/breaking-ny-ag-files-fraud-suit-against-donald-trump-children)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 11:55:49+00:00

New York Attorney General Letitia James filed a civil lawsuit against former President Donald Trump and three of his children on Wednesday alleging business fraud. James has led an investigation into Trump and his business for more than three years, a probe the former president has dismissed as a political witch hunt. When James deposed ...

## NY AG Files Fraud Suit Against Donald Trump, Children
 - [https://www-preprod.dailywire.com/news/breaking-ny-ag-files-fraud-suit-against-donald-trump-children](https://www-preprod.dailywire.com/news/breaking-ny-ag-files-fraud-suit-against-donald-trump-children)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 11:55:49+00:00

New York Attorney General Letitia James filed a civil lawsuit against former President Donald Trump and three of his children on Wednesday alleging business fraud. James has led an investigation into Trump and his business for more than three years, a probe the former president has dismissed as a political witch hunt. When James deposed ...

## Putin Calls Up Reservists. Plane Tickets Exiting Russia Sold Out As Frantic Russians Panic.
 - [https://www.dailywire.com/news/putin-calls-up-reservists-plane-tickets-exiting-russia-sold-out-as-frantic-russians-panic](https://www.dailywire.com/news/putin-calls-up-reservists-plane-tickets-exiting-russia-sold-out-as-frantic-russians-panic)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 11:46:29+00:00

Reports out of Russian indicate that frantic Russians have responded to Russian president Vladimir Putin’s call-up of 300,000 reservists by swamping the airlines for tickets to leave Russia, leaving plane tickets to visa-free countries sold out. Accusing the West of attempting to “weaken and destroy” Russia, Putin announced on Wednesday that “in defense of our ...

## Putin Calls Up Reservists. Plane Tickets Exiting Russia Sold Out As Frantic Russians Panic.
 - [https://www-preprod.dailywire.com/news/putin-calls-up-reservists-plane-tickets-exiting-russia-sold-out-as-frantic-russians-panic](https://www-preprod.dailywire.com/news/putin-calls-up-reservists-plane-tickets-exiting-russia-sold-out-as-frantic-russians-panic)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 11:46:29+00:00

Reports out of Russian indicate that frantic Russians have responded to Russian president Vladimir Putin’s call-up of 300,000 reservists by swamping the airlines for tickets to leave Russia, leaving plane tickets to visa-free countries sold out. Accusing the West of attempting to “weaken and destroy” Russia, Putin announced on Wednesday that “in defense of our ...

## New York Gov. Hochul’s Ad Echoes DNC’s False Narrative About Capitol Police Officers
 - [https://www.dailywire.com/news/new-york-gov-hochuls-ad-echoes-dncs-false-narrative-about-capitol-police-officers](https://www.dailywire.com/news/new-york-gov-hochuls-ad-echoes-dncs-false-narrative-about-capitol-police-officers)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 11:39:33+00:00

I was watching TV the other day and a political ad caught my eye. The ad was courtesy of New York’s Democratic governor Kathy Hochul, slamming her Republican opponent, Lee Zeldin, about his support for “extreme insurrectionists” on January 6 and other purported crimes. So, the lines are being drawn and the strategies are solidifying. ...

## New York Gov. Hochul’s Ad Echoes DNC’s False Narrative About Capitol Police Officers
 - [https://www-preprod.dailywire.com/news/new-york-gov-hochuls-ad-echoes-dncs-false-narrative-about-capitol-police-officers](https://www-preprod.dailywire.com/news/new-york-gov-hochuls-ad-echoes-dncs-false-narrative-about-capitol-police-officers)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 11:39:33+00:00

I was watching TV the other day and a political ad caught my eye. The ad was courtesy of New York’s Democratic governor Kathy Hochul, slamming her Republican opponent, Lee Zeldin, about his support for “extreme insurrectionists” on January 6 and other purported crimes. So, the lines are being drawn and the strategies are solidifying. ...

## Democrats Introduce Legislation To Offer Military Leave For Service Members To Get Abortions
 - [https://www.dailywire.com/news/democrats-introduce-legislation-to-offer-military-leave-for-service-members-to-get-abortions](https://www.dailywire.com/news/democrats-introduce-legislation-to-offer-military-leave-for-service-members-to-get-abortions)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 11:23:11+00:00

A group of House Democrats has introduced a new bill that would require the military to provide a leave of absence for service members to receive abortions, including military payment to cover out-of-state travel. The bill, called the &#8220;Access to Reproductive Care for Service Members Act,&#8221; was introduced to respond to requests for abortions by ...

## Country Star Luke Bell’s Cause Of Death Revealed
 - [https://www.dailywire.com/news/country-star-luke-bells-cause-of-death-revealed](https://www.dailywire.com/news/country-star-luke-bells-cause-of-death-revealed)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 11:23:02+00:00

The cause of death for country star Luke Bell has been revealed. Bell, 32, was discovered dead after going missing for a week in Arizona. Now according to the autopsy report obtained by Fox News, the singer reportedly died of a fentanyl overdose. His death has been ruled an accident.  The autopsy report further stated ...

## Firm Launches Asset That Will Tell Corporate America To Put Profits Before Politics
 - [https://www.dailywire.com/news/firm-launches-asset-that-will-tell-corporate-america-to-put-profits-before-politics](https://www.dailywire.com/news/firm-launches-asset-that-will-tell-corporate-america-to-put-profits-before-politics)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 11:11:22+00:00

Strive Asset Management announced a new index fund that will push corporate America to pursue profits rather than social agendas. The company, launched earlier this year by entrepreneur Vivek Ramaswamy, will sell its Strive 500 exchange-traded fund (ETF) — a basket of shares meant to track the profits of the nation’s 500 largest companies — ...

## FBI Suspends Whistleblower Who Criticized Bureau’s Handling Of January 6 Investigations: Report
 - [https://www.dailywire.com/news/fbi-suspends-whistleblower-who-criticized-bureaus-handling-of-january-6-investigations-report](https://www.dailywire.com/news/fbi-suspends-whistleblower-who-criticized-bureaus-handling-of-january-6-investigations-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 11:02:35+00:00

The FBI has suspended a whistleblower who pushed back against the bureau’s handling of investigations related to the January 6, 2021, riot at the U.S. Capitol, according to House Republicans. “The FBI SUSPENDED a whistleblower for refusing to carry out the Bureau’s politicized investigations,” Republicans on the House Judiciary Committee said in a Twitter post ...

## More Women Share Flirty DMs From Adam Levine Amid His Alleged Cheating Scandal With Instagram Model
 - [https://www.dailywire.com/news/more-women-share-flirty-dms-from-adam-levine-amid-his-alleged-cheating-scandal-with-instagram-model](https://www.dailywire.com/news/more-women-share-flirty-dms-from-adam-levine-amid-his-alleged-cheating-scandal-with-instagram-model)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 10:52:37+00:00

As Adam Levine’s alleged infidelity scandal drags on, two more women came forward with their own allegations of receiving flirty messages from the Maroon 5 singer. Alyson Rosef shared photos of the direct messages (DMs) that Levine allegedly sent to her. They said in part, &#8220;I shouldn&#8217;t be talking to you you know (right)?&#8221;  In ...

## Nets’ Kyrie Irving Calls COVID Vaccine Mandate One Of ‘Biggest Violations’ Of Human Rights In History
 - [https://www.dailywire.com/news/nets-kyrie-irving-calls-covid-vaccine-mandate-one-of-biggest-violations-of-human-rights-in-history](https://www.dailywire.com/news/nets-kyrie-irving-calls-covid-vaccine-mandate-one-of-biggest-violations-of-human-rights-in-history)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 10:28:57+00:00

Brooklyn Nets star Kyrie Irving spoke out after New York City announced an end to its COVID vaccine mandate for private-sector employees on Tuesday, calling the requirement among &#8220;the biggest violations of human rights in history.&#8221; Irving shared the comments in a viral Twitter post on Tuesday following the announcement by New York City Democratic ...

## House Dems Shield Hunter Biden From Corruption Probe Despite National Security Concerns
 - [https://www.dailywire.com/news/house-dems-shield-hunter-biden-from-corruption-probe-despite-national-security-concerns](https://www.dailywire.com/news/house-dems-shield-hunter-biden-from-corruption-probe-despite-national-security-concerns)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 09:26:13+00:00

House Democrats voted Tuesday to protect Hunter Biden from a probe of the alleged influence-peddling schemes revealed by his abandoned laptop. The House Oversight Committee voted along straight party lines to kill a “resolution of inquiry” proposal by Rep. James Comer (R-KY). The proposal followed a steady drip of text messages and emails from the ...

## Media, Democrats Fall For Tweets Suggesting DeSantis Was Sending Migrants To Biden’s Home
 - [https://www.dailywire.com/news/media-democrats-fall-for-tweets-suggesting-desantis-was-sending-migrants-to-bidens-home](https://www.dailywire.com/news/media-democrats-fall-for-tweets-suggesting-desantis-was-sending-migrants-to-bidens-home)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 07:47:14+00:00

The Biden administration, the Delaware governor’s office, and the mainstream media were ready Tuesday to respond to Florida Republican Governor Ron DeSantis flying more illegal immigrants to the East Coast, this time to President Joe Biden&#8217;s home, but the moment never came. Far-Left activists generated buzz online Monday night by insinuating that DeSantis was going ...

## Philosopher Slammed For Claiming It’s Hard To Argue Why Controversial Teacher Should Not Be Allowed Near Kids
 - [https://www.dailywire.com/news/philosopher-slammed-for-claiming-its-hard-to-argue-why-controversial-teacher-should-not-be-allowed-near-kids](https://www.dailywire.com/news/philosopher-slammed-for-claiming-its-hard-to-argue-why-controversial-teacher-should-not-be-allowed-near-kids)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-21 07:34:59+00:00

A normally anti-woke professor faced backlash online Tuesday after urging people on social media to make a &#8220;good argument&#8221; as to why a male teacher in Canada who wears giant prosthetic breasts in the classroom should not be allowed to teach in a public school. The teacher, who Fox News host Tucker Carlson has covered ...


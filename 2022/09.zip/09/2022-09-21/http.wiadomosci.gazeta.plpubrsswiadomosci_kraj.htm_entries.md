# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Wypadek w słowackich Tatrach. Zginął ratownik GOPR i jego żona. "Łączyło ich uczucie i góry"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28939216,wypadek-w-slowackich-tatrach-zginal-ratownik-gopr-i-jego-zona.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28939216,wypadek-w-slowackich-tatrach-zginal-ratownik-gopr-i-jego-zona.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-21 20:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e8/99/1b/z28939240M,Wypadek-w-slowackich-Tatrach--Zginal-ratownik-GOPR.jpg" vspace="2" />W słowackich Tatrach wraz z żoną Roksaną zginął ratownik GOPR, instruktor ratownictwa górskiego i przewodnik wysokogórski IVBV, Andrzej Sokołowski, popularny "Sokół" - poinformowało Górskie Ochotnicze Pogotowie Ratunkowe. Małżeństwo spadło z Kwietnikowej Przełączki pod Staroleśnym Szczytem do Doliny Sławkowskiej.

## Nowy podatek dla parafii. Abp Jędraszewski wprowadza dziesięcinę. Rzecznik tłumaczy się Pismem Świętym
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28938913,nowy-podatek-dla-parafii-abp-jedraszewski-wprowadza-dziesiecine.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28938913,nowy-podatek-dla-parafii-abp-jedraszewski-wprowadza-dziesiecine.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-21 19:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ba/45/1b/z28596410M,Abp--Marek-Jedraszewski---zdjecie-archiwalne.jpg" vspace="2" />Kościół jest w złej kondycji finansowej - na początku pandemia COVID-19, teraz wytchnienia nie daje inflacja i kryzys energetyczny. Abp. Marek Jędraszewski remedium na problemy znalazł w Starym Testamencie. Wydał dekret, w którym nakazuje parafiom oddawać kurii dziesięcinę z ich przychodów od prowadzonej działalności.

## Słupsk. 5-latki były bite pasem ze sprzączką i pięściami. Jest wyrok dla matki i partnera
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28938874,slupsk-final-sprawy-znecania-sie-nad-5-letnimi-blizniaczkami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28938874,slupsk-final-sprawy-znecania-sie-nad-5-letnimi-blizniaczkami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-21 18:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/e0/1a/z28182873M,Sad---zdjecie-ilustracyjne.jpg" vspace="2" />Sąd Okręgowy w Słupsku w środę wydał wyrok w sprawie znęcania się nad 5-letnimi bliźniaczkami z Siemirowic (woj. pomorskie). 26-letnia Klaudia K. (matka dziewczynek) została skazana na 1,5 roku pozbawienia wolności. Z kolei jej partner 29-letni Daniel P. usłyszał wyrok 12 lat więzienia. Wyrok nie jest prawomocny.

## Trzebinia. Na cmentarzu zapadła się ziemia, wciągnęła groby. Będzie ekshumacja? Jest opinia biegłego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28937823,trzebinia-na-cmentarzu-zapadla-sie-ziemia-to-dziesiate-zapadlisko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28937823,trzebinia-na-cmentarzu-zapadla-sie-ziemia-to-dziesiate-zapadlisko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-21 14:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/38/97/1b/z28932152M,Trzebinia--Osunela-sie-ziemia-na-cmentarzu.jpg" vspace="2" />W Trzebini (woj. małopolskie) zapadła się ziemia - już po raz dziesiąty w ciągu roku. Tym razem stało się to na cmentarzu, a zniszczonych zostało około 40 grobów. Wciągnął je lej w ziemi. Dokonanie ekshumacji ciał wymaga zgody biegłego, ten jednak jej odmówił. Jako powód wskazał zagrożenie dla osób, które mogłyby pracować w okolicy zapadliska.

## Prognoza pogody. Deszcz, słońce, przymrozki, śnieg - w tym tygodniu wszystko się może zdarzyć
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28937231,prognoza-pogody-deszcz-slonce-przymrozki-snieg-w-tym-tygodniu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28937231,prognoza-pogody-deszcz-slonce-przymrozki-snieg-w-tym-tygodniu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-21 13:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b9/98/1b/z28937657M,Jesien-w-parku.jpg" vspace="2" />Pogoda w najbliższych dniach będzie bardzo zmienna. Pojawią się obfite opady deszczu, burze, znaczne ochłodzenie oraz przymrozki. Nie zabraknie też pięknych, słonecznych dni. Jak dokładnie będzie wyglądać nadchodzący tydzień?

## Mateusz Morawiecki promuje spot krytykujący prawdomówność Donalda Tuska. "Obsesja. Litości, ileż można?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28935231,mateusz-morawiecki-krytykuje-donalda-tuska-w-spocie-nie-klam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28935231,mateusz-morawiecki-krytykuje-donalda-tuska-w-spocie-nie-klam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-21 12:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/62/98/1b/z28935522M,Mateusz-Morawiecki-udostepnil-spot-krytykujacy-Don.jpg" vspace="2" />Premier Mateusz Morawiecki jest bardzo zaangażowany w podważanie wiarygodności Donalda Tuska. Część internautów nazywa to obsesją. We wtorek w nocy premier udostępnił na Facebooku spot dot. działań lidera PO w czasie, gdy ten był premierem. W nim wypowiedzi Tuska przetykane nagłówkami z gazet sprzed 12-13 lat. I komentarz Morawieckiego: "Donald Tusk jes

## PAP: Radosław M., były dziennikarz TVP i Polskiego Radia, zatrzymany
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28936721,pap-radoslaw-m-byly-dziennikarz-tvp-i-polskiego-radia-zatrzymany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28936721,pap-radoslaw-m-byly-dziennikarz-tvp-i-polskiego-radia-zatrzymany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-21 11:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/76/2b/1a/z27442038M,Kajdanki--zdjecie-ilustracyjne-.jpg" vspace="2" />Radosław M., były dziennikarz TVP i Polskiego Radia zatrzymany - podaje w środę PAP. Informację potwierdziła także warszawska prokuratura okręgowa.

## Jarosław Kaczyński objeżdża kraj. W środę prezes PiS spotka się z mieszkańcami Siedlec
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28935032,jaroslaw-kaczynski-objezdza-kraj-w-srode-prezes-pis-spotka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28935032,jaroslaw-kaczynski-objezdza-kraj-w-srode-prezes-pis-spotka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-21 09:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b0/92/1b/z28912816M,Jaroslaw-Kaczynski.jpg" vspace="2" />Prezes Prawa i Sprawiedliwości Jarosław Kaczyński kontynuuje objazd nowych okręgów partyjnych. Dziś spotka się z mieszkańcami Siedlec.

## Bronisław Komorowski gościem Porannej Rozmowy Gazeta.pl
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28935127,bronislaw-komorowski-gosciem-porannej-rozmowy-gazeta-pl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28935127,bronislaw-komorowski-gosciem-porannej-rozmowy-gazeta-pl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-21 06:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ea/98/1b/z28935146M,Bronislaw-Komorowski-gosciem-Porannej-Rozmowy-Gaze.jpg" vspace="2" />W środę gościem Porannej Rozmowy Gazeta.pl będzie Bronisław Komorowski. Z byłym prezydentem Polski porozmawiamy m.in. o spotkaniu liderów opozycji, raporcie podkomisji smoleńskiej oraz o reparacjach wojennych. Program poprowadzi Jacek Gądek.


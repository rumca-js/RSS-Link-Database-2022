# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Federal judge strikes down federal school mask and vaccine mandate for Head Start program
 - [https://www.foxnews.com/media/federal-judge-strikes-down-federal-school-mask-and-vaccine-mandate-head-state-program](https://www.foxnews.com/media/federal-judge-strikes-down-federal-school-mask-and-vaccine-mandate-head-state-program)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 23:54:19+00:00

U.S. District Court Judge Terry A. Doughty in Louisiana ruled that the federal government cannot push a COVID-19 vaccine or mask mandate for the Head Start program.

## New York AG attempting to ban Trump and family from running businesses in New York: Tom Dupree
 - [https://www.foxnews.com/media/new-york-ag-trump-family-running-businesses-new-york-tom-dupree](https://www.foxnews.com/media/new-york-ag-trump-family-running-businesses-new-york-tom-dupree)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 23:52:08+00:00

Former deputy assistant attorney general Tom Dupree analyzed New York attorney general Letitia James's lawsuit against former President Trump on "Your World."

## California firefighters rescue blind dog that fell inside 15-foot hole at construction site
 - [https://www.foxnews.com/us/california-firefighters-rescue-blind-dog-fell-inside-hole-construction-site](https://www.foxnews.com/us/california-firefighters-rescue-blind-dog-fell-inside-hole-construction-site)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 23:40:40+00:00

California firefighters rescued a 13-year-old blind dog that fell into a 15-foot hole at a construction site in Pasadena on Tuesday evening.

## Ukrainian President Zelenskyy lays out 'peace formula' to end war in country, but says 'Russia wants war'
 - [https://www.foxnews.com/world/ukrainian-president-zelenskyy-lays-peace-formula-end-war-country-russia-wants-war](https://www.foxnews.com/world/ukrainian-president-zelenskyy-lays-peace-formula-end-war-country-russia-wants-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 23:35:44+00:00

Ukrainian President Volodymyr Zelenskyy gave a "peace formula" for the war in his country that contains "just punishment" to Russian President Vladimir Putin.

## Harold Ford Jr: We all need to take a breath before we call people 'woke' or want to cancel them
 - [https://www.foxnews.com/media/harold-ford-jr-need-take-breath-before-call-people-woke-cancel](https://www.foxnews.com/media/harold-ford-jr-need-take-breath-before-call-people-woke-cancel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 23:34:28+00:00

Fox News contributor Harold Ford Jr. suggested both sides of the political aisle shouldn't be so quick to attack each other over differing beliefs on "The Five."

## 9-year-old boy seriously injured in Alaska brown bear mauling, bear shot dead by family member
 - [https://www.foxnews.com/us/9-year-old-boy-seriously-injured-alaska-brown-bear-mauling-bear-shot-dead-family-member](https://www.foxnews.com/us/9-year-old-boy-seriously-injured-alaska-brown-bear-mauling-bear-shot-dead-family-member)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 23:28:26+00:00

A 9-year-old boy in Alaska suffered serious injuries and was taken to the hospital after he was mauled by a brown bear while hunting, state troopers said.

## Former Treasury Secretary Larry Summers predicts there will 'almost certainly' be a 'downturn in the economy'
 - [https://www.foxnews.com/media/former-treasury-secretary-larry-summers-predicts-certainly-downturn-economy](https://www.foxnews.com/media/former-treasury-secretary-larry-summers-predicts-certainly-downturn-economy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 23:27:19+00:00

Former Treasury Secretary Larry Summers predicted there will "almost certainly" be a "downturn in the economy" as prices soar and the Fed raises interest rates to combat inflation.

## Greg Gutfeld: Biden warns UN of climate 'crisis' but spends billions on Ukraine war
 - [https://www.foxnews.com/media/greg-gutfeld-biden-warns-un-climate-crisis-spends-billions-ukraine-war](https://www.foxnews.com/media/greg-gutfeld-biden-warns-un-climate-crisis-spends-billions-ukraine-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 23:22:09+00:00

Russian President Vladimir Putin said he is not bluffing when it comes to the prospect of using nuclear weapons against the West amid the Ukraine war.

## Carly Pearce, Cody Johnson, Kane Brown, Luke Combs and Walker Hayes announced as CMT's Artists of the Year
 - [https://www.foxnews.com/entertainment/carly-pearce-cody-johnson-kane-brown-luke-combs-walker-hayes-announced-cmts-artists-year](https://www.foxnews.com/entertainment/carly-pearce-cody-johnson-kane-brown-luke-combs-walker-hayes-announced-cmts-artists-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 23:15:25+00:00

CMT announced that country stars Carly Pearce, Cody Johnson, Kane Brown, Luke Combs and Walker Hayes have been named the 2022 Artists of the Year.

## Royals fire executive that aided in building 2015 World Series team
 - [https://www.foxnews.com/sports/royals-fire-executive-aided-building-2015-world-series-team](https://www.foxnews.com/sports/royals-fire-executive-aided-building-2015-world-series-team)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 23:13:55+00:00

The Kansas City Royals have fired president of baseball operations Dayton Moore on Wednesday, an executive that has been with the team since 2006.

## Gen. Jack Keane: 'No doubt' Putin loses Ukraine if US gets involved
 - [https://www.foxnews.com/media/gen-jack-keane-no-doubt-putin-loses-ukraine-us-gets-involved](https://www.foxnews.com/media/gen-jack-keane-no-doubt-putin-loses-ukraine-us-gets-involved)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 23:01:02+00:00

General Jack Keane joins "Your World" to break down why Vladimir Putin threatening nuclear war against Ukraine is not a smart strategy.

## Triple H wants NBA star to join WWE: 'All he’s got to do is call me ... let's go'
 - [https://www.foxnews.com/sports/triple-h-wants-nba-star-to-join-wwe-all-hes-gotta-do-is-call-me](https://www.foxnews.com/sports/triple-h-wants-nba-star-to-join-wwe-all-hes-gotta-do-is-call-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 22:56:29+00:00

Dwight Howard has an open invite to the WWE whenever he is ready to officially call it a career in the NBA, according to WWE chief content officer Triple H.

## Debbie Collier case: Criminal profiler warns of possible 'budding serial killer' after missing mom's murder
 - [https://www.foxnews.com/us/debbie-collier-case-criminal-profiler-warns-possible-budding-serial-killer-missing-moms-murder](https://www.foxnews.com/us/debbie-collier-case-criminal-profiler-warns-possible-budding-serial-killer-missing-moms-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 22:46:08+00:00

Georgia mom Debbie Collier's brutal murder shows signs of a repeat sex offender who may have tried to burn off DNA evidence, according to a criminal profiler.

## Fortune magazine headline insists people ‘should be happy’ about inflation
 - [https://www.foxnews.com/media/fortune-magazine-headline-insists-people-happy-inflation](https://www.foxnews.com/media/fortune-magazine-headline-insists-people-happy-inflation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 22:36:36+00:00

Fortune magazine was ridiculed on Tuesday for promoting an article arguing that people should be “happy” with record-high inflation rates despite its impact on the economy.

## Adam Levine admitted to cheating in the past: 'Monogamy is not in our genetic makeup'
 - [https://www.foxnews.com/entertainment/adam-levine-admitted-cheating-past-monogamy-not-genetic-makeup](https://www.foxnews.com/entertainment/adam-levine-admitted-cheating-past-monogamy-not-genetic-makeup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 22:36:16+00:00

Amid Adam Levine's alleged cheating scandal, an interview from 2009 has resurfaced in which the star admitted to cheating during a past relationship.

## Steelers rookie George Pickens claimed to be open '90% of the time' vs. Patriots
 - [https://www.foxnews.com/sports/steelers-rookie-george-pickens-claimed-open-90-percent-time-patriots](https://www.foxnews.com/sports/steelers-rookie-george-pickens-claimed-open-90-percent-time-patriots)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 22:31:19+00:00

Pittsburgh Steelers rookie receiver George Pickens claimed that he was wide open on most of the team's offensive snaps against the New England Patriots last week.

## Florida investigators shut down fentanyl trafficking operation, seize enough drugs to kill 4 million people
 - [https://www.foxnews.com/us/florida-investigators-shut-down-fentanyl-trafficking-operation-seize-enough-drugs-kill-4-million-people](https://www.foxnews.com/us/florida-investigators-shut-down-fentanyl-trafficking-operation-seize-enough-drugs-kill-4-million-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 22:26:08+00:00

A joint operation in Florida shut down a major fentanyl trafficking operation and seized enough drugs to kill more than 4 million people in the process.

## Putin to use 'sham' votes to feign Ukrainians begging to be a part of Russia: Brett Velicovich
 - [https://www.foxnews.com/media/putin-using-propaganda-get-russians-support-ukrainian-annexation-brett-velicovichw](https://www.foxnews.com/media/putin-using-propaganda-get-russians-support-ukrainian-annexation-brett-velicovichw)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 22:13:42+00:00

Brett Velicovich, Army veteran and author of "Drone Warrior" broke down latest news of Russian troop mobilization and annexation on "The Story" Wednesday.

## Houston suspect tells fast-food employees it’s his first robbery, leaves empty-handed, police say
 - [https://www.foxnews.com/us/houston-suspect-tells-fast-food-employees-first-robbery-leaves-empty-handed-police-say](https://www.foxnews.com/us/houston-suspect-tells-fast-food-employees-first-robbery-leaves-empty-handed-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 22:13:21+00:00

A suspect in Houston entered a fast-food restaurant, told employees it was his first robbery, and eventually left empty-handed, according to police.

## Dem Sen. Michael Bennet won't define the word 'woman’ after selling 'women with Bennet' tote bags
 - [https://www.foxnews.com/politics/dem-sen-michael-bennet-refuses-define-word-woman-selling-bags-female-supporters](https://www.foxnews.com/politics/dem-sen-michael-bennet-refuses-define-word-woman-selling-bags-female-supporters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 22:07:33+00:00

Sen. Michael Bennet, the Democratic nominee running in Colorado senate race, refused to define the term "woman" after selling handbags with "Women for Bennet" on his campaign website

## Atlanta city council seeks to fine residents if dogs bark too much
 - [https://www.foxnews.com/us/atlanta-city-council-seeks-fine-residents-dogs-bark-too-much](https://www.foxnews.com/us/atlanta-city-council-seeks-fine-residents-dogs-bark-too-much)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 22:01:40+00:00

The Atlanta City Council is cracking down on pet owners who let their animals make too much noise for too long, with escalating fines for repeat offenders.

## Manchin releases energy permitting bill, hopes GOP, Dems rally around it
 - [https://www.foxnews.com/politics/manchin-releases-energy-permitting-bill-hopes-gop-dems-rally-around-it](https://www.foxnews.com/politics/manchin-releases-energy-permitting-bill-hopes-gop-dems-rally-around-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 22:00:37+00:00

Sen. Joe Manchin on Wednesday released his bill on energy permitting reform, which top Democrats plan to include on an upcoming continuing resolution vote.

## Mets break obscure MLB record after getting hit by three pitches Wednesday
 - [https://www.foxnews.com/sports/mets-tie-obscure-mlb-record-after-getting-hit-by-three-pitches-wednesday](https://www.foxnews.com/sports/mets-tie-obscure-mlb-record-after-getting-hit-by-three-pitches-wednesday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 21:35:05+00:00

The New York Mets are going to need a lot of ice baths after this year. Mets batters have been hit by 106 pitches this season, breaking the modern-day record.

## US F-15 intercepts small plane entering restricted airspace in NYC around time of President Biden's UN speech
 - [https://www.foxnews.com/us/us-f-15-intercepts-small-plane-entering-restricted-airspace-nyc-around-time-president-bidens-un-speech](https://www.foxnews.com/us/us-f-15-intercepts-small-plane-entering-restricted-airspace-nyc-around-time-president-bidens-un-speech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 21:34:36+00:00

A small plane in New York City was intercepted after it went into restricted airspace around the time President Biden gave his address to the United Nations.

## MSNBC's Rachel Maddow misses once-a-week show, replacement hits seven-year viewership low in key demo
 - [https://www.foxnews.com/media/maddow-misses-once-a-week-show-replacement-hits-seven-year-viewership-low-in-key-demo](https://www.foxnews.com/media/maddow-misses-once-a-week-show-replacement-hits-seven-year-viewership-low-in-key-demo)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 21:18:33+00:00

MSNBC had its smallest audience on a Monday at 9 p.m. ET since 2015 this week when Rachel Maddow went on vacation and missed her once-a-week program.

## Hurricanes’ Tyler Van Dyke prefers playing on the road, says home games lack ‘college atmosphere’
 - [https://www.foxnews.com/sports/hurricanes-tyler-van-dyke-prefers-road-games-seeing-that-college-atmosphere](https://www.foxnews.com/sports/hurricanes-tyler-van-dyke-prefers-road-games-seeing-that-college-atmosphere)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 21:17:14+00:00

Miami Hurricanes quarterback Tyler Van Dyke said that he prefers playing in road games as Miami's stadium doesn't have much of a "college atmosphere."

## New York AG Trump lawsuit a 'political hit job' driven by left's desire to 'punish' him: Bill Barr
 - [https://www.foxnews.com/media/new-york-ag-trump-lawsuit-political-hit-job-lefts-desire-punish-him-bill-barr](https://www.foxnews.com/media/new-york-ag-trump-lawsuit-political-hit-job-lefts-desire-punish-him-bill-barr)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 21:16:46+00:00

New York attorney general "grossly overreaches" in her lawsuit against former President Donald Trump and his children, former U.S. Attorney General Bill Barr said.

## Biden official grilled after latest Taiwan declaration contradicts policy: 'He said it four times'
 - [https://www.foxnews.com/media/biden-official-grilled-latest-taiwan-declaration-contradicts-policy-said-four-times](https://www.foxnews.com/media/biden-official-grilled-latest-taiwan-declaration-contradicts-policy-said-four-times)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 21:16:11+00:00

U.S. State Department spokesperson Edward Price joined Fox News' 'The Story' on Wednesday for a wide-ranging interview on topics such as Taiwan and Ukraine.

## Dems reject GOP investigation into safety of unaccompanied children at the border: ‘Completely unnecessary'
 - [https://www.foxnews.com/politics/dems-reject-gop-investigation-safety-unaccompanied-children-border-completely-unnecessary](https://www.foxnews.com/politics/dems-reject-gop-investigation-safety-unaccompanied-children-border-completely-unnecessary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 21:09:47+00:00

Republicans are looking for more information about the surge of migrant children across the border. Democrats are dismissing the necessity of a probe.

## House passes Liz Cheney-backed election reform bill in Dem push to prevent another Trump ‘insurrection’
 - [https://www.foxnews.com/politics/house-passes-cheney-backed-election-reform-bill-dem-push-to-prevent-trump-insurrection](https://www.foxnews.com/politics/house-passes-cheney-backed-election-reform-bill-dem-push-to-prevent-trump-insurrection)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 21:08:09+00:00

The bill is squarely aimed at former President Trump's dispute of the 2020 election results, and would clarify that the vice president's role when counting election results is ministerial only.

## More chilly rain forecasted in northern Nevada
 - [https://www.foxnews.com/us/more-chilly-rain-forecasted-northern-nevada](https://www.foxnews.com/us/more-chilly-rain-forecasted-northern-nevada)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 21:06:53+00:00

The weather forecast predicts northern Nevada will experience more chilly rain. Temperatures in cities like Tahoe and Reno are expected to be 10-20 degrees colder than usual

## Los Angeles city councilman demands answers in Rep. Karen Bass home burglary from LAPD chief, city attorney
 - [https://www.foxnews.com/us/los-angeles-city-councilman-demands-answers-rep-karen-bass-home-burglary-lapd-chief-city-attorney](https://www.foxnews.com/us/los-angeles-city-councilman-demands-answers-rep-karen-bass-home-burglary-lapd-chief-city-attorney)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 21:02:38+00:00

A Los Angeles elected official is asking the police chief and city attorney to provide answers into a home burglary investigation involving U.S. Rep. Karen Bass.

## California Mustang thief runs of out gas during police chase, killed by oncoming traffic: report
 - [https://www.foxnews.com/us/california-mustang-thief-runs-out-gas-during-police-chase-killed-oncoming-traffic-report](https://www.foxnews.com/us/california-mustang-thief-runs-out-gas-during-police-chase-killed-oncoming-traffic-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 20:40:40+00:00

An alleged car thief took a Ford Mustang from a California home and led authorities on a chase before running out of gas. He was killed by oncoming traffic.

## Seattle residents will be able to vote on affordable housing plan
 - [https://www.foxnews.com/us/seattle-residents-able-vote-affordable-housing-plan](https://www.foxnews.com/us/seattle-residents-able-vote-affordable-housing-plan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 20:34:16+00:00

An affordable housing plan will be proposed on a 2023 election ballot. If passed, rental costs will be protected from market fluctuations.

## Border Patrol ordered agents not to assign migrants registration numbers to clear over-crowded facilities
 - [https://www.foxnews.com/politics/border-patrol-ordered-agents-not-assign-migrants-registration-numbers-clear-over-crowded-facilities](https://www.foxnews.com/politics/border-patrol-ordered-agents-not-assign-migrants-registration-numbers-clear-over-crowded-facilities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 20:32:50+00:00

Border Patrol Headquarters directed agents not to assign A-numbers to migrants in some instances in an effort to clear over-crowded facilities and speed up processing.

## Sen. Scott slams 'View' host's remarks on Nikki Haley's heritage: Left trying to 'demoralize' GOP minorities
 - [https://www.foxnews.com/media/sen-scott-slams-view-hosts-remarks-nikki-haleys-heritage-left-trying-demoralize-gop-minorities](https://www.foxnews.com/media/sen-scott-slams-view-hosts-remarks-nikki-haleys-heritage-left-trying-demoralize-gop-minorities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 20:26:41+00:00

Sen. Tim Scott, R-S.C., defends former South Carolina Gov. Nikki Haley against criticism from "View" host Sunny Hostin, arguing the left wants to "diminish" conservative minorities.

## An LSU student tragically gunned down last week was buried Wednesday
 - [https://www.foxnews.com/us/lsu-student-gunned-down-last-week-buried-wednesday](https://www.foxnews.com/us/lsu-student-gunned-down-last-week-buried-wednesday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 20:21:38+00:00

Louisiana State University senior Allison "Allie" Rice, 21, who was murdered last week in Baton Rouge, was buried Wednesday as more than 200 tearful mourners looked on.

## GA school worksheet characterizes 'hypothetical' abortion ban as ‘abuse of power,' prompts parental pushback
 - [https://www.foxnews.com/media/ga-school-worksheet-characterizes-hypothetical-abortion-ban-abusepower-prompts-parental-pushback](https://www.foxnews.com/media/ga-school-worksheet-characterizes-hypothetical-abortion-ban-abusepower-prompts-parental-pushback)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 20:21:28+00:00

A concerned Georgia-based parent brought attention to an assignment that seemed to characterize a "hypothetical" abortion ban ruling as an "abuse of power."

## Idaho on its way to building the nation’s largest research dairy
 - [https://www.foxnews.com/us/idaho-way-building-nations-largest-research-dairy](https://www.foxnews.com/us/idaho-way-building-nations-largest-research-dairy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 20:20:27+00:00

University of Idaho was approved by the state to build the nation’s biggest research dairy and experimental farm. The state will be funding the university $23 million.

## Beautiful black bear with white fur in Michigan is killed by wolves shortly after a sighting
 - [https://www.foxnews.com/lifestyle/beautiful-black-bear-white-fur-spotted-michigan-killed-wolves-sighting](https://www.foxnews.com/lifestyle/beautiful-black-bear-white-fur-spotted-michigan-killed-wolves-sighting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 20:19:54+00:00

An extremely rare white-colored black bear caught on a trail cam in Michigan's Upper Peninsula was killed by wolves, guide service Yooper Outdoors #906 told Fox News Digital.

## 2 US military veterans among 10 released by Russian-backed separatists as part of prisoner exchange
 - [https://www.foxnews.com/us/2-us-military-veterans-among-10-released-russian-backed-separatists-part-prisoner-exchange](https://www.foxnews.com/us/2-us-military-veterans-among-10-released-russian-backed-separatists-part-prisoner-exchange)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 20:19:42+00:00

Russian-backed separatists released 10 people, including two U.S. veterans, as part of a prisoner exchange mediated by Saudi Arabia. Alex Drueke and Andy Huynh went missing on June 9.

## Oregon’s tuition-free preschool program delayed due to staffing shortages, unsigned contracts
 - [https://www.foxnews.com/us/oregons-tuition-free-preschool-program-delayed-due-staffing-shortages-unsigned-contracts](https://www.foxnews.com/us/oregons-tuition-free-preschool-program-delayed-due-staffing-shortages-unsigned-contracts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 20:15:55+00:00

The tuition-free, state-provided preschool program in Oregon is experiencing major delays due to unsigned contracts and staffing shortages.

## SEC commissioner on expanded CFP: 'We want college football to be strong nationally'
 - [https://www.foxnews.com/sports/sec-commissioner-expanded-cfp-we-want-college-football-strong-nationally](https://www.foxnews.com/sports/sec-commissioner-expanded-cfp-we-want-college-football-strong-nationally)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 20:10:39+00:00

SEC commissioner Greg Sankey said that he wants college football to be "strong nationally" and believes the expanded College Football Playoffs will do that.

## New Hampshire to use $5 million in federal funding to support homeless shelters during winter
 - [https://www.foxnews.com/us/new-hampshire-use-5-million-federal-funding-support-homeless-shelters-during-winter](https://www.foxnews.com/us/new-hampshire-use-5-million-federal-funding-support-homeless-shelters-during-winter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 19:33:57+00:00

New Hampshire will be using $5 million in federal funding to help support shelters in the state during the winter with 1,605 experiencing homelessness in the state.

## Belgian clergy defy Vatican warnings, debut 'blessings' for same-sex couples
 - [https://www.foxnews.com/world/belgian-clergy-defy-vatican-warnings-debut-blessings-for-same-sex-couples](https://www.foxnews.com/world/belgian-clergy-defy-vatican-warnings-debut-blessings-for-same-sex-couples)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 19:33:15+00:00

Belgian Catholic bishops have snubbed repeated warnings from the Vatican and Pope Francis against propagating ceremonies for the blessing of same-sex couples.

## NTSB recommends vehicles have blood alcohol monitors to prevent intoxicated driving
 - [https://www.foxnews.com/us/ntsb-recommends-vehicles-have-blood-alcohol-monitors-to-prevent-intoxicated-driving](https://www.foxnews.com/us/ntsb-recommends-vehicles-have-blood-alcohol-monitors-to-prevent-intoxicated-driving)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 19:32:28+00:00

The National Transportation Safety Board recommended that new cars should include alcohol breath tests to prevent intoxicated driving and crashes.

## TUCKER CARLSON: Oakville Trafalgar High School is protecting a child abuser, has institutionalized child abuse
 - [https://www.foxnews.com/opinion/tucker-carlson-oakville-trafalgar-high-school-protecting-child-abuser-institutionalized-child-abuse](https://www.foxnews.com/opinion/tucker-carlson-oakville-trafalgar-high-school-protecting-child-abuser-institutionalized-child-abuse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 19:31:19+00:00

Fox News' Tucker Carlson gives update where he slams Canadian school and media for protecting teacher with giant prosthetic breasts modeled after pornographic content.

## NFL issues warning to Bruce Arians after Bucs-Saints brawl: report
 - [https://www.foxnews.com/sports/nfl-issues-warning-bruce-arians-after-bucs-saints-brawl-report](https://www.foxnews.com/sports/nfl-issues-warning-bruce-arians-after-bucs-saints-brawl-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 19:27:46+00:00

The NFL sent a warning to Tampa Bay Buccaneers senior football consultant Bruce Arians for his role in Sunday's brawl with New Orleans Saints cornerback Marshon Lattimore.

## San Diego finds additional issues at 104-year-old dam, delaying repair schedule
 - [https://www.foxnews.com/us/san-diego-finds-additional-issues-104-year-old-dam-delaying-repair-schedule](https://www.foxnews.com/us/san-diego-finds-additional-issues-104-year-old-dam-delaying-repair-schedule)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 19:20:37+00:00

Workers repairing the Hodges Reservoir Dam in San Diego, California, have found additional problems. The new issues will likely delay the construction project into spring 2023.

## Former Pakistani government minister meets with Israeli Foreign Ministry officials in Jerusalem
 - [https://www.foxnews.com/politics/former-pakistani-government-minister-meets-israeli-foreign-ministry-jerusalem](https://www.foxnews.com/politics/former-pakistani-government-minister-meets-israeli-foreign-ministry-jerusalem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 19:18:28+00:00

A delegation of Pakistanis and Israeli officials met in Jerusalem this week to discuss diplomatic relations between the two countries and interfaith harmony between Jews and Muslims.

## Ratings-challenged Don Lemon ‘not the answer,’ to CNN’s morning show issues, critics say
 - [https://www.foxnews.com/media/ratings-challenged-don-lemon-not-answer-cnn-morning-show-issues-critics-say](https://www.foxnews.com/media/ratings-challenged-don-lemon-not-answer-cnn-morning-show-issues-critics-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 19:16:35+00:00

Don Lemon was pulled from CNN primetime and will move to a morning program later this year, but critics don’t expect him to fix the network’s ratings woes.

## Tom Hardy snuck into a jiu-jitsu tournament and beat everyone
 - [https://www.foxnews.com/entertainment/tom-hardy-snuck-jiu-jitsu-tournament-beat-everyone](https://www.foxnews.com/entertainment/tom-hardy-snuck-jiu-jitsu-tournament-beat-everyone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 19:15:15+00:00

Actor Tom Hardy shocked everyone when he snuck into a martial arts competition hosted in the United Kingdom, but then he took home the gold.

## Fetterman failed to preside over Pennsylvania Senate 33% of the time, but attended every pardons board meeting
 - [https://www.foxnews.com/politics/fetterman-failed-preside-pennsylvania-senate-33-time-attended-every-pardons-board-meeting](https://www.foxnews.com/politics/fetterman-failed-preside-pennsylvania-senate-33-time-attended-every-pardons-board-meeting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 18:41:53+00:00

John Fetterman has been absent from some of his duties as Pennsylvania's lieutenant governor, failing to preside over the Senate at times while attending all board of pardons meetings.

## Vanderbilt University clinic responds to claims of unethical transgender surgery on minors
 - [https://www.foxnews.com/us/vanderbilt-university-clinic-responds-claims-unethical-transgender-surgery-minors](https://www.foxnews.com/us/vanderbilt-university-clinic-responds-claims-unethical-transgender-surgery-minors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 18:32:16+00:00

Tennessee lawmakers are calling for an investigation into a Vanderbilt University clinic after reports that it offers permanent hormone treatment and transgender surgeries to minors.

## Maine former Uber driver charged for sexually assaulting passenger
 - [https://www.foxnews.com/us/maine-former-uber-driver-charged-sexually-assaulting-passenger](https://www.foxnews.com/us/maine-former-uber-driver-charged-sexually-assaulting-passenger)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 18:29:59+00:00

A former Maine car service driver was charged after assaulting a passenger. The woman was intoxicated after being picked up from a nightclub.

## London cops in WhatsApp group with Sarah Everard’s murderer convicted over 'racist,' 'misogynistic' messages
 - [https://www.foxnews.com/world/london-cops-whatsapp-group-sarah-everards-murderer-convicted-racist-misogynistic-messages](https://www.foxnews.com/world/london-cops-whatsapp-group-sarah-everards-murderer-convicted-racist-misogynistic-messages)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 18:28:54+00:00

A London officer and an ex-police constable were found guilty of swapping “grossly offensive” messages about rape and Tasing people in a WhatsApp group with Sarah Everard’s murderer.

## Alabama woman who allegedly let dangerous dogs run wild, leading to 2 deaths, has been charged
 - [https://www.foxnews.com/us/alabama-woman-let-dogs-run-wild-leading-two-deaths-charged](https://www.foxnews.com/us/alabama-woman-let-dogs-run-wild-leading-two-deaths-charged)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 18:22:34+00:00

An Alabama woman who allegedly let dogs run wild, leading to two deaths, has been charged. Brandy Lee Dowdy was indicted by a Franklin County grand jury for the deaths.

## 4 victims identified in fatal crash involving car, tractor-trailer in Arizona
 - [https://www.foxnews.com/us/4-victims-identified-fatal-crash-involving-car-tractor-trailer-arizona](https://www.foxnews.com/us/4-victims-identified-fatal-crash-involving-car-tractor-trailer-arizona)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 18:20:51+00:00

Four people have been identified in a fatal crash where a big rig landed on top of their car in Sedona, Arizona. The victims were overseas visitors from India.

## Tinder dating app connects rescue dogs to forever homes in honor of National Dog Week
 - [https://www.foxnews.com/lifestyle/tinder-dating-app-connects-rescue-dogs-forever-homes-honor-national-dog-week](https://www.foxnews.com/lifestyle/tinder-dating-app-connects-rescue-dogs-forever-homes-honor-national-dog-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 18:12:07+00:00

Tinder is celebrating National Dog Week by allowing users to connect their profiles to rescue dogs in need of forever homes. Happy swiping, dog lovers!

## Southern Baptist Church cuts ties with two congregations over LGBTQ policies, 'discriminatory behavior'
 - [https://www.foxnews.com/us/southern-baptist-church-cuts-ties-two-congregations-over-lgbtq-policies-discriminatory-behavior](https://www.foxnews.com/us/southern-baptist-church-cuts-ties-two-congregations-over-lgbtq-policies-discriminatory-behavior)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 18:11:17+00:00

Southern Baptist Convention administrators cut ties with a New Jersey congregation that was cited for "alleged discriminatory behavior" and an LGBTQ-friendly church in North Carolina.

## Poynter media writer frets over CNN’s attempted pivot to center, says both sides don’t always need a voice
 - [https://www.foxnews.com/media/poynter-media-writer-frets-over-cnns-attempted-pivot-center-both-sides-dont-always-need-voice](https://www.foxnews.com/media/poynter-media-writer-frets-over-cnns-attempted-pivot-center-both-sides-dont-always-need-voice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 18:10:58+00:00

A media watchdog at the Poynter Institute penned a piece claiming CNN's apparent effort to hew to the center is potentially "dangerous" for democracy.

## Pete Davidson spotted with arm around 'Meet Cute' co-star Kaley Cuoco: 'He’s a sweet human being’
 - [https://www.foxnews.com/entertainment/pete-davidson-spotted-arm-around-meet-cute-co-star-kaley-cuoco-hes-sweet-human-being](https://www.foxnews.com/entertainment/pete-davidson-spotted-arm-around-meet-cute-co-star-kaley-cuoco-hes-sweet-human-being)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 17:29:54+00:00

"King of Staten Island" star Pete Davidson is photographed embracing Peacock's "Meet Cute" co-star Kaley Cuoco at the movie premiere in New York City.

## State Department made ‘calculation’ to prioritize Iran nuclear deal over human rights issues
 - [https://www.foxnews.com/politics/state-department-made-calculation-prioritize-iran-nuclear-deal-human-rights-issues](https://www.foxnews.com/politics/state-department-made-calculation-prioritize-iran-nuclear-deal-human-rights-issues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 17:26:46+00:00

Secretary of State Antony Blinken said talks to revive an Iran nuclear deal have gone "backward," but the State Department insists the deal remains its top priority.

## NFL upholds Mike Evans' one-game suspension, Bucs wideout to miss Packers matchup
 - [https://www.foxnews.com/sports/nfl-upholds-mike-evans-one-game-suspension-bucs-wideout-miss-packers-matchup](https://www.foxnews.com/sports/nfl-upholds-mike-evans-one-game-suspension-bucs-wideout-miss-packers-matchup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 17:24:03+00:00

Tampa Bay Buccaneers wide receiver Mike Evans will be out for Sunday's game against the Packers after the NFL rejected his appeal of a one-game suspension.

## Raymond Arroyo, 'Outnumbered' on Biden's response to Putin: The world sees 'unsteady' leadership
 - [https://www.foxnews.com/media/raymond-arroyo-outnumbered-biden-response-putin-world-sees-unsteady-leadership](https://www.foxnews.com/media/raymond-arroyo-outnumbered-biden-response-putin-world-sees-unsteady-leadership)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 17:21:35+00:00

Raymond Arroyo argues President Biden is seen as an 'unsteady' leader on the world stage, as Russia and China ramp up their alliance.

## Pac-12 commissioner open to possibility of UCLA remaining in conference
 - [https://www.foxnews.com/sports/pac-12-commissioner-open-possibility-ucla-remaining-conference](https://www.foxnews.com/sports/pac-12-commissioner-open-possibility-ucla-remaining-conference)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 17:17:56+00:00

Pac-12 commissioner George Kliavkoff discussed the possibility of UCLA remaining in the conference. UCLA and USC announced their intention to join the Big Ten in 2024 in June.

## Georgia Senate showdown: Poll suggests negative view of Democratic Party a drag on Warnock
 - [https://www.foxnews.com/politics/georgia-senate-showdown-poll-suggests-negative-view-democratic-party-drag-warnock](https://www.foxnews.com/politics/georgia-senate-showdown-poll-suggests-negative-view-democratic-party-drag-warnock)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 17:11:05+00:00

A poll of Georgia voters indicates that Democratic Sen. Raphael Warnock is viewed more favorably than Herschel Walker, but the Democratic Party's low approval is keeping the race tight.

## Cowboys for Trump cofounder appeals ruling removing him from office over Jan 6 participation
 - [https://www.foxnews.com/politics/cowboys-trump-cofounder-appeals-ruling-removing-him-from-office-jan-6-participation](https://www.foxnews.com/politics/cowboys-trump-cofounder-appeals-ruling-removing-him-from-office-jan-6-participation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 17:10:48+00:00

A New Mexico county commissioner is appealing a judge's ruling that removed him from office as a result of his participation in the January 6 Capitol Hill protest.

## NYC robbery suspect dead after hurling himself off Bronx jail barge into East River
 - [https://www.foxnews.com/us/nyc-robbery-suspect-dead-hurling-himself-bronx-jail-barge-east-river](https://www.foxnews.com/us/nyc-robbery-suspect-dead-hurling-himself-bronx-jail-barge-east-river)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 17:10:22+00:00

A New York City robbery suspect died after throwing himself off of a Bronx jail barge into the East River, representing the 14th death in NYC Department of Correction custody this year.

## Nikki Haley fires back after Sunny Hostin accused her of hiding her ethnicity: 'I embrace my Indian heritage'
 - [https://www.foxnews.com/media/nikki-haley-fires-back-sunny-hostin-accused-hiding-ethnicity-embrace-indian-heritage](https://www.foxnews.com/media/nikki-haley-fires-back-sunny-hostin-accused-hiding-ethnicity-embrace-indian-heritage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 17:04:10+00:00

Former UN ambassador Nikki Haley highlighted the left's double standard after 'The View' co-host Sunny Hostin accused her of trying to hide her Indian heritage

## Robert Sarver to begin 'process of seeking buyers' for Suns, Mercury after NBA suspension
 - [https://www.foxnews.com/sports/robert-sarver-begin-process-seeking-buyers-suns-mercury-nba-suspension](https://www.foxnews.com/sports/robert-sarver-begin-process-seeking-buyers-suns-mercury-nba-suspension)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 16:48:25+00:00

Robert Sarver said in a statement Wednesday he will begin the process of looking for buyers for the Phoenix Suns and Phoenix Mercury after he was suspended for a year by the NBA

## North Dakota man free after admitting he mowed down 'Republican' teen over politics, records show
 - [https://www.foxnews.com/us/north-dakota-man-freed-50k-bond-fatally-striking-republican-extremist-car-records-show](https://www.foxnews.com/us/north-dakota-man-freed-50k-bond-fatally-striking-republican-extremist-car-records-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 16:36:17+00:00

The North Dakota man accused of hitting an 18-year-old with his car following a "political dispute" early Sunday morning posted $50,000 bond and was released from jail.

## Seahawks' Pete Carroll says its time to 'trust' Geno Smith: 'We don’t need to hold him back at all'
 - [https://www.foxnews.com/sports/seahawks-pete-carroll-says-time-trust-geno-smith-we-dont-need-hold-him-back-all](https://www.foxnews.com/sports/seahawks-pete-carroll-says-time-trust-geno-smith-we-dont-need-hold-him-back-all)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 16:28:04+00:00

Seattle Seahawks head coach Pete Carroll expressed his confidence in quarterback Geno Smith after a tough loss against the San Francisco 49ers in Week 2.

## NH teens accused of carving racially motivated messages in bathroom, targeting Black student
 - [https://www.foxnews.com/us/nh-teens-accused-carving-racially-motivated-messages-bathroom-targeting-black-student](https://www.foxnews.com/us/nh-teens-accused-carving-racially-motivated-messages-bathroom-targeting-black-student)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 16:24:52+00:00

Two 17-year-olds in New Hampshire have allegedly been caught carving racially motivated messages in their high school bathroom, targeting a Black student.

## Kansas man admits to running illegal autopsy scheme, sentenced to nearly 6 years in prison
 - [https://www.foxnews.com/us/kansas-man-admits-running-illegal-autopsy-scheme-sentenced-nearly-6-years-prison](https://www.foxnews.com/us/kansas-man-admits-running-illegal-autopsy-scheme-sentenced-nearly-6-years-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 16:24:04+00:00

A Kansas man has been sentenced to nearly 6 years in prison for wide fraud after admitting to running an illegal autopsy scheme. He pleaded guilty in May as part of a plea deal.

## NYC crime surge leaves former NY gov 'extremely worried' businesses will flee 'frightened' city
 - [https://www.foxnews.com/media/nyc-crime-surge-former-ny-gov-extremely-worried-businesses-flee-frightened-city](https://www.foxnews.com/media/nyc-crime-surge-former-ny-gov-extremely-worried-businesses-flee-frightened-city)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 16:23:51+00:00

Former New York Gov. David Paterson weighs in on the rising crime plaguing New York City and shares his concern that it will drive away businesses.

## San Francisco police to soon monitor private cameras in real time
 - [https://www.foxnews.com/us/san-francisco-police-soon-monitor-private-cameras-real-time](https://www.foxnews.com/us/san-francisco-police-soon-monitor-private-cameras-real-time)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 16:22:43+00:00

San Francisco police will soon be able to access and monitor private cameras in real time. The pilot program will run a trial period that would last 15 months.

## Three-time Pro Bowler Joe Haden to sign one-day contract with Browns, retire: report
 - [https://www.foxnews.com/sports/three-time-pro-bowler-joe-haden-to-sign-one-day-contract-with-browns-retire-report](https://www.foxnews.com/sports/three-time-pro-bowler-joe-haden-to-sign-one-day-contract-with-browns-retire-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 16:19:13+00:00

Three-time Pro Bowl cornerback Joe Haden will sign a one-day contract with the Cleveland Browns and retire after 12 NFL seasons. Haden was drafted by the Browns in 2010.

## Iranian president claims 'America trampled upon the nuclear accord,' wants to revive nuclear deal
 - [https://www.foxnews.com/politics/iranian-president-claims-america-trampled-upon-nuclear-accord-wants-revive-nuclear-deal](https://www.foxnews.com/politics/iranian-president-claims-america-trampled-upon-nuclear-accord-wants-revive-nuclear-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 16:17:23+00:00

The President of Iran announced at the U.N. General Assembly that Iran is serious about reviving a deal to limit its nuclear program, but is skeptical of the U.S. keeping its promises.

## Trace Gallagher named next anchor of 'Fox News @ Night'
 - [https://www.foxnews.com/media/trace-gallagher-named-next-anchor-fox-news-night](https://www.foxnews.com/media/trace-gallagher-named-next-anchor-fox-news-night)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 16:17:20+00:00

Trace Gallagher has been named the next anchor of popular nightly newscast “FOX News @ Night," and will continue to serve as a breaking news correspondent.

## Putin's call for Russian conscripts will require arms Moscow doesn't have, NATO chief says
 - [https://www.foxnews.com/world/putin-call-russian-conscripts-will-require-arms-moscow-doesnt-have-nato-chief-says](https://www.foxnews.com/world/putin-call-russian-conscripts-will-require-arms-moscow-doesnt-have-nato-chief-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 16:15:58+00:00

NATO Secretary General Jens Stoltenberg said Russian President Vladimir Putin's call for conscripts to fight in Ukraine means it will need to arms soldiers with equipment it doesn't have.

## New York AG sues Trump over fraud allegations
 - [https://www.foxnews.com/politics/new-york-ag-sues-trump-fraud-allegations](https://www.foxnews.com/politics/new-york-ag-sues-trump-fraud-allegations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 15:39:24+00:00

New York Attorney General Letitia James filed a lawsuit Wednesday agaist former President Donald Trump, as well as various family members and associates.

## Kirby says US not at war with Russia despite Putin's nuclear threat: 'Nothing can be farther from the truth'
 - [https://www.foxnews.com/media/kirby-says-us-war-russia-putins-nuclear-threat-nothing-farther-truth](https://www.foxnews.com/media/kirby-says-us-war-russia-putins-nuclear-threat-nothing-farther-truth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 15:37:58+00:00

The White House reiterated the U.S. is not at war with Russia over Ukraine on "America's Newsroom," despite Putin's threat to use nuclear weapons.

## 2-year-old wounded in drive-by shooting, dies hours later in Michigan
 - [https://www.foxnews.com/us/2-year-old-wounded-drive-shooting-dies-hours-later-michigan](https://www.foxnews.com/us/2-year-old-wounded-drive-shooting-dies-hours-later-michigan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 15:36:12+00:00

A 2-year-old in Michigan died hours after being wounded in a drive-by shooting. Officer's say that multiple shots were fired during the shooting.

## Biden calls on UN to expand permanent members of Security Council
 - [https://www.foxnews.com/politics/biden-calls-un-expand-permanent-members-security-council](https://www.foxnews.com/politics/biden-calls-un-expand-permanent-members-security-council)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 15:32:28+00:00

President Biden called on the UN to expand the number of permanent members of the Security Council as Russia again expanded its war effort in Ukraine.

## Biden in UN speech accuses Russia of 'extremely significant' violation of international charter
 - [https://www.foxnews.com/politics/biden-un-speech-accuses-russia-extremely-significant-violation-international-charter](https://www.foxnews.com/politics/biden-un-speech-accuses-russia-extremely-significant-violation-international-charter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 15:31:24+00:00

President Biden accused Russia of an “extremely significant” violation of the United Nations international charter and slammed Russian President Vladimir Putin for his war on Ukraine.

## 5 arrested as Boston climate protesters block traffic, organizers say 'We're sorry'
 - [https://www.foxnews.com/us/5-arrested-boston-climate-protesters-block-traffic](https://www.foxnews.com/us/5-arrested-boston-climate-protesters-block-traffic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 15:30:51+00:00

A climate protest in Boston aimed at banning new fossil fuel infrastructure in Massachusetts has blocked commuter traffic, leading state police to make multiple arrests.

## Republican representing Waukesha introduces bill targeting 'pro-criminal, weak bail laws'
 - [https://www.foxnews.com/politics/republican-representing-waukesha-introduces-bill-targeting-pro-criminal-weak-bail-laws](https://www.foxnews.com/politics/republican-representing-waukesha-introduces-bill-targeting-pro-criminal-weak-bail-laws)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 15:29:47+00:00

Rep. Scott Fitzgerald, R-Wis., introduced bail reform legislation Wednesday that would strip federal funding from local jurisdictions that have lenient bail practices.

## Taylor Swift reveals a 'Midnights' song title and her songwriting secret
 - [https://www.foxnews.com/entertainment/taylor-swift-reveals-midnights-song-title-songwriting-secret](https://www.foxnews.com/entertainment/taylor-swift-reveals-midnights-song-title-songwriting-secret)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 15:28:56+00:00

Taylor Swift explained how she categorizes her song lyrics hours before she announced the name of track 13 on her upcoming album "Midnights." Swift recieved a songwriters award Tuesday.

## Karine Jean-Pierre calls out GOP governors, says Biden admin has 'always been ready' to act on immigration
 - [https://www.foxnews.com/media/karine-jean-pierre-calls-out-gop-governors-says-biden-admin-always-been-ready-act-immigration](https://www.foxnews.com/media/karine-jean-pierre-calls-out-gop-governors-says-biden-admin-always-been-ready-act-immigration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 15:24:36+00:00

White House Press Secretary Karine Jean-Pierre told MSNBC's Alex Wagner on Tuesday that the Biden administration has "always been ready" to act on immigration.

## Florida woman jogging on trail fights off man who tackled her to ground, bit her: police
 - [https://www.foxnews.com/us/florida-woman-jogging-trail-fights-off-man-who-tackled-her-ground-bit-her-police](https://www.foxnews.com/us/florida-woman-jogging-trail-fights-off-man-who-tackled-her-ground-bit-her-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 15:19:20+00:00

William Paul Stamper, 19, was been arrested in Seminole County, Florida, after he allegedly attacked a 22-year-old woman who was jogging on Monday night, authorities said.

## Clay Travis: American taxpayers deserve their money back for COVID vaccines
 - [https://www.foxnews.com/media/clay-travis-american-taxpayers-deserve-money-back-covid-vaccines](https://www.foxnews.com/media/clay-travis-american-taxpayers-deserve-money-back-covid-vaccines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 14:38:59+00:00

OutKick founder Clay Travis explains the widespread damage of vaccine mandates on the economy, says the shots did not work as advertised.

## Jalen Hill, ex-UCLA standout basketball player, dead at 22
 - [https://www.foxnews.com/sports/jalen-hill-ex-ucla-standout-basketball-player-dead](https://www.foxnews.com/sports/jalen-hill-ex-ucla-standout-basketball-player-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 14:38:57+00:00

Jalen Hill, a former standout college basketball player at UCLA, has died at he age of 22, his family said. Hill went missing recently in Costa Rica.

## Indiana police apprehend man allegedly armed with a rifle in Bloomington sewers
 - [https://www.foxnews.com/us/indiana-police-apprehend-man-allegedly-armed-with-a-rifle-in-bloomington-sewers](https://www.foxnews.com/us/indiana-police-apprehend-man-allegedly-armed-with-a-rifle-in-bloomington-sewers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 14:38:42+00:00

Indiana police apprehended the man who was in the Bloomington sewers. The suspect was safely removed and transported to the hospital to be evaluated.

## Boston suburb high school bans ‘political’ items, including BLM, pride flags
 - [https://www.foxnews.com/us/boston-suburb-high-school-bans-political-items-blm-pride-flags](https://www.foxnews.com/us/boston-suburb-high-school-bans-political-items-blm-pride-flags)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 14:33:21+00:00

School officials at Stoughton High, located outside of Boston, banned faculty from posting political items in classrooms, such as pro-police thin blue line, pride, and BLM flags.

## Ex-Minneapolis cop Thomas Lane sentenced to 3 years on manslaughter in George Floyd death
 - [https://www.foxnews.com/us/ex-minneapolis-cop-thomas-lane-sentenced-3-years-manslaughter-george-floyd-death](https://www.foxnews.com/us/ex-minneapolis-cop-thomas-lane-sentenced-3-years-manslaughter-george-floyd-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 14:23:44+00:00

Ex-Minneapolis police officer Thomas Lane was sentenced Wednesday to 3 years on an aiding and abetting manslaughter state charge in George Floyd's death, meaning no additional jail time.

## Democratic mayor of El Paso says bussing migrants to other US cities should not be political
 - [https://www.foxnews.com/media/democratic-mayor-el-paso-bussing-migrants-us-cities-political](https://www.foxnews.com/media/democratic-mayor-el-paso-bussing-migrants-us-cities-political)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 14:19:23+00:00

El Paso Mayor Oscar Leeser shares why his city transports migrants to sanctuary cities and calls on leaders to stop politicizing the border crisis.

## Los Angeles prosecutors: More evidence needed in Marilyn Manson sexual abuse investigation
 - [https://www.foxnews.com/entertainment/los-angeles-prosecutors-more-evidence-needed-marilyn-manson-sexual-abuse-investigation](https://www.foxnews.com/entertainment/los-angeles-prosecutors-more-evidence-needed-marilyn-manson-sexual-abuse-investigation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 14:17:50+00:00

After a 19-month probe, detectives turned in the results to prosecutors, who said Tuesday more evidence is needed before they can consider criminal charges against Marilyn Manson.

## UNC quarterback makes snide remark about in-state rival NC State, apologizes
 - [https://www.foxnews.com/sports/unc-quarterback-makes-snide-remark-about-in-state-rival-nc-state-apologizes](https://www.foxnews.com/sports/unc-quarterback-makes-snide-remark-about-in-state-rival-nc-state-apologizes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 14:09:39+00:00

North Carolina freshman quarterback took a jab at in-state rival NC State on Tuesday, later apologizing for his remark. Maye is in his first season as starting quarterback.

## Democrats in key midterm state say 'threats to democracy' more important abortion, economy ahead of midterms
 - [https://www.foxnews.com/politics/democrats-key-midterm-state-say-threats-democracy-more-important-abortion-economy-ahead-midterms](https://www.foxnews.com/politics/democrats-key-midterm-state-say-threats-democracy-more-important-abortion-economy-ahead-midterms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 14:03:13+00:00

Threats to the democracy was the most important factor to likely Democrat voters in Wisconsin over abortion and the economy, while the GOP's priority remains inflation.

## Andrew Cuomo bashes Biden, Democrats for not standing by him during sexual harassment scandal: 'Traumatizing'
 - [https://www.foxnews.com/media/andrew-cuomo-bashes-biden-democrats-standing-him-during-sexual-harassment-scandal-traumatizing](https://www.foxnews.com/media/andrew-cuomo-bashes-biden-democrats-standing-him-during-sexual-harassment-scandal-traumatizing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 14:01:44+00:00

Former New York Gov. Andrew Cuomo unloaded on his former political allies in an explosive interview with a New York Post writer, saying he felt abandoned.

## North Carolina's lottery numbers for Tuesday, Sept. 20
 - [https://www.foxnews.com/us/north-carolinas-lottery-numbers-tuesday-sept-20](https://www.foxnews.com/us/north-carolinas-lottery-numbers-tuesday-sept-20)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 13:37:35+00:00

Mega Millions jackpot is $301,000,000 and Powerball reaches $251,000,000. North Carolina's Lucky For Life lottery numbers for Tuesday, Sept. 20 are 5-26-28-37-42, Lucky Ball: 10

## Beer shortages feared after extinct underground volcano contaminated CO2 reservoir: 'Big concern'
 - [https://www.foxnews.com/media/beer-shortages-feared-extinct-underground-volcano-contaminated-co2-reservoir-big-concern](https://www.foxnews.com/media/beer-shortages-feared-extinct-underground-volcano-contaminated-co2-reservoir-big-concern)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 13:37:13+00:00

Ronn Friedlander, co-CEO of Aeronaut Brewing Company in Massachusetts, shared how unprecedented carbon dioxide shortages could affect breweries on 'Fox & Friends First.'

## North Carolina Highway Patrol sergeant shoots kidnapping suspect
 - [https://www.foxnews.com/us/north-carolina-highway-patrol-sergeant-shoots-kidnapping-suspect](https://www.foxnews.com/us/north-carolina-highway-patrol-sergeant-shoots-kidnapping-suspect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 13:35:53+00:00

North Carolina Highway Patrol Sgt. Aaron Johnson fatally shot a kidnapping suspect. The woman shot at the Sergeant first before he returned fire striking her.

## Japanese man sets himself on fire to protest former PM Shinzo Abe’s funeral
 - [https://www.foxnews.com/world/japanese-man-sets-himself-fire-protest-former-shinzo-abe-pms-funeral](https://www.foxnews.com/world/japanese-man-sets-himself-fire-protest-former-shinzo-abe-pms-funeral)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 13:32:21+00:00

A Japanese man deliberately doused himself in oil and set himself on fire to oppose the government’s decisions to hold a funeral for former Prime Minister Shinzo Abe.

## GA driver who fired a gun into a moving pickup truck, killing a girl, has been sentenced to 10 years in prison
 - [https://www.foxnews.com/us/ga-driver-fired-gun-moving-pickup-truck-killing-girl-been-sentenced-10-years-prison](https://www.foxnews.com/us/ga-driver-fired-gun-moving-pickup-truck-killing-girl-been-sentenced-10-years-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 13:30:54+00:00

A GA man, who claims he was fending off a racist attack when he fatally shot a girl, has been sentenced to 10 years. His attorney argued that he was justified to shoot in self-defense.

## Japanese man sets himself on fire to protest Shinzo Abe funeral
 - [https://www.foxnews.com/world/japanese-man-sets-himself-fire-protest-shinzo-abe-funeral](https://www.foxnews.com/world/japanese-man-sets-himself-fire-protest-shinzo-abe-funeral)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 13:22:48+00:00

A Japanese man believed to be in his seventies doused himself in oil and set himself on fire in protest of the state funeral for the late Prime Minster Shinzo Abe.

## Hundreds of whales beached in Australia mass stranding, officials say at least half presumed alive
 - [https://www.foxnews.com/world/hundreds-whales-beached-australia-mass-stranding-officials-say-least-half-presumed-alive](https://www.foxnews.com/world/hundreds-whales-beached-australia-mass-stranding-officials-say-least-half-presumed-alive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 13:17:53+00:00

Australian wildlife officials in the state of Tasmania mobilized a rescue team on Wednesday after about 230 whales were found stranded on the state's west coast.

## Former ICE official sends message to Mayorkas after suspected terrorists caught at border: 'He knows better'
 - [https://www.foxnews.com/media/former-ice-official-sends-message-mayorkas-suspected-terrorists-caught-border-knows-better](https://www.foxnews.com/media/former-ice-official-sends-message-mayorkas-suspected-terrorists-caught-border-knows-better)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 13:08:22+00:00

Department of Homeland Security Secretary Alejandro Mayorkas accused of 'turning a blind eye' to the 'manmade' border crisis as the migrant surge continues

## ISIS is threat to entire human race, Iraqi foreign minister says in exclusive interview
 - [https://www.foxnews.com/world/isis-threat-human-race-iraqi-foreign-minister-says-exclusive-interview](https://www.foxnews.com/world/isis-threat-human-race-iraqi-foreign-minister-says-exclusive-interview)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 13:00:52+00:00

Iraqi Foreign Minister Fuad Hussein addressed the continuing threat of ISIS, a budding partnership with China and the need for peace with Iraq's neighbors.

## 500 active-duty soldiers in Kentucky are traveling to Ohio for D-Day veteran
 - [https://www.foxnews.com/us/500-active-duty-soldiers-kentucky-traveling-ohio-d-day-veteran](https://www.foxnews.com/us/500-active-duty-soldiers-kentucky-traveling-ohio-d-day-veteran)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 12:52:42+00:00

More than 500 Fort Cambell soldiers from Kentucky are traveling to Ohio in honor of D-Day veteran James "Pee Wee" Martin. The soldiers are from the 3rd Brigade Combat Team.

## Atlanta police say missing 24-year-old woman was murdered, body disposed; second suspect remains at large
 - [https://www.foxnews.com/us/atlanta-police-say-missing-24-year-old-woman-murdered-body-disposed-second-suspect-remains-large](https://www.foxnews.com/us/atlanta-police-say-missing-24-year-old-woman-murdered-body-disposed-second-suspect-remains-large)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 12:35:46+00:00

Atlanta police announced on Tuesday that investigators believe missing 24-year-old Allahnia Lenoir was murdered and that her body was disposed of, as a second suspect remains at-large.

## Hurricane Fiona forecast to track toward Bermuda
 - [https://www.foxnews.com/us/hurricane-fiona-forecast-track-toward-bermuda](https://www.foxnews.com/us/hurricane-fiona-forecast-track-toward-bermuda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 12:26:13+00:00

Hurricane Fiona strengthened to a Category 4 hurricane. The storm, with winds at 130 miles per hour, is forecast to track toward Bermuda on Wednesday.

## Germany raids 24 properties linked to Putin ally Usmanov
 - [https://www.foxnews.com/world/germany-raids-24-properties-linked-putin-ally-usmanov](https://www.foxnews.com/world/germany-raids-24-properties-linked-putin-ally-usmanov)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 12:21:38+00:00

German officers were ordered by the state and federal police to raid properties belonging to one of Russian oligarch, Alisher Usmanov, who is a close ally of President Vladimir Putin.

## GOP senators want info on illegal migrants’ destinations amid concerns ‘sanctuary’ cities driving surge
 - [https://www.foxnews.com/politics/gop-senators-want-info-illegal-migrants-destinations-concerns-sanctuary-cities-driving-surge](https://www.foxnews.com/politics/gop-senators-want-info-illegal-migrants-destinations-concerns-sanctuary-cities-driving-surge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 12:20:46+00:00

Six Republican senators want to know the destinations migrants are putting on their documents amid concerns about the role sanctuary cities play in the crisis.

## Oklahoma State's Mike Gundy puts onus on Oklahoma for Bedlam's end
 - [https://www.foxnews.com/sports/oklahoma-states-mike-gundy-puts-onus-oklahoma-bedlams-end](https://www.foxnews.com/sports/oklahoma-states-mike-gundy-puts-onus-oklahoma-bedlams-end)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 12:19:19+00:00

Oklahoma and Oklahoma State's rivalry series, nicknamed Bedlam, will come to an end and the blame game began Tuesday over who is really ending the games.

## Gianno Caldwell rips new Illinois law: 'This is not criminal justice reform, it's justice for criminals'
 - [https://www.foxnews.com/media/gianno-caldwell-rips-new-illinois-law-criminal-justice-reform-justice-criminals](https://www.foxnews.com/media/gianno-caldwell-rips-new-illinois-law-criminal-justice-reform-justice-criminals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 12:17:28+00:00

Fox News' Gianno Caldwell warns of the dangers of woke criminal justice reform in Illinois, where violent crime has become a crisis.

## UK defense chief says 'Ukraine is winning' no matter what propaganda Putin spins
 - [https://www.foxnews.com/world/uk-defense-chief-says-ukraine-winning-no-matter-what-propaganda-putin-spins](https://www.foxnews.com/world/uk-defense-chief-says-ukraine-winning-no-matter-what-propaganda-putin-spins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 12:15:26+00:00

U.K. Defense Secretary slapped back at a threatening overnight address by Russian President Vladimir Putin and said "Ukraine is winning" the war no matter what rhetoric he uses.

## US urges UN court to toss out Iranian frozen assets case
 - [https://www.foxnews.com/world/us-urges-un-court-toss-out-iranian-frozen-assets-case](https://www.foxnews.com/world/us-urges-un-court-toss-out-iranian-frozen-assets-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 12:13:32+00:00

The US urged the International Court of Justice to throw out a case where Iran seeks to take back frozen assets awarded by the US Supreme Court to victims of a 1983 bombing in Lebanon.

## Putin warns West: Threat to resort to nuclear weapons ‘not a bluff’
 - [https://www.foxnews.com/world/putin-warns-west-threat-resort-nuclear-weapons-not-bluff](https://www.foxnews.com/world/putin-warns-west-threat-resort-nuclear-weapons-not-bluff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 11:56:41+00:00

Russian President Vladimir Putin claimed the West made nuclear threats against Russia and warned that his own country's nuclear threats were "not a bluff."

## White House slammed for backtracking after Biden declares pandemic 'over': 'An absolutely obvious truth'
 - [https://www.foxnews.com/media/white-house-slammed-backtracking-biden-declares-pandemic-absolutely-obvious-truth](https://www.foxnews.com/media/white-house-slammed-backtracking-biden-declares-pandemic-absolutely-obvious-truth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 11:53:42+00:00

Critics ripped President Biden after White House officials clarified his 'pandemic is over' claim, saying it is 'time to be free of this pandemic'

## Hot truck: The 2023 Ford Maverick order books are closing already
 - [https://www.foxnews.com/auto/hot-truck-2023-ford-maverick-closing](https://www.foxnews.com/auto/hot-truck-2023-ford-maverick-closing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 11:33:05+00:00

The order book for the 2023 Ford Maverick are closing less than a week after it opened as Ford struggles to produce enough of the compact pickups to meet demand.

## Aaron Judge's 2022 season a 'notch above' the best of all-time, Yankees manager says
 - [https://www.foxnews.com/sports/aaron-judges-2022-season-notch-above-best-all-time-yankees-manager-says](https://www.foxnews.com/sports/aaron-judges-2022-season-notch-above-best-all-time-yankees-manager-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 11:30:10+00:00

Aaron Judge is having one of the best seasons of his career and New York Yankees manager Aaron Boone suggested where it could go down in all-time.

## Kamala Harris mocked for new word salad: 'Community banks are in the community'
 - [https://www.foxnews.com/media/kamala-harris-mocked-word-salad-community-banks-community](https://www.foxnews.com/media/kamala-harris-mocked-word-salad-community-banks-community)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 11:00:47+00:00

Kamala Harris was mocked by a variety of Twitter users in the latest example of the vice president giving an incoherent speech many on the internet found humorous.

## Ukraine's China problem, and how to solve it
 - [https://www.foxnews.com/opinion/ukraine-china-problem-how-solve-it](https://www.foxnews.com/opinion/ukraine-china-problem-how-solve-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 11:00:33+00:00

Before taxpayer dollars are spent on Ukraine’s reconstruction, there’s a serious problem: Zelenskyy opened the door to Chinese participation.

## Aaron Judge mashed 60th home run off distant relative of Yankees legend
 - [https://www.foxnews.com/sports/aaron-judge-mashed-60th-home-run-off-distant-relative-yankees-legend](https://www.foxnews.com/sports/aaron-judge-mashed-60th-home-run-off-distant-relative-yankees-legend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 11:00:26+00:00

Aaron Judge's 60th home run of the season came off a very distant relative of one of the greatest New York Yankees pitchers of all-time.

## The bald eagle: A brief history of the great conservation success story of America’s bird
 - [https://www.foxnews.com/lifestyle/bald-eagle-brief-history-great-conservation-success-story-americas-bird](https://www.foxnews.com/lifestyle/bald-eagle-brief-history-great-conservation-success-story-americas-bird)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 11:00:02+00:00

Author Jack E. Davis shares the history of the bald eagle's comeback from near extinction with Fox News Digital at the Library of Congress National Book Festival.

## Brad Pitt says debut art exhibition was born from 'brutally honest' reflection on failed relationships
 - [https://www.foxnews.com/entertainment/brad-pitt-says-debut-art-exhibition-born-brutally-honest-reflection-failed-relationships](https://www.foxnews.com/entertainment/brad-pitt-says-debut-art-exhibition-born-brutally-honest-reflection-failed-relationships)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 10:53:21+00:00

Actor Brad Pitt debuted nine pieces of artwork at an exhibition in Finland, which he said was a reflection on missteps in past relationships. It is his first art exhibition.

## Putin takes extreme action to fill ranks, unvaxxed heroes still stuck in limbo and more top headlines
 - [https://www.foxnews.com/us/putin-initiates-conscription-strengthen-counteroffensive-ukraine-russia-war](https://www.foxnews.com/us/putin-initiates-conscription-strengthen-counteroffensive-ukraine-russia-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 10:40:08+00:00

RUSSIAN ROULETTE - Putin takes extreme action to fill his ranks after Ukrainians score major battlefield victory

## Yankees fan snags Aaron Judge's milestone homer, friend makes one request
 - [https://www.foxnews.com/sports/yankees-fan-snags-aaron-judges-milestone-homer-friend-makes-one-request](https://www.foxnews.com/sports/yankees-fan-snags-aaron-judges-milestone-homer-friend-makes-one-request)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 10:28:10+00:00

Aaron Judge hit his 60th home run and the ball was recovered by a 20-year-old New York college baseball player who was with his friends at Yankee Stadium on Tuesday.

## Surveillance footage shows relative push toddler off Chicago's Navy Pier and into lake: report
 - [https://www.foxnews.com/us/surveillance-footage-shows-relative-push-toddler-off-chicagos-navy-pier-into-lake-report](https://www.foxnews.com/us/surveillance-footage-shows-relative-push-toddler-off-chicagos-navy-pier-into-lake-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 10:13:28+00:00

A 3-year-old boy is hospitalized in "very critical condition" after a female relative pushed him off of Chicago's Navy Pier and into Lake Michigan, surveillance footage reportedly showed.

## Hurricane Fiona upgraded to Category 4 as it heads away from Turks and Caicos Islands
 - [https://www.foxnews.com/weather/hurricane-fiona-upgraded-category-4-it-heads-away-turks-and-caicos-islands](https://www.foxnews.com/weather/hurricane-fiona-upgraded-category-4-it-heads-away-turks-and-caicos-islands)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 10:08:41+00:00

Hurricane Fiona became a Category 4 on Wednesday as it moves away from the Turks and Caicos Islands, which reported minimal damage and zero deaths.

## Biden to outline vision for American foreign policy at UN General Assembly with democracy as 'hallmark'
 - [https://www.foxnews.com/politics/biden-outline-vision-american-foreign-policy-un-general-assembly-democracy-hallmark](https://www.foxnews.com/politics/biden-outline-vision-american-foreign-policy-un-general-assembly-democracy-hallmark)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 10:00:42+00:00

President Biden will address the United Nations General Assembly in New York Wednesday morning, where he plans to describe his “vision for American foreign policy."

## Ukraine braces for Russia's fury over military losses in Kharkiv
 - [https://www.foxnews.com/world/ukraine-braces-moscows-fury-over-military-losses-kharkiv](https://www.foxnews.com/world/ukraine-braces-moscows-fury-over-military-losses-kharkiv)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 10:00:27+00:00

A top Ukrainian defense adviser said Ukraine needs to "keep the pressure on" Russia as Kyiv's military makes advances and liberates towns in Kharkiv.

## Steve Doocy's lasagna grilled cheese sandwich recipe: 'Best darn sandwich of my life'
 - [https://www.foxnews.com/lifestyle/steve-doocy-lasagna-grilled-cheese-sandwich-recipe-best-darn-sandwich-life](https://www.foxnews.com/lifestyle/steve-doocy-lasagna-grilled-cheese-sandwich-recipe-best-darn-sandwich-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 10:00:04+00:00

"The Simply Happy Cookbook" is the newest cookbook from Steve and Kathy Doocy — and featured here is a story and recipe adapted from the book for a delicious lasagna-and-grilled-cheese sandwich.

## Kentucky school shooter, up for parole after 25 years, says he still hears voices
 - [https://www.foxnews.com/us/kentucky-school-shooter-parole-after-25-years-says-still-hears-voices](https://www.foxnews.com/us/kentucky-school-shooter-parole-after-25-years-says-still-hears-voices)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 09:45:42+00:00

Michael Carneal, who at 14 years old, killed three students and injured five at his high school in Kentucky in 1997. He said he still hears devilish voices in his head.

## Oregon couple creates wholesome 80's-themed TikTok videos with gerbils: 'Positive and uplifting'
 - [https://www.foxnews.com/entertainment/oregon-couple-creates-wholesome-80s-themed-tiktok-videos-gerbils-positive-uplifting](https://www.foxnews.com/entertainment/oregon-couple-creates-wholesome-80s-themed-tiktok-videos-gerbils-positive-uplifting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 09:24:50+00:00

Oregon couple Kyle and Marylou Bryant have created 1980's-themed TikTok videos about a gerbil named Bella. They hope the wholesome and positive show will combat negative content on the internet.

## Florida man sentenced to life in prison after sexually abusing three young girls: police
 - [https://www.foxnews.com/us/florida-man-sentenced-life-prison-after-sexually-abusing-three-young-girls-police](https://www.foxnews.com/us/florida-man-sentenced-life-prison-after-sexually-abusing-three-young-girls-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 08:54:52+00:00

DeFuniak Springs, Florida, resident Jacob Ramirez was found guilty of sexually abusing three underage girls and sentenced to life in prison, according to Walton County Sheriff's Office.

## Alabama toddler dies after being left in hot car, 27th in US this year
 - [https://www.foxnews.com/us/alabama-toddler-dies-after-left-inside-hot-car](https://www.foxnews.com/us/alabama-toddler-dies-after-left-inside-hot-car)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 08:39:58+00:00

Authorities in east Alabama are investigating the death of a two-year-old boy after he was found dead in a car outside of a day care on Tuesday. Police believe he died of heatstroke.

## California prosecutors rest case against suspects in Kristin Smart murder trial
 - [https://www.foxnews.com/us/california-prosecutors-rest-case-suspects-kristin-smart-murder-trial](https://www.foxnews.com/us/california-prosecutors-rest-case-suspects-kristin-smart-murder-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 08:20:16+00:00

Prosecutors rested their case against Paul and Ruben Flores on Tuesday, as the two men are tried for the murder and disappearance of college student Kristin Smart in 1996.

## Gavin Newsom says GOP governors are ‘doubling down on stupid’ in latest attack
 - [https://www.foxnews.com/politics/gavin-newsom-says-gop-governors-doubling-down-stupid-latest-attack](https://www.foxnews.com/politics/gavin-newsom-says-gop-governors-doubling-down-stupid-latest-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 08:08:22+00:00

California Gov. Gavin Newsom said GOP governors were "doubling down on stupid" in his latest escalation with some of his conservative counterparts, including Florida Gov. Ron DeSantis.

## California mom, daughter plead not guilty to murder after woman dies in illegal buttocks procedure
 - [https://www.foxnews.com/us/california-mom-daughter-plead-not-guilty-murder-after-woman-dies-illegal-buttocks-procedure](https://www.foxnews.com/us/california-mom-daughter-plead-not-guilty-murder-after-woman-dies-illegal-buttocks-procedure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 08:01:53+00:00

A California mother and daughter have pleaded not guilty to the murder of a woman who died during a buttocks augmentation procedure in October 2019.

## Aaron Judge reacts to hitting 60th home run of season: 'An incredible honor'
 - [https://www.foxnews.com/sports/aaron-judge-reacts-hitting-60th-home-run-season-incredible-honor](https://www.foxnews.com/sports/aaron-judge-reacts-hitting-60th-home-run-season-incredible-honor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 07:21:34+00:00

Aaron Judge became the sixth person in MLB history to hit 60 home runs in a single season on Tuesday. What was even sweeter is it kickstarted a huge Yankees comeback.

## Putin initiates conscription to bolster military invasion as Ukraine mounts counteroffensive
 - [https://www.foxnews.com/world/putin-initiates-conscription-bolster-military-invasion-ukraine-mounts-counteroffensive](https://www.foxnews.com/world/putin-initiates-conscription-bolster-military-invasion-ukraine-mounts-counteroffensive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 06:42:05+00:00

Russia has initiated conscription of some of its citizens amid its ongoing invasion of Ukraine. The announcement will require some citizens to serve in the war effort.

## Fan arrested, charged after allegedly hitting Browns owner Jimmy Haslam with water bottle
 - [https://www.foxnews.com/sports/fan-arrested-charged-after-allegedly-hitting-browns-owner-jimmy-haslam-water-bottle](https://www.foxnews.com/sports/fan-arrested-charged-after-allegedly-hitting-browns-owner-jimmy-haslam-water-bottle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 06:03:44+00:00

Jimmy Haslam, the owner of the Cleveland Browns, was hit by a water bottle after an allegedly drunk fan chucked it at him during Sunday's game against the New York Jets.

## Martha's Vineyard church answered call to aid migrants: 'We can take in all' of them
 - [https://www.foxnews.com/lifestyle/marthas-vineyard-church-answered-call-aid-migrants-we-can-take-all](https://www.foxnews.com/lifestyle/marthas-vineyard-church-answered-call-aid-migrants-we-can-take-all)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 06:00:56+00:00

The Rev. Chip Seadale and others explained the response from St. Andrew's Episcopal Church to the migrants who were on Martha's Vineyard for less than 48 hours.

## New online platform helps connect parents with teachers of their choice
 - [https://www.foxnews.com/media/new-online-platform-helps-connect-parents-teachers-choice](https://www.foxnews.com/media/new-online-platform-helps-connect-parents-teachers-choice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 06:00:55+00:00

Teachers1on1 is a new platform that is connecting parents with teachers across the country to help tutor students in the subjects of their choice.

## Illinois's Safe-T Act ending cash bail will also further 'handcuff' police with new provisions: experts
 - [https://www.foxnews.com/us/illinoiss-safe-t-act-ending-cash-bail-further-handcuff-police-new-provisions-experts](https://www.foxnews.com/us/illinoiss-safe-t-act-ending-cash-bail-further-handcuff-police-new-provisions-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 06:00:30+00:00

Chicago crime experts told Fox News Digital that the controversial Safe-T Act set to take effect in Illinois will "handcuff" police officers when morale is already low.

## Is bussing migrants ethical? New Yorkers weigh in
 - [https://www.foxnews.com/us/bussing-migrants-ethical-new-yorkers-weigh](https://www.foxnews.com/us/bussing-migrants-ethical-new-yorkers-weigh)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 06:00:27+00:00

People in New York weighed in on the bussing illegal immigrants across the country following Florida and Texas governors sending migrants to progressive states.

## The end of academia's Gilded Age
 - [https://www.foxnews.com/opinion/end-academia-gilded-age](https://www.foxnews.com/opinion/end-academia-gilded-age)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 06:00:21+00:00

America has a student loan problem, the real issue is that the cost of college tuition has skyrocketed and the value of a diploma has plummeted.

## Biden declared the pandemic over, but unvaxxed Air Force pilots are still grounded
 - [https://www.foxnews.com/politics/biden-declared-pandemic-over-unvaxxed-air-force-pilots-still-grounded](https://www.foxnews.com/politics/biden-declared-pandemic-over-unvaxxed-air-force-pilots-still-grounded)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 06:00:18+00:00

Despite Biden's claim the COVID-19 pandemic is now "over," Air Force pilots seeking religious exemptions to the vaccine mandate are being grounded from flying.

## Royal snub? The real reason Prince Harry's uniform was missing the symbol honoring the Queen
 - [https://www.foxnews.com/entertainment/royal-snub-real-reason-prince-harrys-uniform-missing-symbol-honoring-queen](https://www.foxnews.com/entertainment/royal-snub-real-reason-prince-harrys-uniform-missing-symbol-honoring-queen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 06:00:00+00:00

The Duke of Sussex served 10 years in the British Army and was deployed to Afghanistan twice. He was allowed to wear his uniform once during the mourning period for Queen Elizabeth II.

## Chicago suburb rejects Harrison Ford statue over cost, actor's bullying memories
 - [https://www.foxnews.com/entertainment/chicago-suburb-rejects-harrison-ford-statue-over-cost-actors-bullying-memories](https://www.foxnews.com/entertainment/chicago-suburb-rejects-harrison-ford-statue-over-cost-actors-bullying-memories)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 05:44:18+00:00

Harrison Ford will not get a statue in his honor in the Illinois city where he grew up. Park Ridge, a Chicago suburb, nixed the statue because Ford said he was bullied in the town.

## Houston police find father shot dead, 2-year-old deceased in backseat of SUV: 'Hardest thing I've ever done'
 - [https://www.foxnews.com/us/houston-police-find-father-shot-dead-2-year-old-deceased-backseat-suv-hardest-thing-ever-done](https://www.foxnews.com/us/houston-police-find-father-shot-dead-2-year-old-deceased-backseat-suv-hardest-thing-ever-done)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 04:56:21+00:00

Houston police located a dead man and his 2-year-old son on Tuesday. Investigators said a suspect shot the adult before stealing his SUV and kidnapping the child.

## Tyrus: People were behind him because he was different
 - [https://www.foxnews.com/media/tyrus-people-behind-him-because-different](https://www.foxnews.com/media/tyrus-people-behind-him-because-different)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 04:37:28+00:00

Tyrus discussed with Greg Gutfeld and guests why voters backed Trump and how he resonated with them because he was not a politician on "Gutfeld!"

## GREG GUTFELD: Media has shifted focus 'from Don to Ron'
 - [https://www.foxnews.com/opinion/greg-gutfeld-media-shifted-focus-don-ron](https://www.foxnews.com/opinion/greg-gutfeld-media-shifted-focus-don-ron)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 04:32:08+00:00

Greg Gutfeld discussed the mainstream media's portrayal of Republican candidates, most recently Florida Gov. Ron DeSantis on 'Gutfeld!'

## Aaron Judge's 60th home run sparks miraculous Yankees comeback win against Pirates
 - [https://www.foxnews.com/sports/aaron-judge-60th-home-run-sparks-miraculous-yankees-comeback-win-pirates](https://www.foxnews.com/sports/aaron-judge-60th-home-run-sparks-miraculous-yankees-comeback-win-pirates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 04:27:42+00:00

New York Yankees slugger Aaron Judge provided the spark with his 60th home run of the season, and Giancarlo Stanton hit a walk-off grand slam to defeat the Pittsburgh Pirates.

## Why Biden will not run for re-election in 2024: Ari Fleischer
 - [https://www.foxnews.com/media/biden-run-re-election-2024-ari-fleischer](https://www.foxnews.com/media/biden-run-re-election-2024-ari-fleischer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 04:18:00+00:00

Fox News contributor Ari Fleischer predicted whether or not President Biden will seek to run for the presidency again in 2024 on "The Ingraham Angle."

## El Paso food banks, advocacy groups say they’re running out of resources due to overwhelming migrant surge
 - [https://www.foxnews.com/us/el-paso-food-banks-advocacy-groups-say-theyre-running-out-resources-due-overwhelming-migrant-surge](https://www.foxnews.com/us/el-paso-food-banks-advocacy-groups-say-theyre-running-out-resources-due-overwhelming-migrant-surge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 04:04:55+00:00

The border town of El Paso, Texas, is overwhelmed by the flood of migrants crossing into the U.S. from Mexico. Local food banks and advocacy groups said they're running out of all resources.

## On this day in history, Sept. 21, 1780, Benedict Arnold betrays cause of American independence
 - [https://www.foxnews.com/lifestyle/this-day-history-sept-21-1780-benedict-arnold-betrays-cause-american-independence](https://www.foxnews.com/lifestyle/this-day-history-sept-21-1780-benedict-arnold-betrays-cause-american-independence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 04:02:13+00:00

American officer Benedict Arnold met in secret with British Major John Andre on Sept. 21, 1780, with a plot to trade the American stronghold at West Point for cash amid the American Revolution.

## Mom of 8 says inflation makes her spend more on groceries than mortgage: When are rising prices going to stop?
 - [https://www.foxnews.com/media/mom-8-says-inflation-makes-spend-more-groceries-mortgage-when-rising-prices-going-stop](https://www.foxnews.com/media/mom-8-says-inflation-makes-spend-more-groceries-mortgage-when-rising-prices-going-stop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 03:45:37+00:00

Fox News host Laura Ingraham spoke with a mother of eight to understand the impact a 40-year-high inflation rate is having on families across the country.

## LAURA INGRAHAM: They don't ever want it to end because more emergencies equal more government dependency
 - [https://www.foxnews.com/media/laura-ingraham-ever-want-end-more-emergencies-equal-more-government-dependency](https://www.foxnews.com/media/laura-ingraham-ever-want-end-more-emergencies-equal-more-government-dependency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 03:37:23+00:00

Laura Ingraham discusses how the White House and Democrats walked back President Biden's comment about the pandemic to maintain power through emergency on "The Ingraham Angle."

## WSJ editorial slams Newsom for climate agenda, argues his policies 'could destroy tens of thousands of jobs'
 - [https://www.foxnews.com/media/wsj-editorial-slams-newsom-climate-agenda-argues-his-policies-could-destroy-tens-thousands-jobs](https://www.foxnews.com/media/wsj-editorial-slams-newsom-climate-agenda-argues-his-policies-could-destroy-tens-thousands-jobs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 03:14:16+00:00

The Wall Street Journal editorial board published an article that criticized California Governor Gavin Newsom for his restrictive energy policies in an effort to combat climate change.

## Larry Kudlow: How the left's regulatory assault on fossil fuels epitomizes socialism
 - [https://www.foxnews.com/media/larry-kudlow-lefts-regulatory-assault-fossil-fuels-socialism](https://www.foxnews.com/media/larry-kudlow-lefts-regulatory-assault-fossil-fuels-socialism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 03:00:02+00:00

Fox Business host Larry Kudlow slammed the the Biden administration's energy policies, as inflation numbers undermine President Biden's claims of economic success.

## 'Late Show' host Stephen Colbert blasts 'gaping a--hole' Ron DeSantis
 - [https://www.foxnews.com/media/late-show-host-stephen-colbert-blasts-gaping-a-hole-ron-desantis](https://www.foxnews.com/media/late-show-host-stephen-colbert-blasts-gaping-a-hole-ron-desantis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:59:48+00:00

“Late Show” host Stephen Colbert further attacked Gov. Ron DeSantis as a “gaping a—hole” on Monday for moving illegal immigrants to Martha’s Vineyard.

## SEAN HANNITY: This is a new record for the Biden administration this year
 - [https://www.foxnews.com/media/sean-hannity-new-record-biden-administration-this-year](https://www.foxnews.com/media/sean-hannity-new-record-biden-administration-this-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:52:59+00:00

Sean Hannity discusses how dire the illegal immigration situation at the border has become because of the Biden administration's policies on "Hannity."

## Lanternflies from China causing millions of dollars in damage to US agriculture: expert
 - [https://www.foxnews.com/media/lanternflies-china-causing-millions-dollars-damage-us-agriculture-expert](https://www.foxnews.com/media/lanternflies-china-causing-millions-dollars-damage-us-agriculture-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:46:58+00:00

Outdoor adventurer and expert on the invasive lanternfly outlines the threat surrounding the spotted pests on 'Tucker Carlson Tonight.'

## Lee Zeldin on rising crime: New Yorkers are hitting their breaking point
 - [https://www.foxnews.com/media/lee-zeldin-rising-crime-new-yorkers-hitting-breaking-point](https://www.foxnews.com/media/lee-zeldin-rising-crime-new-yorkers-hitting-breaking-point)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:44:48+00:00

Fox News host Sean Hannity spoke with Rep. Lee Zeldin, R-N.Y., who is running for the state's governor, about why he is the best candidate in the race.

## Aaron Judge hits 60th home run of season, putting him in elite MLB club
 - [https://www.foxnews.com/sports/aaron-judge-hits-60th-home-run-season-putting-him-elite-mlb-club](https://www.foxnews.com/sports/aaron-judge-hits-60th-home-run-season-putting-him-elite-mlb-club)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:43:08+00:00

Aaron Judge joined an elite club on Tuesday, as the New York Yankees slugger became the sixth person to hit 60 home runs in a season in MLB history.

## GOP lawmaker, ex-sheriff calls out Biden's border: Trump was right, 'they're not sending their best'
 - [https://www.foxnews.com/media/gop-lawmaker-sheriff-calls-out-biden-border-trump-right-not-sending-best](https://www.foxnews.com/media/gop-lawmaker-sheriff-calls-out-biden-border-trump-right-not-sending-best)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:38:11+00:00

Donald Trump's widely-criticized comments about illegal immigrants made during his 2015 campaign announcement have been proven true, a Texas congressman said.

## Washington Monument vandalized with vulgar message; suspect in custody
 - [https://www.foxnews.com/us/washington-monument-vandalized-vulgar-message-suspect-custody](https://www.foxnews.com/us/washington-monument-vandalized-vulgar-message-suspect-custody)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:22:29+00:00

The United States Park Police arrested a man who allegedly splashed red paint and wrote a vulgar message on the Washington Monument on Tuesday evening.

## Tennessee man wielding machete outside McDonald's has alleged history of similar altercations
 - [https://www.foxnews.com/us/tennessee-man-wielding-machete-outside-mcdonalds-alleged-history-similar-altercations](https://www.foxnews.com/us/tennessee-man-wielding-machete-outside-mcdonalds-alleged-history-similar-altercations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:20:01+00:00

A Memphis, Tennessee, man wielding a machete was arrested after a standoff with police, and he allegedly has a history of wielding knives outside restaurants.

## Slate journalist: 2016 abortion case marked the 'last truly great day for women and the legal system'
 - [https://www.foxnews.com/media/slate-journalist-2016-abortion-case-marked-last-truly-great-day-women-legal-system](https://www.foxnews.com/media/slate-journalist-2016-abortion-case-marked-last-truly-great-day-women-legal-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:19:27+00:00

Slate's Dahlia Lithwick claimed the last big abortion Supreme Court case before the Trump era was the "last truly great day for women and the legal system."

## Tucker Carlson shreds Biden over the border crisis: 'It's all his fault'
 - [https://www.foxnews.com/opinion/tucker-carlson-shreds-biden-border-crisis-all-fault](https://www.foxnews.com/opinion/tucker-carlson-shreds-biden-border-crisis-all-fault)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:19:15+00:00

Fox News host Tucker Carlson calls out President Joe Biden's handling of the crisis at the southern border after Gov. DeSantis sent migrants to Martha's Vineyard.

## Montana to comply with court order allowing transgender birth certificate changes without surgery
 - [https://www.foxnews.com/us/montana-comply-court-order-allowing-transgender-birth-certificate-changes-without-surgery](https://www.foxnews.com/us/montana-comply-court-order-allowing-transgender-birth-certificate-changes-without-surgery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:14:37+00:00

Montana's health department said it will comply with a district court's order that instructed it to allow transgender people to amend their birth certificate without undergoing surgery.

## Country singer Luke Bell's cause of death revealed
 - [https://www.foxnews.com/entertainment/country-singer-luke-bell-cause-death-revealed](https://www.foxnews.com/entertainment/country-singer-luke-bell-cause-death-revealed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:08:43+00:00

Country music singer Luke Bell died from an accidental fentanyl overdose in Tucson, Arizona in late August after he went missing. The musician was 32.

## Austin man charged with arson possibly linked to 15 separate weekend fires
 - [https://www.foxnews.com/us/austin-man-charged-arson-possibly-linked-15-separate-weekend-fires](https://www.foxnews.com/us/austin-man-charged-arson-possibly-linked-15-separate-weekend-fires)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 02:08:36+00:00

The Austin Police Department arrested a man on Sunday accused of intentionally setting fires over the weekend.

## Margot Robbie and Ryan Gosling were 'mortified' when pictures from 'Barbie' set went viral
 - [https://www.foxnews.com/entertainment/margot-robbie-ryan-gosling-mortified-pictures-barbie-set-viral](https://www.foxnews.com/entertainment/margot-robbie-ryan-gosling-mortified-pictures-barbie-set-viral)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 01:54:06+00:00

Margot Robbie and Ryan Gosling were "mortified" when paparazzi pictures of them on set filming "Barbie" went viral. The actress called it embarrassing.

## Apple in dilemma over Will Smith's 'Emancipation' movie after Oscars slap: report
 - [https://www.foxnews.com/entertainment/apple-dilemma-will-smith-emancipation-movie-oscars-slap](https://www.foxnews.com/entertainment/apple-dilemma-will-smith-emancipation-movie-oscars-slap)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 01:46:29+00:00

Apple is facing a dilemma over when to release Will Smith's new movie, "Emancipation," after the backlash he received for slapping Chris Rock at the 2022 Oscars.

## Brother of man killed by New York bodega worker in self-defense preparing to sue store: Report
 - [https://www.foxnews.com/us/brother-man-killed-new-york-bodega-worker-self-defense-preparing-sue-store](https://www.foxnews.com/us/brother-man-killed-new-york-bodega-worker-self-defense-preparing-sue-store)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 01:40:53+00:00

The brother of a man killed by a New York bodega worker in self-defense has sent a letter informing the Blue Moon convenience store he is going to sue, according to a report,.

## North Dakota man kills teen with vehicle after political dispute, claims victim was Republican 'extremist'
 - [https://www.foxnews.com/us/north-dakota-man-kills-teen-vehicle-political-dispute-victim-republican-extremist](https://www.foxnews.com/us/north-dakota-man-kills-teen-vehicle-political-dispute-victim-republican-extremist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 01:29:21+00:00

A North Dakota man said he fatally struck an 18-year-old boy with his SUV in an alley after a political argument, accusing him of being in a Republican "extremist group."

## Browns' Nick Chubb regrets scoring late touchdown before Jets' comeback
 - [https://www.foxnews.com/sports/browns-nick-chubb-regrets-scoring-late-touchdown-before-jets-comeback](https://www.foxnews.com/sports/browns-nick-chubb-regrets-scoring-late-touchdown-before-jets-comeback)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 01:28:43+00:00

After Nick Chubb's third touchdown of the day, the Cleveland Browns had a 99.9 percent chance of beating the Jets. Had he not scored, it would have been 100.

## PBS reporter: 'Doesn’t look good' that White House officials must act as Biden's 'translators' after he speaks
 - [https://www.foxnews.com/media/pbs-reporter-doesnt-look-good-white-house-officials-act-bidens-translators-speaks](https://www.foxnews.com/media/pbs-reporter-doesnt-look-good-white-house-officials-act-bidens-translators-speaks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 01:25:30+00:00

CNN guest and PBS NewsHour White House correspondent Laura Barron-Lopez argued that White House officials contradicting Biden on the COVID-19 pandemic being over undermine Biden.

## Greg Norman told not to attend PGA Tour event he founded due to LIV Golf ties
 - [https://www.foxnews.com/sports/greg-norman-not-to-attend-pga-tour-event-founded-liv-golf-ties](https://www.foxnews.com/sports/greg-norman-not-to-attend-pga-tour-event-founded-liv-golf-ties)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 01:09:18+00:00

LIV Golf CEO Greg Norman was instructed in December not to attend a PGA Tour event that he founded due to his ties with LIV Golf, he explained Tuesday.

## This is the 'story of the midterms': Josh Kraushaar
 - [https://www.foxnews.com/media/story-midterms-axios-josh-kraushaar](https://www.foxnews.com/media/story-midterms-axios-josh-kraushaar)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 01:02:58+00:00

The "Special Report" All-Star panel looked ahead to the outcomes of the approaching midterm elections and the issues driving the elections on Tuesday.

## Texas sheriff investigating DeSantis says Americans should 'embrace' migrant surge, give them jobs
 - [https://www.foxnews.com/us/texas-sheriff-investigating-desantis-americans-embrace-migrant-surge](https://www.foxnews.com/us/texas-sheriff-investigating-desantis-americans-embrace-migrant-surge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 00:58:02+00:00

Javier Salazar, the Democratic sheriff of Bexar County in Texas, said Tuesday that the solution to the ongoing migrant crisis is to open up more legal pathways.

## The bipartisan effort to craft cybersecurity legislation to combat China, Russia threats
 - [https://www.foxnews.com/media/bipartisan-effort-craft-cybersecurity-legislation-combat-china-russia-threats](https://www.foxnews.com/media/bipartisan-effort-craft-cybersecurity-legislation-combat-china-russia-threats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 00:56:03+00:00

Representatives Nancy Mace R-SC., and Ro Khanna, D-Calif., sit down to discuss inflation and immigration issues on this week's edition of 'Common Ground.'

## Florida Democratic mayor says illegal immigrants 'welcomed' in his city
 - [https://www.foxnews.com/us/florida-democratic-mayor-says-illegal-immigrants-welcomed-city](https://www.foxnews.com/us/florida-democratic-mayor-says-illegal-immigrants-welcomed-city)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 00:53:06+00:00

Florida Mayor Lauren Poe said that immigrants would be welcomed in Gainesville following the Governor Ron DeSantis' decision to place the migrants in Martha's Vineyard.

## Rand Paul rips DC establishment countering Biden on COVID: 'Not in charge of his wits' or White House
 - [https://www.foxnews.com/media/rand-paul-rips-dc-establishment-countering-biden-covid-charge-wits-white-house](https://www.foxnews.com/media/rand-paul-rips-dc-establishment-countering-biden-covid-charge-wits-white-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 00:41:31+00:00

Kentucky Republican Sen. Rand Paul called out the left for its contradiction of President Biden's declaration that the pandemic is "over" on "Jesse Watters Primetime."

## Illinois Democrat facing federal bribery charges tied to red light cameras
 - [https://www.foxnews.com/politics/illinois-democrat-facing-federal-bribery-charges-tied-red-light-cameras](https://www.foxnews.com/politics/illinois-democrat-facing-federal-bribery-charges-tied-red-light-cameras)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 00:27:10+00:00

An Illinois Democratic senator is accused of taking bribes from a red light camera company in exchange for protecting them from legislation he introduced.

## Jesse Watters shreds Biden admin: 'The cartels have never had a better business partner'
 - [https://www.foxnews.com/media/jesse-watters-shreds-biden-cartels-never-had-better-business-partner](https://www.foxnews.com/media/jesse-watters-shreds-biden-cartels-never-had-better-business-partner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 00:25:34+00:00

Fox News host Jesse Watters reacts to outrage from Democrats after Florida Gov. Ron DeSantis sent illegal migrants to Martha's Vineyard on "Jesse Watters Primetime."

## 'Dilbert' author Scott Adams says comic strip about corporate office culture removed from 77 newspapers
 - [https://www.foxnews.com/us/dilbert-author-scott-adams-says-comic-strip-about-corporate-office-culture-removed-from-77-newspapers](https://www.foxnews.com/us/dilbert-author-scott-adams-says-comic-strip-about-corporate-office-culture-removed-from-77-newspapers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 00:16:05+00:00

"Dilbert" was removed from 77 newspapers this week, its author said, citing a move by Lee Enterprises to get rid of several comics across its many publications.

## Aaron Boone chooses Yankees' Game 1 starter for postseason
 - [https://www.foxnews.com/sports/aaron-boone-chooses-yankees-game-1-starter-postseason](https://www.foxnews.com/sports/aaron-boone-chooses-yankees-game-1-starter-postseason)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 00:14:41+00:00

The New York Yankees have named Gerrit Cole as their Game 1 starter for whatever postseason series they start, Aaron Boone told the New York Post.

## Tim Allen goes viral for Biden joke
 - [https://www.foxnews.com/entertainment/tim-allen-viral-biden-joke](https://www.foxnews.com/entertainment/tim-allen-viral-biden-joke)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-21 00:10:56+00:00

Tim Allen sparked an uproar online after making a joke about President Joe Biden. The actor went viral for a wisecrack he made on Twitter after the president appeared on "60 Minutes."


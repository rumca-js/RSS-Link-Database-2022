## #39 Burning Man 2022, Ostatnie 24 godziny.
 - [https://www.youtube.com/watch?v=703p3gNp-28](https://www.youtube.com/watch?v=703p3gNp-28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIFlYVfPnvukmFOvC4JUfOg
 - date published: 2022-09-22 00:00:00+00:00

To już ostatnia część moje przygody z Burning Man 2022.
🧗🏻Wesprzyj moje przygody na patronite: https://patronite.pl/Nejtan
📷 Instagram: https://www.instagram.com/nejthan
📜 Napisz do mnie: swiatwedlugnejtana@gmail.com
🎵 Muzyka: https://share.epidemicsound.com/m7uq26

2022 Trip z  @Vlog Casha   po Florydzie https://bit.ly/3uueZGV
2021 Trip z  @Vlog Casha   po zachodzie Usa i Alaska
https://bit.ly/3D6ClpI
#swiatwedlugnejtana #nejtan


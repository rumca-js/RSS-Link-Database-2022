# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Rings of Power Episode 5 WATCH PARTY
 - [https://www.youtube.com/watch?v=TCJzbY0H0xQ](https://www.youtube.com/watch?v=TCJzbY0H0xQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-09-22 00:00:00+00:00

Continuing this new journey through Middle-earth with episode 5 of The Lord of the Rings: The Rings of Power!

HOW IT WORKS:
1) Pull up Rings of Power on your Prime Video account on your tv, computer screen, or whatever device you want to watch on.
2) Use a second screen, phone, tablet, or whatever to pull up this stream.
3) We all start playing the film at the same time, watching together, then discussing afterwards

#theringsofpower #ringsofpower #lordoftherings

## The History of Pipe-weed | Tolkien Explained | Hobbit Day 2022
 - [https://www.youtube.com/watch?v=S9LW3jf6Xlc](https://www.youtube.com/watch?v=S9LW3jf6Xlc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-09-22 00:00:00+00:00

It's Hobbit Day - Bilbo & Frodo's birthday of September 22nd - a bunch of my Tolkien YouTuber friends and I have come together to celebrate!  After learning about pipe-weed, check out the rest of the playlist: https://youtube.com/playlist?list=PLBCsLcBwXZ_olx0ws0bTUsuGZTKRX7Y27

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Tulikoura - https://www.deviantart.com/tulikoura
Matthew Stewart - http://www.matthew-stewart.com/
BellaBergolts - https://www.deviantart.com/bellabergolts
Magdalena Katanska - https://www.artstation.com/magdalenakatanska/prints  https://www.instagram.com/qualiney
Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc
Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri
Noe Leyva - https://twitter.com/NoeLeyvArt
Clemence Morisseau - https://www.artstation.com/kahirie
Edvige Faini - www.edvigefaini.com , www.facebook.com/edvige.faini , www.instagram.com/edvige_faini

The Shire, A View of Hobbiton from the Hill - Ted Nasmith
Hobbit pipe - John Howe
Green Hill Country - Ted Nasmith
Armenelos - Ralph Damiani
Andunie - Ralph Damiani
Merry - Anna Kulisz
Gandalf Returns to Hobbiton - John Howe
Strider - Weirling
Gandalf, a Light in the Dark - Matthew Stewart
The Scouring of the Shire - Tolman Cotton
JRR Tolkien - Anna Kulisz
The Brandywine - Ralph Damiani
Bree Land - Matej Cadil
In the Garden of Bag End - Matej Cadil
Bilbo Baggins - Aegeri
Bree - The White Council
At the Sign of the Prancing Pony - Ted Nasmith
At the Sign of the Prancing Pony - Tolman Cotton
Hardbottle - Matej Cadil
The Shire - John Howe
Hobbiton - Aegeri
Merry & Pippin at Isengard - Elrodimus Flash
Orthanc - Ralph Damiani
Isengard - Ivan Cavini
Pippin and Merry in Fangorn Forest - Anke Eissmann
The Voice of Isengard - Matthew Stewart
Gandalf and Frodo in Rivendell - Anke Eissmann
Storming the Bank - Ted Nasmith
Sam and Bill - Anna Kulisz
The Visitor - Aronja Art
Bilbo Leaves Bag End - Elrodimus Flash
Hobbiton - Roger Garland
Woodhall - Matej Cadil
Homeward Bound - Tolman Cotton

#hobbitday #lordoftherings #tolkien


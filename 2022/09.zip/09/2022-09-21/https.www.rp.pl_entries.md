## Europejska komisja oskarża PiS. Inwigilacja Brejzy Pegasusem kosztowała 20 mln zł - rp.pl
 - [https://www.rp.pl/polityka/art37096721-europejska-komisja-oskarza-pis-inwigilacja-brejzy-pegasusem-kosztowala-20-mln-zl](https://www.rp.pl/polityka/art37096721-europejska-komisja-oskarza-pis-inwigilacja-brejzy-pegasusem-kosztowala-20-mln-zl)
 - RSS feed: https://www.rp.pl
 - date published: 2022-09-21 06:57:44+00:00

Europejska komisja oskarża PiS. Inwigilacja Brejzy Pegasusem kosztowała 20 mln zł - rp.pl


# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## A VM that can get around Windows 11's hypervisor and VT security nonsense?
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58948](https://www.codeproject.com/script/News/View.aspx?nwid=58948)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-21 04:00:00+00:00

More virtual madness

## By Jove! Jupiter to make closest approach to Earth in 70 years next Monday
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58947](https://www.codeproject.com/script/News/View.aspx?nwid=58947)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-21 04:00:00+00:00

"It's comin' right for us!"

## Disentangling the facts from the hype of quantum computing
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58952](https://www.codeproject.com/script/News/View.aspx?nwid=58952)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-21 04:00:00+00:00

Why is the hype pile so much bigger?

## Java 19 brings new patterns to open source programming
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58950](https://www.codeproject.com/script/News/View.aspx?nwid=58950)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-21 04:00:00+00:00

Do you want cream and sugar with that coffee?

## Microsoft Azure CTO Mark Russinovich: C/C++ should be deprecated
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58945](https://www.codeproject.com/script/News/View.aspx?nwid=58945)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-21 04:00:00+00:00

More like RusTinovich, amirite?

## Microsoft commits to updating Windows 11 once per year, and also all the time
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58949](https://www.codeproject.com/script/News/View.aspx?nwid=58949)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-21 04:00:00+00:00

And whether you need it or not

## Open Web Search
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58951](https://www.codeproject.com/script/News/View.aspx?nwid=58951)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-21 04:00:00+00:00

Read about it now, because it's probably the last you'll hear of it

## Understanding Microsoft's grand vision for building the next generation of apps
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58946](https://www.codeproject.com/script/News/View.aspx?nwid=58946)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-21 04:00:00+00:00

Collaborative Apps - because everyone knows only good things come from a committee

## Want to feel old? the emoticon is 40 :-)
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58953](https://www.codeproject.com/script/News/View.aspx?nwid=58953)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-21 04:00:00+00:00

:-|

## Windows 11 22H2: How to get Microsoft's latest OS update and what's coming next
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58944](https://www.codeproject.com/script/News/View.aspx?nwid=58944)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-21 04:00:00+00:00

It's the pause (and reboots) that refreshes

## Writing unsafe .NET code without the unsafe keyword
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58954](https://www.codeproject.com/script/News/View.aspx?nwid=58954)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-21 04:00:00+00:00

"Everybody's taking the chance"


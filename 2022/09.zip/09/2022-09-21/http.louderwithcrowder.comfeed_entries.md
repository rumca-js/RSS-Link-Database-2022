# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## 'They've abandoned him': Crowder explains situation of jailed Hong Kong Catholic cardinal
 - [https://www.louderwithcrowder.com/cardinal-joseph-zen-hong-kong](https://www.louderwithcrowder.com/cardinal-joseph-zen-hong-kong)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-21 22:37:28+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31799432&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>There's a story that isn't getting enough play right now, and it involves the situation right now surrounding Cardinal Joseph Zen, who has been arrested by the Chinese government for aiding is raising funds to help pay the legal costs of individuals arrested during the pro-democracy protests that took place in 2019. If all of that wasn't 

## 'I don't need help!': Homeless take over Los Angeles, throw feces at residents
 - [https://www.louderwithcrowder.com/homeless-los-angeles-poop](https://www.louderwithcrowder.com/homeless-los-angeles-poop)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-21 22:14:14+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31799378&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>Deep blue America is starting to get upset with the consequences of its ignorant voting behaviors. You get what you vote for, and the residents and business owners on Ventura Boulevard are getting everything they've voted for and more!</p><p><a href="https://www.foxla.com/news/la-homeless-crisis-homeless-man-throws-feces-at-business-owner

## 'Highly dubious': ​Legal scholar scoffs at lawsuit against Ron DeSantis for Martha's Vineyard stunt
 - [https://www.louderwithcrowder.com/jonathan-turley-desantis-immigrant-lawsuit](https://www.louderwithcrowder.com/jonathan-turley-desantis-immigrant-lawsuit)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-21 21:51:48+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31799303&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>There are few people in academia and law who I would ever turn to for answers to questions. There are even fewer who I would seek out for answers or opinions on serious and or complicated matters. Luckily, one of them has <a href="https://jonathanturley.org/2022/09/21/three-martha-vineyard-migrants-file-lawsuit-against-desantis/" target="

## Guy who went bananas and smashed up a McDonald's with an axe wants you to know he's not a bad guy
 - [https://www.louderwithcrowder.com/mcdonalds-axe-smasher-origin-story](https://www.louderwithcrowder.com/mcdonalds-axe-smasher-origin-story)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-21 18:24:18+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31797992&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>Content involving crime being committed against people in progressive cities who vote for the progressive politicians who allow the crime is among our best content. It can be both funny and entertaining since it's not happening to you. That's because, if you're reading this, you most likely live in real America where laws are enforced. We

## Watch: Democrat sheriff investigating Ron DeSantis calls on American restaurants to hire illegal migrants
 - [https://www.louderwithcrowder.com/democrat-sheriff-san-antonio-restaurants](https://www.louderwithcrowder.com/democrat-sheriff-san-antonio-restaurants)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-21 17:36:02+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31797707&amp;width=1245&amp;height=700&amp;coordinates=0%2C38%2C0%2C80" /><br /><br /><p>A poll came out in today's New York Times. <a href="https://flvoicenews.com/nyt-poll-supermajority-support-provisions-of-floridas-parental-rights-in-education-act/" target="_blank">70% oppose teachers pushing instruction on sexual orientation and gender identity to elementary school kids</a>. I bring that up because the last time leftists

## Watch: Jean-Pierre gives all-time worst excuse for pandemic gaffe, blames Biden 'looking around' at cars
 - [https://www.louderwithcrowder.com/auto-show-karine-jean-pierre](https://www.louderwithcrowder.com/auto-show-karine-jean-pierre)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-21 16:44:46+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31797465&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>The White House let Joe Biden give an interview with <em>60  Minutes</em> and were instantly reminded why they don't let Joe Biden talk much. Every time he opens his mouth, <a href="https://www.louderwithcrowder.com/biden-60-minutes-recap" target="_blank">it takes a team of handlers to push back and say what he said isn't what he said</a>

## Mother captures man recording her daughter, her viral video helped identify him as a registered sex offender
 - [https://www.louderwithcrowder.com/walmart-mother-captures-video](https://www.louderwithcrowder.com/walmart-mother-captures-video)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-21 14:31:08+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31796920&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>This may surprise all of you at home, but not everything about TikTok is terrible. Videos on the app could be used to track down registered sex offenders who may be looking to recommit the crime. This is what happen to a mother who caught a man videotaping her daughter at a <a href="https://www.louderwithcrowder.com/walmart-miami-dade-cou

## THE VATICAN IS A COMMUNIST CRAPHOLE (Show Notes)
 - [https://www.louderwithcrowder.com/vatican-is-a-communist-craphole](https://www.louderwithcrowder.com/vatican-is-a-communist-craphole)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-21 14:18:05+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31796992&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Surprise: The Pope hates democracy! Crowder explains why the Vatican is a communist craphole. Also, Putin is threatening to bring us to nuclear war. And, hate to break the news to some of you libertarians, but your ideology doesn't work anymore. </p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="displa

## Maren Morris still won't calm down about Brittany Aldean, might boycott award show over gender joke
 - [https://www.louderwithcrowder.com/maren-morris-cma-awards](https://www.louderwithcrowder.com/maren-morris-cma-awards)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-21 13:23:15+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31796382&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>I had thought we were done with the Brittany Aldean/Instagram/what critics call 'transphobia' brouhaha. Brittany made a light hearted comment and two country singers, one of them being Maren Morris, wouldn't calm down about it. But Morris's PR team wanted to make it an issue again and got Variety to ask her about it. Now Morris may boycot

## Watch: Granny running for state senate drops patriotic campaign rap you can't help but smile at
 - [https://www.louderwithcrowder.com/rapping-granny-state-senate](https://www.louderwithcrowder.com/rapping-granny-state-senate)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-21 12:40:52+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31796272&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>Linda Paulson is taking the internet by storm. You may find yourself asking, "But Brodigan, a grandma running for state senate in Utah? How can that be?" By dropping the hottest campaign rap this cycle.</p><p>Ok, so it's less the "hottest rap" as much as the more just adorable. I defy you to watch this without smiling.</p><div class="rm-e

## WH shows how petty AF they are, lash out at the ONE REPORTER who is reporting from Biden's border crisis
 - [https://www.louderwithcrowder.com/bill-melugin-wh-complains](https://www.louderwithcrowder.com/bill-melugin-wh-complains)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-21 11:53:27+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31795854&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>Ron DeSantis' "stunt" was to force the media to pay attention to the crisis along our southern border. The border has been in crisis since Joe Biden enacted his immigration policies. The media has done its best to ignore it. <a href="https://www.louderwithcrowder.com/ron-desantis-delaware" target="_blank">That's hard to do now</a>. The Wh


# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Streamer apologizes for leaking game reveals, says he did it for clout and 'the buzz'
 - [https://www.pcgamer.com/streamer-apologizes-for-leaking-game-reveals-says-he-did-it-for-clout-and-the-buzz](https://www.pcgamer.com/streamer-apologizes-for-leaking-game-reveals-says-he-did-it-for-clout-and-the-buzz)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 22:47:14+00:00

YouTuber Dan Allen was recently revealed as The Real Insider, who leaked multiple major game reveals and broke at least one major NDA in the process.

## Project Cars 2 is gone from Steam forever
 - [https://www.pcgamer.com/project-cars-2-is-gone-from-steam-forever](https://www.pcgamer.com/project-cars-2-is-gone-from-steam-forever)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 22:37:47+00:00

The storied racing game has been delisted from Steam.

## The best wireless gaming headset in 2022
 - [https://www.pcgamer.com/best-wireless-gaming-headset](https://www.pcgamer.com/best-wireless-gaming-headset)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 22:02:35+00:00

The best wireless gaming headsets allow you to enjoy your games and music tangle-free.

## Exclusive Magic: The Gathering Unfinity card reveal: Opening Ceremony
 - [https://www.pcgamer.com/exclusive-magic-the-gathering-unfinity-card-reveal-opening-ceremony](https://www.pcgamer.com/exclusive-magic-the-gathering-unfinity-card-reveal-opening-ceremony)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 22:00:00+00:00

Let the sanctioned buffoonery begin.

## The best left-handed mouse for gaming in 2022
 - [https://www.pcgamer.com/the-best-left-handed-mouse-for-gaming-for-2019](https://www.pcgamer.com/the-best-left-handed-mouse-for-gaming-for-2019)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 21:52:31+00:00

Shopping for the best left-handed mouse for gaming doesn't have to mean wading through right-handed options that might just work.

## Overwatch 2 will make hero swapping a bigger deal despite locking them behind battle pass
 - [https://www.pcgamer.com/overwatch-2-will-make-hero-swapping-a-bigger-deal-despite-locking-them-behind-battle-pass](https://www.pcgamer.com/overwatch-2-will-make-hero-swapping-a-bigger-deal-despite-locking-them-behind-battle-pass)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 21:40:43+00:00

Last week, Blizzard defended its battle pass by saying nobody switches heroes. Today, it's encouraging hero swaps.

## The biggest leaks in PC gaming history
 - [https://www.pcgamer.com/biggest-gaming-leaks](https://www.pcgamer.com/biggest-gaming-leaks)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 20:15:01+00:00

GTA 6, Half-Life 2, The Witcher 3, and tons of other games sprung huge leaks before they launched.

## Beacon Pines is a cozy horror game that hides an emotional mystery beneath cute characters
 - [https://www.pcgamer.com/beacon-pines-is-a-cozy-horror-game-that-hides-an-emotional-mystery-beneath-cute-characters](https://www.pcgamer.com/beacon-pines-is-a-cozy-horror-game-that-hides-an-emotional-mystery-beneath-cute-characters)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 19:40:36+00:00

This spooky pre-teen mystery has great twists without being too tough.

## Saints Row's disappointing launch won't derail the future of the series
 - [https://www.pcgamer.com/saints-rows-disappointing-launch-wont-change-plans-for-the-future-of-the-series](https://www.pcgamer.com/saints-rows-disappointing-launch-wont-change-plans-for-the-future-of-the-series)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 19:32:24+00:00

The head of Embracer said he'd hoped for a better response to the game, but is confident that it will be a moneymaker.

## Kojima's made a watch with NASA, and if you pay extra it comes with a wearable face mask
 - [https://www.pcgamer.com/kojimas-made-a-watch-with-nasa-and-if-you-pay-extra-it-comes-with-a-wearable-face-mask](https://www.pcgamer.com/kojimas-made-a-watch-with-nasa-and-if-you-pay-extra-it-comes-with-a-wearable-face-mask)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 18:44:04+00:00

'Ludens Mask is a 1:1 life size collectible that is actually wearable–Everyone of us is Ludens.'

## Here's where you can find every Mending Machine in Fortnite
 - [https://www.pcgamer.com/fortnite-mending-machine-locations](https://www.pcgamer.com/fortnite-mending-machine-locations)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 16:51:23+00:00

Just what the doctor ordered.

## The Great War: Western Front is an RTS you'll win by inches, not miles
 - [https://www.pcgamer.com/the-great-war-western-front-is-an-rts-youll-win-by-inches-not-miles](https://www.pcgamer.com/the-great-war-western-front-is-an-rts-youll-win-by-inches-not-miles)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 16:25:19+00:00

Petroglyph's World War 1 strategy is all about the long game.

## Holy cow, Dark Souls 3 PC servers are offline again
 - [https://www.pcgamer.com/holy-cow-dark-souls-3-pc-servers-are-offline-again](https://www.pcgamer.com/holy-cow-dark-souls-3-pc-servers-are-offline-again)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 15:54:40+00:00

FromSoft has acknowledged that there's a problem with the servers for the Steam version of the game.

## The DHS is spending $700,000 on researching counterterrorism in games
 - [https://www.pcgamer.com/the-dhs-is-spending-dollar700000-on-researching-counterterrorism-in-games](https://www.pcgamer.com/the-dhs-is-spending-dollar700000-on-researching-counterterrorism-in-games)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 15:51:35+00:00

The research will focus on the use of big multiplayer 'social platforms' as avenues of white supremacist radicalisation.

## Steam sale dates: When is the next Steam sale?
 - [https://www.pcgamer.com/steam-sale-dates](https://www.pcgamer.com/steam-sale-dates)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 15:45:17+00:00

Dates, biggest discounts, tips, annual Steam sale dates, and more.

## This little RPG is hiding the biggest adventure I've had in years
 - [https://www.pcgamer.com/this-little-rpg-is-hiding-the-biggest-adventure-ive-had-in-years](https://www.pcgamer.com/this-little-rpg-is-hiding-the-biggest-adventure-ive-had-in-years)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 15:42:34+00:00

The most literal pen and paper RPG on PC is so relentlessly creative it puts triple-A RPGs to shame.

## Nvidia GeForce RTX 4090: Release date, price, and specs
 - [https://www.pcgamer.com/nvidia-geforce-rtx-4090-release-date-price-specs-performance](https://www.pcgamer.com/nvidia-geforce-rtx-4090-release-date-price-specs-performance)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 15:27:49+00:00

The flagship Ada Lovelace card is coming soon and packing serious power.

## Twitch refuses to give streamers a better deal, despite pressure from users
 - [https://www.pcgamer.com/twitch-refuses-to-give-streamers-a-better-deal-despite-pressure-from-users](https://www.pcgamer.com/twitch-refuses-to-give-streamers-a-better-deal-despite-pressure-from-users)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 15:23:31+00:00

I am altering the deal. Pray I do not alter it any further.

## DIY laptop maker Framework is launching a modular Chromebook
 - [https://www.pcgamer.com/framework-chromebook-edition-modular-laptop](https://www.pcgamer.com/framework-chromebook-edition-modular-laptop)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 15:06:34+00:00

Swapping your notebook's parts out is such a novelty, and Google is all over it.

## Valorant is inching closer to telling players they're bad people
 - [https://www.pcgamer.com/valorant-is-inching-closer-to-telling-players-theyre-bad-people](https://www.pcgamer.com/valorant-is-inching-closer-to-telling-players-theyre-bad-people)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 13:00:31+00:00

Soon players will be flagged for disruptive behaviour.

## Devs show off how bad early game builds look after moans about GTA 6's visuals
 - [https://www.pcgamer.com/devs-show-off-how-bad-early-game-builds-look-after-moans-about-gta-6s-visuals](https://www.pcgamer.com/devs-show-off-how-bad-early-game-builds-look-after-moans-about-gta-6s-visuals)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 12:06:43+00:00

Bring back Mass Effect 3's headless Shepard, Bioware.

## Level up your gaming with O2's game-changing Switch Up
 - [https://www.pcgamer.com/level-up-your-gaming-with-o2s-game-changing-switch-up](https://www.pcgamer.com/level-up-your-gaming-with-o2s-game-changing-switch-up)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 11:46:39+00:00

Unlimited upgrades with no cancellation charges or extra costs? Tell us more…

## Ted Lasso's going to be in FIFA 23
 - [https://www.pcgamer.com/ted-lassos-going-to-be-in-fifa-23](https://www.pcgamer.com/ted-lassos-going-to-be-in-fifa-23)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 11:11:40+00:00

The fictional coach and AFC Richmond finally make the big time.

## 'Last man standing' for floppy disks reckons it's four years 'till bust
 - [https://www.pcgamer.com/floppy-disks-tom-persky](https://www.pcgamer.com/floppy-disks-tom-persky)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 11:08:45+00:00

But seriously, how are so many industries still using magnetic disks, even now?

## Nvidia has sprung the GPU pricing trap set by the pandemic years
 - [https://www.pcgamer.com/nvidia-rtx-4090-price](https://www.pcgamer.com/nvidia-rtx-4090-price)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 08:53:26+00:00

We got trapped into paying higher prices due to external forces, but because we did, they're here to stay.

## Today's Wordle 459 answer and hint: Wednesday, September 21
 - [https://www.pcgamer.com/todays-wordle-459-answer-hint](https://www.pcgamer.com/todays-wordle-459-answer-hint)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 07:01:28+00:00

Wordle today: The solution and a hint for Wednesday's puzzle.

## The best visual novel of 2017 is getting a sequel
 - [https://www.pcgamer.com/the-best-visual-novel-of-2017-is-getting-a-sequel](https://www.pcgamer.com/the-best-visual-novel-of-2017-is-getting-a-sequel)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 05:13:36+00:00

Butterfly Soup 2 will be out on October 29.

## Nvidia's RTX 4090 4x performance claims aren't holding up on current games
 - [https://www.pcgamer.com/nvidias-rtx-4090-4x-performance-claims-arent-holding-up-on-current-games](https://www.pcgamer.com/nvidias-rtx-4090-4x-performance-claims-arent-holding-up-on-current-games)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 05:07:56+00:00

Most of them are barely getting 2x the boost.

## Nvidia's RTX 4090 targets 300+ FPS at 1440p with low latency for competitive shooters
 - [https://www.pcgamer.com/nvidias-rtx-4090-targets-300-fps-at-1440p-with-low-latency-for-competitive-shooters](https://www.pcgamer.com/nvidias-rtx-4090-targets-300-fps-at-1440p-with-low-latency-for-competitive-shooters)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 04:09:50+00:00

These people are going to click on my head so fast.

## A 25-year-old MMO is finally getting sound
 - [https://www.pcgamer.com/a-25-year-old-mmo-is-finally-getting-sound](https://www.pcgamer.com/a-25-year-old-mmo-is-finally-getting-sound)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 03:58:48+00:00

Tibia players will be able to hear at last.

## Finally, a keyboard glitter mod that doesn't hold back
 - [https://www.pcgamer.com/finally-a-keyboard-glitter-mod-that-doesnt-hold-back](https://www.pcgamer.com/finally-a-keyboard-glitter-mod-that-doesnt-hold-back)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 02:06:13+00:00

At last, a modder with the skills requires has appeared.

## Watch a trailer for PUBG owner Krafton's expensive-looking Korean fantasy game
 - [https://www.pcgamer.com/watch-a-trailer-for-pubg-owner-kraftons-expensive-looking-korean-fantasy-game](https://www.pcgamer.com/watch-a-trailer-for-pubg-owner-kraftons-expensive-looking-korean-fantasy-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-21 01:52:05+00:00

Based on novel series The Bird That Drinks Tears.


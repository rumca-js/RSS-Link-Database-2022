# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Games at RISK of Becoming EXCLUSIVES
 - [https://www.youtube.com/watch?v=4MRKzcL8N6Y](https://www.youtube.com/watch?v=4MRKzcL8N6Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-09-22 00:00:00+00:00

With so many business deals within gaming corporations, there are tons of games that are potentially at risk of going exclusive to one particular platform over another. Here are some speculative examples that we've seen people debating.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 BRAND NEW Survival Games That Are Trying Something NEW
 - [https://www.youtube.com/watch?v=wmViXMcX9b8](https://www.youtube.com/watch?v=wmViXMcX9b8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-09-21 00:00:00+00:00

Looking for a survival game that feels a bit different? We’ve got you covered with these new and upcoming game releases.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:21 Pioneer
1:41 The Lord of the Rings: Return to Moria 
3:01 Earth Revival
4:19 Wizard with a Gun
5:34 Forever Skies 
6:35 Sengoku Dynasty
8:00 Night is Coming 
9:02 Voidtrain 
10:15 Stranded: Alien Dawn 
11:32 Nightingale 

10- Pioneer

Platform : PC

Release Date : TBA 2022



9- The Lord of the Rings: Return to Moria 

Platform : PC

Release Date : Q2 2023 



8- Earth Revival

Platform : PC 

Release Date : TbA 2023 



7-Wizard with a Gun

Platform : PC Switch

Release Date : TBA 2022



6- Forever Skies 

Platform : PC PS5 XSX|S

Release Date : 2023



5- Sengoku Dynasty

Platform : PC 

Release Date : TBA 2022 



4- Night is Coming 

Platform : PC 

Release Date : TBA 2022 



3- Voidtrain 

Platform : PC Xbox One XSX|S

Release Date : 2023 



2- Stranded: Alien Dawn 

Platform : PC 

Release Date : 2023 



1- Nightingale

Platform : PC

Release Date : TBA 2023 Survival games


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Everyone said this was impossible - Backyard Fiber Run
 - [https://www.youtube.com/watch?v=3CDOSj8fZA4](https://www.youtube.com/watch?v=3CDOSj8fZA4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-09-22 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

SmartDeploy: Claim your FREE IT software (worth $580!) at https://lmg.gg/SDSept

Everyone told me I was CRAZY when I pitched running a fibre optic cable directly between our headquarters and our new testing lab for a 100-gigabit internet connection... today I prove them wrong!

Discuss on the forum: https://linustechtips.com/topic/1456774-everyone-said-this-was-impossible-backyard-fiber-run/

Check out BC Planet Healthcare: https://www.bcplanthealthcare.com/

Check out InfiniteCables Armoured Fiber Cable: https://lmg.gg/xTJRR
Check out InfiniteCables Fiber Cables & Accessories: https://lmg.gg/E9vGb

Check out Ubiquiti's Enterprise XG 24 Network Switch: https://lmg.gg/aoyKX

Check out MikroTik's CRS504-4XQ-IN 100GbE Network Switch: https://lmg.gg/gjDYU

Check out FS.com 100GbE Transceivers: https://lmg.gg/vBBl3
Check out FS.com QSFP to SFP Breakout Cables: https://lmg.gg/SEyGv

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro

## I Hope You Have a LOT of Money... RTX 4000 Announced
 - [https://www.youtube.com/watch?v=3RIp7CwkBeA](https://www.youtube.com/watch?v=3RIp7CwkBeA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-09-21 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Get 50% off on your annual Zoho CRM subscription at: https://lmg.gg/ZohoCRM

Nvidia just announced the RTX 4090 and 4080s.  Overall Ada looks great... but Nvidia left out some crucial details that have me concerned.

Discuss on the forum: https://linustechtips.com/topic/1456484-the-rtx-4090-looks-sick/

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro

## The MOST Tricked Out Laptop - MSI Titan GT77
 - [https://www.youtube.com/watch?v=tHNQOJ_nsLc](https://www.youtube.com/watch?v=tHNQOJ_nsLc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-09-21 00:00:00+00:00

Thanks to MSI for sponsoring this video! You can learn more about the MSI Titan GT77 at https://msi.gm/3Lh0E8r or purchase your own at https://msi.gm/3qL9MZv

Remember the last time you tried moving your desktop gaming PC? All those hard drives and full size components sure have some heft to them! We say work smarter, not harder: this laptop has all of the power of a desktop, plus a mechanical keyboard and more storage space than you know what to do with.

Discuss on the forum: https://linustechtips.com/topic/1456604-the-most-tricked-out-laptop-sponsored/

Buy a Crucial 64GB DDR5-4800 Kit (2 x 32GB): https://geni.us/Eu00n

Buy a SABRENT 8TB NVMe 4.0 SSD: https://geni.us/v94hz

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:55 Opening the Box
2:30 Looking Inside the GT77
3:38 Overkill Step 1
4:23 Something New
5:16 Detailed Specs
8:35 An RGB "Caboose"
9:15 372 Steam Games
11:58: The Beast of an IO
12:26 More Cool Stuff
13:06 Outro


# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Twitch Says It Will Reduce Payments for Many Popular Streamers
 - [https://www.nytimes.com/2022/09/21/technology/twitch-reduce-payments-streamers.html](https://www.nytimes.com/2022/09/21/technology/twitch-reduce-payments-streamers.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-21 22:15:38+00:00

The video game streaming service is struggling to strike the right balance between popularity and profit.

## Regulators Accuse Amazon of Singling Out Union Organizers for Discipline
 - [https://www.nytimes.com/2022/09/21/business/economy/amazon-labor-union-nlrb.html](https://www.nytimes.com/2022/09/21/business/economy/amazon-labor-union-nlrb.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-21 21:34:27+00:00

National Labor Relations Board officials said the company had applied its workplace rules unfairly, and asked it to change or scrap the regulations.

## C.E.O. of Kraken, the Cryptocurrency Exchange, Steps Down
 - [https://www.nytimes.com/2022/09/21/technology/ceo-kraken-cryptocurrency-jesse-powell.html](https://www.nytimes.com/2022/09/21/technology/ceo-kraken-cryptocurrency-jesse-powell.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-21 19:58:12+00:00

Jesse Powell, the chief executive, has battled with employees after posting messages about race and gender and urging those who disagreed with his values to leave.

## F.D.A. Warning on NyQuil Chicken Alerts Many to Existence of NyQuil Chicken
 - [https://www.nytimes.com/2022/09/21/technology/nyquil-chicken-tiktok-fda.html](https://www.nytimes.com/2022/09/21/technology/nyquil-chicken-tiktok-fda.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-21 18:34:44+00:00

Cooking poultry in cold medicine is a bad, dangerous idea that few people seemed to be aware of until the government warning attracted media coverage.

## New System Aims to Save Whales Near San Francisco From Ship Collisions
 - [https://www.nytimes.com/2022/09/21/science/whale-safe-san-francisco.html](https://www.nytimes.com/2022/09/21/science/whale-safe-san-francisco.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-21 17:00:10+00:00

Four whales have died near San Francisco this year after ships crashed into them, and scientists hope to drive that number to zero with new technology.

## The Settings That Make Smartphones Easier for Everyone to Use
 - [https://www.nytimes.com/2022/09/21/technology/personaltech/smartphone-accessibility-features.html](https://www.nytimes.com/2022/09/21/technology/personaltech/smartphone-accessibility-features.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-21 13:00:11+00:00

The accessibility features Apple and Google include in their mobile software can help people of all abilities get more from their devices.


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## The Anticipation of Jon Jones' Comeback
 - [https://www.youtube.com/watch?v=gl1_vKBYvH4](https://www.youtube.com/watch?v=gl1_vKBYvH4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-09-21 00:00:00+00:00

Taken from JRE MMA Show #130 w/Will Harris:
https://open.spotify.com/episode/4ZpI1Zd3L7AEYEG7L73f0x?si=66dd275da8e0406c

## Will Harris on Being with Kamaru Usman After Leon Edwards Loss
 - [https://www.youtube.com/watch?v=GZSjbC4tM5s](https://www.youtube.com/watch?v=GZSjbC4tM5s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-09-21 00:00:00+00:00

Taken from JRE MMA Show #130 w/Will Harris:
https://open.spotify.com/episode/4ZpI1Zd3L7AEYEG7L73f0x?si=66dd275da8e0406c


## CDC Oversells the ‘Bivalent’ Covid Shot - WSJ
 - [https://www.wsj.com/articles/cdc-oversells-the-bivalent-covid-shot-hospitalizations-vaccine-booster-omicron-pandemic-pfizer-moderna-china-illness-death-11663793472](https://www.wsj.com/articles/cdc-oversells-the-bivalent-covid-shot-hospitalizations-vaccine-booster-omicron-pandemic-pfizer-moderna-china-illness-death-11663793472)
 - RSS feed: https://www.wsj.com
 - date published: 2022-09-21 13:36:42+00:00

CDC Oversells the ‘Bivalent’ Covid Shot - WSJ


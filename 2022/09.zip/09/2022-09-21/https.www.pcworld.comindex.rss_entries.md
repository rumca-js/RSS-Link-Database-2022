# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## Microsoft tips likely Surface event on October 12
 - [https://www.pcworld.com/article/1072420/microsoft-tips-likely-surface-event-on-oct-12.html](https://www.pcworld.com/article/1072420/microsoft-tips-likely-surface-event-on-oct-12.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 21:11:21+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>Microsoft has announced its fall showcase for Surface hardware on October 12, bright and early for the Redmond, WA, audience at 7 AM PT.</p>



<p>Although the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.microsoft.com/event?&amp;xcust=2-1-1072420-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">&ldquo;save the date&rdquo; invitation</

## Windows Insiders can test dynamic refresh rate on external displays
 - [https://www.pcworld.com/article/1072273/windows-insiders-can-test-out-dynamic-refresh-rate-on-external-displays.html](https://www.pcworld.com/article/1072273/windows-insiders-can-test-out-dynamic-refresh-rate-on-external-displays.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 17:52:06+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>Microsoft&rsquo;s Dynamic Refresh Rate can provide a smoother inking and display experience on its own Surface laptops, like the Surface Laptop Studio. But members of the Windows Insider testing group can now try it out in external monitors, too.</p>



<p>Microsoft announced the new change in Windows Insider Build 25206, part of the Dev Channel. Builds in this channel ship wit

## Logitech’s G Cloud gaming handheld is up for pre-order now
 - [https://www.pcworld.com/article/1072227/logitechs-g-cloud-gaming-handheld-is-up-for-pre-order-now.html](https://www.pcworld.com/article/1072227/logitechs-g-cloud-gaming-handheld-is-up-for-pre-order-now.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 16:57:12+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>Ever-present PC accessory maker Logitech is ready to enter the portable gaming world. Well, almost ready&mdash;the G Cloud, an Android-based game player that focuses on streaming PC games, is set to release on October 18. So sayeth an Amazon store listing that unceremoniously popped up just today, with a list price of $299.99 after a $50 discount. <a href="https://go.redirectin

## The best Asus laptops: Best overall, best for gaming, and more
 - [https://www.pcworld.com/article/633316/best-asus-laptops.html](https://www.pcworld.com/article/633316/best-asus-laptops.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 16:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>Asus is known for its innovative designs and quality products. So whether you&rsquo;re in the market for a powerful workhorse, something you can easily take on the go, or a laptop with a gorgeous OLED display, Asus has it covered. Here at PCWorld, we&rsquo;ve personally reviewed a number of Asus laptops from inexpensive VivoBooks to powerful gaming machines like the ROG Strix a

## Windows 11’s File Explorer tabs are coming in October
 - [https://www.pcworld.com/article/1071395/heres-what-microsoft-plans-for-windows-11-22h2s-first-update.html](https://www.pcworld.com/article/1071395/heres-what-microsoft-plans-for-windows-11-22h2s-first-update.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 15:17:35+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>Microsoft may have <a href="https://www.pcworld.com/article/1068123/windows-11-2022-update-arrives-smart-app-control.html">rolled out the Windows 11 2022 Update (22H2)</a>, but the company is already looking forward to what&rsquo;s next, which is coming in October. That includes the tabbed File Explorer interface originally anticipated to be part of the 2022 Update.</p>



<p>B

## Framework’s Chromebook brings modular DIY laptops to the Googleverse
 - [https://www.pcworld.com/article/1071366/frameworks-chromebook-brings-modular-diy-laptops-to-the-googleverse.html](https://www.pcworld.com/article/1071366/frameworks-chromebook-brings-modular-diy-laptops-to-the-googleverse.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 15:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>The Framework is the modular laptop for the user who wants to upgrade their hardware forever, in a user-friendly (and planet-friendly) way. As a unique part of the PC market <a href="https://www.pcworld.com/article/835070/replacing-the-frameworks-cpu-made-me-a-believer-in-upgradeable-laptops.html" rel="noreferrer noopener" target="_blank">it&rsquo;s a smashing success</a>, and 

## Amazon rekindles its 8-inch Fire HD tablets
 - [https://www.pcworld.com/article/1072025/amazon-rekindles-its-8-inch-fire-hd-tablets.html](https://www.pcworld.com/article/1072025/amazon-rekindles-its-8-inch-fire-hd-tablets.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 14:43:31+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>7-inch tablets have seemed a lot less useful since smartphones have edged towards that size territory anyway. 8 inches is where it&rsquo;s at for a Goldilocks in-between device &mdash; just ask the iPad Mini or Amazon&rsquo;s Fire HD 8, which just got a refresh for its sixth generation (or 11th, if you&rsquo;re counting all of the various Fire models). The new version is thinne

## The best Thunderbolt docks for your laptop
 - [https://www.pcworld.com/article/393714/best-thunderbolt-docks-for-a-laptop-pc.html](https://www.pcworld.com/article/393714/best-thunderbolt-docks-for-a-laptop-pc.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 14:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>As Thunderbolt ports become more common in laptops, a Thunderbolt dock becomes a necessary accessory, providing I/O access for legacy mice, keyboards, external drives, and more. It&rsquo;s essentially the centerpiece of a productive office, whether at work or home. </p>



<p>Thunderbolt docks have become more important as laptop makers slim down, cut costs, and eliminate multi

## 6 hidden GeForce RTX 40-series details Nvidia didn’t talk about
 - [https://www.pcworld.com/article/1071293/6-geforce-rtx-40-series-4090-4080-secrets-nvidia.html](https://www.pcworld.com/article/1071293/6-geforce-rtx-40-series-4090-4080-secrets-nvidia.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 13:34:08+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>At long last, the <a href="https://www.pcworld.com/article/1071034/nvidia-geforce-rtx-4090-4080-revealed-gtc-project-beyond.html">GeForce RTX 40-series has been revealed</a>, but in true Nvidia fashion, CEO Jensen Huang didn&rsquo;t delve deeply into raw speeds and feeds while introducing the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.nvidia.co

## Our favorite NVMe SSD, the SK Hynix Gold P31, is on sale for $86
 - [https://www.pcworld.com/article/1071872/tk-48.html](https://www.pcworld.com/article/1071872/tk-48.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 13:10:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>If you need a massive amount of storage for your plethora of games, you&rsquo;re in luck. <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.amazon.com/SK-hynix-Gold-PCIe-Internal/dp/B08DKB5LWY?th=1&amp;xcust=2-2-1071872-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Amazon&rsquo;s selling the SK Hynix Gold P31 SSD for just $86.39</a>. Tha

## Dell Inspiron 16 2-in-1 review: Spacious laptop, oversized tablet
 - [https://www.pcworld.com/article/1068741/dell-inspiron-16-2-in-1-review.html](https://www.pcworld.com/article/1068741/dell-inspiron-16-2-in-1-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 10:45:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><div class="review" id="review-body"><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Roomy 16-inch 16:10 display</li><li>Long battery life</li><li>

## 5 easy tasks that supercharge your security
 - [https://www.pcworld.com/article/394001/5-easy-tasks-supercharge-your-security.html](https://www.pcworld.com/article/394001/5-easy-tasks-supercharge-your-security.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-09-21 10:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>Protecting your personal data isn&rsquo;t just smart these days&mdash;it&rsquo;s a necessity. As the world grows more and more connected, your private info becomes more and more valuable. Whether it&rsquo;s using leaked info from website breaches to hack into your other accounts or holding your personal computer ransom for money, malicious evildoers won&rsquo;t hesitate to ruin


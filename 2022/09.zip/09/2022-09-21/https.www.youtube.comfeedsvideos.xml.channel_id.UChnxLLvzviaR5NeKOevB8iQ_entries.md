# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Cruisin' with the Instruo Cruinn
 - [https://www.youtube.com/watch?v=9DyKmvxxlpA](https://www.youtube.com/watch?v=9DyKmvxxlpA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-09-22 00:00:00+00:00

Are you ready for BZZZ? Are you ready for 5 BZZZZ, moving very fast from left to right? Well then, come aboard the good ship Cruinn. This is a demo of the new Instruo stereo oscillator through the XOAC Zagrzeb filter and Mutable Instruments Beads. We'll be joined by Bastl Pizza doing some FM duties, and the Bitbox Micro doing drums. Ahoy.

Modules used in this video (via Perfect Circuit and Patchwerks)

Instruo Cruinn: https://bit.ly/cruinnpc
XAOC Zagrzeb: https://bit.ly/3HhbEAj
Mutable Instruments Beads:  https://shrsl.com/38qvc
Acid Rain Navigator: http://shrsl.com/38qt2
Acid Rain Constellation: https://shrsl.com/3plw6
Bitbox Micro: http://shrsl.com/3plw8

00:00 intro
01:52 basic sound demo
03:54 rhythmic fm modulation
07:41 spread cv modulation
09:23 dune fm drones
12:12 outro jam

Join me on Patreon and get access to music, presets, samples, and a great community: http://bit.ly/rmrpatreon

Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


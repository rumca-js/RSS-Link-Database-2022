# Source:Washington Examiner - world, URL:https://feeds.feedburner.com/dcexaminer/WorldNews, language:en-US

## New Zealand sees greatest jump in adult wealth in world
 - [https://www.washingtonexaminer.com/news/new-zealand-sees-greatest-jump-adult-wealth-world](https://www.washingtonexaminer.com/news/new-zealand-sees-greatest-jump-adult-wealth-world)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/WorldNews
 - date published: 2022-09-21 20:57:17+00:00

New Zealand experienced the greatest increase in adult wealth in the world in 2021, according to a new report.


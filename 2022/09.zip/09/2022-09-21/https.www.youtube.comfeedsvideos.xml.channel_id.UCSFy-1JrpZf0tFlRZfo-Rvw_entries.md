# Source:Sydney Watson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSFy-1JrpZf0tFlRZfo-Rvw, language:en-US

## Patreon BANS me but allows THIS?? WTF.
 - [https://www.youtube.com/watch?v=Mb4wuTx8o0Q](https://www.youtube.com/watch?v=Mb4wuTx8o0Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSFy-1JrpZf0tFlRZfo-Rvw
 - date published: 2022-09-21 21:35:20+00:00

Check out American Hartford Gold here https://offers.americanhartfordgold.com/sydneywatson/ or call 866-568-0043 for more information on their gold and silver specials!

Subscribestar, in case you are interested ;D : https://www.subscribestar.com/sydney-watson

Links:
Reduxx article of full story: https://reduxx.info/patreon-fires-security-staff-amid-allegations-of-protecting-maps/

Cyberscoop: https://www.cyberscoop.com/patreon-security-team-layoffs/

My Patreon video: https://www.youtube.com/watch?v=phmizUdHUVI&amp;t=155s
Video about Pedobaiting: https://www.youtube.com/watch?v=Wt5y3HmEHiE&amp;t=574s

Find me:
Subscribestar: https://www.subscribestar.com/sydney-watson
Gab: https://gab.com/sydneywatson 
Facebook: https://www.facebook.com/sydneywatsonofficial 
Twitter: https://twitter.com/sydneylwatson 
Instagram: https://www.instagram.com/sydneywatson__ 

Sign up to my email list (I promise not to harass you haha): https://www.sydneywatson.com


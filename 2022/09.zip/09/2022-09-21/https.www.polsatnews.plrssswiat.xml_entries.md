# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Syn rzecznika Kremla o powołaniu do wojska: "Będę to załatwiać na innym poziomie"
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/syn-rzecznika-kremla-o-powolaniu-do-wojska-bede-to-zalatwiac-na-innym-poziomie/](https://www.polsatnews.pl/wiadomosc/2022-09-21/syn-rzecznika-kremla-o-powolaniu-do-wojska-bede-to-zalatwiac-na-innym-poziomie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 20:15:00+00:00

Współpracownik rosyjskiego dysydenta Aleksieja Nawalnego zadzwonił do syna rzecznika Kremla Dmitrija Pieskowa, podając się za pracownika wojskowej komendy uzupełnień - twierdzi kanał Populiarnaja Politika. Gdy Nikołaj Pieskow usłyszał, że jest mobilizacja i jedzie na front odpowiedział: Będę to załatwiał na innym szczeblu. Zapytany czy pojedzie na front na ochotnika odparł: Nie.

## Tatry Słowackie: Zginęło polskie małżeństwo. Ich ciała znaleziono pod śniegiem
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/tatry-slowackie-zginelo-polskie-malzenstwo-ich-ciala-znaleziono-pod-sniegiem/](https://www.polsatnews.pl/wiadomosc/2022-09-21/tatry-slowackie-zginelo-polskie-malzenstwo-ich-ciala-znaleziono-pod-sniegiem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 19:24:00+00:00

Słowaccy ratownicy górscy poinformowali o śmierci polskiego małżeństwa. Do wypadku doszło w rejonie Kwietnikowej Przełączki.

## Stany Zjednoczone: 73-latek stanął w obronie kobiety. Napastnik był uzbrojony
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/stany-zjednoczone-73-latek-obronil-kobiete-przed-napadem-napastnik-byl-uzbrojony/](https://www.polsatnews.pl/wiadomosc/2022-09-21/stany-zjednoczone-73-latek-obronil-kobiete-przed-napadem-napastnik-byl-uzbrojony/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 16:14:00+00:00

73-letni mężczyzna z Teksasu został okrzyknięty bohaterem po tym, jak stanął w obronie kobiety, którą zaatakował uzbrojony napastnik. Choć starszy pan nie zdołał powstrzymać złodzieja przed kradzieżą auta, to do ostatniej chwili z nim walczył.

## Słowacja. Polak zginął po zderzeniu z jeleniem. Poroże przebiło mu klatkę piersiową
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/slowacja-polak-zginal-w-zderzeniu-z-jeleniem-poroze-przebilo-mu-klatke-piersiowa/](https://www.polsatnews.pl/wiadomosc/2022-09-21/slowacja-polak-zginal-w-zderzeniu-z-jeleniem-poroze-przebilo-mu-klatke-piersiowa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 15:32:00+00:00

Poroże jelenia rozbiło szybę i śmiertelnie zraniło 42-latka z Polski - napisała na Facebooku słowacka policja. Do wypadku doszło w nocy na drodze pomiędzy miejscowościami Huncovec i Kieżmark w zachodniej części kraju.

## Rosja. Nie żyje Anatolij Heraszczenko, były szef Moskiewskiego Instytutu Lotnictwa
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/rosja-nie-zyje-anatolij-heraszczenko-byly-szef-szef-moskiewskiego-instytutu-lotnictwa/](https://www.polsatnews.pl/wiadomosc/2022-09-21/rosja-nie-zyje-anatolij-heraszczenko-byly-szef-szef-moskiewskiego-instytutu-lotnictwa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 14:47:00+00:00

Anatolij Heraszczenko, były szef Moskiewskiego Instytutu Lotnictwa (MAI), zginął w wypadku. 72-letni profesor spadł z dużej wysokości ze schodów. Odniesiona obrażenia okazały się śmiertelne.

## Australia. Około 230 waleni morze wyrzuciło na brzeg Tasmanii. Połowa może już nie żyć
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/australia-okolo-230-waleni-morze-wyrzucilo-na-brzeg-tasmanii-polowa-moze-juz-nie-zyc/](https://www.polsatnews.pl/wiadomosc/2022-09-21/australia-okolo-230-waleni-morze-wyrzucilo-na-brzeg-tasmanii-polowa-moze-juz-nie-zyc/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 14:20:00+00:00

Morze wyrzuciło na brzeg Tasmanii około 230 waleni. W środę wyruszyła na wyspę ekipa ratowników i przyrodników, by pomóc zwierzętom, ale według szacunków nawet połowa z nich może już nie żyć.

## Mateusz Lachowski: Analitycy mówią, że nie ma czegoś takiego jak częściowa mobilizacja
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/mateusz-lachowski-analitycy-mowia-ze-nie-ma-czegos-takiego-jak-czesciowa-mobilizacja/](https://www.polsatnews.pl/wiadomosc/2022-09-21/mateusz-lachowski-analitycy-mowia-ze-nie-ma-czegos-takiego-jak-czesciowa-mobilizacja/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 13:02:00+00:00

- Rosjanie mówią o częściowej mobilizacji, część analityków mówi, że nie ma czegoś takiego jak częściowa mobilizacja. Mobilizacja to zawsze mobilizacja - powiedział reporter Polsat News Mateusz Lachowski. Dziennikarz od kilku dni przebywa w Charkowie.

## Mobilizacja w Rosji. Mieszkańcy chcą uciec z kraju, ale bilety natychmiast zdrożały
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/mobilizacja-w-rosji-mieszkancy-chca-uciec-z-kraju-ale-bilety-natychmiast-zdrozaly/](https://www.polsatnews.pl/wiadomosc/2022-09-21/mobilizacja-w-rosji-mieszkancy-chca-uciec-z-kraju-ale-bilety-natychmiast-zdrozaly/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 12:12:00+00:00

Jak wyjechać z Rosji? - wpisują w Googleu spanikowani mieszkańcy tego kraju po tym, jak ich przywódca Władimir Putin ogłosił częściową mobilizację. Ucieczka z Federacji nie jest prosta. Ceny biletów lotniczych w trymiga skoczyły do rekordowych pułapów, a w internecie krąży plotka, że niełatwo zarezerwować także miejsce w pociągu. O los swoich pracowników obawia się też jeden z banków.

## Grecja. Rząd wzywa kraj do oszczędzania energii. Wyłączona będzie iluminacja
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/grecja-rzad-wzywa-kraj-do-oszczedzania-energii-wylaczona-bedzie-iluminacja/](https://www.polsatnews.pl/wiadomosc/2022-09-21/grecja-rzad-wzywa-kraj-do-oszczedzania-energii-wylaczona-bedzie-iluminacja/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 11:18:00+00:00

Grecki rząd wezwał obywateli i instytucje w kraju do oszczędzania energii elektrycznej. Zgasną iluminacje słynnych obiektów w tym mostu w pobliżu Patras. Ateny wymienią 46 000 żarówek w mieście na żarówki LED.

## Hollywoodzki aktor Tom Hardy wygrał turniej jiu-jitsu. To nie pierwszy taki triumf
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/hollywoodzki-aktor-tom-hardy-wygral-turniej-jiu-jitsu-to-nie-pierwszy-taki-triumf/](https://www.polsatnews.pl/wiadomosc/2022-09-21/hollywoodzki-aktor-tom-hardy-wygral-turniej-jiu-jitsu-to-nie-pierwszy-taki-triumf/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 09:54:00+00:00

Aktor Tom Hardy niespodziewanie pojawił się w sobotę na otwartych mistrzostwach jiu-jitsu w Milton Keynes i wygrał wszystkie swoje mecze. Rzecznik imprezy nazwał gwiazdora naprawdę miłym facetem.

## Nowa Zelandia. Gigantyczny wulkan Taupo znów może wybuchnąć. Po raz pierwszy od 1800 lat
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/nowa-zelandia-gigantyczny-wulkan-taupo-znow-moze-wybuchnac-po-raz-pierwszy-od-1800-lat/](https://www.polsatnews.pl/wiadomosc/2022-09-21/nowa-zelandia-gigantyczny-wulkan-taupo-znow-moze-wybuchnac-po-raz-pierwszy-od-1800-lat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 09:49:00+00:00

Podniesiono poziom alarmowy na gigantycznym wulkanie Taupo w Nowej Zelandii. Formacja ta była źródłem największej erupcji na Ziemi w ciągu ostatnich 5000 lat. Wulkan ostatni raz eksplodował około 1800 lat temu, wyrzucając do atmosfery ponad 100 kilometrów sześciennych materii. Teraz odnotowano prawie 700 małych trzęsień ziemi poniżej jeziora, które wypełnia utworzoną przez wulkan kalderę.

## Orędzie Władimira Putina. Gen. Bieniek: Mobilizacja 300 tysięcy rezerwistów brzmi poważnie
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/oredzie-wladimira-putina-gen-bieniek-mobilizacja-300-tysiecy-rezerwistow-brzmi-powaznie/](https://www.polsatnews.pl/wiadomosc/2022-09-21/oredzie-wladimira-putina-gen-bieniek-mobilizacja-300-tysiecy-rezerwistow-brzmi-powaznie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 09:02:00+00:00

- W przemówieniu Putina zabrzmiały bardzo niebezpieczne akcenty. Nagle powiedział, by ich nie straszyć bronią jądrową. Coś niewiarygodnego, to on od początku straszy użyciem taktycznej broni jądrowej - mówił w Polsat News gen. Mieczysław Bieniek. Dodał, że celem częściowej mobilizacji ogłoszonej w Rosji jest uzupełnienie strat, którego nie uda się prędko przeprowadzić.

## Dziennikarz nie przebierał w słowach. "Skoro o śmieciach mowa, wrócimy do słów Putina"
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/dziennikarz-nie-przebieral-w-slowach-skoro-o-smieciach-mowa-wrocimy-do-slow-putina/](https://www.polsatnews.pl/wiadomosc/2022-09-21/dziennikarz-nie-przebieral-w-slowach-skoro-o-smieciach-mowa-wrocimy-do-slow-putina/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 08:24:00+00:00

Słowa prezentera Polsat News Igora Sokołowskiego zachwyciły internautów. - Skoro o śmieciach mowa, to wrócimy też do słów Władimira Putina - powiedział w środę dziennikarz, odnosząc się do porannego orędzia rosyjskiego prezydenta.

## USA. Sąd zwolnił z więzienia mężczyznę. Powodem nowe informacje ujawnione w podcaście
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/usa-sad-zwolnil-z-wiezienia-mezczyzne-powodem-nowe-informacje-ujawnione-w-podcascie/](https://www.polsatnews.pl/wiadomosc/2022-09-21/usa-sad-zwolnil-z-wiezienia-mezczyzne-powodem-nowe-informacje-ujawnione-w-podcascie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 08:22:00+00:00

Nowe fakty opublikowane przez twórców podcastu Serial dotyczące zbrodni z 1999 roku w Baltimore w USA, doprowadziły we wtorek sąd do decyzji o zwolnieniu osadzonego z więzienia i skierowania sprawy do ponownego rozpatrzenia.

## Irlandia. W żołądku pacjentki znaleziono 55 baterii. To rekord
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/irlandia-w-zoladku-pacjentki-znaleziono-55-baterii-to-rekord/](https://www.polsatnews.pl/wiadomosc/2022-09-21/irlandia-w-zoladku-pacjentki-znaleziono-55-baterii-to-rekord/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 07:22:00+00:00

Do nietypowego medycznego przypadku doszło w Irlandii, gdzie tamtejsi lekarze musieli poradzić sobie z usunięciem kilkudziesięciu baterii z żołądka 66-letniej pacjentki. Kobieta skarżyła się na ból brzucha.

## Władimir Putin: Ogłaszam częściową mobilizację w Rosji
 - [https://www.polsatnews.pl/wiadomosc/2022-09-21/wladimir-putin-oglaszam-czesciowa-mobilizacje-w-rosji/](https://www.polsatnews.pl/wiadomosc/2022-09-21/wladimir-putin-oglaszam-czesciowa-mobilizacje-w-rosji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-21 06:14:00+00:00

Władimir Putin ogłosił, że podpisał dekret o częściowej mobilizacji w Rosji. Dokument wchodzi w życie jeszcze w środę. Zdaniem przywódcy kremlowskiego reżimu to Zachód nie chce pokoju między jego krajem a Ukrainą.


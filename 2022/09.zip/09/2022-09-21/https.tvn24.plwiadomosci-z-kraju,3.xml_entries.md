# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Stacje Lotosu zmienią barwy. Podano termin
 - [https://tvn24.pl/biznes/z-kraju/orlen-lotos-stacje-lotosu-zmienia-barwy-pkn-orlen-ma-zakonczyc-rebranding-w-styczniu-2023-roku-6124322?source=rss](https://tvn24.pl/biznes/z-kraju/orlen-lotos-stacje-lotosu-zmienia-barwy-pkn-orlen-ma-zakonczyc-rebranding-w-styczniu-2023-roku-6124322?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2022-09-21 19:44:52+00:00

<img alt="Stacje Lotosu zmienią barwy. Podano termin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hk2tf4-lotos-shutterstock2121919499-5770130/alternates/LANDSCAPE_1280" />
    Orlen planuje zakończyć rebranding około 100 stacji paliw przejętych od Lotosu w styczniu 2023 roku - poinformował płocki koncern. Firma zapewniła, że nie planuje likwidacji żadnych stacji ze względu na lokalizację w pobliżu placówek Orlenu.

## Coraz więcej ludzi traci pracę. Cięć etatów przybędzie
 - [https://tvn24.pl/biznes/z-kraju/sytuacja-na-rynku-pracy-zwolnienia-w-firmach-obawy-o-utrate-pracy-6122774?source=rss](https://tvn24.pl/biznes/z-kraju/sytuacja-na-rynku-pracy-zwolnienia-w-firmach-obawy-o-utrate-pracy-6122774?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2022-09-21 05:43:45+00:00

<img alt="Coraz więcej ludzi traci pracę. Cięć etatów przybędzie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jn1ndh-pap2022040131f-1-6122809/alternates/LANDSCAPE_1280" />
    Już 12,9 tysięcy osób straciło do lipca pracę. To ponad jedna czwarta więcej niż przed rokiem. Cięć etatów jeszcze przybędzie - donosi w środę "Rzeczpospolita". Gazeta podaje, że liczba ofert pracy maleje w skali roku. Z kolei we wtorek Główny Urząd Statystyczny (GUS) poinformował, że przeciętne wynagrodzenie brutto w sekt


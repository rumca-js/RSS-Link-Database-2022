# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Samsung Galaxy S24 może być pierwszym smartfonem z obsługą Wi-Fi 7
 - [https://ithardware.pl/aktualnosci/samsung_galaxy_s24_moze_byc_pierwszym_smartfonem_z_obsluga_wi_fi_7-23432.html](https://ithardware.pl/aktualnosci/samsung_galaxy_s24_moze_byc_pierwszym_smartfonem_z_obsluga_wi_fi_7-23432.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 21:13:30+00:00

<img src="https://ithardware.pl/artykuly/min/23432_1.jpg" />            Jak wskazują najnowsze pogłoski, Samsung może wprowadzić obsługę&nbsp;Wi-Fi 7 w modelu Galaxy S24, kt&oacute;rego premiera powinna odbyć się w 2024 roku. To wciąż mn&oacute;stwo czasu, jednak ten smartfon może być pierwszym, kt&oacute;ry...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_galaxy_s24_moze_byc_pierwszym_smartfonem_z_obsluga_wi_fi_7-23432.html">https://ithardware.pl/aktualno

## PlayStation VR2 zaprezentowane na nowym zwiastunie
 - [https://ithardware.pl/aktualnosci/playstation_vr2_zaprezentowane_na_nowym_zwiastunie-23431.html](https://ithardware.pl/aktualnosci/playstation_vr2_zaprezentowane_na_nowym_zwiastunie-23431.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 19:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/23431_1.jpg" />            Sony zaprezentowało PlayStation VR2 na nowym zwiastunie i ujawniło kilka informacji. Ostatnio dowiedzieliśmy się, że zestaw wirtualnej rzeczywistości nie będzie wspierał gier z oryginalnego PS VR.

PS VR2 zaoferuje wyświetlacz&nbsp;4K HDR...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/playstation_vr2_zaprezentowane_na_nowym_zwiastunie-23431.html">https://ithardware.pl/aktualnosci/playstation

## Cyberpunk 2077 wzbudza ogromne zainteresowanie. CD Projekt RED ujawnia oficjalne dane
 - [https://ithardware.pl/aktualnosci/cyberpunk_2077_wzbudza_ogromne_zainteresowanie_cd_projekt_red_ujawnia_oficjalne_dane-23429.html](https://ithardware.pl/aktualnosci/cyberpunk_2077_wzbudza_ogromne_zainteresowanie_cd_projekt_red_ujawnia_oficjalne_dane-23429.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 17:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/23429_1.jpg" />            Cyberpunk 2077 przeżywa na Steam odrodzenie. CD Projekt RED ujawnił teraz oficjalne dane dotyczące liczby graczy, kt&oacute;rzy zagrali w grę po raz pierwszy oraz wr&oacute;cili do niej po jakimś czasie.

Od około tygodnia Cyberpunk 2077...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cyberpunk_2077_wzbudza_ogromne_zainteresowanie_cd_projekt_red_ujawnia_oficjalne_dane-23429.html">https://itha

## Firma GALAX potwierdza chipy AD102-300, AD103-300 i AD104-400 dla kart z serii RTX 4090 oraz 4080
 - [https://ithardware.pl/aktualnosci/firma_galax_potwierdza_chipy_ad102_300_ad103_300_i_ad104_400_dla_kart_z_serii_rtx_4090_oraz_4080-23427.html](https://ithardware.pl/aktualnosci/firma_galax_potwierdza_chipy_ad102_300_ad103_300_i_ad104_400_dla_kart_z_serii_rtx_4090_oraz_4080-23427.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 16:30:30+00:00

<img src="https://ithardware.pl/artykuly/min/23427_1.jpg" />            Firma GALAX potwierdziła&nbsp;procesory graficzne&nbsp;AD102-300, AD103-300 oraz&nbsp;AD104-400. Będą one podstawą kart graficznych z serii GeForce RTX 4080 oraz 4090. Rdzeń AD103-300 odnajdziemy w&nbsp;RTX 4080 16 GB. Wersja z 12 GB pamięci VRAM...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/firma_galax_potwierdza_chipy_ad102_300_ad103_300_i_ad104_400_dla_kart_z_serii_rtx_4090_oraz_4080-234

## Genesis Pallad 410 - stylowy plecak gamingowy
 - [https://ithardware.pl/aktualnosci/genesis_pallad_410_stylowy_plecak_gamingowy-23428.html](https://ithardware.pl/aktualnosci/genesis_pallad_410_stylowy_plecak_gamingowy-23428.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 15:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/23428_1.jpg" />            Firma Genesis dodała do swojej oferty gamingowy plecak Pallad 410.&nbsp;Model ten powinien przypaść do gustu graczom, kt&oacute;rzy nie chcą rozstawać się ze swoim laptopem.

Plecak Genesis Pallad 410 został zaprojektowany do przenoszenia...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/genesis_pallad_410_stylowy_plecak_gamingowy-23428.html">https://ithardware.pl/aktualnosci/genesis_pallad_410

## Creative Sound Blaster Blaze V2. Nowa wersja słuchawek dla graczy
 - [https://ithardware.pl/aktualnosci/creative_sound_blaster_blaze_v2_nowa_wersja_sluchawek_dla_graczy-23426.html](https://ithardware.pl/aktualnosci/creative_sound_blaster_blaze_v2_nowa_wersja_sluchawek_dla_graczy-23426.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 14:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/23426_1.jpg" />            Creative Technology, producent rozwiązań audio, odnawia wielce&nbsp;zestaw słuchawkowy Sound Blaster Blaze V2 i wprowadza go do sprzedaży na rynek europejski. Nowa wersja zostaje tylko odświeżona pozostawiając wszystkie najlepsze atuty wydania...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/creative_sound_blaster_blaze_v2_nowa_wersja_sluchawek_dla_graczy-23426.html">https://ithardware.pl/aktu

## Tak wyglądają oficjalne etui na smartfony Google Pixel 7 i Pixel 7 Pro
 - [https://ithardware.pl/aktualnosci/tak_wygladaja_oficjalne_etui_na_smartfony_google_pixel_7_i_pixel_7_pro-23425.html](https://ithardware.pl/aktualnosci/tak_wygladaja_oficjalne_etui_na_smartfony_google_pixel_7_i_pixel_7_pro-23425.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 13:55:30+00:00

<img src="https://ithardware.pl/artykuly/min/23425_1.jpg" />            Jeden z zagranicznych serwis&oacute;w opublikował zdjęcia oficjalnych etui od Google na nadchodzące smartfony Pixel 7 oraz Pixel 7 Pro. Dla podstawowego modelu pojawią się wersje&nbsp;Lemongrass,&nbsp;Obsidian i&nbsp;Chalk. Ten z dopiskiem Pro...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tak_wygladaja_oficjalne_etui_na_smartfony_google_pixel_7_i_pixel_7_pro-23425.html">https://ithardware.p

## Telefony gamingowe - ranking na wrzesień 2022
 - [https://ithardware.pl/rankingi/telefony_gamingowe_ranking_na_wrzesien_2022-23420.html](https://ithardware.pl/rankingi/telefony_gamingowe_ranking_na_wrzesien_2022-23420.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 13:14:40+00:00

<img src="https://ithardware.pl/artykuly/min/23420_1.jpg" />            Na początku trzeba dostosować swoje oczekiwania względem takich p&oacute;łek cenowych jak 500 czy nawet 1000 zł. Smartfon do gier to przede wszystkim mocny SoC (system on chip), czyli połączenie procesora, jednostki centralnej oraz karty...
            <p>Pełna wersja strony <a href="https://ithardware.pl/rankingi/telefony_gamingowe_ranking_na_wrzesien_2022-23420.html">https://ithardware.pl/rankingi/telefony_gamingowe_rankin

## Metawersum pogrąży Zuckerberga? CEO Meta stracił już 70 mld USD, notowania firmy lecą w dół
 - [https://ithardware.pl/aktualnosci/metawersum_pograzy_zuckerberga_ceo_meta_stracil_juz_70_mld_usd_notowania_firmy_leca_w_dol-23424.html](https://ithardware.pl/aktualnosci/metawersum_pograzy_zuckerberga_ceo_meta_stracil_juz_70_mld_usd_notowania_firmy_leca_w_dol-23424.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 12:20:20+00:00

<img src="https://ithardware.pl/artykuly/min/23424_1.jpg" />            Wartość&nbsp;założyciela Facebooka Marka Zuckerberga spadła o 71 miliard&oacute;w dolar&oacute;w w samym 2022 roku. Jest to największy spadek spośr&oacute;d wszystkich miliarder&oacute;w analizowanych przez Bloomberga. W tym jednak przypadku...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/metawersum_pograzy_zuckerberga_ceo_meta_stracil_juz_70_mld_usd_notowania_firmy_leca_w_dol-23424.html">htt

## Rozwijany smartfon od LG pojawił się w pierwszej recenzji. Wygląda niesamowicie
 - [https://ithardware.pl/aktualnosci/rozwijany_smartfon_od_lg_pojawil_sie_w_pierwszej_recenzji_wyglada_niesamowicie-23423.html](https://ithardware.pl/aktualnosci/rozwijany_smartfon_od_lg_pojawil_sie_w_pierwszej_recenzji_wyglada_niesamowicie-23423.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 12:13:40+00:00

<img src="https://ithardware.pl/artykuly/min/23423_1.jpg" />            Do sieci trafiła pierwsza recenzja rozwijanego smartfona od LG. Urządzenie nosi nazwę Rollable i pojawiło się na jednym z koreańskich kanał&oacute;w YouTube. Autorowi filmu udało się ponoć zdobyć prawie ukończony egzemplarz, kt&oacute;ry...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rozwijany_smartfon_od_lg_pojawil_sie_w_pierwszej_recenzji_wyglada_niesamowicie-23423.html">https://ithardware

## Elon Musk poprosi o zwolnienie z sankcji USA wobec Iranu
 - [https://ithardware.pl/aktualnosci/elon_musk_poprosi_o_zwolnienie_z_sankcji_usa_wobec_iranu-23422.html](https://ithardware.pl/aktualnosci/elon_musk_poprosi_o_zwolnienie_z_sankcji_usa_wobec_iranu-23422.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 11:39:10+00:00

<img src="https://ithardware.pl/artykuly/min/23422_1.jpg" />            Internet satelitarny Elona Muska działa już niemal na całym świecie, jednak na mapie wciąż znajdują się czarne plamy.&nbsp;Jednym z takich miejsc jest Iran, gdzie Starlink nie może funkcjonować ze względu na nałożone przez USA...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/elon_musk_poprosi_o_zwolnienie_z_sankcji_usa_wobec_iranu-23422.html">https://ithardware.pl/aktualnosci/elon_musk_poprosi

## NVIDIA o możliwościach OC GeForce'a RTX 4090: Udało nam się wykręcić 3 GHz
 - [https://ithardware.pl/aktualnosci/nvidia_o_mozliwosciach_oc_geforce_a_rtx_4090_udalo_nam_sie_wykrecic_3_ghz-23414.html](https://ithardware.pl/aktualnosci/nvidia_o_mozliwosciach_oc_geforce_a_rtx_4090_udalo_nam_sie_wykrecic_3_ghz-23414.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 11:11:01+00:00

<img src="https://ithardware.pl/artykuly/min/23414_1.png" />            NVIDIA potwierdziła, że ​​ich GPU z rodziny Ada Lovelace, kt&oacute;re napędzają nowe karty graficzne GeForce RTX 4090 i RTX 4080, mogą zostać podkręcone powyżej 3 GHz.

Podczas prezentacji &bdquo;GeForce Beyond&rdquo; dyrektor generalny...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_o_mozliwosciach_oc_geforce_a_rtx_4090_udalo_nam_sie_wykrecic_3_ghz-23414.html">https://ithardware.pl/a

## EVGA samo było sobie winne niskich zysków z kart graficznych? Nowe doniesienia
 - [https://ithardware.pl/aktualnosci/evga_samo_bylo_sobie_winne_niskich_zyskow_z_kart_graficznych_nowe_doniesienia-23412.html](https://ithardware.pl/aktualnosci/evga_samo_bylo_sobie_winne_niskich_zyskow_z_kart_graficznych_nowe_doniesienia-23412.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 10:48:01+00:00

<img src="https://ithardware.pl/artykuly/min/23412_1.jpg" />            W miniony weekend firma EVGA ogłosiła, że ​​nie będzie już produkować kart graficznych, co dla wielu os&oacute;b było dużym zaskoczeniem, szczeg&oacute;lnie na moment przed ujawnieniem przez NVIDIĘ nowej generacji kart, GeForce RTX 4000....
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/evga_samo_bylo_sobie_winne_niskich_zyskow_z_kart_graficznych_nowe_doniesienia-23412.html">https://ithardware.

## Palit i Gainward prezentują nowe karty graficzne z serii GeForce RTX 4000
 - [https://ithardware.pl/aktualnosci/palit_i_gainward_prezentuja_nowe_karty_graficzne_z_serii_geforce_rtx_4000-23419.html](https://ithardware.pl/aktualnosci/palit_i_gainward_prezentuja_nowe_karty_graficzne_z_serii_geforce_rtx_4000-23419.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 10:15:00+00:00

<img src="https://ithardware.pl/artykuly/min/23419_1.jpg" />            Następstwem wczorajszej prezentacji układ&oacute;w graficznych z rodziny Ada Lovelace są zapowiedzi nowych kart graficznych partner&oacute;w firmy NVIDIA. Jednym z producent&oacute;w, kt&oacute;ry przedstawił nadchodzące produkty, jest Palit,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/palit_i_gainward_prezentuja_nowe_karty_graficzne_z_serii_geforce_rtx_4000-23419.html">https://ithardware

## Afganistan: Talibowie zakazują TikToka za negatywny wpływ na dzieci i młodzież
 - [https://ithardware.pl/aktualnosci/afganistan_talibowie_zakazuja_tiktoka_za_negatywny_wplyw_na_dzieci_i_mlodziez-23421.html](https://ithardware.pl/aktualnosci/afganistan_talibowie_zakazuja_tiktoka_za_negatywny_wplyw_na_dzieci_i_mlodziez-23421.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 10:12:10+00:00

<img src="https://ithardware.pl/artykuly/min/23421_1.jpg" />            Rząd talib&oacute;w w Afganistanie zakazał&nbsp;wywodzącej się z Chin sieci społecznościowej TikTok i popularnej strzelanki PUBG.

PUBG i TikTok są popularne w Afganistanie, biorąc pod uwagę, że Afgańczycy nie mają zbyt wiele rozrywki po...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/afganistan_talibowie_zakazuja_tiktoka_za_negatywny_wplyw_na_dzieci_i_mlodziez-23421.html">https://ithardware.

## Star Citizen to fenomen crowdfundingu. Twórcy zebrali od wspierających pół miliarda dolarów
 - [https://ithardware.pl/aktualnosci/star_citizen_to_fenomen_crowdfundingu_tworcy_zebrali_od_wspierajacych_pol_miliarda_dolarow-23411.html](https://ithardware.pl/aktualnosci/star_citizen_to_fenomen_crowdfundingu_tworcy_zebrali_od_wspierajacych_pol_miliarda_dolarow-23411.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 09:28:01+00:00

<img src="https://ithardware.pl/artykuly/min/23411_1.jpg" />            O Star Citizen, czyli kosmicznym RPG o niezwykle ambitnych założeniach, pisaliśmy już wielokrotnie, bo ta gra to swoisty fenomen, bijący wszelkie rekordy crowdfundingu. Oficjalny licznik do śledzenia finansowania społecznościowego tego projektu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/star_citizen_to_fenomen_crowdfundingu_tworcy_zebrali_od_wspierajacych_pol_miliarda_dolarow-23411.html"

## USA przeznaczy prawie 700 000 dolarów na szukanie „ekstremizmu” w grach wideo
 - [https://ithardware.pl/aktualnosci/usa_przeznaczy_prawie_700_000_dolarow_na_szukanie_ekstremizmu_w_grach_wideo-23418.html](https://ithardware.pl/aktualnosci/usa_przeznaczy_prawie_700_000_dolarow_na_szukanie_ekstremizmu_w_grach_wideo-23418.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 09:24:10+00:00

<img src="https://ithardware.pl/artykuly/min/23418_1.jpg" />            Departament Bezpieczeństwa Wewnętrznego (DHS) przyznał naukowcom grant w wysokości 699 768 USD na zbadanie ekstremizmu w grach.

Jak donosi&nbsp;VICE, pieniądze trafią do Logically, firmy zajmującej się problemem &bdquo;złego&rdquo; zachowania...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/usa_przeznaczy_prawie_700_000_dolarow_na_szukanie_ekstremizmu_w_grach_wideo-23418.html">https://ithardw

## Gigabyte prezentuje autorskie wersje kart graficznych GeForce RTX 4000
 - [https://ithardware.pl/aktualnosci/gigabyte_prezentuje_autorskie_wersje_kart_graficznych_geforce_rtx_4000-23417.html](https://ithardware.pl/aktualnosci/gigabyte_prezentuje_autorskie_wersje_kart_graficznych_geforce_rtx_4000-23417.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 08:51:40+00:00

<img src="https://ithardware.pl/artykuly/min/23417_1.jpg" />            Gigabyte oficjalnie wprowadza do portfolio autorskie wersje kart graficznych AORUS GeForce RTX 4000. Wśr&oacute;d nich znajdziemy GeForce RTX 4090 AORUS XTREME WATERFORCE, AORUS MASTER, GAMING OC i WINDFORCE.

Oficjalny pokaz NVIDII już za nami, na...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gigabyte_prezentuje_autorskie_wersje_kart_graficznych_geforce_rtx_4000-23417.html">https://ithardw

## Amazon wspiera UE w testach cyfrowego euro. Cyfrowa waluta banku centralnego coraz bliżej
 - [https://ithardware.pl/aktualnosci/amazon_wspiera_ue_w_testach_cyfrowego_euro_cyfrowa_waluta_banku_centralnego_coraz_blizej-23416.html](https://ithardware.pl/aktualnosci/amazon_wspiera_ue_w_testach_cyfrowego_euro_cyfrowa_waluta_banku_centralnego_coraz_blizej-23416.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 08:05:20+00:00

<img src="https://ithardware.pl/artykuly/min/23416_1.jpg" />            Amazon jest jedną z pięciu firm wybranych przez Europejski Bank Centralny (EBC) do pomocy w opracowaniu interfejs&oacute;w użytkownika dla cyfrowego euro.

EBC oficjalnie rozpoczął&nbsp;&nbsp;we wrześniu ubiegłego roku race...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amazon_wspiera_ue_w_testach_cyfrowego_euro_cyfrowa_waluta_banku_centralnego_coraz_blizej-23416.html">https://ithardware.pl/

## AMD prezentuje pierwsze mobilne procesory z serii Ryzen 7000
 - [https://ithardware.pl/aktualnosci/amd_prezentuje_pierwsze_mobilne_procesory_z_serii_ryzen_7000-23410.html](https://ithardware.pl/aktualnosci/amd_prezentuje_pierwsze_mobilne_procesory_z_serii_ryzen_7000-23410.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 08:04:01+00:00

<img src="https://ithardware.pl/artykuly/min/23410_1.png" />            O mobilnych układach Mendocino słyszeliśmy już w maju, kiedy to AMD uchyliło rąbka tajemnicy podczas targ&oacute;w Computex 2022. Teraz producent zaprezentował swoje pierwsze procesory z tej serii i co ciekawe należą one do rodziny...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_prezentuje_pierwsze_mobilne_procesory_z_serii_ryzen_7000-23410.html">https://ithardware.pl/aktualnosci/amd_prez

## 2K Games zhakowane. Firma radzi graczom zmienić hasła
 - [https://ithardware.pl/aktualnosci/2k_games_zhakowane_firma_radzi_graczom_zmienic_hasla-23413.html](https://ithardware.pl/aktualnosci/2k_games_zhakowane_firma_radzi_graczom_zmienic_hasla-23413.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 07:48:00+00:00

<img src="https://ithardware.pl/artykuly/min/23413_1.jpg" />            Ostatni czas stoi pod znakiem bardzo wzmożonej aktywności haker&oacute;w. Wystarczy przywołać ogromny wyciek GTA 6 czy zhakowanie Ubera i Revoluta, a do tego grona dołącza właśnie 2K Games. Wydawca, kt&oacute;rego właścicielem jest Take-Two,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/2k_games_zhakowane_firma_radzi_graczom_zmienic_hasla-23413.html">https://ithardware.pl/aktualnosci/2k_gam

## Hikvision prezentuje karty pamięci SD do zastosowań uniwersalnych
 - [https://ithardware.pl/aktualnosci/hikvision_prezentuje_karty_pamieci_sd_do_zastosowan_uniwersalnych-23415.html](https://ithardware.pl/aktualnosci/hikvision_prezentuje_karty_pamieci_sd_do_zastosowan_uniwersalnych-23415.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 07:39:21+00:00

<img src="https://ithardware.pl/artykuly/min/23415_1.jpg" />            Lider branży Security rozszerza swoje portfolio o kolejne podzespoły komputerowe - karty, pamięci SD marki Hikstorage.

Portfolio Hikvision, międzynarodowego lidera z zakresu system&oacute;w bezpieczeństwa i, monitoringu wizyjnego, rozszerza się...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hikvision_prezentuje_karty_pamieci_sd_do_zastosowan_uniwersalnych-23415.html">https://ithardware.pl/a

## Nowe karty graficzne NVIDII są dużo droższe w Europie (w tym Polsce) niż w USA
 - [https://ithardware.pl/aktualnosci/nowe_krty_graficzne_nvidii_sa_duzo_drozsze_w_europie_w_tym_polsce_niz_w_usa-23409.html](https://ithardware.pl/aktualnosci/nowe_krty_graficzne_nvidii_sa_duzo_drozsze_w_europie_w_tym_polsce_niz_w_usa-23409.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 07:08:53+00:00

<img src="https://ithardware.pl/artykuly/min/23409_1.jpg" />            Wczoraj NVIDIA ogłosiła swoje karty graficzne GeForce RTX 4090 i RTX 4080. W sieci bardzo szybko zawrzało, gł&oacute;wnie z powodu cen tych grafik, a gracze głośno wyrażają swoje niezadowolenie choćby z 12 GB wariantu GeForce'a RTX 4080,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowe_krty_graficzne_nvidii_sa_duzo_drozsze_w_europie_w_tym_polsce_niz_w_usa-23409.html">https://ithardware.pl

## GPU AD102 w szczegółach. Wiemy, jak może wyglądać GeForce RTX 4090 Ti
 - [https://ithardware.pl/aktualnosci/gpu_ad102_w_szczegolach_wiemy_jak_moze_wygladac_geforce_rtx_4090_ti-23408.html](https://ithardware.pl/aktualnosci/gpu_ad102_w_szczegolach_wiemy_jak_moze_wygladac_geforce_rtx_4090_ti-23408.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-21 06:14:28+00:00

<img src="https://ithardware.pl/artykuly/min/23408_1.jpg" />            Wczorajsza konferencja NVIDII koncentrowała się gł&oacute;wnie na trzech kartach graficznych nowej generacji, czyli GeForce RTX 4090, GeForce RTX 4080 16 GB i GeForce RTX 4080 12 GB, ale partnerzy ujawnili także dodatkowe szczeg&oacute;ły na temat...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gpu_ad102_w_szczegolach_wiemy_jak_moze_wygladac_geforce_rtx_4090_ti-23408.html">https://ithardware.


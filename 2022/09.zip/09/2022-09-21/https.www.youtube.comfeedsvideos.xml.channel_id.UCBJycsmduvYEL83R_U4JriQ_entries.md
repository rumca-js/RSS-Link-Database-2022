# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Apple Watch Ultra Review: Worth It Or Nah?
 - [https://www.youtube.com/watch?v=HjEqOWjTkHE](https://www.youtube.com/watch?v=HjEqOWjTkHE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-09-21 00:00:00+00:00

The Apple Watch Ultra is $800, which makes it worth it only for a certain set of people...

Grab an MKBHD x Moment Apple Watch leather strap: https://mkbhd.com

Waveform podcast interviews: https://youtu.be/vGlbCM2coDU?t=2762

Check out the Apple Watch Ultra at https://geni.us/BslguaO
Check out the Apple Watch Series 8 at https://geni.us/lBcRAy

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Dive computers: https://www.divein.com/diving/dive-computer/

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Watch provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


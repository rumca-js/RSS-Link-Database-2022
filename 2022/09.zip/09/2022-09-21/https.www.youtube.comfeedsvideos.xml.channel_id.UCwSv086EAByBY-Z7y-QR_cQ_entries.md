# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Projekt ustawy o ochronie ludności cywilnej. Analiza zagrożeń
 - [https://www.youtube.com/watch?v=lX3O9mhnS3U](https://www.youtube.com/watch?v=lX3O9mhnS3U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-09-22 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3LyCCWS
2. https://bit.ly/3Uvpplw
3. https://bit.ly/3r0UmAG
4. https://bit.ly/3Uw5fIg
5. https://bit.ly/3UxzRsH
6. https://bit.ly/3BBisa0
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę autorstwa: 
gov.pl - http://bit.ly/2lVWjQr
---------------------------------------------------------------
💡 Tagi: #polityka #UD432
--------------------------------------------------------------

## Polski żołnierz nad Dnieprem! Szczegóły Kijowskiego Układu Bezpieczeństwa.
 - [https://www.youtube.com/watch?v=NLC57f7hrEo](https://www.youtube.com/watch?v=NLC57f7hrEo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-09-21 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3AEK0uJ
2. https://bit.ly/3xBGrEX
3. https://bit.ly/3BC4Wmu
4. https://bit.ly/3fcziok
5. https://bit.ly/3Skga5N
6. https://bit.ly/3Lv0fzs
7. https://bit.ly/3S0ThEJ
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę autorstwa: 
RepublikanieTV - linki poniżej
https://bit.ly/3EJXbhq 
https://bit.ly/3T3buSB
na licencji CC BY 3.0
https://bit.ly/2vZATHO
---
gov.pl - https://bit.ly/3y3Py1x
---------------------------------------------------------------
💡 Tagi: #Kijów #NATO
--------------------------------------------------------------


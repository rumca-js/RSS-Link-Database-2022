# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Salesforce is getting into bed with WhatsApp
 - [https://www.techradar.com/news/salesforce-is-getting-into-bed-with-whatsapp/](https://www.techradar.com/news/salesforce-is-getting-into-bed-with-whatsapp/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 22:54:57+00:00

Salesforce has partnered with Meta to help customers build closer relationships with customers.

## iPhone 15 Pro could get the fastest connection possible
 - [https://www.techradar.com/news/iphone-15-pro-could-get-the-fastest-connection-possible/](https://www.techradar.com/news/iphone-15-pro-could-get-the-fastest-connection-possible/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 22:12:53+00:00

A leak says Apple will go USB-C for the iPhone 15, with the Pro and Ultra phones getting a powerful Thunderbolt 4 port for much faster data transfer.

## This Chromebook lets you do your own memory and storage upgrades
 - [https://www.techradar.com/news/you-next-chromebook-might-be-upgradable-by-you/](https://www.techradar.com/news/you-next-chromebook-might-be-upgradable-by-you/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 22:01:58+00:00

Framework's latest offering allows you to upgrade the RAM and offers the full ChromeOS experience.

## Seagate and Western Digital predict a grim future for storage media sales
 - [https://www.techradar.com/news/seagate-and-western-digital-predict-a-grim-future-for-storage-media-sales/](https://www.techradar.com/news/seagate-and-western-digital-predict-a-grim-future-for-storage-media-sales/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 21:21:50+00:00

The digital media storage industry is weathering several storms at once.

## OnePlus 11 Pro leak leaves us with more questions than enthusiasm
 - [https://www.techradar.com/news/oneplus-11-pro-leak-leaves-us-with-more-questions-than-enthusiasm/](https://www.techradar.com/news/oneplus-11-pro-leak-leaves-us-with-more-questions-than-enthusiasm/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 21:06:57+00:00

A new leak suggests the OnePlus 11 Pro will use even better Qualcomm processors and upgrade the telephoto camera from the OnePlus 10 Pro. Not all specs are an improvement, though.

## Yet another major crypto firm has been hacked
 - [https://www.techradar.com/news/yet-another-major-crypto-firm-has-been-hacked/](https://www.techradar.com/news/yet-another-major-crypto-firm-has-been-hacked/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 20:13:29+00:00

Wintermute sees roughly $160 million in various tokens stolen, but the company is still solvent.

## 2K Games helpdesk hacked to spread malware to players
 - [https://www.techradar.com/news/2k-games-helpdesk-hacked-to-spread-malware-to-players/](https://www.techradar.com/news/2k-games-helpdesk-hacked-to-spread-malware-to-players/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 19:08:51+00:00

Gaming giant warns players not to open any support emails while it investigates.

## Google wants to help remove your personal details from its search results
 - [https://www.techradar.com/news/google-wants-to-help-remove-your-personal-details-from-its-search-results/](https://www.techradar.com/news/google-wants-to-help-remove-your-personal-details-from-its-search-results/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 17:51:44+00:00

New feature for Google Android app helps users remove PII easily.

## Forget HomePod 2, all AirPlay speakers could soon get full Apple TV 4K support
 - [https://www.techradar.com/news/forget-homepod-2-all-airplay-speakers-could-soon-get-full-apple-tv-4k-support/](https://www.techradar.com/news/forget-homepod-2-all-airplay-speakers-could-soon-get-full-apple-tv-4k-support/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 17:41:00+00:00

Right now, only HomePods can be set as default speakers for Apple TV 4K, but according to beta code found in iOS 16.1, it's a trick any AirPlay 2 speaker might soon be able to pull off.

## Even horse racing isn't safe from ransomware now
 - [https://www.techradar.com/news/even-horse-racing-isnt-safe-from-ransomware-now/](https://www.techradar.com/news/even-horse-racing-isnt-safe-from-ransomware-now/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 17:01:26+00:00

Ransomware attack hits the New York Racing Association, with some employee data leaked.

## Wix now has its own keyword search tool
 - [https://www.techradar.com/news/wix-now-has-its-own-keyword-search-tool/](https://www.techradar.com/news/wix-now-has-its-own-keyword-search-tool/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 16:25:57+00:00

Wix users can leverage Semrush’s SEO tools and keyword database to increase their visibility in search results.

## Iranian authorities restrict Instagram as last effort to silence protesters
 - [https://www.techradar.com/news/iranian-authorities-restricts-instagram-as-last-effort-to-silence-protesters/](https://www.techradar.com/news/iranian-authorities-restricts-instagram-as-last-effort-to-silence-protesters/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 16:24:24+00:00

People in Iran need to use a VPN to access one of the last social media platforms available across the country.

## Major Google Tasks upgrade means it might finally be worth using now
 - [https://www.techradar.com/news/major-google-tasks-upgrade-means-it-might-finally-be-worth-using-now/](https://www.techradar.com/news/major-google-tasks-upgrade-means-it-might-finally-be-worth-using-now/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 16:02:57+00:00

Upgraded Google Tasks should mean you never miss a job again.

## Torvalds confirms Rust is coming to the new version of Linux
 - [https://www.techradar.com/news/torvalds-confirms-rust-is-coming-to-the-new-version-of-linux/](https://www.techradar.com/news/torvalds-confirms-rust-is-coming-to-the-new-version-of-linux/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 15:17:51+00:00

After pressure from Google and the wider dev community, Linux will soon support Rust, Torvalds confirms.

## This robot toy nibbles my finger - and I'm okay with that
 - [https://www.techradar.com/news/this-robot-toy-nibbles-my-finger-and-im-okay-with-that/](https://www.techradar.com/news/this-robot-toy-nibbles-my-finger-and-im-okay-with-that/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 14:36:14+00:00

Amagami Ham Ham robot bear is just as strange as you think it is

## Here’s why we shouldn’t get carried away with Nvidia’s DLSS 3 frame rate booster
 - [https://www.techradar.com/news/heres-why-we-shouldnt-get-carried-away-with-nvidias-dlss-3-frame-rate-booster/](https://www.techradar.com/news/heres-why-we-shouldnt-get-carried-away-with-nvidias-dlss-3-frame-rate-booster/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 14:35:51+00:00

Rein in your expectations somewhat around DLSS 3 – it sounds fantastic, but has caveats.

## Nvidia wants its first SaaS product to help power the metaverse
 - [https://www.techradar.com/news/nvidia-wants-its-first-saas-product-to-help-power-the-metaverse/](https://www.techradar.com/news/nvidia-wants-its-first-saas-product-to-help-power-the-metaverse/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 14:26:34+00:00

Nvidia has launched an array of SaaS tools to help developers prepare for the future of the web: the metaverse.

## iPad Crayon maker slips, possibly confirms new Apple iPad Pros are coming
 - [https://www.techradar.com/news/ipad-crayon-maker-slips-possibly-confirms-new-apple-ipad-pros-are-coming/](https://www.techradar.com/news/ipad-crayon-maker-slips-possibly-confirms-new-apple-ipad-pros-are-coming/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 14:14:52+00:00

Logitech has added compatibility to its Crayon Digital Pencil to include two new iPads Pro that have not been announced.

## Vodafone combines connectivity and services into a single SMB subscription
 - [https://www.techradar.com/news/vodafone-combines-connectivity-and-services-into-a-single-smb-subscription/](https://www.techradar.com/news/vodafone-combines-connectivity-and-services-into-a-single-smb-subscription/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 13:13:43+00:00

Vodafone targets SMB market with new combined proposition.

## Voice deepfakes are getting easier to spot
 - [https://www.techradar.com/news/voice-deepfakes-are-getting-easier-to-spot/](https://www.techradar.com/news/voice-deepfakes-are-getting-easier-to-spot/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 13:04:57+00:00

Researchers at the University of Florida have described the findings as “comical”.

## Amazon Fire HD 8 (2022): Amazon's new cheap tablet is here with three siblings
 - [https://www.techradar.com/news/amazon-fire-hd-8-2022/](https://www.techradar.com/news/amazon-fire-hd-8-2022/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 13:01:34+00:00

The Amazon Fire HD 8 (2022) is here, and we've got everything you need to know about it.

## Why the Mobile Phone Museum's mission is to preserve the history of handsets
 - [https://www.techradar.com/news/why-the-mobile-phone-museums-mission-is-to-preserve-the-history-of-handsets/](https://www.techradar.com/news/why-the-mobile-phone-museums-mission-is-to-preserve-the-history-of-handsets/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 11:56:37+00:00

Ahead of the 2022 Mobile Industry Awards, Ben Wood explains why the museum wants to preserve and document the history of the mobile phone

## Brush up on your security knowledge with these back to school security tips
 - [https://www.techradar.com/news/brush-up-on-your-security-knowledge-with-these-back-to-school-security-tips/](https://www.techradar.com/news/brush-up-on-your-security-knowledge-with-these-back-to-school-security-tips/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 11:43:05+00:00

Don't forget these key security actions as you get back into the swing of things.

## The best laptops for your hybrid workforce
 - [https://www.techradar.com/news/the-best-laptops-for-your-hybrid-workforce/](https://www.techradar.com/news/the-best-laptops-for-your-hybrid-workforce/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 11:19:28+00:00

We've taken a look at some of the best devices around today.

## How to secure your hybrid workforce
 - [https://www.techradar.com/news/how-to-secure-your-hybrid-workforce/](https://www.techradar.com/news/how-to-secure-your-hybrid-workforce/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 11:19:00+00:00

In a changing working world, the need for security is greater than ever.

## Accessibility improvements in Windows 11 and iOS 16 show promise for the future
 - [https://www.techradar.com/news/accessibility-improvements-in-windows-11-and-ios-16-show-promise-for-the-future/](https://www.techradar.com/news/accessibility-improvements-in-windows-11-and-ios-16-show-promise-for-the-future/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 11:16:34+00:00

Opinion: Accessibility has long been a hidden menu, but it's finally becoming a front and center feature, as it should be.

## Oracle Cloud admits users could access other customer data
 - [https://www.techradar.com/news/oracle-cloud-admits-users-could-access-other-customer-data/](https://www.techradar.com/news/oracle-cloud-admits-users-could-access-other-customer-data/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 10:51:13+00:00

Lack of permissions verification in the AttachVolume API caused a lot of trouble for Oracle.

## Ted Lasso FIFA 23 tease won't make the show's off the field issues go away
 - [https://www.techradar.com/news/ted-lasso-fifa-23-tease-wont-make-the-shows-off-the-field-issues-go-away/](https://www.techradar.com/news/ted-lasso-fifa-23-tease-wont-make-the-shows-off-the-field-issues-go-away/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 09:47:01+00:00

Ted Lasso and AFC Richmond are reportedly coming to FIFA 23 – but the announcement feels like a distraction tactic.

## The Google Pixel 7 might ship a lot sooner than the Pixel Watch
 - [https://www.techradar.com/news/the-google-pixel-7-might-ship-a-lot-sooner-than-the-pixel-watch/](https://www.techradar.com/news/the-google-pixel-7-might-ship-a-lot-sooner-than-the-pixel-watch/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 09:38:20+00:00

Shipping dates for both the Pixel 7 and Pixel Watch have leaked, with pricing and colors for the latter leaking too.

## Nvidia RTX 4090 and 4080 GPUs could be more expensive than you think
 - [https://www.techradar.com/news/nvidia-rtx-4090-and-4080-gpus-could-be-more-expensive-than-you-think/](https://www.techradar.com/news/nvidia-rtx-4090-and-4080-gpus-could-be-more-expensive-than-you-think/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 09:32:18+00:00

If true, this might leave an opportunity for AMD to win big on the value front.

## Would you sell your data for profit? Nearly 50% of Americans said they would
 - [https://www.techradar.com/news/would-you-sell-your-data-for-profit-nearly-50-of-americans-said-they-would/](https://www.techradar.com/news/would-you-sell-your-data-for-profit-nearly-50-of-americans-said-they-would/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 08:33:41+00:00

Big tech firms already make a lots of money off your data. That's why many would prefer to cash them off themselves.

## Everything confirmed in the GTA 6 leak, including setting, characters, and combat
 - [https://www.techradar.com/news/everything-confirmed-in-the-gta-6-leak-including-setting-characters-and-combat/](https://www.techradar.com/news/everything-confirmed-in-the-gta-6-leak-including-setting-characters-and-combat/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-21 04:00:34+00:00

The mother of all leaks has confirmed a whole lot of details about Grand Theft Auto 6.


# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## KNIGHTS OF 40K - DEFENDERS OF THE FARTHEST FRONTIER | Warhammer 40,000 Lore/History
 - [https://www.youtube.com/watch?v=TBSsIpTSyqs](https://www.youtube.com/watch?v=TBSsIpTSyqs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2022-09-21 00:00:00+00:00

Go to http://www.audible.com/luetin or text luetin to 500 500 to get your free trial
► Subscribe: http://goo.gl/oeZMBS 
► Crystal Fortress Premium Storage: http://bit.ly/3oFuDf7
► Patreon: https://www.patreon.com/Luetin 
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

Visual edits of Knights - https://twitter.com/ArtistsEmpire

Timestamps:
0:00 Intro
2:03 Guardians of the Galaxy
4:52 Into the Void
15:07 Machine Spirit
26:05 The Throne
32:03 Knights Dominion
41:06 Knight Houses Armoury
49:30 A Tradition of Stability
1:01:00 Outro

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.


# Source:ComputerWorld, URL:https://www.computerworld.com/index.rss, language:en-US

## Six in 10 workers want to ditch the 40-hour work week, survey finds
 - [https://www.computerworld.com/article/3674668/six-in-10-workers-want-to-ditch-the-40-hour-work-week-survey-finds.html#tk.rss_all](https://www.computerworld.com/article/3674668/six-in-10-workers-want-to-ditch-the-40-hour-work-week-survey-finds.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-09-21 21:18:00+00:00

<article>
	<section class="page">
<p>Workers want their productivity measured by the results they achieve, not by how many hours they log during the work week, according to a <a href="https://static.adaptavistassets.com/downloads/Adaptavist_Digital_Etiquette-Reinventing_Work_Report.pdf" rel="noopener nofollow" target="_blank">survey of 3,500 employees in the US, UK, Australia and Canada</a>.</p><p>The survey by business software and services provider Adaptavist found 58% of workers want to elimi

## A tale of two companies: How Intel and Dell are creating better places to work
 - [https://www.computerworld.com/article/3674155/a-tale-of-two-companies-how-intel-and-dell-are-creating-better-places-to-work.html#tk.rss_all](https://www.computerworld.com/article/3674155/a-tale-of-two-companies-how-intel-and-dell-are-creating-better-places-to-work.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-09-21 16:53:00+00:00

<article>
	<section class="page">
<p><em>Disclosure: Dell and Intel are clients of the author.</em></p><p>Last week, I visited Intel’s <a href="https://tgdaily.com/technology/how-intels-israel-development-center-is-driving-the-future-renaissance-of-the-company/" rel="noopener nofollow" target="_blank">Israel Development Center</a>; this week I spoke with <a href="https://www.dell.com/en-us/dt/corporate/about-us/leadership/jennifer-saavedra.htm" rel="noopener nofollow" target="_blank">Jenn Saaved

## How to share Safari Tab Groups on iPhone
 - [https://www.computerworld.com/article/3674217/how-to-share-safari-tab-groups-on-iphone.html#tk.rss_all](https://www.computerworld.com/article/3674217/how-to-share-safari-tab-groups-on-iphone.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-09-21 15:20:00+00:00

<article>
	<section class="page">
<p>Apple's latest addition to the litany of tools for project and research collaboration, while inherently limited to Mac, iPhone, and iPad users, might even be of use to pros from time to time.</p><h2><strong>Apple’s keeping tabs for you</strong></h2>
<p>Despite wailing from bookmark reactionaries like myself, Apple seems truly committed to the notion of organizing the web using tabs, rather than traditional bookmarks. It introduced Tab Groups with iOS 15.</p><


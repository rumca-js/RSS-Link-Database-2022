# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Medwedczuk za obrońców Azowstalu. Największa wymiana jeńców między Ukrainą a Rosją
 - [https://www.bankier.pl/wiadomosc/Medwedczuk-za-obroncow-Azowstalu-Najwieksza-wymiana-jencow-miedzy-Ukraina-a-Rosja-8409890.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Medwedczuk-za-obroncow-Azowstalu-Najwieksza-wymiana-jencow-miedzy-Ukraina-a-Rosja-8409890.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 23:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/6/5a2fe89b296d22-948-568-48-73-1232-739.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szef gabinetu prezydenta Ukrainy  Andrij Jermak poinformował w czwartek, że w rezultacie wymiany jeńców uzgodnionej za pośrednictwem prezydenta Turcji udało się uwolnić z rosyjskiej niewoli 215 ukraińskich obrońców, w tym 10-ciu cudzoziemców.</p>

## Zagadkowa śmierć rosyjskiego naukowca. Sprawował pieczę na czarną skrzynką polskiego tupolewa
 - [https://www.bankier.pl/wiadomosc/Zagadkowa-smierc-rosyjskiego-naukowca-Sprawowal-piecze-na-czarna-skrzynka-polskiego-tupolewa-8409887.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zagadkowa-smierc-rosyjskiego-naukowca-Sprawowal-piecze-na-czarna-skrzynka-polskiego-tupolewa-8409887.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 23:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/ac8e4cfeaa0eb1-945-560-0-33-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Były szef Moskiewskiego Instytutu Lotnictwa Anatolij Geraszczenko, który zmarł w środę w wyniku "wypadku", zajmował się przechowywaniem czarnych skrzynek rządowego Tu-154M, który 10 kwietnia 2010 r. rozbił się pod Smoleńskiem - czytamy  na portalu niezależna.pl.</p>

## Fed spowodował wyprzedaż akcji na Wall Street
 - [https://www.bankier.pl/wiadomosc/Fed-spowodowal-wyprzedaz-akcji-na-Wall-Street-8409879.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fed-spowodowal-wyprzedaz-akcji-na-Wall-Street-8409879.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 22:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/1/17a8bdf702b3ff-948-568-115-250-1885-1130.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Środowa sesja na Wall Street rozpoczęła się od wzrostów, ale po ogłoszeniu decyzji o podwyżce stóp proc. przez Fed o 75 pb i komentarzach prezesa Jerome'a Powella inwestorzy zaczęli wyprzedawać akcje i w efekcie główne indeksy zakończyły dzień na sporych minusach.</p>

## Rekordową ilość pieniędzy wysłali do kraju portugalscy emigranci
 - [https://www.bankier.pl/wiadomosc/Rekordowa-ilosc-pieniedzy-wyslali-do-kraju-portugalscy-emigranci-8409873.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rekordowa-ilosc-pieniedzy-wyslali-do-kraju-portugalscy-emigranci-8409873.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 21:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/4/b3d4a56bb165e3-945-567-17-60-3465-2079.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Obywatele Portugalii żyjący na emigracji przesłali w pierwszej połowie tego roku do ojczyzny prawie 1,85 mld euro, nienotowaną wcześniej sumę pieniędzy.</p>

## Szacunkowe wyniki Grupy Azoty w II kwartale powyżej oczekiwań analityków
 - [https://www.bankier.pl/wiadomosc/Szacunkowe-wyniki-Grupy-Azoty-w-II-kwartale-powyzej-oczekiwan-analitykow-8409871.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szacunkowe-wyniki-Grupy-Azoty-w-II-kwartale-powyzej-oczekiwan-analitykow-8409871.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 21:30:00+00:00

<p>Grupa Azoty wstępnie szacuje, że jej zysk netto w drugim kwartale 2022 roku wyniósł 800 mln zł, EBITDA sięgnęła 1,24 mld zł, zysk operacyjny 1,06 mld zł, a przychody 6,41 mld zł - poinformowała spółka w komunikacie. Wyniki Grupy Azoty są lepsze od oczekiwań analityków ankietowanych przez PAP Biznes.</p>

## Także Turcja nie uzna referendów na wschodzie i południu Ukrainy
 - [https://www.bankier.pl/wiadomosc/Takze-Turcja-nie-uzna-referendow-na-wschodzie-i-poludniu-Ukrainy-8409859.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Takze-Turcja-nie-uzna-referendow-na-wschodzie-i-poludniu-Ukrainy-8409859.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 20:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/bb6eb39ea024d7-948-568-0-45-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo spraw zagranicznych Turcji zapowiedziało w środę, że nie uzna referendów w Donbasie oraz w okupowanych częściach obwodów chersońskiego i zaporoskiego na południu Ukrainy w sprawie przyłączenia tych obszarów do Rosji.</p>

## Polska wstrzymała wydawanie wiz turystycznych dla Rosjan. Informuje MSZ
 - [https://www.bankier.pl/wiadomosc/Polska-wstrzymala-wydawanie-wiz-turystycznych-dla-Rosjan-Informuje-MSZ-8409857.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-wstrzymala-wydawanie-wiz-turystycznych-dla-Rosjan-Informuje-MSZ-8409857.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 20:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/7/0331130f64deb8-948-568-15-66-2032-1219.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Korzystając ze stanowiska przyjętego przez Unie Europejską Polska, tak jak kraje bałtyckie, nie wydaje dziś wiz turystycznych dla obywateli Rosji, choć np. Finlandia tego nie zrobiła - powiedział w TVP Info wiceszef MSZ Piotr Wawrzyk.</p>

## Szef MSZ Ukrainy wzywa Finlandię do zamknięcia granicy dla Rosjan
 - [https://www.bankier.pl/wiadomosc/Szef-MSZ-Ukrainy-wzywa-Finlandie-do-zamkniecia-granicy-dla-Rosjan-8409840.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szef-MSZ-Ukrainy-wzywa-Finlandie-do-zamkniecia-granicy-dla-Rosjan-8409840.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 19:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/9d8be2a117c763-948-568-20-250-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szef MSZ Ukrainy Dmytro Kułeba poinformował w środę, że wezwał Finlandię, by dołączyła do państw bałtyckich i Polski, i zamknęła granicę z Rosją.</p>

## Glovo ukarane rekordową grzywną za oszustwa przy zawieraniu umów z kurierami
 - [https://www.bankier.pl/wiadomosc/Glovo-ukarane-rekordowa-grzywna-za-oszustwa-przy-zawieraniu-umow-z-kurierami-8409837.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Glovo-ukarane-rekordowa-grzywna-za-oszustwa-przy-zawieraniu-umow-z-kurierami-8409837.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 19:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/e45ea2897b6815-948-568-0-229-3397-2038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Firma Glovo, dostawca gotowych posiłków, została w środę ukarana rekordową grzywną za nieprawidłowości w zawieranych z kurierami umowach o pracę. Sięga ona kwoty 79 mln euro.</p>

## Donald Trump oskarżony o zawyżanie wyceny swoich nieruchomości
 - [https://www.bankier.pl/wiadomosc/Donadl-Trump-oskarzony-o-zawyzanie-wyceny-swoich-nieruchomosci-8409831.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Donadl-Trump-oskarzony-o-zawyzanie-wyceny-swoich-nieruchomosci-8409831.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 19:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/7/bcd0586c2a6f54-948-568-0-82-1730-1037.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prokurator generalna stanu Nowy Jork Letitia James oskarżyła w środę byłego prezydenta USA Donalda Trumpa o systematyczne podawanie nieprawdziwych wycen swoich nieruchomości. Zarzuca mu czerpanie zysków z "oszałamiającego" oszustwa.</p>

## Fed robi trzecią 75-kę. Stopa funduszy federalnych najwyżej od 2008 roku
 - [https://www.bankier.pl/wiadomosc/Fed-podnosi-stopy-procentowe-wrzesien-2022-8409820.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fed-podnosi-stopy-procentowe-wrzesien-2022-8409820.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 19:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/1/32fa86aeb0e07d-945-560-0-52-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trzeci raz z rzędu Federalny Komitet Otwartego Rynku
zdecydował się na 75-punktową podwyżkę stóp procentowych.</p>

## Prezes PiS: Szykujemy wielką operację obniżki opłat za energię dla instytucji samorządowych i rządowych
 - [https://www.bankier.pl/wiadomosc/Prezes-PiS-Szykujemy-wielka-operacje-obnizki-oplat-za-energie-dla-instytucji-samorzadowych-i-rzadowych-8409818.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezes-PiS-Szykujemy-wielka-operacje-obnizki-oplat-za-energie-dla-instytucji-samorzadowych-i-rzadowych-8409818.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 18:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/1/49b3b25746ae80-948-568-0-115-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jest przygotowywana wielka operacja zmierzająca do tego, żeby wszystkie instytucje samorządowe i rządowe, takie jak teatry i szpitale, które mają dzisiaj propozycje od firm energetycznych, żeby płacić 6-8 razy więcej, miały tę sumę radykalnie obniżoną - powiedział w środę pre

## Jarosław Kaczyński broni Macierewicza. "Zamach smoleński udowodniony w stu procentach"
 - [https://www.bankier.pl/wiadomosc/Jaroslaw-Kaczynski-broni-Macierewicza-Zamach-smolenski-udowodniony-w-stu-procentach-8409804.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jaroslaw-Kaczynski-broni-Macierewicza-Zamach-smolenski-udowodniony-w-stu-procentach-8409804.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 18:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/d496c86364fdc0-948-568-16-225-3204-1922.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zamach smoleński jest moim zdaniem w stu procentach udowodniony - powiedział w środę prezes PiS Jarosław Kaczyński. Kiedy zostaje przeprowadzona oszukańcza akcja TVN w sprawie katastrofy smoleńskiej, to tamta strona wpada w trans szaleńczej radości, że Rosjanie niewinni, że 

## Biden w ONZ odpowiada Putinowi: Nikt nie jest w stanie wygrać wojny jądrowej i nigdy nie może do niej dojść
 - [https://www.bankier.pl/wiadomosc/Biden-w-ONZ-odpowiada-Putinowi-Nikt-nie-jest-w-stanie-wygrac-wojny-jadrowej-i-nigdy-nie-moze-do-niej-dojsc-8409797.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Biden-w-ONZ-odpowiada-Putinowi-Nikt-nie-jest-w-stanie-wygrac-wojny-jadrowej-i-nigdy-nie-moze-do-niej-dojsc-8409797.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 18:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/7/2fdbaf011e6e80-948-568-1090-1190-1400-840.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zamiarem Rosji w wojnie przeciwko Ukrainie jest wymazanie jej z mapy świata, a stawką jest prawo Ukraińców jako narodu do istnienia - powiedział w środę prezydent USA Joe Biden w wystąpieniu przed Zgromadzeniem Ogólnym ONZ w Nowym Jorku. Dodał, że USA chcą zakończenia wojn

## Niemcy zamrozili rosyjskie aktywa o wartości 4,8 mld euro
 - [https://www.bankier.pl/wiadomosc/Niemcy-zamrozili-rosyjskie-aktywa-o-wartosci-4-8-mld-euro-8409777.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niemcy-zamrozili-rosyjskie-aktywa-o-wartosci-4-8-mld-euro-8409777.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 17:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/9f42f2ffa57bdb-948-567-0-7-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władze niemieckie działają powoli w kwestii zamrażania majątków objętych sankcjami Rosjan. Jak szacuje w środę tygodnik „Spiegel”, rząd Niemiec skonfiskował do tej pory niecałe 5 mld euro w postaci nieruchomości, jachtów i innych aktywów. Na unijnej liście podmiotów objętych ant

## Rosjanie wyszli na ulice protestować przeciw mobilizacji. Setki zatrzymanych
 - [https://www.bankier.pl/wiadomosc/Rosjanie-wyszli-na-ulice-protestowac-przeciw-mobilizacji-Setki-zatrzymanych-8409773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosjanie-wyszli-na-ulice-protestowac-przeciw-mobilizacji-Setki-zatrzymanych-8409773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 17:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/8/911f5405a47997-948-568-20-179-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do ponad 400 wzrósł bilans zatrzymanych 
uczestników środowych demonstracji w Rosji przeciwko mobilizacji na 
wojnę z Ukrainą - podała organizacja  OWD-Info. W Moskwie na razie 
wiadomo o 120 zatrzymanych.</p>

## Wzrosty na GPW mimo fatalnej postawy złotego. Umowa o poufności i gwałtowany wzrost kursu
 - [https://www.bankier.pl/wiadomosc/Wzrosty-na-GPW-mimo-fatalnej-postawu-zlotego-Umowa-o-poufnosci-i-gwaltowany-wzrost-kursu-8409713.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wzrosty-na-GPW-mimo-fatalnej-postawu-zlotego-Umowa-o-poufnosci-i-gwaltowany-wzrost-kursu-8409713.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 16:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/1/12904f258c9cd4-948-568-12-52-983-590.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sesja w środę zakończyła się wzrostem głównych indeksów, mimo ogromnej słabości złotego. Inwestorzy odpowiedzieli na sygnały z giełd bazowych wyczekujących na decyzję Fedu. Na NewConnect, kurs spółki zyskał ponad 40 proc. po ogłoszeniu tylko planów współpracy.</p>

## Biedronka przyznała pracownikom po 1,5 tys. zł nagrody specjalnej
 - [https://www.bankier.pl/wiadomosc/Biedronka-przyznala-pracownikom-po-1-5-tys-zl-nagrody-specjalnej-8409710.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Biedronka-przyznala-pracownikom-po-1-5-tys-zl-nagrody-specjalnej-8409710.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 16:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/d/6142adc99aaeb8-945-567-56-67-4353-2612.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Biedronka wypłaci ponad 55 tys. pracownikom do końca września po 1,5 tys. zł brutto nagrody specjalnej  za zaangażowanie w osiągnięcie zakładanego wyniku za pierwsze osiem miesięcy 2022 roku. - podała Biedronka w komunikacie prasowym.</p>

## Tyrowicz: Bez poprawy koordynacji polityki pieniężnej i fiskalnej trudno o CPI w celu w '24
 - [https://www.bankier.pl/wiadomosc/Tyrowicz-Bez-poprawy-koordynacji-polityki-pienieznej-i-fiskalnej-trudno-o-CPI-w-celu-w-24-8409684.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tyrowicz-Bez-poprawy-koordynacji-polityki-pienieznej-i-fiskalnej-trudno-o-CPI-w-celu-w-24-8409684.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 16:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/a3bb0eb90d9b81-948-568-0-266-3942-2365.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bez poprawy koordynacji polityki pieniężnej i fiskalnej będzie trudno sprowadzić inflację do celu w 2024 r. - powiedziała portalowi Money. pl członkini RPP Joanna Tyrowicz.</p>

## Kampania NASK, Google i Demagoga przeciwko dezinformacji o uchodźcach z Ukrainy
 - [https://www.bankier.pl/wiadomosc/Kampania-NASK-Google-i-Demagoga-przeciwko-dezinformacji-o-uchodzcach-z-Ukrainy-8409674.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kampania-NASK-Google-i-Demagoga-przeciwko-dezinformacji-o-uchodzcach-z-Ukrainy-8409674.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 15:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/0/b1947adee90c33-948-568-57-0-1800-1080.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W mediach społecznościowych Polski, Czech i Słowacji trwa kampania przeciwko dezinformacji o ukraińskich uchodźcach, którą przygotowała należąca do Google spółka Jigsaw przy współpracy z Państwowym Instytutem Badawczym NASK oraz stowarzyszeniem fact-checkingowym Demagog - pisz

## Bujak: Tak gwałtownego osłabienia strony podażowej rynku mieszkaniowego nie było nigdy
 - [https://www.bankier.pl/wiadomosc/Bujak-Tak-gwaltownego-oslabienia-strony-podazowej-rynku-mieszkaniowego-nie-bylo-nigdy-8409670.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bujak-Tak-gwaltownego-oslabienia-strony-podazowej-rynku-mieszkaniowego-nie-bylo-nigdy-8409670.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 15:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/2/1c75bed76ee5f8-948-568-120-0-1809-1085.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tak gwałtownego osłabienia strony podażowej rynku mieszkaniowego nie było nigdy – napisał główny ekonomista PKO BP Piotr Bujak, komentując środowe dane GUS.</p>

## Czeski rząd będzie mógł ograniczać ceny energii
 - [https://www.bankier.pl/wiadomosc/Czeski-rzad-bedzie-mogl-ograniczac-ceny-energii-8409660.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czeski-rzad-bedzie-mogl-ograniczac-ceny-energii-8409660.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 15:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/61d08b430ab871-948-568-13-130-1785-1071.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Czech Milosz Zeman podpisał w środę nowelizację ustaw, które pozwalają na obniżenie do końca 2023 r. akcyzy na olej napędowy, a także dają rządowi prawo, na drodze rozporządzenia, do określenia górnej granicy cen energii.</p>

## Minister finansów: Inflacja jest w najwyższym swoim punkcie
 - [https://www.bankier.pl/wiadomosc/Minister-finansow-Inflacja-jest-w-najwyzszym-swoim-punkcie-8409650.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-finansow-Inflacja-jest-w-najwyzszym-swoim-punkcie-8409650.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 15:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/1/7f81cba8afe8fb-948-568-60-44-2940-1763.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Minister finansów Magdalena Rzeczkowska oceniła w środę, że inflacja jest już obecnie w najwyższym swoim punkcie. Zapewniła, że budżet krajowy ma się dobrze, jego realizacja budżetu przebiega zgodnie z planem, resort finansów dysponuje większymi środkami niż przed rokiem.</p>

## Rząd przekazał samorządom środki na wypłaty dodatku węglowego
 - [https://www.bankier.pl/wiadomosc/Rzad-przekazal-samorzadom-srodki-na-wyplaty-dodatku-weglowego-8409647.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-przekazal-samorzadom-srodki-na-wyplaty-dodatku-weglowego-8409647.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 15:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/f/2254862c7efc4f-948-567-0-45-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />- Ministerstwo Klimatu i Środowiska informuje:Polacy ubiegający się o dodatek węglowy mogą spodziewać się w najbliższym czasie wypłat na swoje konta. Środki na ten cel zostały już przekazane wojewodom. Apelujemy do samorządów o...</p>

## Wąsik: Histeryczna krytyka projektu ustawy o ochronie ludności jest chybiona
 - [https://www.bankier.pl/wiadomosc/Wasik-Histeryczna-krytyka-projektu-ustawy-o-ochronie-ludnosci-jest-chybiona-8409605.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wasik-Histeryczna-krytyka-projektu-ustawy-o-ochronie-ludnosci-jest-chybiona-8409605.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 14:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/6/bc6d15493bb080-948-568-75-0-1499-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Projekt ustawy o ochronie ludności nie przewiduje żadnych nowych ograniczeń dla swobód obywatelskich; histeryczna krytyka opozycji jest chybiona - podkreślił w środę wiceszef MSWiA Maciej Wąsik zapytany o zarzuty, które wobec projektu wyraziła Konfederacja.</p>

## Wiceminister: Musimy być przygotowani na kolejną falę uchodźców
 - [https://www.bankier.pl/wiadomosc/Wiceminister-Musimy-byc-przygotowani-na-kolejna-fale-uchodzcow-8409590.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiceminister-Musimy-byc-przygotowani-na-kolejna-fale-uchodzcow-8409590.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 14:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/a/f40d131b5db391-948-568-0-71-2042-1225.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Około 500 tys. uchodźców może zimą migrować ze wschodu na zachód Ukrainy; musimy być przygotowani, że jakaś część tych osób może chcieć dotrzeć do Polski - powiedział w środę wiceszef MSWiA, pełnomocnik rządu ds. uchodźców wojennych z Ukrainy Paweł Szefernaker podczas posiedze

## Protesty po śmierci kobiety zatrzymanej przez policję ds. moralności ogarnęły połowę prowincji Iranu
 - [https://www.bankier.pl/wiadomosc/Protesty-po-smierci-kobiety-zatrzymanej-przez-policje-ds-moralnosci-ogarnely-polowe-prowincji-Iranu-8409588.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Protesty-po-smierci-kobiety-zatrzymanej-przez-policje-ds-moralnosci-ogarnely-polowe-prowincji-Iranu-8409588.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 14:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/23f607bb37b593-948-568-20-614-4011-2407.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Protesty po śmierci kobiety zatrzymanej przez policję ds. moralności ogarnęły już 16 z 31 prowincji Iranu - podała amerykańska rozgłośnia Głos Ameryki. Organizacje praw człowieka, cytowane przez AFP, poinformowały w środę, że wskutek protestów zginęło dotąd sześć osób.</p>

## Finax rusza z europejską emeryturą na Słowacji. W Polsce ustawa wciąż czeka
 - [https://www.bankier.pl/wiadomosc/Finax-rusza-z-europejska-emerytura-na-Slowacji-W-Polsce-ustawa-wciaz-czeka-8409577.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Finax-rusza-z-europejska-emerytura-na-Slowacji-W-Polsce-ustawa-wciaz-czeka-8409577.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 13:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/0/5521618595c584-945-560-0-37-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Europejska emerytura jest już dostępna na Słowacji. Wysokość jej opłat ma ściśle określony limit, jest dziedziczna i podlega prawodawstwu europejskiemu. Pierwszą firmą w Europie, która otrzymała licencję na oferowanie europejskiej emerytury jest słowacki robodoradca Finax.</p>

## BSH zainwestuje w Łodzi 400 mln zł w nowe linie produkcyjne fabryki pralek
 - [https://www.bankier.pl/wiadomosc/BSH-zainwestuje-w-Lodzi-400-mln-zl-w-nowe-linie-produkcyjne-fabryki-pralek-8409541.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/BSH-zainwestuje-w-Lodzi-400-mln-zl-w-nowe-linie-produkcyjne-fabryki-pralek-8409541.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 13:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/3f6129b7a84b87-945-560-0-75-1155-692.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Producent sprzętu AGD, firma BSH zainwestuje 400 mln zł w rozbudowę fabryki pralek w Łodzi. W ramach inwestycji powstaną m.in. dwie kolejne linie produkcyjne, rozpocznie się też produkcja nowego modelu pralek. W związku z tym firma zatrudni kilkudziesięciu nowych pracowników.</

## Atak hakerski na e-Fakturę. MF zapewnia, że dane są bezpieczne
 - [https://www.bankier.pl/wiadomosc/MF-dane-przechowywane-w-ramach-Krajowego-Systemu-e-Faktur-sa-bezpieczne-8409482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/MF-dane-przechowywane-w-ramach-Krajowego-Systemu-e-Faktur-sa-bezpieczne-8409482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 12:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/b840007f2c96a3-948-568-0-271-3441-2065.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Krajowy System e-Faktur (KSeF) działa prawidłowo. KSeF jest na bieżąco monitorowany przez Ministerstwo Finansów, a dane z wystawionych faktur są bezpieczne - poinformowało w środę Ministerstwo Finansów (MF).</p>

## Pesa podpisała z PKP Intercity kontrakt o wartości 376 mln zł brutto
 - [https://www.bankier.pl/wiadomosc/Pesa-podpisala-z-PKP-Intercity-kontrakt-o-wartosci-376-mln-zl-brutto-8409449.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pesa-podpisala-z-PKP-Intercity-kontrakt-o-wartosci-376-mln-zl-brutto-8409449.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 11:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/539ff6438f804a-948-568-0-15-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pesa Bydgoszcz podpisała z PKP Intercity umowę na naprawę na piątym poziomie utrzymania (P5) 59 wagonów serii 152A i 154A. Bydgoska spółka za wykonanie przedmiotu umowy otrzyma 376 mln zł brutto – poinformowała Pesa w komunikacie prasowym.</p>

## PGE Paliwa sprowadzi zza granicy ok. 10 mln ton węgla do końca IV '23
 - [https://www.bankier.pl/wiadomosc/PGE-Paliwa-sprowadzi-zza-granicy-ok-10-mln-ton-wegla-do-konca-IV-23-8409439.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PGE-Paliwa-sprowadzi-zza-granicy-ok-10-mln-ton-wegla-do-konca-IV-23-8409439.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 11:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/2/b6c9293bf0f087-948-568-0-106-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PGE Paliwa zrealizuje import łącznie ok. 10 mln ton węgla do końca kwietnia 2023 roku - poinformował prezes grupy PGE Wojciech Dąbrowski.</p>

## Buda: Odbiorcy pomp ciepła otrzymają wsparcie w związku z rosnącymi cenami prądu
 - [https://www.bankier.pl/wiadomosc/Buda-Odbiorcy-pomp-ciepla-otrzymaja-wsparcie-w-zwiazku-z-rosnacymi-cenami-pradu-8409426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Buda-Odbiorcy-pomp-ciepla-otrzymaja-wsparcie-w-zwiazku-z-rosnacymi-cenami-pradu-8409426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 11:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/6/61e1a7c101de9e-948-568-22-315-4477-2686.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Odbiorcy pomp ciepła dostaną rekompensaty z powodu rosnących cen prądu, będą one takie same, jak dla innych paliw - poinformował szef MRiT Waldemar Buda. Na pomoc mogą też liczyć szpitale, szkoły - dodał. Zapowiedział, że odpowiednie rozwiązanie ma być gotowe za kilka-kilkan

## Zimniej w szkołach i przedszkolach, mniej świątecznych iluminacji. Warszawa oszczędza energię
 - [https://www.bankier.pl/wiadomosc/Zimniej-w-szkolach-i-przedszkolach-mniej-swiatecznych-iluminacji-Warszawa-oszczedza-energie-8409407.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zimniej-w-szkolach-i-przedszkolach-mniej-swiatecznych-iluminacji-Warszawa-oszczedza-energie-8409407.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 10:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/0/b2418d61a91fa0-948-568-0-247-3736-2242.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Obniżenie temperatury w przedszkolach i szkołach oraz urzędach miejskich, ograniczenie podświetlania budowli i iluminacji świątecznej – takie oszczędności rozważa zarząd miasta stołecznego – przekazał w środę prezydent Warszawy Rafał Trzaskowski.</p>

## Ceny prądu dla samorządów po nowemu. Premier: Spółki mają opracować mechanizm
 - [https://www.bankier.pl/wiadomosc/Premier-chce-by-spolki-energetyczne-wypracowaly-nowy-mechanizm-kalkulowania-cen-dla-samorzadow-8409399.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-chce-by-spolki-energetyczne-wypracowaly-nowy-mechanizm-kalkulowania-cen-dla-samorzadow-8409399.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 10:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/17e782dc89d725-948-568-0-0-4000-2400.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo Aktywów Państwowych ma wypracować wraz ze spółkami energetycznymi nowy mechanizm prezentowania cen energii dla samorządów - poinformował premier Mateusz Morawiecki na środowym briefingu.</p>

## KNF nałożyła kary pieniężne na byłego prezesa GetBacku Konrada Kąkolewskiego
 - [https://www.bankier.pl/wiadomosc/KNF-nalozyla-kary-pieniezne-na-bylego-prezesa-GetBacku-8409386.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KNF-nalozyla-kary-pieniezne-na-bylego-prezesa-GetBacku-8409386.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 10:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/0/b9ce7aaf3b3256-945-567-60-40-3940-2364.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Nadzoru Finansowego nałożyła na byłego prezesa GetBacku Konrada Kąkolewskiego kary pieniężne w łącznej wysokości ponad 3,3 mln zł - poinformowała KNF w komunikacie.</p>

## Gazowy gigant Uniper znacjonalizowany przez niemiecki rząd
 - [https://www.bankier.pl/wiadomosc/Gazowy-gigant-Uniper-znacjonalizowany-przez-niemiecki-rzad-8409369.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gazowy-gigant-Uniper-znacjonalizowany-przez-niemiecki-rzad-8409369.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 10:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/6/c996a37fef41fb-948-568-0-303-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W wyniku wstrzymania dostaw gazu z Rosji, rząd Niemiec staje się większościowym udziałowcem największego niemieckiego importera gazu ziemnego – firmy Uniper. Umowa zakłada, że rząd Niemiec będzie posiadał ok. 99 proc. udziałów w Uniperze, który tym samym zostanie znacjonalizo

## Fitch: Podatek od zysków nadzwyczajnych może najmocniej dotknąć PKN Orlen, Repsol i OMV
 - [https://www.bankier.pl/wiadomosc/Podatek-od-zyskow-nadzwyczajnych-moze-najmocniej-dotknac-PKN-Orlen-Repsol-i-OMV-Fitch-8409364.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podatek-od-zyskow-nadzwyczajnych-moze-najmocniej-dotknac-PKN-Orlen-Repsol-i-OMV-Fitch-8409364.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 10:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/0/b6555239186c46-945-567-41-18-1418-851.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zapowiadany przez Komisję Europejską podatek solidarnościowy od nadzwyczajnych zysków będzie miał bardzo ograniczony wpływ na europejskie spółki gazowe i paliwowe, a najmocniej mogą odczuć go PKN Orlen, Repsol i OMV - uważają analitycy agencji ratingowej Fitch.</p>

## UOKiK: zarzuty dla OLX za wprowadzanie konsumentów w błąd
 - [https://www.bankier.pl/wiadomosc/UOKiK-zarzuty-dla-OLX-za-wprowadzanie-konsumentow-w-blad-8409357.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UOKiK-zarzuty-dla-OLX-za-wprowadzanie-konsumentow-w-blad-8409357.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 09:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/8/8d6386b09466d9-945-560-48-0-1406-843.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wprowadzające konsumentów w błąd sortowanie ofert w serwisie oraz iluzoryczna ochrona kupujących w ramach "Pakietu ochronnego" – to niektóre zakwestionowane przez UOKiK praktyki wobec platformy e-commerce OLX - podał Urząd w środę w komunikacie.</p>

## Strajk ogólnokrajowy w Belgii przeciwko drożyźnie
 - [https://www.bankier.pl/wiadomosc/Strajk-ogolnokrajowy-w-Belgii-przeciwko-drozyznie-8409348.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Strajk-ogolnokrajowy-w-Belgii-przeciwko-drozyznie-8409348.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 09:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/2/90489a68c92187-945-560-0-103-1718-1030.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po raz trzeci w tym roku belgijskie związki zawodowe zorganizowały ogólnokrajowy strajk w proteście przeciwko - ich zdaniem - niewystarczającym działaniom rządu mającym chronić siłę nabywczą. Środowe protesty mocno zakłócą funkcjonowanie transportu publicznego.</p>

## PIE: w najbliższych miesiącach handel znajdzie się w stagnacji
 - [https://www.bankier.pl/wiadomosc/PIE-w-najblizszych-miesiacach-handel-znajdzie-sie-w-stagnacji-8409342.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PIE-w-najblizszych-miesiacach-handel-znajdzie-sie-w-stagnacji-8409342.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 09:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/2/17f47640893dec-948-567-0-42-990-593.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost sprzedaży detalicznej pozostaje na bardzo niskim poziomie - zwraca uwagę Polski Instytut Ekonomiczny, komentując środowe dane GUS. Analitycy spodziewają się że w najbliższych miesiącach handel znajdzie się w stagnacji - głównie z powodu spadku siły nabywczej wynagrodzeń.<

## Kolejne kraje przestają honorować karty rosyjskiego systemu płatniczego Mir
 - [https://www.bankier.pl/wiadomosc/Kolejne-kraje-przestaja-honorowac-karty-rosyjskiego-systemu-platniczego-Mir-8409335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kolejne-kraje-przestaja-honorowac-karty-rosyjskiego-systemu-platniczego-Mir-8409335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 09:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/b/13df5825af215a-948-568-0-45-1830-1098.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ślad za Turcją banki w Armenii, Wietnamie i Kazachstanie przestały honorować karty rosyjskiego systemu płatniczego Mir – podał w środę portal Ukrainska Prawda.</p>

## Czterodniowy tydzień pracy w fabryce okien. Nie jako benefit, a ochrona przed zwolnieniami
 - [https://www.bankier.pl/wiadomosc/Czterodniowy-tydzien-pracy-w-fabryce-okien-Nie-jako-benefit-a-ochrona-przed-zwolnieniami-8409301.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czterodniowy-tydzien-pracy-w-fabryce-okien-Nie-jako-benefit-a-ochrona-przed-zwolnieniami-8409301.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 09:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/b6f85033c595ef-948-567-0-32-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Znany producent okien, firma Velux, postanowił wprowadzić czterodniowy tydzień pracy w swojej fabryce w Gnieźnie. Nie jest to jednak benefit dla pracowników, a rozwiązanie, które ma uchronić miejsca pracy.</p>

## Gaz ziemny w środę drożeje
 - [https://www.bankier.pl/wiadomosc/Gaz-ziemny-w-srode-drozeje-8409316.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gaz-ziemny-w-srode-drozeje-8409316.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 09:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/21d5d615c0fd96-948-568-0-8-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W środę przed godz. 10 gaz ziemny w holenderskim hubie TTF w kontraktach październikowych drożał o 6,55 proc., do 207 euro za MWh. Rosły też notowania gazu ziemnego w kontraktach listopadowych - o 6,49 proc., do 220,56 euro za MWh.</p>

## Nie najgorszy sierpień w branży budowlanej. GUS pokazał dane
 - [https://www.bankier.pl/wiadomosc/Nie-najgorszy-sierpien-w-branzy-budowlanej-GUS-pokazal-dane-8409288.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-najgorszy-sierpien-w-branzy-budowlanej-GUS-pokazal-dane-8409288.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/3/c1620453bb53a9-948-568-0-73-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Produkcja budowlano-montażowa była w sierpniu większa niż rok temu. Zaliczyła też wzrost dynamiki miesięcznej. Jednak według danych GUS do końca sierpnia rozpoczęto budowę znacznie mniejszej liczby mieszkań, zarówno w przypadku deweloperów, jak i inwestorów indywidualnych niż 

## Polski konsument (jeszcze) nie skapitulował
 - [https://www.bankier.pl/wiadomosc/Sprzedaz-detaliczna-w-Polsce-sierpien-2022-8409298.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sprzedaz-detaliczna-w-Polsce-sierpien-2022-8409298.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/5/46c3d7e4ec5844-948-568-120-0-1810-1086.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mimo przytłaczającej inflacji i realnego spadku dochodów
polski konsument wciąż dzielnie szturmuje sklepowe półki.</p>

## Biedronka się wycofała, skorzysta polska sieć. Niedzielna książka w pakiecie z zakupami
 - [https://www.bankier.pl/wiadomosc/Siec-Topaz-otwiera-sklepy-w-niedziele-Klub-Czytelnika-to-akcja-edukacyjna-8409266.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Siec-Topaz-otwiera-sklepy-w-niedziele-Klub-Czytelnika-to-akcja-edukacyjna-8409266.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 08:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/f/e4f7795fd394d6-948-568-0-84-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Na ochroniarza", "na placówkę pocztową", "wypożyczalnię sprzętu 
sportowego" czy "na czytelnię" - sklepy wykazują się kreatywnością i 
korzystają z co rusz nowych sposobów na obejście zakazu handlu w 
niedziele. Do tego grona dołączyła polska sieć Topaz.</p>

## Putin umocnił dolara. Złoty słabnie po sygnałach z Kremla
 - [https://www.bankier.pl/wiadomosc/Putin-umocnil-dolara-Zloty-slabnie-po-sygnalach-z-Kremla-8409273.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Putin-umocnil-dolara-Zloty-slabnie-po-sygnalach-z-Kremla-8409273.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 08:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/f/b8a1acffb1db8a-948-568-210-70-3790-2273.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Eskalacja wojny rosyjsko-ukraińskiej w środę rano
doprowadziła do umocnienia dolara amerykańskiego i osłabienia złotego.</p>

## Przychody Asbisu w sierpniu spadły o ok. 15 proc. rdr
 - [https://www.bankier.pl/wiadomosc/Przychody-Asbisu-w-sierpniu-spadly-o-ok-15-proc-rdr-do-ok-207-mln-USD-8409241.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przychody-Asbisu-w-sierpniu-spadly-o-ok-15-proc-rdr-do-ok-207-mln-USD-8409241.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 07:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/ccf4d09f95918d-945-560-978-236-3521-2112.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Skonsolidowane przychody Asbisu w sierpniu 2022 roku wyniosły ok. 207 mln USD, co oznacza spadek o ok. 15 proc. rdr - podała spółka w komunikacie.</p>

## Kowalczyk: Krajowa Grupa Spożywcza antidotum na zmowy cenowe
 - [https://www.bankier.pl/wiadomosc/Kowalczyk-Krajowa-Grupa-Spozywcza-antidotum-na-zmowy-cenowe-8409237.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kowalczyk-Krajowa-Grupa-Spozywcza-antidotum-na-zmowy-cenowe-8409237.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 07:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/c/1e29d390eed044-948-568-577-367-1675-1005.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Krajowa Grupa Spożywcza jest dobrym antidotum na zmowę cenową - ocenił w środę wicepremier, minister rolnictwa i rozwoju wsi Henryk Kowalczyk. Dodał, że trwają prace nad systemem pomocowym dla producentów nawozów.</p>

## Putin ogłosił częściową mobilizację w Rosji
 - [https://www.bankier.pl/wiadomosc/Putin-oglosil-czesciowa-mobilizacje-w-Rosji-8409234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Putin-oglosil-czesciowa-mobilizacje-w-Rosji-8409234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 07:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/5ed8aa1b20c1c8-948-568-503-0-2897-1738.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władimir Putin ogłosił rozpoczęcie częściowej mobilizacji w Rosji – powiadomiły rosyjskie media państwowe.</p>

## Ropa nieco droższa. W środę kluczowa dla rynków decyzja Fed
 - [https://www.bankier.pl/wiadomosc/Ropa-nieco-drozsza-W-srode-kluczowa-dla-rynkow-decyzja-Fed-8409222.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ropa-nieco-drozsza-W-srode-kluczowa-dla-rynkow-decyzja-Fed-8409222.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 06:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/f/feb7feefb4d014-945-560-0-17-930-557.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną przed środową, kluczową dla rynków, decyzją Fed o stopach procentowych w USA - podają maklerzy.</p>

## Eksperci: Ameryka Południowa to nowy kierunek rekrutacji pracowników do polskich firm
 - [https://www.bankier.pl/wiadomosc/Eksperci-Ameryka-Poludniowa-to-nowy-kierunek-rekrutacji-pracownikow-do-polskich-firm-8409215.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Eksperci-Ameryka-Poludniowa-to-nowy-kierunek-rekrutacji-pracownikow-do-polskich-firm-8409215.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 06:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/b/392d5cd57c2738-945-560-0-7-1528-916.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Obok wschodnich i azjatyckich kierunków rekrutacji pracowników do polskich firm, agencje zatrudnienia rekrutują w krajach Ameryki Południowej - powiedzieli PAP eksperci rynku pracy.  W ich ocenie, polscy pracodawcy otwierają się na coraz to odleglejsze kierunki migracji zarobkow

## Rośnie groźba zwolnień w firmach. Przedsiębiorcy analizują sytuację
 - [https://www.bankier.pl/wiadomosc/Rosnie-grozba-zwolnien-w-firmach-Przedsiebiorcy-analizuja-sytuacje-8409209.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosnie-grozba-zwolnien-w-firmach-Przedsiebiorcy-analizuja-sytuacje-8409209.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/60c40bc1f77fcd-948-568-0-78-1200-719.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już 12,9 tys. osób straciło do lipca pracę. To ponad jedna czwarta więcej niż przed rokiem. Cięć etatów jeszcze przybędzie - donosi w środę Rzeczpospolita.</p>

## "Strzelanie z armaty na wróble". Eksperci o nowej ustawie antylichwiarskiej
 - [https://www.bankier.pl/wiadomosc/Nowa-ustawa-antylichwiarska-znacznie-ograniczy-dostep-do-pozyczek-8409206.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowa-ustawa-antylichwiarska-znacznie-ograniczy-dostep-do-pozyczek-8409206.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/a/6414b3c97d405d-948-568-0-148-4256-2553.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowa regulacja antylichwiarska, nad którą właśnie pracuje Sejm, ma w założeniu działać prokonsumencko, ale wielu ekspertów wskazuje, że jej efekt będzie odwrotny do zamierzonego. Przedstawiony w niej obraz rynku pożyczkowego jest bowiem nieaktualny.</p>

## Zapaść psychiatrii dziecięcej. "Kilkadziesiąt złotych za minutę" i długie kolejki
 - [https://www.bankier.pl/wiadomosc/Zapasc-psychiatrii-dzieciecej-Kilkadziesiat-zlotych-za-minute-i-dlugie-kolejki-8409202.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zapasc-psychiatrii-dzieciecej-Kilkadziesiat-zlotych-za-minute-i-dlugie-kolejki-8409202.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/0187acaa64f311-948-568-142-0-2737-1642.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kilkadziesiąt złotych za minutę – tyle kosztuje kontakt z psychiatrą dziecięcym. Komercyjnie. Czas oczekiwania – kilka miesięcy - podaje w środę "Dziennik Gazeta Prawna".</p>

## Techniczne usprawnienie czy sztuczka? Nowelizacja prawa wyborczego wg PiS
 - [https://www.bankier.pl/wiadomosc/Techniczne-usprawnienie-czy-sztuczka-Nowelizacja-prawa-wyborczego-wg-PiS-8409200.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Techniczne-usprawnienie-czy-sztuczka-Nowelizacja-prawa-wyborczego-wg-PiS-8409200.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/ce4aa6b7461935-948-568-0-146-1632-979.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />DGP dotarł do szykowanego w rządzie projektu nowelizacji kodeksu wyborczego i niektórych innych ustaw. Główny cel to stworzenie centralnego rejestru, który zastąpi gminne listy wyborców - czytamy w środę w "Dzienniku Gazecie Prawnej".</p>

## Produkty z drugiej ręki zyskują na popularności
 - [https://www.bankier.pl/wiadomosc/Produkty-z-drugiej-reki-zyskuja-na-popularnosci-8409197.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Produkty-z-drugiej-reki-zyskuja-na-popularnosci-8409197.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/55eeb8d53c4318-945-560-0-24-1200-719.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Coraz więcej osób kupuje w sklepach typu second-hand, nie tylko z oszczędności. Liczba stacjonarnych punktów co prawda spada, za to boom widać w internecie - czytamy w środę w "Rzeczpospolitej".</p>

## Polska kupuje broń z USA za dziesiątki mld dol. Powinna się otworzyć na współpracę z UE
 - [https://www.bankier.pl/wiadomosc/Polska-kupuje-bron-z-USA-za-dziesiatki-mld-dol-Powinna-sie-otworzyc-na-wspolprace-z-UE-8409192.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-kupuje-bron-z-USA-za-dziesiatki-mld-dol-Powinna-sie-otworzyc-na-wspolprace-z-UE-8409192.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/c25165e8e1e0d6-948-568-0-120-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />- W naszym interesie leży to, żeby Polska utrzymywała dobrą współpracę w dziedzinie polityki obronnej i zbrojeń nie tylko ze Stanami Zjednoczonymi, ale także z państwami UE. Zwłaszcza tymi, które posiadają silny przemysł zbrojeniowy.</p>

## Dyrektor CKE: Najwięcej zmian na maturze będzie na egzaminach z języka polskiego
 - [https://www.bankier.pl/wiadomosc/Dyrektor-CKE-Najwiecej-zmian-na-maturze-bedzie-na-egzaminach-z-jezyka-polskiego-8409184.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dyrektor-CKE-Najwiecej-zmian-na-maturze-bedzie-na-egzaminach-z-jezyka-polskiego-8409184.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/0efbaf61e5beff-945-560-0-185-3887-2332.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najwięcej zmian na maturze w nowej formule, którą wiosną przyszłego roku będą zdawać absolwenci 4-letnich liceów, dotyczy egzaminu z języka polskiego, zarówno w części pisemnej, jak i w części ustnej - mówi w rozmowie z PAP dyrektor CKE Marcin Smolik.</p>

## Hotelarze: Wakacyjny pobyt trwał średnio 4 dni
 - [https://www.bankier.pl/wiadomosc/Hotelarze-Wakacyjny-pobyt-trwal-srednio-4-dni-8409183.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hotelarze-Wakacyjny-pobyt-trwal-srednio-4-dni-8409183.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/6/430dcee1699762-945-560-0-0-1767-1060.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Średnia długość pobytu gości w hotelach wypoczynkowych w wakacje wyniosła 4 dni  - wynika z przekazanej PAP ankiety Izby Gospodarczej Hotelarstwa Polskiego. We wrześniu  blisko 60 proc. hoteli ma w rezerwacji 50 proc. miejsc.</p>

## Amerykańscy senatorowie nalegają na sankcje wtórne na rosyjską ropę
 - [https://www.bankier.pl/wiadomosc/Amerykanscy-senatorowie-nalegaja-na-sankcje-wtorne-na-rosyjska-rope-8409181.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Amerykanscy-senatorowie-nalegaja-na-sankcje-wtorne-na-rosyjska-rope-8409181.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/6/297e659c27e5bd-948-568-0-69-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Demokratyczni i republikańscy senatorowie wezwali we wtorek, by administracja prezydenta Joe Bidena nałożyła sankcje wtórne na międzynarodowe banki, dla ochrony pułapu cenowego, jaki kraje G7 planują nałożyć na rosyjską ropę w związku z inwazją na Ukrainę.</p>

## Po podwyżce stóp hipoteki znów zdrożały – 8 proc. to minimum
 - [https://www.bankier.pl/wiadomosc/Ranking-kredytow-hipotecznych-wrzesien-2022-najlepsze-kredyty-hipoteczne-8408988.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-kredytow-hipotecznych-wrzesien-2022-najlepsze-kredyty-hipoteczne-8408988.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/c/6efe1e17eb8edf-948-568-0-130-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wrześniowa podwyżka stóp procentowych pchnęła w górę stawki
oprocentowania. W najnowszej edycji rankingu kredytów z okresowo stałą stopą
nie zobaczymy już ofert z siódemką w cenniku. Jeszcze wyższe wartości proponują
banki tym, którzy chcieliby zaciągnąć zobowiązanie „solo” b

## Pompa ciepła rozwiązaniem na zimę? Właściciele domów mogą liczyć na dotacje sięgające blisko 200 tys. zł
 - [https://www.bankier.pl/wiadomosc/Dofinansowanie-do-pompy-ciepla-Czyste-powietrze-Moje-cieplo-Cieple-mieszkanie-8408260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dofinansowanie-do-pompy-ciepla-Czyste-powietrze-Moje-cieplo-Cieple-mieszkanie-8408260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/8/ce04362381c445-948-568-0-229-3679-2207.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przedsięwzięcie związane z zakupem i montażem pompy ciepła nie należy do najtańszych. Jednak właściciele nowych domów mogą liczyć na dotację do 21 tys. zł, a starszych budynków do 80 tys. zł. Do tego doliczyć można 106 tys. zł ulgi termomodernizacyjnej dla małżeństw, co daje 

## Rachunki w przyszłym roku wzrosną znacząco, ale nie grożą nam zimne kaloryfery
 - [https://www.bankier.pl/wiadomosc/Rachunki-za-ogrzewanie-wzrosna-Nie-bedzie-przerw-w-ogrzewaniu-8408843.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rachunki-za-ogrzewanie-wzrosna-Nie-bedzie-przerw-w-ogrzewaniu-8408843.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/d3ca61dedd1505-948-568-352-577-2125-1275.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rachunki w przyszłym roku mogą wzrosnąć od kilkuset do kilku tysięcy złotych w skali roku dla mieszkańców osiedli. Powodem podwyżek będą nie tylko wyższe taryfy na gaz i prąd, ale skokowe koszty opłat dla spółdzielni. Jednak są też dobre wiadomości – nie grożą nam zimne kal

## W tych miastach najem najmocniej poturbował lokatorów. Stawki najmu na koniec lata
 - [https://www.bankier.pl/wiadomosc/Ceny-ofertowe-wynajmu-mieszkan-wrzesien-2022-Raport-Bankier-pl-8408800.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-ofertowe-wynajmu-mieszkan-wrzesien-2022-Raport-Bankier-pl-8408800.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/38e3a77dc15f24-948-568-0-69-1988-1192.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć od wiosny oczekiwania chcących wynająć mieszkanie rosną w sposób drastyczny, przekładając się na kilkudziesięcioprocentowe wzrosty w skali roku, to w relacji do ostatnich wakacji przed wybuchem pandemii można zauważyć znacznie większe cenowe rozwarstwienie – wynika z dany

## Duda: Nie wolno nam okazywać zmęczenia wojną na Ukrainie
 - [https://www.bankier.pl/wiadomosc/Duda-Nie-wolno-nam-okazywac-zmeczenia-wojna-na-Ukrainie-8409157.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Duda-Nie-wolno-nam-okazywac-zmeczenia-wojna-na-Ukrainie-8409157.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-21 01:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/0df006d77726f0-948-568-0-0-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie wolno nam okazywać zmęczenia wojną na Ukrainie, której globalnym skutkiem jest kryzys żywnościowy oraz widmo głodu - mówił podczas debaty generalnej 77. sesji Zgromadzenia Ogólnego ONZ w Nowym Jorku prezydent Andrzej Duda. Podkreślał konieczność pociągnięcia Rosji do odpowi


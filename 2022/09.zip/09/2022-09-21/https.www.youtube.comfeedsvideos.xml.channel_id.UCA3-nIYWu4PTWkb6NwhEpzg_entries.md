# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## I Opened a Distillery in Portland
 - [https://www.youtube.com/watch?v=KxXpolFK9qk](https://www.youtube.com/watch?v=KxXpolFK9qk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-09-22 00:00:00+00:00

Like Disneyland for adults. With fewer furry suits (on weekdays). 

Aviation American Gin is a high-rated gin (97 points, Wine Enthusiast) and helped establish a new style of American gin - softer and smoother, with juniper in the background and citrus and floral notes in the front - resulting in more balanced cocktails. Created by a unique bartender/distiller partnership, #AviationGin is crafted in Portland, Oregon. 

https://www.aviationgin.com/


# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Built To Spill – Fool's Gold (live for The Current)
 - [https://www.youtube.com/watch?v=W2Y8g1g9EI0](https://www.youtube.com/watch?v=W2Y8g1g9EI0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-09-22 00:00:00+00:00

Built To Spill recently visited The Current studio to play songs and to chat with host Mac Wilson about their new album, "When The Wind Forgets Your Name."

Watch Built To Spill performing the track "Fool's Gold" from the new album. 

See the full studio session here: https://youtu.be/-cI-uH2aySA 

Band Members
Doug Martsch
Melanie Radford
Teresa Esguerra

Credits
Host – Mac Wilson
Guests – Built To Spill
Producer – Rachel Frances
Video – Eric Xu Romani
Camera Operators – Thor Cramer Bornemann
Audio – Evan Clark
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

#builttospill @builttospill

## Franz Ferdinand – Curious (live for The Current)
 - [https://www.youtube.com/watch?v=AMhiMrSh9TQ](https://www.youtube.com/watch?v=AMhiMrSh9TQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-09-22 00:00:00+00:00

In March of 2022, Franz Ferdinand released the double-album set, 'Hits To The Head,' which features 18 hits from the band’s back catalogue as well as two new tracks. While Franz Ferdinand were on tour to promote the double album, they visited The Current studio to perform three tracks from the collection, including this new single, “Curious,” which appears on the double-album set.

Band members
Alex Kapranos – guitar, vocals
Audrey Tait – drums
Bob Hardy – bass
Dino Bardot – guitar
Julian Corrie – keyboards, guitar

Credits
Producer – Derrick Stevens
Camera Operators – Evan Clark, Derek Ramirez
Audio – Eric Xu Romani
Video – Evan Clark
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/ 

#franzferdinand @franz_ferdinand #curious

## Franz Ferdinand — Take Me Out (live for The Current)
 - [https://www.youtube.com/watch?v=Wxt4xtYbkWE](https://www.youtube.com/watch?v=Wxt4xtYbkWE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-09-21 00:00:00+00:00

In March of 2022, Franz Ferdinand released the double-album set, 'Hits To The Head,' which features 18 hits from the band’s back catalogue as well as two new tracks. While Franz Ferdinand were on tour to promote the double album, they visited The Current studio to perform three tracks from the collection, including this song, “Take Me Out” (originally on 2004’s self-titled album). 

Band members
Alex Kapranos – guitar, vocals
Audrey Tait – drums
Bob Hardy – bass
Dino Bardot – guitar
Julian Corrie – keyboards, guitar

Credits
Producer – Derrick Stevens
Camera Operators – Evan Clark, Derek Ramirez
Audio – Eric Xu Romani
Video – Evan Clark
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/ 

#franzferdinand @franz_ferdinand #takemeout


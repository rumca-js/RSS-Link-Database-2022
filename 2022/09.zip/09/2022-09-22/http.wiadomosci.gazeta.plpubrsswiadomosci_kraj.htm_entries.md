# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Prokurator Ewa Wrzosek może mieć postępowanie służbowe. W tle próba udzielenia wywiadu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28943369,prokurator-ewa-wrzosek-moze-miec-postepowanie-sluzbowe-za-probe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28943369,prokurator-ewa-wrzosek-moze-miec-postepowanie-sluzbowe-za-probe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-22 20:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4c/9a/1b/z28943436M,Ewa-Wrzosek---zdjecie-archiwalne.jpg" vspace="2" />Notatką służbową i wezwaniem do udzielenia pisemnych wyjaśnień zakończyła się próba udzielenia wywiadu jednej z telewizji przez prokuratorkę Ewę Wrzosek - dowiedziało się Radio Zet. Wrzosek może też grozić postępowanie służbowe.

## Gdańsk. Kandydatka na szefową ECS ma związki z prorosyjskim "komitetem słowiańskim". Będzie nadzór ABW?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28942597,kandydatka-na-szefowa-ecs-ma-zwiazki-z-prorosyjskim-komitetem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28942597,kandydatka-na-szefowa-ecs-ma-zwiazki-z-prorosyjskim-komitetem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-22 16:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/9a/1b/z28942823M,Elzbieta-Grabarek-Bartoszewicz-i-posel-Kacper-Plaz.jpg" vspace="2" />Gdański ratusz zwróci się do Agencji Bezpieczeństwa Wewnętrznego o nadzór nad procedurą wyboru szefa Europejskiego Centrum Solidarności. Powodem są doniesienia "Gazety Wyborczej" na temat Elżbiety Grabarek-Bartoszewicz, jednej z kandydatek na to stanowisko. Dziennik opisał jej powiązania z prorosyjskim Polskim Komitetem Słowiańskim.

## Dąbrowa Górnicza. Wybuch w koksowni. Są doniesienia o rannych
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28942061,dabrowa-gornicza-wybuch-w-koksowni-sa-doniesienia-o-rannych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28942061,dabrowa-gornicza-wybuch-w-koksowni-sa-doniesienia-o-rannych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-22 13:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8e/99/1b/z28942222M,Koksowania-Przyjazn-w-Dabrowie-Gorniczej---zdjecie.jpg" vspace="2" />Wybuch w Koksowni Przyjaźń w Dąbrowie Górniczej (woj śląskie). Jak podaje RMF FM, prawdopodobnie doszło do eksplozji w jednym z silosów.

## Zaczyna się kalendarzowa i astronomiczna jesień - jaka czeka nas pogoda? Nadchodzi chwilowe ocieplenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28940939,zaczyna-sie-kalendarzowa-i-astronomiczna-jesien-jaka-czeka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28940939,zaczyna-sie-kalendarzowa-i-astronomiczna-jesien-jaka-czeka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-22 11:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/da/85/1b/z28859354M,Zlota-polska-jesien--zdjecie-ilustracyjne-.jpg" vspace="2" />Nadchodzi jesień. Czego możemy się spodziewać w pogodzie w najbliższym czasie? Według rzecznika Instytutu Meteorologii i Gospodarki Wodnej Grzegorza Walijewskiego "coraz wyższych wartości temperatury". Ocieplenie będzie jednak chwilowe.

## Sosnowiec. Zmumifikowane ciało w węźle ciepłowniczym. Trwa ustalanie tożsamości mężczyzny
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28940703,sosnowiec-zmumifikowane-zwloki-w-wezle-cieplowniczym-trwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28940703,sosnowiec-zmumifikowane-zwloki-w-wezle-cieplowniczym-trwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-22 11:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/09/99/1b/z28941065M,Opublikowano-zdjecia-ubioru-mezczyzny-w-celu-jego-.jpg" vspace="2" />W Sosnowcu w węźle ciepłowniczym pracownicy ciepłowni znaleźli zmumifikowane ciało. Na miejsce wezwano służby. Policja prowadzi czynności w celu ustalenia tożsamości znalezionego mężczyzny. Opublikowano zdjęcia jego ubioru.

## Sąd Najwyższy oddalił skargę Ziobry ws. chirurga. Lekarz zaszył w pacjencie chusty chirurgiczne
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28940571,sad-najwyzszy-oddalil-skarge-ziobry-ws-chirurga-lekarz-zaszyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28940571,sad-najwyzszy-oddalil-skarge-ziobry-ws-chirurga-lekarz-zaszyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-22 11:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9b/a7/19/z26902171M,Sad-Najwyzszy--zdjecie-ilustracyjne-.jpg" vspace="2" />Sąd Najwyższy rozpatrzył skargę Zbigniewa Ziobry w sprawie Dariusza R., chirurga, który w 2012 roku zaszył w ciele pacjenta dwie chusty chirurgiczne. W wyniku powikłań po operacji 78-latek zmarł. Sąd zdecydował o oddaleniu skargi Prokuratora Generalnego. - Uniewinniony nie tylko próbował wyczuwać ciała obce, ale też kontrolował wzrokiem pole operacyjne - uzasadniła d

## Dzień bez samochodu 2022. W których miastach można podróżować komunikacją miejską bez biletu? [LISTA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28940133,dzien-bez-samochodu-2022-w-ktorych-miastach-mozna-podrozowac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28940133,dzien-bez-samochodu-2022-w-ktorych-miastach-mozna-podrozowac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-22 09:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fd/e9/1a/z28219901M,Autobusy-elektryczne--zdjecie-ilustracyjne.jpg" vspace="2" />Dzień bez samochodu wypada 22 września, tego dnia osoby korzystające z komunikacji miejskiej nie mają obowiązku kupowania biletu. Sprawdź, w jakich miastach możesz poruszać się tramwajami i autobusami za darmo.

## Brzeziny. Pozwał Archidiecezję Łódzką, bo nie zgodził się z ceną wykopania grobu. Odzyska pieniądze
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28939663,brzeziny-pozwal-archidiecezje-lodzka-bo-nie-zgodzil-sie-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28939663,brzeziny-pozwal-archidiecezje-lodzka-bo-nie-zgodzil-sie-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-22 09:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/91/99/1b/z28939921M,Mieszkaniec-Brzezin-odzyskal-blisko-2-tys--zlotych.jpg" vspace="2" />Mieszkaniec Brzezin pozwał Archidiecezję Łódzką w związku z ogromnym kosztem wykopania grobu. - Tę pracę wykonała koparka, przecież jej wynajęcie tyle nie kosztuje - przekazał zbulwersowany mężczyzna. W środę sprawa w sądzie zakończyła się ugodą.

## Aborcja w Polsce. Lekarz zataił przed pacjentką, że płód nie ma czaszki. Dowiedziała się w 7. miesiącu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28939410,aborcja-w-polsce-lekarz-zatail-przed-pacjentka-ze-plod-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28939410,aborcja-w-polsce-lekarz-zatail-przed-pacjentka-ze-plod-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-22 08:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/97/8f/1a/z27852439M,Ciaza---zdjecie-ilustracyjne.jpg" vspace="2" />Aborcja w Polsce w przypadku, gdy stwierdzona zostanie ciężka wada płodu, zgodnie z orzeczeniem Trybunału Konstytucyjnego, jest nielegalna. Oznacza to, że kobieta nosząca w sobie chory płód jest zmuszona urodzić, nawet jeśli te nie będzie miało szansy na przeżycie. Jedną z takich osób jest pani Marina, która dopiero w siódmym miesiącu ciąży dowiedziała się, że płód nie ma ko


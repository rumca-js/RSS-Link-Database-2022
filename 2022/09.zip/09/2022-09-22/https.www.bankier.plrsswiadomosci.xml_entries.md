# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Moskwa: Każde gospodarstwo skorzysta z zamrożonej ceny prądu do 2000 kWh
 - [https://www.bankier.pl/wiadomosc/Moskwa-Kazde-gospodarstwo-skorzysta-z-zamrozonej-ceny-pradu-do-2000-kWh-8410512.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Moskwa-Kazde-gospodarstwo-skorzysta-z-zamrozonej-ceny-pradu-do-2000-kWh-8410512.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 22:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/d/9c72d0f6557715-948-568-0-154-4417-2650.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Każde gospodarstwo domowe skorzysta z zamrożonej ceny rachunku za energię do 2000 kWh zużycia bez względu na roczne zapotrzebowanie - zapewniła w czwartek wieczorem szefowa resortu klimatu i środowiska Anna Moskwa.</p>

## Kontynuacja spadków w Ameryce. S&P500 najniżej od lipca
 - [https://www.bankier.pl/wiadomosc/Kontynuacja-spadkow-w-Ameryce-8410502.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kontynuacja-spadkow-w-Ameryce-8410502.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 21:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/941eb3f49a4ee6-948-568-185-130-1815-1088.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trzecia z rzędu sesja na Wall Street zakończyła się pod
kreską. Rynek jest nieco przestraszony planami Rezerwy Federalnej.</p>

## Przywódcy państw Zachodu ostrzegli Rosję, że nie pozwolą jej wygrać wojny w Ukrainie
 - [https://www.bankier.pl/wiadomosc/Przywodcy-panstw-Zachodu-ostrzegli-Rosje-ze-nie-pozwola-jej-wygrac-wojny-w-Ukrainie-8410487.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przywodcy-panstw-Zachodu-ostrzegli-Rosje-ze-nie-pozwola-jej-wygrac-wojny-w-Ukrainie-8410487.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 20:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/4/2e611fa24fd247-948-568-0-0-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szefowie dyplomacji państw zachodnich zapowiedzieli w
 czwartek na forum Rady Bezpieczeństwa ONZ, że nie pozwolą Rosji wygrać 
wojny w Ukrainie i apelowali o pociągnięcie jej do odpowiedzialności. 
Nie pozwolimy na to, by pogwałcenie suwerenności Ukrainy uszło Putinowi 
na such

## Premier Izraela chce, aby Iran czuł zagrożenie militarne
 - [https://www.bankier.pl/wiadomosc/Premier-Izraela-chce-aby-Iran-czul-zagrozenie-militarne-8410476.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-Izraela-chce-aby-Iran-czul-zagrozenie-militarne-8410476.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 19:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/3ab8e851079427-948-568-0-0-3549-2129.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podczas obrad Zgromadzenia Ogólnego ONZ premier Izraela Jair Lapid zaapelował w czwartek do społeczności międzynarodowej o użycie „siły”, jeśli Iran wyprodukuje broń atomową. Powtórzył także swoje poparcie dla stworzenia "pokojowego" państwa palestyńskiego.</p>

## Rumuńscy meblarze narzekają na konkurencję firm z Polski
 - [https://www.bankier.pl/wiadomosc/Rumunscy-meblarze-narzekaja-na-konkurencje-firm-z-Polski-8410471.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rumunscy-meblarze-narzekaja-na-konkurencje-firm-z-Polski-8410471.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 19:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/1/30ba6342c43951-945-567-0-116-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Producenci sektora meblarskiego z Rumunii, w szczególności wytwórcy płyt drewnopochodnych, podczas czwartkowego spotkania z rządem skarżyli się na trudności branży. Wskazali, że obecnie na europejskim rynku bardziej konkurencyjne są spółki m.in. z Polski.</p>

## Hiszpania wprowadzi tymczasowy podatek dla najbogatszych
 - [https://www.bankier.pl/wiadomosc/Hiszpania-wprowadzi-tymczasowy-podatek-dla-najbogatszych-8410460.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hiszpania-wprowadzi-tymczasowy-podatek-dla-najbogatszych-8410460.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 18:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/2/778a8baf3d541e-948-568-0-64-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost gospodarczy Hiszpanii w 2022 r. i 2023 r. będzie mniejszy niż pierwotnie planował rząd Pedro Sancheza i wyniesie 4 proc. PKB - ogłosiła w czwartek w Madrycie hiszpańska minister finansów Maria Jesus Montero. Zapowiedziała też uruchomienie od 2023 r. tymczasowego podatku

## Planowali atak terrorystyczny na Islandii. Zostali zatrzymani przez policję
 - [https://www.bankier.pl/wiadomosc/Planowali-atak-terrorystyczny-na-Islandii-Zostali-zatrzymani-przez-policje-8410462.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Planowali-atak-terrorystyczny-na-Islandii-Zostali-zatrzymani-przez-policje-8410462.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 18:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/2/4f988f052d5c8f-948-568-0-104-4160-2495.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Islandzka policja poinformowała w czwartek, że aresztowała cztery osoby podczas zakrojonych na szeroką skalę operacji, mających na celu zapobieżenie przygotowaniom do ataku terrorystycznego.</p>

## Brytyjski rząd wycofuje się z podwyżki składki na ubezpieczenie społeczne
 - [https://www.bankier.pl/wiadomosc/Brytyjski-rzad-wycofuje-sie-z-podwyzki-skladki-na-ubezpieczenie-spoleczne-8410450.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjski-rzad-wycofuje-sie-z-podwyzki-skladki-na-ubezpieczenie-spoleczne-8410450.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 18:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/61e49148861e15-945-560-0-0-2349-1409.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wprowadzona od kwietnia podwyżka składki na ubezpieczenie społeczne, która od kwietnia 2023 roku miała stać się odrębnym podatkiem na potrzeby służby zdrowia i opieki społecznej, zostanie zniesiona 6 listopada - ogłosił w czwartek brytyjski minister finansów Kwasi Kwarteng.</p>

## RARS: W październiku pierwsza dostawa zamówionego przez agencję węgla
 - [https://www.bankier.pl/wiadomosc/RARS-W-pazdzierniku-pierwsza-dostawa-zamowionego-przez-agencje-wegla-8410446.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/RARS-W-pazdzierniku-pierwsza-dostawa-zamowionego-przez-agencje-wegla-8410446.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 18:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/a/6da9e1279b185f-948-567-0-42-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pierwsza dostawa zakontraktowanego przez Rządową Agencję Rezerw Strategicznych węgla przewidziana jest na październik - wynika z opublikowanej w czwartek informacji RARS.</p>

## W Małopolsce trwa spór o odroczenie uchwały antysmogowej
 - [https://www.bankier.pl/wiadomosc/W-Malopolsce-trwa-spor-o-odroczenie-uchwaly-antysmogowej-8410444.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-Malopolsce-trwa-spor-o-odroczenie-uchwaly-antysmogowej-8410444.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 18:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/e/07e81bf8683a80-948-568-0-116-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Małopolskie samorządy w przytłaczającej większości popierają wydłużenie terminu wymiany pieców bezklasowych - podał w czwartek urząd marszałkowski województwa. Z kolei aktywiści społeczni wskazują, że ok. 75 proc. opinii zebranych w ramach konsultacji sprzeciwia się zmianom w

## Niemcy planują znacjonalizowanie Gazpromu Germania
 - [https://www.bankier.pl/wiadomosc/Niemcy-planuja-znacjonalizowanie-Gazpromu-Germania-8410436.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niemcy-planuja-znacjonalizowanie-Gazpromu-Germania-8410436.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 17:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/6/9b1d7a9b12f7c9-948-567-20-25-980-587.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd niemiecki znacjonalizuje dawną spółkę zależną rosyjskiego koncernu, która przez lata dominowała na gazowym rynku Europy Zachodniej - Securing Energy for Europe (SEFE). Firma od kwietnia znajduje się już pod zarządem Federalnej Agencji ds. Sieci. Jak informuje w czwartek „S

## Ceny gazu ziemnego w czwartek spadają
 - [https://www.bankier.pl/wiadomosc/Ceny-gazu-ziemnego-w-czwartek-spadaja-8410434.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-gazu-ziemnego-w-czwartek-spadaja-8410434.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 17:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/9/bcb185ae3d99ce-948-568-7-219-3125-1875.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Cena gazu ziemnego z dostawą w październiku w holenderskim hubie TTF spadła na czwartkowym zamknięciu o 0,94 proc., do 188 euro za MWh. Niższe były także ceny kontraktów listopadowych.</p>

## Media: Izrael dostarczy Zjednoczonym Emiratom Arabskim zaawansowany system obrony powietrznej
 - [https://www.bankier.pl/wiadomosc/Media-Izrael-dostarczy-Zjednoczonym-Emiratom-Arabskim-zaawansowany-system-obrony-powietrznej-8410405.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-Izrael-dostarczy-Zjednoczonym-Emiratom-Arabskim-zaawansowany-system-obrony-powietrznej-8410405.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 16:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/b1d8154a2155c6-945-560-0-953-3051-1830.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Izrael zgodził się sprzedać Zjednoczonym Emiratom Arabskim zaawansowany system obrony powietrznej - poinformowała w czwartek agencja Reutera, powołując się na źródła zaznajomione z transakcją.</p>

## GPW w swoim kierunku. Milion osób grało codziennie w Cyberpunka
 - [https://www.bankier.pl/wiadomosc/GPW-w-swoim-kierunku-Milion-osob-gralo-codziennie-w-Cyberpunka-8410391.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/GPW-w-swoim-kierunku-Milion-osob-gralo-codziennie-w-Cyberpunka-8410391.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 16:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/f/af80e37115f955-948-568-2-0-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Główne indeksy na GPW zakończyły sesję wzrostami w przeciwieństwie do najważniejszych giełd rynków bazowych. Sesja upłynęła pod znakiem lepszego sentymentu do spółek surowcowych i bankowych, a o powrocie zainteresowania graczy „Cyberpunkiem” poinformował w mediach społecznościowy

## Niemiecki rząd: jesteśmy gotowi przyjąć rosyjskich dezerterów
 - [https://www.bankier.pl/wiadomosc/Niemiecki-rzad-jestesmy-gotowi-przyjac-rosyjskich-dezerterow-8410377.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niemiecki-rzad-jestesmy-gotowi-przyjac-rosyjskich-dezerterow-8410377.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 16:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/0/33f2cd22ff9d24-948-568-8-0-3199-1919.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niemcy są gotowe na przyjęcie dezerterów z armii rosyjskiej "zagrożonych poważnymi represjami" - powiedziała niemiecka minister spraw wewnętrznych Nancy Faeser w opublikowanym w czwartek wywiadzie dla "Frankfurter Allgemeine Zeitung".</p>

## Rząd Estonii wezwał niemal 3 tys. rezerwistów na ćwiczenia wojskowe
 - [https://www.bankier.pl/wiadomosc/Rzad-Estonii-wezwal-niemal-3-tys-rezerwistow-na-cwiczenia-wojskowe-8410353.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-Estonii-wezwal-niemal-3-tys-rezerwistow-na-cwiczenia-wojskowe-8410353.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 15:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/4a79503633e95f-945-567-131-323-3310-1986.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo obrony Estonii wezwało w czwartek 2,8 tys. rezerwistów do wzięcia udziału w corocznych ćwiczeniach wojskowych - poinformowała agencja ERR.</p>

## Saudyjczycy chcą wysłać kobietę w kosmos. Już za rok
 - [https://www.bankier.pl/wiadomosc/Saudyjczycy-chca-wyslac-kobiete-w-kosmos-Juz-za-rok-8410347.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Saudyjczycy-chca-wyslac-kobiete-w-kosmos-Juz-za-rok-8410347.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 15:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/2/66071a87e67f55-948-567-0-0-985-590.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władze Arabii Saudyjskiej ogłosiły w czwartek plan stworzenia programu treningowego dla astronautów. Jak podała agencja SPA, w 2023 roku w kosmos ma polecieć załoga, w skład której wejdzie pierwsza saudyjska pilotka i astronautka.</p>

## Sprzedaż miedzi przez grupę KGHM w sierpniu wyższa rdr o 5 proc.
 - [https://www.bankier.pl/wiadomosc/Sprzedaz-miedzi-przez-grupe-KGHM-wyniosla-sierpniu-58-9-tys-ton-wyzsza-rdr-o-5-proc-8410333.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sprzedaz-miedzi-przez-grupe-KGHM-wyniosla-sierpniu-58-9-tys-ton-wyzsza-rdr-o-5-proc-8410333.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 15:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/f/91520a69bc772c-945-560-127-142-2872-1723.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sprzedaż miedzi przez grupę KGHM wyniosła w sierpniu 2022 roku 58,9 tys. ton i była wyższa rdr o 5 proc. Produkcja miedzi płatnej KGHM wyniosła w tym czasie 60,3 tys. ton, co oznacza spadek rdr o 7 proc. - podała grupa w komunikacie, dotyczącym wstępnych wyników produkcyjny

## KNF zażądał zawieszenia notowań spółki z giełdy. Akcjonariuszem jest w niej były piłkarz reprezentacji
 - [https://www.bankier.pl/wiadomosc/KNF-zazadal-zawieszenia-notowan-spolki-z-gieldy-Akcjonariuszem-jest-w-niej-byly-pilkarz-reprezentacji-8410332.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KNF-zazadal-zawieszenia-notowan-spolki-z-gieldy-Akcjonariuszem-jest-w-niej-byly-pilkarz-reprezentacji-8410332.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 15:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/b/ba03872ba3424e-945-560-1181-0-2850-1709.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stopa zwrotu za ostatnie trzy lata na spółce z NewConnect jest większa niż na akcjach Tesli. Notowania ciągle szły w górę, ale nadzorca po ostatnich wzrostach zażądał ich zawieszenia z uwagi na interes inwestorów. Jednym z akcjonariuszy jest były piłkarz reprezentacji Polski

## 11 bit studios przekłada światowy pokaz gry Codename Vitriol
 - [https://www.bankier.pl/wiadomosc/11-bit-studios-przeklada-swiatowy-pokaz-gry-Codename-Vitriol-8410314.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/11-bit-studios-przeklada-swiatowy-pokaz-gry-Codename-Vitriol-8410314.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 15:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/2/6a767043d19aea-945-560-0-132-1938-1162.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Światowy pokaz gry Codename Vitriol autorstwa 11 bit studios został przełożony - poinformowała spółka na Twitterze.</p>

## Związkowcy z Tauron Wydobycie chcą gwarancji pracowniczych. Żądają rozmów z Sasiem
 - [https://www.bankier.pl/wiadomosc/Zwiazkowcy-z-Tauron-Wydobycie-chca-gwarancji-pracowniczych-Zadaja-rozmow-z-Sasiem-8410302.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zwiazkowcy-z-Tauron-Wydobycie-chca-gwarancji-pracowniczych-Zadaja-rozmow-z-Sasiem-8410302.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 14:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/4d02a2551a5224-948-568-0-48-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Związkowcy ze spółki Tauron Wydobycie domagają pilnego spotkania z wicepremierem, szefem Ministerstwa Aktywów Państwowych Jackiem Sasinem. Chcą rozmawiać o gwarancjach pracowniczych w związku z planowanymi przekształceniami w spółce.</p>

## Minister Moskwa: Węgiel z importu płynie i będzie płynął
 - [https://www.bankier.pl/wiadomosc/Minister-Moskwa-Wegiel-z-importu-plynie-i-bedzie-plynal-8410272.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-Moskwa-Wegiel-z-importu-plynie-i-bedzie-plynal-8410272.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 14:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/0/f3cc4fcc21b3f4-948-568-0-67-1473-884.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Węgiel z importu płynie i będzie płynął do kraju - oświadczyła w czwartek minister klimatu Anna Moskwa w Zakopanem. Jak dodała, na rynek powinno trafić ok. 5 mln ton odsianego</p>

## Soboń: Rząd nie zejdzie z drogi polityki społecznej, pomocy rodzinie i wsparcia najbardziej potrzebujących
 - [https://www.bankier.pl/wiadomosc/Sobon-Rzad-nie-zrezygnuje-z-pomocy-rodzinie-i-wsparcia-potrzebujacych-8410265.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sobon-Rzad-nie-zrezygnuje-z-pomocy-rodzinie-i-wsparcia-potrzebujacych-8410265.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 14:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/5/03734c0708100c-948-568-0-169-1274-764.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd Mateusza Morawieckiego nie zejdzie z drogi polityki społecznej, pomocy rodzinie i wsparcia najbardziej potrzebujących – powiedział wiceminister finansów Artur Soboń podczas czwartkowej konferencji prasowej w Zakopanem.</p>

## Jak pokonać kryzys energetyczny w Polsce?
 - [https://www.bankier.pl/wiadomosc/Jak-pokonac-kryzys-energetyczny-w-Polsce-8408729.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jak-pokonac-kryzys-energetyczny-w-Polsce-8408729.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 14:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/a/70e2a3bb3fa52e-948-568-0-56-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zapraszamy do oglądania transmisji z 174. seminarium mBank–CASE zatytułowanego "Jak pokonać kryzys energetyczny w Polsce?".</p>

## Nieoficjalnie: Trwają prace nad kolejnym pakietem sankcji UE wobec Rosji
 - [https://www.bankier.pl/wiadomosc/Nieoficjalnie-Trwaja-prace-nad-kolejnym-pakietem-sankcji-UE-wobec-Rosji-8410234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nieoficjalnie-Trwaja-prace-nad-kolejnym-pakietem-sankcji-UE-wobec-Rosji-8410234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 13:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/0/d00bd85965f109-948-568-0-4-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska i kraje regionu Morza Bałtyckiego przygotowują wspólną propozycję kolejnych sankcji UE wobec Rosji. Prace zakończą się w ciągu najbliższych godzin  – przekazało w czwartek PAP unijne źródło dyplomatyczne.</p>

## NBP: Podaż pieniądza (M3) w sierpniu wzrosła o 7,4 proc. rdr
 - [https://www.bankier.pl/wiadomosc/NBP-Podaz-pieniadza-M3-w-sierpniu-wzrosla-o-7-4-proc-rdr-8410205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBP-Podaz-pieniadza-M3-w-sierpniu-wzrosla-o-7-4-proc-rdr-8410205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 13:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/e442d074ebd6ba-948-568-2-65-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podaż pieniądza (M3) w sierpniu 2022 r. wzrosła o 7,4 proc. rdr, do 2.044.023,1 mln zł - podał Narodowy Bank Polski. W ujęciu miesięcznym podaż pieniądza wzrosła o 1,6 proc.</p>

## Załamanie na rynku hipotek w sierpniu. Może być jeszcze gorzej
 - [https://www.bankier.pl/wiadomosc/Zalamanie-na-rynku-hipotek-w-sierpniu-8410193.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zalamanie-na-rynku-hipotek-w-sierpniu-8410193.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 12:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/b193d758b2eb6c-948-568-0-202-3120-1871.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wartość udzielonych kredytów mieszkaniowych w sierpniu 2022 r. spadła w Polsce o 69,3 proc. rdr, a w ujęciu liczbowym spadła o 68,8 proc. rdr - podało Biuro Informacji Kredytowej (BIK).</p>

## Turcy znów ścięli stopy procentowe na przekór całemu światu
 - [https://www.bankier.pl/wiadomosc/Turcja-obniza-stopy-procentowe-wrzesien-2022-8410164.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Turcja-obniza-stopy-procentowe-wrzesien-2022-8410164.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 12:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/a1b42f803a954b-945-560-0-41-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podczas gdy (prawie) wszystkie ważne banki centralne świata
podnoszą stopy procentowe, Turcy po raz kolejny postanowili je obniżyć, nie zważając na galopującą inflację.</p>

## Bank Anglii podnosi stopy najwyżej od 2008 r. Kolejny zdecydowany ruch
 - [https://www.bankier.pl/wiadomosc/Bank-Anglii-podnosi-stopy-najwyzej-od-2008-r-Kolejny-zdecydowany-ruch-8410145.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bank-Anglii-podnosi-stopy-najwyzej-od-2008-r-Kolejny-zdecydowany-ruch-8410145.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 12:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/f7fe79fb69909e-948-568-0-8-1724-1034.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bank Anglii dalej jest zdeterminowany w walce z inflacją. To już siódma podwyżka w bieżącym cyklu zacieśniania polityki monetarnej i szósta z rzędu. Jednocześnie dokonana kolejny raz za pomocą znacznego ruchu. </p>

## Rusza program rewitalizacji hałd do odzysku węgla. Pilotaż w Bogdance
 - [https://www.bankier.pl/wiadomosc/Bogdanka-ma-porozumienie-z-grupa-CZH-ws-odzysku-wegla-z-hald-kopalnianych-8410155.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bogdanka-ma-porozumienie-z-grupa-CZH-ws-odzysku-wegla-z-hald-kopalnianych-8410155.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 11:58:00+00:00

<p>Rusza program Ministerstwa Aktywów Państwowych odzysku węgla z hałd górniczych.  Pilotażowa instalacja ma rozpocząć pracę w Bogdance na przełomie 2022/23 roku - podała Enea w komunikacie prasowym.</p>

## W Holandii brakuje rąk do pracy we wszystkich grupach zawodowych
 - [https://www.bankier.pl/wiadomosc/W-Holandii-brakuje-rak-do-pracy-we-wszystkich-grupach-zawodowych-8410147.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-Holandii-brakuje-rak-do-pracy-we-wszystkich-grupach-zawodowych-8410147.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 11:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/6/fc1c08dc68e4a3-875-524-125-107-875-524.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niedobór na rynku pracy w Holandii jest dwukrotnie większy niż w ubiegłym roku - informuje w czwartek Agencja Ubezpieczeń Pracowniczych (UWV). Braki kadrowe wzrosły do tego stopnia, że w drugim kwartale niedobory wystąpiły we wszystkich 92 grupach zawodowych.</p>

## Dostawcy technologii jądrowych: co najmniej 50 proc. udziału z Polski
 - [https://www.bankier.pl/wiadomosc/Dostawcy-technologii-jadrowych-co-najmniej-50-proc-udzialu-z-Polski-8410138.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dostawcy-technologii-jadrowych-co-najmniej-50-proc-udzialu-z-Polski-8410138.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 11:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/e/bdb7d7a13837b0-948-567-0-39-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Firmy oferujące technologie dla polskiego projektu jądrowego deklarują, że w pierwszej fazie udział polskich przedsiębiorstw w inwestycji może wynosić ok. 50 proc. wartości, a w dalszych fazach udział ten będzie rósł.</p>

## PIE: niemal 40 proc. firm wdrożyło technologie ograniczające koszty energii
 - [https://www.bankier.pl/wiadomosc/PIE-niemal-40-proc-firm-wdrozylo-technologie-ograniczajace-koszty-energii-8410132.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PIE-niemal-40-proc-firm-wdrozylo-technologie-ograniczajace-koszty-energii-8410132.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 11:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/a/b0683bd33a08ce-948-568-0-296-4096-2457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ok. 40 proc. firm wdrożyło technologie ograniczające koszty energii, a 18 proc. ma to w planach - poinformował w czwartek Polski Instytut Ekonomiczny. Zużycie energii można obniżyć od kilkunastu do kilkudziesięciu procent m.in. modernizując system oświetlenia czy wentylacji -

## Japonia interweniuje na rynku walutowym
 - [https://www.bankier.pl/wiadomosc/Japonia-interweniuje-na-rynku-walutowym-8410128.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Japonia-interweniuje-na-rynku-walutowym-8410128.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 11:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/7/0bd2969dbce65c-945-567-23-135-2338-1403.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władze Japonii zdecydowały się na pierwszą od niemal ćwierć
wieku interwencję na rynku walutowym wzmacniającą jena.</p>

## 1000 zł za udział w posiedzeniu w resorcie. Tak zarabiają doradcy
 - [https://www.bankier.pl/wiadomosc/1000-zl-za-udzial-w-posiedzeniu-w-resorcie-edukacji-rzadu-Jest-projekt-wynagrodzenia-doradcow-8410118.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/1000-zl-za-udzial-w-posiedzeniu-w-resorcie-edukacji-rzadu-Jest-projekt-wynagrodzenia-doradcow-8410118.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 11:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/c49f59cc0a60cf-948-568-20-70-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Określenie wysokości stawek wynagrodzenia za udział w posiedzeniach zespołu doradczego szefa MEiN i za przygotowanie przez jej członków opinii zakłada projekt nowelizacji rozporządzenia Ministra Nauki i Szkolnictwa Wyższego, który w czwartek opublikowano w Rządowym Centrum Le

## Polskę czeka urodzaj jabłek. Resort rolnictwa: to będzie realny problem
 - [https://www.bankier.pl/wiadomosc/Polske-czeka-urodzaj-jablek-Resort-rolnictwa-to-bedzie-realny-problem-8410085.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polske-czeka-urodzaj-jablek-Resort-rolnictwa-to-bedzie-realny-problem-8410085.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 10:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/11cf6a3b2a18c4-948-568-0-119-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dobry urodzaj to będzie realny problem przy zamkniętych rynkach wschodnich - uważa wicepremier, minister rolnictwa i rozwoju wsi Henryk Kowalczyk, pytany w czwartek o tegoroczny zbiór jabłek. Dodał, że trwa szukanie nowych rynków zbytu m.in. w Afryce, Azji, głównie na jabłka 

## Promocje, koniec z rozrywkami, tańsze zamienniki. Niemal 1/3 Polaków oszczędza "na wszystkim"
 - [https://www.bankier.pl/wiadomosc/Promocje-koniec-z-rozrywkami-tansze-zamienniki-Niemal-1-3-Polakow-oszczedza-na-wszystkim-8410084.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Promocje-koniec-z-rozrywkami-tansze-zamienniki-Niemal-1-3-Polakow-oszczedza-na-wszystkim-8410084.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 10:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/4/117fb5d7f274a4-948-568-0-210-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niemal 1/3 Polaków oszczędza "na wszystkim" - wynika z badania postaw Polaków wobec rosnących cen. Ponad 80 proc. respondentów uważa, że w kolejnych miesiącach ceny produktów i usług nadal będą rosły.</p>

## Akcjonariusz Ursusa wyprzedaje akcje. Kurs najniżej w historii
 - [https://www.bankier.pl/wiadomosc/Akcjonariusz-Ursusa-wyprzedaje-akcje-Kurs-najnizej-w-historii-8410082.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Akcjonariusz-Ursusa-wyprzedaje-akcje-Kurs-najnizej-w-historii-8410082.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 10:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/0b3d1e14f3eed9-945-560-33-44-4466-2679.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs popularnego producenta ciągników notowany jest na najniższych poziomach w historii. Jedna ze spółek, będąca częścią holdingu głównego akcjonariusza Ursusa, wyprzedaje swoje akcje w ostatnich dniach. Zadłużenie spółki to już kilkaset milionów złotych.</p>

## Urzędniku, zgaś za sobą światło. Ministerstwa wprowadzają oszczędności
 - [https://www.bankier.pl/wiadomosc/Urzedniku-zgas-za-soba-swiatlo-Ministerstwa-wprowadzaja-oszczednosci-8410077.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Urzedniku-zgas-za-soba-swiatlo-Ministerstwa-wprowadzaja-oszczednosci-8410077.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 10:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/b/0ee6d5f55bfd91-948-568-0-142-3008-1804.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Urzędy w Polsce wdrażają w życie działania mające przełożyć się na oszczędności energii elektrycznej i cieplnej. W poszczególnych ministerstwach w tym celu np. obniżono temperaturę lub wyłączono co drugą świetlówkę.</p>

## Grupa Orlen przejmuje firmę recyklingową Remaq
 - [https://www.bankier.pl/wiadomosc/Grupa-Orlen-przejmuje-firme-recyklingowa-Remaq-8410071.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Grupa-Orlen-przejmuje-firme-recyklingowa-Remaq-8410071.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 10:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/3/7c0a793f6c712c-948-568-0-60-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa Orlen inwestuje w proekologiczne projekty, poprzez przejęcie włosko-czeskiej firmy Remaq – poinformował PKN Orlen w komunikacie prasowym. Spółka zakłada, że transakcja zostanie sfinalizowana do końca marca 2023 roku.</p>

## Przywrócenie życia w Odrze będzie kosztować kilkanaście mln zł i wiele lat
 - [https://www.bankier.pl/wiadomosc/Przywrocenie-zycia-w-Odrze-bedzie-kosztowac-kilkanascie-mln-zl-i-wiele-lat-8410069.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przywrocenie-zycia-w-Odrze-bedzie-kosztowac-kilkanascie-mln-zl-i-wiele-lat-8410069.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 10:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/70e7e313c5bcbb-948-568-0-53-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wojewódzkie fundusze ochrony środowiska przeznaczą 14 mln zł na odnowienie życia w Odrze i jej zarybienie – powiedziała w czwartek na konferencji prasowej w Szczecinie wiceminister klimatu i środowiska Małgorzata Golińska.</p>

## Amazon podpisał jedną z największych umów na zakup energii odnawialnej w Polsce
 - [https://www.bankier.pl/wiadomosc/Amazon-podpisal-jedna-z-najwiekszych-umow-na-zakup-energii-odnawialnej-w-Polsce-8410044.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Amazon-podpisal-jedna-z-najwiekszych-umow-na-zakup-energii-odnawialnej-w-Polsce-8410044.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 09:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/9/5d40c5b97e01cf-948-568-0-0-3105-1863.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amazon podpisał umowę na zakup energii z farmy fotowoltaicznej w Miłkowicach w powiecie legnickim. To jedna z największych dotychczasowych umów zakupu energii słonecznej w Polsce.</p>

## Żołnierze rezerwy w Rosji mają zakaz opuszczania miejsca zamieszkania
 - [https://www.bankier.pl/wiadomosc/Zolnierze-rezerwy-w-Rosji-maja-zakaz-opuszczania-miejsca-zamieszkania-8410054.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zolnierze-rezerwy-w-Rosji-maja-zakaz-opuszczania-miejsca-zamieszkania-8410054.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 09:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/b/d9158c002c16a3-948-568-0-210-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Oficerowie i żołnierze rezerwy, którzy nie otrzymali jeszcze wezwania mobilizacyjnego, mają zakaz opuszczania stałego miejsca zamieszkania bez zgody władz wojskowych – poinformowała w czwartek na swoim portalu ukraińska redakcja Radia Swoboda.</p>

## Ostra jazda franka. Dolar rekordowo drogi
 - [https://www.bankier.pl/wiadomosc/Ostra-jazda-franka-Dolar-rekordowo-drogi-8410040.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ostra-jazda-franka-Dolar-rekordowo-drogi-8410040.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 09:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/7d18914f876547-948-568-17-77-982-589.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po porannej decyzji Szwajcarskiego Banku Narodowego kurs
franka szwajcarskiego spadł poniżej 5 złotych. Na rekordowo wysokim poziomie
znalazły się notowania dolara amerykańskiego.</p>

## UOKiK: PZU Życie ponownie rozpatrzy roszczenia za pobyt na Oddziale Intensywnej Terapii
 - [https://www.bankier.pl/wiadomosc/UOKiK-PZU-Zycie-ponownie-rozpatrzy-roszczenia-za-pobyt-na-Oddziale-Intensywnej-Terapii-8410028.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UOKiK-PZU-Zycie-ponownie-rozpatrzy-roszczenia-za-pobyt-na-Oddziale-Intensywnej-Terapii-8410028.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 08:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/8/078a4d83e5817e-945-567-2-70-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wszyscy ubezpieczeni w PZU Życie, którym odmówiono wypłaty dodatkowego świadczenia za pobyt na Oddziale Intensywnej Terapii oraz Oddziale Anestezjologii i Intensywnej Terapii z powodu braku spełnienia definicji tych oddziałów, mogą ponownie ubiegać się o wypłatę świadczenia - po

## Szwajcarzy po raz drugi podnoszą stopy procentowe
 - [https://www.bankier.pl/wiadomosc/SNB-podnosi-stopy-procentowe-wrzesien-2022-8410012.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/SNB-podnosi-stopy-procentowe-wrzesien-2022-8410012.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 08:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/b/25fc32124fe985-948-568-192-0-1731-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szwajcarski Bank Narodowy zdecydował się na drugą z rzędu
podwyżkę stóp procentowych mającą na celu powstrzymanie dalszego wzrostu
inflacji. Helweci nie wykluczyli kolejnych podwyżek</p>

## Ceny ropy w USA rosną; decyzja Fedu w centrum uwagi
 - [https://www.bankier.pl/wiadomosc/Ropa-naftowa-w-czwartek-rano-drozeje-8409995.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ropa-naftowa-w-czwartek-rano-drozeje-8409995.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 07:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/9/99660f3d5de606-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną. Inwestorzy analizują decyzję Fedu, który podniósł stopy proc. o 75 pb. Rynki obawiają się o spowolnienie gospodarcze na świecie.</p>

## Komisja Europejska skontroluje kamienie milowe zapisane w polskim KPO
 - [https://www.bankier.pl/wiadomosc/Komisja-Europejska-skontroluje-kamienie-milowe-zapisane-w-polskim-KPO-8409960.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Komisja-Europejska-skontroluje-kamienie-milowe-zapisane-w-polskim-KPO-8409960.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 06:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/8/551bbcf7592122-948-568-5-125-1995-1196.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa komisarzy, w tym ja uznała, że kamienie milowe zapisane w polskim KPO nie są wystarczająco jasne; ale większość kolegów zaakceptowała KPO i teraz kluczowe jest, by ocenić, czy kamienie milowe w nim zapisane zostały wykonane - podkreśliła w wywiadzie dla "Rzeczpospolitej

## Afera Getback. Kolejne cztery osoby zatrzymane
 - [https://www.bankier.pl/wiadomosc/Afera-Getback-Kolejne-cztery-osoby-zatrzymane-8409954.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Afera-Getback-Kolejne-cztery-osoby-zatrzymane-8409954.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 06:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/0/7977b44646726f-948-568-2-7-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Funkcjonariusze Centralnego Biura Antykorupcyjnego na polecenie Prokuratury Regionalnej w Warszawie zatrzymali kolejne cztery osoby w śledztwie dotyczącym nieprawidłowości w spółce GetBack S.A. - dowiedziała się PAP. Według śledczych przez zatrzymanych pokrzywdzone zostały 63 osó

## Głównie wygoda, a nie ceny. To nas zachęca do e-zakupów
 - [https://www.bankier.pl/wiadomosc/Glownie-wygoda-a-nie-ceny-To-nas-zacheca-do-e-zakupow-8409950.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Glownie-wygoda-a-nie-ceny-To-nas-zacheca-do-e-zakupow-8409950.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 06:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/4/513ecaf0fa4599-948-568-0-0-1767-1060.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już 26 milionów Polaków kupuje online, w ciągu kilku lat liczba ta jeszcze wzrośnie o kolejne miliony. 8 proc. obecnych klientów rozpoczęło przygodę z e-handlem podczas pandemii. Takiej sprzedaży nie sposób już ignorować - donosi czwartkowa "Rzeczpospolita".</p>

## Bajoński koszt remontu lwów przed Pałacem Prezydenckim
 - [https://www.bankier.pl/wiadomosc/Bajonski-majatek-na-remont-lwow-przed-Palacem-Prezydenckim-8409948.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bajonski-majatek-na-remont-lwow-przed-Palacem-Prezydenckim-8409948.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 06:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/1/cdc0fb6d015916-948-568-105-265-1783-1070.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Cztery niepozorne posągi przed dziesięcioma laty przeszły renowację. Mimo to planowana jest kolejna, za niemal 3 mln zł - czytamy w czwartkowej "Rzeczpospolitej".</p>

## Lewica chce skrócenia czasu pracy. Biejat: to będzie miało wpływ na wydajność i zdrowie pracowników
 - [https://www.bankier.pl/wiadomosc/Lewica-chce-skrocenia-czasu-pracy-Biejat-to-bedzie-mialo-wplyw-na-wydajnosc-i-zdrowie-pracownikow-8409947.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lewica-chce-skrocenia-czasu-pracy-Biejat-to-bedzie-mialo-wplyw-na-wydajnosc-i-zdrowie-pracownikow-8409947.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 06:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/9/6a8b03e9a4ba1c-945-560-578-271-2297-1378.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Lewica w czwartek złoży w Sejmie projekt ustawy przewidujący skrócenie czasu pracy z 40 do 35 godzin tygodniowo. Skrócenie czasu pracy będzie miało wpływ na poziom wydajności pracowników i na ich zdrowie - mówi PAP wiceszefowa klubu Magdalena Biejat. Lewica będzie zachęcać 

## Kredytowy kryzys gorszy niż pandemia. Deweloperzy tną inwestycje
 - [https://www.bankier.pl/wiadomosc/Kredytowy-kryzys-gorszy-niz-pandemia-Deweloperzy-tna-inwestycje-8409946.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kredytowy-kryzys-gorszy-niz-pandemia-Deweloperzy-tna-inwestycje-8409946.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 06:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/2/a9e0effeec59c5-948-568-0-94-1989-1193.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nawet w czasie lockdownu deweloperzy budowali więcej mieszkań niż obecnie. Ograniczenie podaży to efekt spadku popytu z powodu niedostępności kredytów, ale też chęci utrzymania marż - pisze czwartkowa "Rzeczpospolita".</p>

## Ustawa o wsparciu odbiorców ciepła wydłużyła termin wypłaty dodatku węglowego
 - [https://www.bankier.pl/wiadomosc/Ustawa-o-wsparciu-odbiorcow-ciepla-wydluzyla-termin-wyplaty-dodatku-weglowego-8409941.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ustawa-o-wsparciu-odbiorcow-ciepla-wydluzyla-termin-wyplaty-dodatku-weglowego-8409941.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 06:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/3/12f714a13c3c67-948-567-0-32-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ustawa o wsparciu odbiorców ciepła wydłużyła z miesiąca do dwóch miesięcy termin wypłaty przez samorządy dodatku węglowego. Inny zapis nowej ustawy ustalił zasadę wypłaty dodatku węglowego w przypadku, gdy miejsce zamieszkania zamieszkuje więcej, niż jedno gospodarstwo domowe.<

## Akcjonariusze Berlinga ogłoszą wezwanie do sprzedaży akcji spółki po 4,45 zł/szt
 - [https://www.bankier.pl/wiadomosc/Akcjonariusze-Berlinga-oglosza-wezwanie-do-sprzedazy-akcji-spolki-po-4-45-zl-szt-8409931.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Akcjonariusze-Berlinga-oglosza-wezwanie-do-sprzedazy-akcji-spolki-po-4-45-zl-szt-8409931.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 05:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/ccf4d09f95918d-948-568-78-0-4421-2652.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Berling, Dao, Arkton oraz Berling Development zamierzają ogłosić wezwanie do sprzedaży 6.593.173 akcji spółki Berling, stanowiących 37,57 proc. kapitału zakładowego i głosów na WZ, po 4,45 zł za akcję - podał Berling w komunikacie.</p>

## Nowe technologie coraz mocniej wkraczają na rynek pracy. Kolejną rewolucję wywoła metawersum
 - [https://www.bankier.pl/wiadomosc/Nowe-technologie-coraz-mocniej-wkraczaja-na-rynek-pracy-Kolejna-rewolucje-wywola-metawersum-8409917.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowe-technologie-coraz-mocniej-wkraczaja-na-rynek-pracy-Kolejna-rewolucje-wywola-metawersum-8409917.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 05:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/d025a84c8084b4-948-568-1006-0-1385-831.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W dobie pandemii większość pracowników biurowych realizowała zadania zdalnie, poprzez komunikatory odbywały się również rozmowy rekrutacyjne. Choć sytuacja epidemiczna jest już mniej poważna, to pracownicy przyzwyczaili się do pracy zdalnej i hybrydowej i nie chcą z niej rezy

## UE zgadza się na przygotowanie nowych sankcji wymierzonych w Rosję
 - [https://www.bankier.pl/wiadomosc/Nowy-pakiet-sankcji-na-Rosje-bedzie-nalozony-po-ogloszeniu-czesciowej-mobilizacj-8409915.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowy-pakiet-sankcji-na-Rosje-bedzie-nalozony-po-ogloszeniu-czesciowej-mobilizacj-8409915.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 05:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/c02b35ece7e8cb-948-568-0-57-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministrowie spraw zagranicznych państw Unii Europejskiej zgodzili się w środę podczas nieformalnego spotkania w Nowym Jorku  na wprowadzenie nowych sankcji wymierzonych w Rosję, powiedział Josep Borrell</p>

## Gwałtowny zapotrzebowania na pożyczki w sierpniu [dane BIK]
 - [https://www.bankier.pl/wiadomosc/Gwaltowny-zapotrzebowania-na-pozyczki-w-sierpniu-dane-BIK-8409910.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gwaltowny-zapotrzebowania-na-pozyczki-w-sierpniu-dane-BIK-8409910.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 05:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/f/ea854cf65a65e0-948-568-19-116-2572-1543.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Firmy pożyczkowe udzieliły w sierpniu br. o 27,3 proc. więcej pożyczek w porównaniu do sierpnia 2021 r.  - podało Biuro Informacji Kredytowej. Wzrosła również wartość udzielonych pożyczek, o 29,3 proc. rdr.</p>

## Antyranking lokat i kont oszczędnościowych. W tych bankach czas stanął w miejscu
 - [https://www.bankier.pl/wiadomosc/Antyranking-lokat-i-kont-oszczednosciowych-W-tych-bankach-czas-stanal-w-miejscu-8409535.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Antyranking-lokat-i-kont-oszczednosciowych-W-tych-bankach-czas-stanal-w-miejscu-8409535.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/eaf8dd868c2b75-948-568-0-21-2100-1259.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />7 procent… 7,50 procent. Kto da więcej? 8 procent w jednym, a za chwilę kilku bankach. Instytucje prześcigają się w zdobywaniu oszczędności klientów, podnosząc stawki na swoich produktach. Są jednak banki, które od czasu rekordowo niskich stawek, nie pokusiły się o żadne wielk

## Inżynierowie potrzebni od zaraz. W tych branżach mogą dobrze zarobić
 - [https://www.bankier.pl/wiadomosc/Inzynierowie-zarobki-i-zapotrzebowanie-8409479.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inzynierowie-zarobki-i-zapotrzebowanie-8409479.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/4216440d2336e8-948-568-12-165-2537-1522.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />OZE, biotechnologia oraz mechatronika – to zdaniem Bergman Engineering branże, które już teraz zgłaszają wysokie zapotrzebowanie na inżynierów. Najlepiej opłacanymi są specjaliści od odnawialnych źródeł energii, dla których stawki wynoszą nawet kilkanaście tysięcy złotych br

## Węgiel dla PGE także droższy. Średni koszt to nawet 460 zł za tonę
 - [https://www.bankier.pl/wiadomosc/Wegiel-dla-PGE-takze-drozszy-Sredni-koszt-to-nawet-460-zl-za-tone-8409652.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wegiel-dla-PGE-takze-drozszy-Sredni-koszt-to-nawet-460-zl-za-tone-8409652.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/d/b381aef01f1240-948-568-0-70-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa PGE pokazała wyniki za pierwsze półrocze, dzięki czemu
dowiedzieliśmy się, ile największy producent energii i ciepła w kraju płacił za
węgiel kamienny. </p>

## Zełenski w ONZ: Nie możemy zgodzić się na tymczasowe wstrzymanie wojny
 - [https://www.bankier.pl/wiadomosc/Zelenski-w-ONZ-Nie-mozemy-zgodzic-sie-na-tymczasowe-wstrzymanie-wojny-8409891.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zelenski-w-ONZ-Nie-mozemy-zgodzic-sie-na-tymczasowe-wstrzymanie-wojny-8409891.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-22 00:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/9e0ac9bffefc57-948-568-7-15-2992-1795.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przeciwko Ukrainie została popełniona zbrodnia i żądamy za nią sprawiedliwej kary - powiedział w środę prezydent Ukrainy Wołodymyr Zełenski w wirtualnym wystąpieniu przed Zgromadzeniem Ogólnym ONZ. Jak dodał, Ukraina wkrótce przedstawi w ONZ propozycję stworzenia specjalnego t


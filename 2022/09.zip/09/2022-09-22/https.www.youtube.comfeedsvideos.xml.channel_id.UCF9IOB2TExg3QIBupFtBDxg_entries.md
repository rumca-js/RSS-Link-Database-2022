# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Covid infections increasing again
 - [https://www.youtube.com/watch?v=QKQSKeGuDqU](https://www.youtube.com/watch?v=QKQSKeGuDqU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-09-23 00:00:00+00:00

Zoe Health study report, Live time data

https://health-study.joinzoe.com/

Incidence, = 152,071

(new symptomatic cases 0n 21st September)

Current prevalence, 1,829,701

(people currently predicted to have symptomatic covid in the UK)

R = 1.1

ONS

 https://www.ons.gov.uk/peoplepopulationandcommunity/healthandsocialcare/conditionsanddiseases/articles/coronaviruscovid19latestinsights/infections

W/E 5th September

Professor Spector report

https://www.youtube.com/watch?v=rQq91Z3ssqQ

Daily new cases of symptomatic COVID

Report and the data files download

https://console.cloud.google.com/storage/browser/covid-public-data

Average over the two weeks up to 20 September 2022.

Daily new cases of symptomatic COVID

UK = 148,830 

Based on the number of newly symptomatic app users per day, 
and the proportion of these who give positive swab tests. 

Check against NHS data

https://www.nhs.uk/conditions/coronavirus-covid-19/

https://coronavirus.data.gov.uk

Past 7 days

Testing positive, up 12.7%

Admitted to hospital, 4,015

(up 16.9%) 
Deaths, 289, (down 24.3%)

(within 28 days of a positive test)
Deaths, 

List of covid (mostly BA.5) symptoms

Sore throat, 68%

Headache, 55%

Cough, no phlegm 52%

Blocked nose, 51%

Runny nose, 51%

Cough with phlegm, 47%

Sneezing, 44%

Hoarse, 43%

Muscle pains / aches 31%

Fatigue, 24%

Dizzy, 21%

Swollen neck glands, 19%

Altered smell, 18%

Sore eyes, 16%

Shortness of breath, 15%

Chest pain / tightness, 15%

Chills or shivers, 14%

Loss of smell, 13%

Earache, 13%

Fever, 12%


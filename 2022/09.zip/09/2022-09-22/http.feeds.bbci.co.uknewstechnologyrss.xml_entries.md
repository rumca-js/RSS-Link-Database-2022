# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Rape posts every half-hour found on online incel forum
 - [https://www.bbc.co.uk/news/technology-62908601?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62908601?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-09-22 23:57:43+00:00

More must be done to tackle women-hating movement incel, the Centre for Countering Digital Hate warns.

## The firms making flour from mushrooms and cauliflower
 - [https://www.bbc.co.uk/news/business-62646817?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62646817?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-09-22 23:14:14+00:00

The search for wheat alternatives is being driven by a demand for healthier diets and food security.

## Australia phones cyber-attack exposes personal data
 - [https://www.bbc.co.uk/news/technology-62996101?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62996101?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-09-22 13:18:05+00:00

Optus is looking into the unauthorised access of data including names, addresses and passport numbers.

## Ted Lasso characters join Fifa 23
 - [https://www.bbc.co.uk/news/articles/cw84pj51p2no?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/cw84pj51p2no?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-09-22 09:23:01+00:00

The fictional AFC Richmond will be available in the the latest version of the popular football game.


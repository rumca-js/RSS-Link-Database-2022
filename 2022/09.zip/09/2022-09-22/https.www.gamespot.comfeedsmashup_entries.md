# Source:GameSpot, URL:https://www.gamespot.com/feeds/mashup, language:en-US

## Microsoft CEO Weighs In On Xbox/Activision Deal In Jeopardy
 - [https://www.gamespot.com/videos/microsoft-ceo-weighs-in-on-xbox-activision-deal-in-jeopardy/2300-6459622/](https://www.gamespot.com/videos/microsoft-ceo-weighs-in-on-xbox-activision-deal-in-jeopardy/2300-6459622/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 22:20:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1574/15746725/4039651-20220922_microsoftceoactivisionplaystation_newsv3.jpg" width="480" /> Microsoft's CEO hits back at PlayStation, PC specs for Modern Warfare 2, and new details on the next Splinter Cell.

## Slime Rancher 2 First 20 Minutes of Gameplay
 - [https://www.gamespot.com/videos/slime-rancher-2-first-20-minutes-of-gameplay/2300-6459623/](https://www.gamespot.com/videos/slime-rancher-2-first-20-minutes-of-gameplay/2300-6459623/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 22:12:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1574/15746725/4039653-slime_v0.jpg" width="480" /> Slime Rancher 2 continues the story of Beatrix LeBeau and the Far Far Range from the first game, only this time she'll be heading to a new area called Rainbow Island. Players will once again build the slime farm of their dreams while also discovering Rainbow Island's secrets.

## Why Does Shovel Knight Make So Many Cameos? "We Think It's Funny"
 - [https://www.gamespot.com/articles/why-does-shovel-knight-make-so-many-cameos-we-think-its-funny/1100-6507769/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/why-does-shovel-knight-make-so-many-cameos-we-think-its-funny/1100-6507769/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 22:06:00+00:00

<p dir="ltr">Shovel Knight, the character, made his debut in 2014 in a video game appropriately called Shovel Knight. The game was praised upon release and is remembered as a well-executed platformer inspired by NES classics. Since then, the game has received multiple DLC additions and Shovel Knight has appeared in spin-offs like Shovel Knight Pocket Dungeon and most recently, the roguelike platformer, <a href="https://www.gamespot.com/reviews/shovel-knight-dig-review-ace-of-spades/1900-6417965/

## Deathloop Goldenloop Update - Where To Find Everything New
 - [https://www.gamespot.com/articles/deathloop-goldenloop-update-where-to-find-everything-new/1100-6507768/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/deathloop-goldenloop-update-where-to-find-everything-new/1100-6507768/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 21:36:00+00:00

<p><a href="https://www.gamespot.com/games/deathloop/">Deathloop</a> has finally made its way to Xbox Series X|S and Xbox Game Pass and Arkane has released some new content on all the game's platforms to celebrate. The <a href="https://www.gamespot.com/articles/deathloop-is-coming-to-xbox-series-x-on-september-20-with-several-upgrades/1100-6507534/">Goldenloop Update</a> adds a new weapon, a new boss, a new Slab, and an extended ending. All of the new content is designed to make your journey thr

## Pierce Brosnan Doesn't Care Who The Next James Bond Is, But Wishes Him Well
 - [https://www.gamespot.com/articles/pierce-brosnan-doesnt-care-who-the-next-james-bond-is-but-wishes-him-well/1100-6507766/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/pierce-brosnan-doesnt-care-who-the-next-james-bond-is-but-wishes-him-well/1100-6507766/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 21:11:00+00:00

<p>While the search continues for the next actor to play James Bond, Pierce Brosnan--the fifth actor to play the British superspy--spoke with <a href="https://www.gq.com/story/the-brosnan-boys">GQ</a> about his indifference about who will step into the role after Daniel Craig.</p><p dir="ltr">"Who should do it? I don't care," Brosnan said. "It'll be interesting to see who they get, who the man shall be… whoever he be, I wish him well." Adds GQ writer Alex Pappademas, describing Brosnan's tone as

## New On Prime Video In October 2022: The Peripheral, Downton Abbey: A New Era
 - [https://www.gamespot.com/articles/new-on-prime-video-in-october-2022-the-peripheral-downton-abbey-a-new-era/1100-6507765/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/new-on-prime-video-in-october-2022-the-peripheral-downton-abbey-a-new-era/1100-6507765/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 21:10:00+00:00

<p dir="ltr">Prime Video is getting even bigger in October, with more new movies and TV shows to watch--including original content. October means Halloween, Hulu is of course getting lots of horror picks, although there is also some nice variety with other picks also deserving of your attention.</p><p dir="ltr"><a href="https://www.gamespot.com/articles/prime-videos-the-peripheral-from-westworlds-lisa-joy-and-jonathan-nolan-gets-first-trippy-trailer/1100-6507306/">The Peripheral</a>, an upcoming

## Get A 1TB Lifetime Cloud Storage Subscription For Just $112
 - [https://www.gamespot.com/articles/get-a-1tb-lifetime-cloud-storage-subscription-for-just-112/1100-6507755/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/get-a-1tb-lifetime-cloud-storage-subscription-for-just-112/1100-6507755/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 21:00:00+00:00

<p>Looking to free up some space on your hard drive? Consider picking up a lifetime subscription to <span class="norewrite">           <a href="https://deals.gamespot.com/sales/koofr-cloud-storage-plans-lifetime-subscription-1tb?utm_source=gamespot.com&amp;utm_medium=referral&amp;utm_campaign=koofr-cloud-storage-plans-lifetime-subscription-1tb_092322&amp;utm_term=scsf-555930&amp;utm_content=a0x1P000004yUSFQA2&amp;scsonar=1">Koofr Cloud Storage,</a> </span> which is currently offering its 1TB pla

## The Best Xbox Deals: Save On Game Pass, Consoles, Elite Controllers, And More
 - [https://www.gamespot.com/gallery/the-best-xbox-deals-save-on-game-pass-consoles-elite-controllers-and-more/2900-4344/](https://www.gamespot.com/gallery/the-best-xbox-deals-save-on-game-pass-consoles-elite-controllers-and-more/2900-4344/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 20:42:00+00:00

<p><img src="https://www.gamespot.com/a/uploads/scale_large/1702/17023653/4039420-fallout4%284%29.jpg" /><br /><h3><p>Xbox Series X|S are great consoles for gamers on a budget thanks to the excellent Xbox Game Pass Ultimate subscription program and frequent deals for many of its games, including recently released titles. If you're looking to add to your game library, there are a bunch of discounts on first-party exclusives and multi-platform blockbusters at major retailers. Some of these deals g

## John Carpenter Is Teasing Something Godzilla-Related
 - [https://www.gamespot.com/articles/john-carpenter-is-teasing-something-godzilla-related/1100-6507764/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/john-carpenter-is-teasing-something-godzilla-related/1100-6507764/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 20:34:00+00:00

<p dir="ltr">Horror movie legend John Carpenter took to Twitter via Fangoria to post a coy video of him sitting in a movie theater, as an off-screen projector plays an unseen film with an audible Godzilla scream and foot stomping--leading to widespread speculation that the director has a Godzilla project coming.</p><p dir="ltr">On the Twitter thread, Fangoria also tags Shout Factory, Scream Factory, and TokuSHOUTsu. The latter, notably, is the streaming home for many notable popular Japanese fil

## CoD: MW2 Beta Offers A Lukewarm Glimpse Of Its Multiplayer AI In Ground War Invasion
 - [https://www.gamespot.com/articles/cod-mw2-beta-offers-a-lukewarm-glimpse-of-its-multiplayer-ai-in-ground-war-invasion/1100-6507767/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/cod-mw2-beta-offers-a-lukewarm-glimpse-of-its-multiplayer-ai-in-ground-war-invasion/1100-6507767/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 20:15:00+00:00

<p dir="ltr">The second weekend of <a href="https://www.gamespot.com/games/call-of-duty-modern-warfare-ii/">Call of Duty: Modern Warfare 2’</a>s multiplayer beta is officially live, and this final test period brings PlayStation, Xbox, and PC players together to battle across the maps and modes from the first PlayStation-exclusive weekend, but it also includes the new addition of Ground War.</p><p dir="ltr">Weekend two of Modern Warfare 2's beta includes Team Deathmatch, Domination, Knockout, Pri

## The Diofield Chronicle Video Review
 - [https://www.gamespot.com/videos/the-diofield-chronicle-video-review/2300-6459620/](https://www.gamespot.com/videos/the-diofield-chronicle-video-review/2300-6459620/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 20:10:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1574/15746725/4039596-untitled.png" width="480" /> The Diofield Chronicle is a pedestrian real-time tactics game that suffers from a lack of imagination.

## Vince Gilligan's New Series Starring Rhea Seehorn Gets Two-Season Order At Apple TV Plus
 - [https://www.gamespot.com/articles/vince-gilligans-new-series-starring-rhea-seehorn-gets-two-season-order-at-apple-tv-plus/1100-6507763/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/vince-gilligans-new-series-starring-rhea-seehorn-gets-two-season-order-at-apple-tv-plus/1100-6507763/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 20:01:00+00:00

<p> </p><p dir="ltr">Vince Gilligan's next TV project has been scooped up by Apple TV+, which has given the Breaking Bad creator a two-season straight-to-series order. <a href="https://deadline.com/2022/09/vince-gilligan-next-series-rhea-seehorn-star-apple-tv-plus-two-season-order-1235124488/">Deadline</a> was the first to report.</p><p dir="ltr">The untitled project, a "blended, grounded genre drama" will reteam Gilligan with Better Call Saul's Rhea Seehorn, who will play the series lead. <a hr

## Look At This Custom Deathloop Xbox Series X Console
 - [https://www.gamespot.com/articles/look-at-this-custom-deathloop-xbox-series-x-console/1100-6507762/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/look-at-this-custom-deathloop-xbox-series-x-console/1100-6507762/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 18:49:00+00:00

<p>To promote the recent launch of Deathloop on Xbox, Microsoft created a custom Xbox Series X themed around the time loop game. The snazzy-looking console features characters and art from the game, with a matching controller that carries some of the same color accents and details.</p><p>The custom console isn't going on sale to the public, but fans can follow the Xbox account on Twitter and retweet the message for a chance to win. You can <a href="https://click.linksynergy.com/deeplink?id=VZfI2

## Call Of Duty: Modern Warfare 2 Beta Players Are Asking For Enemy Nameplates To Return
 - [https://www.gamespot.com/articles/call-of-duty-modern-warfare-2-beta-players-are-asking-for-enemy-nameplates-to-return/1100-6507760/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/call-of-duty-modern-warfare-2-beta-players-are-asking-for-enemy-nameplates-to-return/1100-6507760/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 17:56:00+00:00

<p><a href="https://www.gamespot.com/games/call-of-duty-modern-warfare-ii/">Call of Duty: Modern Warfare II's</a> beta is in full swing, and one of the hot topics players are discussing is the lack of nameplates above enemies, with many calling for the feature to return in the name of improving visibility.</p><p dir="ltr">In previous Call of Duty titles, enemy players would have their name displayed in red above their heads, making it clear they were not teammates but hostiles. That's not the ca

## David Tennant's Son Joins House Of The Dragon In Major Role After Time Jump
 - [https://www.gamespot.com/articles/david-tennants-son-joins-house-of-the-dragon-in-major-role-after-time-jump/1100-6507758/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/david-tennants-son-joins-house-of-the-dragon-in-major-role-after-time-jump/1100-6507758/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 17:56:00+00:00

<p>House of the Dragon's next episode will feature a 10-year time jump, and in addition to the roles of Alicent and Rhaenyra being recast, the baby Aegon II Targaryen is grown up. An actor who comes from a famous acting family will play the role, it's been revealed.</p><p>Ty Tennant--the son of Doctor Who star David Tennant and the grandson of another Doctor, Pete Davison--will play the teenage Aegon in House of the Dragon.</p><div>          </div><p>Tennant previously appeared in the movie Tolk

## How To Dive In Call Of Duty: Modern Warfare 2
 - [https://www.gamespot.com/articles/how-to-dive-in-call-of-duty-modern-warfare-2/1100-6507738/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/how-to-dive-in-call-of-duty-modern-warfare-2/1100-6507738/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 17:45:00+00:00

<p>Infinity Ward's <a href="https://www.gamespot.com/games/call-of-duty-modern-warfare-ii/">Call Of Duty: Modern Warfare II</a> is upon us, which means it's time to <strong>dolphin dive</strong>. The sequel to 2019's Modern Warfare reboot is out next month, October 28th, 2022, and weekend two of the multiplayer beta <a href="https://www.gamespot.com/articles/call-of-duty-modern-warfare-2-beta-dates-early-access-and-details/1100-6506542/">runs from September 22-26</a> for PlayStation, Xbox, and P

## How To Dolphin Dive In Call Of Duty: Modern Warfare 2
 - [https://www.gamespot.com/articles/how-to-dolphin-dive-in-call-of-duty-modern-warfare-2/1100-6507738/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/how-to-dolphin-dive-in-call-of-duty-modern-warfare-2/1100-6507738/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 17:45:00+00:00

<p>Infinity Ward's <a href="https://www.gamespot.com/games/call-of-duty-modern-warfare-ii/">Call Of Duty: Modern Warfare II</a> is upon us, which means it's time to <strong>dolphin dive</strong>. The sequel to 2019's Modern Warfare reboot is out next month, October 28th, 2022, and weekend two of the multiplayer beta <a href="https://www.gamespot.com/articles/call-of-duty-modern-warfare-2-beta-dates-early-access-and-details/1100-6506542/">runs from September 22-26</a> for PlayStation, Xbox, and P

## Turn Your Hunter Into A Lightning-Punch Machine In Destiny 2
 - [https://www.gamespot.com/articles/turn-your-hunter-into-a-lightning-punch-machine-in-destiny-2/1100-6507242/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/turn-your-hunter-into-a-lightning-punch-machine-in-destiny-2/1100-6507242/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 17:30:00+00:00

<p>Hunters are typically mobile fighters in Destiny 2, agile death-dealers who can strike fast and dance out of danger with a well-timed dodge. With Arc 3.0 in play, not much has changed on that front and these Guardians are now more nimble than ever on the battlefield.</p><p>For the player looking to try a more daring approach, there's a combination of skills and the right Exotic armor piece that'll transform your Hunter into a close-range fighter, capable of doing devastating amounts of damage

## Shovel Knight Dig Review - Ace Of Spades
 - [https://www.gamespot.com/reviews/shovel-knight-dig-review-ace-of-spades/1900-6417965/?ftag=CAD-01-10abi2f](https://www.gamespot.com/reviews/shovel-knight-dig-review-ace-of-spades/1900-6417965/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 17:07:00+00:00

<p dir="ltr">Shovel Knight Dig is very unlike the retro action game that catapulted the character into indie royalty. But in a strange way, it feels like a natural extension of that game's mechanics and concepts. If the original Shovel Knight evoked the feeling of a lost platformer from the NES era, Shovel Knight Dig feels like a disruptive follow-up that boldly charts new ground for the series, instead of hewing closely to the source material. This isn't actually Shovel Knight 2, but it could h

## AMC's Interview With The Vampire Review - A Dark Gift Beyond Our Wildest Dreams
 - [https://www.gamespot.com/reviews/amcs-interview-with-the-vampire-review-a-dark-gift-beyond-our-wildest-dreams/1900-6417964/?ftag=CAD-01-10abi2f](https://www.gamespot.com/reviews/amcs-interview-with-the-vampire-review-a-dark-gift-beyond-our-wildest-dreams/1900-6417964/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 17:01:00+00:00

<p> </p><p dir="ltr">The vampire genre is full of icons dating back hundreds of years. They come in all shapes and sizes, in virtually very context, from glittering YA protagonists to wretched shambling creatures. And while we're absolutely not here to pick favorites or measure the unquantifiable, it would be difficult to overstate just how important the work of Anne Rice is in this particular cultural phenomena. Anne Rice's vampires aren't the first, nor are they the last, to enter into the gen

## Diablo 2: Resurrected's Terror Zones Offer A Welcome New Endgame Option
 - [https://www.gamespot.com/articles/diablo-2-resurrecteds-terror-zones-offer-a-welcome-new-endgame-option/1100-6507734/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/diablo-2-resurrecteds-terror-zones-offer-a-welcome-new-endgame-option/1100-6507734/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 17:00:00+00:00

<p><a href="https://www.gamespot.com/games/diablo-ii/">Diablo II: Resurrected</a>'s first new gameplay feature arrives today with patch 2.5, and it's one that dramatically changes how players will approach the endgame grind of Blizzard's classic ARPG. It's a change the developers didn't introduce lightly.</p><p dir="ltr">When Diablo II: Resurrected first released, Blizzard was keen on keeping changes small. <a href="https://www.gamespot.com/articles/diablo-2-resurrecteds-accessibility-options-in

## NHL 23 Best Players And Ratings: Top 50 Players Overall
 - [https://www.gamespot.com/articles/nhl-23-best-players-and-ratings-top-50-players-overall/1100-6507725/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/nhl-23-best-players-and-ratings-top-50-players-overall/1100-6507725/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 17:00:00+00:00

<p>Break out the toe drags and double dekes; it's officially Ratings Week for <a href="https://www.gamespot.com/games/nhl-23/">NHL 23</a>. The team over at EA Vancouver has shared its picks for <a href="https://twitter.com/EASPORTSNHL/status/1571922139787235333">Fastest Wings</a>, <a href="https://twitter.com/EASPORTSNHL/status/1572592854706565123">Most Powerful Shots</a>, and the <a href="https://twitter.com/EASPORTSNHL/status/1572616776327774208">Best Under 23 Skaters</a>, and today's reveals 

## Apex Legends' Throwing Knife Isn't Here To Stay, But More LTMs Are On The Way
 - [https://www.gamespot.com/articles/apex-legends-throwing-knife-isnt-here-to-stay-but-more-ltms-are-on-the-way/1100-6507756/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/apex-legends-throwing-knife-isnt-here-to-stay-but-more-ltms-are-on-the-way/1100-6507756/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 16:51:00+00:00

<p dir="ltr"><a href="https://www.gamespot.com/games/apex-legends/">Apex Legends</a> developer Respawn Entertainment <a href="https://www.gamespot.com/articles/respawn-hosting-two-apex-legends-amas-ahead-of-beast-of-prey-event/1100-6507673/">recently hosted two Reddit AMAs</a> to answer questions from players regarding various aspects of the game. The <a href="https://www.reddit.com/r/apexlegends/comments/xjavf2/ama_lets_talk_ltms_and_gun_run/">first AMA</a> took place on Tuesday, shortly after 

## Get A 1TB Lifetime Cloud Storage Subscription For Just $140
 - [https://www.gamespot.com/articles/get-a-1tb-lifetime-cloud-storage-subscription-for-just-140/1100-6507755/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/get-a-1tb-lifetime-cloud-storage-subscription-for-just-140/1100-6507755/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 16:32:00+00:00

<p>Looking to free up some space on your hard drive? Consider picking up a lifetime subscription to <span class="norewrite">           <a href="https://deals.gamespot.com/sales/koofr-cloud-storage-plans-lifetime-subscription-1tb?utm_source=gamespot.com&amp;utm_medium=referral&amp;utm_campaign=koofr-cloud-storage-plans-lifetime-subscription-1tb_092322&amp;utm_term=scsf-555930&amp;utm_content=a0x1P000004yUSFQA2&amp;scsonar=1">Koofr Cloud Storage,</a> </span> which is currently offering its 1TB pla

## Tower Of Fantasy Vera 2.0 Story Trailer Teases New Enemies And Playable Characters
 - [https://www.gamespot.com/articles/tower-of-fantasy-vera-2-0-story-trailer-teases-new-enemies-and-playable-characters/1100-6507757/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/tower-of-fantasy-vera-2-0-story-trailer-teases-new-enemies-and-playable-characters/1100-6507757/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 16:32:00+00:00

<p><a href="https://www.gamespot.com/games/tower-of-fantasy/">Tower of Fantasy</a>, the free-to-play gacha MMORPG that released in August, is set to receive its first major expansion later this Fall. A new story trailer highlights some of the dangerous new enemy types players will face, as well as some of the new unlockable characters players can use to take them down.</p><p dir="ltr">The game's Vera 2.0 update will introduce the new Vera region, which is comprised of the barren Desert Gobby (no

## PS5 Restock: Multiple Retailers Have The PlayStation 5 In Stock
 - [https://www.gamespot.com/articles/ps5-restock-multiple-retailers-have-the-playstation-5-in-stock/1100-6498228/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/ps5-restock-multiple-retailers-have-the-playstation-5-in-stock/1100-6498228/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 16:27:00+00:00

<div class="norewrite" title="6475811 - PS5 Preorder Guide - Retailer Listings">    <div class="buylink__container">                                                                                                                                                                                               <div class="buylink__item">                  <div class="buylink__image-container clickable">                                            <img alt="" class="buylink__image" src="https://www.game

## PS5 Restock: PS5 Digital Bundles Are Available Now
 - [https://www.gamespot.com/articles/ps5-restock-ps5-digital-bundles-are-available-now/1100-6498228/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/ps5-restock-ps5-digital-bundles-are-available-now/1100-6498228/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 16:27:00+00:00

<div class="norewrite" title="6475811 - PS5 Preorder Guide - Retailer Listings">    <div class="buylink__container">                                                                                                                                                                                               <div class="buylink__item">                  <div class="buylink__image-container clickable">                                            <img alt="" class="buylink__image" src="https://www.game

## First Mario Movie Trailer Coming During New York Comic Con
 - [https://www.gamespot.com/articles/first-mario-movie-trailer-coming-during-new-york-comic-con/1100-6507754/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/first-mario-movie-trailer-coming-during-new-york-comic-con/1100-6507754/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 16:09:00+00:00

<p>The first trailer for the Super Mario movie starring Chris Pratt as Mario will be released on October 6 as part of New York Comic Con. The trailer will premiere that day at 1 PM PT / 4 PM ET.</p><p>This will be a "teaser" trailer for the animated film, so don't expect anything too lengthy. But in any event, it'll be the first footage from the film to debut. The movie was produced by Illumination, the studio behind Minions and Despicable Me.</p><p>The Mario movie is directed by Aaron Horvath a

## Mario + Rabbids Sparks Of Hope Understands The Importance Of Rewarding Strategic Movement
 - [https://www.gamespot.com/articles/mario-rabbids-sparks-of-hope-understands-the-importance-of-rewarding-strategic-movement/1100-6507688/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/mario-rabbids-sparks-of-hope-understands-the-importance-of-rewarding-strategic-movement/1100-6507688/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 16:00:00+00:00

<p>Though <a href="https://www.gamespot.com/games/mario-plus-rabbids-sparks-of-hope/">Mario + Rabbids Sparks of Hope</a> builds on the core idea of its predecessor, <a href="https://www.gamespot.com/games/mario-plus-rabbids-kingdom-battle/">Kingdom Battle</a>, its formula makes some big departures too. Most notably, Sparks of Hope outright transforms the flow of combat, dropping the grid-based movement and strict action economy of Kingdom Battle to incorporate a wider variety of meaningful choic

## Mario + Rabbids Sparks of Hope 20 Minutes of the Midnite Boss Battle
 - [https://www.gamespot.com/videos/mario-rabbids-sparks-of-hope-20-minutes-of-the-midnite-boss-battle/2300-6459614/](https://www.gamespot.com/videos/mario-rabbids-sparks-of-hope-20-minutes-of-the-midnite-boss-battle/2300-6459614/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 16:00:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1352/13527689/4039249-gameplay_mariorabbids_site.jpg" width="480" /> Check out a boss fight against Midnite in Mario + Rabbids Sparks of Hope.

## Mario + Rabbids Sparks of Hope Hands On Preview
 - [https://www.gamespot.com/videos/mario-rabbids-sparks-of-hope-hands-on-preview/2300-6459613/](https://www.gamespot.com/videos/mario-rabbids-sparks-of-hope-hands-on-preview/2300-6459613/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 16:00:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1352/13527689/4039247-preview_mariorabbids_site.jpg" width="480" /> We go hands on with Mario + Rabbids Sparks of Hope in this latest preview.

## Ed Sheeran Still Loves Playing Pokemon Silver On Game Boy, Releasing A New Pokemon Song Soon
 - [https://www.gamespot.com/articles/ed-sheeran-still-loves-playing-pokemon-silver-on-game-boy-releasing-a-new-pokemon-song-soon/1100-6507751/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/ed-sheeran-still-loves-playing-pokemon-silver-on-game-boy-releasing-a-new-pokemon-song-soon/1100-6507751/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 15:38:00+00:00

<p>Singer-songwriter Ed Sheeran is a huge fan of Pokemon, this much we already knew after he <a href="https://www.gamespot.com/articles/ed-sheeran-will-perform-inside-pokemon-go-next-week/1100-6498150/">spoke about his fandom and performed inside Pokemon Go last year.</a> Now he's going all-in, writing a new song inspired by Pokemon, with an animated music video coming from the creators of Pokemon. The song is called "Celestial" and it debuts Thursday, September 29.</p><p>Sheeran <a href="https:

## Jurassic World Studio Asked Bryce Dallas Howard To Lose Weight, Director Rejected The Request
 - [https://www.gamespot.com/articles/jurassic-world-studio-asked-bryce-dallas-howard-to-lose-weight-director-rejected-the-request/1100-6507753/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/jurassic-world-studio-asked-bryce-dallas-howard-to-lose-weight-director-rejected-the-request/1100-6507753/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 15:38:00+00:00

<p>Actor Bryce Dallas Howard recently had her third outing in the Jurassic World franchise this summer and it might have been the most tense of the trilogy. Talking to British lifestyle site <a href="https://metro.co.uk/2022/09/22/bryce-dallas-howard-on-fighting-pressure-to-lose-weight-in-hollywood-17428791/">Metro</a>, Howard revealed she was asked to lose weight before shooting Jurassic World Dominion.</p><p>Howard said that her weight has often been a topic of discussion among studio executiv

## This Week's Free Games At Epic Are Great And Available Now
 - [https://www.gamespot.com/articles/this-weeks-free-games-at-epic-are-great-and-available-now/1100-6476419/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/this-weeks-free-games-at-epic-are-great-and-available-now/1100-6476419/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 15:11:00+00:00

<p>The Epic Games Store continues to give away free games each week, more than three years after the digital storefront launched its awesome weekly freebies program. Epic has confirmed that the free games program will continue through at least the end of 2022. Every Thursday at the same time 8 AM PT / 11 AM ET--Epic gives up between one and three free games. You merely need to <a href="https://www.epicgames.com/id/register">create a free Epic account</a> and enable two-factor authentication to s

## Today's Wordle Answer (#460) - September 22, 2022
 - [https://www.gamespot.com/articles/todays-wordle-answer-460-september-22-2022/1100-6507739/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/todays-wordle-answer-460-september-22-2022/1100-6507739/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 14:40:00+00:00

<p>Who doesn't enjoy a little Thursday <a href="https://www.gamespot.com/games/wordle/">Wordle</a> action every now and again? We're back with another edition of our Wordle guides, this time on September 22. After a series of difficult answers over the past couple of weeks, the Wordle gods have blessed players with a fairly easy word. This is great news for players who might not want too hard of a challenge with their morning coffee (or whenever players do the Wordle), but disheartening for thos

## NASA To Test If Movies About Diverting Deadly Asteroids Headed For Earth Were Bullshit
 - [https://www.gamespot.com/articles/nasa-to-test-if-movies-about-diverting-deadly-asteroids-headed-for-earth-were-bullshit/1100-6507750/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/nasa-to-test-if-movies-about-diverting-deadly-asteroids-headed-for-earth-were-bullshit/1100-6507750/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 14:31:00+00:00

<p>NASA's next planetary defense test mission is underway, with the space agency attempting to test whether or not it would be able to change the motion of an asteroid so it doesn't crash into Earth and kill us all. In other words, NASA is putting to test the theories put forth in the disaster movies Armageddon and Deep Impact.</p><p>The Double Asteroid Redirection Test (DART) program is part of NASA's Planetary Defense Coordination Office, and it will test if a "kinetic impact" can "slightly ch

## Microsoft CEO Confident Activision Blizzard Deal Will Happen, Says PlayStation Is Bigger Than Xbox
 - [https://www.gamespot.com/articles/microsoft-ceo-confident-activision-blizzard-deal-will-happen-says-playstation-is-bigger-than-xbox/1100-6507749/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/microsoft-ceo-confident-activision-blizzard-deal-will-happen-says-playstation-is-bigger-than-xbox/1100-6507749/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 14:27:00+00:00

<p>Microsoft CEO Satya Nadella is confident that the company's proposed $68.7 billion acquisition of Activision Blizzard will be approved by regulators. Speaking to <a href="https://www.bloomberg.com/news/articles/2022-09-22/microsoft-ceo-is-confident-about-activision-deal-approval-handling-of-economy?srnd=technology-vp">Bloomberg</a>, Nadella said it's understandable that an acquisition of this size--the biggest ever for Microsoft and one of the largest in history across the technology space--w

## Don't Expect GPU Prices To Go Down, Nvidia Boss Says
 - [https://www.gamespot.com/articles/dont-expect-gpu-prices-to-go-down-nvidia-boss-says/1100-6507748/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/dont-expect-gpu-prices-to-go-down-nvidia-boss-says/1100-6507748/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 14:12:00+00:00

<p>Nvidia graphics cards have been a serious investment for PC gamers, and with the reveal of the <a href="https://www.gamespot.com/articles/nvidia-reveals-rtx-4090-and-4080-gpus-prices-start-at-900/1100-6507676/">new (and expensive) RTX 40-series GPUs</a>, don't expect prices to come down for the latest gaming hardware.</p><p>Speaking to <a href="https://www.digitaltrends.com/computing/nvidia-says-falling-gpu-prices-are-over/">Digital Trends</a>, Nvidia CEO Jensen Huang was asked about the pric

## Project Winter - 2.5 Million Community Celebration/Update Trailer
 - [https://www.gamespot.com/videos/project-winter-2-5-million-community-celebration-update-trailer/2300-6459583/](https://www.gamespot.com/videos/project-winter-2-5-million-community-celebration-update-trailer/2300-6459583/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 14:00:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1574/15746725/4037699-untitled%284%29.png" width="480" /> A giant THANK YOU FOR 2.5M PLAYERS across all platforms to Other Ocean’s wonderful community!

## Project Winter Gets Big Content Update, Price Permanently Lowered
 - [https://www.gamespot.com/articles/project-winter-gets-big-content-update-price-permanently-lowered/1100-6507722/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/project-winter-gets-big-content-update-price-permanently-lowered/1100-6507722/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 14:00:00+00:00

<p>Project Winter gives players a great way to never trust their friends again, placing traitors among a group of survivors who just want to, well, survive.</p><p>Starting today, traitors will have even more tools at their disposal to make survivors' lives hell, and the game is getting a new low price to celebrate.</p><p dir="ltr">The free update, which comes as Project Winter passes 2.5 million players, includes four traitor items:</p><a href="https://www.gamespot.com/articles/project-winter-ge

## Project Winter Gets Content Update With Graphics Overhaul, Price Permanently Lowered
 - [https://www.gamespot.com/articles/project-winter-gets-content-update-with-graphics-overhaul-price-permanently-lowered/1100-6507722/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/project-winter-gets-content-update-with-graphics-overhaul-price-permanently-lowered/1100-6507722/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 14:00:00+00:00

<p>Project Winter gives players a great way to never trust their friends again, placing traitors among a group of survivors who just want to, well, survive.</p><p>Starting today, traitors will have even more tools at their disposal to make survivors' lives hell, and the game is getting a new low price to celebrate.</p><p dir="ltr">The free update, which comes as Project Winter passes 2.5 million players, includes four traitor items:</p><a href="https://www.gamespot.com/articles/project-winter-ge

## The Walking Dead Final Season Episodes 17 And 18 Review — Strolling Into Oblivion
 - [https://www.gamespot.com/reviews/the-walking-dead-final-season-episodes-17-and-18-review-strolling-into-oblivion/1900-6417962/?ftag=CAD-01-10abi2f](https://www.gamespot.com/reviews/the-walking-dead-final-season-episodes-17-and-18-review-strolling-into-oblivion/1900-6417962/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 14:00:00+00:00

<p dir="ltr">Through two-thirds of its elongated final season, The Walking Dead hasn't really felt like it's coming to a close. Sure, the surviving heroes have once again been facing down extinction at the hands of a seemingly insurmountable threat, but the feud between them and the Commonwealth hasn't felt any more dramatic than past conflicts with the Saviors, the Whisperers, the Governor, and so on. Now with just eight episodes to go, I've been eager to get to the part of the season that illu

## What You Need To Know - Modern Warfare 2 Multiplayer
 - [https://www.gamespot.com/videos/what-you-need-to-know-modern-warfare-2-multiplayer/2300-6459612/](https://www.gamespot.com/videos/what-you-need-to-know-modern-warfare-2-multiplayer/2300-6459612/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 14:00:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1352/13527689/4039246-cod_v7.jpg" width="480" /> Modern Warfare II has made big changes to guns, movement, throwables, and perks. Let’s give you the knowledge to slay in the open beta.

## CoD: MW2 PC Beta Minimum/Recommended Specs And Other Options Detailed
 - [https://www.gamespot.com/articles/cod-mw2-pc-beta-minimum-recommended-specs-and-other-options-detailed/1100-6507747/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/cod-mw2-pc-beta-minimum-recommended-specs-and-other-options-detailed/1100-6507747/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 13:21:00+00:00

<p>The <a href="https://www.gamespot.com/games/call-of-duty-modern-warfare-ii/">Call of Duty: Modern Warfare II</a> multiplayer comes to PC today for people who preorder, and Activision has provided a rundown of the minimum and recommended specs and additional general PC settings and options.</p><p>The minimum specs for the beta call for 8 GB of RAM, an Intel Core i5-3570 or AMD Ryzen 5 1600X CPU, along with a Nvidia GeForce GTX 960 or AMD Radeon RX 470 card. The recommended specs, meanwhile, ca

## Splinter Cell Remake Will Feature A Rewritten Story For "Modern-Day" Audiences
 - [https://www.gamespot.com/articles/splinter-cell-remake-will-feature-a-rewritten-story-for-modern-day-audiences/1100-6507746/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/splinter-cell-remake-will-feature-a-rewritten-story-for-modern-day-audiences/1100-6507746/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 13:21:00+00:00

<p>The upcoming Splinter Cell remake will feature a rewritten story, as Ubisoft is looking to update the game and make it more relevant to a "modern-day audience."</p><p>In a job listing that was spotted by <a href="https://www.psu.com/news/splinter-cell-remake-job-listing-reveals-story-is-being-rewritten-for-modern-audiences/">PSU</a>, Ubisoft is looking to hire a scriptwriter who can faithfully update the original game's story. "Using the first Splinter Cell game as our foundation we are rewri

## Avatar's Re-Release Includes New Footage Of The Way Of Water
 - [https://www.gamespot.com/articles/avatars-re-release-includes-new-footage-of-the-way-of-water/1100-6507745/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/avatars-re-release-includes-new-footage-of-the-way-of-water/1100-6507745/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 12:41:00+00:00

<p>The long-awaited sequel to James Cameron's Avatar is coming in December, but ahead of that, the original movie is back in theaters for a special remastered re-release. The re-release opens in the US on September 23, but it debuted in some international markets already. People have reported that the film includes a special look at new scenes from The Way of Water.</p><p>Avatar's remastered re-release is out now in France and Korea, and people there reported on social media that the movie ends 

## M. Night Shyamalan's Next Movie Gets Spooky First Trailer Where Family Must Make An "Unthinkable Choice"
 - [https://www.gamespot.com/articles/m-night-shyamalans-next-movie-gets-spooky-first-trailer-where-family-must-make-an-unthinkable-choice/1100-6507744/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/m-night-shyamalans-next-movie-gets-spooky-first-trailer-where-family-must-make-an-unthinkable-choice/1100-6507744/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 12:06:00+00:00

<p>The first trailer for M. Night Shyamalan's next film has arrived, and it is suitably spooky. The movie, Knock at the Cabin, follows the story of a young girl and her parents who, when on vacation at an idyllic remote cabin the woods, are contacted by four armed strangers who call upon the family to "make an unthinkable choice" to save the world.</p><p>"With limited access to the outside world, the family must decide what they believe before all is lost," reads a line from the film's descripti

## Logitech G Pro Racing Wheel Comes With Cool Accessibility Features
 - [https://www.gamespot.com/articles/logitech-g-pro-racing-wheel-comes-with-cool-accessibility-features/1100-6507741/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/logitech-g-pro-racing-wheel-comes-with-cool-accessibility-features/1100-6507741/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 12:03:00+00:00

<p>Logitech unveiled a new steering wheel during its livestream event, a piece of kit aimed at serious racing game fans and packing some impressive specs. A small LED display, force feedback, and low-latency response are all great features to have in an enthusiast kit, but it's the modular design that makes the steering wheel not only that much more customizable but also more accessible to people with disabilities.</p><p>The G Pro foot pedals that are sold separately are equipped with a load cel

## Overwatch 2 DPS Heroes Are Getting A Speed Boost At Launch
 - [https://www.gamespot.com/articles/overwatch-2-dps-heroes-are-getting-a-speed-boost-at-launch/1100-6507740/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/overwatch-2-dps-heroes-are-getting-a-speed-boost-at-launch/1100-6507740/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-09-22 12:02:00+00:00

<p>Ahead of the Overwatch 2 launch next month, Blizzard has posted a preview of changes that players can expect. One of the big tweaks, when compared to the previous betas, is a new passive ability for each class of hero, with DPS role characters getting an increase in speed.</p><p>In the betas, DPS heroes retained 30% of their ultimate power when they were swapped out for another character, and this buff will also be applied to Tank and Support heroes. To give DPS characters a more clearly defi


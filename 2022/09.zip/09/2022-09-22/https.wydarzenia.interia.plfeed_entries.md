# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Żaryn o zdjęciu Dudy i Ławrowa: Tak wykorzystuje się kłamstwo
 - [https://wydarzenia.interia.pl/kraj/news-zaryn-o-zdjeciu-dudy-i-lawrowa-tak-wykorzystuje-sie-klamstwo,nId,6302190](https://wydarzenia.interia.pl/kraj/news-zaryn-o-zdjeciu-dudy-i-lawrowa-tak-wykorzystuje-sie-klamstwo,nId,6302190)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 21:55:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zaryn-o-zdjeciu-dudy-i-lawrowa-tak-wykorzystuje-sie-klamstwo,nId,6302190"><img align="left" alt="Żaryn o zdjęciu Dudy i Ławrowa: Tak wykorzystuje się kłamstwo " src="https://i.iplsc.com/zaryn-o-zdjeciu-dudy-i-lawrowa-tak-wykorzystuje-sie-klamstwo/000FM716GB72PFYK-C321.jpg" /></a>W czwartek w internecie pojawiło się zdjęcie, na którym widać jak prezydent Andrzej Duda podaje rękę ministrowi spraw zagranicznych Federacji Rosyjskiej Siergiejowi Ław

## Gdzie w Polsce jest najwięcej grzybów? Sprawdźcie to na mapie
 - [https://wydarzenia.interia.pl/kraj/news-gdzie-w-polsce-jest-najwiecej-grzybow-sprawdzcie-to-na-mapie,nId,6302171](https://wydarzenia.interia.pl/kraj/news-gdzie-w-polsce-jest-najwiecej-grzybow-sprawdzcie-to-na-mapie,nId,6302171)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 20:15:08+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-gdzie-w-polsce-jest-najwiecej-grzybow-sprawdzcie-to-na-mapie,nId,6302171"><img align="left" alt="Gdzie w Polsce jest najwięcej grzybów? Sprawdźcie to na mapie" src="https://i.iplsc.com/gdzie-w-polsce-jest-najwiecej-grzybow-sprawdzcie-to-na-mapie/000G3TMJRLQWEA63-C321.jpg" /></a>Fanów grzybobrania z pewnością w Polsce nie brakuje - trwający sezon jest jednak silnie zróżnicowany na terenie kraju, a co za tym idzie nie wszyscy wrócą z lasów w swoj

## Nie żyje 12-latka. Została ranna w wypadku
 - [https://wydarzenia.interia.pl/swietokrzyskie/news-nie-zyje-12-latka-zostala-ranna-w-wypadku,nId,6302170](https://wydarzenia.interia.pl/swietokrzyskie/news-nie-zyje-12-latka-zostala-ranna-w-wypadku,nId,6302170)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 20:07:29+00:00

<p><a href="https://wydarzenia.interia.pl/swietokrzyskie/news-nie-zyje-12-latka-zostala-ranna-w-wypadku,nId,6302170"><img align="left" alt="Nie żyje 12-latka. Została ranna w wypadku" src="https://i.iplsc.com/nie-zyje-12-latka-zostala-ranna-w-wypadku/000G3TMKXMCWIUQ5-C321.jpg" /></a>W nocy ze środy na czwartek zmarła 12-letnia Maja, która po wypadku trafiła nieprzytomna do szpitala. Do zdarzenia doszło 1 września w Wojciechowicach (woj. świętokrzyskie). Jak informowała policja, 50-latek kierując

## Iran. Protesty rosną w siłę. Władze blokują dostęp do internetu
 - [https://wydarzenia.interia.pl/zagranica/news-iran-protesty-rosna-w-sile-wladze-blokuja-dostep-do-internet,nId,6302159](https://wydarzenia.interia.pl/zagranica/news-iran-protesty-rosna-w-sile-wladze-blokuja-dostep-do-internet,nId,6302159)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 19:29:23+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-iran-protesty-rosna-w-sile-wladze-blokuja-dostep-do-internet,nId,6302159"><img align="left" alt="Iran. Protesty rosną w siłę. Władze blokują dostęp do internetu " src="https://i.iplsc.com/iran-protesty-rosna-w-sile-wladze-blokuja-dostep-do-internet/000G3TE2V66EH7K8-C321.jpg" /></a>Protesty w Iranie po śmierci 22-letniej Mahsy Amini przybierają na sile. Kobiety ściągają swoje hidżaby i palą je na ulicach. Media społecznościowe zalała fala n

## Edward Mosberg nie żyje. Andrzej Duda przerwał obowiązki
 - [https://wydarzenia.interia.pl/zagranica/news-edward-mosberg-nie-zyje-andrzej-duda-przerwal-obowiazki,nId,6302158](https://wydarzenia.interia.pl/zagranica/news-edward-mosberg-nie-zyje-andrzej-duda-przerwal-obowiazki,nId,6302158)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 19:25:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-edward-mosberg-nie-zyje-andrzej-duda-przerwal-obowiazki,nId,6302158"><img align="left" alt="Edward Mosberg nie żyje. Andrzej Duda przerwał obowiązki" src="https://i.iplsc.com/edward-mosberg-nie-zyje-andrzej-duda-przerwal-obowiazki/000G3TDTHC99JY74-C321.jpg" /></a>Prezydent Andrzej Duda przerwał program pobytu w Nowym Yorku na sesji Zgromadzenia Ogólnego ONZ, by uczestniczyć w pogrzebie Edwarda Mosberga - przekazał w czwartek szef prezydenc

## Tragedia w USA. Ciężarówka spadła z wiaduktu i stanęła w ogniu
 - [https://wydarzenia.interia.pl/zagranica/news-tragedia-w-usa-ciezarowka-spadla-z-wiaduktu-i-stanela-w-ogni,nId,6302117](https://wydarzenia.interia.pl/zagranica/news-tragedia-w-usa-ciezarowka-spadla-z-wiaduktu-i-stanela-w-ogni,nId,6302117)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 18:56:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tragedia-w-usa-ciezarowka-spadla-z-wiaduktu-i-stanela-w-ogni,nId,6302117"><img align="left" alt="Tragedia w USA. Ciężarówka spadła z wiaduktu i stanęła w ogniu" src="https://i.iplsc.com/tragedia-w-usa-ciezarowka-spadla-z-wiaduktu-i-stanela-w-ogni/000G3T7V741PII0H-C321.jpg" /></a>Do tragicznego wypadku doszło we wtorek w Teksasie w Stanach Zjednoczonych. Ciężarówka spadła z wiaduktu na drogę i stanęła w płomieniach. Kierujący pojazdem zginą

## Żona Dżamala Chaszodżdżiego idzie do sądu. Na celowniku izraelska firma
 - [https://wydarzenia.interia.pl/zagranica/news-zona-dzamala-chaszodzdziego-idzie-do-sadu-na-celowniku-izrae,nId,6302132](https://wydarzenia.interia.pl/zagranica/news-zona-dzamala-chaszodzdziego-idzie-do-sadu-na-celowniku-izrae,nId,6302132)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 18:56:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zona-dzamala-chaszodzdziego-idzie-do-sadu-na-celowniku-izrae,nId,6302132"><img align="left" alt="Żona Dżamala Chaszodżdżiego idzie do sądu. Na celowniku izraelska firma" src="https://i.iplsc.com/zona-dzamala-chaszodzdziego-idzie-do-sadu-na-celowniku-izrae/0007O4N5BJQ7OXL8-C321.jpg" /></a>Hanan Elatr żona brutalnie zamordowanego w 2018 roku dziennikarza Dżamala Chaszodżdżiego o planuje pozwać producenta oprogramowania szpiegowskiego NSO Gro

## "Brutalnie torturowani". Ukraiński wywiad o stanie jeńców
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-brutalnie-torturowani-ukrainski-wywiad-o-stanie-jencow,nId,6302118](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-brutalnie-torturowani-ukrainski-wywiad-o-stanie-jencow,nId,6302118)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 18:29:29+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-brutalnie-torturowani-ukrainski-wywiad-o-stanie-jencow,nId,6302118"><img align="left" alt="&quot;Brutalnie torturowani&quot;. Ukraiński wywiad o stanie jeńców" src="https://i.iplsc.com/brutalnie-torturowani-ukrainski-wywiad-o-stanie-jencow/000G3T4XUQ5GUX62-C321.jpg" /></a>Część jeńców, którzy zostali wyzwoleni z rosyjskiej niewoli, była brutalnie teorturowana - informuje szef ukraińskiego wywiadu wojskowego (

## Morderstwo w Bielsku-Białej. Nieoficjalnie: Córka zabiła matkę
 - [https://wydarzenia.interia.pl/slaskie/news-morderstwo-w-bielsku-bialej-nieoficjalnie-corka-zabila-matke,nId,6302113](https://wydarzenia.interia.pl/slaskie/news-morderstwo-w-bielsku-bialej-nieoficjalnie-corka-zabila-matke,nId,6302113)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 18:16:37+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-morderstwo-w-bielsku-bialej-nieoficjalnie-corka-zabila-matke,nId,6302113"><img align="left" alt="Morderstwo w Bielsku-Białej. Nieoficjalnie: Córka zabiła matkę" src="https://i.iplsc.com/morderstwo-w-bielsku-bialej-nieoficjalnie-corka-zabila-matke/000G3T3Q4U2QH9R7-C321.jpg" /></a>Nieprzytomna kobieta znaleziona w mieszkaniu w Bielsku-Białej - takie zgłoszenie otrzymały służby ratunkowe. Gdy ratownicy przybyli na miejsce okazało się, że poszko

## "Nie" dla mężczyzn jedzących mięso. PETA wzywa do strajku seksualnego
 - [https://wydarzenia.interia.pl/zagranica/news-nie-dla-mezczyzn-jedzacych-mieso-peta-wzywa-do-strajku-seksu,nId,6302073](https://wydarzenia.interia.pl/zagranica/news-nie-dla-mezczyzn-jedzacych-mieso-peta-wzywa-do-strajku-seksu,nId,6302073)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 17:36:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nie-dla-mezczyzn-jedzacych-mieso-peta-wzywa-do-strajku-seksu,nId,6302073"><img align="left" alt="&quot;Nie&quot; dla mężczyzn jedzących mięso. PETA wzywa do strajku seksualnego" src="https://i.iplsc.com/nie-dla-mezczyzn-jedzacych-mieso-peta-wzywa-do-strajku-seksu/000G3ST04V2PF2WG-C321.jpg" /></a>Międzynarodowa organizacja PETA wzywa do strajku seksualnego przeciwko mężczyznom, którzy jedzą mięso. Jak twierdzi organizacja zajmująca się praw

## Były minister zdrowia Niemiec krytykuje sam siebie za działania w pandemii
 - [https://wydarzenia.interia.pl/zagranica/news-byly-minister-zdrowia-niemiec-krytykuje-sam-siebie-za-dziala,nId,6302068](https://wydarzenia.interia.pl/zagranica/news-byly-minister-zdrowia-niemiec-krytykuje-sam-siebie-za-dziala,nId,6302068)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 17:22:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-byly-minister-zdrowia-niemiec-krytykuje-sam-siebie-za-dziala,nId,6302068"><img align="left" alt="Były minister zdrowia Niemiec krytykuje sam siebie za działania w pandemii" src="https://i.iplsc.com/byly-minister-zdrowia-niemiec-krytykuje-sam-siebie-za-dziala/000DRD1LY2F1T1OE-C321.jpg" /></a>Nie tak powinny wyglądać wszystkie działania niemieckiego rządu podczas pandemii - przyznał były minister zdrowia Jens Spahn, który w czasie kryzysu zw

## Czy pozwalać Rosjanom uciec od wojny? Mieli na to pół roku
 - [https://wydarzenia.interia.pl/zagranica/news-czy-pozwalac-rosjanom-uciec-od-wojny-mieli-na-to-pol-roku,nId,6301699](https://wydarzenia.interia.pl/zagranica/news-czy-pozwalac-rosjanom-uciec-od-wojny-mieli-na-to-pol-roku,nId,6301699)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 17:09:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czy-pozwalac-rosjanom-uciec-od-wojny-mieli-na-to-pol-roku,nId,6301699"><img align="left" alt="Czy pozwalać Rosjanom uciec od wojny? Mieli na to pół roku" src="https://i.iplsc.com/czy-pozwalac-rosjanom-uciec-od-wojny-mieli-na-to-pol-roku/000G3PUTAYXT9WTD-C321.jpg" /></a>Setki aresztowanych, protesty w kilkudziesięciu miastach, tłumy na granicach, horrendalnie drogie ceny biletów. Tak wielu Rosjan, zwłaszcza młodych, odpowiada na częściową m

## Kuriozalne słowa Ławrowa. Oskarżył Ukraińców i wyszedł z sali
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kuriozalne-slowa-lawrowa-oskarzyl-ukraincow-i-wyszedl-z-sali,nId,6302070](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kuriozalne-slowa-lawrowa-oskarzyl-ukraincow-i-wyszedl-z-sali,nId,6302070)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 16:56:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kuriozalne-slowa-lawrowa-oskarzyl-ukraincow-i-wyszedl-z-sali,nId,6302070"><img align="left" alt="Kuriozalne słowa Ławrowa. Oskarżył Ukraińców i wyszedł z sali" src="https://i.iplsc.com/kuriozalne-slowa-lawrowa-oskarzyl-ukraincow-i-wyszedl-z-sali/000G0QJB40PLWPWE-C321.jpg" /></a>- Mamy wiele dowodów na przestępcze działania Ukrainy - mówił w czasie Rady Bezpieczeństwa ONZ minister spraw zagranicznych Rosji Sie

## Zaskakujące badania. Płody "płaczą" gdy matka je jarmuż
 - [https://wydarzenia.interia.pl/zagranica/news-zaskakujace-badania-plody-placza-gdy-matka-je-jarmuz,nId,6302064](https://wydarzenia.interia.pl/zagranica/news-zaskakujace-badania-plody-placza-gdy-matka-je-jarmuz,nId,6302064)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 16:47:36+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zaskakujace-badania-plody-placza-gdy-matka-je-jarmuz,nId,6302064"><img align="left" alt="Zaskakujące badania. Płody &quot;płaczą&quot; gdy matka je jarmuż" src="https://i.iplsc.com/zaskakujace-badania-plody-placza-gdy-matka-je-jarmuz/000G3SSPVWXY05O1-C321.jpg" /></a>Smak jarmużu wywołuje na twarzach nienarodzonych dzieci grymas podobny do płaczu - wynika z badań naukowców z University of Durham w Wielkiej Brytanii. Płody dwukrotnie częście

## Premie i nagrody w Kancelarii Senatu. Tomasz Grodzki reaguje na wyrok sądu
 - [https://wydarzenia.interia.pl/kraj/news-premie-i-nagrody-w-kancelarii-senatu-tomasz-grodzki-reaguje-,nId,6301888](https://wydarzenia.interia.pl/kraj/news-premie-i-nagrody-w-kancelarii-senatu-tomasz-grodzki-reaguje-,nId,6301888)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 16:40:09+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premie-i-nagrody-w-kancelarii-senatu-tomasz-grodzki-reaguje-,nId,6301888"><img align="left" alt="Premie i nagrody w Kancelarii Senatu. Tomasz Grodzki reaguje na wyrok sądu" src="https://i.iplsc.com/premie-i-nagrody-w-kancelarii-senatu-tomasz-grodzki-reaguje/000FDNPCFIB2DQJH-C321.jpg" /></a>Marszałek Senatu Tomasz Grodzki odniósł się do publikacji Interii, która od miesięcy domaga się ujawnienia nagród, dodatków senackich oraz premii wypłacanych

## Prezydent Iranu odmówił wywiadu. Dziennikarka CNN oburzona
 - [https://wydarzenia.interia.pl/zagranica/news-prezydent-iranu-odmowil-wywiadu-dziennikarka-cnn-oburzona,nId,6301886](https://wydarzenia.interia.pl/zagranica/news-prezydent-iranu-odmowil-wywiadu-dziennikarka-cnn-oburzona,nId,6301886)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 15:46:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prezydent-iranu-odmowil-wywiadu-dziennikarka-cnn-oburzona,nId,6301886"><img align="left" alt="Prezydent Iranu odmówił wywiadu. Dziennikarka CNN oburzona" src="https://i.iplsc.com/prezydent-iranu-odmowil-wywiadu-dziennikarka-cnn-oburzona/000G3SDOLNHFPCL0-C321.jpg" /></a>Prezydent Iranu Ebrahim Ra’isi odmówił udzielenia wywiadu dziennikarce CNN Christiane Amanpour, ponieważ ta odmówiła założenia chusty na głowę. &quot;Jesteśmy w Nowym Jorku,

## Amerykański generał bez ogródek. Porównał Putina do Hitlera
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanski-general-bez-ogrodek-porownal-putina-do-hitlera,nId,6301884](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanski-general-bez-ogrodek-porownal-putina-do-hitlera,nId,6301884)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 15:43:17+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanski-general-bez-ogrodek-porownal-putina-do-hitlera,nId,6301884"><img align="left" alt="Amerykański generał bez ogródek. Porównał Putina do Hitlera" src="https://i.iplsc.com/amerykanski-general-bez-ogrodek-porownal-putina-do-hitlera/000G1BJEBPN6TQ6P-C321.jpg" /></a>Mocne słowa byłego dowódcy wojsk amerykańskich w Europie. W wywiadzie dla niemieckiego dziennika &quot;Bild&quot; gen. Ben Hodges porównał 

## Referenda na okupowanych terytoriach Ukrainy. Media pokazały biuletyny
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-referenda-na-okupowanych-terytoriach-ukrainy-media-pokazaly-,nId,6301842](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-referenda-na-okupowanych-terytoriach-ukrainy-media-pokazaly-,nId,6301842)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 15:17:55+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-referenda-na-okupowanych-terytoriach-ukrainy-media-pokazaly-,nId,6301842"><img align="left" alt="Referenda na okupowanych terytoriach Ukrainy. Media pokazały biuletyny" src="https://i.iplsc.com/referenda-na-okupowanych-terytoriach-ukrainy-media-pokazaly/000G3S4KXD13CF5E-C321.jpg" /></a>Niezależny portal Meduza opublikował w czwartek zdjęcia przedstawiające biuletyny, które mają być wykorzystywane podczas tzw.

## Sondaż wyborczy: Rośnie poparcie dla Zjednoczonej Prawicy. Kłopoty Hołowni
 - [https://wydarzenia.interia.pl/kraj/news-sondaz-wyborczy-rosnie-poparcie-dla-zjednoczonej-prawicy-klo,nId,6301835](https://wydarzenia.interia.pl/kraj/news-sondaz-wyborczy-rosnie-poparcie-dla-zjednoczonej-prawicy-klo,nId,6301835)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 14:50:44+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sondaz-wyborczy-rosnie-poparcie-dla-zjednoczonej-prawicy-klo,nId,6301835"><img align="left" alt="Sondaż wyborczy: Rośnie poparcie dla Zjednoczonej Prawicy. Kłopoty Hołowni" src="https://i.iplsc.com/sondaz-wyborczy-rosnie-poparcie-dla-zjednoczonej-prawicy-klo/000G3S2WJ3UX8D5M-C321.jpg" /></a>Rośnie poparcie dla Zjednoczonej Prawicy - wynika z najnowszego badania przeprowadzonego przez pracownię Research Partner. Na obóz rządzący głos chce oddać 

## Wypadek pod Hrubieszowem. Ciągnik przygniótł rolnika
 - [https://wydarzenia.interia.pl/lubelskie/news-wypadek-pod-hrubieszowem-ciagnik-przygniotl-rolnika,nId,6301834](https://wydarzenia.interia.pl/lubelskie/news-wypadek-pod-hrubieszowem-ciagnik-przygniotl-rolnika,nId,6301834)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 14:36:01+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-wypadek-pod-hrubieszowem-ciagnik-przygniotl-rolnika,nId,6301834"><img align="left" alt="Wypadek pod Hrubieszowem. Ciągnik przygniótł rolnika" src="https://i.iplsc.com/wypadek-pod-hrubieszowem-ciagnik-przygniotl-rolnika/000G3S0BRKJ2N5QB-C321.jpg" /></a>48-latek został przygnieciony przez ciągnik w miejscowości Matcze (woj. lubelskie) i trafił do szpitala. Wstępne ustalenia policji wskazują, że w trakcie jazdy od pojazdu odpiął się wózek, mę

## Ile można zarobić na kasie w Biedronce i innych sklepach? Znamy kwoty
 - [https://wydarzenia.interia.pl/kraj/news-ile-mozna-zarobic-na-kasie-w-biedronce-i-innych-sklepach-zna,nId,6301625](https://wydarzenia.interia.pl/kraj/news-ile-mozna-zarobic-na-kasie-w-biedronce-i-innych-sklepach-zna,nId,6301625)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 14:03:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ile-mozna-zarobic-na-kasie-w-biedronce-i-innych-sklepach-zna,nId,6301625"><img align="left" alt="Ile można zarobić na kasie w Biedronce i innych sklepach? Znamy kwoty" src="https://i.iplsc.com/ile-mozna-zarobic-na-kasie-w-biedronce-i-innych-sklepach-zna/000G3Q8UGP7WWWSA-C321.jpg" /></a>Wynagrodzenia sprzedawców, kasjerów i kierowników w popularnych sieciach sklepów w Polsce nie odbiegają od siebie znacząco. Pracownicy dyskontów i supermarketów 

## Najnowsza prognoza pogody dla grzybiarzy. Gdzie jest najwięcej grzybów?
 - [https://wydarzenia.interia.pl/kraj/news-najnowsza-prognoza-pogody-dla-grzybiarzy-gdzie-jest-najwiece,nId,6301711](https://wydarzenia.interia.pl/kraj/news-najnowsza-prognoza-pogody-dla-grzybiarzy-gdzie-jest-najwiece,nId,6301711)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 14:02:41+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-najnowsza-prognoza-pogody-dla-grzybiarzy-gdzie-jest-najwiece,nId,6301711"><img align="left" alt="Najnowsza prognoza pogody dla grzybiarzy. Gdzie jest najwięcej grzybów?" src="https://i.iplsc.com/najnowsza-prognoza-pogody-dla-grzybiarzy-gdzie-jest-najwiece/000G3QSSV1KPWE94-C321.jpg" /></a>Pogoda we wrześniu rozpieszcza miłośników grzybobrania. Ostatnie opady deszczu poprawiły wilgotność gleby i ściółki leśnej, co sprawiło, że lasy obrodziły grzy

## Tragedia w USA. 37-latek zadźgany. Wcześniej domagał się "podziękowań"
 - [https://wydarzenia.interia.pl/zagranica/news-tragedia-w-usa-37-latek-zadzgany-wczesniej-domagal-sie-podzi,nId,6301770](https://wydarzenia.interia.pl/zagranica/news-tragedia-w-usa-37-latek-zadzgany-wczesniej-domagal-sie-podzi,nId,6301770)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 14:00:17+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tragedia-w-usa-37-latek-zadzgany-wczesniej-domagal-sie-podzi,nId,6301770"><img align="left" alt="Tragedia w USA. 37-latek zadźgany. Wcześniej domagał się &quot;podziękowań&quot;" src="https://i.iplsc.com/tragedia-w-usa-37-latek-zadzgany-wczesniej-domagal-sie-podzi/000G3S3PCPII2RQB-C321.jpg" /></a>37-letni mężczyzna został zadźgany nożem w Nowym Jorku. Do incydentu doszło po tym, jak ofiara domagała się podziękowania po przytrzymaniu drzwi 

## Wybuch w Dąbrowie Górniczej. Akcja w koksowni
 - [https://wydarzenia.interia.pl/slaskie/news-wybuch-w-dabrowie-gorniczej-akcja-w-koksowni,nId,6301797](https://wydarzenia.interia.pl/slaskie/news-wybuch-w-dabrowie-gorniczej-akcja-w-koksowni,nId,6301797)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 13:48:14+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-wybuch-w-dabrowie-gorniczej-akcja-w-koksowni,nId,6301797"><img align="left" alt="Wybuch w Dąbrowie Górniczej. Akcja w koksowni" src="https://i.iplsc.com/wybuch-w-dabrowie-gorniczej-akcja-w-koksowni/000FZ899M2IC99HN-C321.jpg" /></a>Akcja służb w Dąbrowie Górniczej (woj. śląskie). Jak donoszą lokalne media, doszło tam do wybuchu w jednej z koksowni. Z pożarem ma walczyć nawet kilkanaście jednostek straży pożarnej.</p><br clear="all" />

## Poseł Konfederacji jechał bez prawa jazdy. Czy ma uprawnienia?
 - [https://wydarzenia.interia.pl/autor/dawid-zdrojewski/news-posel-konfederacji-jechal-bez-prawa-jazdy-czy-ma-uprawnienia,nId,6301777](https://wydarzenia.interia.pl/autor/dawid-zdrojewski/news-posel-konfederacji-jechal-bez-prawa-jazdy-czy-ma-uprawnienia,nId,6301777)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 13:32:15+00:00

<p><a href="https://wydarzenia.interia.pl/autor/dawid-zdrojewski/news-posel-konfederacji-jechal-bez-prawa-jazdy-czy-ma-uprawnienia,nId,6301777"><img align="left" alt="Poseł Konfederacji jechał bez prawa jazdy. Czy ma uprawnienia?" src="https://i.iplsc.com/posel-konfederacji-jechal-bez-prawa-jazdy-czy-ma-uprawnienia/000G3R1A28Y60HH0-C321.jpg" /></a>Poseł Konfederacji Michał Urbaniak został zatrzymany przez policję bez uprawnień do kierowania pojazdem - ustaliła Interia. Urbaniak tłumaczy, że praw

## Zapadlisko na cmentarzu. Prokuratura sprawdza, czy doszło do przestępstwa
 - [https://wydarzenia.interia.pl/malopolskie/news-zapadlisko-na-cmentarzu-prokuratura-sprawdza-czy-doszlo-do-p,nId,6301760](https://wydarzenia.interia.pl/malopolskie/news-zapadlisko-na-cmentarzu-prokuratura-sprawdza-czy-doszlo-do-p,nId,6301760)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 13:22:32+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-zapadlisko-na-cmentarzu-prokuratura-sprawdza-czy-doszlo-do-p,nId,6301760"><img align="left" alt="Zapadlisko na cmentarzu. Prokuratura sprawdza, czy doszło do przestępstwa" src="https://i.iplsc.com/zapadlisko-na-cmentarzu-prokuratura-sprawdza-czy-doszlo-do-p/000G3QXGFXFDII3U-C321.jpg" /></a>Prokuratura Rejonowa w Chrzanowie prowadzi postępowanie w sprawie zapadliska na cmentarzu parafialnym. Śledczy sprawdzają, czy doszło do przestępstwa 

## Biedronia zabrakło na spotkaniu liderów opozycji. Odnalazł się w Etiopii
 - [https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-biedronia-zabraklo-na-spotkaniu-liderow-opozycji-odnalazl-si,nId,6301714](https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-biedronia-zabraklo-na-spotkaniu-liderow-opozycji-odnalazl-si,nId,6301714)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 13:20:00+00:00

<p><a href="https://wydarzenia.interia.pl/autor/lukasz-szpyrka/news-biedronia-zabraklo-na-spotkaniu-liderow-opozycji-odnalazl-si,nId,6301714"><img align="left" alt="Biedronia zabrakło na spotkaniu liderów opozycji. Odnalazł się w Etiopii" src="https://i.iplsc.com/biedronia-zabraklo-na-spotkaniu-liderow-opozycji-odnalazl-si/000G3QMHUSFQH8Q0-C321.jpg" /></a>Spotkanie liderów partii opozycyjnych było jednym z ważniejszych politycznie wydarzeń tego tygodnia. Zabrakło na nim jednak Roberta Biedronia,

## Utajniony punkt dekretu Putina. Media o mobilizacji na masową skalę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-utajniony-punkt-dekretu-putina-media-o-mobilizacji-na-masowa,nId,6301715](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-utajniony-punkt-dekretu-putina-media-o-mobilizacji-na-masowa,nId,6301715)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 12:38:44+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-utajniony-punkt-dekretu-putina-media-o-mobilizacji-na-masowa,nId,6301715"><img align="left" alt="Utajniony punkt dekretu Putina. Media o mobilizacji na masową skalę" src="https://i.iplsc.com/utajniony-punkt-dekretu-putina-media-o-mobilizacji-na-masowa/000G1V0PDT45C9AM-C321.jpg" /></a>Pojawia się coraz więcej informacji o ukrytym punkcie dekretu Władimira Putina w sprawie mobilizacji. Jak donoszą niezależne me

## Tragedia w Japonii. Podpalił się w sprzeciwie wobec pogrzebu Shinzo Abe
 - [https://wydarzenia.interia.pl/zagranica/news-tragedia-w-japonii-podpalil-sie-w-sprzeciwie-wobec-pogrzebu-,nId,6301705](https://wydarzenia.interia.pl/zagranica/news-tragedia-w-japonii-podpalil-sie-w-sprzeciwie-wobec-pogrzebu-,nId,6301705)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 12:32:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tragedia-w-japonii-podpalil-sie-w-sprzeciwie-wobec-pogrzebu-,nId,6301705"><img align="left" alt="Tragedia w Japonii. Podpalił się w sprzeciwie wobec pogrzebu Shinzo Abe" src="https://i.iplsc.com/tragedia-w-japonii-podpalil-sie-w-sprzeciwie-wobec-pogrzebu/000G3QORKPU6C70D-C321.jpg" /></a>70-letni Japończyk podpalił się pod siedzibą premiera Japonii, by zaprotestować przeciwko pogrzebowi byłego szefa rządu - Shinzo Abe, który na początku lip

## Poznań. 36-latka zmarła przez błąd pielęgniarki. Rodzina żąda zadośćuczynienia
 - [https://wydarzenia.interia.pl/wielkopolskie/news-poznan-36-latka-zmarla-przez-blad-pielegniarki-rodzina-zada-,nId,6301675](https://wydarzenia.interia.pl/wielkopolskie/news-poznan-36-latka-zmarla-przez-blad-pielegniarki-rodzina-zada-,nId,6301675)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 11:57:39+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-poznan-36-latka-zmarla-przez-blad-pielegniarki-rodzina-zada-,nId,6301675"><img align="left" alt="Poznań. 36-latka zmarła przez błąd pielęgniarki. Rodzina żąda zadośćuczynienia" src="https://i.iplsc.com/poznan-36-latka-zmarla-przez-blad-pielegniarki-rodzina-zada/000G3QH7GJBXS5CB-C321.jpg" /></a>36-letnia Anna K. zmarła w styczniu 2019 roku przez błąd pielęgniarki w tzw. klinice medycyny naturalnej w Poznaniu. Kobieta poddawana była tam 

## Dziecko zabiło dziecko? "Najgorszy koszmar rodzica"
 - [https://wydarzenia.interia.pl/zagranica/news-dziecko-zabilo-dziecko-najgorszy-koszmar-rodzica,nId,6301639](https://wydarzenia.interia.pl/zagranica/news-dziecko-zabilo-dziecko-najgorszy-koszmar-rodzica,nId,6301639)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 11:30:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-dziecko-zabilo-dziecko-najgorszy-koszmar-rodzica,nId,6301639"><img align="left" alt="Dziecko zabiło dziecko? &quot;Najgorszy koszmar rodzica&quot;" src="https://i.iplsc.com/dziecko-zabilo-dziecko-najgorszy-koszmar-rodzica/000G3QEH78K655EJ-C321.jpg" /></a>Tragedia w angielskim Huddersfield. 15-latek został ugodzony nożem przed szkołą na oczach innych uczniów i rodziców odbierających dzieci. Zbrodni miał dokonać 16-latek, który został zatrzy

## Otwock. Pacjent zniszczył samochód, bo był wściekły. Wcześniej wyrzucili go ze szpitala
 - [https://wydarzenia.interia.pl/mazowieckie/news-otwock-pacjent-zniszczyl-samochod-bo-byl-wsciekly-wczesniej-,nId,6301638](https://wydarzenia.interia.pl/mazowieckie/news-otwock-pacjent-zniszczyl-samochod-bo-byl-wsciekly-wczesniej-,nId,6301638)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 11:30:41+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-otwock-pacjent-zniszczyl-samochod-bo-byl-wsciekly-wczesniej-,nId,6301638"><img align="left" alt="Otwock. Pacjent zniszczył samochód, bo był wściekły. Wcześniej wyrzucili go ze szpitala" src="https://i.iplsc.com/otwock-pacjent-zniszczyl-samochod-bo-byl-wsciekly-wczesniej/000G3QAD72O98ECI-C321.jpg" /></a>Policjanci z Otwocka zatrzymali 52-latka, który zniszczył drogi samochód na szpitalnym parkingu. Chwilę wcześniej pacjent został wydalony

## Poznań: Dziewięciolatek z Ukrainy dotkliwie pobity. Napadli go nastolatkowie
 - [https://wydarzenia.interia.pl/wielkopolskie/news-poznan-dziewieciolatek-z-ukrainy-dotkliwie-pobity-napadli-go,nId,6301618](https://wydarzenia.interia.pl/wielkopolskie/news-poznan-dziewieciolatek-z-ukrainy-dotkliwie-pobity-napadli-go,nId,6301618)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 11:17:51+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-poznan-dziewieciolatek-z-ukrainy-dotkliwie-pobity-napadli-go,nId,6301618"><img align="left" alt="Poznań: Dziewięciolatek z Ukrainy dotkliwie pobity. Napadli go nastolatkowie" src="https://i.iplsc.com/poznan-dziewieciolatek-z-ukrainy-dotkliwie-pobity-napadli-go/000D1M9BT7LCWIW2-C321.jpg" /></a>O karze dla dwóch nastolatków, którzy w ubiegłym tygodniu napadli na dziewięciolatka z Ukrainy, zdecyduje sąd rodzinny - poinformowała policja. Z

## Szczepienia przeciw COVID-19. Lekarz: Nie warto na nic czekać
 - [https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-szczepienia-przeciw-covid-19-lekarz-nie-warto-na-nic-czekac,nId,6301610](https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-szczepienia-przeciw-covid-19-lekarz-nie-warto-na-nic-czekac,nId,6301610)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 11:06:40+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-szczepienia-przeciw-covid-19-lekarz-nie-warto-na-nic-czekac,nId,6301610"><img align="left" alt="Szczepienia przeciw COVID-19. Lekarz: Nie warto na nic czekać" src="https://i.iplsc.com/szczepienia-przeciw-covid-19-lekarz-nie-warto-na-nic-czekac/000G3QA0AWR5CDU5-C321.jpg" /></a>- Nie warto zwlekać z przyjęciem kolejnej dawki szczepienia przeciw COVID-19, najlepiej zaszczepić się teraz - przekonuje dr hab. Jerzy 

## Chiny tworzą wyspy i je uzbrajają. Skala oszałamia, USA zaniepokojone
 - [https://wydarzenia.interia.pl/zagranica/news-chiny-tworza-wyspy-i-je-uzbrajaja-skala-oszalamia-usa-zaniep,nId,6299633](https://wydarzenia.interia.pl/zagranica/news-chiny-tworza-wyspy-i-je-uzbrajaja-skala-oszalamia-usa-zaniep,nId,6299633)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 10:58:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chiny-tworza-wyspy-i-je-uzbrajaja-skala-oszalamia-usa-zaniep,nId,6299633"><img align="left" alt="Chiny tworzą wyspy i je uzbrajają. Skala oszałamia, USA zaniepokojone" src="https://i.iplsc.com/chiny-tworza-wyspy-i-je-uzbrajaja-skala-oszalamia-usa-zaniep/000G3Q1HS1RRKL79-C321.jpg" /></a>Gdy oczy świata zwrócone są na Ukrainę, Chiny nie tylko zaostrzają kurs wobec kwestionowanej przez Pekin niepodległości Tajwanu, ale równocześnie intensyfik

## "Rekordowe" podwyżki ministra Czarnka. Czy nauczyciele faktycznie mogą liczyć na wyższą pensję?
 - [https://wydarzenia.interia.pl/kraj/news-rekordowe-podwyzki-ministra-czarnka-czy-nauczyciele-faktyczn,nId,6301547](https://wydarzenia.interia.pl/kraj/news-rekordowe-podwyzki-ministra-czarnka-czy-nauczyciele-faktyczn,nId,6301547)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 10:48:08+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rekordowe-podwyzki-ministra-czarnka-czy-nauczyciele-faktyczn,nId,6301547"><img align="left" alt="&quot;Rekordowe&quot; podwyżki ministra Czarnka. Czy nauczyciele faktycznie mogą liczyć na wyższą pensję?" src="https://i.iplsc.com/rekordowe-podwyzki-ministra-czarnka-czy-nauczyciele-faktyczn/000G3PSELQU40NBO-C321.jpg" /></a>W środowisku nauczycielskim i akademickim wrze po kolejnych wystąpieniach publicznych ministra Przemysława Czarnka, który zap

## Rosja. "Częściowa" mobilizacja. Płoną wojskowe komendy uzupełnień
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-czesciowa-mobilizacja-plona-wojskowe-komendy-uzupelnie,nId,6301571](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-czesciowa-mobilizacja-plona-wojskowe-komendy-uzupelnie,nId,6301571)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 10:35:02+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-czesciowa-mobilizacja-plona-wojskowe-komendy-uzupelnie,nId,6301571"><img align="left" alt="Rosja. &quot;Częściowa&quot; mobilizacja. Płoną wojskowe komendy uzupełnień" src="https://i.iplsc.com/rosja-czesciowa-mobilizacja-plona-wojskowe-komendy-uzupelnie/000G3Q1BDCNAE91C-C321.jpg" /></a>Niedaleko Petersburga ktoś podpalili w nocy wojskową komendę uzupełnień. To nie pierwszy taki przypadek. Rosjanie masow

## Stoltenberg: Wojny nuklearnej nie można wygrać. Mówiliśmy to Moskwie
 - [https://wydarzenia.interia.pl/zagranica/news-stoltenberg-wojny-nuklearnej-nie-mozna-wygrac-mowilismy-to-m,nId,6301548](https://wydarzenia.interia.pl/zagranica/news-stoltenberg-wojny-nuklearnej-nie-mozna-wygrac-mowilismy-to-m,nId,6301548)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 10:28:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-stoltenberg-wojny-nuklearnej-nie-mozna-wygrac-mowilismy-to-m,nId,6301548"><img align="left" alt="Stoltenberg: Wojny nuklearnej nie można wygrać. Mówiliśmy to Moskwie" src="https://i.iplsc.com/stoltenberg-wojny-nuklearnej-nie-mozna-wygrac-mowilismy-to-m/000ESJPH6FO5MPQM-C321.jpg" /></a>- Putin powinien wiedzieć, że wojny nuklearnej nie można wygrać i nie wolno jej prowadzić - powiedział sekretarz generalny NATO Jens Stoltenberg w wywiadzie 

## Piwo lało się strumieniami po autostradzie. Kierowca nie wyhamował
 - [https://wydarzenia.interia.pl/zagranica/news-piwo-lalo-sie-strumieniami-po-autostradzie-kierowca-nie-wyha,nId,6301569](https://wydarzenia.interia.pl/zagranica/news-piwo-lalo-sie-strumieniami-po-autostradzie-kierowca-nie-wyha,nId,6301569)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 10:22:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-piwo-lalo-sie-strumieniami-po-autostradzie-kierowca-nie-wyha,nId,6301569"><img align="left" alt="Piwo lało się strumieniami po autostradzie. Kierowca nie wyhamował" src="https://i.iplsc.com/piwo-lalo-sie-strumieniami-po-autostradzie-kierowca-nie-wyha/000G3Q0SC73QKLBT-C321.jpg" /></a>Wszystkie pasy ruchu autostrady na Florydzie zostały zablokowane z powodu wycieku... piwa. Tysiące puszek wypadło z naczepy ciężarówki, po tym, jak kierowca wj

## Kościan: Ciągnik zderzył się z samochodem osobowym. Nikt nie chce przyznać się do wizy
 - [https://wydarzenia.interia.pl/wiadomosci-lokalne/news-koscian-ciagnik-zderzyl-sie-z-samochodem-osobowym-nikt-nie-c,nId,6301462](https://wydarzenia.interia.pl/wiadomosci-lokalne/news-koscian-ciagnik-zderzyl-sie-z-samochodem-osobowym-nikt-nie-c,nId,6301462)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 10:22:37+00:00

<p><a href="https://wydarzenia.interia.pl/wiadomosci-lokalne/news-koscian-ciagnik-zderzyl-sie-z-samochodem-osobowym-nikt-nie-c,nId,6301462"><img align="left" alt="Kościan: Ciągnik zderzył się z samochodem osobowym. Nikt nie chce przyznać się do wizy" src="https://i.iplsc.com/koscian-ciagnik-zderzyl-sie-z-samochodem-osobowym-nikt-nie-c/000G3PP8KFI8ONBL-C321.jpg" /></a>W Kościanie doszło do nietypowej kolizji. Kierująca, próbując uniknąć zderzenia z innym kierowcą, uderzyła czołowo w ciągnik. Jak 

## Media: Rosjanie otrzymują wezwanie do wojska za udział w protestach
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosjanie-otrzymuja-wezwanie-do-wojska-za-udzial-w-prot,nId,6301526](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosjanie-otrzymuja-wezwanie-do-wojska-za-udzial-w-prot,nId,6301526)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 10:14:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-rosjanie-otrzymuja-wezwanie-do-wojska-za-udzial-w-prot,nId,6301526"><img align="left" alt="Media: Rosjanie otrzymują wezwanie do wojska za udział w protestach" src="https://i.iplsc.com/media-rosjanie-otrzymuja-wezwanie-do-wojska-za-udzial-w-prot/000G3Q235YGELR49-C321.jpg" /></a>Protestujący przeciwko częściowej mobilizacji otrzymują wezwania do wojska na komisariatach - donosi portal OWD-Info. Choć zgod

## 23 września duża zmiana w kalendarzu. Długoterminowa pogoda na jesień: Kiedy przyjdzie mróz?
 - [https://wydarzenia.interia.pl/kraj/news-23-wrzesnia-duza-zmiana-w-kalendarzu-dlugoterminowa-pogoda-n,nId,6299466](https://wydarzenia.interia.pl/kraj/news-23-wrzesnia-duza-zmiana-w-kalendarzu-dlugoterminowa-pogoda-n,nId,6299466)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 09:55:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-23-wrzesnia-duza-zmiana-w-kalendarzu-dlugoterminowa-pogoda-n,nId,6299466"><img align="left" alt="23 września duża zmiana w kalendarzu. Długoterminowa pogoda na jesień: Kiedy przyjdzie mróz?" src="https://i.iplsc.com/23-wrzesnia-duza-zmiana-w-kalendarzu-dlugoterminowa-pogoda-n/000G3JQ86B2BF7Q5-C321.jpg" /></a>Początek września przywitał nas bardzo kapryśną pogodą - w całej Polsce przeważała niska temperatura, silny wiatr oraz intensywne opady de

## Chiny: Kara śmierci dla ministra sprawiedliwości za korupcję
 - [https://wydarzenia.interia.pl/zagranica/news-chiny-kara-smierci-dla-ministra-sprawiedliwosci-za-korupcje,nId,6301483](https://wydarzenia.interia.pl/zagranica/news-chiny-kara-smierci-dla-ministra-sprawiedliwosci-za-korupcje,nId,6301483)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 09:06:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chiny-kara-smierci-dla-ministra-sprawiedliwosci-za-korupcje,nId,6301483"><img align="left" alt="Chiny: Kara śmierci dla ministra sprawiedliwości za korupcję" src="https://i.iplsc.com/chiny-kara-smierci-dla-ministra-sprawiedliwosci-za-korupcje/000G3PLRIRCCQPET-C321.jpg" /></a>Kara śmierci za korupcję dla byłego ministra sprawiedliwości Fu Zhenghua - to decyzja chińskiego sądu, o której poinformowały państwowe media. Gdy polityk był jeszcze 

## "Le Figaro" o Putinie: Radioaktywny car
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-le-figaro-o-putinie-radioaktywny-car,nId,6301480](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-le-figaro-o-putinie-radioaktywny-car,nId,6301480)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 08:50:29+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-le-figaro-o-putinie-radioaktywny-car,nId,6301480"><img align="left" alt="&quot;Le Figaro&quot; o Putinie: Radioaktywny car" src="https://i.iplsc.com/le-figaro-o-putinie-radioaktywny-car/000G3PIAA2G48Q35-C321.jpg" /></a>Prezydent Rosji Władimir Putin zachowuje się, jak &quot;radioaktywny car&quot;, który grozi światu użyciem broni nuklearnej, co jest publicznym przyznaniem się do swojej porażki - pisze w czwar

## Tajemnicze zaginięcie 27-letniej Rusłany. Miała być na dyskotece
 - [https://wydarzenia.interia.pl/slaskie/news-tajemnicze-zaginiecie-27-letniej-ruslany-miala-byc-na-dyskot,nId,6301457](https://wydarzenia.interia.pl/slaskie/news-tajemnicze-zaginiecie-27-letniej-ruslany-miala-byc-na-dyskot,nId,6301457)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 08:31:35+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-tajemnicze-zaginiecie-27-letniej-ruslany-miala-byc-na-dyskot,nId,6301457"><img align="left" alt="Tajemnicze zaginięcie 27-letniej Rusłany. Miała być na dyskotece" src="https://i.iplsc.com/tajemnicze-zaginiecie-27-letniej-ruslany-miala-byc-na-dyskot/000G3PAA20T435FS-C321.jpg" /></a>Rusłana Krzeminska zaginęła w sobotę, 3 września. Ostatni raz była widziana w Zabrzu, gdy wyszła z domu i pojechała na dyskotekę do Katowic. Do tej pory nie wrócił

## Białoruś. Na wolność wyszedł dziennikarz Radia Swaboda
 - [https://wydarzenia.interia.pl/zagranica/news-bialorus-na-wolnosc-wyszedl-dziennikarz-radia-swaboda,nId,6301433](https://wydarzenia.interia.pl/zagranica/news-bialorus-na-wolnosc-wyszedl-dziennikarz-radia-swaboda,nId,6301433)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 08:25:04+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bialorus-na-wolnosc-wyszedl-dziennikarz-radia-swaboda,nId,6301433"><img align="left" alt="Białoruś. Na wolność wyszedł dziennikarz Radia Swaboda" src="https://i.iplsc.com/bialorus-na-wolnosc-wyszedl-dziennikarz-radia-swaboda/000G3P24S47OT56J-C321.jpg" /></a>Dziennikarz Radia Swaboda, białoruskiej redakcji Radia Wolna Europa, Ałeh Hruzdziłowicz, został w środę wypuszczony z więzienia. Reporter został skazany za &quot;organizację protestów&q

## Prezydent Węgier: Potępiamy rosyjską agresję, która zniszczyła pokój w Europie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prezydent-wegier-potepiamy-rosyjska-agresje-ktora-zniszczyla,nId,6301451](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prezydent-wegier-potepiamy-rosyjska-agresje-ktora-zniszczyla,nId,6301451)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 08:21:18+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-prezydent-wegier-potepiamy-rosyjska-agresje-ktora-zniszczyla,nId,6301451"><img align="left" alt="Prezydent Węgier: Potępiamy rosyjską agresję, która zniszczyła pokój w Europie" src="https://i.iplsc.com/prezydent-wegier-potepiamy-rosyjska-agresje-ktora-zniszczyla/000G3P8APM3KK645-C321.jpg" /></a>Węgry stanowczo potępiają rosyjską agresję, która zniszczyła pokój w Europie - powiedziała prezydent Węgier Katalin 

## Takich zdjęć nie było od dekad. Planeta "w nowym świetle"
 - [https://wydarzenia.interia.pl/zagranica/news-takich-zdjec-nie-bylo-od-dekad-planeta-w-nowym-swietle,nId,6301441](https://wydarzenia.interia.pl/zagranica/news-takich-zdjec-nie-bylo-od-dekad-planeta-w-nowym-swietle,nId,6301441)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 08:09:39+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-takich-zdjec-nie-bylo-od-dekad-planeta-w-nowym-swietle,nId,6301441"><img align="left" alt="Takich zdjęć nie było od dekad. Planeta &quot;w nowym świetle&quot;" src="https://i.iplsc.com/takich-zdjec-nie-bylo-od-dekad-planeta-w-nowym-swietle/000G3P5BYL2LQ1T5-C321.jpg" /></a>Kosmiczny teleskop Jamesa Webba do obserwacji w podczerwieni uchwycił najczystszy widok pierścieni Neptuna od ponad 30 lat. Na nowych zdjęciach widać siedem z 14 znanych 

## Politycy w zbiorkomie. Bezpłatne bilety to nie wszystko
 - [https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-politycy-w-zbiorkomie-bezplatne-bilety-to-nie-wszystko,nId,6299973](https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-politycy-w-zbiorkomie-bezplatne-bilety-to-nie-wszystko,nId,6299973)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 08:06:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-politycy-w-zbiorkomie-bezplatne-bilety-to-nie-wszystko,nId,6299973"><img align="left" alt="Politycy w zbiorkomie. Bezpłatne bilety to nie wszystko" src="https://i.iplsc.com/politycy-w-zbiorkomie-bezplatne-bilety-to-nie-wszystko/000G3NEOUGRJC6TM-C321.jpg" /></a>100 procent zniżki na bilety, zwroty za podróże samolotami i przedziały poselskie w PKP Intercity - to niektóre z udogodnień, które politycy posi

## Towarowa kolej w obliczu bankructwa. "Trzeba radykalnych kroków"
 - [https://wydarzenia.interia.pl/raporty/raport-kryzys-energetyczny/aktualnosci/news-towarowa-kolej-w-obliczu-bankructwa-trzeba-radykalnych-kroko,nId,6299966](https://wydarzenia.interia.pl/raporty/raport-kryzys-energetyczny/aktualnosci/news-towarowa-kolej-w-obliczu-bankructwa-trzeba-radykalnych-kroko,nId,6299966)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 08:02:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-kryzys-energetyczny/aktualnosci/news-towarowa-kolej-w-obliczu-bankructwa-trzeba-radykalnych-kroko,nId,6299966"><img align="left" alt="Towarowa kolej w obliczu bankructwa. &quot;Trzeba radykalnych kroków&quot;" src="https://i.iplsc.com/towarowa-kolej-w-obliczu-bankructwa-trzeba-radykalnych-kroko/000G3NAR4I8NJSCB-C321.jpg" /></a>- Z hasła &quot;TIR-y na tory&quot; nic nie wyszło. Udział kolei w przewozie towarów spada z roku na rok, a niemal

## Rzepin: 31-latek zatrzymany za napaść na policjantów. Ma też inne zarzuty
 - [https://wydarzenia.interia.pl/lubuskie/news-rzepin-31-latek-zatrzymany-za-napasc-na-policjantow-ma-tez-i,nId,6301406](https://wydarzenia.interia.pl/lubuskie/news-rzepin-31-latek-zatrzymany-za-napasc-na-policjantow-ma-tez-i,nId,6301406)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 07:50:40+00:00

<p><a href="https://wydarzenia.interia.pl/lubuskie/news-rzepin-31-latek-zatrzymany-za-napasc-na-policjantow-ma-tez-i,nId,6301406"><img align="left" alt="Rzepin: 31-latek zatrzymany za napaść na policjantów. Ma też inne zarzuty" src="https://i.iplsc.com/rzepin-31-latek-zatrzymany-za-napasc-na-policjantow-ma-tez-i/000EKI4ZPO87B15O-C321.jpg" /></a>Zarzuty czynnej napaści na policjantów, posiadania narkotyków oraz kradzieży usłyszał 31-latek zatrzymany przez funkcjonariuszy z komisariatu w Rzepinie 

## Wojna w Ukrainie. Atak na Zaporoże. Pod gruzami hotelu są ludzie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-atak-na-zaporoze-pod-gruzami-hotelu-sa-ludz,nId,6301386](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-atak-na-zaporoze-pod-gruzami-hotelu-sa-ludz,nId,6301386)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 07:34:19+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-atak-na-zaporoze-pod-gruzami-hotelu-sa-ludz,nId,6301386"><img align="left" alt="Wojna w Ukrainie. Atak na Zaporoże. Pod gruzami hotelu są ludzie" src="https://i.iplsc.com/wojna-w-ukrainie-atak-na-zaporoze-pod-gruzami-hotelu-sa-ludz/000G3ON1IW3O84V2-C321.jpg" /></a>Wojska rosyjskie zaatakowały Zaporoże na południowym wschodzie Ukrainy dziewięcioma rakietami. Jedna z nich trafiła w budynek hote

## Reparacje od Niemiec. Posłanka Bundestagu krytykuje Scholza. "To moralnie naganne"
 - [https://wydarzenia.interia.pl/zagranica/news-reparacje-od-niemiec-poslanka-bundestagu-krytykuje-scholza-t,nId,6301409](https://wydarzenia.interia.pl/zagranica/news-reparacje-od-niemiec-poslanka-bundestagu-krytykuje-scholza-t,nId,6301409)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 07:24:22+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-reparacje-od-niemiec-poslanka-bundestagu-krytykuje-scholza-t,nId,6301409"><img align="left" alt="Reparacje od Niemiec. Posłanka Bundestagu krytykuje Scholza. &quot;To moralnie naganne&quot;" src="https://i.iplsc.com/reparacje-od-niemiec-poslanka-bundestagu-krytykuje-scholza-t/000G3OUJHGW8E975-C321.jpg" /></a>Posłanka Bundestagu Żaklin Nastić z Lewicy skrytykowała odrzucenie przez Niemców polskich żądań ws. reparacji. - Całkowite odrzucenie

## Berlin: Skonfiskowano auta z orszaku weselnego. Panna młoda poszła piechotą
 - [https://wydarzenia.interia.pl/zagranica/news-berlin-skonfiskowano-auta-z-orszaku-weselnego-panna-mloda-po,nId,6301387](https://wydarzenia.interia.pl/zagranica/news-berlin-skonfiskowano-auta-z-orszaku-weselnego-panna-mloda-po,nId,6301387)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 07:15:25+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-berlin-skonfiskowano-auta-z-orszaku-weselnego-panna-mloda-po,nId,6301387"><img align="left" alt="Berlin: Skonfiskowano auta z orszaku weselnego. Panna młoda poszła piechotą" src="https://i.iplsc.com/berlin-skonfiskowano-auta-z-orszaku-weselnego-panna-mloda-po/000G3OUP49XY1AAM-C321.jpg" /></a>Panna młoda musiała pójść na swoje wesele pieszo po tym, gdy wraz ze współbiesiadnikami i wbrew wszelkim przepisom przemierzała ulice centrum Berlina 

## Jędraszewski sięga do parafialnych kas. Będzie nowy podatek
 - [https://wydarzenia.interia.pl/malopolskie/news-jedraszewski-siega-do-parafialnych-kas-bedzie-nowy-podatek,nId,6301398](https://wydarzenia.interia.pl/malopolskie/news-jedraszewski-siega-do-parafialnych-kas-bedzie-nowy-podatek,nId,6301398)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 07:07:37+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-jedraszewski-siega-do-parafialnych-kas-bedzie-nowy-podatek,nId,6301398"><img align="left" alt="Jędraszewski sięga do parafialnych kas. Będzie nowy podatek" src="https://i.iplsc.com/jedraszewski-siega-do-parafialnych-kas-bedzie-nowy-podatek/000G3OP0CDVATB18-C321.jpg" /></a>Arcybiskup metropolita krakowski Marek Jędraszewski nałożył na podległe mu parafie nowy podatek. Mają one oddawać dziesięcinę z przychodów od prowadzonej działalności. 

## "Stworzyliśmy potwora". Pokazali, jak w Polsce zwijano kolej
 - [https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-stworzylismy-potwora-pokazali-jak-w-polsce-zwijano-kolej,nId,6299885](https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-stworzylismy-potwora-pokazali-jak-w-polsce-zwijano-kolej,nId,6299885)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 06:59:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-stworzylismy-potwora-pokazali-jak-w-polsce-zwijano-kolej,nId,6299885"><img align="left" alt="&quot;Stworzyliśmy potwora&quot;. Pokazali, jak w Polsce zwijano kolej" src="https://i.iplsc.com/stworzylismy-potwora-pokazali-jak-w-polsce-zwijano-kolej/000G3MKCM5TOYT7I-C321.jpg" /></a>Stworzyli mapę i zdziwili się, jaką skalę likwidacji polskiej kolei pasażerskiej na niej widać. Na schemacie nasz kraj przecin

## Quiz o patronach pociągów. Pytania nie tylko dla kolejarzy
 - [https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-quiz-o-patronach-pociagow-pytania-nie-tylko-dla-kolejarzy,nId,6299947](https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-quiz-o-patronach-pociagow-pytania-nie-tylko-dla-kolejarzy,nId,6299947)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 06:35:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-quiz-o-patronach-pociagow-pytania-nie-tylko-dla-kolejarzy,nId,6299947"><img align="left" alt="Quiz o patronach pociągów. Pytania nie tylko dla kolejarzy" src="https://i.iplsc.com/quiz-o-patronach-pociagow-pytania-nie-tylko-dla-kolejarzy/000G3N0T6SLJVWWR-C321.jpg" /></a>Malinowski, Mehoffer, Szyndzielnia czy Staszic - to słowa znane nie tylko z kart szkolnych podręczników, ale i rozkładu jazdy PKP Interc

## Remont lwów przed Pałacem Prezydenckim. "Kolejny królewski wydatek"
 - [https://wydarzenia.interia.pl/kraj/news-remont-lwow-przed-palacem-prezydenckim-kolejny-krolewski-wyd,nId,6301353](https://wydarzenia.interia.pl/kraj/news-remont-lwow-przed-palacem-prezydenckim-kolejny-krolewski-wyd,nId,6301353)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 06:34:04+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-remont-lwow-przed-palacem-prezydenckim-kolejny-krolewski-wyd,nId,6301353"><img align="left" alt="Remont lwów przed Pałacem Prezydenckim. &quot;Kolejny królewski wydatek&quot;" src="https://i.iplsc.com/remont-lwow-przed-palacem-prezydenckim-kolejny-krolewski-wyd/000G3OK3B1BE5GX9-C321.jpg" /></a>Wejścia do Pałacu Prezydenckiego strzegą cztery kamienne lwy. Te niepozorne posągi przed dziesięcioma laty przeszły renowację. Na przełomie września i pa

## Holandia: Statek dla azylantów wywołał protesty lokalnej ludności
 - [https://wydarzenia.interia.pl/zagranica/news-holandia-statek-dla-azylantow-wywolal-protesty-lokalnej-ludn,nId,6301329](https://wydarzenia.interia.pl/zagranica/news-holandia-statek-dla-azylantow-wywolal-protesty-lokalnej-ludn,nId,6301329)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 06:12:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-holandia-statek-dla-azylantow-wywolal-protesty-lokalnej-ludn,nId,6301329"><img align="left" alt="Holandia: Statek dla azylantów wywołał protesty lokalnej ludności" src="https://i.iplsc.com/holandia-statek-dla-azylantow-wywolal-protesty-lokalnej-ludn/000G3OECIJ55A05S-C321.jpg" /></a>Mieszczący ponad 1000 osób statek wycieczkowy przypłynął do Holandii, by przyjąć uchodźców, którzy ubiegają się o azyl w tym kraju. Przybycie jednostki wywołało

## Wojna w Ukrainie. Rosjanie transportują paliwo cysternami do mleka
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-rosjanie-transportuja-paliwo-cysternami-do-,nId,6301320](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-rosjanie-transportuja-paliwo-cysternami-do-,nId,6301320)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 05:57:55+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-rosjanie-transportuja-paliwo-cysternami-do-,nId,6301320"><img align="left" alt="Wojna w Ukrainie. Rosjanie transportują paliwo cysternami do mleka" src="https://i.iplsc.com/wojna-w-ukrainie-rosjanie-transportuja-paliwo-cysternami-do/000G3OEZO281IEIE-C321.jpg" /></a>W obwodzie mikołajowskim Rosjanie przejęli od lokalnych przedsiębiorców cysterny do przewozu mleka. Wykorzystują je, by potajemni

## Więcej przypadków boreliozy w Polsce. Jakie są jej objawy?
 - [https://wydarzenia.interia.pl/kraj/news-wiecej-przypadkow-boreliozy-w-polsce-jakie-sa-jej-objawy,nId,6301307](https://wydarzenia.interia.pl/kraj/news-wiecej-przypadkow-boreliozy-w-polsce-jakie-sa-jej-objawy,nId,6301307)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 05:02:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wiecej-przypadkow-boreliozy-w-polsce-jakie-sa-jej-objawy,nId,6301307"><img align="left" alt="Więcej przypadków boreliozy w Polsce. Jakie są jej objawy?" src="https://i.iplsc.com/wiecej-przypadkow-boreliozy-w-polsce-jakie-sa-jej-objawy/000G3OARWCVIUSFQ-C321.jpg" /></a>Od 1 stycznia do 15 września potwierdzono w Polsce 10 727 przypadków boreliozy, choroby przenoszonej przez kleszcze - wynika z najnowszego zestawienia opublikowanego przez Narodowy

## Szef MSZ w Nowym Jorku. Będzie rozmawiał o orędziu Putina
 - [https://wydarzenia.interia.pl/zagranica/news-szef-msz-w-nowym-jorku-bedzie-rozmawial-o-oredziu-putina,nId,6301303](https://wydarzenia.interia.pl/zagranica/news-szef-msz-w-nowym-jorku-bedzie-rozmawial-o-oredziu-putina,nId,6301303)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 04:42:58+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szef-msz-w-nowym-jorku-bedzie-rozmawial-o-oredziu-putina,nId,6301303"><img align="left" alt="Szef MSZ w Nowym Jorku. Będzie rozmawiał o orędziu Putina" src="https://i.iplsc.com/szef-msz-w-nowym-jorku-bedzie-rozmawial-o-oredziu-putina/000G3O97QWBT8QYM-C321.jpg" /></a>Szef MSZ Zbigniew Rau w Nowym Jorku weźmie udział w nadzwyczajnym spotkaniu Europejskiej Rady Spraw Zagranicznych. Posiedzenie będzie poświęcone ostatniemu wystąpieniu prezyden

## Biały Dom o groźbach Putina: Ta zagrywka nie odniesie sukcesu
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialy-dom-o-grozbach-putina-ta-zagrywka-nie-odniesie-sukcesu,nId,6301300](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialy-dom-o-grozbach-putina-ta-zagrywka-nie-odniesie-sukcesu,nId,6301300)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 04:21:15+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialy-dom-o-grozbach-putina-ta-zagrywka-nie-odniesie-sukcesu,nId,6301300"><img align="left" alt="Biały Dom o groźbach Putina: Ta zagrywka nie odniesie sukcesu" src="https://i.iplsc.com/bialy-dom-o-grozbach-putina-ta-zagrywka-nie-odniesie-sukcesu/000G3O8BX62STP6P-C321.jpg" /></a>- Wysyłamy Rosji bardzo jasne sygnały na temat konsekwencji, z jakimi będzie wiązać się eskalacja konfliktu na Ukrainie - powiedział 

## Kryzys komunikacji miejskiej. Ekspert: Czas ograniczyć ruch aut
 - [https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-kryzys-komunikacji-miejskiej-ekspert-czas-ograniczyc-ruch-au,nId,6297536](https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-kryzys-komunikacji-miejskiej-ekspert-czas-ograniczyc-ruch-au,nId,6297536)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 04:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-kryzys-komunikacji-miejskiej-ekspert-czas-ograniczyc-ruch-au,nId,6297536"><img align="left" alt="Kryzys komunikacji miejskiej. Ekspert: Czas ograniczyć ruch aut" src="https://i.iplsc.com/kryzys-komunikacji-miejskiej-ekspert-czas-ograniczyc-ruch-au/000G3FXS1127TML4-C321.jpg" /></a>- Musimy zdecydować się na śmiałe rozwiązania dla komunikacji zbiorowej. Likwidowanie linii czy drastyczne ograniczanie kurso

## Gdańsk: Śmieci, smród i zdrapane rozkłady. Tak jeździ się z dworca PKS
 - [https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-gdansk-smieci-smrod-i-zdrapane-rozklady-tak-jezdzi-sie-z-dwo,nId,6297810](https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-gdansk-smieci-smrod-i-zdrapane-rozklady-tak-jezdzi-sie-z-dwo,nId,6297810)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 03:58:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-transport-publiczny/aktualnosci/news-gdansk-smieci-smrod-i-zdrapane-rozklady-tak-jezdzi-sie-z-dwo,nId,6297810"><img align="left" alt="Gdańsk: Śmieci, smród i zdrapane rozkłady. Tak jeździ się z dworca PKS" src="https://i.iplsc.com/gdansk-smieci-smrod-i-zdrapane-rozklady-tak-jezdzi-sie-z-dwo/000G3GT66FMXR34D-C321.jpg" /></a>Kto chce przenieść się w czasie, niech odwiedzi główny dworzec autobusowy w Gdańsku. Tu standardy XXI wieku jeszcze ni

## USA: Aresztowano mężczyznę z fentanylem. Mógł zabić 100 tysięcy osób
 - [https://wydarzenia.interia.pl/zagranica/news-usa-aresztowano-mezczyzne-z-fentanylem-mogl-zabic-100-tysiec,nId,6301298](https://wydarzenia.interia.pl/zagranica/news-usa-aresztowano-mezczyzne-z-fentanylem-mogl-zabic-100-tysiec,nId,6301298)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 03:44:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-aresztowano-mezczyzne-z-fentanylem-mogl-zabic-100-tysiec,nId,6301298"><img align="left" alt="USA: Aresztowano mężczyznę z fentanylem. Mógł zabić 100 tysięcy osób" src="https://i.iplsc.com/usa-aresztowano-mezczyzne-z-fentanylem-mogl-zabic-100-tysiec/000G3O74P0SYINT3-C321.jpg" /></a>Jak przekazało Politico powołując się na biuro szeryfa hrabstwa Flagler, policja aresztowała na Florydzie poszukiwanego mężczyznę. Do zatrzymania doszło podc

## Wojna w Ukrainie. 211. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo,nzId,3048,akt,220547](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo,nzId,3048,akt,220547)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 03:25:57+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo,nzId,3048,akt,220547"><img align="left" alt="Wojna w Ukrainie. 211. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo/000G3O6IBAFB9D4G-C321.jpg" /></a>Najważniejsze i najnowsze informacje o sytuacji w Ukrainie. Śledź relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 211. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo,nzId,3048,akt,220630](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo,nzId,3048,akt,220630)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 03:25:57+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo,nzId,3048,akt,220630"><img align="left" alt="Wojna w Ukrainie. 211. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo/000G3O6IBAFB9D4G-C321.jpg" /></a>Najważniejsze i najnowsze informacje o sytuacji w Ukrainie. Śledź relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 211. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo,nzId,3048,akt,220730](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo,nzId,3048,akt,220730)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-22 03:25:57+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo,nzId,3048,akt,220730"><img align="left" alt="Wojna w Ukrainie. 211. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-211-dzien-inwazji-rosji-relacja-na-zywo/000G3O6IBAFB9D4G-C321.jpg" /></a>Najważniejsze i najnowsze informacje o sytuacji w Ukrainie. Śledź relację na żywo.</p><br clear="all" />


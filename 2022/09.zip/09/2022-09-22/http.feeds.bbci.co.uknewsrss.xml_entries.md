# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Five things to take to university - and one to avoid
 - [https://www.bbc.co.uk/news/education-58545266?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-58545266?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 23:45:10+00:00

Brighten up your accommodation, make friends and save on costs with these handy items.

## Subway murder sparks fury over South Korea’s stalking laws
 - [https://www.bbc.co.uk/news/world-asia-62998084?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62998084?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 23:19:43+00:00

The shocking attack on a young woman in a toilet sparks fury over the nation's weak anti-stalking laws.

## Robert Page: Manager hails Wales character before must-win Poland game
 - [https://www.bbc.co.uk/sport/football/63003275?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63003275?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 23:18:53+00:00

Wales manager Robert Page praises his side's character after a battling 2-1 defeat in Belgium sets up a must-win game against Poland on Sunday.

## Africa Eye: One man's search for a new life in Europe
 - [https://www.bbc.co.uk/news/world-africa-63000822?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-63000822?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 23:16:35+00:00

Africa Eye investigates the struggles facing illegal migrants between Nigeria and Europe.

## Brazil election: Bolsonaro and Lula dance and cry
 - [https://www.bbc.co.uk/news/world-latin-america-62800264?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-62800264?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 23:15:10+00:00

Brazil presidential hopefuls step up their social media campaigns with dancing, crying and celebrity endorsements.

## Queen Elizabeth II leaves complex legacy for Aboriginal Australians
 - [https://www.bbc.co.uk/news/world-australia-62922864?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-62922864?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 23:11:00+00:00

Some are grappling with how to celebrate her life while also acknowledging trauma from colonisation.

## The Papers: 'UK heads into recession' and 'tax cut bonanza'
 - [https://www.bbc.co.uk/news/blogs-the-papers-63003162?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-63003162?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 23:10:16+00:00

A difficult economic outlook faces the UK and the government's plans to cut taxes lead the front pages.

## Bosses think workers do less from home, says Microsoft
 - [https://www.bbc.co.uk/news/business-62980639?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62980639?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 23:06:38+00:00

A new survey from Microsoft suggests that workers and bosses disagree about productivity.

## Ukraine war: 'What's happening in Russia now is total fear'
 - [https://www.bbc.co.uk/news/world-europe-63000034?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63000034?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 23:06:22+00:00

In Lithuania, Russians opposing Vladimir Putin's war say their home country is "like a huge prison".

## Are Mar-a-Lago and other Trump-owned properties over-valued?
 - [https://www.bbc.co.uk/news/world-us-canada-62990041?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62990041?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 22:42:36+00:00

A closer look at the former president's real estate, and allegations he lied about its value.

## Iran headscarf: Raisi says police custody death must be investigated
 - [https://www.bbc.co.uk/news/world-middle-east-63003344?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63003344?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 22:35:32+00:00

The death of a woman who allegedly broke headscarf rules sparks the worst unrest in recent years.

## Dozens of migrants killed as boat sinks off Syrian coast
 - [https://www.bbc.co.uk/news/world-middle-east-63003384?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63003384?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 21:51:57+00:00

The boats carrying more than 100 people had set off from near the Lebanese port city of Tripoli.

## Church of England bars Desmond Tutu's daughter from leading funeral
 - [https://www.bbc.co.uk/news/uk-63003282?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63003282?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 21:51:07+00:00

The Church of England would not allow her to take the funeral because she is married to a woman.

## Hurricane Fiona: 'The important thing is we're alive'
 - [https://www.bbc.co.uk/news/world-us-canada-63003336?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63003336?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 21:36:08+00:00

Now a Category 4 storm, Hurricane Fiona has wrecked parts of Puerto Rico and the Dominican Republic.

## Nations League 2022: Kevin De Bruyne inspires Belgium to victory over Wales
 - [https://www.bbc.co.uk/sport/football/62910381?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62910381?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 20:41:00+00:00

Kevin de Bruyne stars as Belgium withstand a spirited fightback from Wales to leave them teetering on the brink of relegation in the Nations League.

## Gareth Southgate: 'Not a lot more' England players can do but discuss key issues
 - [https://www.bbc.co.uk/sport/football/62988523?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62988523?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 20:16:58+00:00

Gareth Southgate says England's players cannot do much more but discuss human rights issues in the build-up to the World Cup in Qatar.

## England in Pakistan: Babar Azam and Mohammad Rizwan steer Pakistan to incredible 10-wicket win
 - [https://www.bbc.co.uk/sport/cricket/62998630?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62998630?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 18:34:01+00:00

Babar Azam hits 110 not out and Mohammad Rizwan an unbeaten 88 as Pakistan pull off a remarkable 10-wicket victory over England.

## Child heard crying as mobilised Russian men leave to fight
 - [https://www.bbc.co.uk/news/world-europe-63002654?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63002654?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 18:33:34+00:00

A child can be heard crying 'Daddy, goodbye' in a video shared on Russian social media

## Iran: CNN cancels interview with Iranian president over headscarf demand
 - [https://www.bbc.co.uk/news/world-middle-east-63000854?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63000854?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 18:13:00+00:00

Christiane Amanpour refuses to cover her hair for an interview with Iran's leader in New York.

## Leicester disorder: Independent review to be held
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-62997119?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-62997119?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 17:38:20+00:00

A total of 47 people have been arrested following unrest in the city over the past few weeks.

## Ukraine war: US says it takes Putin nuclear threat seriously
 - [https://www.bbc.co.uk/news/world-us-canada-63000444?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63000444?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 17:25:12+00:00

Russia is "irresponsible" to threaten using nuclear weapons in Ukraine, a top US official tells the BBC.

## Ukraine war: Mum of Aiden Aslin thought son's release 'would never happen'
 - [https://www.bbc.co.uk/news/uk-62998902?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62998902?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 17:11:35+00:00

Aiden Aslin is now looking to rebuild his life with his fiancée after they were reunited, his mum says.

## Tesla ordered to recall more than a million US cars
 - [https://www.bbc.co.uk/news/technology-62996103?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62996103?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 17:05:15+00:00

The US car-safety watchdog says a window glitch is affecting all four Tesla models.

## ECB proposals equally unworkable as current schedule in county cricket, says Sussex chief
 - [https://www.bbc.co.uk/sport/cricket/62999460?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62999460?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 17:00:19+00:00

The chair of Sussex County Cricket Club Jon Filby says the English game's current schedule is "unworkable" but proposed changes are "equally unworkable".

## Watchdog urged to investigate £120m 'Festival of Brexit'
 - [https://www.bbc.co.uk/news/entertainment-arts-62658750?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62658750?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 17:00:15+00:00

The chair of an influential parliamentary committee asks the UK spending watchdog to probe Unboxed.

## Stamp duty: What is it and how much do I pay?
 - [https://www.bbc.co.uk/news/business-53319433?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-53319433?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 16:59:05+00:00

What are the stamp duty rules across the UK?

## Former I’m a Celebrity stars to return for all-stars series in South Africa
 - [https://www.bbc.co.uk/news/entertainment-arts-62996147?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62996147?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 16:44:05+00:00

Some of the reality-TV show's former contestants will compete in an "all-stars" series next year.

## Queen Elizabeth II statue in Trafalgar Square gets MPs' support
 - [https://www.bbc.co.uk/news/uk-england-london-62995442?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62995442?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 16:15:15+00:00

Calls for Her Majesty to be honoured on the Fourth Plinth are met with support in the Commons.

## Quiz of the week: Which planet did James Webb telescope capture?
 - [https://www.bbc.co.uk/news/world-62989261?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-62989261?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 15:17:25+00:00

How closely have you been paying attention to what's been going on over the past seven days?

## National Insurance rise to be reversed in November
 - [https://www.bbc.co.uk/news/business-62998661?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62998661?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 14:41:08+00:00

The 1.25% rise will be reversed from 6 November and a levy to fund health and social care will be axed.

## Rail strikes: New date set for 40,000 workers to walk out
 - [https://www.bbc.co.uk/news/business-62999136?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62999136?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 14:35:53+00:00

It is the latest walkout in a long-running dispute over pay, jobs and conditions.

## Iran: Mahsa Amini's father accuses authorities of a cover-up
 - [https://www.bbc.co.uk/news/world-middle-east-62998231?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-62998231?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 14:24:19+00:00

Iranian officials are covering up how a young woman died in police custody, her father tells the BBC.

## Ukraine war: 'I will break my arm, my leg... anything to avoid the draft'
 - [https://www.bbc.co.uk/news/world-europe-62992365?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62992365?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 14:19:00+00:00

Russian men explain how they are trying to resist Vladimir Putin's call-up of 300,000 military reservists.

## County Championship: Surrey beat Yorkshire by 10 wickets to win title
 - [https://www.bbc.co.uk/sport/cricket/62988999?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62988999?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 14:09:19+00:00

Surrey win the County Championship for the first time since 2018 - their 20th outright title - as they beat Yorkshire at The Oval.

## National Insurance: Will tax changes save me money?
 - [https://www.bbc.co.uk/news/uk-politics-58436009?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-58436009?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 14:07:45+00:00

The government has confirmed it will reverse the 1.25p increase in National Insurance.

## £500m funding to help hospitals discharge patients
 - [https://www.bbc.co.uk/news/health-62998146?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-62998146?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 13:54:50+00:00

The money is part of a package of measures to support NHS and care system this winter, ministers say.

## Ukraine war: Russians flee to border after military call-up
 - [https://www.bbc.co.uk/news/world-europe-62996212?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62996212?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 12:48:27+00:00

Georgia's border sees large queues after flights sell out as some fighting-age men flee Russia.

## MLB: Felix White prepares for BBC commentary on New York Yankees v Boston Red Sox
 - [https://www.bbc.co.uk/sport/av/baseball/62996346?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/baseball/62996346?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 12:42:45+00:00

Tailenders' podcaster Felix White trades cricket for baseball as he visits Fenway Park to prepare to commentate on New York Yankees v Boston Red Sox live on the BBC this Saturday,

## England v Italy: Gareth Southgate's squad dilemmas in statistics
 - [https://www.bbc.co.uk/sport/football/62877990?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62877990?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 12:29:01+00:00

Harry Maguire's form, reliance on Harry Kane's goals, Trent Alexander-Arnold's selection - what the stats say about England coach Gareth Southgate's selection dilemmas.

## William and Kate thank funeral volunteers in Windsor
 - [https://www.bbc.co.uk/news/uk-62995240?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62995240?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 12:26:10+00:00

The Prince and Princess of Wales make their first public appearance since the Queen's funeral.

## Iran police battle protesters in Tehran as unrest over woman's death spirals
 - [https://www.bbc.co.uk/news/world-middle-east-62994003?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-62994003?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 12:22:25+00:00

The unrest, now in its seventh day, was sparked by the death of a woman detained by morality police.

## Jacob Rees-Mogg faces Tory anger over plan to buy local fracking support
 - [https://www.bbc.co.uk/news/uk-politics-62993487?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62993487?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 12:15:44+00:00

Jacob-Rees Mogg faces a backlash from MPs in areas of England where fracking could cause disruption.

## What is a recession and how could it affect me?
 - [https://www.bbc.co.uk/news/business-52986863?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-52986863?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 12:13:20+00:00

The Bank of England has forecasted that the UK economy is already in recession - what does that mean?

## Ashfield councillor guilty of harassing neighbours in hot tub row
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-62985587?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-62985587?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 12:05:20+00:00

Tom Hollis is found guilty of harassment following a dispute with neighbours over Covid rules.

## Roger Federer to team up with Rafael Nadal for final match in Laver Cup doubles
 - [https://www.bbc.co.uk/sport/tennis/62994642?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62994642?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 11:40:22+00:00

Roger Federer's final match will see him play alongside old rival Rafael Nadal in the Laver Cup doubles on Friday.

## Bank of England says UK may already be in recession
 - [https://www.bbc.co.uk/news/business-62991376?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62991376?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 11:35:11+00:00

The warning comes as the Bank raises interest rates to 2.25% - the highest level for 14 years.

## Pret a Manger customer had fatal reaction to 'vegan' wrap
 - [https://www.bbc.co.uk/news/uk-england-wiltshire-62995578?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-wiltshire-62995578?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 11:29:49+00:00

Celia Marsh had a severe dairy allergy and ate food labelled as vegan that had traces of milk in it.

## Channel migrants: More than 30,000 cross in small boats this year
 - [https://www.bbc.co.uk/news/uk-england-kent-62987683?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-62987683?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 11:15:28+00:00

Among the latest arrivals at Dungeness in Kent were children wrapped up in blankets.

## Author Jodi Picoult stages The Book Thief musical as a 'cautionary tale'
 - [https://www.bbc.co.uk/news/entertainment-arts-62881338?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62881338?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 11:07:32+00:00

Best-selling US author Jodi Picoult relocates to the UK to stage a musical version of The Book Thief.

## Ukraine war: Britons held by Russian forces reunite with family
 - [https://www.bbc.co.uk/news/uk-62991589?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62991589?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 10:19:56+00:00

The five UK nationals arrive back in the UK after Saudi Arabia brokered their release.

## Molly Russell inquest: Social media key to 14-year-old's death, dad says
 - [https://www.bbc.co.uk/news/uk-england-london-62991510?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62991510?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 10:17:14+00:00

The 14-year-old girl viewed material about self-harm and suicide before she died in 2017.

## Heating oil: Tory MPs worried about off-grid energy support
 - [https://www.bbc.co.uk/news/uk-politics-62989499?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62989499?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 10:13:43+00:00

Some argue an extra payment of £100 is not enough support for households who use heating oil.

## County Championship games could be reduced under ECB plans
 - [https://www.bbc.co.uk/sport/cricket/62985372?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62985372?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 10:00:10+00:00

The number of County Championship matches could be cut from 14 to 10 with a smaller First Division of six teams under new ECB proposals.

## Census 2021: More from Catholic background in NI than Protestant
 - [https://www.bbc.co.uk/news/uk-northern-ireland-62980394?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-62980394?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 09:35:39+00:00

For the first time there are more people from a Catholic background (45.7%) than Protestant (43.48%) in NI.

## Football disorder in England and Wales reaches eight-year high - Home Office
 - [https://www.bbc.co.uk/sport/football/62989792?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62989792?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 09:32:26+00:00

Arrests and reported incidents of disorder at football matches in England and Wales last season were at their highest level for eight years.

## Israel: Is this an ultra-Orthodox MeToo moment?
 - [https://www.bbc.co.uk/news/world-middle-east-62984847?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-62984847?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 09:30:45+00:00

Victims of sexual abuse within Israel's haredi community tell of their struggle to bring their abusers to justice.

## Huddersfield stabbing: Murder arrest after boy, 15, killed outside school
 - [https://www.bbc.co.uk/news/uk-england-leeds-62992837?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-62992837?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 09:28:01+00:00

A 16-year-old boy was arrested in the early hours following the attack close to the school gates.

## TfL: London transport chief Andy Byford to leave role
 - [https://www.bbc.co.uk/news/uk-england-london-62986749?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62986749?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 08:47:04+00:00

Andy Byford joined Transport for London during a time when the Covid pandemic hit its finances.

## Driver leaves toy gift for man who waves at M6 traffic
 - [https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-62985430?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-62985430?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 08:44:47+00:00

The toy was left on a bridge above the M6 for Alex Chesters, who regularly waves to vehicles.

## Reading hammer throwing champion set sights on Olympics
 - [https://www.bbc.co.uk/news/uk-england-berkshire-62991477?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-berkshire-62991477?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 08:43:06+00:00

Hammer thrower Charlotte Payne, 20, is the youngest woman in the UK to throw over 70m.

## Emma Raducanu beats Yanina Wickmayer to continue run at Korea Open
 - [https://www.bbc.co.uk/sport/tennis/62991628?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62991628?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 08:26:10+00:00

Britain's Emma Raducanu beats Yanina Wickmayer 6-3 7-5 in an hour and 41 minutes to progress to the Korea Open last eight in Seoul.

## Fracking ban for shale gas lifted by government
 - [https://www.bbc.co.uk/news/science-environment-62982332?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62982332?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 08:19:48+00:00

Scientific review into fracking concludes there is still a limited understanding of impacts.

## Huddersfield school 'devastated' after pupil stabbed to death
 - [https://www.bbc.co.uk/news/uk-england-leeds-62986828?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-62986828?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 08:06:13+00:00

The 15-year-old boy was stabbed outside North Huddersfield Trust School on Wednesday afternoon.

## Tom Hollis: Hot tub row councillor denies bullying neighbours
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-62985585?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-62985585?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 07:39:48+00:00

The deputy council leader is accused of falsely claiming he was threatened with a knife.

## Earthquake levels set for review to allow fracking
 - [https://www.bbc.co.uk/news/uk-politics-62990021?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-62990021?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 07:29:20+00:00

A report on the risk of fracking-linked earthquakes is due as ministers seek to boost energy supplies.

## Steve Lansdown: Bristol owner calls on Premiership Rugby to generate more revenue
 - [https://www.bbc.co.uk/sport/rugby-union/62992223?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/62992223?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 07:27:48+00:00

Bristol Bears owner Steve Lansdown says Premiership Rugby must do more to increase revenues to help financially-struggling clubs.

## Artemis: Nasa's Moon rocket completes fuelling test
 - [https://www.bbc.co.uk/news/science-environment-62982986?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62982986?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 07:25:46+00:00

The Space Launch System edges closer to a maiden flight after concluding a tanking demonstration.

## Rural areas hit harder by cost-of-living crisis, study finds
 - [https://www.bbc.co.uk/news/science-environment-62983030?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62983030?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 06:39:30+00:00

People living in the countryside face higher costs than those in urban areas, a new report finds.

## Bellator Dublin: Leah McCourt relishing Dayana Silva fight
 - [https://www.bbc.co.uk/sport/mixed-martial-arts/62808173?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/mixed-martial-arts/62808173?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 05:54:03+00:00

Leah McCourt is relishing her bout with Dayana Silva at Bellator Dublin on Friday after rediscovering her love for fighting.

## Birmingham's Commonwealth bull to leave Centenary Square
 - [https://www.bbc.co.uk/news/uk-england-birmingham-62969581?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-62969581?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 05:28:27+00:00

Thursday will be the last chance to see the 2.5-tonne creation in its current home.

## Met Police failing in areas of its work, inspectors say
 - [https://www.bbc.co.uk/news/uk-england-london-62983924?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62983924?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 05:25:01+00:00

A police watchdog says the way the Met responds to the public is inadequate and must improve.

## James Bond actor Daniel Craig sends message to 3 Dads Walking
 - [https://www.bbc.co.uk/news/uk-england-62989271?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-62989271?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 05:20:37+00:00

Daniel Craig backs three fathers who lost daughters to suicide ahead of their latest challenge.

## Roger Federer retires: Swiss great played tennis with a balletic grace beyond modern compare
 - [https://www.bbc.co.uk/sport/tennis/62985363?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62985363?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 05:07:12+00:00

The tennis Roger Federer played may not have been relatable, but his warm and emotional character certainly was, writes BBC tennis correspondent Russell Fuller.

## Sri Lanka: Inflation rate jumps to 70.2% in August
 - [https://www.bbc.co.uk/news/business-62990385?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62990385?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 03:48:13+00:00

The South Asian nation is facing its worst economic crisis since independence from the UK in 1948.

## Beer spill truck crash closes Florida highway
 - [https://www.bbc.co.uk/news/world-us-canada-62990366?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62990366?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 03:40:37+00:00

A crash involving five semi-trailers caused thousands of cans of beer to spill across the road.

## Ukraine war: Zelensky calls for 'just punishment' for Russia
 - [https://www.bbc.co.uk/news/world-europe-62990141?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62990141?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 00:32:15+00:00

In an impassioned UN speech, the Ukrainian leader calls for the creation of a special war tribunal.

## NHS: I will make it easier to see GP, promises Coffey
 - [https://www.bbc.co.uk/news/health-62987823?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-62987823?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-22 00:06:16+00:00

The health secretary unveils plans to boost access - but doctors say they will have minimal impact.


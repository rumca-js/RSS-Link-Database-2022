# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Study of large incel internet forum raises alarms about its growth
 - [https://www.washingtonpost.com/technology/2022/09/22/incels-rape-murder-study/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/09/22/incels-rape-murder-study/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-22 19:00:00+00:00

More than 2.6 million visit the incel forum each month, where their posts often endorse rape and mass murder, according to the Center for Countering Digital Hate.

## Outside audit says Facebook restricted Palestinian posts during Gaza war
 - [https://www.washingtonpost.com/technology/2022/09/22/facebook-censorship-palestinians/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/09/22/facebook-censorship-palestinians/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-22 18:42:11+00:00

An independent audit of Meta’s handling of online content during the two-week war between Israel and the militant Palestinian group Hamas last year found that the social media giant had denied Palestinian users their freedom of expression by erroneously removing their content and punished Arabic-speaking users more heavily than Hebrew-speaking ones.

## Jan. 6 Twitter witness: Failure to curb Trump spurred ‘terrifying’ choice
 - [https://www.washingtonpost.com/technology/2022/09/22/jan6-committee-twitter-witness-navaroli/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/09/22/jan6-committee-twitter-witness-navaroli/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-22 17:35:00+00:00

The whistleblower, who spoke exclusively with The Washington Post, said Twitter's complacency toward then-President Donald Trump led to disastrous consequences.

## Video game YouTuber Dunkey launches indie game publisher Bigmode
 - [https://www.washingtonpost.com/video-games/2022/09/22/dunkey-youtube-bigmode-indie-publisher/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2022/09/22/dunkey-youtube-bigmode-indie-publisher/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-22 17:25:51+00:00

In a debut video, Dunkey said he wanted to make good games instead of waiting for them. But some in the space questioned his lack of experience.

## The ‘Omega Strikers’ pitch is ‘gladiator hockey.’ That’s just the start.
 - [https://www.washingtonpost.com/video-games/2022/09/22/omega-strikers-interview/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2022/09/22/omega-strikers-interview/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-22 12:37:32+00:00

'Omega Strikers' is a 3v3 sports brawler from Odyssey Interactive that's aiming to be the most accessible and watchable game in the market.

## Book bans are surging but online access tries to fill the void
 - [https://www.washingtonpost.com/technology/2022/09/22/books-banned-libraries/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/09/22/books-banned-libraries/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-22 10:13:05+00:00

Books are being banned across United States school libraries in record numbers, led largely by conservative lawmakers and activists.

## Health apps share your concerns with advertisers. HIPAA can’t stop it.
 - [https://www.washingtonpost.com/technology/2022/09/22/health-apps-privacy/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/09/22/health-apps-privacy/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-22 07:00:37+00:00

We examined the privacy practices of popular health apps including Drugs.com, WebMD, K Health, HealthTap and Period Calendar.

## Inside the civil rights campaign to get Big Tech to fight the ‘big lie’
 - [https://www.washingtonpost.com/technology/2022/09/22/midterms-elections-social-media-civil-rights/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/09/22/midterms-elections-social-media-civil-rights/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-22 07:00:22+00:00

For months, the Change the Terms coalition pleaded with Meta, Twitter, TikTok and YouTube to bolster its content moderation systems.

## Inside crypto’s house of cards
 - [https://www.washingtonpost.com/technology/interactive/2022/crypto-exchange-bitcoin-history/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/interactive/2022/crypto-exchange-bitcoin-history/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-22 06:30:45+00:00

The wild beginnings, crazy turns, colorful characters and multiple comebacks of crypto.

## Biotech aims to detect cancer early. But tests have a long way to go.
 - [https://www.washingtonpost.com/technology/2022/09/22/early-detection-cancer-tests-biden-cancer-moonshot/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/09/22/early-detection-cancer-tests-biden-cancer-moonshot/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-09-22 06:00:24+00:00

President Biden said he wants to foster research on early-cancer-detection blood tests through his cancer “moonshot” initiative.


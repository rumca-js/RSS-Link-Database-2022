# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## GM stops taking reservations for Hummer EV
 - [https://www.cnn.com/2022/09/22/business/gm-hummer-ev/index.html](https://www.cnn.com/2022/09/22/business/gm-hummer-ev/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 21:44:59+00:00

There's a lot of buyer interest in the electric Hummer now being offered by Chevrolet. But there's limited capacity to build them, and now General Motors has stopped taking orders for the massive EV.

## Japan to reopen to mass tourism in October
 - [https://www.cnn.com/travel/article/japan-reopening-border-tourists/index.html](https://www.cnn.com/travel/article/japan-reopening-border-tourists/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 20:46:27+00:00

Japan, one of the world's last major holdouts during the pandemic, is dissolving its Covid-19 restrictions and opening the door back up to mass tourism.

## ISIS attempts suicide attack on al-Hol camp in Syria
 - [https://www.cnn.com/2022/09/22/politics/isis-attempts-suicide-attack-syria/index.html](https://www.cnn.com/2022/09/22/politics/isis-attempts-suicide-attack-syria/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 19:01:47+00:00

A group of ISIS militants in two vehicles rigged with suicide explosives attempted to attack the al-Hol camp in Syria which holds around 60,000 displaced persons, according to US Central Command.

## Why Jamie Dimon apologized to Elizabeth Warren
 - [https://www.cnn.com/2022/09/22/economy/bank-ceos-testify-senate/index.html](https://www.cnn.com/2022/09/22/economy/bank-ceos-testify-senate/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 18:56:18+00:00

JPMorgan CEO Jamie Dimon is testifying on Capitol Hill Thursday for the second straight day. This time, he'll face longtime critic, Sen. Elizabeth Warren.

## Why it's getting even harder to rent or buy a home
 - [https://www.cnn.com/2022/09/22/homes/housing-affordability/index.html](https://www.cnn.com/2022/09/22/homes/housing-affordability/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 18:43:32+00:00

Americans looking to buy or rent a home have had a rough year.

## Iran's President abandons CNN interview after Amanpour declines head scarf demand
 - [https://www.cnn.com/2022/09/22/middleeast/iran-president-ebrahim-raisi-christiane-amanpour-intl/index.html](https://www.cnn.com/2022/09/22/middleeast/iran-president-ebrahim-raisi-christiane-amanpour-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 15:51:23+00:00

Iranian President Ebrahim Raisi withdrew from a long-planned interview with CNN's chief international anchor Christiane Amanpour at the United Nations General Assembly in New York on Wednesday, after she declined a last-minute demand to wear a head scarf.

## Mortgage rates rise to nearly 6.3%, the highest since 2008
 - [https://www.cnn.com/2022/09/22/homes/mortgage-rates-september-22/index.html](https://www.cnn.com/2022/09/22/homes/mortgage-rates-september-22/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 15:30:26+00:00

Mortgage rates jumped higher for the fifth week in a row, further pushing past 6% in the face of yet another aggressive rate hike from the Federal Reserve.

## One-year-old dies as 11 more suspected Ebola cases identified in Uganda
 - [https://www.cnn.com/2022/09/22/africa/suspected-ebola-cases-uganda-intl/index.html](https://www.cnn.com/2022/09/22/africa/suspected-ebola-cases-uganda-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 12:04:46+00:00

Uganda's Ministry of Health reported another 11 suspected cases of Ebola identified in the country's Mubende district as of Tuesday. Of these, the ministry recorded one probable Ebola-related death, a one-year-old, it said in a statement released Tuesday night.

## Nigeria's Buhari, in last UN speech, slams 'corrosive impact' of leaders who cling to power
 - [https://www.cnn.com/2022/09/22/africa/buhari-term-limits-speech-intl/index.html](https://www.cnn.com/2022/09/22/africa/buhari-term-limits-speech-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 11:56:20+00:00

Nigeria's President Muhammadu Buhari on Wednesday criticized fellow leaders who extend term limits to cling to power, saying this was having a "corrosive" effect, and promised free and fair elections when the country elects his successor in February.

## Opinion: The political charmer who repacked Italy's far-right
 - [https://www.cnn.com/2022/09/22/opinions/giorgia-meloni-italian-election-opinion-galietti/index.html](https://www.cnn.com/2022/09/22/opinions/giorgia-meloni-italian-election-opinion-galietti/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 07:30:27+00:00

I am often asked what Giorgia Meloni -- leader of the national conservative Brothers of Italy party, and likely next prime minister of the country -- is really up to.

## Kia, Hyundai are easy targets for thieves, insurance data confirms
 - [https://www.cnn.com/2022/09/22/business/hldi-hyundai-kia-theft/index.html](https://www.cnn.com/2022/09/22/business/hldi-hyundai-kia-theft/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 04:10:08+00:00

Stealing older model Hyundai and Kia cars and SUVs became a scary social media trend. Now, data from the Highway Loss Data Institute, which collects information on insurance claims, confirm these South Korean models are far more likely to get stolen than others.

## 200 whales dead, 35 remain alive after mass stranding in Australia
 - [https://www.cnn.com/2022/09/21/world/tasmania-australia-mass-whale-stranding-deaths-intl-hnk/index.html](https://www.cnn.com/2022/09/21/world/tasmania-australia-mass-whale-stranding-deaths-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-22 03:02:02+00:00

Around 200 whales have died and just 35 remain alive following a mass stranding in Australia this week, rescue teams say.


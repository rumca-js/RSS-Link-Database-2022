# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Hang On, Bill Gates Said WHAT About Vaccines?
 - [https://www.youtube.com/watch?v=b9HZSxXfXkw](https://www.youtube.com/watch?v=b9HZSxXfXkw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-09-22 00:00:00+00:00

BIG ANNOUNCEMENT + With Joe Biden’s announcement that the pandemic is “over” and vaccine makers stock price plummeting as a result, how will they respond - cos they don’t really care about profit, do they? #covid #vaccines #pandemic 

References
https://www.ft.com/content/c6fcbde9-9575-4c9c-a6eb-2c8796c2c5cb
https://www.science.org/content/article/omicron-booster-shots-are-coming-lots-questions
https://www.commonsense.news/p/us-public-health-agencies-arent-following
https://www.telegraph.co.uk/politics/2020/06/09/school-age-children-likely-hit-lightning-die-coronavirus-oxbridge/
https://www.wsj.com/articles/the-high-cost-of-disparaging-natural-immunity-to-covid-vaccine-mandates-protests-fire-rehire-employment-11643214336
https://www.statnews.com/2022/09/06/pfizer-covid-vaccines-researchers-next-gen-studies/
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


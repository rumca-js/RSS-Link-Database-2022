# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Gay Rights Organization Gets Deplatformed By PayPal While Pro-Pedophile Group Remains
 - [https://www.dailywire.com/news/gay-rights-organization-gets-deplatformed-by-paypal-while-pro-pedophile-group-remains](https://www.dailywire.com/news/gay-rights-organization-gets-deplatformed-by-paypal-while-pro-pedophile-group-remains)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 22:36:27+00:00

A gay rights organization was deplatformed by PayPal and its subsidiary Venmo, only to discover on Thursday that pro-pedophile organization Prostasia continues to be on good business terms with the multinational financial technology company. Gays Against Groomers, an organization comprised entirely of gay, lesbian, bisexual, and even transgender people, launched in 2022 and has had ...

## McCarthy Unveils New ‘Commitment To America’ Agenda That GOP Will Pursue If They Retake House
 - [https://www.dailywire.com/news/mccarthy-unveils-new-commitment-to-america-agenda-that-gop-will-pursue-if-they-retake-house](https://www.dailywire.com/news/mccarthy-unveils-new-commitment-to-america-agenda-that-gop-will-pursue-if-they-retake-house)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 22:06:29+00:00

House Minority Leader Kevin McCarthy (R-CA) rolled out a new agenda for House Republicans that he said the conference will pursue should they retake control of the chamber after the midterm elections in November. McCarthy&#8217;s new agenda, the Commitment to America, started back in 2020 when he worked for months trying to form a bipartisan ...

## ‘Ridiculous’: Rogan Torches White House Press Secretary After Doocy Asked About Her 2016 Stolen Election Claim
 - [https://www.dailywire.com/news/ridiculous-rogan-torches-white-house-press-secretary-after-doocy-asked-about-her-2016-stolen-election-claim](https://www.dailywire.com/news/ridiculous-rogan-torches-white-house-press-secretary-after-doocy-asked-about-her-2016-stolen-election-claim)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 21:39:39+00:00

Joe Rogan torched White House Press Secretary Karine Jean-Pierre over what he called a &#8220;ridiculous&#8221; answer to Fox News&#8217; Peter Doocy about her 2016 stolen election claim. During Spotify&#8217;s &#8220;The Joe Rogan Experience&#8221; podcast on Tuesday, the host was speaking with stand-up comedians Tony Hinchcliffe and Hans Kim about the press secretary&#8217;s &#8220;hilarious&#8221; answer to Doocy ...

## Trudeau Comes To The ‘Help’ Of American Women In Getting Them Access To Abortion
 - [https://www.dailywire.com/news/trudeau-comes-to-the-help-of-american-women-in-getting-them-access-to-abortion](https://www.dailywire.com/news/trudeau-comes-to-the-help-of-american-women-in-getting-them-access-to-abortion)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 19:44:11+00:00

Canadian Prime Minister Justin Trudeau wants to assist American women in accessing abortion. &#8220;In Canada, we support unequivocally women&#8217;s right to choose. It is a fundamental tenet of freedom,&#8221; Trudeau said. “[It] is a fundamental tenet of our society. We stand up for women’s rights.” &#8220;As we see in the United States attempts to roll ...

## ‘We Simply Have To Step Back’: The Realist Approach To War In Ukraine And America’s European Allies
 - [https://www.dailywire.com/news/we-simply-have-to-step-back-the-realist-approach-to-war-in-ukraine-and-americas-european-allies](https://www.dailywire.com/news/we-simply-have-to-step-back-the-realist-approach-to-war-in-ukraine-and-americas-european-allies)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 19:35:58+00:00

Russian troops have retreated amidst a successful Ukrainian counteroffensive in recent weeks, but the brutal war drags on toward winter with no end in sight. As they defend their homeland, the Ukrainians rely on billions of dollars in U.S. assistance as European powers balance supporting President Volodymyr Zelensky while also facing an energy crisis made ...

## DeSantis Takes New Action To Combat Influence Of China, Other Hostile Nations In Florida
 - [https://www.dailywire.com/news/desantis-takes-new-action-to-combat-influence-of-china-other-hostile-nations-in-florida](https://www.dailywire.com/news/desantis-takes-new-action-to-combat-influence-of-china-other-hostile-nations-in-florida)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 19:35:11+00:00

Florida Governor Ron DeSantis (R) announced new executive actions and legislative proposals on Thursday aimed at combatting the influence of China and other hostile foreign nations in the state. The new actions from DeSantis are aimed at addressing threats posed by China, Cuba, Russia, Iran, North Korea, Syria, and Venezuela in cyberspace, real estate, and academia. ...

## Sharon Osbourne Reveals What She Wanted To Say When Co-Hosts Accused Her Of Racism On The Air
 - [https://www.dailywire.com/news/sharon-osbourne-reveals-what-she-wanted-to-say-when-co-hosts-accused-her-of-racism-on-the-air](https://www.dailywire.com/news/sharon-osbourne-reveals-what-she-wanted-to-say-when-co-hosts-accused-her-of-racism-on-the-air)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 19:01:00+00:00

Sharon Osbourne, formerly of CBS&#8217; &#8220;The Talk,&#8221; revealed in a new Fox Nation special what she really wanted to say when her co-hosts accused her of racism during a live broadcast. The special, titled &#8220;Sharon Osbourne: To Hell &amp; Back,&#8221; is set to premiere on the streaming service on September 26 — and it follows ...

## GOP Senators Press FDA On Puberty Blocker Risks After Matt Walsh Exposes Vanderbilt Transgender Clinic
 - [https://www.dailywire.com/news/gop-senators-press-fda-on-puberty-blocker-risks-after-matt-walsh-exposes-vanderbilt-transgender-clinic](https://www.dailywire.com/news/gop-senators-press-fda-on-puberty-blocker-risks-after-matt-walsh-exposes-vanderbilt-transgender-clinic)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 18:47:00+00:00

Two GOP senators are pressing the FDA to provide data on the effects of a puberty-inhibiting drug recently warned about by some medical experts. GOP Sens. Marsha Blackburn of Tennessee and Cynthia Lummis of Wyoming wrote a letter to FDA Commissioner Robert Califf on Thursday about the side-effects of gonadotropin-releasing hormone (GnRH) agonists, which are ...

## Here’s Why James Webb Telescope Discoveries Are Causing Scientists To Rethink Galaxy Formation
 - [https://www.dailywire.com/news/heres-why-james-webb-telescope-discoveries-are-causing-scientists-to-rethink-galaxy-formation](https://www.dailywire.com/news/heres-why-james-webb-telescope-discoveries-are-causing-scientists-to-rethink-galaxy-formation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 18:24:45+00:00

Theories about the origin of the universe inevitably raise profound questions. So when science writer and independent physics researcher Eric Lerner reported that NASA’s new James Webb Space Telescope (JWST) had collected images disproving the widely-accepted Big Bang theory, the ensuing media excitement was perhaps understandable. Writing in a journal published by the British Institute ...

## MIDTERM EXAM: All The Latest On The 2022 Elections (Part II)
 - [https://www.dailywire.com/news/midterm-exam-all-the-latest-on-the-2022-elections-part-ii](https://www.dailywire.com/news/midterm-exam-all-the-latest-on-the-2022-elections-part-ii)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 18:24:16+00:00

Happy Thursday. This week&#8217;s first exam can be read here. These are just minor tidbits from the campaign trail. If there is a major story we don’t have covered in this exam, it can likely be found here. Let&#8217;s get started. Tim Ryan Sucks Up To &#8216;Future Boss&#8217; Chuck Schumer Representative Tim Ryan (D-OH) made it ...

## California Announces Office Of Gun Violence Prevention
 - [https://www.dailywire.com/news/california-announces-office-of-gun-violence-prevention](https://www.dailywire.com/news/california-announces-office-of-gun-violence-prevention)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 18:10:19+00:00

California’s Democratic Attorney General Rob Bonta announced the Office of Gun Violence Prevention (OGVP) on Wednesday, making California the first state to establish such a group. “This moment of crisis demands more than thoughts and prayers — we need action now,” Bonta said in a press release. “That is why as California Attorney General, I am doubling ...

## READ IT: Newspaper Ad Trolls Martha’s Vineyard Residents Who Sent Migrants Packing
 - [https://www.dailywire.com/news/read-it-newspaper-ad-trolls-marthas-vineyard-residents-who-sent-migrants-packing](https://www.dailywire.com/news/read-it-newspaper-ad-trolls-marthas-vineyard-residents-who-sent-migrants-packing)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 18:05:15+00:00

A Florida-based conservative nonprofit known for trolling liberals took out a newspaper ad to mock residents of Martha’s Vineyard who sent 50 migrants packing after they were dropped off on the idyllic island on orders of Sunshine State Governor Ron DeSantis. The ad, run in the Providence Journal, a major Rhode Island daily newspaper, channels ...

## One Of Baseball’s Most Hallowed Records Is About To Fall. Do Fans Even Care?
 - [https://www.dailywire.com/news/one-of-baseballs-most-hallowed-records-is-about-to-fall-do-fans-even-care](https://www.dailywire.com/news/one-of-baseballs-most-hallowed-records-is-about-to-fall-do-fans-even-care)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 17:36:54+00:00

Yankees right fielder Aaron Judge is having arguably the greatest offensive season in baseball history. As of this writing, he leads major league baseball in home runs, RBIs, runs, on-base percentage, slugging percentage, OPS, OPS+, and WAR, and he leads the American League in batting average and walks. Judge is a lock to break Roger ...

## Question: If Joe Biden Were Your Dad, Would You Let Him Live On His Own?
 - [https://www.dailywire.com/news/question-if-joe-biden-were-your-dad-would-you-let-him-live-on-his-own](https://www.dailywire.com/news/question-if-joe-biden-were-your-dad-would-you-let-him-live-on-his-own)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 17:27:42+00:00

Serious question: If President Joe Biden were your dad, would you let him live on his own? Or would you start having conversations with your siblings about putting him in a retirement home? At the very least, you would likely discuss hiring a part-time caretaker because it is apparent that the president isn&#8217;t quite all ...

## Liberal Critics Furious Over Talking Baby Abortion Scene In Marilyn Monroe Biopic, ‘Blonde’
 - [https://www.dailywire.com/news/liberal-critics-furious-over-talking-baby-abortion-scene-in-marilyn-monroe-biopic-blonde](https://www.dailywire.com/news/liberal-critics-furious-over-talking-baby-abortion-scene-in-marilyn-monroe-biopic-blonde)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 16:55:34+00:00

Liberal critics are furious that the new historical psychological drama “Blonde,” based on the life of Marilyn Monroe, makes an effort to depict the humanity of unborn babies and the violence of abortion. The movie was directed by Andrew Dominik and apparently took more than a decade to finish. It got slapped with an NC-17 ...

## French President Unveils Massive Green Power Development Proposal As Energy Crisis Continues
 - [https://www.dailywire.com/news/french-president-unveils-massive-green-power-development-proposal-as-energy-crisis-continues](https://www.dailywire.com/news/french-president-unveils-massive-green-power-development-proposal-as-energy-crisis-continues)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 16:52:41+00:00

French President Emmanuel Macron called on Thursday for a “massive” increase in renewable energy development. Russia stopped natural gas flow through the Nord Stream 1 pipeline earlier this month in an apparent retaliation against Western Europe for supporting Ukraine. Macron asserted that turmoil from rising power prices is evidence that his nation ought to become ...

## Kanye West Says He ‘Absolutely’ Sees Politics In His Future Plans
 - [https://www.dailywire.com/news/kanye-west-says-he-absolutely-sees-politics-in-his-future-plans](https://www.dailywire.com/news/kanye-west-says-he-absolutely-sees-politics-in-his-future-plans)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 16:44:20+00:00

Kanye West definitely got everyone&#8217;s attention Thursday when he announced that he &#8220;absolutely&#8221; sees politics in his future plans — following his brief presidential run in 2020. During the 45-year-old rapper&#8217;s interview with &#8220;Good Morning America,&#8221; West was asked whether he had &#8220;future political aspirations&#8221; after running for president in the 2020 election against then-President ...

## Here’s What The Federal Reserve’s Recent Rate Hike Means For The Economy
 - [https://www.dailywire.com/news/heres-what-the-federal-reserves-recent-rate-hike-means-for-the-economy](https://www.dailywire.com/news/heres-what-the-federal-reserves-recent-rate-hike-means-for-the-economy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 16:22:23+00:00

The Federal Reserve raised the federal funds rate 0.75% on Wednesday afternoon, sending the Dow Jones falling more than 500 points. As inflation remains elevated and core inflation — the price level increase for all items except for food and energy — continues to rise, the central bank’s decision signals that officials are prioritizing a ...

## Nurse Who Publicly Supported J.K. Rowling, Targeted By Trans Activists, Faces Hearing From Canadian Medical Board
 - [https://www.dailywire.com/news/nurse-who-publicly-supported-j-k-rowling-targeted-by-trans-activists-faces-hearing-from-canadian-medical-board](https://www.dailywire.com/news/nurse-who-publicly-supported-j-k-rowling-targeted-by-trans-activists-faces-hearing-from-canadian-medical-board)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 16:10:31+00:00

A Canadian nurse who publicly supported famed “Harry Potter” author J.K. Rowling and insists that men cannot become women, is at risk of losing her job as she faces a hearing from a national medical board. As far back as November 2020, Amy Eileen Hamm, a single mother with two young sons, has faced an ...

## WATCH: Dem Rep Melts After Falsely Claiming Jan. 6 Rioters Beat Cop To Death
 - [https://www.dailywire.com/news/watch-dem-rep-melts-after-falsely-claiming-jan-6-rioters-beat-cop-to-death](https://www.dailywire.com/news/watch-dem-rep-melts-after-falsely-claiming-jan-6-rioters-beat-cop-to-death)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 16:01:51+00:00

A House Democrat insisted Wednesday that a cop was beaten to death with a fire extinguisher by January 6 rioters even though the claim has long been debunked. Rep. Mondaire Jones, (D-NY), insisted at a House Judiciary Committee meeting that Capitol Police Officer Brian Sicknick was bludgeoned by Trump supporters, a claim first reported &#8212; ...

## ‘Saturday Night Live’ Alum Says He’s ‘100 Percent Not’ Political After Being Slammed For Questioning COVID ‘Puppet Masters’
 - [https://www.dailywire.com/news/saturday-night-live-alum-says-hes-100-percent-not-political-after-being-slammed-for-questioning-covid-puppet-masters](https://www.dailywire.com/news/saturday-night-live-alum-says-hes-100-percent-not-political-after-being-slammed-for-questioning-covid-puppet-masters)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 15:49:01+00:00

&#8220;Saturday Night Live&#8221; alum Jim Breuer said he&#8217;s &#8220;100 percent not&#8221; political after being slammed for questioning what he called the COVID &#8220;puppet masters&#8221; when it comes to the vaccine. During the 55-year-old comedian&#8217;s recent appearance on &#8220;The Glenn Beck&#8221; podcast, the host asked Breuer about the &#8220;kind of price&#8221; he&#8217;s paid for being called ...

## Video: Why Does Biden Constantly Wander Around Aimlessly After Speeches?
 - [https://www.dailywire.com/news/video-why-does-biden-constantly-wander-around-aimlessly-after-speeches](https://www.dailywire.com/news/video-why-does-biden-constantly-wander-around-aimlessly-after-speeches)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 15:46:55+00:00

Why does President Joe Biden constantly wander around aimlessly after his speeches? It is perplexing, but perhaps nothing is odder about his time as commander-in-chief than his difficulty exiting stages after a public oration. On Wednesday, Biden was spotted moseying about a stage in New York City, apparently completely bewildered as to where he was ...

## She Accused Him Of Sexual Assault. Lawsuit Shows Her Allegations Were False, Yet She Continues To Defame Him On Campus
 - [https://www.dailywire.com/news/she-accused-him-of-sexual-assault-lawsuit-shows-her-allegations-were-false-yet-she-continues-to-defame-him-on-campus](https://www.dailywire.com/news/she-accused-him-of-sexual-assault-lawsuit-shows-her-allegations-were-false-yet-she-continues-to-defame-him-on-campus)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 15:43:57+00:00

In a blatant example of a school failing to protect a male student from false accusations of sexual assault, the University of Maryland-College Park (UMD) allowed an accuser and a powerful campus group to brand him a rapist even after the school determined he was not responsible, according to a lawsuit. The male student, referred ...

## High School Sophomore Dies After Suffering Traumatic Injury During Football Game
 - [https://www.dailywire.com/news/high-school-sophomore-dies-after-suffering-traumatic-injury-during-football-game](https://www.dailywire.com/news/high-school-sophomore-dies-after-suffering-traumatic-injury-during-football-game)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 15:21:01+00:00

A New Jersey high school student has died after suffering a traumatic brain injury on the field during a football game. Xavier McClain, a sophomore at Linden High School, was injured during a game that took place on September 9 against Woodbridge High School, and he died of his injuries just over a week later. ...

## ‘A Very Sick Person’: Meghan McCain Blasts Stacey Abrams’ Claim About No Fetal Heartbeat At 6 Weeks
 - [https://www.dailywire.com/news/a-very-sick-person-meghan-mccain-blasts-stacey-abrams-claim-about-no-heartbeat-at-6-weeks](https://www.dailywire.com/news/a-very-sick-person-meghan-mccain-blasts-stacey-abrams-claim-about-no-heartbeat-at-6-weeks)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 14:55:49+00:00

Meghan McCain blasted Democratic Georgia gubernatorial candidate Stacey Abrams as &#8220;a very sick person&#8221; over her claim that unborn babies have no fetal heartbeat at six weeks. The former cohost of &#8220;The View&#8221; reacted Thursday to video of Abrams telling a group of people that doctors are &#8220;faking fetal heartbeats.&#8221; &#8220;Hearing my babies heartbeats at ...

## Iranian President Scraps Interview After CNN Reporter Refuses To Wear Head Scarf
 - [https://www.dailywire.com/news/iranian-president-scraps-interview-after-cnn-reporter-refuses-to-wear-head-scarf](https://www.dailywire.com/news/iranian-president-scraps-interview-after-cnn-reporter-refuses-to-wear-head-scarf)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 14:51:42+00:00

CNN Chief International Anchor Christiane Amanpour announced on Thursday that Iranian President Ebrahim Raisi had scrapped a planned interview when she refused to put on a head scarf. Amanpour and her team had already put in hours of preparation, securing translators and lighting for what would have been Raisi&#8217;s first interview on American soil, when ...

## ‘Take Your Fetish Behind A Closed Door’: Megyn Kelly Blows Up At Canadian School For Allowing Trans Shop Teacher With Enormous Breasts Prosthetics
 - [https://www.dailywire.com/news/take-your-fetish-behind-a-closed-door-megyn-kelly-blows-up-at-canadian-school-for-allowing-trans-shop-teacher-with-enormous-breasts-prosthetics](https://www.dailywire.com/news/take-your-fetish-behind-a-closed-door-megyn-kelly-blows-up-at-canadian-school-for-allowing-trans-shop-teacher-with-enormous-breasts-prosthetics)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 14:48:22+00:00

Megyn Kelly blew up at a Canadian school for allowing a transgender educator, a biological male who identifies as a female, to have massive breasts prosthetics while teaching children. During the Sirius XM &#8220;The Megyn Kelly Show&#8221; podcast Wednesday, the host was speaking with the guys from &#8220;The Ruthless&#8221; podcast about the Ontario shop teacher. ...

## Carrie Underwood’s ‘Date Night’ Includes Shooting A Few Rounds In A Mini Skirt
 - [https://www.dailywire.com/news/carrie-underwoods-date-night-includes-shooting-a-few-rounds-in-a-mini-skirt](https://www.dailywire.com/news/carrie-underwoods-date-night-includes-shooting-a-few-rounds-in-a-mini-skirt)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 14:42:02+00:00

Country singer Carrie Underwood worked on her aim during a date night with husband Mike Fisher last week. The married couple, particularly Fisher, have been somewhat open about their conservative and Christian leanings in the past. &#8220;When [Carrie Underwood] wants to practice as part of our date night you never say no,&#8221; Fisher captioned a ...

## Police Performed A Wellness Check On A 22-Year-Old NYC Woman. They Found Body Parts In Suitcases
 - [https://www.dailywire.com/news/police-performed-a-wellness-check-on-a-22-year-old-nyc-woman-they-found-body-parts-in-suitcases](https://www.dailywire.com/news/police-performed-a-wellness-check-on-a-22-year-old-nyc-woman-they-found-body-parts-in-suitcases)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 14:35:27+00:00

New York City Police Department detectives were called to perform a wellness check on a 22-year-old woman on Wednesday afternoon, only to discover suitcases stuffed with human remains. Residents of an apartment complex in Brooklyn told administrators there was a foul smell coming from one of the apartments, telling apartment security that they hadn’t seen ...

## Biden Got It All Right In U.N. Address — Until He Got It All Wrong
 - [https://www.dailywire.com/news/biden-got-it-all-right-in-u-n-address-until-he-got-it-all-wrong](https://www.dailywire.com/news/biden-got-it-all-right-in-u-n-address-until-he-got-it-all-wrong)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 14:29:16+00:00

I&#8217;ve covered politics for 35 years, so let me tell you one thing I&#8217;ve learned: the president of the party you oppose is not always wrong. Wrong a lot, sure, does things you don&#8217;t agree with, certainly, but sometimes, that guy gets it just right. And if you&#8217;re able to take your partisan hat off ...

## Biden’s Military: Forget ‘Mom,’ ‘Dad,’ Use Woke Substitutes Instead, Air Force Cadets Told
 - [https://www.dailywire.com/news/bidens-military-forget-mom-dad-use-woke-substitutes-instead-air-force-cadets-told](https://www.dailywire.com/news/bidens-military-forget-mom-dad-use-woke-substitutes-instead-air-force-cadets-told)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 14:19:28+00:00

In yet another indication of how wokeness has permeated the American military under the Biden administration, Air Force cadets have been instructed not to use gender-specific terms like “Mom” or “Dad” and replace such terms with words such as “parent” or “caregiver.” That instruction was featured at the Air Force Academy in Colorado as part ...

## Jimmy Failla: ‘Stacey Abrams Is A Clown, And She Should Just Go Back To Writing Romance Novels’
 - [https://www.dailywire.com/news/jimmy-failla-stacey-abrams-is-a-clown-and-she-should-just-go-back-to-writing-romance-novels](https://www.dailywire.com/news/jimmy-failla-stacey-abrams-is-a-clown-and-she-should-just-go-back-to-writing-romance-novels)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 14:16:09+00:00

&#8220;Fox Across America&#8221; radio host and comedian Jimmy Failla said on Thursday that Georgia Democrat gubernatorial candidate Stacey Abrams should get out of politics and &#8220;go back to writing romance novels.&#8221; Failla made an appearance on Fox News&#8217; midday panel show &#8220;Outnumbered,&#8221; where the discussion turned to Abrams&#8217; recent claim that 6-week fetal heartbeats were &#8220;manufactured&#8221; ...

## Federal Tyrants Weaponize Law Enforcement To Destroy Trump, Create Police State
 - [https://www.dailywire.com/news/federal-tyrants-weaponize-law-enforcement-to-destroy-trump-create-police-state](https://www.dailywire.com/news/federal-tyrants-weaponize-law-enforcement-to-destroy-trump-create-police-state)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 13:32:14+00:00

The FBI was once the most trusted and respected law enforcement agency in the world. As we witness the destruction of that reputation because of their corrupt leaders bowing to the whims of tyrannical politicians, we are once again reminded of the dire effects of extreme politics on policing. In the federal government, and in ...

## ‘What Are You Doing?’: Whoopi Goldberg Kicks Off ‘The View’ By ‘Thinking’ Trump Into Jail
 - [https://www.dailywire.com/news/what-are-you-doing-whoopi-goldberg-kicks-off-the-view-by-thinking-trump-into-jail](https://www.dailywire.com/news/what-are-you-doing-whoopi-goldberg-kicks-off-the-view-by-thinking-trump-into-jail)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 13:27:15+00:00

&#8220;The View&#8221; host Whoopi Goldberg opened Thursday&#8217;s broadcast by taking a swipe at former President Donald Trump, mocking his recent claim that a sitting president could declassify documents simply by &#8220;thinking about&#8221; doing so. Goldberg, after playing a clip of the former president&#8217;s comments, paused dramatically with her eyes closed and a broad smile on ...

## ‘Biggest Coward In Baseball’: Yankees Fans Rip Pitcher Who Avoided Judge’s 61st Home Run
 - [https://www.dailywire.com/news/biggest-coward-in-baseball-yankees-fans-rip-pitcher-who-avoided-judges-61st-home-run](https://www.dailywire.com/news/biggest-coward-in-baseball-yankees-fans-rip-pitcher-who-avoided-judges-61st-home-run)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 13:21:51+00:00

New York Yankees fans blistered Pittsuburg Pirates’ pitcher Eric Stout for avoiding the possibility of giving up a record-tying home run to Yankees’ slugger Aaron Judge after Stout threw four straight pitches out of the strike zone, walking Judge on four pitches. It was clear that Judge’s at-bat against Stout would be his last of ...

## Dana Perino Issues Stark Warning About ESG Agenda, Gives Key Abortion Example
 - [https://www.dailywire.com/news/dana-perino-issues-stark-warning-about-esg-agenda-gives-key-abortion-example](https://www.dailywire.com/news/dana-perino-issues-stark-warning-about-esg-agenda-gives-key-abortion-example)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 13:04:32+00:00

Fox News host Dana Perino issued a stark warning Wednesday about the environmental, social, and governance (ESG) movement affecting corporate America and the culture more broadly. The system has been criticized as a tool to force Left-wing politics and racial and gender quotas on corporations, even at the expense of their shareholders. &#8220;ESG forces companies to ...

## ‘Strengthening Our Energy Resilience’: Britain Ends Fracking Ban, Will Become Net Exporter By 2040
 - [https://www.dailywire.com/news/strengthening-our-energy-resilience-britain-ends-fracking-ban-will-become-net-exporter-by-2040](https://www.dailywire.com/news/strengthening-our-energy-resilience-britain-ends-fracking-ban-will-become-net-exporter-by-2040)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 12:57:54+00:00

The government of the United Kingdom ended its fracking ban in a push to bolster the nation’s energy security, according to a Thursday announcement. Russia severed natural gas flow through the Nord Stream 1 pipeline earlier this month in an apparent retaliation against Western Europe for supporting Ukraine. As other countries impose energy consumption restrictions ...

## ‘Yeah, So?’ Drew Barrymore Says She’ll Go ‘Years’ Without Sex, No Problem
 - [https://www.dailywire.com/news/yeah-so-drew-barrymore-says-shell-go-years-without-sex-no-problem](https://www.dailywire.com/news/yeah-so-drew-barrymore-says-shell-go-years-without-sex-no-problem)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 12:41:46+00:00

Drew Barrymore recently admitted that going without sex for extended periods of time is no big deal for her. The 47-year-old actress made the comments during a Wednesday episode of “The Drew Barrymore Show,” per Fox News. &#8220;What’s wrong with me that six months doesn’t seem like a very long time?&#8221; she quipped to co-host ...

## Dr. Anthony Fauci Mocked ‘Ass-Backwards’ Restaurant Diners Who Took Masks Off At Table, New Book Says
 - [https://www.dailywire.com/news/dr-anthony-fauci-mocked-ass-backwards-restaurant-diners-who-took-masks-off-at-table-new-book-says](https://www.dailywire.com/news/dr-anthony-fauci-mocked-ass-backwards-restaurant-diners-who-took-masks-off-at-table-new-book-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 12:29:17+00:00

Dr. Anthony Fauci, the highest-paid federal worker &#8212; yes, he makes more than the president &#8212; has a serious disdain for the American people. When COVID first hit U.S. shores, Fauci was instrumental in forcing federal officials to shut down &#8230; well, everything. The economy imploded, largely as a result of his Debbie Downer advice, ...

## ‘F*** George Gascon’: Young Mother Who Was Carrying Baby When Teenage Driver Hit Her Lashes Out
 - [https://www.dailywire.com/news/f-george-gascon-young-mother-who-was-carrying-baby-when-teenage-driver-hit-her-lashes-out](https://www.dailywire.com/news/f-george-gascon-young-mother-who-was-carrying-baby-when-teenage-driver-hit-her-lashes-out)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 12:10:20+00:00

A young mother who was slammed into by a teenage driver while she was carrying her eight-month-old baby ripped leftist Los Angeles County District Attorney George Gascón for not notifying her the youth was going to plead for early release. The teenager was sentenced to five to seven months in a juvenile probation camp after ...

## Yes, Johnny Depp Is Dating His Attorney: Report
 - [https://www.dailywire.com/news/yes-johnny-depp-is-dating-his-attorney-report](https://www.dailywire.com/news/yes-johnny-depp-is-dating-his-attorney-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 12:09:08+00:00

In a plot twist straight from Hollywood — actor Johnny Depp is reportedly dating one of the attorneys who represented him in a recent matter in the United Kingdom. Joelle Rich, who was part of Depp&#8217;s legal team in his U.K. libel trial against The Sun, is reportedly still married but separated — and according ...

## Black America Needs To Change Or It Will Continue To Be Destroyed
 - [https://www.dailywire.com/news/black-america-needs-to-change-or-it-will-continue-to-be-destroyed](https://www.dailywire.com/news/black-america-needs-to-change-or-it-will-continue-to-be-destroyed)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 12:03:45+00:00

The question on my mind today is: Who is your queen? Who is your king? It’s been especially on my mind as I watched Queen Elizabeth’s funeral and black America’s subsequent reaction, which has painted Elizabeth as a murdering, complicit colonist who doesn’t deserve praise or respect. I’ve responded to the colonialist critique many times ...

## State Will Consider Banning The Sale Of New Diesel Trucks
 - [https://www.dailywire.com/news/state-will-consider-banning-the-sale-of-new-diesel-trucks](https://www.dailywire.com/news/state-will-consider-banning-the-sale-of-new-diesel-trucks)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 12:02:18+00:00

California regulators are considering a ban on new diesel trucks by 2040, according to a policy proposal due for review next month. Draft guidelines from the California Air Resources Board would also mandate that all medium-duty and heavy-duty trucks entering ports and railyards must be zero-emission, with state and local government fleets reaching the standard ...

## Illinois’ Former Wealthiest Man Reveals The Breaking Points That Prompted His Move To Florida
 - [https://www.dailywire.com/news/illinois-former-wealthiest-man-reveals-the-breaking-points-that-prompted-his-move-to-florida](https://www.dailywire.com/news/illinois-former-wealthiest-man-reveals-the-breaking-points-that-prompted-his-move-to-florida)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 11:59:06+00:00

Citadel CEO Ken Griffin revealed on Tuesday that he moved from Illinois to Florida after a senior colleague was robbed at gunpoint during a coffee run in Chicago, while another was attacked without provocation by a “random lunatic.” Griffin — whose $30 billion net worth places him among the 50 richest men on the planet, ...

## ‘Fat Leonard,’ Fugitive Who Bribed Navy Brass With Booze, Hookers, Nabbed After International Manhunt
 - [https://www.dailywire.com/news/fat-leonard-fugitive-who-bribed-navy-brass-with-booze-hookers-nabbed-after-international-manhunt](https://www.dailywire.com/news/fat-leonard-fugitive-who-bribed-navy-brass-with-booze-hookers-nabbed-after-international-manhunt)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 11:23:07+00:00

“Fat Leonard,” the flamboyant defense contractor who admitted bribing top Navy brass with booze and hookers in a $35 million scheme and bolted while awaiting sentencing earlier this month, was nabbed in Venezuela on Tuesday morning as he tried to flee to Russia. The Malaysian national, whose real name is Leonard Glenn Francis, was captured ...

## ‘Beyond QAnon S***’: Stacey Abrams Says Unborn Babies’ Heartbeats Not Real At Six Weeks, ‘A Manufactured Sound,’ Tool Of Patriarchy
 - [https://www.dailywire.com/news/beyond-qanon-s-stacey-abrams-says-unborn-babies-heartbeats-not-real-at-six-weeks-a-manufactured-sound-tool-of-patriarchy](https://www.dailywire.com/news/beyond-qanon-s-stacey-abrams-says-unborn-babies-heartbeats-not-real-at-six-weeks-a-manufactured-sound-tool-of-patriarchy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 10:43:46+00:00

Georgia Democrat Stacey Abrams said in a recently surfaced video that at six weeks, unborn babies&#8217; heartbeats aren&#8217;t real but a &#8220;manufactured sound designed&#8221; to take away women&#8217;s rights. Abrams is again campaigning to be governor of Georgia after a failed run in 2018. Notably, the Democrat refused to traditionally concede the race to Republican ...

## Katy Perry On Refusal To Hire Full-Time Nanny: ‘Would Never … Care For My Daughter Like I’m Meant To’
 - [https://www.dailywire.com/news/katy-perry-on-refusal-to-hire-full-time-nanny-would-never-care-for-my-daughter-like-im-meant-to](https://www.dailywire.com/news/katy-perry-on-refusal-to-hire-full-time-nanny-would-never-care-for-my-daughter-like-im-meant-to)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 10:04:41+00:00

Pop star Katy Perry doesn’t want to outsource motherhood to her nanny — at least, not completely.  The 37-year-old singer explained her parenting perspective during an appearance on the “SmartLess” podcast this week, per Page Six. “I am working a lot, and I’ve always worked a lot,” Perry said. “I have a wonderful nanny, but ...

## Hollywood A-Lister Says He’d Be ‘Arrogant Not To’ Consider Presidential Run
 - [https://www.dailywire.com/news/hollywood-a-lister-says-hed-be-arrogant-not-to-consider-presidential-run](https://www.dailywire.com/news/hollywood-a-lister-says-hed-be-arrogant-not-to-consider-presidential-run)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 09:41:31+00:00

Hollywood star Matthew McConaughey is acting like he wants to be president. The “Dazed and Confused” star, who has flirted with a gubernatorial run in his native Texas, told attendees at San Francisco’s Dreamforce conference this week that he would “be arrogant not to” consider a White House run in the future. McConaughey, who has ...

## WATCH: Hawley Grills Biden’s National Archives Nominee: ‘You Wrote … Republican Voters Are Stupid’
 - [https://www.dailywire.com/news/watch-hawley-grills-bidens-national-archives-nominee-you-wrote-republican-voters-are-stupid](https://www.dailywire.com/news/watch-hawley-grills-bidens-national-archives-nominee-you-wrote-republican-voters-are-stupid)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 08:39:30+00:00

Missouri GOP Senator Josh Hawley grilled Colleen Shogan, President Biden’s nominee to lead the National Archives and Records Administration, noting that she had written a paper he said disparaged every two-term Republican president since World War II. Hawley’s questions came during a Senate Homeland Security and Governmental Affairs Committee hearing on Wednesday. “You have talked ...

## Man Who Allegedly Drove Over ‘Republican’ Teen: I Don’t Want To Lose My ‘Job,’ ‘Life,’ ‘House’ Because Of Bond
 - [https://www.dailywire.com/news/man-who-allegedly-drove-over-republican-teen-i-dont-want-to-lose-my-job-life-house-because-of-bond](https://www.dailywire.com/news/man-who-allegedly-drove-over-republican-teen-i-dont-want-to-lose-my-job-life-house-because-of-bond)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 08:14:06+00:00

The 41-year-old man who allegedly admitted to murdering a Republican teenager over politics at the start of the week said this week in court that he did not want to lose things in his life due to bond because of the charges. Shannon Brandt was charged with vehicular homicide and leaving the scene of a crash ...

## Florida Issues Forceful Response To Credit Card Companies That Want To Track Gun And Ammo Sales
 - [https://www.dailywire.com/news/florida-issues-forceful-response-to-credit-card-companies-that-want-to-track-gun-and-ammo-sales](https://www.dailywire.com/news/florida-issues-forceful-response-to-credit-card-companies-that-want-to-track-gun-and-ammo-sales)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 07:54:23+00:00

The state of Florida issued a forceful response Wednesday to credit card companies that want to start tracking gun and ammunition sales, saying that if they proceed that the state will pass a law punishing those companies. Visa, Mastercard, and American Express have reportedly decided to separately categorize firearm purchases at gun stores in a ...

## Trump: I Could Declassify Documents ‘Even By Thinking About It’
 - [https://www.dailywire.com/news/trump-i-could-declassify-documents-even-by-thinking-about-it](https://www.dailywire.com/news/trump-i-could-declassify-documents-even-by-thinking-about-it)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 07:38:41+00:00

Former President Donald Trump addressed the FBI&#8217;s raid last month on his Florida home at Mar-a-Lago during a Fox News interview Wednesday night where he said that he had the ability to declassify documents by just &#8220;thinking about it.&#8221; The sections of the U.S. criminal code that were cited on the search warrant indicated that ...

## Trump-Endorsed Ohio GOP Congressional Candidate Allegedly Lied About Military Service Record: Report
 - [https://www.dailywire.com/news/trump-endorsed-ohio-gop-congressional-candidate-allegedly-lied-about-military-service-record-report](https://www.dailywire.com/news/trump-endorsed-ohio-gop-congressional-candidate-allegedly-lied-about-military-service-record-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 07:28:22+00:00

J.R. Majewski, a Republican U.S. congressional candidate in Ohio, allegedly lied about his military service record on the campaign trail, according to a new report published on Wednesday. The Associated Press reported that the 42-year-old has presented himself as &#8220;an Air Force combat veteran who deployed to Afghanistan after the 9/11 terrorist attacks, once describing ...

## Former UCLA Basketball Player Jalen Hill Dies At 22
 - [https://www.dailywire.com/news/former-ucla-basketball-player-jalen-hill-dies-at-22](https://www.dailywire.com/news/former-ucla-basketball-player-jalen-hill-dies-at-22)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-22 07:17:28+00:00

Former UCLA basketball player Jalen Hill has died at the age of 22, according to his family and the university. The Associated Press reported that Hill&#8217;s family learned of his death after he recently went missing while in Costa Rica. “We know Jalen has played a part in the lives of so many people,” Hill’s ...


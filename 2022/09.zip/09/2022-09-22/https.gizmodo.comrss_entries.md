# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Dystopian Short Heartless Imagines a World of Endless Arranged Marriages
 - [https://gizmodo.com/short-film-sci-fi-dystopian-heartless-iceland-1849571110](https://gizmodo.com/short-film-sci-fi-dystopian-heartless-iceland-1849571110)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 23:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--OA4E3zJW--/c_fit,fl_progressive,q_80,w_636/d0f740290ec0c4fb6b96edd1a73e61d7.jpg" /><p>Imagine meeting the person you want to spend your life with—but you live in a community where partners are forcibly switched via a <a href="https://gizmodo.com/mega-millions-jackpot-odds-july-winning-lottery-hacks-1849339749">lottery</a> on a regular basis, and no amount of true love makes any difference. That’s the premise of <em>Heartless</em>, an

## I Love You, Andor Bell Guy
 - [https://gizmodo.com/andor-bell-guy-hammers-disney-plus-star-wars-1849570848](https://gizmodo.com/andor-bell-guy-hammers-disney-plus-star-wars-1849570848)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 22:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--2rXBYtMq--/c_fit,fl_progressive,q_80,w_636/10ac508a0c5962a3fa844dd87b5d10ad.png" /><p><a href="https://gizmodo.com/star-wars-andor-diego-luna-disney-plus-lucasfilm-1849555939"><em>Andor</em></a> is a show about the messy side of the galaxy far, far away and the<a href="https://gizmodo.com/andor-star-wars-messy-heroes-disney-plus-1849565311"> even messier people</a> who inhabit it. Angry people, unpleasant people, liars and killers lo

## One Day After Report of Child Predators on Twitch, Matt Gaetz Joins Twitch
 - [https://gizmodo.com/twitch-matt-gaetz-1849570214](https://gizmodo.com/twitch-matt-gaetz-1849570214)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 22:05:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--I7QffFYl--/c_fit,fl_progressive,q_80,w_636/144295cd4988784a67b7d442b11b9ad2.jpg" /><p>Matt Gaetz,  Florida Republican Congressman and <a href="https://gizmodo.com/matt-gaetzs-lackey-reportedly-used-venmo-to-pay-off-mor-1846687315">alleged sex criminal</a>, is now on Twitch. Gaetz (or at least whoever runs his social media accounts) announced his arrival on the streaming platform in a tweet. “I’m joining @Twitch to bring my America Fi

## Hit Sci-Fi Novel Iron Widow Is Becoming a Movie
 - [https://gizmodo.com/sci-fi-ya-book-iron-widow-becoming-movie-xiran-jay-zhao-1849570503](https://gizmodo.com/sci-fi-ya-book-iron-widow-becoming-movie-xiran-jay-zhao-1849570503)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 21:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--MnbRzM_D--/c_fit,fl_progressive,q_80,w_636/13dc60a2bf57203eaf6f00dc00192418.png" /><p>Aiming to be the next <a href="https://gizmodo.com/hunger-games-prequel-movie-teaser-release-date-2023-1849022575"><em>Hunger Games</em></a><em> </em>by way of <a href="https://gizmodo.com/guillermo-del-toros-monster-films-lessons-blade-2-pacif-1848860866"><em>Pacific Rim</em></a><em>—</em>which admittedly does sound rather awesome<em>—</em>best-sel

## Meta’s Own Commissioned Report Says It Harmed Palestinian Human Rights
 - [https://gizmodo.com/meta-human-rights-palestine-content-moderation-1849570678](https://gizmodo.com/meta-human-rights-palestine-content-moderation-1849570678)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--nj6mmh-a--/c_fit,fl_progressive,q_80,w_636/691bb8d17c40a778f65950646d6918a2.jpg" /><p>Meta, the company founded on the <a href="https://about.meta.com/company-info/?utm_source=about.facebook.com&amp;utm_medium=redirect" rel="noopener noreferrer" target="_blank">principle</a> of building connectivity and giving people a voice worldwide, did just the opposite last year and enforced speech policies that violated Palestinian’s freedom of

## Wildfire Smoke Is Making U.S. Air Toxic
 - [https://gizmodo.com/wildfire-smoke-is-making-u-s-air-toxic-1849569349](https://gizmodo.com/wildfire-smoke-is-making-u-s-air-toxic-1849569349)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 21:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--OqNCgyng--/c_fit,fl_progressive,q_80,w_636/3a86b081ec919d6e0a7c347ececa6817.jpg" /><p>Regional wildfire smoke is significantly lowering air quality for millions of people across the country.</p><p><a href="https://gizmodo.com/wildfire-smoke-is-making-u-s-air-toxic-1849569349">Read more...</a></p>

## What Happens if the Rockstar Hacker Leaks the GTA6 Source Code
 - [https://gizmodo.com/grand-theft-auto-6-rockstar-hack-delay-1849553185](https://gizmodo.com/grand-theft-auto-6-rockstar-hack-delay-1849553185)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 21:07:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--tpKs4QJ---/c_fit,fl_progressive,q_80,w_636/09afd82f5c44d50d04c7fcfc40187c18.jpg" /><p>What, if any, is the impact of a severe hack earlier this week going to be on Rockstar Games’ business? The game publisher’s <a href="https://kotaku.com/gta-6-leak-grand-theft-rockstar-teapotuberhacker-forum-1849552442">systems were breached</a> just days ago in what some are calling the biggest hack of its kind in recent memory. Known for popular f

## TikTok Company's New VR Headset Competes with Meta on Price and Privacy
 - [https://gizmodo.com/tiktok-vr-bytedance-pico-headset-meta-quest-2-pro-1849570315](https://gizmodo.com/tiktok-vr-bytedance-pico-headset-meta-quest-2-pro-1849570315)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--peUEahZW--/c_fit,fl_progressive,q_80,w_636/ea3231a469fb053670f434a07ea06311.png" /><p>Meta is terrified of TikTok’s <a href="https://gizmodo.com/tiktok-popular-facebook-meta-widely-viewed-content-1849486879">domineering</a> presence in the social media market, and now it seems the company behind the app, ByteDance, is coming for Meta’s own stake in the Metaverse with a headset that’s the closest we’ve seen in price to the Quest 2.</p

## More Americans Are Surviving Cancer Than Ever Before
 - [https://gizmodo.com/more-americans-are-surviving-cancer-than-ever-before-1849569822](https://gizmodo.com/more-americans-are-surviving-cancer-than-ever-before-1849569822)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 20:28:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ce30fhg4--/c_fit,fl_progressive,q_80,w_636/7e6937ecbc2ce8d82afbea0d4a9be5d9.jpg" /><p>A new report from the American Association for Cancer Research this week offers a good prognosis about the state of cancer care in the U.S. More Americans than ever are surviving cancer, and the long-running decline in mortality has only sped up in recent years. At the same time, some groups continue to face a higher…</p><p><a href="https://gizmodo.

## No One Was Talking About NyQuil Chicken Until the FDA Told Everyone Not to Talk About It
 - [https://gizmodo.com/nyquil-chicken-fda-warning-late-misinformation-tiktok-1849569728](https://gizmodo.com/nyquil-chicken-fda-warning-late-misinformation-tiktok-1849569728)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--YLehImht--/c_fit,fl_progressive,q_80,w_636/7796d47db73c91981d1413625a9a9844.png" /><p>If you’ve gone online this week or turned on the TV, there’s a good chance you’ve heard about the gross and potentially fatal practice of cooking chicken in NyQuil. Last week, the Food and Drug Administration <a href="https://www.fda.gov/consumers/consumer-updates/recipe-danger-social-media-challenges-involving-medicines" rel="noopener noreferrer" t

## Hilton's Bringing Lodging to Future Space Station
 - [https://gizmodo.com/hilton-voyager-space-starlab-iss-1849567725](https://gizmodo.com/hilton-voyager-space-starlab-iss-1849567725)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 19:55:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--l3V-SyNk--/c_fit,fl_progressive,q_80,w_636/7e3275746abd11ecd187f77f6e47ed28.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--9AOXXhr6--/c_fit,fl_progressive,q_80,w_636/7e3275746abd11ecd187f77f6e47ed28.mp4" type="video/mp4" /></video><p>Voyager Space announced a new collaboration with Hilton, the American hotel and hospitality company. Together, the companies are planning to bring crew lodging to Sta

## Into the Odd Is a Beautifully Self-Cannibalizing RPG Built on Bodies
 - [https://gizmodo.com/into-the-odd-rpg-review-free-league-dungeon-crawl-osr-1849568683](https://gizmodo.com/into-the-odd-rpg-review-free-league-dungeon-crawl-osr-1849568683)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 19:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--9HCVLgrQ--/c_fit,fl_progressive,q_80,w_636/a83f023abe57a70e374865a8f60aa5db.png" /><p><a href="https://freeleaguepublishing.com/en/store/?product_id=7749919539458" rel="noopener noreferrer" target="_blank"><em>Into the Odd</em></a><em> </em>takes its taglines of rules-light and flavor-heavy very, <em>very</em> seriously. This Old-School Roleplaying (OSR) tabletop game has the veneer of a simple dungeon-delver, but once you dig into t

## A Hot Gas Bubble Is Swirling Around the Milky Way’s Black Hole
 - [https://gizmodo.com/milky-way-black-hole-hot-gas-bubble-1849569308](https://gizmodo.com/milky-way-black-hole-hot-gas-bubble-1849569308)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 19:19:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--i6GfGL-P--/c_fit,fl_progressive,q_80,w_636/6198933ef7b83ee115e76a2ddaeec7b8.png" /><p>The supermassive black hole at the center of the Milky Way galaxy is being circled by a bubble of hot gas, according to recent analysis by the <a href="https://eventhorizontelescope.org/" rel="noopener noreferrer" target="_blank">Event Horizon Telescope Collaboration</a>. The gas is whipping around the black hole at about 30% the speed of light. </p

## You Can Use Dynamic Island on Android Now, But You Probably Shouldn't
 - [https://gizmodo.com/android-dynamic-island-app-ios-iphone-14-pro-max-play-1849569473](https://gizmodo.com/android-dynamic-island-app-ios-iphone-14-pro-max-play-1849569473)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 19:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--sC7LksTH--/c_fit,fl_progressive,q_80,w_636/69ad5a58f13f6a4433ed6c7629539d3a.jpg" /><p>It bears repeating that trying to emulate an iOS feature that isn’t native to Android often results in something <a href="https://gizmodo.com/apple-iphone-google-pixel-ios-launcher-android-skin-1849547275">too hacky</a> to use daily. That’s how I feel about a new attempt to bring Apple’s dynamic island iPhone feature to Android.</p><p><a href="https

## At Last, Star Trek: Lower Decks Finally Nailed It This Season
 - [https://gizmodo.com/star-trek-lower-decks-episode-5-recap-reflections-1849569629](https://gizmodo.com/star-trek-lower-decks-episode-5-recap-reflections-1849569629)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Prqa-U7p--/c_fit,fl_progressive,q_80,w_636/577b1221e57121c072c539e4a64a1054.png" /><p><em>Star Trek: Lower Decks</em>’ third season has struggled to find a<a href="https://gizmodo.com/star-trek-lower-decks-season-3-episode-1-recap-grounded-1849456679"> point for itself</a>, <a href="https://gizmodo.com/star-trek-lower-decks-season-3-episode-3-recap-1849513195">regressing its ensign heroes</a> and relying on the charms of its pastiche

## Elon Says Starship Megarocket Could Perform First Orbital Flight in November
 - [https://gizmodo.com/spacex-orbital-test-starship-november-elon-musk-1849568715](https://gizmodo.com/spacex-orbital-test-starship-november-elon-musk-1849568715)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 18:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--NQDaXhFL--/c_fit,fl_progressive,q_80,w_636/33277ee6366a4eb55dabd8f607f6e9bc.jpg" /><p>SpaceX is expecting to see its gigantic Starship rocket take off on its first flight very soon. CEO Elon Musk revealed that the company is gearing up to attempt the first-ever orbital test flight of the two-stage reusable system as early as late October, but with a launch in November being more “likely.” <br /></p><p><a href="https://gizmodo.com/spa

## Trump Could Be Back on Facebook as Soon as January
 - [https://gizmodo.com/trump-facebook-meta-social-media-ban-1849568749](https://gizmodo.com/trump-facebook-meta-social-media-ban-1849568749)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 18:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--mo3KmD82--/c_fit,fl_progressive,q_80,w_636/aec6a3fe8aba0ee9be35ab21b79d6f7c.jpg" /><p>Donald Trump could be back to his <a href="https://gizmodo.com/facebook-finally-hits-delete-button-on-trump-post-claim-1844628266">old social media antics</a> in just a few months. The <a href="https://gizmodo.com/trump-suspended-from-facebook-for-at-least-two-years-1847034400">two-year ban</a>, barring the former poster-in-chief from Facebook, expi

## Yes, Instagram Is Down
 - [https://gizmodo.com/instagram-meta-outage-app-1849569341](https://gizmodo.com/instagram-meta-outage-app-1849569341)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 18:23:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ZQ-cY6PD--/c_fit,fl_progressive,q_80,w_636/b4f0bb61a7dd6d1f5da0504be966f83e.jpg" /><p>If you’re able to access your Instagram account right now, I guess you can consider yourself lucky. The app was reportedly down for some users Thursday according to thousands of user-generated <a href="https://downdetector.com/status/instagram/" rel="noopener noreferrer" target="_blank">reports</a> on Downdetector.com.<br /></p><p><a href="https://g

## Dungeons & Dragons & Novels: Revisiting Black Wizards
 - [https://gizmodo.com/dungeons-dragon-novels-black-wizards-forgotten-realms-1849566199](https://gizmodo.com/dungeons-dragon-novels-black-wizards-forgotten-realms-1849566199)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 18:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Mq9LCdwb--/c_fit,fl_progressive,q_80,w_636/1fb9a74bfda64aa7d246f2984579c428.jpg" /><p>It’s been over two years since I reviewed <a href="https://gizmodo.com/dungeons-dragons-novels-revisiting-darkwalker-on-m-1844776398"><em>Darkwalker on Moonshae</em></a>, the fabulously titled first book ever set in <a href="https://gizmodo.com/one-dnd-racism-rpg-stereotypes-dungeons-dragons-wotc-1849531852"><em>Dungeons &amp; Dragons</em></a>’ vene

## Mike Bloomberg Wages War Against Plastic
 - [https://gizmodo.com/mike-bloomberg-beyond-petrochemicals-plastics-1849568972](https://gizmodo.com/mike-bloomberg-beyond-petrochemicals-plastics-1849568972)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 17:54:50+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--fFfm9EDy--/c_fit,fl_progressive,q_80,w_636/268ef969577e830596f868092aa7488e.jpg" /><p>Michael Bloomberg is taking on plastic producers. The billionaire announced Wednesday that he will launch a $85 million campaign to fight against the expansion of the petrochemical industry.<br /></p><p><a href="https://gizmodo.com/mike-bloomberg-beyond-petrochemicals-plastics-1849568972">Read more...</a></p>

## NASA Refines Its Strategy for Getting Humans to Mars
 - [https://gizmodo.com/nasa-moon-to-mars-strategy-1849568641](https://gizmodo.com/nasa-moon-to-mars-strategy-1849568641)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 17:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--dj8DTmQo--/c_fit,fl_progressive,q_80,w_636/pkyijfsmd9n8mbg4dhrj.jpg" /><p>NASA’s <a href="https://gizmodo.com/nasa-artemis-program-moon-landing-launch-dates-1848906821">upcoming Artemis Moon program</a> is serving as a stepping stone for an eventual crewed mission to Mars. A revised list of planning objectives details a strategy for accomplishing this daunting feat. </p><p><a href="https://gizmodo.com/nasa-moon-to-mars-strategy-18495

## She-Hulk's Jameela Jamil Talks Her Favorite MCU Characters
 - [https://gizmodo.com/she-hulks-jameela-jamil-talks-favorite-mcu-characters-1849552461](https://gizmodo.com/she-hulks-jameela-jamil-talks-favorite-mcu-characters-1849552461)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 17:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--8f-UMSiO--/c_fit,fl_progressive,q_80,w_636/cc4b1474c78e6e7446fac7ba78322b51.jpg" /><p><a href="https://gizmodo.com/she-hulks-jameela-jamil-talks-favorite-mcu-characters-1849552461">Read more...</a></p>

## Manchin’s Latest Legislation Would Accelerate Fossil Fuel Projects
 - [https://gizmodo.com/manchin-energy-independence-security-act-fossil-fuels-1849567368](https://gizmodo.com/manchin-energy-independence-security-act-fossil-fuels-1849567368)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 16:58:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Dp0mKbiM--/c_fit,fl_progressive,q_80,w_636/f872a0d6977563f4113646aa9beb09bb.jpg" /><p>West Virginia <a href="https://gizmodo.com/coal-plant-wont-pay-its-rent-but-can-pay-joe-manchin-1848548520">coal baron</a> and Senator Joe Manchin released <a href="https://www.energy.senate.gov/services/files/EAB527DC-FA23-4BA9-B3C6-6AB108626F02" rel="noopener noreferrer" target="_blank">the final text</a> for his anticipated permitting reform legi

## The Sandman's Vanessa Benton on Writing About Death and Dreams
 - [https://gizmodo.com/netflix-sandman-neil-gaiman-vanessa-benton-interview-1849563633](https://gizmodo.com/netflix-sandman-neil-gaiman-vanessa-benton-interview-1849563633)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 16:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ok4dA5Ym--/c_fit,fl_progressive,q_80,w_636/e7522098d6ccf68944cabd5d269a9b72.png" /><p>“It’s scary as shit. I’m working on <a href="https://gizmodo.com/neil-gaiman-leaked-sandman-script-jon-peters-1849461594"><em>Sandman</em></a> as my first staff writing job?” Vanessa Benton shook their head as they said this, leaning back a little; we’re talking in the morning over video chat. “It was an incredible learning experience, <a href="http

## Samsung's New Rugged Tablet and Smartphone Look Perfect For a Hike or Construction Site
 - [https://gizmodo.com/samsung-galaxy-tab-active4-pro-xcover6-rugged-phone-1849564948](https://gizmodo.com/samsung-galaxy-tab-active4-pro-xcover6-rugged-phone-1849564948)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--wlgj7X7i--/c_fit,fl_progressive,q_80,w_636/a721b247b4ea65a87f70b6ba324e8ec0.png" /><p>Samsung’s newest hardware for the U.S. market is a pair of rugged devices made for hiking or jobs that would put them in harm’s way. The Samsung Galaxy Tab Active4 Pro tablet and the Galaxy XCover6 Pro smartphone feature military-grade device protection and 5G connectivity. But their most interesting feature is that …</p><p><a href="https://gizmodo.

## MyPillow CEO Is Under Federal Investigation for Potential Ties to Colorado Election Security Breach
 - [https://gizmodo.com/my-pillow-election-2020-trump-dominion-1849568341](https://gizmodo.com/my-pillow-election-2020-trump-dominion-1849568341)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 16:05:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--jvUy7W4D--/c_fit,fl_progressive,q_80,w_636/96dbcfb815e7db512e5cf7c8e5026fb5.jpg" /><p>MyPillow CEO and proverbial <a href="https://gizmodo.com/mypillow-mike-lindell-walmart-cancel-culture-1849076941">yeller</a> <a href="https://gizmodo.com/mypillow-guy-re-banned-from-twitter-after-just-three-ho-1848868012">at clouds</a> Mike Lindell is under investigation by the Department of Justice for potential identity theft and intent to damage 

## She-Hulk Went to a Wedding and Introduced a Brand New Marvel 'Hero'
 - [https://gizmodo.com/she-hulk-episode-6-just-jen-recap-marvel-studios-disney-1849567680](https://gizmodo.com/she-hulk-episode-6-just-jen-recap-marvel-studios-disney-1849567680)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--THeJEyOE--/c_fit,fl_progressive,q_80,w_636/27731cdfcb79bb69eb16b2b6dca7173a.jpg" /><p>Anyone who  has been to a wedding totally understood why the sixth episode of <em>She-Hulk</em> was so on the money. Last week, <a href="https://gizmodo.com/she-hulk-episode-5-recap-titania-avongers-disney-plus-1849539633">things ended with She-Hulk getting her very own super suit</a> and a tease of an exciting cameo in <a href="https://gizmodo.com/

## Optoma's New Short-Throw 4K Projector Needs Just Four Feet to Fill a 100-inch Screen
 - [https://gizmodo.com/optoma-short-throw-4k-projector-100-inch-image-four-fee-1849567472](https://gizmodo.com/optoma-short-throw-4k-projector-100-inch-image-four-fee-1849567472)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 15:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--MpznQlI7--/c_fit,fl_progressive,q_80,w_636/42efff4b889d364f1492ed3af896ffc8.jpg" /><p>Once a feature exclusive to million dollar homes and properties featured on MTV’s <em>Cribs</em>, a decent home theater is now far more attainable thanks to companies like Optoma churning out well-spec’d  4K projectors like its new UHD35STx, which delivers <a href="https://www.optomausa.com/product-details/uhd35STx#specifications" rel="noopener nore

## Knock at the Cabin Gives M. Night Shyamalan the End of the World to Deal With
 - [https://gizmodo.com/knock-at-the-cabin-m-night-shyamalan-horror-trailer-1849567588](https://gizmodo.com/knock-at-the-cabin-m-night-shyamalan-horror-trailer-1849567588)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ZGk9zAEc--/c_fit,fl_progressive,q_80,w_636/0ca2a7004ddff8038f47e13d62bf59dd.png" /><p><em>Knock at the Cabin</em> is not, in fact <a href="https://gizmodo.com/m-night-shyamalan-finally-made-a-comedy-5576076">a comedy</a>. It’s not <a href="https://gizmodo.com/13-tips-for-surviving-a-night-in-a-cabin-in-the-woods-1603005477">even a satire</a> (at least, I don’t think it is...). I’ll admit I was fooled by both the initial cast announce

## Grandmaster Carlsen Digs Deeper Trench Over Online Chess Cheating Debacle
 - [https://gizmodo.com/hans-niemann-magnus-carlsen-chess24-cheating-chess-1849567535](https://gizmodo.com/hans-niemann-magnus-carlsen-chess24-cheating-chess-1849567535)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 14:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--zDAomrpw--/c_fit,fl_progressive,q_80,w_636/d74e38604bfe63a79a5aa03a396fc92e.jpg" /><p>The ongoing chess cheating scandal won’t die out, and it’s starting to seem like the rest of us are just pawns being shuffled from one accusation to the next.</p><p><a href="https://gizmodo.com/hans-niemann-magnus-carlsen-chess24-cheating-chess-1849567535">Read more...</a></p>

## Black Panther: Wakanda Forever Merch Gives Us a Look at Ironheart's Final Suit
 - [https://gizmodo.com/black-panther-wakanda-forever-ironheart-suit-pictures-1849551412](https://gizmodo.com/black-panther-wakanda-forever-ironheart-suit-pictures-1849551412)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--8ZvPcC2M--/c_fit,fl_progressive,q_80,w_636/6d927c2b0e0eaf925330c656804ba0e1.png" /><p>Producer Barbara Broccoli wants the next James Bond to last a while. <em>The Flash</em>’s final season has found a new Captain Boomerang. Plus, get another look at Jodie Whittaker’s <em>Doctor Who</em> exit, and what’s coming on <em>The Handmaid’s Tale</em> and <em>Rick &amp; Morty</em>. Spoilers, away!<br /></p><p><a href="https://gizmodo.com/black

## Recent Space Force Training Exercise Included 'Live Fire' Jamming of Actual Satellites
 - [https://gizmodo.com/recent-space-force-training-exercise-included-live-fire-1849565108](https://gizmodo.com/recent-space-force-training-exercise-included-live-fire-1849565108)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--4iZuFlJt--/c_fit,fl_progressive,q_80,w_636/a9f0d73e31ceb49e81cbb99c5b779fcc.jpg" /><p>The United States Space Force is gearing up for hostile skies, training its Guardians this week on the use of satellite jammers to shut down enemy communications. <br /></p><p><a href="https://gizmodo.com/recent-space-force-training-exercise-included-live-fire-1849565108">Read more...</a></p>

## Grinch Melania Trump Suddenly Loves Christmas Because She's Selling Ornament NFTs
 - [https://gizmodo.com/melania-trump-christmas-ornament-nfts-1849566922](https://gizmodo.com/melania-trump-christmas-ornament-nfts-1849566922)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 13:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--E15qlAvL--/c_fit,fl_progressive,q_80,w_636/3ed6471a3f270dcdee7c7f243291b504.jpg" /><p>Melania Trump wants the public to know that Christmas is an “important” time for her and that she is “devoted” to the holiday, despite what the nasty mainstream news media—and the former first lady herself—have said in the past. Why, you ask? Perhaps because she’s hawking Christmas ornaments and NFTs, just in time for…</p><p><a href="https://gizmodo

## Chromecast with Google TV (HD) is Here to Revive Your Old Screens
 - [https://gizmodo.com/chromecast-google-tv-hd-1080p-4k-av1-codec-dolby-atmos-1849565835](https://gizmodo.com/chromecast-google-tv-hd-1080p-4k-av1-codec-dolby-atmos-1849565835)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--fz_zPfKx--/c_fit,fl_progressive,q_80,w_636/4be6b07e4da08593ec2e90cb2f4586ec.png" /><p>We’ve all done it: try to get out of paying a ton for new hardware by buying something smaller and less expensive. Google’s new Chromecast with Google TV (HD) is for folks who can’t help but attempt to breathe new life into old hardware. It helps that it doesn’t cost more than $30.<br /></p><p><a href="https://gizmodo.com/chromecast-google-tv-hd-108

## DJI Added a Dedicated Focus and Zoom Knob to its Stabilized Telescoping Smartphone Selfie Stick
 - [https://gizmodo.com/dji-smartphone-selfie-stick-osmo-mobile-5-6-focus-zoom-1849564407](https://gizmodo.com/dji-smartphone-selfie-stick-osmo-mobile-5-6-focus-zoom-1849564407)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--19eHnY1H--/c_fit,fl_progressive,q_80,w_636/d4dcecb59fd6981bcfc478e12dcb71c2.jpg" /><p><a href="https://gizmodo.com/dji-turned-its-smartphone-stabilizer-into-a-steady-tele-1847635344">Last year</a>, DJI took its smartphone stabilizer in a different direction and turned the <a href="https://gizmodo.com/dji-turned-its-smartphone-stabilizer-into-a-steady-tele-1847635344">Osmo Mobile 5</a> into a super-powered extending selfie stick. For 

## The AirPods Pro 2 Are Simply the Best Wireless Earbuds For iPhone Users
 - [https://gizmodo.com/apple-airpods-pro-2-review-best-iphone-wireless-earbuds-1849541242](https://gizmodo.com/apple-airpods-pro-2-review-best-iphone-wireless-earbuds-1849541242)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s---i_V7iB4--/c_fit,fl_progressive,q_80,w_636/3c066aaf1358c8bba066ae1f28a70bdf.jpg" /><p>The over-arching theme of Apple’s recent “Far Out” event, where it debuted its second generation AirPods Pro, was “don’t rock the boat.” The company opted to think a little less different this year, with several upgraded Apple Watches and iPhones that were nearly indistinguishable from last year’s offerings. The same…</p><p><a href="https://gizmodo.

## The Best Surfboards, Wetsuits, and Surfing Accessories
 - [https://gizmodo.com/best-surfboards-wetsuits-surfing-accessories-shorts-fin-1849559105](https://gizmodo.com/best-surfboards-wetsuits-surfing-accessories-shorts-fin-1849559105)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 12:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--7LqVyzTj--/c_fit,fl_progressive,q_80,w_636/23619668f0df007e823cc8128110a40d.jpg" /><p>Ah surfing, the sport of champions. It provides incredible exercise, a raw immersion in nature, and a lifetime of challenges. The best part is there are no lift tickets, tee times, or club fees. All you really need is your body, a wave, and a board. That being said, there is a lot of gear that is made for surfing that…</p><p><a href="https://gizmodo

## Iran Blocks Internet During Protests Making It Difficult to Write This Article If We're Being Completely Honest
 - [https://gizmodo.com/iran-mahsa-amini-whatsapp-instagram-internet-protests-1849566793](https://gizmodo.com/iran-mahsa-amini-whatsapp-instagram-internet-protests-1849566793)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-22 10:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--6ixABtAo--/c_fit,fl_progressive,q_80,w_636/715d916b560cad217e1072627a8e984e.jpg" /><p>Internet services like WhatsApp and Instagram are currently being blocked in Iran along with at least two major mobile networks, according to the UK-based internet access watchdog <a href="https://netblocks.org/reports/internet-disrupted-in-iran-amid-protests-over-death-of-mahsa-amini-X8qVEwAD" rel="noopener noreferrer" target="_blank">Netblocks</a>


# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The First ACTUAL Oculus Quest 2 "Killer" is HERE
 - [https://www.youtube.com/watch?v=XSt6oFwZne0](https://www.youtube.com/watch?v=XSt6oFwZne0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-09-22 18:30:34+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news! Today we have very possibly the very first real competition for the Oculus Quest 2, The pico 4 and 4 pro were recently officially announced! 

Also Quest V44 update, some disappointing PSVR 2 news, and thousands of games coming to PCVR soon! Hope you enjoyed! This is an exciting week!

Flat2VR discord: 
https://discord.gg/g27k4aVbgw

My links:
https://www.twitch.tv/thrilluwu
My discord: 
https://discord.gg/2hCGM9BYez
Patreon link:
https://www.patreon.com/Thrillseeker

Timestamps are back! 
00:00 INTRO
01:04  MODS
02:18 LUKE ROSS
02:38 UNREAL ENGINE VR INJECTOR
04:53 PICO 4
07:27 PICO 4 PRO
09:02 V44 UPDATE
09:33 PSVR 2
10:15 PSVR 2 BACKWARDS COMPATIBILITY
11:05 HALF-LIFE 2: VR MOD
11:44 CONTRACTORS UPDATE
12:27 BONELAB 
12:34 QOTW
13:02 OUTRO


# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Dziecko było chore, aborcji odmówiono mimo zaświadczenia. "Strach wynika z niewystarczająco skonstruowanego środowiska pracy"
 - [https://tvn24.pl/polska/dziecko-nie-mialo-czaszki-lekarze-w-warszawie-odmowili-kobiecie-aborcji-profesor-lukasz-wicherek-o-ustawie-aborcyjnej-6125789?source=rss](https://tvn24.pl/polska/dziecko-nie-mialo-czaszki-lekarze-w-warszawie-odmowili-kobiecie-aborcji-profesor-lukasz-wicherek-o-ustawie-aborcyjnej-6125789?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2022-09-22 18:46:00+00:00

<img alt="Dziecko było chore, aborcji odmówiono mimo zaświadczenia. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kxri09-22-1925-fpf-cl-0025-6125877/alternates/LANDSCAPE_1280" />
    Profesor Łukasz Wicherek, ginekolog i dyrektor z warszawskiego Szpitala Specjalistycznego "Inlancka" był gościem "Faktów po Faktach". Pojawia się on w reportażu TVN24 o kobiecie, która w 30. tygodniu ciąży dowiedziała się, że jej dziecko nie ma czaszki. To profesor Wicherek cofnął decyzję o braku zgody na aborcję. -


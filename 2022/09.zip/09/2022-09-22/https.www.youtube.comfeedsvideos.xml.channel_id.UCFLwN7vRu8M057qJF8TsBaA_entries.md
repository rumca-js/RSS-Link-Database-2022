# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Star Trek Is An Absolute Nightmare - This Is Why
 - [https://www.youtube.com/watch?v=n8eQRx-9xww](https://www.youtube.com/watch?v=n8eQRx-9xww)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2022-09-22 21:00:11+00:00

Thanks to Razer for sponsoring this video. You can see the Razer Blade 15, and all of Razer's other laptops here:
https://www.razer.com/gb-en/gaming-laptops/razer-blade

This is part 1 in a 2 part series where I review some episodes of Star Trek, this one is on The Next Generation, while part 2 will be on Star Trek: Voyager! I plan to do Star Trek: Deep Space 9 and Star Trek The Original Series in a 2 parter in the future. But if I actually will is debatable. 

Enjoy!

Patreon bros: https://www.patreon.com/UpIsNotJump 
Merch-o-bros: https://www.pixelempire.com/pages/upisnotjump
Twitter-o-fish: https://twitter.com/UpIsNotJump 

Editing workflow partly by: https://twitter.com/MudanTV 
Thumbnail Artwork by Skutch: https://twitter.com/skutchdraws?lang=en

Super big thank you to my memberz!
Ryan Moser
Siberial


# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## ESPN star suggests Ime Udoka situation amplified because of race, accuses Celtics of leaking info
 - [https://www.foxnews.com/sports/espn-star-suggests-ime-udoka-situation-amplified-because-of-race-accuses-celtics-of-leaking-info](https://www.foxnews.com/sports/espn-star-suggests-ime-udoka-situation-amplified-because-of-race-accuses-celtics-of-leaking-info)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:59:02+00:00

Boston Celtics coach Ime Udoka may be suspended over an inappropriate relationship with a female staffer, and Stephen A. Smith of ESPN has a theory about the ordeal.

## Wynonna Judd says she cries 'a lot' after her mother Naomi Judd's death: 'I feel joy and sorrow'
 - [https://www.foxnews.com/entertainment/wynonna-judd-says-cries-after-mother-naomi-judds-death-feel-joy-sorrow](https://www.foxnews.com/entertainment/wynonna-judd-says-cries-after-mother-naomi-judds-death-feel-joy-sorrow)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:56:42+00:00

Wynonna Judd discusses how the grieving process has been since she lost her mother, Naomi Judd, in April. The Grammy-award winning singer died at 76.

## North Dakota political murder 'lands in the lap' of Joe Biden: Judge Jeanine Pirro
 - [https://www.foxnews.com/media/north-dakota-political-murder-lands-lap-joe-biden-judge-jeanine-pirro](https://www.foxnews.com/media/north-dakota-political-murder-lands-lap-joe-biden-judge-jeanine-pirro)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:49:10+00:00

Judge Jeanine Pirro blamed President Biden's recent rhetoric for fueling "extremist hate" prior to the slaying of an 18-year-old because of his conservative political views.

## Presidents Cup 2022: Team USA earns four points in first five matches in Day 1
 - [https://www.foxnews.com/sports/presidents-cup-2022-team-usa-earns-four-points-first-five-matches-day-1](https://www.foxnews.com/sports/presidents-cup-2022-team-usa-earns-four-points-first-five-matches-day-1)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:47:20+00:00

Xander Schauffele and Patrick Cantlay, and the rest of Team USA, dominated the first day of the Presidents Cup at Quail Hallow, leading 4-1 after day one.

## Cotton grills Air Force over diversity training replacing 'mom' and 'dad' with gender-neutral terms
 - [https://www.foxnews.com/politics/cotton-grills-air-force-diversity-training-replacing-mom-dad-gender-neutral-terms](https://www.foxnews.com/politics/cotton-grills-air-force-diversity-training-replacing-mom-dad-gender-neutral-terms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:46:18+00:00

Arkansas Republican Sen. Tom Cotton sent a letter to the Air Force Academy superintendent, demanding answers regarding the reported "diversity and inclusion" training for cadets.

## Sen. Lindsey Graham defends abortion bill: Democrats trying to make this country like China
 - [https://www.foxnews.com/media/sen-lindsey-graham-defends-abortion-bill-democrats-trying-make-country-like-china](https://www.foxnews.com/media/sen-lindsey-graham-defends-abortion-bill-democrats-trying-make-country-like-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:36:46+00:00

Sen. Lindsey Graham defended his controversial abortion bill on "The Story" Thursday from critics on the left like Georgia gubernatorial candidate Stacey Abrams.

## ‘Dallas’ star Patrick Duffy reveals secret behind lasting romance with 'Happy Days' actress Linda Purl
 - [https://www.foxnews.com/entertainment/dallas-star-patrick-duffy-reveals-secret-behind-lasting-romance](https://www.foxnews.com/entertainment/dallas-star-patrick-duffy-reveals-secret-behind-lasting-romance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:31:49+00:00

Patrick Duffy, a star on "Dallas" and "Step By Step," was married to ballet dancer Carlyn Rosser from 1974 until her death in 2017 from cancer.

## Get ready for the autumn equinox: How is it different from a solstice?
 - [https://www.foxnews.com/us/autumn-equinox-different-from-solstice](https://www.foxnews.com/us/autumn-equinox-different-from-solstice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:31:45+00:00

Get your sweaters ready. The autumn equinox will mark the official end of the summer season and the start of fall on Thursday, Sept. 22, at 9:04 pm EST.

## New York Mayor Adams blasts city infighting, claims Texas Gov. Abbott is the ‘real villain’
 - [https://www.foxnews.com/us/new-york-mayor-adams-blasts-city-infighting-texas-gov-abbott-real-villain](https://www.foxnews.com/us/new-york-mayor-adams-blasts-city-infighting-texas-gov-abbott-real-villain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:29:54+00:00

Eric Adams condemned infighting in New York City over how to deal with the migrant crisis, arguing that Texas Gov. Greg Abbott is the "real villain."

## Kamala Harris slams ‘irresponsibility,’ ‘dereliction of duty’ of GOP governors sending migrants to blue areas
 - [https://www.foxnews.com/media/kamala-harris-slams-irresponsibility-dereliction-duty-gop-governors-sending-migrantsblue-areas](https://www.foxnews.com/media/kamala-harris-slams-irresponsibility-dereliction-duty-gop-governors-sending-migrantsblue-areas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:27:48+00:00

Vice President Kamala Harris scorched Republican leaders for their abortion and immigration policies during a recent interview with Vice News.

## Cuban migrants sent back by Coast Guard, warns of hurricane danger
 - [https://www.foxnews.com/us/coast-guard-repatriates-46-cubans-cuba-warns-migrants-hurricane-dangers](https://www.foxnews.com/us/coast-guard-repatriates-46-cubans-cuba-warns-migrants-hurricane-dangers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:26:11+00:00

On Thursday, the U.S. Coast Southeast repatriated 46 Cubans to Cuba. Due to hurricane season, Homeland Security warned migrants of the increased risks of travelling via boat.

## Good Samaritans help rescue Hawaii girl shackled on school bus, forced to smoke meth
 - [https://www.foxnews.com/us/good-samaritans-help-rescue-hawaii-girl-shackled-school-bus-forced-smoke-meth](https://www.foxnews.com/us/good-samaritans-help-rescue-hawaii-girl-shackled-school-bus-forced-smoke-meth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:20:02+00:00

Good Samaritans in Hawaii helped rescue a 15-year-old girl after her alleged 52-year-old captor kidnaped her at knifepoint and shackled her to a school bus on his property.

## Stacey Abrams spreading 'nonsense,' saying 6-week heartbeats are 'manufactured sound,' pro-life group says
 - [https://www.foxnews.com/politics/stacey-abrams-spreading-nonsense-saying-6-week-heartbeats-manufactured-sound-pro-life-group-says](https://www.foxnews.com/politics/stacey-abrams-spreading-nonsense-saying-6-week-heartbeats-manufactured-sound-pro-life-group-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:07:10+00:00

Heartbeat International said Stacey Abrams is using her platform to spread "nonsense" when she said fetal heartbeats are "manufactured sound."

## Rob Schneider surprises fans by working at chicken drive through to promote his new film ‘Daddy Daughter Trip’
 - [https://www.foxnews.com/entertainment/rob-schneider-surprises-fans-working-chicken-drive-through-promote-his-new-film-daddy-daughter-trip](https://www.foxnews.com/entertainment/rob-schneider-surprises-fans-working-chicken-drive-through-promote-his-new-film-daddy-daughter-trip)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:07:08+00:00

Rob Schneider surprised his fans by working in the Raising Cane's drive through and passing out free movie tickets. He was promoting his new movie "Daddy Daughter Trip."

## WSJ slams Rep. Tlaib for trying to incite a 'bank run' against J.P. Morgan after CEO rejects climate demands
 - [https://www.foxnews.com/media/wsj-slams-rep-tlaib-trying-incite-bank-run-against-jp-morgan-after-ceo-rejects-climate-demands](https://www.foxnews.com/media/wsj-slams-rep-tlaib-trying-incite-bank-run-against-jp-morgan-after-ceo-rejects-climate-demands)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:03:26+00:00

The Wall Street Journal editorial board criticized Rep. Rashida Tlaib for attempting to incite a 'bank run' on J.P. Morgan after its CEO refuted her climate demands.

## South Carolina 3-year-old accidentally shoots, kills mother after gaining access to unsecured gun, police say
 - [https://www.foxnews.com/us/south-carolina-3-year-old-accidentally-shoots-kills-mother-gaining-access-unsecured-gun-police-say](https://www.foxnews.com/us/south-carolina-3-year-old-accidentally-shoots-kills-mother-gaining-access-unsecured-gun-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 23:02:59+00:00

A three-year-old child got a hold of an unsecured gun and accidentally shot and killed its mother at a South Carolina home earlier Wednesday, according to police.

## Bucs' Tom Brady says throwing hand 'feels great' ahead of Packers matchup
 - [https://www.foxnews.com/sports/bucs-tom-brady-says-throwing-hand-feels-great-ahead-packers-matchup](https://www.foxnews.com/sports/bucs-tom-brady-says-throwing-hand-feels-great-ahead-packers-matchup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 22:35:44+00:00

Tom Brady told reporters after the Tampa Bay Buccaneers practice on Thursday that the ring finger on his throwing hand "feels great" after apparently hurting it during last week's win.

## Cowboys' Jerry Jones entertains idea that Cooper Rush could force QB controversy if he plays well
 - [https://www.foxnews.com/sports/cowboys-jerry-jones-entertains-idea-cooper-rush-could-force-qb-controversy-he-plays-well](https://www.foxnews.com/sports/cowboys-jerry-jones-entertains-idea-cooper-rush-could-force-qb-controversy-he-plays-well)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 22:30:06+00:00

If Cooper Rush runs off some wins while Dak Prescott is injured, Rush could challenge Prescott for the starting QB job going forward, Jerry Jones says.

## Inside Saudi Arabia's role freeing American POWs from Putin's prison
 - [https://www.foxnews.com/world/inside-saudi-arabias-role-freeing-american-pows-putins-prison](https://www.foxnews.com/world/inside-saudi-arabias-role-freeing-american-pows-putins-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 22:26:18+00:00

Two Americans were among 10 prisoners of war held by Russia freed on Wednesday. Saudi Arabia Crown Prince Mohammed bin Salman is credited with playing pivotal role in the release.

## Dr. Oz says he will release his medical records by the weekend, challenges Fetterman to do the same
 - [https://www.foxnews.com/media/dr-oz-release-medical-records-weekend-calls-fetterman-same](https://www.foxnews.com/media/dr-oz-release-medical-records-weekend-calls-fetterman-same)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 22:10:27+00:00

Dr. Mehmet Oz said his opponent John Fetterman’s recent health problems should raise concerns among voters about whether the candidate is fit for office.

## Super Bowl champ set to sign with Ravens: reports
 - [https://www.foxnews.com/sports/super-bowl-champ-sign-ravens-reports](https://www.foxnews.com/sports/super-bowl-champ-sign-ravens-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 22:02:27+00:00

Two-time Super Bowl champion Jason Pierre-Paul is signing with the Baltimore Ravens for the remainder of this season in a deal worth up to $5.5 million.

## Utah student arrested after allegedly threatening to cause ‘mass destruction’ if football team lost
 - [https://www.foxnews.com/sports/utah-student-arrested-allegedly-threatening-cause-mass-destruction-football-team-lost](https://www.foxnews.com/sports/utah-student-arrested-allegedly-threatening-cause-mass-destruction-football-team-lost)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:54:31+00:00

An engineering student at the University of Utah allegedly threatened to "cause mass destruction" if the school's football team lost to San Diego State.

## Flyers' Ryan Ellis likely to miss 2022-2023 season with possible career-threatening back injury
 - [https://www.foxnews.com/sports/flyers-ryan-ellis-likely-miss-2022-2023-season-possible-career-threatening-back-injury](https://www.foxnews.com/sports/flyers-ryan-ellis-likely-miss-2022-2023-season-possible-career-threatening-back-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:50:04+00:00

Philadelphia Flyers general manager Chuck Fletcher said veteran defenseman Eyan Ellis will likely miss the upcoming season due to a “multifaceted” back injury.

## Celtics' Joe Mazzulla may be interim head coach should Ime Udoka be suspended: reports
 - [https://www.foxnews.com/sports/celtics-joe-mazzulla-may-interim-head-coach-should-ime-udoka-suspended-reports](https://www.foxnews.com/sports/celtics-joe-mazzulla-may-interim-head-coach-should-ime-udoka-suspended-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:43:47+00:00

Ime Udoka is apparently in hot water over reports that he broke Boston Celtics' rules for having a relationship with a female staff member.

## Minneapolis gang violence intensifies after police defunding: 'It's like you're playing Russian roulette'
 - [https://www.foxnews.com/us/minneapolis-gang-violence-police-defunding-russian-roulette](https://www.foxnews.com/us/minneapolis-gang-violence-police-defunding-russian-roulette)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:41:32+00:00

In North Minneapolis, gangs run rampant and gunshots ring out nightly. Gangs are aware that cops are unlikely to take major action against them.

## Arizona Republicans trailing in key Senate, gubernatorial races: New AARP poll
 - [https://www.foxnews.com/politics/arizona-republicans-trailing-senate-gubernatorial-races-aarp-poll](https://www.foxnews.com/politics/arizona-republicans-trailing-senate-gubernatorial-races-aarp-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:40:12+00:00

A new AARP poll shows Arizona Republicans trailing in the state's Senate and gubernatorial races ahead of November's general election.

## Washington Post fact-checker slammed for calling ‘fetal heartbeat’ a ‘misnomer’ in defense of Stacey Abrams
 - [https://www.foxnews.com/media/washington-post-fact-checker-slammed-calling-fetal-heartbeat-misnomer-defense-stacey-abrams](https://www.foxnews.com/media/washington-post-fact-checker-slammed-calling-fetal-heartbeat-misnomer-defense-stacey-abrams)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:33:09+00:00

Washington Post chief fact-checker Glenn Kessler tweeted on Thursday that the "fetal heartbeat" is a misnomer and it's really just the sound the ultrasound makes.

## Adam Levine still set to perform in Las Vegas with Maroon 5 amid cheating scandal
 - [https://www.foxnews.com/entertainment/adam-levine-set-perform-las-vegas-maroon-5-amid-cheating-scandal](https://www.foxnews.com/entertainment/adam-levine-set-perform-las-vegas-maroon-5-amid-cheating-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:27:16+00:00

Adam Levine and Maroon 5 are still set to perform in Las Vegas in October as the musician continues to battle his cheating and flirtatious messages scandal.

## Special Master taps retired judge with ‘Top Secret’ clearance to aid in review of seized Mar-a-Lago records
 - [https://www.foxnews.com/politics/special-master-taps-retired-judge-with-top-secret-clearance-to-aid-in-review-of-seized-mar-a-lago-records](https://www.foxnews.com/politics/special-master-taps-retired-judge-with-top-secret-clearance-to-aid-in-review-of-seized-mar-a-lago-records)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:27:00+00:00

Special Master Raymond Dearie has tapped a retired judge who served as an impartial adviser to the FISA court to assist in the review of records seized by the FBI from Mar-a-Lago.

## Predators hire former goalie Pekka Rinne as special alumni adviser
 - [https://www.foxnews.com/sports/predators-hire-former-goalie-pekka-rinne-special-alumni-adviser](https://www.foxnews.com/sports/predators-hire-former-goalie-pekka-rinne-special-alumni-adviser)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:17:38+00:00

The Nashville Predators are set to hire former goalie Pekka Rinne as a special alumni adviser following his retirement from the NHL in 2021.

## First day of fall 2022: What to know about the autumn equinox
 - [https://www.foxnews.com/lifestyle/first-day-fall-what-know-autumn-equinox](https://www.foxnews.com/lifestyle/first-day-fall-what-know-autumn-equinox)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:13:27+00:00

The first day of fall 2022 starts with the autumnal equinox. Here's what you should know about the change of season, and what time it typically happens.

## Abortion ‘losing ground’ to issues that ‘favor Republicans’ in Google searches, Axios reports
 - [https://www.foxnews.com/media/abortion-losing-ground-issues-favor-republicans-google-searches-axios-reports](https://www.foxnews.com/media/abortion-losing-ground-issues-favor-republicans-google-searches-axios-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:05:35+00:00

Axios reported on Thursday that Google searches on crime and immigration have surpassed searches on abortion and the FBI Mar-a-Lago raid ahead of the midterm elections.

## Slain LSU student Allie Rice was not targeted by gang, police say
 - [https://www.foxnews.com/us/slain-lsu-student-allie-rice-gang-police](https://www.foxnews.com/us/slain-lsu-student-allie-rice-gang-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:04:50+00:00

The Baton Rouge mayor and police department gave a press conference Thursday on violent crime — one day after hundreds mourned slain LSU student Allison "Allie" Rice at her funeral.

## Will Patrick Dempsey and Ellen Pompeo reunite?
 - [https://www.foxnews.com/entertainment/patrick-dempsey-ellen-pompeo-reunite](https://www.foxnews.com/entertainment/patrick-dempsey-ellen-pompeo-reunite)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:02:24+00:00

Actor Patrick Dempsey said during a recent interview he wants to work with Ellen Pompeo again. Dempsey starred as Derek "McDreamy" in "Grey's Anatomy."

## Packers’ Aaron Rodgers won’t play to 45 like Tom Brady, cites 'interests outside the game''
 - [https://www.foxnews.com/sports/packers-aaron-rodgers-wont-play-45-tom-brady-cites-interest-outside-games](https://www.foxnews.com/sports/packers-aaron-rodgers-wont-play-45-tom-brady-cites-interest-outside-games)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 21:01:19+00:00

Green Bay quarterback Aaron Rodgers said he has no intention of playing until the age of 45 like Tampa Bay Buccaneers quarterback Tom Brady has.

## China to blame for fentanyl crisis, covering up COVID says DeSantis
 - [https://www.foxnews.com/politics/china-blame-fentanyl-crisis-covering-covid-desantis](https://www.foxnews.com/politics/china-blame-fentanyl-crisis-covering-covid-desantis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 20:55:18+00:00

Florida Gov. Ron DeSantis on Wednesday blamed China for the amount of fentanyl making its way into the United States.

## NCAA hands LSU football 1-year probation for former coach's recruiting violation
 - [https://www.foxnews.com/sports/ncaa-hands-lsu-football-1-year-probation-former-coachs-recruiting-violation](https://www.foxnews.com/sports/ncaa-hands-lsu-football-1-year-probation-former-coachs-recruiting-violation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 20:42:34+00:00

Following an investigation, the NCAA gives LSU's football program one year probation, following former offensive line coach James Cregg violation of recruiting rules in 2020.

## 'The Bodyguard' returning to theaters 30 years after debut
 - [https://www.foxnews.com/entertainment/the-bodyguard-returning-to-theaters-30-years-after-debut](https://www.foxnews.com/entertainment/the-bodyguard-returning-to-theaters-30-years-after-debut)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 20:40:07+00:00

"The Bodyguard," which starred Kevin Costner and Whitney Houston in 1992, is returning to theaters for two days in November, 30 years after its original release.

## Italy's population may shrink by 11 million people within 50 years, study shows
 - [https://www.foxnews.com/world/italys-population-shrink-11-million-people-50-years-study-shows](https://www.foxnews.com/world/italys-population-shrink-11-million-people-50-years-study-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 20:39:57+00:00

Italy may see a smaller population in the next five decades, a study shows. The country is expected to shrink by 20% or 11 million people.

## GOP trashes Dem public safety bills as attempt to hide past support for ‘defund the police’
 - [https://www.foxnews.com/politics/gop-trashes-dem-public-safety-bills-attempt-to-hide-past-support-defund-police](https://www.foxnews.com/politics/gop-trashes-dem-public-safety-bills-attempt-to-hide-past-support-defund-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 20:39:38+00:00

Republicans say the midterm elections prompted Democrats to create the appearance that they support local policing efforts.

## ‘Avatar’ sequel to focus on a theme of family
 - [https://www.foxnews.com/entertainment/avatar-sequel-focus-theme-family](https://www.foxnews.com/entertainment/avatar-sequel-focus-theme-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 20:38:59+00:00

“Avatar,” the top-grossing movie of all time, will return to the theaters with a sequel, “Avatar: The Way of Water,” in December. The film will focus on a theme of protecting family.

## Facebook whistleblower launches nonprofit to address harms created by social media
 - [https://www.foxnews.com/tech/facebook-whistleblower-launches-nonprofit-address-harms-created-social-media](https://www.foxnews.com/tech/facebook-whistleblower-launches-nonprofit-address-harms-created-social-media)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 20:38:08+00:00

Facebook whistleblower Frances Haugen, who has detailed how the tech company failed their ethical obligations, launched a nonprofit to solve social media harms.

## Ohio parents concerned by teacher badges linking to sexually explicit material
 - [https://www.foxnews.com/media/ohio-parents-concerned-teacher-badges-linking-sexually-explicit-material](https://www.foxnews.com/media/ohio-parents-concerned-teacher-badges-linking-sexually-explicit-material)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 20:37:57+00:00

Parents in Hilliard, Ohio, are upset by QR code-enabled badges worn by some teachers to reach out to LGBTQ+ students that links to sexually explicit material.

## Dems attack GOP candidate over women's suffrage posts after spending nearly $500K to help him win primary
 - [https://www.foxnews.com/politics/dems-attack-gop-candidate-over-womens-suffrage-posts-after-spending-nearly-500000-help-him-win-primary](https://www.foxnews.com/politics/dems-attack-gop-candidate-over-womens-suffrage-posts-after-spending-nearly-500000-help-him-win-primary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 20:34:26+00:00

Democrats called on the GOP to denounce John Gibbs for his comments on women voting after the DCCC funneled hundreds of thousands into boosting his primary campaign.

## Texas county sheriff’s office arrests precinct chief in undercover prostitution sting operation
 - [https://www.foxnews.com/us/texas-county-sheriffs-office-arrests-precinct-chief-undercover-prostitution-sting-operation](https://www.foxnews.com/us/texas-county-sheriffs-office-arrests-precinct-chief-undercover-prostitution-sting-operation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 20:33:56+00:00

A Harris County, Texas, precinct chief was among more than a dozen arrested Wednesday evening in an undercover prostitution sting operation, authorities said.

## US-backed forces in Syria foil 'massive' suicide bombing attack in refugee camp
 - [https://www.foxnews.com/world/us-backed-forces-syria-foil-massive-suicide-bombing-attack-refugee-camp](https://www.foxnews.com/world/us-backed-forces-syria-foil-massive-suicide-bombing-attack-refugee-camp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 20:27:04+00:00

The U.S.-backed Syrian Democratic Forces foiled what would have been a devastating suicide bombing attack Thursday, halting two vehicles full of extremists.

## Biden pledges aid for Puerto Rico in aftermath of Hurricane Fiona; 'We are not just going to walk away'
 - [https://www.foxnews.com/politics/biden-pledges-puerto-rico-aid-aftermath-hurricane-fiona](https://www.foxnews.com/politics/biden-pledges-puerto-rico-aid-aftermath-hurricane-fiona)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 19:41:55+00:00

President Biden said he will send aid to Puerto Rico as it recovers from Hurricane Fiona while New York and other states have also pledge to send relief.

## Josh Shapiro stresses need for safety, says abortion 'on people's minds' ahead of Pennsylvania election
 - [https://www.foxnews.com/politics/josh-shapiro-stresses-need-safety-says-abortion-peoples-minds-ahead-pennsylvania-election](https://www.foxnews.com/politics/josh-shapiro-stresses-need-safety-says-abortion-peoples-minds-ahead-pennsylvania-election)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 19:40:32+00:00

Pennsylvania Democratic gubernatorial candidate Josh Shapiro says safety is of utmost importance to him and suggested that abortion will play a factor in the midterms.

## 4th defendant of a white supremacist group pleads guilty to hate crime
 - [https://www.foxnews.com/us/4th-defendant-white-supremacist-group-pleads-guilty-hate-crime](https://www.foxnews.com/us/4th-defendant-white-supremacist-group-pleads-guilty-hate-crime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 19:39:46+00:00

A fourth defendant pleaded guilty to a racist attack. The defendants were members of a white supremacist group who beat up a Black man north of Seattle while yelling racist slurs.

## Nets’ Ben Simmons explains infamous pass against Hawks in 2021 NBA playoffs
 - [https://www.foxnews.com/sports/nets-ben-simmons-explains-infamous-pass-against-hawks-2021-nba-playoffs](https://www.foxnews.com/sports/nets-ben-simmons-explains-infamous-pass-against-hawks-2021-nba-playoffs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 19:35:55+00:00

Former Philadelphia 76er and current Brooklyn Net Ben Simmons explained his infamous decision to pass up a dunk in Game 7 of the 2021 Eastern Conference Semifinals.

## Rep. Cammack bill would allow DHS to suspend migrant entry during surges, terror threats
 - [https://www.foxnews.com/politics/rep-cammack-bill-allow-dhs-suspend-migrant-entry-during-surges-terror-threats](https://www.foxnews.com/politics/rep-cammack-bill-allow-dhs-suspend-migrant-entry-during-surges-terror-threats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 19:35:38+00:00

Rep. Kat Cammack, R-Fla., is introducing legislation to broaden DHS' ability to block the entry of migrants into the U.S. in the case of a border surge or pandemic.

## Former Phoenix police officer sentenced in fraud case, ordered to pay $1 million in restitution
 - [https://www.foxnews.com/us/former-phoenix-police-officer-sentenced-fraud-case-ordered-pay-1-million-restitution](https://www.foxnews.com/us/former-phoenix-police-officer-sentenced-fraud-case-ordered-pay-1-million-restitution)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 19:33:22+00:00

A former police officer in Phoenix, Arizona, was sentenced to federal prison for filing a false application for PPP money. He received and improperly spent over $1.2 million.

## Former Chinese justice minister sentenced to death for helping criminals, taking bribes
 - [https://www.foxnews.com/us/former-chinese-justice-minister-sentenced-death-helping-criminals-taking-bribes](https://www.foxnews.com/us/former-chinese-justice-minister-sentenced-death-helping-criminals-taking-bribes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 19:25:55+00:00

A Chinese justice minister has been sentenced to death for taking bribes and helping criminals. One of the criminals he helped was his brother.

## Vietnam Veterans Memorial in Washington vandalized, wreath and name directory burned
 - [https://www.foxnews.com/us/vietnam-veterans-memorial-washington-vandalized-wreath-name-directory-burned](https://www.foxnews.com/us/vietnam-veterans-memorial-washington-vandalized-wreath-name-directory-burned)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 19:25:29+00:00

The Vietnam Veterans Memorial in Washington, D.C., was struck by vandalism on Tuesday. On the same day, a man was arrested for vandalizing the Washington Monument.

## Demings to skip Biden's Florida visit, will be in DC with House not in session
 - [https://www.foxnews.com/politics/demings-skip-biden-florida-visit-dc-house-not-session](https://www.foxnews.com/politics/demings-skip-biden-florida-visit-dc-house-not-session)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 19:23:35+00:00

Rep. Val Demings will not be appearing alongside President Biden during his visit to her hometown of Orlando, even though the House will not be in session.

## Florida trail attack suspect seen approaching jogger in chilling surveillance video arrested
 - [https://www.foxnews.com/us/florida-trail-attack-suspect-seen-approaching-jogger-chilling-surveillance-video-arrested](https://www.foxnews.com/us/florida-trail-attack-suspect-seen-approaching-jogger-chilling-surveillance-video-arrested)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 19:22:37+00:00

Chilling surveillance video and a hat left at the scene led Florida investigators to the 19-year-old suspect now charged with attacking a 22-year-old jogger on a walking trail.

## Portland's Board of Education upsets parents with school choice vote
 - [https://www.foxnews.com/media/portlands-board-education-upsets-parents-school-choice-vote](https://www.foxnews.com/media/portlands-board-education-upsets-parents-school-choice-vote)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 19:14:00+00:00

At a board meeting in Portland, Maine, parents were upset to find out that the school board changed the district's high school admissions policy, which ends school choice after 43 years.

## Bill to name Atlanta's main post office after late civil rights leader John Lewis close to becoming law
 - [https://www.foxnews.com/us/bill-name-atlantas-main-post-office-late-civil-rights-leader-john-lewis-close-becoming-law](https://www.foxnews.com/us/bill-name-atlantas-main-post-office-late-civil-rights-leader-john-lewis-close-becoming-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 18:32:31+00:00

A bill that passed the U.S. Senate Wednesday and is close to becoming law will name Atlanta's main post office after late congressman and civil rights leader John Lewis

## North Dakota woman who brought raccoon into bar facing criminal charges
 - [https://www.foxnews.com/us/north-dakota-woman-brought-raccoon-bar-facing-criminal-charges](https://www.foxnews.com/us/north-dakota-woman-brought-raccoon-bar-facing-criminal-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 18:31:48+00:00

A North Dakota woman who brought a raccoon into a bar is now facing criminal charges. She allegedly provided false information to law enforcement.

## School board races get national attention as Youngkin mulls endorsements
 - [https://www.foxnews.com/politics/school-board-races-get-national-attention-youngkin-mulls-endorsements](https://www.foxnews.com/politics/school-board-races-get-national-attention-youngkin-mulls-endorsements)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 18:26:41+00:00

School board races in states including Florida, Pennsylvania and Texas are getting endorsements from PACs and governors as the politics of education resonates.

## Greek authorities search for 6 migrants reported missing at sea
 - [https://www.foxnews.com/world/greek-authorities-search-6-migrants-reported-missing-sea](https://www.foxnews.com/world/greek-authorities-search-6-migrants-reported-missing-sea)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 18:26:03+00:00

The Greek coast guard launched a search and rescue for six migrants from Turkey who were reported missing on Thursday after a boat arrived.

## Trump ally Tom Barrack dismisses foreign agent allegations as NYC trial opens: 'Nothing short of ridiculous'
 - [https://www.foxnews.com/politics/trump-ally-tom-barrack-dismisses-foreign-agent-allegations-nyc-trial-opens-nothing-short-ridiculous](https://www.foxnews.com/politics/trump-ally-tom-barrack-dismisses-foreign-agent-allegations-nyc-trial-opens-nothing-short-ridiculous)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 18:25:08+00:00

The lawyer for California billionaire and former Trump campaign adviser Tom Barrack said claims his client acted as a foreign agent for the UAE were "nothing short of ridiculous."

## Milwaukee hospital ends religious exemption for COVID-19 vaccine
 - [https://www.foxnews.com/us/milwaukee-hospital-ends-religious-exemption-covid-19-vaccine](https://www.foxnews.com/us/milwaukee-hospital-ends-religious-exemption-covid-19-vaccine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 18:20:38+00:00

The religious exemption for the COVID-19 vaccine has ended at Froedtert Health, a Milwaukee-based health care provider. Employees are now required to get the shot.

## Twitter users baffled after Stacy Abrams claims no fetal heartbeat at six weeks: 'Wild conspiracy theory'
 - [https://www.foxnews.com/media/twitter-users-baffled-stacy-abrams-claims-no-fetal-heartbeat-six-weeks-wild-conspiracy-theory](https://www.foxnews.com/media/twitter-users-baffled-stacy-abrams-claims-no-fetal-heartbeat-six-weeks-wild-conspiracy-theory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 18:16:44+00:00

Stacey Abrams prompted outrage on the right after claiming that a fetal heartbeat at six weeks was a "manufactured sound" meant to control a woman's body.

## Fauci admits 'certain aspects' of the government's COVID-19 response were 'botched'
 - [https://www.foxnews.com/politics/fauci-admits-certain-aspects-governments-covid-19-response-botched](https://www.foxnews.com/politics/fauci-admits-certain-aspects-governments-covid-19-response-botched)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 18:14:38+00:00

National Institute of Allergy and Infectious Diseases Director Anthony Fauci said "certain aspects" of the government's response to COVID-19 were "botched."

## CIA's first podcast disses Russia as a 'declining' power, warns China is a 'central geopolitical challenge'
 - [https://www.foxnews.com/politics/cia-director-warns-declining-powers-like-russia-disruptive-rising-ones-launch-podcast](https://www.foxnews.com/politics/cia-director-warns-declining-powers-like-russia-disruptive-rising-ones-launch-podcast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 18:11:05+00:00

CIA Director William Burns said “declining powers,” like Russia, are “as disruptive as rising ones,” warning that China is a “central geopolitical challenge” for the U.S.

## Earthquake in Mexico creates 'desert tsunami' 1,500 miles away in Death Valley National Park
 - [https://www.foxnews.com/science/earthquake-mexico-creates-desert-tsunami-1500-miles-away-death-valley-national-park](https://www.foxnews.com/science/earthquake-mexico-creates-desert-tsunami-1500-miles-away-death-valley-national-park)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 18:08:00+00:00

Waves were triggered in the Devils Hole cave system at Death Valley National Park in Arizona by a 7.6 magnitude earthquake that struck western Mexico about 1,500 miles away.

## NBC’s ‘Today’ stuns, delights pro-lifers with segment referring to ‘babies in the womb'
 - [https://www.foxnews.com/media/nbcs-today-stuns-delights-pro-lifers-segment-referring-babies-womb](https://www.foxnews.com/media/nbcs-today-stuns-delights-pro-lifers-segment-referring-babies-womb)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 17:39:31+00:00

Conservatives expressed shock as a segment of NBC "Today" referred to unborn babies as "babies in the womb" and gushed over their sensory capabilities.

## Texas tractor trailer truck careens off overpass, driver killed in fiery crash
 - [https://www.foxnews.com/us/texas-tractor-trailer-truck-careens-overpass-driver-killed-fiery-crash](https://www.foxnews.com/us/texas-tractor-trailer-truck-careens-overpass-driver-killed-fiery-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 17:39:16+00:00

Video shows a tractor trailer truck plunging off a freeway overpass in Texas, flipping and bursting into flames. The driver who died has been identified.

## Olivia Wilde addresses rumor Harry Styles spit on Chris Pine in Venice: 'People will look for drama'
 - [https://www.foxnews.com/entertainment/olivia-wilde-addresses-rumor-harry-styles-spit-chris-pine-venice-people-will-look-drama](https://www.foxnews.com/entertainment/olivia-wilde-addresses-rumor-harry-styles-spit-chris-pine-venice-people-will-look-drama)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 17:35:27+00:00

Olivia Wilde addressed the rumor that Harry Styles spit on Chris Pine at the premiere of "Don't Worry Darling" during an appearance on "The Late Show with Stephen Colbert."

## El Salvador landslide kills at least 7 following 4 days of heavy rain
 - [https://www.foxnews.com/world/el-salvador-landslide-kills-least-7-following-4-days-heavy-rain](https://www.foxnews.com/world/el-salvador-landslide-kills-least-7-following-4-days-heavy-rain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 17:34:59+00:00

A landslide in El Salvador is confirmed to have killed at least seven people following four days of heavy rains. Authorities continue to search for more people trapped in the disaster.

## Manchin energy proposal picks up key GOP vote but still faces tough path to passage
 - [https://www.foxnews.com/politics/manchin-energy-proposal-picks-up-key-gop-vote-still-faces-tough-path-passage](https://www.foxnews.com/politics/manchin-energy-proposal-picks-up-key-gop-vote-still-faces-tough-path-passage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 17:32:55+00:00

Sen. Shelley Moore Capito Thursday said she will vote for a continuing resolution with an energy permitting reform plan from Sen. Joe Manchin included.

## Georgia teen suffered 'critical medical emergency' during flag football game before death: report
 - [https://www.foxnews.com/sports/georgia-teen-suffered-critical-medical-emergency-flag-football-game-before-death-report](https://www.foxnews.com/sports/georgia-teen-suffered-critical-medical-emergency-flag-football-game-before-death-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 17:30:41+00:00

A Georgia teen who died during a flag football game reportedly suffered a "critical medical emergency," school officials said in a letter.

## Dr. Saphier, 'Outnumbered' roast Stacey Abrams for claim about fetal ultrasounds: 'This is a flat-out lie'
 - [https://www.foxnews.com/media/dr-saphier-outnumbered-roast-stacey-abrams-claim-fetal-ultrasounds-flat-lie](https://www.foxnews.com/media/dr-saphier-outnumbered-roast-stacey-abrams-claim-fetal-ultrasounds-flat-lie)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 17:29:39+00:00

Fox News medical contributor Dr. Nicole Saphier called out Stacey Abrams on 'Outnumbered' after she said a six-week fetal heartbeat is a 'manufactured sound'

## New York's strict gun laws leave veterans fearful they could wind up in jail over 21-gun funeral salute
 - [https://www.foxnews.com/us/new-yorks-strict-gun-laws-veterans-fearful-jail-21-gun-funeral-salute](https://www.foxnews.com/us/new-yorks-strict-gun-laws-veterans-fearful-jail-21-gun-funeral-salute)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 17:24:30+00:00

The commander of the American Legion Department of New York spoke out about concerns regarding firing 21-gun salutes after the state's strict gun laws were rolled out this month.

## Czech government won't issue Russian NHL players visas ahead 2022 Global Series in Prague
 - [https://www.foxnews.com/sports/czech-government-wont-issue-russian-nhl-players-visas-ahead-2022-global-series-prague](https://www.foxnews.com/sports/czech-government-wont-issue-russian-nhl-players-visas-ahead-2022-global-series-prague)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 17:19:49+00:00

The Czech Foreign Ministry Office sent a letter to the NHL informing the league that it is not issuing visas to Russian players ahead the 2022 Global Series games in Prague next month.

## Mandela Barnes endorsed by leftist environmental group that popularized Green New Deal
 - [https://www.foxnews.com/politics/mandela-barnes-endorsed-leftist-environmental-group-popularized-green-new-deal](https://www.foxnews.com/politics/mandela-barnes-endorsed-leftist-environmental-group-popularized-green-new-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 16:31:29+00:00

Wisconsin Democratic Senate nominee Mandela Barnes has been endorsed by a group that champions the Green New Deal and takes aim at Democrats who do not support their climate agenda.

## Will Cain calls out Stacey Abrams' abortion 'conspiracy': 'This is someone we're supposed to take seriously?'
 - [https://www.foxnews.com/media/will-cain-calls-stacey-abrams-abortion-conspiracy-someone-supposed-take-seriously](https://www.foxnews.com/media/will-cain-calls-stacey-abrams-abortion-conspiracy-someone-supposed-take-seriously)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 16:21:14+00:00

'Fox & Friends Weekend' host Will Cain calls out Stacey Abrams' conspiratorial comments about ultrasound machines and abortions.

## DeSantis-linked plan to fly migrants to Delaware falls through: report
 - [https://www.foxnews.com/us/desantis-linked-plan-fly-migrants-delaware-falls-through-report](https://www.foxnews.com/us/desantis-linked-plan-fly-migrants-delaware-falls-through-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 16:19:55+00:00

Florida Gov. Ron Desantis's long-rumored transport flight relocating illegal migrants from Texas and Florida to Delaware failed to materialize this week.

## Former MSNBC host Chris Matthews, who pushed Russia theories: 'We have honest elections in this country'
 - [https://www.foxnews.com/media/msnbcs-chris-matthews-pushed-russia-theories-honest-elections-country](https://www.foxnews.com/media/msnbcs-chris-matthews-pushed-russia-theories-honest-elections-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 16:17:52+00:00

MSNBC's former "Hardball" host Chris Matthews joined the hosts of "Morning Joe" on Thursday and repeatedly emphasized "we have honest elections in this country."

## Technicians in Ukraine in a race against time to remove unexploded land mines before winter
 - [https://www.foxnews.com/media/technicians-ukraine-race-against-time-remove-unexploded-land-mines-winter](https://www.foxnews.com/media/technicians-ukraine-race-against-time-remove-unexploded-land-mines-winter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 16:15:19+00:00

Fox News' Jeff Paul speaks to technicians dedicated to the dangerous task of removing unexploded Russian ordnances before the ground freezes in Ukraine.

## Washington employees may get $1K for receiving COVID-19 booster
 - [https://www.foxnews.com/us/washington-employees-1k-receiving-covid-19-booster](https://www.foxnews.com/us/washington-employees-1k-receiving-covid-19-booster)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 16:14:45+00:00

Washington workers may get a $1,000 bonus if they receive a COVID-19 booster shot, according to a tentative state deal. The agreement also includes pay raises and a retention bonus.

## Oregon State Hospital fined $54K for not investigating workplace injuries
 - [https://www.foxnews.com/us/oregon-state-hospital-fined-54k-not-investigating-workplace-injuries](https://www.foxnews.com/us/oregon-state-hospital-fined-54k-not-investigating-workplace-injuries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 16:13:56+00:00

The Oregon State Hospital was fined $54,000 by the Occupational Safety and Health Administration for not looking into every injury that caused its employees to miss work.

## Man who slapped Rudy Giuliani on the back accepts plea deal
 - [https://www.foxnews.com/us/man-who-slapped-rudy-giuliani-back-accepts-plea-deal](https://www.foxnews.com/us/man-who-slapped-rudy-giuliani-back-accepts-plea-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 16:10:30+00:00

The man who was caught on video slapping Rudy Giuliani on the back has accepted a plea deal, having his charges dropped in six months if he stays out of trouble during that time.

## Trump to Hannity: Presidents can declassify documents 'by thinking about it'
 - [https://www.foxnews.com/politics/trump-hannity-presidents-can-declassify-documents-thinking-about-it](https://www.foxnews.com/politics/trump-hannity-presidents-can-declassify-documents-thinking-about-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 16:10:03+00:00

Former President Donald Trump says he could declassify documents just by "thinking" about it. Trump is facing a criminal probe into whether he mishandled classified documents.

## Eagles rookie says he was denied access to players' parking lot before home opener
 - [https://www.foxnews.com/sports/eagles-rookie-says-he-was-denied-access-players-parking-lot-home-opener](https://www.foxnews.com/sports/eagles-rookie-says-he-was-denied-access-players-parking-lot-home-opener)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 15:34:38+00:00

Britain Covey going back and forth between the active roster and the practice squad may have cost him a spot in the players' lot on Monday night.

## Hawley probes Pentagon over 'alarming' mishandling of religious exemptions to the COVID vaccine
 - [https://www.foxnews.com/politics/hawley-probes-pentagon-alarming-mishandling-religious-exemptions-covid-vaccine](https://www.foxnews.com/politics/hawley-probes-pentagon-alarming-mishandling-religious-exemptions-covid-vaccine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 15:34:08+00:00

Senator Josh Hawley is asking for information from the Pentagon related to an internal investigation into the handling of service members requests for exemptions to the vaccine on religious grounds.

## Many New Mexico residents to no longer qualify for Medicaid
 - [https://www.foxnews.com/us/many-new-mexico-residents-longer-qualify-medicaid](https://www.foxnews.com/us/many-new-mexico-residents-longer-qualify-medicaid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 15:32:52+00:00

Up to 100,000 New Mexico residents will no longer be qualified for Medicaid health care as the state phases out special pandemic-era spending and curtail enrollment.

## New Hampshire Senate showdown: Hassan leading Bolduc by 8 points in crucial battleground state
 - [https://www.foxnews.com/politics/new-hampshire-senate-showdown-hassan-leading-bolduc-8-points-crucial-battleground-state](https://www.foxnews.com/politics/new-hampshire-senate-showdown-hassan-leading-bolduc-8-points-crucial-battleground-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 15:31:42+00:00

A new poll in the key swing state of New Hampshire indicates Democratic Sen. Maggie Hassan with an 8-point lead over her Republican challenger, former Army Gen. Don Bolduc

## The end is near for Putin's war against Ukraine
 - [https://www.foxnews.com/opinion/end-near-putin-war-against-ukraine](https://www.foxnews.com/opinion/end-near-putin-war-against-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 15:31:02+00:00

Putin said he will call up reservists and he threatened to use nuclear weapons if Russian territory is in danger. But Putin isn't fooling anybody.

## Retired NYPD officer rescues driver who crashed convertible into North Carolina lake
 - [https://www.foxnews.com/us/retired-nypd-officer-rescues-driver-crashed-convertible-north-carolina-lake](https://www.foxnews.com/us/retired-nypd-officer-rescues-driver-crashed-convertible-north-carolina-lake)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 15:30:37+00:00

A retired New York City police officer rescued a driver from a sinking convertible that crashed into Lake Norman in Mooresville, North Carolina, on Wednesday.

## 1 dead, 1 injured in NC glider crash off Outer Banks coast
 - [https://www.foxnews.com/us/1-dead-1-injured-nc-glider-crash-off-outer-banks-shore](https://www.foxnews.com/us/1-dead-1-injured-nc-glider-crash-off-outer-banks-shore)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 15:28:07+00:00

An ultralight glider crash killed a person and left another injured in North Carolina. The accident took place off of the Outer Banks coast.

## Kanye West apologizes to Kim Kardashian, says he had to 'scream' for rights to parent his kids
 - [https://www.foxnews.com/entertainment/kanye-west-apologizes-kim-kardashian-says-had-to-scream-for-rights-to-parent-his-kids](https://www.foxnews.com/entertainment/kanye-west-apologizes-kim-kardashian-says-had-to-scream-for-rights-to-parent-his-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 15:26:14+00:00

Kanye West apologized to Kim Kardashian for any "stress" he caused her, but also said he had to 'scream' to be heard about his children. He also talked political aspirations.

## Portland candidate fined $77K for accepting illegal contributions
 - [https://www.foxnews.com/us/portland-candidate-fined-77k-accepting-illegal-contributions](https://www.foxnews.com/us/portland-candidate-fined-77k-accepting-illegal-contributions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 15:19:44+00:00

A man running for the Portland City Council will be fined $77K for accepting a 96% discounted rental office, which is over the legal limit under the campaign finance program.

## James Webb Space Telescope captures stunning image of Neptune, rings
 - [https://www.foxnews.com/science/james-webb-space-telescope-captures-stunning-image-neptune-rings](https://www.foxnews.com/science/james-webb-space-telescope-captures-stunning-image-neptune-rings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 15:16:52+00:00

NASA shared stunning images from the James Webb Space Telescope of Neptune and its surrounding rings. The ice giant and its moons were captured in infrared light.

## Indiana abortion ban put on hold after being in effect for a week
 - [https://www.foxnews.com/us/indiana-abortion-ban-put-hold-after-being-effect-week](https://www.foxnews.com/us/indiana-abortion-ban-put-hold-after-being-effect-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 14:43:26+00:00

An Indiana Judge blocked the state's abortion ban on Thursday. The law has been put on hold as abortion clinic operators say the law violates the state's constitution.

## ND driver charged after fatally hitting teen with SUV, stemmed from political argument
 - [https://www.foxnews.com/us/nd-driver-charged-fatally-hitting-teen-suv-stemmed-political-argument](https://www.foxnews.com/us/nd-driver-charged-fatally-hitting-teen-suv-stemmed-political-argument)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 14:42:16+00:00

A North Dakota man has been charged after he hit a teen with his SUV. The man told investigators he hit the teen on purpose following a political argument.

## Oil tanker catches fire off Gulf of Finland, crew extinguishes the flames
 - [https://www.foxnews.com/world/oil-tanker-catches-fire-off-gulf-finland-crew-extinguishes-flames](https://www.foxnews.com/world/oil-tanker-catches-fire-off-gulf-finland-crew-extinguishes-flames)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 14:40:28+00:00

An 820-foot oil tanker burst into flames in the Gulf of Finland, but the crew was able to put out the blaze before anyone was injured. Estonian officials are investigating.

## Reporter calls out Biden admin, liberals as children are abandoned at border: Where is the outrage?
 - [https://www.foxnews.com/media/reporter-calls-biden-admin-liberals-children-abandoned-border-outrage](https://www.foxnews.com/media/reporter-calls-biden-admin-liberals-children-abandoned-border-outrage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 14:38:29+00:00

Daily Caller field reporter Jorge Ventura highlights hypocritical outrage from the left on the border crisis and says President Biden's policies encourage this 'humanitarian crisis.'

## Iran protest: 9 dead in escalating unrest as demonstrators set fire to police stations, stab regime enforcer
 - [https://www.foxnews.com/world/iran-protest-dead-escalating-unrest-demonstrators-set-fire-police-stations-stab-regime-enforcer](https://www.foxnews.com/world/iran-protest-dead-escalating-unrest-demonstrators-set-fire-police-stations-stab-regime-enforcer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 14:36:47+00:00

Nine people have been killed as protests against the death of Mahsa Amini escalate in Iran, where the Islamist regime cut access to social media.

## South Korean President Yoon's profane reaction to Biden speech caught on hot mic
 - [https://www.foxnews.com/world/south-korean-president-yoon-profane-reaction-to-biden-speech-caught-on-hot-mic](https://www.foxnews.com/world/south-korean-president-yoon-profane-reaction-to-biden-speech-caught-on-hot-mic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 14:32:41+00:00

South Korean President Yoon Suk-yeol made a profane comment on a hot mic Wednesday after speaking with President Biden at the United Nations General Assembly.

## Washington Post column calls DeSantis' 'cruel' Martha's Vineyard stunt an effort to distract from abortion
 - [https://www.foxnews.com/media/washington-post-column-calls-desantis-cruel-marthas-vineyard-stunt-effort-distract-abortion](https://www.foxnews.com/media/washington-post-column-calls-desantis-cruel-marthas-vineyard-stunt-effort-distract-abortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 14:31:22+00:00

A Washington Post columnist claimed that Gov. Ron DeSantis pulled off the "cruel stunt" of relocating migrants to distract from his political weaknesses.

## Chicago teen charged with attempted murder after allegedly opening fire on police officers
 - [https://www.foxnews.com/us/chicago-teen-charged-attempted-murder-opening-fire-police-officers](https://www.foxnews.com/us/chicago-teen-charged-attempted-murder-opening-fire-police-officers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 14:28:14+00:00

Chicago police arrested a 16-year-old male and recovered a rifle after the teen allegedly fired shots toward officers responding to a call on Tuesday night.

## Philadelphia police officer convicted of manslaughter after shooting unarmed Black motorist
 - [https://www.foxnews.com/us/philadelphia-police-officer-convicted-manslaughter-after-shooting-unarmed-black-motorist](https://www.foxnews.com/us/philadelphia-police-officer-convicted-manslaughter-after-shooting-unarmed-black-motorist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 14:16:15+00:00

A Philadelphia police officer has been convicted of voluntary manslaughter after fatally shooting an unarmed Black motorist just six seconds after arriving on the scene.

## Federal judge rules Rhode Island must end truck tolling program within 48 hours
 - [https://www.foxnews.com/us/federal-judge-rules-ri-must-end-truck-tolling-program-within-48-hours](https://www.foxnews.com/us/federal-judge-rules-ri-must-end-truck-tolling-program-within-48-hours)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 14:15:05+00:00

A federal judge ruled that Rhode Island must end its truck tolling system within 48 hours, claiming the program unfairly targets out-of-state truckers and is unconstitutional.

## South Dakota AG Mark Vargo prepared to hire law enforcement officer for missing Indigenous people
 - [https://www.foxnews.com/us/south-dakota-ag-mark-vargo-prepared-hire-law-enforcement-officer-missing-indigenous-people](https://www.foxnews.com/us/south-dakota-ag-mark-vargo-prepared-hire-law-enforcement-officer-missing-indigenous-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 13:43:47+00:00

The AG of South Dakota, Mark Vargo, is preparing to hire a law enforcement officer to help coordinate investigations regarding the murder and disappearance of Indigenous people.

## Iran’s Raisi is ‘a murderer president' who will never get a nuclear bomb, Israeli UN ambassador
 - [https://www.foxnews.com/world/irans-raisi-murderer-president-nuclear-bomb-israeli-un-ambassador](https://www.foxnews.com/world/irans-raisi-murderer-president-nuclear-bomb-israeli-un-ambassador)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 13:43:28+00:00

Israeli's UN Ambassador Gilad Erdan tells Eric Shawn that Israel is not “bound by any international agreement” to stop Tehran’s nuclear program.

## Atlanta newspaper highlights Stacey Abrams' 'troubling' struggles with Black voters in Georgia race
 - [https://www.foxnews.com/media/atlanta-newspaper-highlights-stacey-abrams-troubling-struggles-black-voters-georgia-race](https://www.foxnews.com/media/atlanta-newspaper-highlights-stacey-abrams-troubling-struggles-black-voters-georgia-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 13:35:36+00:00

Democratic Georgia gubernatorial candidate Stacey Abrams is "struggling" to garner support among Black voters, the Atlanta Journal Constitution reported.

## Josh Barro slams Gavin Newsom as 'gross and embarrassing,' says 'sleazy' governor will never be president
 - [https://www.foxnews.com/media/josh-barro-slams-gavin-newsom-gross-embarrassing-sleazy-governor-never-president](https://www.foxnews.com/media/josh-barro-slams-gavin-newsom-gross-embarrassing-sleazy-governor-never-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 13:31:12+00:00

Gavin Newsom's recent clashes with Republican governors are an 'embarrassing' posture to bolster a future presidential campaign, according to Josh Barro.

## Parents remain frustrated by baby formula shortage, call on Biden admin to put more pressure on manufacturers
 - [https://www.foxnews.com/media/parents-remain-frustrated-baby-formula-shortage-call-biden-admin-put-pressure-manufacturers](https://www.foxnews.com/media/parents-remain-frustrated-baby-formula-shortage-call-biden-admin-put-pressure-manufacturers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 13:14:57+00:00

Parents Cailee Yielding, Jillian Arroyo and Chris Arroyo are calling for accountability as they continue to face empty shelves and high prices.

## Texas 2-year-old boy found dead in stolen SUV hours after his dad is killed
 - [https://www.foxnews.com/us/texas-2-year-old-boy-found-dead-stolen-suv-hours-dad-killed](https://www.foxnews.com/us/texas-2-year-old-boy-found-dead-stolen-suv-hours-dad-killed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 13:06:43+00:00

Houston police found a dead 2-year-old boy in a stolen SUV. This came hours after his dad was fatally shot at a gas station. A 38-year-old man was arrested for the murder.

## At UN General Assembly, US Coast Guard, NYPD boats guard the water
 - [https://www.foxnews.com/us/un-general-assembly-us-coast-guard-nypd-boats-guard-water](https://www.foxnews.com/us/un-general-assembly-us-coast-guard-nypd-boats-guard-water)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 13:05:30+00:00

The UN General Assembly is taking place in New York City this week. Protective measures are heavy, with barricades surrounding the UN building and boats protecting the water.

## Vermont finishes lead testing on 98% of its schools
 - [https://www.foxnews.com/us/vt-finishes-lead-testing-98-schools](https://www.foxnews.com/us/vt-finishes-lead-testing-98-schools)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 13:03:19+00:00

Vermont has completed lead testing on 98% of its schools in accordance with a 2019 law requiring schools and childcare facilities to test their water for lead and other heavy metals.

## Hurricane Fiona barrels toward Bermuda, warnings issued
 - [https://www.foxnews.com/us/hurricane-fiona-barrels-toward-bermuda-warnings-issued](https://www.foxnews.com/us/hurricane-fiona-barrels-toward-bermuda-warnings-issued)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:49:44+00:00

Hurricane Fiona is forecast to impact Bermuda on Friday, with warnings issued. The storm will also produce rip current risks for beaches on the East Coast.

## Indiana man who shot 2 judges outside of a White Castle convicted
 - [https://www.foxnews.com/us/indiana-man-shot-2-judges-outside-white-castle-convicted](https://www.foxnews.com/us/indiana-man-shot-2-judges-outside-white-castle-convicted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:47:49+00:00

An Indiana man who shot two judges in 2019 outside of a White Castle was convicted on seven of eight felonies and one misdemeanor. The man claims he was acting in self-defense.

## Adam Levine cheating scandal leads to memes from NFL teams
 - [https://www.foxnews.com/sports/adam-levine-cheating-scandal-leads-memes-nfl-teams](https://www.foxnews.com/sports/adam-levine-cheating-scandal-leads-memes-nfl-teams)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:42:52+00:00

Adam Levine's cheating scandal trickled into the NFL world as teams used some of his alleged messages as memes ahead of Week 3 of the 2022 season.

## Hawaii mom outraged over school still requiring kids to eat lunch in outdoor heat: 'Kids have suffered enough'
 - [https://www.foxnews.com/media/hawaii-mom-outraged-school-policy-forces-kids-eat-lunch-outdoor-heat-kids-suffered-enough](https://www.foxnews.com/media/hawaii-mom-outraged-school-policy-forces-kids-eat-lunch-outdoor-heat-kids-suffered-enough)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:42:28+00:00

Hawaii mom Kristina Tullos ripped her child's elementary school for requiring most students to eat lunch outside while denying the policy has anything to do with COVID.

## Texas' lottery numbers for Wednesday, Sept. 21
 - [https://www.foxnews.com/us/texas-lottery-numbers-wednesday-sept-21](https://www.foxnews.com/us/texas-lottery-numbers-wednesday-sept-21)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:40:37+00:00

The Mega Million's estimated jackpot is $301,000,000. The Powerball estimated jackpot is $270,000,000. The Cash 5 numbers for Wednesday, Sept. 21 are 12-15-23-25-28.

## Florida's lottery numbers for Wednesday, Sept. 21
 - [https://www.foxnews.com/us/floridas-lottery-numbers-wednesday-sept-21](https://www.foxnews.com/us/floridas-lottery-numbers-wednesday-sept-21)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:40:08+00:00

The Mega Million's estimated jackpot is $301,000,000. The Powerball estimated jackpot is $270,000,000. The Cash4Life numbers for Wednesday, Sept. 21 are 01-04-43-48-60.

## Ukraine receives hundreds of POWs from Russia in prisoner swap for top Putin ally
 - [https://www.foxnews.com/world/ukraine-receives-hundreds-pows-russia-prisoner-swap-top-putin-ally](https://www.foxnews.com/world/ukraine-receives-hundreds-pows-russia-prisoner-swap-top-putin-ally)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:39:13+00:00

Russia and Ukraine exchanged nearly 300 soldiers in a surprise prisoner swap Wednesday. Ukraine received 215 troops, as well as 10 foreign nationals, including two Americans.

## Australian wildlife team rescues 32 beached pilot whales after nearly 200 die in mass stranding
 - [https://www.foxnews.com/world/australian-wildlife-team-rescues-beached-pilot-whales-die-mass-stranding](https://www.foxnews.com/world/australian-wildlife-team-rescues-beached-pilot-whales-die-mass-stranding)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:34:18+00:00

Nearly 200 pilot whales have died in a mass stranding on the shores of Australia's island state of Tasmania as rescuers worked Thursday to save the 35 whales still alive.

## LA mayoral candidate Karen Bass insists gun storage, registration '100% legal' in debate
 - [https://www.foxnews.com/politics/la-mayoral-candidate-karen-bass-insists-gun-storage-registration-100-legal-debate](https://www.foxnews.com/politics/la-mayoral-candidate-karen-bass-insists-gun-storage-registration-100-legal-debate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:33:36+00:00

Democratic congresswoman and Los Angeles mayoral candidate Karen Bass insisted during a Wednesday night debate that guns stolen from her home were properly owned and stored.

## Roger Federer to pair with tennis legend for final match
 - [https://www.foxnews.com/sports/roger-federer-pair-tennis-legend-final-match](https://www.foxnews.com/sports/roger-federer-pair-tennis-legend-final-match)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:32:04+00:00

Roger Federer will have his farewell match at the Laver Cup on Friday in a doubles pairing twith another tennis legend, Rafael Nadal.

## Queen Elizabeth 'exhausted,' 'hurt' from Prince Harry, Meghan Markle's decision to step down as senior royals
 - [https://www.foxnews.com/entertainment/queen-elizabeth-exhausted-hurt-prince-harry-meghan-markle-decision-step-down-senior-royals](https://www.foxnews.com/entertainment/queen-elizabeth-exhausted-hurt-prince-harry-meghan-markle-decision-step-down-senior-royals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:16:19+00:00

The late Queen Elizabeth II was reportedly "deeply hurt" by Prince Harry and Meghan Markle choosing to step down as senior royals, according to the new book "The New Royals" from Katie Nicholl.

## Legendary Dodge Challenger 'Black Ghost' street racer resurrected with 807 hp
 - [https://www.foxnews.com/auto/legendary-dodge-challenger-black-ghost](https://www.foxnews.com/auto/legendary-dodge-challenger-black-ghost)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 12:13:52+00:00

The Dodge Challenger Black Ghost is a limited edition model that was inspired by a famous car from the Detroit street racing scene of the 1970s.

## Gleyber Torres joins wacky MLB club in Yankees' rout over Pirates
 - [https://www.foxnews.com/sports/gleyber-torres-joins-wacky-mlb-club-yankees-rout-pirates](https://www.foxnews.com/sports/gleyber-torres-joins-wacky-mlb-club-yankees-rout-pirates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 11:40:54+00:00

New York Yankees second baseman Gleyber Torres joined a unique group of MLB players after hitting two home runs in one inning on Wednesday night.

## Presidents Cup 2022: What to know about the tournament
 - [https://www.foxnews.com/sports/presidents-cup-2022-what-know-tournament](https://www.foxnews.com/sports/presidents-cup-2022-what-know-tournament)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 11:31:01+00:00

The Presidents Cup is set to tee off Thursday afternoon at Quail Hollow in Charlotte, North Carolina, but the field looks a bit different.

## 2024 Watch: Pence returning to Iowa to headline Republican dinner
 - [https://www.foxnews.com/politics/2024-watch-pence-returning-iowa-headline-republican-dinner](https://www.foxnews.com/politics/2024-watch-pence-returning-iowa-headline-republican-dinner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 11:00:52+00:00

2024 Watch: Former Vice President Mike heads back to Iowa next week where he’ll serve as the featured speaker at a prominent Republican family’s annual gathering

## Elton John next star to play at Biden White House but 'sad songs' aren't gonna turn things around
 - [https://www.foxnews.com/opinion/elton-john-next-star-to-play-biden-white-house-sad-songs-arent-gonna-turn-things-around](https://www.foxnews.com/opinion/elton-john-next-star-to-play-biden-white-house-sad-songs-arent-gonna-turn-things-around)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 11:00:39+00:00

Sir Elton John will perform at a concert at the White House on Friday. President Biden's attempt to bond with Americans through the performance is tone deaf.

## Air Force Academy goes 'woke,' Dems shift focus from economy for midterms and more top headlines
 - [https://www.foxnews.com/us/air-force-academy-diversity-inclusion-training-woke-gender-words](https://www.foxnews.com/us/air-force-academy-diversity-inclusion-training-woke-gender-words)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 10:45:06+00:00

WOKE MILITARY - Air Force Academy diversity training tells cadets to use words that 'include all genders​,' drop 'mom and dad

## Drew Barrymore says she can go 'years' without sex
 - [https://www.foxnews.com/entertainment/drew-barrymore-says-she-can-years-without-sex](https://www.foxnews.com/entertainment/drew-barrymore-says-she-can-years-without-sex)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 10:23:17+00:00

On her talk show this week actress Drew Barrymore said that she is fine being abstinent for "years." In the past, she has set she's avoided dating to focus on her two daughters.

## William and Kate's children using new 'Wales' last names following title change
 - [https://www.foxnews.com/entertainment/william-kates-children-using-new-wales-last-names-following-title-change](https://www.foxnews.com/entertainment/william-kates-children-using-new-wales-last-names-following-title-change)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 10:14:58+00:00

Princes George and Louis and their sister Princess Charlotte have started using their new last name of "Wales," after King Charles III bestowed the title the Prince of Wales on William, their father.

## 6.8 magnitude earthquake strikes Mexico, killing at least 1
 - [https://www.foxnews.com/world/6-8-magnitude-earthquake-strikes-mexico-killing-least-1](https://www.foxnews.com/world/6-8-magnitude-earthquake-strikes-mexico-killing-least-1)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 10:07:18+00:00

At least one person has been reported dead after a major magnitude 6.8 earthquake hit western Mexico on Thursday. A woman fell from her stairs and hit her head during the quake.

## At least 7 Los Angeles teens overdosed from suspected fentanyl pills this month: LAPD
 - [https://www.foxnews.com/us/least-7-los-angeles-teens-overdosed-suspected-fentanyl-pills-month-lapd](https://www.foxnews.com/us/least-7-los-angeles-teens-overdosed-suspected-fentanyl-pills-month-lapd)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 09:51:46+00:00

Los Angeles authorities said at least seven local teens have overdosed from fentanyl-laced pills over the past month, including one who died from a fake Percocet pill.

## Man banned from American Airlines for life after assaulting a flight attendant; FBI investigating
 - [https://www.foxnews.com/us/man-banned-american-airlines-life-assaulting-flight-attendant-fbi-investigating](https://www.foxnews.com/us/man-banned-american-airlines-life-assaulting-flight-attendant-fbi-investigating)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 09:39:15+00:00

A passenger was banned from American Airlines for life after allegedly punching a flight attendant's neck on a flight from Cabo to Los Angeles, as the FBI investigates the incident.

## Grandfather charged in hot car death of Alabama toddler returned to truck 3 times: 'I don't understand it'
 - [https://www.foxnews.com/us/grandfather-charged-hot-car-death-alabama-toddler-returned-truck-3-times-dont-understand](https://www.foxnews.com/us/grandfather-charged-hot-car-death-alabama-toddler-returned-truck-3-times-dont-understand)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 09:32:20+00:00

An Alabama man has been charged in the hot car death of his 2-year-old grandson after forgetting to drop him off at daycare on his way to work. The toddler was found dead at 3:06 p.m.

## Beverly Hills smash-and-grab suspects who allegedly stole millions from jewelry store arrested: police
 - [https://www.foxnews.com/us/beverley-hills-smash-grab-suspects-allegedly-stole-millions-jewelry-store-arrested-police](https://www.foxnews.com/us/beverley-hills-smash-grab-suspects-allegedly-stole-millions-jewelry-store-arrested-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 09:20:24+00:00

Beverly Hills police and FBI tactical teams successfully arrested three suspects believed to have stolen between $3 million and $5 million from a jewelry store in a March robbery.

## Candidates should speak out about school choice, advises former congressman
 - [https://www.foxnews.com/media/candidates-should-speak-school-choice-former-congressman](https://www.foxnews.com/media/candidates-should-speak-school-choice-former-congressman)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 09:00:36+00:00

School choice is an issue that can unite parties, former congressman and President of the Invest in Education Foundation Luke Messer argued.

## Neptune and rings shine in photos from new space telescope
 - [https://www.foxnews.com/science/neptune-rings-shine-photos-from-new-space-telescope](https://www.foxnews.com/science/neptune-rings-shine-photos-from-new-space-telescope)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 08:51:17+00:00

NASA released new, detailed photos of Neptune and its rings, taken by the world's biggest, most powerful telescope, which rocketed into space last December.

## Giants legend becomes first former player to join team's ownership group
 - [https://www.foxnews.com/sports/giants-legend-becomes-first-former-player-join-teams-ownership-group](https://www.foxnews.com/sports/giants-legend-becomes-first-former-player-join-teams-ownership-group)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 08:47:43+00:00

Buster Posey is now a part owner of the San Francisco Giants after winning three World Series in 12 seasons with the club from 2009 to 2021.

## Celtics' Ime Udoka could face 'significant suspension' for violating team guidelines: report
 - [https://www.foxnews.com/sports/celtics-ime-udoka-could-face-significant-suspension-violating-team-guidelines-report](https://www.foxnews.com/sports/celtics-ime-udoka-could-face-significant-suspension-violating-team-guidelines-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 08:31:34+00:00

Ime Udoka is facing a possible suspension for violating organization guidelines, ESPN reports. A suspension could be announced as early as Thursday.

## Coors Light beer drenches Florida highway after semi-trailer crash
 - [https://www.foxnews.com/us/coors-light-beer-drenches-florida-highway-semitrailer-crash](https://www.foxnews.com/us/coors-light-beer-drenches-florida-highway-semitrailer-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 08:28:57+00:00

Florida Highway Patrol said a semi-trailer crash on Wednesday resulted in hundreds of beer cans covering an interstate after one vehicle failed to brake.

## Fort Hood solider charged with murder of Texas woman, bond set at $1M
 - [https://www.foxnews.com/us/fort-hood-army-solider-charged-murder-killeen-texas](https://www.foxnews.com/us/fort-hood-army-solider-charged-murder-killeen-texas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 08:15:13+00:00

An active-duty soldier at Fort Hood is jailed on $1 million bond in connection with the murder of a 34-year-old Texas woman, according to Killeen police.

## Dismembered body reportedly found in suitcases in New York City apartment: 'Scary'
 - [https://www.foxnews.com/us/dismembered-body-reportedly-found-suitcases-new-york-city-apartment-scary](https://www.foxnews.com/us/dismembered-body-reportedly-found-suitcases-new-york-city-apartment-scary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 08:10:31+00:00

After neighbors reported a terrible smell, a body was reportedly found dismembered in several suitcases Wednesday inside a Brooklyn apartment.

## Tiffany Haddish and Aries Spears' child sexual abuse lawsuit dismissed at accuser Jane Doe's request
 - [https://www.foxnews.com/entertainment/tiffany-haddish-aries-spears-child-sexual-abuse-lawsuit-dismissed-accuser-jane-does-request](https://www.foxnews.com/entertainment/tiffany-haddish-aries-spears-child-sexual-abuse-lawsuit-dismissed-accuser-jane-does-request)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 07:53:23+00:00

A woman identified only as Jane Doe has dropped a lawsuit she filed against Tiffany Haddish and Aries Spears, in which she accused the two of child sexual assault.

## Illegal immigrant who stabbed, shot NYPD officers sentenced to 30 years in prison, deportation
 - [https://www.foxnews.com/us/illegal-immigrant-stabbed-shot-nypd-officers-sentenced-30-years-prison-deportation](https://www.foxnews.com/us/illegal-immigrant-stabbed-shot-nypd-officers-sentenced-30-years-prison-deportation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 07:33:19+00:00

A foreign national who is in the U.S. illegally was sentenced in both federal and state court to 30 years in prison after stabbing and shooting NYPD officers in 2020.

## NY attorney general accuses Trump of civil fraud, but under a cloud of partisanship
 - [https://www.foxnews.com/media/ny-attorney-general-accuses-trump-civil-fraud-under-cloud-partisanship](https://www.foxnews.com/media/ny-attorney-general-accuses-trump-civil-fraud-under-cloud-partisanship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 07:06:13+00:00

New York Attorney General Letitia James has launched a civil suit against the Trump organization after DA Alvin Bragg declined to pursue a criminal probe.

## Biden approves Puerto Rico disaster declaration after devastating Hurricane Fiona impact
 - [https://www.foxnews.com/us/biden-approves-puerto-rico-disaster-declaration-devastating-hurricane-fiona-impact](https://www.foxnews.com/us/biden-approves-puerto-rico-disaster-declaration-devastating-hurricane-fiona-impact)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 06:50:25+00:00

As Puerto Rico continues its recovery effort following the devastating impact of Hurricane Fiona, President Joe Biden approved a declaration that would make federal funds available.

## 'Fat Leonard' captured: Navy corruption scandal mastermind nabbed in Venezuela after weeks on the run
 - [https://www.foxnews.com/us/fat-leonard-captured-navy-corruption-scandal-mastermind-nabbed-venezuela-after-weeks-run](https://www.foxnews.com/us/fat-leonard-captured-navy-corruption-scandal-mastermind-nabbed-venezuela-after-weeks-run)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 06:14:01+00:00

Wanted fugitive Leonard Francis was captured in Venezuela after fleeing before he was set to be sentenced. He pleaded guilty in 2015 to bribing Navy officials in a $35 million scandal.

## After Dobbs, the right to personal privacy no longer exists for anyone
 - [https://www.foxnews.com/opinion/after-dobbs-the-right-to-personal-privacy-no-longer-exists-for-anyone](https://www.foxnews.com/opinion/after-dobbs-the-right-to-personal-privacy-no-longer-exists-for-anyone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 06:00:36+00:00

In the aftermath of the Supreme Court's decision on Roe vs. Wade there are a host of open legal questions about personal privacy. And they are very alarming.

## Adam Levine accused of cheating: 7 more wild celebrity infidelity scandals
 - [https://www.foxnews.com/entertainment/adam-levine-accused-cheating-wild-celebrity-infedility-scandals](https://www.foxnews.com/entertainment/adam-levine-accused-cheating-wild-celebrity-infedility-scandals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 06:00:35+00:00

Adam Levine has been accused of sending flirtatious messages to multiple women while married to Behati Prinsloo. Fox News Digital explores other celebrity cheating scandals.

## Biden's handling of the economy put to the test; Americans weigh in
 - [https://www.foxnews.com/politics/bidens-handling-economy-put-test-americans-weigh](https://www.foxnews.com/politics/bidens-handling-economy-put-test-americans-weigh)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 06:00:28+00:00

People in New York and San Francisco rated how well President Biden has handled the economy, as inflation continues to soar and a potential recession looms.

## Air Force Academy diversity training tells cadets to use words that 'include all genders​,' drop 'mom and dad'
 - [https://www.foxnews.com/politics/air-force-academy-diversity-training-tells-cadets-to-use-words-that-include-all-genders-drop-mom-and-dad](https://www.foxnews.com/politics/air-force-academy-diversity-training-tells-cadets-to-use-words-that-include-all-genders-drop-mom-and-dad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 06:00:19+00:00

A diversity and inclusion training by the United States Air Force Academy tells cadets to stop using gendered language like "mom and dad" and "boyfriend and girlfriend."

## Sunny Hostin's stunning remarks about Nikki Haley her latest personal attack on conservatives
 - [https://www.foxnews.com/media/sunny-hostins-stunning-remarks-about-nikki-haley-latest-personal-attack-conservatives](https://www.foxnews.com/media/sunny-hostins-stunning-remarks-about-nikki-haley-latest-personal-attack-conservatives)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 06:00:14+00:00

"The View" co-host Sunny Hostin has a lengthy history of personal attacks towards conservatives that continued this week with her broadside at Nikki Haley.

## Economy tops list of independent voters' concerns, but James Carville and other Dems defend focus on abortion
 - [https://www.foxnews.com/politics/economy-tops-list-independent-voters-concerns-james-carville-other-dems-defend-focus-abortion](https://www.foxnews.com/politics/economy-tops-list-independent-voters-concerns-james-carville-other-dems-defend-focus-abortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 06:00:11+00:00

Political analysts weigh in on recent polls that found Democrats are focused on abortion, while Independents and Republicans are most concerned about the economy and inflation.

## Chinese government has little incentive to stop the country's drug cartels from fueling US fentanyl crisis
 - [https://www.foxnews.com/world/chinese-government-little-incentive-stop-countrys-drug-cartels-from-fueling-us-fentanyl-crisis](https://www.foxnews.com/world/chinese-government-little-incentive-stop-countrys-drug-cartels-from-fueling-us-fentanyl-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 06:00:07+00:00

The Chinese government has little incentive to rejoin and effort to stop its drug cartels from shipping fentanyl to the U.S. and deepening the opioid crisis in America.

## Georgia high school student dies during flag football practice
 - [https://www.foxnews.com/sports/georgia-high-school-student-dies-during-flag-football-practice](https://www.foxnews.com/sports/georgia-high-school-student-dies-during-flag-football-practice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 04:54:11+00:00

A high school student reportedly died after suffering a medical emergency during flag football practice after school in Sandy Springs, Georgia, on Wednesday.

## GREG GUTFELD: This is the face of the Republican Party and the Democrats are scared
 - [https://www.foxnews.com/opinion/greg-gutfeld-face-republican-party-democrats-scared](https://www.foxnews.com/opinion/greg-gutfeld-face-republican-party-democrats-scared)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 04:46:10+00:00

Greg Gutfeld slammed Biden's and the Dem's labeling of 'extreme-MAGA' Republicans, highlighting Republican candidates like Tudor Dixon and Linda Paulson on "Gutfeld!"

## You don’t know how ‘horribly racist’ Sunny’s comments were: Tyrus
 - [https://www.foxnews.com/media/tyrus-the-view-racist-comments-sunny-hostin](https://www.foxnews.com/media/tyrus-the-view-racist-comments-sunny-hostin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 04:20:47+00:00

Tyrus discusses with Greg Gutfeld and guests how the ladies of "The View" slammed Nikki Haley for not representing her heritage with her name on "Gutfeld!"

## TUCKER CARLSON: Threats to children are no longer punished, but celebrated and then protected
 - [https://www.foxnews.com/opinion/tucker-carlson-threats-children-no-longer-punished-celebrated-protected](https://www.foxnews.com/opinion/tucker-carlson-threats-children-no-longer-punished-celebrated-protected)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 04:17:30+00:00

Fox News' Tucker Carlson shines light on a teacher in Canada who started wearing prosthetic breasts modeled after porn content in class and how he's allegedly being protected.

## LAURA INGRAHAM: The American people are facing a long period of decline and despair
 - [https://www.foxnews.com/media/laura-ingraham-american-people-facing-long-period-decline-despair](https://www.foxnews.com/media/laura-ingraham-american-people-facing-long-period-decline-despair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 04:07:21+00:00

Laura Ingraham discussed how the Biden administration is continuing to deny the severity of the economic crisis and Biden's poor foreign policy on "The Ingraham angle."

## On this day in history, Sept. 22, 1862, Abraham Lincoln proclaims slaves will soon be 'forever free'
 - [https://www.foxnews.com/lifestyle/on-this-day-history-sept-22-1862-abraham-lincoln-proclaims-slaves-soon-forever-free](https://www.foxnews.com/lifestyle/on-this-day-history-sept-22-1862-abraham-lincoln-proclaims-slaves-soon-forever-free)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 04:02:18+00:00

Abraham Lincoln issued the "preliminary" Emancipation Proclamation on this day in history, Sept. 22, 1862, announcing that the slaves would be freed on Jan. 1, 1863.

## Hyundais and Kias stolen nearly twice as often as other vehicles, national study finds
 - [https://www.foxnews.com/auto/hyundais-kias-stolen-twice-vehicles-national-study](https://www.foxnews.com/auto/hyundais-kias-stolen-twice-vehicles-national-study)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 04:00:58+00:00

A new report from the Highway Loss Data Institute found that Hyundais and Kias were stolen at nearly twice the rate of other models in 2021.

## Trump blasts Democrats' litigation barrage as NY sues him: 'What does Letitia James know?'
 - [https://www.foxnews.com/media/trump-blasts-democrats-litigation-barrage-ny-sues-him-letitia-james](https://www.foxnews.com/media/trump-blasts-democrats-litigation-barrage-ny-sues-him-letitia-james)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 03:44:53+00:00

New York Attorney General Letitia James sued President Trump, several members of his family and associates, in a hundreds-of-pages-long civil litigation filing.

## Michael Henry: AG Letitia James turns 'blind eye' to New York's corruption, crises
 - [https://www.foxnews.com/media/michael-henry-ag-letitia-james-turns-blind-eye-new-yorks-corruption-crises](https://www.foxnews.com/media/michael-henry-ag-letitia-james-turns-blind-eye-new-yorks-corruption-crises)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 03:39:46+00:00

New York attorney general candidate Michael Henry joined "The Ingraham Angle" to share why he believes he can beat New York AG Letitia James in the upcoming midterms.

## Mike Pompeo: The Chinese Communist Party has declared economic war on America
 - [https://www.foxnews.com/media/mike-pompeo-chinese-communist-party-declared-economic-war-america](https://www.foxnews.com/media/mike-pompeo-chinese-communist-party-declared-economic-war-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 03:35:09+00:00

Former Trump Secretary of State Mike Pompeo discussed President Joe Biden's speech at the U.N. General Assembly Wednesday on "The Ingraham Angle."

## 'Gutfeld!' on Trump, DeSantis and MAGA Republicans
 - [https://www.foxnews.com/transcript/gutfeld-trump-desantis-maga-republicans](https://www.foxnews.com/transcript/gutfeld-trump-desantis-maga-republicans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 03:00:00+00:00

Guests: Jared Kushner, Mike Baker, Kat Timpf, Tyrus

## TUCKER CARLSON: Hospitals are mutilating children, and one day we'll look back in shame, horror
 - [https://www.foxnews.com/opinion/tucker-carlson-hospitals-mutilating-children-look-back-shame-horror](https://www.foxnews.com/opinion/tucker-carlson-hospitals-mutilating-children-look-back-shame-horror)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 02:57:08+00:00

Fox News host Tucker Carlson rips hospitals for performing surgeries on transgender children and explains the devastating impact on kids on Wednesday's "Tucker Carlson Tonight."

## SEAN HANNITY: Do we have equal justice under the law?
 - [https://www.foxnews.com/media/sean-hannity-equal-justice-law-donald-trump](https://www.foxnews.com/media/sean-hannity-equal-justice-law-donald-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 02:56:58+00:00

Sean Hannity discusses the faltering sense of equal justice in America and how Donald Trump has been a victim of this injustice on "Hannity."

## Kellyanne Conway outlines what Dems are trying to run on for the midterms
 - [https://www.foxnews.com/media/kellyanne-conway-democrats-strategy-midterms-trump-abortion](https://www.foxnews.com/media/kellyanne-conway-democrats-strategy-midterms-trump-abortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 02:39:06+00:00

Former Trump senior counselor Kellyanne Conway provided analysis on "Special Report" on key voter issues with races tightening as election day approaches.

## Illinois police arrest 15 people after they allegedly used PPP loans to bond out of jail
 - [https://www.foxnews.com/us/illinois-police-arrest-15-people-allegedly-used-ppp-loans-bond-jail](https://www.foxnews.com/us/illinois-police-arrest-15-people-allegedly-used-ppp-loans-bond-jail)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 02:09:02+00:00

Illinois police and federal agencies arrested 15 people and are looking for several more after they allegedly used PPP funds to bond out of jail during the pandemic.

## Trump inquiry: Court lifts judge's hold blocking DOJ from using classified documents found at Mar-a-Lago
 - [https://www.foxnews.com/politics/trump-inquiry-court-lifts-judges-hold-blocking-doj-using-classified-documents-found-mar-a-lago](https://www.foxnews.com/politics/trump-inquiry-court-lifts-judges-hold-blocking-doj-using-classified-documents-found-mar-a-lago)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 02:01:57+00:00

An appeals court on Wednesday lifted a judge's ruling that blocked the Justice Department from using classified documents seized from resident Donald Trump’s Florida estate.

## MSNBC's Mehdi Hasan attacks Ron DeSantis for 'throwing his own ancestors under the bus'
 - [https://www.foxnews.com/media/msnbcs-mehdi-hasan-ron-desantis-throwing-ancestors-bus](https://www.foxnews.com/media/msnbcs-mehdi-hasan-ron-desantis-throwing-ancestors-bus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 01:50:27+00:00

MSNBC host Mehdi Hasan claimed Gov. Ron DeSantis, R-Fla., is a hypocrite for moving migrants to Martha’s Vineyard while having immigrant ancestors.

## Fauci says he wants to inspire ‘younger generation of scientists and would-be scientists’ upon retirement
 - [https://www.foxnews.com/us/fauci-inspire-younger-generation-scientists-would-scientists-upon-retirement](https://www.foxnews.com/us/fauci-inspire-younger-generation-scientists-would-scientists-upon-retirement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 01:49:50+00:00

Dr. Anthony Fauci said he wants to inspire a new generation of scientists after he retires following his decades-long career in the federal government.

## Chicago judge denies bail for Illinois woman who allegedly pushed 3-year-old nephew into Lake Michigan
 - [https://www.foxnews.com/us/chicago-judge-denies-bail-illinois-woman-allegedly-pushed-year-old-nephew-lake-michigan](https://www.foxnews.com/us/chicago-judge-denies-bail-illinois-woman-allegedly-pushed-year-old-nephew-lake-michigan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 01:46:53+00:00

A woman in Illinois who allegedly pushed her nephew into Lake Michigan at Navy Pier allegedly told police officers that she had no idea who the child was, prosecutors say.

## Ana de Armas says it's 'disgusting' nudity from 'Blonde' film will go viral: 'I can’t control it'
 - [https://www.foxnews.com/entertainment/ana-de-armas-says-disgusting-nudity-from-blonde-film-go-viral-cant-control-it](https://www.foxnews.com/entertainment/ana-de-armas-says-disgusting-nudity-from-blonde-film-go-viral-cant-control-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 01:42:49+00:00

Ana de Armas is expecting the nude scenes from "Blonde" to go viral on the internet. The Netflix film based on a fictional take on the life of Marilyn Monroe debuts on Sept. 28.

## NY Times’ Nikole Hannah-Jones slams US as ‘one of the most unequal societies in the history of the world’
 - [https://www.foxnews.com/media/ny-times-nikole-hannah-jones-slams-us-one-unequal-societies-history-world](https://www.foxnews.com/media/ny-times-nikole-hannah-jones-slams-us-one-unequal-societies-history-world)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 01:20:02+00:00

The controversial writer who reframed American history around the slave trade spoke at an Arlington Public Library event that touted itself around the idea of 'freedom to read.'

## Jesse Watters: Here's the bottom line, there's only one reporter at the border - they don't want even one
 - [https://www.foxnews.com/media/jesse-watters-bottom-line-only-one-reporter-border-dont-want-even-one](https://www.foxnews.com/media/jesse-watters-bottom-line-only-one-reporter-border-dont-want-even-one)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 01:10:23+00:00

Fox News host Jesse Watters slammed the Biden White House over their reported reaction to Fox News' Bill Melugin's reporting of the Biden-border crisis on "The Five."

## Clay Travis: Suddenly, the liberal enclave can't handle around 50 illegal immigrants
 - [https://www.foxnews.com/media/clay-travis-suddenly-liberal-enclave-handle-50-illegal-immigrants](https://www.foxnews.com/media/clay-travis-suddenly-liberal-enclave-handle-50-illegal-immigrants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 01:02:51+00:00

Clay Travis discusses how he gives a lot of credit to Govs. Doug Ducey, Greg Abbott and Ron DeSantis for pushing the migrant crisis into the spotlight on "Jesse Watters Primetime."

## 2 players, including Super Bowl champion, suspended 3 games for violating substance abuse policy
 - [https://www.foxnews.com/sports/2-players-including-super-bowl-champion-suspended-3-games-for-violating-substance-abuse-policy](https://www.foxnews.com/sports/2-players-including-super-bowl-champion-suspended-3-games-for-violating-substance-abuse-policy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 01:01:16+00:00

The National Football League handed out three-game suspensions to two players Wednesday for their alleged violation of the league's substance abuse policy.

## Twitter progressives praise NY AG Letitia James for filing civil lawsuit against Trump: 'Eternally grateful'
 - [https://www.foxnews.com/media/twitter-progressives-praise-ny-ag-letitia-james-filing-civil-lawsuit-trump-eternally-grateful](https://www.foxnews.com/media/twitter-progressives-praise-ny-ag-letitia-james-filing-civil-lawsuit-trump-eternally-grateful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 01:00:27+00:00

Progressive social media users praised New York Attorney General Letitia James for announcing a civil lawsuit against former President Donald Trump on Wednesday.

## Los Angeles wrong-way hit-and-run driver who plowed into mom and baby in stolen car wants early release
 - [https://www.foxnews.com/us/los-angeles-wrong-way-hit-run-driver-plowed-mom-baby-stolen-car-wants-early-release](https://www.foxnews.com/us/los-angeles-wrong-way-hit-run-driver-plowed-mom-baby-stolen-car-wants-early-release)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:57:43+00:00

A Los Angeles wrong-way driving teen who mowed down a mother and her 8-month-old in a stolen car wants an early release from his 5- to 7-month sentence at probation camp.

## North Dakota man who ran down 'Republican' teen says he doesn't want his own life, job jeopardized
 - [https://www.foxnews.com/us/north-dakota-man-admitted-killing-republican-teen-his-life-job-jeopardized](https://www.foxnews.com/us/north-dakota-man-admitted-killing-republican-teen-his-life-job-jeopardized)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:52:21+00:00

A North Dakota man was in court when he said the charges against him for the vehicular death of a teenage boy confused him and that he wasn't a flight risk.

## Lamar Jackson placed on Ravens injury report, vows to play Sunday
 - [https://www.foxnews.com/sports/lamar-jackson-ravens-injury-report-vows-to-play-sunday](https://www.foxnews.com/sports/lamar-jackson-ravens-injury-report-vows-to-play-sunday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:47:10+00:00

Baltimore Ravens quarterback Lamar Jackson was placed on the team's injury report Wednesday, but he didn't seem too worried about missing the game on Sunday.

## The left condemns hate speech while ignoring fallout from Biden branding Trumpers fascist: Victor Davis Hanson
 - [https://www.foxnews.com/media/left-condemns-hate-speech-ignoring-fallout-biden-branding-trumpers-fascist-victor-davis-hanson](https://www.foxnews.com/media/left-condemns-hate-speech-ignoring-fallout-biden-branding-trumpers-fascist-victor-davis-hanson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:41:44+00:00

Victor Davis Hanson responded to the case of a North Dakota man who allegedly hit and killed a Republican teenager over a purported political dispute on "Jesse Watters Primetime."

## Mollie Hemingway blasts politicians' 'schoolyard posturing' toward Russia during Ukraine war
 - [https://www.foxnews.com/media/mollie-hemingway-politicians-schoolyard-posturing-russia-ukraine-war](https://www.foxnews.com/media/mollie-hemingway-politicians-schoolyard-posturing-russia-ukraine-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:40:11+00:00

Fox News contributor Mollie Hemingway questioned the United States' response to the Russian war on Ukraine Wednesday on the "Special Report" All-Star panel.

## Trump slams NYAG James' 'ridiculous' case, says she should 'focus on people who kill people' as crime spikes
 - [https://www.foxnews.com/politics/trump-slams-nyag-james-ridiculous-case-says-she-should-focus-people-who-kill-people-crime-spikes](https://www.foxnews.com/politics/trump-slams-nyag-james-ridiculous-case-says-she-should-focus-people-who-kill-people-crime-spikes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:30:17+00:00

New York Attorney General Letitia James filed a complaint against former President Trump and his family Wednesday, alleging Trump "inflated his net worth by billions."

## Gavin Newsom says people left California because of Trump’s visa policies
 - [https://www.foxnews.com/politics/gavin-newsom-people-left-california-because-trumps-visa-policies](https://www.foxnews.com/politics/gavin-newsom-people-left-california-because-trumps-visa-policies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:24:33+00:00

California Gov. Gavin Newsom recently gave a talk in which he argued that the reason so many people have left California in recent years is because of President Trump's visa policies.

## JESSE WATTERS: The illegal migrants DeSantis flew to Martha's Vineyard are suing him
 - [https://www.foxnews.com/media/jesse-watters-illegal-migrants-desantis-flew-marthas-vineyard-suing](https://www.foxnews.com/media/jesse-watters-illegal-migrants-desantis-flew-marthas-vineyard-suing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:23:46+00:00

Fox News host Jesse Watters gives his take on illegal migrants suing Florida Gov. Ron DeSantis after he sent them to Martha's Vineyard on “Jesse Watters Primetime.”

## Train engineer in Minnesota bites hand of knife-wielding attacker who told him to 'speed up, then jumps
 - [https://www.foxnews.com/us/train-engineer-minnesota-bites-hand-knife-wielding-attacker-speed-then-jumps](https://www.foxnews.com/us/train-engineer-minnesota-bites-hand-knife-wielding-attacker-speed-then-jumps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:15:42+00:00

An engineer in Minnesota bit a man's hand and jumped off a moving train after someone boarded the train, choked him and attacked him with a knife.

## Mississippi police officer saves choking baby
 - [https://www.foxnews.com/us/mississippi-police-officer-saves-choking-baby](https://www.foxnews.com/us/mississippi-police-officer-saves-choking-baby)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:12:24+00:00

A Mississippi police officer saved a choking baby on Sept. 15 by taking "lifesaving" measures to save the infant, who was taken to a local hospital for evaluation.

## Royal photographer shares sweet story behind Queen Elizabeth II's photoshoot
 - [https://www.foxnews.com/entertainment/royal-photographer-shares-sweet-story-behind-queen-elizabeth-iis-photoshoot](https://www.foxnews.com/entertainment/royal-photographer-shares-sweet-story-behind-queen-elizabeth-iis-photoshoot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:06:41+00:00

Royal photographer Ranald Mackechnie shared a sweet encounter he had with Queen Elizabeth II while snapping the portrait shared on the eve of her funeral.

## Tucker Carlson: Hospitals are mutilating children
 - [https://www.foxnews.com/transcript/tucker-carlson-hospitals-mutilating-children](https://www.foxnews.com/transcript/tucker-carlson-hospitals-mutilating-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-22 00:00:21+00:00

Guests: Miranda Devine, Matt Walsh, Harmeet Dhillon, Nayib Bukele


# Source:Engadget, URL:https://www.engadget.com/rss.xml, language:en-US

## The FDA may have unintentionally made 'Nyquil Chicken' go viral on TikTok
 - [https://www.engadget.com/nyquil-chicken-tiktok-fda-232314004.html?src=rss](https://www.engadget.com/nyquil-chicken-tiktok-fda-232314004.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 23:23:14+00:00

<p>If you’ve been anywhere near social media, local news, or late-night talk shows in the last few days, you’ve probably heard something about <a href="https://www.youtube.com/watch?v=ON5Wwplp0EM"><ins>“Nyquil Chicken,”</ins></a> a supposedly viral TikTok “challenge” that’s exactly what it sounds like: cooking chicken in a marinade of cold medicine.</p><p>News about the supposed trend is usually accompanied by vomit-inducing photos of raw chicken simmering in dark green syrup. It’s both disgusti

## Meta sued for allegedly dodging Apple's privacy rules
 - [https://www.engadget.com/meta-lawsuit-over-apple-privacy-rules-211450574.html?src=rss](https://www.engadget.com/meta-lawsuit-over-apple-privacy-rules-211450574.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 21:14:50+00:00

<p>Felix Krause's discovery that Meta's Facebook and Instagram apps can <a href="https://www.engadget.com/meta-can-track-facebook-and-instagram-users-on-ios-with-its-in-app-browsers-071834703.html">track iPhone owners across websites</a> hasn't sat well with some people. <em>Bloomberg</em><a href="https://www.engadget.com/ios-14-5-users-reject-app-tracking-165309407.html">reports</a> users have filed two proposed class action lawsuits accusing Meta of  evading Apple's privacy-oriented <a href="h

## Meta ordered to pay $175 million in patent infringement case
 - [https://www.engadget.com/meta-patent-infringement-ruling-voxer-walkie-talkie-195730500.html?src=rss](https://www.engadget.com/meta-patent-infringement-ruling-voxer-walkie-talkie-195730500.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 19:57:30+00:00

<p><a href="https://www.engadget.com/tag/meta/"><ins>Meta</ins></a> is facing a hefty bill after losing a patent infringement lawsuit. A federal judge in Texas has ordered the company to pay Voxer, the developer of app called Walkie Talkie, nearly $175 million as an ongoing royalty. Voxer accused Meta of infringing its patents and incorporating that tech in <a href="https://www.engadget.com/tag/instagram%20live/"><ins>Instagram Live</ins></a> and <a href="https://www.engadget.com/tag/facebook%20

## SpaceX wants to put Starlink internet on rural school buses
 - [https://www.engadget.com/spacex-starlink-school-bus-satellite-internet-192015878.html?src=rss](https://www.engadget.com/spacex-starlink-school-bus-satellite-internet-192015878.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 19:20:15+00:00

<p>Starlink satellite internet access has already spread to <a href="https://www.engadget.com/starlink-maritime-satellite-internet-054320228.html">boats</a> and <a href="https://www.engadget.com/starlink-satellite-internet-rv-080542776.html">RVs</a>, and now it might accompany your child on the way home from class. SpaceX told the FCC in a <a href="https://www.fcc.gov/ecfs/search/search-filings/filing/1092076267604">filing</a> that it's piloting Starlink aboard school buses in the rural US. The 

## Facebook violated Palestinians' right to free expression, says report commissioned by Meta
 - [https://www.engadget.com/facebook-meta-palestine-free-speech-bsr-report-190534575.html?src=rss](https://www.engadget.com/facebook-meta-palestine-free-speech-bsr-report-190534575.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 19:05:34+00:00

<p>Meta has finally <a href="https://about.fb.com/news/2022/09/human-rights-impact-meta-israel-palestine/"><ins>released</ins></a> the findings of an outside report that examined how its content moderation policies affected Israelis and Palestinians amid an escalation of violence in the Gaza Strip last May. The  <a href="https://www.bsr.org/en/our-insights/report-view/meta-human-rights-israel-palestine"><ins>report</ins></a>, from Business for Social Responsibility (BSR), found that Facebook and

## Tesla to recall more than a million vehicles over pinchy windows
 - [https://www.engadget.com/tesla-to-recall-more-than-a-million-vehicles-over-pinchy-windows-185041420.html?src=rss](https://www.engadget.com/tesla-to-recall-more-than-a-million-vehicles-over-pinchy-windows-185041420.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 18:50:41+00:00

<p>More than a million Tesla owners will have yet another recall notice to deal with in the coming weeks.   On Tuesday the National Highway Traffic Safety Administration <a href="https://www.cbsnews.com/news/tesla-recall-windows-model-3-model-y-model-s-model-x/">filed a safety recall notice</a> for numerous late model vehicles from across the EV maker's lineup because &quot;the window automatic reversal system may not react correctly after detecting an obstruction,&quot; and as such, &quot;a clo

## Instagram app rendered unusable for some by instant crash bug
 - [https://www.engadget.com/instagram-android-app-crash-bug-stopping-not-working-182525952.html?src=rss](https://www.engadget.com/instagram-android-app-crash-bug-stopping-not-working-182525952.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 18:25:25+00:00

<p>If you had been using Instagram's Android app in the past hour or so, you might have noticed that an error had been causing it to crash seconds after launching, rendering it almost unusable. You weren't alone: users from multiple regions flooded Twitter with complaints about this phenomenon. According to Downdetector, this bug first appeared around 12:44PM EDT today (September 23rd) — roughly matching the time when this author also started scratching head over the seemingly random crashes. At

## Nothing reveals the charging case for its next earbuds
 - [https://www.engadget.com/nothing-ear-stick-earbuds-charging-case-teaser-180105886.html?src=rss](https://www.engadget.com/nothing-ear-stick-earbuds-charging-case-teaser-180105886.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 18:01:05+00:00

<p><a href="https://www.engadget.com/tag/nothing/"><ins>Nothing</ins></a> is preparing to release its second set of true wireless earbuds and it's given a first peek at what it has in store. The company started teasing the Ear Stick with images of the cylindrical charging case, which made an appearance on the runway at London Fashion Week.</p><p>Details are still scant, though the Ear Stick is an &quot;entirely new product&quot; with a fresh bud and case, Nothing told <a href="https://www.thever

## Moog once again revives the Model 10, its first compact modular synth
 - [https://www.engadget.com/moog-model-10-back-on-sale-165013056.html?src=rss](https://www.engadget.com/moog-model-10-back-on-sale-165013056.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 16:50:13+00:00

<p>Moog has brought back its pioneering <a href="https://www.engadget.com/2019-09-17-moog-legendary-model-10-compact-modular-synthesizer.html">Model 10 synth</a> for a <a href="https://www.moogmusic.com/news/moog-model-10-synthesizer-returns">second time</a>, and you might have a better chance of owning this one. The &quot;compact&quot; modular device has reentered production and is available worldwide through dealers. It's a slight improvement on the limited-run 2019 version, too, with an updat

## Verizon's rebranded TracFone prepaid service includes Disney+ with some plans
 - [https://www.engadget.com/verizon-total-prepaid-phone-plans-disney-plus-160115489.html?src=rss](https://www.engadget.com/verizon-total-prepaid-phone-plans-disney-plus-160115489.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 16:01:15+00:00

<p>Verizon (Engadget's former owner) is finally overhauling TracFone's service following the <a href="https://www.engadget.com/verizon-buys-tracfone-150503793.html">2020 acquisition</a>, and the reborn service might pique your interest in the right circumstances. The <a href="https://www.verizon.com/about/news/redefines-no-contract-wireless-total-by-verizon">newly launched</a> Total appears built to compete against big prepaid carriers like AT&amp;T's Cricket and T-Mobile's Metro. In addition to

## ByteDance's Pico reveals its latest VR headset as it aims to compete with Meta Quest 2
 - [https://www.engadget.com/pico-4-vr-headset-bytedance-150028514.html?src=rss](https://www.engadget.com/pico-4-vr-headset-bytedance-150028514.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 15:00:28+00:00

<p><a href="https://www.engadget.com/tag/bytedance/"><ins>ByteDance</ins></a> subsidiary Pico has <a href="https://twitter.com/PICOXR/status/1572941317193469952"><ins>unveiled its latest virtual reality headset</ins></a>. The Pico 4 will initially be available in Japan, South Korea, the UK, France, Germany, Spain, Italy and eight other European countries. Pico hasn't revealed US release plans as yet, but it aims to bring the device to Singapore and Malaysia by the end of the year, and China at a

## Affirm's pay-over-time option comes to Canada through Amazon
 - [https://www.engadget.com/affirm-pay-over-time-canada-amazon-142751552.html?src=rss](https://www.engadget.com/affirm-pay-over-time-canada-amazon-142751552.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 14:27:51+00:00

<p>You no longer need to live in the US to use <a href="https://www.engadget.com/amazon-affirm-partnership-buy-now-pay-later-204909148.html">Affirm's buy-now-pay-later services</a> for much of your online shopping. Affirm is <a href="https://www.businesswire.com/news/home/20220922005311/en/Affirm-and-Amazon-Introduce-Pay-Over-Time-Option-to-Customers-in-Canada">expanding</a> to Canada through a partnership with Amazon. Spend $50 or more at Amazon.ca and you can choose Affirm's pay-over-time opti

## Microscopic robots walk autonomously using simple 'brains'
 - [https://www.engadget.com/micro-robot-autonomous-brain-133516556.html?src=rss](https://www.engadget.com/micro-robot-autonomous-brain-133516556.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 13:35:16+00:00

<p>It's long been possible to make <a href="https://www.engadget.com/2016-05-12-origami-robot-surgeon.html">extremely small robots</a>, but they usually need some form of direct external control just to operate. Cornell scientists may have solved that problem on a basic level, however. They've <a href="https://news.cornell.edu/stories/2022/09/brains-board-smart-microrobots-walk-autonomously">created</a> microrobots (no more than 250 micrometers across) with basic electronic &quot;brains&quot; th

## The best smartphones you can buy right now
 - [https://www.engadget.com/best-smartphones-140004900.html?src=rss](https://www.engadget.com/best-smartphones-140004900.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 13:19:09+00:00

<p>Choosing your next smartphone can be challenging. With so many brands offering similar features at similar prices, it can be hard to understand what device actually has the things you want. If you’ve already determined you only want <a href="https://www.engadget.com/apple-iphone-13-and-13-mini-review-130035113.html">an iPhone</a>, your decision-making process is slightly easier. (And even then, <a href="https://www.apple.com/iphone/">Apple’s lineup</a> offers more options than ever.) Those al

## AirPods Pro (2022) review: Big improvements, all on the inside
 - [https://www.engadget.com/airpods-pro-review-second-generation-130048218.html?src=rss](https://www.engadget.com/airpods-pro-review-second-generation-130048218.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 13:00:48+00:00

<p>Three years ago, Apple finally gave the people what they wanted: active noise cancellation (ANC) <a href="https://www.engadget.com/2019-11-06-apple-airpods-pro-review.html">in a set of AirPods</a>. That first-generation model retained the overall look of the company’s classic earbuds, but added an ear tip for noise isolation along with a better fit. After a total redesign of the <a href="https://www.engadget.com/apple-airpods-review-2021-160026883.html">“regular” AirPods</a> last year and int

## Yale's redesigned Assure Lock 2 will be one of the first Matter-compatible smart home devices
 - [https://www.engadget.com/yales-redesigned-assure-lock-2-will-be-one-of-the-first-matter-compatible-smart-home-devices-130037862.html?src=rss](https://www.engadget.com/yales-redesigned-assure-lock-2-will-be-one-of-the-first-matter-compatible-smart-home-devices-130037862.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 13:00:37+00:00

<p>We've already <a href="https://www.engadget.com/yale-assure-smart-lock-gadget-irl-153534460.html">written about the convenience of Yale's smart locks</a>. But now after five years on the market, Yale is updating its flagship product with a brand new design, a wider range of connectivity options and even more styles to suit your home.</p><p>Priced between $160 to $260, the new Assure Lock 2 will be available in four main variations: two touchscreen models (both with and without a key cylinder)

## DJI's Osmo Mobile 6 gimbal offers improved tracking and a new 'Quick Launch' feature
 - [https://www.engadget.com/dji-osmo-mobile-6-gimbal-enhanced-tracking-quick-launch-for-iphone-130019549.html?src=rss](https://www.engadget.com/dji-osmo-mobile-6-gimbal-enhanced-tracking-quick-launch-for-iphone-130019549.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 13:00:19+00:00

<p>DJI has launched the <a href="http://www.dji.com/osmo-mobile-6">Osmo Mobile 6</a> gimbal, and it comes with a larger clamp than its predecessors to accommodate bigger phones or smaller ones with bulky cases. It has a new handle handle designed to be more comfortable to hold, but it kept the <a href="https://www.engadget.com/dj-osmo-mobile-5-gimbal-selfie-stick-135559718.html">Osmo Mobile 5's</a> built-in extension rod that lets you use it as a selfie stick. The Osmo 6 also features an improve

## Google now offers a cheaper, 1080p version of the Chromecast with Google TV
 - [https://www.engadget.com/chromecast-with-google-tv-hd-1080p-hdr-remote-130016962.html?src=rss](https://www.engadget.com/chromecast-with-google-tv-hd-1080p-hdr-remote-130016962.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 13:00:16+00:00

<p>Confirming <a href="https://www.engadget.com/google-1080p-chromecast-google-tv-streaming-stick-210040616.html">rumors</a>, Google has unveiled the <a href="https://bestbuy.7tiv.net/jWbdkM">Chromecast with Google TV (HD) device</a> that offers features from the <a href="https://www.engadget.com/chromecast-with-google-tv-review-163024220.html">$50 4K model</a> at a significantly cheaper $30 price. Unlike the original $35 Chromecast, it comes with a remote control that eliminates the need for a 

## NASA and Hideo Kojima team up for a Ludens-inspired watch
 - [https://www.engadget.com/nasa-hideo-kojima-ludens-inspired-watch-anicorn-125247062.html?src=rss](https://www.engadget.com/nasa-hideo-kojima-ludens-inspired-watch-anicorn-125247062.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 12:52:47+00:00

<p>NASA and Hideo Kojima have teamed up for a project, and it's not the partnership itself that's unusual. <a href="https://www.engadget.com/2019-05-29-death-stranding-collectors-edition-baby-pod-what.html">Kojima Productions'</a> mascot, after all, is a character called Ludens, who wears an extravehicular activity spacesuit and is meant to be an astronaut exploring digital space. No, it's the fact that they've collaborated on a watch. It's not even a smartwatch — it's an actual wristwatch calle

## Victrola made a $799 turntable that can connect to any Sonos speaker
 - [https://www.engadget.com/victrola-stream-carbon-sonos-enabled-turntable-120100279.html?src=rss](https://www.engadget.com/victrola-stream-carbon-sonos-enabled-turntable-120100279.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 12:00:00+00:00

<p>The vinyl resurgence <a href="https://www.engadget.com/riaa-streaming-cd-vinyl-music-sales-184307421.html">shows no sign of slowing down</a> — but streaming services are still the preferred way for most people to listen to music these days. As such, smart speakers like the Amazon Echo, HomePod mini and the line of Sonos products make a ton of sense for most people. But most of those speakers don’t work with turntables, which can make things complicated if you want to both play records and str

## Big tech companies to face UK probes over cloud service, messenger and smart speaker dominance
 - [https://www.engadget.com/ofcom-probe-cloud-service-messenger-smart-speaker-113555459.html?src=rss](https://www.engadget.com/ofcom-probe-cloud-service-messenger-smart-speaker-113555459.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 11:35:55+00:00

<p><a href="https://www.engadget.com/2017-09-05-three-judicial-review-ofcom-spectrum-auction.html">Ofcom</a>, the broadcasting and telecoms regulator in the UK, is launching a probe to look into the cloud services tech giants offer in the coming weeks to ensure that there's healthy competition in the space. Further, the regulator has revealed that it will examine messaging and video calling services, as well as smart and connected devices in the near future. For its cloud investigation, Ofcom's 

## The Morning After: The rollable smartphone that never was
 - [https://www.engadget.com/the-morning-after-the-rollable-smartphone-that-never-was-111606421.html?src=rss](https://www.engadget.com/the-morning-after-the-rollable-smartphone-that-never-was-111606421.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 11:16:06+00:00

<p>At CES 2021, LG revealed it was working on a phone with a rollable display and that it was going to be available later that year. Unfortunately, the company shuttered its mobile business before that happened. Now, a hands-on video by Korean tech reviewer BullsLab <a href="https://www.engadget.com/lg-rollable-hands-on-122505508.html%20https://www.engadget.com/...">shows</a> just how close LG’s Rollable got to launching.</p><p>The Rollable went a different way with flexible screen tech. Instead

## Instagram is working on 'nudity protection' technology for messages
 - [https://www.engadget.com/instagram-protect-from-unsolicited-nude-images-081812784.html?src=rss](https://www.engadget.com/instagram-protect-from-unsolicited-nude-images-081812784.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 08:18:12+00:00

<p>Unsolicited nude photos are a massive problem on social media, but Instagram is reportedly working on a tool that could help. An early screengrab <a href="https://twitter.com/alex193a/status/1571924946183397377">tweeted</a> by researcher Alessandro Paluzzi indicates that &quot;Nudity protection&quot; technology &quot;covers photos that may contain nudity in chat,&quot; giving users the option to view them or not. Instagram parent Meta confirmed to <a href="https://www.theverge.com/2022/9/21/2

## NASA successfully completes vital Artemis 1 rocket fuel test
 - [https://www.engadget.com/nasa-completes-artemis-1-rocket-fuel-test-034656131.html?src=rss](https://www.engadget.com/nasa-completes-artemis-1-rocket-fuel-test-034656131.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-09-22 03:46:56+00:00

<p>The next Artemis 1 launch attempt might take place as soon as next week, seeing as NASA has met all the objectives it set out to do to consider its rocket's <a href="https://blogs.nasa.gov/artemis/">fuel test a success</a>. NASA had to test adding super-cooled fuel to the Space Launch System's tanks to confirm the repairs it made after it <a href="https://www.engadget.com/nasa-scrubs-artemis-1-again-153016409.html">scrubbed</a> the mission's second launch attempt in late August. The ground te


# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Shop teacher Kayla Lemieux with those enormous fake knockers debuts their new poolside look
 - [https://www.louderwithcrowder.com/canadian-teacher-poolside](https://www.louderwithcrowder.com/canadian-teacher-poolside)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-22 18:28:04+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31802988&amp;width=1245&amp;height=700&amp;coordinates=0%2C118%2C0%2C0" /><br /><br /><p>
	Kayla Lemieux, the Canadian shop teacher who was once a man but is now living her best life with size ZZZ fake chesticles, has taken the internet by storm. Kayla debuted in a viral video <a href="https://www.louderwithcrowder.com/shop-teacher-ontario" target="_blank">of them and her fake knockers</a>, with rock solid fake nipples, tryin

## 'Very troubling to me': Donald Trump's son-in-law Jared Kushner attacks Ron DeSantis over migrant stunt
 - [https://www.louderwithcrowder.com/jared-kushner-ron-desantis](https://www.louderwithcrowder.com/jared-kushner-ron-desantis)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-22 17:25:47+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31802702&amp;width=1200&amp;height=800&amp;coordinates=24%2C0%2C0%2C0" /><br /><br /><p>Conservatives have been saying for eons that if the left is going to ignore the border crisis and signal their virtue by calling themselves "sanctuary cities," the migrants leftists want so much should be moved to those sanctuary cities. Stop overwhelming the small border towns in Texas and Arizona, and make leftists live by the consequenc

## Watch: Man who murdered teenager he claimed was in a 'Republican extremist group' already out a bail
 - [https://www.louderwithcrowder.com/north-dakota-man-bail](https://www.louderwithcrowder.com/north-dakota-man-bail)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-22 16:47:42+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31793459&amp;width=1200&amp;height=800&amp;coordinates=24%2C0%2C0%2C0" /><br /><br /><p>On September 1, Joe Biden gave a <a href="https://www.louderwithcrowder.com/joe-biden-unaired-60-minutes" target="_blank">divisive speech declaring "MAGA Republicans"</a> extremists and a threat to democracy. Three weeks later, Shannon Brandt murdered a teenager with his car over a political dispute, claiming the teen was part of a "Republ

## Matthew McConaughey, who flirted with a run for Governor, now wants you to think he may run for President
 - [https://www.louderwithcrowder.com/matthew-mcconaughey-flirts-president](https://www.louderwithcrowder.com/matthew-mcconaughey-flirts-president)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-22 14:33:14+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31801880&amp;width=1245&amp;height=700&amp;coordinates=0%2C69%2C0%2C49" /><br /><br /><p>Matthew McConaughey wants you to think he's considering a run for president. The star of such hits as <em>Dazed and Confused</em> and <em>EdTV</em> had <a href="https://www.louderwithcrowder.com/texas-governor-matthew-mcconaughey" target="_blank">flirted with the idea of running for Texas Governor</a>. Then he said he wasn't. Now, he's fl

## New Leftist Trend: Murdering Republican Teens? (Show Notes)
 - [https://www.louderwithcrowder.com/show-notes-republican-teens](https://www.louderwithcrowder.com/show-notes-republican-teens)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-22 14:10:25+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31801894&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C1" /><br /><br /><p>Did you hear the one about the leftist who murdered a "Republican extremist" with his car? After Joe Biden declared war on MAGA Republicans? I’m guessing not, but you will after today’s show. Also, Rashida Tlaib wants a ban on fossil fuels and got shut down by someone who isn’t a moron. And why exactly is military recruiting down?</p><p cla

## David Hogg releases anti-Ben Shapiro manifesto, refuses to respect him until Shapiro learns about sex
 - [https://www.louderwithcrowder.com/david-hogg-ben-shapiro](https://www.louderwithcrowder.com/david-hogg-ben-shapiro)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-22 13:17:37+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31801521&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>It's all over for Ben Shapiro. He had a good run. He survived almost getting beat up by a trans activist. He's destroyed many an opponent using facts and reason. And, as of this writing, there has yet to be definitive proof that the Daily Wire tumbler causes cancer. Mostly because it causes three new cancers they don't have names for yet,

## Wow: Dems double down on attacking Fox News immigration reporter, mock him for being too good looking
 - [https://www.louderwithcrowder.com/bill-melugin-part-time-arizona](https://www.louderwithcrowder.com/bill-melugin-part-time-arizona)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-22 12:38:41+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31801418&amp;width=1245&amp;height=700&amp;coordinates=0%2C59%2C0%2C59" /><br /><br /><p>It's clear Democrats believe their immigration problems are not the border crisis of their own creation. It's ackshually Bill Melugin reporting on their border crisis. It started as all things do, with a Media Matters hit piece back in May. When <a href="https://www.louderwithcrowder.com/jonathan-turley-desantis-immigrant-lawsuit" target=

## Watch: Stacey Abrams makes shocking and extreme anti-science claim about abortion and fetal heartbeats
 - [https://www.louderwithcrowder.com/stacey-abrams-men-control-bodies](https://www.louderwithcrowder.com/stacey-abrams-men-control-bodies)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-22 12:02:39+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31801198&amp;width=1245&amp;height=700&amp;coordinates=0%2C70%2C0%2C50" /><br /><br /><p>Democrats still think the Supreme Court overturn of Roe v Wade is going to lead them to victory in November. It sure as dookie isn't the economy, immigration, cost of living, the direction of America, or what an inspiring leader Joe Biden is. Abortion is all they have. They're running it into the ground as if it's a seventy-eight-year-old


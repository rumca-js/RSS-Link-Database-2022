# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## A pair of Rust kernel modules
 - [https://lwn.net/Articles/907685/](https://lwn.net/Articles/907685/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 23:51:01+00:00

<p>Article URL: <a href="https://lwn.net/Articles/907685/">https://lwn.net/Articles/907685/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32946145">https://news.ycombinator.com/item?id=32946145</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## We Need New Motherboards Before GPUs Collapse Under Their Own Gravity
 - [https://erikmcclure.com/blog/we-need-new-motherboards/](https://erikmcclure.com/blog/we-need-new-motherboards/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 23:32:49+00:00

<p>Article URL: <a href="https://erikmcclure.com/blog/we-need-new-motherboards/">https://erikmcclure.com/blog/we-need-new-motherboards/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32946012">https://news.ycombinator.com/item?id=32946012</a></p>
<p>Points: 43</p>
<p># Comments: 51</p>

## Rust 2024 the Year of Everywhere?
 - [https://smallcultfollowing.com/babysteps/blog/2022/09/22/rust-2024-the-year-of-everywhere/](https://smallcultfollowing.com/babysteps/blog/2022/09/22/rust-2024-the-year-of-everywhere/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 23:28:08+00:00

<p>Article URL: <a href="https://smallcultfollowing.com/babysteps/blog/2022/09/22/rust-2024-the-year-of-everywhere/">https://smallcultfollowing.com/babysteps/blog/2022/09/22/rust-2024-the-year-of-everywhere/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32945978">https://news.ycombinator.com/item?id=32945978</a></p>
<p>Points: 30</p>
<p># Comments: 6</p>

## Avoiding homework with code (and getting caught)
 - [https://alistair.blog/mochip](https://alistair.blog/mochip)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 23:20:00+00:00

<p>Article URL: <a href="https://alistair.blog/mochip">https://alistair.blog/mochip</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32945906">https://news.ycombinator.com/item?id=32945906</a></p>
<p>Points: 24</p>
<p># Comments: 2</p>

## Despite faster broadband every year, web pages don't load any faster
 - [https://www.datafantic.com/how-much-time-do-we-waste-waiting-for-websites-to-load/](https://www.datafantic.com/how-much-time-do-we-waste-waiting-for-websites-to-load/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 23:13:17+00:00

<p>Article URL: <a href="https://www.datafantic.com/how-much-time-do-we-waste-waiting-for-websites-to-load/">https://www.datafantic.com/how-much-time-do-we-waste-waiting-for-websites-to-load/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32945858">https://news.ycombinator.com/item?id=32945858</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Expanding access to the future of work with crypto payouts
 - [https://stripe.com/newsroom/stories/braintrust-crypto-payouts](https://stripe.com/newsroom/stories/braintrust-crypto-payouts)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 23:07:02+00:00

<p>Article URL: <a href="https://stripe.com/newsroom/stories/braintrust-crypto-payouts">https://stripe.com/newsroom/stories/braintrust-crypto-payouts</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32945801">https://news.ycombinator.com/item?id=32945801</a></p>
<p>Points: 21</p>
<p># Comments: 20</p>

## The rush to mine lithium could dry up the high Andes
 - [https://e360.yale.edu/features/lithium-mining-water-andes-argentina](https://e360.yale.edu/features/lithium-mining-water-andes-argentina)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 22:35:34+00:00

<p>Article URL: <a href="https://e360.yale.edu/features/lithium-mining-water-andes-argentina">https://e360.yale.edu/features/lithium-mining-water-andes-argentina</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32945508">https://news.ycombinator.com/item?id=32945508</a></p>
<p>Points: 15</p>
<p># Comments: 2</p>

## Pcmcia Pico W Card
 - [https://www.yyzkevin.com/pcmcia-pico-w-card/](https://www.yyzkevin.com/pcmcia-pico-w-card/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 22:02:04+00:00

<p>Article URL: <a href="https://www.yyzkevin.com/pcmcia-pico-w-card/">https://www.yyzkevin.com/pcmcia-pico-w-card/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32945197">https://news.ycombinator.com/item?id=32945197</a></p>
<p>Points: 29</p>
<p># Comments: 2</p>

## PayPal closes account of UK's Free Speech Union without explanation
 - [https://lauradodsworth.substack.com/p/paypal-censors-free-speech-union](https://lauradodsworth.substack.com/p/paypal-censors-free-speech-union)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 21:57:24+00:00

<p>Article URL: <a href="https://lauradodsworth.substack.com/p/paypal-censors-free-speech-union">https://lauradodsworth.substack.com/p/paypal-censors-free-speech-union</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32945147">https://news.ycombinator.com/item?id=32945147</a></p>
<p>Points: 62</p>
<p># Comments: 2</p>

## Why adults still dream about school
 - [https://www.theatlantic.com/family/archive/2022/09/why-school-haunts-our-dreams-long-after-graduation/671506/](https://www.theatlantic.com/family/archive/2022/09/why-school-haunts-our-dreams-long-after-graduation/671506/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 21:38:19+00:00

<p>Article URL: <a href="https://www.theatlantic.com/family/archive/2022/09/why-school-haunts-our-dreams-long-after-graduation/671506/">https://www.theatlantic.com/family/archive/2022/09/why-school-haunts-our-dreams-long-after-graduation/671506/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32944956">https://news.ycombinator.com/item?id=32944956</a></p>
<p>Points: 20</p>
<p># Comments: 14</p>

## New Story (YC S15) Is Hiring a Controller
 - [https://newstorycharity.org/careers/](https://newstorycharity.org/careers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 21:00:23+00:00

<p>Article URL: <a href="https://newstorycharity.org/careers/">https://newstorycharity.org/careers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32944570">https://news.ycombinator.com/item?id=32944570</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## TLDR explains what a piece of code does
 - [https://twitter.com/marcelpociot/status/1572690548074348549](https://twitter.com/marcelpociot/status/1572690548074348549)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 20:16:45+00:00

<p>Article URL: <a href="https://twitter.com/marcelpociot/status/1572690548074348549">https://twitter.com/marcelpociot/status/1572690548074348549</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32944069">https://news.ycombinator.com/item?id=32944069</a></p>
<p>Points: 40</p>
<p># Comments: 26</p>

## Luxury Media
 - [https://www.tbray.org/ongoing/When/202x/2022/09/21/Luxury-Media](https://www.tbray.org/ongoing/When/202x/2022/09/21/Luxury-Media)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 20:00:02+00:00

<p>Article URL: <a href="https://www.tbray.org/ongoing/When/202x/2022/09/21/Luxury-Media">https://www.tbray.org/ongoing/When/202x/2022/09/21/Luxury-Media</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32943904">https://news.ycombinator.com/item?id=32943904</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## 'Soleus Pushup' Fuels Metabolism for Hours While Sitting
 - [https://stories.uh.edu/2022-soleus-pushup/index.html](https://stories.uh.edu/2022-soleus-pushup/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 19:58:20+00:00

<p>Article URL: <a href="https://stories.uh.edu/2022-soleus-pushup/index.html">https://stories.uh.edu/2022-soleus-pushup/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32943890">https://news.ycombinator.com/item?id=32943890</a></p>
<p>Points: 52</p>
<p># Comments: 34</p>

## Japan to reopen to independent travelers and lift daily arrival cap
 - [https://www.japantimes.co.jp/news/2022/09/23/national/kishida-japan-border-opening/](https://www.japantimes.co.jp/news/2022/09/23/national/kishida-japan-border-opening/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 19:22:14+00:00

<p>Article URL: <a href="https://www.japantimes.co.jp/news/2022/09/23/national/kishida-japan-border-opening/">https://www.japantimes.co.jp/news/2022/09/23/national/kishida-japan-border-opening/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32943477">https://news.ycombinator.com/item?id=32943477</a></p>
<p>Points: 134</p>
<p># Comments: 37</p>

## Japan will allow visa-free, individual tourism from Oct. 11
 - [https://twitter.com/japantimes/status/1572962383252934656](https://twitter.com/japantimes/status/1572962383252934656)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 19:22:14+00:00

<p>Article URL: <a href="https://twitter.com/japantimes/status/1572962383252934656">https://twitter.com/japantimes/status/1572962383252934656</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32943477">https://news.ycombinator.com/item?id=32943477</a></p>
<p>Points: 48</p>
<p># Comments: 3</p>

## Dilemmas in a General Theory of Planning (1973) [pdf]
 - [https://hci.stanford.edu/dschool/resources/readings/Rittel+Webber+Dilemmas+General_Theory_of_Planning.pdf](https://hci.stanford.edu/dschool/resources/readings/Rittel+Webber+Dilemmas+General_Theory_of_Planning.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 19:22:02+00:00

<p>Article URL: <a href="https://hci.stanford.edu/dschool/resources/readings/Rittel+Webber+Dilemmas+General_Theory_of_Planning.pdf">https://hci.stanford.edu/dschool/resources/readings/Rittel+Webber+Dilemmas+General_Theory_of_Planning.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32943474">https://news.ycombinator.com/item?id=32943474</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Running a Docker Host under OpenBSD using vmd(8)
 - [https://www.tumfatig.net/2022/running-docker-host-openbsd-vmd/](https://www.tumfatig.net/2022/running-docker-host-openbsd-vmd/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 19:11:11+00:00

<p>Article URL: <a href="https://www.tumfatig.net/2022/running-docker-host-openbsd-vmd/">https://www.tumfatig.net/2022/running-docker-host-openbsd-vmd/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32943330">https://news.ycombinator.com/item?id=32943330</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Show HN: Open Prompts – dataset of 10M Stable Diffusion generations
 - [https://github.com/krea-ai/open-prompts](https://github.com/krea-ai/open-prompts)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 19:03:17+00:00

<p>Open Prompts is the dataset used to build krea.ai. The data comes from the Stability AI Discord and includes around 10M images from 2M prompts. You can use it for creating semantic search engines of prompts, training LLMs, fine-tuning image-to-text models like BLIP, or extracting insights from the data—like the most common combinations of modifiers.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32943224">https://news.ycombinator.com/item?id=32943224</a></p>
<p>Poin

## Most US professors are trained at same few elite universities
 - [https://www.nature.com/articles/d41586-022-02998-w](https://www.nature.com/articles/d41586-022-02998-w)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 18:38:24+00:00

<p>Article URL: <a href="https://www.nature.com/articles/d41586-022-02998-w">https://www.nature.com/articles/d41586-022-02998-w</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32942886">https://news.ycombinator.com/item?id=32942886</a></p>
<p>Points: 43</p>
<p># Comments: 25</p>

## Pgsqlite: a pure Python module to import SQLite databases into Postgres
 - [https://innerjoin.bit.io/introducing-pgsqlite-a-pure-python-module-to-import-sqlite-databases-into-postgres-bf3940cfa19f](https://innerjoin.bit.io/introducing-pgsqlite-a-pure-python-module-to-import-sqlite-databases-into-postgres-bf3940cfa19f)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 18:32:36+00:00

<p>Article URL: <a href="https://innerjoin.bit.io/introducing-pgsqlite-a-pure-python-module-to-import-sqlite-databases-into-postgres-bf3940cfa19f">https://innerjoin.bit.io/introducing-pgsqlite-a-pure-python-module-to-import-sqlite-databases-into-postgres-bf3940cfa19f</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32942820">https://news.ycombinator.com/item?id=32942820</a></p>
<p>Points: 15</p>
<p># Comments: 0</p>

## The Reason Java Is Still Popular
 - [https://debugagent.com/the-reason-java-is-still-popular](https://debugagent.com/the-reason-java-is-still-popular)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 18:17:43+00:00

<p>Article URL: <a href="https://debugagent.com/the-reason-java-is-still-popular">https://debugagent.com/the-reason-java-is-still-popular</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32942651">https://news.ycombinator.com/item?id=32942651</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Tell HN: Reddit shadowban account upon creation
 - [https://news.ycombinator.com/item?id=32942635](https://news.ycombinator.com/item?id=32942635)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 18:16:42+00:00

<p>Sharing this funny story so that people won't feel alone when it happen to them.<p>It seems my first and only reddit account created two hours ago is shadow-banned since the very beginning, tried one comment on /r/cpp and one post on /r/rust, nobody ever seen them other than one kind mod that confirmed there's nothing they can do.<p>Even funnier is that there is a subreddit /r/ShadowBan dedicated to test shadowban and some obvious spam-bot accounts are not banned yet mine is.<p>related:
[1] h

## Extending supabase with your own back end – its supa easy
 - [https://blog.xa0.de/post/Extending-supabase-with-your-own-backend%20---%20its-supa-easy%21/](https://blog.xa0.de/post/Extending-supabase-with-your-own-backend%20---%20its-supa-easy%21/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 18:12:38+00:00

<p>Article URL: <a href="https://blog.xa0.de/post/Extending-supabase-with-your-own-backend%20---%20its-supa-easy%21/">https://blog.xa0.de/post/Extending-supabase-with-your-own-backend%20---%20its-supa-easy%21/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32942579">https://news.ycombinator.com/item?id=32942579</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Florida to Supreme Court: Let us regulate social networks as common carriers
 - [https://arstechnica.com/tech-policy/2022/09/florida-to-supreme-court-let-us-regulate-social-networks-as-common-carriers/](https://arstechnica.com/tech-policy/2022/09/florida-to-supreme-court-let-us-regulate-social-networks-as-common-carriers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 18:08:21+00:00

<p>Article URL: <a href="https://arstechnica.com/tech-policy/2022/09/florida-to-supreme-court-let-us-regulate-social-networks-as-common-carriers/">https://arstechnica.com/tech-policy/2022/09/florida-to-supreme-court-let-us-regulate-social-networks-as-common-carriers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32942540">https://news.ycombinator.com/item?id=32942540</a></p>
<p>Points: 43</p>
<p># Comments: 122</p>

## AlphaFold developers win US$3M Breakthrough Prize
 - [https://www.nature.com/articles/d41586-022-02999-9](https://www.nature.com/articles/d41586-022-02999-9)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 17:46:00+00:00

<p>Article URL: <a href="https://www.nature.com/articles/d41586-022-02999-9">https://www.nature.com/articles/d41586-022-02999-9</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32942260">https://news.ycombinator.com/item?id=32942260</a></p>
<p>Points: 55</p>
<p># Comments: 3</p>

## Nvidia launches first SaaS Offering
 - [https://nvidianews.nvidia.com/news/nvidia-launches-omniverse-cloud-services-for-building-and-operating-industrial-metaverse-applications](https://nvidianews.nvidia.com/news/nvidia-launches-omniverse-cloud-services-for-building-and-operating-industrial-metaverse-applications)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 17:25:41+00:00

<p>Article URL: <a href="https://nvidianews.nvidia.com/news/nvidia-launches-omniverse-cloud-services-for-building-and-operating-industrial-metaverse-applications">https://nvidianews.nvidia.com/news/nvidia-launches-omniverse-cloud-services-for-building-and-operating-industrial-metaverse-applications</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32941968">https://news.ycombinator.com/item?id=32941968</a></p>
<p>Points: 19</p>
<p># Comments: 14</p>

## Hightouch (YC S19) Is Hiring an Engineering Manager
 - [https://boards.greenhouse.io/hightouch/jobs/4580317004](https://boards.greenhouse.io/hightouch/jobs/4580317004)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 17:00:23+00:00

<p>Article URL: <a href="https://boards.greenhouse.io/hightouch/jobs/4580317004">https://boards.greenhouse.io/hightouch/jobs/4580317004</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32941630">https://news.ycombinator.com/item?id=32941630</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Google wants to take on Dolby with new open media formats
 - [https://www.protocol.com/entertainment/google-dolby-atmos-vision-project-caviar](https://www.protocol.com/entertainment/google-dolby-atmos-vision-project-caviar)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 16:17:59+00:00

<p>Article URL: <a href="https://www.protocol.com/entertainment/google-dolby-atmos-vision-project-caviar">https://www.protocol.com/entertainment/google-dolby-atmos-vision-project-caviar</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32941051">https://news.ycombinator.com/item?id=32941051</a></p>
<p>Points: 54</p>
<p># Comments: 41</p>

## TimescaleDB 2.7 vs. PostgreSQL 14
 - [https://www.timescale.com/blog/postgresql-timescaledb-1000x-faster-queries-90-data-compression-and-much-more/](https://www.timescale.com/blog/postgresql-timescaledb-1000x-faster-queries-90-data-compression-and-much-more/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 15:54:04+00:00

<p>Article URL: <a href="https://www.timescale.com/blog/postgresql-timescaledb-1000x-faster-queries-90-data-compression-and-much-more/">https://www.timescale.com/blog/postgresql-timescaledb-1000x-faster-queries-90-data-compression-and-much-more/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32940701">https://news.ycombinator.com/item?id=32940701</a></p>
<p>Points: 38</p>
<p># Comments: 3</p>

## Gender and Age Differences in Love Styles and Attitudes
 - [https://www.dimensional.me/blog/gender-differences-in-love-attitudes-and-expression](https://www.dimensional.me/blog/gender-differences-in-love-attitudes-and-expression)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 15:12:35+00:00

<p>Article URL: <a href="https://www.dimensional.me/blog/gender-differences-in-love-attitudes-and-expression">https://www.dimensional.me/blog/gender-differences-in-love-attitudes-and-expression</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32939981">https://news.ycombinator.com/item?id=32939981</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Show HN: I made an open-source Bitly alternative
 - [https://dub.sh/](https://dub.sh/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 14:39:52+00:00

<p>Article URL: <a href="https://dub.sh/">https://dub.sh/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32939407">https://news.ycombinator.com/item?id=32939407</a></p>
<p>Points: 32</p>
<p># Comments: 32</p>

## American Data Privacy and Protection Act
 - [https://www.congress.gov/bill/117th-congress/house-bill/8152/text](https://www.congress.gov/bill/117th-congress/house-bill/8152/text)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 14:32:34+00:00

<p>Article URL: <a href="https://www.congress.gov/bill/117th-congress/house-bill/8152/text">https://www.congress.gov/bill/117th-congress/house-bill/8152/text</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32939301">https://news.ycombinator.com/item?id=32939301</a></p>
<p>Points: 33</p>
<p># Comments: 8</p>

## The Road to Realistic Full-Body Deepfakes
 - [https://metaphysic.ai/the-road-to-realistic-full-body-deepfakes/](https://metaphysic.ai/the-road-to-realistic-full-body-deepfakes/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 14:15:44+00:00

<p>Article URL: <a href="https://metaphysic.ai/the-road-to-realistic-full-body-deepfakes/">https://metaphysic.ai/the-road-to-realistic-full-body-deepfakes/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32939058">https://news.ycombinator.com/item?id=32939058</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Wasp (YC W21) is hiring eng to work on DSL for making web apps (compiler, webdev)
 - [https://news.ycombinator.com/item?id=32938880](https://news.ycombinator.com/item?id=32938880)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 14:03:15+00:00

<p>Wasp-lang (<a href="https://wasp-lang.dev/" rel="nofollow">https://wasp-lang.dev/</a>) | Founding Engineer | Full-Time | Remote [GMT - 5, GMT + 3]<p>At Wasp, we are building a compiled, stack-agnostic DSL for implementing full stack web-apps, that interops with the existing stack (React & Node.js currently). Imagine Ruby on Rails as a language and not bound to the specific stack or architecture. The compiler is implemented in Haskell.<p>Our team is remote, with engineers currently located bot

## Facebook proven to negatively impact mental health
 - [https://english.tau.ac.il/science_links_facebook_mental_health](https://english.tau.ac.il/science_links_facebook_mental_health)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 13:41:57+00:00

<p>Article URL: <a href="https://english.tau.ac.il/science_links_facebook_mental_health">https://english.tau.ac.il/science_links_facebook_mental_health</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32938622">https://news.ycombinator.com/item?id=32938622</a></p>
<p>Points: 91</p>
<p># Comments: 46</p>

## Google loses EU appeal and is fined a record $4B
 - [https://www.axios.com/2022/09/14/google-loses-appeal-eu-antitrust-ruling](https://www.axios.com/2022/09/14/google-loses-appeal-eu-antitrust-ruling)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 13:37:42+00:00

<p>Article URL: <a href="https://www.axios.com/2022/09/14/google-loses-appeal-eu-antitrust-ruling">https://www.axios.com/2022/09/14/google-loses-appeal-eu-antitrust-ruling</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32938589">https://news.ycombinator.com/item?id=32938589</a></p>
<p>Points: 97</p>
<p># Comments: 54</p>

## The Next Silicon Valley Will Be in the US Heartland
 - [https://www.wired.com/story/the-next-silicon-valley-will-be-in-the-us-heartlands/](https://www.wired.com/story/the-next-silicon-valley-will-be-in-the-us-heartlands/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 13:25:42+00:00

<p>Article URL: <a href="https://www.wired.com/story/the-next-silicon-valley-will-be-in-the-us-heartlands/">https://www.wired.com/story/the-next-silicon-valley-will-be-in-the-us-heartlands/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32938467">https://news.ycombinator.com/item?id=32938467</a></p>
<p>Points: 27</p>
<p># Comments: 31</p>

## First new Jakarta EE (Java EE) release in years; Jakarta EE 10 released
 - [https://jakarta.ee/news/jakarta-ee-10-released/](https://jakarta.ee/news/jakarta-ee-10-released/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 13:24:50+00:00

<p>Article URL: <a href="https://jakarta.ee/news/jakarta-ee-10-released/">https://jakarta.ee/news/jakarta-ee-10-released/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32938457">https://news.ycombinator.com/item?id=32938457</a></p>
<p>Points: 19</p>
<p># Comments: 7</p>

## Remote workers are wasting their time proving they’re working
 - [https://www.vox.com/recode/2022/9/22/23360887/remote-work-productivity-theater-back-to-office](https://www.vox.com/recode/2022/9/22/23360887/remote-work-productivity-theater-back-to-office)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 13:13:46+00:00

<p>Article URL: <a href="https://www.vox.com/recode/2022/9/22/23360887/remote-work-productivity-theater-back-to-office">https://www.vox.com/recode/2022/9/22/23360887/remote-work-productivity-theater-back-to-office</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32938345">https://news.ycombinator.com/item?id=32938345</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Censorship by Big Tech at the behest of the U.S. government
 - [https://www.tabletmag.com/sections/arts-letters/articles/government-privatized-censorship-regime](https://www.tabletmag.com/sections/arts-letters/articles/government-privatized-censorship-regime)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 13:09:43+00:00

<p>Article URL: <a href="https://www.tabletmag.com/sections/arts-letters/articles/government-privatized-censorship-regime">https://www.tabletmag.com/sections/arts-letters/articles/government-privatized-censorship-regime</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32938305">https://news.ycombinator.com/item?id=32938305</a></p>
<p>Points: 17</p>
<p># Comments: 0</p>

## ZincSearch – lightweight alternative to Elasticsearch written in Go
 - [https://zincsearch.com/](https://zincsearch.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 13:09:40+00:00

<p>Article URL: <a href="https://zincsearch.com/">https://zincsearch.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32938304">https://news.ycombinator.com/item?id=32938304</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## C++ by Example
 - [https://cppbyexample.com](https://cppbyexample.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 12:52:29+00:00

<p>Article URL: <a href="https://cppbyexample.com">https://cppbyexample.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32938135">https://news.ycombinator.com/item?id=32938135</a></p>
<p>Points: 58</p>
<p># Comments: 14</p>

## Bitmap Indexes in Go: Search Speed (2019)
 - [https://habr.com/en/company/badoo/blog/455608/](https://habr.com/en/company/badoo/blog/455608/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 12:29:35+00:00

<p>Article URL: <a href="https://habr.com/en/company/badoo/blog/455608/">https://habr.com/en/company/badoo/blog/455608/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32937930">https://news.ycombinator.com/item?id=32937930</a></p>
<p>Points: 30</p>
<p># Comments: 1</p>

## Chainalysis: A startup that helps governments trace crypto
 - [https://www.bloomberg.com/news/articles/2022-09-21/crypto-tracer-chainalysis-busts-bitcoin-btc-anonymity](https://www.bloomberg.com/news/articles/2022-09-21/crypto-tracer-chainalysis-busts-bitcoin-btc-anonymity)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 12:23:21+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2022-09-21/crypto-tracer-chainalysis-busts-bitcoin-btc-anonymity">https://www.bloomberg.com/news/articles/2022-09-21/crypto-tracer-chainalysis-busts-bitcoin-btc-anonymity</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32937876">https://news.ycombinator.com/item?id=32937876</a></p>
<p>Points: 8</p>
<p># Comments: 4</p>

## The origin of the strong form of superconductivity
 - [https://www.quantamagazine.org/high-temperature-superconductivity-understood-at-last-20220921/](https://www.quantamagazine.org/high-temperature-superconductivity-understood-at-last-20220921/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 12:18:34+00:00

<p>Article URL: <a href="https://www.quantamagazine.org/high-temperature-superconductivity-understood-at-last-20220921/">https://www.quantamagazine.org/high-temperature-superconductivity-understood-at-last-20220921/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32937828">https://news.ycombinator.com/item?id=32937828</a></p>
<p>Points: 23</p>
<p># Comments: 0</p>

## Engine makers sound downbeat on supersonic, leaving Boom in a bind
 - [https://www.flightglobal.com/airframers/engine-makers-sound-downbeat-on-supersonic-leaving-boom-in-a-bind/150215.article](https://www.flightglobal.com/airframers/engine-makers-sound-downbeat-on-supersonic-leaving-boom-in-a-bind/150215.article)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 12:09:29+00:00

<p>Article URL: <a href="https://www.flightglobal.com/airframers/engine-makers-sound-downbeat-on-supersonic-leaving-boom-in-a-bind/150215.article">https://www.flightglobal.com/airframers/engine-makers-sound-downbeat-on-supersonic-leaving-boom-in-a-bind/150215.article</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32937736">https://news.ycombinator.com/item?id=32937736</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Facebook sued for skirting Apple privacy rules to snoop on users
 - [https://www.bloomberg.com/news/articles/2022-09-22/meta-sued-for-skirting-apple-privacy-rules-to-snoop-on-users](https://www.bloomberg.com/news/articles/2022-09-22/meta-sued-for-skirting-apple-privacy-rules-to-snoop-on-users)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 12:06:42+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2022-09-22/meta-sued-for-skirting-apple-privacy-rules-to-snoop-on-users">https://www.bloomberg.com/news/articles/2022-09-22/meta-sued-for-skirting-apple-privacy-rules-to-snoop-on-users</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32937710">https://news.ycombinator.com/item?id=32937710</a></p>
<p>Points: 106</p>
<p># Comments: 35</p>

## I came up with a better way to communicate with users
 - [https://news.ycombinator.com/item?id=32937523](https://news.ycombinator.com/item?id=32937523)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 11:42:54+00:00

<p>f you like me and have created a website or an app that had some active users (I had 30 lol ) then you’ve probably realized that there is no good way to talk to them.<p>Emails have a low response rate and can be just lost in spam. Feedback forms are hard to implement and are not very flexible. Creating communities in discord/slack takes time.<p>So as a self-respected developer I decided to solve this problem. I thought why not bring smth like discord server directly to a website/app? Somethin

## Exploring Lock-Free Rust (2017)
 - [https://morestina.net/blog/742/exploring-lock-free-rust-1-locks](https://morestina.net/blog/742/exploring-lock-free-rust-1-locks)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 09:53:29+00:00

<p>Article URL: <a href="https://morestina.net/blog/742/exploring-lock-free-rust-1-locks">https://morestina.net/blog/742/exploring-lock-free-rust-1-locks</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32936746">https://news.ycombinator.com/item?id=32936746</a></p>
<p>Points: 21</p>
<p># Comments: 1</p>

## If the Moon Were Only 1 Pixel - real scale of our Solar System
 - [https://joshworth.com/dev/pixelspace/pixelspace_solarsystem.html](https://joshworth.com/dev/pixelspace/pixelspace_solarsystem.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 09:27:12+00:00

<p>Article URL: <a href="https://joshworth.com/dev/pixelspace/pixelspace_solarsystem.html">https://joshworth.com/dev/pixelspace/pixelspace_solarsystem.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32936581">https://news.ycombinator.com/item?id=32936581</a></p>
<p>Points: 39</p>
<p># Comments: 27</p>

## Lose weight the slow and incredibly difficult way
 - [https://nautil.us/lose-weight-the-slow-and-incredibly-difficult-way-239703/](https://nautil.us/lose-weight-the-slow-and-incredibly-difficult-way-239703/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 09:04:19+00:00

<p>Article URL: <a href="https://nautil.us/lose-weight-the-slow-and-incredibly-difficult-way-239703/">https://nautil.us/lose-weight-the-slow-and-incredibly-difficult-way-239703/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32936436">https://news.ycombinator.com/item?id=32936436</a></p>
<p>Points: 50</p>
<p># Comments: 9</p>

## Show HN: Rocketry – Modern scheduler to power your Python projects
 - [https://github.com/Miksus/rocketry](https://github.com/Miksus/rocketry)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 06:44:30+00:00

<p>Article URL: <a href="https://github.com/Miksus/rocketry">https://github.com/Miksus/rocketry</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32935506">https://news.ycombinator.com/item?id=32935506</a></p>
<p>Points: 19</p>
<p># Comments: 8</p>

## Ask HN: Which books you have read till now that were worth investing time in?
 - [https://news.ycombinator.com/item?id=32935412](https://news.ycombinator.com/item?id=32935412)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 06:31:44+00:00

<p>The books you mention can be of any genre and from any discipline of life. The important criteria is that they were helpful to you in whatever way you think.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32935412">https://news.ycombinator.com/item?id=32935412</a></p>
<p>Points: 16</p>
<p># Comments: 5</p>

## So You Want to Compete with Steam
 - [https://www.fortressofdoors.com/so-you-want-to-compete-with-steam/](https://www.fortressofdoors.com/so-you-want-to-compete-with-steam/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 06:11:30+00:00

<p>Article URL: <a href="https://www.fortressofdoors.com/so-you-want-to-compete-with-steam/">https://www.fortressofdoors.com/so-you-want-to-compete-with-steam/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32935290">https://news.ycombinator.com/item?id=32935290</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## 9m Australians affected by Optus data breach
 - [https://www.optus.com.au/about/media-centre/media-releases/2022/09/optus-notifies-customers-of-cyberattack](https://www.optus.com.au/about/media-centre/media-releases/2022/09/optus-notifies-customers-of-cyberattack)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 05:18:30+00:00

<p>Article URL: <a href="https://www.optus.com.au/about/media-centre/media-releases/2022/09/optus-notifies-customers-of-cyberattack">https://www.optus.com.au/about/media-centre/media-releases/2022/09/optus-notifies-customers-of-cyberattack</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32935046">https://news.ycombinator.com/item?id=32935046</a></p>
<p>Points: 59</p>
<p># Comments: 21</p>

## As unrest grows, Iran restricts access to Instagram, WhatsApp
 - [https://www.reuters.com/world/middle-east/iran-restricts-access-instagram-netblocks-2022-09-21/](https://www.reuters.com/world/middle-east/iran-restricts-access-instagram-netblocks-2022-09-21/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 04:56:18+00:00

<p>Article URL: <a href="https://www.reuters.com/world/middle-east/iran-restricts-access-instagram-netblocks-2022-09-21/">https://www.reuters.com/world/middle-east/iran-restricts-access-instagram-netblocks-2022-09-21/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32934936">https://news.ycombinator.com/item?id=32934936</a></p>
<p>Points: 37</p>
<p># Comments: 7</p>

## Real-time sync for apps even without the internet
 - [https://www.ditto.live/](https://www.ditto.live/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 04:38:38+00:00

<p>Article URL: <a href="https://www.ditto.live/">https://www.ditto.live/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32934849">https://news.ycombinator.com/item?id=32934849</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Cinder is Meta's internal performance-oriented production version of CPython
 - [https://github.com/facebookincubator/cinder](https://github.com/facebookincubator/cinder)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 01:54:20+00:00

<p>Article URL: <a href="https://github.com/facebookincubator/cinder">https://github.com/facebookincubator/cinder</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32933991">https://news.ycombinator.com/item?id=32933991</a></p>
<p>Points: 20</p>
<p># Comments: 14</p>

## The Deceiving Stretch of Water with 100% Mortality Rate
 - [https://the-yorkshireman.com/the-strid/](https://the-yorkshireman.com/the-strid/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-22 00:56:33+00:00

<p>Article URL: <a href="https://the-yorkshireman.com/the-strid/">https://the-yorkshireman.com/the-strid/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32933603">https://news.ycombinator.com/item?id=32933603</a></p>
<p>Points: 22</p>
<p># Comments: 8</p>


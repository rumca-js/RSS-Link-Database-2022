# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## KDE 5.26 beta, GNOME 43, and New Snap Store - Linux and Open Source News
 - [https://www.youtube.com/watch?v=51bxcMiMEj4](https://www.youtube.com/watch?v=51bxcMiMEj4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-09-23 00:00:00+00:00

Get 100$ credit for your own Linux and gaming server: https://www.linode.com/linuxexperiment 
Grab a brand new laptop or desktop running Linux:https://www.tuxedocomputers.com/en#


👏 SUPPORT THE CHANNEL:
Get access to a weekly podcast, vote on the next topics I cover, and get your name in the credits:

YouTube: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join
Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

📹 MORE VIDEOS FROM ME
Linux news in Shorts format: https://www.youtube.com/channel/UCtZp0mK9IBrpS2-jNzMZmoA
Gaming on Linux: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw
I'm also on ODYSEE: https://odysee.com/$/invite/@TheLinuxExperiment:e

🏆 FOLLOW ME ELSEWHERE:
Twitter : http://twitter.com/thelinuxEXP
Mastodon: https://mastodon.social/web/@thelinuxEXP
Pixelfed: https://pixelfed.social/TLENick

📷 GEAR I USE:
Sony Alpha A6600 Mirrorless Camera: https://amzn.to/30zKyn7
Sigma 56mm Fixed Prime Lens: https://amzn.to/3aRvK5l
Logitech MX Master 3 Mouse: https://amzn.to/3BVI0Od
Bluetooth Space Grey Mac Keyboard: https://amzn.to/3jcJETZ
Logitech Brio 4K Webcam: https://amzn.to/3jgeTh9
LG Curved Ultrawide Monitor: https://amzn.to/3pcTVDH
Logitech White Speakers: https://amzn.to/3n6wSb0
Xbox Controller: https://amzn.to/3BWmIA3
*Amazon Links are affiliate codes and generate small commissions to support the channel*

This video is distributed under the Creative Commons Share Alike license.

#linux #opensource #news 

00:00 Intro
00:33 Sponsor: 100$ free credit for your Linux or gaming server
01:28 KDE Plasma 5.26: Plasma comes to the big screen
03:54 GNOME 43 is released
05:16 GNOME weekly updates
06:54 KDE Weekly updates
08:32 New Ubuntu Snap Store shows promise
10:07 Kdenlive raises money to improve performance
11:27 Intel funds Krita
12:48 343 works on Halo on Linux, and Linux driver improvements
14:21 Sponsor: Get a device that runs Linux perfectly
15:30 Support the channel

KDE Plasma 5.26: Plasma comes to the big screen
https://kde.org/announcements/plasma/5/5.25.90/

GNOME 43 is released
https://www.youtube.com/watch?v=wefK40cjz9s

GNOME weekly updates
https://blogs.gnome.org/alexm/2022/09/15/libadwaita-1-2/

https://thisweek.gnome.org/posts/2022/09/twig-61/

KDE Weekly updates
https://pointieststick.com/2022/09/16/this-week-in-kde-its-a-big-one-folks/

https://claudiocambra.com/2022/09/15/kde-pim-in-july-and-august/

New Ubuntu Snap Store shows promise
https://www.omgubuntu.co.uk/2022/09/that-unofficial-snap-store-could-become-more-official

Kdenlive raises money to improve performance
https://kdenlive.org/en/fund/

Intel funds Krita
https://krita.org/en/item/intel-becomes-first-krita-development-fund-corporate-gold-patron/#

343 works on Halo on Linux, and Linux driver improvements
https://www.gamingonlinux.com/2022/09/343-working-on-halo-the-master-chief-collection-anti-cheat-for-steam-deck-linux/

https://www.gamingonlinux.com/2022/09/mesa-gets-a-big-csgo-speedup-plus-upcoming-amd-radv-performance-boost/

https://www.gamingonlinux.com/2022/09/intel-linux-vulkan-driver-readying-up-a-60p-speed-boost/


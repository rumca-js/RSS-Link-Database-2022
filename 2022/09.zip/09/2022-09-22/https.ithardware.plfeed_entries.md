# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Epic Games Store. Nowe gry dostępne za darmo do pobrania
 - [https://ithardware.pl/aktualnosci/epic_games_store_nowe_gry_dostepne_za_darmo_do_pobrania-23457.html](https://ithardware.pl/aktualnosci/epic_games_store_nowe_gry_dostepne_za_darmo_do_pobrania-23457.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 20:55:10+00:00

<img src="https://ithardware.pl/artykuly/min/23457_1.jpg" />            Od dziś w Epic Games Store dostępne są do odebrania za darmo dwie gry. Platforma ujawniła także produkcje, kt&oacute;re przypiszemy do kont w kolejny czwartek.

Zgodnie z zapowiedzią od dzisiaj, 22 do 29 września możemy przypisać do swoich...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/epic_games_store_nowe_gry_dostepne_za_darmo_do_pobrania-23457.html">https://ithardware.pl/aktualnosci/epic_

## Take-Two na wojnie z modderami. Wydawca zażądał usunięcia modyfikacji do GTA 4
 - [https://ithardware.pl/aktualnosci/take_two_na_wojnie_z_modderami_wydawca_zazadal_usuniecia_modyfikacji_do_gta_4-23453.html](https://ithardware.pl/aktualnosci/take_two_na_wojnie_z_modderami_wydawca_zazadal_usuniecia_modyfikacji_do_gta_4-23453.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 18:40:00+00:00

<img src="https://ithardware.pl/artykuly/min/23453_1.jpg" />            Take-Two walczy z modderami, kt&oacute;rzy przygotowują modyfikacje do poszczeg&oacute;lnych odsłon Grand Theft Auto i domaga się ich wycofania z internetowej dystrybucji. Nie inaczej jest w przypadku moda do GTA 4.

Zesp&oacute;ł modder&oacute;w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/take_two_na_wojnie_z_modderami_wydawca_zazadal_usuniecia_modyfikacji_do_gta_4-23453.html">https://it

## Splinter Cell Remake otrzyma zmodyfikowaną historię dostosowaną do współcznesnego gracza
 - [https://ithardware.pl/aktualnosci/splinter_cell_remake_otrzyma_zmodyfikowana_historie_dostosowana_do_wspolcznesnego_gracza-23452.html](https://ithardware.pl/aktualnosci/splinter_cell_remake_otrzyma_zmodyfikowana_historie_dostosowana_do_wspolcznesnego_gracza-23452.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 17:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/23452_1.jpg" />            Splinter Cell został odstawiony przez Ubisoft na boczny tor ze względu na inne marki takie jak Assassin's Creed czy Far Cry. Trwają jednak prace nad odświeżoną wersją pierwszej części przyg&oacute;d agenta Sama Fishera, kt&oacute;ra może...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/splinter_cell_remake_otrzyma_zmodyfikowana_historie_dostosowana_do_wspolcznesnego_gracza-23452.html">https://

## G.Skill zapowiada nowe zestawy pamięci DDR5 Trident Z5 RGB. Jest szybko
 - [https://ithardware.pl/aktualnosci/g_skill_zapowiada_nowe_zestawy_pamieci_ddr5_trident_z5_rgb_jest_szybko-23451.html](https://ithardware.pl/aktualnosci/g_skill_zapowiada_nowe_zestawy_pamieci_ddr5_trident_z5_rgb_jest_szybko-23451.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 16:58:00+00:00

<img src="https://ithardware.pl/artykuly/min/23451_1.jpg" />            Marka G.Skill ogłasza dwa nowe zestawy podkręconych pamięci DDR5 z serii&nbsp;Trident Z5 RGB. W ofercie producenta znajdą się moduły DDR5-6800 CL32-45-45-108 32GB (2x16GB) oraz&nbsp;DDR5-6400 CL32-39-39-102 64GB (2x32GB). Kości są kompatybilne z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/g_skill_zapowiada_nowe_zestawy_pamieci_ddr5_trident_z5_rgb_jest_szybko-23451.html">https://ithardware

## Ethereum 2.0 - jak stakować i ile można zarobić?
 - [https://ithardware.pl/poradniki/ethereum_2_0_jak_stakowac_i_ile_mozna_zarobic-23445.html](https://ithardware.pl/poradniki/ethereum_2_0_jak_stakowac_i_ile_mozna_zarobic-23445.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 16:24:00+00:00

<img src="https://ithardware.pl/artykuly/min/23445_1.jpg" />            Stało się&hellip; Jedna z najpopularniejszych kryptowalut przechodzi na system Proof-of-stake. Przyjrzyjmy się Ethereum 2.0 temu, jak działa i jak aktualizacja wpłynie na rynek krypto i nie tylko.

Słowem wstępu od razu powitam wszystkich...
            <p>Pełna wersja strony <a href="https://ithardware.pl/poradniki/ethereum_2_0_jak_stakowac_i_ile_mozna_zarobic-23445.html">https://ithardware.pl/poradniki/ethereum_2_0_jak_sta

## Instagram pracuje nad zabezpieczeniem przeciw nagości w wiadomościach
 - [https://ithardware.pl/aktualnosci/instagram_pracuje_nad_zabezpieczeniem_przeciw_nagosci_w_wiadomosciach-23450.html](https://ithardware.pl/aktualnosci/instagram_pracuje_nad_zabezpieczeniem_przeciw_nagosci_w_wiadomosciach-23450.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 15:30:40+00:00

<img src="https://ithardware.pl/artykuly/min/23450_1.jpg" />            Instagram pracuje na ochroną przed nagością w wiadomościach. W tym celu opracowywane jest specjalne narzędzie, kt&oacute;re wprowadzi cenzurę niechcianych zdjęć. Opublikowany zrzut ekranu z wczesnych prac dostarcza informacji, że nowa funkcja...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/instagram_pracuje_nad_zabezpieczeniem_przeciw_nagosci_w_wiadomosciach-23450.html">https://ithardware.pl/

## Samsung aktualizuje smartfon, który zadebiutował ponad 7 lat temu
 - [https://ithardware.pl/aktualnosci/galaxy_s6_dostal_niespodziewana_aktualizacje_od_samsunga-23449.html](https://ithardware.pl/aktualnosci/galaxy_s6_dostal_niespodziewana_aktualizacje_od_samsunga-23449.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 15:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/23449_1.jpg" />            Samsung nieoczekiwanie wydaje aktualizacje do starszych modeli smartfon&oacute;w z serii Galaxy. Wcześniej był to Galaxy S8 z 2017 roku a teraz przyszła kolej na jeszcze starszą generację, Galaxy S6 z 2015 roku.

Od premiery Samsunga Galaxy S6...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/galaxy_s6_dostal_niespodziewana_aktualizacje_od_samsunga-23449.html">https://ithardware.pl/aktualnosci/

## Rozbił swój samochód... żeby sprawdzić nową funkcję iPhone 14 Pro
 - [https://ithardware.pl/aktualnosci/rozbil_swoj_samochod_zeby_sprawdzic_nowa_funkcje_iphone_14_pro-23448.html](https://ithardware.pl/aktualnosci/rozbil_swoj_samochod_zeby_sprawdzic_nowa_funkcje_iphone_14_pro-23448.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 14:35:00+00:00

<img src="https://ithardware.pl/artykuly/min/23448_1.jpg" />            Apple wprowadziło do swoich nowych urządzeń kilka przydatnych funkcji. Jedną z nich, Crash Detection, udało się nawet przetestować. Youtuber postanowił&nbsp;sprawdzić, czy iPhone faktycznie wykryje, że jego właściciel brał udział w wypadku...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rozbil_swoj_samochod_zeby_sprawdzic_nowa_funkcje_iphone_14_pro-23448.html">https://ithardware.pl/aktualnosc

## Asus przedstawia karty graficzne ROG Strix i TUF Gaming GeForce RTX 4000
 - [https://ithardware.pl/aktualnosci/asus_przedstawia_karty_graficzne_rog_strix_i_tuf_gaming_geforce_rtx_4000-23447.html](https://ithardware.pl/aktualnosci/asus_przedstawia_karty_graficzne_rog_strix_i_tuf_gaming_geforce_rtx_4000-23447.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 13:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/23447_1.jpg" />            Asus&nbsp;prezentuje nowe karty graficzne ROG Strix i TUF Gaming dysponujące od dawna oczekiwanymi procesorami graficznymi NVIDIA&nbsp;GeForce z serii RTX 4000 &ndash; zaczynając od najwyższej klasy modeli GeForce RTX 4090 24 GB, RTX 4080 16 GB i RTX...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/asus_przedstawia_karty_graficzne_rog_strix_i_tuf_gaming_geforce_rtx_4000-23447.html">https://ith

## Meta (Facebook) śledzi użytkowników iOS nawet bez ich zgody. Pozwy już są przygotowane
 - [https://ithardware.pl/aktualnosci/meta_facebook_sledzi_uzytkownikow_na_ios_bez_ich_zgody_pozwy_juz_sa_przygotowane-23446.html](https://ithardware.pl/aktualnosci/meta_facebook_sledzi_uzytkownikow_na_ios_bez_ich_zgody_pozwy_juz_sa_przygotowane-23446.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 12:55:50+00:00

<img src="https://ithardware.pl/artykuly/min/23446_1.jpg" />            Apple wprowadziło rygorystyczne zasady dotyczące śledzenia użytkownik&oacute;w przez aplikacje, co wywołało ogromny sprzeciw ze strony Facebooka. Gigant społecznościowy będzie musiał zmierzyć się teraz z kolejnymi pozwami, m.in. w związku z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/meta_facebook_sledzi_uzytkownikow_na_ios_bez_ich_zgody_pozwy_juz_sa_przygotowane-23446.html">https://ithar

## Colorful przygotował PC z GeForcem RTX 4090, na który stać każdego
 - [https://ithardware.pl/aktualnosci/colorful_przygotowal_pc_z_geforcem_rtx_4090_na_ktory_stac_kazdego-23440.html](https://ithardware.pl/aktualnosci/colorful_przygotowal_pc_z_geforcem_rtx_4090_na_ktory_stac_kazdego-23440.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 11:47:01+00:00

<img src="https://ithardware.pl/artykuly/min/23440_1.jpg" />            Jak donosi VideoCardz, już za 299 CNY (ok. 200 zł) w ramach przedsprzedaży (399 CNY/270 PLN w normalnej sprzedaży) fani Colorful mogą zam&oacute;wić w Chinach jedyny w swoim rodzaju komputer PC ze wszystkimi ważnymi komponentami wykonanymi z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/colorful_przygotowal_pc_z_geforcem_rtx_4090_na_ktory_stac_kazdego-23440.html">https://ithardware.pl/aktua

## NVIDIA RTX 6000 z pamięcią 48 GB i ogromną liczbą rdzeni CUDA. TDP za to niższe niż u RTX 4090
 - [https://ithardware.pl/aktualnosci/nvidia_rtx_6000_z_pamiecia_48_gb_i_ogromna_liczba_rdzeni_cuda_tdp_za_to_nizsze_niz_u_rtx_4090-23444.html](https://ithardware.pl/aktualnosci/nvidia_rtx_6000_z_pamiecia_48_gb_i_ogromna_liczba_rdzeni_cuda_tdp_za_to_nizsze_niz_u_rtx_4090-23444.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 11:46:50+00:00

<img src="https://ithardware.pl/artykuly/min/23444_1.jpg" />            Wraz z architekturą Ada Lovelace, Nvidia zaprezentowała nie tylko nowe karty GeForce RTX 4000, ale także profesjonalne modele RTX 6000. Wyposażone są one w 48 GB pamięci i przewyższają liczbę rdzeni CUDA nawet RTX 4090. Znajdziemy ich tu aż...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_rtx_6000_z_pamiecia_48_gb_i_ogromna_liczba_rdzeni_cuda_tdp_za_to_nizsze_niz_u_rtx_4090-23444.html">

## Największa na świecie instalacja do usuwania CO2 może pochłaniać 5 milionów ton rocznie
 - [https://ithardware.pl/aktualnosci/najwieksza_na_swiecie_instalacja_do_usuwania_co2_moze_pochlaniac_5_milionow_ton_rocznie-23443.html](https://ithardware.pl/aktualnosci/najwieksza_na_swiecie_instalacja_do_usuwania_co2_moze_pochlaniac_5_milionow_ton_rocznie-23443.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 10:58:50+00:00

<img src="https://ithardware.pl/artykuly/min/23443_1.jpg" />            CarbonCapture to&nbsp;kolejny projekt typu DAC (Direct Air Capture), kt&oacute;rego zadaniem jest wychwytywanie dwutlenku węgla z atmosfery i składowanie go pod ziemią.&nbsp;Tym razem będzie to obiekt w Wyoming w USA, kt&oacute;ry w końcowej fazie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/najwieksza_na_swiecie_instalacja_do_usuwania_co2_moze_pochlaniac_5_milionow_ton_rocznie-23443.html"

## OnePlus 11 Pro - poznaliśmy specyfikację nadchodzącego flagowca. Warto czekać?
 - [https://ithardware.pl/aktualnosci/oneplus_11_pro_poznalismy_specyfikacje_nadchodzacego_flagowca_warto_czekac-23439.html](https://ithardware.pl/aktualnosci/oneplus_11_pro_poznalismy_specyfikacje_nadchodzacego_flagowca_warto_czekac-23439.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 10:25:01+00:00

<img src="https://ithardware.pl/artykuly/min/23439_1.jpg" />            W zeszłym tygodniu do sieci wyciekły pierwsze rendery smartfona OnePlus 11 Pro. Teraz to samo źr&oacute;dło (OnLeaks) powraca ze specyfikacją urządzenia, więc wiemy już, czego możemy się spodziewać po kolejnym flagowcu chińskiej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/oneplus_11_pro_poznalismy_specyfikacje_nadchodzacego_flagowca_warto_czekac-23439.html">https://ithardware.pl/aktualnos

## Samsung może być kolejnym producentem, który wprowadzi awaryjne połączenia przez satelitę
 - [https://ithardware.pl/aktualnosci/samsung_moze_byc_kolejnym_producentem_ktory_wprowadzi_awaryjne_polaczenia_przez_satelite-23442.html](https://ithardware.pl/aktualnosci/samsung_moze_byc_kolejnym_producentem_ktory_wprowadzi_awaryjne_polaczenia_przez_satelite-23442.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 10:08:30+00:00

<img src="https://ithardware.pl/artykuly/min/23442_1.jpg" />            Według najnowszych pogłosek, Samsung może być następna firmą, kt&oacute;ra umożliwi posiadaczom swoich smartfon&oacute;w wysyłanie wiadomości SOS przez satelitę. M&oacute;wi się, że Koreańczycy będą chcieli dodać wspomnianą funkcję...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_moze_byc_kolejnym_producentem_ktory_wprowadzi_awaryjne_polaczenia_przez_satelite-23442.html">https://ithard

## AMD Ryzen 9 7950X otrzymuje ocenę 10/10 w recenzji Sisoftware
 - [https://ithardware.pl/aktualnosci/amd_ryzen_9_7950x_otrzymuje_ocene_10_10_w_recenzji_sisoftware-23437.html](https://ithardware.pl/aktualnosci/amd_ryzen_9_7950x_otrzymuje_ocene_10_10_w_recenzji_sisoftware-23437.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 09:13:01+00:00

<img src="https://ithardware.pl/artykuly/min/23437_1.jpg" />            Sisoftware, czyli deweloper odpowiedzialny za benchmark Sandra, wziął na tapet nadchodzącego flagowego Ryzena od AMD, czyli procesor Ryzen 9 7950X - CPU uzyskało najlepszą z możliwych ocen.&nbsp;

Na stronie Sisoftware można znaleźć...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_ryzen_9_7950x_otrzymuje_ocene_10_10_w_recenzji_sisoftware-23437.html">https://ithardware.pl/aktualnosci/amd_ry

## Nie dawaj kciuka w dół na YouTube... to i tak nie działa
 - [https://ithardware.pl/aktualnosci/nie_dawaj_kciuka_w_dol_na_youtubie_to_i_tak_nie_dziala-23441.html](https://ithardware.pl/aktualnosci/nie_dawaj_kciuka_w_dol_na_youtubie_to_i_tak_nie_dziala-23441.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 08:33:01+00:00

<img src="https://ithardware.pl/artykuly/min/23441_1.jpg" />            Mozilla, tw&oacute;rcy przeglądarki Firefox, postanowiła przyjrzeć się narzędziom do moderowania wideo YouTube i odkryła, że większość użytkownik&oacute;w największego serwisu wideo uważa, że ​​są one&hellip;...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nie_dawaj_kciuka_w_dol_na_youtubie_to_i_tak_nie_dziala-23441.html">https://ithardware.pl/aktualnosci/nie_dawaj_kciuka_w_dol_na_youtubie_to

## Twórcy cheatów do Destiny 2 oskarżają Bungie o zhakowanie ich systemów
 - [https://ithardware.pl/aktualnosci/tworcy_cheatow_do_destiny_2_oskarzaja_bungie_o_zhakowanie_ich_systemow-23438.html](https://ithardware.pl/aktualnosci/tworcy_cheatow_do_destiny_2_oskarzaja_bungie_o_zhakowanie_ich_systemow-23438.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 08:06:40+00:00

<img src="https://ithardware.pl/artykuly/min/23438_1.jpg" />            Bungie, tw&oacute;rcy Destiny 2, ostatnio postanowili p&oacute;jść na walkę z oszustami. Firma pozwała&nbsp;jednego użytkownika za oszukiwanie i groźby pod adresem pracownik&oacute;w studia, a także YouTubera, kt&oacute;ry wystosował prawie 100...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tworcy_cheatow_do_destiny_2_oskarzaja_bungie_o_zhakowanie_ich_systemow-23438.html">https://ithardware.

## Pożar magazynu energii Tesla Megapack. To kolejny taki przypadek
 - [https://ithardware.pl/aktualnosci/tesla_megapack_zapalil_sie_po_mniej_niz_6_miesiacach_uzytkowania_w_podstacji-23434.html](https://ithardware.pl/aktualnosci/tesla_megapack_zapalil_sie_po_mniej_niz_6_miesiacach_uzytkowania_w_podstacji-23434.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 07:28:10+00:00

<img src="https://ithardware.pl/artykuly/min/23434_1.jpg" />            Megapack, czyli&nbsp;akumulator&nbsp;Tesli wielkości kontenera, kt&oacute;ry wraz z innymi&nbsp;od 6 miesięcy funkcjonował&nbsp;w podstacji elektrycznej&nbsp;w Kalifornii, zapalił się przedwczoraj wczesnym rankiem.

Według lokalnych medi&oacute;w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tesla_megapack_zapalil_sie_po_mniej_niz_6_miesiacach_uzytkowania_w_podstacji-23434.html">https://ith

## Ryzen 9 7950X podkręcony do 5,8 GHz na wszystkich rdzeniach
 - [https://ithardware.pl/aktualnosci/ryzen_9_7950x_podkrecony_do_5_8_ghz_na_wszystkich_rdzeniach-23436.html](https://ithardware.pl/aktualnosci/ryzen_9_7950x_podkrecony_do_5_8_ghz_na_wszystkich_rdzeniach-23436.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 07:18:47+00:00

<img src="https://ithardware.pl/artykuly/min/23436_1.jpg" />            Kiedy AMD ogłosiło w sierpniu swoje procesory Ryzen 7000 bazujące na architekturze Zen 4, chwaliło się prędkością 5,7 GHz dla topowego 16-rdzeniowego modelu Ryzen 9 7950X. Co więcej, oczekuje się, że CPU przyspieszy do 5,85 GHz w trybie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ryzen_9_7950x_podkrecony_do_5_8_ghz_na_wszystkich_rdzeniach-23436.html">https://ithardware.pl/aktualnosci/ryze

## Logitech prezentuje swoją przenośną konsolę G Cloud. Cena nie zachęca
 - [https://ithardware.pl/aktualnosci/logitech_prezentuje_swoja_przenosna_konsole_g_cloud_cena_nie_zacheca-23435.html](https://ithardware.pl/aktualnosci/logitech_prezentuje_swoja_przenosna_konsole_g_cloud_cena_nie_zacheca-23435.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-22 06:06:50+00:00

<img src="https://ithardware.pl/artykuly/min/23435_1.jpg" />            Logitech od jakiegoś czasu zwiastuje handheld G Cloud i w końcu doczekaliśmy się pełnoprawnej prezentacji tej mobilnej konsoli do gier. Nie będzie ona jednak bezpośrednim konkurentem Steam Decka, ponieważ zamiast na mocne podzespoły wewnętrzne...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/logitech_prezentuje_swoja_przenosna_konsole_g_cloud_cena_nie_zacheca-23435.html">https://ithardware.pl/


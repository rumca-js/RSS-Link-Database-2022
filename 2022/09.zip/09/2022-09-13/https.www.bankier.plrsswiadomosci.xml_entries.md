# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Niemiecki Urząd statystyczny: tankowanie znacznie droższe niż w krajach sąsiednich
 - [https://www.bankier.pl/wiadomosc/Niemiecki-Urzad-statystyczny-tankowanie-znacznie-drozsze-niz-w-krajach-sasiednich-8405433.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niemiecki-Urzad-statystyczny-tankowanie-znacznie-drozsze-niz-w-krajach-sasiednich-8405433.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 23:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/e292cbf77d2fd7-948-568-0-65-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po wygaśnięciu rabatu paliwowego kierowcy na niemieckich stacjach benzynowych muszą płacić znacznie więcej niż kierowcy w krajach sąsiadujących z RFN - poinformował Federalny Urząd Statystyczny.</p>

## Wielkie rozczarowanie na Wall Street. Najgorsza sesja w tym roku
 - [https://www.bankier.pl/wiadomosc/Wielkie-rozczarowanie-na-Wall-Street-Najgorsza-sesja-w-tym-roku-8405416.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wielkie-rozczarowanie-na-Wall-Street-Najgorsza-sesja-w-tym-roku-8405416.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 21:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/8/d437464930930e-945-560-0-95-1739-1043.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zdecydowanie wyższy od oczekiwań odczyt inflacji CPI w
Stanach Zjednoczonych skutkował najsilniejszą w tym roku przeceną na
nowojorskich giełdach.</p>

## Media: USA rozważają dodatkowe sankcje na Chiny, by powstrzymać je od inwazji na Tajwan
 - [https://www.bankier.pl/wiadomosc/Media-USA-rozwazaja-dodatkowe-sankcje-na-Chiny-by-powstrzymac-je-od-inwazji-na-Tajwan-8405407.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-USA-rozwazaja-dodatkowe-sankcje-na-Chiny-by-powstrzymac-je-od-inwazji-na-Tajwan-8405407.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 20:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/e8a0fdd932f1f9-948-568-132-0-1699-1019.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stany Zjednoczone rozważają wdrożenie dodatkowego pakietu sankcji przeciwko Chinom, aby powstrzymać je od inwazji na Tajwan - informuje we wtorek Reuters. Zdaniem agencji Unia Europejska znalazła się pod dyplomatyczną presją Tajpej, aby zrobiła to samo.</p>

## Dodatek węglowy z poprawkami Senatu i komisji sejmowych. Co zmieniają?
 - [https://www.bankier.pl/wiadomosc/Dodatek-weglowy-z-poprawkami-Senatu-i-komisji-sejmowych-Co-zmieniaja-8405405.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dodatek-weglowy-z-poprawkami-Senatu-i-komisji-sejmowych-Co-zmieniaja-8405405.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 20:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/f/2254862c7efc4f-948-567-0-45-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejmowa komisja poparła we wtorek szereg poprawek Senatu - głównie redakcyjnych i precyzujących - do ustawy o wsparciu odbiorców ciepła. Nowe przepisy wprowadzają m.in. kolejne dodatki energetyczne dla ogrzewających się drewnem, LPG, czy olejem opałowym.</p>

## Dochody Rosji ze sprzedaży surowców energetycznych najniższe od 14 miesięcy
 - [https://www.bankier.pl/wiadomosc/Dochody-Rosji-ze-sprzedazy-surowcow-energetycznych-najnizsze-od-14-miesiecy-8405378.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dochody-Rosji-ze-sprzedazy-surowcow-energetycznych-najnizsze-od-14-miesiecy-8405378.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 19:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/76ac45858d5613-832-499-167-0-832-499.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dochody Rosji ze sprzedaży surowców energetycznych spadły w sierpniu do najniższego poziomu od 14 miesięcy - podał we wtorek Bloomberg. To skutek spadku cen rosyjskiej ropy z powodu zachodnich sankcji.</p>

## PGE Paliwa i Węglokoks już w 80 proc. wykonały plan importu węgla na ten rok
 - [https://www.bankier.pl/wiadomosc/PGE-Paliwa-i-Weglokoks-juz-w-80-proc-wykonaly-plan-importu-wegla-na-ten-rok-8405364.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PGE-Paliwa-i-Weglokoks-juz-w-80-proc-wykonaly-plan-importu-wegla-na-ten-rok-8405364.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 18:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/3/def5034987e17f-948-568-0-0-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PGE Paliwa i Węglokoks już w 80 proc.  wykonały decyzję  premiera dotyczącą tegorocznego importu węgla. Do Polski trafi 5 mln ton gotowego do spalania węgla -  zapewniła we wtorek  Minister Klimatu i Środowiska Anna Moskwa.</p>

## Prezes PiS zapowiada zaciskanie pasa w spółkach Skarbu Państwa. "Zamrozimy ceny prądu, zabronimy brania premii"
 - [https://www.bankier.pl/wiadomosc/Prezes-PiS-zapowiada-zaciskanie-pasa-w-spolkach-Skarby-Panstwa-Zamrozimy-ceny-pradu-zabronimy-brania-premii-8405345.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezes-PiS-zapowiada-zaciskanie-pasa-w-spolkach-Skarby-Panstwa-Zamrozimy-ceny-pradu-zabronimy-brania-premii-8405345.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 18:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/0/7d92a03fbe3978-948-568-0-110-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W tym roku zabronimy osobom kierującym spółkami Skarbu Państwa brania premii - zapowiedział we wtorek w Pruszkowie prezes PiS Jarosław Kaczyński. Zaznaczył, że będą też "inne zabiegi", ale stosowne decyzje ogłosi w najbliższych dniach premier Mateusz Morawiecki.</p>

## Twitter zatrudniał chińskiego szpiega. Zeznał były szef bezpieczeństwa firmy
 - [https://www.bankier.pl/wiadomosc/Twitter-zatrudnial-chinskiego-szpiega-Zeznal-byly-szef-bezpieczenstwa-firmy-8405344.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Twitter-zatrudnial-chinskiego-szpiega-Zeznal-byly-szef-bezpieczenstwa-firmy-8405344.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 17:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/f/da31c430f4f535-948-568-0-90-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zostaliśmy poinformowani przez służby, że na liście płac mamy agenta chińskiego wywiadu - powiedział we wtorek w Kongresie USA były szef bezpieczeństwa Twittera Peiter "Mudge" Zatko. Jak dodał, kierownictwo spółki lekceważyło sytuację, mimo że wcześniej wykryto, iż w firmie pr

## Skarb Państwa zamierza przejąć kopalnie Taurona za symboliczną złotówkę
 - [https://www.bankier.pl/wiadomosc/Tauron-otrzymal-od-Ministerstwa-Aktywow-Panstwowych-oferte-nabycia-Tauron-Wydobycie-za-1-zl-8405306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tauron-otrzymal-od-Ministerstwa-Aktywow-Panstwowych-oferte-nabycia-Tauron-Wydobycie-za-1-zl-8405306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 17:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/6d2b9f3ac738da-665-399-13-0-665-399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tauron otrzymał od Skarbu Państwa, reprezentowanego przez Ministerstwo Aktywów Państwowych ofertę nabycia 100 proc. udziałów Tauron Wydobycie za 1 zł - podała spółka w komunikacie.</p>

## Powrót do spadków na GPW. Szybka realizacja zysków
 - [https://www.bankier.pl/wiadomosc/Powrot-do-spadkow-na-GPW-Szybka-realizacja-zyskow-8405255.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powrot-do-spadkow-na-GPW-Szybka-realizacja-zyskow-8405255.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 15:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/4/3547ef30379763-948-568-43-227-3430-2058.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na giełdę znów powróciły spadki, po kilku dniach lepszego sentymentu. Z dobrych nastrojów inwestorzy wyszli po publikacji amerykańskich danych o inflacji. Dynamika przeceny świadczy o szybkiej realizacji zysków i powrotu do kontynuacji zniżek na indeksach w ramach kilkumiesi

## Hakerzy wykradli dane 115 tys. pasażerów linii TAP, która lata m.in. do Polski
 - [https://www.bankier.pl/wiadomosc/Hakerzy-wykradli-dane-115-tys-pasazerow-linii-TAP-ktora-lata-m-in-do-Polski-8405226.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hakerzy-wykradli-dane-115-tys-pasazerow-linii-TAP-ktora-lata-m-in-do-Polski-8405226.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 15:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/5/a4bd3bfcfa8eb2-948-568-10-250-4163-2498.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Hakerzy z grupy o nazwie Ragnar Locker ujawnili w internecie szczegółowe dane 115 tys. osób, które korzystały z usług największego portugalskiego przewoźnika spółki TAP. Od 2009 r. realizuje on loty pomiędzy Lizboną a Warszawą.</p>

## Fitch: Ceny paliw negatywnie wpłyną na EBITDA w segmentach wytwórczych Tauronu, Enea i PGE
 - [https://www.bankier.pl/wiadomosc/Ceny-paliw-negatywnie-wplyna-na-EBITDA-w-segmentach-wytworczych-Tauronu-Enea-i-PGE-Fitch-8405222.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-paliw-negatywnie-wplyna-na-EBITDA-w-segmentach-wytworczych-Tauronu-Enea-i-PGE-Fitch-8405222.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 15:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/0/b6555239186c46-945-567-41-18-1418-851.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wysokie ceny paliw negatywnie wpłyną na wynik EBITDA w 2022roku  w segmentach wytwórczych Tauronu, Enea i w mniejszym stopniu PGE Polskiej Grupy Energetycznej - ocenili analitycy Fitch Ratings.</p>

## Ukraina: pomimo sankcji niemieckie firmy wciąż współpracują z rosyjską zbrojeniówką
 - [https://www.bankier.pl/wiadomosc/Ukraina-pomimo-sankcji-niemieckie-firmy-wciaz-wspolpracuja-z-rosyjska-zbrojeniowka-8405218.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraina-pomimo-sankcji-niemieckie-firmy-wciaz-wspolpracuja-z-rosyjska-zbrojeniowka-8405218.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 15:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/3/dd4da45fdb6bab-948-568-0-25-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pomimo zachodnich sankcji niemieckie firmy Walter, Schunk i Kemmler działają w Rosji i dostarczają technologie, których Rosja potrzebuje do produkcji i serwisowania broni ofensywnej – pisze Euromaidan Press.</p>

## Branża wodno-kanalizacyjna może za chwilę przeżywać potężny kryzys
 - [https://www.bankier.pl/wiadomosc/Branza-wodno-kanalizacyjna-moze-za-chwile-przezywac-potezny-kryzys-8405205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Branza-wodno-kanalizacyjna-moze-za-chwile-przezywac-potezny-kryzys-8405205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 14:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/b4b0f196d8a938-948-568-0-70-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Branża wodno-kanalizacyjna może za chwilę przeżywać potężny kryzys; dyskutując z przedstawicielami Wód Polskich oraz ministerstwa infrastruktury szukamy rozwiązań dla poprawy systemu taryfikacyjnego, ale przede wszystkim dlatego, by system się nie załamał - powiedział poseł Mare

## NBP wprowadza do obiegu monetę kolekcjonerską "100-lecie Portu Gdynia"
 - [https://www.bankier.pl/wiadomosc/NBP-wprowadza-do-obiegu-monete-kolekcjonerska-100-lecie-Portu-Gdynia-8405194.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBP-wprowadza-do-obiegu-monete-kolekcjonerska-100-lecie-Portu-Gdynia-8405194.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 14:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/b/d5bacc2797f797-948-567-0-161-950-569.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />NBP wprowadza do obiegu srebrną monetę kolekcjonerską "100-lecie Portu Gdynia" o nominale 20 zł – podał bank centralny we wtorkowym komunikacie.</p>

## Lewiatan: proponowana przez rząd podwyżka płacy minimalnej w 2023 r. uderzy w przedsiębiorców i zatrudnienie
 - [https://www.bankier.pl/wiadomosc/Lewiatan-proponowana-przez-rzad-podwyzka-placy-minimalnej-w-2023-r-uderzy-w-przedsiebiorcow-i-zatrudnienie-8405190.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lewiatan-proponowana-przez-rzad-podwyzka-placy-minimalnej-w-2023-r-uderzy-w-przedsiebiorcow-i-zatrudnienie-8405190.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 14:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/d025a84c8084b4-948-568-1243-131-1156-693.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Proponowana przez rząd podwyżka płacy minimalnej w 2023 r. w warunkach galopującej inflacji i kryzysu energetycznego uderzy w przedsiębiorców i zatrudnienie – ocenia Jacek Męcina z Konfederacji Lewiatan decyzję rady ministrów o tym, że od 1 stycznia ma ona wynosić 3490 zł, 

## Citi Handlowy z silną ofertą lokat w USD 2,5% oraz PLN 7,5%
 - [https://www.bankier.pl/wiadomosc/Citi-Handlowy-z-silna-oferta-lokat-w-USD-2-5-oraz-PLN-7-5-8398098.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Citi-Handlowy-z-silna-oferta-lokat-w-USD-2-5-oraz-PLN-7-5-8398098.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 14:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/f/f0572dcba68f0a-948-568-243-0-3358-2015.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Citi Handlowy przygotował dla nowych klientów banku ciekawą propozycję. Ci, którzy spełnią warunki promocji „Citigold 7.5”, mogą skorzystać ze specjalnej oferty lokat terminowych. Warto zwrócić uwagę, że oprócz atrakcyjnego oprocentowania lokaty mają wysoki górny limit kwoty.

## ING BSK: w najbliższym czasie spodziewamy się dalszego pogłębiania deficytu w obrotach bieżących
 - [https://www.bankier.pl/wiadomosc/ING-BSK-w-najblizszym-czasie-spodziewamy-sie-dalszego-poglebiania-deficytu-w-obrotach-biezacych-8405174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ING-BSK-w-najblizszym-czasie-spodziewamy-sie-dalszego-poglebiania-deficytu-w-obrotach-biezacych-8405174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 14:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/ff479e772a4018-948-567-0-187-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W najbliższych miesiącach spodziewamy się dalszego stopniowego pogłębiania deficytu w obrotach bieżących do około 5 proc. PKB pod koniec roku – podano w komentarzu banku ING BSK do wtorkowych danych Narodowego Banku Polskiego.</p>

## PIE: wzrost wartości sprowadzanych paliw oznacza dodatkowy koszt rzędu 10 mld zł miesięcznie
 - [https://www.bankier.pl/wiadomosc/PIE-wzrost-wartosci-sprowadzanych-paliw-oznacza-dodatkowy-koszt-rzedu-10-mld-zl-miesiecznie-8405136.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PIE-wzrost-wartosci-sprowadzanych-paliw-oznacza-dodatkowy-koszt-rzedu-10-mld-zl-miesiecznie-8405136.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 13:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/7c153b2de74a32-948-568-26-248-3513-2108.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost cen surowców energetycznych zwiększa wartość importu. Wzrost wartości sprowadzanych paliw oznacza dodatkowy koszt rzędu 10 mld zł miesięcznie – podał Polski Instytut Ekonomiczny w komentarzu do danych NBP o deficycie na rachunku bieżącym.</p>

## Inflacja w USA zwolniła i równocześnie przyspieszyła
 - [https://www.bankier.pl/wiadomosc/Inflacja-w-USA-sierpien-2022-8405107.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-w-USA-sierpien-2022-8405107.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 13:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/d/110e6cc60a637b-948-568-310-270-3690-2213.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sierpniowe statystyki inflacji CPI pokazały drugi z rzędu
spadek rocznej dynamiki tego wskaźnika, lecz równocześnie wzrosła inflacja
bazowa.</p>

## Rząd przygotowuje pakiet rozwiązań pomocowych dla sektora energochłonnego. Premier: chcemy objąć ok. tysiąca firm
 - [https://www.bankier.pl/wiadomosc/Rzad-przygotowuje-pakiet-rozwiazan-pomocowych-dla-sektora-energochlonnego-Premier-chcemy-objac-ok-tysiaca-firm-8405119.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-przygotowuje-pakiet-rozwiazan-pomocowych-dla-sektora-energochlonnego-Premier-chcemy-objac-ok-tysiaca-firm-8405119.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 13:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/1d074e3e23e5d2-948-568-0-129-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pakietem rozwiązań pomocowych dla sektora energochłonnego chcemy objąć ok. tysiąca firm; na pewno 800-900 firm, które są najbardziej uzależnione od kosztów energii, gazu - powiedział we wtorek premier Mateusz Morawiecki.</p>

## MAP przedstawi program ws. zakupu i dostaw węgla dla klientów indywidualnych
 - [https://www.bankier.pl/wiadomosc/MAP-przedstawi-program-ws-zakupu-i-dostaw-wegla-dla-klientow-indywidualnych-8405108.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/MAP-przedstawi-program-ws-zakupu-i-dostaw-wegla-dla-klientow-indywidualnych-8405108.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 13:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/836ad5be90943a-948-567-0-2-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wkrótce resort aktywów państwowych ma przedstawić program dot. zakupu i dostaw węgla dla indywidualnych klientów - zapowiedział we wtorek premier Mateusz Morawiecki. Dodał, że rząd będzie chciał też skłonić sprzedających węgiel do obniżenia jego cen.</p>

## Projekt przesuwający wybory samorządowe wkrótce trafi pod obrady Sejmu
 - [https://www.bankier.pl/wiadomosc/Projekt-przesuwajacy-wybory-samorzadowe-wkrotce-trafi-pod-obrady-Sejmu-8405097.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Projekt-przesuwajacy-wybory-samorzadowe-wkrotce-trafi-pod-obrady-Sejmu-8405097.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 13:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/f/a8d3be8cbe5ead-945-560-35-5-2012-1207.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wybory parlamentarne odbędą się zgodnie z terminem, czyli w październiku lub listopadzie 2023 roku; wybory samorządowe - prawdopodobnie odbędą się w terminie późniejszym - powiedział we wtorek premier Mateusz Morawiecki. Dodał, że projektem ws. ich przesunięcia Sejm zajmie się

## Rząd ruszył z realizacją projektów z KPO
 - [https://www.bankier.pl/wiadomosc/Rzad-ruszyl-z-realizacja-projektow-z-KPO-8405096.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-ruszyl-z-realizacja-projektow-z-KPO-8405096.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 13:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/13c4c66d393d3a-948-568-9-0-3914-2348.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ruszyliśmy z realizacją projektów z KPO i będziemy je realizować niezależnie od tego, czy Komisja Europejska zapłaciła, czy nie; nie chcemy wstrzymywać ich realizacji; pieniądze z KPO prędzej czy później na pewno do nas wpłyną - oświadczył we wtorek premier Mateusz Morawiecki.<

## Norbert Kaczmarczyk odwołany. Solidarna Polska ma wybrać nowego wiceministra
 - [https://www.bankier.pl/wiadomosc/Norbert-Kaczmarczyk-odwolany-Solidarna-Polska-ma-wybrac-nowego-wiceministra-8405093.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Norbert-Kaczmarczyk-odwolany-Solidarna-Polska-ma-wybrac-nowego-wiceministra-8405093.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 13:11:00+00:00

<p>Premier Mateusz Morawiecki przekazał, że wpłynął do niego wniosek od wicepremiera, ministra rolnictwa Henryka Kowalczyka związany z rezygnacją, dymisją wiceministra rolnictwa Norberta Kaczmarczyka. Zgodnie z umową koalicyjną, Solidarna Polska ma prawo wskazać kandydata na wiceministra - dodał.</p>

## CPK będzie miał połączenie kolejowe z Ukrainą
 - [https://www.bankier.pl/wiadomosc/CPK-bedzie-mial-polaczenie-kolejowe-z-Ukraina-8405073.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/CPK-bedzie-mial-polaczenie-kolejowe-z-Ukraina-8405073.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 12:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/b/4d512431a410ac-948-568-20-105-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />100-km odcinek linii kolejowej Trawniki - Bełżec planowany w ramach budowy Centralnego Portu Komunikacyjnego zostanie wydłużony do granicy z Ukrainą. Jeszcze w tym roku nastąpi wybór wariantu inwestorskiego dla tzw. szprychy CPK nr 5 – poinformowali we wtorek przedstawiciele

## Drogie inwestowanie na giełdzie. Raport o kosztach związanych z GPW
 - [https://www.bankier.pl/wiadomosc/Drogie-inwestowanie-na-gieldzie-Raport-o-kosztach-zwiazanych-z-GPW-8405062.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Drogie-inwestowanie-na-gieldzie-Raport-o-kosztach-zwiazanych-z-GPW-8405062.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 12:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/d/7ba02d475eddc6-945-560-20-67-980-587.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo Finansów i Urząd Komisji Nadzoru Finansowego przedstawiły raport zawierający analizę poziomu kosztów ponoszonych przez inwestorów, na rynku kapitałowym w Polsce. Wynika z niego m.in., że polskie firmy inwestycyjne wypadają relatywnie drogo na tle globalnych konkure

## Minimalne wynagrodzenie w 2023 r. wyniesie 3490 zł, a stawka godzinowa - 22,80 zł
 - [https://www.bankier.pl/wiadomosc/Minimalne-wynagrodzenie-w-2023-r-wyniesie-3490-zl-a-stawka-godzinowa-22-80-zl-8405059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minimalne-wynagrodzenie-w-2023-r-wyniesie-3490-zl-a-stawka-godzinowa-22-80-zl-8405059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 12:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/c/5c832046f844ca-948-568-0-202-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada Ministrów przyjęła rozporządzenie w sprawie minimalnego wynagrodzenia za pracę w 2023 r. W przyszłym roku minimalne pensje wzrosną do 3490 zł, a minimalna stawka godzinowa wyniesie 22,80 zł – powiedział we wtorek premier Mateusz Morawiecki.</p>

## Finlandia nie może zamknąć granicy przed Rosjanami. "Odpowiedzialność zbiorowa jest nielegalna"
 - [https://www.bankier.pl/wiadomosc/Finlandia-nie-moze-zamknac-granicy-przed-Rosjanami-Odpowiedzialnosc-zbiorowa-jest-nielegalna-8405026.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Finlandia-nie-moze-zamknac-granicy-przed-Rosjanami-Odpowiedzialnosc-zbiorowa-jest-nielegalna-8405026.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 12:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/3/f871d0fc00d97c-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wprowadzenie zakazu wjazdu dla obywateli jednego kraju nie byłoby legalne. System rządów prawa „nie uznaje odpowiedzialności zbiorowej” (za działania rosyjskiego państwa) – tak szef służby konsularnej w fińskim MSZ Jussi Tanner, uzasadnił politykę Finlandii w sprawie wiz dla 

## Hołownia: rząd nie ma prawa mówić przedsiębiorcom "oszczędzajcie energię", jak sam nie zacznie jej oszczędzać
 - [https://www.bankier.pl/wiadomosc/Holownia-rzad-nie-ma-prawa-mowic-przedsiebiorcom-oszczedzajcie-energie-jak-sam-nie-zacznie-jej-oszczedzac-8405025.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Holownia-rzad-nie-ma-prawa-mowic-przedsiebiorcom-oszczedzajcie-energie-jak-sam-nie-zacznie-jej-oszczedzac-8405025.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 12:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/e/106b6cbcb2c0fa-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd nie ma prawa iść dzisiaj do przedsiębiorców i mówić: oszczędzajcie energię, jak sam nie zacznie tej energii oszczędzać - mówił we wtorek w Poznaniu lider Polski 2050 Szymon Hołownia. Polityk chce nałożenia na firmy energetyczne opłaty solidarnościowej.</p>

## Koszty uczestników polskich funduszy inwestycyjnych spadły, ale nadal należą do najwyższych w UE [raport]
 - [https://www.bankier.pl/wiadomosc/Koszty-uczestnikow-polskich-funduszy-inwestycyjnych-spadly-ale-nadal-naleza-do-najwyzszych-w-UE-raport-8405024.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koszty-uczestnikow-polskich-funduszy-inwestycyjnych-spadly-ale-nadal-naleza-do-najwyzszych-w-UE-raport-8405024.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 12:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/6/565350c9b19a1a-930-557-0-2-930-557.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Koszty ponoszone przez uczestników polskich funduszy inwestycyjnych wyraźnie spadły, ale nadal należą do najwyższych w Europie – wynika z raportu przygotowanego przez Ministerstwo Finansów i Komisję Nadzoru Finansowego.</p>

## PiS złożyło w Sejmie projekt uchwały ws. reparacji od Niemiec
 - [https://www.bankier.pl/wiadomosc/PiS-zlozylo-w-Sejmie-projekt-uchwaly-ws-reparacji-od-Niemiec-8405000.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PiS-zlozylo-w-Sejmie-projekt-uchwaly-ws-reparacji-od-Niemiec-8405000.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 11:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/9/b502bf9d046011-948-568-0-4-1600-959.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm RP oświadcza, że należycie reprezentowane państwo polskie nigdy nie zrzekło się roszczeń wobec państwa niemieckiego - głosi projekt uchwały ws. reparacji, który złożyła w Sejmie grupa posłow PiS. Projekt skierowano do pierwszego czytania w komisji spraw zagranicznych.</p>

## Reaktor w szwedzkiej elektrowni jądrowej nieczynny do stycznia, spowoduje to wzrost cen prądu
 - [https://www.bankier.pl/wiadomosc/Reaktor-w-szwedzkiej-elektrowni-jadrowej-nieczynny-do-stycznia-spowoduje-to-wzrost-cen-pradu-8404983.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Reaktor-w-szwedzkiej-elektrowni-jadrowej-nieczynny-do-stycznia-spowoduje-to-wzrost-cen-pradu-8404983.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 10:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/6/d77879c68ec671-948-568-0-220-3534-2120.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Naprawa nieczynnego od sierpnia z powodu awarii reaktora w elektrowni jądrowej Ringhals pod Goeteborgiem potrwa o dwa miesiące dłużej, do końca stycznia 2023 roku - poinformował we wtorek koncern Vattenfall. Przestój spowoduje wzrost cen prądu w południowej Szwecji.</p>

## Węglowy poker na GPW. Bumech szybko traci, CoalEnergy gwałtownie zyskuje
 - [https://www.bankier.pl/wiadomosc/Weglowy-poker-na-GPW-Bumech-szybko-traci-CoalEnergy-gwaltownie-zyskuje-8404949.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Weglowy-poker-na-GPW-Bumech-szybko-traci-CoalEnergy-gwaltownie-zyskuje-8404949.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 10:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/3/7e1ad27587cae7-948-567-0-2-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na GPW w tym tygodniu uwagę inwestorów skupiają 
spółki
węglowe. Bardzo dużo dzieje się, patrząc na dynamikę notowań, na akcjach
 Bumechu i CoalEnergy. W obu przypadkach sentyment zmienił się nagle i 
bez jednoznacznego
powodu.</p>

## Xiaomi kontra Apple. "Unikalna" funkcja iPhone'a 14 wykorzystana przez chińskiego producenta
 - [https://www.bankier.pl/wiadomosc/Xiaomi-kontra-Apple-Unikalna-funkcja-iPhone-a-14-wykorzystana-przez-chinskiego-producenta-8404957.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Xiaomi-kontra-Apple-Unikalna-funkcja-iPhone-a-14-wykorzystana-przez-chinskiego-producenta-8404957.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 10:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/9/2d51bfb6acefb3-948-568-12-38-2552-1531.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeszcze przed oficjalną premierą nowego modelu iPhone’a stracił on swoją unikalną funkcję. Ta zdążyła już zadebiutować na telefonach konkurencyjnego systemu Android.</p>

## Wysokość zarobków kluczowa przy szukaniu pracy, jednak nie dla młodszych pracowników
 - [https://www.bankier.pl/wiadomosc/Wysokosc-zarobkow-kluczowa-przy-szukaniu-pracy-jednak-nie-dla-mlodszych-pracownikow-8404954.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wysokosc-zarobkow-kluczowa-przy-szukaniu-pracy-jednak-nie-dla-mlodszych-pracownikow-8404954.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 10:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/27d35629620dc0-948-568-0-52-2350-1409.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dla 78 proc. badanych Polaków wysokość zarobków jest kluczowa przy wyborze pracy – wynika z badań Pracuj.pl. Dodano, że dla najmłodszych pracowników wchodzących na rynek wynagrodzenie nie jest tak istotne przy wyborze oferty, jak dla pozostałych grup wiekowych.</p>

## Koniec pobierania filmów z Chomikuj.pl. Sąd Najwyższy wydał przełomowy wyrok
 - [https://www.bankier.pl/wiadomosc/Koniec-pobierania-filmow-z-Chomikuj-pl-Sad-wydal-przelomowy-wyrok-8404884.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-pobierania-filmow-z-Chomikuj-pl-Sad-wydal-przelomowy-wyrok-8404884.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 10:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/d56f4ad0246ba5-948-568-0-174-2592-1555.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chomikuj.pl jest „bezpośrednim naruszycielem praw autorskich”. Wyrok Sądu Najwyższego wskazuje, że "platformy udostępniające nielegalne treści swoich użytkowników będą pociągane do odpowiedzialności". Z serwisu znikną lub zostaną zablokowane nielegalnie udostępniane materiały

## Polski producent dżemów i wódki znów podniesie ceny. Koszty niszczą rentowność
 - [https://www.bankier.pl/wiadomosc/Maspex-znow-podniesie-ceny-Koszty-niszcza-rentownosc-8404913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Maspex-znow-podniesie-ceny-Koszty-niszcza-rentownosc-8404913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/5/805fe016162477-945-567-26-32-2578-1547.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Maspex planuje pod koniec 2022 r. kolejną podwyżkę cen o kilkanaście procent - poinformował PAP Biznes Krzysztof Pawiński, prezes producenta soków, dżemów, makaronów i alkoholu. Koncern i cała branża spożywcza borykają się z ogromnym wzrostem kosztów energii i surowców, co zn

## Polska wydała ok. 2,2 tys. zł na każdego uchodźcę z Ukrainy
 - [https://www.bankier.pl/wiadomosc/Polska-wydala-ok-2-2-tys-zl-na-kazdego-uchodzce-z-Ukrainy-8404898.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-wydala-ok-2-2-tys-zl-na-kazdego-uchodzce-z-Ukrainy-8404898.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 09:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/de33b032ef1679-948-568-0-35-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szacuje się, że do tej pory Polska wydała na każdego uchodźcę z Ukrainy mniej więcej 2,2 tys. zł - poinformowała minister w KPRM Agnieszka Ścigaj, odnosząc się do kosztów pomocy uchodźcom wojennym z Ukrainy. Dodała, że od 24 lutego do Polski przyjechało i zostało 1,3 mln Ukrai

## Frank coraz droższy. Kurs euro nie zszedł poniżej 4,70 zł
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-nie-zszedl-ponizej-4-70-zl-8404886.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-nie-zszedl-ponizej-4-70-zl-8404886.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 08:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/c/32be852bf8e4a3-905-543-80-0-905-543.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Fiaskiem zakończyła się kolejna próba zejścia przez kurs
euro poniżej linii 4,70 zł.</p>

## Czarnek: Nie ma ryzyka, że szkoły będą zamykane ze względu na problemy z ogrzewaniem
 - [https://www.bankier.pl/wiadomosc/Czarnek-Nie-ma-ryzyka-ze-szkoly-beda-zamykane-ze-wzgledu-na-problemy-z-ogrzewaniem-8404880.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czarnek-Nie-ma-ryzyka-ze-szkoly-beda-zamykane-ze-wzgledu-na-problemy-z-ogrzewaniem-8404880.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 08:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/431f56f43fd45a-948-568-0-26-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Uważam, że nie ma takiego ryzyka, że szkoły będą zamykane ze względu na problemy z ogrzewaniem. Przekazaliśmy samorządom 13,7 mld zł, które mogą przeznaczyć na ogrzewanie szkół – powiedział we wtorek w Radiu Zet minister edukacji i nauki Przemysław Czarnek.</p>

## Podwyżki wynagrodzeń dla nauczycieli akademickich od 1 października. W 2023 roku kolejne
 - [https://www.bankier.pl/wiadomosc/Podwyzki-wynagrodzen-dla-nauczycieli-akademickich-od-1-pazdziernika-W-2023-roku-kolejne-8404878.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podwyzki-wynagrodzen-dla-nauczycieli-akademickich-od-1-pazdziernika-W-2023-roku-kolejne-8404878.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 08:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/8/640389cb2ffbd7-945-560-0-67-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 1 października wynagrodzenia dla nauczycieli akademickich wzrosną o kilkaset złotych, a od przyszłego roku o kolejne 7,8 proc. Łącznie będzie to ok. 12-13 proc. podwyżki – powiedział we wtorek w Radiu Zet minister edukacji i nauki Przemysław Czarnek.</p>

## Klienci PKO i BNP ponownie na celowniku oszustów
 - [https://www.bankier.pl/wiadomosc/PKO-Bank-Polski-i-BNP-Paribas-ostrzegaja-przed-oszustami-8404836.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKO-Bank-Polski-i-BNP-Paribas-ostrzegaja-przed-oszustami-8404836.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 08:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/4/005378443ee715-948-568-207-0-1765-1059.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PKO Bank Polski i BNP Paribas znów ostrzegają przed 
oszustami. W jednym wariancie przestępcy wysyłają fałszywe wiadomości z 
polisą, w rzeczywistości załączniki zawierają szkodliwe oprogramowanie. 
Otwarcie plików może skutkować utratą kontroli nad kontem i stratą 
pieniędzy

## Władze Chin cenzurują opisy lockdownu w Sinciangu; każą mediom pokazywać uśmiechniętych seniorów
 - [https://www.bankier.pl/wiadomosc/Wladze-Chin-cenzuruja-opisy-lockdownu-w-Sinciangu-kaza-mediom-pokazywac-usmiechnietych-seniorow-8404863.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wladze-Chin-cenzuruja-opisy-lockdownu-w-Sinciangu-kaza-mediom-pokazywac-usmiechnietych-seniorow-8404863.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 08:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/b/cd771e35d2f9e8-948-568-0-0-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chińskie władze cenzurują skargi mieszkańców prefektury Ili w Sinciangu na niedobory żywności i trwający od ponad miesiąca lockdown. Każą mediom pokazywać „uśmiechniętych seniorów na spacerach” – wynika z wytycznych, do których dotarł portal China Digital Times (CDT).</p>

## Polska elektrownia jądrowa do 2033 roku? Minister Moskwa: To realistyczne
 - [https://www.bankier.pl/wiadomosc/Elektrownia-jadrowa-do-2033-r-Min-Moskwa-To-realistyczne-8404861.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Elektrownia-jadrowa-do-2033-r-Min-Moskwa-To-realistyczne-8404861.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 08:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/7/d01c9f0ba2d7e5-948-568-0-22-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ciągle jest realistyczny rok 2033, jeśli chodzi o powstanie w Polsce elektrowni atomowej, jak również realistyczny jest rok 2026 jako moment rozpoczęcia jej budowy - powiedziała we wtorek minister klimatu i środowiska Anna Moskwa.</p>

## Ostatnie miesiące pod znakiem podwyżek pensji. To był dobry kwartał dla pracowników
 - [https://www.bankier.pl/wiadomosc/Ostatnie-miesiace-pod-znakiem-podwyzek-pensji-To-byl-dobry-kwartal-dla-pracownikow-8404845.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ostatnie-miesiace-pod-znakiem-podwyzek-pensji-To-byl-dobry-kwartal-dla-pracownikow-8404845.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 07:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/6/61e1a7c101de9e-948-568-22-315-4477-2686.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />49 proc. badanych otrzymało w ciągu ostatniego kwartału podwyżkę wynagrodzenia - wynika z raportu przeprowadzonego na zlecenie GI Group (d. Work Service).</p>

## Ceny miedzi w górę. Evergrande "odmrozi" inwestycje w Chinach
 - [https://www.bankier.pl/wiadomosc/Ceny-miedzi-w-gore-Evergrande-odmrozi-inwestycje-w-Chinach-8404856.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-miedzi-w-gore-Evergrande-odmrozi-inwestycje-w-Chinach-8404856.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 07:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/9/4600a86442b914-945-560-0-50-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny miedzi na giełdzie metali w Londynie rosną w 
reakcji na informacje o "odmrażaniu" w Chinach inwestycji prowadzonych 
przez spółkę deweloperską China Evergrande Group. Metal w dostawach 
3-miesięcznych na LME jest wyceniany wyżej wobec 7 956,00 USD za tonę 
notowanych na z

## Nadchodzi ochłodzenia nastrojów rekrutacyjnych firm. Te branże nadal będą zatrudniać
 - [https://www.bankier.pl/wiadomosc/Nadchodzi-ochlodzenia-nastrojow-rekrutacyjnych-firm-Te-branze-nadal-beda-zatrudniac-8404833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nadchodzi-ochlodzenia-nastrojow-rekrutacyjnych-firm-Te-branze-nadal-beda-zatrudniac-8404833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 07:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/0/3d9b596c542f56-948-568-171-0-990-594.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />24 proc. polskich firm chce zwiększyć zatrudnienie w ostatnim kwartale tego roku, tyle samo planuje redukcję etatów - wynika z raportu ManpowerGroup. Jak skomentowali autorzy raportu, najbliższe miesiące będą okresem stabilizacji na rynku pracy.</p>

## Huczne i drogie wesele wiceministra. Norbert Kaczmarczyk zdymisjonowany
 - [https://www.bankier.pl/wiadomosc/Huczne-i-drogie-wesele-wiceministra-Norbert-Kaczmarczyk-zdymisjonowany-8404831.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Huczne-i-drogie-wesele-wiceministra-Norbert-Kaczmarczyk-zdymisjonowany-8404831.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/c/23a14e61536b1a-948-568-0-0-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydium komitetu politycznego PiS zdecydowało, że musi nastąpić dymisja wiceministra rolnictwa i rozwoju wsi Norberta Kaczmarczyka - poinformował we wtorek wicemarszałek Sejmu i szef klubu PiS Ryszard Terlecki. Dodał, że koalicjant będzie mógł uzupełnić ten wakat w rządzie sw

## Umowa kredytu bez przejrzystego mechanizmu wymiany waluty. Skarga PG ws. umowy "frankowej"
 - [https://www.bankier.pl/wiadomosc/Umowa-kredytu-bez-przejrzystego-mechanizmu-wymiany-waluty-Skarga-PG-ws-umowy-frankowej-8404830.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Umowa-kredytu-bez-przejrzystego-mechanizmu-wymiany-waluty-Skarga-PG-ws-umowy-frankowej-8404830.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 06:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/3/f227252cd1f229-948-568-22-37-977-586.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zapisy umowy kredytowej nie odwołały się do ustalonego obiektywnie kursu franka szwajcarskiego, umowa nie zawierała przejrzystego mechanizmu wymiany waluty - wskazał Prokurator Generalny w skardze nadzwyczajnej w sprawie "frankowicza", wobec którego trwa już postępowanie egzeku

## Australia wprowadzi do obiegu monety z wizerunkiem króla Karola III od 2023 roku
 - [https://www.bankier.pl/wiadomosc/Australia-wprowadzi-do-obiegu-monety-z-wizerunkiem-krola-Karola-III-od-2023-roku-8404823.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Australia-wprowadzi-do-obiegu-monety-z-wizerunkiem-krola-Karola-III-od-2023-roku-8404823.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 06:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/5/612a04ac93a166-948-568-0-0-1820-1091.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Australijska mennica królewska od 2023 r. będzie biła monety z wizerunkiem nowego króla Karola III, zamiast ze zmarłą królową Elżbietą II - ogłosił we wtorek wiceminister skarbu Andrew Leigh. Wizerunek króla nie pojawi się automatycznie na banknocie pięciodolarowym, na którym o

## Drogo, coraz drożej. Polacy oszczędzają na zakupach, częściej kupują na promocjach
 - [https://www.bankier.pl/wiadomosc/Drogo-coraz-drozej-Polacy-oszczedzaja-na-zakupach-czesciej-kupuja-na-promocjach-8404811.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Drogo-coraz-drozej-Polacy-oszczedzaja-na-zakupach-czesciej-kupuja-na-promocjach-8404811.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 05:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/1963b4393d61e2-948-568-0-51-1730-1037.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tylko 16 proc. kupujących nie ograniczyło wydatków na podstawowe kategorie. Pozostali szukają promocji, a z niektórych produktów po prostu rezygnują - czytamy we wtorkowym wydaniu "Rzeczpospolitej".</p>

## Powstanie film o Lechu Kaczyńskim. "Prometeusz polski" z dużym dofinansowaniem
 - [https://www.bankier.pl/wiadomosc/Powstanie-film-o-Lechu-Kaczynskim-Prometeusz-polski-z-duzym-dofinansowaniem-8404808.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powstanie-film-o-Lechu-Kaczynskim-Prometeusz-polski-z-duzym-dofinansowaniem-8404808.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 05:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/d/50a7dec2eacc1d-948-568-0-76-3826-2295.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo Kultury i Dziedzictwa Narodowego dofinansowało film o „roli śp. prezydenta Lecha Kaczyńskiego w dziejach współczesnej Polski i Gruzji” - czytamy we wtorkowym wydaniu "Rzeczpospolitej", która informuje o filmie pt. "Prometeusz polski. Lech Kaczyński i Gruzja".</p>

## Ekwiwalent za niewykorzystany urlop. Kiedy przysługuje i ile można dostać? Podpowiadamy
 - [https://www.bankier.pl/wiadomosc/Ekwiwalent-za-urlop-wypoczynkowy-Ile-i-jak-obliczyc-ekwiwalent-8401949.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekwiwalent-za-urlop-wypoczynkowy-Ile-i-jak-obliczyc-ekwiwalent-8401949.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/6496ac3717dbc1-948-568-0-119-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ekwiwalent za urlop wypoczynkowy należy się pracownikowi w przypadku 
niewykorzystania przysługującego wolnego w całości lub części. Jest on 
wypłacany wyłącznie w sytuacji, gdy stosunek pracy zakończył się z 
powodu rozwiązania umowy lub wygasł.</p>

## Ma być szybciej, taniej i bardziej ekologicznie. Zbliża się najważniejszy dzień dla kryptowalut w 2022 roku
 - [https://www.bankier.pl/wiadomosc/Najwazniejszy-dzien-dla-kryptowalut-w-2022-roku-8404537.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najwazniejszy-dzien-dla-kryptowalut-w-2022-roku-8404537.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/c/2aa455586e4fc6-948-568-0-286-4240-2543.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nadszedł najbardziej wyczekiwany moment dla świata kryptowalut w 2022 r. Drugi pod względem kapitalizacji ethereum (ETH) zmienia sposób zatwierdzania transakcji. Ma być szybciej, taniej, a przez to bardziej ekologicznie.</p>

## Podwyżka „zjadła” korektę. Ceny działek rosną po przerwie [Nowy raport]
 - [https://www.bankier.pl/wiadomosc/Ceny-transakcyjne-dzialek-budowlanych-II-kw-2022-r-Raport-8404470.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-transakcyjne-dzialek-budowlanych-II-kw-2022-r-Raport-8404470.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/3/c6d82dd7119d95-948-568-0-0-1979-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podobnie jak na rynku sprzedaży mieszkań również 
średnie kwoty płacone za działki budowlane w II kw. 2022 r. wzrosły 
względem pierwszych trzech miesięcy roku. Zanotowane podwyżki 
„skonsumowały” tym samym obniżki mające miejsce trzy miesiące wcześniej.</p>

## Ranking lokat kwartalnych. Banki kuszą stawkami do 8 proc. rocznie
 - [https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-3-miesiace-wrzesien-2022-Ranking-Bankier-pl-8404494.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-3-miesiace-wrzesien-2022-Ranking-Bankier-pl-8404494.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/4/490b0c8d9bf40d-948-568-0-288-2304-1382.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />8 proc. w skali roku to obecnie maksymalna stawka dostępna na lokacie terminowej. Oferty z tym oprocentowaniem można policzyć na palcach jednej ręki. Jedną z nich jest lokata kwartalna dostępna po założeniu rachunku depozytowego.</p>

## Sony Music wycofuje się z Rosji z powodu wojny w Ukrainie
 - [https://www.bankier.pl/wiadomosc/Sony-Music-wycofuje-sie-z-Rosji-z-powodu-wojny-na-Ukrainie-8404784.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sony-Music-wycofuje-sie-z-Rosji-z-powodu-wojny-na-Ukrainie-8404784.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 04:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/c/6babffc4fe8a92-948-568-0-195-3008-1804.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wytwórnia Sony Music rezygnuje z prowadzenia działalności w Rosji z powodu inwazji na Ukrainę - poinformowała we wtorek agencja Rutera, cytując komunikat firmy.</p>

## Zełenski: Odzyskaliśmy 6000 km kwadratowych terytorium
 - [https://www.bankier.pl/wiadomosc/Zelenski-Odzyskalismy-6000-km-kwadratowych-terytorium-8404772.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zelenski-Odzyskalismy-6000-km-kwadratowych-terytorium-8404772.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 01:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/e389ae08c51f9d-948-568-8-57-1764-1058.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Ukrainy Wołodymyr Zełenski w poniedziałek wieczorem w swoim cyklicznym wystąpieniu w mediach społecznościowych oświadczył, że wojska ukraińskie od początku miesiąca odzyskały 6 000 km kwadratowych terytorium zajmowanego przez Rosję.</p>

## Macierewicz ukrył część dowodów ws. katastrofy smoleńskiej? Dotarli do nich dziennikarze
 - [https://www.bankier.pl/wiadomosc/Macierewicz-ukryl-czesc-dowodow-ws-katastrofy-smolenskiej-Dotarli-do-nich-dziennikarze-8404771.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Macierewicz-ukryl-czesc-dowodow-ws-katastrofy-smolenskiej-Dotarli-do-nich-dziennikarze-8404771.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-09-13 00:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/4/e3e76bbd981d02-948-568-0-45-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zarzuty i pseudoargumenty przedstawione przez stację TVN są fałszywe i prezentują rosyjski punt widzenia, wprowadzając w błąd polską opinię publiczną - czytamy w przesłanym PAP oświadczeniu Podkomisji ds. Ponownego Zbadania Wypadku Lotniczego w związku z emisją programu "Czarn


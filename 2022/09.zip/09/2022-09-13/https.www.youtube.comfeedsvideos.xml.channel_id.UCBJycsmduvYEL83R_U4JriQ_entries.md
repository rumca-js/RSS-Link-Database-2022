# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## iPhone 14 Pro Review: This Will Be Copied!
 - [https://www.youtube.com/watch?v=SdLShOCvVeM](https://www.youtube.com/watch?v=SdLShOCvVeM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-09-14 00:00:00+00:00

iPhone 14 Pro and iPhone 14 Pro Max have 3 main new things. My honest thoughts!

New Chevron Hoodie! http://shop.MKBHD.com

Bring new life to your smartphone with iFixit at https://ifixit.com/MKBHD and check out the iPhone 14 Pro teardown at https://ifix.gd/teardownvideos

Skin your iPhone at https://dbrand.com/shop/iphone-14
Get an iPhone 14 Pro at https://geni.us/VO4z4
Get an iPhone 14 Pro Max at https://geni.us/CigazCO
Get an iPhone 13 Pro at https://geni.us/VO4z4
Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

0:00 Intro!
1:28 Internals
5:27 Display
13:33 Cameras
19:41 My Take


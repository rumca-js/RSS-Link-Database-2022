# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This Is So Embarrassing! - Building a PC with My Sister
 - [https://www.youtube.com/watch?v=AOdp09SYhCc](https://www.youtube.com/watch?v=AOdp09SYhCc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-09-14 00:00:00+00:00

Check out Corsair's new K70 Pro Mini Wireless Keyboard at https://lmg.gg/K70ProMiniLTT

Save 10% and Free Worldwide Shipping at Ridge Wallet by using offer code LINUS at https://www.ridge.com/LINUS

Linus' sister is playing The Sims 4 on an old Macbook. He'd like to change that and see if she can be converted to the glorious ways of the mighty PC, but it comes at the cost of some embarrassing childhood stories.

Discuss on the forum: https://linustechtips.com/topic/1455257-this-is-so-embarrassing/

Buy an RTX 3060 Ti: https://geni.us/AnUl0L

Buy an MSI Pro Z690 A WiFi: https://geni.us/Cqmdts

Buy a Core i5 12400: https://geni.us/7Mn6

Buy a Crucial P5+ 1TB: https://geni.us/VuMHnuG

Buy a G.Skill Ripjaws V 2x8GB 3600MHz CL18: https://geni.us/200UOC

Buy a Noctua NH U12S: https://geni.us/tWdjLS

Buy Fractal Pop Air: https://geni.us/cH9T9

Buy a RM750X Gold: https://geni.us/Y9HOh

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:02 The Deal
2:05 Stories
4:30 Motherboard
5:25 CPU
7:22 More Stories
10:05 Linus the Troublemaker
12:34 GPU
14:00 Boot
14:55 Conclusion
17:33 Outro

## This $69 Gaming PC is INCREDIBLE
 - [https://www.youtube.com/watch?v=xTAzwKiQ7Ns](https://www.youtube.com/watch?v=xTAzwKiQ7Ns)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-09-13 00:00:00+00:00

A portion of this video was sponsored by IBM. Want to learn more? Check out IBM’s YouTube channel or New Creators homepage: https://ibm.co/3QtW6wD

Our last $69 gaming PC from 2018 was a pretty good machine for the budget. Will we be able to beat it in 2022? Watch to find out!

Discuss on the forum: https://linustechtips.com/topic/1455063-this-69-gaming-pc-is-incredible/

Buy an AData SU635: https://geni.us/JQ5f
Buy an AData SU760: https://geni.us/wvJHE

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:48 A new challenger - HP Z420
2:20 Looking inside the Z420
5:40 Availability and more options
7:55 A GPU and storage for $25?
9:40 GPU secured!
10:35 Storage for $2.07?
12:05 Step 1 Sell old GPU. Step 2 cha-ching!
12:54 Booting up the $69 PC
13:36 Benchmarking games
16:19 Conclusion
16:53 Outro


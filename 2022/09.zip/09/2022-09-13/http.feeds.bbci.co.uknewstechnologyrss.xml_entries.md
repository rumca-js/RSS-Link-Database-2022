# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Ethereum Merge: How one big cryptocurrency is going green
 - [https://www.bbc.co.uk/news/technology-62891715?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62891715?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-09-13 23:26:31+00:00

Ethereum, which currently uses as much energy as a medium-sized country, is to halt cryptomining.

## Google faces €25bn legal action in UK and the EU
 - [https://www.bbc.co.uk/news/technology-62891769?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62891769?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-09-13 17:04:43+00:00

Publishers should be compensated over Google's 'anti-competitive' digital ad practices, say lawyers.

## Twitter misleading the public, whistleblower says
 - [https://www.bbc.co.uk/news/technology-62889754?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62889754?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-09-13 15:40:30+00:00

Twitter's former head of security Peiter Zatko has been giving evidence to US lawmakers.


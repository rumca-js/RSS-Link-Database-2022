# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Californians Move to Texas | Episode 1: Moving Day
 - [https://www.youtube.com/watch?v=HlDWzN6TW5Y](https://www.youtube.com/watch?v=HlDWzN6TW5Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-09-13 00:00:00+00:00

This couple left California due to the cost of living, crime, taxes, etc. etc. etc. But now they're not so sure they can get used to living in Texas!

Subscribe to Chandler's Youtube: https://www.youtube.com/chandlerjuliet

Subscribe to our new podcast channel: https://www.youtube.com/thebabylonbeepodcast

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


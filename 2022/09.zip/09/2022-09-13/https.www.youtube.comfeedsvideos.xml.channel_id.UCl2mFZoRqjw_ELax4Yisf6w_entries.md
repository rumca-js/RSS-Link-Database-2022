# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## NYC apartment with flooding, rats, and roaches gets $800 rent hike
 - [https://www.youtube.com/watch?v=sDC62kMs3rM](https://www.youtube.com/watch?v=sDC62kMs3rM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-09-13 00:00:00+00:00

https://gitlab.futo.org/eron/public/-/wikis/FUTO-Social-Media-Plan

https://www.dexerto.com/entertainment/tiktoker-mortified-after-nyc-landlord-raises-rat-infested-apartment-rent-by-800-1926239/

https://www.youtube.com/watch?v=5pJ0A46hk_k


# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## D'banj - Cover Me (Live on KEXP)
 - [https://www.youtube.com/watch?v=uVkBfw0REGM](https://www.youtube.com/watch?v=uVkBfw0REGM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-09-14 00:00:00+00:00

http://KEXP.ORG presents D’banj performing “Cover Me” live in the KEXP studio. Recorded August 15, 2022.

D’banj - Vocals
Babafemi Oluwagbeminiyi Kuti - Sax
Olaitan Jeremiah Adebowale - Keyboards
Oluwatobi Olalekan Alapo - Drums
Alfred Mukum - DJ / Producer

Host: Lace Cadence
Audio Engineer: Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://iamdbanj.live
http://kexp.org

## D'banj - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=PvYmzh-JEF8](https://www.youtube.com/watch?v=PvYmzh-JEF8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-09-14 00:00:00+00:00

http://KEXP.ORG presents D’banj performing live in the KEXP studio. Recorded August 15, 2022.

Songs:
Stress Free
Cover Me
Oliver Twist
Welcome To Lagos

D’banj - Vocals
Babafemi Oluwagbeminiyi Kuti - Sax
Olaitan Jeremiah Adebowale - Keyboards
Oluwatobi Olalekan Alapo - Drums
Alfred Mukum - DJ / Producer

Host: Lace Cadence
Audio Engineer: Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://iamdbanj.live
http://kexp.org

## D'banj - Oliver Twist (Live on KEXP)
 - [https://www.youtube.com/watch?v=FG9bwmMa7R8](https://www.youtube.com/watch?v=FG9bwmMa7R8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-09-14 00:00:00+00:00

http://KEXP.ORG presents D’banj performing “Oliver Twist” live in the KEXP studio. Recorded August 15, 2022.

D’banj - Vocals
Babafemi Oluwagbeminiyi Kuti - Sax
Olaitan Jeremiah Adebowale - Keyboards
Oluwatobi Olalekan Alapo - Drums
Alfred Mukum - DJ / Producer

Host: Lace Cadence
Audio Engineer: Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://iamdbanj.live
http://kexp.org

## D'banj - Stress Free (Live on KEXP)
 - [https://www.youtube.com/watch?v=XEm3CdSe6V8](https://www.youtube.com/watch?v=XEm3CdSe6V8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-09-14 00:00:00+00:00

http://KEXP.ORG presents D’banj performing “Stress Free” live in the KEXP studio. Recorded August 15, 2022.

D’banj - Vocals
Babafemi Oluwagbeminiyi Kuti - Sax
Olaitan Jeremiah Adebowale - Keyboards
Oluwatobi Olalekan Alapo - Drums
Alfred Mukum - DJ / Producer

Host: Lace Cadence
Audio Engineer: Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://iamdbanj.live
http://kexp.org

## D'banj - Welcome To Lagos (Live on KEXP)
 - [https://www.youtube.com/watch?v=0UVEjP95ra4](https://www.youtube.com/watch?v=0UVEjP95ra4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-09-14 00:00:00+00:00

http://KEXP.ORG presents D’banj performing “Welcome To Lagos” live in the KEXP studio. Recorded August 15, 2022.

D’banj - Vocals
Babafemi Oluwagbeminiyi Kuti - Sax
Olaitan Jeremiah Adebowale - Keyboards
Oluwatobi Olalekan Alapo - Drums
Alfred Mukum - DJ / Producer

Host: Lace Cadence
Audio Engineer: Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://iamdbanj.live
http://kexp.org

## Sampa The Great - Bona (Live on KEXP)
 - [https://www.youtube.com/watch?v=eDUXvaA48ys](https://www.youtube.com/watch?v=eDUXvaA48ys)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-09-13 00:00:00+00:00

http://KEXP.ORG presents Sampa The Great performing “Bona” live in the KEXP studio. Recorded August 9, 2022.

Sampa Tembo - Vocals
Lazarus Zulu - Keys
Kasonde Sunkutu - Drums
Samuel “Sammy” Masta - Guitar
Mwanjé Tembo - Vocals
Taonga “Tio” Nyirongo - Vocals

Host: Gabriel Teodros
Audio Engineers: Daniel Evanko, Julian Martlew & Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Ettie Wahl
Editor: Jim Beckmann

https://sampathegreat.com
http://kexp.org

## Sampa The Great - Final Form (Live on KEXP)
 - [https://www.youtube.com/watch?v=yF_A5YzS11A](https://www.youtube.com/watch?v=yF_A5YzS11A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-09-13 00:00:00+00:00

http://KEXP.ORG presents Sampa The Great performing “Final Form” live in the KEXP studio. Recorded August 9, 2022.

Sampa Tembo - Vocals
Lazarus Zulu - Keys
Kasonde Sunkutu - Drums
Samuel “Sammy” Masta - Guitar
Mwanjé Tembo - Vocals
Taonga “Tio” Nyirongo - Vocals

Host: Gabriel Teodros
Audio Engineers: Daniel Evanko, Julian Martlew & Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Ettie Wahl
Editor: Jim Beckmann

https://sampathegreat.com
http://kexp.org

## Sampa The Great - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Sit2mu4jWok](https://www.youtube.com/watch?v=Sit2mu4jWok)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-09-13 00:00:00+00:00

http://KEXP.ORG presents Sampa The Great performing live in the KEXP studio. Recorded August 9, 2022.

Songs:
Never Forget
Bona
Let Me Be Great
Final Form

Sampa Tembo - Vocals
Lazarus Zulu - Keys
Kasonde Sunkutu - Drums
Samuel “Sammy” Masta - Guitar
Mwanjé Tembo - Vocals
Taonga “Tio” Nyirongo - Vocals

Host: Gabriel Teodros
Audio Engineers: Daniel Evanko, Julian Martlew & Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Ettie Wahl
Editor: Jim Beckmann

https://sampathegreat.com
http://kexp.org

## Sampa The Great - Let Me Be Great (Live on KEXP)
 - [https://www.youtube.com/watch?v=Sc4-lwaof8I](https://www.youtube.com/watch?v=Sc4-lwaof8I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-09-13 00:00:00+00:00

http://KEXP.ORG presents Sampa The Great performing “Let Me Be Great” live in the KEXP studio. Recorded August 9, 2022.

Sampa Tembo - Vocals
Lazarus Zulu - Keys
Kasonde Sunkutu - Drums
Samuel “Sammy” Masta - Guitar
Mwanjé Tembo - Vocals
Taonga “Tio” Nyirongo - Vocals

Host: Gabriel Teodros
Audio Engineers: Daniel Evanko, Julian Martlew & Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Ettie Wahl
Editor: Jim Beckmann

https://sampathegreat.com
http://kexp.org

## Sampa The Great - Never Forget (Live on KEXP)
 - [https://www.youtube.com/watch?v=Gbgmgkq_FXM](https://www.youtube.com/watch?v=Gbgmgkq_FXM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-09-13 00:00:00+00:00

http://KEXP.ORG presents Sampa The Great performing “Never Forget” live in the KEXP studio. Recorded August 9, 2022.

Sampa Tembo - Vocals
Lazarus Zulu - Keys
Kasonde Sunkutu - Drums
Samuel “Sammy” Masta - Guitar
Mwanjé Tembo - Vocals
Taonga “Tio” Nyirongo - Vocals

Host: Gabriel Teodros
Audio Engineers: Daniel Evanko, Julian Martlew & Jon Roberts
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Ettie Wahl
Editor: Jim Beckmann

https://sampathegreat.com
http://kexp.org


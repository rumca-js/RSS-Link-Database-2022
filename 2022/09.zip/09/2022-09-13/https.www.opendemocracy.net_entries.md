## NHS cancels thousands of appointments because of Queen’s funeral | openDemocracy
 - [https://www.opendemocracy.net/en/nhs-cancels-cancer-appointments-queen-elizabeth-funeral-bank-holiday/](https://www.opendemocracy.net/en/nhs-cancels-cancer-appointments-queen-elizabeth-funeral-bank-holiday/)
 - RSS feed: https://www.opendemocracy.net
 - date published: 2022-09-13 08:08:06.939457+00:00

         Exclusive: Thousands of patients waiting for surgery, maternity checks and some cancer care will be affected     


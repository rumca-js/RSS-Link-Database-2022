# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Pogrzeb królowej Elżbiety II. Media: Nie zaproszono przywódców Rosji, Białorusi i Birmy
 - [https://www.polsatnews.pl/wiadomosc/2022-09-13/pogrzeb-krolowej-elzbiety-ii-media-nie-zaproszono-przywodcow-rosji-bialorusi-i-birmy/](https://www.polsatnews.pl/wiadomosc/2022-09-13/pogrzeb-krolowej-elzbiety-ii-media-nie-zaproszono-przywodcow-rosji-bialorusi-i-birmy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-13 14:12:00+00:00

Wielka Brytania nie zaprosiła przedstawicieli Rosji, Białorusi i Birmy do udziału w państwowym pogrzebie królowej Elżbiety II, który ma się odbyć w następny poniedziałek - poinformowało źródło, na które powołuje się Reuters.

## Azerbejdżan ostrzelał Armenię. Zginęło 49 armeńskich żołnierzy
 - [https://www.polsatnews.pl/wiadomosc/2022-09-13/azerbejdzan-zaatakowal-armenie-zginelo-49-armenskich-zolnierzy/](https://www.polsatnews.pl/wiadomosc/2022-09-13/azerbejdzan-zaatakowal-armenie-zginelo-49-armenskich-zolnierzy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-13 10:23:00+00:00

Azerbejdżan rozpoczął zmasowany ostrzał artyleryjski i lotniczy południowo-wschodniej części terytorium Armenii. W wyniku ofensywy, zginęło 49 armeńskich żołnierzy. Skala i charakter nie miały wcześniej takiego precedensu - poinformował Arkadiusz Legieć z Polskiego Instytutu Spraw Międzynarodowych.

## Wojna w Ukrainie. Nie żyje ukraiński baletmistrz. Zginął w walce
 - [https://www.polsatnews.pl/wiadomosc/2022-09-13/wojna-w-ukrainie-nie-zyje-ukrainski-baletmistrz-zginal-w-walce/](https://www.polsatnews.pl/wiadomosc/2022-09-13/wojna-w-ukrainie-nie-zyje-ukrainski-baletmistrz-zginal-w-walce/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-13 09:18:00+00:00

Aleksander Szapowal zginął w poniedziałek w bitwie pod Majorskiem - poinformowały ukraińskie media. Serce nie chce w to uwierzyć - napisała primabalerina, która występowała ze Szapowalem w Operze Narodowej Ukrainy.

## Francja. Uciekły przed wojną. Rosjanin zaatakował je za słuchanie ukraińskiej muzyki
 - [https://www.polsatnews.pl/wiadomosc/2022-09-13/francja-uciekly-przed-wojna-rosjanin-zaatakowal-je-za-sluchanie-ukrainskiej-muzyki/](https://www.polsatnews.pl/wiadomosc/2022-09-13/francja-uciekly-przed-wojna-rosjanin-zaatakowal-je-za-sluchanie-ukrainskiej-muzyki/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-13 09:03:00+00:00

Dwie Ukrainki które uciekły przed wojną do Francji, podczas wieczornego spaceru zostały pobite przez Rosjanina. Powodem ataku miało być słuchanie przez kobiety ukraińskiej muzyki. Mężczyzna uciekł, ofiary trafiły do szpitala. Ambasador Ukrainy w Estonii po raz kolejny zaapelowała o zakaz wydawania wiz dla obywateli Rosji.

## Rosja. Kolejna tajemnicza śmierć menadżera. Iwan Pieczorin wypadł z łodzi
 - [https://www.polsatnews.pl/wiadomosc/2022-09-13/rosja-kolejna-tajemnicza-smierc-menadzera-wypadl-z-lodzi/](https://www.polsatnews.pl/wiadomosc/2022-09-13/rosja-kolejna-tajemnicza-smierc-menadzera-wypadl-z-lodzi/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-13 08:44:00+00:00

39-letni Iwan Pieczorin, dyrektor zarządzający z Korporacji Rozwoju Dalekiego Wschodu i Arktyki, miał wypaść z łodzi płynącej na pełnych obrotach w pobliżu Wyspy Rosyjskiej na Morzu Japońskim.

## Nie żyje Jean-Luc Godard. "Ojciec chrzestny francuskiego kina"
 - [https://www.polsatnews.pl/wiadomosc/2022-09-13/nie-zyje-jean-luc-godard-ojciec-chrzestny-francuskiego-kina/](https://www.polsatnews.pl/wiadomosc/2022-09-13/nie-zyje-jean-luc-godard-ojciec-chrzestny-francuskiego-kina/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-13 08:24:00+00:00

O śmierci Jean-Luc Godarda poinformował Reuters za francuską gazetą Liberation. Ojciec chrzestny francuskiego kina Nowej Fali miał 91 lat.

## Wojna w Ukrainie. Brytyjski wywiad: Żołnierze elitarnej armii Rosji uciekli z frontu
 - [https://www.polsatnews.pl/wiadomosc/2022-09-13/wojna-w-ukrainie-brytyjski-wywiad-zolnierze-1-gwardyjskiej-armii-pancernej-rosji-uciekli-z-ukrainy/](https://www.polsatnews.pl/wiadomosc/2022-09-13/wojna-w-ukrainie-brytyjski-wywiad-zolnierze-1-gwardyjskiej-armii-pancernej-rosji-uciekli-z-ukrainy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-13 07:39:00+00:00

Rosyjscy żołnierze, którzy w ostatnich dniach uciekli z frontu należeli do najbardziej elitarnej armii Federacji Rosyjskiej, która w razie wojny z NATO miała bronić Moskwę - poinformował brytyjski wywiad. Wysoko postawiony urzędnik Pentagonu zauważa z kolei, że uciekający Rosjanie zostawiają za sobą broń i sprzęt wojskowy. - To może świadczyć o dezorganizacji ich dowództwa - ocenia.

## Blue Origin. Awaria rakiety Jeffa Bezosa. Uratowano kapsułę
 - [https://www.polsatnews.pl/wiadomosc/2022-09-13/blue-origin-awaria-rakiety-jeffa-bezosa-uratowano-kapsule/](https://www.polsatnews.pl/wiadomosc/2022-09-13/blue-origin-awaria-rakiety-jeffa-bezosa-uratowano-kapsule/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-13 06:47:00+00:00

Podczas 23. startu rakiety New Shepard firmy Blue Origin, należącej do właściciela Amazona Jeffa Bezosa, doszło do awarii. Silnik, który miał wynieść rakietę na orbitę, zaczął tracić moc. Wówczas system awaryjny zareagował tak, jak go zaprojektowano. Kapsuła zawierająca ładunek oddzieliła się, a następnie wylądowała na spadochronach. Rakieta wielokrotnego użytku rozbiła się w Teksasie.

## Wojna w Ukrainie. Zełenski o zdobyczach Ukrainy: Odzyskano 6 tys. km kwadratowych terytorium
 - [https://www.polsatnews.pl/wiadomosc/2022-09-13/wojna-w-ukrainie-zelenski-o-zdobyczach-ukrainy-odzyskano-6-tys-km-kwadratowych-terytorium/](https://www.polsatnews.pl/wiadomosc/2022-09-13/wojna-w-ukrainie-zelenski-o-zdobyczach-ukrainy-odzyskano-6-tys-km-kwadratowych-terytorium/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-09-13 04:19:00+00:00

Na wschodzie Ukrainy trwa ukraińska kontrofensywa. Siły Zbrojne Ukrainy odzyskują kolejne miejscowości, które znajdowały się w rękach Rosjan. Prezydent Wołodymyr Zełenski w wystąpieniu w mediach społecznościowych poinformował, że od początku września odzyskano 6 tys. km kwadratowych terytorium kraju.


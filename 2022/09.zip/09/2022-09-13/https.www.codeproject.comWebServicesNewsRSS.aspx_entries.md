# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## .NET now on Windows Package Manager
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58860](https://www.codeproject.com/script/News/View.aspx?nwid=58860)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

Because downloading direct is just too easy

## Arm64 Performance Improvements in .NET 7
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58864](https://www.codeproject.com/script/News/View.aspx?nwid=58864)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

When's LEG day?

## Blazor Best Practices: Handling Errors
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58851](https://www.codeproject.com/script/News/View.aspx?nwid=58851)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

Errors are likely to occur, the question is how to handle them. Let’s take a look at best practices in handling them in your Blazor app.

## Consider a mobile-first approach for your next web initiative
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58853](https://www.codeproject.com/script/News/View.aspx?nwid=58853)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

Mobile-first web strategies let developers and designers focus on the core of the product and use cases that address this expanding market.

## Flutter For Front-End Web Developers
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58849](https://www.codeproject.com/script/News/View.aspx?nwid=58849)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

In this article, I want to share my experience and inspire anyone feeling paralyzed with choosing one ecosystem over the other by showing how concepts transfer over and any new concepts are learnable.

## Google canceled its next Pixelbook and shut down the team building it
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58862](https://www.codeproject.com/script/News/View.aspx?nwid=58862)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

They've cancelled all their software projects, time to move to hardware

## HTML Markup Tips for Developing Accessible Websites
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58850](https://www.codeproject.com/script/News/View.aspx?nwid=58850)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

Improving HTML markup can make websites more accessible for assisted technology and help developers with automated testing.

## How to use EF Core as an in-memory database in ASP.NET Core 6
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58854](https://www.codeproject.com/script/News/View.aspx?nwid=58854)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

Entity Framework Core allows you to store and retrieve data to and from an in-memory database. It’s a quick and easy way to test your ASP.NET Core 6 web applications.

## Intel teases 6 GHz Raptor Lake at stock, 8 GHz overclocking world record
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58858](https://www.codeproject.com/script/News/View.aspx?nwid=58858)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

"Clever girl"

## It's time to quit quitting on the quiet quitters
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58859](https://www.codeproject.com/script/News/View.aspx?nwid=58859)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

Or quit quitting the quitting quitters. Quite!

## Java is very fast, if you don’t create many objects
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58856](https://www.codeproject.com/script/News/View.aspx?nwid=58856)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

Even faster if you rewrite in C

## Playwright: A Modern, Open Source Approach to End-To-End Testing
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58852](https://www.codeproject.com/script/News/View.aspx?nwid=58852)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

I was excited when I started writing my first end-to-end tests years ago.

## Rotation
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58865](https://www.codeproject.com/script/News/View.aspx?nwid=58865)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00



## The developer case for using Tim Berners-Lee’s Solid
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58863](https://www.codeproject.com/script/News/View.aspx?nwid=58863)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

Believe them or not, they are solid arguments

## This week's survey
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58855](https://www.codeproject.com/script/News/View.aspx?nwid=58855)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

A regular 'non-programmer' or management track one?

## Who thought asking the internet to name NASA’s Uranus mission was a good idea?
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58861](https://www.codeproject.com/script/News/View.aspx?nwid=58861)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

Uranus McUranusface, of course

## Why the web framework hype train is always moving
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58848](https://www.codeproject.com/script/News/View.aspx?nwid=58848)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

JavaScript frameworks are a useful tool for developers because they help developers be more efficient by eliminating the need to rewrite boilerplate code for a new app or download individual libraries.

## Zoom’s Slack competitor is getting a new name and features
 - [https://www.codeproject.com/script/News/View.aspx?nwid=58857](https://www.codeproject.com/script/News/View.aspx?nwid=58857)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-09-13 04:00:00+00:00

Does it auto-convert all the messages to "Can you hear me now?"


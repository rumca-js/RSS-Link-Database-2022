## Automating a Reading List - Zanshin.net
 - [https://zanshin.net/2022/09/11/automating-a-reading-list/](https://zanshin.net/2022/09/11/automating-a-reading-list/)
 - RSS feed: https://zanshin.net
 - date published: 2022-09-13 23:53:24+00:00

The personal website of Mark Hanford Nichols.


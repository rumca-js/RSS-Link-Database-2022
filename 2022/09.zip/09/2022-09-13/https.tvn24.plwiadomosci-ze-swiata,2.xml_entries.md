# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Możliwe alerty IMGW. Synoptycy mogą ostrzegać przed ulewnym deszczem
 - [https://tvn24.pl/tvnmeteo/pogoda/mozliwe-alerty-imgw-przed-ulewnym-deszczem-prognoza-zagrozen-na-srode-6110485?source=rss](https://tvn24.pl/tvnmeteo/pogoda/mozliwe-alerty-imgw-przed-ulewnym-deszczem-prognoza-zagrozen-na-srode-6110485?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-09-13 13:58:30+00:00

<img alt="Możliwe alerty IMGW. Synoptycy mogą ostrzegać przed ulewnym deszczem" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie8ea1d2eaf6dfc710b6ba4cc0b1245a93-miejscami-moze-spasc-ulewny-deszcz-5140555/alternates/LANDSCAPE_1280" />
    IMGW wydał prognozę zagrożeń pogodowych. Według komunikatów, synoptycy zamierzają w środę ostrzegać przed ulewnymi opadami deszczu. Sprawdź, gdzie aura może dać się nam we znaki.

## Przekroczony budżet na dodatki węglowe, kiedy wypłata świadczeń. Ministerstwo odpowiada
 - [https://tvn24.pl/biznes/z-kraju/dodatek-weglowy-przekroczony-budzet-zmiana-przepisow-rzecznik-ministerstwa-klimatu-komentuje-6110408?source=rss](https://tvn24.pl/biznes/z-kraju/dodatek-weglowy-przekroczony-budzet-zmiana-przepisow-rzecznik-ministerstwa-klimatu-komentuje-6110408?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-09-13 13:57:56+00:00

<img alt="Przekroczony budżet na dodatki węglowe, kiedy wypłata świadczeń. Ministerstwo odpowiada" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uvkxqv-pieniadze-zlotowki-pln-shutterstock1246227253-5760573/alternates/LANDSCAPE_1280" />
    Według danych zebranych przez TVN24 Biznes z 14 województw kwota wynikająca z wniosków o dodatek węglowy sięgnęła 15,7 miliarda złotych. Tymczasem na wypłatę świadczenia rząd przeznaczył 11,5 miliarda złotych. Aleksander Brzózka, rzecznik Ministerstwa Środowiska


# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Colts' Jonathan Taylor reveals how he's helping his communities, picks side in New Jersey debates
 - [https://www.foxnews.com/sports/colts-jonathan-taylor-reveals-how-hes-helping-communities-picks-side-new-jersey-debates](https://www.foxnews.com/sports/colts-jonathan-taylor-reveals-how-hes-helping-communities-picks-side-new-jersey-debates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 23:53:27+00:00

Indianapolis Colts star running back Jonathan Taylor talked to Fox News Digital about giving back to his communities and why he takes pride in his New Jersey roots.

## Manchin slams Kamala Harris: 'Dead wrong' on border security claim
 - [https://www.foxnews.com/media/manchin-slams-kamala-harris-dead-wrong-border-security-claim](https://www.foxnews.com/media/manchin-slams-kamala-harris-dead-wrong-border-security-claim)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 23:45:07+00:00

Joe Manchin, a Democratic senator from West Virginia, called out Vice President Kamala Harris' declaration the U.S. southern border is secure, despite statistics.

## Photo Gallery: Queen Elizabeth's Coffin Travels To London
 - [https://www.foxnews.com/entertainment/photo-gallery-queen-elizabeths-coffin-travels-to-london](https://www.foxnews.com/entertainment/photo-gallery-queen-elizabeths-coffin-travels-to-london)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 23:43:25+00:00

Queen Elizabeth II's coffin traveled from Edinburgh, Scotland to Buckingham Palace in London, England.

## King Charles III awaits Queen Elizabeth II's casket with Prince Harry and Meghan Markle at Buckingham Palace
 - [https://www.foxnews.com/entertainment/king-charles-iii-awaits-queen-elizabeth-ii-casket-prince-harry-meghan-markle-buckingham-palace](https://www.foxnews.com/entertainment/king-charles-iii-awaits-queen-elizabeth-ii-casket-prince-harry-meghan-markle-buckingham-palace)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 23:40:00+00:00

King Charles III waited with Prince Harry, Meghan Markle and royal family to receive Queen Elizabeth II's casket at Buckingham Palace in London Tuesday

## Media puts more emphasis on Fetterman's health as Pennsylvania election heats up
 - [https://www.foxnews.com/media/media-puts-more-emphasis-fettermans-health-pennsylvania-election-heats-up](https://www.foxnews.com/media/media-puts-more-emphasis-fettermans-health-pennsylvania-election-heats-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 23:31:06+00:00

Media outlets have begun focusing on Pennsylvania Senate Democrat candidate John Fetterman’s health issues as the election nears after previously ignoring them.

## Judge Jeanine: To the left, it's really them versus us
 - [https://www.foxnews.com/media/judge-jeanine-left-really-them-versus-us](https://www.foxnews.com/media/judge-jeanine-left-really-them-versus-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 23:30:32+00:00

Judge Jeanine discusses with "The Five" how Kamala Harris and the left are attempting to claim that the Supreme Court lack "integrity" after Roe ruling.

## New York City block hires private security guards amid crime wave
 - [https://www.foxnews.com/us/new-york-city-block-hires-private-security-guards-crime-wave](https://www.foxnews.com/us/new-york-city-block-hires-private-security-guards-crime-wave)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 23:27:51+00:00

Residents and business owners on a block in Greenwich Village hired their own private security officers last month amid rising crime in New York City.

## Quinta Brunson jokes she 'might punch' Jimmy Kimmel 'in the face' after stunt during her Emmys speech
 - [https://www.foxnews.com/entertainment/quinta-brunson-jokes-might-punch-jimmy-kimmel-face-stunt-during-emmys-speech](https://www.foxnews.com/entertainment/quinta-brunson-jokes-might-punch-jimmy-kimmel-face-stunt-during-emmys-speech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 23:19:18+00:00

Quinta Brunson had a humorous response after Jimmy Kimmel's stunt during the Emmys. The late night host was criticizing for laying at her feet during her acceptance speech as part of a planned bit.

## Stefanik, Donalds will compete to be next House GOP conference chair
 - [https://www.foxnews.com/politics/stefanik-donalds-compete-next-house-gop-conference-chair](https://www.foxnews.com/politics/stefanik-donalds-compete-next-house-gop-conference-chair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 23:11:39+00:00

Reps. Stefanik and Donalds will face off in a race for House GOP conference chair after the midterms as Republicans plan for a potential House majority.

## California launches taxpayer-funded website promoting state’s abortion services
 - [https://www.foxnews.com/politics/california-launches-taxpayer-funded-website-promoting-states-abortion-services](https://www.foxnews.com/politics/california-launches-taxpayer-funded-website-promoting-states-abortion-services)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 23:07:21+00:00

California has launched a taxpayer-funded website promoting abortion services and resources -- even for non-residents and illegal immigrants.

## Biden slammed for hosting Inflation Reduction Act celebration with ‘American's 401Ks going down the drain’
 - [https://www.foxnews.com/media/biden-slammed-hosting-inflation-reduction-act-celebration-americans-401ks-going-down-drain](https://www.foxnews.com/media/biden-slammed-hosting-inflation-reduction-act-celebration-americans-401ks-going-down-drain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 22:50:05+00:00

President Biden was criticized for celebrating the Inflation Reduction Act despite the latest CPI report showing higher than expected inflation, causing stocks to tumble.

## Border patrol agent: Drug cartels are flourishing from an open border
 - [https://www.foxnews.com/media/border-patrol-agent-drug-cartels-flourishing-open-border](https://www.foxnews.com/media/border-patrol-agent-drug-cartels-flourishing-open-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 22:45:58+00:00

National Border Patrol Council vice president Art Del Cueto joins 'Your World' to react to a video of camouflaged migrants at the southern border.

## Monica Lewinsky on Ken Starr death: 'Painful loss for those who love him'
 - [https://www.foxnews.com/politics/monica-lewinsky-ken-starr-death-painful-loss-those-love-him](https://www.foxnews.com/politics/monica-lewinsky-ken-starr-death-painful-loss-those-love-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 22:39:49+00:00

Former White House intern Monica Lewinsky said Ken Starr's death brought up "complicated feelings" but noted that his loss was painful for his loved ones.

## Broncos' Melvin Gordon delivers warning to Seahawks after upset: 'They can laugh now'
 - [https://www.foxnews.com/sports/broncos-melvin-gordon-delivers-warning-seahawks-upset-they-can-laugh-now](https://www.foxnews.com/sports/broncos-melvin-gordon-delivers-warning-seahawks-upset-they-can-laugh-now)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 22:39:35+00:00

Denver Broncos running back Melvin Gordon is hoping to meet the Seattle Seahawks again after the Seahawks' upset Monday night of the Broncos in Seattle.

## Biden's student loan handouts a 'political trick' ahead of midterms: Montana governor
 - [https://www.foxnews.com/media/bidens-student-loan-handouts-political-trick-midterms-montana-governor](https://www.foxnews.com/media/bidens-student-loan-handouts-political-trick-midterms-montana-governor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 22:37:39+00:00

Montana Gov. Greg Gianforte reacted to President Biden’s governmental spending and his student loan handouts amid inflation on Tuesday on "Your World."

## Broncos' Nathaniel Hackett regrets kicking 64-yard field goal: 'We definitely should've gone for it'
 - [https://www.foxnews.com/sports/broncos-nathaniel-hackett-regrets-kicking-64-yard-field-goal-we-definitely-shouldve-gone-for-it](https://www.foxnews.com/sports/broncos-nathaniel-hackett-regrets-kicking-64-yard-field-goal-we-definitely-shouldve-gone-for-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 22:34:59+00:00

Nathaniel Hackett found out how hard it is to be a head coach rather quickly, and he's already taking back his first controversial decision.

## Judge Pirro blasts Biden's 'tone-deaf party' as Inflation Reduction Act ushers in even higher inflation
 - [https://www.foxnews.com/media/judge-pirro-blasts-biden-tone-deaf-party-inflation-reduction-act-ushers-higher-inflation](https://www.foxnews.com/media/judge-pirro-blasts-biden-tone-deaf-party-inflation-reduction-act-ushers-higher-inflation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 22:30:19+00:00

President Joe Biden and the Democratic leaders of both Congressional chambers came together on the White House lawn to celebrate the Inflation Reduction Act.

## Chicago man gets 65 years for killing father of five in road rage encounter
 - [https://www.foxnews.com/us/chicago-man-gets-65-years-killing-father-five-road-rage-encounter](https://www.foxnews.com/us/chicago-man-gets-65-years-killing-father-five-road-rage-encounter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 22:27:55+00:00

A Chicago man was sentenced to 65 years in jail for shooting and killing a father of five during a road rage encounter two years ago, authorities said.

## Feds disrupt 'prolific' human smuggling operation that moved hundreds across the southern border
 - [https://www.foxnews.com/politics/feds-disrupt-prolific-human-smuggling-operation-moved-hundreds-across-southern-border](https://www.foxnews.com/politics/feds-disrupt-prolific-human-smuggling-operation-moved-hundreds-across-southern-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 22:26:59+00:00

DOJ and DHS announced a joint task force action that resulted in the indictment of fourteen individuals involved in a major migrant smuggling operation “motivated by greed” on the U.S. – Mexico border.

## Brett Favre got help from former Mississippi gov to get volleyball complex built using welfare funds: report
 - [https://www.foxnews.com/sports/brett-favre-got-help-former-mississippi-gov-get-volleyball-complex-built-using-welfare-funds-report](https://www.foxnews.com/sports/brett-favre-got-help-former-mississippi-gov-get-volleyball-complex-built-using-welfare-funds-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 22:23:39+00:00

New evidence in a Mississippi welfare fraud case shows that Hall of Famer Brett Favre sent and received texts regarding the funding for a new volleyball stadium with public money.

## Inside Prince Harry, Prince William's royal reunion: Behind the scenes of dramatic appearance with their wives
 - [https://www.foxnews.com/entertainment/inside-prince-harry-prince-williams-royal-reunion-behind-the-scenes-dramatic-appearance-with-their-wives](https://www.foxnews.com/entertainment/inside-prince-harry-prince-williams-royal-reunion-behind-the-scenes-dramatic-appearance-with-their-wives)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 21:40:52+00:00

Prince Harry and Prince William's reunion after the death of Queen Elizabeth II was marred by reports of drama behind the scenes. Fox News Digital explores what went down

## Oprah Winfrey slammed for defending Meghan Markle, Prince Harry after Queen Elizabeth II's death
 - [https://www.foxnews.com/entertainment/oprah-winfrey-slammed-defending-meghan-markle-prince-harry-queen-elizabeth-iis-death](https://www.foxnews.com/entertainment/oprah-winfrey-slammed-defending-meghan-markle-prince-harry-queen-elizabeth-iis-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 21:36:02+00:00

Critics took to Twitter and ripped Oprah Winfrey for making comments about Queen Elizabeth II's death being a "peacemaking" opportunity for Harry, Meghan and the royal family.

## Sen. Daines presses Big Tech execs on how social media platforms plan to combat fentanyl, illicit drug sales
 - [https://www.foxnews.com/politics/sen-daines-presses-big-tech-execs-social-media-platforms-plan-combat-fentanyl-illicit-drug-sales](https://www.foxnews.com/politics/sen-daines-presses-big-tech-execs-social-media-platforms-plan-combat-fentanyl-illicit-drug-sales)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 21:31:13+00:00

Montana Sen. Steve Daines sent a letter to the CEOs of Sanpchat, TikTok, Instagram and YouTube on Tuesday asking about what steps they are taking to combat drug sales online.

## Alabama’s Nick Saban pleased with team’s mental toughness in win over Texas: ‘Tough times make hard people’
 - [https://www.foxnews.com/sports/alabamas-nick-saban-pleased-teams-mental-toughness-win-texas-tough-times-make-hard-people](https://www.foxnews.com/sports/alabamas-nick-saban-pleased-teams-mental-toughness-win-texas-tough-times-make-hard-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 21:18:50+00:00

Alabama head coach Nick Saban praised his team's mental toughness after beating Texas 20-19 in Week 2. Alabama won on a last-second field goal in Austin.

## Democrats outpacing Republicans by tens of thousands of absentee ballot requests in key midterm state
 - [https://www.foxnews.com/politics/democrats-outpacing-republicans-tens-of-thousands-absentee-ballot-requests-key-midterm-state](https://www.foxnews.com/politics/democrats-outpacing-republicans-tens-of-thousands-absentee-ballot-requests-key-midterm-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 21:18:14+00:00

Democrats have requested tens of thousands more absentee ballots than Republicans in North Carolina, one of the most closely watched states this election cycle.

## Las Vegas Dem charged in reporters murder appears in court
 - [https://www.foxnews.com/us/las-vegas-dem-charged-reporters-murder-appears-court](https://www.foxnews.com/us/las-vegas-dem-charged-reporters-murder-appears-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 21:13:31+00:00

A Nevada Democratic elected official charged with the murder of a journalist who had been investigating him briefly appeared in court Tuesday, court records show.

## CNN's fact-checker continues strong focus on Republicans, pays Biden little attention
 - [https://www.foxnews.com/media/cnns-fact-checker-continues-strong-focus-republicans-pays-biden-little-attention](https://www.foxnews.com/media/cnns-fact-checker-continues-strong-focus-republicans-pays-biden-little-attention)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 21:11:59+00:00

CNN's Daniel Dale continues to focus most of his fact-checking attention on Republican claims, while largely ignoring remarks made by President Biden.

## Expert: School shooter's mother drank heavily in pregnancy
 - [https://www.foxnews.com/us/expert-school-shooters-mother-drank-heavily-pregnancy](https://www.foxnews.com/us/expert-school-shooters-mother-drank-heavily-pregnancy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 21:10:17+00:00

The trial of Florida school shooter Nikolas Cruz continued as the defense continued to argue their case that Cruz's birth mother's alcohol abuse led to shooting

## Nancy Pelosi nudges audience to clap during White House lawn event: ‘That’s an applause line’
 - [https://www.foxnews.com/politics/nancy-pelosi-nudges-audience-clap-during-white-house-lawn-event-applause-line](https://www.foxnews.com/politics/nancy-pelosi-nudges-audience-clap-during-white-house-lawn-event-applause-line)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 21:08:34+00:00

House Speaker Nancy Pelosi told an audience on the White House lawn, "that's an applause line" while celebrating President Biden signing the Inflation Reduction Act.

## DeSantis aide Christina Pushaw touts blocking access to liberal media 'activists': 'Cut them off'
 - [https://www.foxnews.com/media/desantis-aide-christina-pushaw-touts-blocking-access-liberal-media-activists](https://www.foxnews.com/media/desantis-aide-christina-pushaw-touts-blocking-access-liberal-media-activists)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 21:08:10+00:00

Top DeSantis aide Christina Pushaw spoke at the National Conservatism conference on the media's animosity towards GOPers and how they should follow her boss's lead and "cut them off."

## Former Pennsylvania EMS chief allegedly used hidden cameras to record girls, women undressing in bathrooms
 - [https://www.foxnews.com/us/former-pennsylvania-ems-chief-allegedly-used-hidden-cameras-record-girls-women-undressing-bathrooms](https://www.foxnews.com/us/former-pennsylvania-ems-chief-allegedly-used-hidden-cameras-record-girls-women-undressing-bathrooms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 20:48:39+00:00

A former Pennsylvania EMS chief is charged with secretly recording women and underage girls in bathrooms without their consent, authorities said.

## Kentucky football literally chomps gator after Florida victory
 - [https://www.foxnews.com/sports/kentucky-football-literally-chomps-gator-after-florida-victory](https://www.foxnews.com/sports/kentucky-football-literally-chomps-gator-after-florida-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 20:48:21+00:00

The University of Kentucky football team seems to have literally eaten gator for dinner Monday night following their win over the University of Florida this weekend.

## Florida student alerts teacher after finding bag of fentanyl
 - [https://www.foxnews.com/us/florida-students-alert-teachers-finding-bag-fentanyl](https://www.foxnews.com/us/florida-students-alert-teachers-finding-bag-fentanyl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 20:47:28+00:00

Deputies say a Florida high school teacher asked the school resource deputy for help after a student found a small packet of fentanyl outside of the bathroom.

## Commanders' defensive lineman trashes idea Carson Wentz is problem in locker room
 - [https://www.foxnews.com/sports/commanders-d-lineman-trashes-idea-carson-wentz-problem-locker-room](https://www.foxnews.com/sports/commanders-d-lineman-trashes-idea-carson-wentz-problem-locker-room)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 20:41:57+00:00

Carson Wentz left both the Philadelphia Eagles and Indianapolis Colts on bad terms, but new teammate Jonathan Allen isn't buying that Wentz is an issue in the locker room.

## Biden celebrates ‘Inflation Reduction Act’ after inflation rises in August
 - [https://www.foxnews.com/politics/biden-celebrates-inflation-reduction-act-inflation-rises-august](https://www.foxnews.com/politics/biden-celebrates-inflation-reduction-act-inflation-rises-august)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 20:37:13+00:00

President Biden gave a speech on the White House lawn Tuesday, touting the passage of the Inflation Reduction Act, even as inflation rose in August.

## Republicans slam Biden's new clean energy czar John Podesta as CCP 'shill' over ties to top Chinese official
 - [https://www.foxnews.com/politics/republicans-slam-bidens-new-clean-energy-czar-john-podesta-ties-ccp-official](https://www.foxnews.com/politics/republicans-slam-bidens-new-clean-energy-czar-john-podesta-ties-ccp-official)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 20:36:25+00:00

Republican leaders in Congress are blasting President Biden’s newly tapped clean energy czar, John Podesta, over his close ties to a top Chinese Communist Party (CCP) official.

## James Taylor sings 'Fire and Rain' to kick off White House Inflation Reduction Act celebration
 - [https://www.foxnews.com/entertainment/james-taylor-sings-fire-and-rain-kick-off-white-house-inflation-reduction-act-celebration](https://www.foxnews.com/entertainment/james-taylor-sings-fire-and-rain-kick-off-white-house-inflation-reduction-act-celebration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 20:28:03+00:00

Grammy Award winner James Taylor performed "Fire and Ice" in front of the White House to celebrate the Inflation Reduction Act on Tuesday.

## San Bernardino ends decade-long bankruptcy status
 - [https://www.foxnews.com/us/san-bernardino-ends-decade-long-bankruptcy-status](https://www.foxnews.com/us/san-bernardino-ends-decade-long-bankruptcy-status)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 20:27:59+00:00

San Bernardino finally closes its decade-long bankruptcy case. The Southern California city now has a budget surplus compared to its $45 million budget shortfall in 2012.

## Carolina Herrera's new line 'The Secret Garden' unveiled at NY Fashion Week
 - [https://www.foxnews.com/lifestyle/carolina-herreras-new-line-secret-garden-unveiled-ny-fashion-week](https://www.foxnews.com/lifestyle/carolina-herreras-new-line-secret-garden-unveiled-ny-fashion-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 20:27:25+00:00

Carolina Herrera unveiled their new fall 2022 fashion line, "The Secret Garden," at New York Fashion Week, featuring artistic portrayals of nature and beauty.

## Steelers' Najee Harris confirms availability for home opener, Mike Tomlin remains cautiously optimistic
 - [https://www.foxnews.com/sports/steelers-najee-harris-confirms-availability-home-opener-mike-tomlin-remains-cautiously-optimistic](https://www.foxnews.com/sports/steelers-najee-harris-confirms-availability-home-opener-mike-tomlin-remains-cautiously-optimistic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 19:40:31+00:00

Second-year running back Najee Harris said Tuesday that he'll be ready for the Pittsburgh Steelers home opener against the New England Patriots on Sunday.

## Austin woman attacked and robbed as 'jugging' turns violent, police seek suspects
 - [https://www.foxnews.com/us/austin-woman-attacked-robbed-jugging-violent-police-seek-suspects](https://www.foxnews.com/us/austin-woman-attacked-robbed-jugging-violent-police-seek-suspects)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 19:38:56+00:00

A woman was attacked and robbed on her front porch after withdrawing cash from a bank in Austin, Texas, on Friday afternoon, according to police.

## Betsy DeVos hits back at Sen. Patty Murray, accuses her of wanting 'Title IX kangaroo courts back'
 - [https://www.foxnews.com/media/betsy-devos-accuses-democratic-senator-of-wanting-title-ix-kangaroo-courts-back](https://www.foxnews.com/media/betsy-devos-accuses-democratic-senator-of-wanting-title-ix-kangaroo-courts-back)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 19:35:53+00:00

Betsy Devos responds to Sen. Patty Murray, D-Wash., who called the former education secretary's Title IX rule "cruel" and lauded Biden's proposed changes.

## Half a million Somali children under 5 at risk of dying from famine
 - [https://www.foxnews.com/world/half-a-million-somali-children-under-5-risk-dying-famine](https://www.foxnews.com/world/half-a-million-somali-children-under-5-risk-dying-famine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 19:35:15+00:00

Half a million children in Somalia under five are at risk of dying from famine, a number unseen in any country this century, as the region faces a fifth consecutive failed rainy season.

## Republican wives adding 'authenticity' to husbands' campaigns makes NY Times editorial board member 'gag'
 - [https://www.foxnews.com/media/republican-wives-adding-authenticity-husbands-campaigns-makes-ny-times-editorial-board-member-gag](https://www.foxnews.com/media/republican-wives-adding-authenticity-husbands-campaigns-makes-ny-times-editorial-board-member-gag)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 19:32:04+00:00

New York Times editorial board member Michelle Cottle scoffed at the idea of Republican candidates featuring their wives in campaign ads to help their image.

## Steelers' TJ Watt posts clever meme to vow return after injury in Week 1
 - [https://www.foxnews.com/sports/steelers-tj-watt-posts-clever-meme-vow-return-week-1-injury](https://www.foxnews.com/sports/steelers-tj-watt-posts-clever-meme-vow-return-week-1-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 19:31:39+00:00

Pittsburgh Steelers defensive end T.J. Watt used a clever Terminator meme to vow that he will return at some point this season following a pec injury in Week 1.

## Karine Jean-Pierre stumbles when pressed on so-called Inflation Reduction Act: 'Is it fair?'
 - [https://www.foxnews.com/politics/karine-jean-pierre-stumbles-when-pressed-so-called-inflation-reduction-act-fair](https://www.foxnews.com/politics/karine-jean-pierre-stumbles-when-pressed-so-called-inflation-reduction-act-fair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 19:23:12+00:00

Karine Jean-Pierre floundered when pressed to defend President Joe Biden's Inflation Reduction Act on Tuesday. Reporters suggested she was misrepresenting the bill.

## Steve Sarkisian channels his inner Nick Saban, says Texas must be ‘careful of the rat poison’
 - [https://www.foxnews.com/sports/steve-sarkisian-channels-inner-nick-saban-texas-must-careful-rat-poison](https://www.foxnews.com/sports/steve-sarkisian-channels-inner-nick-saban-texas-must-careful-rat-poison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 19:21:38+00:00

Texas head coach Steve Sarkisian told reporters his team needs to be wary of the "rat poison," a frequently used phrase by Nick Saban, after a close loss to Alabama.

## Peyton Manning mocks Jets as coach Robert Saleh takes notes
 - [https://www.foxnews.com/sports/peyton-manning-mocks-jets-coach-robert-saleh-takes-notes](https://www.foxnews.com/sports/peyton-manning-mocks-jets-coach-robert-saleh-takes-notes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 19:18:59+00:00

Peyton Manning took aim at the New York Jets after Sunday's loss to the Ravens, mocking quarterback Joe Flacco for his 59 attempts in Baltimore's 24-9 victory.

## Maryland 11-year-old charged with arson in fire that destroyed dollar store
 - [https://www.foxnews.com/us/maryland-11-year-old-charged-arson-fire-destroyed-dollar-store](https://www.foxnews.com/us/maryland-11-year-old-charged-arson-fire-destroyed-dollar-store)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 19:12:45+00:00

A Maryland boy has been charged with arson after he started a fire that destroyed a dollar store. The boy was charged with first-degree arson and released to his parent’s custody

## Senate Republicans demand Biden admin rescind Head Start toddler mask mandate
 - [https://www.foxnews.com/politics/senate-republicans-demand-biden-admin-rescind-head-start-toddler-mask-mandate](https://www.foxnews.com/politics/senate-republicans-demand-biden-admin-rescind-head-start-toddler-mask-mandate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:50:21+00:00

As the pandemic enters its third full school year, Senate Republicans say it's time to stop requiring masks in federal Head Start preschool programs.

## World leaders expected to attend Queen Elizabeth II's funeral include President Biden and Macron
 - [https://www.foxnews.com/world/world-leaders-expected-attend-queen-elizabeth-iis-funeral-include-president-biden-and-macron](https://www.foxnews.com/world/world-leaders-expected-attend-queen-elizabeth-iis-funeral-include-president-biden-and-macron)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:49:49+00:00

Queen Elizabeth II's funeral is expected to draw numerous world leaders, including President Biden, to London, potentially prompting shutdowns in the city.

## Trump-picked special master candidate signed Carter Page warrant before FBI misconduct discovered
 - [https://www.foxnews.com/politics/trump-picked-special-master-candidate-signed-carter-page-fisa-before-fbi-misconduct-discovered](https://www.foxnews.com/politics/trump-picked-special-master-candidate-signed-carter-page-fisa-before-fbi-misconduct-discovered)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:43:28+00:00

Former President Trump's candidate for special master, approved by DOJ, signed off on a FISA warrant to surveil Carter Page – before the FBI misconduct was discovered.

## Pro-life activist clashes with Dr. Phil, audience member on abortion: 'You keep speaking over me'
 - [https://www.foxnews.com/media/pro-life-activist-clashes-dr-phil-audience-member-abortion-you-keep-speaking-over-me](https://www.foxnews.com/media/pro-life-activist-clashes-dr-phil-audience-member-abortion-you-keep-speaking-over-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:42:36+00:00

Pro-life activist Lila Rose faced off against Dr. Phil and a member of his studio audience during a tense conversation about abortion and women's rights.

## Rick Scott won't commit to backing McConnell as GOP Senate leader
 - [https://www.foxnews.com/politics/rick-scott-wont-commit-to-backing-mcconnell-gop-senate-leader](https://www.foxnews.com/politics/rick-scott-wont-commit-to-backing-mcconnell-gop-senate-leader)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:39:09+00:00

National Republican Senatorial Committee Chairman Rick Scott refused to say whether he will back Minority Leader Mitch McConnell for another term leading the Senate GOP.

## Oregon parents rights group files petition against Oregon Health Authority over school vaccine mandate
 - [https://www.foxnews.com/media/oregon-parents-rights-group-files-petition-oregon-health-authority-school-vaccine-mandate](https://www.foxnews.com/media/oregon-parents-rights-group-files-petition-oregon-health-authority-school-vaccine-mandate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:37:18+00:00

A parents' rights group called the Oregon Moms Union filed a petition to the Oregon Health Authority (OHA) to repeal OAR 333-019-1030, which is a vaccine mandate for public schools.

## US sailor killed in Pearl Harbor to be laid to rest after decades-long effort to identify remains
 - [https://www.foxnews.com/us/us-sailor-killed-pearl-harbor-laid-rest-decades-long-effort-identify-remains](https://www.foxnews.com/us/us-sailor-killed-pearl-harbor-laid-rest-decades-long-effort-identify-remains)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:28:50+00:00

U.S. sailor Herbert Jacobson will be laid to rest in Arlington National Cemerary Tuesday, 80 years after his death at Pearl Harbor. The sailor grew up in northern Illinois.

## Britney Spears body-shames Christina Aguilera, singer unfollows her: report
 - [https://www.foxnews.com/entertainment/britney-spears-body-shames-christina-aguilera-singer-unfollows-her-report](https://www.foxnews.com/entertainment/britney-spears-body-shames-christina-aguilera-singer-unfollows-her-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:24:26+00:00

Britney Spears decided to body-shame fellow pop star and "Mickey Mouse Club" member Christina Aguilera on Instagram. The "Toxic" singer was bashed by fans for her disparaging comment.

## No charges in deaths of 3 New York kids found on Coney Island beach, mother hospitalized for evaluation
 - [https://www.foxnews.com/us/no-charges-deaths-new-york-kids-found-coney-island-beach-mother-hospitalized-evaluation](https://www.foxnews.com/us/no-charges-deaths-new-york-kids-found-coney-island-beach-mother-hospitalized-evaluation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:23:48+00:00

The Brooklyn mother of three deceased children found unconscious on a Coney Island beach remains hospitalized, and no charges have been filed in connection to the suspected drownings.

## Charlie Crist has a history of comparing himself to Jesus Christ, calling opponent 'DeSatan'
 - [https://www.foxnews.com/politics/charlie-crist-history-comparing-himself-jesus-christ-calling-opponent-desatan](https://www.foxnews.com/politics/charlie-crist-history-comparing-himself-jesus-christ-calling-opponent-desatan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:21:19+00:00

Rep. Charlie Crist called Florida Gov. Ron DeSantis "DeSatan" at several campaign events, while also making biblical references and comparing himself to Jesus Christ.

## Suspect accused of beheading ex-girlfriend with sword believed to be US citizen
 - [https://www.foxnews.com/us/suspect-accused-beheading-ex-girlfriend-sword-us-illegally-report](https://www.foxnews.com/us/suspect-accused-beheading-ex-girlfriend-sword-us-illegally-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:14:10+00:00

Jose Solano Landaeta, accused of beheading his ex-girlfriend with a sword, is believed to be a U.S. citizen, following a report he's in the country illegally.

## Senate candidate Rep. Tim Ryan tells MSNBC: Time to 'kill and confront' the 'extremist' Republican movement
 - [https://www.foxnews.com/media/senate-candidate-rep-tim-ryan-tells-msnbc-time-to-kill-confront-extremist-republican-movement](https://www.foxnews.com/media/senate-candidate-rep-tim-ryan-tells-msnbc-time-to-kill-confront-extremist-republican-movement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 18:09:45+00:00

Democratic candidate for U.S. Senate in Ohio, Rep. Tim Ryan, told MSNBC's "Morning Joe" that it is time to "kill and confront" the "extremist" Republican movement.

## Rapper shot to death at LA restaurant targeted for jewelry after girlfriend tagged Instagram location: report
 - [https://www.foxnews.com/us/rapper-shot-death-la-restaurant-targeted-jewelry-girlfriend-tagged-instagram-location-report](https://www.foxnews.com/us/rapper-shot-death-la-restaurant-targeted-jewelry-girlfriend-tagged-instagram-location-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 17:47:26+00:00

Rapper PnB Rock, who was fatally shot at a Los Angeles restaurant, might have been targeted for his jewelry after his girlfriend tagged their location on Instagram, a report says.

## UK's long-term sickness rate highest since 2005
 - [https://www.foxnews.com/world/uks-long-term-sickness-rate-highest-since-2005](https://www.foxnews.com/world/uks-long-term-sickness-rate-highest-since-2005)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 17:46:54+00:00

The UK believes that its workforce has reached the highest level of people who are too sick to work since 2005 because of a mixture of long-COVID and difficulty accessing health care.

## Marshall University to host investiture ceremony of 38th president
 - [https://www.foxnews.com/us/marshall-university-host-investiture-ceremony-38th-president](https://www.foxnews.com/us/marshall-university-host-investiture-ceremony-38th-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 17:45:46+00:00

Marshall University in West Virginia is hosting the investiture ceremony for Brad D. Smith on Friday. The ceremony will take place in Huntington on the Morrow Library lawn.

## UN: Cholera outbreak in Syria poses serious threat
 - [https://www.foxnews.com/health/un-cholera-outbreak-syria-poses-serious-threat](https://www.foxnews.com/health/un-cholera-outbreak-syria-poses-serious-threat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 17:45:03+00:00

Health experts at the U.N. and WHO are concerned over a recent cholera outbreak in Syria, which they believe was caused by infrastructure issues creating unsafe drinking water.

## Man accused of abducting and killing two young girls faces first two trials
 - [https://www.foxnews.com/us/man-accused-abducting-killing-two-young-girls-first-two-trials](https://www.foxnews.com/us/man-accused-abducting-killing-two-young-girls-first-two-trials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 17:38:21+00:00

A man is facing his first two trials for allegedly abducting and killing a 6-year-old and a 13-year-old girl in Tucson, Arizona. He later dumped their bodies in the desert.

## Attorney for the man who beheaded a woman with a sword requests psychiatric evaluation
 - [https://www.foxnews.com/us/attorney-man-beheaded-woman-sword-requests-psychiatric-evaluation](https://www.foxnews.com/us/attorney-man-beheaded-woman-sword-requests-psychiatric-evaluation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 17:36:21+00:00

The attorney for a man accused of beheading his child’s mother with a sword requests psychiatric evaluation for the defendant, claiming he may not be mentally competent to stand trial.

## Pentagon in 'potential noncompliance' with law after denying vaccine religious accommodation requests: IG
 - [https://www.foxnews.com/politics/pentagon-potential-noncompliance-law-denying-vaccine-religious-accommodation-requests-ig](https://www.foxnews.com/politics/pentagon-potential-noncompliance-law-denying-vaccine-religious-accommodation-requests-ig)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 17:32:49+00:00

The Pentagon's inspector general says that the agency is in "potential noncompliance" with standards for reviewing and denying service members' requests for religious accommodations to the COVID-19 vaccine.

## Azerbaijan-Armenia fighting leaves 99 dead, Putin looks to 'de-escalate' conflict
 - [https://www.foxnews.com/world/azerbaijan-armenia-fighting-dead-putin-looks-de-escalate-conflict](https://www.foxnews.com/world/azerbaijan-armenia-fighting-dead-putin-looks-de-escalate-conflict)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 17:32:27+00:00

Russian President Vladimir Putin urged peace Tuesday after a border conflict between former Soviet nations, Armenia and Azerbaijan, left at least 49 dead.

## Georgia Republican Gov. Brian Kemp offers new K-12 bid as part of re-election efforts
 - [https://www.foxnews.com/us/georgia-republican-gov-brian-kemp-offers-new-k-12-bid-part-reelection-efforts](https://www.foxnews.com/us/georgia-republican-gov-brian-kemp-offers-new-k-12-bid-part-reelection-efforts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 17:32:14+00:00

Georgia Gov. Brian Kemp announced a plan for K-12 schools as part of his re-election effort for the 2022 election. Kemp made a $5,000 pay raise for teachers a centerpiece of his agenda.

## Election Brief: 2022 primary season concludes with fiery Republican face-offs in battleground New Hampshire
 - [https://www.foxnews.com/politics/election-brief-2022-primary-season-concludes-fiery-republican-battleground-new-hampshire](https://www.foxnews.com/politics/election-brief-2022-primary-season-concludes-fiery-republican-battleground-new-hampshire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 17:30:12+00:00

Final primary elections ahead of November's 2022 midterms will determine who will take on Sen. Maggie Hassan, D-N.H., and more news from the campaign trail in Fox News' Election brief

## At least 12 new Ford Mustangs stolen from Michigan assembly plant
 - [https://www.foxnews.com/us/least-twelve-new-ford-mustangs-stolen-michigan-assembly-plant](https://www.foxnews.com/us/least-twelve-new-ford-mustangs-stolen-michigan-assembly-plant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 16:43:50+00:00

Police in Michigan are looking for the people who drove off in 12 to 15 new Mustangs from Ford's Flat Rock Assembly Plant.

## Harris: Authoritarians can point to Dobbs decision to justify taking away rights
 - [https://www.foxnews.com/politics/harris-authoritarians-can-point-dobbs-decision-justify-taking-away-rights](https://www.foxnews.com/politics/harris-authoritarians-can-point-dobbs-decision-justify-taking-away-rights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 16:40:16+00:00

Vice President Kamala Harris stated that with the Supreme Court overturning Roe v. Wade, the U.S. has lost authority on the world stage to talk about human rights.

## Ford developing smartphone-controlled towing tech
 - [https://www.foxnews.com/auto/ford-developing-remote-controlled-towing-tech](https://www.foxnews.com/auto/ford-developing-remote-controlled-towing-tech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 16:38:04+00:00

Ford has filed a patent for technology that would allow a driver to back up a vehicle with a trailer attached remotely by using their smartphone.

## Legalized sports betting has arrived in Kansas
 - [https://www.foxnews.com/us/legalized-sports-betting-arrived-kansas](https://www.foxnews.com/us/legalized-sports-betting-arrived-kansas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 16:36:20+00:00

Kansas officially launched legalized sports betting in the state on Sept. 8. The launch came just in time for week one of the NFL season.

## Bill Gates concerned about maintaining focus on public health during economic downturn
 - [https://www.foxnews.com/health/bill-gates-concerned-maintaining-focus-public-health-economic-downturn](https://www.foxnews.com/health/bill-gates-concerned-maintaining-focus-public-health-economic-downturn)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 16:28:44+00:00

As the world is still economically recovering from the COVID pandemic, Bill Gates worries that finding funding to assist countries with public health issues will only get harder.

## NBA: Suns owner Robert Sarver used N-word on at least 5 occasions, made 'many sex-related comments'
 - [https://www.foxnews.com/sports/nba-suns-owner-robert-sarver-used-n-word-at-least-5-occasions-made-many-sex-related-comments](https://www.foxnews.com/sports/nba-suns-owner-robert-sarver-used-n-word-at-least-5-occasions-made-many-sex-related-comments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 16:26:25+00:00

The NBA revealed the discipline for the Phoenix Suns team owner after an independent probe said he "violated common workplace standards."

## Leonardo DiCaprio and Gigi Hadid reportedly 'getting to know each other'
 - [https://www.foxnews.com/entertainment/leonardo-dicaprio-gigi-hadid-reportedly-getting-know-each-other](https://www.foxnews.com/entertainment/leonardo-dicaprio-gigi-hadid-reportedly-getting-know-each-other)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 16:15:42+00:00

"Wolf of Wall Street" star Leonardo DiCaprio is "getting to know" supermodel Gigi Hadid following his split with longtime ex-girlfriend Camila Morrone.

## Liberal media outlet skewered for blasting Rubio’s mockery of ‘pregnant men’: ‘you guys just failed biology’
 - [https://www.foxnews.com/media/liberal-media-outlet-skewered-blasting-rubios-mockery-pregnant-men-you-guys-just-failed-biology](https://www.foxnews.com/media/liberal-media-outlet-skewered-blasting-rubios-mockery-pregnant-men-you-guys-just-failed-biology)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 16:13:36+00:00

Liberal outlet The Recount was torched on Twitter for condemning Sen. Marco Rubio, R-Fla., after the Republican said men cannot get pregnant during a recent speech.

## 'Woke' Department of Defense equity chief writes anti-White posts: 'Exhausted with these white folx'
 - [https://www.foxnews.com/media/woke-department-defense-equity-chief-writes-anti-white-posts-exhausted-white-folx](https://www.foxnews.com/media/woke-department-defense-equity-chief-writes-anti-white-posts-exhausted-white-folx)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 16:01:11+00:00

A diversity chief at the U.S. Department of Defense has posted several disparaging comments about White people on Twitter, Fox News Digital has learned.

## New Hampshire Primary: Republican voters sound off on Biden, abortion, student debt handouts
 - [https://www.foxnews.com/media/new-hampshire-primary-republican-voters-sound-off-biden-abortion-student-debt-handouts](https://www.foxnews.com/media/new-hampshire-primary-republican-voters-sound-off-biden-abortion-student-debt-handouts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 16:00:42+00:00

New Hampshire Republicans gave exclusive interviews to Fox News Digital on President Biden, abortion and student loan handouts ahead of the state's primary election.

## Youngkin slams VA Dems for 'desperate' attack on his campaigning for GOP midterm candidates
 - [https://www.foxnews.com/politics/youngkin-slams-va-dems-desperate-attack-his-campaigning-gop-midterm-candidates](https://www.foxnews.com/politics/youngkin-slams-va-dems-desperate-attack-his-campaigning-gop-midterm-candidates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 15:46:35+00:00

Virginia Republican Governor Glenn Youngkin blasted his state's Democrats for their "desperate" attacks on his campaigning in support for GOP candidates across America.

## Kyle Busch leaves Joe Gibbs Racing in rearview, joins Richard Childress for 2023
 - [https://www.foxnews.com/sports/kyle-busch-leaves-joe-gibbs-racing-rearview-joins-richard-childress-2023](https://www.foxnews.com/sports/kyle-busch-leaves-joe-gibbs-racing-rearview-joins-richard-childress-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 15:43:42+00:00

Kyle Busch found a home for the 2023 season, leaving Joe Gibbs Racing in the dust and bringing his winning ways to Richard Childress Racing.

## Migrants killing dogs, stealing from homes prompts some Texas border town residents to arm themselves
 - [https://www.foxnews.com/us/migrants-killing-dogs-stealing-from-homes-prompts-texas-border-town-residents-arm-themselves](https://www.foxnews.com/us/migrants-killing-dogs-stealing-from-homes-prompts-texas-border-town-residents-arm-themselves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 15:39:28+00:00

Eagle Pass, Texas, residents share how mass illegal migration has made them feel unsafe in their small town following robberies, break-ins and pet killings.

## Senate Republicans look to protect Americans earning less than $400k from IRS audits
 - [https://www.foxnews.com/us/senate-republicans-protect-americans-earning-less-than-400k-irs-audits](https://www.foxnews.com/us/senate-republicans-protect-americans-earning-less-than-400k-irs-audits)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 15:38:54+00:00

Republicans worry that billions of dollars in new IRS funding will mean headaches for Americans across the country.

## Missouri looter faces sentencing in murder of retired St. Louis police captain during 2020 George Floyd riots
 - [https://www.foxnews.com/us/missouri-looter-faces-sentencing-murder-retired-st-louis-police-captain-during-george-floyd-riots](https://www.foxnews.com/us/missouri-looter-faces-sentencing-murder-retired-st-louis-police-captain-during-george-floyd-riots)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 15:37:56+00:00

The Missouri looter convicted of the murder of retired St. Louis police Capt. David Dorn during a night of rioting after George Floyd's death is to be sentenced on Tuesday.

## Steve Doocy and his dad, high stakes midterms and more Fox News Opinion
 - [https://www.foxnews.com/opinion/steve-doocy-his-dad-high-stakes-midterms](https://www.foxnews.com/opinion/steve-doocy-his-dad-high-stakes-midterms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 15:36:53+00:00

Read the latest Fox News Opinion columns and watch videos from Tucker Carlson, Sean Hannity, Laura Ingraham and more.

## Pearl Harbor sailor to be buried in Arlington National Cemeterymore than 80 years after death
 - [https://www.foxnews.com/us/pearl-harbor-sailor-buried-arlington-national-cemetery-more-80-years-death](https://www.foxnews.com/us/pearl-harbor-sailor-buried-arlington-national-cemetery-more-80-years-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 15:34:42+00:00

Herbert Jacobson, a U.S. sailor, is being buried 80 years after his death. Jacobson was among the 400 sailors who lost their lives on the USS Oklahoma during the Pearl harbor attack.

## DOJ issues more than 30 subpoenas to Trump associates: source
 - [https://www.foxnews.com/us/doj-issues-more-than-30-subpoenas-trump-associates-source](https://www.foxnews.com/us/doj-issues-more-than-30-subpoenas-trump-associates-source)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 15:33:50+00:00

The Department of Justice issued over 30 subpoenas to allies of former President Donald Trump as part of an investigation into his claims that the 2020 presidential election was rigged.

## Pastor Max Lucado shares message of hope for the weary in new faith book
 - [https://www.foxnews.com/lifestyle/pastor-max-lucado-shares-message-hope-weary-new-faith-book](https://www.foxnews.com/lifestyle/pastor-max-lucado-shares-message-hope-weary-new-faith-book)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 15:31:12+00:00

Pastor Max Lucado joined "Fox & Friends" on Tuesday, Sept. 13, 2022, to talk about his new book "Help Is Here," which encourages readers to look for the Holy Spirit in times of need.

## Delaware Democratic primary voters to decide if state auditor deserves a chance at re-election in November
 - [https://www.foxnews.com/us/delaware-democratic-primary-voters-decide-state-auditor-deserves-chance-re-election-november](https://www.foxnews.com/us/delaware-democratic-primary-voters-decide-state-auditor-deserves-chance-re-election-november)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 15:31:03+00:00

A DE incumbent state auditor is up for re-election. Delaware voters can decide if the auditor, who is awaiting criminal charges for corruption, deserves to be re-elected in November.

## Broncos' Russell Wilson backs 64-yard field goal attempt: ‘I believe in coach Hackett’
 - [https://www.foxnews.com/sports/broncos-russell-wilson-backs-64-yard-field-goal-attempt-i-believe-in-coach-hackett](https://www.foxnews.com/sports/broncos-russell-wilson-backs-64-yard-field-goal-attempt-i-believe-in-coach-hackett)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 14:42:08+00:00

Denver Broncos quarterback Russell Wilson backed the decision by head coach Nathaniel Hackett to attempt a 64-yard field goal with 20 seconds left in the game.

## Texas man accused of pistol-whipping victim, dumping him at gas station naked
 - [https://www.foxnews.com/us/texas-man-accused-pistol-whipping-victim-dumping-him-gas-station-naked](https://www.foxnews.com/us/texas-man-accused-pistol-whipping-victim-dumping-him-gas-station-naked)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 14:41:56+00:00

A man in Texas was arrested Monday for his alleged involvement in the kidnapping of a teenage boy that involved pistol-whipping the victim and leaving him naked at a convenience store.

## What's at stake for Republicans, Democrats in midterms now that primary election season is over
 - [https://www.foxnews.com/opinion/stake-republicans-democrats-midterms-primary-election-season-over](https://www.foxnews.com/opinion/stake-republicans-democrats-midterms-primary-election-season-over)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 14:41:45+00:00

The November midterm elections are just 56 days away. The primary election season wraps up this week.The big question that looms over the midterms is are you better off under Biden?

## Washington Post fact-checker calls out Biden’s ‘flimsy’ claim he has the strongest manufacturing jobs record
 - [https://www.foxnews.com/media/washington-post-fact-checker-calls-out-bidens-flimsy-claim-strongest-manufacturing-jobs-record](https://www.foxnews.com/media/washington-post-fact-checker-calls-out-bidens-flimsy-claim-strongest-manufacturing-jobs-record)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 14:41:29+00:00

The Washington Post's Glenn Kessler said President Biden's claim about having the strongest record for manufacturing jobs in modern history was "flimsy."

## Schumer-Manchin energy permitting plan teeters in Senate ahead of key government funding deadline
 - [https://www.foxnews.com/politics/schumer-manchin-energy-permitting-plan-teeters-senate-ahead-key-government-funding-deadline](https://www.foxnews.com/politics/schumer-manchin-energy-permitting-plan-teeters-senate-ahead-key-government-funding-deadline)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 14:41:25+00:00

A deal between Sen. Joe Manchin and Majority Leader Chuck Schumer on energy permitting reform may be in jeopardy amid opposition from both Republicans and progressives in the Senate.

## Air quality in Montana deteriorates due to wildfire smoke
 - [https://www.foxnews.com/us/air-quality-montana-deteriorates-wildfire-smoke](https://www.foxnews.com/us/air-quality-montana-deteriorates-wildfire-smoke)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 14:40:38+00:00

The Montana Department of Environmental Quality warned residents on Monday that wildfire smoke had contributed to unhealthy air quality levels in western counties.

## California sheriff says fentanyl an 'urgent public health crisis' after middle school teacher nearly poisoned
 - [https://www.foxnews.com/media/california-sheriff-fentanyl-urgent-public-health-crisis-middle-school-teacher-nearly-poisoned](https://www.foxnews.com/media/california-sheriff-fentanyl-urgent-public-health-crisis-middle-school-teacher-nearly-poisoned)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 14:36:38+00:00

Tulare County Sheriff Mike Boudreaux said a California teacher accidentally inhaled fentanyl after a 13-year-old was found at school with 150 pills.

## Dolly Parton's Dollywood wins 3 Golden Ticket Awards
 - [https://www.foxnews.com/travel/dolly-partons-dollywood-wins-3-golden-ticket-awards](https://www.foxnews.com/travel/dolly-partons-dollywood-wins-3-golden-ticket-awards)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 14:28:55+00:00

Dollywood, the Tennessee theme park owned by singer Dolly Parton, won three industry awards for the best kids’ area, the best guest experience and the best Christmas event.

## Leo Terrell calls out 'dangerous' indoctrination: Public schools being 'hijacked by the far left'
 - [https://www.foxnews.com/media/leo-terrell-calls-dangerous-indoctrination-public-schools-hijacked-far-left](https://www.foxnews.com/media/leo-terrell-calls-dangerous-indoctrination-public-schools-hijacked-far-left)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 14:15:44+00:00

Former school teacher Leo Terrell lays out the dangers of Democratic talking points being injected increasingly into the public school system.

## Video shows Prince Andrew heckler getting arrested as crowd chants ‘God save the king’
 - [https://www.foxnews.com/world/video-shows-prince-andrew-heckler-arrested-crowd-chants-god-save-the-king](https://www.foxnews.com/world/video-shows-prince-andrew-heckler-arrested-crowd-chants-god-save-the-king)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 13:44:04+00:00

A young man in Scotland was detained by police after heckling Prince Andrew as a "sick old man" during the procession of Queen Elizabeth II's body in Edinburgh.

## Illegal immigrants who entered US since Biden took office to cost taxpayers $20+ billion a year: analysis
 - [https://www.foxnews.com/politics/illegal-immigrants-entered-us-biden-took-office-cost-taxpayers-20-billion-year-analysis](https://www.foxnews.com/politics/illegal-immigrants-entered-us-biden-took-office-cost-taxpayers-20-billion-year-analysis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 13:39:52+00:00

An analysis by a hawkish immigration group find that the illegal immigrants released or who evaded Border Patrol will cost taxpayers tens of billions of dollars a year.

## Australian man killed by kangaroo, first fatal attack in over 85 years
 - [https://www.foxnews.com/world/australian-man-killed-kangaroo-first-fatal-attack-over-85-years](https://www.foxnews.com/world/australian-man-killed-kangaroo-first-fatal-attack-over-85-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 13:33:49+00:00

A 77-year-old Australian man was attacked and killed by a kangaroo over the weekend. Authorities said it was believed the victim had been keeping it as a pet.

## Army suggests food stamps for soldiers battling inflation
 - [https://www.foxnews.com/us/army-suggests-food-stamps-soldiers-battling-inflation](https://www.foxnews.com/us/army-suggests-food-stamps-soldiers-battling-inflation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 13:23:15+00:00

Guidance from the U.S. Army for soldiers struggling with inflation suggests that eligible service members and families apply for the Supplemental Nutrition Assistance Program.

## Ukraine's soldiers inch toward Sievierodonetsk in major counteroffensive
 - [https://www.foxnews.com/world/ukraines-soldiers-inch-toward-sievierodonetsk-major-counteroffensive](https://www.foxnews.com/world/ukraines-soldiers-inch-toward-sievierodonetsk-major-counteroffensive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 13:20:23+00:00

Russia forces have apparently withdrawn from some cities and towns in Ukraine's eastern Luhansk region, which it has largely occupied since the war began.

## Giants' Gabe Kapler, Zack Littell involved in tense exchange during win over Braves
 - [https://www.foxnews.com/sports/giants-gabe-kapler-zack-littell-involved-tense-exchange-win-braves](https://www.foxnews.com/sports/giants-gabe-kapler-zack-littell-involved-tense-exchange-win-braves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 13:18:59+00:00

San Francisco Giants manager Gabe Kapler appeared to have a tense moment with pitcher Zack Littell toward the end of their win against the Atlanta Braves on Monday night.

## North Carolina's lottery numbers for Monday, Sept. 12
 - [https://www.foxnews.com/us/north-carolinas-lottery-numbers-monday-sept-12](https://www.foxnews.com/us/north-carolinas-lottery-numbers-monday-sept-12)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 13:15:35+00:00

Mega Millions jackpot is $231,000,000 and Powerball reaches $206,000,000. North Carolina's Lucky For Life lottery numbers for Monday, Sept. 12 are 4-6-16-41-46, Lucky Ball: 11

## Seahawks' Shelby Harris relishes win against former team
 - [https://www.foxnews.com/sports/seahawks-shelby-harris-relishes-win-against-former-team](https://www.foxnews.com/sports/seahawks-shelby-harris-relishes-win-against-former-team)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 13:12:46+00:00

Shelby Harris talked the talk after walking the walk in the Seattle Seahawks' victory over the Denver Broncos on Monday night to wrap up Week 1.

## Texas woman accused of killing 21-year-old, attempting to steal unborn baby
 - [https://www.foxnews.com/us/texas-woman-accused-of-killing-21-year-ol-attempting-to-steal-unborn-baby](https://www.foxnews.com/us/texas-woman-accused-of-killing-21-year-ol-attempting-to-steal-unborn-baby)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 13:11:34+00:00

A TX woman is being accused of homicide for allegedly killing a 21-year-old and using a scalpel to remove her unborn baby. Authorities believe she wanted to present the baby as her own.

## Tomi Lahren on 'Fox & Friends First': Vulnerable Dems running from Biden 'like the plague'
 - [https://www.foxnews.com/media/tomi-lahren-fox-friends-first-vulnerable-dems-running-biden-plague](https://www.foxnews.com/media/tomi-lahren-fox-friends-first-vulnerable-dems-running-biden-plague)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 12:53:31+00:00

Tomi Lahren explained why Democrats are distancing themselves from President Biden after Sen. Mark Kelly struggled to assess the administration's performance.

## Steve Doocy is cooking up something all fans will enjoy with new recipes, Fox Nation interactive event
 - [https://www.foxnews.com/media/steve-doocy-cooking-something-fans-enjoy-new-recipes-fox-nation-interactive-event](https://www.foxnews.com/media/steve-doocy-cooking-something-fans-enjoy-new-recipes-fox-nation-interactive-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 12:47:31+00:00

You're invited: Fox & Friends co-host Steve Doocy releases his new "Simply Happy Cookbook" and will host an accompanying live virtual cookalong event on Fox Nation.

## 2022 primary season concludes with fiery Republican face-offs in battleground New Hampshire
 - [https://www.foxnews.com/politics/2022-primary-season-concludes-fiery-republican-faceoffs-battleground-new-hampshire](https://www.foxnews.com/politics/2022-primary-season-concludes-fiery-republican-faceoffs-battleground-new-hampshire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 12:36:17+00:00

Trump's not on the ballot, but he's part of the conversation, as New Hampshire, Rhode Island and Delaware hold the final nominating primaries of the 2022 election cycle

## Memphis shooting spree suspect Ezekiel Kelly back in court following livestreamed attacks
 - [https://www.foxnews.com/us/memphis-shooting-spree-suspect-ezekiel-kelly-back-court-following-livestreamed-attacks](https://www.foxnews.com/us/memphis-shooting-spree-suspect-ezekiel-kelly-back-court-following-livestreamed-attacks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 12:28:54+00:00

Accused Memphis mass shooter Ezekiel Kelly, 19, returned to court Tuesday in connection with a city-wide shooting spree that killed four and injured three.

## Memphis shooting spree suspect Ezekiel Kelly due in court following livestreamed attacks
 - [https://www.foxnews.com/us/memphis-shooting-spree-suspect-ezekiel-kelly-due-court-following-livestreamed-attacks](https://www.foxnews.com/us/memphis-shooting-spree-suspect-ezekiel-kelly-due-court-following-livestreamed-attacks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 12:28:54+00:00

Accused Memphis mass shooter Ezekiel Kelly, 19, returns to court Tuesday in connection with a city-wide shooting spree that killed four and injured three.

## Chuck Schumer offers up $15 million to bolster Democratic Senate campaigns
 - [https://www.foxnews.com/politics/chuck-schumer-offers-fifteen-million-bolster-democratic-senate-campaigns](https://www.foxnews.com/politics/chuck-schumer-offers-fifteen-million-bolster-democratic-senate-campaigns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 12:25:41+00:00

Chuck Schumer injected $15 million into Democratic senatorial campaigns across the country Tuesday. The Senate is split 50-50 and Republicans are now only slightly favored.

## Seattle teachers strike: Tentative deal reached
 - [https://www.foxnews.com/us/seattle-teachers-strike-tentative-deal-reached](https://www.foxnews.com/us/seattle-teachers-strike-tentative-deal-reached)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 12:24:03+00:00

A tentative deal was announced late Tuesday night between Seattle Public Schools and the Seattle Education Association after a union strike that began last week.

## Texas' lottery numbers for Monday, Sept. 12
 - [https://www.foxnews.com/us/texas-lottery-numbers-monday-sept-12](https://www.foxnews.com/us/texas-lottery-numbers-monday-sept-12)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 12:23:53+00:00

The Mega Million's estimated jackpot is $231,000,000. The Powerball estimated jackpot is $206,000,000. The Cash 5 numbers for Monday, Sept. 12 are 01-02-13-21-24.

## Ohio's lottery numbers for Monday, Sept. 12
 - [https://www.foxnews.com/us/ohios-lottery-numbers-monday-sept-12](https://www.foxnews.com/us/ohios-lottery-numbers-monday-sept-12)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 12:16:48+00:00

The Mega Million's estimated jackpot is $231,000,000. The Powerball estimated jackpot is $206,000,000. The Classic Lotto numbers for Monday, Sept. 12 are 19-24-26-28-32-48.

## Jacob Elordi cast as the next Elvis Presley in new Sofia Coppola movie 'Priscilla'
 - [https://www.foxnews.com/entertainment/jacob-elordi-cast-next-elvis-presley-new-sofia-coppola-movie-priscilla](https://www.foxnews.com/entertainment/jacob-elordi-cast-next-elvis-presley-new-sofia-coppola-movie-priscilla)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 12:16:16+00:00

Jacob Elordi has been cast as Elvis Presley in Sofia Coppola's upcoming film "Priscilla." He will star alongside Cailee Spaeny, who will play Priscilla Presley.

## New Jersey's lottery numbers for Monday, Sept. 12
 - [https://www.foxnews.com/us/new-jerseys-lottery-numbers-monday-sept-12](https://www.foxnews.com/us/new-jerseys-lottery-numbers-monday-sept-12)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 12:15:59+00:00

The Mega Million's estimated jackpot is $231,000,000. The Powerball estimated jackpot is $206,000,000. The Cash4Life numbers for Monday, Sept. 12 are 21-31-37-42-60.

## China's growing dominance in Latin America a problem, experts say
 - [https://www.foxnews.com/world/chinas-growing-dominance-latin-america-problem-experts-say](https://www.foxnews.com/world/chinas-growing-dominance-latin-america-problem-experts-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 11:50:36+00:00

From Mexico to Argentina, China seeks to increase its sphere of influence through the Western Hemisphere far beyond economic, political and technological issues

## William Ruto sworn in as Kenya's president after close vote
 - [https://www.foxnews.com/world/william-ruto-sworn-in-kenya-president-close-vote](https://www.foxnews.com/world/william-ruto-sworn-in-kenya-president-close-vote)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 11:45:39+00:00

Kenya's new president, William Ruto, was sworn in on Tuesday, with citizens initially breaking into chaos to enter the packed stadium.

## Illinois lawmaker says some Dems regret voting to end cash bail: 'Too much, too soon'
 - [https://www.foxnews.com/media/illinois-lawmaker-dems-regret-voting-end-cash-bail-much-soon](https://www.foxnews.com/media/illinois-lawmaker-dems-regret-voting-end-cash-bail-much-soon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 11:39:28+00:00

Illinois State Rep. Patrick Windhorst (R) warned some lawmakers already regret voting to end cash bail by supporting the Safe-T Act.

## Washington Post Editorial Board calls out Fetterman campaign, demands he attend debate
 - [https://www.foxnews.com/media/washington-post-editorial-board-calls-out-fetterman-campaign-demands-attend-debate](https://www.foxnews.com/media/washington-post-editorial-board-calls-out-fetterman-campaign-demands-attend-debate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 11:39:07+00:00

The Washington Post Editorial Board called out Pennsylvania Senate candidate John Fetterman, urging him to debate in order to demonstrate his ability to hold office.

## NFL power rankings: Bills, Chiefs among the top teams in league through Week 1
 - [https://www.foxnews.com/sports/nfl-power-rankings-bills-chiefs-top-teams-league-through-week-1](https://www.foxnews.com/sports/nfl-power-rankings-bills-chiefs-top-teams-league-through-week-1)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 11:05:45+00:00

Josh Allen and the Buffalo Bills put together a statement win over the Los Angeles Rams on Thursday night and are starting off the season as the best team in the NFL.

## Hillary Clinton claims 'no one is above the law'—except her
 - [https://www.foxnews.com/opinion/hillary-clinton-claims-no-one-above-law-except-her](https://www.foxnews.com/opinion/hillary-clinton-claims-no-one-above-law-except-her)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 11:00:59+00:00

Hillary Clinton can’t resist insinuating herself into the Donald Trump classified documents debate.

## Republicans, focus midterms on Biden errors and don't say anything stupid
 - [https://www.foxnews.com/opinion/republicans-focus-midterms-biden-errors-dont-say-anything-stupid](https://www.foxnews.com/opinion/republicans-focus-midterms-biden-errors-dont-say-anything-stupid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 11:00:41+00:00

The midterms should be about President Biden's dismal record, but we how have a choice election with a Republican brand that has seen much better days.

## Sen. Marco Rubio suggests Trump should compete in GOP primary if former POTUS runs in 2024
 - [https://www.foxnews.com/media/sen-marco-rubio-suggests-trump-should-compete-in-gop-primary-if-former-potus-runs-in-2024](https://www.foxnews.com/media/sen-marco-rubio-suggests-trump-should-compete-in-gop-primary-if-former-potus-runs-in-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 11:00:37+00:00

Speaking with Fox News Digital, Sen. Marco Rubio predicts former President Trump will be the GOP nominee if he runs in 2024 but suggests he shouldn't be afraid of a primary challenge.

## Prince Harry and Meghan Markle's bombshell claims, unprecedented migrant directive and more top headlines
 - [https://www.foxnews.com/us/prince-harry-meghan-markle-bombshell-claims-royal-family](https://www.foxnews.com/us/prince-harry-meghan-markle-bombshell-claims-royal-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 10:27:11+00:00

ROYAL REGRETS? - Prince Harry and Meghan Markle‘s bombshell claims about the monarchy

## Fans complain that Emmy Awards snubbed Queen Elizabeth II from 'In Memoriam' segment
 - [https://www.foxnews.com/entertainment/fans-complain-emmy-awards-snubbed-queen-elizabeth-ii-from-memoriam-segment](https://www.foxnews.com/entertainment/fans-complain-emmy-awards-snubbed-queen-elizabeth-ii-from-memoriam-segment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 10:27:05+00:00

Bewildered fans of "The Crown" took to social media to complain that the 74th Primetime Emmy Awards did not mention the death of Queen Elizabeth II during its "In Memoriam" segment.

## Democrats meddle in another key GOP primary, but this time Republican PAC spend big to offset their effort
 - [https://www.foxnews.com/politics/democrats-meddle-another-key-gop-primary-republicans-spending-big-offset-their-effort](https://www.foxnews.com/politics/democrats-meddle-another-key-gop-primary-republicans-spending-big-offset-their-effort)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 10:23:26+00:00

Democrats are meddling in another Republican primary race, while a Republican PAC is combatting their efforts to elect a candidate they believe has the best chance at winning this fall.

## Iconic French director Jean-Luc Godard dies at age 91
 - [https://www.foxnews.com/entertainment/iconic-french-director-jean-luc-godard-dies-age-91](https://www.foxnews.com/entertainment/iconic-french-director-jean-luc-godard-dies-age-91)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 10:05:24+00:00

French New Wave director Jean-Luc Godard died at the age of 91, leaving an artistic legacy that influenced directors such as Quentin Tarantino and Martin Scorsese.

## Biden's VA undermining law that gives veterans access to private health care
 - [https://www.foxnews.com/us/bidens-va-undermining-law-gives-veterans-access-private-health-care](https://www.foxnews.com/us/bidens-va-undermining-law-gives-veterans-access-private-health-care)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 10:00:45+00:00

The Biden administration is looking to pare back a bipartisan law signed by President Trump to give veterans more health care choices.

## Liberal Chicago city councilmember decries intense crime wave: 'A joke'
 - [https://www.foxnews.com/us/liberal-chicago-city-councilmember-decries-intense-crime-wave-joke](https://www.foxnews.com/us/liberal-chicago-city-councilmember-decries-intense-crime-wave-joke)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 10:00:27+00:00

The liberal deputy floor leader of Chicago City Council blasted the increased crime in the city, saying public safety 'was a joke' and questioned why citizens bother calling the police.

## LA Times op-ed claims America 'fueled the rise of Nazism and the Holocaust'
 - [https://www.foxnews.com/media/la-times-ep-ed-claims-america-fueled-rise-nazism-holocaust](https://www.foxnews.com/media/la-times-ep-ed-claims-america-fueled-rise-nazism-holocaust)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 09:00:18+00:00

An opinion piece in the Los Angeles Times argued that Americans originally helped to promote the rise of Nazism and even the Holocaust in the 1930s and 1940s.

## Car bomb explodes at Washington funeral, police search for suspect
 - [https://www.foxnews.com/us/car-bomb-explodes-washington-funeral-police-search-suspect](https://www.foxnews.com/us/car-bomb-explodes-washington-funeral-police-search-suspect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 08:55:55+00:00

Police in Auburn, Washington, are searching for a suspect who allegedly placed a bomb in a car during a funeral at Mountain View Cemetery on August 23.

## Georgia rape suspect busted thanks to location sharing app, alligator sign
 - [https://www.foxnews.com/us/georgia-rape-suspect-busted-thanks-location-sharing-app-alligator-sign](https://www.foxnews.com/us/georgia-rape-suspect-busted-thanks-location-sharing-app-alligator-sign)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 08:31:14+00:00

A 17-year-old girl was able to use a smartphone app and alligator sign to alert authorities to her location after a man allegedly raped her in Georgia.

## Texas police union fumes over bond for alleged cop-killing repeat offenders: 'Absolutely foolish'
 - [https://www.foxnews.com/us/texas-police-fume-bail-bonds-alleged-cop-killing-repeat-offenders-absolutely-foolish](https://www.foxnews.com/us/texas-police-fume-bail-bonds-alleged-cop-killing-repeat-offenders-absolutely-foolish)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 07:20:06+00:00

The Houston Police Officers' Union criticized a judge's decision to set bail for two men accused of killing a deputy while they were out on bond for previous murder charges.

## Latest Trump-Biden clashes help illuminate the fascination with a queen
 - [https://www.foxnews.com/media/latest-trump-biden-clashes-help-illuminate-fascination-queen](https://www.foxnews.com/media/latest-trump-biden-clashes-help-illuminate-fascination-queen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 07:07:29+00:00

Britain’s parliamentary system is just as messy and chaotic as in most other places but for seven decades, the queen managed to float above all that.

## Nearly every major fact-checker has completely ignored Karine Jean-Pierre since taking over for Psaki
 - [https://www.foxnews.com/media/nearly-every-major-fact-checker-completely-ignored-karine-jean-pierre-since-taking-over-psaki](https://www.foxnews.com/media/nearly-every-major-fact-checker-completely-ignored-karine-jean-pierre-since-taking-over-psaki)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 06:00:51+00:00

White House press secretary Karine Jean-Pierre has never been fact-checked by Reuter, The Associated Press, Factcheck.org, Daniel Dale, and Glenn Kessler.

## Portlanders are taking precautions to avoid being attacked in response to rising crime
 - [https://www.foxnews.com/us/portlanders-taking-precautions-avoid-attacked-response-rising-crime](https://www.foxnews.com/us/portlanders-taking-precautions-avoid-attacked-response-rising-crime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 06:00:42+00:00

Some Portland residents worry about being physically attacked while walking in the city or encountering someone dealing with mental health or drug issues.

## Democrat-run tourist town in North Carolina sees violent crime spike as police dwindle: 'Perfect storm'
 - [https://www.foxnews.com/us/democrat-run-tourist-town-north-carolina-sees-violent-crime-spike-as-police-dwindle-perfect-storm](https://www.foxnews.com/us/democrat-run-tourist-town-north-carolina-sees-violent-crime-spike-as-police-dwindle-perfect-storm)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 06:00:36+00:00

Multiple local law enforcement sources who spoke to Fox News Digital blamed rising violent crime in Asheville, N.C., on Democratic political leadership and left-wing activists.

## Border Patrol chief says memo clearing migrant release into US after Title 42 end is unprecedented
 - [https://www.foxnews.com/politics/border-patrol-chief-says-memo-clearing-migrant-release-title-42-end-unprecedented](https://www.foxnews.com/politics/border-patrol-chief-says-memo-clearing-migrant-release-title-42-end-unprecedented)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 06:00:14+00:00

Border Patrol Chief Raul Ortiz confirmed an internal memo allowing agents to release illegal aliens into the U.S. was unprecedented for the agency, said it deals with possible Title 42 rollback.

## Biden's proposed Title IX re-write fails the test
 - [https://www.foxnews.com/opinion/biden-proposed-title-ix-re-write-fails-test](https://www.foxnews.com/opinion/biden-proposed-title-ix-re-write-fails-test)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 06:00:12+00:00

The Biden administration’s proposed re-write of Title IX would only advance an extreme political agenda over doing what’s right for students.

## Prince Harry, Meghan's harsh comments and bombshell claims about the royal family: Do they have royal regrets?
 - [https://www.foxnews.com/entertainment/prince-harry-meghan-markle-harsh-comments-bombshell-claims-royal-family-regrets](https://www.foxnews.com/entertainment/prince-harry-meghan-markle-harsh-comments-bombshell-claims-royal-family-regrets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 06:00:09+00:00

Prince Harry and Meghan Markle have been outspoken since they stepped down from their royal roles in 2020 about how they feel towards the royal family and the British media.

## Oregon boy, 5, celebrates 'superhero heart' after he was born with 'Swiss cheese' defect
 - [https://www.foxnews.com/lifestyle/oregon-boy-5-celebrates-superhero-heart-born-swiss-cheese-defect](https://www.foxnews.com/lifestyle/oregon-boy-5-celebrates-superhero-heart-born-swiss-cheese-defect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 06:00:01+00:00

Maverick Waler, 5, of Redmond, Oregon, underwent a cutting-edge procedure in New York City to close multiple holes in his heart – and his dad, Brad Waler, shared the story with Fox News Digital.

## Minnesota squirrel causes power outage for more than 9,000 residents
 - [https://www.foxnews.com/us/minnesota-squirrel-causes-power-outage-more-than-9000-residents](https://www.foxnews.com/us/minnesota-squirrel-causes-power-outage-more-than-9000-residents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 05:19:51+00:00

Nearly 10,000 people were left without power in Minneapolis, Minnesota, on Sunday after a squirrel disrupted a power transmission, according to energy provider Xcel.

## Geno Smith spoils Russell Wilson's return to Seattle as Seahawks upset Broncos
 - [https://www.foxnews.com/sports/geno-smith-spoils-russell-wilsons-return-seahawks-upset-broncos](https://www.foxnews.com/sports/geno-smith-spoils-russell-wilsons-return-seahawks-upset-broncos)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 04:42:02+00:00

A 64-yard field goal went just left enough for the Seattle Seahawks to beat Russell Wilson and the Denver Broncos on Monday Night Football.

## GREG GUTFELD: The mainstream media hates regular Americans
 - [https://www.foxnews.com/opinion/greg-gutfeld-the-mainstream-media-hates-regular-americans](https://www.foxnews.com/opinion/greg-gutfeld-the-mainstream-media-hates-regular-americans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 04:39:21+00:00

Greg Gutfeld discusses how progressives try to tear down anything that unifies America and suggests that he can be more unifying than the left on "Gutfeld!"

## Jamie Lissow: You gotta do some research before destroying someone's life
 - [https://www.foxnews.com/media/jamie-lissow-you-gotta-do-some-research-before-destroying-someones-life](https://www.foxnews.com/media/jamie-lissow-you-gotta-do-some-research-before-destroying-someones-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 04:30:02+00:00

Jamie Lissow discusses with Fox News host Greg Gutfeld and guests the controversy over an alleged racial slur at a BYU volleyball game on "Gutfeld!"

## When China buys US farmland, they hear 'this place is open': Geoffrey Cain
 - [https://www.foxnews.com/media/china-buys-farmland-hear-place-open-geoffrey-cain](https://www.foxnews.com/media/china-buys-farmland-hear-place-open-geoffrey-cain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 04:14:21+00:00

Fox News host Laura Ingraham spoke with two members of the Lincoln Network about China's large purchases of U.S. farmland in several states on "The Ingraham Angle."

## Laura Ingraham rips Hillary Clinton over 'Gutsy' series
 - [https://www.foxnews.com/media/laura-ingraham-rips-hillary-clinton-over-gutsy-series](https://www.foxnews.com/media/laura-ingraham-rips-hillary-clinton-over-gutsy-series)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 04:08:24+00:00

Fox News host Laura Ingraham slammed Hillary and Chelsea Clinton over the guests they have featured on their new docuseries on "The Ingraham Angle."

## On this day in history, Sept. 13, 1857, milk chocolate magnate Milton Hershey born in PA
 - [https://www.foxnews.com/lifestyle/this-day-history-sept-13-1857-milk-chocolate-magnate-milton-hershey-born-pa](https://www.foxnews.com/lifestyle/this-day-history-sept-13-1857-milk-chocolate-magnate-milton-hershey-born-pa)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 04:02:02+00:00

American entrepreneur Milton S. Hershey was born in a Mennonite community in Derry Township, Penn., on this day in history, Sept. 13, 1857. He built the iconic Hershey chocolate brand.

## Women, minorities breaking Democratic gun-owner stereotype amid nationwide crime wave, Travis says
 - [https://www.foxnews.com/media/women-minorities-breaking-democratic-gun-owner-stereotype-amid-nationwide-crime-wave-travis](https://www.foxnews.com/media/women-minorities-breaking-democratic-gun-owner-stereotype-amid-nationwide-crime-wave-travis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 03:18:46+00:00

Liberal Democratic Rep. Karen Bass of California, running for Los Angeles mayor, had her house robbed and claimed only her guns were stolen by the criminals.

## Emmys 2022: Complete list of winners
 - [https://www.foxnews.com/entertainment/emmys-2022-complete-list-of-winners](https://www.foxnews.com/entertainment/emmys-2022-complete-list-of-winners)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 03:04:30+00:00

The 2022 Emmy Awards are here. Here is a full list of the 2022 Emmy award winners.

## LAURA INGRAHAM: This is sort of a reverse Robin Hood situation
 - [https://www.foxnews.com/media/laura-ingraham-sort-of-reverse-robin-hood-situation](https://www.foxnews.com/media/laura-ingraham-sort-of-reverse-robin-hood-situation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:59:55+00:00

Laura Ingraham discusses how the Left encouraging their green energy agenda only means that Americans will have less in their pockets on "The Ingraham Angle."

## NPR report defends ESG, says Republicans are 'trying to score political points'
 - [https://www.foxnews.com/media/npr-report-defends-esg-says-republicans-trying-score-political-points](https://www.foxnews.com/media/npr-report-defends-esg-says-republicans-trying-score-political-points)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:55:36+00:00

NPR published a news report by its "climate and corporations correspondent" slamming Republicans as opposing ESG policies for their own political benefit.

## Gov. Greg Abbott on increased border crossings: 'This is Biden's fault pure and simple'
 - [https://www.foxnews.com/media/gov-greg-abbott-increased-border-crossings-bidens-fault-pure-simple](https://www.foxnews.com/media/gov-greg-abbott-increased-border-crossings-bidens-fault-pure-simple)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:50:07+00:00

Fox News host Jesse Watters spoke with Texas Gov. Greg Abbott about Chicago Mayor Lori Lightfoot questioning his Christian faith after he bussed migrants to her city.

## Mike Huckabee: GOP needs to stop being afraid of issues like abortion
 - [https://www.foxnews.com/media/mike-huckabee-gop-needs-stop-being-afraid-issues-abortion](https://www.foxnews.com/media/mike-huckabee-gop-needs-stop-being-afraid-issues-abortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:48:57+00:00

Former Arkansas governor Mike Huckabee joined "Hannity" to push back on President Joe Biden's recent characterization of "MAGA" supporters.

## Ted Cruz: Dems have no plan for inflation other than to make it worse
 - [https://www.foxnews.com/media/ted-cruz-dems-no-plan-inflation-make-worse](https://www.foxnews.com/media/ted-cruz-dems-no-plan-inflation-make-worse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:45:47+00:00

Fox News host Sean Hannity spoke with Texas Sen. Ted Cruz about the differences in midterm strategies between the Republican and Democrat Party on 'Hannity.'

## TUCKER CARLSON: Drawing a parallel between January 6 protests and fall of the Twin towers — true lunacy
 - [https://www.foxnews.com/opinion/tucker-carlson-drawing-parallel-between-january-6-protests-fall-twin-towers-true-lunacy](https://www.foxnews.com/opinion/tucker-carlson-drawing-parallel-between-january-6-protests-fall-twin-towers-true-lunacy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:41:15+00:00

Fox News host Tucker Carlson reacts to various lawmakers who politicized the mark of 21 years since the September 11 terrorist attacks on the United States.

## Jennifer Rubin claims ‘tone-deaf’ Supreme Court destroyed ‘its own integrity,’ calls for court packing
 - [https://www.foxnews.com/media/jennifer-rubin-claims-tone-deaf-supreme-court-destroyed-own-integrity-calls-court-packing](https://www.foxnews.com/media/jennifer-rubin-claims-tone-deaf-supreme-court-destroyed-own-integrity-calls-court-packing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:36:57+00:00

Washington Post columnist Jennifer Rubin wrote a piece condemning Supreme Court members for their conduct and suggesting the institution must be overhauled for its own good.

## Lawyer for Britt Reid crash victim slams plea deal for ex-Chiefs coach
 - [https://www.foxnews.com/sports/lawyer-britt-reid-crash-victim-slams-plea-deal-ex-chiefs-coach](https://www.foxnews.com/sports/lawyer-britt-reid-crash-victim-slams-plea-deal-ex-chiefs-coach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:28:31+00:00

Former Kansas City Chiefs coach Britt Reid pleaded guilty to to felony driving while intoxicated resulting in serious physical injury stemming from a 2021 crash that left a girl serious injured.

## SEAN HANNITY: Democrats have dipped back into their 'election year playbook'
 - [https://www.foxnews.com/media/sean-hannity-democrats-dipped-into-election-year-playbook](https://www.foxnews.com/media/sean-hannity-democrats-dipped-into-election-year-playbook)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:21:17+00:00

Fox News host Sean Hannity discussed the primary issues Democrats will focus on as the November 2022 midterms elections rapidly approach on "Hannity."

## Joe Piscopo urges Americans not to forget about Sept. 11, as new generations grow up
 - [https://www.foxnews.com/media/joe-piscopo-urges-americans-not-forget-sept-eleventh-new-generations-grow-up](https://www.foxnews.com/media/joe-piscopo-urges-americans-not-forget-sept-eleventh-new-generations-grow-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:21:07+00:00

Salem radio host Joe Piscopo reflected Monday on the 21st anniversary of the 9/11 terror attacks, saying future generations must remember that day in history.

## Trump backer says FBI showed up at her home after she voiced support online
 - [https://www.foxnews.com/media/trump-backer-fbi-showed-up-home-voiced-support-online](https://www.foxnews.com/media/trump-backer-fbi-showed-up-home-voiced-support-online)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:06:14+00:00

Lisa Gallagher, a New Jersey resident who has been vocal in support of Trump, says she was visited by FBI agents at her home claiming to have an 'anonymous tip' against her.

## Steelers might not lose TJ Watt for rest of season: report
 - [https://www.foxnews.com/sports/steelers-might-not-lose-tj-watt-rest-season](https://www.foxnews.com/sports/steelers-might-not-lose-tj-watt-rest-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 02:00:29+00:00

The Pittsburgh Steelers might have to breathe a sigh of relief, as it's been reported that T.J. Watt might not be out for the season with his pectoral injury.

## Anderson Silva recreates special photo with Paul brothers, explains why he has 'respect' for YouTube stars
 - [https://www.foxnews.com/sports/anderson-silva-recreates-special-photo-paul-brothers-explains-why-he-has-respect-youtube-stars](https://www.foxnews.com/sports/anderson-silva-recreates-special-photo-paul-brothers-explains-why-he-has-respect-youtube-stars)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 01:55:39+00:00

Anderson Silva and Jake Paul's pre-fight press conference was toned down a bit more than previous newsers and the UFC legend even took a picture with Jake and his brother Logan.

## King Charles III, King George VI, and other notable royal family members: A look back on past kings
 - [https://www.foxnews.com/entertainment/king-charles-iii-king-george-vi-notable-royal-family-members-look-back-past-kings](https://www.foxnews.com/entertainment/king-charles-iii-king-george-vi-notable-royal-family-members-look-back-past-kings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 01:48:26+00:00

King Charles III became king following the death of his mother, Queen Elizabeth II. King George VI was the queen's father and King George V was her grandfather.

## Florida high school panic was 'cruel prank,' police say, recommend expulsion for 'pranksters'
 - [https://www.foxnews.com/us/florida-high-school-prank](https://www.foxnews.com/us/florida-high-school-prank)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 01:45:26+00:00

Authorities in Florida said several students could face charges for a "cruel prank" and said they ought to be expelled from school.

## Utah State School Board approved rule change that gives parents more of a voice in the classroom
 - [https://www.foxnews.com/media/utah-state-school-board-approved-rule-change-that-gives-parents-more-of-a-voice-in-the-classroom](https://www.foxnews.com/media/utah-state-school-board-approved-rule-change-that-gives-parents-more-of-a-voice-in-the-classroom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 01:42:14+00:00

The Utah State School Board approved a rule change that requires schools to provide transparency and public access to a school’s process of curating books and videos.

## Queen Elizabeth II's funeral forces 3 more EPL matches to be rescheduled
 - [https://www.foxnews.com/sports/queen-elizabeth-iis-funeral-forces-3-more-epl-matches-rescheduled](https://www.foxnews.com/sports/queen-elizabeth-iis-funeral-forces-3-more-epl-matches-rescheduled)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 01:34:53+00:00

Three more EPL games were postponed to later dates after the league decided to give the days following up to Queen Elizabeth II's funeral time to honor the queen.

## Jake Paul talks training for Anderson Silva fight, offers knockout prediction: 'It's gonna be a movie'
 - [https://www.foxnews.com/sports/jake-paul-talks-training-anderson-silva-fight-offers-knockout-prediction-gonna-movie](https://www.foxnews.com/sports/jake-paul-talks-training-anderson-silva-fight-offers-knockout-prediction-gonna-movie)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 01:31:06+00:00

Jake Paul talked to Fox News Digital about his training for the Anderson Silva bout and offered a prediction on when he'd knock out the UFC legend.

## Scottish protester holding ‘abolish monarch’ sign arrested during King Charles III declaration
 - [https://www.foxnews.com/world/scottish-protester-holding-abolish-monarch-sign-arrested-during-king-charles-declaration](https://www.foxnews.com/world/scottish-protester-holding-abolish-monarch-sign-arrested-during-king-charles-declaration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 01:24:27+00:00

A protester holding an 'abolish monarchy' sign during the formal declaration of King Charles III's accession to the throne was arrested in Edinburgh on Sunday.

## Seattle cancels classes for another day amid negotiations as teacher's union strike delays school year start
 - [https://www.foxnews.com/us/seattle-classes-teachers-union-strike-delay-school-year-start](https://www.foxnews.com/us/seattle-classes-teachers-union-strike-delay-school-year-start)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 01:21:09+00:00

Seattle public school officials canceled classes for Tuesday as contract negotiations have postponed the start of the school year.

## Jake Paul throws cold water on MMA fight against Nick Diaz: 'The money’s in boxing'
 - [https://www.foxnews.com/sports/jake-paul-throws-cold-water-mma-fight-against-nick-diaz-moneys-boxing](https://www.foxnews.com/sports/jake-paul-throws-cold-water-mma-fight-against-nick-diaz-moneys-boxing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 01:11:48+00:00

Jake Paul shut down any chance of stepping into the Octagon with Nick Diaz in the future, telling Fox News Digital that the "money's in boxing."

## Justice Department says it supports one of Trump's nominees for special master
 - [https://www.foxnews.com/politics/justice-department-says-supports-trumps-nominees-special-master](https://www.foxnews.com/politics/justice-department-says-supports-trumps-nominees-special-master)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 01:06:46+00:00

The Department of Justice said Monday that it supports the appointment of Raymond Dearie, a former chief federal judge in New York, to be special master.

## Apollo 7 astronaut: Public thought space race 'impossible'
 - [https://www.foxnews.com/media/apollo-7-astronaut-public-thought-space-race-impossible](https://www.foxnews.com/media/apollo-7-astronaut-public-thought-space-race-impossible)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 01:04:09+00:00

One of the Apollo 7 astronauts and living legend Walter Cunningham joined "Your World" to reflect on 60 years of the famous "Moonshot" speech given by President John F. Kennedy.

## Jake Paul declares himself the 'real king of Stockton,' challenges Nate Diaz
 - [https://www.foxnews.com/sports/jake-paul-declares-himself-real-king-stockton-challenges-nate-diaz](https://www.foxnews.com/sports/jake-paul-declares-himself-real-king-stockton-challenges-nate-diaz)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 00:46:07+00:00

Jake Paul took a shot at Nate Diaz in an interview with Fox News Digital ahead of his fight with Anderson Silva. He said the former UFC fighter is in his crosshairs.

## New York City Dem endorses Republican Lee Zeldin instead of Gov. Kathy Hochul
 - [https://www.foxnews.com/politics/new-york-city-dem-republican-lee-zeldin-kathy-hochul](https://www.foxnews.com/politics/new-york-city-dem-republican-lee-zeldin-kathy-hochul)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 00:33:41+00:00

A New York City elected official is supporting a Republican congressman in his bid for governor against fellow Democrat, Gov. Kathy Hochul as crime continues to plague the city.

## Richard Fowler: Inflation, Dobbs decision aren't the only issues on the American voters' plate
 - [https://www.foxnews.com/media/richard-fowler-inflation-dobbs-decision-arent-only-issues-american-voters-plate](https://www.foxnews.com/media/richard-fowler-inflation-dobbs-decision-arent-only-issues-american-voters-plate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 00:24:33+00:00

Fox News host Bret Baier spoke with Richard Fowler about the race to the November midterms and increased campaign rhetoric from both political parties.

## Jake Paul says boxing 'helped me mature and really find myself'
 - [https://www.foxnews.com/sports/jake-paul-says-boxing-helped-me-mature-really-find-myself](https://www.foxnews.com/sports/jake-paul-says-boxing-helped-me-mature-really-find-myself)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 00:19:51+00:00

Jake Paul explained what's changed from the trouble he's been in to now where he's set to fight MMA legend Anderson Silva. He explained boxing changed his life for the better.

## Bank of America CEO pushes back on criticisms of zero-down mortgages for minority communities
 - [https://www.foxnews.com/media/bank-america-ceo-pushes-back-criticisms-zero-down-mortgages-minority-communities](https://www.foxnews.com/media/bank-america-ceo-pushes-back-criticisms-zero-down-mortgages-minority-communities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 00:17:49+00:00

Bank of America Chief Executive Officer Brian Moynihan joined 'Special Report' for a wide-ranging interview, where he spoke on the topic of zero-down mortgages.

## Former Planned Parenthood president warns against California's medical misinformation bill
 - [https://www.foxnews.com/media/former-planned-parenthood-president-warns-against-californias-medical-misinformation-bill](https://www.foxnews.com/media/former-planned-parenthood-president-warns-against-californias-medical-misinformation-bill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 00:17:23+00:00

Former president of Planned Parenthood sounded the alarm that a bill to stop misinformation could end up punishing medical professionals and unleash partisan crackdowns.

## A look back at Queen Elizabeth II's children: King Charles III, Princess Anne, Prince Andrew and Prince Edward
 - [https://www.foxnews.com/entertainment/queen-elizabeth-ii-children-king-charles-iii-princess-anne-prince-andrew-prince-edward](https://www.foxnews.com/entertainment/queen-elizabeth-ii-children-king-charles-iii-princess-anne-prince-andrew-prince-edward)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-09-13 00:04:44+00:00

Queen Elizabeth II and her husband Prince Philip had four children after their marriage in 1947, King Charles, Princess Anne, Prince Andrew and Prince Edward.


# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Pomorskie. 62-latek ciągnął kucyki za samochodem. Potem kopał zwierzęta [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28907551,pomorskie-62-latek-ciagnal-kucyki-za-samochodem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28907551,pomorskie-62-latek-ciagnal-kucyki-za-samochodem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 19:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bf/91/1b/z28907711M,62-latek-ciagnal-kucyki-za-samochodem.jpg" vspace="2" />W Żukowie 62-latek ciągnął za swoim samochodem dwa kucyki. Gdy jeden koń się przewrócił, mężczyzna wyszedł z samochodu i zaczął go kopać. Całe zdarzenie zarejestrował jeden ze świadków. Sprawa trafiła na policję.

## Dolnośląskie. Ksiądz domagał się pieniędzy za pogrzeb. "Nie pieprz, że to wina banku!!!"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28907432,dolnoslaskie-ksiadz-domagal-sie-pieniedzy-za-pogrzeb-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28907432,dolnoslaskie-ksiadz-domagal-sie-pieniedzy-za-pogrzeb-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 19:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0f/69/1b/z28745487M,Ksiadz--zdjecie-ilustracyjne-.jpg" vspace="2" />Ksiądz domagał się od kobiety pieniędzy "co łaska" za pogrzeb jej matki. Kiedy wyjaśniła mu, że zwłoka jest spowodowana trudnościami z założeniem konta, duchowny naskoczył na nią. "Nie pieprz, że to wina banku - to charakterek!!! To zresztą podobnie było z pogrzebem Babci. Jeżeli Ty tak się opiekowałaś mamą, jak załatwiłaś jej pogrzeb - to szczerze współczuję!!! Dobrze, że 

## Malbork. 9-latek stał w otwartym oknie. Służby wyważyły drzwi i ściągnęły chłopca z parapetu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28907356,malbork-9-latek-stal-w-otwartym-oknie-sluzby-wywazyly-drzwi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28907356,malbork-9-latek-stal-w-otwartym-oknie-sluzby-wywazyly-drzwi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 19:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fa/9b/15/z22657274M,Okno--zdjecie-ilustracyjne-.jpg" vspace="2" />W centrum Malborka 9-letni chłopiec otworzył okno w jednym z mieszkań i stał na parapecie. Dzięki reakcji świadka na miejscu szybko pojawiły się służby ratunkowe. "Pokój, w którym znajdowało się dziecko, był zamknięty na klucz" - przekazują policjanci.

## Barbara Nowak ma przeprosić ZNP. Uznała, że strajk nauczycieli to "metody, które stosują terroryści"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28906727,barbara-nowak-ma-przeprosic-znp-uznala-ze-strajk-nauczycieli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28906727,barbara-nowak-ma-przeprosic-znp-uznala-ze-strajk-nauczycieli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 16:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e0/75/1b/z28792288M,Barbara-Nowak--malopolska-kurator-oswiaty-.jpg" vspace="2" />Decyzją warszawskiego sądu okręgowego Barbara Nowak musi przeprosić Związek Nauczycielstwa Polskiego. "Związek Nauczycielstwa Polskiego przepraszam także za moje stwierdzenie, jakoby organizujący strajk działacze ZNP wzorowali się na totalitarnych systemach, takich jak komunizm i faszyzm" - czytamy we fragmencie przeprosin, które mają pojawić się w mediach społ

## Pomorskie. Ukradł fotopułapkę - ta robiła zdjęcia mieszkania. Policjanci poznali sprawcę po bałaganie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28907000,pomorskie-ukradl-fotopulapke-ta-robila-zdjecia-mieszkania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28907000,pomorskie-ukradl-fotopulapke-ta-robila-zdjecia-mieszkania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 16:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/66/8d/1b/z28892518M,Zdjecie-z-fotopulaki-skradzionej-w-Potegowie.jpg" vspace="2" />Mieszkaniec gminy Potęgowo został zatrzymany w sprawie kradzieży fotopułapki. Mężczyzna przyniósł urządzenie do iebie, a to robiło zdjęcia jego mieszkania i wysyłało je urzędnikom. Fotografiom przyjrzeli się policjanci, którzy rozpoznali sprawcę po bałaganie, jaki ma w domu.

## Ruda Śląska. Nagrywali na TikToku relację z alkoholowej imprezy. Odwiedzili ich policjanci
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28905933,ruda-slaska-nagrywali-na-tiktoku-relacje-z-alkoholowej-imprezy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28905933,ruda-slaska-nagrywali-na-tiktoku-relacje-z-alkoholowej-imprezy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 14:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/92/85/1b/z28858770M,przemoc-wobec-dzieci---zdjecie-ilustracyjne.jpg" vspace="2" />W poniedziałek w nocy pijani rodzice z Rudy Śląskiej urządzili w mieszkaniu imprezę i transmitowali ją na TikToku, zapraszając kolejnych gości. Pod ich opieką było dwoje dzieci. Z zaproszenia skorzystali policjanci, a para trafiła do aresztu.

## Lubelskie. Z samolotów spadną brunatne kostki. Uwaga: nie wolno ich dotykać!
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28906311,lubelskie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28906311,lubelskie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 14:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0a/91/1b/z28906762M,Kostki-ze-szczepionka-przeciwko-wsciekliznie---200.jpg" vspace="2" />Na terenie województwa lubelskiego rozpoczęła się kolejna w tym roku akcja szczepienia lisów wolnożyjących przeciwko wściekliźnie. Działania będą prowadzone na terenach leśnych i polnych z pominięciem obszarów zabudowanych.

## Podkarpackie. 42-latek zmarł podczas interwencji policjantów. Mieli go obezwładnić, podduszając
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28904253,podkarpackie-42-latek-zmarl-podczas-interwencji-policjantow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28904253,podkarpackie-42-latek-zmarl-podczas-interwencji-policjantow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 12:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/81/91/1b/z28905601M,Zatrzymanie--zdjecie-ilustracyjne-.jpg" vspace="2" />42-letni mężczyzna zmarł w poniedziałek w Radymnie (woj. podkarpackie) podczas policyjnej interwencji. Miał on pokłócić się wcześniej z siostrą, która wezwała funkcjonariuszy. W trakcie zatrzymania stracił przytomność. Według świadków policjanci powalili go na ziemię i zastosowali technikę podduszania. Mimo reanimacji nie udało się przywrócić funkcji życiowych.

## Katowice. Kierowca autobusu oskarżony o zabójstwo. Prokuratura: Celowo najechał na kobietę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28905520,katowice-kierowca-autobusu-oskarzony-o-zabojstwo-prokuratura.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28905520,katowice-kierowca-autobusu-oskarzony-o-zabojstwo-prokuratura.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 12:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2d/20/1a/z27394349M,Potracenie-19-latki-w-Katowicach.jpg" vspace="2" />Do Sądu Okręgowego w Katowicach trafił akt oskarżenia w sprawie 32-letniego kierowcy miejskiego autobusu. Pod koniec lipca ubiegłego roku mężczyzna najechał na 19-letnią kobietę, która zmarła w wyniku odniesionych obrażeń. Badania wykazały, że w chwili zdarzenia 32-latek był pod wpływem substancji psychoaktywnych.

## Jarosław Kaczyński straszy na Podkarpaciu: Nie będzie naszej władzy, nie będzie realizacji planu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28904042,jaroslaw-kaczynski-o-dzialaniach-pis-musimy-zrobic-wszystko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28904042,jaroslaw-kaczynski-o-dzialaniach-pis-musimy-zrobic-wszystko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 11:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/14/90/1b/z28904212M,Jaroslaw-Kaczynski.jpg" vspace="2" />Jarosław Kaczyński, podczas swojego objazdu polskich miast, udzielił wywiadu rzeszowskim dziennikarzom. Prezes PiS sugerował, że po zmianie władzy, zatrzyma się rozwój regionu. Straszył, że bez PiS-u nie będzie dalszej modernizacji.

## Czarnek: Nauczyciele nie będą uczyć tylko jednego przedmiotu. Standardem jest dwuprzedmiotowiec
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28904183,czarnek-nauczyciele-nie-beda-uczyc-tylko-jednego-przedmiotu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28904183,czarnek-nauczyciele-nie-beda-uczyc-tylko-jednego-przedmiotu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 09:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/25/8b/1b/z28882213M,Przemyslaw-Czarnek.jpg" vspace="2" />Minister edukacji Przemysław Czarnek od ręki znalazł sposób na braki kadrowe w polskich szkołach, a mianowicie "nauczyciel dwuprzedmiotowiec". Stwierdził też, że ma związane ręce kartą nauczyciela. Jeśli chodzi o podwyżki, minister życzy każdemu w budżetówce "takich zarobków, jakie mają pracownicy oświaty".

## Pogoda długoterminowa na październik 2022. Będą przymrozki, możliwe pierwsze opady śniegu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28903742,pogoda-dlugoterminowa-na-pazdziernik-2022-beda-przymrozki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28903742,pogoda-dlugoterminowa-na-pazdziernik-2022-beda-przymrozki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-09-13 06:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b3/90/1b/z28903859M,Pogoda--Pierwszy-snieg--zdjecie-ilustracyjne-.jpg" vspace="2" />Pogoda długoterminowa na październik 2022 według IMGW przewiduje średnią temperaturę w normie, jednak inne modele wskazują na anomalię powyżej normy. Co z opadami? Czy czeka nas kolejny suchy miesiąc?


# Source:Washington Examiner - Tech, URL:https://feeds.feedburner.com/dcexaminer/tech, language:en-US

## Astrophysicist predicts capability to detect life outside solar system in 25 years
 - [https://www.washingtonexaminer.com/policy/space/astrophysicist-predicts-capability-detecting-life-outside-solar-system-25-years](https://www.washingtonexaminer.com/policy/space/astrophysicist-predicts-capability-detecting-life-outside-solar-system-25-years)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/tech
 - date published: 2022-09-13 17:12:39+00:00

An astrophysicist predicted that humans would have the ability to detect life on planets outside of the solar system in about a quarter of a century.


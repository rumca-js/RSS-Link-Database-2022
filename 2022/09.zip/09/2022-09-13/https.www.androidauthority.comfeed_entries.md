# Source:Android Authority, URL:https://www.androidauthority.com/feed/, language:en-US

## $400 off the 2021 MacBook Pro, and more of the latest Laptop deals
 - [https://www.androidauthority.com/best-laptop-deals-1109232/](https://www.androidauthority.com/best-laptop-deals-1109232/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 22:00:11+00:00

We've trawled the web to find the latest and greatest offers on laptops for all use cases and budgets.

## 31 new emoji just landed today, check out what made it on the list
 - [https://www.androidauthority.com/31-new-emoji-landed-today-3208475/](https://www.androidauthority.com/31-new-emoji-landed-today-3208475/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 21:25:11+00:00

Unicode 15.0 will bring new emojis to major platforms later this or in early 2023.

## What is Thread, and why does it matter in a smart home?
 - [https://www.androidauthority.com/what-is-thread-3205634/](https://www.androidauthority.com/what-is-thread-3205634/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 20:00:46+00:00

Make Thread a priority whenever you're considering gear.

## Discord finally comes to Xbox: here’s how to use Discord on your Xbox
 - [https://www.androidauthority.com/how-to-use-discord-on-xbox-3208232/](https://www.androidauthority.com/how-to-use-discord-on-xbox-3208232/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 19:40:26+00:00

It's about time, Microsoft. Discord finally comes to Xbox!

## Save 25% on the WD 1TB My Passport Ultra, and more external hard drive deals
 - [https://www.androidauthority.com/best-cheap-external-hard-drive-deals-1118021/](https://www.androidauthority.com/best-cheap-external-hard-drive-deals-1118021/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 18:10:29+00:00

The already affordable storage option just dropped to its best price in many months.

## Bose QuietComfort SE headphones just dropped out of nowhere
 - [https://www.androidauthority.com/bose-quietcomfort-se-headphones-3208296/](https://www.androidauthority.com/bose-quietcomfort-se-headphones-3208296/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 17:51:24+00:00

Bose's QuietComfort headphones have been found on a number of retail websites.

## How to track your order on eBay
 - [https://www.androidauthority.com/track-ebay-order-3151081/](https://www.androidauthority.com/track-ebay-order-3151081/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 17:31:21+00:00

Follow your packages online to see when they will arrive.

## How to turn Disney Plus subtitles on and off
 - [https://www.androidauthority.com/disney-plus-subtitles-3143016/](https://www.androidauthority.com/disney-plus-subtitles-3143016/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 17:13:59+00:00

Learn the words to sing along to your favorite Disney songs. Or not.

## How to change the voice on Waze
 - [https://www.androidauthority.com/change-voice-waze-3133061/](https://www.androidauthority.com/change-voice-waze-3133061/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 16:13:01+00:00

Are you tired of that robotic, AI voice giving you directions? Why not let Morgan Freeman take hold of the mic?

## What is Apple’s Photonic Engine all about?
 - [https://www.androidauthority.com/apple-photonic-engine-3208007/](https://www.androidauthority.com/apple-photonic-engine-3208007/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 14:41:24+00:00

Getting the best out of multiple shots.

## How to use Waze: Tutorial, tips and tricks
 - [https://www.androidauthority.com/waze-tutorial-tips-tricks-3130672/](https://www.androidauthority.com/waze-tutorial-tips-tricks-3130672/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 13:13:55+00:00

Master the ways of Waze to arrive at your destination swiftly.

## Poll: Do you sleep with your phone in bed?
 - [https://www.androidauthority.com/sleep-with-phone-poll-3208088/](https://www.androidauthority.com/sleep-with-phone-poll-3208088/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 13:13:09+00:00

Many people use their phones in bed, but does yours stay in bed for the night?

## Fitbit Inspire 3 review: The best all-round budget fitness tracker
 - [https://www.androidauthority.com/fitbit-inspire-3-review-3202955/](https://www.androidauthority.com/fitbit-inspire-3-review-3202955/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 13:03:59+00:00

Fitbit covers all the basics, now on a brighter display.

## Amazon announces new Kindle for 2022, blurs line between Kindle and Paperwhite
 - [https://www.androidauthority.com/amazon-kindle-2022-3207829/](https://www.androidauthority.com/amazon-kindle-2022-3207829/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 13:00:59+00:00

Amazon is slightly increasing the price of the Kindle but bringing over a ton of Paperwhite features.

## Dear Tim Cook: Should I toss my perfectly functional Pixel in a landfill?
 - [https://www.androidauthority.com/apple-rcs-tim-cook-comments-3206886/](https://www.androidauthority.com/apple-rcs-tim-cook-comments-3206886/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 13:00:13+00:00

Let's all toss our Android phones in the trash and create an ecological disaster so Apple doesn't need to adopt RCS.

## You will never need to recharge these true wireless buds
 - [https://www.androidauthority.com/urbanista-phoenix-solar-charging-wireless-buds-3207442/](https://www.androidauthority.com/urbanista-phoenix-solar-charging-wireless-buds-3207442/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 13:00:04+00:00

The Urbanista Phoenix adds a solar panel to its charging case for endless listening.

## The 25 best iPhone 14 cases to keep your new phone safe and stylish
 - [https://www.androidauthority.com/best-iphone-14-cases-3206752/](https://www.androidauthority.com/best-iphone-14-cases-3206752/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 11:01:08+00:00

You don't have to sacrifice style for protection.

## Daily Authority: 📞 OnePlus 11 Pro unofficially breaks cover
 - [https://www.androidauthority.com/daily-authority-september-13-2022-3208059/](https://www.androidauthority.com/daily-authority-september-13-2022-3208059/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 09:54:33+00:00

Plus, spoons and bowls that can make your food taste salty.

## When we said Google needs to improve its chips, this isn’t what we had in mind
 - [https://www.androidauthority.com/google-chips-3208064/](https://www.androidauthority.com/google-chips-3208064/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 08:11:22+00:00

We want a processor that's not just a chip off the old block.

## You told us: You’re split over your phones’ camera zoom quality
 - [https://www.androidauthority.com/phone-camera-zoom-quality-poll-results-3207565/](https://www.androidauthority.com/phone-camera-zoom-quality-poll-results-3207565/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2022-09-13 06:51:28+00:00

It turns out that just under a third of respondents are happy with camera zoom results.


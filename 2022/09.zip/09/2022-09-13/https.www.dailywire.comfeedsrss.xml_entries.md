# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Tudor Dixon Reveals Massive Plan To Give More Funding To Michigan Police
 - [https://www.dailywire.com/news/tudor-dixon-reveals-massive-plan-to-give-more-funding-to-michigan-police](https://www.dailywire.com/news/tudor-dixon-reveals-massive-plan-to-give-more-funding-to-michigan-police)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 22:38:18+00:00

Michigan Republican governor nominee Tudor Dixon proposed a $1 billion plan Tuesday aimed at recruiting and retaining state and local law enforcement officers. Dixon’s proposal, focused on “building a safe state,” would seek to hire over 5,000 local officers, 500 state troopers, 2,000 state and local corrections officers, and 5,000 fire and EMS personnel, The ...

## BREAKING: My Pillow CEO Mike Lindell Claims FBI Surrounded His Car, Seized Cell Phone
 - [https://www.dailywire.com/news/breaking-my-pillow-ceo-mike-lindell-claims-fbi-surrounded-his-car-seized-cell-phone](https://www.dailywire.com/news/breaking-my-pillow-ceo-mike-lindell-claims-fbi-surrounded-his-car-seized-cell-phone)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 21:26:10+00:00

My Pillow CEO Mike Lindell, one of the fiercest defenders of former President Donald Trump, claimed during a livestream that the FBI surrounded his vehicle while he was on a hunting trip and seized his cell phone. &#8220;I have my own breaking news tonight,&#8221; Lindell said on his show. &#8220;This afternoon I was, I went ...

## Tucker Carlson Calls Out Large Bump On John Fetterman’s Neck: ‘Keep Your Eyes On This Lump’
 - [https://www.dailywire.com/news/tucker-carlson-calls-out-large-bump-on-john-fettermans-neck-keep-your-eyes-on-this-lump](https://www.dailywire.com/news/tucker-carlson-calls-out-large-bump-on-john-fettermans-neck-keep-your-eyes-on-this-lump)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 21:00:49+00:00

Fox News host Tucker Carlson highlighted a large bump on the back of U.S. Senate candidate John Fetterman&#8217;s (D-PA) neck that has recently gained attention online as Fetterman&#8217;s overall fitness for office has been called into question following a stroke that he suffered earlier this year. The segment on &#8220;Tucker Carlson Tonight&#8221; comes after The ...

## Carjackers Steal At Least A Dozen Ford Mustangs, Several Jeeps From Michigan Factories In The Same Morning
 - [https://www.dailywire.com/news/carjackers-steal-at-least-a-dozen-ford-mustangs-several-jeeps-from-michigan-factories-in-the-same-morning](https://www.dailywire.com/news/carjackers-steal-at-least-a-dozen-ford-mustangs-several-jeeps-from-michigan-factories-in-the-same-morning)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 20:56:14+00:00

Police are searching for suspects who stole at least a dozen Ford Mustangs from a manufacturing plant in Michigan. Police in the city of Woodhaven, Michigan, a suburb of Detroit, are searching for thieves who stole between 12 and 15 Ford Mustangs from the Flat Rock Assembly Plant, Fox 2 Detroit reported. Two of the ...

## Top Democratic Senator Blasts Kamala Harris For Claiming Southern Border Is ‘Secure’: ‘She’s Dead Wrong’
 - [https://www.dailywire.com/news/top-democratic-senator-blasts-kamala-harris-for-claiming-southern-border-is-secure-shes-dead-wrong](https://www.dailywire.com/news/top-democratic-senator-blasts-kamala-harris-for-claiming-southern-border-is-secure-shes-dead-wrong)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 20:43:31+00:00

Sen. Joe Manchin (D-WV) slammed Vice President Kamala Harris (D) during an interview Tuesday afternoon over her claim that the U.S. Southern Border is &#8220;secure.&#8221; Manchin made the remarks during a Fox News interview with anchor Bret Baier in response to Baier bringing up Harris calling the border &#8220;secure.&#8221; &#8220;It&#8217;s wrong. She&#8217;s dead wrong on ...

## Biden Slammed For Celebrating Bill Passage After Inflation Worse Than Expected, Stock Market Tanks
 - [https://www.dailywire.com/news/biden-slammed-for-celebrating-bill-passage-after-inflation-worse-than-expected-stock-market-tanks](https://www.dailywire.com/news/biden-slammed-for-celebrating-bill-passage-after-inflation-worse-than-expected-stock-market-tanks)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 20:03:50+00:00

President Joe Biden faced backlash Tuesday afternoon for celebrating the passage of his so-called &#8220;Inflation Reduction Act,&#8221; which experts say will have little to no impact on reducing inflation, while the latest Consumer Price Index (CPI) showed today that inflation rose in August compared to last year and while the stock market tanked. Biden claimed ...

## Newsom Announces Abortion Website
 - [https://www.dailywire.com/news/newsom-announces-abortion-website](https://www.dailywire.com/news/newsom-announces-abortion-website)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 19:52:31+00:00

California has started a new abortion website for residents and out-of-state women to provide more information about abortion clinics in an to attempt to make the state increasingly abortion-friendly. In his most recent action going after Republican-led states with pro-life legislation, Democratic Governor of California Gavin Newsom announced the beginning of the website on Tuesday. ...

## ‘I Can’t Do This Anymore’: Former Disney Star Makes Huge Career Announcement
 - [https://www.dailywire.com/news/i-cant-do-this-anymore-former-disney-star-makes-huge-career-announcement](https://www.dailywire.com/news/i-cant-do-this-anymore-former-disney-star-makes-huge-career-announcement)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 19:20:20+00:00

Former Disney star Demi Lovato announced that &#8220;this next tour&#8221; will be her last one — because she &#8220;can&#8217;t do this anymore&#8221; — in a since-deleted post on her Instagram Stories. The 30-year-old actress/pop singer definitely got everyone&#8217;s attention on Tuesday when she made posts on social media about how she was feeling sick and ...

## Nearly Two-Thirds Of Americans, Even Most Democrats, Say Biden’s Attacks on ‘MAGA Republicans’ Are Dividing The Country: Survey
 - [https://www.dailywire.com/news/nearly-two-thirds-of-americans-even-most-democrats-say-bidens-attacks-on-maga-republicans-are-dividing-the-country-survey](https://www.dailywire.com/news/nearly-two-thirds-of-americans-even-most-democrats-say-bidens-attacks-on-maga-republicans-are-dividing-the-country-survey)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 19:12:41+00:00

Nearly two-thirds of Americans, including a surprisingly large majority of Democrats, believe the Biden administration&#8217;s attacks on so-called &#8220;MAGA Republicans&#8221; are dividing the country. According to a survey of 1,277 U.S. adults, conducted by I&amp;I/TIPP between September 7-9, nearly two-thirds of Americans, 62% agreed that the White House&#8217;s attacks on so-called &#8220;MAGA Republicans&#8221; increase division ...

## Fetterman Mocked Oz For Owning 10 Properties. Fetterman Owns 8, But Didn’t Disclose Them.
 - [https://www.dailywire.com/news/fetterman-mocked-oz-for-owning-10-properties-fetterman-owns-8-but-didnt-disclose-them](https://www.dailywire.com/news/fetterman-mocked-oz-for-owning-10-properties-fetterman-owns-8-but-didnt-disclose-them)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 19:12:05+00:00

Pennsylvania Lt. Governor and Democratic Senate nominee John Fetterman did not mention his eight properties on federal financial disclosures, even though he has repeatedly mocked Republican rival Dr. Mehmet Oz for owning multiple real estate holdings. According to a Tuesday release from the Foundation for Accountability and Civic Trust, candidates are required to submit a ...

## It’s Time To Hold Democrats Accountable For Biden’s Education Crisis
 - [https://www.dailywire.com/news/its-time-to-hold-democrats-accountable-for-bidens-education-crisis](https://www.dailywire.com/news/its-time-to-hold-democrats-accountable-for-bidens-education-crisis)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 18:35:25+00:00

As the midterm elections approach and voters weigh their options at the ballot box, every American should remember a simple fact: when Democrat politicians had a choice between keeping our kids in the classroom or mortgaging their futures with devastating school lockdowns, they chose to put our kids last. Protecting our children and putting them ...

## Young Brit Slams U.S. Leftists Mocking Mourning Of Queen: You Mourned George Floyd
 - [https://www.dailywire.com/news/young-brit-slams-u-s-leftists-mocking-mourning-of-queen-you-mourned-george-floyd](https://www.dailywire.com/news/young-brit-slams-u-s-leftists-mocking-mourning-of-queen-you-mourned-george-floyd)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 18:18:14+00:00

A young conservative British commentator took aim at American leftists who mocked the British for mourning their beloved Queen Elizabeth, who died last week. Sophie Corcoran, who has appeared on Sky News and other outlets and boasts 124,000 Twitter followers, said the same critics across the pond were likely mourning the death of George Floyd ...

## ‘Absurdity’: Megyn Kelly Slams Hillary Clinton’s ‘Pandering’ Praise Of ‘WAP’
 - [https://www.dailywire.com/news/absurdity-megyn-kelly-slams-hillary-clintons-pandering-praise-of-wap](https://www.dailywire.com/news/absurdity-megyn-kelly-slams-hillary-clintons-pandering-praise-of-wap)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 17:39:48+00:00

Megyn Kelly slammed former Democratic presidential nominee Hillary Clinton, saying that she was &#8220;just pandering&#8221; when she praised the vulgar &#8220;WAP&#8221; song by Cardi B featuring rapper Megan Thee Stallion during her Apple TV series &#8220;Gutsy.&#8221; During Sirius XM’s “The Megyn Kelly Show&#8221; podcast Tuesday, the host was speaking with GB News host Nigel Farage about Queen ...

## Rapper PnB Rock Shot And Killed In L.A., Days After Talking About Criminals Targeting Rappers
 - [https://www.dailywire.com/news/rapper-pnb-rock-shot-and-killed-in-l-a-days-after-talking-about-criminals-targeting-rappers](https://www.dailywire.com/news/rapper-pnb-rock-shot-and-killed-in-l-a-days-after-talking-about-criminals-targeting-rappers)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 17:30:20+00:00

Rapper PnB Rock was shot and killed during a robbery in Los Angeles Monday. The 30-year-old Philadelphia native rapper was robbed while he was eating lunch with his girlfriend at Roscoe&#8217;s House of Chicken and Waffles, a soul food restaurant chain in South Los Angeles, police said. The &#8220;Selfish&#8221; and &#8220;Jealous&#8221; rapper was approached by ...

## Mexico Pursuing Charges Against Hunter Biden Associate And Son Of Mexican Political Royalty, In Contrast To DOJ Treatment Of Hunter
 - [https://www.dailywire.com/news/mexico-pursuing-charges-against-hunter-biden-associate-and-son-of-mexican-political-royalty-in-contrast-to-doj-treatment-of-hunter](https://www.dailywire.com/news/mexico-pursuing-charges-against-hunter-biden-associate-and-son-of-mexican-political-royalty-in-contrast-to-doj-treatment-of-hunter)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 17:19:05+00:00

Mexico is pursuing criminal tax-scofflaw charges against the heir of one of its powerful political families—charges that have not materialized against Hunter Biden, who allegedly had similar financial problems and who did business with the Mexican heir.

## What The … James Taylor Sings At White House As  Biden Celebrates Inflation Reduction Act
 - [https://www.dailywire.com/news/what-the-james-taylor-sings-at-white-house-as-biden-celebrates-inflation-reduction-act](https://www.dailywire.com/news/what-the-james-taylor-sings-at-white-house-as-biden-celebrates-inflation-reduction-act)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 17:17:56+00:00

The new normal is pretty weird, man. Just when you think Biden&#8217;s America cannot get any stranger, he trots out an aging folk singer to celebrate the passage of a multi-billion boondoggle climate change chicanery bill known as the Inflation Reduction Act. For some reason, Biden has spent all day boasting about the passage of ...

## BREAKING: Ken Starr, Former Federal Judge And Clinton Investigator, Dies At 76
 - [https://www.dailywire.com/news/breaking-ken-starr-former-federal-judge-and-clinton-investigator-dies-at-76](https://www.dailywire.com/news/breaking-ken-starr-former-federal-judge-and-clinton-investigator-dies-at-76)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 16:39:54+00:00

Ken Starr, a former federal judge who later led the investigation that resulted in former President Bill Clinton&#8217;s impeachment, died on Tuesday. He was 76-years-old. Starr died in Houston at Baylor St. Luke&#8217;s Medical Center of complications from surgery, according to a statement from his family. Starr was appointed as a judge to the federal ...

## Nigerian Prince Alert: Feds’ Coronavirus Loan Program Paid $1 Billion To People Who Applied From Other Countries
 - [https://www.dailywire.com/news/nigerian-prince-alert-feds-coronavirus-loan-program-paid-1-billion-to-people-who-applied-from-other-countries](https://www.dailywire.com/news/nigerian-prince-alert-feds-coronavirus-loan-program-paid-1-billion-to-people-who-applied-from-other-countries)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 16:29:56+00:00

The federal government paid $1.3 billion in forgivable coronavirus loans to people whose applications were submitted from foreign IP addresses, according to a new Small Business Administration Inspector General report.

## Hollywood Actress Gets Stuck In Elevator At Film Festival – Firefighters Save The Day
 - [https://www.dailywire.com/news/hollywood-actress-gets-stuck-in-elevator-at-film-festival-firefighters-save-the-day](https://www.dailywire.com/news/hollywood-actress-gets-stuck-in-elevator-at-film-festival-firefighters-save-the-day)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 16:27:29+00:00

Actress Anna Kendrick and her team got stuck in an elevator at the Toronto International Film Festival, and had to wait for firefighters to come to the rescue. Kendrick documented her temporary captivity on Instagram, sharing a video on Sunday of what had happened behind closed doors — in what appeared to be a very ...

## Controversial Sex Education Post About Children Removed From Instagram
 - [https://www.dailywire.com/news/controversial-sex-education-post-about-children-removed-from-instagram](https://www.dailywire.com/news/controversial-sex-education-post-about-children-removed-from-instagram)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 16:12:17+00:00

An Instagram post promoting sex education for young kids was removed from the platform after multiple reports that it was &#8220;inappropriate.&#8221; An Instagram account that creates sex education slideshows made a controversial post advocating for adults to talk to children about pleasure – sexual and otherwise. The image carousel featured stock photography of children who ...

## ‘A Serious Inflation Problem’: Top Obama Economist Sounds The Alarm Over Prices As White House Celebrates
 - [https://www.dailywire.com/news/a-serious-inflation-problem-top-obama-economist-sounds-the-alarm-over-prices-as-white-house-celebrates](https://www.dailywire.com/news/a-serious-inflation-problem-top-obama-economist-sounds-the-alarm-over-prices-as-white-house-celebrates)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 15:58:17+00:00

Former Treasury Secretary and National Economic Council director Lawrence Summers warned on Tuesday that the United States still has a “serious inflation problem.” The Consumer Price Index (CPI) rose 8.3% between August 2021 and August 2022, according to a report released on Tuesday by the Bureau of Labor Statistics. The reading marks a decline from ...

## Candace Owens, Perez Hilton, And Scott Newgent Speak About Trans Surgeries For Kids
 - [https://www.dailywire.com/news/candace-owens-perez-hilton-and-scott-newgent-speak-about-trans-surgeries-for-kids](https://www.dailywire.com/news/candace-owens-perez-hilton-and-scott-newgent-speak-about-trans-surgeries-for-kids)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 15:57:20+00:00

Candace Owens recently hosted outspoken trans man Scott Newgent and gossip maven Perez Hilton for a lively Daily Wire roundtable debate about the danger of medical gender transitioning for children. The sizzle and the substance to kick off the conversation came courtesy of Brittany Aldean, wife of country music star Jason Aldean, who got branded &#8220;transphobic&#8221; ...

## Biden Administration To Pursue New Geothermal Energy Effort
 - [https://www.dailywire.com/news/biden-administration-to-pursue-new-geothermal-energy-effort](https://www.dailywire.com/news/biden-administration-to-pursue-new-geothermal-energy-effort)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 15:46:43+00:00

Energy Secretary Jennifer Granholm announced a goal on Thursday to make geothermal power a “widespread renewable energy option.” According to a press release from the Department of Energy, policymakers are pursuing the objective of making power from enhanced geothermal systems — which create power by forcing water through hot rock layers in the ground — ...

## Jesse Watters Accuses Biden Of Turning ‘War On Terror’ Into War On Republicans: ‘Am I Going To Gitmo?’
 - [https://www.dailywire.com/news/jesse-watters-accuses-biden-of-turning-war-on-terror-into-war-on-republicans-am-i-going-to-gitmo](https://www.dailywire.com/news/jesse-watters-accuses-biden-of-turning-war-on-terror-into-war-on-republicans-am-i-going-to-gitmo)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 15:45:44+00:00

Fox News host Jesse Watters accused President Joe Biden of turning the &#8220;War on Terror&#8221; into all-out war against Republicans — and adopting the same language that had previously been reserved for terrorists in the process. Watters unloaded on the president during his Monday evening monologue, arguing that Biden&#8217;s language when attacking the opposing political ...

## What Color Is The Sky In Kamala’s World?
 - [https://www.dailywire.com/news/what-color-is-the-sky-in-kamalas-world](https://www.dailywire.com/news/what-color-is-the-sky-in-kamalas-world)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 15:28:13+00:00

Shortly after Joe Biden and Kamala Harris took office, the president declared his veep &#8220;border czar.&#8221; Biden certainly didn&#8217;t want that mess on his plate, and as everyone knows, messes flow downhill. Suddenly, Harris had to try to take care of a mess her boss had abandoned. So what did she do? Nothing. Literally and ...

## Prince Harry Finds Unlikely Supporter Who Says He’s ‘Earned’ The Right To Wear His Military Uniform
 - [https://www.dailywire.com/news/prince-harry-finds-unlikely-supporter-who-says-hes-earned-the-right-to-wear-his-military-uniform](https://www.dailywire.com/news/prince-harry-finds-unlikely-supporter-who-says-hes-earned-the-right-to-wear-his-military-uniform)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 15:28:09+00:00

Prince Harry finds an unlikely defender in TV host Piers Morgan, who said the royal has &#8220;earned&#8221; the right to wear his military uniform to events honoring the late-Queen Elizabeth II. The host of &#8220;Piers Morgan Uncensored,&#8221; who has previously slammed the Duke of Sussex as a &#8220;spoiled brat&#8221; and a &#8220;spineless self-pitying twerp,&#8221; took ...

## Wall Street Journal Blasts Joe Biden, John Kerry For Pushing ‘Self-Destructive’ Green Energy Policies While China Burns More Coal
 - [https://www.dailywire.com/news/wall-street-journal-blasts-joe-biden-john-kerry-for-pushing-self-destructive-green-energy-policies-while-china-burns-more-coal](https://www.dailywire.com/news/wall-street-journal-blasts-joe-biden-john-kerry-for-pushing-self-destructive-green-energy-policies-while-china-burns-more-coal)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 14:54:04+00:00

The editorial board of The Wall Street Journal blasted the White House in a scathing Monday opinion piece as officials push green energy despite Chinese forays into fossil fuels. President Joe Biden’s energy policy has centered upon a rapid transition toward renewable power and away from oil, gas, and coal. Beyond nixing expansions to the ...

## Sen. Lindsey Graham Introduces National 15-Week Abortion Ban Bill
 - [https://www.dailywire.com/news/sen-lindsey-graham-introduces-national-15-week-abortion-ban-bill](https://www.dailywire.com/news/sen-lindsey-graham-introduces-national-15-week-abortion-ban-bill)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 14:52:17+00:00

Sen. Lindsey Graham (R-SC) has introduced a bill to ban abortions nationwide after 15 weeks. The bill, dubbed the &#8220;Protecting Pain-Capable Unborn Children from Late-Term Abortions Act,&#8221; was announced during a press conference in Washington, D.C., on Tuesday. &#8220;I see this as a responsible alternative to the very radical position by Democratic senators,&#8221; Graham said. ...

## Democrat Tim Ryan: We Need To ‘Kill And Confront’ The MAGA Movement
 - [https://www.dailywire.com/news/democrat-tim-ryan-we-need-to-kill-and-confront-the-maga-movement](https://www.dailywire.com/news/democrat-tim-ryan-we-need-to-kill-and-confront-the-maga-movement)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 14:35:31+00:00

Rep. Tim Ryan (D-OH) told MSNBC&#8217;s &#8220;Morning Joe&#8221; that he is willing to work with any moderate Republican but cautioned that &#8220;mainstream&#8221; GOP officials and Democrats need &#8220;to kill and confront&#8221; the MAGA movement. Ryan has attempted to rebrand himself as a moderate Democrat in his Senate race against GOP candidate JD Vance, but critics ...

## DOJ Blocks Disclosure Of Plan To Combat ‘Obstacles’ To ‘Free And Fair Elections’
 - [https://www.dailywire.com/news/doj-blocks-disclosure-of-plan-to-combat-obstacles-to-free-and-fair-elections](https://www.dailywire.com/news/doj-blocks-disclosure-of-plan-to-combat-obstacles-to-free-and-fair-elections)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 14:19:38+00:00

The Department of Justice (DOJ) is claiming a 15-page plan to promote voting access and other election-related initiatives cannot be released to the public because of “presidential communications privileges.” The DOJ’s Civil Rights Division last week denied a government watchdog’s request to release the department’s “Strategic Plan” on “Promoting Access to Voting.” The Foundation for ...

## ‘State Is Going To S***’: NFL Star Slams COVID Restrictions He Says Destroyed ‘All The Small Businesses’
 - [https://www.dailywire.com/news/state-is-going-to-s-nfl-star-slams-covid-restrictions-he-says-destroyed-all-the-small-businesses](https://www.dailywire.com/news/state-is-going-to-s-nfl-star-slams-covid-restrictions-he-says-destroyed-all-the-small-businesses)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 14:06:13+00:00

Green Bay Packers quarterback Aaron Rodgers didn&#8217;t beat around the bush when he said California is &#8220;going to s***&#8221; as he slammed the state&#8217;s COVID-related mandates that he says destroyed small businesses. During a recent appearance on the &#8220;Club Random with Bill Maher&#8221; podcast,&#8221; Rodgers and the host discussed life in the so-called Golden State. ...

## ‘How Dare You’: Fans Blast Emmys For Excluding Olivia Newton-John From Memorial Tribute
 - [https://www.dailywire.com/news/how-dare-you-fans-blast-emmys-for-excluding-olivia-newton-john-from-memorial-tribute](https://www.dailywire.com/news/how-dare-you-fans-blast-emmys-for-excluding-olivia-newton-john-from-memorial-tribute)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 14:02:37+00:00

The Emmys were slammed after excluding the late Olivia Newton-John from their “In Memoriam” tribute on Monday. The famed pop music icon died in August after a thirty-year intermittent battle against cancer in August. She was 73. “How do forget Olivia Newton John? How dare you. She is and always will be an icon. And ...

## WATCH: King Charles Yells At Pen During Northern Ireland Signing Ceremony
 - [https://www.dailywire.com/news/watch-king-charles-yells-at-pen-during-northern-ireland-signing-ceremony](https://www.dailywire.com/news/watch-king-charles-yells-at-pen-during-northern-ireland-signing-ceremony)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 13:55:53+00:00

King Charles III expressed his frustration with an uncooperative pen – and the moment was caught on film for the world to see. Charles made a visit on Monday to Northern Ireland — part of a tour through the United Kingdom to lead the nation in mourning the recent passing of his mother, the late ...

## Railroad Freight Companies Cutting Service Ahead Of Potential Nationwide Strike
 - [https://www.dailywire.com/news/railroad-freight-companies-cutting-service-ahead-of-potential-nationwide-strike](https://www.dailywire.com/news/railroad-freight-companies-cutting-service-ahead-of-potential-nationwide-strike)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 13:28:45+00:00

Four of the nation&#8217;s largest railroad companies have begun scaling back service ahead of a potential nationwide strike that could result in massive supply chain delays. BNSF, CSX, Norfolk Southern, and Union Pacific announced embargoes on selected shipments this week. Negotiations with two of the nation&#8217;s largest rail unions, the International Association of Sheet Metal, ...

## Taylor Lorenz Questions Libs Of TikTok About Her Helping ‘Foster Violence,’ Gets Mocked In Reply
 - [https://www.dailywire.com/news/taylor-lorenz-questions-libs-of-tiktok-about-fostering-violence-gets-mocked-in-reply](https://www.dailywire.com/news/taylor-lorenz-questions-libs-of-tiktok-about-fostering-violence-gets-mocked-in-reply)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 13:28:00+00:00

Taylor Lorenz, who covers technology and online culture for The Washington Post, has once again found herself the subject of ridicule online. On Monday, Lorenz again questioned the woman behind the Libs of TikTok account on Twitter, asking her for comment on a colleague&#8217;s story. Why is she obsessed with me? @TaylorLorenz, I don’t want ...

## ‘I Think You’re A Traitor To Your Own’: Pro-Life Leader Lila Rose Takes On Fuming Abortion Activist On ‘Dr. Phil’
 - [https://www.dailywire.com/news/i-think-youre-a-traitor-to-your-own-pro-life-leader-lila-rose-takes-on-fuming-abortion-activist-on-dr-phil](https://www.dailywire.com/news/i-think-youre-a-traitor-to-your-own-pro-life-leader-lila-rose-takes-on-fuming-abortion-activist-on-dr-phil)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 13:22:00+00:00

Live Action founder Lila Rose took on a fuming abortion activist, and many others, during a Monday appearance on &#8220;Dr. Phil.&#8221; Rose, one of the leading pro-life figures in the nation, was called a &#8220;traitor&#8221; to women and decried as lacking empathy by one pro-abortion activist in the audience. In her typical fashion, Rose responded ...

## ‘That God May Give Me Wisdom’: The Very Real, Personal Faith Of Queen Elizabeth
 - [https://www.dailywire.com/news/that-god-may-give-me-wisdom-the-very-real-personal-faith-of-queen-elizabeth](https://www.dailywire.com/news/that-god-may-give-me-wisdom-the-very-real-personal-faith-of-queen-elizabeth)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 13:17:07+00:00

When Elizabeth Windsor was crowned queen of England in June of 1953, C.S. Lewis watched from afar. Queen Elizabeth II’s coronation was the first to be televised, an innovation that gave the great Christian author a chance to reflect on what her reign might mean. “You know, over here people did not get that fairy-tale ...

## Marvel To Feature Israeli Superhero In Captain America Movie. Anti-Semites Go On Attack.
 - [https://www.dailywire.com/news/marvel-to-feature-israeli-superhero-in-captain-america-movie-anti-semites-go-on-attack](https://www.dailywire.com/news/marvel-to-feature-israeli-superhero-in-captain-america-movie-anti-semites-go-on-attack)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 13:15:26+00:00

The Marvel Cinematic Universe announced it was expanding with a new Israeli superhero and anti-Semites flooded social media with their hatred. Actress Shira Haas, who soared to fame with her role on the award-winning Israeli series “Shtisel,” will star as former Mossad agent Ruth Bat-Seraph, aka “Sabra,” in the next Captain America movie, “Captain America: ...

## British TV Network Censors Comedian John Oliver’s Jokes About Queen Elizabeth II
 - [https://www.dailywire.com/news/british-tv-network-censors-comedian-john-olivers-jokes-about-queen-elizabeth-ii](https://www.dailywire.com/news/british-tv-network-censors-comedian-john-olivers-jokes-about-queen-elizabeth-ii)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 12:52:49+00:00

Comedian John Oliver found himself on the wrong side of censors in the United Kingdom after he chose to include jokes about the late Queen Elizabeth II on his HBO show following her death. Sky News, which is owned by Comcast, cut out a short segment of the British comedian&#8217;s monologue during which he made ...

## It’s Been Nine Long Months Since Biden Said Inflation Peaked Last December
 - [https://www.dailywire.com/news/its-been-nine-long-months-since-biden-said-inflation-peaked-last-december](https://www.dailywire.com/news/its-been-nine-long-months-since-biden-said-inflation-peaked-last-december)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 12:44:48+00:00

A lot can change in nine months. President Joe Biden replaced his dog with a cat, took a spill on his bicycle, and has taken weeks upon weeks of vacation since last December. To the president&#8217;s chagrin, one thing that remains the same is the general trajectory of inflation. On December 10, 2021, Biden claimed ...

## Whistleblower Reveals What Information Twitter Collects From Users
 - [https://www.dailywire.com/news/whistleblower-reveals-what-information-twitter-collects-from-users](https://www.dailywire.com/news/whistleblower-reveals-what-information-twitter-collects-from-users)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 12:35:42+00:00

Twitter whistleblower and former head of security Peiter Zatko revealed to lawmakers on Tuesday that engineers have access to the plethora of data the social media company collects from users. Last month, Zatko alleged in a whistleblower account that Twitter lacks sufficient cybersecurity safeguards and claimed that executives misled board members about potential vulnerabilities that ...

## Boston Marathon Adds New Guidelines For ‘Non-Binary Athletes’
 - [https://www.dailywire.com/news/boston-marathon-adds-new-guidelines-for-non-binary-athletes](https://www.dailywire.com/news/boston-marathon-adds-new-guidelines-for-non-binary-athletes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 12:23:09+00:00

The Boston Marathon has added new guidelines for 2023 that will allow runners to register as &#8220;non-binary athletes.&#8221; The Boston Athletic Association (BAA) shared the announcement on Monday as registration opened for next year&#8217;s race. &#8220;The Boston Athletic Association is currently working on expanding opportunities for non-binary athletes at our events, including the upcoming 2023 ...

## Biden Vows ‘Cancer Moonshot,’ But Here’s What His Own Cancer Charity Spent On Research
 - [https://www.dailywire.com/news/biden-vows-cancer-moonshot-but-heres-what-his-own-cancer-charity-spent-on-research](https://www.dailywire.com/news/biden-vows-cancer-moonshot-but-heres-what-his-own-cancer-charity-spent-on-research)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 12:03:40+00:00

President Joe Biden has vowed a taxpayer-funded “moonshot” bid to cure cancer, but his own cancer charity spent millions on staff salaries and nothing on actual research, according to tax filings. Borrowing a phrase from former President Kennedy, Biden on Monday called on America to &#8220;end cancer as we know it.” Biden, who often talks about ...

## Christian College Sued By Students, Staff Over LGBTQ Hiring Ban
 - [https://www.dailywire.com/news/christian-college-sued-by-students-staff-over-lgbtq-hiring-ban](https://www.dailywire.com/news/christian-college-sued-by-students-staff-over-lgbtq-hiring-ban)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 11:59:53+00:00

A Christian college in Washington state has been sued by more than a dozen students and staff members over its LGBTQ hiring ban based on its religious beliefs. The lawsuit against Seattle Pacific University (SPU) was filed in Washington State Superior Court on Monday. The legal filing requests that interim President Pete Menjares and other ...

## Oprah, Who Many Blame For Interview That Tore Apart British Royal Family: ‘Burying Your Dead’ May Bring Peace
 - [https://www.dailywire.com/news/oprah-who-many-blame-for-interview-that-tore-apart-british-royal-family-burying-your-dead-may-bring-peace](https://www.dailywire.com/news/oprah-who-many-blame-for-interview-that-tore-apart-british-royal-family-burying-your-dead-may-bring-peace)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 11:44:26+00:00

Oprah Winfrey, who many blame for the interview that tore apart the Royal Family last year, offered her hope that the death of Queen Elizabeth would bring the family closer together. Winfrey, at the Toronto Film Festival for the premiere of “Sidney,” a film she co-produced about the late movie star Sidney Poitier, was asked ...

## Majority Of Twitter Shareholders Want Elon Musk At Helm Of The Company: Report
 - [https://www.dailywire.com/news/majority-of-twitter-shareholders-want-elon-musk-at-helm-of-the-company](https://www.dailywire.com/news/majority-of-twitter-shareholders-want-elon-musk-at-helm-of-the-company)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 11:39:11+00:00

A majority of Twitter shareholders voted in favor of a $44 billion deal to sell the social media company to Tesla and SpaceX CEO Elon Musk, according to a recent report from Reuters. Multiple sources told the outlet that the deadline for shareholders to submit votes on the deal is on Tuesday, although a sufficient ...

## ‘White Men Really Are Insufferable’: Jimmy Kimmel Blasted For Playing Dead During Black Creator’s Emmys Acceptance Speech
 - [https://www.dailywire.com/news/white-men-really-are-insufferable-jimmy-kimmel-blasted-for-playing-dead-during-black-creators-emmy-acceptance-speech](https://www.dailywire.com/news/white-men-really-are-insufferable-jimmy-kimmel-blasted-for-playing-dead-during-black-creators-emmy-acceptance-speech)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 11:27:09+00:00

The 2022 Emmy Awards went forward mostly without incident, except for a controversial bit by Jimmy Kimmel, which involved him playing dead on stage while the “Abbott Elementary” series creator and writer was accepting her award.  Kimmel got dragged out onto the stage by actor Will Arnett, who then announced the winner for best writing ...

## Rape Suspect Arrested Using App, Alligator Sign To Track Location
 - [https://www.dailywire.com/news/rape-suspect-arrested-using-app-alligator-sign-to-track-location](https://www.dailywire.com/news/rape-suspect-arrested-using-app-alligator-sign-to-track-location)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 11:22:32+00:00

A West Virginia man suspected of raping a teenager was arrested after investigators tracked his location using a phone app and an alligator sign as a clue. Coweta County, Georgia, authorities revealed that after the suspect allowed a 17-year-old female girl to use her smartphone after the alleged rape, she was able to tip them ...

## ‘Woefully Inadequate’: Arizona Sheriffs Condemn Biden Administration And CBP On Immigration
 - [https://www.dailywire.com/news/woefully-inadequate-arizona-sheriffs-condemn-biden-administration-and-cbp-on-immigration](https://www.dailywire.com/news/woefully-inadequate-arizona-sheriffs-condemn-biden-administration-and-cbp-on-immigration)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 11:12:21+00:00

In a letter addressed to President Biden, the Arizona Sheriff’s Association slammed the Biden administration for its dilatory attitude regarding illegal immigration and expressed their lack of confidence in CBP Commissioner Chris Magnus. The letter cited the fact that curbing the number of illegal immigrants and illicit drugs crossing the border had been a priority ...

## Valedictorian Could Lose License To Practice Over Graduation Speech Bucking Radical Gender Theory: Report
 - [https://www.dailywire.com/news/valedictorian-could-lose-license-to-practice-over-graduation-speech-bucking-radical-gender-theory-report](https://www.dailywire.com/news/valedictorian-could-lose-license-to-practice-over-graduation-speech-bucking-radical-gender-theory-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 10:44:25+00:00

A university student in Mexico is facing the loss of his license to practice psychology over a speech he gave as the school&#8217;s valedictorian challenging radical gender theory and defending the traditional family, according to legal nonprofit Alliance Defending Freedom (ADF) International. The Autonomous University of Baja California is expected to make a judgement in ...

## ‘The Duchess Of Netflix’: Video Of Meghan Markle Getting Snubbed By Mourners Inspires Mockery
 - [https://www.dailywire.com/news/the-duchess-of-netflix-video-of-meghan-markle-getting-snubbed-by-mourners-inspires-mockery](https://www.dailywire.com/news/the-duchess-of-netflix-video-of-meghan-markle-getting-snubbed-by-mourners-inspires-mockery)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 10:37:57+00:00

A video of Meghan Markle seemingly being snubbed while greeting a group of mourners is getting all sorts of reactions on social media. The Duchess of Sussex was in London over the weekend as royal family members gathered to mourn the death of Queen Elizabeth. It was the first time in years that Prince Harry, ...

## August Inflation Report Shows Several Nasty Surprises, Biden Claims Victory Anyway
 - [https://www.dailywire.com/news/august-inflation-report-shows-several-nasty-surprises-biden-claims-victory-anyway](https://www.dailywire.com/news/august-inflation-report-shows-several-nasty-surprises-biden-claims-victory-anyway)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 10:31:34+00:00

The Consumer Price Index (CPI) rose 8.3% between August 2021 and August 2022, according to a Tuesday report from the Bureau of Labor Statistics. The reading marks a decline from the 8.5% year-over-year rate seen in July and the 9.1% year-over-year rate seen in June as gasoline prices continue to fall. However, month-over-month prices for ...

## Florida Gubernatorial Candidate Charlie Crist Portrays Himself As Jesus Christ Fighting Against ‘DeSatan’
 - [https://www.dailywire.com/news/florida-gubernatorial-candidate-charlie-crist-portrays-himself-as-jesus-christ-fighting-against-desatan](https://www.dailywire.com/news/florida-gubernatorial-candidate-charlie-crist-portrays-himself-as-jesus-christ-fighting-against-desatan)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 08:51:08+00:00

Florida Democrat gubernatorial candidate Charlie Crist compared himself to Jesus in a bizarre stump speech that was uncovered this week in which he said he was fighting against &#8220;DeSatan,&#8221; a reference to the state&#8217;s popular Republican Governor Ron DeSantis. The Daily Caller reported that the video was from a March 17, 2022, campaign event where ...

## Disgraced Former CNN Host Chris Cuomo Slams Democrats For Demonizing Everyone Who Voted For Trump
 - [https://www.dailywire.com/news/disgraced-former-cnn-host-chris-cuomo-slams-democrats-for-demonizing-everyone-who-voted-for-trump](https://www.dailywire.com/news/disgraced-former-cnn-host-chris-cuomo-slams-democrats-for-demonizing-everyone-who-voted-for-trump)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 07:43:17+00:00

Disgraced former CNN host Chris Cuomo slammed Democrats for demonizing everyone who voted for former President Donald Trump, saying that some Trump supporters &#8220;are very open to reasonable, regular rhetoric.&#8221; Cuomo responded to a leftist who claimed that Trump supporters &#8220;demonize immigrants, Jews, African Americans and anyone who isn’t &#8216;Christian&#8217; by their standards.&#8221; &#8220;I think ...

## Biden’s DOJ Signals It Is Open To Trump’s Pick For Special Master
 - [https://www.dailywire.com/news/bidens-doj-signals-it-is-open-to-trumps-pick-for-special-master](https://www.dailywire.com/news/bidens-doj-signals-it-is-open-to-trumps-pick-for-special-master)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-09-13 07:18:05+00:00

The U.S. Department of Justice signaled in a court filing this week that it is open to accepting one of former President Donald Trump&#8217;s picks to be the special master who reviews the documents that the FBI seized from Mar-a-Lago last month. Prosecutors said in a court filing that they would approve of Raymond J. ...


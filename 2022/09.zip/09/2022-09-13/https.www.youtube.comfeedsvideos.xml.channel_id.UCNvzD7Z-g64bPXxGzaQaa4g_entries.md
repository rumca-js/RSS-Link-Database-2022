# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 BIG NEW PlayStation State of Play Announcements
 - [https://www.youtube.com/watch?v=TKLnbvzwrhI](https://www.youtube.com/watch?v=TKLnbvzwrhI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-09-14 00:00:00+00:00

Sony held a new State of Play streaming event this September 2022 revealing new games and release dates. Let's talk.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:15 Tekken 8
2:11 Like A Dragon Ishin
3:54 Star Wars Tales of The Galaxy Enhanced Edtition
5:07 Pacific Drive
6:23 Exclusive Hogwarts Legacy Quest
7:06 Playstation Stars
8:09 Synduality
9:16 God of War Ragnarok Controller
10:22 Stellar Blade
11:43 Rise of the Ronin

## What the hell is going on with ASSASSIN'S CREED?
 - [https://www.youtube.com/watch?v=ZmyaYt0lhrQ](https://www.youtube.com/watch?v=ZmyaYt0lhrQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-09-13 00:00:00+00:00

The Assassin's Creed franchise is expanding into mobile, Japan (finally) and even nostalgic territory. Let's talk about what all the recent announcements mean.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


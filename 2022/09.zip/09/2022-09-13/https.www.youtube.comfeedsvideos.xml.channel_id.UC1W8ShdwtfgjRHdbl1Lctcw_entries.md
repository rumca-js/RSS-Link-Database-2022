# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## San Francisco early 40's,50's in color [60fps,Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=fVJ2b6gOP5A](https://www.youtube.com/watch?v=fVJ2b6gOP5A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2022-09-14 00:00:00+00:00

I colorized, restored and created a sound design for this video of the San Francisco early 40's and early 50's you can clearly see what is going on during the day, we start with a tower in the downtown area, Passing by the Market Street, After a drive in the early 50's in the residential area,  At the end a panoramic view of the city of San Francisco,

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance (not historically accurate)
✔sound design added only for the ambiance
✔restoration:(stabilisation,denoise,cleand,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

B&W Video Source from: Rick Prelinger, Internet Archive

Rights to the black and white Video Source are held by Internet Archive. under the Creative Commons Attribution License


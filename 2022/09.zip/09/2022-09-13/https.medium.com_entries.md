## Software Component Names Should Be Whimsical And Cryptic | by Aaron Zinger | Sep, 2022 | Medium
 - [https://medium.com/@histocrat/software-component-names-should-be-whimsical-and-cryptic-ca260b013de0](https://medium.com/@histocrat/software-component-names-should-be-whimsical-and-cryptic-ca260b013de0)
 - RSS feed: https://medium.com
 - date published: 2022-09-13 09:59:12.151786+00:00

Descriptive names considered harmful.


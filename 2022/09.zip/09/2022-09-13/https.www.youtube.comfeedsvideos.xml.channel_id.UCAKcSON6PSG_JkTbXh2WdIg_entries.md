# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Ka Lia Universe – Dej Txias Cold Water (live for The Current)
 - [https://www.youtube.com/watch?v=NQBybn3gijI](https://www.youtube.com/watch?v=NQBybn3gijI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-09-14 00:00:00+00:00

Ka Lia Universe performed at the MPR Booth at the 2022 Minnesota State Fair. The Hmong-American pop singer is from St Paul and put on a lively set for fairgoers on a bright, sunny day. Watch Ka Lia Universe's performance of "Dej Txias Cold Water," recorded live at the State Fair. 

Host – Diane
Guests – Ka Lia Universe
Producer – Tom Campbell
Camera Operators – Evan Clark and Tom Campbell
Audio – Eric Xu Romani

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

This activity is made possible in part by the Minnesota Legacy Amendment's Arts & Cultural Heritage Fund.

#kaliauniverse #losingulosingme #dejtxias #fairytale #hmongamerican #hmong #popmusic #stpaulmusic #mnstatefair

## Ka Lia Universe live at the Minnesota State Fair
 - [https://www.youtube.com/watch?v=tSJPL0GnS84](https://www.youtube.com/watch?v=tSJPL0GnS84)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-09-13 00:00:00+00:00

Ka Lia Universe performed three songs from the MPR Booth at the 2022 Minnesota State Fair, followed by an interview with The Current's Local Show host Diane. The Hmong-American pop singer is from St Paul and put on a lively set for fairgoers on a bright, sunny day. She spoke with Diane about her influences, Hmong roots, and recent performance at First Avenue's Mainroom.

Songs Played 
0:00:00 Losin' U, Losin' Me
0:02:58 Fairytale 
0:06:25 Dej Txias (Cold Water)
0:11:15 Interview

Host – Diane
Guests – Ka Lia Universe
Producer – Tom Campbell
Camera Operators – Evan Clark and Tom Campbell
Audio – Eric Xu Romani

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

This activity is made possible in part by the Minnesota Legacy Amendment's Arts & Cultural Heritage Fund.

#kaliauniverse #losingulosingme #dejtxias #fairytale #hmongamerican #hmong #popmusic #stpaulmusic #mnstatefair

## Phoenix – 1901 (live for The Current)
 - [https://www.youtube.com/watch?v=RfpDoWG4Iig](https://www.youtube.com/watch?v=RfpDoWG4Iig)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-09-13 00:00:00+00:00

Hours before launching their Alpha Zulu tour at the Palace Theatre in St. Paul, Minn., on Tuesday, Sept. 6, French indie-pop band Phoenix visited The Current studio to perform a set of songs — including two from the new album — as well as this throwback to their 2009 album, "Wolfgang Amadeus Phoenix." Watch Phoenix perform "1901" during a session recorded live in The Current studio.

Band members
Thomas Mars
Deck D'Arcy
Christian Mazzalai
Laurent Brancowitz

Credits
Guests – Phoenix
Producer – Derrick Stevens
Director – Erik Stromstad
Camera Operators – Erik Stromstad, Evan Clark
Audio – Eric Xu Romani
Video Editor – Evan Clark
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

#phoenix @welovephoenix


# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## 'You're good, bud!': Man books it during traffic stop for no reason, only to give the officer a reason
 - [https://www.louderwithcrowder.com/traffic-stop-stupid-meth](https://www.louderwithcrowder.com/traffic-stop-stupid-meth)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-13 21:02:36+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31701172&amp;width=1245&amp;height=700&amp;coordinates=0%2C59%2C0%2C59" /><br /><br /><p>Democrats love their drug addicts and criminals. They also aren't very bright. The guy in this video who thought it would be a bright idea to just take off during a traffic stop for effectively no reason is probably the entire Democratic Party's spirit animal. Enjoy seeing just how stupid this guy is and just how funny it gets. Shout out 

## 'That's an applause line': Nancy Pelosi blows smoke up POTUS' patootie, lectures crowd for not clapping
 - [https://www.louderwithcrowder.com/nancy-pelosi-applause-line](https://www.louderwithcrowder.com/nancy-pelosi-applause-line)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-13 20:40:02+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31700922&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>On a day when the stock market is having its worst performance since the start of the pandemic due to a worse-than-expected inflation report, Joe Biden is celebrating his so-called Inflation Reduction Act. Yes, <a href="https://www.louderwithcrowder.com/search/?q=inflation+reduction+act" target="_blank">the same one that doesn't do anythi

## Against pro-life advocate Lila Rose, leftists are out-classed and out-gunned: 'It is a scientific fact'
 - [https://www.louderwithcrowder.com/lila-rose-dr-phil-abortion](https://www.louderwithcrowder.com/lila-rose-dr-phil-abortion)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-13 20:35:39+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31701141&amp;width=1245&amp;height=700&amp;coordinates=0%2C89%2C0%2C29" /><br /><br /><p>I don't know what <a href="https://www.louderwithcrowder.com/james-lindsay-professor-crt" target="_blank">Dr. Phil </a>was thinking when he invited <a href="https://www.louderwithcrowder.com/lila-rose-what-planned-parenthoods-doing-is-illegalhttps://www.louderwithcrowder.com/lila-rose-what-planned-parenthoods-doing-is-illegal" target="_bl

## EXCLUSIVE: Professor peddles CRT, Marxism, and advocates for censorship: 'A lot of noise needs to be made'
 - [https://www.louderwithcrowder.com/exclusive-professor-woke-marxist-censorship](https://www.louderwithcrowder.com/exclusive-professor-woke-marxist-censorship)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-13 18:16:07+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31699137&amp;width=1245&amp;height=700&amp;coordinates=0%2C67%2C0%2C67" /><br /><br /><p>Anyone who has attended a university in the past decade or so can attest to the wokeness that's injected into nearly every single subject. A discussion cannot be had about literature without also considering how writing about black characters serves as a form of slavery by profiting off the depictions of black bodies. We must first agree 

## 'Not on my watch': Crowd erupts as Ron DeSantis GOES OFF on elites and what their pandemic endgame was
 - [https://www.louderwithcrowder.com/ron-desantis-elities-speech](https://www.louderwithcrowder.com/ron-desantis-elities-speech)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-13 18:08:22+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31699817&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C220" /><br /><br /><p>Turns out, lots of what we were told about the pandemic was hooey, and the people spreading the hooey are trying to rewrite the history concerning said hooey. As someone who the hooey spreaders treated as an enemy of the state, America's Governor Ron DeSantis has no intention of letting that happen.</p><p>Little by little, everything bein

## Twitter whistleblower shocker: 4000 employees have access to your personal info, can dox users on a whim
 - [https://www.louderwithcrowder.com/twitter-whistleblower-4000-emplioyees](https://www.louderwithcrowder.com/twitter-whistleblower-4000-emplioyees)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-13 17:14:12+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31699314&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>There is another Big Tech senate hearing happening today. For sake of argument, let's pretend that unlike all the other Big Tech hearings, something may happen other than senators getting clips of themselves bloviating that they then share on Big Tech platforms. Because the Twitter whistleblower's comments on doxxing are terrifying.</p><p

## EXCLUSIVE: CROWDER EXPOSES COLLEGE PROFESSOR. IS IT YOURS? (Show Notes)
 - [https://www.louderwithcrowder.com/crowder-exposes-college-professor](https://www.louderwithcrowder.com/crowder-exposes-college-professor)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-13 14:26:23+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31698569&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C200%2C0" /><br /><br /><p>We debut a new exclusive feature MAKE MY PROFESSOR FAMOUS. Our first "educator" trying to indoctrinate students into Marxism comes from the University of North Texas. Also, Brian Stelter got a job at Harvard for some dumb reason. And what's with conservatives being elected in socialist Europe?</p><p class="shortcode-media shortcode-media-

## Watch: Men attempt to eat in Los Angeles restaurant, get robbed at gunpoint in broad daylight
 - [https://www.louderwithcrowder.com/restaurant-robbery-gunpoint](https://www.louderwithcrowder.com/restaurant-robbery-gunpoint)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-13 14:24:13+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31698448&amp;width=1200&amp;height=800&amp;coordinates=11%2C0%2C12%2C0" /><br /><br /><p>Crime waves in progressive-run cities are no longer shocking. The only thing shocking is the brazen way the thugs, punks, and nogoodniks go about it. Like this clip for example. Two men walk into a restaurant and rob two other men at gunpoint. In broad daylight.</p><p>Yes, this takes place in <a href="https://www.louderwithcrowder.com/sea

## Liberal news outlet slams Marco Rubio's 'factually inaccurate' claim that men can't get pregnant
 - [https://www.louderwithcrowder.com/marco-rubio-pregnant](https://www.louderwithcrowder.com/marco-rubio-pregnant)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-13 13:41:47+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31698228&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C176" /><br /><br /><p>Senator Marco Rubio is under fire for claiming that men can't get pregnant. Liberal video journalismers The Recount, which brags that "everything is politics," has labeled Rubio's claims as "transphobic" and "factually inaccurate."</p><p><a href="https://www.louderwithcrowder.com/search/?q=marco+rubio" target="_blank">Sen. Rubio</a> made 

## Velma smeared as racist 'Karen' for calling cops on LeBron James in 'Scooby Doo' game, Warner Bros caves
 - [https://www.louderwithcrowder.com/scooby-doo-velma-video-game](https://www.louderwithcrowder.com/scooby-doo-velma-video-game)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-13 12:52:42+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31698036&amp;width=1245&amp;height=700&amp;coordinates=0%2C59%2C0%2C59" /><br /><br /><p>A fringe minority of random idiots on the internet got Warner Bros to change a video game after labeling Velma from Scooby Doo a racist "Karen" who calls cops on black people. I would call this the dumbest outrage yet, but whenever I do I jinx us all.</p><p>Warner Bros has a fighting <a href="https://www.louderwithcrowder.com/search/?q=vi

## Watch: Police tackle guy who called alleged pedo Prince Andrew 'sick old man' during Queen's funeral procession
 - [https://www.louderwithcrowder.com/prince-andrew-heckled](https://www.louderwithcrowder.com/prince-andrew-heckled)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-09-13 11:54:56+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31697539&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>The Queen is dead. Long live the... meh. I don't get Americans having strong opinions either way. Not to mention, the queen died in 1992. To the zoomers at Meta who decide "community guidelines," that's a reference to Freddie Mercury being the lead singer of a band called Queen and not a slur. </p><p>While I don't care about the Queen, th


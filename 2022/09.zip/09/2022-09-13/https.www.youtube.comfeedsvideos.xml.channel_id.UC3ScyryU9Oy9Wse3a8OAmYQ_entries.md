# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## Inside the Epic Political Battle Over the Debt Ceiling in 2012 (documentary) | FRONTLINE
 - [https://www.youtube.com/watch?v=galprD-cW-s](https://www.youtube.com/watch?v=galprD-cW-s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2022-09-13 00:00:00+00:00

FRONTLINE investigated how a clash of politics and personalities in 2012-2013 took the U.S. economy to the edge of the “fiscal cliff.” (Aired 2013)

This journalism is made possible by viewers like you. Support your local PBS station here: http://www.pbs.org/donate​.

Based on interviews with key Republican and Democratic players including former Speaker of the House John Boehner, former White House adviser Gene Sperling and President Obama’s former Chief of Staff William Daley, “Cliffhanger” investigated how a struggle over America’s debt ceiling and deficit problems led to a bitter, high-stakes standoff. 

Explore additional reporting on "Cliffhanger" on our website:
https://www.pbs.org/wgbh/frontline/documentary/cliffhanger/

#Documentary #DebtCeiling #USeconomy

Subscribe on YouTube: http://bit.ly/1BycsJW​
Instagram: https://www.instagram.com/frontlinepbs​
Twitter: https://twitter.com/frontlinepbs​
Facebook: https://www.facebook.com/frontline

FRONTLINE is produced at GBH in Boston and is broadcast nationwide on PBS. Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Additional funding is provided by the Abrams Foundation; the John D. and Catherine T. MacArthur Foundation; Park Foundation; and the FRONTLINE Journalism Fund with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundation, and additional support from Koo and Patricia Yuen.

CHAPTERS:
Prologue - 00:00
Republicans Elected in the 2010 Midterms - 0:49
The "Young Guns:" Eric Cantor, Kevin McCarthy, Paul Ryan - 08:41
The President and the House Speaker’s Grand Bargain - 15:41
Another Deal from the Senate - 25:212
Teetering on the Fiscal Cliff - 35:02
Credits - 51:57


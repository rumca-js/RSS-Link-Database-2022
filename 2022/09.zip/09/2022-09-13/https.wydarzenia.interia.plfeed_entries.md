# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Zełenski: Ponad 4000 km kw. terytorium odbitego od Rosjan pod kontrolą Ukrainy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-ponad-4000-km-kw-terytorium-odbitego-od-rosjan-pod-,nId,6283676](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-ponad-4000-km-kw-terytorium-odbitego-od-rosjan-pod-,nId,6283676)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 20:23:56+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-ponad-4000-km-kw-terytorium-odbitego-od-rosjan-pod-,nId,6283676"><img align="left" alt="Zełenski: Ponad 4000 km kw. terytorium odbitego od Rosjan pod kontrolą Ukrainy" src="https://i.iplsc.com/zelenski-ponad-4000-km-kw-terytorium-odbitego-od-rosjan-pod/000EQVPVIOT44A2G-C321.jpg" /></a>Ukraina ma pełną kontrolę nad ponad 4000 km kw. terytorium odbitego od sił rosyjskich - mówił we wtorkowym wieczornym

## Biały Dom: Putin wciąż ma dużo zdolności wojskowych do dyspozycji, nie tylko w Ukrainie
 - [https://wydarzenia.interia.pl/zagranica/news-bialy-dom-putin-wciaz-ma-duzo-zdolnosci-wojskowych-do-dyspoz,nId,6283669](https://wydarzenia.interia.pl/zagranica/news-bialy-dom-putin-wciaz-ma-duzo-zdolnosci-wojskowych-do-dyspoz,nId,6283669)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 20:03:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bialy-dom-putin-wciaz-ma-duzo-zdolnosci-wojskowych-do-dyspoz,nId,6283669"><img align="left" alt="Biały Dom: Putin wciąż ma dużo zdolności wojskowych do dyspozycji, nie tylko w Ukrainie" src="https://i.iplsc.com/bialy-dom-putin-wciaz-ma-duzo-zdolnosci-wojskowych-do-dyspoz/000FACT0U9Q0QQH8-C321.jpg" /></a>Rosja wciąż ma duże zdolności wojskowe do wykorzystania nie tylko w Ukrainie, ale potencjalnie także gdzieś indziej - mówił rzecznik Rady 

## Zwierzęcy dramat na Kaszubach. 62-latek znęcał się nad kucykami
 - [https://wydarzenia.interia.pl/pomorskie/news-zwierzecy-dramat-na-kaszubach-62-latek-znecal-sie-nad-kucyka,nId,6283635](https://wydarzenia.interia.pl/pomorskie/news-zwierzecy-dramat-na-kaszubach-62-latek-znecal-sie-nad-kucyka,nId,6283635)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 19:55:37+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-zwierzecy-dramat-na-kaszubach-62-latek-znecal-sie-nad-kucyka,nId,6283635"><img align="left" alt="Zwierzęcy dramat na Kaszubach. 62-latek znęcał się nad kucykami" src="https://i.iplsc.com/zwierzecy-dramat-na-kaszubach-62-latek-znecal-sie-nad-kucyka/000G2CN7JVRB741Q-C321.jpg" /></a>62-letni mieszkaniec Żukowa z powiatu kartuskiego (woj. pomorskie) został nagrany podczas znęcania się nad parą młodych koni, które przywiązał do samochodu. W pew

## Trumna z ciałem Elżbiety II w Pałacu Buckingham
 - [https://wydarzenia.interia.pl/zagranica/news-trumna-z-cialem-elzbiety-ii-w-palacu-buckingham,nId,6283651](https://wydarzenia.interia.pl/zagranica/news-trumna-z-cialem-elzbiety-ii-w-palacu-buckingham,nId,6283651)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 19:14:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-trumna-z-cialem-elzbiety-ii-w-palacu-buckingham,nId,6283651"><img align="left" alt="Trumna z ciałem Elżbiety II w Pałacu Buckingham   " src="https://i.iplsc.com/trumna-z-cialem-elzbiety-ii-w-palacu-buckingham/000G2CTLAGH2U3U3-C321.jpg" /></a>Karawan wiozący trumnę z ciałem brytyjskiej królowej Elżbiety II dotarł we wtorek wieczorem do Pałacu Buckingham w Londynie, gdzie czekali na nią król Karol III, królowa-małżonka Camilla i pozostali cz

## Gdynia. Uśmiercono chorego łosia. Zwierzę próbowało atakować ludzi
 - [https://wydarzenia.interia.pl/pomorskie/news-gdynia-usmiercono-chorego-losia-zwierze-probowalo-atakowac-l,nId,6283627](https://wydarzenia.interia.pl/pomorskie/news-gdynia-usmiercono-chorego-losia-zwierze-probowalo-atakowac-l,nId,6283627)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 19:00:52+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-gdynia-usmiercono-chorego-losia-zwierze-probowalo-atakowac-l,nId,6283627"><img align="left" alt="Gdynia. Uśmiercono chorego łosia. Zwierzę próbowało atakować ludzi" src="https://i.iplsc.com/gdynia-usmiercono-chorego-losia-zwierze-probowalo-atakowac-l/0002H0Y3VX2IC7X6-C321.jpg" /></a>W Gdyni uśmiercono chorego łosia, który od kilku dni przebywał na terenie Trójmiasta. Informację na ten temat przekazał gdyński magistrat. Jak wynikało z wcześ

## Ukraina: Su-24 i Su-25 zestrzelone w ciągu dwóch godzin
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-su-24-i-su-25-zestrzelone-w-ciagu-dwoch-godzin,nId,6283607](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-su-24-i-su-25-zestrzelone-w-ciagu-dwoch-godzin,nId,6283607)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 18:43:05+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-su-24-i-su-25-zestrzelone-w-ciagu-dwoch-godzin,nId,6283607"><img align="left" alt="Ukraina: Su-24 i Su-25 zestrzelone w ciągu dwóch godzin" src="https://i.iplsc.com/ukraina-su-24-i-su-25-zestrzelone-w-ciagu-dwoch-godzin/000G2CEK5XCWIUQ8-C321.jpg" /></a>Dowództwo Powietrznych Sił Zbrojnych potwierdziło informację o zestrzeleniu drona i dwóch rosyjskich maszyn - bombowca Su-24 w obwodzie chersońskim ora

## "Tego człowieka już nie ma. Wypadł z systemu". Macierewicz w PiS-ie to dziś margines
 - [https://wydarzenia.interia.pl/autor/lukasz-rogojsz/news-tego-czlowieka-juz-nie-ma-wypadl-z-systemu-macierewicz-w-pis,nId,6283594](https://wydarzenia.interia.pl/autor/lukasz-rogojsz/news-tego-czlowieka-juz-nie-ma-wypadl-z-systemu-macierewicz-w-pis,nId,6283594)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 17:17:55+00:00

<p><a href="https://wydarzenia.interia.pl/autor/lukasz-rogojsz/news-tego-czlowieka-juz-nie-ma-wypadl-z-systemu-macierewicz-w-pis,nId,6283594"><img align="left" alt="&quot;Tego człowieka już nie ma. Wypadł z systemu&quot;. Macierewicz w PiS-ie to dziś margines" src="https://i.iplsc.com/tego-czlowieka-juz-nie-ma-wypadl-z-systemu-macierewicz-w-pis/000G2CDM23A5W4V2-C321.jpg" /></a>Po emisji reportażu &quot;Siła kłamstwa&quot; w magazynie &quot;Czarno na białym&quot;, dotyczącym manipulacji w pracach

## Kaczyński w Pruszkowie: Prąd dla każdej rodziny będzie po dotychczasowej cenie
 - [https://wydarzenia.interia.pl/kraj/news-kaczynski-w-pruszkowie-prad-dla-kazdej-rodziny-bedzie-po-dot,nId,6283582](https://wydarzenia.interia.pl/kraj/news-kaczynski-w-pruszkowie-prad-dla-kazdej-rodziny-bedzie-po-dot,nId,6283582)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 16:57:16+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kaczynski-w-pruszkowie-prad-dla-kazdej-rodziny-bedzie-po-dot,nId,6283582"><img align="left" alt="Kaczyński w Pruszkowie: Prąd dla każdej rodziny będzie po dotychczasowej cenie " src="https://i.iplsc.com/kaczynski-w-pruszkowie-prad-dla-kazdej-rodziny-bedzie-po-dot/000G2CBMRO5LL655-C321.jpg" /></a>Podjęliśmy działania zmierzające do tego, żeby prąd dla każdej rodziny do zużycia 2000 kWh był po cenie stałej, w gruncie rzeczy dotychczasowej - powie

## Kaczyński w Pruszkowie: Prąd dla niemal każdej rodziny będzie po dotychczasowej cenie
 - [https://wydarzenia.interia.pl/kraj/news-kaczynski-w-pruszkowie-prad-dla-niemal-kazdej-rodziny-bedzie,nId,6283582](https://wydarzenia.interia.pl/kraj/news-kaczynski-w-pruszkowie-prad-dla-niemal-kazdej-rodziny-bedzie,nId,6283582)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 16:57:16+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kaczynski-w-pruszkowie-prad-dla-niemal-kazdej-rodziny-bedzie,nId,6283582"><img align="left" alt="Kaczyński w Pruszkowie: Prąd dla niemal każdej rodziny będzie po dotychczasowej cenie " src="https://i.iplsc.com/kaczynski-w-pruszkowie-prad-dla-niemal-kazdej-rodziny-bedzie/000G2CA19HP5LIUP-C321.jpg" /></a>Podjęliśmy działania zmierzające do tego, żeby prąd dla każdej rodziny do zużycia 2000 kWh był po cenie stałej, w gruncie rzeczy dotychczasowej 

## Kanclerz Niemiec zażądał od Putina "całkowitego wycofania się" z Ukrainy
 - [https://wydarzenia.interia.pl/zagranica/news-kanclerz-niemiec-zazadal-od-putina-calkowitego-wycofania-sie,nId,6283577](https://wydarzenia.interia.pl/zagranica/news-kanclerz-niemiec-zazadal-od-putina-calkowitego-wycofania-sie,nId,6283577)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 16:38:57+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kanclerz-niemiec-zazadal-od-putina-calkowitego-wycofania-sie,nId,6283577"><img align="left" alt="Kanclerz Niemiec zażądał od Putina &quot;całkowitego wycofania się&quot; z Ukrainy" src="https://i.iplsc.com/kanclerz-niemiec-zazadal-od-putina-calkowitego-wycofania-sie/000G2C9JXE7TI55C-C321.jpg" /></a>Kanclerz Niemiec Olaf Scholz rozmawiał przez telefon z prezydentem Rosji Władimirem Putinem - informuje Reuters. Scholz wezwał do znalezienia d

## Najlepsze memy o rachunkach za ogrzewanie i wysokich cenach paliw. Internauci nie zawiedli!
 - [https://wydarzenia.interia.pl/kraj/news-najlepsze-memy-o-rachunkach-za-ogrzewanie-i-wysokich-cenach-,nId,6260371](https://wydarzenia.interia.pl/kraj/news-najlepsze-memy-o-rachunkach-za-ogrzewanie-i-wysokich-cenach-,nId,6260371)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 16:34:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-najlepsze-memy-o-rachunkach-za-ogrzewanie-i-wysokich-cenach-,nId,6260371"><img align="left" alt="Najlepsze memy o rachunkach za ogrzewanie i wysokich cenach paliw. Internauci nie zawiedli!" src="https://i.iplsc.com/najlepsze-memy-o-rachunkach-za-ogrzewanie-i-wysokich-cenach/000G2A5ZY1ABPLVN-C321.jpg" /></a>Kilkunastoprocentowa inflacja oraz coraz wyższe rachunki z każdym dniem mocniej dają się nam we znaki. Jedni załamują ręce, a inni znajdują 

## Śmiech przez łzy, czyli najlepsze memy o drożyźnie, inflacji i wysokich rachunkach
 - [https://wydarzenia.interia.pl/kraj/news-smiech-przez-lzy-czyli-najlepsze-memy-o-drozyznie-inflacji-i,nId,6260371](https://wydarzenia.interia.pl/kraj/news-smiech-przez-lzy-czyli-najlepsze-memy-o-drozyznie-inflacji-i,nId,6260371)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 16:34:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-smiech-przez-lzy-czyli-najlepsze-memy-o-drozyznie-inflacji-i,nId,6260371"><img align="left" alt="Śmiech przez łzy, czyli najlepsze memy o drożyźnie, inflacji i wysokich rachunkach" src="https://i.iplsc.com/smiech-przez-lzy-czyli-najlepsze-memy-o-drozyznie-inflacji-i/000G2A5ZY1ABPLVN-C321.jpg" /></a>Kilkunastoprocentowa inflacja oraz coraz wyższe rachunki z każdym dniem mocniej dają się nam we znaki. Jedni załamują ręce, a inni znajdują w tym po

## "Kopiuj-wklej" czy "strzał z grubej rury"? Błaszczak poszedł na zakupy
 - [https://wydarzenia.interia.pl/kraj/news-kopiuj-wklej-czy-strzal-z-grubej-rury-blaszczak-poszedl-na-z,nId,6283388](https://wydarzenia.interia.pl/kraj/news-kopiuj-wklej-czy-strzal-z-grubej-rury-blaszczak-poszedl-na-z,nId,6283388)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 16:17:33+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kopiuj-wklej-czy-strzal-z-grubej-rury-blaszczak-poszedl-na-z,nId,6283388"><img align="left" alt="&quot;Kopiuj-wklej&quot; czy &quot;strzał z grubej rury&quot;? Błaszczak poszedł na zakupy" src="https://i.iplsc.com/kopiuj-wklej-czy-strzal-z-grubej-rury-blaszczak-poszedl-na-z/000G2BPQRDHB6W5V-C321.jpg" /></a>Minister Mariusz Błaszczak poinformował, że Polska złożyła ofertę w sprawie zakupu 96 śmigłowców Apache. - Wystrzelił z grubej rury - mówi I

## Siergiej Ławrow z wizą na Zgromadzenie Ogólne ONZ
 - [https://wydarzenia.interia.pl/zagranica/news-siergiej-lawrow-z-wiza-na-zgromadzenie-ogolne-onz,nId,6283406](https://wydarzenia.interia.pl/zagranica/news-siergiej-lawrow-z-wiza-na-zgromadzenie-ogolne-onz,nId,6283406)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 16:17:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-siergiej-lawrow-z-wiza-na-zgromadzenie-ogolne-onz,nId,6283406"><img align="left" alt="Siergiej Ławrow z wizą na Zgromadzenie Ogólne ONZ" src="https://i.iplsc.com/siergiej-lawrow-z-wiza-na-zgromadzenie-ogolne-onz/000FTLSKB9FBBL2L-C321.jpg" /></a>Siergiej Ławrow i jego współpracownicy otrzymali wizę i będą mogli udać się na Zgromadzenie Ogólne ONZ w Nowym Jorku - informuje agencja Reutera za rosyjską agencją Interfax. Rosja od dłuższego czas

## Nowy warunek na Węgrzech dla kobiet chcących usunąć ciążę
 - [https://wydarzenia.interia.pl/zagranica/news-nowy-warunek-na-wegrzech-dla-kobiet-chcacych-usunac-ciaze,nId,6283411](https://wydarzenia.interia.pl/zagranica/news-nowy-warunek-na-wegrzech-dla-kobiet-chcacych-usunac-ciaze,nId,6283411)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 15:54:36+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowy-warunek-na-wegrzech-dla-kobiet-chcacych-usunac-ciaze,nId,6283411"><img align="left" alt="Nowy warunek na Węgrzech dla kobiet chcących usunąć ciążę" src="https://i.iplsc.com/nowy-warunek-na-wegrzech-dla-kobiet-chcacych-usunac-ciaze/000G2C9XGQFWARWD-C321.jpg" /></a>Nowe przepisy aborcyjne na Węgrzech. Kobiety chętne do jej przeprowadzenia będą musiały wcześniej posłuchać bicia serca płodu.</p><br clear="all" />

## Karol III w Irlandii Północnej. Deklarował, że będzie dbał o dobro mieszkańców
 - [https://wydarzenia.interia.pl/zagranica/news-karol-iii-w-irlandii-polnocnej-deklarowal-ze-bedzie-dbal-o-d,nId,6283381](https://wydarzenia.interia.pl/zagranica/news-karol-iii-w-irlandii-polnocnej-deklarowal-ze-bedzie-dbal-o-d,nId,6283381)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 15:34:39+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-karol-iii-w-irlandii-polnocnej-deklarowal-ze-bedzie-dbal-o-d,nId,6283381"><img align="left" alt="Karol III w Irlandii Północnej. Deklarował, że będzie dbał o dobro mieszkańców" src="https://i.iplsc.com/karol-iii-w-irlandii-polnocnej-deklarowal-ze-bedzie-dbal-o-d/000G2BQRG5DF0RU0-C321.jpg" /></a>Król Karol III złożył pierwszą wizytę w Irlandii Północnej, gdzie mówił, że królowa Elżbieta II nigdy nie przestała się modlić o pomyślność tego kr

## "Metalowe ciała obce" w serze. GIS ostrzega konsumentów
 - [https://wydarzenia.interia.pl/kraj/news-metalowe-ciala-obce-w-serze-gis-ostrzega-konsumentow,nId,6283368](https://wydarzenia.interia.pl/kraj/news-metalowe-ciala-obce-w-serze-gis-ostrzega-konsumentow,nId,6283368)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 15:04:44+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-metalowe-ciala-obce-w-serze-gis-ostrzega-konsumentow,nId,6283368"><img align="left" alt="&quot;Metalowe ciała obce&quot; w serze. GIS ostrzega konsumentów" src="https://i.iplsc.com/metalowe-ciala-obce-w-serze-gis-ostrzega-konsumentow/000G2BMWOSW8D5P3-C321.jpg" /></a>Ze sklepów wycofano niektóre partie sera pleśniowego z mleka koziego - poinformował Główny Inspektorat Sanitarny. Swoją decyzję argumentuje ostrzeżeniem producenta o możliwej obecno

## Papież Franciszek w Kazachstanie. Nawiązał do Jana Pawła II
 - [https://wydarzenia.interia.pl/zagranica/news-papiez-franciszek-w-kazachstanie-nawiazal-do-jana-pawla-ii,nId,6283363](https://wydarzenia.interia.pl/zagranica/news-papiez-franciszek-w-kazachstanie-nawiazal-do-jana-pawla-ii,nId,6283363)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 14:36:18+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-papiez-franciszek-w-kazachstanie-nawiazal-do-jana-pawla-ii,nId,6283363"><img align="left" alt="Papież Franciszek w Kazachstanie. Nawiązał do Jana Pawła II" src="https://i.iplsc.com/papiez-franciszek-w-kazachstanie-nawiazal-do-jana-pawla-ii/000G2BKH61N60E11-C321.jpg" /></a>Papież Franciszek rozpoczął we wtorek trzydniową wizytę w Kazachstanie. W swoim pierwszym przemówieniu nawiązał do słów Jana Pawła II wypowiedzianych w tym kraju 21 lat t

## Ważne zmiany w dodatku węglowym. Kiedy wypłaty pieniędzy? Czy wszyscy dostaną 3 tys. zł?
 - [https://wydarzenia.interia.pl/kraj/news-wazne-zmiany-w-dodatku-weglowym-kiedy-wyplaty-pieniedzy-czy-,nId,6283065](https://wydarzenia.interia.pl/kraj/news-wazne-zmiany-w-dodatku-weglowym-kiedy-wyplaty-pieniedzy-czy-,nId,6283065)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 14:04:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wazne-zmiany-w-dodatku-weglowym-kiedy-wyplaty-pieniedzy-czy-,nId,6283065"><img align="left" alt="Ważne zmiany w dodatku węglowym. Kiedy wypłaty pieniędzy? Czy wszyscy dostaną 3 tys. zł?" src="https://i.iplsc.com/wazne-zmiany-w-dodatku-weglowym-kiedy-wyplaty-pieniedzy-czy/000G29I998FH7I0F-C321.jpg" /></a>Kiedy będą wypłaty dodatku węglowego? To pytanie zadaje sobie 3,8 mln polskich rodzin. Rząd obiecał 3 tys. zł wsparcia dla każdego gospodarstwa

## "Oburzające treści. Komentarz pełen kłamstw". Żaryn o artykule "Times of Israel"
 - [https://wydarzenia.interia.pl/zagranica/news-oburzajace-tresci-komentarz-pelen-klamstw-zaryn-o-artykule-t,nId,6283325](https://wydarzenia.interia.pl/zagranica/news-oburzajace-tresci-komentarz-pelen-klamstw-zaryn-o-artykule-t,nId,6283325)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 13:45:57+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-oburzajace-tresci-komentarz-pelen-klamstw-zaryn-o-artykule-t,nId,6283325"><img align="left" alt="&quot;Oburzające treści. Komentarz pełen kłamstw&quot;. Żaryn o artykule &quot;Times of Israel&quot; " src="https://i.iplsc.com/oburzajace-tresci-komentarz-pelen-klamstw-zaryn-o-artykule-t/000G2B4MJLGI45B7-C321.jpg" /></a>Polscy przedstawiciele reagują na tekst w &quot;Times of Israel&quot; poświęcony polskim staraniom o reparacje. &quot;Oburza

## Małopolska kurator przegrała w sądzie. Będzie musiała przeprosić ZNP
 - [https://wydarzenia.interia.pl/kraj/news-malopolska-kurator-przegrala-w-sadzie-bedzie-musiala-przepro,nId,6283324](https://wydarzenia.interia.pl/kraj/news-malopolska-kurator-przegrala-w-sadzie-bedzie-musiala-przepro,nId,6283324)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 13:44:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-malopolska-kurator-przegrala-w-sadzie-bedzie-musiala-przepro,nId,6283324"><img align="left" alt="Małopolska kurator przegrała w sądzie. Będzie musiała przeprosić ZNP" src="https://i.iplsc.com/malopolska-kurator-przegrala-w-sadzie-bedzie-musiala-przepro/000G2AOJK67HTO00-C321.jpg" /></a>Zapadł wyrok w sprawie oskarżeń wysuwanych przez Barbarę Nowak wobec Związku Nauczycielstwa Polskiego. Teraz małopolska kurator oświaty musi publicznie przeprosić

## Ukraińcy weszli do Swiatohirska. Szef separatystów: To polscy najemnicy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-weszli-do-swiatohirska-szef-separatystow-to-polscy-,nId,6283291](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-weszli-do-swiatohirska-szef-separatystow-to-polscy-,nId,6283291)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 13:35:53+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-weszli-do-swiatohirska-szef-separatystow-to-polscy-,nId,6283291"><img align="left" alt="Ukraińcy weszli do Swiatohirska. Szef separatystów: To polscy najemnicy" src="https://i.iplsc.com/ukraincy-weszli-do-swiatohirska-szef-separatystow-to-polscy/000G2AJW6HUWXY2D-C321.jpg" /></a>Ukraińska ofensywa przekracza granicę obwodu charkowskiego. Tymczasem Denis Puszylin, przywódca separatystycznej Donieckiej 

## Prezydent Andrzej Duda wręczył sztandar Dowództwu Generalnemu Sił Zbrojnych
 - [https://wydarzenia.interia.pl/kraj/news-prezydent-andrzej-duda-wreczyl-sztandar-dowodztwu-generalnem,nId,6283218](https://wydarzenia.interia.pl/kraj/news-prezydent-andrzej-duda-wreczyl-sztandar-dowodztwu-generalnem,nId,6283218)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 13:23:25+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezydent-andrzej-duda-wreczyl-sztandar-dowodztwu-generalnem,nId,6283218"><img align="left" alt="Prezydent Andrzej Duda wręczył sztandar Dowództwu Generalnemu Sił Zbrojnych" src="https://i.iplsc.com/prezydent-andrzej-duda-wreczyl-sztandar-dowodztwu-generalnem/000G2A7LRSLMD23A-C321.jpg" /></a>Żołnierze Wojska Polskiego  wyróżniają się odwagą, męstwem i honorem. Te cechy symbolizuje sztandar - powiedział szef MON Mariusz Błaszczak na uroczystości

## KO złoży projekt uchwały ws. reparacji. "Należą się nam zarówno od Niemiec, jak i od Rosji"
 - [https://wydarzenia.interia.pl/kraj/news-ko-zlozy-projekt-uchwaly-ws-reparacji-naleza-sie-nam-zarowno,nId,6283248](https://wydarzenia.interia.pl/kraj/news-ko-zlozy-projekt-uchwaly-ws-reparacji-naleza-sie-nam-zarowno,nId,6283248)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 13:04:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ko-zlozy-projekt-uchwaly-ws-reparacji-naleza-sie-nam-zarowno,nId,6283248"><img align="left" alt="KO złoży projekt uchwały ws. reparacji. &quot;Należą się nam zarówno od Niemiec, jak i od Rosji&quot;" src="https://i.iplsc.com/ko-zlozy-projekt-uchwaly-ws-reparacji-naleza-sie-nam-zarowno/0009TLTHB3H6GSLN-C321.jpg" /></a>Klub Koalicji Obywatelskiej złoży swój projekt uchwały w sprawie reparacji - poinformował szef klubu Borys Budka. - Będziemy chci

## Wielka Brytania nie zaprosiła delegacji trzech państw na pogrzeb Elżbiety
 - [https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-nie-zaprosila-delegacji-trzech-panstw-na-pog,nId,6283251](https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-nie-zaprosila-delegacji-trzech-panstw-na-pog,nId,6283251)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 12:47:52+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wielka-brytania-nie-zaprosila-delegacji-trzech-panstw-na-pog,nId,6283251"><img align="left" alt="Wielka Brytania nie zaprosiła delegacji trzech państw na pogrzeb Elżbiety" src="https://i.iplsc.com/wielka-brytania-nie-zaprosila-delegacji-trzech-panstw-na-pog/000G2AE0FYNE210Y-C321.jpg" /></a>Wielka Brytania nie zaprosiła przedstawicieli trzech państw do udziału w państwowym pogrzebie królowej Elżbiety II, który ma się odbyć w najbliższy poni

## Mateusz Morawiecki: Antoni Macierewicz powinien dostać medal za konsekwencje
 - [https://wydarzenia.interia.pl/kraj/news-mateusz-morawiecki-antoni-macierewicz-powinien-dostac-medal-,nId,6283217](https://wydarzenia.interia.pl/kraj/news-mateusz-morawiecki-antoni-macierewicz-powinien-dostac-medal-,nId,6283217)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 12:45:04+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mateusz-morawiecki-antoni-macierewicz-powinien-dostac-medal-,nId,6283217"><img align="left" alt="Mateusz Morawiecki: Antoni Macierewicz powinien dostać medal za konsekwencje" src="https://i.iplsc.com/mateusz-morawiecki-antoni-macierewicz-powinien-dostac-medal/000G2AESQ6LJVVQ3-C321.jpg" /></a>- Ja kilku tysięcy stron tego raportu nie prześledziłem, tylko zapoznałem się z wnioskami końcowymi - mówił Mateusz Morawiecki o raporcie w sprawie katastr

## Premier Finlandii: Powinniśmy byli słuchać naszych przyjaciół z Polski
 - [https://wydarzenia.interia.pl/zagranica/news-premier-finlandii-powinnismy-byli-sluchac-naszych-przyjaciol,nId,6283184](https://wydarzenia.interia.pl/zagranica/news-premier-finlandii-powinnismy-byli-sluchac-naszych-przyjaciol,nId,6283184)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 12:15:29+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-premier-finlandii-powinnismy-byli-sluchac-naszych-przyjaciol,nId,6283184"><img align="left" alt="Premier Finlandii: Powinniśmy byli słuchać naszych przyjaciół z Polski " src="https://i.iplsc.com/premier-finlandii-powinnismy-byli-sluchac-naszych-przyjaciol/000G2A28JVTHW5YH-C321.jpg" /></a>Wojna pokazała, jak ważne dla Europy jest posiadanie własnej produkcji sprzętu obronnego i jak bardzo jesteśmy wrażliwi, jeśli chodzi o energię. Musimy pr

## Dymisja Norberta Kaczmarczyka faktem. Premier przyjął wniosek
 - [https://wydarzenia.interia.pl/kraj/news-dymisja-norberta-kaczmarczyka-faktem-premier-przyjal-wniosek,nId,6283121](https://wydarzenia.interia.pl/kraj/news-dymisja-norberta-kaczmarczyka-faktem-premier-przyjal-wniosek,nId,6283121)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 11:56:23+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dymisja-norberta-kaczmarczyka-faktem-premier-przyjal-wniosek,nId,6283121"><img align="left" alt="Dymisja Norberta Kaczmarczyka faktem. Premier przyjął wniosek" src="https://i.iplsc.com/dymisja-norberta-kaczmarczyka-faktem-premier-przyjal-wniosek/000G2A6Z8Q1UBYXU-C321.jpg" /></a>Norbert Kaczmarczyk nie jest już wiceministrem rolnictwa w rządzie Zjednoczonej Prawicy. Premier Mateusz Morawiecki przyjął wniosek o jego odwołanie. Nieco wcześniej, na

## Mateusz Morawiecki: Wpłynął wniosek od wicepremiera o dymisji Kaczmarczyka
 - [https://wydarzenia.interia.pl/kraj/news-mateusz-morawiecki-wplynal-wniosek-od-wicepremiera-o-dymisji,nId,6283121](https://wydarzenia.interia.pl/kraj/news-mateusz-morawiecki-wplynal-wniosek-od-wicepremiera-o-dymisji,nId,6283121)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 11:56:23+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mateusz-morawiecki-wplynal-wniosek-od-wicepremiera-o-dymisji,nId,6283121"><img align="left" alt="Mateusz Morawiecki: Wpłynął wniosek od wicepremiera o dymisji Kaczmarczyka" src="https://i.iplsc.com/mateusz-morawiecki-wplynal-wniosek-od-wicepremiera-o-dymisji/000FZ899M2IC99HN-C321.jpg" /></a>Wpłynął do mnie wniosek Henryka Kowalczyka związany z dymisją Norberta Kaczmarczyka - powiedział Mateusz Morawiecki podczas konferencji prasowej we wtorek. 

## Kierowca autobusu oskarżony o zabójstwo 19-latki. Miał celowo wjechać w ludzi
 - [https://wydarzenia.interia.pl/slaskie/news-kierowca-autobusu-oskarzony-o-zabojstwo-19-latki-mial-celowo,nId,6283140](https://wydarzenia.interia.pl/slaskie/news-kierowca-autobusu-oskarzony-o-zabojstwo-19-latki-mial-celowo,nId,6283140)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 11:41:25+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-kierowca-autobusu-oskarzony-o-zabojstwo-19-latki-mial-celowo,nId,6283140"><img align="left" alt="Kierowca autobusu oskarżony o zabójstwo 19-latki. Miał celowo wjechać w ludzi" src="https://i.iplsc.com/kierowca-autobusu-oskarzony-o-zabojstwo-19-latki-mial-celowo/000D64QTURA3NYXU-C321.jpg" /></a>32-letni kierowca autobusu został oskarżony o zabójstwo 19-latki i usiłowanie zabójstwa trzech innych osób. Za przestępstwa odpowie przed sądem. W lip

## Konflikt Armenia-Azerbejdżan. Putin "robi wszystko, co w jego mocy"
 - [https://wydarzenia.interia.pl/zagranica/news-konflikt-armenia-azerbejdzan-putin-robi-wszystko-co-w-jego-m,nId,6283165](https://wydarzenia.interia.pl/zagranica/news-konflikt-armenia-azerbejdzan-putin-robi-wszystko-co-w-jego-m,nId,6283165)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 11:20:17+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-konflikt-armenia-azerbejdzan-putin-robi-wszystko-co-w-jego-m,nId,6283165"><img align="left" alt="Konflikt Armenia-Azerbejdżan. Putin &quot;robi wszystko, co w jego mocy&quot;" src="https://i.iplsc.com/konflikt-armenia-azerbejdzan-putin-robi-wszystko-co-w-jego-m/000FD8W4548R6I57-C321.jpg" /></a>- Prezydent Władimir Putin robi wszystko, co w jego mocy, aby pomóc w deeskalacji działań wojennych między Armenią a Azerbejdżanem - poinformował we

## Wyburzyli zabytkowy fort bez zgody urzędu. Teraz chcą budować w Nowej Hucie
 - [https://wydarzenia.interia.pl/malopolskie/news-wyburzyli-zabytkowy-fort-bez-zgody-urzedu-teraz-chca-budowac,nId,6283113](https://wydarzenia.interia.pl/malopolskie/news-wyburzyli-zabytkowy-fort-bez-zgody-urzedu-teraz-chca-budowac,nId,6283113)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 11:04:50+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-wyburzyli-zabytkowy-fort-bez-zgody-urzedu-teraz-chca-budowac,nId,6283113"><img align="left" alt="Wyburzyli zabytkowy fort bez zgody urzędu. Teraz chcą budować w Nowej Hucie" src="https://i.iplsc.com/wyburzyli-zabytkowy-fort-bez-zgody-urzedu-teraz-chca-budowac/000G29JEYOG8SC9C-C321.jpg" /></a>Policyjne radiowozy, interwencja funkcjonariuszy, protest mieszkańców, deweloper rozpoczynający pracę w asyście mundurowych, a w tle spór o pozwolen

## Zofia, hrabina Wesseksu. To "druga córka" królowej Elżbiety II
 - [https://wydarzenia.interia.pl/zagranica/news-zofia-hrabina-wesseksu-to-druga-corka-krolowej-elzbiety-ii,nId,6283144](https://wydarzenia.interia.pl/zagranica/news-zofia-hrabina-wesseksu-to-druga-corka-krolowej-elzbiety-ii,nId,6283144)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 10:58:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zofia-hrabina-wesseksu-to-druga-corka-krolowej-elzbiety-ii,nId,6283144"><img align="left" alt="Zofia, hrabina Wesseksu. To &quot;druga córka&quot; królowej Elżbiety II" src="https://i.iplsc.com/zofia-hrabina-wesseksu-to-druga-corka-krolowej-elzbiety-ii/000G29LZWPRPAAL6-C321.jpg" /></a>Zofia, żona księcia Edwarda, najmłodszego syna Elżbiety II, była dla monarchini jak rodzona córka. Fotoreporterzy uchwycili moment, gdy hrabina, pogrążona w 

## Brunatne kostki zrzucane z samolotów. Nie wolno ich podnosić
 - [https://wydarzenia.interia.pl/lubelskie/news-brunatne-kostki-zrzucane-z-samolotow-nie-wolno-ich-podnosic,nId,6283096](https://wydarzenia.interia.pl/lubelskie/news-brunatne-kostki-zrzucane-z-samolotow-nie-wolno-ich-podnosic,nId,6283096)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 10:47:08+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-brunatne-kostki-zrzucane-z-samolotow-nie-wolno-ich-podnosic,nId,6283096"><img align="left" alt="Brunatne kostki zrzucane z samolotów. Nie wolno ich podnosić" src="https://i.iplsc.com/brunatne-kostki-zrzucane-z-samolotow-nie-wolno-ich-podnosic/0003IZIFO5NXPRO6-C321.jpg" /></a>W województwie lubelskim rozpoczęła się druga w tym roku akcja szczepienia lisów przeciwko wściekliźnie. Ma potrwać trzy dni - do 15 września. Organizatorzy ostrzegają

## Sosnowiec: Policja szuka sprawcy napaści seksualnej na nastolatkę
 - [https://wydarzenia.interia.pl/slaskie/news-sosnowiec-policja-szuka-sprawcy-napasci-seksualnej-na-nastol,nId,6283132](https://wydarzenia.interia.pl/slaskie/news-sosnowiec-policja-szuka-sprawcy-napasci-seksualnej-na-nastol,nId,6283132)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 10:45:41+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-sosnowiec-policja-szuka-sprawcy-napasci-seksualnej-na-nastol,nId,6283132"><img align="left" alt="Sosnowiec: Policja szuka sprawcy napaści seksualnej na nastolatkę" src="https://i.iplsc.com/sosnowiec-policja-szuka-sprawcy-napasci-seksualnej-na-nastol/000G29OEW098GJD9-C321.jpg" /></a>Policja poszukuje mężczyzny, który w czerwcu w autobusie komunikacji miejskiej w Sosnowcu napastował seksualnie 14-letnią dziewczynkę. We wtorek policjanci opubli

## Reparacje od Niemiec. Projekt uchwały w Sejmie
 - [https://wydarzenia.interia.pl/kraj/news-reparacje-od-niemiec-projekt-uchwaly-w-sejmie,nId,6283130](https://wydarzenia.interia.pl/kraj/news-reparacje-od-niemiec-projekt-uchwaly-w-sejmie,nId,6283130)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 10:44:54+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-reparacje-od-niemiec-projekt-uchwaly-w-sejmie,nId,6283130"><img align="left" alt="Reparacje od Niemiec. Projekt uchwały w Sejmie" src="https://i.iplsc.com/reparacje-od-niemiec-projekt-uchwaly-w-sejmie/000G07SUGNXQU530-C321.jpg" /></a>&quot;Sejm RP oświadcza, że należycie reprezentowane państwo polskie nigdy nie zrzekło się roszczeń wobec państwa niemieckiego&quot; - głosi projekt uchwały ws. reparacji, który złożyła w Sejmie grupa posłow PiS. P

## Ukraina: Irański dron bojowy zestrzelony w pobliżu Kupiańska
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-iranski-dron-bojowy-zestrzelony-w-poblizu-kupianska,nId,6283087](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-iranski-dron-bojowy-zestrzelony-w-poblizu-kupianska,nId,6283087)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 10:20:02+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-iranski-dron-bojowy-zestrzelony-w-poblizu-kupianska,nId,6283087"><img align="left" alt="Ukraina: Irański dron bojowy zestrzelony w pobliżu Kupiańska" src="https://i.iplsc.com/ukraina-iranski-dron-bojowy-zestrzelony-w-poblizu-kupianska/000G29KR2DRP962T-C321.jpg" /></a>Wykorzystywany przez Rosję dron bojowy, wyprodukowany w Iranie, został zestrzelony w obwodzie charkowskim - powiadomiła agencja Ukrinfor

## Azerbejdżan kontra Armenia, czyli widmo kolejnej wojny. Konflikt na Kaukazie zbiera krwawe żniwo
 - [https://wydarzenia.interia.pl/zagranica/news-azerbejdzan-kontra-armenia-czyli-widmo-kolejnej-wojny-konfli,nId,6283057](https://wydarzenia.interia.pl/zagranica/news-azerbejdzan-kontra-armenia-czyli-widmo-kolejnej-wojny-konfli,nId,6283057)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 10:11:34+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-azerbejdzan-kontra-armenia-czyli-widmo-kolejnej-wojny-konfli,nId,6283057"><img align="left" alt="Azerbejdżan kontra Armenia, czyli widmo kolejnej wojny. Konflikt na Kaukazie zbiera krwawe żniwo" src="https://i.iplsc.com/azerbejdzan-kontra-armenia-czyli-widmo-kolejnej-wojny-konfli/000G29AP2QLS6FQC-C321.jpg" /></a>Podczas wtorkowych walk z Azerbejdżanem zginęło dotychczas 49 armeńskich żołnierzy. Obie strony, pozostające od lat w konflikcie,

## Rosja każe zaprzestać działań wojennych Armenii i Azerbejdżanowi
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-kaze-zaprzestac-dzialan-wojennych-armenii-i-azerbejdza,nId,6283016](https://wydarzenia.interia.pl/zagranica/news-rosja-kaze-zaprzestac-dzialan-wojennych-armenii-i-azerbejdza,nId,6283016)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 10:10:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-kaze-zaprzestac-dzialan-wojennych-armenii-i-azerbejdza,nId,6283016"><img align="left" alt="Rosja każe zaprzestać działań wojennych Armenii i Azerbejdżanowi" src="https://i.iplsc.com/rosja-kaze-zaprzestac-dzialan-wojennych-armenii-i-azerbejdza/000FZ153Y9FEN4MS-C321.jpg" /></a>Rosja wezwała Armenię i Azerbejdżan do zaprzestania działań wojennych i przestrzegania porozumienia o zawieszeniu broni. &quot;Wyrażamy skrajne zaniepokojenie wz

## Mieli bronić Moskwę przed NATO, uciekli z okolic Charkowa
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-mieli-bronic-moskwe-przed-nato-uciekli-z-okolic-charkowa,nId,6283040](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-mieli-bronic-moskwe-przed-nato-uciekli-z-okolic-charkowa,nId,6283040)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 09:51:09+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-mieli-bronic-moskwe-przed-nato-uciekli-z-okolic-charkowa,nId,6283040"><img align="left" alt="Mieli bronić Moskwę przed NATO, uciekli z okolic Charkowa" src="https://i.iplsc.com/mieli-bronic-moskwe-przed-nato-uciekli-z-okolic-charkowa/000FVS0BDCN9D4G0-C321.jpg" /></a>1. Gwardyjska Armia Pancerna (1.GTA) wycofała się z obwodu charkowskiego - powiadomiło brytyjskie Ministerstwo Obrony. Armia ta w przypadku wojny

## Spotkanie Putin-Xi. Ministerstwo nabiera wody w usta
 - [https://wydarzenia.interia.pl/zagranica/news-spotkanie-putin-xi-ministerstwo-nabiera-wody-w-usta,nId,6283004](https://wydarzenia.interia.pl/zagranica/news-spotkanie-putin-xi-ministerstwo-nabiera-wody-w-usta,nId,6283004)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 09:48:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-spotkanie-putin-xi-ministerstwo-nabiera-wody-w-usta,nId,6283004"><img align="left" alt="Spotkanie Putin-Xi. Ministerstwo nabiera wody w usta" src="https://i.iplsc.com/spotkanie-putin-xi-ministerstwo-nabiera-wody-w-usta/000G292HJHUTJAT8-C321.jpg" /></a>Ministerstwo Spraw Zagranicznych Chin odmówiło udzielenia odpowiedzi na pytanie, czy prezydent Xi Jinping spotka się z Władimirem Putinem bądź premierem Indii Narendrem Modi podczas szczytu S

## Pierwszy śnieg w Tatrach. Są zdjęcia
 - [https://wydarzenia.interia.pl/kraj/news-pierwszy-snieg-w-tatrach-sa-zdjecia,nId,6282974](https://wydarzenia.interia.pl/kraj/news-pierwszy-snieg-w-tatrach-sa-zdjecia,nId,6282974)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 09:32:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pierwszy-snieg-w-tatrach-sa-zdjecia,nId,6282974"><img align="left" alt="Pierwszy śnieg w Tatrach. Są zdjęcia" src="https://i.iplsc.com/pierwszy-snieg-w-tatrach-sa-zdjecia/000G29AGPFYOHEIE-C321.jpg" /></a>W Tatrach spadł pierwszy śnieg. Mimo że kalendarzowe lato jeszcze się nie skończyło, to na wysokości powyżej 2500 m n.p.m. zaobserwowano opad. Użytkownicy dzielą się w sieci &quot;zimowymi&quot; widokami z gór. W związku z sytuacją pogodową Tat

## Ponad 7,8 tys. zakażeń SARS-CoV-2. Niedzielski: To nie jest nowa fala
 - [https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-ponad-7-8-tys-zakazen-sars-cov-2-niedzielski-to-nie-jest-now,nId,6283043](https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-ponad-7-8-tys-zakazen-sars-cov-2-niedzielski-to-nie-jest-now,nId,6283043)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 09:30:10+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-ponad-7-8-tys-zakazen-sars-cov-2-niedzielski-to-nie-jest-now,nId,6283043"><img align="left" alt="Ponad 7,8 tys. zakażeń SARS-CoV-2. Niedzielski: To nie jest nowa fala" src="https://i.iplsc.com/ponad-7-8-tys-zakazen-sars-cov-2-niedzielski-to-nie-jest-now/000D5YHTQYM757HU-C321.jpg" /></a>Mamy 7876 zakażeń SARS-CoV-2 - wynika z najnowszego dobowego raportu Ministerstwa Zdrowia. To o dwa tysiące więcej niż tydzień

## Znany drag queen i weteran armii ukarany. Śpiewał hymn z tęczową flagą
 - [https://wydarzenia.interia.pl/zagranica/news-znany-drag-queen-i-weteran-armii-ukarany-spiewal-hymn-z-tecz,nId,6282923](https://wydarzenia.interia.pl/zagranica/news-znany-drag-queen-i-weteran-armii-ukarany-spiewal-hymn-z-tecz,nId,6282923)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 09:03:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-znany-drag-queen-i-weteran-armii-ukarany-spiewal-hymn-z-tecz,nId,6282923"><img align="left" alt="Znany drag queen i weteran armii ukarany. Śpiewał hymn z tęczową flagą" src="https://i.iplsc.com/znany-drag-queen-i-weteran-armii-ukarany-spiewal-hymn-z-tecz/000G28WS26P3A5YD-C321.jpg" /></a>Popularny w Rosji drag queen Bomba Kibersisi zaśpiewał hymn państwowy, trzymając w ręku tęczową flagę - symbol LGBT. Do zdarzenia doszło w jednym z klubów 

## Sinciang: Władze cenzurują skargi na lockdown. Mają być tylko "uśmiechnięci seniorzy"
 - [https://wydarzenia.interia.pl/zagranica/news-sinciang-wladze-cenzuruja-skargi-na-lockdown-maja-byc-tylko-,nId,6283017](https://wydarzenia.interia.pl/zagranica/news-sinciang-wladze-cenzuruja-skargi-na-lockdown-maja-byc-tylko-,nId,6283017)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 08:56:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sinciang-wladze-cenzuruja-skargi-na-lockdown-maja-byc-tylko-,nId,6283017"><img align="left" alt="Sinciang: Władze cenzurują skargi na lockdown. Mają być tylko &quot;uśmiechnięci seniorzy&quot;" src="https://i.iplsc.com/sinciang-wladze-cenzuruja-skargi-na-lockdown-maja-byc-tylko/000G292WC16OYUEC-C321.jpg" /></a>Władze Chin próbują kreować inną, pozytywną rzeczywistość w objętej lockdownem prowincji Sinciang. Jak podają chińskie media, skarg

## Zmiana frontu Marianny Schreiber. "Otworzyłam oczy"
 - [https://wydarzenia.interia.pl/kraj/news-zmiana-frontu-marianny-schreiber-otworzylam-oczy,nId,6282987](https://wydarzenia.interia.pl/kraj/news-zmiana-frontu-marianny-schreiber-otworzylam-oczy,nId,6282987)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 08:46:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zmiana-frontu-marianny-schreiber-otworzylam-oczy,nId,6282987"><img align="left" alt="Zmiana frontu Marianny Schreiber. &quot;Otworzyłam oczy&quot;" src="https://i.iplsc.com/zmiana-frontu-marianny-schreiber-otworzylam-oczy/000G290ZUSFSNXPT-C321.jpg" /></a>Marianna Schreiber, żona ministra w rządzie PiS Łukasza Schreibera, zasłynęła z głoszenia opinii będących w kontrze do poglądów jej męża. Mówiła, że popiera małżeństwa jednopłciowe i opowiada s

## Czarnek o problemach z ogrzewaniem: Nie ma ryzyka zamykania szkół
 - [https://wydarzenia.interia.pl/kraj/news-czarnek-o-problemach-z-ogrzewaniem-nie-ma-ryzyka-zamykania-s,nId,6283000](https://wydarzenia.interia.pl/kraj/news-czarnek-o-problemach-z-ogrzewaniem-nie-ma-ryzyka-zamykania-s,nId,6283000)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 08:45:23+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-czarnek-o-problemach-z-ogrzewaniem-nie-ma-ryzyka-zamykania-s,nId,6283000"><img align="left" alt="Czarnek o problemach z ogrzewaniem: Nie ma ryzyka zamykania szkół" src="https://i.iplsc.com/czarnek-o-problemach-z-ogrzewaniem-nie-ma-ryzyka-zamykania-s/000FPT2FPN83TVY9-C321.jpg" /></a>Jak podkreśla minister edukacji i nauki, &quot;nie ma takiego ryzyka, że szkoły będą zamykane ze względu na problemy z ogrzewaniem&quot;. - Przekazaliśmy samorządom 

## Alarm bombowy na niemieckim lotnisku. To przez pamiątkę z Polski
 - [https://wydarzenia.interia.pl/zagranica/news-alarm-bombowy-na-niemieckim-lotnisku-to-przez-pamiatke-z-pol,nId,6282961](https://wydarzenia.interia.pl/zagranica/news-alarm-bombowy-na-niemieckim-lotnisku-to-przez-pamiatke-z-pol,nId,6282961)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 08:14:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-alarm-bombowy-na-niemieckim-lotnisku-to-przez-pamiatke-z-pol,nId,6282961"><img align="left" alt="Alarm bombowy na niemieckim lotnisku. To przez pamiątkę z Polski" src="https://i.iplsc.com/alarm-bombowy-na-niemieckim-lotnisku-to-przez-pamiatke-z-pol/000G28WNTA03ETW4-C321.jpg" /></a>Nietypowa pamiątka z Polski spowodowała alarm bombowy na niemieckim lotnisku Heringsdorf na wyspie Uznam.</p><br clear="all" />

## Franciszek w drodze do Kazachstanu.
 - [https://wydarzenia.interia.pl/zagranica/news-franciszek-w-drodze-do-kazachstanu,nId,6282945](https://wydarzenia.interia.pl/zagranica/news-franciszek-w-drodze-do-kazachstanu,nId,6282945)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 07:56:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-franciszek-w-drodze-do-kazachstanu,nId,6282945"><img align="left" alt="Franciszek w drodze do Kazachstanu. " src="https://i.iplsc.com/franciszek-w-drodze-do-kazachstanu/000FVSQ34RH58TEI-C321.jpg" /></a>Papież Franciszek wyruszył we wtorek rano w trzydniową podróż do Kazachstanu. To jego 38. zagraniczna pielgrzymka. W jej trakcie weźmie udział w VII Kongresie Przywódców Religii Światowych i Tradycyjnych w stolicy kraju, Nur-Sułtan. &quot;To

## Franciszek w drodze do Kazachstanu. Spekulacje o ważnym spotkaniu
 - [https://wydarzenia.interia.pl/zagranica/news-franciszek-w-drodze-do-kazachstanu-spekulacje-o-waznym-spotk,nId,6282945](https://wydarzenia.interia.pl/zagranica/news-franciszek-w-drodze-do-kazachstanu-spekulacje-o-waznym-spotk,nId,6282945)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 07:56:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-franciszek-w-drodze-do-kazachstanu-spekulacje-o-waznym-spotk,nId,6282945"><img align="left" alt="Franciszek w drodze do Kazachstanu. Spekulacje o ważnym spotkaniu" src="https://i.iplsc.com/franciszek-w-drodze-do-kazachstanu-spekulacje-o-waznym-spotk/000FVSQ34RH58TEI-C321.jpg" /></a>Papież Franciszek wyruszył we wtorek rano w trzydniową podróż do Kazachstanu. To jego 38. zagraniczna pielgrzymka. W jej trakcie weźmie udział w VII Kongresie P

## Ukraina: Rosjanie w mniej niż tydzień stracili sprzęt wojskowy za 673 mln dolarów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-rosjanie-w-mniej-niz-tydzien-stracili-sprzet-wojskow,nId,6282936](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-rosjanie-w-mniej-niz-tydzien-stracili-sprzet-wojskow,nId,6282936)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 07:55:21+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-rosjanie-w-mniej-niz-tydzien-stracili-sprzet-wojskow,nId,6282936"><img align="left" alt="Ukraina: Rosjanie w mniej niż tydzień stracili sprzęt wojskowy za 673 mln dolarów" src="https://i.iplsc.com/ukraina-rosjanie-w-mniej-niz-tydzien-stracili-sprzet-wojskow/000FM2KHLNKWUK8H-C321.jpg" /></a>Zbrojne Siły Ukrainy w ciągu sześciu dni zniszczyły 590 sztuk rosyjskiego sprzętu wojskowego o łącznej wartości 6

## Etapy akceptacji porażki. Analiza programów rosyjskiej telewizji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-etapy-akceptacji-porazki-analiza-programow-rosyjskiej-telewi,nId,6282898](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-etapy-akceptacji-porazki-analiza-programow-rosyjskiej-telewi,nId,6282898)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 07:08:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-etapy-akceptacji-porazki-analiza-programow-rosyjskiej-telewi,nId,6282898"><img align="left" alt="Etapy akceptacji porażki. Analiza programów rosyjskiej telewizji" src="https://i.iplsc.com/etapy-akceptacji-porazki-analiza-programow-rosyjskiej-telewi/000G285N3DM07Y9D-C321.jpg" /></a>Rosyjska telewizja publiczna to tuba propagandowa Kremla. Wraz z sukcesami ukraińskiej ofensywy, w prokremlowskich mediach zmienił

## Rosyjskie dowództwo chce "wzmocnić" wojsko. Żołnierze nie dostają pieniędzy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-dowodztwo-chce-wzmocnic-wojsko-zolnierze-nie-dosta,nId,6282891](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-dowodztwo-chce-wzmocnic-wojsko-zolnierze-nie-dosta,nId,6282891)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 06:44:03+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-dowodztwo-chce-wzmocnic-wojsko-zolnierze-nie-dosta,nId,6282891"><img align="left" alt="Rosyjskie dowództwo chce &quot;wzmocnić&quot; wojsko. Żołnierze nie dostają pieniędzy" src="https://i.iplsc.com/rosyjskie-dowodztwo-chce-wzmocnic-wojsko-zolnierze-nie-dosta/000G1R992JHVX5SO-C321.jpg" /></a>Dowództwo rosyjskiej samodzielnej Brygady Strzelców Zmotoryzowanych przestało płacić żołnierzom, zwłaszcza ty

## Sukces Ukraińców na południu. ISW: Rosjanie wycofali się z Kyseliwki
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-sukces-ukraincow-na-poludniu-isw-rosjanie-wycofali-sie-z-kys,nId,6282871](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-sukces-ukraincow-na-poludniu-isw-rosjanie-wycofali-sie-z-kys,nId,6282871)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 06:40:49+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-sukces-ukraincow-na-poludniu-isw-rosjanie-wycofali-sie-z-kys,nId,6282871"><img align="left" alt="Sukces Ukraińców na południu. ISW: Rosjanie wycofali się z Kyseliwki" src="https://i.iplsc.com/sukces-ukraincow-na-poludniu-isw-rosjanie-wycofali-sie-z-kys/000G27Z88Y74YKY3-C321.jpg" /></a>Nie tylko udana kontrofensywa w obwodzie charkowskim. Wojsko ukraińskie odnosi sukcesy również na południu kraju. Jak ocenia I

## Ukraińcy prą do przodu. Zełenski o kolejnych sukcesach
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-pra-do-przodu-zelenski-o-kolejnych-sukcesach,nId,6282893](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-pra-do-przodu-zelenski-o-kolejnych-sukcesach,nId,6282893)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 06:27:31+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-pra-do-przodu-zelenski-o-kolejnych-sukcesach,nId,6282893"><img align="left" alt="Ukraińcy prą do przodu. Zełenski o kolejnych sukcesach" src="https://i.iplsc.com/ukraincy-pra-do-przodu-zelenski-o-kolejnych-sukcesach/000FXOQFXVJ4YHI5-C321.jpg" /></a>Sześć tysięcy kilometrów kwadratowych terytorium okupowanego przez Rosjan - jak przekazuje Wołodymyr Zełenski, tyle od początku miesiąca odzyskała armia u

## Olbrzymie utrudnienia w centrum Warszawy. Remont sparaliżował stolicę
 - [https://wydarzenia.interia.pl/mazowieckie/news-olbrzymie-utrudnienia-w-centrum-warszawy-remont-sparalizowal,nId,6282851](https://wydarzenia.interia.pl/mazowieckie/news-olbrzymie-utrudnienia-w-centrum-warszawy-remont-sparalizowal,nId,6282851)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 05:48:02+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-olbrzymie-utrudnienia-w-centrum-warszawy-remont-sparalizowal,nId,6282851"><img align="left" alt="Olbrzymie utrudnienia w centrum Warszawy. Remont sparaliżował stolicę " src="https://i.iplsc.com/olbrzymie-utrudnienia-w-centrum-warszawy-remont-sparalizowal/000G27Z3ANF5GV3S-C321.jpg" /></a>Remont placu Trzech Krzyży spowodował olbrzymie utrudnienia w centrum stolicy. Drogowcy zagrodzili jego wschodnią część i cały ruch odbywa się częścią za

## Norbert Kaczmarczyk odchodzi. Zapadła decyzja o dymisji
 - [https://wydarzenia.interia.pl/kraj/news-norbert-kaczmarczyk-odchodzi-zapadla-decyzja-o-dymisji,nId,6282861](https://wydarzenia.interia.pl/kraj/news-norbert-kaczmarczyk-odchodzi-zapadla-decyzja-o-dymisji,nId,6282861)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 05:39:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-norbert-kaczmarczyk-odchodzi-zapadla-decyzja-o-dymisji,nId,6282861"><img align="left" alt="Norbert Kaczmarczyk odchodzi. Zapadła decyzja o dymisji" src="https://i.iplsc.com/norbert-kaczmarczyk-odchodzi-zapadla-decyzja-o-dymisji/000FZ899M2IC99HN-C321.jpg" /></a>Wczoraj prezydium komitetu politycznego Prawa i Sprawiedliwości zdecydowało, że ta dymisja musi nastąpić i ona nastąpi - mówił w Polskim radiu Ryszard Terlecki. Szef klubu PiS odniósł się

## Norbert Kaczmarczyk odchodzi? Terlecki: Decyzja musi nastąpić
 - [https://wydarzenia.interia.pl/kraj/news-norbert-kaczmarczyk-odchodzi-terlecki-decyzja-musi-nastapic,nId,6282861](https://wydarzenia.interia.pl/kraj/news-norbert-kaczmarczyk-odchodzi-terlecki-decyzja-musi-nastapic,nId,6282861)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 05:39:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-norbert-kaczmarczyk-odchodzi-terlecki-decyzja-musi-nastapic,nId,6282861"><img align="left" alt="Norbert Kaczmarczyk odchodzi? Terlecki: Decyzja musi nastąpić" src="https://i.iplsc.com/norbert-kaczmarczyk-odchodzi-terlecki-decyzja-musi-nastapic/000G280AYS0ODT3Y-C321.jpg" /></a>Wczoraj prezydium komitetu politycznego Prawa i Sprawiedliwości zdecydowało, że ta dymisja musi nastąpić i ona nastąpi - mówił w Polskim Radiu Ryszard Terlecki. Szef klubu

## Terlecki o dymisji Norberta Kaczmarczyka: Decyzja zapadła
 - [https://wydarzenia.interia.pl/kraj/news-terlecki-o-dymisji-norberta-kaczmarczyka-decyzja-zapadla,nId,6282861](https://wydarzenia.interia.pl/kraj/news-terlecki-o-dymisji-norberta-kaczmarczyka-decyzja-zapadla,nId,6282861)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 05:39:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-terlecki-o-dymisji-norberta-kaczmarczyka-decyzja-zapadla,nId,6282861"><img align="left" alt="Terlecki o dymisji Norberta Kaczmarczyka: Decyzja zapadła" src="https://i.iplsc.com/terlecki-o-dymisji-norberta-kaczmarczyka-decyzja-zapadla/000G280AYS0ODT3Y-C321.jpg" /></a>Wczoraj prezydium komitetu politycznego Prawa i Sprawiedliwości zdecydowało, że ta dymisja musi nastąpić i ona nastąpi - mówił w Polskim Radiu Ryszard Terlecki. Szef klubu PiS odnió

## Zmiana ordynacji wyborczej. Przeciw także zwolennicy PiS
 - [https://wydarzenia.interia.pl/kraj/news-zmiana-ordynacji-wyborczej-przeciw-takze-zwolennicy-pis,nId,6282847](https://wydarzenia.interia.pl/kraj/news-zmiana-ordynacji-wyborczej-przeciw-takze-zwolennicy-pis,nId,6282847)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 05:20:10+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zmiana-ordynacji-wyborczej-przeciw-takze-zwolennicy-pis,nId,6282847"><img align="left" alt="Zmiana ordynacji wyborczej. Przeciw także zwolennicy PiS" src="https://i.iplsc.com/zmiana-ordynacji-wyborczej-przeciw-takze-zwolennicy-pis/000G0WS9N3FWCYUC-C321.jpg" /></a>Z sondażu IBRiS dla wynika, że obywatele nie chcą zmian w ordynacji, szczególnie w roku przedwyborczym. Takiego zdania jest prawie 65 proc. wyborców. </p><br clear="all" />

## Badają gen Tob. Odgrywa ważną rolę w zwalczaniu depresji
 - [https://wydarzenia.interia.pl/zagranica/news-badaja-gen-tob-odgrywa-wazna-role-w-zwalczaniu-depresji,nId,6282833](https://wydarzenia.interia.pl/zagranica/news-badaja-gen-tob-odgrywa-wazna-role-w-zwalczaniu-depresji,nId,6282833)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 05:12:58+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-badaja-gen-tob-odgrywa-wazna-role-w-zwalczaniu-depresji,nId,6282833"><img align="left" alt="Badają gen Tob. Odgrywa ważną rolę w zwalczaniu depresji" src="https://i.iplsc.com/badaja-gen-tob-odgrywa-wazna-role-w-zwalczaniu-depresji/000E8BNEJ1KQ1XL6-C321.jpg" /></a>Naukowcy z Okinawa Institute of Science and Technology (OIST) przeprowadzili multidyscyplinarne badania, dzięki którym udało się odkryć rolę genu Tob w przypadku depresji, strachu

## Pilny telefon premiera Armenii do Putina. "Nie do zaakceptowania"
 - [https://wydarzenia.interia.pl/zagranica/news-pilny-telefon-premiera-armenii-do-putina-nie-do-zaakceptowan,nId,6282838](https://wydarzenia.interia.pl/zagranica/news-pilny-telefon-premiera-armenii-do-putina-nie-do-zaakceptowan,nId,6282838)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 05:12:25+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pilny-telefon-premiera-armenii-do-putina-nie-do-zaakceptowan,nId,6282838"><img align="left" alt="Pilny telefon premiera Armenii do Putina. &quot;Nie do zaakceptowania&quot;" src="https://i.iplsc.com/pilny-telefon-premiera-armenii-do-putina-nie-do-zaakceptowan/000FXVFOMM8C15KG-C321.jpg" /></a>Konflikt między Armenią a Azerbejdżanem zaostrzył się w nocy z poniedziałku na wtorek. Premier Armenii Nikol Paszynian odbył rozmowę telefoniczną z Wł

## Śledztwo w sprawie Smoleńska. Podkomisja odpowiada na zarzuty dziennikarzy
 - [https://wydarzenia.interia.pl/kraj/news-sledztwo-w-sprawie-smolenska-podkomisja-odpowiada-na-zarzuty,nId,6282831](https://wydarzenia.interia.pl/kraj/news-sledztwo-w-sprawie-smolenska-podkomisja-odpowiada-na-zarzuty,nId,6282831)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 04:49:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sledztwo-w-sprawie-smolenska-podkomisja-odpowiada-na-zarzuty,nId,6282831"><img align="left" alt="Śledztwo w sprawie Smoleńska. Podkomisja odpowiada na zarzuty dziennikarzy" src="https://i.iplsc.com/sledztwo-w-sprawie-smolenska-podkomisja-odpowiada-na-zarzuty/000G27U8HCCL2F1U-C321.jpg" /></a>&quot;Zarzuty i pseudoargumenty przedstawione przez stację TVN są fałszywe i prezentują rosyjski punt widzenia, wprowadzając w błąd polską opinię publiczną&

## Konflikt Armenia-Azerbejdżan. Komunikat USA
 - [https://wydarzenia.interia.pl/zagranica/news-konflikt-armenia-azerbejdzan-komunikat-usa,nId,6282828](https://wydarzenia.interia.pl/zagranica/news-konflikt-armenia-azerbejdzan-komunikat-usa,nId,6282828)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 04:29:58+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-konflikt-armenia-azerbejdzan-komunikat-usa,nId,6282828"><img align="left" alt="Konflikt Armenia-Azerbejdżan. Komunikat USA" src="https://i.iplsc.com/konflikt-armenia-azerbejdzan-komunikat-usa/000G27TJ69R6HX9F-C321.jpg" /></a>Sekretarz stanu USA wzywa do deeskalacji działań wojennych wzdłuż granicy Armenii z Azerbejdżanem. &quot;Nie może być mowy o militarnym rozwiązaniu konfliktu&quot; - podkreśla Antony Blinken. Obie strony konfliktu obwi

## Wojna w Ukrainie. 202. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo,nzId,3001,akt,130556](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo,nzId,3001,akt,130556)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 03:52:11+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo,nzId,3001,akt,130556"><img align="left" alt="Wojna w Ukrainie. 202. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo/000G27SNYHMOHGVY-C321.jpg" /></a>Najważniejsze i najnowsze informacje dotyczące wojny w Ukrainie w jednym miejscu. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 202. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo,nzId,3001,akt,130650](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo,nzId,3001,akt,130650)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 03:52:11+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo,nzId,3001,akt,130650"><img align="left" alt="Wojna w Ukrainie. 202. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo/000G27SNYHMOHGVY-C321.jpg" /></a>Najważniejsze i najnowsze informacje dotyczące wojny w Ukrainie w jednym miejscu. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 202. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo,nzId,3001,akt,130758](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo,nzId,3001,akt,130758)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-09-13 03:52:11+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo,nzId,3001,akt,130758"><img align="left" alt="Wojna w Ukrainie. 202. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-202-dzien-inwazji-rosji-relacja-na-zywo/000G27SNYHMOHGVY-C321.jpg" /></a>Najważniejsze i najnowsze informacje dotyczące wojny w Ukrainie w jednym miejscu. Śledź naszą relację na żywo.</p><br clear="all" />


# Source:The Verge, URL:https://www.theverge.com/rss/index.xml, language:en-US

## Here are the first not-an-NFT “digital collectibles” for PlayStation Stars
 - [https://www.theverge.com/2022/9/13/23352063/sony-playstation-stars-digital-collectibles-previews](https://www.theverge.com/2022/9/13/23352063/sony-playstation-stars-digital-collectibles-previews)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 23:34:47+00:00

<figure>
      <img alt="Image of a digital statue of two cats, holding a birthday cake together." src="https://cdn.vox-cdn.com/thumbor/CBCX6UpF2cIPap5J6B-gH2bEOKA=/113x0:2192x1386/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71364318/Screenshot_2022_09_13_at_16.01.02.0.png" />
        <figcaption>Image: Sony</figcaption>
    </figure>

  <p id="l985QK">During its State of Play even on Tuesday, Sony gave us a look at some of the first “digital collectibles” that’ll be available as rewards

## The biggest announcements from Sony’s September State of Play
 - [https://www.theverge.com/2022/9/13/23351958/sony-playstation-state-of-play-biggest-announcements-news-god-of-war-ragnarok-tekken-8](https://www.theverge.com/2022/9/13/23351958/sony-playstation-state-of-play-biggest-announcements-news-god-of-war-ragnarok-tekken-8)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 23:22:28+00:00

<figure>
      <img alt="A screenshot from God of War Ragnarok. Atreus is has an arrow notched in his bow that’s pointed at a monster being held down by Kratos." src="https://cdn.vox-cdn.com/thumbor/Tpn0oaPGrqjZRr2lQC5uda25pjE=/300x0:1920x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71364278/2d542341c22b385787a639322d68347d.0.jpeg" />
        <figcaption><em>I don’t think this monster is going to live.</em> | Image: Sony</figcaption>
    </figure>

  <p id="wUSxLX">Sony just wrapped 

## God of War Ragnarok’s story trailer teases a hellish trip ahead for Kratos and Atreus
 - [https://www.theverge.com/2022/9/13/23352058/god-of-war-ragnarok-story-trailer-sony-state-of-play](https://www.theverge.com/2022/9/13/23352058/god-of-war-ragnarok-story-trailer-sony-state-of-play)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 23:21:45+00:00

<figure>
      <img alt="Screenshot from God of War Ragnarok featuring a large man covered in white ash and a red tattoo and his son, a young boy clad in furs and carrying a boy pondering cave drawings" src="https://cdn.vox-cdn.com/thumbor/LAC65OyYzvTP5_aahH4Es0VN7ao=/150x0:1770x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71364274/ezgif.com_gif_maker__1_.0.png" />
        <figcaption>Sony</figcaption>
    </figure>

  <p id="ZNhf3s">Today’s just been a day of pleasant, <a href="http

## Judge throws out Facebook collusion claims in Google antitrust suit
 - [https://www.theverge.com/2022/9/13/23352005/google-ad-tech-antitrust-suit-moves-forward-jedi-blue-facebook-collusion-claims-dismissed](https://www.theverge.com/2022/9/13/23352005/google-ad-tech-antitrust-suit-moves-forward-jedi-blue-facebook-collusion-claims-dismissed)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 23:02:48+00:00

<figure>
      <img alt="An image of Google’s logo" src="https://cdn.vox-cdn.com/thumbor/jWQTXkbS0HwcsuEyj1DbqqO5P8U=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71364213/STK093_Google_01.0.jpg" />
        <figcaption>A Google G logo. | The Verge</figcaption>
    </figure>

  <p id="uz71cz">A federal judge has allowed crucial elements of an antitrust case against Google to proceed, including allegations that Google illegally monopolized the ad-tech market. However, <a href=

## NASA has a new launch date for its Artemis I megarocket
 - [https://www.theverge.com/2022/9/13/23351703/nasa-artemis-i-megarocket-new-launch-date](https://www.theverge.com/2022/9/13/23351703/nasa-artemis-i-megarocket-new-launch-date)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 22:02:17+00:00

<figure>
      <img alt="NASA Launches Artemis I On Moon Orbit Mission" src="https://cdn.vox-cdn.com/thumbor/TUNRq0M4JUNl9HIF1HaRTTUgOeQ=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71363991/1420429212.0.jpg" />
        <figcaption><em>NASA’s Artemis I rocket</em> | Photo by Joe Raedle / Getty Images</figcaption>
    </figure>

  <p id="7O8D86">NASA’s Artemis I rocket is now <a href="https://blogs.nasa.gov/artemis/2022/09/12/nasa-adjusts-dates-for-artemis-i-cryogenic-demons

## EA announces kernel-level anti-cheat system for PC games
 - [https://www.theverge.com/2022/9/13/23351900/ea-kernel-level-anti-cheat-system-fifa-23](https://www.theverge.com/2022/9/13/23351900/ea-kernel-level-anti-cheat-system-fifa-23)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 21:51:52+00:00

<figure>
      <img alt="EA has a new custom anti-cheat system for PC" src="https://cdn.vox-cdn.com/thumbor/ecvNqbbDfRuyOBSp9X3w5psMjZM=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71363921/acastro_300505_4008_pcGameHacks_0001.0.jpg" />
        <figcaption><em>EA’s new anti-cheat arrives in </em>FIFA 23<em> first.</em> | Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="RgWsex">Electronics Arts (EA) is launching a new kernel-level anti-cheat syste

## Elon Musk’s SpaceX and Tesla emails are for his eyes only
 - [https://www.theverge.com/2022/9/13/23351798/elon-musk-emails-spacex-tesla-ruling-privacy](https://www.theverge.com/2022/9/13/23351798/elon-musk-emails-spacex-tesla-ruling-privacy)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 21:09:51+00:00

<figure>
      <img alt="Elon Musk grins in a photo-illustration, lifting his arms over his head triumphantly because no one can read his emails without his permission" src="https://cdn.vox-cdn.com/thumbor/Yg8o_KKJL3LT5DloM-kdqoQ3zeA=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71363791/VRG_Illo_STK022_K_Radtke_Musk_Void.0.jpg" />
        <figcaption><em>It’s good to be Technoking.</em> | Kristen Radtke / The Verge; Getty Images</figcaption>
    </figure>

  <p id="LX3cSU">

## We’re careening into ‘uncharted territory of destruction,’ WMO climate report says
 - [https://www.theverge.com/2022/9/13/23351138/wmo-climate-change-report-greenhouse-gas-emission-uncharted-territory-destruction](https://www.theverge.com/2022/9/13/23351138/wmo-climate-change-report-greenhouse-gas-emission-uncharted-territory-destruction)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 20:34:32+00:00

<figure>
      <img alt="This aerial photograph shows flooded residential areas after heavy monsoon rains in Dera Allah Yar, Balochistan province." src="https://cdn.vox-cdn.com/thumbor/sG83kVlEHsiGj9JbF69fU-WyHqc=/0x0:3375x2250/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71363562/1242966727.0.jpg" />
        <figcaption><em>This aerial photograph taken on September 5th, 2022, shows flooded residential areas after heavy monsoon rains in Dera Allah Yar, Balochistan province in Pakistan, fo

## The best deals on true wireless earbuds right now
 - [https://www.theverge.com/22307388/wireless-earbuds-deals-airpods-galaxy-buds-powerbeats](https://www.theverge.com/22307388/wireless-earbuds-deals-airpods-galaxy-buds-powerbeats)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 20:12:39+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/EMA4Er2sFrxHrUuDpHfpSH0b1VM=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/68898291/bfarsace_201130_4322_0001.0.0.jpg" />
        <figcaption>Photo by Becca Farsace / The Verge</figcaption>
    </figure>

  <p id="Upaue8">When it comes to true wireless earbuds, there are a ton of brands and products to choose from. Whether you need something with noise cancellation for your daily commute like the <a href="https:/

## Facebook and Messenger take a hint from Discord for new Community Chats
 - [https://www.theverge.com/2022/9/13/23351094/facebook-community-chats-launch-messenger-groups](https://www.theverge.com/2022/9/13/23351094/facebook-community-chats-launch-messenger-groups)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 20:01:55+00:00

<figure>
      <img alt="Two screenshots of the Facebook app are displayed on two iPhone X devices floating on a pink and blue cloud looking backdrop. The screens show an example of chats in a group called Women Who Surf" src="https://cdn.vox-cdn.com/thumbor/-KfDd0hLxbCp33C5wXaa7WdeCdw=/301x0:3541x2160/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71363426/Community_Chats___MSGR___FB.0.png" />
        <figcaption><em>A Facebook Group called “Women Who Surf” has multiple new Community Chats

## Patreon is laying off 17 percent of its workforce and closing offices
 - [https://www.theverge.com/2022/9/13/23351414/patreon-layoffs-september-2022-operations-finance-security](https://www.theverge.com/2022/9/13/23351414/patreon-layoffs-september-2022-operations-finance-security)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 19:15:37+00:00

<figure>
      <img alt="In this photo illustration, a Patreon logo is seen on a smartphone in front of a larger Patreon logo on an orange background." src="https://cdn.vox-cdn.com/thumbor/gb7uMRWuquKk67Y8cm-SH2_Psjk=/0x37:3832x2592/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71363237/1234553076.0.jpg" />
        <figcaption><em>The company says it’s changing direction.</em> | Photo Illustration by Pavlo Gonchar/SOPA Images/LightRocket via Getty Images</figcaption>
    </figure>

  <p id

## The Verge Partners with Chicago Humanities Festival for a Series of Conversations about Social Media
 - [https://www.theverge.com/2022/9/13/23351596/the-verge-partners-with-chicago-humanities-festival-for-a-series-of-conversations-about-social-media](https://www.theverge.com/2022/9/13/23351596/the-verge-partners-with-chicago-humanities-festival-for-a-series-of-conversations-about-social-media)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 19:08:04+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/iQn2dio3ZVImIsu1vmsauIKIZhI=/0x0:1200x800/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71363203/CHF_Verge_Pass.0.jpg" />
    </figure>

  <p id="3dKVy0">On November 12, 2022, The Verge will join the Chicago Humanities Festival for a full day of exploring how big tech impacts the public in a series of conversations called “The Social Mind.” The day will end with an interactive afterparty with video games provided by Bit Bash. 

## Viral internet documentary series Channel 5 is getting the HBO treatment
 - [https://www.theverge.com/2022/9/13/23351338/andrew-callaghan-channel-5-documentary-january-6-insurrection-hbo-a24-deal](https://www.theverge.com/2022/9/13/23351338/andrew-callaghan-channel-5-documentary-january-6-insurrection-hbo-a24-deal)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 19:00:10+00:00

<figure>
      <img alt="Andrew Callaghan interviews a source for an episode of the show on the People’s Convoy." src="https://cdn.vox-cdn.com/thumbor/gg-nrjadGTmiBa6TOSPjnzShS6U=/0x0:1266x844/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71363180/Screen_Shot_2022_09_13_at_2.15.00_PM.0.png" />
        <figcaption><em>Andrew Callaghan is the host of Channel 5 videos.</em> | Image: Channel 5</figcaption>
    </figure>

  <p id="5kHp3S">Internet documentary series Channel 5 has taken viewers 

## Hot Pod Summit is back at On Air LA Annex 2022!
 - [https://www.theverge.com/23348881/hot-pod-summit-on-air-fext-la-annex-2022-kcrw](https://www.theverge.com/23348881/hot-pod-summit-on-air-fext-la-annex-2022-kcrw)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 18:00:00+00:00

<figure>
      <img alt="The Hot Pod logo in yellow is overlaid on a photo of Hot Pod lead writer Ariel Shapiro on an orange background. " src="https://cdn.vox-cdn.com/thumbor/veY9RQiQ9iTqe86hQO5GWh37RZg=/0x0:2051x1367/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362844/Hot_Pod_New_Site_Post.0.jpg" />
        <figcaption>Image: The Verge</figcaption>
    </figure>

  <p id="gRH5ua"><em>The Verge </em>is pleased to announce that Hot Pod Summit — our invite-only event for creators and lea

## Here are the biggest announcements from Nintendo’s latest Direct
 - [https://www.theverge.com/2022/9/13/23350975/nintendo-direct-switch-fire-emblem-legend-of-zelda-tears-of-the-kingdom](https://www.theverge.com/2022/9/13/23350975/nintendo-direct-switch-fire-emblem-legend-of-zelda-tears-of-the-kingdom)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 17:13:44+00:00

<figure>
      <img alt="GoldenEye returns to consoles after 25 years" src="https://cdn.vox-cdn.com/thumbor/Q-ESfKpXLXlbB7VJuz2p_ZIUWI4=/94x0:1107x675/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362639/FciqQP1XoAMBEPv.0.jpg" />
        <figcaption><em>Goldeneye 007 is coming to the Switch.</em> | Image: Rare</figcaption>
    </figure>

  <p id="2c0dlM">As expected, Nintendo pulled out all the stops for its fall Direct showcase with <a href="https://www.theverge.com/2022/9/13/23350851/f

## Twitter shareholders approve $44 billion Elon Musk buyout
 - [https://www.theverge.com/2022/9/13/23349687/twitter-musk-acquisition-shareholder-vote-approval](https://www.theverge.com/2022/9/13/23349687/twitter-musk-acquisition-shareholder-vote-approval)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 17:11:49+00:00

<figure>
      <img alt="The Twitter logo on a red and black background." src="https://cdn.vox-cdn.com/thumbor/SEr7oxDvw2WT_MvcCkEUb452DsU=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362631/acastro_STK050_09.5.jpg" />
        <figcaption>The Twitter logo. | Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="hdn9FQ">Twitter’s shareholders have voted to approve a proposed $44 billion acquisition by Elon Musk.</p>
<p id="PXkbEO">Reports yesterday s

## Join The Verge at the 2022 Chicago Humanities Festival!
 - [https://www.theverge.com/23344323/verge-series-chicago-humanities-festival-2022-tickets](https://www.theverge.com/23344323/verge-series-chicago-humanities-festival-2022-tickets)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 17:00:00+00:00

<figure>
      <img alt="A phone with an image of a brain. A cord is plugged into the phone making the outline of a head on a yellow background. " src="https://cdn.vox-cdn.com/thumbor/V3mi8mf5wFbTr1X9KAqQlcYaVn8=/66x0:6335x4179/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362521/CHF_Verge_Pass.0.png" />
        <figcaption>Illustration by Emmett Mottl</figcaption>
    </figure>

  <p id="k3vHMg">We’re excited to announce that <em>The Verge </em>is partnering with the Chicago Humanities 

## Meghan Markle paused her podcast to mourn the queen, but it’s still a huge hit
 - [https://www.theverge.com/2022/9/13/23351126/meghan-markle-podcast-queen-charles-royals-spotify-twitter-hot-pod-summit](https://www.theverge.com/2022/9/13/23351126/meghan-markle-podcast-queen-charles-royals-spotify-twitter-hot-pod-summit)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 17:00:00+00:00

<figure>
      <img alt="The Prince and Princess of Wales Accompanied By The Duke And Duchess Of Sussex Greet Wellwishers Outside Windsor Castle" src="https://cdn.vox-cdn.com/thumbor/BN4PRthx1qSBPYQwB_TgR7OoWt0=/1502x161:5575x2876/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362518/1422557569.0.jpg" />
        <figcaption>Photo by Chris Jackson - WPA Pool / Getty Images</figcaption>
    </figure>

  <p id="eIKyT0">We’ve got a lot on the docket, so I’ll keep it brief. Today: Meghan Markl

## All the news from Nintendo’s September 2022 Direct
 - [https://www.theverge.com/2022/9/13/23351091/nintendo-september-2022-direct-news-storystream](https://www.theverge.com/2022/9/13/23351091/nintendo-september-2022-direct-news-storystream)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 16:39:14+00:00

<figure>
      <img alt="In a screenshot from The Legend of Zelda: Tears of the Kingdom, Link crouches on a stone bird that is flying in the air over Hyrule." src="https://cdn.vox-cdn.com/thumbor/Yc0DxiyEfB_KTdwGG6LmhvbpRyU=/150x0:1770x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362371/The_Legend_of_Zelda__Tears_of_the_Kingdom___Coming_May_12th__2023___Nintendo_Switch_1_6_screenshot.0.png" />
        <figcaption><em>I can’t wait to fly on this stone bird thing in 2023.</em> | Imag

## There’s a hidden feature in iOS 16 that lets you see only your unread messages
 - [https://www.theverge.com/2022/9/13/23351132/ios-16-unread-messages-feature-filter-unknown-senders](https://www.theverge.com/2022/9/13/23351132/ios-16-unread-messages-feature-filter-unknown-senders)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 16:35:22+00:00

<figure>
      <img alt="Someone holding the iPhone 14 Plus." src="https://cdn.vox-cdn.com/thumbor/echV0tWlM1XgfUZUhhbgq1K-3zs=/4x0:3004x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362348/DSC03649.0.jpeg" />
        <figcaption><em>iOS 16 brings lots of features to new and old devices — some more obvious than others.</em> | Photo by Allison Johnson / The Verge</figcaption>
    </figure>

  <p id="MjnJfW">If you <a href="https://www.theverge.com/2022/9/12/23348578/ios-16-download-r

## Twitter ‘lacked the ability to hunt for foreign intelligence agents,’ says whistleblower
 - [https://www.theverge.com/2022/9/13/23351158/twitter-mudge-zatko-foreign-intelligence-agents-whistleblower-judiciary-committee](https://www.theverge.com/2022/9/13/23351158/twitter-mudge-zatko-foreign-intelligence-agents-whistleblower-judiciary-committee)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 16:32:30+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/sUwk8oA0F7v6p-v8q8k1tw7AQdM=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362335/acastro_STK050_09.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="Mrz8OE">Twitter’s lack of internal security controls was such that the company was simply unable to detect agents of foreign intelligence services who had infiltrated the company, former security chief Peite

## Hunter Douglas’ new smart shades platform will work with Matter
 - [https://www.theverge.com/2022/9/13/23350626/hunter-douglas-smart-shades-powerview-gen3-platform-matter](https://www.theverge.com/2022/9/13/23350626/hunter-douglas-smart-shades-powerview-gen3-platform-matter)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 16:05:03+00:00

<figure>
      <img alt="Hunter Douglas smart shades" src="https://cdn.vox-cdn.com/thumbor/mWXYYz295llvuj6b2rYfJreXf-I=/160x0:1120x640/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362189/Hunter_Douglas_Designer_Roller_Shade___2_.0.png" />
        <figcaption><em>Hunter Douglas’ new smart shades and blinds will work with the new smart home standard Matter.</em> | Image: Hunter Douglas</figcaption>
    </figure>

  <p id="iqkygT"><a href="https://www.theverge.com/21402661/lutron-serena-sm

## And the Emmy goes to...
 - [https://www.theverge.com/2022/9/13/23350612/emmy-winners-2022](https://www.theverge.com/2022/9/13/23350612/emmy-winners-2022)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 15:58:36+00:00

<figure>
      <img alt="Actor Lee Jung-jae and Squid Game director Hwang Dong-hyuk posing with their Emmys in front of a turquoise backdrop." src="https://cdn.vox-cdn.com/thumbor/NmSRVoxpepfZCB16-2H__hjxu-0=/42x0:6054x4008/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362121/1243184135.0.jpg" />
        <figcaption><em>Lee Jung-jae (left) and </em>Squid Game<em> director Hwang Dong-hyuk (right)&nbsp;posing with their Emmys.</em> | FREDERIC J. BROWN/AFP via Getty Images</figcaption>
    

## Everyone knows what YouTube is — few know how it really works
 - [https://www.theverge.com/2022/9/13/23349037/mark-bergen-youtube-creators-tiktok-algorithm](https://www.theverge.com/2022/9/13/23349037/mark-bergen-youtube-creators-tiktok-algorithm)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 15:54:59+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/VFTVeItrAFXiC8Wd0gLM29ZEQ7k=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362097/226271_Decoder_Mark_Bergen_002.0.jpg" />
        <figcaption>Photo illustration by Will Joel / The Verge</figcaption>
    </figure>


  		 <p>Mark Bergen takes us inside the black box</p>
  <p>
    <a href="https://www.theverge.com/2022/9/13/23349037/mark-bergen-youtube-creators-tiktok-algorithm">Continue reading&hellip;</a>
  </p

## Proton and DuckDuckGo want Congress to approve tech antitrust reform ‘as soon as possible’
 - [https://www.theverge.com/2022/9/13/23351036/proton-mail-duckduckgo-mozilla-schumer-aico-antitrust-amazon-google](https://www.theverge.com/2022/9/13/23351036/proton-mail-duckduckgo-mozilla-schumer-aico-antitrust-amazon-google)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 15:47:43+00:00

<figure>
      <img alt="Senators Meet For Their Policy Luncheon On Capitol Hill" src="https://cdn.vox-cdn.com/thumbor/g1aBSC1V52ZcYCPeN5_7_OxnzG0=/0x0:6000x4000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71362073/1421683770.0.jpg" />
        <figcaption><em>Sen. Chuck Schumer (D-NY) has yet to call a vote on the American Innovation and Choice Online Act.</em> | Photo by Anna Moneymaker/Getty Images</figcaption>
    </figure>

  <p id="octwAo">More than a dozen smaller tech companies, i

## Honda will introduce at least 10 fully electric motorcycles by 2025
 - [https://www.theverge.com/2022/9/13/23350781/honda-electric-motorcycle-10-new-models-2025](https://www.theverge.com/2022/9/13/23350781/honda-electric-motorcycle-10-new-models-2025)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 15:28:33+00:00

<figure>
      <img alt="Honda dominates the motorcycle business today. " src="https://cdn.vox-cdn.com/thumbor/uw_9rHU4HIi5I7NO1A8I_u4fvEU=/300x0:3540x2160/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361993/8_FUN_EV_models.0.jpg" />
        <figcaption>Honda wants its motorcycle business to be carbon neutral by 2040. | Image: Honda</figcaption>
    </figure>

  <p id="vtoSMI">Honda, one of the biggest names in motorcycles, announced that it will release at least 10 new electric models 

## These working prototypes reveal the Steam Deck’s evolution
 - [https://www.theverge.com/2022/9/13/23350852/valve-steam-deck-prototype-designs](https://www.theverge.com/2022/9/13/23350852/valve-steam-deck-prototype-designs)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 15:13:32+00:00

<figure>
      <img alt="A photograph of a line of Steam Deck prototypes" src="https://cdn.vox-cdn.com/thumbor/7ICrUkAUASXti4dIkoPplXI_E0c=/150x0:1770x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361917/Steam_Deck_prototype.0.jpg" />
        <figcaption><em>A line of Steam Deck prototypes displaying the evolutionary journey of the Valve handheld gaming PC.</em> | Image: Pierre-Loup Griffais</figcaption>
    </figure>

  <p id="3fq9MI">A collection of playable <a href="https://www.t

## The Legend of Zelda: Tears of the Kingdom is the sequel to Breath of the Wild
 - [https://www.theverge.com/2022/9/13/23350972/the-legend-of-zelda-tears-of-the-kingdom-sequel-breath-of-the-wild-2-nintendo-switch](https://www.theverge.com/2022/9/13/23350972/the-legend-of-zelda-tears-of-the-kingdom-sequel-breath-of-the-wild-2-nintendo-switch)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 14:57:50+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/sHHjbJb-4WS6kMZ92vvqYMuTPno=/173x0:1883x1140/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361802/image.0.png" />
    </figure>

  <p id="elqWXM">Nintendo finally revealed the name and launch date for <em>The Legend of Zelda: Breath of the Wild’s</em> sequel: <em>The Legend of Zelda: Tears of the Kingdom</em>. <a href="https://www.youtube.com/watch?v=2SNF4M_v7wc">In a trailer</a>, Nintendo revealed the new name and the game’

## Sony announces development of its first over-the-counter hearing aid for the US
 - [https://www.theverge.com/2022/9/13/23350757/sony-otc-hearing-aid-announced-ws-audiology-fda](https://www.theverge.com/2022/9/13/23350757/sony-otc-hearing-aid-announced-ws-audiology-fda)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 14:40:56+00:00

<figure>
      <img alt="An illustration featuring the Sony logo." src="https://cdn.vox-cdn.com/thumbor/JFy-pniFhk9b63zm5JOq_2h1UH4=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361742/STK325_K_Radtke_Sony_01.0.jpg" />
        <figcaption>Illustration by Kristen Radtke / The Verge</figcaption>
    </figure>

  <p id="mljZXG">A ruling from the FDA that <a href="https://www.theverge.com/2022/8/16/23307974/hearing-aids-over-counter-fda-apple-bose">allows over-the-counter sale

## Samsung’s new Z Flip and Z Fold phones just got their first discount
 - [https://www.theverge.com/2022/9/13/23349187/samsung-z-flip-fold-spigen-anker-charger-corsair-gaming-keyboard-deal-sale](https://www.theverge.com/2022/9/13/23349187/samsung-z-flip-fold-spigen-anker-charger-corsair-gaming-keyboard-deal-sale)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 14:39:23+00:00

<figure>
      <img alt="A photo of the Samsung Galaxy Z Fold 4, opened halfway, on a marble surface." src="https://cdn.vox-cdn.com/thumbor/I7oZ2SJHnjKeOKqbs5sKG1wv2BM=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361734/DSC03319_fold_4.0.jpg" />
        <figcaption><em>Samsung’s fourth-generation foldables are already getting a discount.</em> | Photo by Allison Johnson / The Verge</figcaption>
    </figure>

  <p id="sOG4xA">Following Apple’s “Far Out” event, where it had

## GoldenEye 007 is finally coming to Xbox and Nintendo Switch
 - [https://www.theverge.com/2022/9/13/23162373/goldeneye-007-xbox-release-remaster-nintendo-switch](https://www.theverge.com/2022/9/13/23162373/goldeneye-007-xbox-release-remaster-nintendo-switch)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 14:30:44+00:00

<figure>
      <img alt="GoldenEye returns to consoles after 25 years" src="https://cdn.vox-cdn.com/thumbor/QezoxQ6701-RIqRx6uY6jH9190Y=/94x0:1107x675/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361674/FciqQP1XoAMBEPv.0.jpg" />
        <figcaption><em>GoldeEye 007 is back.﻿</em> | Image: Rare</figcaption>
    </figure>

  <p id="tnHdlm"><em>GoldenEye 007</em> is finally coming to Nintendo Switch and Xbox. Nintendo announced today that Rare is releasing <em>GoldenEye 007</em> HD on Nint

## The Inflation Reduction Act’s tax credits are confusing, so the White House launched a website to help
 - [https://www.theverge.com/2022/9/13/23350787/inflation-reduction-act-green-energy-tax-credit-website](https://www.theverge.com/2022/9/13/23350787/inflation-reduction-act-green-energy-tax-credit-website)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 14:30:00+00:00

<figure>
      <img alt="Biden administration to secure $5 billion funding to create electric vehicle chargers across the US" src="https://cdn.vox-cdn.com/thumbor/M3HKfevl4gws-XOL8tE0VH6T-fs=/0x0:3500x2333/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361658/1403679844.0.jpg" />
    </figure>

  <p id="X3UcNe">The Biden administration launched a new website — <a href="http://CleanEnergy.gov">CleanEnergy.gov</a> — aimed at helping Americans navigate the new green energy tax credits contai

## The sound of your voice might diagnose diseases
 - [https://www.theverge.com/2022/9/13/23350793/human-voice-disease-ai-diagnosis](https://www.theverge.com/2022/9/13/23350793/human-voice-disease-ai-diagnosis)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 14:30:00+00:00

<figure>
      <img alt="Microphone against a yellow background." src="https://cdn.vox-cdn.com/thumbor/tmtX9emAGkJJDUgbHnvCZ9LvAmI=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361665/akrales_190313_3227_0061.0.jpg" />
        <figcaption><em>Voice could be a way to detect disease.</em> | Photo by Amelia Holowaty Krales / The Verge</figcaption>
    </figure>

  <p id="JJ5rwa">Researchers are building a database of human voices that they’ll use to develop AI-based tools tha

## Tunic is coming to the Switch and PlayStation in just a couple weeks
 - [https://www.theverge.com/2022/9/13/23350828/tunic-nintendo-switch-playstation-4-5-release-date](https://www.theverge.com/2022/9/13/23350828/tunic-nintendo-switch-playstation-4-5-release-date)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 14:22:34+00:00

<figure>
      <img alt="In a screenshot from Tunic, the main character stands with his sword raised on a plot of blocky land." src="https://cdn.vox-cdn.com/thumbor/65OQm8tuTpokpfdWqY6IJwiho0U=/150x0:1770x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361637/TUNIC_Demo_Screenshot_Wave.0.png" />
        <figcaption><em>Play as this adorable fox on new platforms soon.</em> | Image: Finji</figcaption>
    </figure>

  <p id="O3TeT7"><em>Tunic</em>, the indie hit where you explore a myst

## Fire Emblem Engage is the next entry in Nintendo’s brilliant strategy franchise
 - [https://www.theverge.com/2022/9/13/23350851/fire-emblem-engage-nintendo-switch-game-release-date-trailer](https://www.theverge.com/2022/9/13/23350851/fire-emblem-engage-nintendo-switch-game-release-date-trailer)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 14:17:12+00:00

<figure>
      <img alt="A drawing of Fire Emblem Engage, the latest strategy game from nintendo" src="https://cdn.vox-cdn.com/thumbor/pIl6m8Y6ewe4yqOhefXPbJ0tdOA=/0x0:1711x1141/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361620/feengage.0.jpg" />
        <figcaption>Nintendo</figcaption>
    </figure>

  <p id="PAX27I">Nintendo announced <em>Fire Emblem Engage</em> during its latest Direct showcase. The new strategy-based game will release for the Nintendo Switch on January 20th, 2023

## Babylon’s Fell
 - [https://www.theverge.com/2022/9/13/23350704/babylons-fall-offline-date-2023-platinum-games](https://www.theverge.com/2022/9/13/23350704/babylons-fall-offline-date-2023-platinum-games)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 14:12:21+00:00

<figure>
      <img alt="Screenshot from Babylon’s Fall with heroes standing in the foreground in front of a tall looming structure" src="https://cdn.vox-cdn.com/thumbor/vdHZY_OG-exniUS-I7zgYxyBIxI=/103x0:1260x771/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361601/Screen_Shot_2019_12_10_at_9.28.22_AM.0.png" />
        <figcaption>Image: Platinum Games</figcaption>
    </figure>

  <p id="STanWf">All good things must come to an end. <a href="https://www.theverge.com/2018/6/11/17449562/b

## Amazon’s latest Kindle has USB-C charging and a much better screen
 - [https://www.theverge.com/2022/9/13/23350735/amazon-kindle-usb-c-display-screen-features](https://www.theverge.com/2022/9/13/23350735/amazon-kindle-usb-c-display-screen-features)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 13:49:09+00:00

<figure>
      <img alt="An Amazon Kindle on a colorful background." src="https://cdn.vox-cdn.com/thumbor/VM10AtyS-I88oqeOj4bN5Ww4bWI=/0x221:2000x1554/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361444/Kindle__Black__Covers.0.jpeg" />
        <figcaption><em>The new Kindle’s new screen now matches the other models.</em> | Photo: Amazon</figcaption>
    </figure>

  <p id="MtXwzl">Amazon just <a href="https://press.aboutamazon.com/news-releases/news-release-details/introducing-all-new-k

## Fitbit Inspire 3 hands-on: blast from the past
 - [https://www.theverge.com/2022/9/13/23349403/fitbit-inspire-3-hands-on-fitness-tracker-wearables](https://www.theverge.com/2022/9/13/23349403/fitbit-inspire-3-hands-on-fitness-tracker-wearables)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 13:00:00+00:00

<figure>
      <img alt="The Fitbit Inspire 3 on top of a plant" src="https://cdn.vox-cdn.com/thumbor/l16YDhEQ649Iiv5_4ZRb1RXFuIw=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361248/226269_FITBIT_INSPIRE_3_PHO_vsong_0004.0.jpg" />
        <figcaption><em>The Fitbit Inspire 3 does the basics well.</em></figcaption>
    </figure>


  		 <p>The basics with a modern twist</p>
  <p>
    <a href="https://www.theverge.com/2022/9/13/23349403/fitbit-inspire-3-hands-on-fitness-trac

## Sonos announces long-awaited Sub Mini for $429
 - [https://www.theverge.com/2022/9/13/23348826/sonos-sub-mini-announced-features-price-release-date](https://www.theverge.com/2022/9/13/23348826/sonos-sub-mini-announced-features-price-release-date)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 13:00:00+00:00

<figure>
      <img alt="A Sonos Sub Mini subwoofer pictured next to a couch, with a television in the background." src="https://cdn.vox-cdn.com/thumbor/206YBFW4eScNqOvF3kpkBL2MpDs=/0x170:2040x1530/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71361250/SubMiniLede.0.jpg" />
        <figcaption><em>The Sub Mini will be available October 6th.</em> | Image: Sonos</figcaption>
    </figure>

  <p id="WeO1A3">Sonos fans have been waiting ages for a home theater subwoofer that’s cheaper than the

## The HP Elite Dragonfly Chromebook is incredible — with one big problem
 - [https://www.theverge.com/23341235/hp-elite-dragonfly-chromebook-2022-review](https://www.theverge.com/23341235/hp-elite-dragonfly-chromebook-2022-review)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 12:30:00+00:00

<p>Beautiful chassis, fast processor, great screen, and software that doesn’t keep up</p>
  <p>
    <a href="https://www.theverge.com/23341235/hp-elite-dragonfly-chromebook-2022-review">Continue reading&hellip;</a>
  </p>

## We have a new Verge comment system!
 - [https://www.theverge.com/2022/9/13/23348811/the-verge-new-comments-coral](https://www.theverge.com/2022/9/13/23348811/the-verge-new-comments-coral)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 12:00:18+00:00

<figure>
      <img alt="A&amp;nbsp;fictional toroidal space colony" src="https://cdn.vox-cdn.com/thumbor/PnltfHsAK_F3cCTm7LltksIomwU=/0x64:1041x758/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71360762/toroidal_colony.0.jpg" />
        <figcaption>Image: NASA Ames Research Center</figcaption>
    </figure>


  		 <p>The Verge is now powered by Coral, and you are all beautiful fish</p>
  <p>
    <a href="https://www.theverge.com/2022/9/13/23348811/the-verge-new-comments-coral">Continue re

## Welcome to the new Verge
 - [https://www.theverge.com/2022/9/13/23349876/the-verge-website-redesign-new-newsfeed-blogs-logo](https://www.theverge.com/2022/9/13/23349876/the-verge-website-redesign-new-newsfeed-blogs-logo)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 11:59:40+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/l2x4hEvCQJGIgPeRDXHq-n9ow1s=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71360640/TheVerge_Letterforms_09.10.png" />
    </figure>


  		 <p>Revolutionizing the media with blog posts</p>
  <p>
    <a href="https://www.theverge.com/2022/9/13/23349876/the-verge-website-redesign-new-newsfeed-blogs-logo">Continue reading&hellip;</a>
  </p>

## Intel just leaked its 13th Gen processor specs
 - [https://www.theverge.com/2022/9/13/23350509/intel-13th-gen-core-i5-i7-i9-specs-leak](https://www.theverge.com/2022/9/13/23350509/intel-13th-gen-core-i5-i7-i9-specs-leak)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 09:18:56+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/s7INP2gJNvHEAAtNF8FUTz5lfOc=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71360126/acastro_STK094_01.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="JVXMNh">Intel has accidentally published the specifications for its 13th Gen Raptor Lake processors. A day after confirming an upcoming 13th Gen CPU will <a href="https://www.theverge.com/2022/9/12/23348620/

## Sony’s latest smartphone accessory is pretty cool
 - [https://www.theverge.com/2022/9/13/23350504/sony-xperia-stream-smartphone-cooling-fan-usb-hub-ethernet-hdmi-3-5mm](https://www.theverge.com/2022/9/13/23350504/sony-xperia-stream-smartphone-cooling-fan-usb-hub-ethernet-hdmi-3-5mm)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 08:51:02+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/DeeBgYD3EspMm1WsPg6tyEJG3hE=/0x0:1312x875/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71360101/223GE_Accy_Medium_00_05_D.0.jpg" />
        <figcaption><em>The Xperia Stream clips onto the back of Sony’s smartphone.</em> | Image: Sony</figcaption>
    </figure>

  <p id="fW5gIc">Sony has launched a smartphone cooling fan accessory that’s designed to lower the temperature of its <a href="https://www.theverge.com/23065641/sony-

## Apple will let you roll back the iPhone’s security patches
 - [https://www.theverge.com/2022/9/12/23350044/apple-iphone-ios-rapid-response-security](https://www.theverge.com/2022/9/12/23350044/apple-iphone-ios-rapid-response-security)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 00:14:07+00:00

<figure>
      <img alt="Illustration of a phone with yellow caution tape running over it." src="https://cdn.vox-cdn.com/thumbor/afr86bUOBoFZKPZbSA3zyELlkmw=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71359302/akrales_220309_4977_0305.0.jpg" />
        <figcaption><em>But doing so obviously leaves your phone unprotected.</em> | Photo by Amelia Holowaty Krales / The Verge</figcaption>
    </figure>

  <p id="UpzkqK">Apple will let you remove the security patches installed b

## EA and Koei Tecmo are partnering on ‘the next great hunting game’
 - [https://www.theverge.com/2022/9/12/23350034/ea-koei-tecmo-next-great-hunting-game-monster-hunter-originals](https://www.theverge.com/2022/9/12/23350034/ea-koei-tecmo-next-great-hunting-game-monster-hunter-originals)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2022-09-13 00:02:21+00:00

<figure>
      <img alt="This is a piece of concept art from EA and Koei Tecmo’s new “hunting game.” In the middle of the image, a tall tree with pink leaves winds through a large building with Japanese-inspired architecture. On the sides of the image, there are other buildings and trees." src="https://cdn.vox-cdn.com/thumbor/ojtPvfVxCjo4XrkWAmerpb9m-9E=/660x0:3437x1851/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/71359270/conceptart_EMBARGO_SEPT_12_3PM_PST___11PM_GMT_UK.0.jpg" />
       


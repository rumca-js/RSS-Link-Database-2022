# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## God of War Ragnarok trailer teases Fenrir may be your wolf companion
 - [https://www.techradar.com/news/god-of-war-ragnarok-closes-state-of-play-with-action-packed-new-trailer/](https://www.techradar.com/news/god-of-war-ragnarok-closes-state-of-play-with-action-packed-new-trailer/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 22:40:42+00:00

God of War Ragnarok closed the latest PlayStation State of Play presentation with an action-loaded new trailer.

## Sony's free rewards program PlayStation Stars launches this September
 - [https://www.techradar.com/news/sonys-free-rewards-program-playstation-stars-will-launch-in-september/](https://www.techradar.com/news/sonys-free-rewards-program-playstation-stars-will-launch-in-september/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 22:34:25+00:00

PlayStation Stars will launch in Asia later this year, before rolling out to other regions in the weeks after.

## Kingston's new USB drive features a frankly unreal amount of military-grade security
 - [https://www.techradar.com/news/kingston-reveals-its-most-secure-usb-drive-ever/](https://www.techradar.com/news/kingston-reveals-its-most-secure-usb-drive-ever/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 22:11:39+00:00

The Kingston IronKey Keypad 200 promises users the highest levels of modern data protection.

## ASUS wants you to use its new ExpertBook business laptop everywhere
 - [https://www.techradar.com/news/asus-wants-you-to-use-its-new-expertbook-business-laptop-everywhere/](https://www.techradar.com/news/asus-wants-you-to-use-its-new-expertbook-business-laptop-everywhere/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 22:02:04+00:00

Powered by the Qualcomm 7c Gen 2, the new B3 laptops houses a WUXGA resolution screen and Antibacterial Guard.

## Steam accounts are being stolen by this devious phishing attack
 - [https://www.techradar.com/news/steam-accounts-are-being-stolen-by-this-devious-phishing-attack/](https://www.techradar.com/news/steam-accounts-are-being-stolen-by-this-devious-phishing-attack/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 20:52:14+00:00

Pro gamers targeted with "browser-in-browser" attacks, with stolen Steam accounts sold off on the black market.

## Looking for a boot drive? Here's why you should go for an SSD, not an HDD
 - [https://www.techradar.com/news/looking-for-a-boot-drive-heres-why-you-should-go-for-a-ssd-not-an-hdd/](https://www.techradar.com/news/looking-for-a-boot-drive-heres-why-you-should-go-for-a-ssd-not-an-hdd/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 20:02:48+00:00

A new report on drive failure rate demonstrates why SSD boot drives are a better choice than HDD equivalents.

## Meta is handing over its PyTorch AI platform to the Linux Foundation
 - [https://www.techradar.com/news/meta-is-handing-over-its-pytorch-ai-platform-to-the-linux-foundation/](https://www.techradar.com/news/meta-is-handing-over-its-pytorch-ai-platform-to-the-linux-foundation/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 19:17:49+00:00

Meta reveals PyTorch ownership is being transferred to the Linux Foundation.

## You can remove Apple's newest iOS 16 security tool if you really want, but we wouldn't recommend it
 - [https://www.techradar.com/news/you-can-remove-apples-newest-ios-16-security-tool-if-you-really-want-but-we-wouldnt-recommend-it/](https://www.techradar.com/news/you-can-remove-apples-newest-ios-16-security-tool-if-you-really-want-but-we-wouldnt-recommend-it/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 18:29:33+00:00

iOS 16 Rapid Security Response can be disabled and enabled at any time, but it's probably not a good idea.

## U-Haul confirms data breach, customer driving licences exposed
 - [https://www.techradar.com/news/u-haul-confirms-data-breach-customer-driving-licences-exposed/](https://www.techradar.com/news/u-haul-confirms-data-breach-customer-driving-licences-exposed/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 18:01:43+00:00

Hacker compromises two “unique passwords” and gains access to U-Haul search tool.

## Discord is finally available to all Xbox Series X players
 - [https://www.techradar.com/news/discord-is-finally-available-to-all-xbox-series-x-players/](https://www.techradar.com/news/discord-is-finally-available-to-all-xbox-series-x-players/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 18:00:27+00:00

Discord voice chat has rolled out to all players on Xbox Series X|S after exiting the Insider Programme.

## Steam Deck prototype pics spark debate about what could have been
 - [https://www.techradar.com/news/steam-deck-prototype-pics-spark-debate-about-what-could-have-been/](https://www.techradar.com/news/steam-deck-prototype-pics-spark-debate-about-what-could-have-been/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 17:59:00+00:00

Eye-opening photos – plus a video – have certainly caused some controversy.

## HP will pay you compensation if you bought the wrong printer ink
 - [https://www.techradar.com/news/hp-will-pay-you-compensation-if-you-bought-the-wrong-printer-ink/](https://www.techradar.com/news/hp-will-pay-you-compensation-if-you-bought-the-wrong-printer-ink/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 17:32:16+00:00

HP set to compensate customers impacted by issues surrounding “Dynamic Security”.

## Intel accidentally leaks its own Raptor Lake CPUs
 - [https://www.techradar.com/news/intel-accidentally-leaks-its-own-raptor-lake-cpus/](https://www.techradar.com/news/intel-accidentally-leaks-its-own-raptor-lake-cpus/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 17:27:12+00:00

The specs of a trio of Raptor Lake processors have been mistakenly aired.

## This new feature will make Microsoft Word feel even more like Google Docs
 - [https://www.techradar.com/news/this-new-feature-will-make-microsoft-word-feel-even-more-like-google-docs/](https://www.techradar.com/news/this-new-feature-will-make-microsoft-word-feel-even-more-like-google-docs/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 17:03:50+00:00

Create and assign tasks in Microsoft Word with new @mentions.

## This simple Microsoft Teams update could save you a ton of hassle
 - [https://www.techradar.com/news/this-simple-microsoft-teams-update-could-save-you-a-ton-of-hassle/](https://www.techradar.com/news/this-simple-microsoft-teams-update-could-save-you-a-ton-of-hassle/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 16:02:29+00:00

Microsoft Teams tweak will let you quickly spot unread messages.

## Breath of the Wild 2 finally has a release date – and a new name
 - [https://www.techradar.com/news/breath-of-the-wild-2-finally-has-a-release-date-and-a-new-name/](https://www.techradar.com/news/breath-of-the-wild-2-finally-has-a-release-date-and-a-new-name/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 16:00:00+00:00

The Legend of Zelda: Tears of the Kingdom is coming next May.

## iOS 16 will eventually reduce your iPhone’s carbon footprint
 - [https://www.techradar.com/news/ios-16-will-eventually-reduce-your-iphones-carbon-footprint/](https://www.techradar.com/news/ios-16-will-eventually-reduce-your-iphones-carbon-footprint/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 15:01:05+00:00

A future version of iOS 16 will help reduce the carbon footprint of your iPhone by changing how it charges.

## Apple releases another urgent iOS security patch, so install now
 - [https://www.techradar.com/news/apple-releases-another-urgent-ios-security-patch-so-install-now/](https://www.techradar.com/news/apple-releases-another-urgent-ios-security-patch-so-install-now/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 14:54:27+00:00

Two major iOS and macOS flaws are already being abused, so patch now.

## Oracle is pushing some of its most popular database tools to AWS
 - [https://www.techradar.com/news/oracle-is-pushing-some-of-its-most-popular-database-tools-to-aws/](https://www.techradar.com/news/oracle-is-pushing-some-of-its-most-popular-database-tools-to-aws/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 14:44:46+00:00

MySQL HeatWave will now be available to run on Amazon Web Services.

## IBM gives its Linux mainframe a major update
 - [https://www.techradar.com/news/ibm-gives-its-linux-mainframe-a-major-update/](https://www.techradar.com/news/ibm-gives-its-linux-mainframe-a-major-update/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 14:11:57+00:00

IBM’s latest z16-based Emperor 4 mainframe, designed specifically for Linux users, is about to drop.

## Margot Robbie wants to fight a snake in a wild first Babylon trailer
 - [https://www.techradar.com/news/margot-robbie-wants-to-fight-a-snake-in-a-wild-first-babylon-trailer/](https://www.techradar.com/news/margot-robbie-wants-to-fight-a-snake-in-a-wild-first-babylon-trailer/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 13:31:54+00:00

The first trailer for Babylon, Damien Chazelle's Hollywood wildly epic period drama, has debuted online.

## Google Pixelbook is no more, proving the world wasn’t ready for premium Chromebooks
 - [https://www.techradar.com/news/google-pixelbook-is-no-more-proving-the-world-wasnt-ready-for-premium-chromebooks/](https://www.techradar.com/news/google-pixelbook-is-no-more-proving-the-world-wasnt-ready-for-premium-chromebooks/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 13:03:54+00:00

Google made one of the best laptops ever – but don’t expect any more Pixelbooks.

## New Amazon Kindle (2022) price, screen, features and what's new
 - [https://www.techradar.com/news/new-amazon-kindle-2022-price-screen-features-and-whats-new/](https://www.techradar.com/news/new-amazon-kindle-2022-price-screen-features-and-whats-new/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 13:00:35+00:00

Amazon's new Kindle is here, and we have all the information on this entry-level ereader.

## Sonos Sub Mini is the smaller, cheaper soundbar upgrade I've been waiting for
 - [https://www.techradar.com/news/sonos-sub-mini-is-the-smaller-cheaper-soundbar-upgrade-ive-been-waiting-for/](https://www.techradar.com/news/sonos-sub-mini-is-the-smaller-cheaper-soundbar-upgrade-ive-been-waiting-for/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 13:00:33+00:00

The Sonos Sub Mini is finally official, and it looks like exactly what I want for my Sonos setup.

## Amazon's new cheap Kindle update comes with 3 useful upgrades
 - [https://www.techradar.com/news/amazons-new-cheap-kindle-update-comes-with-three-useful-upgrades/](https://www.techradar.com/news/amazons-new-cheap-kindle-update-comes-with-three-useful-upgrades/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 13:00:04+00:00

Amazon has launched two new Kindle ereaders, including an updated version of its standard model.

## The Next World Forum provided insight into the future of eSports
 - [https://www.techradar.com/news/the-next-world-forum-provided-insight-into-the-future-of-esports/](https://www.techradar.com/news/the-next-world-forum-provided-insight-into-the-future-of-esports/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 12:56:43+00:00

Saudi eSports hosted the first ever Next World Forum over two days in Riyadh Saudi Arabia. Athletes, creators, and industry experts from around the world came to share their vision for the future of gaming.

## iPhone 15: what we know so far
 - [https://www.techradar.com/news/iphone-15/](https://www.techradar.com/news/iphone-15/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 12:34:07+00:00

Here's what we've already heard about the iPhone 15, a year before it's expected to release.

## iPhone 15: what we know so far
 - [https://www.techradar.com/news/iphone-15](https://www.techradar.com/news/iphone-15)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 12:34:07+00:00

Here's what we've already heard about the iPhone 15, a year before it's expected to release.

## Microsoft, Dell warn against impulsive budget cuts as recession looms
 - [https://www.techradar.com/news/microsoft-dell-warn-against-impulsive-budget-cuts-as-recession-looms/](https://www.techradar.com/news/microsoft-dell-warn-against-impulsive-budget-cuts-as-recession-looms/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 12:01:13+00:00

Microsoft and Dell say businesses need to consider the long-term strategic importance of technology.

## Square Enix is finally shutting down its biggest disaster of the year
 - [https://www.techradar.com/news/square-enix-is-finally-shutting-down-its-biggest-disaster-of-the-year/](https://www.techradar.com/news/square-enix-is-finally-shutting-down-its-biggest-disaster-of-the-year/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 12:00:28+00:00

Multiplayer RPG Babylon's Fall will be terminated only a year after its release.

## New password manager does away with master passwords once and for all
 - [https://www.techradar.com/news/new-password-manager-does-away-with-master-passwords-once-and-for-all/](https://www.techradar.com/news/new-password-manager-does-away-with-master-passwords-once-and-for-all/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 11:51:17+00:00

New password manager eliminates master passwords and includes Open Directory technology for easy access by IT admins.

## iOS 16 finally brings two features to Photos that I've been asking for
 - [https://www.techradar.com/news/ios-16-finally-brings-two-features-to-photos-that-ive-been-asking-for/](https://www.techradar.com/news/ios-16-finally-brings-two-features-to-photos-that-ive-been-asking-for/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 11:16:55+00:00

After fifteen years, the Photos app on iOS finally lets you get rid of duplicate photos within its own section.

## Nintendo Switch successor should go big on this one feature, says former president
 - [https://www.techradar.com/news/nintendo-switch-successor-should-go-big-on-this-one-feature-says-former-president/](https://www.techradar.com/news/nintendo-switch-successor-should-go-big-on-this-one-feature-says-former-president/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 11:00:46+00:00

Former Nintendo president Reggie Fils-Aimé weighs in on what he'd like to see from the company's next console.

## Intel assures us its Arc graphics cards are here to stay
 - [https://www.techradar.com/news/intel-assures-us-its-arc-graphics-cards-are-here-to-stay/](https://www.techradar.com/news/intel-assures-us-its-arc-graphics-cards-are-here-to-stay/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 10:27:52+00:00

An Intel exec has made it very clear that the rumors around Arc GPUs being ditched are just plain wrong.

## Grab a bunch of freebies by playing the Call of Duty: Modern Warfare 2 beta
 - [https://www.techradar.com/news/grab-a-bunch-of-freebies-by-playing-the-call-of-duty-modern-warfare-2-beta/](https://www.techradar.com/news/grab-a-bunch-of-freebies-by-playing-the-call-of-duty-modern-warfare-2-beta/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 10:25:45+00:00

Dip into the Modern Warfare 2 open beta to unlock exclusive in-game rewards.

## Audio Pro's new speakers promise a big, easy TV audio upgrade for soundbar haters
 - [https://www.techradar.com/news/audio-pros-new-speakers-promise-a-big-easy-tv-audio-upgrade-for-soundbar-haters/](https://www.techradar.com/news/audio-pros-new-speakers-promise-a-big-easy-tv-audio-upgrade-for-soundbar-haters/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 10:02:46+00:00

Want big, bold TV sound but don't care for all the 3D Dolby Atmos soundbar shenanigans? These Audio Pro wireless speakers could be exactly what you need.

## iOS 16's battery update won’t come to smaller iPhones
 - [https://www.techradar.com/news/ios16s-battery-update-wont-come-to-smaller-iphones/](https://www.techradar.com/news/ios16s-battery-update-wont-come-to-smaller-iphones/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 09:47:44+00:00

Apple's smaller iPhones like the iPhone 13 mini and iPhone 11 won't get iOS 16's battery update.

## Succession and Ted Lasso lose out to surprise HBO Max show at 2022 Emmys
 - [https://www.techradar.com/news/succession-and-ted-lasso-lose-out-to-surprise-hbo-max-show-at-2022-emmys/](https://www.techradar.com/news/succession-and-ted-lasso-lose-out-to-surprise-hbo-max-show-at-2022-emmys/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 09:43:35+00:00

Ted Lasso and Succession weren't the biggest winners at the 74th Primetime Emmy Awards.

## Ransomware attackers are abusing VoIP software to breach organizations
 - [https://www.techradar.com/news/ransomware-attackers-are-abusing-voip-software-to-breach-organizations/](https://www.techradar.com/news/ransomware-attackers-are-abusing-voip-software-to-breach-organizations/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 09:33:13+00:00

Unpatched Mitel MiVoice VOIP appliances are being hunted by the Lorenz ransomware operators.

## Call of Duty Next: how to watch, start time and what to expect
 - [https://www.techradar.com/news/call-of-duty-next-how-to-watch-start-time-and-what-to-expect/](https://www.techradar.com/news/call-of-duty-next-how-to-watch-start-time-and-what-to-expect/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 09:14:55+00:00

Call of Duty Next will reveal all about the franchise's future, as Activision promises a bumper crop of updates.

## Employees are losing hundreds of hours to old-school ways of working
 - [https://www.techradar.com/news/employees-are-losing-hundreds-of-hours-to-old-school-ways-of-working/](https://www.techradar.com/news/employees-are-losing-hundreds-of-hours-to-old-school-ways-of-working/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 05:36:23+00:00

UK businesses lose 28 days each year on inefficient work practices.

## New leaks suggest tantalizing Nvidia RTX 4090 and RTX 4080 announcement
 - [https://www.techradar.com/news/new-leaks-suggest-tantalizing-nvidia-rtx-4090-and-rtx-4080-announcement/](https://www.techradar.com/news/new-leaks-suggest-tantalizing-nvidia-rtx-4090-and-rtx-4080-announcement/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 05:00:26+00:00

Two recent leaked photos of the RTX 4090 and RTX 4080 go a long way

## Zoom's answer to Slack is getting a new name and some new tools
 - [https://www.techradar.com/news/zooms-answer-to-slack-is-getting-a-new-name-and-some-new-tools/](https://www.techradar.com/news/zooms-answer-to-slack-is-getting-a-new-name-and-some-new-tools/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 04:00:34+00:00

Now known as Zoom Team Chat, the messaging platform's upcoming features paint a more collaborative future.

## Make sure not to damage your iPhone 14 – it could cost much more to repair
 - [https://www.techradar.com/news/make-sure-not-to-damage-your-iphone-14-it-could-cost-much-more-to-repair/](https://www.techradar.com/news/make-sure-not-to-damage-your-iphone-14-it-could-cost-much-more-to-repair/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 04:00:24+00:00

The cost of a battery replacement for an iPhone 14 phone is a lot higher than it was for the iPhone 13.

## Astell & Kern's new hi-res music player wants to outdo the very best (aka: itself)
 - [https://www.techradar.com/news/astell-and-kerns-new-flagship-player-wants-to-outdo-the-very-best-aka-another-aandk/](https://www.techradar.com/news/astell-and-kerns-new-flagship-player-wants-to-outdo-the-very-best-aka-another-aandk/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-09-13 02:00:24+00:00

A&amp;K's new baby is the world’s first portable player with a watch-grade 904L stainless steel body.


# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Celsius Network Plots a Comeback After a Crypto Crash
 - [https://www.nytimes.com/2022/09/13/technology/celsius-network-crypto.html](https://www.nytimes.com/2022/09/13/technology/celsius-network-crypto.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-13 16:29:28+00:00

The chief executive of the experimental crypto bank Celsius has told employees about an audacious plan to revive the firm, which filed for bankruptcy in July.

## Whistle-Blower Says Twitter ‘Chose to Mislead’ on Security Flaws
 - [https://www.nytimes.com/2022/09/13/technology/twitter-whistle-blower-security-flaws.html](https://www.nytimes.com/2022/09/13/technology/twitter-whistle-blower-security-flaws.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-09-13 15:25:38+00:00

At a congressional hearing, Peiter Zatko, Twitter’s former head of security, told lawmakers that the company lied about its data practices.


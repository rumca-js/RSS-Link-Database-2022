# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Flights and hotel prices rocket for trips to London the night before the Queen's funeral
 - [https://www.dailymail.co.uk/news/article-11209625/Flights-hotel-prices-rocket-trips-London-night-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209625/Flights-hotel-prices-rocket-trips-London-night-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 23:55:47+00:00

Analysis by the Mail yesterday found the cheapest Edinburgh to Heathrow fare with BA (pictured) on Sunday, the day before the funeral, was £422. But it dropped to £99 a day later.

## Husband of Melissa Caddick 'wasn't overly concerned' after the conwoman went missing, inquest hears
 - [https://www.dailymail.co.uk/news/article-11209411/Husband-Melissa-Caddick-wasnt-overly-concerned-conwoman-went-missing-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209411/Husband-Melissa-Caddick-wasnt-overly-concerned-conwoman-went-missing-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 23:53:41+00:00

Detective Sergeant Michael Kyneur told an inquest Melissa Caddick's husband Anthony Koletti didn't appear 'overly concerned' after her disappearance in November, 2020.

## Queen dies: Anthony Albanese announces new square for Sydney city in tribute to Queen Elizabeth II
 - [https://www.dailymail.co.uk/news/article-11209631/Queen-dies-Anthony-Albanese-announces-new-square-Sydney-city-tribute-Queen-Elizabeth-II.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209631/Queen-dies-Anthony-Albanese-announces-new-square-Sydney-city-tribute-Queen-Elizabeth-II.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 23:51:30+00:00

Prime Minister Anthony Albanese and NSW Premier Dominic Perrottet announced the touching memorial to the late Queen on Wednesday morning.

## Husband of Texas teacher fired for defending pedophiles to kids says she was challenging children
 - [https://www.dailymail.co.uk/news/article-11209281/Husband-Texas-teacher-fired-defending-pedophiles-kids-says-challenging-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209281/Husband-Texas-teacher-fired-defending-pedophiles-kids-says-challenging-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 23:36:50+00:00

Amber Parker, 53, was fired from her job teaching English at an El Paso school on September 6. Her husband now says she was taken out of context and her career ruined by an edited clip.

## KJP says Biden is looking at mobilizing airports, roads and WATERWAYS as mass rail strike looms
 - [https://www.dailymail.co.uk/news/article-11209303/KJP-says-Biden-looking-mobilizing-airports-roads-WATERWAYS-mass-rail-strike-looms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209303/KJP-says-Biden-looking-mobilizing-airports-roads-WATERWAYS-mass-rail-strike-looms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 23:36:26+00:00

The Biden administration is scrambling to establish a clear contingency plan in the face of a looming mass railroad workers strike, press secretary Karine Jean-Pierre confirmed on Tuesday.

## The Parlour Room Clovelly owner Natalie Ferrari slams National Day of Mourning for the Queen
 - [https://www.dailymail.co.uk/news/article-11209357/The-Parlour-Room-Clovelly-owner-Natalie-Ferrari-slams-National-Day-Mourning-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209357/The-Parlour-Room-Clovelly-owner-Natalie-Ferrari-slams-National-Day-Mourning-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 23:28:42+00:00

The owner of a popular beauty parlour, Natalie Ferrari, is enraged at the government's decision to have a National Day of Mourning for the Queen, saying it will hurt small businesses.

## Vladimir Putin's forces 'are refusing to fight' and are surrendering, intelligence official claims
 - [https://www.dailymail.co.uk/news/article-11209559/Vladimir-Putins-forces-refusing-fight-surrendering-intelligence-official-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209559/Vladimir-Putins-forces-refusing-fight-surrendering-intelligence-official-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 23:17:14+00:00

Russian soldiers are refusing to fight in Ukraine amid Moscow's rising losses, it was claimed last night. The embarrassing turnaround was also said to be having an impact at home for Putin.

## Her Majesty rides off into the sunset: Cloud over London resembles late monarch on a horse
 - [https://www.dailymail.co.uk/news/article-11209557/Her-Majesty-rides-sunset-Cloud-London-resembles-late-monarch-horse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209557/Her-Majesty-rides-sunset-Cloud-London-resembles-late-monarch-horse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 23:16:51+00:00

From the double rainbow over Buckingham Palace when her death was announced to the heavens opening in symbolic downpour, the elements have appeared to reflect the nation's mood.

## Peter FitzSimons' Australia republic campaign will call to get rid of Queen and monarchy from $5
 - [https://www.dailymail.co.uk/news/article-11209427/Peter-FitzSimons-Australia-republic-campaign-call-rid-Queen-monarchy-5-notes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209427/Peter-FitzSimons-Australia-republic-campaign-call-rid-Queen-monarchy-5-notes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:55:05+00:00

The Peter FitzSimons' led Australian Republican Movement is set to call for Queen Elizabeth's image to be removed from the country's existing $5 note.

## MAFS star Stacey Hampton shares heartbreaking post about Rebels bikie ex Shane Smith killed in crash
 - [https://www.dailymail.co.uk/news/article-11209111/MAFS-star-Stacey-Hampton-shares-heartbreaking-post-Rebels-bikie-ex-Shane-Smith-killed-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209111/MAFS-star-Stacey-Hampton-shares-heartbreaking-post-Rebels-bikie-ex-Shane-Smith-killed-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:53:58+00:00

The former MAFS star  thanked wellwishers for the heartfelt messages as she shared a heartbreaking update on how her grieving sons are doing following their dad's tragic death in Adelaide.

## William and Harry will walk together with their father the King behind the Queen's coffin
 - [https://www.dailymail.co.uk/news/article-11209433/William-Harry-walk-father-King-Queens-coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209433/William-Harry-walk-father-King-Queens-coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:48:37+00:00

The Queen is staying in Buckingham Palace overnight before she is transported to lie in state ahead of her funeral. Prince William and Prince Harry will escort the coffin to Westminster.

## Meghan Markle and Prince Harry join the royal family at Buckingham Palace
 - [https://www.dailymail.co.uk/femail/article-11209273/Meghan-Markle-Prince-Harry-join-royal-family-Buckingham-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11209273/Meghan-Markle-Prince-Harry-join-royal-family-Buckingham-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:45:31+00:00

The Duke and Duchess of Sussex, who have remained in the UK following what was supposed to be a whistlestop tour of Europe, were spotted in their vehicle.

## The Bidens leave White House for unannounced trip to Wilmington
 - [https://www.dailymail.co.uk/news/article-11209231/The-Bidens-leave-White-House-unannounced-trip-Wilmington.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209231/The-Bidens-leave-White-House-unannounced-trip-Wilmington.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:40:56+00:00

President Joe Biden and Jill Biden departed the White House Tuesday night for an unannounced trip back to Wilmington, Delaware to vote in the state's Democratic primary.

## Power outage forces surgeon to perform VASECTOMY with energy siphoned from his own electric truck
 - [https://www.dailymail.co.uk/news/article-11209019/Power-outage-forces-surgeon-perform-VASECTOMY-energy-siphoned-electric-truck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209019/Power-outage-forces-surgeon-perform-VASECTOMY-energy-siphoned-electric-truck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:39:49+00:00

A urologist in Austin, Texas went the creative route during an office power outage - he used energy from his electric truck to power the tools he needed to perform a vasectomy.

## Emmys audience craters to all-time low of six million after post-pandemic bounce
 - [https://www.dailymail.co.uk/news/article-11209235/Emmys-audience-craters-time-low-six-million-post-pandemic-bounce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209235/Emmys-audience-craters-time-low-six-million-post-pandemic-bounce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:34:56+00:00

The Emmys' viewership fell to 5.9 million on Monday night, an all-time-low for the awards show after it saw a post-pandemic rebound last year, with critics slamming this year's ceremony.

## Infowars' Alex Jones made $232K off hoax Sandy Hook claims in revenue in just 1 day, lawyer says
 - [https://www.dailymail.co.uk/news/article-11209045/Infowars-Alex-Jones-232K-hoax-Sandy-Hook-claims-revenue-just-1-day-lawyer-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209045/Infowars-Alex-Jones-232K-hoax-Sandy-Hook-claims-revenue-just-1-day-lawyer-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:33:08+00:00

Deep-pocketed conspiracy theorist Alex Jones reaped nearly a quarter of a million dollars in just one day off of the bogus claim that the horrific Sandy Hook Elementary School massacre was a hoax

## Kittyhawk had flown her last: Robert Hardman watches as Queen's coffin is flown to London
 - [https://www.dailymail.co.uk/news/article-11209279/Kittyhawk-flown-Robert-Hardman-watches-Queens-coffin-flown-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209279/Kittyhawk-flown-Robert-Hardman-watches-Queens-coffin-flown-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:31:49+00:00

ROBERT HARDMAN: The Queen's RAF C-17 landed at RAF Northolt dwarfing everything around it - a vast plane to carry such a tiny coffin. Has it ever carried a more precious load?

## Suspect arrested in connection to a Texas murder after the victims mom calls off the search
 - [https://www.dailymail.co.uk/news/article-11208947/Suspect-arrested-connection-Texas-murder-victims-mom-calls-search.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208947/Suspect-arrested-connection-Texas-murder-victims-mom-calls-search.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:31:27+00:00

Police arrested a Texas man in connection to the death of a 31-year-old after the victim's mother received final text messages from her son that may have been from his murderer.

## Record-breaking female powerlifter can deadlift 639 lbs after kicking her food addiction
 - [https://www.dailymail.co.uk/news/article-11208773/Record-breaking-female-powerlifter-deadlift-639-lbs-kicking-food-addiction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208773/Record-breaking-female-powerlifter-deadlift-639-lbs-kicking-food-addiction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:14:56+00:00

Tamara Walcott weighed 415lbs but once she replaced her food addiction with lifting weights she lost 165lbs and and today can deadlift 639lbs - the weight of a baby grand piano

## Watchdog slams 'staggering' $20.4 billion U.S. taxpayers spend each year on Biden-era immigrants
 - [https://www.dailymail.co.uk/news/article-11209075/Watchdog-slams-staggering-20-4-billion-U-S-taxpayers-spend-year-Biden-era-immigrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209075/Watchdog-slams-staggering-20-4-billion-U-S-taxpayers-spend-year-Biden-era-immigrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 22:10:59+00:00

Each undocumented alien costs $9,232 in education, healthcare, welfare, justice, law enforcement and other schemes each year, says the Federation for American Immigration Reform.

## Calls grow for monarch's final journey to Windsor to be extended
 - [https://www.dailymail.co.uk/news/article-11209167/Calls-grow-monarchs-final-journey-Windsor-extended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209167/Calls-grow-monarchs-final-journey-Windsor-extended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:53:51+00:00

There were calls yesterday to lengthen the Queen's final journey to her resting place at Windsor Castle to maximise the number of people who can line the route.

## White House slams Lindsey Graham's new 15-week abortion ban as 'extreme'
 - [https://www.dailymail.co.uk/news/article-11209037/White-House-slams-Lindsey-Grahams-new-15-week-abortion-ban-extreme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209037/White-House-slams-Lindsey-Grahams-new-15-week-abortion-ban-extreme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:53:45+00:00

The White House didn't have to go back too far to find comments from Sen. Lindsey Graham that 'states should decide the issue of abortion,' after Graham introduced a nationwide 15-week ban.

## Karine Jean-Pierre congratulates staffer and former Biden researcher on their upcoming nuptials
 - [https://www.dailymail.co.uk/news/article-11208909/Karine-Jean-Pierre-congratulates-staffer-former-Biden-researcher-upcoming-nuptials.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208909/Karine-Jean-Pierre-congratulates-staffer-former-Biden-researcher-upcoming-nuptials.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:51:08+00:00

Karine Jean-Pierre kicked off her Tuesday briefing by congratulating deputy press secretary Andrew Bates and former White House researcher Megan Apper on their upcoming nuptials.

## Tens of thousands of Londoners turn out in rain to witness the Queen's final return to the capital
 - [https://www.dailymail.co.uk/news/article-11209089/Tens-thousands-Londoners-turn-rain-witness-Queens-final-return-capital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209089/Tens-thousands-Londoners-turn-rain-witness-Queens-final-return-capital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:49:56+00:00

Many put down their umbrellas as a sign of respect and some could be seen wiping tears from their eyes, while phone camera lights lit up the crowds.

## Redundancy threats for King's staff at Clarence House
 - [https://www.dailymail.co.uk/news/article-11197171/Redundancy-threats-Kings-staff-Clarence-House.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11197171/Redundancy-threats-Kings-staff-Clarence-House.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:48:14+00:00

Employees, some of whom had been with Charles for decades, claimed they were told their jobs were at risk while a church service was held for the Queen on Monday.

## MPs slam Uefa from blocking British clubs from playing the national anthem
 - [https://www.dailymail.co.uk/news/article-11209317/MPs-slam-Uefa-blocking-British-clubs-playing-national-anthem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209317/MPs-slam-Uefa-blocking-British-clubs-playing-national-anthem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:44:21+00:00

Glasgow Rangers, Manchester City and Chelsea all asked permission to play the national anthem ahead of their Champions League home games tomorrow.

## JANE FRYER talks to some of the mourners who started queueing early to see the Queen lying in state
 - [https://www.dailymail.co.uk/news/article-11209263/JANE-FRYER-talks-mourners-started-queueing-early-Queen-lying-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209263/JANE-FRYER-talks-mourners-started-queueing-early-Queen-lying-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:44:04+00:00

JANE FRYER: They're queuing on the south side of Lambeth Bridge to file past the Queen's coffin, open for viewings from 5pm today and anticipated to attract 330,000 visitors at a rate of 3,000 an hour.

## FBI affidavit: Trump counsel says he 'wasn't advised there were records in any private office'
 - [https://www.dailymail.co.uk/news/article-11209149/FBI-affidavit-Trump-counsel-says-wasnt-advised-records-private-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209149/FBI-affidavit-Trump-counsel-says-wasnt-advised-records-private-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:37:53+00:00

A magistrate in Florida unredacted more details on Tuesday of the FBI affidavit outlining its case to search Donald Trump Mar-a-Lago home.

## US Navy sailor killed in Pearl Harbor attack will finally be buried at Arlington Cemetery today
 - [https://www.dailymail.co.uk/news/article-11208983/US-Navy-sailor-killed-Pearl-Harbor-attack-finally-buried-Arlington-Cemetery-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208983/US-Navy-sailor-killed-Pearl-Harbor-attack-finally-buried-Arlington-Cemetery-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:37:11+00:00

Herbert Jacobson died on December 7, 1941, at the age of 21 aboard the USS Oklahoma. For 80 years he was one of the nearly 400 who died aboard the Oklahoma but remained unidentified.

## Lord Ashcroft offers £50,000 reward to catch gunman who killed Olivia Pratt-Korbel
 - [https://www.dailymail.co.uk/news/article-11209069/Lord-Ashcroft-offers-50-000-reward-catch-gunman-killed-Olivia-Pratt-Korbel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209069/Lord-Ashcroft-offers-50-000-reward-catch-gunman-killed-Olivia-Pratt-Korbel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:27:57+00:00

The Tory peer made the donation via his charity Crimestoppers to help find those responsible for Olivia Pratt-Korbel's murder who was shot dead last month at her home in Liverpool.

## Migrants stealing from shops and knocking on doors at night prompt town residents to buy guns
 - [https://www.dailymail.co.uk/news/article-11208831/Migrants-stealing-shops-knocking-doors-night-prompt-town-residents-buy-guns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208831/Migrants-stealing-shops-knocking-doors-night-prompt-town-residents-buy-guns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:25:41+00:00

An influx of migrants into a Texas border town killing local pets, stealing from shops and knocking on doors late at night has prompted residents to buy more guns.

## White House calls out Putin for masking retreat of Russian forces amid Ukrainian advances
 - [https://www.dailymail.co.uk/news/article-11208935/White-House-calls-Putin-masking-retreat-Russian-forces-amid-Ukrainian-advances.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208935/White-House-calls-Putin-masking-retreat-Russian-forces-amid-Ukrainian-advances.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:24:12+00:00

The White House accused Vladimir Putin of lying to his own people about the invasion of Ukraine on Tuesday, as the Russian president faced growing criticism of his handling of the war.

## Texas mom, 29, stands trial 'for murdering pregnant friend, 21, and her unborn baby'
 - [https://www.dailymail.co.uk/news/article-11208705/Texas-mom-29-stands-trial-murdering-pregnant-friend-21-unborn-baby.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208705/Texas-mom-29-stands-trial-murdering-pregnant-friend-21-unborn-baby.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:22:37+00:00

Parker, 29, is accused of killing Regan Simmons-Hancock, 21, and her baby in New Boston, in October 2020. Parker could face the death penalty after being charged with capital murder.

## Woman has died after she was struck by a train in Adelaide
 - [https://www.dailymail.co.uk/news/article-11209285/Woman-died-struck-train-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209285/Woman-died-struck-train-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:14:44+00:00

A South Australian woman has died after she was struck by a train in Adelaide's southern suburbs.

## When the Queen lies in State, we won't have seen anything like it since Churchill in 1965
 - [https://www.dailymail.co.uk/news/article-11209101/When-Queen-lies-State-wont-seen-like-Churchill-1965.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209101/When-Queen-lies-State-wont-seen-like-Churchill-1965.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 21:12:19+00:00

Two rivers run silently through London tonight, and one is made of people. Dark and quiet as the night-time Thames itself, it flows through Westminster Hall, eddying about the foot of the rock...

## Sweet message to the Queen left by grieving royal fan leaves social media users in tears
 - [https://www.dailymail.co.uk/femail/article-11206601/Sweet-message-Queen-left-grieving-royal-fan-leaves-social-media-users-tears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11206601/Sweet-message-Queen-left-grieving-royal-fan-leaves-social-media-users-tears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 20:59:05+00:00

At royal residences across the UK, thousands of people have left heartfelt tributes to Her Majesty after she died aged 96 at Balmoral on Thursday.

## Starbucks will spend $450m on 'Reinvention' plan that'll see Frappuccinos made 51 seconds faster
 - [https://www.dailymail.co.uk/news/article-11208905/Starbucks-spend-450m-Reinvention-plan-thatll-frappuccinos-51-seconds-faster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208905/Starbucks-spend-450m-Reinvention-plan-thatll-frappuccinos-51-seconds-faster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 20:53:39+00:00

Starbucks has introduced a 'Reinvention' plan that aims to open new stores and speed up current ones with new equipment that will decrease preparation time for some of their most popular drinks.

## Judge removes DA from case of dad whose daughter was raped by trans boy at school
 - [https://www.dailymail.co.uk/news/article-11208597/Judge-removes-DA-case-dad-daughter-raped-trans-boy-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208597/Judge-removes-DA-case-dad-daughter-raped-trans-boy-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 20:53:33+00:00

Scott Smith's daughter was attacked by the unnamed student at Stone Bridge High School in Ashburn, Virginia, in May of last year - spurring school officials deny the  girl had ever been raped.

## Furious Columbia University students blast school after it fell 16 places in world rankings
 - [https://www.dailymail.co.uk/news/article-11208353/Furious-Columbia-University-students-blast-school-fell-16-places-world-rankings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208353/Furious-Columbia-University-students-blast-school-fell-16-places-world-rankings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 20:51:59+00:00

Columbia University students blasted their school after it dropped a whopping 16 spots in the US News & World Report college rankings for incorrectly reporting data.

## Biden's victory lap stumbles as dow drops as president speaks
 - [https://www.dailymail.co.uk/news/article-11209097/Bidens-victory-lap-stumbles-dow-drops-president-speaks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209097/Bidens-victory-lap-stumbles-dow-drops-president-speaks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 20:51:45+00:00

President Biden's victory lap took a stumble on Tuesday as he celebrated its passage at the White House while the stock market had its biggest tumble in two years.

## Clinton prosecutor Ken Starr dies age 76 of complications from surgery in Houston hospital
 - [https://www.dailymail.co.uk/news/article-11209109/Clinton-prosecutor-Ken-Starr-dies-age-76-complications-surgery-Houston-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11209109/Clinton-prosecutor-Ken-Starr-dies-age-76-complications-surgery-Houston-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 20:51:45+00:00

Clinton investigator Kenneth Star died Tuesday at 76 after a lengthy illness.

## NYC subway mugger dies after jumping between cars and falling onto train tracks following a robbery
 - [https://www.dailymail.co.uk/news/article-11206789/NYC-subway-mugger-dies-jumping-cars-following-robbery-falling-train-tracks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206789/NYC-subway-mugger-dies-jumping-cars-following-robbery-falling-train-tracks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 20:45:26+00:00

A New York City thief was killed while jumping between train cars following a robbery in the Bronx on Tuesday morning. Thieves robbed a passenger when the escape plan went wrong.

## Senate GOP offers bill to stop audits of Americans making under $400K using IRS' $80B boost
 - [https://www.dailymail.co.uk/news/article-11208775/Senate-GOP-offers-bill-stop-audits-Americans-making-400K-using-IRS-80B-boost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208775/Senate-GOP-offers-bill-stop-audits-Americans-making-400K-using-IRS-80B-boost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 20:39:39+00:00

Senate Republicans introduced a bill this week that will ensure that the IRS can't audit Americans making under $400,000 a year using the boost of funds included in the Inflation Reduction Act.

## Argentine authorities beef up security for VP Cristina Fernández
 - [https://www.dailymail.co.uk/news/article-11208725/Argentine-authorities-beef-security-VP-Cristina-Fern-ndez.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208725/Argentine-authorities-beef-security-VP-Cristina-Fern-ndez.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 20:39:33+00:00

Argentina's Vice President Cristina Fernández received a death threat phone call Monday, 11 days after she was nearly assassinated in front of her home in Buenos Aires.

## Woke Defense Department diversity officer mocks 'white folx' and 'Karens' in newly uncovered tweets
 - [https://www.dailymail.co.uk/news/article-11208787/Woke-Defense-Department-diversity-officer-mocks-white-folx-Karens-newly-uncovered-tweets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208787/Woke-Defense-Department-diversity-officer-mocks-white-folx-Karens-newly-uncovered-tweets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 20:34:23+00:00

Before joining the Defense Department, Wing had been a teacher and served in the US Army. During her military service Wing rose to the level of Staff Sergeant, according to a biography on her website.

## Mom calls for bully to be expelled after he sent her son a swastika with the N-word on it 60 times
 - [https://www.dailymail.co.uk/news/article-11208645/Mom-calls-bully-expelled-sent-son-swastika-N-word-60-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208645/Mom-calls-bully-expelled-sent-son-swastika-N-word-60-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 20:03:14+00:00

Jana Veasey, a furious Colorado mother, wants her son's tormentor to be expelled after she says the bully AirDropped an image of a swastika written using the N-word typed out than 60 times

## Warner Bros. Discovery to lay off HUNDREDS of employees in latest round of cost cutting measures
 - [https://www.dailymail.co.uk/news/article-11208753/Warner-Bros-Discovery-lay-HUNDREDS-employees-latest-round-cost-cutting-measures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208753/Warner-Bros-Discovery-lay-HUNDREDS-employees-latest-round-cost-cutting-measures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 19:58:10+00:00

The layoffs are expected to be carried out Tuesday and center around the advertising sales teams of both WarnerMedia and Discovery.

## MEGHAN MCCAIN: No Oprah, Harry and Meghan's truce won't last
 - [https://www.dailymail.co.uk/news/article-11206747/MEGHAN-MCCAIN-No-Oprah-Harry-Meghans-truce-wont-last.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206747/MEGHAN-MCCAIN-No-Oprah-Harry-Meghans-truce-wont-last.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 19:57:34+00:00

MCCAIN: The spotlight will never be on Harry and Meghan the way it is on William and Kate and they have made it abundantly clear that is an unacceptable way for them to live.

## Minute's silence for the Queen is impeccably observed by Liverpool fans
 - [https://www.dailymail.co.uk/news/article-11208749/Minutes-silence-Queen-impeccably-observed-Liverpool-fans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208749/Minutes-silence-Queen-impeccably-observed-Liverpool-fans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 19:56:24+00:00

Liverpool made a request to UEFA for the tribute to be held following the late monarch's death at the age of 96, with their manager Jurgen Klopp insisting it was the right thing for the club to do.

## Prince Harry 'WILL' release his memoir after the Queen's death
 - [https://www.dailymail.co.uk/news/article-11206707/Prince-Harry-release-memoir-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206707/Prince-Harry-release-memoir-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 19:54:15+00:00

Tom Bower, whose biography of Meghan Markle was released earlier this year, claimed the Duke of Sussex was 'insisting' on the original date being honoured.

## Airline blasted for losing traveler's prosthetic limb for twelve days, ruining vacation
 - [https://www.dailymail.co.uk/news/article-11206773/Airline-blasted-losing-travelers-prosthetic-limb-twelve-days-ruining-vacation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206773/Airline-blasted-losing-travelers-prosthetic-limb-twelve-days-ruining-vacation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 19:51:57+00:00

Allegiant Airlines lost a bag containing a passenger's prosthetic leg for twelve days. The leg, which was supposed to arrive in Southern California, was mistakenly sent to Utah.

## Yuma, Arizona has seen nearly 250,000 migrants cross into city of 100,000 in past year
 - [https://www.dailymail.co.uk/news/article-11204401/Yuma-Arizona-seen-nearly-250-000-migrants-cross-city-100-000-past-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204401/Yuma-Arizona-seen-nearly-250-000-migrants-cross-city-100-000-past-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 19:49:13+00:00

Over the past 12 months, almost 250,000 people have flooded into Yuma, Arizona - a city of 100,000 - lured by gaps in the border fence and a Border Patrol sector stretched to the limit.

## Democratic senator is at loss for words when asked on live TV if Biden is doing a good job
 - [https://www.dailymail.co.uk/news/article-11206775/Democratic-senator-loss-words-asked-live-TV-Biden-doing-good-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206775/Democratic-senator-loss-words-asked-live-TV-Biden-doing-good-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 19:25:03+00:00

During his appearance on CBS5 News, Sen. Mark Kelly faced a barrage of questions about his thoughts on Biden. And it did not go well, despite the fairly obvious line of questioning.

## Royal Archer collapses as the Queen's coffin is carried out of St Giles Cathedral in Edinburgh
 - [https://www.dailymail.co.uk/news/article-11208599/Royal-Archer-collapses-Queens-coffin-carried-St-Giles-Cathedral-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11208599/Royal-Archer-collapses-Queens-coffin-carried-St-Giles-Cathedral-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 19:18:17+00:00

This is the moment when a Royal Archer collapses as the Queen's coffin was being carried out of St Giles' Cathedral in Edinburgh.

## The Queen lands back in London: Her Majesty's coffin begins journey to Buckingham Palace
 - [https://www.dailymail.co.uk/news/article-11206755/The-royal-family-say-goodbyes-beloved-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206755/The-royal-family-say-goodbyes-beloved-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 18:54:48+00:00

King Charles III and the Queen Consort, his feuding sons Princes William and Harry and their wives Kate Middleton and Meghan Markle will receive the late Queen at Buckingham Palace.

## Jimmy Kimmel accused of 'white privilege' after Emmys stunt during Quinta Brunson's victory speech
 - [https://www.dailymail.co.uk/news/article-11206467/Jimmy-Kimmel-accused-white-privilege-Emmys-stunt-Quinta-Brunsons-victory-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206467/Jimmy-Kimmel-accused-white-privilege-Emmys-stunt-Quinta-Brunsons-victory-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 18:52:19+00:00

Jimmy Kimmel has been accused of utilizing white privilege after refusing to leave the stage during Quinta Brunson's victory speech at the 2022 Emmys.

## PA Senate candidate John Fetterman failed to disclose owning eight properties
 - [https://www.dailymail.co.uk/news/article-11206847/PA-Senate-candidate-John-Fetterman-failed-disclose-owning-eight-properties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206847/PA-Senate-candidate-John-Fetterman-failed-disclose-owning-eight-properties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 18:52:02+00:00

A watchdog group is filing a complaint asking the Senate Ethics Committee to investigate why Pennsylvania Democrat John Fetterman allegedly failed to disclose eight real estate assets.

## Flight tracking website CRASHES as 6milllion try to follow progress of Queen's final flight
 - [https://www.dailymail.co.uk/news/article-11206919/Flight-tracking-website-CRASHES-6milllion-try-follow-progress-Queens-final-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206919/Flight-tracking-website-CRASHES-6milllion-try-follow-progress-Queens-final-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 18:36:04+00:00

Popular aircraft tracking service FlightRadar24 crashed under the weight of the six million people who attempted to log onto the service as the late Queen was brought to London from Scotland.

## The majority of floating voters DISAGREE with Biden's claim Trump represents a threat to democracy
 - [https://www.dailymail.co.uk/news/article-11206623/The-majority-floating-voters-DISAGREE-Bidens-claim-Trump-represents-threat-democracy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206623/The-majority-floating-voters-DISAGREE-Bidens-claim-Trump-represents-threat-democracy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 18:26:41+00:00

A majority of voters unaffiliated with one of the two majority parties are against President Joe Biden's statements claiming Trump voters are a 'threat to democracy.'

## Kanye West to exit Gap and Adidas at end of contracts, after waging very public battles
 - [https://www.dailymail.co.uk/news/article-11206543/Kanye-West-exit-Gap-Adidas-end-contracts-waging-public-battles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206543/Kanye-West-exit-Gap-Adidas-end-contracts-waging-public-battles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 18:26:35+00:00

Rapper Kanye West said  that he's done with corporate sponsorships and will not renew his current contracts with Gap and Adidas when they expire - jeopardizing billions in revenue

## Lindsey Graham confronted by woman who had abortion at 16 weeks during pro-life press conference
 - [https://www.dailymail.co.uk/news/article-11206749/Lindsey-Graham-abortion-15-weeks-protester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206749/Lindsey-Graham-abortion-15-weeks-protester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 18:26:24+00:00

Graham's abortion bill is Republicans' first piece of legislation concerning the procedure since the Supreme Court repealed the landmark 1973 decision in Roe v. Wade.

## Pet kangaroo beat Australian alpaca farmer, 77, to death in first fatal attack since 1936
 - [https://www.dailymail.co.uk/news/article-11206761/Pet-kangaroo-beat-Australian-alpaca-farmer-77-death-fatal-attack-1936.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206761/Pet-kangaroo-beat-Australian-alpaca-farmer-77-death-fatal-attack-1936.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 18:23:19+00:00

Peter Eades (pictured), 77, was found by a relative at his property in Redmond, near Albany in Western Australia, after suffering serious injuries at about 5pm (10am UK time) on Sunday.

## Venezuelan teenage migrant bid farewell to his dog at the United States-Mexico border
 - [https://www.dailymail.co.uk/news/article-11206315/Venezuelan-teenage-migrant-bid-farewell-dog-United-States-Mexico-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206315/Venezuelan-teenage-migrant-bid-farewell-dog-United-States-Mexico-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 18:07:27+00:00

Brayan Pinto experienced the heartbreaking moment of having to separate himself from his pet dog Brandy because he could not seek asylum with her at the United States-Mexico border Sunday.

## A final test for Trump: Voters head to the polls in last primaries of the season
 - [https://www.dailymail.co.uk/news/article-11206655/A-final-test-Trump-Voters-head-polls-primaries-season.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206655/A-final-test-Trump-Voters-head-polls-primaries-season.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 18:02:07+00:00

Voters take to the polls in three northeastern states Tuesday in the final primary of midterms season.

## Dow Jones slumps by 891 points as inflation remains stubbornly high at 8.3%
 - [https://www.dailymail.co.uk/news/article-11206631/Dow-Jones-slumps-891-points-inflation-remains-stubbornly-high-8-3.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206631/Dow-Jones-slumps-891-points-inflation-remains-stubbornly-high-8-3.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 17:51:47+00:00

Dow Jones Industrial Average is down 891 points or 2.71 per cent as of 12.30pm, to 31,486.89 as the latest inflation data sparked fears that the Fed will continue its aggressive path of rate hikes.

## New York's Strand Bookstore partners with Bottega Veneta to sell a $3,100 TOTE BAG
 - [https://www.dailymail.co.uk/news/article-11206555/New-Yorks-Strand-Bookstore-partners-Bottega-Veneta-sell-3-100-TOTE-BAG.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206555/New-Yorks-Strand-Bookstore-partners-Bottega-Veneta-sell-3-100-TOTE-BAG.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 17:45:40+00:00

NYC's famed Strand Book Store has collaborated with Italian designer Bottega Veneta to produce a range of highly-priced tote bags, including one that costs a whopping $3,100.

## Twitter shareholders vote in favor of Elon Musk's $44B takeover bid
 - [https://www.dailymail.co.uk/news/article-11206809/Twitter-shareholders-vote-favor-Elon-Musks-44B-takeover-bid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206809/Twitter-shareholders-vote-favor-Elon-Musks-44B-takeover-bid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 17:42:43+00:00

Twitter's shareholders have voted in favor of selling the company to Elon Musk for $44 billion, a deal that the billionaire is now scrambling to back out of.

## British football clubs are told they CAN'T play God Save The King before European matches
 - [https://www.dailymail.co.uk/news/article-11206689/British-football-clubs-told-play-God-Save-King-European-matches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206689/British-football-clubs-told-play-God-Save-King-European-matches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 17:41:33+00:00

A number of English and Scottish clubs are due to play in the European competitions over the coming days after Premier League fixtures were cancelled last weekend.

## King Charles III has an awkward moment when he is confronted with a leaking PEN
 - [https://www.dailymail.co.uk/news/article-11206531/King-Charles-III-awkward-moment-pen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206531/King-Charles-III-awkward-moment-pen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 17:40:25+00:00

This is the moment the King blasts a leaking pen that threatens to ruin his mood just hours after the new monarch was warmly embraced by the people of Northern Ireland during his inaugural trip as monarch.

## Emmy viewers are furious awards ceremony omitted monarch from its 'In Memoriam' section
 - [https://www.dailymail.co.uk/news/article-11206429/Emmy-viewers-furious-awards-ceremony-omitted-monarch-Memoriam-section.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206429/Emmy-viewers-furious-awards-ceremony-omitted-monarch-Memoriam-section.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 17:38:45+00:00

Some Emmy viewers are outraged after Queen Elizabeth II was excluded from the 'In Memoriam' tribute section on Monday. Spectators called out the 74th award ceremony for not including the Monarch.

## Olivia Pratt-Korbel's classmates receive counselling after returning to school after the shooting
 - [https://www.dailymail.co.uk/news/article-11206719/Olivia-Pratt-Korbels-classmates-receive-counselling-returning-school-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206719/Olivia-Pratt-Korbels-classmates-receive-counselling-returning-school-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 17:37:03+00:00

St Margaret Mary's Catholic Junior School in Huyton, where Olivia attended, said that the school's 480 pupils have all been offered counselling on their return to the classroom.

## Archives staff warned Congress it is 'not certain' Trump has returned all the records he removed
 - [https://www.dailymail.co.uk/news/article-11206567/Archives-staff-warned-Congress-not-certain-Trump-returned-records-removed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206567/Archives-staff-warned-Congress-not-certain-Trump-returned-records-removed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 17:21:16+00:00

Staff for the National Archives recently informed the House Oversight Committee that it is 'not certain' whether Donald Trump surrendered every record, even after the Mar-a-Lago raid.

## Democrats are slightly beating Republicans in poll on November election
 - [https://www.dailymail.co.uk/news/article-11206627/Democrats-slightly-beating-Republicans-poll-November-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206627/Democrats-slightly-beating-Republicans-poll-November-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 17:18:40+00:00

Democrats continue to show gains in polls on the upcoming congressional election as President Joe Biden's approval rating shows marginal improvements.

## Celebrity magazine publisher Jason Binn, 54, is cleared of groping a teen relative
 - [https://www.dailymail.co.uk/news/article-11206553/Celebrity-magazine-publisher-Jason-Binn-54-cleared-groping-teen-relative.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206553/Celebrity-magazine-publisher-Jason-Binn-54-cleared-groping-teen-relative.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 17:17:23+00:00

The New York District Attorney's office dropped the charges against Jason Binn, 54, that he'd groped a 16-year-old female relative last winter.

## Dubai ruler should not be invited to Queen's funeral says his daughter Princess Latifa's best friend
 - [https://www.dailymail.co.uk/news/article-11206577/Dubai-ruler-not-invited-Queens-funeral-says-daughter-Princess-Latifas-best-friend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206577/Dubai-ruler-not-invited-Queens-funeral-says-daughter-Princess-Latifas-best-friend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 17:09:03+00:00

Princess Latifa (left) was allegedly abducted by her father Sheikh Maktoum, a close horse-racing friend of Her Majesty's, when she tried to escape Dubai in 2018 with best friend Tiina Jauhiainen (right).

## Prince Harry will wear a morning suit at vigils for The Queen
 - [https://www.dailymail.co.uk/news/article-11206505/Prince-Harry-wear-morning-suit-vigils-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206505/Prince-Harry-wear-morning-suit-vigils-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:56:02+00:00

Harry has been denied the chance to wear military uniform at official events, even though his disgraced uncle the Duke of York will be permitted to do so at the lying in state vigil.

## Well-paid millennials left New York and California in their THOUSANDS in early pandemic
 - [https://www.dailymail.co.uk/news/article-11206277/Well-paid-millennials-left-New-York-California-THOUSANDS-early-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206277/Well-paid-millennials-left-New-York-California-THOUSANDS-early-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:53:02+00:00

Many under-35s earning at least $100,000 per year appear to have opted for sunnier southern climes like Texas and Florida as the pandemic ravaged dense cities and forced offices to close.

## Chris Kaba's family say they weren't told he had been killed for 11 hours
 - [https://www.dailymail.co.uk/news/article-11206563/Chris-Kabas-family-say-werent-told-killed-11-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206563/Chris-Kabas-family-say-werent-told-killed-11-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:51:04+00:00

Cousin Jefferson Bosela said that Chris Kaba's mother would have gone to work not knowing he was not alive anymore after he was killed in the south London shooting.

## Ex police officer Matthew Littlefair sells his house to repay £100k in fraud wages
 - [https://www.dailymail.co.uk/news/article-11206283/Ex-police-officer-Matthew-Littlefair-sells-house-repay-100k-fraud-wages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206283/Ex-police-officer-Matthew-Littlefair-sells-house-repay-100k-fraud-wages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:48:00+00:00

Matthew Littlefair, 37, was jailed for two years and three months in November 2021 for fraud. The former Dorset police officer claimed he unable to work because of the pain he was suffering.

## Twitter whistleblower claims he was told social media giant had been infiltrated by a CHINESE SPY
 - [https://www.dailymail.co.uk/news/article-11206495/Twitter-whistleblower-claims-told-social-media-giant-infiltrated-CHINESE-SPY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206495/Twitter-whistleblower-claims-told-social-media-giant-infiltrated-CHINESE-SPY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:46:55+00:00

A former security officer at Twitter told senators on Tuesday that he learned a Chinese intelligence agent was on the social media company's payroll a week before he was dismissed.

## King Charles III has an awkward moment when he is confronted with a leaking PEN
 - [https://www.dailymail.co.uk/news/article-11206531/King-Charles-III-awkward-moment-confronted-leaking-PEN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206531/King-Charles-III-awkward-moment-confronted-leaking-PEN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:46:31+00:00

This is the moment the King blasts a leaking pen that threatens to ruin his mood just hours after the new monarch was warmly embraced by the people of Northern Ireland during his inaugural trip as monarch.

## Mother claims her children paddled through SEWAGE at Lincolnshire beach
 - [https://www.dailymail.co.uk/news/article-11206447/Mother-claims-children-paddled-SEWAGE-Lincolnshire-beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206447/Mother-claims-children-paddled-SEWAGE-Lincolnshire-beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:45:31+00:00

Emma Oldham, 33, claimed she and her three children encountered sewage the beach in Huttoft, East Lindsey, Lincolnshire. Above: The mother's video allegedly showing sewage.

## Hard Rock reveals $100M plan to raise half its workers salaries by up to 60%
 - [https://www.dailymail.co.uk/news/article-11206503/Hard-Rock-reveals-100M-plan-raise-half-workers-salaries-60.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206503/Hard-Rock-reveals-100M-plan-raise-half-workers-salaries-60.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:41:45+00:00

Hard Rock International has announced that it is spending over $100 million to give significant raises to 10,000 non-tipped workers, most of them in the US, in a bid to retain workers.

## Showpo CEO Jane Lu reveals culture at Big Four firms like EY after Aishwarya Venkatachalam death
 - [https://www.dailymail.co.uk/news/article-11187211/Showpo-CEO-Jane-Lu-reveals-culture-Big-Four-firms-like-EY-Aishwarya-Venkatachalam-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11187211/Showpo-CEO-Jane-Lu-reveals-culture-Big-Four-firms-like-EY-Aishwarya-Venkatachalam-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:40:10+00:00

The millionaire founder of fashion empire Showpo has lifted the lid on why she quit her hated job at consulting giant EY. Jane Lu, 36, built the company after leaving the accounting job.

## New York prosecutor Geoffrey Berman says the Palace protected Prince Andrew
 - [https://www.dailymail.co.uk/news/article-11206183/New-York-prosecutor-Geoffrey-Berman-says-Palace-protected-Prince-Andrew.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206183/New-York-prosecutor-Geoffrey-Berman-says-Palace-protected-Prince-Andrew.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:35:05+00:00

Geoffrey Berman writes in new memoir Holding the Line that he got 'absolutely nowhere' with his efforts to bring Andrew to justice over his links to pedophile Epstein.

## Poet Laureate Simon Armitage reads his emotional tribute to Her Majesty in a heart-breaking video
 - [https://www.dailymail.co.uk/news/article-11206421/Poet-Laureate-Simon-Armitage-reads-emotional-tribute-Majesty-heart-breaking-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206421/Poet-Laureate-Simon-Armitage-reads-emotional-tribute-Majesty-heart-breaking-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:34:57+00:00

The Royal Family has published a heart-breaking video of Poet Laurette Simon Armitage solemnly reading out his poem for the late Queen, Floral Tribute.

## Two-year freeze on energy bills will benefit richer families more than poorer ones, says think tank
 - [https://www.dailymail.co.uk/news/article-11206525/Two-year-freeze-energy-bills-benefit-richer-families-poorer-ones-says-think-tank.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206525/Two-year-freeze-energy-bills-benefit-richer-families-poorer-ones-says-think-tank.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:24:41+00:00

In a new report, the Resolution Foundation found the richest fifth of households may gain an average of about £1,300 this winter, compared with £1,100 for the poorest 20 per cent.

## Senate Judiciary to probe former US Attorney's claims of political interference
 - [https://www.dailymail.co.uk/news/article-11206383/Senate-Judiciary-probe-former-Attorneys-claims-political-interference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206383/Senate-Judiciary-probe-former-Attorneys-claims-political-interference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:23:12+00:00

The Senate Judiciary Committee will probe former US Attorney Geoffrey Berman's claims of 'political interference' by the Trump Justice Department, Sen. Richard Durbin said.

## Carindale Goodlife gym Comanchero bikie stabbing victim Levi Johnson mourned by Brisbane family
 - [https://www.dailymail.co.uk/news/article-11205893/Carindale-Goodlife-gym-Comanchero-bikie-stabbing-victim-Levi-Johnson-mourned-Brisbane-family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205893/Carindale-Goodlife-gym-Comanchero-bikie-stabbing-victim-Levi-Johnson-mourned-Brisbane-family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 16:17:00+00:00

Comancheros associate Levi Maurice Johnson, 23, was stabbed to death in an ambush outside a Goodlife gym in Carindale, Brisbane, and his family including boxing champ sister gathered to mourn.

## Defiant Carnegie Mellon professor claims her job is NOT in jeopardy for sick posts on Queen's death
 - [https://www.dailymail.co.uk/news/article-11206235/Defiant-Carnegie-Mellon-professor-claims-job-NOT-jeopardy-sick-posts-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206235/Defiant-Carnegie-Mellon-professor-claims-job-NOT-jeopardy-sick-posts-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:59:38+00:00

The Carnegie Mellon professor who wished the late Queen an 'excruciatingly painful' death, said her job is safe despite her outrageous sentiments.

## Putin's soldiers 'categorically refusing to deploy to front lines due to distrust of high command'
 - [https://www.dailymail.co.uk/news/article-11206469/Putins-soldiers-categorically-refusing-deploy-lines-distrust-high-command.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206469/Putins-soldiers-categorically-refusing-deploy-lines-distrust-high-command.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:58:10+00:00

The General Staff of the Armed Forces of Ukraine said that 'distrust of the higher command' and fears about the huge death toll are putting off troops from fighting.

## Son, 62, is CLEARED of fleecing his 89-year-old mother out of £270,000
 - [https://www.dailymail.co.uk/news/article-11206363/Son-62-CLEARED-fleecing-89-year-old-mother-270-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206363/Son-62-CLEARED-fleecing-89-year-old-mother-270-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:52:49+00:00

Jonathan Feld, 62, was accused by his sister Louise Radley of helping himself to 89-year-old Hannah Feld's life savings after she became too ill to look after her financial affairs.

## Ain't that a kick in the head!
 - [https://www.dailymail.co.uk/news/article-11206433/Aint-kick-head.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206433/Aint-kick-head.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:52:22+00:00

Pope Francis appears to be getting kicked in his face on his arrival in Kazakhstan.

## 'Tombstoning teenager' dies in hospital after jumping off Brighton Pier into three feet of water
 - [https://www.dailymail.co.uk/news/article-11206215/Tombstoning-teenager-dies-hospital-jumping-Brighton-Pier-three-feet-water.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206215/Tombstoning-teenager-dies-hospital-jumping-Brighton-Pier-three-feet-water.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:52:02+00:00

A young man believed to be in his teens who was critically injured after allegedly 'tombstoning'  into the sea by diving off Brighton Pier on Sunday, August 28, has lost his fight for life in hospital.

## The Queen: Australian artist Ralph Heimans recalls painting the Diamond Jubilee portrait
 - [https://www.dailymail.co.uk/news/article-11206019/The-Queen-Australian-artist-Ralph-Heimans-recalls-painting-Diamond-Jubilee-portrait.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206019/The-Queen-Australian-artist-Ralph-Heimans-recalls-painting-Diamond-Jubilee-portrait.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:51:22+00:00

Ralph Heimans, from Sydney who now lives in South London with his wife and daughters, was allowed a one-hour sitting with the Queen at Buckingham Palace to paint her portrait in 2012.

## Queen's final journey from her beloved Scotland
 - [https://www.dailymail.co.uk/news/article-11206457/Queens-final-journey-beloved-Scotland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206457/Queens-final-journey-beloved-Scotland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:51:17+00:00

The Queen is leaving Scotland for the last time as her coffin is flown from Edinburgh to London then transported to Buckingham Palace by hearse.

## Shocking video shows white van driver fleeing in a panic after 'fly-tipping' in a country lane
 - [https://www.dailymail.co.uk/news/article-11206039/Shocking-video-shows-white-van-driver-fleeing-panic-fly-tipping-country-lane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206039/Shocking-video-shows-white-van-driver-fleeing-panic-fly-tipping-country-lane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:49:34+00:00

The panicked van driver was caught red handed by farmer Edward Goadby, 23, who filmed the man dumping rubbish on the outskirts of Nuneaton on Monday evening.

## Kangaroo attacks and kills man in Redmond, Western Australia: Peter Eades
 - [https://www.dailymail.co.uk/news/article-11206255/Kangaroo-attacks-kills-man-Redmond-Western-Australia-Peter-Eades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206255/Kangaroo-attacks-kills-man-Redmond-Western-Australia-Peter-Eades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:41:13+00:00

An elderly man who was savagely killed by his pet kangaroo in the first deadly attack in 86 years, was a respected and loving alpaca farmer.

## Female PC battered Dalian Atkinson with a baton while her cop lover kicked him to death, court hears
 - [https://www.dailymail.co.uk/news/article-11206259/Female-PC-battered-Dalian-Atkinson-baton-cop-lover-kicked-death-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206259/Female-PC-battered-Dalian-Atkinson-baton-cop-lover-kicked-death-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:40:23+00:00

The former Aston Villa striker Mr Atkinson died after being tasered and kicked in the head by PC Benjamin Monk outside his dad's home in Telford, Shropshire in 2016.

## Ex-Disney CEO Bob Iger will join Jared Kushner's brother's venture-capital firm
 - [https://www.dailymail.co.uk/news/article-11206269/Ex-Disney-CEO-Bob-Iger-join-Jared-Kushners-brothers-venture-capital-firm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206269/Ex-Disney-CEO-Bob-Iger-join-Jared-Kushners-brothers-venture-capital-firm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:38:38+00:00

Former Disney CEO Bob Iger will be joining investment firm Thrive Capital to mentor start-up founders as his old firm flounders following multiple woke gaffes.

## Las Vegas Democrat official SMIRKS while being arraigned for murder of journalist
 - [https://www.dailymail.co.uk/news/article-11206417/Las-Vegas-Democrat-official-SMIRKS-arraigned-murder-journalist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206417/Las-Vegas-Democrat-official-SMIRKS-arraigned-murder-journalist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:38:04+00:00

A smirking Democratic official has appeared in court charged with the murder of a Las Vegas journalist who exposed his affair in a series of articles.

## 'Quiet quitters' make up more than HALF the US workforce as Gen Z staff do bare minimum
 - [https://www.dailymail.co.uk/news/article-11206125/Quiet-quitters-make-HALF-workforce-Gen-Z-staff-bare-minimum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206125/Quiet-quitters-make-HALF-workforce-Gen-Z-staff-bare-minimum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:36:40+00:00

Gallup poll numbers show only 32 percent of workers are 'actively engaged' in their work, and 18 percent are 'actively disengaged' and looking for new jobs.

## Q Fever: Australians warned to get vaccinated for disease: Wide Bay Queensland
 - [https://www.dailymail.co.uk/news/article-11206261/Q-Fever-Australians-warned-vaccinated-disease-Wide-Bay-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206261/Q-Fever-Australians-warned-vaccinated-disease-Wide-Bay-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:23:23+00:00

Queensland Health has told residents in the electoral division of Wide Bay - which includes Noosa, Maryborough and Gympie - that they should get vaccinated against Q fever.

## Pennsylvania man in a rainbow wig arrested after bringing loaded handgun into Dairy Queen
 - [https://www.dailymail.co.uk/news/article-11206085/Pennsylvania-man-rainbow-wig-arrested-bringing-loaded-handgun-Dairy-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206085/Pennsylvania-man-rainbow-wig-arrested-bringing-loaded-handgun-Dairy-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:19:11+00:00

Jan Stawovy, 61, was arrested Saturday for walking into a Pennsylvania Dairy Queen with a loaded handgun, dressed in a clown wig, and told police he wanted to 'kill Democrats.'

## Kevin McCarthy warns 'real wages are falling' as Biden celebrates 'progress' of 8.3% inflation rate
 - [https://www.dailymail.co.uk/news/article-11206305/Kevin-McCarthy-Biden-inflation-rate-August.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206305/Kevin-McCarthy-Biden-inflation-rate-August.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:15:02+00:00

'The cost of living is up 8.3 percent over last year, rose further this month despite Democrats' victory lap in July, and is up nearly 13 percent since January 2021.

## Substitute PE teacher is arrested 'after she offered schoolchildren $5 each to BULLY a classmate
 - [https://www.dailymail.co.uk/news/article-11206213/Substitute-PE-teacher-arrested-offered-schoolchildren-5-BULLY-classmate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206213/Substitute-PE-teacher-arrested-offered-schoolchildren-5-BULLY-classmate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:14:52+00:00

Aadrina Salean Smith, 24, was arrested on Monday after allegedly paying five different students $5 each to bully another student during PE on August 23. Smith was a substitute at a Louisiana school.

## The last-minute dash to say goodbye to Her Majesty
 - [https://www.dailymail.co.uk/news/article-11206435/The-minute-dash-say-goodbye-Majesty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206435/The-minute-dash-say-goodbye-Majesty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 15:08:53+00:00

Mourners made a last-minute dash to pay their final respects to the Queen in Edinburgh before her coffin is flown to London today - after thousands of well-wishers said farewell to the monarch.

## Trump was pictured at his DC course WITHOUT clubs - as speculation mounts he was meeting lawyers
 - [https://www.dailymail.co.uk/news/article-11206165/Trump-pictured-DC-course-WITHOUT-clubs-speculation-mounts-meeting-lawyers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206165/Trump-pictured-DC-course-WITHOUT-clubs-speculation-mounts-meeting-lawyers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:55:03+00:00

Speculation is stirring that Donald Trump was in D.C. this week to meet with lawyers about a potential indictment after images emerged of him on his Virginia golf course without clubs.

## Manchester City star Benjamin Mendy is cleared of one count of rape
 - [https://www.dailymail.co.uk/news/article-11206145/Manchester-City-star-Benjamin-Mendy-cleared-one-count-rape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206145/Manchester-City-star-Benjamin-Mendy-cleared-one-count-rape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:53:58+00:00

Man City star Benjamin Mendy was this afternoon cleared of one count of rape and his alleged fixer of three other sex charges after a tape of one of the encounters was revealed in court.

## Teenage boy, 16, was found dead after being 'groomed' by county lines gang
 - [https://www.dailymail.co.uk/news/article-11206211/Teenage-boy-16-dead-groomed-county-lines-gang.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206211/Teenage-boy-16-dead-groomed-county-lines-gang.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:53:23+00:00

Ben Nelson-Roux, from Harrogate, was forced to deal Class A drugs, including crack cocaine, in cities including York and Sheffield, the hearing heard.

## Heinz Ketchup will have to change iconic sauce bottles following the Queen's death
 - [https://www.dailymail.co.uk/news/article-11206185/Heinz-Ketchup-change-iconic-sauce-bottles-following-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206185/Heinz-Ketchup-change-iconic-sauce-bottles-following-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:52:33+00:00

The distinctive image depicts the lion of England, unicorn of Scotland and a shield divided into four quarters, along with the words 'by appointment to Her Majesty the Queen'.

## Professional bull rider killed by his domestic abuser girlfriend while attending Utah State Fair
 - [https://www.dailymail.co.uk/news/article-11206091/Professional-bull-rider-killed-domestic-abuser-girlfriend-attending-Utah-State-Fair.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206091/Professional-bull-rider-killed-domestic-abuser-girlfriend-attending-Utah-State-Fair.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:51:38+00:00

A professional bull rider was shot dead by his on-and-off girlfriend after the pair attended the Utah State Fair on Monday.

## McDonald's customer finds mouse poo in meal: Perth, WA
 - [https://www.dailymail.co.uk/news/article-11205719/McDonalds-customer-finds-mouse-poo-meal-Perth-WA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205719/McDonalds-customer-finds-mouse-poo-meal-Perth-WA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:50:42+00:00

Hannah Whittome, 19, from Perth, said she made the disgusting discovery after buying a meal from a drive-thru with her boyfriend.

## Massachusetts town livid after giant donut chain closes shop and creating a 'Dunkin desert'
 - [https://www.dailymail.co.uk/news/article-11206065/Massachusetts-town-livid-giant-donut-chain-closes-shop-creating-Dunkin-desert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206065/Massachusetts-town-livid-giant-donut-chain-closes-shop-creating-Dunkin-desert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:50:21+00:00

The coffee-loving residents of Stow, Massachusetts got a different kind of jolt recently when both of the town's beloved Dunkin Donuts shut down. 'It sucks,' one resident said. 'There's nothing fun to do.'

## John Bolton warns Putin is 'a lot closer' to using NUKES after rapid Ukrainian advances
 - [https://www.dailymail.co.uk/news/article-11206231/John-Bolton-warns-Putin-lot-closer-using-NUKES-rapid-Ukrainian-advances.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206231/John-Bolton-warns-Putin-lot-closer-using-NUKES-rapid-Ukrainian-advances.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:50:18+00:00

Former U.S. Ambassador to the United Nations John Bolton warned Monday that a battered and bloodied Vladimir Putin could use nuclear weapons in a desperate effort to cling on to power.

## Female patient, 50, who 'bombarded cancer doctor with gifts' fails to get stalking order thrown out
 - [https://www.dailymail.co.uk/news/article-11206111/Female-patient-50-bombarded-cancer-doctor-gifts-fails-stalking-order-thrown-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206111/Female-patient-50-bombarded-cancer-doctor-gifts-fails-stalking-order-thrown-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:45:41+00:00

Lisa Addison, 50, is said to have bombarded Dr Myles Smith (pictured) with gifts and emails between April 2020 and March 2022 after an operation at the Royal Marsden hospital in London.

## Australian High Commission concerned over Ben Roberts-Smith's invite to Queen's funeral
 - [https://www.dailymail.co.uk/news/article-11206187/Australian-High-Commission-concerned-Ben-Roberts-Smiths-invite-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206187/Australian-High-Commission-concerned-Ben-Roberts-Smiths-invite-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:40:56+00:00

Ben Roberts-Smith's invite to the Queen's funeral has left Australia's High Commission in London deeply concerned, with officials revealing they had expected him to refuse the invitation.

## Kim Kardashian-esque French policewoman goes viral
 - [https://www.dailymail.co.uk/news/article-11206341/Kim-Kardashian-esque-French-policewoman-goes-viral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206341/Kim-Kardashian-esque-French-policewoman-goes-viral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:38:18+00:00

A father-and-son dentist duo have been jailed in France - but all eyes were on the policewoman escorting the pair into court after people noticed her Kardashian-esque posterior.

## Russian war correspondent accidentally reveals catastrophic losses in Ukraine on state TV
 - [https://www.dailymail.co.uk/news/article-11206191/Russian-war-correspondent-accidentally-reveals-catastrophic-losses-Ukraine-state-TV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206191/Russian-war-correspondent-accidentally-reveals-catastrophic-losses-Ukraine-state-TV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:37:18+00:00

Alexander Sladkov was speaking to Kremlin-run Rossiya 1 news channel from the Donbas where he let slip how effective Ukraine's counter-offensive has been.

## Biden to attack Republicans who voted against Inflation Reduction Act
 - [https://www.dailymail.co.uk/news/article-11206209/Biden-attack-Republicans-voted-against-Inflation-Reduction-Act.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206209/Biden-attack-Republicans-voted-against-Inflation-Reduction-Act.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:36:29+00:00

President Joe Biden will celebrate his climate change and prescription drug prices law with an event designed to bolster Democrats' work to ease cost of living for Americans.

## Teenage 'rape victim' is rescued from kidnap ordeal after using a tracking app to reveal location
 - [https://www.dailymail.co.uk/news/article-11206131/Teenage-rape-victim-rescued-kidnap-ordeal-using-tracking-app-reveal-location.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206131/Teenage-rape-victim-rescued-kidnap-ordeal-using-tracking-app-reveal-location.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:36:03+00:00

Dalton Ramsey, 28, allegedly raped the 17-year-old girl at knifepoint after he convinced the teenager to meet him by offering to drive her to Pennsylvania to meet her boyfriend, police said.

## Experts divided over whether Trump can use his $115m war chest to fund presidential run
 - [https://www.dailymail.co.uk/news/article-11206105/Experts-divided-Trump-use-115m-war-chest-fund-presidential-run.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206105/Experts-divided-Trump-use-115m-war-chest-fund-presidential-run.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 14:23:22+00:00

Former President Trump has about $100 million in his Save America PAC that he can use to fund rallies and other activities - but the law prevents him from simply transferring it to a campaign.

## 'It's what she would have wanted': Twitter jokes at odd raft of closures as UK mourns Queen
 - [https://www.dailymail.co.uk/news/article-11205887/Britons-left-scratching-heads-closures-cancellations-respect-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205887/Britons-left-scratching-heads-closures-cancellations-respect-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 13:57:18+00:00

From bike rack closures, turning down supermarket checkout bleeps to stopping the clocks, these are some of the more 'obscure' ways people are commemorating Queen Elizabeth II's death

## Ukrainian family of nine evicted because they were 'not what we were expecting'
 - [https://www.dailymail.co.uk/news/article-11206237/Ukrainian-family-nine-evicted-not-expecting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206237/Ukrainian-family-nine-evicted-not-expecting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 13:54:19+00:00

Their case took a significant twist after it was later reported by MailOnline that Mr Hyryk is a former police officer who had enjoyed a lavish lifestyle running a lucrative buy-to-let business in Kyiv.

## Giselle breaks silence on husband Tom Brady's NFL U-turn amid rumors of a marital split over it
 - [https://www.dailymail.co.uk/news/article-11206127/Giselle-breaks-silence-husband-Tom-Bradys-NFL-U-turn-amid-rumors-marital-split-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206127/Giselle-breaks-silence-husband-Tom-Bradys-NFL-U-turn-amid-rumors-marital-split-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 13:53:35+00:00

Gisele Bündchen has finally broken her silence on her husband Tom Brady's U-turn decision to return to NFL after initially retiring from the sport at the end of last season.

## Expert claims Queen will just be buried with gold wedding band and pair of pearl earrings
 - [https://www.dailymail.co.uk/news/article-11206061/Expert-claims-Queen-just-buried-gold-wedding-band-pair-pearl-earrings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206061/Expert-claims-Queen-just-buried-gold-wedding-band-pair-pearl-earrings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 13:53:00+00:00

Lisa Levinson, head of communications at the Natural Diamond Council, said it is 'unlikely' that the 'humble' Queen is buried with anything other than her 'Welsh gold wedding band' and 'pearl earrings'.

## US braces for national railroad strike costing up to $2b-a-day and threaten supply chain chaos
 - [https://www.dailymail.co.uk/news/article-11206075/US-braces-national-railroad-strike-costing-2b-day-threaten-supply-chain-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206075/US-braces-national-railroad-strike-costing-2b-day-threaten-supply-chain-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 13:52:24+00:00

Starting Tuesday, the passenger rail agency is suspending service on three cross-country routes out of Chicago, going to San Francisco, the Pacific Northwest, and Los Angeles, Amtrak said.

## Grandmother, 46, jumped on her son's ex-lover's car after she was denied access to her grandchildren
 - [https://www.dailymail.co.uk/news/article-11205977/Grandmother-46-jumped-sons-ex-lovers-car-denied-access-grandchildren.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205977/Grandmother-46-jumped-sons-ex-lovers-car-denied-access-grandchildren.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 13:50:01+00:00

Hairdresser Sorelle Owens (pictured), 46, from north Wales, took revenge by jumping on the car bonnet owned by Bonnie Owens, the mother of her three grandchildren.

## Archie Battersbee funeral: Family and friends lay 12-year-old to rest
 - [https://www.dailymail.co.uk/news/article-11205905/Archie-Battersbee-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205905/Archie-Battersbee-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 13:39:14+00:00

Archie's funeral is taking place at St Mary's Church in Prittlewell, Southend, with the Reverend Paul Mackay overseeing a service featuring music and poetry.

## B-52 bomber roaming skies over Gloucestershire after emergency 'squawk' code
 - [https://www.dailymail.co.uk/news/article-11206153/B52-bomber-roaming-skies-Gloucestershire-emergency-squawk-code.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206153/B52-bomber-roaming-skies-Gloucestershire-emergency-squawk-code.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 13:37:39+00:00

The US Air Force jet, coded SPICY22, took off from RAF Fairford in Gloucestershire today before it began to circle in a constant loop after issuing an emergency Squawk 7700 code.

## Seven neglected Labrador puppies are 'dumped like rubbish' at roadside
 - [https://www.dailymail.co.uk/news/article-11205857/Seven-neglected-Labrador-puppies-dumped-like-rubbish-roadside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205857/Seven-neglected-Labrador-puppies-dumped-like-rubbish-roadside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 13:36:11+00:00

Seven golden Labrador puppies were found starving and abandoned in a crate by a roadside in Swale, Kent, with unclipped claws and covered in mange.

## Female shopper, 21, 'threw an umbrella at woman' and broke own her fingers
 - [https://www.dailymail.co.uk/news/article-11206163/Female-shopper-21-threw-umbrella-woman-broke-fingers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206163/Female-shopper-21-threw-umbrella-woman-broke-fingers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 13:25:01+00:00

Abigail Cameron (above), 21, allegedly called Sammy Capone a 'miserable b**ch' throwing an umbrella in her face, breaking her own fingers, at the world famous store in Knightsbridge last year.

## Tony Blair reveals how the Queen gently put him in his place when they first met
 - [https://www.dailymail.co.uk/news/article-11206155/Tony-Blair-reveals-Queen-gently-place-met.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206155/Tony-Blair-reveals-Queen-gently-place-met.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 13:08:15+00:00

Mr Blair, who was in Downing Street for a decade from 1997, spoke to US television about the monarch, including his 'surprise' at her death.

## Car bomb blows up Washington funeral-goers vehicle during service as it rips trees from their roots
 - [https://www.dailymail.co.uk/news/article-11206007/Car-bomb-blows-Washington-funeral-goers-vehicle-service-rips-trees-roots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206007/Car-bomb-blows-Washington-funeral-goers-vehicle-service-rips-trees-roots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 12:54:57+00:00

No one was injured in the explosion at Mountain View Cemetery on August 23, but officers are appealing for information on the suspect.

## Brits decorate their homes in tribute to the Queen with fan covering house in 150 Union Jack flags
 - [https://www.dailymail.co.uk/news/article-11205915/Brits-decorate-homes-tribute-Queen-fan-covering-house-150-Union-Jack-flags.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205915/Brits-decorate-homes-tribute-Queen-fan-covering-house-150-Union-Jack-flags.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 12:51:47+00:00

Paul Bibby, 57, has covered his home in Chelmsford, Essex, with 150 Union Jack flags. Meanwhile the Tate family have painted their home in Richmond-upon-Thames in black, grey and white.

## Startup firm FIRES six employees for 'harassment'
 - [https://www.dailymail.co.uk/news/article-11205955/Startup-firm-FIRES-six-employees-harassment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205955/Startup-firm-FIRES-six-employees-harassment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 12:49:31+00:00

Checkout.com - which was valued at £34billion at the start of the year - began an investigation in May within 24 hours of concerns being raised about staff behaviour.

## Inflation falls to 8.3% - the second drop in a row - but still sits near 40-year high
 - [https://www.dailymail.co.uk/news/article-11206073/Inflation-falls-8-3-second-drop-row-sits-near-40-year-high.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206073/Inflation-falls-8-3-second-drop-row-sits-near-40-year-high.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 12:46:56+00:00

The latest consumer price index report on Tuesday represented a drop from a four-decade high of 9.1 percent in June and 8.5 percent in July -- but showed that inflation is still running hot.

## First Lady claims she has NOT spoken to Biden about him running for a second term
 - [https://www.dailymail.co.uk/news/article-11206133/First-Lady-claims-NOT-spoken-Biden-running-second-term.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206133/First-Lady-claims-NOT-spoken-Biden-running-second-term.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 12:44:49+00:00

Speaking with NBC's Today Show, the first lady admitted that being on the campaign trail is 'taxing.' Asked if they'd talked about doing it again in 2024, Biden answered: 'Not yet.'

## Rudy Giuliani admitted he 'got nothing' in his efforts to dig up dirt on Biden, new book reveals
 - [https://www.dailymail.co.uk/news/article-11204675/Rudy-Giuliani-admitted-got-efforts-dig-dirt-Biden-new-book-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204675/Rudy-Giuliani-admitted-got-efforts-dig-dirt-Biden-new-book-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 12:39:34+00:00

Rudy Giuliani made the confession in a text to Lev Parnas, a Ukrainian associate now jailed for breaking campaign finance  laws, according to Giuliani: The Rise and Tragic Fall of America's Mayor.

## Chris Kaba's family demand video of his final moments following suspension of firearms officer
 - [https://www.dailymail.co.uk/news/article-11206067/Chris-Kabas-family-demand-video-final-moments-following-suspension-firearms-officer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206067/Chris-Kabas-family-demand-video-final-moments-following-suspension-firearms-officer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 12:37:22+00:00

Chris Kaba's family have called for the video footage of his final moments to be shown to them after the Metropolitan Police announced that the firearms officer had been suspended.

## Lindsey Graham introduces bill banning abortion after 15 weeks
 - [https://www.dailymail.co.uk/news/article-11206003/Lindsey-Graham-introduces-bill-banning-abortion-15-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206003/Lindsey-Graham-introduces-bill-banning-abortion-15-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 12:33:06+00:00

The U.S. is seeing its first nation-wide abortion restriction proposal following the overturn of Roe v. Wade as Senator Lindsey Graham seeks to ban terminating a pregnancy after 15 weeks.

## Sydney father Danny Abdallah invited to Queen's funeral...Oatlands tragedy
 - [https://www.dailymail.co.uk/news/article-11205841/Sydney-father-Danny-Abdallah-invited-Queens-funeral-Oatlands-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205841/Sydney-father-Danny-Abdallah-invited-Queens-funeral-Oatlands-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:55:54+00:00

Danny Abdallah and his wife Leila lost three of their four children and their niece when a drunk driver hit them with his car on February 1, 2020 at Oatlands in Sydney's northwest.

## RAF boss denies discrimination took place amid claim women and minorities were favoured over men
 - [https://www.dailymail.co.uk/news/article-11205883/RAF-boss-denies-discrimination-took-place-amid-claim-women-minorities-favoured-men.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205883/RAF-boss-denies-discrimination-took-place-amid-claim-women-minorities-favoured-men.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:55:14+00:00

Air Chief Marshal Sir Mike Wigston, head of the RAF insisted there was 'no drop' in standard as he denied there was discrimination in the RAF following a bombshell row between military top brass.

## Singer Murray Head, 76, injured in car crash in southern France
 - [https://www.dailymail.co.uk/news/article-11206029/Singer-Murray-Head-76-injured-car-crash-southern-France.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206029/Singer-Murray-Head-76-injured-car-crash-southern-France.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:54:50+00:00

Murray Head, 76, the singer and actor best-known for hits including On Night In Bangkok and films such as Sunday Bloody Sunday, crashed around 3pm Monday in southern France.

## Archie Battersbee's family lay the 12-year-old to rest in Prittlewell, Southend
 - [https://www.dailymail.co.uk/news/article-11205905/Archie-Battersbees-family-lay-12-year-old-rest-Prittlewell-Southend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205905/Archie-Battersbees-family-lay-12-year-old-rest-Prittlewell-Southend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:53:59+00:00

Archie's funeral is taking place at St Mary's Church in Prittlewell, Southend, with the Reverend Paul Mackay overseeing a service featuring music and poetry.

## Putin could order a 'nuclear strike to instil terror in Ukrainians' after Kharkiv rout
 - [https://www.dailymail.co.uk/news/article-11206005/Putin-order-nuclear-strike-instil-terror-Ukrainians-Kharkiv-rout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11206005/Putin-order-nuclear-strike-instil-terror-Ukrainians-Kharkiv-rout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:53:38+00:00

Rose Gottemoeller, who was deputy secretary general of NATO for three years, said Putin may 'strike back in unpredictable ways' including using nukes after rout in Kharkiv.

## Who is going to the Queen's funeral? The guest list we know so far
 - [https://www.dailymail.co.uk/news/article-11205641/Who-going-Queens-funeral-guest-list.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205641/Who-going-Queens-funeral-guest-list.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:53:21+00:00

The globe's most powerful men and women are scrambling for seats at Westminster Abbey on Monday amid limits on who can join the congregation of 2,000.

## Marine Bill Bee on how he has still not been medically retired despite three brain injuries
 - [https://www.dailymail.co.uk/news/article-11205665/Marine-Bill-Bee-not-medically-retired-despite-three-brain-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205665/Marine-Bill-Bee-not-medically-retired-despite-three-brain-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:51:43+00:00

In his memoir The Shot, he details the the moment where he had enough and wrote a goodbye letter to his wife Bobbie after she left with their son during an argument.

## Husband faces life in jail as he admits strangling his 'beautiful' wife, 29, to death
 - [https://www.dailymail.co.uk/news/article-11205873/Husband-faces-life-jail-admits-strangling-beautiful-wife-29-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205873/Husband-faces-life-jail-admits-strangling-beautiful-wife-29-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:41:46+00:00

Matthew Fisher, 29, appeared before Leeds Crown Court on Tuesday where he was arraigned pleaded guilty to his wife Abi's murder just six months after she gave birth to their daughter.

## South of England will be hit by downpours as thousands queue make their final farewells to the Queen
 - [https://www.dailymail.co.uk/news/article-11205939/South-England-hit-downpours-thousands-queue-make-final-farewells-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205939/South-England-hit-downpours-thousands-queue-make-final-farewells-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:38:07+00:00

Mourners in London may need to take a brolly with them when they queue through the streets of the capital to pay their respects to the Queen this week - with downpours expected tonight.

## Ex-WWE star Eva Maria goes into 'anaphylactic shock' from fire ant bites
 - [https://www.dailymail.co.uk/news/article-11205799/Ex-WWE-star-Eva-Maria-goes-anaphylactic-shock-fire-ant-bites.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205799/Ex-WWE-star-Eva-Maria-goes-anaphylactic-shock-fire-ant-bites.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:29:50+00:00

A video posted to her TikTok shows Marie in an emergency room, where she says she was admitted for 'anaphylactic shock'.

## Cruel parents jailed after torturing their five-year-old girl
 - [https://www.dailymail.co.uk/news/article-11205921/Cruel-parents-jailed-torturing-five-year-old-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205921/Cruel-parents-jailed-torturing-five-year-old-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:20:57+00:00

Georgia Newman, 29, and boyfriend Jordan Michael Kilkenny, 29, tortured her five-year-old girl by forcing her into an ice-cold bath at their home in Leeds, West Yorkshire, until she was on the brink of death.

## Migrant crossings hit 28,561: More have now crossed the English Channel this year than in 2021
 - [https://www.dailymail.co.uk/news/article-11205863/Migrant-crossings-hit-28-561-crossed-English-Channel-year-2021.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205863/Migrant-crossings-hit-28-561-crossed-English-Channel-year-2021.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 11:11:21+00:00

A record number of migrants have now crossed the English Channel by small boat already this year.

## Russian fighter jet CRASHES in fireball after take-off in Crimea as Ukraine condemn 'incompetence'
 - [https://www.dailymail.co.uk/news/article-11205839/Russian-fighter-jet-CRASHES-fireball-Crimea-Ukraine-condemn-incompetence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205839/Russian-fighter-jet-CRASHES-fireball-Crimea-Ukraine-condemn-incompetence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:58:34+00:00

On Sunday morning, the jet, which costs an estimated £9.5million, tried to take off alongside another aircraft at a strip on the Crimean peninsula.

## You can't camp here! Police tell royal fans on the Mall to pack away tents for 'security reasons'
 - [https://www.dailymail.co.uk/news/article-11205819/You-camp-Police-tell-royal-fans-Mall-pack-away-tents-security-reasons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205819/You-camp-Police-tell-royal-fans-Mall-pack-away-tents-security-reasons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:57:50+00:00

Video footage has emerged showing police telling royal superfans including John Loughrey, 67, they need to take their tents down on the Mall.

## NUS president Shaima Dallali says she has received barrage of death threats after being suspended
 - [https://www.dailymail.co.uk/news/article-11205797/NUS-president-Shaima-Dallali-says-received-barrage-death-threats-suspended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205797/NUS-president-Shaima-Dallali-says-received-barrage-death-threats-suspended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:57:03+00:00

Dallai, is currently under investigation for anti-Semitism following a tweet that she wrote 10 years ago referencing the Battle of Khaybar - an ancient battle between Muslims and Jews.

## Man, 22, is charged with breaching the peace after spectator heckled Prince Andrew
 - [https://www.dailymail.co.uk/news/article-11205823/Man-22-charged-breaching-peace-spectator-heckled-Prince-Andrew.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205823/Man-22-charged-breaching-peace-spectator-heckled-Prince-Andrew.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:56:48+00:00

A 22-year-old man has been charged with breaching the peace after a spectator heckled the Duke of York as he marched with King Charles III behind the Queen's coffin in Edinburgh.

## SNP MP who travelled from London to Scotland by train knowing she had Covid given community service
 - [https://www.dailymail.co.uk/news/article-11205871/SNP-MP-travelled-London-Scotland-train-knowing-Covid-given-community-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205871/SNP-MP-travelled-London-Scotland-train-knowing-Covid-given-community-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:56:07+00:00

Scottish MP Margaret Ferrier, who admitted to  travelling on a train from London to Scotland knowing she had Covid-19, has been ordered to undertake 270 hours of unpaid work.

## The Queen: Majority of Australia supports the monarchy and not a republic: King Charles III
 - [https://www.dailymail.co.uk/news/article-11205707/The-Queen-Majority-Australia-supports-monarchy-not-republic-King-Charles-III.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205707/The-Queen-Majority-Australia-supports-monarchy-not-republic-King-Charles-III.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:55:17+00:00

A new poll has revealed most Australians want to keep the monarchy and not transition to a republic with one of the main reasons given being 'why change something that works'.

## Oprah Winfrey criticised for saying she hopes Harry and Meghan will 'make peace' with Royal Family
 - [https://www.dailymail.co.uk/news/article-11205717/Oprah-Winfrey-criticised-saying-hopes-Harry-Meghan-make-peace-Royal-Family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205717/Oprah-Winfrey-criticised-saying-hopes-Harry-Meghan-make-peace-Royal-Family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:55:04+00:00

Harry and Meghan's royal relationship soured further after the Oprah interview in 2021, when they shared a series of accusations, leading some to question why the talk show host was getting involved

## How King Charles will privately mourn his mother in Buckingham Palace's Bow Room
 - [https://www.dailymail.co.uk/news/article-11205635/How-King-Charles-privately-mourn-mother-Buckingham-Palaces-Bow-Room.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205635/How-King-Charles-privately-mourn-mother-Buckingham-Palaces-Bow-Room.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:54:42+00:00

The Queen's coffin is arriving in London this evening and will be taken by hearse to Buckingham Palace. It will be carried to the Bow Room (above), where Charles and other royals can mourn.

## Royal Family fans already camping for Queen's funeral on Monday in London
 - [https://www.dailymail.co.uk/news/article-11205743/London-braces-millions-mourners-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205743/London-braces-millions-mourners-Queens-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:54:21+00:00

Officials expect Westminster Hall has capacity for 350,000 people to view the coffin despite the venue opening from 5pm tomorrow until 6.30am next Monday.

## Irish PM says Queen's death is chance to 'reset' relations between UK and Ireland after Brexit rows
 - [https://www.dailymail.co.uk/news/article-11205875/Irish-PM-says-Queens-death-chance-reset-relations-UK-Ireland-Brexit-rows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205875/Irish-PM-says-Queens-death-chance-reset-relations-UK-Ireland-Brexit-rows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:51:20+00:00

The Taoiseach claimed Her Majesty's passing should offer 'time for reflection' and 'remind us of the need to proactively nurture the relationship' between the two countries.

## Stone Roses manager to pay neighbours £400 after campaign of harassment ended in dog being put down
 - [https://www.dailymail.co.uk/news/article-11205861/Stone-Roses-manager-pay-neighbours-400-campaign-harassment-ended-dog-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205861/Stone-Roses-manager-pay-neighbours-400-campaign-harassment-ended-dog-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:47:24+00:00

Gareth Evans, 76, would prove to be a general irritant and 'constantly provoked' the married couple living next door despite being ordered by a court to leave the husband and wife alone.

## Mother who said heartbreaking goodbye to son with rare brain condition 5 times hears him say 'mum'
 - [https://www.dailymail.co.uk/news/article-11205881/Mother-said-heartbreaking-goodbye-son-rare-brain-condition-5-times-hears-say-mum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205881/Mother-said-heartbreaking-goodbye-son-rare-brain-condition-5-times-hears-say-mum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:47:12+00:00

Georgia Eaton, 36, was told 'countless' times that son James wasn't going to 'make it' after he was diagnosed with encephalitis - a condition causing inflammation of the brain.

## Royal fans battle for hotels in London and Windsor ahead of Queen's state funeral
 - [https://www.dailymail.co.uk/news/article-11205629/Royal-fans-battle-hotels-London-Windsor-ahead-Queens-state-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205629/Royal-fans-battle-hotels-London-Windsor-ahead-Queens-state-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:39:06+00:00

Royal fans are scrambling to try and book hotels in London and Windsor after police and foreign media leave rooms 'sold out' ahead of the Queen's state funeral on Monday, September 19

## Major world leaders will NOT have to take a bus to Queen's funeral
 - [https://www.dailymail.co.uk/news/article-11205829/Major-world-leaders-NOT-bus-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205829/Major-world-leaders-NOT-bus-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:35:44+00:00

Leaders of the G7 along with other high-profile dignitaries will not be required to board coaches to Westminster Abbey on Monday for the Queen's funeral, a government source has said.

## Ex-England star Andy Carroll is seen talking to police officers after smash
 - [https://www.dailymail.co.uk/news/article-11205801/Ex-England-star-Andy-Carroll-seen-talking-police-officers-smash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205801/Ex-England-star-Andy-Carroll-seen-talking-police-officers-smash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:25:57+00:00

Former England striker Andy Carroll's Mercedes has been smashed in a 'head-on' car with a Ford Fiesta - as witnesses say he was left 'shocked' and was 'walking around in a daze'.

## Succession creator Jesse Armstrong blasted online after 'obscene' King Charles comments during Emmys
 - [https://www.dailymail.co.uk/news/article-11205779/Succession-creator-Jesse-Armstrong-blasted-online-obscene-King-Charles-comments-Emmys.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205779/Succession-creator-Jesse-Armstrong-blasted-online-obscene-King-Charles-comments-Emmys.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:23:38+00:00

Jesse Armstrong, 51, the British creator of the HBO hit Succession, faced backlash online after he took an 'obscene' swipe at King Charles III during his acceptance speech at the Emmy Awards last night.

## Funeral directors blasted for 'diabolical' advert on Queen's hearse break their silence over gaffe
 - [https://www.dailymail.co.uk/news/article-11205693/Funeral-directors-blasted-diabolical-advert-Queens-hearse-break-silence-gaffe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205693/Funeral-directors-blasted-diabolical-advert-Queens-hearse-break-silence-gaffe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:22:00+00:00

William Purves has broken its silence after sparking a   social media storm by leaving one of its adverts on the Queen's hearse as it travelled from Balmoral to Edinburgh.

## Nearly 1,300 NYTimes employees pledge NOT to return to the office
 - [https://www.dailymail.co.uk/news/article-11205771/Nearly-1-300-NYTimes-employees-pledge-NOT-return-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205771/Nearly-1-300-NYTimes-employees-pledge-NOT-return-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 10:18:19+00:00

The employees have stated they will not return to the newsroom after the New York Times expected workers to be in the office for a minimum of three days starting this week.

## Queen funeral news LIVE: Coffin to be flown to London after King Charles III visits Northern Ireland
 - [https://www.dailymail.co.uk/news/live/article-11205473/Queen-funeral-news-LIVE-Coffin-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11205473/Queen-funeral-news-LIVE-Coffin-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:52:31+00:00

Follow MailOnline's liveblog for updates today as the Queen's coffin is taken to Buckingham Palace and King Charles III travels to Northern Ireland with Camilla.

## Two groups of students at Florida high school face criminal charges after gun prank
 - [https://www.dailymail.co.uk/news/article-11205691/Two-groups-students-Florida-high-school-face-criminal-charges-gun-prank.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205691/Two-groups-students-Florida-high-school-face-criminal-charges-gun-prank.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:49:16+00:00

Pupils ran for their lives after school girls approached the staff member and told them they had seen someone carrying again, sparking a mass panic.

## Senator Jacinta Price breaks her silence about losing her brother to cancer when she was three
 - [https://www.dailymail.co.uk/news/article-11205505/Senator-Jacinta-Price-breaks-silence-losing-brother-cancer-three.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205505/Senator-Jacinta-Price-breaks-silence-losing-brother-cancer-three.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:49:12+00:00

The Indigenous Senator shared a post to her social media on Monday to raise awareness about cancer affecting young kids as part of Childhood Cancer Awareness Month.

## Daughter of Paddington creator leads calls for toys to be sent to children's charities
 - [https://www.dailymail.co.uk/news/article-11205721/Daughter-Paddington-creator-leads-calls-toys-sent-childrens-charities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205721/Daughter-Paddington-creator-leads-calls-toys-sent-childrens-charities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:48:59+00:00

Children across the nation have paid their respects with the teddy bears and marmalade sandwiches in a nod to the delightful sketch filmed for the Queen's Platinum Jubilee in June.

## South Australian chicken shop closes down: Inflation and staff shortages to blame: Glenelg South
 - [https://www.dailymail.co.uk/news/article-11205489/South-Australian-chicken-shop-closes-Inflation-staff-shortages-blame-Glenelg-South.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205489/South-Australian-chicken-shop-closes-Inflation-staff-shortages-blame-Glenelg-South.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:46:39+00:00

Chick N' Chips in Glenelg South in South Australia, provided the local community with 100 per cent free range produce and its own gluten free stuffing - but it can't stay open any longer.

## Who is going to the Queen's funeral? Joe Biden and royals heading to Westminster Abbey
 - [https://www.dailymail.co.uk/news/article-11205641/Who-going-Queens-funeral-Joe-Biden-royals-heading-Westminster-Abbey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205641/Who-going-Queens-funeral-Joe-Biden-royals-heading-Westminster-Abbey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:44:00+00:00

The globe's most powerful men and women are scrambling for seats at Westminster Abbey on Monday amid limits on who can join the congregation of 2,000.

## Iranian TV calls Queen 'one of the greatest criminals in history' and compares her to HITLER
 - [https://www.dailymail.co.uk/news/article-11205673/Iranian-TV-calls-Queen-one-greatest-criminals-history-compares-HITLER.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205673/Iranian-TV-calls-Queen-one-greatest-criminals-history-compares-HITLER.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:43:08+00:00

Iran's foreign ministry has not commented on her death or the ascension to the throne of King Charles III, and its TV channels have been spreading vile remarks about her legacy.

## Ukraine continues to push Russia back raising hopes of turning point in war
 - [https://www.dailymail.co.uk/news/article-11205529/Ukraine-continues-push-Russia-raising-hopes-turning-point-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205529/Ukraine-continues-push-Russia-raising-hopes-turning-point-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:40:31+00:00

Russian troops are surrendering en masse in the face of a Ukrainian advance near Kharkiv because 'they realise the hopelessness of their situation', Kyiv's military intelligence has said.

## 'Heartbroken' King Charles III stands guard by Queen's coffin during St Giles' Cathedral vigil
 - [https://www.dailymail.co.uk/femail/article-11204573/King-Charles-III-Queens-coffin-St-Giles-Cathedral-vigil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11204573/King-Charles-III-Queens-coffin-St-Giles-Cathedral-vigil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:40:29+00:00

Royal fans have sympathised with King Charles after noting that the new monarch looked 'heartbroken' this evening during a vigil for Queen Elizabeth in Edinburgh.

## King Charles and Queen Consort Camilla said to be 'in no rush to move into Buckingham Palace'
 - [https://www.dailymail.co.uk/news/article-11205671/King-Charles-Queen-Consort-Camilla-said-no-rush-Buckingham-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205671/King-Charles-Queen-Consort-Camilla-said-no-rush-Buckingham-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:38:23+00:00

King Charles and Camilla are going to continue to use Clarence House as their London residence and are in 'no rush' to move into Buckingham Palace.

## Boy, 16, filmed himself stabbing 15-year-old schoolboy to death is locked up for at least 13 years
 - [https://www.dailymail.co.uk/news/article-11205679/Boy-16-filmed-stabbing-15-year-old-schoolboy-death-locked-13-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205679/Boy-16-filmed-stabbing-15-year-old-schoolboy-death-locked-13-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:27:26+00:00

The unnamed defendant, pulled out a Rambo-style knife from his waistband before chasing Jalan Woods-Bell, slashing his face and stabbing him in the chest during an attack in Hayes, West London.

## Prince William's friend the Marquess of Cholmondeley loses job
 - [https://www.dailymail.co.uk/news/article-11205661/Prince-Williams-friend-Marquess-Cholmondeley-loses-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205661/Prince-Williams-friend-Marquess-Cholmondeley-loses-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:26:50+00:00

The Marquess, also known as film-maker David Rocksavage, had the role, in which he had to walk backwards in front of the monarch at the State Opening of Parliament.

## Warning over 'rush for the Commonwealth door' following the death of the Queen
 - [https://www.dailymail.co.uk/news/article-11205669/Warning-rush-Commonwealth-door-following-death-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205669/Warning-rush-Commonwealth-door-following-death-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 09:05:00+00:00

In addition to the UK, Charles III now rules in 14 Commonwealth countries that were former dominions of the British Empire.

## Ron DeSantis pokes fun at college students taking 'zombie studies with $100,000 in debt'
 - [https://www.dailymail.co.uk/news/article-11205577/Ron-DeSantis-pokes-fun-college-students-taking-zombie-studies-100-000-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205577/Ron-DeSantis-pokes-fun-college-students-taking-zombie-studies-100-000-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 08:57:01+00:00

The Republican lawmaker (pictured) stressed the importance of offering different paths for young people, rather than pushing them into expensive college degrees for which they are ill-suited

## Azerbaijan 'tries to advance' into Armenia, with clashes breaking out across the border
 - [https://www.dailymail.co.uk/news/article-11205549/Azerbaijan-tries-advance-Armenia-clashes-breaking-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205549/Azerbaijan-tries-advance-Armenia-clashes-breaking-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 08:52:52+00:00

Both sides have blamed each other for the flare up over the Nagorno-Karabakh region amid claims Azerbaijan is targeting civilian infrastructure (file image).

## Sydney, Brisbane, Melbourne weather: Australia set for third consecutive La Nina this summer
 - [https://www.dailymail.co.uk/news/article-11205531/Sydney-Brisbane-Melbourne-weather-Australia-set-consecutive-La-Nina-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205531/Sydney-Brisbane-Melbourne-weather-Australia-set-consecutive-La-Nina-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 08:44:22+00:00

The record-breaking rain and flooding that smashed Australia's east coast earlier this year could be repeated with the Bureau of Meteorology declaring a third consecutive La Nina summer is on the way.

## Melissa Caddick inquest: Top cop reveals strange behaviour of fraudster's husband after she vanished
 - [https://www.dailymail.co.uk/news/article-11205521/Melissa-Caddick-inquest-cop-reveals-strange-behaviour-fraudsters-husband-vanished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205521/Melissa-Caddick-inquest-cop-reveals-strange-behaviour-fraudsters-husband-vanished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 08:28:41+00:00

The first police investigator to work on fraudster Melissa Caddick's disappearance has told an inquest her husband gave conflicting accounts of her final moments.

## Google faces £22billion 'ad tech' lawsuit from publishers in Europe
 - [https://www.dailymail.co.uk/news/article-11205555/Google-faces-22billion-ad-tech-lawsuit-publishers-Europe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205555/Google-faces-22billion-ad-tech-lawsuit-publishers-Europe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 08:28:18+00:00

Lawyers seeking up to £22billion in damages for publishers across Europe claim the US tech firm deprived the media of revenue through its 'anti-competitive conduct'.

## Florida man arrested after giving child near-fatal dose of FENTANYL
 - [https://www.dailymail.co.uk/news/article-11205599/Florida-man-arrested-giving-child-near-fatal-dose-FENTANYL.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205599/Florida-man-arrested-giving-child-near-fatal-dose-FENTANYL.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 08:23:29+00:00

Scott Honeycutt, 43, called 911 last month to tell emergency services that a juvenile was overdosing in his house after taking an unknown narcotic.

## Weeping mourners stand in mile-long queue to see the Queen in Edinburgh
 - [https://www.dailymail.co.uk/news/article-11205523/Weeping-mourners-stand-mile-long-queue-Queen-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205523/Weeping-mourners-stand-mile-long-queue-Queen-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 07:52:30+00:00

Pensioners slept on benches, others caught up on rest in camping chairs or even sat on pavements or chose to go without sleep at all to be among those to enter St Giles' Cathedral.

## How to visit the Queen's coffin in London's Westminster Hall
 - [https://www.dailymail.co.uk/news/article-11205057/Queens-coffin-Londons-Westminster-Hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205057/Queens-coffin-Londons-Westminster-Hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 07:42:25+00:00

The Queen will return to London today to lie in state, accompanied by Princess Anne, after thousands of mourners gathered to pay their respects at St Giles' Cathedral in Edinburgh.

## Scotland grieves its Queen in St Giles' Cathedral in Edinburgh
 - [https://www.dailymail.co.uk/news/article-11204991/Scotland-Queen-coffin-St-Giles-Cathedral-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204991/Scotland-Queen-coffin-St-Giles-Cathedral-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 07:39:54+00:00

Respectful well-wishers have been overcome with emotion, after queueing for hours through the streets of the Scottish capital. A poignant vigil was held inside St Giles' Cathedral this evening.

## Sophie, Countess of Wessex and the Queen: A loving bond
 - [https://www.dailymail.co.uk/news/article-11204763/Sophie-Countess-Wessex-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204763/Sophie-Countess-Wessex-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 07:30:43+00:00

REBECCA ENGLISH: Hunkered down on her heels, eyes red-rimmed as she studied the floral tributes and loving messages, the Countess of Wessex appeared lost in thought.

## How Michael Mansell's single meeting with the Queen changed an Australian state forever
 - [https://www.dailymail.co.uk/news/article-11204927/How-Michael-Mansells-single-meeting-Queen-changed-Australian-state-forever.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204927/How-Michael-Mansells-single-meeting-Queen-changed-Australian-state-forever.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 07:26:20+00:00

Aboriginal Land Council of Tasmania chairman Michael Mansell looked back on his memorable meeting with the Queen during a civic reception held at Hobart's Wrest Point Casino.

## The big squeeze continues as pay tumbles 3.9% compared to inflation
 - [https://www.dailymail.co.uk/news/article-11205507/The-big-squeeze-continues-pay-tumbles-3-9-compared-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205507/The-big-squeeze-continues-pay-tumbles-3-9-compared-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 07:16:30+00:00

Although regular pay - excluding bonuses - was ticking up by 5.2 per cent in the quarter to July, that was far behind inflation.

## How to spot a killer kangaroo - after man is killed by marsupial in Redmond, WA
 - [https://www.dailymail.co.uk/news/article-11205329/How-spot-killer-kangaroo-man-killed-marsupial-Redmond-WA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205329/How-spot-killer-kangaroo-man-killed-marsupial-Redmond-WA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 07:15:23+00:00

Paramedics were called to the property of a 77-year-old in Redmond, near Albany, Western Australia, on Sunday night after the man was attacked by a kangaroo at his home.

## Four-year-old Tasmanian boy in Launceston saves mother's life by calling Triple Zero
 - [https://www.dailymail.co.uk/news/article-11183969/Four-year-old-Tasmanian-boy-Launceston-saves-mothers-life-calling-Triple-Zero.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11183969/Four-year-old-Tasmanian-boy-Launceston-saves-mothers-life-calling-Triple-Zero.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:58:31+00:00

Wendy Cocker taught her four-year-old son Monty (left) how to call triple zero with a mobile phone last month in Launceston, Tasmania - the day after he helped save her life

## Australia pandemic leave payments are going no-where, PM indicates
 - [https://www.dailymail.co.uk/news/article-11205311/Australia-pandemic-leave-payments-going-no-PM-indicates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205311/Australia-pandemic-leave-payments-going-no-PM-indicates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:58:01+00:00

Prime Minister Anthony Albanese has strongly indicated he  supports the state and territory push to extend emergency pandemic leave payments beyond the end of September.

## King Charles III LIVE: Latest news as Queen's coffin is flown to London
 - [https://www.dailymail.co.uk/news/live/article-11205473/King-Charles-III-LIVE-Latest-news-Queens-coffin-flown-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11205473/King-Charles-III-LIVE-Latest-news-Queens-coffin-flown-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:54:31+00:00

Follow MailOnline's liveblog for updates today as the Queen's coffin is taken to Buckingham Palace and King Charles III travels to Northern Ireland with Camilla.

## Queens death: Ben Roberts-Smith breaks silence on being one of handful of invited Australians
 - [https://www.dailymail.co.uk/news/article-11205389/Queens-death-Ben-Roberts-Smith-breaks-silence-one-handful-invited-Australians.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205389/Queens-death-Ben-Roberts-Smith-breaks-silence-one-handful-invited-Australians.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:53:42+00:00

Ben Roberts-Smith has opened up about his invitation to attend the Queen's funeral at Westminster Abbey in London, hailing Her Majesty for her personal sacrifice and 'magnificent' example.

## Cops swoop on shirtless, tattooed man over stabbing death of Brisbane Comanchero bikie associate
 - [https://www.dailymail.co.uk/news/article-11205411/Cops-swoop-shirtless-tattooed-man-stabbing-death-Brisbane-Comanchero-bikie-associate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205411/Cops-swoop-shirtless-tattooed-man-stabbing-death-Brisbane-Comanchero-bikie-associate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:51:31+00:00

The police have released dramatic footage of  officers swooping in to arrest a shirtless, tattooed man in thongs after the killing of a Comanchero bikie associate in Brisbane.

## Why the Ford Everest has a major mountain to climb even though it's a very capable four-wheel drive
 - [https://www.dailymail.co.uk/news/article-11202791/Why-Ford-Everest-major-mountain-climb-capable-four-wheel-drive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11202791/Why-Ford-Everest-major-mountain-climb-capable-four-wheel-drive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:49:40+00:00

Australians love four-wheel drives and utes but not four-wheel drives based on a ute. Ford has struggled to sell the Everest as buyers line up for the Ranger ute.

## Queen's death: Footage resurfaces of Queen's memorable visit to Vasse Primary School, Busselton
 - [https://www.dailymail.co.uk/news/article-11205217/Queens-death-Footage-resurfaces-Queens-memorable-visit-Vasse-Primary-School-Busselton.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205217/Queens-death-Footage-resurfaces-Queens-memorable-visit-Vasse-Primary-School-Busselton.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:45:01+00:00

A former principal has fondly looked back on the Queen's memorable visit at his school in Western Australia's south-west which made international headlines at the time.

## NSW Health alert over measles case echoes Covid 'exposure site' warnings
 - [https://www.dailymail.co.uk/news/article-11205419/NSW-Health-alert-measles-case-echoes-Covid-exposure-site-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205419/NSW-Health-alert-measles-case-echoes-Covid-exposure-site-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:41:23+00:00

NSW has recorded its first case of measles since 2020 as health authorities issued a list of 'exposure sites' the victim visited while infectious in an echo of Covid prevention measures.

## Rapper shot dead - just days after claiming to be target of robberies in an interview
 - [https://www.dailymail.co.uk/news/article-11205429/Rapper-shot-dead-just-days-claiming-target-robberies-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205429/Rapper-shot-dead-just-days-claiming-target-robberies-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:37:28+00:00

Rapper PnB Rock was shot dead this week just days after revealing that he'd been the target of several failed robbery attempts prior to his death.

## Charles III will leave Scotland for Northern Ireland today
 - [https://www.dailymail.co.uk/news/article-11205431/Charles-III-leave-Scotland-Northern-Ireland-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205431/Charles-III-leave-Scotland-Northern-Ireland-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:28:46+00:00

His Majesty will touch down in Belfast for his 40th visit to the province - but it is his first as King, and his saddest. This evening the Queen will leave her beloved Scotland for the last time.

## Premier Annastacia Palaszczuk calls emergency housing summit after 50,000 people move to Queensland
 - [https://www.dailymail.co.uk/news/article-11205325/Premier-Annastacia-Palaszczuk-calls-emergency-housing-summit-50-000-people-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205325/Premier-Annastacia-Palaszczuk-calls-emergency-housing-summit-50-000-people-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:25:04+00:00

Queensland Premier Annastacia Palaszczuk will chair an emergency summit addressing housing challenges in the state caused by floods, population growth and mass interstate migration.

## Dog mauls a 10-year-old boy in 'nasty' incident that comes after a spate of other dog attacks
 - [https://www.dailymail.co.uk/news/article-11205363/Dog-mauls-10-year-old-boy-nasty-incident-comes-spate-dog-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205363/Dog-mauls-10-year-old-boy-nasty-incident-comes-spate-dog-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:23:39+00:00

A 10-year old boy has been rushed to hospital after suffering 'a number' of lacerations to his arms and head in a vicious dog attack in the Northern Territory town of Bellamack.

## American living in Australia reveals the horrible text that her boss sent her: 'I should have SUED'
 - [https://www.dailymail.co.uk/news/article-11205093/American-living-Australia-reveals-horrible-text-boss-sent-SUED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205093/American-living-Australia-reveals-horrible-text-boss-sent-SUED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 06:18:28+00:00

An American worker known as tatesescape compared a nasty message sent by her US manager while working there to the 'sweet' RUOK text from her Aussie boss

## Grace Tame deletes her social media to focus on book tour of her memoir
 - [https://www.dailymail.co.uk/news/article-11205417/Grace-Tame-deletes-social-media-focus-book-tour-memoir.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205417/Grace-Tame-deletes-social-media-focus-book-tour-memoir.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 05:56:44+00:00

Both the Twitter and Instagram account of the former Australian of the Year was noticeably taken down on Tuesday.

## Largest private-sector nurses strike in U.S. history begins as 15,000 healthcare workers walk off
 - [https://www.dailymail.co.uk/news/article-11205297/Largest-private-sector-nurses-strike-U-S-history-begins-15-000-healthcare-workers-walk-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205297/Largest-private-sector-nurses-strike-U-S-history-begins-15-000-healthcare-workers-walk-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 05:56:41+00:00

Nurses in Minnesota picketed on Monday - the first of three days of strike action. They are protesting pay and staff shortages, after negotiations began with private hospitals in March broke down.

## Household Division rehearse taking Queen's coffin from Buckingham Palace to Westminster Hall
 - [https://www.dailymail.co.uk/news/article-11205395/Household-Division-rehearse-taking-Queens-coffin-Buckingham-Palace-Westminster-Hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205395/Household-Division-rehearse-taking-Queens-coffin-Buckingham-Palace-Westminster-Hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 05:56:23+00:00

Overnight the Household Division rehearsed taking the Queen's coffin from Buckingham Palace to Westminster Hall to lie in state, as they were seen marching down the Mall in ceremonial attire.

## Shocking moment Texas teenager mows down man crossing parking lot in wheelchair despite waving stop
 - [https://www.dailymail.co.uk/news/article-11205347/Shocking-moment-Texas-teenager-mows-man-crossing-parking-lot-wheelchair-despite-waving-stop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205347/Shocking-moment-Texas-teenager-mows-man-crossing-parking-lot-wheelchair-despite-waving-stop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 05:54:43+00:00

Austin Police arrested Pablo Avila-Banagas, 17, in connection to a hit-and-run where a man in an electric wheelchair was hit and left with life-threatening injuries. It was all caught on camera.

## Michigan man who shot wife, daughter and family dog before being killed by police lost mind to QAnon
 - [https://www.dailymail.co.uk/news/article-11205305/Michigan-man-shot-wife-daughter-family-dog-killed-police-lost-mind-QAnon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205305/Michigan-man-shot-wife-daughter-family-dog-killed-police-lost-mind-QAnon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 05:53:00+00:00

Rebecca Lanis, 21, went viral over the weekend posting on the 'QAnon Casualties' Reddit page, where people discuss family members they see as having been 'ruined' by QAnon.

## Jetstar passengers stranded at Tokyo's Narita airport trying to get back to Australia
 - [https://www.dailymail.co.uk/news/article-11205267/Jetstar-passengers-stranded-Tokyos-Narita-airport-trying-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205267/Jetstar-passengers-stranded-Tokyos-Narita-airport-trying-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 05:49:25+00:00

For the second time in a fortnight Jetstar passengers have been left stranded in Tokyo's main airport with the group of 16, including a toddler, forced to make do over two nights.

## Kosciuszko National Park: 11 wild brumbies killed as 2GB's Ray Hadley weighs in
 - [https://www.dailymail.co.uk/news/article-11204957/Kosciuszko-National-Park-11-wild-brumbies-killed-2GBs-Ray-Hadley-weighs-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204957/Kosciuszko-National-Park-11-wild-brumbies-killed-2GBs-Ray-Hadley-weighs-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 05:44:12+00:00

GRAPHIC CONTENT WARNING: Two photographers discovered a herd of brumbies had been brutally slaughtered in a culling within Kosciuszko National Park.

## NASA desperate to launch Doomed Artemis 1 mission to the moon SEPT 27
 - [https://www.dailymail.co.uk/news/article-11205233/NASA-desperate-launch-Doomed-Artemis-1-mission-moon-SEPT-27.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205233/NASA-desperate-launch-Doomed-Artemis-1-mission-moon-SEPT-27.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 05:39:47+00:00

NASA has settled on launching the seemingly doomed Artemis 1 on September 27, after the moon mission was delayed by technical problems on two occasions.

## Melbourne mum's babies were taken from Sunshine Hospital to Sandringham Hospital before she saw them
 - [https://www.dailymail.co.uk/news/article-11205295/Melbourne-mums-babies-taken-Sunshine-Hospital-Sandringham-Hospital-saw-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205295/Melbourne-mums-babies-taken-Sunshine-Hospital-Sandringham-Hospital-saw-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 05:23:47+00:00

First-time mother Sally wasn't able to hold her newborn premature twins for the first time until four days after their birth because there weren't enough beds at her hospital.

## Gold Coast Instagram influencer Jaxon Tippet opens up on how steroid addiction destroyed his life
 - [https://www.dailymail.co.uk/news/article-11202945/Gold-Coast-Instagram-influencer-Jaxon-Tippet-opens-steroid-addiction-destroyed-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11202945/Gold-Coast-Instagram-influencer-Jaxon-Tippet-opens-steroid-addiction-destroyed-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 04:51:15+00:00

The Gold Coast social influencer has opened up about his steroid addiction, five years after cops found steroids and testosterone down his pants, along with a syringe and needle in his underwear.

## Din Tai Fung, dumpling restaurant, accused of underpaying workers in Sydney and Melbourne
 - [https://www.dailymail.co.uk/news/article-11205187/Din-Tai-Fung-dumpling-restaurant-accused-underpaying-workers-Sydney-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205187/Din-Tai-Fung-dumpling-restaurant-accused-underpaying-workers-Sydney-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 04:41:51+00:00

A payroll officer for world-famous dumpling chain restaurant Din Tai Fung told a court they were instructed to create a fake payroll to hide the company underpaying Australian staff.

## No jail for woman after fake abuse claims about man she dated
 - [https://www.dailymail.co.uk/news/article-11205159/No-jail-woman-fake-abuse-claims-man-dated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205159/No-jail-woman-fake-abuse-claims-man-dated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 04:40:33+00:00

After a medical examination found Makaela Bacon's injuries inconsistent with her claims she had been choked unconscious, the 19-year-old doubled down.

## Taxi driver falsely accused of rape bashed and robbed after a vigilante tracked him down
 - [https://www.dailymail.co.uk/news/article-11205345/Taxi-driver-falsely-accused-rape-bashed-robbed-vigilante-tracked-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205345/Taxi-driver-falsely-accused-rape-bashed-robbed-vigilante-tracked-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 04:36:52+00:00

A taxi driver falsely accused of rape was robbed and bashed when a gel blaster-wielding vigilante tracked him down, a court has been told.

## Young powerlifter who accused Melbourne University coach of rape sued for defamation
 - [https://www.dailymail.co.uk/news/melbourne/article-11205251/Young-powerlifter-accused-Melbourne-University-coach-rape-sued-defamation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/melbourne/article-11205251/Young-powerlifter-accused-Melbourne-University-coach-rape-sued-defamation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 04:20:46+00:00

A young powerlifter who accused a top coach of rape and sexual harassment is being sued for defaming him.

## John Lennon's killer Mark David Chapman denied parole for 12th time - nearly 42 years after murder
 - [https://www.dailymail.co.uk/news/article-11205235/John-Lennons-killer-Mark-David-Chapman-denied-parole-12th-time-nearly-42-years-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205235/John-Lennons-killer-Mark-David-Chapman-denied-parole-12th-time-nearly-42-years-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 04:18:28+00:00

Chapman, 67, appeared before a parole board at the end of August, according to the state Department of Corrections and Community Supervision.

## Succession creator Jesse Armstrong DISSES King Charles III during Emmys acceptance speech
 - [https://www.dailymail.co.uk/news/article-11205257/Succession-creator-Jesse-Armstrong-DISSES-King-Charles-III-Emmys-acceptance-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205257/Succession-creator-Jesse-Armstrong-DISSES-King-Charles-III-Emmys-acceptance-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 03:51:09+00:00

The creator and writer of the hit HBO television series Succession has taken swipe at Britain's new king, days after he ascended the throne. Jesse Armstrong, 51, is himself British.

## Pauline Hanson race row deepens, Mark Latham rips into Greens' Mehreen Faruqi over Queen death tweet
 - [https://www.dailymail.co.uk/news/article-11205135/Pauline-Hanson-race-row-deepens-Mark-Latham-rips-Greens-Mehreen-Faruqi-Queen-death-tweet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205135/Pauline-Hanson-race-row-deepens-Mark-Latham-rips-Greens-Mehreen-Faruqi-Queen-death-tweet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 03:49:03+00:00

Within of the Queen's death, deputy Greens leader Mehreen Faruqi tweeted 'I cannot mourn the leader of a racist empire', sparking an increasingly bitter racism row in Australia.

## Sydney man's heartfelt plea to three young thieves after his shop is robbed twice in one month
 - [https://www.dailymail.co.uk/news/article-11205119/Sydney-mans-heartfelt-plea-three-young-thieves-shop-robbed-twice-one-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205119/Sydney-mans-heartfelt-plea-three-young-thieves-shop-robbed-twice-one-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 03:48:34+00:00

A Sydney petrol station and burger shop owner has issued a heartfelt plea to three young thieves after they were caught on CCTV cameras stealing from his store.

## Queen Elizabeth II death: Australian coins that are set to become instant collector's items
 - [https://www.dailymail.co.uk/news/article-11205079/Queen-Elizabeth-II-death-Australian-coins-set-instant-collectors-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205079/Queen-Elizabeth-II-death-Australian-coins-set-instant-collectors-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 03:24:23+00:00

The Royal Australian Mint routinely releases new coins in September with the following year's date. Chief executive Leigh Gordon said this batch with the Queen's profile would be worth a lot.

## Anthony Albanese blows up at reporter asking if an Aussie will be on the $5 note: 'Bit of respect'
 - [https://www.dailymail.co.uk/news/article-11205223/Anthony-Albanese-blows-reporter-asking-Aussie-5-note-Bit-respect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205223/Anthony-Albanese-blows-reporter-asking-Aussie-5-note-Bit-respect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 03:24:02+00:00

Prime Minister Anthony Albanese has exploded at a reporter who dared ask him a question on Monday, calling for 'a bit of respect'. He was asked if an Australian would replace the Queen on the $5 note.

## Tyrell Edwards' tragic crash leads to call for tougher NSW P-plate driver's licence laws
 - [https://www.dailymail.co.uk/news/article-11205141/Tyrell-Edwards-tragic-crash-leads-call-tougher-NSW-P-plate-drivers-licence-laws.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205141/Tyrell-Edwards-tragic-crash-leads-call-tougher-NSW-P-plate-drivers-licence-laws.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 02:59:44+00:00

There are calls to toughen the laws for P-plate drivers in NSW after it was revealed the 18-year-old alleged to be the driver in a crash that killed five teenagers had been twice suspended for speeding.

## The Australians invited to Queen Elizabeth II's funeral at Westminster Abbey
 - [https://www.dailymail.co.uk/news/article-11204875/The-Australians-invited-Queen-Elizabeth-IIs-funeral-Westminster-Abbey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204875/The-Australians-invited-Queen-Elizabeth-IIs-funeral-Westminster-Abbey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 02:56:23+00:00

Excluding dignitaries such as Prime Minister Anthony Albanese, and his partner Jodie Haydon, only ten Aussies will be invited to the service in London's Westminster Abbey next Monday.

## 'The person you see is not the man I married': Judith Giuliani breaks her silence on ex-husband Rudy
 - [https://www.dailymail.co.uk/news/article-11205125/The-person-not-man-married-Judith-Giuliani-breaks-silence-ex-husband-Rudy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205125/The-person-not-man-married-Judith-Giuliani-breaks-silence-ex-husband-Rudy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 02:51:14+00:00

Judith Giuliani, 67, was married to Rudy from 2003-19. She said he has dramatically changed, and accused him of humiliating and degrading himself. She is currently suing him for unpaid divorce money.

## Teenage girl killed in Buxton crash had never been allowed in the car with a P-plate driver before
 - [https://www.dailymail.co.uk/news/article-11203211/Teenage-girl-killed-Buxton-crash-never-allowed-car-P-plate-driver-before.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11203211/Teenage-girl-killed-Buxton-crash-never-allowed-car-P-plate-driver-before.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 02:50:35+00:00

Gabriella McLennan's parents let her get in the car driven by a friend for the first time last Tuesday in Tahmoor, south-west of Sydney. An hour later, she and four other teenagers were dead.

## Coca Cola axes Lift and replaces it with Sprite+
 - [https://www.dailymail.co.uk/news/article-11205237/Coca-Cola-axes-Lift-replaces-Sprite.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205237/Coca-Cola-axes-Lift-replaces-Sprite.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 02:42:45+00:00

Lift will be permanently removed from supermarket shelves. A staple of the Aussie market since the 1970s, the drink will be phased out in Australia by the end of September 2022.

## Oklahoma inmate tortured to death by jailers played Baby Shark song on repeat for HOURS found dead
 - [https://www.dailymail.co.uk/news/article-11205117/Oklahoma-inmate-tortured-death-jailers-played-Baby-Shark-song-repeat-HOURS-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205117/Oklahoma-inmate-tortured-death-jailers-played-Baby-Shark-song-repeat-HOURS-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 02:32:44+00:00

John Basco, 48, was found unresponsive in his cell early on Sunday. He was part of a group of three former inmates who had filed a civil rights lawsuit against Oklahoma County for playing Baby Shark.

## Goodlife Carindale stabbing victim identified as Levi Johnson as cops probe mystery backpacks
 - [https://www.dailymail.co.uk/news/article-11205059/Goodlife-Carindale-stabbing-victim-identified-Levi-Johnson-cops-probe-mystery-backpacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205059/Goodlife-Carindale-stabbing-victim-identified-Levi-Johnson-cops-probe-mystery-backpacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 02:02:42+00:00

Two mystery backpacks could hold vital clues, with four men on the run and one being questioned by police after the 'horrific' stabbing death of a bikie on Monday.

## University lecturer Adam Brown to plead guilty to wife's murder in Croydon North, Melbourne
 - [https://www.dailymail.co.uk/news/melbourne/article-11205127/University-lecturer-Adam-Brown-plead-guilty-wifes-murder-Croydon-North-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/melbourne/article-11205127/University-lecturer-Adam-Brown-plead-guilty-wifes-murder-Croydon-North-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:55:18+00:00

A senior university lecturer  charged with slaying his wife in their own home will plead guilty to murder.

## New YouGov poll shows 63 per cent think King Charles will make a good monarch for Britain
 - [https://www.dailymail.co.uk/news/article-11205089/New-YouGov-poll-shows-63-cent-think-King-Charles-make-good-monarch-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205089/New-YouGov-poll-shows-63-cent-think-King-Charles-make-good-monarch-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:54:40+00:00

The majority of British people think that King Charles III will make a good monarch with only a fifth thinking he will do a bad job, according to new a poll by YouGov.

## Julie Bishop tells Karl Stefanovic and Ally Langdon of work with King Charles' charity
 - [https://www.dailymail.co.uk/news/article-11204843/Julie-Bishop-tells-Karl-Stefanovic-Ally-Langdon-work-King-Charles-charity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204843/Julie-Bishop-tells-Karl-Stefanovic-Ally-Langdon-work-King-Charles-charity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:53:58+00:00

Former foreign minister Julie Bishop told a story on morning TV to show how funny King Charles is but Nine hosts Karl Stefanovic and Ally Langdon appeared not to get the joke for a minute, at least.

## Alabama prepares execute death row prisoner by nitrogen hypoxia later this month Alan Eugene Miller
 - [https://www.dailymail.co.uk/news/article-11202551/Alabama-prepares-execute-death-row-prisoner-nitrogen-hypoxia-later-month-Alan-Eugene-Miller.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11202551/Alabama-prepares-execute-death-row-prisoner-nitrogen-hypoxia-later-month-Alan-Eugene-Miller.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:49:28+00:00

Nitrogen hypoxia is supposed to cause death by replacing oxygen with nitrogen, and has been authorized by Alabama and two other states for executions.

## Thousands of people queue into the night in Edinburgh to see the Queen's coffin
 - [https://www.dailymail.co.uk/news/article-11204991/Thousands-people-queue-night-Edinburgh-Queens-coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204991/Thousands-people-queue-night-Edinburgh-Queens-coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:47:42+00:00

Respectful well-wishers have been overcome with emotion, after queueing for hours through the streets of the Scottish capital. A poignant vigil was held inside St Giles' Cathedral this evening.

## Touching moment a ray of sunshine shines on Queen Elizabeth II's coffin
 - [https://www.dailymail.co.uk/news/article-11205043/Touching-moment-ray-sunshine-shines-Queen-Elizabeth-IIs-coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205043/Touching-moment-ray-sunshine-shines-Queen-Elizabeth-IIs-coffin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:40:12+00:00

A single ray of sunshine from the heavens has been captured on camera shining down on Queen Elizabeth II's coffin, during a procession to transport her to St. Giles Cathedral in Edinburgh.

## Kings Cross chaos as eight cops wrestle tall man into the back of a police wagon; eshays commentate
 - [https://www.dailymail.co.uk/news/article-11203067/Kings-Cross-chaos-eight-cops-wrestle-tall-man-police-wagon-eshays-commentate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11203067/Kings-Cross-chaos-eight-cops-wrestle-tall-man-police-wagon-eshays-commentate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:39:34+00:00

A 28-year-old man, believed to be 6 foot 5, has been filmed wrestling a group of police officers on a Sydney street as they struggle to throw him into the back of a police wagon.

## World leaders travelling to the UK for Queen's funeral 'will have to pay to use the NHS'
 - [https://www.dailymail.co.uk/news/article-11205097/World-leaders-travelling-UK-Queens-funeral-pay-use-NHS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205097/World-leaders-travelling-UK-Queens-funeral-pay-use-NHS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:19:23+00:00

With thousands of people from across the world set to arrive in Britain in the coming days for the service on Monday, September 19, the NHS is being urged to charge those who use its services.

## Melissa Caddick inquest: watch as Anthony Koletti answers police questions about her disappearance
 - [https://www.dailymail.co.uk/news/article-11204879/Melissa-Caddick-inquest-watch-Anthony-Koletti-answers-police-questions-disappearance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204879/Melissa-Caddick-inquest-watch-Anthony-Koletti-answers-police-questions-disappearance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:18:33+00:00

The behaviour of Melissa Caddick's husband, Anthony Caddick, when police arrived at their Dover Heights home to take his statement over her disappearance can be seen in police video.

## Alice Springs child abuse horror as man, 40, is charged with forcing four young kids to do oral sex
 - [https://www.dailymail.co.uk/news/article-11204905/Alice-Springs-child-abuse-horror-man-40-charged-forcing-four-young-kids-oral-sex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204905/Alice-Springs-child-abuse-horror-man-40-charged-forcing-four-young-kids-oral-sex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:15:09+00:00

A 40-year-old man has been arrested after he allegedly committed four acts of gross indecency on four young children.

## How Queen's casket will return to London today to lie in state - accompanied by Princess Anne
 - [https://www.dailymail.co.uk/news/article-11205057/How-Queens-casket-return-London-today-lie-state-accompanied-Princess-Anne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205057/How-Queens-casket-return-London-today-lie-state-accompanied-Princess-Anne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:12:51+00:00

The Queen will return to London today to lie in state, accompanied by Princess Anne, after thousands of mourners gathered to pay their respects at St Giles' Cathedral in Edinburgh.

## Florida English teacher, 42, at renowned private school is arrested for sex with a student
 - [https://www.dailymail.co.uk/news/article-11204735/Florida-English-teacher-42-renowned-private-school-arrested-sex-student.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204735/Florida-English-teacher-42-renowned-private-school-arrested-sex-student.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:12:48+00:00

Jamie Melton, 42, was charged with sexual battery upon being taken into custody a day after a warrant was issued for her arrest.

## Oprah Winfrey hopes Queen's death will help Prince Harry and Meghan Markle make 'peace' with royals
 - [https://www.dailymail.co.uk/femail/article-11204615/Oprah-Winfrey-hopes-Queens-death-help-Prince-Harry-Meghan-Markle-make-peace-royals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11204615/Oprah-Winfrey-hopes-Queens-death-help-Prince-Harry-Meghan-Markle-make-peace-royals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:05:32+00:00

Oprah, 68, has spoken out about where Prince Harry, 37, and Prince William, 40, stand, and she said that she feels hopeful that the tragic loss of Queen Elizabeth II could bring them together.

## Legendary street photographer William Klein known for gritty  dies aged 96
 - [https://www.dailymail.co.uk/news/article-11204853/Legendary-street-photographer-William-Klein-known-gritty-dies-aged-96.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204853/Legendary-street-photographer-William-Klein-known-gritty-dies-aged-96.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 01:03:42+00:00

American photographer, William Klein, who built his legacy with imagery of fashion and urban life and strongly influenced the medium in the late 20th century died aged 96.

## Black ties sell out at gentlemen's stores as people snap up mourning attire to mark Queen's passing
 - [https://www.dailymail.co.uk/news/article-11205033/Black-ties-sell-gentlemens-stores-people-snap-mourning-attire-mark-Queens-passing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205033/Black-ties-sell-gentlemens-stores-people-snap-mourning-attire-mark-Queens-passing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:54:47+00:00

Demand for Black ties has surpassed levels seen when Princess Diana and Prince Philip died, according to Turnbull and Asser store manager James Cook.

## Report from NSW gaming regulator find Star casino in Sydney unfit for licence
 - [https://www.dailymail.co.uk/news/article-11205055/Report-NSW-gaming-regulator-Star-casino-Sydney-unfit-licence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205055/Report-NSW-gaming-regulator-Star-casino-Sydney-unfit-licence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:52:10+00:00

Sydney's Star casino could have its licence revoked after a report by the NSW gaming regulator found it repeatedly breached the law, misled banks and was infiltrated by criminal elements.

## Qantas boss Alan Joyce savaged by 2GB radio host Ben Fordham over $80 million pay
 - [https://www.dailymail.co.uk/news/article-11204901/Qantas-boss-Alan-Joyce-savaged-2GB-radio-host-Ben-Fordham-80-million-pay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204901/Qantas-boss-Alan-Joyce-savaged-2GB-radio-host-Ben-Fordham-80-million-pay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:47:54+00:00

The Australian national carrier has been heavily criticised by passengers over its performance since services resumed after  Covid lockdown restrictions - but the CEO has raked in millions.

## Justice Department agrees to support Trump-backed candidate for special master in Mar-a-Lago case
 - [https://www.dailymail.co.uk/news/article-11205001/Justice-Department-agrees-support-Trump-backed-candidate-special-master-Mar-Lago-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205001/Justice-Department-agrees-support-Trump-backed-candidate-special-master-Mar-Lago-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:37:03+00:00

Raymond J. Dearie was proposed by Donald Trump's team to act as a special master in the Mar-a-Lago investigation. On Monday the Justice Department agreed. A court will now decide.

## Anthony Albanese stumbles over public holiday for Queen's death on 2GB with 'Melbourne' comment
 - [https://www.dailymail.co.uk/news/article-11204837/Anthony-Albanese-stumbles-public-holiday-Queens-death-2GB-Melbourne-comment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204837/Anthony-Albanese-stumbles-public-holiday-Queens-death-2GB-Melbourne-comment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:36:52+00:00

Prime Minister Anthony Albanese has been called out live on radio over a bizarre ramble about next week's public holiday - on Thursday, September 22 - to mourn the Queen's passing.

## DAILY MAIL COMMENT: King must show our Union is in safe hands
 - [https://www.dailymail.co.uk/news/article-11205041/DAILY-MAIL-COMMENT-King-Union-safe-hands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205041/DAILY-MAIL-COMMENT-King-Union-safe-hands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:36:39+00:00

DAILY MAIL COMMENT: It was an extraordinary and deeply moving spectacle. The new King, resplendent in military regalia, walked solemnly with his siblings behind the Queen's coffin.

## Brits could be told to work from home due  'unprecedented' travel disruption from Queen's funeral
 - [https://www.dailymail.co.uk/news/article-11204959/Brits-told-work-home-unprecedented-travel-disruption-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204959/Brits-told-work-home-unprecedented-travel-disruption-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:36:33+00:00

People could be told to work from home this week as railway bosses warned there would be 'unprecedented' travel disruption to get into London this week ahead of the late Queen's funeral.

## EPHRAIM HARDCASTLE: It's go time for Boris Johnson's honours list
 - [https://www.dailymail.co.uk/news/article-11205035/EPHRAIM-HARDCASTLE-time-Boris-Johnsons-honours-list.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205035/EPHRAIM-HARDCASTLE-time-Boris-Johnsons-honours-list.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:35:31+00:00

EPHRAIM HARDCASTLE: Boris Johnson's resignation honours list is 'signed off and ready to go', I hear. The late Queen's Lord Chamberlain suggested PMs should issue their own medals.

## Prince Andrew wears a suit and is banned from saluting as he joins siblings for vigil in Edinburgh
 - [https://www.dailymail.co.uk/news/article-11204975/Prince-Andrew-banned-wearing-military-uniform-saluting-joins-siblings-vigil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204975/Prince-Andrew-banned-wearing-military-uniform-saluting-joins-siblings-vigil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:29:32+00:00

The Duke of York turned up to yesterday's  traditional Vigil of the Princes in a suit,  a sharp contrast to his siblings - Princess Anne and Prince Edward - who wore their military uniforms.

## Morrisons bosses turn down beeping sound on tills as mark of respect to Queen
 - [https://www.dailymail.co.uk/news/article-11205073/Morrisons-bosses-turn-beeping-sound-tills-mark-respect-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11205073/Morrisons-bosses-turn-beeping-sound-tills-mark-respect-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:28:18+00:00

Most chain stores will close on Monday as the funeral takes place, among them John Lewis, Waitrose, Homebase, Aldi, Apple and Primark.

## Princess Anne will remain by Queen's side for journey from Scotland to London today
 - [https://www.dailymail.co.uk/news/article-11204995/Princess-Anne-remain-Queens-journey-Scotland-London-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204995/Princess-Anne-remain-Queens-journey-Scotland-London-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:13:11+00:00

Princess Anne, 72, the late monarch's only daughter, will accompany her coffin as it leaves Scotland for London on a flight at 6pm today, after being the only royal to travel with it from Balmoral to Edinburgh.

## Trains could run round-the-clock to help well-wishers travelling to London for Queen's funeral
 - [https://www.dailymail.co.uk/news/article-11204979/Trains-run-round-clock-help-wishers-travelling-London-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11204979/Trains-run-round-clock-help-wishers-travelling-London-Queens-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-09-13 00:10:07+00:00

Capacity could be boosted by 50 per cent on some lines. Transport chiefs are expecting demand on railways and roads in the capital to be 'unprecedented'.


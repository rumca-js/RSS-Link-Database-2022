# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## This weird comedy horror game from March went mostly unnoticed
 - [https://www.pcgamer.com/this-weird-comedy-horror-game-from-march-went-mostly-unnoticed](https://www.pcgamer.com/this-weird-comedy-horror-game-from-march-went-mostly-unnoticed)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 23:40:26+00:00

As we enter spooky season, The Upturned deserves another look.

## Team Ninja reveals its own Assassin's Creed Japan
 - [https://www.pcgamer.com/team-ninja-reveals-its-own-assassins-creed-japan](https://www.pcgamer.com/team-ninja-reveals-its-own-assassins-creed-japan)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 23:30:53+00:00

Samurai duels, grappling hooks, and wingsuits.

## Anime action game Project Eve is now called Stellar Blade, coming in 2023
 - [https://www.pcgamer.com/anime-action-game-project-eve-is-now-called-stellar-blade-coming-in-2023](https://www.pcgamer.com/anime-action-game-project-eve-is-now-called-stellar-blade-coming-in-2023)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 22:57:50+00:00

Killer robot beasts, swords, and cool rail gun arms.

## With veins bulging and biceps glistening, here comes Tekken 8
 - [https://www.pcgamer.com/tekken-8-reveal](https://www.pcgamer.com/tekken-8-reveal)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 22:47:18+00:00

The announcement arrives over seven years after Tekken 7 released in arcades.

## Samurai-era Yakuza spin-off is getting a surprise remake and English localization
 - [https://www.pcgamer.com/samurai-era-yakuza-spin-off-is-getting-a-surprise-remake-and-english-localization](https://www.pcgamer.com/samurai-era-yakuza-spin-off-is-getting-a-surprise-remake-and-english-localization)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 22:42:11+00:00

Yakuza Ishin is being "rebuilt from the ground up."

## Your car is your only companion in 'driving survival game' Pacific Drive
 - [https://www.pcgamer.com/your-car-is-your-only-companion-in-driving-survival-game-pacific-drive](https://www.pcgamer.com/your-car-is-your-only-companion-in-driving-survival-game-pacific-drive)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 22:41:05+00:00

In this "road-like" you drive through a dangerous exclusion zone in "a fully customizable car that develops its own quirks."

## A huge nerf to one of Destiny 2's most powerful exotics got left off today's patch notes
 - [https://www.pcgamer.com/a-huge-nerf-to-one-of-destiny-2s-most-powerful-exotics-got-left-off-todays-patch-notes](https://www.pcgamer.com/a-huge-nerf-to-one-of-destiny-2s-most-powerful-exotics-got-left-off-todays-patch-notes)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 21:46:47+00:00

The Loreley Splendor Helm is splendid no longer.

## This Wipeout-style anti-gravity racing game looks like a literal blast
 - [https://www.pcgamer.com/this-wipeout-style-anti-gravity-racing-game-looks-like-a-literal-blast](https://www.pcgamer.com/this-wipeout-style-anti-gravity-racing-game-looks-like-a-literal-blast)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 20:19:44+00:00

Turbo Force will sport online competitions and a track editor when it launches next year.

## This Italian horror game has one of the weirdest art styles I've seen this year
 - [https://www.pcgamer.com/this-italian-horror-game-has-one-of-the-weirdest-art-styles-ive-seen-this-year](https://www.pcgamer.com/this-italian-horror-game-has-one-of-the-weirdest-art-styles-ive-seen-this-year)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 19:49:12+00:00

Saturnalia's strange color palette and jittery animations stand out.

## Yakuza spin-off Judgment and its sequel are coming to PC
 - [https://www.pcgamer.com/yakuza-spin-off-judgment-and-its-sequel-are-coming-to-pc](https://www.pcgamer.com/yakuza-spin-off-judgment-and-its-sequel-are-coming-to-pc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 19:21:34+00:00

After years relegated to console exclusivity, the Yakuza series spin-offs just got PC ESRB ratings.

## Disney Dreamlight Valley: The secret trick for crossing blocked bridges
 - [https://www.pcgamer.com/disney-dreamlight-valley-the-secret-trick-for-crossing-blocked-bridges](https://www.pcgamer.com/disney-dreamlight-valley-the-secret-trick-for-crossing-blocked-bridges)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 18:49:43+00:00

Access some areas of the Disney Dreamlight Valley map before you're supposed to with one little trick.

## How HDMI Technology Is Bringing Gaming Features To More Gamers
 - [https://www.pcgamer.com/how-hdmi-technology-is-bringing-gaming-features-to-more-gamers](https://www.pcgamer.com/how-hdmi-technology-is-bringing-gaming-features-to-more-gamers)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 18:29:48+00:00

Jeff Park, CTO of HDMI LA, discusses how the latest HDMI spec makes gaming more accessible.

## Triangle Strategy comes to PC next month as our strategy RPG cup overfloweth
 - [https://www.pcgamer.com/triangle-strategy-comes-to-pc-next-month-as-our-strategy-rpg-cup-overfloweth](https://www.pcgamer.com/triangle-strategy-comes-to-pc-next-month-as-our-strategy-rpg-cup-overfloweth)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 18:09:04+00:00

Too many tactics games, not enough time: a great problem to have.

## Check out Half Life 2 running on a Steam Deck that never was
 - [https://www.pcgamer.com/check-out-half-life-2-running-on-a-steam-deck-that-never-was](https://www.pcgamer.com/check-out-half-life-2-running-on-a-steam-deck-that-never-was)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 16:20:37+00:00

Valve has been showing off its Steam Deck prototypes as part of the device's launch in Asia.

## The latest RTX 4090 number-porn rumour suggests a GPU with more than 75B transistors
 - [https://www.pcgamer.com/nvidia-rtx-4090-75b-transistors-rumour](https://www.pcgamer.com/nvidia-rtx-4090-75b-transistors-rumour)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 15:52:02+00:00

If true, Nvidia will be really pushing the reticle limit of GPU production with the new Lovelace generation flagship.

## The latest RTX 4090 number-porn rumour suggests a GPU with more than 75B transistors
 - [https://www.pcgamer.com/the-latest-rtx-4090-number-porn-rumour-suggests-a-gpu-with-more-than-75b-transistors](https://www.pcgamer.com/the-latest-rtx-4090-number-porn-rumour-suggests-a-gpu-with-more-than-75b-transistors)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 15:44:40+00:00

If true, Nvidia will be really pushing the reticle limit of GPU production with the new Lovelace generation flagship.

## Bully Maguire pushes his way into Spider-Man Remastered
 - [https://www.pcgamer.com/bully-maguire-has-pushed-his-way-into-spider-man-remastered](https://www.pcgamer.com/bully-maguire-has-pushed-his-way-into-spider-man-remastered)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 15:40:26+00:00

I'm really gonna enjoy this!

## Valheim Mistlands: Everything we know so far
 - [https://www.pcgamer.com/valheim-mistlands-update-release-date](https://www.pcgamer.com/valheim-mistlands-update-release-date)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 15:37:51+00:00

From the new biome to new weapons.

## Discord integration with Xbox is now live for everyone
 - [https://www.pcgamer.com/discord-integration-with-xbox-is-now-live-for-everyone](https://www.pcgamer.com/discord-integration-with-xbox-is-now-live-for-everyone)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 15:31:38+00:00

Now all our Xbox friends can join us in voice chat.

## Best gaming laptops in 2022
 - [https://www.pcgamer.com/best-gaming-laptop](https://www.pcgamer.com/best-gaming-laptop)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 15:10:01+00:00

The best gaming laptop doesn't compromise on portability and performance.

## Begin and end office rivalries with Checkbox Olympics
 - [https://www.pcgamer.com/begin-or-end-office-rivalries-with-checkbox-olympics](https://www.pcgamer.com/begin-or-end-office-rivalries-with-checkbox-olympics)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 14:47:13+00:00

So, Brian from accounts, we meet again.

## Jeweller spends over 700 hours recreating Warcraft's most legendary blade in gold and silver
 - [https://www.pcgamer.com/jeweller-spends-over-700-hours-recreating-warcrafts-most-legendary-blade-in-gold-and-silver](https://www.pcgamer.com/jeweller-spends-over-700-hours-recreating-warcrafts-most-legendary-blade-in-gold-and-silver)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 13:49:41+00:00

A 'wow' is appropriate.

## The remake of the XIII remake is out and looks a hundred times better
 - [https://www.pcgamer.com/the-remake-of-the-xiii-remake-is-out-and-looks-a-hundred-times-better](https://www.pcgamer.com/the-remake-of-the-xiii-remake-is-out-and-looks-a-hundred-times-better)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 13:16:29+00:00

Remakeception.

## Babylon's Fall to close after less than a year live
 - [https://www.pcgamer.com/babylons-fall-to-close-after-less-than-a-year-live](https://www.pcgamer.com/babylons-fall-to-close-after-less-than-a-year-live)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 12:01:39+00:00

Babylon's fallen and it can't get up.

## Ubisoft wants to stop making games that try to be all things to all people
 - [https://www.pcgamer.com/ubisoft-wants-to-stop-making-games-that-try-to-be-all-things-to-all-people](https://www.pcgamer.com/ubisoft-wants-to-stop-making-games-that-try-to-be-all-things-to-all-people)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 11:39:39+00:00

'We're not making the one game for everybody, but we're making a game for you'.

## Average graphics card prices have halved since the start of 2022
 - [https://www.pcgamer.com/average-graphics-card-prices-have-halved-since-the-start-of-2022](https://www.pcgamer.com/average-graphics-card-prices-have-halved-since-the-start-of-2022)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 11:34:30+00:00

The data points over the last couple of years are fascinating, but I doubt we'll ever see average pricing at 2019 levels again.

## The best builds for Dori in Genshin Impact
 - [https://www.pcgamer.com/genshin-impact-dori-build-banner](https://www.pcgamer.com/genshin-impact-dori-build-banner)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 11:23:28+00:00

A great setup for Sumeru's four-star mastermind merchant.

## Your Raptor Lake PC will wake as you walk up to it and sleep when you leave
 - [https://www.pcgamer.com/intel-wifi-sensing-raptor-lake](https://www.pcgamer.com/intel-wifi-sensing-raptor-lake)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 11:20:54+00:00

Using only standard Wi-Fi technology.

## Best SSD for gaming in 2022
 - [https://www.pcgamer.com/best-ssd-for-gaming](https://www.pcgamer.com/best-ssd-for-gaming)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 11:08:31+00:00

Give your gaming PC a serious speed boost with the best SSD for gaming.

## Where to find Shadows of Doom in World of Wrath of the Lich King Classic
 - [https://www.pcgamer.com/world-of-warcraft-wow-shadows-of-doom](https://www.pcgamer.com/world-of-warcraft-wow-shadows-of-doom)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 11:07:37+00:00

These elite enemies arrived with the Scourge invasion.

## Best external SSD for gaming on PC, PS5, and Xbox Series X
 - [https://www.pcgamer.com/best-external-ssd-for-game-storage](https://www.pcgamer.com/best-external-ssd-for-game-storage)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 10:38:18+00:00

Bag one of the best USB Type-C SSDs for game storage on a PC or console.

## Today's Wordle 451 answer and hint: Tuesday, September 13
 - [https://www.pcgamer.com/todays-wordle-451-answer-hint](https://www.pcgamer.com/todays-wordle-451-answer-hint)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 07:01:28+00:00

Wordle today: The solution and a hint for Tuesday's puzzle.

## A new browser-in-the-browser attack threatens Steam users
 - [https://www.pcgamer.com/a-new-browser-in-the-browser-attack-threatens-steam-users](https://www.pcgamer.com/a-new-browser-in-the-browser-attack-threatens-steam-users)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 05:02:58+00:00

Going after your virtual goods.

## Those coffin office chairs aren't real, but they should be
 - [https://www.pcgamer.com/those-coffin-office-chairs-arent-real-but-they-should-be](https://www.pcgamer.com/those-coffin-office-chairs-arent-real-but-they-should-be)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 03:24:46+00:00

A plea to stop it with the race car and bring in the coffice chair.

## Zotac's RTX 4090 smiles for the camera
 - [https://www.pcgamer.com/zotacs-rtx-4090-smiles-for-the-camera](https://www.pcgamer.com/zotacs-rtx-4090-smiles-for-the-camera)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 03:19:37+00:00

It's got some curves.

## Unreleased Meta VR headset possibly leaked after found discarded in Hotel
 - [https://www.pcgamer.com/unreleased-meta-vr-headset-possibly-leaked-after-found-discarded-in-hotel](https://www.pcgamer.com/unreleased-meta-vr-headset-possibly-leaked-after-found-discarded-in-hotel)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 01:40:11+00:00

The video looks pretty convincing.

## 343 Industries founder leaves company due to family medical issue
 - [https://www.pcgamer.com/343-industries-founder-leaves-company-due-to-family-medical-issue](https://www.pcgamer.com/343-industries-founder-leaves-company-due-to-family-medical-issue)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-09-13 00:31:07+00:00

Bonnie Ross founded the Halo successor studio after Bungie's split with Microsoft in 2007.


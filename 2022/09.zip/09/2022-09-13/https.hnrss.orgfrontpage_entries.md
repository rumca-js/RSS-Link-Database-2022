# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Is Peer Review a Good Idea? (2020)
 - [https://www.journals.uchicago.edu/doi/10.1093/bjps/axz029](https://www.journals.uchicago.edu/doi/10.1093/bjps/axz029)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 23:20:38+00:00

<p>Article URL: <a href="https://www.journals.uchicago.edu/doi/10.1093/bjps/axz029">https://www.journals.uchicago.edu/doi/10.1093/bjps/axz029</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32831386">https://news.ycombinator.com/item?id=32831386</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## “Secrets” about the consumer audio business you may find interesting
 - [https://www.audiosciencereview.com/forum/index.php?threads%2Fsecrets-about-the-consumer-audio-business-you-may-find-interesting.37344%2F](https://www.audiosciencereview.com/forum/index.php?threads%2Fsecrets-about-the-consumer-audio-business-you-may-find-interesting.37344%2F)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 22:21:22+00:00

<p>Article URL: <a href="https://www.audiosciencereview.com/forum/index.php?threads%2Fsecrets-about-the-consumer-audio-business-you-may-find-interesting.37344%2F">https://www.audiosciencereview.com/forum/index.php?threads%2Fsecrets-about-the-consumer-audio-business-you-may-find-interesting.37344%2F</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32830916">https://news.ycombinator.com/item?id=32830916</a></p>
<p>Points: 47</p>
<p># Comments: 11</p>

## Show HN: BoldContacts Mobile App for Alzheimer's, Parkinson's, ALS, MS, MD
 - [https://github.com/SixArm/BoldContacts](https://github.com/SixArm/BoldContacts)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 21:18:10+00:00

<p>Article URL: <a href="https://github.com/SixArm/BoldContacts">https://github.com/SixArm/BoldContacts</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32830294">https://news.ycombinator.com/item?id=32830294</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Contentedge (YC W17) is hiring to build AI content writing software for SEO
 - [https://www.contentedge.com/?pg=jobs](https://www.contentedge.com/?pg=jobs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 21:00:39+00:00

<p>Article URL: <a href="https://www.contentedge.com/?pg=jobs">https://www.contentedge.com/?pg=jobs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32830123">https://news.ycombinator.com/item?id=32830123</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Diablo 2, Diablo 4, and Single Player: An open letter to Blizzard
 - [https://www.purediablo.com/diablo-2-diablo-4-and-single-player/](https://www.purediablo.com/diablo-2-diablo-4-and-single-player/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 20:58:13+00:00

<p>Article URL: <a href="https://www.purediablo.com/diablo-2-diablo-4-and-single-player/">https://www.purediablo.com/diablo-2-diablo-4-and-single-player/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32830102">https://news.ycombinator.com/item?id=32830102</a></p>
<p>Points: 11</p>
<p># Comments: 9</p>

## US Treasury FAQ on Cyber-Related Sanctions
 - [https://home.treasury.gov/policy-issues/financial-sanctions/faqs/1076](https://home.treasury.gov/policy-issues/financial-sanctions/faqs/1076)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 20:57:09+00:00

<p>Article URL: <a href="https://home.treasury.gov/policy-issues/financial-sanctions/faqs/1076">https://home.treasury.gov/policy-issues/financial-sanctions/faqs/1076</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32830085">https://news.ycombinator.com/item?id=32830085</a></p>
<p>Points: 12</p>
<p># Comments: 2</p>

## Rust stabilizes generic associated types
 - [https://github.com/rust-lang/rust/pull/96709](https://github.com/rust-lang/rust/pull/96709)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 20:30:16+00:00

<p>Article URL: <a href="https://github.com/rust-lang/rust/pull/96709">https://github.com/rust-lang/rust/pull/96709</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32829806">https://news.ycombinator.com/item?id=32829806</a></p>
<p>Points: 26</p>
<p># Comments: 0</p>

## The Next Incarnation of EDA
 - [https://semiengineering.com/the-next-incarnation-of-eda/](https://semiengineering.com/the-next-incarnation-of-eda/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 20:05:32+00:00

<p>Article URL: <a href="https://semiengineering.com/the-next-incarnation-of-eda/">https://semiengineering.com/the-next-incarnation-of-eda/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32829553">https://news.ycombinator.com/item?id=32829553</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Twitter trackers jeopardize military aircraft
 - [https://www.usni.org/magazines/proceedings/2022/september/twitter-trackers-jeopardize-military-aircraft-0](https://www.usni.org/magazines/proceedings/2022/september/twitter-trackers-jeopardize-military-aircraft-0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 19:10:26+00:00

<p>Article URL: <a href="https://www.usni.org/magazines/proceedings/2022/september/twitter-trackers-jeopardize-military-aircraft-0">https://www.usni.org/magazines/proceedings/2022/september/twitter-trackers-jeopardize-military-aircraft-0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32828902">https://news.ycombinator.com/item?id=32828902</a></p>
<p>Points: 10</p>
<p># Comments: 13</p>

## Show HN: Query SQLite files stored in S3
 - [https://github.com/litements/s3sqlite](https://github.com/litements/s3sqlite)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 19:03:08+00:00

<p>Article URL: <a href="https://github.com/litements/s3sqlite">https://github.com/litements/s3sqlite</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32828799">https://news.ycombinator.com/item?id=32828799</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Increase: Banking API
 - [https://increase.com/](https://increase.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 18:53:26+00:00

<p>Article URL: <a href="https://increase.com/">https://increase.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32828669">https://news.ycombinator.com/item?id=32828669</a></p>
<p>Points: 34</p>
<p># Comments: 10</p>

## When to use Bazel?
 - [https://earthly.dev/blog/bazel-build/](https://earthly.dev/blog/bazel-build/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 18:46:21+00:00

<p>Article URL: <a href="https://earthly.dev/blog/bazel-build/">https://earthly.dev/blog/bazel-build/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32828584">https://news.ycombinator.com/item?id=32828584</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Byte Magazine: Declarative Languages (1985)
 - [https://archive.org/details/byte-magazine-1985-08](https://archive.org/details/byte-magazine-1985-08)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 18:45:13+00:00

<p>Article URL: <a href="https://archive.org/details/byte-magazine-1985-08">https://archive.org/details/byte-magazine-1985-08</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32828569">https://news.ycombinator.com/item?id=32828569</a></p>
<p>Points: 31</p>
<p># Comments: 1</p>

## Mini Metroidvania in 13KB of JavaScript
 - [https://arineonshark.itch.io/infernal-throne](https://arineonshark.itch.io/infernal-throne)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 18:25:05+00:00

<p>Article URL: <a href="https://arineonshark.itch.io/infernal-throne">https://arineonshark.itch.io/infernal-throne</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32828309">https://news.ycombinator.com/item?id=32828309</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## W4 Games raises $8.5M to support Godot Engine growth
 - [https://w4games.com/2022/09/13/w4-games-raises-8-5-million-to-support-godot-engine-growth/](https://w4games.com/2022/09/13/w4-games-raises-8-5-million-to-support-godot-engine-growth/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 17:46:29+00:00

<p>Article URL: <a href="https://w4games.com/2022/09/13/w4-games-raises-8-5-million-to-support-godot-engine-growth/">https://w4games.com/2022/09/13/w4-games-raises-8-5-million-to-support-godot-engine-growth/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32827762">https://news.ycombinator.com/item?id=32827762</a></p>
<p>Points: 119</p>
<p># Comments: 17</p>

## Gödel, Escher, Bach: an in-depth explainer
 - [https://www.alignmentforum.org/posts/wwNnzaPnB5a48K86N/book-review-goedel-escher-bach-an-in-depth-explainer](https://www.alignmentforum.org/posts/wwNnzaPnB5a48K86N/book-review-goedel-escher-bach-an-in-depth-explainer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 17:12:43+00:00

<p>Article URL: <a href="https://www.alignmentforum.org/posts/wwNnzaPnB5a48K86N/book-review-goedel-escher-bach-an-in-depth-explainer">https://www.alignmentforum.org/posts/wwNnzaPnB5a48K86N/book-review-goedel-escher-bach-an-in-depth-explainer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32827209">https://news.ycombinator.com/item?id=32827209</a></p>
<p>Points: 46</p>
<p># Comments: 20</p>

## Patreon Lays off 17% of Staff
 - [https://www.instagram.com/p/CidAMM7pQ7u/](https://www.instagram.com/p/CidAMM7pQ7u/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 16:36:27+00:00

<p>Article URL: <a href="https://www.instagram.com/p/CidAMM7pQ7u/">https://www.instagram.com/p/CidAMM7pQ7u/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32826610">https://news.ycombinator.com/item?id=32826610</a></p>
<p>Points: 65</p>
<p># Comments: 47</p>

## Patreon Lays off 17% of Staff
 - [https://blog.patreon.com/a-note-from-jack](https://blog.patreon.com/a-note-from-jack)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 16:36:27+00:00

<p>Article URL: <a href="https://blog.patreon.com/a-note-from-jack">https://blog.patreon.com/a-note-from-jack</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32826610">https://news.ycombinator.com/item?id=32826610</a></p>
<p>Points: 271</p>
<p># Comments: 253</p>

## FB feed is 98% suggested pages and barely any friend's posts
 - [https://old.reddit.com/r/facebook/comments/tvqddc/fb_feed_is_98_suggested_pages_and_barely_any/](https://old.reddit.com/r/facebook/comments/tvqddc/fb_feed_is_98_suggested_pages_and_barely_any/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 16:25:25+00:00

<p>Article URL: <a href="https://old.reddit.com/r/facebook/comments/tvqddc/fb_feed_is_98_suggested_pages_and_barely_any/">https://old.reddit.com/r/facebook/comments/tvqddc/fb_feed_is_98_suggested_pages_and_barely_any/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32826437">https://news.ycombinator.com/item?id=32826437</a></p>
<p>Points: 216</p>
<p># Comments: 99</p>

## Scaling Git’s garbage collection
 - [https://github.blog/2022-09-13-scaling-gits-garbage-collection/](https://github.blog/2022-09-13-scaling-gits-garbage-collection/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 16:02:11+00:00

<p>Article URL: <a href="https://github.blog/2022-09-13-scaling-gits-garbage-collection/">https://github.blog/2022-09-13-scaling-gits-garbage-collection/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32826072">https://news.ycombinator.com/item?id=32826072</a></p>
<p>Points: 23</p>
<p># Comments: 3</p>

## X-Plane 12 Early Access
 - [https://www.x-plane.com/desktop/buy-it/](https://www.x-plane.com/desktop/buy-it/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 15:39:24+00:00

<p>Article URL: <a href="https://www.x-plane.com/desktop/buy-it/">https://www.x-plane.com/desktop/buy-it/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32825732">https://news.ycombinator.com/item?id=32825732</a></p>
<p>Points: 30</p>
<p># Comments: 15</p>

## Factorio is coming to Nintendo Switch
 - [https://www.factorio.com/blog/post/factorio-on-nintendo-switch](https://www.factorio.com/blog/post/factorio-on-nintendo-switch)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 15:26:36+00:00

<p>Article URL: <a href="https://www.factorio.com/blog/post/factorio-on-nintendo-switch">https://www.factorio.com/blog/post/factorio-on-nintendo-switch</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32825543">https://news.ycombinator.com/item?id=32825543</a></p>
<p>Points: 179</p>
<p># Comments: 58</p>

## Woman sues after DNA from rape kit used to arrest her
 - [https://nypost.com/2022/09/13/woman-sues-after-dna-from-rape-kit-used-to-arrest-her/](https://nypost.com/2022/09/13/woman-sues-after-dna-from-rape-kit-used-to-arrest-her/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 15:05:45+00:00

<p>Article URL: <a href="https://nypost.com/2022/09/13/woman-sues-after-dna-from-rape-kit-used-to-arrest-her/">https://nypost.com/2022/09/13/woman-sues-after-dna-from-rape-kit-used-to-arrest-her/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32825247">https://news.ycombinator.com/item?id=32825247</a></p>
<p>Points: 50</p>
<p># Comments: 18</p>

## Poll: Should you work for yourself or take a full-time job?
 - [https://news.ycombinator.com/item?id=32825178](https://news.ycombinator.com/item?id=32825178)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 15:01:10+00:00

<p>I know it will depend on the person, I'm just curious as to which work arrangement that you all find to be more rewarding in terms of work-life-balance, pay, job satisfaction, etc. By "Work for yourself" I mean freelancing, independent contracting, building a profitable application, etc.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32825178">https://news.ycombinator.com/item?id=32825178</a></p>
<p>Points: 13</p>
<p># Comments: 23</p>

## Grafana Labs launches free incident management tool in Grafana Cloud
 - [https://grafana.com/blog/2022/09/13/grafana-incident-for-incident-management-is-now-generally-available-in-grafana-cloud/](https://grafana.com/blog/2022/09/13/grafana-incident-for-incident-management-is-now-generally-available-in-grafana-cloud/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 14:54:59+00:00

<p>Article URL: <a href="https://grafana.com/blog/2022/09/13/grafana-incident-for-incident-management-is-now-generally-available-in-grafana-cloud/">https://grafana.com/blog/2022/09/13/grafana-incident-for-incident-management-is-now-generally-available-in-grafana-cloud/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32825070">https://news.ycombinator.com/item?id=32825070</a></p>
<p>Points: 32</p>
<p># Comments: 5</p>

## Senior Engineers Are Living in the Future
 - [https://www.zerobanana.com/essays/living-in-the-future/](https://www.zerobanana.com/essays/living-in-the-future/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 14:40:27+00:00

<p>Article URL: <a href="https://www.zerobanana.com/essays/living-in-the-future/">https://www.zerobanana.com/essays/living-in-the-future/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32824872">https://news.ycombinator.com/item?id=32824872</a></p>
<p>Points: 56</p>
<p># Comments: 32</p>

## What Is Kubernetes HPA and How Can It Help You Save on the Cloud?
 - [https://cast.ai/blog/what-is-kubernetes-hpa-and-how-can-it-help-you-save-on-the-cloud/](https://cast.ai/blog/what-is-kubernetes-hpa-and-how-can-it-help-you-save-on-the-cloud/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 14:27:23+00:00

<p>Article URL: <a href="https://cast.ai/blog/what-is-kubernetes-hpa-and-how-can-it-help-you-save-on-the-cloud/">https://cast.ai/blog/what-is-kubernetes-hpa-and-how-can-it-help-you-save-on-the-cloud/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32824698">https://news.ycombinator.com/item?id=32824698</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Mudge Twitter Whistleblower Testimony
 - [https://www.judiciary.senate.gov/meetings/data-security-at-risk-testimony-from-a-twitter-whistleblower](https://www.judiciary.senate.gov/meetings/data-security-at-risk-testimony-from-a-twitter-whistleblower)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 14:11:18+00:00

<p>Article URL: <a href="https://www.judiciary.senate.gov/meetings/data-security-at-risk-testimony-from-a-twitter-whistleblower">https://www.judiciary.senate.gov/meetings/data-security-at-risk-testimony-from-a-twitter-whistleblower</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32824504">https://news.ycombinator.com/item?id=32824504</a></p>
<p>Points: 14</p>
<p># Comments: 5</p>

## The SSD Edition: 2022 Drive Stats Mid-Year Review
 - [https://www.backblaze.com/blog/ssd-drive-stats-mid-2022-review/](https://www.backblaze.com/blog/ssd-drive-stats-mid-2022-review/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 14:06:04+00:00

<p>Article URL: <a href="https://www.backblaze.com/blog/ssd-drive-stats-mid-2022-review/">https://www.backblaze.com/blog/ssd-drive-stats-mid-2022-review/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32824451">https://news.ycombinator.com/item?id=32824451</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Software fees to make up 10% of John Deere's revenues by 2030
 - [https://www.theregister.com/2022/09/12/deere_software_revenues/](https://www.theregister.com/2022/09/12/deere_software_revenues/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 14:00:31+00:00

<p>Article URL: <a href="https://www.theregister.com/2022/09/12/deere_software_revenues/">https://www.theregister.com/2022/09/12/deere_software_revenues/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32824384">https://news.ycombinator.com/item?id=32824384</a></p>
<p>Points: 48</p>
<p># Comments: 18</p>

## AiSupervision (YC W22) is hiring a back-end software engineer (Remote)
 - [https://www.aisupervision.com/careers/back-end-software-engineer](https://www.aisupervision.com/careers/back-end-software-engineer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 13:39:03+00:00

<p>Article URL: <a href="https://www.aisupervision.com/careers/back-end-software-engineer">https://www.aisupervision.com/careers/back-end-software-engineer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32824130">https://news.ycombinator.com/item?id=32824130</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## mRNA-LNP inhibits adaptive immune response, alters immune fitness inheritably
 - [https://pubmed.ncbi.nlm.nih.gov/36054264/](https://pubmed.ncbi.nlm.nih.gov/36054264/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 13:33:44+00:00

<p>Article URL: <a href="https://pubmed.ncbi.nlm.nih.gov/36054264/">https://pubmed.ncbi.nlm.nih.gov/36054264/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32824054">https://news.ycombinator.com/item?id=32824054</a></p>
<p>Points: 149</p>
<p># Comments: 121</p>

## The Last Person Standing in the Floppy Disk Business
 - [https://eyeondesign.aiga.org/we-spoke-with-the-last-person-standing-in-the-floppy-disk-business/](https://eyeondesign.aiga.org/we-spoke-with-the-last-person-standing-in-the-floppy-disk-business/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 13:32:36+00:00

<p>Article URL: <a href="https://eyeondesign.aiga.org/we-spoke-with-the-last-person-standing-in-the-floppy-disk-business/">https://eyeondesign.aiga.org/we-spoke-with-the-last-person-standing-in-the-floppy-disk-business/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32824038">https://news.ycombinator.com/item?id=32824038</a></p>
<p>Points: 74</p>
<p># Comments: 18</p>

## Show HN: pg_netstat, a Postgres extension to monitor database network traffic
 - [https://github.com/supabase/pg_netstat](https://github.com/supabase/pg_netstat)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 12:51:18+00:00

<p>pg_netstat is a Postgres extension to monitor database network traffic. It uses libpcap to capture packets and aggregates at user-specified interval.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32823589">https://news.ycombinator.com/item?id=32823589</a></p>
<p>Points: 26</p>
<p># Comments: 3</p>

## The search for dirt on Mudge
 - [https://www.newyorker.com/news/news-desk/the-search-for-dirt-on-the-twitter-whistle-blower](https://www.newyorker.com/news/news-desk/the-search-for-dirt-on-the-twitter-whistle-blower)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 12:46:14+00:00

<p>Article URL: <a href="https://www.newyorker.com/news/news-desk/the-search-for-dirt-on-the-twitter-whistle-blower">https://www.newyorker.com/news/news-desk/the-search-for-dirt-on-the-twitter-whistle-blower</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32823548">https://news.ycombinator.com/item?id=32823548</a></p>
<p>Points: 29</p>
<p># Comments: 6</p>

## Some New HTTP Verbs
 - [https://shkspr.mobi/blog/2022/09/some-new-http-verbs/](https://shkspr.mobi/blog/2022/09/some-new-http-verbs/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 12:03:04+00:00

<p>Article URL: <a href="https://shkspr.mobi/blog/2022/09/some-new-http-verbs/">https://shkspr.mobi/blog/2022/09/some-new-http-verbs/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32823201">https://news.ycombinator.com/item?id=32823201</a></p>
<p>Points: 35</p>
<p># Comments: 35</p>

## Unfortunately for the Star, that person was their fashion editor
 - [https://twitter.com/pdmcleod/status/1569388980315033601](https://twitter.com/pdmcleod/status/1569388980315033601)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 12:02:19+00:00

<p>Article URL: <a href="https://twitter.com/pdmcleod/status/1569388980315033601">https://twitter.com/pdmcleod/status/1569388980315033601</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32823193">https://news.ycombinator.com/item?id=32823193</a></p>
<p>Points: 37</p>
<p># Comments: 7</p>

## Cake: C23 Front End and Transpiler C23 – C99
 - [https://github.com/thradams/cake](https://github.com/thradams/cake)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 11:54:10+00:00

<p>Article URL: <a href="https://github.com/thradams/cake">https://github.com/thradams/cake</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32823118">https://news.ycombinator.com/item?id=32823118</a></p>
<p>Points: 13</p>
<p># Comments: 3</p>

## European natural gas imports and storage reserves
 - [https://www.bruegel.org/dataset/european-natural-gas-imports](https://www.bruegel.org/dataset/european-natural-gas-imports)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 11:31:13+00:00

<p>Article URL: <a href="https://www.bruegel.org/dataset/european-natural-gas-imports">https://www.bruegel.org/dataset/european-natural-gas-imports</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32822944">https://news.ycombinator.com/item?id=32822944</a></p>
<p>Points: 17</p>
<p># Comments: 3</p>

## Weightless: Parabolic Flight on an A310
 - [https://www.flightradar24.com/blog/parabolic-flight/](https://www.flightradar24.com/blog/parabolic-flight/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 11:26:36+00:00

<p>Article URL: <a href="https://www.flightradar24.com/blog/parabolic-flight/">https://www.flightradar24.com/blog/parabolic-flight/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32822910">https://news.ycombinator.com/item?id=32822910</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Scala Isn't Fun Anymore
 - [https://alexn.org/blog/2022/09/09/scala-isnt-fun-anymore/](https://alexn.org/blog/2022/09/09/scala-isnt-fun-anymore/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 10:44:47+00:00

<p>Article URL: <a href="https://alexn.org/blog/2022/09/09/scala-isnt-fun-anymore/">https://alexn.org/blog/2022/09/09/scala-isnt-fun-anymore/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32822609">https://news.ycombinator.com/item?id=32822609</a></p>
<p>Points: 32</p>
<p># Comments: 21</p>

## Show HN: Tombl – Easily query .toml files from bash
 - [https://github.com/snyball/tombl](https://github.com/snyball/tombl)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 09:58:30+00:00

<p>Article URL: <a href="https://github.com/snyball/tombl">https://github.com/snyball/tombl</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32822326">https://news.ycombinator.com/item?id=32822326</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Don't compare yourself to other entrepreneurs
 - [https://www.petecodes.io/dont-compare-yourself-to-others/](https://www.petecodes.io/dont-compare-yourself-to-others/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 09:56:49+00:00

<p>Article URL: <a href="https://www.petecodes.io/dont-compare-yourself-to-others/">https://www.petecodes.io/dont-compare-yourself-to-others/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32822313">https://news.ycombinator.com/item?id=32822313</a></p>
<p>Points: 18</p>
<p># Comments: 2</p>

## Open Props: Tailwind Alternative from Chrome Dev Team
 - [https://open-props.style/](https://open-props.style/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 09:44:59+00:00

<p>Article URL: <a href="https://open-props.style/">https://open-props.style/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32822257">https://news.ycombinator.com/item?id=32822257</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## A pair of Linux kernel modules using Rust
 - [https://lwn.net/SubscriberLink/907685/0290fbfe1ba855ea/](https://lwn.net/SubscriberLink/907685/0290fbfe1ba855ea/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 09:12:21+00:00

<p>Article URL: <a href="https://lwn.net/SubscriberLink/907685/0290fbfe1ba855ea/">https://lwn.net/SubscriberLink/907685/0290fbfe1ba855ea/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32822082">https://news.ycombinator.com/item?id=32822082</a></p>
<p>Points: 25</p>
<p># Comments: 6</p>

## Modula-2 Compilers on CP/M
 - [https://techtinkering.com/articles/modula-2-compilers-on-cpm/](https://techtinkering.com/articles/modula-2-compilers-on-cpm/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 08:51:34+00:00

<p>Article URL: <a href="https://techtinkering.com/articles/modula-2-compilers-on-cpm/">https://techtinkering.com/articles/modula-2-compilers-on-cpm/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32821990">https://news.ycombinator.com/item?id=32821990</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Why peer to peer digital payment system UPI should remain free in India
 - [https://www.capitalmind.in/2022/09/why-upi-should-be-free/](https://www.capitalmind.in/2022/09/why-upi-should-be-free/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 08:43:29+00:00

<p>Article URL: <a href="https://www.capitalmind.in/2022/09/why-upi-should-be-free/">https://www.capitalmind.in/2022/09/why-upi-should-be-free/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32821955">https://news.ycombinator.com/item?id=32821955</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Entity Resolution: Reflections on the most common data science challenge
 - [https://tilores.io/content/Entity-Resolution-Reflections-on-the-most-common-data-science-challenge](https://tilores.io/content/Entity-Resolution-Reflections-on-the-most-common-data-science-challenge)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 08:30:28+00:00

<p>Article URL: <a href="https://tilores.io/content/Entity-Resolution-Reflections-on-the-most-common-data-science-challenge">https://tilores.io/content/Entity-Resolution-Reflections-on-the-most-common-data-science-challenge</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32821888">https://news.ycombinator.com/item?id=32821888</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Europe gas storage reserves – by country, updated daily
 - [https://viborc.com/europe-gas-storage-reserves-capacities-by-country-daily/](https://viborc.com/europe-gas-storage-reserves-capacities-by-country-daily/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 08:21:24+00:00

<p>Article URL: <a href="https://viborc.com/europe-gas-storage-reserves-capacities-by-country-daily/">https://viborc.com/europe-gas-storage-reserves-capacities-by-country-daily/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32821844">https://news.ycombinator.com/item?id=32821844</a></p>
<p>Points: 28</p>
<p># Comments: 27</p>

## Jean-Luc Godard has died
 - [https://www.lemonde.fr/en/obituaries/article/2022/09/13/jean-luc-godard-legendary-french-film-director-dies-aged-91_5996746_15.html](https://www.lemonde.fr/en/obituaries/article/2022/09/13/jean-luc-godard-legendary-french-film-director-dies-aged-91_5996746_15.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 08:09:55+00:00

<p>Article URL: <a href="https://www.lemonde.fr/en/obituaries/article/2022/09/13/jean-luc-godard-legendary-french-film-director-dies-aged-91_5996746_15.html">https://www.lemonde.fr/en/obituaries/article/2022/09/13/jean-luc-godard-legendary-french-film-director-dies-aged-91_5996746_15.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32821761">https://news.ycombinator.com/item?id=32821761</a></p>
<p>Points: 57</p>
<p># Comments: 10</p>

## HAProxy: How to temporary disable a back end server using the command line
 - [https://www.claudiokuenzler.com/blog/1240/haproxy-how-to-disable-enable-backend-server-command-line-cli-socket](https://www.claudiokuenzler.com/blog/1240/haproxy-how-to-disable-enable-backend-server-command-line-cli-socket)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 08:03:19+00:00

<p>Article URL: <a href="https://www.claudiokuenzler.com/blog/1240/haproxy-how-to-disable-enable-backend-server-command-line-cli-socket">https://www.claudiokuenzler.com/blog/1240/haproxy-how-to-disable-enable-backend-server-command-line-cli-socket</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32821724">https://news.ycombinator.com/item?id=32821724</a></p>
<p>Points: 16</p>
<p># Comments: 12</p>

## macOS leaves users vulnerable, and unaware of their vulnerability
 - [https://eclecticlight.co/2022/09/13/how-macos-leaves-users-vulnerable-and-unaware-of-their-vulnerability/](https://eclecticlight.co/2022/09/13/how-macos-leaves-users-vulnerable-and-unaware-of-their-vulnerability/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 07:57:52+00:00

<p>Article URL: <a href="https://eclecticlight.co/2022/09/13/how-macos-leaves-users-vulnerable-and-unaware-of-their-vulnerability/">https://eclecticlight.co/2022/09/13/how-macos-leaves-users-vulnerable-and-unaware-of-their-vulnerability/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32821699">https://news.ycombinator.com/item?id=32821699</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Details on new free tier limits on gitlab.com
 - [https://about.gitlab.com/pricing/faq-efficient-free-tier/](https://about.gitlab.com/pricing/faq-efficient-free-tier/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 07:55:56+00:00

<p>Article URL: <a href="https://about.gitlab.com/pricing/faq-efficient-free-tier/">https://about.gitlab.com/pricing/faq-efficient-free-tier/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32821682">https://news.ycombinator.com/item?id=32821682</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Climate change: Six tipping points ‘likely’ to be crossed
 - [https://www.bbc.co.uk/news/science-environment-62838627](https://www.bbc.co.uk/news/science-environment-62838627)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 07:23:04+00:00

<p>Article URL: <a href="https://www.bbc.co.uk/news/science-environment-62838627">https://www.bbc.co.uk/news/science-environment-62838627</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32821528">https://news.ycombinator.com/item?id=32821528</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## The World’s First Hydrogen Trains Started Passenger Service in Germany
 - [https://singularityhub.com/2022/09/12/the-worlds-first-hydrogen-trains-started-passenger-service-in-germany/](https://singularityhub.com/2022/09/12/the-worlds-first-hydrogen-trains-started-passenger-service-in-germany/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 06:36:10+00:00

<p>Article URL: <a href="https://singularityhub.com/2022/09/12/the-worlds-first-hydrogen-trains-started-passenger-service-in-germany/">https://singularityhub.com/2022/09/12/the-worlds-first-hydrogen-trains-started-passenger-service-in-germany/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32821258">https://news.ycombinator.com/item?id=32821258</a></p>
<p>Points: 10</p>
<p># Comments: 6</p>

## Boosters for Young Adults: Risk-Benefit Assessment and Arguments Against Mandate
 - [https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4206070](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4206070)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 05:25:48+00:00

<p>Article URL: <a href="https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4206070">https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4206070</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32820934">https://news.ycombinator.com/item?id=32820934</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Is bin-opening in cockatoos leading to an innovation arms race with humans?
 - [https://www.cell.com/current-biology/fulltext/S0960-9822(22)01285-4](https://www.cell.com/current-biology/fulltext/S0960-9822(22)01285-4)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 05:15:17+00:00

<p>Article URL: <a href="https://www.cell.com/current-biology/fulltext/S0960-9822(22)01285-4">https://www.cell.com/current-biology/fulltext/S0960-9822(22)01285-4</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32820894">https://news.ycombinator.com/item?id=32820894</a></p>
<p>Points: 22</p>
<p># Comments: 4</p>

## Show HN: BrainFlow the library to work with biosensors and neurointerfaces
 - [https://brainflow.org/](https://brainflow.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 05:01:51+00:00

<p>Article URL: <a href="https://brainflow.org/">https://brainflow.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32820822">https://news.ycombinator.com/item?id=32820822</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## The mysterious balancing stones on frozen lakes
 - [https://physicstoday.scitation.org/doi/10.1063/PT.3.5088](https://physicstoday.scitation.org/doi/10.1063/PT.3.5088)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 03:15:54+00:00

<p>Article URL: <a href="https://physicstoday.scitation.org/doi/10.1063/PT.3.5088">https://physicstoday.scitation.org/doi/10.1063/PT.3.5088</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32820299">https://news.ycombinator.com/item?id=32820299</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## The strange behavior of sound through solids
 - [https://www.ias.edu/news/2022/sound-through-solids](https://www.ias.edu/news/2022/sound-through-solids)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 01:32:26+00:00

<p>Article URL: <a href="https://www.ias.edu/news/2022/sound-through-solids">https://www.ias.edu/news/2022/sound-through-solids</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32819733">https://news.ycombinator.com/item?id=32819733</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## A personal list of Rust grievances
 - [https://gist.github.com/brendanzab/d41c3ae485d66c07178749eaeeb9e5f7](https://gist.github.com/brendanzab/d41c3ae485d66c07178749eaeeb9e5f7)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 00:55:50+00:00

<p>Article URL: <a href="https://gist.github.com/brendanzab/d41c3ae485d66c07178749eaeeb9e5f7">https://gist.github.com/brendanzab/d41c3ae485d66c07178749eaeeb9e5f7</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32819444">https://news.ycombinator.com/item?id=32819444</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Planning Go 1.20 Cryptography Work
 - [https://words.filippo.io/dispatches/go1-20/](https://words.filippo.io/dispatches/go1-20/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-09-13 00:10:06+00:00

<p>Article URL: <a href="https://words.filippo.io/dispatches/go1-20/">https://words.filippo.io/dispatches/go1-20/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=32819096">https://news.ycombinator.com/item?id=32819096</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>


# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Exploding the Elektron Analog Rytm MkII
 - [https://www.youtube.com/watch?v=hr5HaVsGPPI](https://www.youtube.com/watch?v=hr5HaVsGPPI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-09-13 00:00:00+00:00

This video is sponsored by Patchwerks, Seattle's synthesizer store. But also yours.
Shop a great selection of gear here! https://shrsl.com/3cs6v 
Let's make a beat on the Elektron Analog Rytm MkII because its fun and good ok?
Watch the final beat in action: https://youtu.be/LrSFyZ2p-iM

00:00 intro
01:12 beat making
17:44 PATCHWERKS ADVERT
18:33 scenes
22:11 FINAL BEAT YEAH

Join me on Patreon and get access to music, presets, samples, and a great community: http://bit.ly/rmrpatreon

Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## 20 Hidden NEW Features in iOS 16
 - [https://www.youtube.com/watch?v=pisqAFvTO-8](https://www.youtube.com/watch?v=pisqAFvTO-8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-09-13 00:00:00+00:00

There are a bunch of hidden cool features nobody is talking about!

⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

▼ Time Stamps: ▼
0:00 - Intro
0:27 - Report Junk for Any Message
0:52 - Haptic Feedback for Keyboard
1:13 - Show Battery Percentage
1:28 - Locked Photo Albums
1:46 - Remove Duplicate Photos
2:09 - Copy & Paste Photo Edits
2:25 - Bulk Edit Photo Metadata
2:47 - Wallpaper Crop
2:59 - View Saved Wi-Fi Passwords
3:19 - View All Known Wi-Fi Networks
3:42 - Merge Duplicate Contacts
4:29 - Contact Lists
5:20 - Share Only Certain Contact Details
5:38 - Dual-Sim Message Filtering
5:52 - Control Center Quick Note
6:00 - Disable Hang Up on Lock
6:26 - Airpod Settings Menu
6:54 - Rapid Security Response
7:30 - Rename Screenshot File
7:48 - New Screenshot Save Options
8:16 - Remove Only Local Copy of File
8:39 - Change Mail Unsend Delay
9:04 - More Forecast Data in Weather App
9:19 - Passkeys

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


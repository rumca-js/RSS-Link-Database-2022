# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Feels Like E3 in September — Tears of the Kingdom, Ragnarok, and Yakuza 8 | Breakout
 - [https://www.youtube.com/watch?v=5mFLRVwy8WI](https://www.youtube.com/watch?v=5mFLRVwy8WI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-09-14 00:00:00+00:00

This week on Breakout we're discussing how all of a sudden it feels like we just got E3 in September.

Featuring Nick Calandra, Marty Sliva, and KC Nwosu, the freeform podcast dives into a bit of our daily lives, the latest games, movies, tv shows and books, the occasional craft beer review and random topics we find interesting.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Mortuary Assistant (Zero Punctuation)
 - [https://www.youtube.com/watch?v=fBc0TSmF85g](https://www.youtube.com/watch?v=fBc0TSmF85g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-09-14 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

This week on Zero Punctuation, Yahtzee reviews The Mortuary Assistant. 

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee and Marty Play Soul Hackers 2 | Post-ZP Stream
 - [https://www.youtube.com/watch?v=At_7rgpyBcI](https://www.youtube.com/watch?v=At_7rgpyBcI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-09-14 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Yahtzee plays two hours of Soul Hackers 2 for today's Post-ZP Stream.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist​

Want to see the next episode a week early? Check out http://www.escapistmagazine.com​ for the latest episodes of your favorite shows.

---



---


The Escapist Merch Store ►►https://teespring.com/stores/the-esca...​
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag​
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## You Suck at Parking | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=Qn8G4IAuhh4](https://www.youtube.com/watch?v=Qn8G4IAuhh4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-09-14 00:00:00+00:00

Elise Avery reviews You Suck at Parking, developed by Happy Volcano. 

You Suck at Parking on Steam: https://store.steampowered.com/app/837880/You_Suck_at_Parking/

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Metal: Hellsinger | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=ZKiemJvskjc](https://www.youtube.com/watch?v=ZKiemJvskjc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-09-13 00:00:00+00:00

Jesse Galena reviews Metal: Hellsinger, developed by The Outsiders.

Metal: Hellsinger on Steam: https://store.steampowered.com/app/1061910/Metal_Hellsinger/

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Nioh - Deep in the Shadows | The Editor's Hour
 - [https://www.youtube.com/watch?v=BHYzQn1csDA](https://www.youtube.com/watch?v=BHYzQn1csDA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-09-13 00:00:00+00:00

For The Editor's Hour today, Nick's starting his playthrough of NIOH..

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Rings of Power Finds its Footing | The Recap
 - [https://www.youtube.com/watch?v=uLuSZBDMwEI](https://www.youtube.com/watch?v=uLuSZBDMwEI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-09-13 00:00:00+00:00

This week on The Recap, we discuss the third episode of Rings of Power, House of the Dragon and Nick gushes about Warrior. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


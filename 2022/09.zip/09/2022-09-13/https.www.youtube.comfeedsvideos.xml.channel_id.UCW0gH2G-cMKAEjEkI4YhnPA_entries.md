# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## LIVE with Lloyd Owen (Elendil in The Rings of Power)
 - [https://www.youtube.com/watch?v=Rqt_jANq8cQ](https://www.youtube.com/watch?v=Rqt_jANq8cQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-09-13 00:00:00+00:00

We'll chat LIVE with Lloyd Owen about his character Elendil, the island realm of Númenor, and his deep dives into Tolkien's more obscure writings to inform the Elendil we meet in The Lord of the Rings: The Rings of Power!

#theringsofpower #elendil #lordoftherings


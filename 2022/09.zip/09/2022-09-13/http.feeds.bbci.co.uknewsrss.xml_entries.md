# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Russia covertly spent $300m to meddle abroad - US
 - [https://www.bbc.co.uk/news/world-us-canada-62897570?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62897570?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 23:48:14+00:00

The US alleges that Moscow has sought to buy political influence in more than 24 countries since 2014.

## The Papers: 'Home to rest' and 'junk food rules under threat'
 - [https://www.bbc.co.uk/news/blogs-the-papers-62897436?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-62897436?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 23:41:52+00:00

The Queen's coffin has returned to Buckingham Palace where it was met by members of the Royal Family.

## China's Xi to meet Putin in first foreign trip since pandemic
 - [https://www.bbc.co.uk/news/world-asia-china-62885151?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-62885151?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 23:35:15+00:00

He will meet Russian leader Vladimir Putin on the sidelines of a regional summit in Uzbekistan.

## Queen Elizabeth II: What her death means to Malaysia
 - [https://www.bbc.co.uk/news/world-asia-62885963?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62885963?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 23:15:12+00:00

Tributes are paid to Queen Elizabeth amid calls for the Commonwealth to be reformed for a new age.

## Clarence House staff told jobs are at risk
 - [https://www.bbc.co.uk/news/uk-62897488?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62897488?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 23:03:16+00:00

Redundancies are "unavoidable" following King Charles III's accession, a spokesman says.

## Queen's favourite brands hope to keep Royal Warrants
 - [https://www.bbc.co.uk/news/business-62891159?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62891159?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 23:02:18+00:00

When Queen Elizabeth II passed away, more than 600 Royal Warrants passed with her.

## Christopher Atherton: Glenavon teenager breaks record as UK's youngest senior footballer
 - [https://www.bbc.co.uk/sport/football/62897652?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62897652?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 22:21:24+00:00

Glenavon teenager Christopher Atherton becomes the youngest senior footballer in the UK at 13 years and 329 days old.

## Kenneth Starr: Clinton investigator dead at 76
 - [https://www.bbc.co.uk/news/world-us-canada-62893927?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62893927?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 21:41:32+00:00

The prosecutor exposed an affair between then-President Bill Clinton and an intern, Monica Lewinsky.

## William and Harry to walk behind Queen's coffin to Westminster Hall
 - [https://www.bbc.co.uk/news/uk-62896860?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62896860?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 21:33:18+00:00

The brothers, with the King, will follow the coffin in a procession through central London.

## Bayern Munich 2-0 Barcelona: Robert Lewandowski homecoming falls flat with defeat
 - [https://www.bbc.co.uk/sport/football/62882374?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62882374?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 21:32:09+00:00

Bayern Munich beat Barcelona in a battle of European heavyweights in the Champions League group stage on Tuesday night.

## Liverpool 2-1 Ajax: Joel Matip header seals win at Anfield
 - [https://www.bbc.co.uk/sport/football/62879294?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62879294?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 21:31:37+00:00

Joel Matip's header seals a first win for Liverpool in this season's Champions League after Ajax's Mohammed Kudos cancels out Mohammed Salah's goal.

## Armenia-Azerbaijan: Almost 100 killed in overnight clashes
 - [https://www.bbc.co.uk/news/world-europe-62888891?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62888891?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 20:32:56+00:00

The EU and the UN call for de-escalation in the latest fighting between the neighbouring countries.

## England v India: Smriti Mandhana guides tourists to win to set up T20 series decider
 - [https://www.bbc.co.uk/sport/cricket/62892727?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62892727?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 20:27:04+00:00

Opener Smriti Mandhana makes an unbeaten 79 to guide India to a eight-wicket win over England and set up a decider in the three-match Twenty20 series.

## Ukraine war: Accounts of Russian torture emerge in liberated areas
 - [https://www.bbc.co.uk/news/world-europe-62888388?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62888388?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 20:26:23+00:00

The BBC hears accusations that Russian forces electrocuted prisoners and shot civilians in the Kharkiv region.

## England v India: Watch the best shots from Smriti Mandhana's 79 not out
 - [https://www.bbc.co.uk/sport/av/cricket/62896841?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/62896841?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 20:03:17+00:00

Watch the best shots from Smriti Mandhana's innings as she hits 13 fours in her unbeaten 79 to guide India to an eight-wicket win over England and level the T20 series at 1-1 ahead of the final match in the series in Bristol on Thursday.

## Liverpool & EFL: Tributes paid to Queen Elizabeth II as professional football resumes
 - [https://www.bbc.co.uk/sport/football/62893621?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62893621?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 19:53:56+00:00

Liverpool fans and supporters of EFL clubs pay tribute to Queen Elizabeth II as professional football fixtures resume across the UK.

## Twitter shareholders approve $44bn Musk deal
 - [https://www.bbc.co.uk/news/technology-62894600?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62894600?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 19:13:15+00:00

Twitter shareholders have approved a $44bn deal for the world's richest man to buy the company.

## Sporting Lisbon 2-0 Tottenham: Antonio Conte's side lose for first time this season
 - [https://www.bbc.co.uk/sport/football/62884428?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62884428?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 18:54:27+00:00

Tottenham concede two injury-time goals as they slump to a Champions League defeat against Sporting Lisbon in Portugal.

## England v India: Freya Kemp hits 'wonderful knock' to reach half-century
 - [https://www.bbc.co.uk/sport/av/cricket/62894745?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/62894745?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 18:52:11+00:00

Watch the best shots from Freya Kemp's "wonderful knock" as she hits her first international half-century in England's T20 match against India at The Incora County Ground in Derby.

## Royal Family to receive Queen Elizabeth II's coffin at Buckingham Palace
 - [https://www.bbc.co.uk/news/uk-62883712?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62883712?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 18:31:02+00:00

The King will be joined by royals including Princes William and Harry and their wives.

## Princess Anne: The can-do will-do royal
 - [https://www.bbc.co.uk/news/uk-62895373?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62895373?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 17:46:12+00:00

How Princess Anne's role escorting Queen Elizabeth's coffin is a mark of her importance to the Royal Family.

## Queen's funeral guests: Who's coming and who's not?
 - [https://www.bbc.co.uk/news/uk-62890879?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62890879?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 17:05:27+00:00

Here's what we know so far about who will and won't be coming to this historic event.

## The Queen's journey to lying-in-state
 - [https://www.bbc.co.uk/news/uk-62895941?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62895941?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 17:05:14+00:00

Her coffin travels from Buckingham Palace to Westminster Hall, where the public can pay their respects.

## Graham Potter: Challenge of being Chelsea manager 'too big to turn down'
 - [https://www.bbc.co.uk/sport/football/62893344?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62893344?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 16:52:53+00:00

Graham Potter says the challenge of being Chelsea manager was "too big to turn down".

## Backlash as Center Parcs to close for Queen's funeral
 - [https://www.bbc.co.uk/news/business-62893476?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62893476?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 16:36:46+00:00

Holidaymakers have been told they must leave Center Parcs sites for a day or go home early.

## Worcester Warriors owners 'agree terms of sale of club' to interested party
 - [https://www.bbc.co.uk/sport/rugby-union/62876136?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/62876136?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 16:32:16+00:00

Worcester Warriors' owners say they have agreed the terms of the sale of the troubled club to an interested party.

## Tyson Fury v Anthony Joshua: Is it still a global super-fight?
 - [https://www.bbc.co.uk/sport/boxing/62889509?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/62889509?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 15:59:01+00:00

Anthony Joshua has agreed to Tyson Fury's terms for a December meeting, but can the all-British bout still be considered a global super-fight?

## Women's Big Bash League: Sophie Ecclestone and Alice Capsey selected for WBBL
 - [https://www.bbc.co.uk/sport/cricket/62893242?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/62893242?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 15:36:50+00:00

England's Sophie Ecclestone and Alice Capsey sign Women's Big Bash contracts with Sydney Sixers and Melbourne Stars respectively.

## Crowds line Edinburgh streets for Queen's farewell to Scotland
 - [https://www.bbc.co.uk/news/uk-scotland-62887168?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-62887168?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 15:34:22+00:00

The Queen's coffin is transported to Edinburgh Airport and will be flown to RAF Northolt in London.

## Strictly Come Dancing: Premiere delayed following Queen's death
 - [https://www.bbc.co.uk/news/entertainment-arts-62894460?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62894460?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 15:34:12+00:00

The series will will now debut on 23 September, one week later than originally planned.

## Switching to renewable energy could save trillions - study
 - [https://www.bbc.co.uk/news/science-environment-62892013?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-62892013?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 15:26:00+00:00

New report says falling cost of renewable energy makes switch from fossil fuels cheapest option.

## Benjamin Mendy found not guilty of one count of rape
 - [https://www.bbc.co.uk/news/uk-england-manchester-62894037?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-62894037?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 15:24:38+00:00

Manchester City footballer Benjamin Mendy remains on trial for multiple alleged sexual offences.

## Walk and wait is best strategy to stop baby crying
 - [https://www.bbc.co.uk/news/health-62889539?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-62889539?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 15:01:52+00:00

Scientists carry out tests with new parents to find what works best to help crying babies sleep.

## The monarchy's delicate Scottish balancing act
 - [https://www.bbc.co.uk/news/uk-scotland-62887905?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-62887905?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 14:51:56+00:00

There was genuine affection for the Queen in Scotland but uncertainty looms for King Charles.

## Queen 'helped to change attitudes' in Northern Ireland
 - [https://www.bbc.co.uk/news/uk-northern-ireland-62894026?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-62894026?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 14:33:32+00:00

Stormont Speaker Alex Maskey pays tribute to the Queen's contribution to peace in Northern Ireland.

## Jean-Luc Godard: Visionary director's life and films in pictures
 - [https://www.bbc.co.uk/news/entertainment-arts-62889491?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62889491?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 14:25:30+00:00

A look back at the groundbreaking films of French cinematic pioneer Jean-Luc Godard.

## Is there a right to protest at royal events?
 - [https://www.bbc.co.uk/news/explainers-62887745?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/explainers-62887745?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 13:58:32+00:00

A number of people have been arrested for protesting at royal events, what does the law say about this?

## Gio Queiroz: Arsenal sign Brazil winger from Barcelona then loan to Everton
 - [https://www.bbc.co.uk/sport/football/62890657?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62890657?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 13:00:15+00:00

Arsenal sign Brazil winger Gio Queiroz from Barcelona, then loan her to Everton for the 2022-23 season.

## Liverpool v Ajax: Hillsborough Survivors Support Alliance calls for respect for silence
 - [https://www.bbc.co.uk/sport/football/62886074?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62886074?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 12:32:16+00:00

A Hillsborough support group has called on Liverpool fans to "show respect" to the silence for Queen Elizabeth II before Tuesday's Champions League match against Ajax.

## Archie Battersbee: Family gathers for Southend funeral
 - [https://www.bbc.co.uk/news/uk-england-essex-62889234?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-62889234?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 12:12:22+00:00

Family and friends of the boy, 12, who died following a life support dispute, gather for his funeral.

## Kenya election 2022: William Ruto sworn in as president
 - [https://www.bbc.co.uk/news/world-africa-62886989?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-62886989?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 12:11:52+00:00

About 60,000 pack a stadium to witness the transfer of power, following last month's election.

## Man charged over heckling of Prince Andrew as he followed coffin
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-62889396?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-62889396?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 11:47:36+00:00

The Duke of York was shouted at as he walked up the Royal Mile behind the Queen's coffin.

## Margaret Ferrier: MP who exposed public to Covid must do unpaid work
 - [https://www.bbc.co.uk/news/uk-scotland-62887853?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-62887853?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 10:44:41+00:00

Margaret Ferrier took the train from London to Glasgow after testing positive for the virus.

## Davis Cup Finals: Great Britain begin campaign against United States in Glasgow
 - [https://www.bbc.co.uk/sport/tennis/62866160?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/62866160?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 10:44:15+00:00

The group stages of the Davis Cup Finals start in Glasgow on Tuesday, with Britain facing the United States in their first match on Wednesday.

## Anthony Joshua 'accepts Tyson Fury's terms' for all-British December fight
 - [https://www.bbc.co.uk/sport/boxing/62889501?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/62889501?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 10:43:55+00:00

Anthony Joshua has accepted WBC champion Tyson Fury's terms for an all-British heavyweight fight in December and is awaiting a response, his management company has said.

## St Giles' vigil: Up all night and queueing through the sunrise
 - [https://www.bbc.co.uk/news/uk-scotland-62853613?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-62853613?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 10:36:40+00:00

Edinburgh emerges from its all-night vigil as thousands continue to pay respects at St Giles' Cathedral.

## Chris Kaba family says officer suspension too slow after shooting
 - [https://www.bbc.co.uk/news/uk-england-london-62886400?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-62886400?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 10:32:08+00:00

Chris Kaba's family welcomes the Met firearms officer's suspension but says there is "no urgency".

## PnB Rock: Rapper shot dead in LA waffle house in suspected robbery
 - [https://www.bbc.co.uk/news/newsbeat-62888207?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-62888207?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 10:02:43+00:00

Tributes flood in for the 30-year-old musician after he is reportedly killed in an armed robbery.

## The quiet symbolism of the Queen's farewell to Scotland
 - [https://www.bbc.co.uk/news/uk-62887703?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62887703?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 09:49:39+00:00

Queen Elizabeth's lying at rest was a gesture toward the distinctive character of Scotland's historic nationhood.

## Jean-Luc Godard: Legendary French film director dies at 91
 - [https://www.bbc.co.uk/news/entertainment-arts-62886470?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-62886470?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 09:41:49+00:00

The New Wave director rewrote cinema's rules and influenced film-makers from Tarantino to Scorsese.

## Canada has its first Michelin guide. Does it matter?
 - [https://www.bbc.co.uk/news/world-us-canada-62854914?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62854914?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 09:34:15+00:00

Michelin's arrival in Canada's most diverse city reignites a debate on the legitimacy of food rankings.

## Will Jamaica now seek to 'move on' from royals as a republic?
 - [https://www.bbc.co.uk/news/world-latin-america-62846653?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-62846653?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 09:21:15+00:00

As the nation weighs its future, polls suggest more than 50% of Jamaicans support becoming a republic.

## Ryan Fraser back for Scotland as Andy Robertson misses Nations League matches
 - [https://www.bbc.co.uk/sport/football/62887094?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62887094?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 09:05:41+00:00

Ryan Fraser returns to the Scotland squad for September's Nations League matches, but captain Andy Robertson misses out through injury.

## Queen Elizabeth II: Dressmaker 'so lucky' to land dream job
 - [https://www.bbc.co.uk/news/uk-england-hampshire-62874367?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-hampshire-62874367?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 08:53:55+00:00

Maureen Rose spent 30 years working as a dressmaker to the Queen.

## Jean-Luc Godard: Nine things about the man who remade cinema
 - [https://www.bbc.co.uk/news/entertainment-arts-46709681?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-46709681?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 08:53:25+00:00

In a prolific career, Jean-Luc Godard, has provoked, baffled, delighted and inspired.

## "Art is dead Dude" - the rise of the AI artists
 - [https://www.bbc.co.uk/news/technology-62788725?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-62788725?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 08:47:29+00:00

A number of new artificial intelligence systems turn simple text prompts into striking images.

## Aldi becomes Britain’s fourth largest supermarket
 - [https://www.bbc.co.uk/news/business-62887477?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62887477?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 08:37:56+00:00

The discount chain overtakes Morrisons, a research firm says, as shoppers become more cost-conscious.

## Public urged to queue now to see Queen's coffin in Edinburgh
 - [https://www.bbc.co.uk/news/uk-scotland-62887444?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-62887444?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 08:05:34+00:00

The waiting time for St Giles' Cathedral is expected to exceed two hours as the day progresses.

## Queen Elizabeth II: Poet Laureate Simon Armitage marks death of monarch
 - [https://www.bbc.co.uk/news/uk-62886384?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62886384?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 07:08:27+00:00

The first letter of each line of "Floral Tribute" spells out Elizabeth in honour of the late monarch.

## UK unemployment at lowest rate for 48 years
 - [https://www.bbc.co.uk/news/business-62877700?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62877700?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 06:46:55+00:00

The jobless rate falls to 3.6%, but pay is still failing to keep up with the rising cost of living.

## Australian man killed by kangaroo he kept as pet, police say
 - [https://www.bbc.co.uk/news/world-australia-62884861?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-62884861?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 06:45:49+00:00

The 77-year-old man was found by relative in the first such fatal incident since 1936.

## Blue Origin rocket malfunctions on trip to space
 - [https://www.bbc.co.uk/news/world-us-canada-62885026?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62885026?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 06:40:01+00:00

The emergency escape system on the uncrewed craft was triggered mid-air.

## Akshay Kumar's ad on road safety criticised for promoting dowry
 - [https://www.bbc.co.uk/news/world-asia-india-62885463?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-62885463?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 06:06:04+00:00

The ad, starring Bollywood star Akshay Kumar, has been criticised for allegedly promoting dowry.

## Torvill and Dean share memories of the Queen
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-62878841?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-62878841?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 05:49:44+00:00

Mr Dean wrote to express thanks to the monarch and received a response a few days before her death.

## Queen Elizabeth II: A life in Land Rovers
 - [https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-62851013?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-coventry-warwickshire-62851013?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 05:32:12+00:00

The iconic cars were "part of the royal family's DNA" according to motoring journalist Quentin Willson.

## Barcelona: Jordi Cruyff says summer signings joined club to 'follow their dream'
 - [https://www.bbc.co.uk/sport/football/62862591?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62862591?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 05:20:13+00:00

Barcelona director Jordi Cruyff tells Spanish football expert Guillem Balague that the club's summer signings joined to "follow their dream".

## Thailand lèse-majesté: Activist jailed for dressing like Thai queen at protest
 - [https://www.bbc.co.uk/news/world-asia-62885149?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-62885149?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 04:47:46+00:00

Another activist is imprisoned under Thailand's stringent law banning criticism of the royals.

## The Papers: 'The King's vigil' and 'PM under pressure'
 - [https://www.bbc.co.uk/news/uk-62884578?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-62884578?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 01:04:58+00:00

The newspapers reflect on the Royal Family's vigil for the Queen as her children stood by her coffin.

## Ukraine war: We retook 6,000 sq km from Russia in September, says Zelensky
 - [https://www.bbc.co.uk/news/world-europe-62884668?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-62884668?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-09-13 00:13:59+00:00

President Volodymyr Zelensky says the gains were made in the east and south during a swift counter-offensive.


# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Niechlubna seria Barcelony trwa
 - [https://eurosport.tvn24.pl/niechlubna-seria-barcelony-trwa,1118460.html?source=rss](https://eurosport.tvn24.pl/niechlubna-seria-barcelony-trwa,1118460.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 21:24:58+00:00

<img alt="Niechlubna seria Barcelony trwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j96m3v-barcelona-znow-nie-wygrala-w-monachium-6111095/alternates/LANDSCAPE_1280" />
    Kibice, którzy liczyli, że Katalończycy przełamią klątwę i w końcu wygrają w Monachium, znowu muszą czuć duży zawód.

## Liverpool znów zafundował thriller. Minuta ciszy przed meczem
 - [https://eurosport.tvn24.pl/liverpool-zn-w-zafundowa--thriller--minuta-ciszy-przed-meczem,1118453.html?source=rss](https://eurosport.tvn24.pl/liverpool-zn-w-zafundowa--thriller--minuta-ciszy-przed-meczem,1118453.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 20:56:18+00:00

<img alt="Liverpool znów zafundował thriller. Minuta ciszy przed meczem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6mvff5-minuta-ciszy-przed-meczem-ligi-mistrzow-pomiedzy-liverpoolem-a-ajaksem-amsterdam-6111085/alternates/LANDSCAPE_1280" />
    Zobacz, co działo się na innych boiskach we wtorkowych meczach Ligi Mistrzów.

## Zmarnowane szanse, to będzie długo bolało Lewandowskiego
 - [https://eurosport.tvn24.pl/-wietne-szanse-zmarnowane--to-mo-e-bole---lewandowski-nie-jest-sob-,1118457.html?source=rss](https://eurosport.tvn24.pl/-wietne-szanse-zmarnowane--to-mo-e-bole---lewandowski-nie-jest-sob-,1118457.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 20:51:00+00:00

<img alt="Zmarnowane szanse, to będzie długo bolało Lewandowskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ux49z1-lewandowski-nie-potrafil-pokonac-neuera/alternates/LANDSCAPE_1280" />
    Oczy zwrócone były na niego.

## Nieudany powrót Lewandowskiego do Monachium. Barcelona dostała lekcję skuteczności
 - [https://eurosport.tvn24.pl/bayern-odmieniony-po-przerwie--barcelona-dosta-a-lekcj--skuteczno-ci,1118450.html?source=rss](https://eurosport.tvn24.pl/bayern-odmieniony-po-przerwie--barcelona-dosta-a-lekcj--skuteczno-ci,1118450.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 20:50:57+00:00

<img alt="Nieudany powrót Lewandowskiego do Monachium. Barcelona dostała lekcję skuteczności" src="https://tvn24.pl/najnowsze/cdn-zdjecie-icrtd8-lewandowski-byl-nieskuteczny-w-meczu-z-bayernem-6111082/alternates/LANDSCAPE_1280" />
    Bayern odmieniony po przerwie.

## Tak przywitano Lewandowskiego w Monachium. On sam zachował się znakomicie
 - [https://eurosport.tvn24.pl/tak-przywitano-lewandowskiego-w-monachium--on-sam-zachowa--si--znakomicie,1118436.html?source=rss](https://eurosport.tvn24.pl/tak-przywitano-lewandowskiego-w-monachium--on-sam-zachowa--si--znakomicie,1118436.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 18:54:00+00:00

<img alt="Tak przywitano Lewandowskiego w Monachium. On sam zachował się znakomicie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6flv0j-robert-lewandowski-przywital-swoich-niedawnych-kibicow-brawami/alternates/LANDSCAPE_1280" />
    Dla Roberta Lewandowskiego wyjazdowy mecz Barcelony z Bayernem Monachium w Lidze Mistrzów jest wyjątkowy.

## Trener Halep zdradza, co stało za atakiem paniki tenisistki
 - [https://eurosport.tvn24.pl/trener-halep-zdradza--co-sta-o-za-atakiem-paniki-tenisistki,1118427.html?source=rss](https://eurosport.tvn24.pl/trener-halep-zdradza--co-sta-o-za-atakiem-paniki-tenisistki,1118427.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 18:23:00+00:00

<img alt="Trener Halep zdradza, co stało za atakiem paniki tenisistki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8vzflh-simona-halep-poczula-sie-zle-w-trakcie-meczu-z-zheng/alternates/LANDSCAPE_1280" />
    Świat tenisa martwił się o zdrowie zawodniczki.

## Wrócił. Lewandowski i Barcelona na stadionie Bayernu
 - [https://eurosport.tvn24.pl/bayern-monachium---fc-barcelona--wynik-meczu-na--ywo-i-relacja,1118411.html?source=rss](https://eurosport.tvn24.pl/bayern-monachium---fc-barcelona--wynik-meczu-na--ywo-i-relacja,1118411.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 18:15:00+00:00

<img alt="Wrócił. Lewandowski i Barcelona na stadionie Bayernu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-frnxze-2-relecja-tiker-wiekszy-16-copy-6110833/alternates/LANDSCAPE_1280" />
    Relacja z meczu w eurosport.pl.

## Świątek pewna gry w prestiżowym turnieju. Możliwy rewanż za finał US Open
 - [https://eurosport.tvn24.pl/-wi-tek-pewna-gry-w-presti-owym-turnieju--mo-liwy-rewan--za-fina--us-open,1118422.html?source=rss](https://eurosport.tvn24.pl/-wi-tek-pewna-gry-w-presti-owym-turnieju--mo-liwy-rewan--za-fina--us-open,1118422.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 17:20:00+00:00

<img alt="Świątek pewna gry w prestiżowym turnieju. Możliwy rewanż za finał US Open" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mo1yuq-iga-swiatek-to-triumfatorka-tegorocznego-us-open/alternates/LANDSCAPE_1280" />
    Występ potwierdzono oficjalnie.

## Europoseł PiS pyta, jak "wyjść" z KPO. "Jaka jest procedura?"
 - [https://fakty.tvn24.pl/eurodeputowany-pis-wprost-pyta--jak-anulowa--kpo---jaka-jest-procedura--,1118420.html?source=rss](https://fakty.tvn24.pl/eurodeputowany-pis-wprost-pyta--jak-anulowa--kpo---jaka-jest-procedura--,1118420.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 17:09:00+00:00

<img alt="Europoseł PiS pyta, jak " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ah61h3-eurodeputowany-pis-wprost-pyta-jak-anulowac-kpo-jaka-jest-procedura/alternates/LANDSCAPE_1280" />
    Politycy Zjednoczonej Prawicy coraz głośniej wyrażają niechęć do brania pieniędzy od UE.

## "Gołębie się zastanawiają, czy można na tym usiąść"
 - [https://fakty.tvn24.pl/patriotyczna--awka-nie-wytrzyma-a-deszczu---go--bie-si--zastanawiaj---czy-mo-na-na-tym-usi----,1118421.html?source=rss](https://fakty.tvn24.pl/patriotyczna--awka-nie-wytrzyma-a-deszczu---go--bie-si--zastanawiaj---czy-mo-na-na-tym-usi----,1118421.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 17:07:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rphm8h-patriotyczna-lawka-nie-wytrzymala-deszczu-golebie-sie-zastanawiaja-czy-mozna-na-tym-usiasc/alternates/LANDSCAPE_1280" />
    Patriotyczna ławka nie wytrzymała deszczu.

## Udany powrót Majki. Finiszował z najlepszymi
 - [https://eurosport.tvn24.pl/udany-powr-t-majki--finiszowa--z-najlepszymi,1118419.html?source=rss](https://eurosport.tvn24.pl/udany-powr-t-majki--finiszowa--z-najlepszymi,1118419.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 16:32:00+00:00

<img alt="Udany powrót Majki. Finiszował z najlepszymi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jdd8qc-rafal-majka-podczas-tour-de-luxembourg/alternates/LANDSCAPE_1280" />
    W swoim pierwszym starcie od Tour de France nie zawiódł.

## Włosi wydali werdykt w sprawie skandalu po anulowaniu gola Milika
 - [https://eurosport.tvn24.pl/w-osi-wydali-werdykt-w-sprawie-skandalu-po-anulowaniu-gola-milika,1118401.html?source=rss](https://eurosport.tvn24.pl/w-osi-wydali-werdykt-w-sprawie-skandalu-po-anulowaniu-gola-milika,1118401.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 15:22:00+00:00

<img alt="Włosi wydali werdykt w sprawie skandalu po anulowaniu gola Milika" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9j2sr7-milik-nie-zagra-w-nastepnym-meczu-juve-w-serie-a/alternates/LANDSCAPE_1280" />
    Posypały się czerwone kartki, w tym jedna dla Polaka.

## Wicemistrzowie świata z wizytą u premiera
 - [https://eurosport.tvn24.pl/wicemistrzowie--wiata-z-wizyt--u-premiera,1118395.html?source=rss](https://eurosport.tvn24.pl/wicemistrzowie--wiata-z-wizyt--u-premiera,1118395.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 14:36:34+00:00

<img alt="Wicemistrzowie świata z wizytą u premiera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-26zn3g-polscy-siatkarze-spotkali-sie-z-premierem-mateuszem-morawieckim/alternates/LANDSCAPE_1280" />
    "Jestem niesamowicie dumny".

## PZPN gotowy na mundial
 - [https://eurosport.tvn24.pl/pzpn-gotowy-na-mundial---to-b-dzie-wygodny-turniej-,1118385.html?source=rss](https://eurosport.tvn24.pl/pzpn-gotowy-na-mundial---to-b-dzie-wygodny-turniej-,1118385.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 13:30:00+00:00

<img alt="PZPN gotowy na mundial" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i8cw4i-polacy-wystapia-w-mistrzostwach-swiata-w-katarze/alternates/LANDSCAPE_1280" />
    "To będzie wygodny turniej".

## Występ Świątek w reprezentacji niezagrożony
 - [https://eurosport.tvn24.pl/wyst-p--wi-tek-w-reprezentacji-niezagro-ony--mecz-polek-zostanie-op--niony,1118377.html?source=rss](https://eurosport.tvn24.pl/wyst-p--wi-tek-w-reprezentacji-niezagro-ony--mecz-polek-zostanie-op--niony,1118377.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 12:19:00+00:00

<img alt="Występ Świątek w reprezentacji niezagrożony" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eif83c-iga-swiatek/alternates/LANDSCAPE_1280" />
    Mecz Polek zostanie opóźniony.

## Morawiecki, Semeniuk, Fogiel: "w sprawie KPO zrobiliśmy wszystko". Sprawdziliśmy, że jednak nie
 - [https://konkret24.tvn24.pl/r/morawiecki--semeniuk--fogiel---w-sprawie-kpo-zrobili-my-wszystko---sprawdzili-my---e-jednak-nie,1118367.html?source=rss](https://konkret24.tvn24.pl/r/morawiecki--semeniuk--fogiel---w-sprawie-kpo-zrobili-my-wszystko---sprawdzili-my---e-jednak-nie,1118367.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 12:10:48+00:00

<img alt="Morawiecki, Semeniuk, Fogiel: " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6awa1y-dobre-miasto-16072021-premier-mateusz-morawiecki-oraz-podsekretarz-stanu-w-ministerstwie-rozwoju-pracy-i-technologii-olga-semeniuk/alternates/LANDSCAPE_1280" />
    Wyjaśniamy.

## Sprzęt "podarowany Ukrainie" przez uciekających Rosjan? To nie jest odbity Izium
 - [https://konkret24.tvn24.pl/r/sprz-t--podarowany-ukrainie--przez-uciekaj-cych-rosjan--to-nie-jest-odbity-izium,1118287.html?source=rss](https://konkret24.tvn24.pl/r/sprz-t--podarowany-ukrainie--przez-uciekaj-cych-rosjan--to-nie-jest-odbity-izium,1118287.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 11:39:54+00:00

<img alt="Sprzęt " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qbydc3-pojazdy-zjpg-6109955/alternates/LANDSCAPE_1280" />
    Internauci pokazują zdjęcia i filmy ze sprzętem zostawianym przez wycofujące się wojska rosyjskie. Przestrzegamy: nie wszystkie te obrazy powstały teraz na odbitych terenach.

## Iga wróciła do Polski. "Witaj w domu"
 - [https://eurosport.tvn24.pl/-wi-tek-wr-ci-a-do-polski---witaj-w-domu--iga-,1118369.html?source=rss](https://eurosport.tvn24.pl/-wi-tek-wr-ci-a-do-polski---witaj-w-domu--iga-,1118369.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 11:16:00+00:00

<img alt="Iga wróciła do Polski. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pn1n34-iga-swiatek-wygrala-trzy-imprezy-wielkoszlemowe-6110243/alternates/LANDSCAPE_1280" />
    Rejsowy samolot z tenisistką na pokładzie wylądował na lotnisku Chopina w Warszawie przed godziną 13.

## Iga Świątek przyciągnęła przed ekrany miliony
 - [https://eurosport.tvn24.pl/iga--wi-tek-przyci-gn--a-przed-ekrany-miliony--najlepiej-ogl-dany-mecz-tenisa-w-historii,1118381.html?source=rss](https://eurosport.tvn24.pl/iga--wi-tek-przyci-gn--a-przed-ekrany-miliony--najlepiej-ogl-dany-mecz-tenisa-w-historii,1118381.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 10:17:26+00:00

<img alt="Iga Świątek przyciągnęła przed ekrany miliony" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j7c01z-iga-swiatek-wygrala-us-open-2022/alternates/LANDSCAPE_1280" />
    Finał US Open był najchętniej oglądaną transmisją z meczu Wielkiego Szlema w Polsce w historii.

## Apel o wdzięczność dla Lewandowskiego. Powodów jest wiele
 - [https://eurosport.tvn24.pl/apel-o-wdzi-czno---dla-lewandowskiego--powod-w-jest-wiele,1118371.html?source=rss](https://eurosport.tvn24.pl/apel-o-wdzi-czno---dla-lewandowskiego--powod-w-jest-wiele,1118371.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 09:38:56+00:00

<img alt="Apel o wdzięczność dla Lewandowskiego. Powodów jest wiele" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rgkyaf-lewyjpg/alternates/LANDSCAPE_1280" />
    Oto najważniejsze z nich.

## Lewandowski znów w Monachium. "Nie wybuczymy go"
 - [https://eurosport.tvn24.pl/lewandowski-zn-w-w-monachium---nie-wybuczymy-go-,1118366.html?source=rss](https://eurosport.tvn24.pl/lewandowski-zn-w-w-monachium---nie-wybuczymy-go-,1118366.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 09:14:18+00:00

<img alt="Lewandowski znów w Monachium. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9128ti-lewandowski-strzela-w-nowym-zespole-jak-na-zawolanie/alternates/LANDSCAPE_1280" />
    Dla napastnika Barcelony będzie to powrót na obiekt, który opuścił w lipcu po ośmiu latach.

## Fotoreporterzy podpadli Kloppowi. "Pięć sekund przerwy"
 - [https://eurosport.tvn24.pl/fotoreporterzy-podpadli-kloppowi---pi---sekund-przerwy-,1118364.html?source=rss](https://eurosport.tvn24.pl/fotoreporterzy-podpadli-kloppowi---pi---sekund-przerwy-,1118364.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 08:51:00+00:00

<img alt="Fotoreporterzy podpadli Kloppowi. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-35drsf-klopp-zdenerwowal-sie-na-fotografa/alternates/LANDSCAPE_1280" />
    Trener Liverpoolu znów miał problem z mediami w trakcie przedmeczowej konferencji prasowej.

## Świątek przypomniała o Ukrainie. "Wojna wciąż trwa, bardzo blisko mojego kraju"
 - [https://eurosport.tvn24.pl/-wi-tek-przypomnia-a-o-ukrainie---wojna-wci---trwa--bardzo-blisko-mojego-kraju-,1118374.html?source=rss](https://eurosport.tvn24.pl/-wi-tek-przypomnia-a-o-ukrainie---wojna-wci---trwa--bardzo-blisko-mojego-kraju-,1118374.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 08:36:19+00:00

<img alt="Świątek przypomniała o Ukrainie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hwv4ld-iga-swiatek-wygrala-us-open-2022/alternates/LANDSCAPE_1280" />
    Tenisistka gościła w programie jednej z amerykańskich telewizji.

## Wczoraj kat Barcelony, dzisiaj jej lider. "Lewandowski wraca do drugiego domu"
 - [https://eurosport.tvn24.pl/wczoraj-kat-barcelony--dzisiaj-jej-lider---lewandowski-wraca-do-drugiego-domu-,1118361.html?source=rss](https://eurosport.tvn24.pl/wczoraj-kat-barcelony--dzisiaj-jej-lider---lewandowski-wraca-do-drugiego-domu-,1118361.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 07:38:42+00:00

<img alt="Wczoraj kat Barcelony, dzisiaj jej lider. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1xzaub-robert-lewandowski-na-okladkach-sportu-i-mundo-deportivo/alternates/LANDSCAPE_1280" />
    Katalońskie gazety żyją meczem z Bayernem.

## Były tenisowy mistrz chyli czoła przed Igą Świątek
 - [https://eurosport.tvn24.pl/by-y-tenisowy-mistrz-chyli-czo-a-przed-ig---wi-tek---rok-jej-dominacji-,1118359.html?source=rss](https://eurosport.tvn24.pl/by-y-tenisowy-mistrz-chyli-czo-a-przed-ig---wi-tek---rok-jej-dominacji-,1118359.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 05:57:16+00:00

<img alt="Były tenisowy mistrz chyli czoła przed Igą Świątek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7xgb28-iga-swiatek-wygrala-us-open-2022/alternates/LANDSCAPE_1280" />
    Andy Roddick dołączył do grona sportowych gwiazd wielbiących talent Polki.

## Niepokój Słoweńców przed meczem z Polską
 - [https://eurosport.tvn24.pl/niepok-j-s-owe-c-w-przed-meczem-z-polsk---luka-donczi--kontuzjowany,1118358.html?source=rss](https://eurosport.tvn24.pl/niepok-j-s-owe-c-w-przed-meczem-z-polsk---luka-donczi--kontuzjowany,1118358.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 05:36:55+00:00

<img alt="Niepokój Słoweńców przed meczem z Polską" src="https://tvn24.pl/najnowsze/cdn-zdjecie-avbuy9-luka-donczic-rozegral-kilka-fenomenalnych-meczow-w-me-2022/alternates/LANDSCAPE_1280" />
    Luka Donczić doznał skręcenia kostki podczas treningu.

## Wróci na kort dopiero za kilka tygodni. Miała "trudności z oddychaniem"
 - [https://eurosport.tvn24.pl/halep-wr-ci-dopiero-za-kilka-tygodni--mia-a--trudno-ci-z-oddychaniem-,1118356.html?source=rss](https://eurosport.tvn24.pl/halep-wr-ci-dopiero-za-kilka-tygodni--mia-a--trudno-ci-z-oddychaniem-,1118356.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 04:45:58+00:00

<img alt="Wróci na kort dopiero za kilka tygodni. Miała " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rhhqp1-simona-halep-wroci-za-kilka-tygodni/alternates/LANDSCAPE_1280" />
    Simonę Halep czeka przerwa w grze.

## Niewybuch i ewakuacja mieszkańców
 - [https://kontakt24.tvn24.pl/sg/przed-blokiem-znaleziono-niewybuch-ewakuacja-mieszkancow,352038.html?source=rss](https://kontakt24.tvn24.pl/sg/przed-blokiem-znaleziono-niewybuch-ewakuacja-mieszkancow,352038.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 04:41:11+00:00

<img alt="Niewybuch i ewakuacja mieszkańców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1k2lgf-ewakuacja-mieszkancow-zabek-6109428/alternates/LANDSCAPE_1280" />
    W Ząbkach koło Warszawy.

## Lewandowski przeciwko Bayernowi. Trener Barcelony zapowiada
 - [https://eurosport.tvn24.pl/xavi-pewny--lewandowski-przeciwko-bayernowi-poka-e-pe-ni--charakteru,1118342.html?source=rss](https://eurosport.tvn24.pl/xavi-pewny--lewandowski-przeciwko-bayernowi-poka-e-pe-ni--charakteru,1118342.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 04:15:14+00:00

<img alt="Lewandowski przeciwko Bayernowi. Trener Barcelony zapowiada" src="https://tvn24.pl/najnowsze/cdn-zdjecie-quudhi-lewandowski-w-ostatnim-meczu-pojawil-sie-na-boisku-w-drugiej-polowie/alternates/LANDSCAPE_1280" />
    Pokaże cały swój charakter - przekonuje Xavi.

## Z Kielc na Czerwoną Planetę. "Chcemy inspirować kolejne pokolenia do eksploracji Marsa"
 - [https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-37,S00E37,859349?source=rss](https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-37,S00E37,859349?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-09-13 04:00:00+00:00

<img alt="Z Kielc na Czerwoną Planetę. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6f9ctg-kijek-w-kosmosie-misja-na-marsa-6109321/alternates/LANDSCAPE_1280" />
    Zawodom łazików w Kielcach przyjrzał się Hubert Kijek.


## #36 Burning man 2022, Moja nocna przygoda cz.1
 - [https://www.youtube.com/watch?v=keL0XHdRbkU](https://www.youtube.com/watch?v=keL0XHdRbkU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIFlYVfPnvukmFOvC4JUfOg
 - date published: 2022-09-14 00:00:00+00:00

Przejażdżka i moja przygoda po Burning man nocą.
🧗🏻Wesprzyj moje przygody na patronite: https://patronite.pl/Nejtan
📷 Instagram: https://www.instagram.com/nejthan
📜 Napisz do mnie: swiatwedlugnejtana@gmail.com
🎵 Muzyka: https://share.epidemicsound.com/m7uq26

2022 Trip z  @Vlog Casha   po Florydzie https://bit.ly/3uueZGV
2021 Trip z  @Vlog Casha   po zachodzie Usa i Alaska
https://bit.ly/3D6ClpI
#swiatwedlugnejtana #nejtan


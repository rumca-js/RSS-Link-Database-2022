# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## DJI Action 3 Premierowo - Nowa, sportowa i trzyma poziom ;)
 - [https://www.youtube.com/watch?v=4HnTrZChBV8](https://www.youtube.com/watch?v=4HnTrZChBV8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-09-14 00:00:00+00:00

DJI Action 3 - https://bit.ly/3eTiSB6 
Ceny (ceneo) - https://bit.ly/3zyR3oY 

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

W odcinku:
00:00 Kamerki sportowe na rynku: GoPro, insta360, DJI
00:32 Pierwsza kamera sportowa od DJI – Osmo Action
00:48 Action 2 od DJI
01:28 Osmo Action 3
01:45 Sposoby mocowania kamery
02:08 Przedni ekran
02:22 Mikrofony
02:48 Możliwość podłączenia mikrofonu zewnętrznego
03:10 Przegrzewanie się
03:24 Możliwości video kamery i stabilizacja
03:54 Case z bateriami – powerbank
04:26 Informacja dla nurków
04:34 Webcam
04:46 Podsumowanie i materiał z kamery
05:15 Pożegnanie

## GoPro Hero 11 Black Premierowo - Też nowa, też sportowa i też trzyma poziom ;)
 - [https://www.youtube.com/watch?v=29YfovgoMZ0](https://www.youtube.com/watch?v=29YfovgoMZ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-09-14 00:00:00+00:00

Dzięki GoHERO.pl za wypożyczenie kamery do testów!
GoPro Hero 11 Black - https://bit.ly/3QEjuaJ

Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Film z DJI Action 3, który również miał dziś swoją premierę znajdziecie tutaj: https://youtu.be/4HnTrZChBV8

W odcinku:
00:00 Tryb Easy w GoPro Hero 11
00:48 Bateria i akcesoria od GoPro 10
01:21 Matryca 8:7
02:05 Rozdzielczość: DJI Action 3 vs GoPro Hero 11 Black
03:17 Stabilizacja: DJI vs GoPro
04:18 Nurkowanie z GoPro i z DJI Action
04:28 Webcam i GPS w GoPro
04:56 Możliwości foto
05:03 Nowa funkcja: automatyczne montowanie materiałów video
06:06 Materiał wideo z GoPro Hero 11
06:35 Podsumowanie
06:54 Do zobaczenia


# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## Rob & Ryan Lead From Behind
 - [https://www.youtube.com/watch?v=5sXkIUZEWIo](https://www.youtube.com/watch?v=5sXkIUZEWIo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-09-13 00:00:00+00:00

I made a bet. I lost. But it still paid off. https://leadfrombehind.org/

LEAD FROM BEHIND is on a mission to make colon cancer famous. 
We're raising awareness that #ColonCancer is The Preventable Cancer. 

► Colon cancer is the second biggest cancer killer in America. 1 in 24 Americans gets colon cancer. It doesn’t need to be - because it’s preventable.
► The best way to prevent colon cancer is by getting a colonoscopy when you turn 45. The guidelines changed in 2021 lowering the age from 50 to 45.
► People don’t want to talk about colonoscopies, let alone get one. We’re using humor and heart to change that.
► Colon cancer is rising in young people - predicted to be the top cancer killer for people under 50 by 2030.

LEAD FROM BEHIND is founded by Brooks Bell, powered by @colorectalcanceralliance, and created in partnership with Maximum Effort & Chrysi Philalithes.

#LeadFromBehind


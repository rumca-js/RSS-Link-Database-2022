# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Corsair wprowadza do oferty klawiaturę K60 PRO TKL i nowe produkty z rodziny K70 PRO
 - [https://ithardware.pl/aktualnosci/corsair_wprowadza_do_oferty_klawiature_k60_pro_tkl_i_nowe_produkty_z_rodziny_k70_pro-23276.html](https://ithardware.pl/aktualnosci/corsair_wprowadza_do_oferty_klawiature_k60_pro_tkl_i_nowe_produkty_z_rodziny_k70_pro-23276.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 21:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/23276_1.jpg" />            Corsar zapowiedział&nbsp;klawiaturę optyczno-mechaniczną bez bloku numerycznego z rodziny K60 PRO: K60 PRO TKL. Według producenta oferuje ona&nbsp;pełnię funkcji gamingowych klawiatur K60 PRO w zajmującej niewiele miejsca konstrukcji bez bloku...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/corsair_wprowadza_do_oferty_klawiature_k60_pro_tkl_i_nowe_produkty_z_rodziny_k70_pro-23276.html">https:

## Hyperbook prezentuje laptopa Liquid V17. Firma zaprasza na event dla graczy
 - [https://ithardware.pl/aktualnosci/hyperbook_prezentuje_laptopa_liquid_v17_firma_zaprasza_na_event_dla_graczy-23275.html](https://ithardware.pl/aktualnosci/hyperbook_prezentuje_laptopa_liquid_v17_firma_zaprasza_na_event_dla_graczy-23275.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 19:40:30+00:00

<img src="https://ithardware.pl/artykuly/min/23275_1.jpg" />            Najnowszy Hyperbook Liquid V17 został wyposażono w specjalny układ chłodzenia, kt&oacute;ry zdaniem producenta radykalnie zmienia koncepcję chłodzenia laptopa. Polska marka opr&oacute;cz prezentacji notebooka przygotowuje się także do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hyperbook_prezentuje_laptopa_liquid_v17_firma_zaprasza_na_event_dla_graczy-23275.html">https://ithardware.pl/akt

## Gigabyte wprowadzi aż 11 wariantów kart RTX 4090
 - [https://ithardware.pl/aktualnosci/gigabyte_wprowadzi_az_11_wariantow_kart_rtx_4090-23267.html](https://ithardware.pl/aktualnosci/gigabyte_wprowadzi_az_11_wariantow_kart_rtx_4090-23267.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 18:51:40+00:00

<img src="https://ithardware.pl/artykuly/min/23267_1.jpg" />            Gigabyte przygotowuje się do premiery RTX 4090, na co wskazują nowe&nbsp;pozycje w bazie danych EEC.&nbsp;Gigant planuje aż jedenaście modeli kart RTX 4090, w tym wersje Aorus, Windforce, Gaming i Eagle.&nbsp;

Lista modeli w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gigabyte_wprowadzi_az_11_wariantow_kart_rtx_4090-23267.html">https://ithardware.pl/aktualnosci/gigabyte_wprowadzi_az_11_w

## GoldenEye 007 Remaster oficjalnie zapowiedziany
 - [https://ithardware.pl/aktualnosci/goldeneye_007_remaster_oficjalnie_zapowiedziany-23274.html](https://ithardware.pl/aktualnosci/goldeneye_007_remaster_oficjalnie_zapowiedziany-23274.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 18:23:30+00:00

<img src="https://ithardware.pl/artykuly/min/23274_1.jpg" />            GoldenEye 007 to gra pierwotnie wydana w 1997 roku, kt&oacute;ra jest jedną z lepszych o przygodach słynnego Jamesa Bonda. Jakiś czas temu spekulowano o wydaniu remastera, kt&oacute;ry właśnie dziś został oficjalnie zapowiedziany.

GoldenEye 007...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/goldeneye_007_remaster_oficjalnie_zapowiedziany-23274.html">https://ithardware.pl/aktualnosci/goldene

## GoldenEye 007 oficjalnie zapowiedziany na konsole Xbox
 - [https://ithardware.pl/aktualnosci/goldeneye_007_oficjalnie_zapowiedziany_na_konsole_xbox-23274.html](https://ithardware.pl/aktualnosci/goldeneye_007_oficjalnie_zapowiedziany_na_konsole_xbox-23274.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 18:23:30+00:00

<img src="https://ithardware.pl/artykuly/min/23274_1.jpg" />            GoldenEye 007 to gra pierwotnie wydana w 1997 roku będąca&nbsp;z lepszych pozycji o przygodach słynnego Jamesa Bonda. Jakiś czas temu spekulowano o pracach nad wersją&nbsp;dedykowaną konsolom Xbox, kt&oacute;ra&nbsp;właśnie dziś została...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/goldeneye_007_oficjalnie_zapowiedziany_na_konsole_xbox-23274.html">https://ithardware.pl/aktualnosci/goldeneye

## Google nie wypuści Pixelbooka 2023. Projekt anulowano ze względu na oszczędności
 - [https://ithardware.pl/aktualnosci/google_nie_wypusci_pixelbooka_2023_projekt_anulowano_ze_wzgledu_na_oszczednosci-23272.html](https://ithardware.pl/aktualnosci/google_nie_wypusci_pixelbooka_2023_projekt_anulowano_ze_wzgledu_na_oszczednosci-23272.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 17:10:30+00:00

<img src="https://ithardware.pl/artykuly/min/23272_1.jpg" />            W związku z przygotowaniami Google do podjęcia środk&oacute;w&nbsp;oszczędnościowych, firma zdecydowała się na rozwiązanie działu odpowiedzialnego za prace nad kolejnym Pixelbookiem, kt&oacute;ry miał zadebiutować już w przyszłym roku....
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/google_nie_wypusci_pixelbooka_2023_projekt_anulowano_ze_wzgledu_na_oszczednosci-23272.html">https://ithardware.

## Cyberpunk nie zostanie porzucony. CD Projekt RED jest w pełni zaangażowany w rozwój marki
 - [https://ithardware.pl/aktualnosci/cyberpunk_nie_zostanie_porzucony_cd_projekt_red_jest_w_pelni_zaangazowany_w_rozwoj_marki-23273.html](https://ithardware.pl/aktualnosci/cyberpunk_nie_zostanie_porzucony_cd_projekt_red_jest_w_pelni_zaangazowany_w_rozwoj_marki-23273.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 16:13:50+00:00

<img src="https://ithardware.pl/artykuly/min/23273_1.jpg" />            Cyberpunk 2077 nie odni&oacute;sł sukcesu, jakiego CD Projekt RED oczekiwał, ale mimo tego studio nie zamierza porzucać swojej marki, tylko&nbsp;chce ją rozwijać. Czy to oznacza, że w przyszłości dostaniemy kolejną grę?

Nadzieje związane z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cyberpunk_nie_zostanie_porzucony_cd_projekt_red_jest_w_pelni_zaangazowany_w_rozwoj_marki-23273.html">https

## Apple podnosi cenę wymiany baterii w iPhone 14. Ta wzrosła prawie o 50%
 - [https://ithardware.pl/aktualnosci/apple_podnosi_cene_wymiany_baterii_w_iphone_14_ta_wzrosla_prawie_o_50-23270.html](https://ithardware.pl/aktualnosci/apple_podnosi_cene_wymiany_baterii_w_iphone_14_ta_wzrosla_prawie_o_50-23270.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 14:58:00+00:00

<img src="https://ithardware.pl/artykuly/min/23270_1.jpg" />            Wymiana baterii w nowych iPhone'ach 14 będzie kosztować teraz więcej niż w przypadku serii 13. Apple zdecydowało się na podniesienie ceny tej usługi aż o 45%. Wymiana uszkodzonego lub zużytego akumulatora w przypadku&nbsp;iPhone'a 14,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_podnosi_cene_wymiany_baterii_w_iphone_14_ta_wzrosla_prawie_o_50-23270.html">https://ithardware.pl/aktualno

## MSI Arc A380 - niskoprofilową kartę umieszczono w gotowcu i przetestowano w 3DMarku
 - [https://ithardware.pl/aktualnosci/msi_arc_a380_niskoprofilowa_karte_umieszczono_w_gotowcu_i_przetestowano_w_3dmarku-23266.html](https://ithardware.pl/aktualnosci/msi_arc_a380_niskoprofilowa_karte_umieszczono_w_gotowcu_i_przetestowano_w_3dmarku-23266.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 14:23:20+00:00

<img src="https://ithardware.pl/artykuly/min/23266_1.jpg" />            Na jednym z zagranicznych portali pojawił się gotowy zestaw komputerowy&nbsp;DAIV Z3-A380, kt&oacute;ry zawiera kartę graficzną MSI Intel Arc A380. Dokładniej m&oacute;wiąc jest to niskoprofilowa konstrukcja pozbawiona dodatkowych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/msi_arc_a380_niskoprofilowa_karte_umieszczono_w_gotowcu_i_przetestowano_w_3dmarku-23266.html">https://ithardware.pl/

## Lepiej nie uszkodzić Apple Watch Ultra. Naprawa smartwatcha będzie droga
 - [https://ithardware.pl/aktualnosci/lepiej_nie_uszkodzic_apple_watch_ultra_naprawa_smartwatcha_bedzie_droga-23271.html](https://ithardware.pl/aktualnosci/lepiej_nie_uszkodzic_apple_watch_ultra_naprawa_smartwatcha_bedzie_droga-23271.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 14:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/23271_1.jpg" />            Apple to firma, kt&oacute;ra się ceni, o czym świadczą wartości produkt&oacute;w, za kt&oacute;re musimy zapłacić niemało pieniędzy, ale jak się okazuje na tej liście są r&oacute;wnież usługi serwisowe.

Apple Watch Ultra jest najnowszym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/lepiej_nie_uszkodzic_apple_watch_ultra_naprawa_smartwatcha_bedzie_droga-23271.html">https://ithardware.pl/akt

## Bezpieczeństwo danych w firmie to podstawa i nie chodzi tu tylko o RODO
 - [https://ithardware.pl/artykuly/bezpieczenstwo_danych_w_firmie_jak_dbac-23268.html](https://ithardware.pl/artykuly/bezpieczenstwo_danych_w_firmie_jak_dbac-23268.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 13:41:50+00:00

<img src="https://ithardware.pl/artykuly/min/23268_1.jpg" />            Jeśli chodzi o środowisko profesjonalne, czyli wszelkiego rodzaju małe i średnie przedsiębiorstwa, niezależnie od rodzaju działalności, kluczowym zagadnieniem jest bezpieczeństwo danych. Nie chodzi już tylko o przetwarzanie danych osobowych i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/bezpieczenstwo_danych_w_firmie_jak_dbac-23268.html">https://ithardware.pl/artykuly/bezpieczenstwo_danych_w_

## Chiński pocisk napędzany borem będzie działał w powietrzu i pod wodą. Jest tylko jeden mały problem
 - [https://ithardware.pl/aktualnosci/chinski_pocisk_napedzany_borem_bedzie_dzialal_w_powietrzu_i_pod_woda_jest_tylko_jeden_maly_problem-23269.html](https://ithardware.pl/aktualnosci/chinski_pocisk_napedzany_borem_bedzie_dzialal_w_powietrzu_i_pod_woda_jest_tylko_jeden_maly_problem-23269.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 13:08:20+00:00

<img src="https://ithardware.pl/artykuly/min/23269_1.jpg" />            Chińscy naukowcy&nbsp;pracują nad stworzeniem naddźwiękowego pocisku napędzanego borem, kt&oacute;ry może latać jak komercyjny samolot pasażerski, a następnie pływać w wodzie jako torpeda.&nbsp;

Według raportu&nbsp;SCMP, zesp&oacute;ł z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chinski_pocisk_napedzany_borem_bedzie_dzialal_w_powietrzu_i_pod_woda_jest_tylko_jeden_maly_problem-23269.html

## To pamięci stanowić będą wąskie gardło dla dysków SSD PCIe 5.0
 - [https://ithardware.pl/aktualnosci/to_pamieci_stanowic_beda_waskie_gardlo_dla_dyskow_ssd_pcie_5_0-23258.html](https://ithardware.pl/aktualnosci/to_pamieci_stanowic_beda_waskie_gardlo_dla_dyskow_ssd_pcie_5_0-23258.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 12:25:01+00:00

<img src="https://ithardware.pl/artykuly/min/23258_1.jpg" />            Producenci w ostatnich tygodniach ogłaszają kolejne dyski SSD oparte na kontrolerach Phison E26, kt&oacute;re wykorzystują standard PCIe Gen 5.0. Chociaż ten układ pokładowy pozwala osiągnąć prędkość do 13 GB/s, większość zapowiedzianych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/to_pamieci_stanowic_beda_waskie_gardlo_dla_dyskow_ssd_pcie_5_0-23258.html">https://ithardware.pl/aktualnosci/

## Procesor graficzny NVIDIA AD102 z ponad 75 miliardami tranzystorów
 - [https://ithardware.pl/aktualnosci/procesor_graficzny_nvidia_ad102_z_ponad_75_miliardami_tranzystorow-23263.html](https://ithardware.pl/aktualnosci/procesor_graficzny_nvidia_ad102_z_ponad_75_miliardami_tranzystorow-23263.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 12:09:50+00:00

<img src="https://ithardware.pl/artykuly/min/23263_1.jpg" />            Jeden z informator&oacute;w, znany w sieci pod pseudonimem kopite7kimi udostępnił tweeta, w kt&oacute;rym poinformował, że flagowy procesor graficzny&nbsp;Ada Lovelace (AD102) będzie zawierał ponad 75 miliard&oacute;w tranzystor&oacute;w. To...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/procesor_graficzny_nvidia_ad102_z_ponad_75_miliardami_tranzystorow-23263.html">https://ithardware.pl/aktu

## W iPhone'ach montowane są chińskie pamięci NAND 3D od YMTC. Rzad USA wyraża zaniepokojenie
 - [https://ithardware.pl/aktualnosci/w_iphone_ach_montowane_sa_chinskie_pamieci_nand_3d_od_ymtc_rzad_usa_wyraza_zaniepokojenie-23265.html](https://ithardware.pl/aktualnosci/w_iphone_ach_montowane_sa_chinskie_pamieci_nand_3d_od_ymtc_rzad_usa_wyraza_zaniepokojenie-23265.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 11:40:20+00:00

<img src="https://ithardware.pl/artykuly/min/23265_1.jpg" />            Pozyskanie kolejnego producenta 3D NAND jest dla Apple bez wątpienia korzystne - po ostatnich miesiącach każda firma rozbudowuje swoją siatkę dostawc&oacute;w, jednak urzędnicy w USA nie patrzą przychylnie na takie działania, zwłaszcza jeśli...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/w_iphone_ach_montowane_sa_chinskie_pamieci_nand_3d_od_ymtc_rzad_usa_wyraza_zaniepokojenie-23265.html">htt

## GeForce RTX 4000 - nowe przecieki zdradzają, kiedy poszczególne modele trafią na rynek
 - [https://ithardware.pl/aktualnosci/geforce_rtx_4000_nowe_przecieki_zdradzaja_kiedy_poszczegolne_modele_trafia_na_rynek-23259.html](https://ithardware.pl/aktualnosci/geforce_rtx_4000_nowe_przecieki_zdradzaja_kiedy_poszczegolne_modele_trafia_na_rynek-23259.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 11:32:01+00:00

<img src="https://ithardware.pl/artykuly/min/23259_1.jpg" />            W sieci pojawiły się właśnie nowe przecieki na temat nadchodzących kart graficznych NVIDII z serii GeForce RTX 4000, kt&oacute;re zostaną wprowadzone na rynek w czwartym kwartale 2022 roku.

Najnowsze plotki, zdradzające daty premier...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_4000_nowe_przecieki_zdradzaja_kiedy_poszczegolne_modele_trafia_na_rynek-23259.html">https://ithardwar

## Nieudany start rakiety Jeffa Bezosa. New Shepard stanął w płomieniach, przerywając passę sukcesów
 - [https://ithardware.pl/aktualnosci/nieudany_start_rakiety_jeffa_bezosa_new_shepard_stanal_w_plomieniach_przerywajac_passe_sukcesow-23264.html](https://ithardware.pl/aktualnosci/nieudany_start_rakiety_jeffa_bezosa_new_shepard_stanal_w_plomieniach_przerywajac_passe_sukcesow-23264.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 11:01:20+00:00

<img src="https://ithardware.pl/artykuly/min/23264_1.jpg" />            Suborbitalna rakieta New Shepard Blue Origin doznała katastrofalnej awarii silnika podczas 23 pr&oacute;by startu, kończąc siedmioletnią passę 21 sukces&oacute;w.

Po kilku op&oacute;źnieniach, gł&oacute;wnie związanych z pogodą, kt&oacute;re...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nieudany_start_rakiety_jeffa_bezosa_new_shepard_stanal_w_plomieniach_przerywajac_passe_sukcesow-23264.ht

## Quest Pro - tak wygląda nowy headset VR od Meta. Wyciekł film z unboxingu
 - [https://ithardware.pl/aktualnosci/quest_pro_tak_wyglada_nowy_headset_vr_od_meta_wyciekl_film_z_unboxingu-23257.html](https://ithardware.pl/aktualnosci/quest_pro_tak_wyglada_nowy_headset_vr_od_meta_wyciekl_film_z_unboxingu-23257.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 09:19:01+00:00

<img src="https://ithardware.pl/artykuly/min/23257_1.jpg" />            Gogle Meta Quest Pro mają zadebiutować w przyszłym miesiącu, ale do sieci wyciekł właśnie film, kt&oacute;ry już pozwala nam dobrze przyjrzeć się temu headsetowi VR. Ten został opublikowany na Facebooku przez Ramiro Cardenasa, kt&oacute;ry...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/quest_pro_tak_wyglada_nowy_headset_vr_od_meta_wyciekl_film_z_unboxingu-23257.html">https://ithardware.pl/ak

## Administracja Bidena szukuje kolejne uderzenie w chińskich producentów. Tylko po co?
 - [https://ithardware.pl/aktualnosci/administracja_bidena_szukuje_kolejne_uderzenie_w_chinskich_producentow_tylko_po_co-23262.html](https://ithardware.pl/aktualnosci/administracja_bidena_szukuje_kolejne_uderzenie_w_chinskich_producentow_tylko_po_co-23262.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 09:01:20+00:00

<img src="https://ithardware.pl/artykuly/min/23262_1.jpg" />            Departament Handu USA chce poszerzyć listę technologii objętych zakazem eksporty do Chin. Problem w tym, że zakazy te są tylko na papierze.

Zaznajomione ze sprawą źr&oacute;dła przekazały Rutersowi informacje, z kt&oacute;rych wynika, że...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/administracja_bidena_szukuje_kolejne_uderzenie_w_chinskich_producentow_tylko_po_co-23262.html">https://ithar

## Microsoft wchodzi na rynek gamingowych laptopów. Nadchodzi Surface Gaming
 - [https://ithardware.pl/aktualnosci/microsoft_wchodzi_na_rynek_gamingowych_laptopow_nadchodzi_surface_gaming-23261.html](https://ithardware.pl/aktualnosci/microsoft_wchodzi_na_rynek_gamingowych_laptopow_nadchodzi_surface_gaming-23261.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 08:16:31+00:00

<img src="https://ithardware.pl/artykuly/min/23261_1.jpg" />            Rodzina urządzeń Surface od Microsoftu jest dostępna w przer&oacute;żnych opcjach, od standardowych laptop&oacute;w po wersje Pro i Studio, ale wygląda na to, że firma przygotowuje się do wprowadzenia na rynek swojego pierwszego notebooka Surface...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_wchodzi_na_rynek_gamingowych_laptopow_nadchodzi_surface_gaming-23261.html">https://ithardw

## Intel zapowiada procesor o fabrycznym taktowaniu 6 GHz
 - [https://ithardware.pl/aktualnosci/intel_zapowiada_procesor_o_fabrycznym_taktowaniu_6_ghz-23256.html](https://ithardware.pl/aktualnosci/intel_zapowiada_procesor_o_fabrycznym_taktowaniu_6_ghz-23256.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 07:13:14+00:00

<img src="https://ithardware.pl/artykuly/min/23256_1.jpg" />            W miniony weekend pisaliśmy o podkręceniu procesora Core i9-13900K do 8 GHz i Intel właśnie potwierdził ten nowy rekord świata, a jednocześnie zapowiedział, że szykuje CPU o taktowaniu fabrycznym sięgającym aż 6 GHz.&nbsp;

Tak naprawdę...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_zapowiada_procesor_o_fabrycznym_taktowaniu_6_ghz-23256.html">https://ithardware.pl/aktualnosci/intel_zap

## Chiny odkryły nieznany minerał na Księżycu. Nazwano go Changesite-(Y)
 - [https://ithardware.pl/aktualnosci/chiny_odkryly_nieznany_mineral_na_ksiezycu_nazwano_go_changesite_y-23245.html](https://ithardware.pl/aktualnosci/chiny_odkryly_nieznany_mineral_na_ksiezycu_nazwano_go_changesite_y-23245.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 06:50:50+00:00

<img src="https://ithardware.pl/artykuly/min/23245_1.jpg" />            Chiny ogłosiły, że w pr&oacute;bkach przywiezionych z Księżyca, odkryto nieznany dotąd minerał.&nbsp;inerał nazwany został &bdquo;Changesite-(Y)&rdquo; na cześć Chang'e &ndash; bogini księżyca z chińskiej mitologii.

Pr&oacute;bki...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chiny_odkryly_nieznany_mineral_na_ksiezycu_nazwano_go_changesite_y-23245.html">https://ithardware.pl/aktualnosci/chi

## Ubisoft kolejnym wydawcą, który podnosi ceny swoich gier
 - [https://ithardware.pl/aktualnosci/ubisoft_kolejnym_wydawca_ktory_podnosi_ceny_swoich_gier-23255.html](https://ithardware.pl/aktualnosci/ubisoft_kolejnym_wydawca_ktory_podnosi_ceny_swoich_gier-23255.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-09-13 06:17:50+00:00

<img src="https://ithardware.pl/artykuly/min/23255_1.jpg" />            Niestety Ubisoft postanowił dołączyć do grona wydawc&oacute;w, kt&oacute;rzy zdecydowali się podnieść ceny swoich gier. Wkr&oacute;tce firma zacznie sprzedawać swoje tytuły za 69,99 USD za wszystkie przyszłe duże gry AAA na nowszych systemach...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ubisoft_kolejnym_wydawca_ktory_podnosi_ceny_swoich_gier-23255.html">https://ithardware.pl/aktualnosci/ub


# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Dig Into Thor: Love and Thunder With These Exclusive Shot Breakdowns
 - [https://gizmodo.com/thor-love-thunder-vfx-marvel-studios-chris-hemsworth-1849530759](https://gizmodo.com/thor-love-thunder-vfx-marvel-studios-chris-hemsworth-1849530759)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 23:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--3SEKFf21--/c_fit,fl_progressive,q_80,w_636/332d21ac73439818e6397627efa5cd46.png" /><p>While <a href="https://gizmodo.com/thor-love-and-thunder-movie-review-thor-4-marvel-mcu-1849105691"><em>Thor: Love and Thunder</em></a> was <a href="https://gizmodo.com/thor-love-thunder-open-channel-1849149513">more divisive</a> than fans would have guessed a few months ago, there’s still plenty about it worth enjoying. Natalie Portman’s <a href="h

## Wizards of the Coast Wants to Shut Down TSR for Bigotry
 - [https://gizmodo.com/dnd-wizards-of-the-coast-lawsuit-tsr-space-frontiers-1849532281](https://gizmodo.com/dnd-wizards-of-the-coast-lawsuit-tsr-space-frontiers-1849532281)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 22:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--TQUouEJB--/c_fit,fl_progressive,q_80,w_636/6145c200ff61114971f4b5c0f99a55f9.jpg" /><p>Citing concerns over racist and transphobic material, <em>Dungeons &amp; Dragons</em> publisher <a href="https://gizmodo.com/spelljammer-dungeons-and-dragons-dnd-confirmed-1849361439">Wizards of the Coast</a> is trying to take back an old game to prevent its publication, according to a report in <a href="https://www.polygon.com/tabletop-games/233496

## Bankrupt Crypto Broker Celsius Has New Plan to Become Hot Again, Codenamed 'Kelvin'
 - [https://gizmodo.com/celsius-crypto-kelvin-1849532210](https://gizmodo.com/celsius-crypto-kelvin-1849532210)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 21:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--C9qyabHx--/c_fit,fl_progressive,q_80,w_636/14195c899b1b75fef4eaf5b6ec2e3f6d.jpg" /><p>Kelvin, as a temperature scale, uses “absolute zero” as its baseline. That lowest conceived temperature would effectively stop all particle activity due to a lack of any semblance of energy. That point of temperature has never been achieved, but failed crypto firm Celsius seems to want to get as close as it can to…</p><p><a href="https://gizmodo.com

## The 15 Biggest Tech Layoffs of the Year... So Far
 - [https://gizmodo.com/the-12-biggest-tech-layoffs-of-the-year-so-far-1849372352](https://gizmodo.com/the-12-biggest-tech-layoffs-of-the-year-so-far-1849372352)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 21:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--YmgVsgCe--/c_fit,fl_progressive,q_80,w_636/a0ab1fc48131350ab50bc7c4bb611aea.jpg" /><p>Tens of thousands of tech employees in jobs previously thought to be secure and high-paying have had to pack their bags in recent months. They’re seeking out new positions as a downturn in the wider economy hits the tech industry especially hard. SoundCloud, one of the leading music streaming platforms favored by…</p><p><a href="https://gizmodo.com/

## DC Release Dates: When to See DCEU Movies and HBO Max Shows
 - [https://gizmodo.com/warner-bros-dc-release-dates-hbo-max-cast-details-1848354161](https://gizmodo.com/warner-bros-dc-release-dates-hbo-max-cast-details-1848354161)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 21:30:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--QBlM_DWO--/c_fit,fl_progressive,q_80,w_636/4850d2dc11bba95cd15d04db2b0038ba.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--n_w1xmOy--/c_fit,fl_progressive,q_80,w_636/4850d2dc11bba95cd15d04db2b0038ba.mp4" type="video/mp4" /></video><p>Marvel’s streaming shows and movies may still steal the majority of the headlines, but the <a href="https://gizmodo.com/new-black-adam-the-flash-and-aquaman-2-footage

## The Eggplant Emoji Makes You Less Likable According to New Report
 - [https://gizmodo.com/emoji-eggplant-adobe-texting-1849531595](https://gizmodo.com/emoji-eggplant-adobe-texting-1849531595)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 21:05:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--TU8sDnqy--/c_fit,fl_progressive,q_80,w_636/8b1b72e151689a93449bd26c7e067fcf.png" /><p><a href="https://gizmodo.com/the-dea-published-a-list-of-emoji-code-for-drugs-1849408074">Emojis</a> make our lives a lot easier. From actually serving to represent how we’re feeling to being the punchline to an inside joke, emojis has revolutionized how we text, tweet, and communicate. With that, Adobe just released a trend report that surveyed 5,0

## Get Your Hands on One of Elon Musk's Family Jewels
 - [https://gizmodo.com/elon-musk-jewelry-auction-1849531588](https://gizmodo.com/elon-musk-jewelry-auction-1849531588)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 20:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vIMs7ojW--/c_fit,fl_progressive,q_80,w_636/99d2daf8336d8f8254422688da0f1f8e.png" /><p>You read that headline right. For a limited time only, you can purchase an emerald necklace allegedly derived from the Musk family jewel mine.<br /></p><p><a href="https://gizmodo.com/elon-musk-jewelry-auction-1849531588">Read more...</a></p>

## Meta's Reportedly Combining Teams Responsible for Moderating Ads and User Content
 - [https://gizmodo.com/meta-facebook-ads-user-content-1849531750](https://gizmodo.com/meta-facebook-ads-user-content-1849531750)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 20:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--1VDVDErS--/c_fit,fl_progressive,q_80,w_636/acc9f6d048f3a72b98bc8e1bbe393d6d.jpg" /><p>Meta’s reportedly moving to combine two integrity teams in charge of moderating different types of content under one roof in an effort to cut down costs. The significant reorganizing comes as some workers continue to fear the prospect of potential layoffs looming over the horizon.</p><p><a href="https://gizmodo.com/meta-facebook-ads-user-content-184

## Patreon Enacts Layoffs, Cutting 17% of Staff
 - [https://gizmodo.com/patreon-layoffs-podcasts-tech-1849530943](https://gizmodo.com/patreon-layoffs-podcasts-tech-1849530943)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 20:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--LPvTY_iB--/c_fit,fl_progressive,q_80,w_636/1559179a0d999050f20f912942087976.jpg" /><p>Patreon is laying off about 80 employees, comprising 17% of the subscription platform’s staff. The news first came in an <a href="https://www.instagram.com/p/CidAMM7pQ7u/?igshid=YmMyMTA2M2Y%3D" rel="noopener noreferrer" target="_blank">Instagram post</a> from Jack Conte, the creator loyalty company’s CEO and in <a href="https://blog.patreon.com/a-no

## How to Pack a Go Bag for Climate Disasters
 - [https://gizmodo.com/how-to-pack-a-go-bag-climate-disasters-wildfires-floods-1849457027](https://gizmodo.com/how-to-pack-a-go-bag-climate-disasters-wildfires-floods-1849457027)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 20:42:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--A0T-uJOr--/c_fit,fl_progressive,q_80,w_636/3f4b6e68ef5dac3a84bd4329d045701d.jpg" /><p>Climate change-fueled natural disasters, from wildfires to  floods, are affecting more Americans every year. Many people are caught off guard by emergencies in their communities, but there are ways to prepare that can help you protect your life and health when the worst happens.<br /></p><p><a href="https://gizmodo.com/how-to-pack-a-go-bag-climate-d

## 5 Things We Liked, and 3 We Didn't, About Cyberpunk Edgerunners
 - [https://gizmodo.com/cyberpunk-edgerunners-netflix-trigger-review-spoilers-1849529423](https://gizmodo.com/cyberpunk-edgerunners-netflix-trigger-review-spoilers-1849529423)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 20:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--6JomRq_o--/c_fit,fl_progressive,q_80,w_636/bc2498d7d593f138cc8acbd1cf8960d0.png" /><p><a href="https://gizmodo.com/cyberpunk-edgerunner-trailer-studio-trigger-2077-1849355564"><em>Cyberpunk: Edgerunners</em></a> has a lot of weird baggage attached, from its connection to the controversial and <a href="https://gizmodo.com/cyberpunk-2077s-retrofuturistic-world-is-worth-explorin-1847254174">divisive CD Projekt game</a> to being the late

## China Accuses the NSA of Hacking a Top University to Steal Data
 - [https://gizmodo.com/china-nsa-northwestern-polytechnical-university-hack-1849530364](https://gizmodo.com/china-nsa-northwestern-polytechnical-university-hack-1849530364)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 20:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--7G0DuD6C--/c_fit,fl_progressive,q_80,w_636/82b829fd601151a666739930d7a9fa9b.jpg" /><p>China claims that America’s National Security Agency used sophisticated cyber tools to hack into an elite research university on Chinese soil. The attack allegedly targeted the Northwestern Polytechnical University in Xi’an (not to be confused with a California <a href="https://www.npu.edu/" rel="noopener noreferrer" target="_blank">school</a> of th

## No Such Thing as an 'Average Dog': How Pups Get Their Personalities
 - [https://gizmodo.com/the-year-of-the-puppy-alexandra-horowitz-1849525880](https://gizmodo.com/the-year-of-the-puppy-alexandra-horowitz-1849525880)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 19:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--fQfc7keQ--/c_fit,fl_progressive,q_80,w_636/28b2bd8bd9daab82aea03081388e6288.jpg" /><p>Alexandra Horowitz has been studying the inner lives of humanity’s best friend for about two decades, including in her <a href="https://psychology.barnard.edu/profiles/alexandra-horowitz" rel="noopener noreferrer" target="_blank">current role</a> as head of the  Dog Cognition Lab at Barnard College in New York. Since 2009, Horowitz has also been a b

## Barbarian Director Has Batman Fanfic Ready to Go, Like Anytime
 - [https://gizmodo.com/barbarian-director-would-love-to-make-a-batman-movie-1849531258](https://gizmodo.com/barbarian-director-would-love-to-make-a-batman-movie-1849531258)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--LKY6fhLh--/c_fit,fl_progressive,q_80,w_636/9260c8a1cd7fdded46d5336919481bc9.jpg" /><p>In an interview with <a href="https://bloody-disgusting.com/exclusives/3731057/barbarian-director-zach-cregger-teases-his-weird-and-ambitious-next-horror-movie-exclusive/" rel="noopener noreferrer" target="_blank">Bloody Disgusting</a>, Zach Cregger, the writer-director of current <a href="https://gizmodo.com/speak-no-evil-shocking-danish-horror-fil

## Alex Jones' Second Trial Over His Lies About Sandy Hook Attack Begins
 - [https://gizmodo.com/alex-jones-infowars-sandy-hook-trial-1849530310](https://gizmodo.com/alex-jones-infowars-sandy-hook-trial-1849530310)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--tupRsKvt--/c_fit,fl_progressive,q_80,w_636/6224bab25e6a5982d3f631073ceececf.jpg" /><p>InfoWars’ <a href="https://gizmodo.com/alex-jones-perjury-sandy-hook-trial-infowars-1849366019">Alex Jones</a> is in the throes of his second defamation trial regarding his infamous comments about the Sandy Hook Elementary School shooting. While Jones was not in attendance, the trial began today in Connecticut.<br /></p><p><a href="https://gizmodo.c

## NASA Has a New Target Date to Launch SLS Megarocket
 - [https://gizmodo.com/nasa-new-target-date-launch-sls-megarocket-artemis-1849530433](https://gizmodo.com/nasa-new-target-date-launch-sls-megarocket-artemis-1849530433)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--tpNzEM2f--/c_fit,fl_progressive,q_80,w_636/7bd7d781b091df5619dda0530a00ac07.jpg" /><p>After two failed  attempts to launch its mega Moon rocket, NASA is  planning for a third go at its inaugural  Artemis mission. The space agency is now hoping to test the rocket on September 21 and finally launch it to space six days later,  with a backup opportunity in early October. That is, if Space Force agrees. <br /></p><p><a href="https://gizm

## Squid Game's Creator Has Some Thoughts on That Game Show Spin-off
 - [https://gizmodo.com/netflix-squid-game-emmys-reality-game-show-1849530885](https://gizmodo.com/netflix-squid-game-emmys-reality-game-show-1849530885)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 18:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--4qtwF5Na--/c_fit,fl_progressive,q_80,w_636/ea5634289c598d5128f18e4860f3bdea.png" /><p>Netflix hit <a href="https://gizmodo.com/squid-game-season-2-netflix-teaser-1849051004"><em>Squid Game</em></a><em> </em><a href="https://gizmodo.com/squid-game-best-lead-actor-emmy-awards-netflix-1849529353">won a number of Emmys</a> last night, including best lead in the drama category for <a href="https://gizmodo.com/star-wars-squid-game-lee-jung

## Every Netflix Game, Ranked
 - [https://gizmodo.com/every-netflix-game-ranked-from-worst-to-best-1849105949](https://gizmodo.com/every-netflix-game-ranked-from-worst-to-best-1849105949)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 18:06:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--6z9_wwCL--/c_fit,fl_progressive,q_80,w_636/613517a3649c64afb0558667f2b609ee.jpg" /><p>Netflix wants you to keep your account… No, Netflix NEEDS you to keep your account. So, in order to keep you around, the company needs to give you other reasons to paying your monthly tithe. And it seems to <a href="https://gizmodo.com/netflix-s-attempt-at-gaming-is-awkward-as-hell-1848032178">believe</a> a pivot to mobile video games might do the t

## Shocking Photos Show Spain's Punishing Drought
 - [https://gizmodo.com/spain-drought-olive-crop-2022-1849529071](https://gizmodo.com/spain-drought-olive-crop-2022-1849529071)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 17:39:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ImVvvdlk--/c_fit,fl_progressive,q_80,w_636/5dbc777603c53a96d00ea830b3fddbed.jpg" /><p>Parts of Spain this summer are experiencing the worst drought the country has seen in 1,200 years, as extreme heat and drought grip much of Europe.</p><p><a href="https://gizmodo.com/spain-drought-olive-crop-2022-1849529071">Read more...</a></p>

## Whoopsies: Intel Self-Leaks Upcoming 13th Gen i5, i7, i9 CPU Specs
 - [https://gizmodo.com/intel-13th-gen-raptor-lake-core-i5-i7-i9-cpu-specs-amd-1849530630](https://gizmodo.com/intel-13th-gen-raptor-lake-core-i5-i7-i9-cpu-specs-amd-1849530630)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 17:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--aRxBhcGU--/c_fit,fl_progressive,q_80,w_636/0f6febdffa401c2a2902196666a9b031.jpg" /><p>Intel accidentally dropped details for its upcoming slate of desktop processors on its Canadian site, and though the company was quick to pull the specs, the Internet Archive has your back for those looking to see the <a href="http://web.archive.org/web/20220912155753/https://www.intel.ca/content/www/ca/en/gaming/resources/gaming-cpu.html" rel="noop

## The 14 Best Reveals From the Obi-Wan Kenobi Documentary
 - [https://gizmodo.com/obi-wan-kenobi-documentary-disney-plus-star-wars-vader-1849530139](https://gizmodo.com/obi-wan-kenobi-documentary-disney-plus-star-wars-vader-1849530139)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 17:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--PCXJJDHk--/c_fit,fl_progressive,q_80,w_636/f30b162bb41cfb951edca7ed2a4b9f20.jpg" /><p>Think of all the years fans were waiting for <a href="https://gizmodo.com/report-ewan-mcgregor-will-return-as-obi-wan-kenobi-in-1837288832">Ewan McGregor to return</a> as Obi-Wan Kenobi. Think of all the thousands of times the actor was asked about it. This year, <a href="https://gizmodo.com/obi-wan-kenobi-finale-ewan-mcgregor-darth-vader-luke-sk-18

## In Major Win for Gig Workers, Uber Agrees to Pay New Jersey $100 Million for Mischaracterizing Drivers as Contractors
 - [https://gizmodo.com/uber-gig-workers-new-jersey-ride-share-1849530325](https://gizmodo.com/uber-gig-workers-new-jersey-ride-share-1849530325)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ktKq5Ugd--/c_fit,fl_progressive,q_80,w_636/a1cf34d1304ab3311f4a55e47ed87f0f.jpg" /><p>Uber may have built its hailing empire, in part, by <a href="https://www.theguardian.com/news/2022/jul/10/uber-files-leak-reveals-global-lobbying-campaign" rel="noopener noreferrer" target="_blank">notoriously</a> <a href="https://www.vice.com/en/article/8xwxyv/uber-became-big-by-ignoring-laws-and-it-plans-to-keep-doing-that" rel="noopener noreferre

## Man Who Sued Over Alleged 'Baby Shark' Torture Found Dead in Jail Cell
 - [https://gizmodo.com/baby-shark-oklahoma-torture-jail-1849529662](https://gizmodo.com/baby-shark-oklahoma-torture-jail-1849529662)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 16:30:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--PBbJuhe2--/c_fit,fl_progressive,q_80,w_636/5ee668a04f3eecaf545e1e9e4c03c83f.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--rRmFT_K2--/c_fit,fl_progressive,q_80,w_636/5ee668a04f3eecaf545e1e9e4c03c83f.mp4" type="video/mp4" /></video><p>“Baby Shark,” the viral kids song, certainly is annoying. It is so annoying in fact that it was allegedly used to torture detainees in the Oklahoma County Detention C

## Rick and Morty's Season 6 Premiere Is Now Streaming Free on YouTube
 - [https://gizmodo.com/rick-and-morty-season-six-watch-now-first-episode-1849530110](https://gizmodo.com/rick-and-morty-season-six-watch-now-first-episode-1849530110)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 16:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--1UrDx3dN--/c_fit,fl_progressive,q_80,w_636/b4735ea9d6bc4bb41f1c48253e4b4a8e.png" /><p>In the much-anticipated <a href="https://gizmodo.com/rick-and-morty-s6-justin-roiland-dan-harmon-adult-swim-1849481092">buildup</a> to <em>Rick and Morty</em>’s season six premiere, Adult Swim released an interactive fan event where <a href="https://gizmodo.com/rick-and-mortys-wormageddon-is-somehow-stranger-than-yo-1849440740">Wormageddon sculpture

## What the Orion Nebula Looks Like to Webb Telescope Vs Hubble Telescope
 - [https://gizmodo.com/orion-nebula-webb-hubble-telescope-images-1849529693](https://gizmodo.com/orion-nebula-webb-hubble-telescope-images-1849529693)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 16:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--P0WEAuD5--/c_fit,fl_progressive,q_80,w_636/8657d2246446a206b8d32131f4a0ce5a.png" /><p>The Webb Telescope recently imaged a region of the Orion Nebula associated with star birth, and the result is about what we’ve come to expect from the cutting-edge space observatory. </p><p><a href="https://gizmodo.com/orion-nebula-webb-hubble-telescope-images-1849529693">Read more...</a></p>

## Class Begins in the First School for Good and Evil Trailer
 - [https://gizmodo.com/school-for-good-and-evil-trailer-netflix-movie-1849529457](https://gizmodo.com/school-for-good-and-evil-trailer-netflix-movie-1849529457)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 15:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--el84AJWo--/c_fit,fl_progressive,q_80,w_636/0f06e3cf16653378e1f1ebfe2e6ba1be.jpg" /><p>Okay, yes, sure; this is a movie about kids who get whisked away from the normal world and stuck in a <a href="https://gizmodo.com/at-school-for-angels-and-demons-one-devil-just-wants-t-1358866906">magical school </a>taught by a plethora of A-list celebrity actors in which the heroes and the villains are rigorously defined. But if you can get certai

## NASA’s CAPSTONE Moon Probe Is in More Trouble Than We Realized
 - [https://gizmodo.com/capstone-moon-spacecraft-tumbling-nasa-1849529736](https://gizmodo.com/capstone-moon-spacecraft-tumbling-nasa-1849529736)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 15:37:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--uaL_s2u8--/c_fit,fl_progressive,q_80,w_636/5016e5b3dd7c0f685c21d27be8a79bc0.jpg" /><p>Controllers with the CAPSTONE mission are attempting to regain control of the Moon-bound probe, which is currently tumbling, experiencing temperature issues, and unable to use its solar panels to fully recharge its batteries.</p><p><a href="https://gizmodo.com/capstone-moon-spacecraft-tumbling-nasa-1849529736">Read more...</a></p>

## Meta Dredges Sensitive Data for Over 100 Rival Companies While Still Claiming It Isn't a Monopoly
 - [https://gizmodo.com/meta-ftc-facebook-antitrust-1849529661](https://gizmodo.com/meta-ftc-facebook-antitrust-1849529661)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 15:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--j5YJobMi--/c_fit,fl_progressive,q_80,w_636/92b269f2f6e402a8702797aa328199ef.jpg" /><p>An ongoing Federal Trade Commission lawsuit against Meta has claimed the tech giant has been anticompetitive. How does Meta respond? By demanding the sensitive data of hundreds of tech companies, including several of its biggest rivals and competitors.</p><p><a href="https://gizmodo.com/meta-ftc-facebook-antitrust-1849529661">Read more...</a></p>

## GoldenEye 007 Is Coming to Nintendo Switch With Online Multiplayer, Xbox Game Pass Gets Remaster
 - [https://gizmodo.com/goldeneye-007-remaster-nintendo-switch-xbox-online-play-1849529967](https://gizmodo.com/goldeneye-007-remaster-nintendo-switch-xbox-online-play-1849529967)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 15:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--NXydJiWL--/c_fit,fl_progressive,q_80,w_636/5f853d50b56256fe89d50b21c4e2344e.jpg" /><p>The one question that’s been on every Nintendo fan’s mind ever since the company started porting its past hits to newer consoles is when <em>GoldenEye 007</em>, the N64's beloved first-person shooter, would show up again. After years of licensing and rights battles, we finally have an answer, and it’s even better than we could…</p><p><a href="https:

## Internet Slang Becomes Legit
 - [https://gizmodo.com/internet-slang-becomes-legit-1849529115](https://gizmodo.com/internet-slang-becomes-legit-1849529115)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 15:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--d0v8SmfQ--/c_fit,fl_progressive,q_80,w_636/71355dad26b6cd4441787dcde52a182e.jpg" /><p><a href="https://gizmodo.com/internet-slang-becomes-legit-1849529115">Read more...</a></p>

## Twitter Shareholders Likely to Vote in Favor of Embattled Musk Deal
 - [https://gizmodo.com/twitter-shareholders-elon-musk-bots-1849529246](https://gizmodo.com/twitter-shareholders-elon-musk-bots-1849529246)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 15:17:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--wdPIQKiS--/c_fit,fl_progressive,q_80,w_636/c327e9c85b588867f1c27f3e20e63e60.jpg" /><p>Twitter’s stockholders are making their voices heard. They’ve reportedly voted in favor of the company’s $44 billion acquisition deal with Elon Musk, according to <a href="https://www.reuters.com/markets/deals/most-twitter-shareholders-vote-favor-sale-musk-sources-2022-09-12/" rel="noopener noreferrer" target="_blank">a report from</a> Reuters <a hr

## Squid Game Makes History (Again), This Time at the Emmys
 - [https://gizmodo.com/squid-game-best-lead-actor-emmy-awards-netflix-1849529353](https://gizmodo.com/squid-game-best-lead-actor-emmy-awards-netflix-1849529353)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 14:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--FCnZChv0--/c_fit,fl_progressive,q_80,w_636/d78a3bd7aa89ce9a361a582ec751b961.jpg" /><p>As <a href="https://gizmodo.com/arcane-netflix-emmy-win-bridging-the-rift-videos-1849495829">Awards</a> season continues, <a href="https://gizmodo.com/emmy-nomination-2022-squid-game-stranger-things-moon-kn-1849169151"><em>Squid Game</em></a> supremacy is nigh. The Netflix-produced dystopian fiction show has continued to show up to <a href="https://

## The Twitter Whistleblower Is Testifying Before Congress
 - [https://gizmodo.com/twitter-whistleblower-peiter-zatko-congress-testimony-1849529511](https://gizmodo.com/twitter-whistleblower-peiter-zatko-congress-testimony-1849529511)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 14:19:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--dhYNT5b2--/c_fit,fl_progressive,q_80,w_636/0297d37ae1f64efb5b357035853cac14.jpg" /><p>Twitter is facing a day of reckoning at a hearing on Capitol Hill today, and someone from the company won’t even be there to offer its side of the story. </p><p><a href="https://gizmodo.com/twitter-whistleblower-peiter-zatko-congress-testimony-1849529511">Read more...</a></p>

## Updates From Halloween Ends, Armor Wars, and More
 - [https://gizmodo.com/halloween-ends-david-gordon-green-michael-myers-1849528586](https://gizmodo.com/halloween-ends-david-gordon-green-michael-myers-1849528586)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 14:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--m-TrNo9q--/c_fit,fl_progressive,q_80,w_636/3b41d36ac9371febcfdb9600348a1790.png" /><p>Michael Giacchino says he’s somehow found time to score Marvel’s <em>Werewolf by Night</em>. Tiffany returns in new <em>Chucky</em> season 2 pictures. Plus, what’s coming on <em>Star Trek: Lower Decks</em> and <em>Rick and Morty</em>. Spoilers now!<br /></p><p><a href="https://gizmodo.com/halloween-ends-david-gordon-green-michael-myers-1849528586">R

## Weird Hexagonal Diamonds Came From an Asteroid-Dwarf Planet Smashup
 - [https://gizmodo.com/hexagonal-diamonds-lonsdaleite-meteorites-1849524782](https://gizmodo.com/hexagonal-diamonds-lonsdaleite-meteorites-1849524782)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 13:21:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ypiU8Sw6--/c_fit,fl_progressive,q_80,w_636/a96006e34deddb7bf19fbec26e4d6c98.jpg" /><p>New research indicates that a rare form of diamond may originate in the burbling cores of distant worlds, arriving on Earth thanks to violent cosmic collisions.</p><p><a href="https://gizmodo.com/hexagonal-diamonds-lonsdaleite-meteorites-1849524782">Read more...</a></p>

## The Cheapest Kindle Is Now Less Cheap, but It’s Got a Better Screen
 - [https://gizmodo.com/kindle-cheapest-version-upgrade-more-expensive-screen-1849525251](https://gizmodo.com/kindle-cheapest-version-upgrade-more-expensive-screen-1849525251)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--EAKUPc4r--/c_fit,fl_progressive,q_80,w_636/2b62368ddb16425c7d9db1f0f62d1d17.jpg" /><p>If all you really care about is reading, you don’t need to spend more than $100 on an e-reader. Amazon’s newest entry-level Kindle is even easier on the eyes, thanks to an an upgraded screen, but with a $100 starting price, it’s slightly more expensive than its $90 predecessor (thanks, pandemic!). It’s even pricier if…</p><p><a href="https://gizmodo

## How To Set Up Guest Mode So Someone Else Can Use Your Android Phone
 - [https://gizmodo.com/android-phone-guest-mode-how-to-enable-set-up-users-1849523145](https://gizmodo.com/android-phone-guest-mode-how-to-enable-set-up-users-1849523145)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 12:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--WuhbpXeb--/c_fit,fl_progressive,q_80,w_636/23d19024905e496cbd94f1e56cd9dbed.jpg" /><p>While you might have never realized it, your Android phone can support multiple user accounts in the same way Windows and macOS can—and although you’re probably not sharing your smartphone with too many people day to day, there is a Guest Mode feature available than can be helpful if you ever need to lend your phone…</p><p><a href="https://gizmodo.c

## GM's Cruise to Launch Robotaxis in Austin and Phoenix by End of 2022
 - [https://gizmodo.com/gm-cruise-launch-robotaxis-austin-phoenix-end-2022-1849528762](https://gizmodo.com/gm-cruise-launch-robotaxis-austin-phoenix-end-2022-1849528762)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-09-13 10:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--SK0M52CN--/c_fit,fl_progressive,q_80,w_636/c28dd9d08d75577f101fc54e2046137d.jpg" /><p>Cruise will launch its autonomous taxi service in Phoenix and Austin before the end of 2022, according to Kyle Vogt, the CEO of driverless car company. And Vogt promises that his company is planning to expand rapidly in 2023 if everything goes to plan.</p><p><a href="https://gizmodo.com/gm-cruise-launch-robotaxis-austin-phoenix-end-2022-1849528762">


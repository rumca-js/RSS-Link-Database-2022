# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Oh F*ck, He's At It Again
 - [https://www.youtube.com/watch?v=mJ3IdmlD9Mw](https://www.youtube.com/watch?v=mJ3IdmlD9Mw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-09-14 00:00:00+00:00

As Bill Gates buys up yet more farmland, are we seeing the systematic transfer of land from farmers to oligarchs happening in real time? 
#billgates #farmers #farmland 

References
https://www.newsweek.com/bill-gates-north-dakota-land-purchase-sparks-questions-online-1722660
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## I Can't Believe This Just Happened
 - [https://www.youtube.com/watch?v=PXC-xP1UNrA](https://www.youtube.com/watch?v=PXC-xP1UNrA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-09-13 00:00:00+00:00

As anti-royal protesters are being arrested in the U.K., how exactly are they breaking the law, and just what has happened to freedom of speech? #queen #protest #royals

References
https://www.npr.org/2022/09/12/1122379162/uk-anti-royal-arrests
https://www.commondreams.org/views/2022/09/12/it-time-throw-monarchies-world-dustbin-history
--------------------------------------------------------------------------------------------------------------------------
Tickets To My Live Show: https://www.russellbrand.com/live-dates/

Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


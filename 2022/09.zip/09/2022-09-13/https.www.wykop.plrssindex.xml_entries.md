## Chińskie komponenty w iPhone'ach. Apple „igra z ogniem”
 - [https://www.wykop.pl/link/6814441/chinskie-komponenty-w-iphone-ach-apple-igra-z-ogniem/](https://www.wykop.pl/link/6814441/chinskie-komponenty-w-iphone-ach-apple-igra-z-ogniem/)
 - RSS feed: https://www.wykop.pl/rss/index.xml/
 - date published: 2022-09-13 13:47:02+00:00

<img src="https://www.wykop.pl/cdn/c3397993/link_1663026306CnWTrMPYjwEprg6lBcoBn9,w104h74.jpg" /><br />
		 Koncern Apple „igra z ogniem&quot;, używając chińskich komponentów w swoich smartfonach. Republikanie zasiadający w Kongresie zapowiedzieli, że jeśli w nowym modelu iPhone'a znajdą się chińskie czipy pamięci, firma doczeka się drobiazgowej kontroli.


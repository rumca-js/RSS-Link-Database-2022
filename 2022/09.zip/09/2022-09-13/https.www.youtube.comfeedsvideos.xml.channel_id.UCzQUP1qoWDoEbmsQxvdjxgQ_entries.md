# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Max Lugavere on Controversial Alzheimer's Drugs and Studies
 - [https://www.youtube.com/watch?v=hR2vPB5b20Y](https://www.youtube.com/watch?v=hR2vPB5b20Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-09-14 00:00:00+00:00

Taken from JRE #1870 w/Max Lugavere:
https://open.spotify.com/episode/7fkDRpWn7bVWDDsDaOEy5y?si=f623c319b9494d57

## Physician Gabor Mate Gives His Analysis on ADHD and Anxiety
 - [https://www.youtube.com/watch?v=4jQSOSi2DA8](https://www.youtube.com/watch?v=4jQSOSi2DA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-09-13 00:00:00+00:00

Taken from JRE #1869 w/Gabor Mate:
https://open.spotify.com/episode/2XCJAb43d6b4cNLdKS9jSw?si=94595d5f33cc4b24


# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Russia has spent over $300 million on influencing foreign elections since 2014, US officials say
 - [https://www.cnn.com/2022/09/13/politics/russia-foreign-elections-influence/index.html](https://www.cnn.com/2022/09/13/politics/russia-foreign-elections-influence/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-13 19:56:24+00:00

Russia has covertly transferred over $300 million to foreign political parties around the globe since 2014, a senior Biden administration official said Tuesday, citing a review by the US intelligence community.

## Americans won't be going crazy with holiday gifting this year
 - [https://www.cnn.com/2022/09/13/economy/holiday-forecast-deloitte/index.html](https://www.cnn.com/2022/09/13/economy/holiday-forecast-deloitte/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-13 10:11:47+00:00

The kids, the grandparents, the babysitter, maybe your favorite aunt or uncle. That's it.

## Blinken calls Iran's latest response to nuclear deal proposal a 'step backward'
 - [https://www.cnn.com/2022/09/12/politics/iran-nuclear-deal-blinken/index.html](https://www.cnn.com/2022/09/12/politics/iran-nuclear-deal-blinken/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-13 02:18:00+00:00

Iran has taken "a step backward" with its latest response to a nuclear deal proposal, US Secretary of State Antony Blinken said Monday, calling a near-term agreement "unlikely."

## Analysis: The clock is ticking on a big threat to the US economy
 - [https://www.cnn.com/2022/09/12/economy/nightcap-rail-strike-cpi-preview/index.html](https://www.cnn.com/2022/09/12/economy/nightcap-rail-strike-cpi-preview/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-09-13 00:01:08+00:00

This Friday, tens of thousands of railroad workers are poised to go on strike, potentially bringing a nearly a third of all US freight to a grinding halt. It would be the first national rail strike in 30 years.


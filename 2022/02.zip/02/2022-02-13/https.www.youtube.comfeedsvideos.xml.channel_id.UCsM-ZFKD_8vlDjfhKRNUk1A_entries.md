# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Patrick the Pan - Porozmawiajmy o emocjach - live MUZO.FM
 - [https://www.youtube.com/watch?v=sBQv4vNAddA](https://www.youtube.com/watch?v=sBQv4vNAddA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-02-14 00:00:00+00:00

Patrick the Pan na żywo w MUZO.FM. Utwór Porozmawiajmy o emocjach pochodzi z płyty Miło wszystko. 

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Patrick the Pan: http://www.facebook.com/patrickthepan
Instagram Patrick the Pan: http://www.instagram.com/patrick_the_pan
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku


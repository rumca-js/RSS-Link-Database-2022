# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Kiss Me More | Doja Cat | funk cover ft. Samuel Larsen
 - [https://www.youtube.com/watch?v=02dWb6ZULlc](https://www.youtube.com/watch?v=02dWb6ZULlc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-02-14 00:00:00+00:00

Join the Vinyl Club tier by Feb. 28 to get "Technicolor Magic" AND "Best of 2021" on vinyl! http://modal.scarypocketsfunk.com/patreon

Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Doja Cat's "Kiss Me More" by Scary Pockets & Samuel Larsen.

MUSICIAN CREDITS
Lead vocal: Samuel Larsen
Drums: Abe Laboriel Jr.
Bass: Nick Campbell
Keys: Carey Frank
Guitar: Ariel Posen
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Kenzo Le 
Editor: Adam Kritzberg
Skit editor: Jude Smith

Recorded Live at East West in Los Angeles, CA.

#ScaryPockets #Funk #DojaCat #KissMeMore #SamuelLarsen


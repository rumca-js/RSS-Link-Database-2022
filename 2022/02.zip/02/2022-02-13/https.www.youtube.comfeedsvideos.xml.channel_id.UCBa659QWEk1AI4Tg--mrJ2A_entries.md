# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The top secret plan to explode a nuclear bomb in Yorkshire
 - [https://www.youtube.com/watch?v=ceWZslOfEjs](https://www.youtube.com/watch?v=ceWZslOfEjs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-02-14 00:00:00+00:00

In the 1960s, America was running "Operation Plowshare": the idea that perhaps nuclear bombs could be used for peace, not war. At least some British scientists had similar ambitions, and it involved setting off a nuclear bomb under Wheeldale, in the North York Moors National Park.

Based on catalogue reference ES 26 in the National Archives, mainly ES 26/2 and 26/4. "Atomic Weapons Research Establishment and Atomic Weapons Establishment: Peaceful Uses of Nuclear Explosions: Files and Reports". Contains public sector information licensed under the Open Government Licence v3.0: https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/

The Open Government License does not cover personally identifying information, so names and signatures on documents have been blurred.

Operation Plowshare footage from the Prelinger Archives: https://archive.org/details/Plowshar1961 and https://archive.org/details/Plowshar1961_2

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


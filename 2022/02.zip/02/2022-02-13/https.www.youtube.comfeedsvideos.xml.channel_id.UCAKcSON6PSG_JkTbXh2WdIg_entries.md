# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Spoon - Rent I Pay (live performance for The Current)
 - [https://www.youtube.com/watch?v=8CeXAUmoKYE](https://www.youtube.com/watch?v=8CeXAUmoKYE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-14 00:00:00+00:00

Austin's Spoon perform "Rent I Pay" from their 2014 album "They Want My Soul" live at The Bunker Studio in Brooklyn, NY for The Current. 

Catch up with frontman Britt Daniel about how the band decides to sequence their records, their new album "Lucifer on the Sofa," and how he's grown to love touring over the years in a conversation with The Current's Mary Lucia: https://youtu.be/sYoiJCmxT34

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Recorded at The Bunker Studio on October 20, 2021 in Brooklyn, NY
Director: Marisa Gesualdi
DP: Jake Denicola (www.animaworks.nyc/)
Cameras: Hil Steadman, Caleb Weiss, Jake Denicola, Marisa Gesualdi
Editor: Marisa Gesualdi (Sessions 1-4 ), Michael Speed (Session 5)
Lighting Engineer: Christian Lincoln
Gaffer: Caleb Weiss
Engineer: Todd Carder
Assistant Engineer: Neal Shaw
Studio Manager: Andy Plovnick
Producers, The Current: Jesse Wiza, Derrick Stevens 
Technical Director - Eric Romani

## Spoon - Wild (live performance for The Current)
 - [https://www.youtube.com/watch?v=d4symgKxRP4](https://www.youtube.com/watch?v=d4symgKxRP4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-14 00:00:00+00:00

Austin's Spoon perform "Wild" from their 2022 album "Lucifer on the Sofa" live at The Bunker Studio in Brooklyn, NY for The Current. 

Catch up with frontman Britt Daniel about how the band decides to sequence their records, their new album "Lucifer on the Sofa," and how he's grown to love touring over the years in his interview with The Current's Mary Lucia: https://youtu.be/sYoiJCmxT34

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Credits
Recorded at The Bunker Studio on October 20, 2021 in Brooklyn, NY
Director: Marisa Gesualdi
DP: Jake Denicola (www.animaworks.nyc/)
Cameras: Hil Steadman, Caleb Weiss, Jake Denicola, Marisa Gesualdi
Editor: Marisa Gesualdi (Sessions 1-4 ), Michael Speed (Session 5)
Lighting Engineer: Christian Lincoln
Gaffer: Caleb Weiss
Engineer: Todd Carder
Assistant Engineer: Neal Shaw
Studio Manager: Andy Plovnick
Producers, The Current: Jesse Wiza, Derrick Stevens
Technical Director - Eric Romani

## Spoon's Britt Daniel talks "Lucifer on the Sofa", and the art of sequencing
 - [https://www.youtube.com/watch?v=sYoiJCmxT34](https://www.youtube.com/watch?v=sYoiJCmxT34)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-14 00:00:00+00:00

Spoon's Britt Daniel joins The Current to catch up with Mary Lucia about the release of the band's tenth studio album, "Lucifer on the Sofa". Hear about Spoon's process for sequencing a record, Britt's affinity for radio that began in his younger years growing up in Temple, Texas, and how he's grown to love touring even more over the years.

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Guest - Britt Daniel
Host - Mary Lucia
Producers - Jesse Wiza, Derrick Stevens
Technical Director - Eric Romani


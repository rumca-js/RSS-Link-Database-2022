# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 REALISTIC Unreal Engine 5 Demos Show Future of Graphics [4K]
 - [https://www.youtube.com/watch?v=ZSZDIeKCs4o](https://www.youtube.com/watch?v=ZSZDIeKCs4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-14 00:00:00+00:00

Unreal Engine 5 is producing some incredible looking projects. Here are some amazing recent examples with great graphics.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Part 1 - https://www.youtube.com/watch?v=BYQmp1ZM0jM
---------------
Sources:
https://www.youtube.com/watch?v=p3tpq5zD418&ab_channel=DanielMagyar
--
https://www.youtube.com/watch?v=g0VAy6t0UFI&ab_channel=dviz
https://www.youtube.com/watch?v=DHV3EvstBWI&ab_channel=dviz
--
https://www.youtube.com/watch?v=SjLXyO_CpHM&ab_channel=WaveFunctionVR

https://www.youtube.com/watch?v=XRcXsw5Pj4Y

https://www.youtube.com/watch?v=0kWn90jb1r4&ab_channel=BrilliantBlue

https://www.youtube.com/watch?v=ADjoNvkLL20&ab_channel=RivardoKusuma

https://www.youtube.com/watch?v=VaGQhqqTkxo&ab_channel=AnuarFigueroa3D

https://www.youtube.com/watch?v=2i8HenF-zMk&t=174s&ab_channel=MelhemSfeir

https://www.youtube.com/watch?v=jKuHiDyLZfw&t=34s&ab_channel=MelhemSfeir

https://www.youtube.com/watch?v=-n58sQqdmA0&ab_channel=RobJinStudio

## Dying Light 2: Top 10 Secrets & Easter Eggs
 - [https://www.youtube.com/watch?v=hDxKCi8RGsY](https://www.youtube.com/watch?v=hDxKCi8RGsY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-14 00:00:00+00:00

Dying Light 2 (PC, PS5, PS4, Xbox Series X/S/One) is filled with tons of fun secrets, easter eggs, and references to find. Here are our some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#DyingLight2

references:

#2
 https://www.reddit.com/r/dyinglight/comments/slg9q6/any_idea_as_to_what_the_evil_rubber_ducks_are_for/

#1
https://www.reddit.com/r/dyinglight/comments/slg9q6/any_idea_as_to_what_the_evil_rubber_ducks_are_for/

## Top 10 NEW Medieval Games of 2022
 - [https://www.youtube.com/watch?v=rb4R4npjxCw](https://www.youtube.com/watch?v=rb4R4npjxCw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-13 00:00:00+00:00

Looking for swords, castles, and maybe even sorcery in your video games? We've got you covered with these medieval themed games on PC, PS5, PS4, and Xbox Series X/S/One.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

10-Thymesia

Platform : PC PS5 XSX|S

Release Date : TBA 2022 



9- Project Awakening

Platform : PS4 PS5

Release Date : TBA 2022 



8-Crimson Desert

Platform : PC PS4 PS5 XSX|S Xbox One 

Release Date : TBA 2022 



7-Knights of Honor II: Sovereign 

Platform : PC 

Release Date : TBA 2022 



6-Manor Lords

Platform : PC 

Release Date : TBA



5-A Plague Tale: Requiem 

Platform : PC PS5 XSX|S Switch 

Release Date : TBA 2022 



4-Diplomacy is Not an Option 

Platform : PC 

Release Date : 9 February 2022 



3-Total War: Warhammer III 

Platform : PC Linnux 

Release Date : February 17, 2022 



2-Avowed 

Platform : PC XSX|S

Release Date : TBA 



1-Elden Ring

Platform : PC PS4 PS5 XSX|S Xbox One 

Release Date : February 25, 2022 



Bonus:



V Rising

Platform : PC 

Release Date : TBA  


The Iron Oath 

Platform : PC 

Release Date : TBA  


Babylon's Fall

Platform : PC PS4 PS5 

Release Date : March 3, 2022    


Forspoken 

Platform : PC PS5 

Release Date : May 24, 2022    



The Lord of the Rings: Gollum

Platform : PC PS4 PS5 XSX|S Xbox One Switch 

Release Date : 2022 



God of War Ragnarok 

Platform : PS4 PS5 

Release Date : 2022


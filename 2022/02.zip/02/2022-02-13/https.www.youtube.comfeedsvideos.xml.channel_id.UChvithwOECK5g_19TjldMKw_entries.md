# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## The Olympics Backfired on China - Disastrous Regret
 - [https://www.youtube.com/watch?v=tNVUqyeJklw](https://www.youtube.com/watch?v=tNVUqyeJklw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2022-02-14 00:00:00+00:00

The Beijing 2022 Winter Olympics were incredibly important for Chinese leadership. Unfortunately for them, it backfired. It was disastrous, and now
China faces some serious issues.

SerpentZA - Olympians Forced to use this App - https://youtu.be/-YhEN8ZPD6I

◘ Support me on Patreon to talk to me directly and support my work - http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C
◘ Odysee - http://odysee.com/@laowhy86

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music -
Big Bad Beats
https://www.youtube.com/c/bigbadbeats


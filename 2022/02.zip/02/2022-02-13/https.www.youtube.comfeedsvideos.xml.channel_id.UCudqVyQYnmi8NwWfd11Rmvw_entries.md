## Victor Davis Hanson - How COVID Lockdowns Killed Small Businesses | Highlights Ep.38
 - [https://www.youtube.com/watch?v=-CucAwH3YQY](https://www.youtube.com/watch?v=-CucAwH3YQY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCudqVyQYnmi8NwWfd11Rmvw
 - date published: 2022-02-13 21:56:39+00:00

Victor Davis Hanson - How COVID Lockdowns Killed Small Businesses | Highlights Ep.38


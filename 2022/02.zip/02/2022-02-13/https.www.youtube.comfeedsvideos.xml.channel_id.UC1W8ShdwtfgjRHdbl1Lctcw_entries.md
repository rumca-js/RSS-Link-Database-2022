# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## California 1952, Hollywood to Sunset Strip in color [60fps,Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=YM5A4TamTzo](https://www.youtube.com/watch?v=YM5A4TamTzo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2022-02-14 00:00:00+00:00

I colorized, restored and created a sound design for this video of Trip Sunset Boulevard from Hollywood to the mid-Sunset Strip in California in 1952, we can clearly see what is happening in broad daylight,

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance (not historically accurate)
✔sound design added only for the ambiance
✔restoration:(stabilisation,denoise,cleand,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

Great thanks to Rick Prelinger for share the amazing black and white Video Source

B&W Video Source from: Rick Prelinger on archive.org
B&W Video Source: https://archive.org/details/ia-35000350-sandlers-6-n-001-0-0


Rights to the black and white 35mm Video Source are held by Internet Archive. under the Creative Commons Attribution License
- - - - - - - - - - - - - - - - - - - -
📨 Contact me at :nassthegoodman@gmail.com
- - - - - - - - - - - - - - - - - - - -
For any Copyright issues, please reach out to us first before filing a claim with YouTube. Send us a message or email detailing your concerns and we'll make sure the matter is resolved immediately. All contact details in our channel's "About" page! Please consider "fair use" before filing a claim. Thank You!


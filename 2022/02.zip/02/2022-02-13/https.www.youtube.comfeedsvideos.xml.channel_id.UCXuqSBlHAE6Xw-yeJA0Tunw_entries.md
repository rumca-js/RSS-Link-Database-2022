# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## These $35 AirPods clones SOUND better than Apple's
 - [https://www.youtube.com/watch?v=0Q4WkWBjpvw](https://www.youtube.com/watch?v=0Q4WkWBjpvw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-14 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

Knock-off electronics have a well-deserved reputation for being a complete waste of money, but some fans claim that these fake AirPods are as good as the real ones but at a fraction of the price. Could these no-name Chinese replicas possibly take on Apple? We test with some friends from around the office to find out.

Discuss on the forum: https://linustechtips.com/topic/1411810-these-fake-airpods-are-better-than-apple%E2%80%99s/

Buy OnePlus Buds Z
  Amazon: https://geni.us/uxAh

Buy Anker Soundcore Life Dot 2
  Amazon: https://geni.us/rF87zC

Buy JLAB Go Air Pop True Wireless
  Amazon: https://geni.us/ZBM6zP
  Best Buy: https://geni.us/vWmPCb

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:58 The FakePods
1:29 Build Quality feat. Horst
2:53 Listening Tests Intro
3:35 Airpods Pro vs Fakes
5:27 Airpods 2 vs Fakes
7:07 Airpods 3 vs Fakes
9:07 Features and Quality of Life
11:03 Don't Buy These

## This should be illegal… Battery Repair Blocking
 - [https://www.youtube.com/watch?v=Mkum7G-0vWg](https://www.youtube.com/watch?v=Mkum7G-0vWg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-13 00:00:00+00:00

Repower your devices with iFixit at https://iFixit.com/LTT

What exactly happens to those batteries once you’re done with them? And why is replacing them so dang hard? We explore the how’s and the why’s. 

Discuss on the forum: https://linustechtips.com/topic/1411559-this-should-be-illegal%E2%80%A6-battery-repair-blocking/

Find a battery return location near you:
USA - https://search.earth911.com/?what=Lithium-ion+Batteries
Canada - https://www.call2recycle.ca/locator/
Rest of World -  Varies by country, check with your local regulator

Read "Nix The Fix" FTC Report: https://geni.us/NixTheFix
Check out THT Battery:  http://www.THTBattery.com 
Check out Retriev Technologies: https://www.retrievtech.com/

Buy 18650 Battery Holder/Organizer
Amazon: https://geni.us/oXmIMP

Buy iFixit Toolkit
Amazon: https://geni.us/BGhE1XD
Best Buy: https://geni.us/k74sAD
Newegg: https://geni.us/1bgwyEF

Buy bebob V150MICRO
B&H Photo: https://geni.us/9zMsqz

Buy 1900W Battery Soldering Pencil (It's... OK)
Amazon: https://geni.us/uA7DE

Buy Nickel Strips
Amazon: https://geni.us/1y3Il
Newegg: https://geni.us/1y3Il

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:16 Cautions
1:32 Basic components
2:40 We can do this.. right? 
3:46 Pack prep
6:47 Building the pack 
7:54 Spot welding
9:35 POP
9:50 Back-up plan
11:50 He's OK 
12:50 Mishap
14:02 Battery repair realities
15:10 BMS Types
17:20 Middle Ground
18:09 How YOU can help


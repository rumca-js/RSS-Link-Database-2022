# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Your Politicians Accept Dark Money
 - [https://www.youtube.com/watch?v=0Wts4yY7jRU](https://www.youtube.com/watch?v=0Wts4yY7jRU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-14 00:00:00+00:00

Despite pledging to do the opposite, a new report shows that Democrat politicians accept more "dark corporate" donations that their Republicans counterparts. But by pointing this out will I continue to be labelled 'right-wing'? 
#lobbying #DarkMoney #right

References
Jacobin Mag: https://www.jacobinmag.com/2022/02/dems-gop-super-pacs-pelosi-bloomberg-warren

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Bill Gates: How The Gates Foundation Really Works
 - [https://www.youtube.com/watch?v=_Q5kaVxAZPo](https://www.youtube.com/watch?v=_Q5kaVxAZPo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-13 00:00:00+00:00

With new trustees joining the board of the Gates Foundation, will they really “shape its governance” or will their financial ties to the foundation limit their influence, and in turn the shaping of the global health narrative? 
#BillGates #Billionaire #Covid #WHO

References
Forbes: https://www.forbes.com/sites/rachelsandler/2022/01/26/newly-appointed-gates-foundati[…]clude-an-african-billionaire-and-an-academic/?sh=31b7be901005

The Nation: https://www.thenation.com/article/society/gates-foundation-board-accountability/

AP: https://www.msn.com/en-ph/money/companies/gates-foundation-expands-board-following-bill-melinda-split/ar-AATacoN

ABC News: https://abcnews.go.com/Health/wireStory/gates-foundation-expands-board-bill-melinda-split-82483946

Quartz: https://qz.com/2102889/the-who-is-too-dependent-on-gates-foundation-donations/#:~:text=The%20Gates%20Foundation%20is%20the,the%20US%20donated%20%24730%20million.

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


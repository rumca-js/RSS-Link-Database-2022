# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Woman Driving Alone In Carpool Lane Claims Preferred Pronoun Is 'They'
 - [https://www.youtube.com/watch?v=dEaRnAR0dlw](https://www.youtube.com/watch?v=dEaRnAR0dlw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-14 00:00:00+00:00

This woman - er, wymxn? - was pulled over for driving alone in the carpool lane. But she's got a surefire way to get out of the ticket: her preferred pronoun is they!

Follow Chandler's Youtube: https://www.YouTube.com/chandlerjuliet

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


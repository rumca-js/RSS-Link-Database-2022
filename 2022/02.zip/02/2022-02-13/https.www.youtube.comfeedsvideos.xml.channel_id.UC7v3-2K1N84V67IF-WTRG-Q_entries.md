# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Doctor Strange in the Multiverse of Madness - Trailer 2 (My Thoughts)
 - [https://www.youtube.com/watch?v=44M6Y15lhlU](https://www.youtube.com/watch?v=44M6Y15lhlU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-02-14 00:00:00+00:00

DOCTOR STRANGE IN THE MULTIVERSE OF MADNESS gets a 2nd trailer with a possible crazy cross over/cameo reveal. Let's talk about it!

Watch the trailer here: https://www.youtube.com/watch?v=aWzlQ2N6qqg&t=48s&ab_channel=MarvelEntertainment

#DoctorStrange


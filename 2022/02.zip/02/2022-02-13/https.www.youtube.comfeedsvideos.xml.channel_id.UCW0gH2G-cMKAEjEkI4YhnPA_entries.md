# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Rings of Power Teaser BREAKDOWN | The Lord of the Rings on Prime
 - [https://www.youtube.com/watch?v=YQmGXbXpw80](https://www.youtube.com/watch?v=YQmGXbXpw80)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-02-14 00:00:00+00:00

We finally got our first teaser trailer for The Lord of the Rings: The Rings of Power!  In this video, I go through it shot-by-shot giving my interpretations, thoughts, and theories.  The teaser certainly left me wanting more - in both good ways, and some ways that are more underwhelming for me as a huge book fan.  We see Galadriel, Gil-galad, Elrond, Durin IV, Disa, Arondir, Halbrand, Finrod, "Meteor Man", and new hobbit Elenor "Nori" Brandyfoot.  We also got our first look at Númenor, an ice troll, and more.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

You can watch the trailer here: https://youtu.be/OCLoZI-FOYA

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Ted Nasmith - www.tednasmith.com/shop/
Kip Rasmussen - https://www.kiprasmussen.com

Helcaraxe - Jenny Dolfen
Eru and the Gods Singing the First Song of Creation - Kip Rasmussen
Morgoth Came - Jenny Dolfen
Lorien - Brothers Hildebrandt
The Burning of the Ships - Ted Nasmith
Fingolfin Leads the Host Across the Helcaraxe - Ted Nasmith

#ringsofpower #lotronprime #lotrrop

## LOTR Rings of Power Trailer Watch Party! Super Bowl Sunday w/ TheOneRing.net
 - [https://www.youtube.com/watch?v=IoFnHAUR12s](https://www.youtube.com/watch?v=IoFnHAUR12s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-02-13 00:00:00+00:00

I'll be joining the folks at The One Ring for the OFFICIAL The Lord of the Rings: The Rings of Power trailer watch party!  As a special treat, the good folks at TORn and I have worked it out so that we will simulcast the stream to my channel in addition to their YouTube, Twitter, etc.  Check them out here: @TheOneRingNet 

After the teaser airs, we will screen it live and give our reactions, extensive analysis, and take questions/comments/thoughts from YOU in the live chat!  Click "Set Reminder" so you get notified when we go LIVE!  (Scheduled time is subject to change depending on when the teaser actually airs.)

Rings of Power Description:
Beginning in a time of relative peace, we follow an ensemble cast of characters as they confront the re-emergence of evil to Middle-earth. From the darkest depths of the Misty Mountains, to the majestic forests of Lindon, to the breathtaking island kingdom of Númenor, to the furthest reaches of the map, these kingdoms and characters will carve out legacies that live on long after they are gone.

#ringsofpower #lotrrop #lotronprime


# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Rings of Power - War For A Fandom
 - [https://www.youtube.com/watch?v=9QJbAbe2yyo](https://www.youtube.com/watch?v=9QJbAbe2yyo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-02-13 00:00:00+00:00

Lord of the Rings: The Rings of Power on Amazon has caused a fair bit of controversy since it was announced, and the first trailer isn't even out yet. Join me as I break down the reasons behind the fan backlash and the reactions to it.


# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Anime Deserves Better Video Games | The Takeaway
 - [https://www.youtube.com/watch?v=OLTRqSwEkGM](https://www.youtube.com/watch?v=OLTRqSwEkGM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-02-14 00:00:00+00:00

Over the years, for every decent anime adaptation of a beloved video game franchise, there have been dozens more that drop the ball, but recently it seems the quality of anime adaptations has improved. However, the same hasn’t been true of video game adaptations of anime. I’m sure you can think of a couple really good ones right away, but we’re over 30 years into these sorts of collaborations and I’m willing to bet your list doesn’t reach past five titles. And if it does, how many on that list are fighting games?

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Not Tonight 2 | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=yoJnoMSl6t8](https://www.youtube.com/watch?v=yoJnoMSl6t8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-02-14 00:00:00+00:00

Will Cruz (@WillCBlogs) reviews Not Tonight 2, developed by PanicBarn.

Not Tonight 2 on Steam: https://store.steampowered.com/app/1600370/Not_Tonight_2/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Book of Boba Fett is Modern Star Wars in a Nutshell | Your Feature Presentation
 - [https://www.youtube.com/watch?v=-PMNfCzyGnc](https://www.youtube.com/watch?v=-PMNfCzyGnc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-02-13 00:00:00+00:00

This week on Your Feature Presentation, Jack and Darren discuss the schlock that is Moonfall, and then Marty and Omar do a final wrap-up of their thoughts on The Book of Boba Fett, a show that wasn't exactly very good.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---
Timestamps
00:00 - Intro
02:02 - Moonfall
17:38 - The Book of Boba Fett


---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


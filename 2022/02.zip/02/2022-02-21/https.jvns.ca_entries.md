## Things that used to be hard and are now easy
 - [https://jvns.ca/blog/2022/02/20/things-that-used-to-be-hard-and-are-now-easy/](https://jvns.ca/blog/2022/02/20/things-that-used-to-be-hard-and-are-now-easy/)
 - RSS feed: https://jvns.ca
 - date published: 2022-02-21 15:10:33.971827+00:00

Things that used to be hard and are now easy


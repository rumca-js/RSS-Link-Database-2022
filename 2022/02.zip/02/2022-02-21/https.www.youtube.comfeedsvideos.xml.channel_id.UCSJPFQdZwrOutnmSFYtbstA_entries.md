# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Uncharted - How Could They Mess This Up?
 - [https://www.youtube.com/watch?v=itg4h7VAT-Q](https://www.youtube.com/watch?v=itg4h7VAT-Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-02-21 00:00:00+00:00

Adapting a videogame like Uncharted into a movie seems like the easiest win ever. But a combination of bad casting choices, lacklustre writing and pacing somehow managed to derail the Tom Holland, Mark Wahlberg action film.


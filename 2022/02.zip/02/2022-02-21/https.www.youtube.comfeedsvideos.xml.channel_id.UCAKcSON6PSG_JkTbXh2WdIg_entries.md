# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Miloe Full Performance Jan. 22, 2022 (The Current's 17th Anniversary Party)
 - [https://www.youtube.com/watch?v=lugJbPmVzZY](https://www.youtube.com/watch?v=lugJbPmVzZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-22 00:00:00+00:00

Watch #Minneapolis singer-songwriter Miloe play a #live set at The Current's 17th Anniversary, live from First Avenue in Minneapolis, Minn. Miloe performs a solo set of the sweet, distinctive songs that have earned him a growing national audience.

Songs Played:
03:46 Change Your Mind
07:16 Motorola
10:18 Marna
12:56 Winona
16:05 Greenhouse

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Minnesota Sessions: The Cactus Blossoms at The Terrarium (live for The Current)
 - [https://www.youtube.com/watch?v=lI6F-JWaEPA](https://www.youtube.com/watch?v=lI6F-JWaEPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-21 00:00:00+00:00

Jack Torrey and Page Burkum of The Cactus Blossoms join The Current just after the release of their third studio record, 'One Day'. The Minnesotan sibling duo play three tracks from the new album, discuss the murky waters of songwriting inspiration, and their work with David Lynch on "Twin Peaks". 

Songs Played:
00:00 Is It Over
02:51 Hey Baby
06:10 One Day

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Vocals, Acoustic Guitar, Electric Guitar - Jack Torrey
Vocals, Acoustic Guitar - Page Burkum
Drums - Jeremy Hanson
Bass - Philip Hicks
Electric Guitar - Jacob Hanson
Wurlitzer, Steel Guitar - Ben Lester
Host - Diane
Producer - Jesse Wiza
Director, Camera Op, Editor - Evan Clark
Production Manager, Camera Op - Erik Stromstad
Cinematographer, Colorist - Eric Romani
Audio Recording, Mix Engineer - Alex Proctor
Engineer, The Terrarium - Jason Orris

## The Cactus Blossoms - Hey Baby (live performance for The Current)
 - [https://www.youtube.com/watch?v=JJMqvVA_7pE](https://www.youtube.com/watch?v=JJMqvVA_7pE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-21 00:00:00+00:00

Jack Torrey and Page Burkum of The Cactus Blossoms join The Current just after the release of their third studio record, 'One Day' to perform at The Terrarium studio in Minneapolis. Watch their full session, including an interview about the new record here: https://youtu.be/q8Cri_cvDr8

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Vocals, Acoustic Guitar, Electric Guitar - Jack Torrey
Vocals, Acoustic Guitar - Page Burkum
Drums - Jeremy Hanson
Bass - Philip Hicks
Electric Guitar - Jacob Hanson
Wurlitzer, Steel Guitar - Ben Lester
Host - Diane
Producer - Jesse Wiza
Director, Camera Op, Editor - Evan Clark
Production Manager, Camera Op - Erik Stromstad
Cinematographer, Colorist - Eric Romani
Audio Recording, Mix Engineer - Alex Proctor
Engineer, The Terrarium - Jason Orris

## The Cactus Blossoms - Is It Over (live performance for The Current)
 - [https://www.youtube.com/watch?v=yKfSQLpEsNU](https://www.youtube.com/watch?v=yKfSQLpEsNU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-21 00:00:00+00:00

Jack Torrey and Page Burkum of The Cactus Blossoms join The Current just after the release of their third studio record, 'One Day' to perform at The Terrarium studio in Minneapolis. Watch their full session, including an interview about the new record here: https://youtu.be/q8Cri_cvDr8

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Vocals, Acoustic Guitar, Electric Guitar - Jack Torrey
Vocals, Acoustic Guitar - Page Burkum
Drums - Jeremy Hanson
Bass - Philip Hicks
Electric Guitar - Jacob Hanson
Wurlitzer, Steel Guitar - Ben Lester
Host - Diane
Producer - Jesse Wiza
Director, Camera Op, Editor - Evan Clark
Production Manager, Camera Op - Erik Stromstad
Cinematographer, Colorist - Eric Romani
Audio Recording, Mix Engineer - Alex Proctor
Engineer, The Terrarium - Jason Orris

## The Cactus Blossoms - One Day (live performance for The Current)
 - [https://www.youtube.com/watch?v=cuyCFGBHsHw](https://www.youtube.com/watch?v=cuyCFGBHsHw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-21 00:00:00+00:00

Jack Torrey and Page Burkum of The Cactus Blossoms join The Current just after the release of their third studio record, 'One Day' to perform at The Terrarium studio in Minneapolis. Watch their full session, including an interview about the new record here: https://youtu.be/q8Cri_cvDr8

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Vocals, Acoustic Guitar, Electric Guitar - Jack Torrey
Vocals, Acoustic Guitar - Page Burkum
Drums - Jeremy Hanson
Bass - Philip Hicks
Electric Guitar - Jacob Hanson
Wurlitzer, Steel Guitar - Ben Lester
Host - Diane
Producer - Jesse Wiza
Director, Camera Op, Editor - Evan Clark
Production Manager, Camera Op - Erik Stromstad
Cinematographer, Colorist - Eric Romani
Audio Recording, Mix Engineer - Alex Proctor
Engineer, The Terrarium - Jason Orris

## The Cactus Blossoms on "One Day," working with David Lynch, and the mysteries of songwriting
 - [https://www.youtube.com/watch?v=q8Cri_cvDr8](https://www.youtube.com/watch?v=q8Cri_cvDr8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-21 00:00:00+00:00

Jack Torrey and Page Burkum of The Cactus Blossoms join The Current just after the release of their third studio record, 'One Day'. The Minnesotan sibling duo discuss the murky waters of songwriting inspiration, inviting Jenny Lewis to join them for one of the tracks on the new record, and their work with David Lynch on "Twin Peaks". 

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Guests - Jack Torrey, Page Burkum
Host - Diane
Producer - Jesse Wiza
Director, Camera Op, Editor - Evan Clark
Production Manager, Camera Op - Erik Stromstad
Cinematographer, Colorist - Eric Romani
Audio Recording, Mix Engineer - Alex Proctor
Engineer, The Terrarium - Jason Orris

## The Cactus Blossoms perform three songs from 'One Day' (live for The Current)
 - [https://www.youtube.com/watch?v=2EJaOTwriTc](https://www.youtube.com/watch?v=2EJaOTwriTc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-21 00:00:00+00:00

Jack Torrey and Page Burkum of The Cactus Blossoms join The Current just after the release of their third studio record, 'One Day' to perform a three songs set at The Terrarium studio in Minneapolis. Watch their full session, including an interview about the new record here: https://youtu.be/q8Cri_cvDr8

Songs Played:
00:00 Is It Over
02:51 Hey Baby
06:10 One Day

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Vocals, Acoustic Guitar, Electric Guitar - Jack Torrey
Vocals, Acoustic Guitar - Page Burkum
Drums - Jeremy Hanson
Bass - Philip Hicks
Electric Guitar - Jacob Hanson
Wurlitzer, Steel Guitar - Ben Lester
Host - Diane
Producer - Jesse Wiza
Director, Camera Op, Editor - Evan Clark
Production Manager, Camera Op - Erik Stromstad
Cinematographer, Colorist - Eric Romani
Audio Recording, Mix Engineer - Alex Proctor
Engineer, The Terrarium - Jason Orris


# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Photographer's surreal family portraits are literally breathtaking
 - [https://www.cnn.com/style/article/photographer-hal-flesh-love/index.html](https://www.cnn.com/style/article/photographer-hal-flesh-love/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-02-21 00:52:54+00:00

Having a family portrait taken by Haruhiko Kawaguchi comes with one unusual condition: That he wrap your entire house in plastic and then vacuum-seal you into an airtight bag.


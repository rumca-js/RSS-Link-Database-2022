# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## a quick favor, Connecticut residents
 - [https://www.youtube.com/watch?v=m38YqCDyOaI](https://www.youtube.com/watch?v=m38YqCDyOaI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-22 00:00:00+00:00

https://tinyurl.com/rossmatrix


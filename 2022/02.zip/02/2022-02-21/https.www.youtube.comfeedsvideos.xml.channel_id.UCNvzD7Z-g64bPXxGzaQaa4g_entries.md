# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 10 NEW Games of March 2022
 - [https://www.youtube.com/watch?v=Tp9ISqmR9HI](https://www.youtube.com/watch?v=Tp9ISqmR9HI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-22 00:00:00+00:00

Looking for something to play on PC, PS5, PS4, Xbox Series X/S/One, or Nintendo Switch in March 2022? We've got you covered with these upcoming game releases and release dates.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

ELEX II 

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : March 1, 2022



Weird West 

Platform : PC PS4 Xbox One

Release Date : March 31, 2022 



Babylon’s Fall 

Platform : PC PS4 PS5 

Release Date : March 3, 2022 



Kirby and the Forgotten Land 

Platform : Switch

Release Date : March 25, 2022 



Shadow Warrior 3 

Platform : PC PS4 Xbox One 

Release Date : March 1, 2022



Gran Turismo 7 

Platform : PS4 PS5

Release Date : March 4, 2022



Triangle Strategy        

Platform : Switch 

Release Date : March 4, 2022             



Tiny Tina’s Wonderlands

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : March 25, 2022 



Stranger of Paradise: Final Fantasy Origin

Platform : PC PS4 PS5 Xbox One XSX|S

Release Date : March 18, 2022 



Ghostwire: Tokyo 

Platform : PC PS5

Release Date : March 25, 2022 



BONUS :- 



WWE 2K22 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : March 11, 2022 



Grand Theft Auto V 

Platform : PS5, XSX

Release Date : 15 March 2022 



Crusader Kings III 

Platform : Coming to PS5 XSX|S

Release Date : March 29, 2022 



Persona 4 Arena Ultimax

Platform : PC Switch PS4 

Release Date : March 17, 2022 



Chocobo GP 

Platform : Switch

Release Date : March 10 

0:00 Intro
0:15 ELEX II 
3:01 Weird West 
4:02 Babylon’s Fall 
5:25 Kirby and the Forgotten Land 
6:22 Shadow Warrior 3 
7:45 Gran Turismo 7 
9:19 Triangle Strategy        
10:40 Tiny Tina’s Wonderlands
11:48 Stranger of Paradise: Final Fantasy Origin
12:51 Ghostwire: Tokyo 
14:00 BONUS

## 10 Ridiculous SECRET Rooms Found In Recent Video Games [Part 2]
 - [https://www.youtube.com/watch?v=wnk4nQnVRZY](https://www.youtube.com/watch?v=wnk4nQnVRZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-21 00:00:00+00:00

Many recent video games have secret strange rooms that are a ton of fun to find. Here are some of our favorite examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Pokemon news via: https://youtu.be/T-I5hmewOmA


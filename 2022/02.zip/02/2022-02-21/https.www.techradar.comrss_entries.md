# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## New Netflix movies 2022: every original film coming to the streamer this year
 - [https://www.techradar.com/news/new-netflix-movies/](https://www.techradar.com/news/new-netflix-movies/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-21 17:50:48+00:00

We round up the biggest Netflix original movies heading to the streamer in 2022, from Glass Onion: A Knives Out Mystery to Guillermo del Toro's Pinocchio.

## New Netflix movies 2022: every original film coming to the streamer this year
 - [https://www.techradar.com/news/new-netflix-movies](https://www.techradar.com/news/new-netflix-movies)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-21 17:50:48+00:00

We round up the biggest Netflix original movies heading to the streamer in 2022, from Guillermo del Toro's Pinocchio to Glass Onion: A Knives Out Mystery.

## New movies 2022: what to watch in theaters this year – and which films are streaming
 - [https://www.techradar.com/news/new-movies-2021/](https://www.techradar.com/news/new-movies-2021/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-21 15:28:32+00:00

We highlight the biggest new movies heading to theaters in 2022, from Babylon to Avatar: The Way of Water.

## New movies 2022: what to watch in theaters this year – and which films are streaming
 - [https://www.techradar.com/news/new-movies-2021](https://www.techradar.com/news/new-movies-2021)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-21 15:28:32+00:00

We highlight the biggest new movies heading to theaters in 2022, from Babylon to Avatar: The Way of Water.

## Presidents' Day TV sales 2023: when is it and today's best deals
 - [https://www.techradar.com/news/the-best-presidents-day-tv-sales-tv-deals-from-best-buy-walmart-and-amazon](https://www.techradar.com/news/the-best-presidents-day-tv-sales-tv-deals-from-best-buy-walmart-and-amazon)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-21 13:58:06+00:00

Your 2023 Presidents' Day TV sales guide with everything you need to know, plus today's best early deals.

## New horror movies 2022: every big scary film coming to theaters and streamers
 - [https://www.techradar.com/news/new-horror-movies/](https://www.techradar.com/news/new-horror-movies/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-21 12:59:53+00:00

We highlight the new horror movies heading to theaters and streamers in 2022 and beyond.

## New horror movies 2023: every big scary film coming to theaters and streamers
 - [https://www.techradar.com/news/new-horror-movies](https://www.techradar.com/news/new-horror-movies)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-21 12:59:53+00:00

We highlight the new horror movies heading to theaters and streamers in 2023 and beyond.


# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## telepatía | Kali Uchis | funk cover ft. Vidya Vox
 - [https://www.youtube.com/watch?v=ynTD0o10M7o](https://www.youtube.com/watch?v=ynTD0o10M7o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-02-21 00:00:00+00:00

Join the Vinyl Club tier by Feb. 28 to get "Technicolor Magic" AND "Best of 2021" on vinyl! http://modal.scarypocketsfunk.com/patreon
Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Kali Uchis' "telepatía" by Scary Pockets & Vidya Vox.

MUSICIAN CREDITS
Lead vocal: Vidya Vox
Drums: Otis McDonald
Bass: Nicole Row
Guitar: Eric Krasno
Guitar: Ryan Lerman
Keys: Jack Conte
Additional Synths, Percussion: Brian Green

AUDIO CREDITS
Recording Engineer: Caleb Parker
Assistant Engineer: Nicole Schmidt
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
DP: Ricky Chavez 
Editor: Adam Kritzberg

Recorded Live at The Village in Los Angeles, CA.

#ScaryPockets #Funk #KaliUchis #telepatia #VidyaVox


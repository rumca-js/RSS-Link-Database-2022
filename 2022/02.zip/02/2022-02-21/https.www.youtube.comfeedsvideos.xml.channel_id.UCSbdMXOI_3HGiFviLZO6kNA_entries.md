# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## PSVR 2 is the competition for the Quest 2 we’ve been waiting for
 - [https://www.youtube.com/watch?v=rKiKwTyWOSI](https://www.youtube.com/watch?v=rKiKwTyWOSI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-02-22 00:00:00+00:00

Hello and Welcome to TUESDAY NEWSDAY! Your number one resource for the entire week's worth of VR news! This week is honestly pretty crazy, we have the official PSVR 2 reveal, Valve Index news, Quest 2 hacks, Apple AR/VR news and a ton more. Hope you enjoy this week's newsday! 

The title is a joke btw, I mean it is looking insane. But yeah, I know I say insane a lot. I just get excited. 

DISCORD LINK FOR MEETUPS AND GAME NIGHTS:
Discord.gg/Thrill

My links:
Twitch.tv/Thrilluwu
Twitter.com/Thrilluwu

TIMESTAMPS: 
00:00 INTRO
00:35 DISCORD VR MEETUPS
00:48 FACEMIC VULNERABILITIES
02:30 MINECRAFT VR
03:34 PSVR 2 REVEALED
07:11 MEME BREAK (actually funny)
07:29 Meta 300k party
08:06 QUEST 2 HACKS
08:42 SIMULA ONE LINUX UPDATE
09:41 INDEX PARTS UPDATE
10:21 APPLE AR/VR HEADSET in 22
11:13 question of the week
12:30 Dope outro music

SOURCES:
Video used from UPLOAD VR and ZUCKLES
https://www.youtube.com/watch?v=XAuuqGgoros&t=83s
https://www.youtube.com/watch?v=HFVzMv-bATE


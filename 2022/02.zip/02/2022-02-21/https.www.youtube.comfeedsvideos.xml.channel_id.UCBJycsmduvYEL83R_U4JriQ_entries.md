# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Galaxy S22 Ultra Review: Separating from the Pack!
 - [https://www.youtube.com/watch?v=vXIAB_1FEC0](https://www.youtube.com/watch?v=vXIAB_1FEC0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-02-22 00:00:00+00:00

Samsung's Galaxy S22 Ultra separates itself from the rest of the lineup with more than just specs
dbrand Atomic Grip case: https://dbrand.com/atomic-grip
Galaxy S22 Review: https://youtu.be/qWIkBMNKj1s

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Samsung for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I better not screw this up - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=39Z00YkoUeA](https://www.youtube.com/watch?v=39Z00YkoUeA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-22 00:00:00+00:00

Thanks to Intel for continuing to sponsor this series! Check out Intel 12th Gen Processors at https://geni.us/Cb1jg

Discuss on the forum: https://linustechtips.com/topic/1413730-i-better-not-screw-this-up-intel-5000-extreme-tech-upgrade/


Check out Clarence's part list at https://lmg.gg/PGprr

Check out the Plugable UD-ULTC4K Docking Station: https://lmg.gg/cmoPv

Check out Chris Colfer's The Land of Stories book series: https://geni.us/DRXY

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

Special Intro by MBarek Abdelwassaa
https://www.instagram.com/mbarek_abdel/

CHAPTERS
---------------------------------------------------
0:00 Intro
1:17 Overview
2:46 Accounting
4:17 New Monitor
5:07 Pluggable Hub
7:56 Why Laptop?
8:45 Living Room
10:02 Books
11:19 Google Home
11:46 Living Room Upgrade
16:12 Speakers
21:19 Testing
22:54 Bed

## I Broke This CPU on Purpose... Let me Explain -  Lenovo ThinkCenter Locked-down CPU
 - [https://www.youtube.com/watch?v=bFNJVaO9E-o](https://www.youtube.com/watch?v=bFNJVaO9E-o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-21 00:00:00+00:00

Get 30% off list price and 30% off onboarding at http://www.graphus.ai/linus

SmartDeploy: Claim your FREE IT software (worth $696!) at https://lmg.gg/OTTP7

We got a Lenovo ThinkCenter that will lock down any CPU installed in it.. we think. The information is very poor so we need to try it for ourselves.

Watch ServeTheHome's video on PSB: https://youtu.be/KAVlHy05XzM

Buy ThinkCenter M75s: https://geni.us/qOhlQB
Buy AMD Ryzen 5 5600G: https://geni.us/T9WnVvR
Buy ASUS ROG Strix B550-E Gaming: https://geni.us/QMU2H

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1413506-i-broke-this-cpu-on-purpose-let-me-explain/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:07 SmartDeploy
1:20 Bent Pin Repair
1:53 Is our Ryzen 5 5650G locked down?
3:35 Do only Pro CPUs get locked down?
4:50 What is PSB?
7:00 Will our Ryzen 5 5600G get locked?
8:11 Is there a way to reverse PSB?
9:56 Why we're mad at Lenovo
11:38 Graphus
12:12 Outro


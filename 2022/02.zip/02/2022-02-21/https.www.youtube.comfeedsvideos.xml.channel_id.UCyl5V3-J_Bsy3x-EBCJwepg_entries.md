# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Babylon Bee Weak-ly News Update 2/22/2022: Tyrannical Banking And The Last COVID-Free Place On Earth
 - [https://www.youtube.com/watch?v=CpFU09C-gGg](https://www.youtube.com/watch?v=CpFU09C-gGg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-22 00:00:00+00:00

Host Adam Yenser gives us the news of the week, including the Super Bowl Halftime Show, Canada going full potato over the trucker protest, and the last place on earth that is COVID-free.

Watch the full podcast here: https://www.youtube.com/watch?v=zRjMOkRffU8

Follow Adam on Youtube: https://www.youtube.com/user/adamyenser

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## 9 New Woke Characters From Amazon's 'Rings of Power'
 - [https://www.youtube.com/watch?v=m4larn30Uts](https://www.youtube.com/watch?v=m4larn30Uts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-21 00:00:00+00:00

Join Klovbar the Strong and his co-host Willis as these two Lord of the Rings geeks exclusively reveal these 9 new woke characters from Amazon's new Lord of the Rings show: The Rings of Power.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


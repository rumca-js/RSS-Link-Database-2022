# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Fight broke out on Ukrainian TV over potential Russian invasion
 - [https://www.cnn.com/videos/world/2022/02/21/fight-breaks-out-on-ukrainian-talk-show-over-potential-russian-invasion-orig-llr.cnn](https://www.cnn.com/videos/world/2022/02/21/fight-breaks-out-on-ukrainian-talk-show-over-potential-russian-invasion-orig-llr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-02-21 22:00:52+00:00

Journalist and activist Yuriy Butusov hit pro-Russian MP Nestor Shufrych in the face on a political talk show on Ukrainian television.


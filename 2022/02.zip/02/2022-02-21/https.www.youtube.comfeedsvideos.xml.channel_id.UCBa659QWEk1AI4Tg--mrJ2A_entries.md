# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## This town forgot to be a city
 - [https://www.youtube.com/watch?v=kBaLb1C4WAg](https://www.youtube.com/watch?v=kBaLb1C4WAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-02-21 00:00:00+00:00

Rochester, in the south-east of England, was a city for nearly 800 years. And then, in 1998, an administrative error took that city status away, likely forever. Here's the story.

Research and script assistance from Jess Jewell

REFERENCES:
BBC article: http://news.bbc.co.uk/1/hi/uk/england/1991827.stm
Kent Online article: https://www.kentonline.co.uk/medway/news/labour-lost-city-status-deliberately-say-tories-191729/
Minutes of the meeting: https://www.whatdotheyknow.com/request/minute_1197_policy_and_resources

Additional research links:
https://city-of-rochester.org.uk/features/rochester-city-status
Local Government Act (1972) see: https://www.lawteacher.net/acts/local-government-act-1972.php
Charter Trustees Regulations (1996): https://www.legislation.gov.uk/uksi/1996/263/made

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


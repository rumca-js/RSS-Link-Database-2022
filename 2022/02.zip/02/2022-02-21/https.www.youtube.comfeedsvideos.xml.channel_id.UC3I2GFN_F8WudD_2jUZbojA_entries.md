# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## The Dodos - Annie (Live on KEXP)
 - [https://www.youtube.com/watch?v=FxhYHMEHPAI](https://www.youtube.com/watch?v=FxhYHMEHPAI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-22 00:00:00+00:00

http://KEXP.ORG presents The Dodos performing “Annie” live in the KEXP studio. Recorded February 11, 2022.

Meric Long - Vocals / Guitar
Logan Kroeber - Drums

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://dodosmusic.net
http://kexp.org

## The Dodos - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=sMBfjQhbmAo](https://www.youtube.com/watch?v=sMBfjQhbmAo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-22 00:00:00+00:00

http://KEXP.ORG presents The Dodos performing live in the KEXP studio. Recorded February 11, 2022.

Songs:
The Surface
Annie
Pale Horizon
Quiet Voices

Meric Long - Vocals / Guitar
Logan Kroeber - Drums

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://dodosmusic.net
http://kexp.org

## The Dodos - Pale Horizon (Live on KEXP)
 - [https://www.youtube.com/watch?v=WkUOOOU9aVc](https://www.youtube.com/watch?v=WkUOOOU9aVc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-22 00:00:00+00:00

http://KEXP.ORG presents The Dodos performing “Pale Horizon” live in the KEXP studio. Recorded February 11, 2022.

Meric Long - Vocals / Guitar
Logan Kroeber - Drums

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://dodosmusic.net
http://kexp.org

## The Dodos - Quiet Voices (Live on KEXP)
 - [https://www.youtube.com/watch?v=XU2LgnSIpNs](https://www.youtube.com/watch?v=XU2LgnSIpNs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-22 00:00:00+00:00

http://KEXP.ORG presents The Dodos performing “Quiet Voices” live in the KEXP studio. Recorded February 11, 2022.

Meric Long - Vocals / Guitar
Logan Kroeber - Drums

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://dodosmusic.net
http://kexp.org

## The Dodos - The Surface (Live on KEXP)
 - [https://www.youtube.com/watch?v=di_OrnnhyJ4](https://www.youtube.com/watch?v=di_OrnnhyJ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-22 00:00:00+00:00

http://KEXP.ORG presents The Dodos performing “The Surface” live in the KEXP studio. Recorded February 11, 2022.

Meric Long - Vocals / Guitar
Logan Kroeber - Drums

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://dodosmusic.net
http://kexp.org


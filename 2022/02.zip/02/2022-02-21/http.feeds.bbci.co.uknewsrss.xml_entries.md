# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## US reveals claims of Russian 'kill list' if Moscow occupies Ukraine
 - [https://www.bbc.co.uk/news/world-europe-60472889?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60472889?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 22:50:49+00:00

The US says it has "credible information" that Russia is creating lists of Ukrainians to be killed.

## 'Not the time to laugh' - Tuchel backs Lukaku after fewest touches in Premier League history
 - [https://www.bbc.co.uk/sport/football/60468407?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60468407?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 21:17:51+00:00

Chelsea manager Thomas Tuchel says "it is not the time to laugh about" Romelu Lukaku after the £97.5m striker's recent struggles.

## Ukraine crisis: Five reasons why Putin might not invade
 - [https://www.bbc.co.uk/news/world-europe-60468264?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60468264?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 15:55:53+00:00

Despite warnings from the West, there are reasons to believe Putin won't launch a full-scale invasion.

## Jamal Edwards: 'Every young guy wanted to do what he was doing'
 - [https://www.bbc.co.uk/news/newsbeat-60462191?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-60462191?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 14:58:21+00:00

Tributes have been paid to the SBTV founder by the young people he inspired with his work.

## Cambridge: David Hockney self-portrait to be displayed in UK first
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-60463495?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-60463495?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 13:16:26+00:00

Exhibition a first "to give serious scholarly scrutiny to Hockney's ideas as well as his art."

## Covid: Living with Covid plan will restore freedom, says Boris Johnson
 - [https://www.bbc.co.uk/news/uk-60455943?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60455943?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 12:51:04+00:00

The PM's meeting with the Cabinet ahead of his statement to the Commons on the plan was delayed.

## Ukraine crisis: War, sickness and love in rebel-held Ukraine
 - [https://www.bbc.co.uk/news/world-europe-60460003?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60460003?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 12:43:52+00:00

Orla Guerin talks to people who cross military checkpoints for medical treatment and to see family.

## Jamal Edwards, music entrepreneur and Youtube star, dies aged 31
 - [https://www.bbc.co.uk/news/uk-60457063?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60457063?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 12:30:08+00:00

Edwards founded SBTV, an online music platform that helped launch stars such as Dave and Ed Sheeran.

## Storm Franklin hits UK with flooding and high winds
 - [https://www.bbc.co.uk/news/uk-60452334?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60452334?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 12:28:09+00:00

The UK is being hit by strong winds and heavy rain with widespread yellow weather warnings in place.

## Solihull: Arthur Labinjo-Hughes report uncovers help delay
 - [https://www.bbc.co.uk/news/uk-england-birmingham-60462072?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-60462072?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 12:19:46+00:00

Youngsters living where the six-year-old was killed face "drift and delay" in getting support.

## British Airways blames luggage delays on high winds
 - [https://www.bbc.co.uk/news/business-60464257?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60464257?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 11:57:24+00:00

The airline says continuous high winds are making it difficult to offload passengers' luggage.

## Townsend calls six into Scotland squad as Gray joins injured list
 - [https://www.bbc.co.uk/sport/rugby-union/60463846?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/60463846?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 11:48:19+00:00

Scotland head coach Gregor Townsend adds six players to his Six Nations squad after a host of call-offs.

## PFA says concussion protocols 'failing to prioritise player safety' after Koch injury
 - [https://www.bbc.co.uk/sport/football/60461233?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60461233?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 11:48:02+00:00

The Professional Footballers' Association says concussion protocols "are failing to prioritise player safety" following the head injury sustained by Leeds United's Robin Koch.

## Home buyers see asking prices soar by nearly £8,000
 - [https://www.bbc.co.uk/news/business-60463196?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60463196?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 11:34:56+00:00

The price rise between January and February is the highest for 20 years, says Rightmove.

## Jimmy 'the Fist' First: Meet the oldest boxing prospect in Britain
 - [https://www.bbc.co.uk/sport/boxing/60115823?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/60115823?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 11:22:42+00:00

Jimmy 'the Fist' First calls himself the oldest prospect in British boxing as he prepares to challenge for his first title at the age of 41.

## Ukraine tensions: Biden agrees in principle to summit with Putin
 - [https://www.bbc.co.uk/news/world-europe-60454818?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60454818?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 11:02:55+00:00

The meeting, proposed by France, will only take place if Russia does not invade Ukraine, the US says.

## FA investigates after Man Utd's Elanga hit by object thrown from crowd during win at Leeds
 - [https://www.bbc.co.uk/sport/football/60461226?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60461226?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 10:41:47+00:00

The Football Association is investigating after Manchester United's Anthony Elanga is struck by an object thrown from the crowd in the win at Leeds United.

## 'It's dead in the water' - McIlroy says Johnson & DeChambeau rejecting Super League is a fatal blow
 - [https://www.bbc.co.uk/sport/golf/60457721?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/60457721?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 09:48:15+00:00

Dustin Johnson and Bryson DeChambeau distance themselves from a Saudi-backed Super League by reaffirming their commitment to the PGA Tour.

## Wales call fit-again Faletau into squad for England game
 - [https://www.bbc.co.uk/sport/rugby-union/60455167?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/60455167?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 09:38:18+00:00

Taulupe Faletau is called into Wales' Six Nations squad for Saturday's game against England after recovering from injury.

## Queen carries on with light duties after Covid symptoms
 - [https://www.bbc.co.uk/news/uk-60460402?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60460402?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 08:01:32+00:00

Her workload is likely to include the reading of state papers or looking through correspondence.

## Smell training to 'bring back the senses'
 - [https://www.bbc.co.uk/news/uk-england-london-60459718?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-60459718?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 06:18:31+00:00

A charity has been hosting a number of workshops to help those who have lost their sense of smell.

## The Papers: 'Queen's Covid example' as PM 'lifts virus curbs'
 - [https://www.bbc.co.uk/news/blogs-the-papers-60457518?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60457518?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 06:15:27+00:00

Monday's front pages are dominated by the news that the monarch has tested positive for coronavirus.

## Vegetables alone not enough to reduce heart risk, study finds
 - [https://www.bbc.co.uk/news/health-60429955?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60429955?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 05:11:21+00:00

Other lifestyle factors have more of an impact on heart attacks and strokes, a large UK study suggests.

## Joyful reunions as Australia opens to world after two years
 - [https://www.bbc.co.uk/news/world-australia-60458829?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-60458829?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 04:52:17+00:00

Family and friends reunite in airports as tourists enter the country for the first time in nearly two years.

## The elaborate con that tricked dozens into working for a fake design agency
 - [https://www.bbc.co.uk/news/uk-60387324?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60387324?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 03:18:08+00:00

Dozens of young people were tricked into thinking they were working for a glamorous UK design agency - which didn’t really exist.

## Covid: Australia's border reopens to international visitors
 - [https://www.bbc.co.uk/news/world-australia-60457735?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-60457735?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 00:53:34+00:00

It allows tourists to enter and families to reunite for the first time in nearly two years.

## Uttar Pradesh: India's Muslim victims of hate crimes live in fear
 - [https://www.bbc.co.uk/news/world-asia-india-60225543?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-60225543?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 00:30:17+00:00

The BBC examines violent crimes against Muslims in the north Indian state of Uttar Pradesh.

## How will the Beijing Games be remembered?
 - [https://www.bbc.co.uk/news/world-asia-china-60429251?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-60429251?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 00:10:18+00:00

Passports, pressure and pandas: A look back at two weeks of sports, drama and controversy.

## Bangkok: Exploring a lost world in an abandoned department store
 - [https://www.bbc.co.uk/news/world-asia-60431874?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-60431874?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 00:06:18+00:00

A group of artists and architects have turned a derelict building into an art and light exhibit.

## Japanese internment camps: How a long-lost kimono unearthed a family secret
 - [https://www.bbc.co.uk/news/world-us-canada-60408913?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60408913?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 00:03:49+00:00

The US imprisoned Japanese Americans 80 years ago - now the younger generation are asking questions.

## How smart sensors can help us care for our houseplants
 - [https://www.bbc.co.uk/news/business-60387006?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60387006?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-21 00:03:47+00:00

Sales of houseplants have soared since the pandemic and tech can help us to look after them.


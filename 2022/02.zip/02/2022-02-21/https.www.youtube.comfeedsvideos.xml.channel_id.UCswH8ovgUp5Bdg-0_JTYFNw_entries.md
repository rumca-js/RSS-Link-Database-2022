# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Dr John Campbell - You Need To Know This Now
 - [https://www.youtube.com/watch?v=OSvc5gFif8E](https://www.youtube.com/watch?v=OSvc5gFif8E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-22 00:00:00+00:00

Dr. John Campbell is a retired nurse educator who holds a Master of Science in health science and Ph.D. in nursing. He has come to prominence lately due to his YouTube channel that gained popularity during the pandemic. Audiences enjoy his content as he endeavours to present medical data that is often unaddressed in mainstream media in an objective and educational manner.

#DrJohnCampbell #BigPharma #Pandemic 

References
https://www.youtube.com/c/Campbellteaching

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Misinformation Is Now Terrorism?!
 - [https://www.youtube.com/watch?v=m2FHZ6bKybw](https://www.youtube.com/watch?v=m2FHZ6bKybw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-22 00:00:00+00:00

“Misinformation” is rife – especially with podcast hosts. But with misinformation now potentially equating to terrorism, is free speech becoming a terror threat?
#Misinformation #Censorship #Terror

References
https://truthout.org/articles/homeland-securitys-attempts-to-combat-misinformation-are-suspect/
https://alexberenson.substack.com/

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Canadian Trucker Data Stolen
 - [https://www.youtube.com/watch?v=bJ8ZhiOLejI](https://www.youtube.com/watch?v=bJ8ZhiOLejI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-21 00:00:00+00:00

As we discover more about the ability that government agencies in both Canada and the US have to illegally collect and use citizens data, what else don’t we know?
#Truckers #FreedomConvoy #Trudeau

References
https://reclaimthenet.org/cbc-uses-stolen-freedom-convoy-donor-list-to-contact-donors/
https://jacobinmag.com/2022/02/cia-spying-domestic-surveillance-program-data-collection

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


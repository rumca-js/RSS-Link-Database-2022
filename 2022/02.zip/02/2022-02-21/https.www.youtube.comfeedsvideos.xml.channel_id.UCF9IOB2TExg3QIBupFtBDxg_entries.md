# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Brendan
 - [https://www.youtube.com/watch?v=_PNPV3EF9oE](https://www.youtube.com/watch?v=_PNPV3EF9oE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-02-22 00:00:00+00:00

Guidance on Myocarditis and Pericarditis after mRNA COVID-19 Vaccines (Official Australian government publication).

https://www.health.gov.au/sites/default/files/documents/2021/10/covid-19-vaccination-guidance-on-myocarditis-and-pericarditis-after-mrna-covid-19-vaccines.pdf

Thank yo so much Brendan

## Dr Lisa Fitzpatrick, Community health promotion, Washington DC
 - [https://www.youtube.com/watch?v=k2XNOtBzGDU](https://www.youtube.com/watch?v=k2XNOtBzGDU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-02-21 00:00:00+00:00

Grapevine Health web site, https://www.grapevinehealth.com/

and YouTube channel, https://www.youtube.com/c/GrapevineHealth

Thank you very much for coming on again Lisa, and for your great work

## Pandemic ends Thursday
 - [https://www.youtube.com/watch?v=AOUHSg81HMU](https://www.youtube.com/watch?v=AOUHSg81HMU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-02-21 00:00:00+00:00

All legal restrictions in England ending Thursday, 24th February

Prof Sir David Spiegelhalter

https://www.bbc.co.uk/news/health-60408419?xtor=ES-208-[50410_NEWS_NLB_ACT_WK08_Mon_21_February]-20220221

It is now time to start seeing the risks as similar to those we face from other viruses and hazards we encounter in our lives.

Covid has assumed what is called a "dread risk"

the mental and emotional toll of the pandemic means people overestimate the actual risks.

"Those feelings of dread make it challenging to accept a risk as something 'normal', to weigh it up in the way we all have to weigh the inevitable risks of everyday life."

HMQ

Thursday, 24th Feb, all Covid restrictions will end in England

https://www.bbc.co.uk/news/uk-60467183

Legal duty to isolate for positive tests stopped

Free mass testing will stop from 1 April

Mr Johnson

Today is not the day we can declare victory over Covid because this virus is not going away

but it is the day when all the efforts of the last two years finally enable us to protect ourselves whilst restoring our liberties in full.

Omicron, with falling cases and hospital admissions, and we could now complete the "transition back towards normality" 

while retaining contingencies to respond to a Covid resurgence or a new variant.

Prof Sir Chris Whitty

the ending of virus restrictions was a "gradual, steady change over a period of time" as rates were declining, adding: "This is not a sudden everything stops."

The public health advice would be for people with Covid to self-isolate to prevent others catching it, 

as would be the case for many other highly infectious diseases

Sir Patrick Vallance

the virus would continue to evolve over the next couple of years and there was no guarantee that future variants would be less severe than Omicron.

From 21 February

dropping guidance for education and childcare, twice weekly asymptomatic testing

From Thursday 24 February
 
People who test positive for Covid will no longer be legally required to self-isolate

still be advised to stay at home and avoid contact with others for at least five full days

Routine contact tracing will end

Fully vaccinated close contacts and those aged under 18 will no longer be legally required to test daily for seven days

From 1 April

Free mass testing for symptomatic and asymptomatic for the general public will end

will instead be targeted towards the most vulnerable

People with Covid symptoms will be asked to exercise personal responsibility when deciding whether to stay at home, 

until then they are still advised to do so

Current government guidance on Covid passports will end and it will no longer recommend venues use the NHS Covid pass


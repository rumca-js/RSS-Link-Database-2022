# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## 'Everything he did was magnificent' - how Kane's masterclass at Man City blew title race wide open
 - [https://www.bbc.co.uk/sport/football/60449846?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60449846?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 23:54:56+00:00

Tottenham striker Harry Kane puts in one of his best performances of the season against Premier League leaders Manchester City to dent the title charge of the side he might have joined in the summer.

## Miami helicopter crash: Police share footage showing swimmers metres away from site
 - [https://www.bbc.co.uk/news/world-us-canada-60448611?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60448611?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 22:39:19+00:00

Miami Beach Police said two of the three passengers were taken to hospital in a stable condition.

## Winter Olympics: Belgium win first gold for 74 years
 - [https://www.bbc.co.uk/sport/winter-olympics/60445999?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-olympics/60445999?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 15:11:03+00:00

Belgium win their first Winter Olympics gold medal since 1948 when Bart Swings skates to victory in the men's mass start.

## Cheers and tears at home as GB take curling silver
 - [https://www.bbc.co.uk/news/uk-scotland-60446643?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-60446643?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 13:50:31+00:00

Cheers and tears at home in Scotland as Great Britain's men win silver medal in Beijing.

## Ukraine crisis: How are people coping with the threat of war?
 - [https://www.bbc.co.uk/news/world-europe-60446826?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60446826?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 13:33:42+00:00

Three Ukrainians tell the BBC how they have been dealing with life amid fears of a Russian invasion.

## Warrington Wolves: Why this rugby mascot drove off with the ball
 - [https://www.bbc.co.uk/news/uk-60443700?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60443700?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 12:37:44+00:00

Warrington Wolves' boss explains what happened with Whizzy Rascal's viral debut on the pitch.

## Storm Eunice leaves thousands of homes without power
 - [https://www.bbc.co.uk/news/uk-60442797?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60442797?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 12:27:28+00:00

Work is under way to restore power to those cut off after one of the worst UK storms in decades.

## Ukraine invasion would shock the world, Boris Johnson says
 - [https://www.bbc.co.uk/news/uk-politics-60432970?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60432970?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 12:24:31+00:00

The prime minister tells fellow world leaders "we should not underestimate the gravity of this moment".

## Ukraine conflict: Rebels declare general mobilisation as fighting grows
 - [https://www.bbc.co.uk/news/world-europe-60443504?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60443504?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 11:59:18+00:00

Men of fighting age are put on stand-by in Ukraine's breakaway territories amid high tensions.

## Storm Eunice: Meet the man behind the Big Jet TV phenomenon
 - [https://www.bbc.co.uk/news/uk-60445558?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60445558?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 11:18:55+00:00

Jerry Dyer's YouTube channel went viral after livestreaming planes trying to land in Storm Eunice.

## GB men's curlers win silver at Winter Olympics
 - [https://www.bbc.co.uk/sport/winter-olympics/60443333?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-olympics/60443333?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 10:53:36+00:00

Great Britain's men's curlers have to settle for Olympic silver as Sweden triumph 5-4 in a nerve-shredding final to claim gold.

## Winter Olympics: Great Britain lose 5-4 to Sweden in men's curling final - highlights
 - [https://www.bbc.co.uk/sport/av/winter-olympics/60444450?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/winter-olympics/60444450?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 10:37:31+00:00

Watch highlights lose 5-4 to Sweden after an extra end in the men's curling final to finish with silver at the Winter Olympics in Beijing.

## Storm Eunice: Huge 200-year-old oak tree falls on to house
 - [https://www.bbc.co.uk/news/uk-england-essex-60440429?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-60440429?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 10:05:34+00:00

A family 'does the very British thing' after their house is storm damaged... and goes to the pub.

## Winter Olympics: GB's Gus Kenworthy recovers from fall as New Zealand's Nico Porteous wins halfpipe gold
 - [https://www.bbc.co.uk/sport/av/winter-olympics/60442921?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/winter-olympics/60442921?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 09:44:12+00:00

Great Britain's Gus Kenworthy recovers from an "awful" fall to finish eighth in the freeski halfpipe as New Zealand's Nico Porteous wins gold at the Winter Olympics in Beijing.

## Neuroblastoma: The cancer-hit families facing a funding mountain
 - [https://www.bbc.co.uk/news/uk-england-leeds-60388625?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-60388625?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 09:06:32+00:00

What do you do if you are told your child has cancer, but treatment could cost more than a house?

## More than 17,000 chain store shops closed last year
 - [https://www.bbc.co.uk/news/business-60418435?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60418435?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 08:03:58+00:00

Figures reflect the rise of online shopping and the pandemic, but the rate of closures is slowing.

## Covid: PM returns lockdown party survey to police, and New Zealand reports record case numbers
 - [https://www.bbc.co.uk/news/uk-60442824?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60442824?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 07:45:02+00:00

Five things you need to know about the coronavirus pandemic this Saturday morning.

## Star Wars: Millennium Falcon exhibit draws family before it opens
 - [https://www.bbc.co.uk/news/uk-wales-60419386?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60419386?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 07:10:21+00:00

The planned Millennium Falcon exhibition even pushed one family to make the jump to hyperspace early.

## Energy bills: Paralysed dad fears he may lose adapted home
 - [https://www.bbc.co.uk/news/uk-wales-60433755?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60433755?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 07:09:17+00:00

Dave Davies is using credit cards to pay his energy bills as his costs continue to rise.

## Amir Khan v Kell Brook: Pundits and pros make their predictions for all-British grudge fight
 - [https://www.bbc.co.uk/sport/boxing/60415260?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/60415260?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 06:30:29+00:00

Will Amir Khan's speed be too much for Kell Brook? Or will Brook's timing and power stop Khan? We have some predictions from the boxing world.

## The Papers: 'Carnage' as '122mph storm batters Britain'
 - [https://www.bbc.co.uk/news/blogs-the-papers-60440729?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60440729?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 06:22:07+00:00

The fallout and damage wrought by Storm Eunice dominates Saturday's front pages.

## Who is the coach that gave Valieva a 'chilling' reception?
 - [https://www.bbc.co.uk/sport/winter-olympics/60427119?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-olympics/60427119?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 04:41:24+00:00

Who is the coach whose "cold" treatment of a sobbing Kamila Valieva was "chilling" to watch according to the IOC?

## Ministers set to drop UK ban on foie gras and fur imports
 - [https://www.bbc.co.uk/news/uk-politics-60439796?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60439796?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 04:20:12+00:00

The proposed measure is likely to be dropped from an animal welfare bill, after ministers raised concerns.

## Boris Johnson returns lockdown party questionnaire to police
 - [https://www.bbc.co.uk/news/uk-politics-60440746?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60440746?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 02:30:18+00:00

Boris Johnson was one of more than 50 people to be sent the document by the Metropolitan Police.

## Canada protests: Police begin to make arrests at Ottawa protest
 - [https://www.bbc.co.uk/news/world-us-canada-60420469?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60420469?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 01:10:02+00:00

Police accuse protesters of using children as a shield between officers and the demonstration.

## Do crime apps and viral videos stop bystanders from helping?
 - [https://www.bbc.co.uk/news/world-us-canada-60091787?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60091787?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 01:00:27+00:00

Popular use of mobile phone cameras and apps fans fears of a digitally charged "bystander effect".

## Maryland couple plead guilty in nuclear secrets plot
 - [https://www.bbc.co.uk/news/world-us-canada-60442225?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60442225?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 00:41:56+00:00

The wife acted as lookout while her husband hid a data card inside a peanut butter sandwich.

## The role of stomachs in Nigerian electioneering
 - [https://www.bbc.co.uk/news/world-africa-60023007?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-60023007?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 00:33:33+00:00

How bags of rice will be used by grovelling Nigerian candidates to curry favour.

## Week in pictures: 12-18 February 2022
 - [https://www.bbc.co.uk/news/in-pictures-60429635?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-60429635?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 00:21:15+00:00

A selection of powerful images from all over the globe, taken in the last seven days.

## The amateur historians chronicling Delhi's past on Instagram
 - [https://www.bbc.co.uk/news/world-asia-india-60299136?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-60299136?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 00:17:59+00:00

Some amateur historians are documenting neglected corners of Delhi, one Instagram post at a time.

## Shlomo on why he stepped back from the beatboxing limelight
 - [https://www.bbc.co.uk/news/uk-england-sussex-60368918?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-sussex-60368918?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-19 00:02:26+00:00

After tackling depression, beatboxer Shlomo is now back on stage helping children's mental health.


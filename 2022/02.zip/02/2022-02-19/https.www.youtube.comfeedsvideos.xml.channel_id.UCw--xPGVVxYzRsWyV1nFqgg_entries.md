# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## “New” Wheel of Time Book⌛ Bioshock movie☣️ New Stormlight Covers📖-FANTASY NEWS
 - [https://www.youtube.com/watch?v=YCngbzoUXSo](https://www.youtube.com/watch?v=YCngbzoUXSo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-02-19 00:00:00+00:00

Let's jump into the new Fantasy News slot! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 Intro

00:52 Stormlight Covers https://twitter.com/gollancz/status/1494648925587922946 

01:38 Blade itself special edition https://twitter.com/binding_broken/status/1491849457843032068?t=WVs2qadGxqQU69_m4oqlKw&s=19 

02:16 New Wheel of Time Book https://www.tor.com/2022/02/15/book-announcements-origins-of-the-wheel-of-time-the-legends-and-mythologies-that-inspired-robert-jordan/ 

03:24 DRAGON’S PROMISE https://twitter.com/LizLim/status/1493978613452087297 

03:49 Michael Moorcock omnibus: https://www.tor.com/2021/03/02/revealing-omnibus-editions-of-michael-moorcocks-elric-of-melnibone/ 

04:16 New Elric Saga Prequel: https://www.simonandschuster.com/books/The-Citadel-of-Forgotten-Myths/Michael-Moorcock/Elric-Saga-The/9781982199807 

04:36 Cyberpunk 1.5 patch:  https://www.polygon.com/22934908/cyberpunk-2077-next-gen-update-patch-1-5-notes-ps5-xbox-series-x-pc 

05:10 Bioshock movie: https://deadline.com/2022/02/bioshock-netflix-to-produce-film-based-on-video-game-franchise-1234933395/ 

06:06 I AM LEGEND movie: https://screenrant.com/i-am-legend-sequel-movie-show-development-details/ 

06:18 Halo season 2: https://twitter.com/DiscussingFilm/status/1493706390849957896?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet 

06:53 Lord of the Rings Rings of Power Performance: https://www.syfy.com/syfy-wire/lord-of-the-rings-the-rings-of-power-sets-new-super-bowl-record 

07:33 Dune Best Director snub: https://www.indiewire.com/2022/02/josh-brolin-denis-villeneuve-dune-oscar-snub-1234698390/ 

07:48 Alien series setting: https://twitter.com/DiscussingFilm/status/1494368432132956166?t=9IBIM7BwCZyBF-XOzFmz4A&s=19


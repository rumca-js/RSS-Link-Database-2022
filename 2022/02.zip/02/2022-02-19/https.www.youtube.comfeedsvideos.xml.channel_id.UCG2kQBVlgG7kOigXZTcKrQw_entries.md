# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Meksyk - jak powstały cenoty? Ślub w cenocie. I jak Coca Cola niszczy Meksykanów?
 - [https://www.youtube.com/watch?v=8wB5ciH5CgI](https://www.youtube.com/watch?v=8wB5ciH5CgI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2022-02-20 00:00:00+00:00

Po dłuższej przerwie zapraszamy na nowy sezon filmów 2022 :) Będzie w tym roku dużo roweru, będzie sporo gór, ale najpierw będzie co nieco meksykańskiego słońca. Jest to pierwszy odcinek z Jukatanu (będą w sumie dwa) i może wydawać się ciut rwany, za co przepraszam. Po prostu było zbyt dużo wątków, które chciałem połączyć w jedną całość i mam lekkie wrażenie, że nie wyszło. Wybaczcie jeśli Was ten film zmęczył, obiecuję, że drugi o Majach będzie znacznie lepszy :)

►►Zachęcam do subskrypcji: http://bit.ly/2cmWbSO 

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

Muzyka Artlist i Nevaeh


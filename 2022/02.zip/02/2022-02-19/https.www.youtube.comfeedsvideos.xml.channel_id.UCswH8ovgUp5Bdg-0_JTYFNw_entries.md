# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## This Is Why US Government Wants War
 - [https://www.youtube.com/watch?v=ivROLiLmnro](https://www.youtube.com/watch?v=ivROLiLmnro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-20 00:00:00+00:00

As Joe Biden escalates tensions over Ukraine, is this latest potential war being used to divert American public attention from government corruption and incompetence? 
#War #WW3 #Russia 

References
https://scheerpost.com/2022/02/14/hedges-democrats-the-more-effective-evil/

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Trudeau - Is This Your Liberal Hero?
 - [https://www.youtube.com/watch?v=S_GnClytz34](https://www.youtube.com/watch?v=S_GnClytz34)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-19 00:00:00+00:00

Justin Trudeau has invoked emergency powers to deal with the Canadian freedom convoy – are these the actions of a liberal leader who believes in democracy?  
#Trudeau #Truckers #Canada 

References
https://www.wsj.com/articles/justin-trudeau-trucker-emergency-canada-ottowa-emergency-powers-protest-vaccine-mandate-freedom-convoy-11644962166
https://taibbi.substack.com/p/justin-trudeaus-ceausescu-moment?utm_source=url
https://www.theguardian.com/world/2022/feb/13/freedom-convoys-legitimate-covid-protest-or-vehicle-for-darker-beliefs

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


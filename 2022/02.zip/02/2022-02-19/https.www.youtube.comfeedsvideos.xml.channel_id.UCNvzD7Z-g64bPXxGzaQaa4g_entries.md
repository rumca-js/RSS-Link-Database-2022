# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 20 NEW PS4 & PS5 Games of 2022 [4K]
 - [https://www.youtube.com/watch?v=i8M-O5Dqoxg](https://www.youtube.com/watch?v=i8M-O5Dqoxg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-20 00:00:00+00:00

PS4 & PS5 game releases aren't slowing down in 2022. Here's everything worth looking forward to in 2022.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1
#20 The Day Before

Platform : PC PS5 XSX|S 

Release Date : June 21, 2022



#19 Gotham Knights

Platform : PC PS5 XSX|S PS4 Xbox One 

Release Date : 2022 



#18 Evil West 

Platform : PC PS5 XSX|S PS4 Xbox One 

Release Date : TBA 2022



#17 King of Fighters XV

Platform : PC PS5 XSX|S PS4 Xbox One 

Release Date : February 17, 2022 



#16 SHOWA AMERICAN STORY  

Platform : PC PS4 PS5 

Release Date : TBA 



#15 Sifu 

Platform : PC PS4 PS5 

Release Date : February 8, 2022



#14 Star Wars: Knights of the Old Republic Remake

Platform : PC PS5 

Release Date : TBA 



#13 Steelrising

Platform : PC PS5 XSX|S 

Release Date : June 2022 



#12 Stray

Platform : PC PS5 PS4 

Release Date : Early 2022 



#11 Tiny Tina's Wonderlands 

Platform : PC PS5 XSX|S PS4 Xbox One 

Release Date : March 25, 2022 



#10 Hogwarts Legacy

Platform : PC PS5 XSX|S PS4 Xbox One     

Release Date : 2022 



#9 Little Devil Inside

Platform : PC PS5 Switch PS4 Xbox One 

Release Date : Winter 2022 



#8 Atomic Heart 

Platform : PC PS5 XSX|S PS4 Xbox One     

Release Date : Q3-Q4 2022 



#7 Saints Row 

Platform : PC PS5 XSX|S PS4 Xbox One    

Release Date : August 23, 2022 



#6 A Plague Tale Requiem

Platform : Switch PS5 XSX|S PC

Release Date : TBA 2022



#5 Ghostwire Tokyo 

Platform : PC PS5 

Release Date : March 25, 2022 



#4 Elden Ring

Platform : PC PS5 XSX|S PS4 Xbox One   

Release Date : February 25, 2022 



#3 Gran Turismo 7

Platform : PS4 PS5 

Release Date : March 4, 2022 



#2 Horizon Forbidden West

Platform : PS4 PS5 

Release Date : February 18, 2022 



#1 God of War Ragnarok

Platform : PS4 PS5 

Release Date : 2022 



Bonus :- 



Lies of P 

Platform : PC PS5 XSX|S Stadia 

Release Date : late 2022 or 2023  



Sniper Elite 5 

Platform : PC PS5 XSX|S PS4 Xbox One  

Release Date : TBA 2022 



Forspoken

Platform : PC PS5 

Release Date : May 24, 2022 



Elex II

Platform : PC PS5 XSX|S PS4 Xbox One 

Release Date : March 1, 2022 



Stranger of Paradise: Final Fantasy Origin

Platform : PC PS5 XSX|S PS4 Xbox One  

Release Date : March 18, 2022 
Dying Light 2: Stay Human 

Platform :  PC PS5 XSX|S PS4 Xbox One February 4, 2022 

Release Date : Switch Q2 2022



Marvel’s Midnight Suns

Platform : PC PS5 XSX|S PS4 Switch Xbox One 

Release Date : Q3/Q4 2022 



Sonic Frontiers

Platform : PC PS5 XSX|S PS4 Switch Xbox One  

Release Date : Q4 2022 



Test Drive Unlimited Solar Crown 

Platform : PC PS5 XSX|S PS4 Switch Xbox One    

Release Date : September 22, 2022



Lego Star Wars: Skywalker Saga

Platform : PC PS5 XSX|S PS4 Switch Xbox One  

Release Date : April 5, 2022 



OlliOlli World

Platform : PC PS5 XSX|S PS4 Switch Xbox One 

Release Date : 8 February 2022 

0:00 Intro 
0:17 The Day Before
0:53 Gotham Knights
1:49 Evil West 
2:36 King of Fighters XV
3:21 SHOWA AMERICAN STORY  
4:17 Sifu 
4:57 Star Wars: Knights of the Old Republic Remake
5:26 Steelrising
6:19 Stray
6:50 Tiny Tina's Wonderlands 
7:24 Hogwarts Legacy
8:03 Little Devil Inside
8:43 Atomic Heart 
9:19 Saints Row 
9:56 A Plague Tale Requiem
10:33 Ghostwire Tokyo 
11:17 Elden Ring
11:56 Gran Turismo 7
12:34 Horizon Forbidden West
13:10 God of War Ragnarok
13:50 Bonus

## Horizon Forbidden West - Before You Buy
 - [https://www.youtube.com/watch?v=eCCKH6qYLKo](https://www.youtube.com/watch?v=eCCKH6qYLKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-19 00:00:00+00:00

Horizon Forbidden West (PS5, PS4) is the follow up to the 2017 original with better graphics, world, and gameplay. How does it truly stack up? Let’s talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy Horizon: https://amzn.to/3Bxd0oa


Watch more 'Before You Buy': https://bit.ly/2kfdxI6


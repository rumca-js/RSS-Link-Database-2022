# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Moje życie w Polsce - z @RomanFanPolszy @vlogcasha @mowikamera
 - [https://www.youtube.com/watch?v=3vntsZoX_fk](https://www.youtube.com/watch?v=3vntsZoX_fk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2022-02-19 09:49:17+00:00

Zgarnij pocztówki i magnesy z podróży wspierając BezPlanu na Patronite: http://bit.ly/2KsFTZk

Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv

Wszystkie odcinki BezPlanu chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

Goście (chronologicznie):
Roman FanPolszy: https://www.youtube.com/c/RomanFanPolszy
Cash: https://www.youtube.com/c/vlogcasha
Evelina Ross: https://www.instagram.com/evelinaross_/
Adrian Kilar: https://www.youtube.com/c/AdrianKilarMowi
Tomek Surdel: https://www.instagram.com/tomeksurdel/
Anna Markowska: https://www.instagram.com/annmarelo/

Czas akcji: luty 2022r.


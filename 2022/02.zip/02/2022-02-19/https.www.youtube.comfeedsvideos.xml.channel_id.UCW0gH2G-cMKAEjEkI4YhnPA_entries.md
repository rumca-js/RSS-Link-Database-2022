# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## War Of The Rohirrim First Look - Lore, Breakdown, & Theories | The Lord of the Rings Anime
 - [https://www.youtube.com/watch?v=5NaXg6um5B0](https://www.youtube.com/watch?v=5NaXg6um5B0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-02-19 00:00:00+00:00

First images and release date from War of the Rohirrim!  We now know that The Lord of the Rings: The War of the Rohirrim Anime will release on April 12, 2024.  We also got our first look at two pieces of concept art from the film and a slew of confirmations of who is involved.  We already knew that anime director Kenji Kamiyama was on board, but we also learned of the involvement of Alan Lee, John Howe, Sir Richard Taylor, WETA, and Philippa Boyens!  Today's video not only covers the news and what it means for the film, but we also dive deep into the lore around this time and talk over the spine-tingling ways this could connect to the Lord of the Rings trilogy!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello

The Riders of Rohan - Turner Mohan
Ride of the Rohirrim - Donato Giancola
Helm Hammerhand's Last Stand - Matej Cadil
Helm's Last Stand - Turner Mohan
The Men of Dunland - Turner Mohan
Dunlendings - The Voice of Isengard
Rohirrim - Angus McBride
Eowyn - Sara Morello
Eowyn - Sara Morello
Eowyn and the Witch-King - Matthew Stewart
Eowyn - Matthew Stewart
Eowyn of Rohan - Sara Morello
Rohirrim - Aegeri
Forth Eorlingas - Jenny Dolfen
Eowyn and Merry - Matthew Stewart
Ride of the Rohirrim - Anke Eissmann
The Riders of Rohan - Ted Nasmith
Helm's Deep - Ralph Damiani
Helm Hammerhand - Turner Mohan
The House of Eorl, Helm Hammerhand - Aegeri
Helm Hammerhand (in snow) - Uknown Artist
Rohirrim in Battle of Pelennor Fields - Ivan Cavini
The Rohirrim - Aegeri
Rohirrim - Aronja Art
The Charge of the Rohirrim at Helm's Deep - John Howe
Rohirrim and Haradrim - Alan Lee

#lordoftherings #waroftherohirrim #rohan


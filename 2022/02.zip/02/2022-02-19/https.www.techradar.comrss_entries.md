# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Hogwarts Legacy release date, trailers, gameplay and pre-order details
 - [https://www.techradar.com/news/harry-potter-rpg-everything-we-know/](https://www.techradar.com/news/harry-potter-rpg-everything-we-know/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-19 09:36:12+00:00

Hogwarts Legacy looks set to be the Harry Potter RPG that fans have waited years for. Here's everything we know so far, including a release date, and a look at all the latest news.

## Hogwarts Legacy release date, trailers, gameplay and pre-order details
 - [https://www.techradar.com/news/harry-potter-rpg-everything-we-know](https://www.techradar.com/news/harry-potter-rpg-everything-we-know)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-19 09:36:12+00:00

Hogwarts Legacy looks set to be the Harry Potter RPG that fans have waited years for. Here's everything we know so far.


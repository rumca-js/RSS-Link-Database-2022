# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Maajid Nawaz on the Misguided Nature of the War on Terror
 - [https://www.youtube.com/watch?v=zJX3byjYSMc](https://www.youtube.com/watch?v=zJX3byjYSMc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-02-19 00:00:00+00:00

Taken from JRE #1780 w/Maajid Nawaz:
https://open.spotify.com/episode/1ugbn7cuab3mNgKbo81ajM?si=df79999d00f84e52


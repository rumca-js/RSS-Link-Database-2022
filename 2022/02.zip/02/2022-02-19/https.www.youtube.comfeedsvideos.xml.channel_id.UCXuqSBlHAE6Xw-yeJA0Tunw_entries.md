# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This PS4 runs Linux now...
 - [https://www.youtube.com/watch?v=TVSE5wusBuE](https://www.youtube.com/watch?v=TVSE5wusBuE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-20 00:00:00+00:00

Get 50% off your Zoho CRM annual subscription with code ZCRM50 at: https://lmg.gg/ZohoCRM


Anthony would like to apologize to Sony for having way too much fun messing around with a jailbroken PS4 Pro. Cheats? You bet. Homebrewed Software? Totally. Linux? You better believe it. HALO AND MARIOKART?… HECK. YES. Why buy a PS5 when you can do this?

ModdedWarfare's PS4 Jailbreak Tutorial Playlist
https://youtube.com/playlist?list=PLn7ji3VsPy3Gryq_sCOMp6H87jXywCMPI

Discuss on the forum: https://linustechtips.com/topic/1413259-dont-buy-a-ps5-until-you-try-this/

Buy Kingston 32GB USB 3 Pack: https://geni.us/lBqpp

Buy Samsung SSD T7 Portable External SSD: https://geni.us/aeIbvC1

Buy DualShock 4 Controller: https://geni.us/NnOUv

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:34 About the hack
3:00 The one big problem
3:48 Homebrew Store
5:27 Cheats and Trainers
6:17 The Last of Us Part 2
7:50 Bloodborne at ~60 fps
9:12 PS4 go brrrrrrr
9:40 Linux Setup
10:41 Dat linux
12:12 Get rekt, Anthony
12:22 Why?
14:07 Outro

## This Seems Like a BAD Idea - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=cjGqxbsY9JA](https://www.youtube.com/watch?v=cjGqxbsY9JA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-19 00:00:00+00:00

Thanks to Intel for continuing to sponsor this series! Check out Intel 12th Gen Processors at https://geni.us/uNekg

Colin's speaker audition gauntlet
Spotify: https://open.spotify.com/playlist/0Gb6OyxtdyCwyWRsfwoaHb?si=ec880f393daa4152
Tidal: https://tidal.com/browse/playlist/254a714e-88cd-44e3-9654-c93f0b2a42e0

Discuss on the forum: https://linustechtips.com/topic/1413015-i-have-some-regrets-intel-5000-extreme-tech-upgrade/


Check out Colin's part list: https://lmg.gg/FKEZs

Check out the TIG Button at https://lmg.gg/E7hG3

Check out the Miller Syncrowave 210 Speakerpower SP1-700-HT Subwoofer Plate Amplifier at https://geni.us/OTBCb

Purchases made through some store links may provide some compensation to Linus Media Group.

Special thanks to:

Soniclab Sound - https://www.instagram.com/soniclab.sound/
Stickybuds - https://stickybuds.com/
Westwood Recording - https://westwoodrecordings.com/
Air Liquide - https://www.airliquide.ca/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Speaker Testing: Stickybuds - In Your System
Artist Link:  https://www.youtube.com/user/Stickybudsmusic
Listen on Spotify: https://open.spotify.com/artist/0EdsvtaOf72jQy9LoQ8QqF?si=4c3Kv3xdRmqZ6h5pDs6bHg

Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:37 Naptime
1:28 Colin's Favourite Toys
2:08 Colin's Parts
4:19 More Shop Fun
6:06 Harvesting the Old Server
8:07 Starting the Build
13:01 Crank the Volume
13:54 Making It Work
17:19 First Start Up and Configuration
20:13 Update!
21:08 Conclusion


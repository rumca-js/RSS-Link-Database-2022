## Ottawa Police Chief says police will come after protesters for months to come “with financial sanctions and criminal charges”
 - [https://westphaliantimes.com/ottawa-police-chief-says-law-enforcement-will-come-after-protestors-even-if-they-go-home/](https://westphaliantimes.com/ottawa-police-chief-says-law-enforcement-will-come-after-protestors-even-if-they-go-home/)
 - RSS feed: westphaliantimes.com
 - date published: 2022-02-19 06:53:36+00:00

test


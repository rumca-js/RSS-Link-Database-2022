# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week - Platformy za miliony, Rogan i małpy oraz dziurawe słuchawki od Sony
 - [https://www.youtube.com/watch?v=fmwO5Q_W2lo](https://www.youtube.com/watch?v=fmwO5Q_W2lo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-02-20 00:00:00+00:00

Dziś w odcinku:
00:00 Samodzielne myślenie 
00:51 Dobry wieczór
00:55 Donda2 na stemplayerze za 200$
02:54 Kontrowersje Joe Rogana
08:25 Jay Z sprzedał udziały Tidala
08:45 Słuchawki Sony Link Buds
10:06 Chrome OS na każym laptopie
10:53 Mobilne Centrum Testów we Wrocławiu
11:55 Nowy laptop od Samsunga?
12:31 Kto będzie na targach MWC
12:55 Problemy Huawei, Xiaomi i Oppo
14:37 Nowe produkty od Apple z 5G
15:13 Pożegnanko
15:25 Znośnego tygodnia!

Źródła:
Centrum Testów we Wrocławiu: https://bit.ly/3s3Go2o
Ye sprzedaje album za 200$: https://bit.ly/3BAz7tY
1971 - zwiastun: https://youtu.be/7QUSrefGO34
Joe Rogan i jego historie: https://youtu.be/D5SYrX41BtA
Jak Jay Z zarobił na Tidalu: https://bit.ly/3LKAA5y
Sony Link Buds: https://bit.ly/3p3skUG
Zrób chromebooka z (prawie) każdego laptopa: https://bit.ly/3H7qvvU
Samsung z nowym... laptopem: https://bit.ly/3BzSSlf
MWC w Barcelonie - kto będzie, a kto nie: https://bit.ly/3I5N6ue
Nadchodzą stare iPhone'y i iPady 5G: https://bit.ly/3I8d1Bm

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


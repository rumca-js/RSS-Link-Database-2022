## Jean-Luc Brunel: Epstein associate found dead in Paris prison cell - BBC News
 - [https://www.bbc.com/news/world-europe-60443518](https://www.bbc.com/news/world-europe-60443518)
 - RSS feed: https://www.bbc.com
 - date published: 2022-02-19 11:21:46+00:00

Jean-Luc Brunel: Epstein associate found dead in Paris prison cell - BBC News


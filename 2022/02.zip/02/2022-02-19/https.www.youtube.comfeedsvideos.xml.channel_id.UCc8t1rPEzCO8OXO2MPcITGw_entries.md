## A Timeline of Narnia History | Narnia Lore | The Seven Ages of Narnia
 - [https://www.youtube.com/watch?v=Vy_nbi_Gl7k](https://www.youtube.com/watch?v=Vy_nbi_Gl7k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCc8t1rPEzCO8OXO2MPcITGw
 - date published: 2022-02-19 00:00:00+00:00

Narnian history spans several thousand years, but is marked by seven distinct ages.  Understanding these ages helps us see further up and further into the world created by C.S. Lewis.  Including the lives of beloved Lucy Pevinse and her siblings Peter, Edmund, and Susan, Tumnus, Jadis the White Witch, Caspian, Reepicheep, and many others--not the least of which is King Aslan the Lion himself.

Many thanks to these fantastic artists for their incredible work.  Please check them out and support their efforts:

Pauline Baynes
Justin Sweet @ justinsweet.com
Henrik Tamm @ henriktamm.com
Craig Mullins @ArtStationHQ 
Timur Kasov @ArtStationHQ
Sedeptra @deviantart9965 
Vance Kovaks @deviantart9965 
Sjored Bijkerk @ArtStationHQ 
ReneAinger   @DeviantArt
Nele Diel @deviantart9965 
Kate Miterko @ArtStationHQ 
Aisule @deviantart9965
Murat Gul @geethaarts 
Leo Hakkio @ArtStationHQ 
Joseph Feely @ArtStationHQ 
Jack Dowell @ArtStationHQ 
Hugo Pozzuoli @ArtStationHQ 
88grzes @ArtStationHQ 
Emma Ronkainen @ArtStationHQ 
Helena Nikulina @ArtStationHQ 
SwordoftheWord @deviantart9965 
Gabriel Perez @ArtStationHQ 
Anh Le @ArtStationHQ


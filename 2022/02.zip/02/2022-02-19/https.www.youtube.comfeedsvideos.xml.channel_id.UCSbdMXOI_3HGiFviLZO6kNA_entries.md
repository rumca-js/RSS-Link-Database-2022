# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The last VR game you’ll ever play
 - [https://www.youtube.com/watch?v=IVcNkznLZsg](https://www.youtube.com/watch?v=IVcNkznLZsg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-02-19 00:00:00+00:00

Hello! Here is my video on Zenith- the first VRMMORPG to really take off. Similar to World of Warcraft, Final Fantasy XIV, and Runescape, except it's all in VR. It's sort of (if you're feeling fictional) our first taste of something like Sword Art Online. Needless to say plenty of Kiritos have been running around. 

Something interesting here is that I think Zenith can actually do a lot more, but it's held back by the restraints of the risky MMO genre. Here's an interesting analytical piece on the game, the genre's future within VR, and my thoughts on Zenith as a whole. 

Find the game here: 
https://zenithmmo.com/

My links:
Discord.gg/Thrill
Twitch.tv/Thrilluwu
Twitter.com/Thrilluwu


# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 1 Księga Królewska || Rozdział 08
 - [https://www.youtube.com/watch?v=HrNJiTNLh3M](https://www.youtube.com/watch?v=HrNJiTNLh3M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-20 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Historie potłuczone [#54] O błaźnie, co księdzem został
 - [https://www.youtube.com/watch?v=-I4w9dDImaQ](https://www.youtube.com/watch?v=-I4w9dDImaQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-20 00:00:00+00:00

Historie potłuczone to opowieści o córkach i synach Boga, pięknych i brzydkich, świętych i grzesznych, szczęśliwych i na skraju rozpaczy. To opowieści o drodze, którą idzie się do nieba i o zakrętach i chaszczach, które spychają do piekła. To opowieści o ludziach po prostu. Czyli o nas.

Muzyka: Kai Engel: Brand New World, https://freemusicarchive.org/music/Kai_Engel/Sustains/Kai_Engel_-_Sustains_-_01_Brand_New_World

@Langustanapalmie 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 1 Księga Królewska || Rozdział 07
 - [https://www.youtube.com/watch?v=niSL1bMkO84](https://www.youtube.com/watch?v=niSL1bMkO84)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-19 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#275] Kiedy nadstawić policzek, a kiedy dać w gębę?
 - [https://www.youtube.com/watch?v=djPzRcTkJ_k](https://www.youtube.com/watch?v=djPzRcTkJ_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-19 00:00:00+00:00

#cnn #dobrewiadomości    @Langustanapalmie   

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedziela, VII Tydzień zwykły, Rok C, II
Siódma Niedziela zwykła

1. czytanie (1 Sm 26, 2. 7-9. 12-13. 22-23)

Saul wyruszył ku pustyni Zif, a wraz z nim trzy tysiące doborowych Izraelitów, aby wpaść na trop Dawida na pustyni Zif.
Dawid wraz z Abiszajem zakradli się w nocy do obozu; Saul właśnie spał w środku obozowiska, a jego dzida była wbita w ziemię obok głowy. Abner i ludzie leżeli uśpieni dokoła niego. Rzekł więc Abiszaj do Dawida: «Dziś Bóg oddaje wroga twojego w twe ręce. Teraz pozwól, że przybiję go dzidą do ziemi, jednym pchnięciem, drugiego nie będzie trzeba». Dawid odparł Abiszajowi: «Nie zabijaj go! Któż bowiem podniósłby rękę na pomazańca Pańskiego, a nie poniósł kary?»
Wziął więc Dawid dzidę i bukłak na wodę od wezgłowia Saula i poszli sobie. Nikt ich nie spostrzegł, nikt o nich nie wiedział, nikt się nie obudził. Wszyscy spali, gdyż Pan zesłał na nich twardy sen.
Dawid oddalił się na przeciwległą stronę i stanął na wierzchołku góry w oddali, a dzieliła go od nich spora odległość.
Wtedy Dawid zawołał do Saula: «Oto dzida królewska, niech przyjdzie który z pachołków i weźmie ją. Pan nagradza człowieka za sprawiedliwość i wierność: Pan dał mi ciebie w ręce, lecz ja nie podniosłem ich przeciw pomazańcowi Pańskiemu».

2. czytanie (1 Kor 15, 45-49)

Bracia:
Stał się pierwszy człowiek, Adam, duszą żyjącą, a ostatni Adam duchem ożywiającym. Nie było jednak wpierw tego, co duchowe, ale to, co ziemskie; duchowe było potem. Pierwszy człowiek z ziemi – ziemski, Drugi Człowiek – z nieba. Jaki ów ziemski, tacy i ziemscy; jaki Ten niebieski, tacy i niebiescy.
A jak nosiliśmy obraz ziemskiego człowieka, tak też nosić będziemy obraz Człowieka niebieskiego.

Ewangelia (Łk 6, 27-38)

Jezus powiedział do swoich uczniów:
«Powiadam wam, którzy słuchacie: Miłujcie waszych nieprzyjaciół; dobrze czyńcie tym, którzy was nienawidzą; błogosławcie tym, którzy was przeklinają, i módlcie się za tych, którzy was oczerniają. Jeśli cię kto uderzy w policzek, nadstaw mu i drugi. Jeśli zabiera ci płaszcz, nie broń mu i szaty. Dawaj każdemu, kto cię prosi, a nie dopominaj się zwrotu od tego, który bierze twoje. Jak chcecie, żeby ludzie wam czynili, podobnie wy im czyńcie.
Jeśli bowiem miłujecie tych tylko, którzy was miłują, jakaż za to należy się wam wdzięczność? Przecież i grzesznicy okazują miłość tym, którzy ich miłują. I jeśli dobrze czynicie tym tylko, którzy wam dobrze czynią, jaka za to należy się wam wdzięczność? I grzesznicy to samo czynią. Jeśli pożyczek udzielacie tym, od których spodziewacie się zwrotu, jakaż za to należy się wam wdzięczność? I grzesznicy pożyczają grzesznikom, żeby tyleż samo otrzymać.
Wy natomiast miłujcie waszych nieprzyjaciół, czyńcie dobrze i pożyczajcie, niczego się za to nie spodziewając. A wasza nagroda będzie wielka i będziecie synami Najwyższego; ponieważ On jest dobry dla niewdzięcznych i złych. Bądźcie miłosierni, jak Ojciec wasz jest miłosierny. Nie sądźcie, a nie będziecie sądzeni; nie potępiajcie, a nie będziecie potępieni; odpuszczajcie, a będzie wam odpuszczone. Dawajcie, a będzie wam dane; miarę dobrą, ubitą, utrzęsioną i wypełnioną ponad brzegi wsypią w zanadrza wasze. Odmierzą wam bowiem taką miarą, jaką wy mierzycie».
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

Niedzielnik na ROK C
→ https://wdrodze.pl/produkt/niedzielnik-c-komentarze-do-czytan-adam-szustak/

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1023] Wolno
 - [https://www.youtube.com/watch?v=TIcCWXySQM8](https://www.youtube.com/watch?v=TIcCWXySQM8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-19 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


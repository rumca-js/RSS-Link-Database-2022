# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## A legend died: honoring Tim Gilles aka slipperman. A great man, recording engineer, & inspiration.
 - [https://www.youtube.com/watch?v=rld3plefXtA](https://www.youtube.com/watch?v=rld3plefXtA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-20 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://www.uticaod.com/obituaries/pnys0135877
👉 https://gearspace.com/board/for-those-we-have-lost-memorials-rips-and-obituaries/1369965-r-i-p-tim-mildenhall-gilles-aka-rumblefish-aka-slipperman.html
👉 https://www.youtube.com/watch?v=qOzrlOY9jPM

🔵 Desk: https://amzn.to/3njMvN3
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3JZ2rOy
🔵 Camera: https://amzn.to/3K2H5Qw

## I made a wrong turn and a new friend
 - [https://www.youtube.com/watch?v=NxTxGcE0bp0](https://www.youtube.com/watch?v=NxTxGcE0bp0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-20 00:00:00+00:00

https://tinyurl.com/rossmatrix

## Louis Rossmann AMA random livestream
 - [https://www.youtube.com/watch?v=QE0gAbB5Lrs](https://www.youtube.com/watch?v=QE0gAbB5Lrs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-19 00:00:00+00:00

https://tinyurl.com/rossmatrix
Post a message on screen http://bit.ly/postamessage Or else I will read it in the normal chat if it is not swamped. I am sorry if I miss your message, I do my best to read as much stuff as I can that is somewhat interesting even if it is a normal unpaid message, but the chat sometimes moves way too fast for me to get things.


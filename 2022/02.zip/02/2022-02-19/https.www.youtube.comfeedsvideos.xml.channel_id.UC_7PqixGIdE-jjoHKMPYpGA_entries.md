# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Co złego jest w kazirodztwie?
 - [https://www.youtube.com/watch?v=BYQ1yUIbRDw](https://www.youtube.com/watch?v=BYQ1yUIbRDw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2022-02-19 00:00:00+00:00

📚 Kup moją najnowszą książkę ► https://siedem.alt.pl
Do 9 listopada darmowa wysyłka na terenie Polski

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Książka o genach ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook

👉 Nasz serwis popularnonaukowy ► https://naukowybelkot.pl 
👉 Patronite ► https://patronite.pl/NaukowyBelkot 

Odcinek miał wyjść na walentynki, ale się nie wyrobiłem. Dowiedziałem się jednak zbyt ciekawych rzeczy, żeby czekać do 2023 roku z publikacją.

===
Rozkład jazdy:

0:00 Hiszpańscy Habsburgowie
2:44 O kazirodztwie trochę formalnie
5:50 Karol Darwin - mąż swojej kuzynki
7:24 Geny
10:22 Nasze przygody z inbredem
12:10 Dlaczego to jest tabu?
14:15 Przekleństwo gepardów i Karola II

===
Źródła (wybrane):

D. Myśliwiec - Przepis na człowieka (a co!)
M. Fareed i in. - Estimating the Inbreeding Depression on Cognitive Behavior: A Population Based Study of Child Cohort
M. Ridley - Czerwona królowa. Płeć a ewolucja natury ludzkiej
J. Antfolk i in. - Fitness Costs Predict Inbreeding Aversion Irrespective of Self-Involvement: Support for Hypotheses Derived from Evolutionary Theory
A. Wolff i in. - Fitness Costs Predict Inbreeding Aversion Irrespective of Self-Involvement: Support for Hypotheses Derived from Evolutionary Theory
H. Zimmer i in. - She Has Her Mother's Laugh : The Story of Heredity


## Tesla’s 3-6-9 and Vortex Math: Is this really the key to the universe?
 - [https://www.youtube.com/watch?v=6ZrO90AI0c8](https://www.youtube.com/watch?v=6ZrO90AI0c8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1_uAIS3r8Vu6JjXWvastJg
 - date published: 2022-02-19 13:54:53+00:00

Tesla’s 3-6-9 and Vortex Math: Is this really the key to the universe?


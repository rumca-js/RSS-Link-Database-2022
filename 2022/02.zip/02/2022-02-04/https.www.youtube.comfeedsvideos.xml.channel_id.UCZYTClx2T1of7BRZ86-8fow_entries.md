# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## 10-Year Cancer Remission Thanks to T Cell Therapy​​ | SciShow News
 - [https://www.youtube.com/watch?v=xsx0Gb5XNlI](https://www.youtube.com/watch?v=xsx0Gb5XNlI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-02-04 00:00:00+00:00

Visit https://brilliant.org/scishow/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.

Some researchers trained the immune systems of leukemia patients to help keep them in remission. And other researchers found that it's possible to help African clawed frogs regrow lost limbs, an ability they normally lose once they hit adulthood.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Dr. Melvin Sanicas, Sam Lutfi, Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Nazara, Ash, Jason A Saslow, Matt Curls, Eric Jensen, GrowingViolet, Jeffrey Mckishen, Christopher R Boucher, Alex Hackman, Piya Shedden, charles george, Tom Mosner, Jeremy Mysliwiec, Adam Brainard, Chris Peters, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.nature.com/articles/s41586-021-04390-6 
https://www.eurekalert.org/news-releases/940952
https://www.science.org/doi/10.1126/sciadv.abj2164 

Images:
https://commons.wikimedia.org/wiki/File:Healthy_Human_T_Cell.jpg
https://www.istockphoto.com/vector/b-cell-and-t-cell-adaptive-immune-system-gm1290711030-386040305
https://www.istockphoto.com/vector/cancer-treatment-and-car-t-cell-therapy-gm1299335217-391993392
https://www.istockphoto.com/photo/cancer-cells-vis-gm1284442686-381578226
https://en.wikipedia.org/wiki/File:CAR-Engineered_T-Cell_Adoptive_Transfer.jpg
https://www.istockphoto.com/vector/t-cell-and-chimeric-antigen-receptor-gm1206082055-347712655
https://www.istockphoto.com/vector/cytokine-storm-or-hypercytokinemia-gm1281435328-379469325
https://www.istockphoto.com/photo/immune-system-gm951668074-259777128
https://www.istockphoto.com/photo/t-cell-attacking-a-cancer-cell-gm862601694-142997663
https://www.istockphoto.com/photo/car-t-cell-immunotherapy-gm1338985407-419427128
https://www.eurekalert.org/multimedia/815169
https://www.shutterstock.com/image-photo/regenerating-tail-northern-dusky-salamander-desmognathus-1553901581
https://commons.wikimedia.org/wiki/File:Krallenfrosch_Xenopus_laevis.jpg
https://commons.wikimedia.org/wiki/File:Xenopus_laevis_1.jpg
https://www.inaturalist.org/observations/104920916
https://www.inaturalist.org/observations/70605658
https://www.istockphoto.com/photo/new-growed-tail-of-green-male-sand-lizard-lacerta-agilis-isolated-on-white-gm1219561138-356779435
https://www.istockphoto.com/photo/supermodel-gm186362649-27999212
https://www.istockphoto.com/vector/antibody-and-antigen-humoral-immunity-gm1297441084-390577392


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Randall Carlson's Take on Atlantis
 - [https://www.youtube.com/watch?v=zdqX09zZNf8](https://www.youtube.com/watch?v=zdqX09zZNf8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-02-05 00:00:00+00:00

Taken from JRE #1772 w/Randall Carlson:
https://open.spotify.com/episode/190slemJsUXH5pEYR6DUbf?si=62a5ab67f632423e

## Joe on Francis Ngannou's Victory Over Ciryl Gane
 - [https://www.youtube.com/watch?v=5Sh5sRz91SU](https://www.youtube.com/watch?v=5Sh5sRz91SU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-02-04 00:00:00+00:00

Taken from JRE #1771 w/Andy Stumpf:
https://open.spotify.com/episode/4rJBoD4BeeYFd8eLhrDRMU?si=7f723409f6314288

## The Chinese App Using Facial Scans on Teenage Gamers
 - [https://www.youtube.com/watch?v=sRST0Ltu4SU](https://www.youtube.com/watch?v=sRST0Ltu4SU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-02-04 00:00:00+00:00

Taken from JRE #1771 w/Andy Stumpf:
https://open.spotify.com/episode/4rJBoD4BeeYFd8eLhrDRMU?si=7f723409f6314288


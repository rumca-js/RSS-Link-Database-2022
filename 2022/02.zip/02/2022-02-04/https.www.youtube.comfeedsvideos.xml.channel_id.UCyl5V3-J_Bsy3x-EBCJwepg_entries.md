# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Babylon Bee Weak-ly News Update 2/4/2022: Getting Ready For Super Bowl LVI and Joe Rogan Was Right
 - [https://www.youtube.com/watch?v=uc0oePGHRb0](https://www.youtube.com/watch?v=uc0oePGHRb0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-04 00:00:00+00:00

Host Adam Yenser gives us the news of the week, including how the city of Los Angeles is getting ready for SuperBowl, people got dangerous correct information from listening to Joe Rogan, and a 40-person brawl broke out at a Golden Corral over a piece of steak!

Watch the full podcast here: https://youtu.be/MDLdRqw8aDA

Follow Adam on Youtube: https://www.youtube.com/user/adamyenser

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## THE BEE WEEKLY: Biden’s First Year and The Viking Heart
 - [https://www.youtube.com/watch?v=MDLdRqw8aDA](https://www.youtube.com/watch?v=MDLdRqw8aDA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-04 00:00:00+00:00

The Babylon Bee remembers the first year of Joe Biden’s Presidency since he might have forgotten it and also talks to historian Arthur Herman about how to be more like the Vikings, but not the football team. The Bee also has an exclusive statement from Justin Trudeau, Weakly News from Adam Yenser, and an inside look to this week at The Babylon Bee.

Check out Arthur Herman’s latest book The Viking Heart: https://www.amazon.com/gp/product/B08B3CWG2Z/ref=dbs_a_def_rwt_hsch_vapi_tkin_p1_i0

This episode is brought to you by Faithful Counseling: http://faithfulcounseling.com/babylonbee

This episode is also brought to you by Enduring Word Bible Commentary: https://enduringword.com

Kyle played board games, Adam went to Montana, and Dan’s roof blew away in a windstorm. A subscriber makes it possible for The Bee to launch our subscriber-exclusive audio yacht. There’s a banger and bomb article of the week, stuff that’s good, and an exclusive statement from Justin Trudeau brought to you only by The Babylon Bee. Adam Yenser brings Weakly News and then The Bee remembers Joe Biden’s first year of being President because it’s possible that he doesn’t quite remember all of it. Then Kyle and Adam talk to historian Arthur Herman about pointy helmets, conquering the world, and the indomitable spirit of the Vikings. Of course, The Bee opens up its hate mail for the week too.

In the subscriber exclusive lounge on the third floor of The Babylon Bee Audio Yacht, subscribers are treated to the Bee’s classic article, subscriber headlines, love mail, bonus hate mail, and the rest of the interview with Arthur Herman!


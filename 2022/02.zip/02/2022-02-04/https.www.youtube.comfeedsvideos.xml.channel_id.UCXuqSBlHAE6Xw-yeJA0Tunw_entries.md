# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Finally Spending My YouTube Money - New House Update
 - [https://www.youtube.com/watch?v=c_Ab2F8UwvQ](https://www.youtube.com/watch?v=c_Ab2F8UwvQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-05 00:00:00+00:00

War Thunder: Join us for FREE and get an exclusive bonus at https://playwt.link/joinltt
PCBWay: Learn about PCBWay's full feature custom PCB services, CNC, 3D Printing and more at https://lmg.gg/PCBWay

Construction has been steadily progressing on my new house tech upgrades, so it’s time to show you all exactly how my ideas are coming to life.

Discuss on the forum: https://linustechtips.com/topic/1409568-finally-spending-my-youtube-money/

Buy Icron USB Raven Fiber Extender
  Icron: https://lmg.gg/GCgFI
  B&H Photo: https://geni.us/laIx6

Buy Multimode Duplex Aqua Fibre Cable
  InfiniteCables: https://lmg.gg/c5dv4
  Amazon: https://geni.us/43Fts8Z
  Newegg: https://geni.us/51DAZ

Buy AOC Active Optical Cable 100ft
  InfiniteCables: https://lmg.gg/Rv9Nb
  Amazon: https://geni.us/E840G9
  Newegg: https://geni.us/eBi3N

Check out the Cel-Fi QUATRA 2000 Signal Booster System: https://lmg.gg/iS1J3

Check out the EV40D Dual EV Charger: https://lmg.gg/R6GgV

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro

## They Almost Got Away With It! - WAN Show February 04, 2022
 - [https://www.youtube.com/watch?v=UfcTm6cfkFQ](https://www.youtube.com/watch?v=UfcTm6cfkFQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-04 00:00:00+00:00

Get your Grid Studio frame today at: https://lmg.gg/gridstudio

Get 30% off list price and 30% off onboarding at http://www.graphus.ai/linus

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Check out the WAN Show & Podcast Gear: https://lmg.gg/podcastgear
Check out the They're Just Movies Podcast: https://lmg.gg/tjmpodcast

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/They-Almost-Got-Away-With-It----WAN-Show-February-04--2022-e1e2m3s

Timestamps: (Courtesy of NoKi1119)
0:00 Chapters
1:32 Intro
2:00 Topic #1 - Gamer Nexus Newegg return issues
2:30 Steam Deck live tease
4:50 Linus planning to run Steam Deck for a month
7:10 Discussing the Newegg return claims, RMA issues
14:02 Possibilities for missed open-box damages
19:44 Does Newegg run a scam? Whose burden is this?
23:40 Gamer Nexus fans boycotting, store monopoly
27:33 Linus's conversation with ASUS on motherboards
29:46 Amazon is not a great technology store
33:06 Other technology companies listed by chat
37:48 Linus reaching out for similar experience
39:42 Topic #2 - Sony acquires Destiny's Bungie for 36B
43:16 Speculations behind reason of purchase
44:48 Sponsor - Grid Studio
46:55 Sponsor - Graphus
47:34 Sponsor - Squarespace
48:36 Topic #3 - Facebook value drops by $232B
50:14 Other stock values & past examples of FB values
51:22 Is Facebook dying? & "The Palace"
54:45 Second Life, VR Chat
57:50 Linus scammed via a bad statement
1:00:00 Merch Message Reply
1:02:34 LTTStore Controller & Computer plushies w/ code
1:04:16 Dropped shares & company value discussion
1:10:44 LMG's cost of hire, issue with being rich
1:15:12 Spending & investments for a rich person
1:19:28 Linus's house mortgage, Vancouver housing prices
1:26:31 "Eat the rich," Linus calls Jake "Geoff"
1:27:42 Merch Messages
1:28:26 Open bench maintenance
1:30:38 RX 580's value in 2022, upgradability discussion
1:32:19 Principles behind designing case air flow
1:34:22 Motorcycles content, 3D printed construction
1:37:10 Newer mainstream CPUs, Linus didn't buy phones
1:42:12 Portable audio players, TrueNAS VS Unraid
1:44:05 Sofa with speaker, Sam Zeloof, blind aid products
1:47:01 LTTStore screwdriver bit loaders, Linus's house update
1:50:26 Warehouse newsletter: USB-_Crap_ signal integrity
1:53:26 Screwdriver material, testing Steam Deck on Windows
1:54:20 LTT lab validating LMG tech products
1:55:26 Motherboard suggestions, LTT mice/keyboards
1:58:42 Software side lab benchmarks, non-terrestrial ISPs
2:01:22 Rack mount PC, list of Linus's house tech cost
2:04:42 Outro


# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Here's how successful the Pixel 6 is (exclusive)!
 - [https://www.youtube.com/watch?v=YYJI_CXaUfw](https://www.youtube.com/watch?v=YYJI_CXaUfw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-02-04 00:00:00+00:00

Sponsored by Curiositystream. Visit https://curiositystream.com/tfc to sign up and get access to Nebula for free with your subscription.

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This week the Google Pixel 6 sales numbers got released and I have some exclusive info, a weird portless laptop was released, and Facebook / Meta crashed together with other advertisers.

Episode 82

This video on Nebula: https://nebula.app/videos/the-friday-checkout-heres-how-successful-the-pixel-6-is-exclusive
Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 
Quiz: https://link.crrowd.com/quiz

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:34 Release highlights
1:13 Pixel 6 exclusive numbers
3:20 Portless laptop (Craob X)
4:48 Facebook's crash


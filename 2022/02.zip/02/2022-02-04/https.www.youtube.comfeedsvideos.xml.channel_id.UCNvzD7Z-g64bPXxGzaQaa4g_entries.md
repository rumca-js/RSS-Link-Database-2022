# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Nintendo SWITCH 2: 10 Things We WANT
 - [https://www.youtube.com/watch?v=2bImxU8aNmw](https://www.youtube.com/watch?v=2bImxU8aNmw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-05 00:00:00+00:00

The new Nintendo Switch might not be coming anytime soon but we sure do have a wishlist.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## GTA6 FINALLY CONFIRMED, THE REAL REASON SONY BOUGHT BUNGIE, & MORE
 - [https://www.youtube.com/watch?v=MPMaaf5T79I](https://www.youtube.com/watch?v=MPMaaf5T79I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-04 00:00:00+00:00

Thank You Epic Desk for sponsoring this video. Click https://epicdesk.shop and to use code GAMERANX for 15% off any stock deskmat.

Jake on twitter: https://bit.ly/3gdkPqD​​​​

Instagram: https://bit.ly/3uUh9Ot


 ~~~~STORIES~~~~


Battlefield needs “more time”
https://twitter.com/battlefieldcomm/status/1489160643945152512?s=21

Rockstar confirms next GTA6 in development
https://twitter.com/RockstarGames/status/1489617718009606150?s=20&t=Zteb8XH3wZdZpchPewDFvA
https://www.rockstargames.com/newswire/article/ak73k92o47ko75/grand-theft-auto-community-update


Bungie and Sony
https://www.theverge.com/2022/2/2/22914016/sony-playstation-live-service-games-launch-march-2026l + https://www.tweaktown.com/news/84367/sony-has-10-billion-left-to-spend-on-acquisitions-through-2023/index.html
https://www.gamesindustry.biz/articles/2022-01-31-sony-buying-bungie-for-usd3-6-billion

(Also discord https://www.playstation.com/en-us/support/subscriptions/link-psn-status-discord/)
PSVR2 https://www.playstation.com/en-us/ps-vr2/


Suicide Squad delayed to 2023
https://gameranx.com/updates/id/286896/article/suicide-squad-kill-the-justice-league-delayed-to-2023/



Yacht Club new game
https://youtu.be/_Fx0aJCRRpE

Dying Light 2
https://youtu.be/oCMxsThDJBc

Bloodborne demake
https://youtu.be/EMUNczGAYfo

Gran Turismo 7
https://youtu.be/JlbMzBnfnzM

Ghostwire Tokyo
https://youtu.be/cG86MAgwmAM



More CD Projekt Red
https://gameranx.com/updates/id/286885/article/cd-projekt-red-to-develop-two-triple-a-titles-in-2022/`


COD tease
https://twitter.com/InfinityWard/status/1489346822208249861?s=20&t=lxrHDp8YoQEUCQWfjEoKdg


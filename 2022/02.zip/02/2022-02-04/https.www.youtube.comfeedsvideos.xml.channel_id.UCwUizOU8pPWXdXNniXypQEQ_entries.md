# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Extremists Against Mandates! What Really Happened
 - [https://www.youtube.com/watch?v=44HJKW2QfEY](https://www.youtube.com/watch?v=44HJKW2QfEY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-02-05 00:00:00+00:00

Grab your Magnesium Breakthrough at https://magnesiumbreakthrough.com/jp
Use Code "AWAKEN" For a Deal

Check Out My Merch Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

Extremists go against the mandates! Radical freedom lovers were trying to destroy our democracy by preserving our constitutional rights to freedom. March against the mandates in Washington DC January 23, 2022 is where it went down. Here’s the full video of what happened.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


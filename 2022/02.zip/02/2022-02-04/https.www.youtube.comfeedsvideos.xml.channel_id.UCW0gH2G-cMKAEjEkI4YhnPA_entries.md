# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Sons of Fëanor: Maedhros | Tolkien Explained
 - [https://www.youtube.com/watch?v=j6OycdMnvuk](https://www.youtube.com/watch?v=j6OycdMnvuk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-02-05 00:00:00+00:00

Maedhros is the eldest of the sons of Fëanor.  With his father and brothers, they would swear a dreadful oath that would lead to great evil.  Maedhros would take part in all three kinslayings of elves against elves, seeing five of his six brothers die in the attempts to retrieve a Silmaril.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Steamey - https://www.deviantart.com/steamey
Kip Rasmussen - https://www.kiprasmussen.com/
CK Goksoy - https://www.artstation.com/ckgoksoy
Ivan Cavini - https://www.instagram.com/ivan_cavini/

Feanoreans - Jenny Dolfen
Oath of Feanor - Jenny Dolfen
Seven Sons - Jenny Dolfen
Alqualonde - Ted Nasmith
It ends in flame - Jenny Dolfen
The Oath of Feanor - Bellabergolts
Maedhros home - YidanYuan
Death of the Trees - Kuliszu
Morgoth came - Jenny Dolfen
Oath of Feanor - Aegeri
The Oath of Feanor - Ted Nasmith
Feanor with Silmaril - Steamey
Taniquetil - Ted Nasmith
Osse and Teleri - Steamey
Swanhaven - Alan Lee
The Grey Swan Ship - Alan Lee
The Kinslaying - Ted Nasmith
Alqualonde - Ted Nasmith
Spirit of Fire - Jenny Dolfen
Bliss of Valinor - Jenny Dolfen
Buring the Ships - Ted Nasmith
Then Maedhros alone stood aside - Catherine Karine Chmiel
Beleriand Map - Lamaarcana
The Battle of the Five Armies - Alan Lee
Feanors last stand - Pete Amachree
Death of Feanor - Jenny Dolfen
Maedhros - Bellabergolts
Luthien Tenuviel - Aegeri
Maedhros and Maglor - Jenny Dolfen
But Morgoth sent the more - Catherine Chmiel
Humiliation - Jenny Dolfen
Captured - Jenny Dolfen
Maedhros beholds the sun - Turner Mohan
Friends - Maedhros and Fingon - Catherine Karine Chmiel
Thangorodrim - Catherine Karine Chmiel
Forgive me my brother - Jenny Dolfen
Helcaraxe - Jenny Dolfen
Himlin - Aegeri
Eithel Sirion - YidanYuan
Fingon - YidanYuan
The Coming of Glaurung - Alan Lee
Battle of Sudden Flame - Alan Lee
Deeds of Surpassing Valour - Jenny Dolfen
Maglor slew Uldor - Jenny Dolfen
Beren Recovers a Silmaril - Anke Eissmann
Noldor - Bellabergolts
Maedhros - Bellabergolts
Turin - Catherine Karine Chmiel
Battle of Unnumbered Tears - Alan Lee
Dagor Nirnaeth Arnoediad - John Howe
Tears Unnumbered - Jenny Dolfen
Fall of Gondolin - Ralph Damiani
Death of the Lord of Nogrod - Steamey
Luthien at Tol Galen - Ted Nasmith
Despair and Determination - Jenny Dolfen
Descendants of Thingol - Jenny Dolfen
Maedhros searches for the sons of Dior - Jenny Dolfen
Elwing receives the survivors of Gondolin - Alan Lee
The Sea - Ted Nasmith
And Maglor took pity upon them - Catherine Karina Chmiel
As little might be thought - Jenny Dolfen
Earendil and Elwing - Aegeri
The Shores of Valinor - Ted Nasmith
Vingilot - Aegeri
Surely that is a Silmaril - Alan Lee
Maedhros and Maglor See the Silmaril Rise - Kip Rasmussen
Gil-Estel the Star of High Hope - Lida Holubova
There will be blood - Jenny Dolfen
Maedhros and Caranthir - Catherine Karina Chmiel
Earendil Searches Tirion - Ted Nasmith
Battle - Anke Eissmann
Tulkas Chaining Morgoth - Kip Rasmussen
Ossiriand - Jenny Dolfen
Maedhros the Tall - Jenny Dolfen
Maglor - Jenny Dolfen
They Prepared to Die - Jenny Dolfen
Maedhros and Maglor prepared to defend themselves - Catherine Karina Chmiel
Maglor - Aegeri
Maedhros - Aegeri
Maedhros - Yidan Yuan
Maedhros casts himself into a chasm - Ted Nasmith
The Halls of Mandos - Ralph Damiani
The Sundering - Ralph Damiani

For more on the life of Maedhros check out: 
The Silmarillion by JRR Tolkien
Tolkien Gateway
The Encyclopedia of Arda

All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

#maedhros #silmarillion #tolkien

## Rings of Power Poster Reveal BREAKDOWN | The Lord of the Rings on Prime
 - [https://www.youtube.com/watch?v=5xRDhjlAKiE](https://www.youtube.com/watch?v=5xRDhjlAKiE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-02-04 00:00:00+00:00

After a day that saw 23 character posters released for The Lord of the Rings: The Rings of Power, I'm breaking down each one with some observations, theories, and even some dwarven and elvish translations.  Some posters give us massive clues about the show and while some are incredibly vague, others have almost certainly confirmed which characters are pictured!

Special thanks to my friends who translated the languages!
Elvish: Tolkien Guide - tolkienguide.com
Dwarvish: The Dwarrow Scholar - dwarrowscholar.com

Shoutout to Fellowship of Fans for the Isildur poster scoop!  Check them out:  @Fellowship of Fans  

#lotrrop #ringsofpower #lordoftherings


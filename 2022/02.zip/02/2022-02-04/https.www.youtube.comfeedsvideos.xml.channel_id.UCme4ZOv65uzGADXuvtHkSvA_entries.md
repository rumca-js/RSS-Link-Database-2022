# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## 2 Księga Samuela || Rozdział 17
 - [https://www.youtube.com/watch?v=mMsmPKKs6d8](https://www.youtube.com/watch?v=mMsmPKKs6d8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-05 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## CNN [#273] Całkowicie zaufaj Jezusowi
 - [https://www.youtube.com/watch?v=eWRMzVFUFQw](https://www.youtube.com/watch?v=eWRMzVFUFQw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-05 00:00:00+00:00

#cnn #dobrewiadomości   @Langustanapalmie 

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

Niedziela, V Tydzień zwykły, Rok C, II
Piąta Niedziela zwykła

1. czytanie (Iz 6, 1-2a. 3-8)

W roku śmierci króla Ozjasza ujrzałem Pana zasiadającego na wysokim i wyniosłym tronie, a tren Jego szaty wypełniał świątynię. Serafiny stały ponad Nim; każdy z nich miał po sześć skrzydeł.
I wołał jeden do drugiego: «Święty, Święty, Święty jest Pan Zastępów. Cała ziemia pełna jest Jego chwały». Od głosu tego, który wołał, zadrgały futryny drzwi, a świątynia napełniła się dymem.
I powiedziałem: «Biada mi! Jestem zgubiony! Wszak jestem mężem o nieczystych wargach i mieszkam pośród ludu o nieczystych wargach, a oczy moje oglądały Króla, Pana Zastępów!»
Wówczas przyleciał do mnie jeden z serafinów, trzymając w ręce węgiel, który szczypcami wziął z ołtarza. Dotknął nim ust moich i rzekł: «Oto dotknęło to twoich warg, twoja wina jest zmazana, zgładzony twój grzech».
I usłyszałem głos Pana mówiącego: «Kogo mam posłać? Kto by Nam poszedł?» Odpowiedziałem: «Oto ja, poślij mnie!»

2. czytanie (1 Kor 15, 1-11)

Przypominam, bracia, Ewangelię, którą wam głosiłem, którą przyjęliście i w której też trwacie. Przez nią również będziecie zbawieni, jeżeli ją zachowacie tak, jak wam głosiłem. Bo inaczej na próżno byście uwierzyli.
Przekazałem wam na początku to, co przejąłem: że Chrystus umarł – zgodnie z Pismem – za nasze grzechy, że został pogrzebany, że zmartwychwstał trzeciego dnia, zgodnie z Pismem; i że ukazał się Kefasowi, a potem Dwunastu, później zjawił się więcej niż pięciuset braciom równocześnie; większość z nich żyje dotąd, niektórzy zaś pomarli. Potem ukazał się Jakubowi, później wszystkim apostołom. W końcu, już po wszystkich, ukazał się także i mnie jako poronionemu płodowi.
Jestem bowiem najmniejszy ze wszystkich apostołów i niegodzien zwać się apostołem, bo prześladowałem Kościół Boży. Lecz za łaską Boga jestem tym, czym jestem, a dana mi łaska Jego nie okazała się daremna; przeciwnie, pracowałem więcej od nich wszystkich, nie ja, co prawda, lecz łaska Boża ze mną.
Tak więc czy to ja, czy inni, tak nauczamy i tak uwierzyliście.

Ewangelia (Łk 5, 1-11)

Pewnego razu – gdy tłum cisnął się do Jezusa, aby słuchać słowa Bożego, a On stał nad jeziorem Genezaret – zobaczył dwie łodzie stojące przy brzegu; rybacy zaś wyszli z nich i płukali sieci. Wszedłszy do jednej łodzi, która należała do Szymona, poprosił go, żeby nieco odbił od brzegu. Potem usiadł i z łodzi nauczał tłumy.
Gdy przestał mówić, rzekł do Szymona: «Wypłyń na głębię i zarzućcie sieci na połów!» A Szymon odpowiedział: «Mistrzu, całą noc pracowaliśmy i nic nie ułowiliśmy. Lecz na Twoje słowo zarzucę sieci». Skoro to uczynili, zagarnęli tak wielkie mnóstwo ryb, że sieci ich zaczynały się rwać. Skinęli więc na współtowarzyszy w drugiej łodzi, żeby im przyszli z pomocą. Ci podpłynęli; i napełnili obie łodzie, tak że się prawie zanurzały.
Widząc to, Szymon Piotr przypadł Jezusowi do kolan i rzekł: «Wyjdź ode mnie, Panie, bo jestem człowiekiem grzesznym». I jego bowiem, i wszystkich jego towarzyszy w zdumienie wprawił połów ryb, jakiego dokonali; jak również Jakuba i Jana, synów Zebedeusza, którzy byli wspólnikami Szymona.
A Jezus rzekł do Szymona: «Nie bój się, odtąd ludzi będziesz łowił». I wciągnąwszy łodzie na ląd, zostawili wszystko i poszli za Nim.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

Niedzielnik na ROK C
→ https://wdrodze.pl/produkt/niedzielnik-c-komentarze-do-czytan-adam-szustak/

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: The Last of Us 2 [18] Serce w klatce
 - [https://www.youtube.com/watch?v=hwGLEjVCIzA](https://www.youtube.com/watch?v=hwGLEjVCIzA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-05 00:00:00+00:00

​    @Langustanapalmie      #ksiądzgrawgrę #TheLastofUs2 ________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1011] Milion
 - [https://www.youtube.com/watch?v=XLkXquK3_pI](https://www.youtube.com/watch?v=XLkXquK3_pI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-05 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## 2 Księga Samuela || Rozdział 16
 - [https://www.youtube.com/watch?v=LLFnY8dys_8](https://www.youtube.com/watch?v=LLFnY8dys_8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-04 00:00:00+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Ksiądz gra w grę: The Last of Us 2 [17] Po drugiej stronie też jest człowiek
 - [https://www.youtube.com/watch?v=GTr0ZmITs9g](https://www.youtube.com/watch?v=GTr0ZmITs9g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-04 00:00:00+00:00

​     @Langustanapalmie      #ksiądzgrawgrę #TheLastofUs2 ________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.

## Wstawaki [#1010] Utwierdza
 - [https://www.youtube.com/watch?v=pkhSnsnlP_Q](https://www.youtube.com/watch?v=pkhSnsnlP_Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2022-02-04 00:00:00+00:00

Wstawaj, żyj i kochaj, czyli poranna dawka energii na cały dzień i nie tylko. 

"Wstawaki 2.0" muz: Jan Smoczyński || Agnieszka Musiał
#Wstawaki #zróbmydobrydzień #AdamSzustakOP
________________________________________
Książkę znajdziecie tu ♡
→ https://langustanapalmie.pl/produkt/jaksiemodlic/
 
Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Podcasts → https://bit.ly/2OlBWH

♡  Pismo Święte: 
Anchor → https://anchor.fm/langusta-na-palmie
Spreaker → https://www.spreaker.com/show/przeczytaj-pismo-swiete-z-langusta
Spotify →  https://spoti.fi/34nZwLr
Apple →  https://apple.co/33zdwCV
Google Podcasts → https://bit.ly/3nmaZUc

Strona z kalendarzem o. Adama: 
→ http://www.langustanapalmie.pl
Można nas również znaleźć na Facebooku: 
→ https://www.facebook.com/LangustaNaPalmie
Twitterze: 
→ https://twitter.com/LangustaPalmowa
Instagramie: 
→ https://www.instagram.com/langustanapalmie/

Zapraszamy.


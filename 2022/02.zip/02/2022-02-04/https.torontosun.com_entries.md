## GoFundMe pulls plug on fundraiser for Ottawa convoy protesters | Toronto Sun
 - [https://torontosun.com/news/national/gofundme-pulls-plug-on-fundraiser-for-ottawa-convoy-protesters](https://torontosun.com/news/national/gofundme-pulls-plug-on-fundraiser-for-ottawa-convoy-protesters)
 - RSS feed: https://torontosun.com
 - date published: 2022-02-04 20:49:21+00:00

GoFundMe pulls plug on fundraiser for Ottawa convoy protesters | Toronto Sun


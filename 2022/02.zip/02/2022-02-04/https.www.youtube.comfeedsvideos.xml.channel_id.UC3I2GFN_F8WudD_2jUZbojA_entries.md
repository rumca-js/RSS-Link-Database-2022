# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Squid - Boy Racers & Narrator (Live on KEXP)
 - [https://www.youtube.com/watch?v=fM0CsCZG_N0](https://www.youtube.com/watch?v=fM0CsCZG_N0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-04 00:00:00+00:00

http://KEXP.ORG presents Squid performing “Boy Racers" and "Narrator” live in the KEXP studio. Recorded November 23, 2021.

Anton Pearson - Guitar, vocals, bass
Oliver Judge - Drums, vocals
Arthur Leadbetter - Synths, percussion
Louis Borlase - Guitar, vocals, synth, percussion, bass
Laurie Nankivell - Bass, brass, percussion, drum machine

Host: Cheryl Waters
Audio Engineers: Jake Lewis & Kevin Suggs
Audio Mixer: Max Goulding
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

https://squidband.uk
http://kexp.org

## Squid - Documentary Filmmaker & Pamphlets (Live on KEXP)
 - [https://www.youtube.com/watch?v=Nc3LoqiNfBU](https://www.youtube.com/watch?v=Nc3LoqiNfBU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-04 00:00:00+00:00

http://KEXP.ORG presents Squid performing “Documentary Filmmaker" and "Pamphlets” live in the KEXP studio. Recorded November 23, 2021.

Anton Pearson - Guitar, vocals, bass
Oliver Judge - Drums, vocals
Arthur Leadbetter - Synths, percussion
Louis Borlase - Guitar, vocals, synth, percussion, bass
Laurie Nankivell - Bass, brass, percussion, drum machine

Host: Cheryl Waters
Audio Engineers: Jake Lewis & Kevin Suggs
Audio Mixer: Max Goulding
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

https://squidband.uk
http://kexp.org

## Squid - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=g-JWNggMB58](https://www.youtube.com/watch?v=g-JWNggMB58)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-04 00:00:00+00:00

http://KEXP.ORG presents Squid performing live in the KEXP studio. Recorded November 23, 2021.

Songs:
0:31 - Boy Racers
11:27 - Narrator
21:11 - Documentary Filmmaker
27:18 - Pamphlets

Anton Pearson - Guitar, vocals, bass
Oliver Judge - Drums, vocals
Arthur Leadbetter - Synths, percussion
Louis Borlase - Guitar, vocals, synth, percussion, bass
Laurie Nankivell - Bass, brass, percussion, drum machine

Host: Cheryl Waters
Audio Engineers: Jake Lewis & Kevin Suggs
Audio Mixer: Max Goulding
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Alaia D'Alessandro, Scott Holpainen & Kendall Rock
Editor: Jim Beckmann

https://squidband.uk
https://brightgreenfield.squidband.uk/tour
http://kexp.org


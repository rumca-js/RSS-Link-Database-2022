# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Suicide Squad Kill the Justice League: everything we know so far
 - [https://www.techradar.com/news/suicide-squad-game/](https://www.techradar.com/news/suicide-squad-game/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-04 17:40:10+00:00

Suicide Squad: Kill the Justice League, is an upcoming multiplayer action game. Play as one of Task Force X and take down the Justice League. Here's what we know so far.

## Suicide Squad Kill the Justice League: everything we know so far
 - [https://www.techradar.com/news/suicide-squad-game](https://www.techradar.com/news/suicide-squad-game)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-04 17:40:10+00:00

Suicide Squad: Kill the Justice League, is an upcoming multiplayer action game. Here's what we know so far.

## Invincible season 2: everything we know so far
 - [https://www.techradar.com/news/invincible-season-2](https://www.techradar.com/news/invincible-season-2)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-02-04 15:34:36+00:00

Here's what we know about Invincible season 2 ahead of its release on Prime Video.


# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Yola - three songs at The Current (2020)
 - [https://www.youtube.com/watch?v=Lieq8S5hrN4](https://www.youtube.com/watch?v=Lieq8S5hrN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-04 00:00:00+00:00

Singer-songwriter Yola continues to take the music world by storm. The Nashville-by-way-of-Bristol, England artist has already won two U.K. Americana Music Association Awards in 2022 — for U.K. Album of the Year (for "Stand for Myself") and U.K. Artist of the Year — marking her fourth and fifth U.K. Americana Music Association Awards overall, respectively. Yola is also nominated for two Grammy Awards for Best Americana Album and Best American Roots Song ("Diamond Studded Shoes"). Back in January 2020, Yola visited The Current studio to play songs from her 2019 album, "Walk Through Fire." Watch those performances above. 

SONGS PERFORMED
0:00 "Ride Out In The Country"
3:10 "Walk Through Fire"
6:46 "Shady Grove"

PERSONNEL
Yola – guitar and vocals
Jerry Bernhardt – guitar 

CREDITS
Video & Photo: Nate Ryan
Audio: Michael DeMark and Tessa Bloch
Production: Derrick Stevens

FIND MORE:
2019 set at The Current's Day Party during SXSW: https://www.thecurrent.org/feature/2019/03/16/watch-yola-perform-at-the-current-day-party-in-austin-texas-sxsw
2020 studio session: https://www.thecurrent.org/feature/2020/01/19/yola-performs-songs-from-walk-through-fire-in-the-current-studio
2021 virtual session:
https://www.thecurrent.org/feature/2021/07/15/yola-plays-songs-from-standing-for-myself-talks-about-upcoming-role-as-sister-rosetta-tha
2021 August 7 Album of the Week, "Stand For Myself"
https://www.thecurrent.org/feature/2021/08/07/album-of-the-week-yola-stand-for-myself

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#yola #iamyola #yolamusic


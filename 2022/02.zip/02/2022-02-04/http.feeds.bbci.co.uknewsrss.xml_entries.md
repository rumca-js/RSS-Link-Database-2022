# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Trump was wrong to seek to overturn Biden win, says Mike Pence
 - [https://www.bbc.co.uk/news/world-us-canada-60266121?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60266121?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 22:43:36+00:00

Mike Pence issues his strongest rebuttal of Donald Trump's claim over the 2021 election result.

## Why champions Wales are Six Nations underdogs once more
 - [https://www.bbc.co.uk/sport/rugby-union/60243935?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/60243935?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 22:02:23+00:00

Defending champions they may be, but Wales are underdogs again as the 2022 Six Nations begins.

## Grand Theft Auto 6: Rockstar announces it is working on the game
 - [https://www.bbc.co.uk/news/entertainment-arts-60266275?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60266275?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 18:16:17+00:00

The studio said development of the next entry in the Grand Theft Auto series is "well under way."

## Combat drones: We are in a new era of warfare - here's why
 - [https://www.bbc.co.uk/news/world-60047328?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60047328?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 18:03:39+00:00

No longer the preserve of superpowers, drones are now in the hands of insurgents and smaller countries.

## Don Broco: How they topped this week's chart with last year's album
 - [https://www.bbc.co.uk/news/newsbeat-60261266?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-60261266?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 17:28:23+00:00

It's taken Don Broco until 2022 to release physical versions of their album - and the wait paid off.

## Why do energy prices have to go up? And other questions
 - [https://www.bbc.co.uk/news/business-60258670?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60258670?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 15:23:02+00:00

BBC correspondent Kevin Peachey answers your questions on the rise in energy prices.

## Brexit: Sea border checks order suspended by High Court
 - [https://www.bbc.co.uk/news/uk-northern-ireland-60259351?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-60259351?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 12:54:22+00:00

Inspections on goods entering NI from GB must continue pending the outcome of legal challenges.

## China joins Russia in opposing Nato expansion
 - [https://www.bbc.co.uk/news/world-asia-60257080?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-60257080?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 12:48:39+00:00

Moscow and Beijing release a statement showcasing agreement on a wide range of geopolitical issues.

## Brexit: The NI Protocol and its economic impact
 - [https://www.bbc.co.uk/news/uk-northern-ireland-60259342?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-60259342?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 12:44:14+00:00

What is the truth around the figures quoted about the NI Protocol - are there costs or opportunities?

## Silverwood was under 'impossible strain', Thorpe leaves & Root to remain skipper
 - [https://www.bbc.co.uk/sport/cricket/60260548?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/60260548?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 12:29:03+00:00

Chris Silverwood was placed under an "impossible strain" to combine roles as England head coach and lead selector, according to Sir Andrew Strauss.

## Six Nations: Wales-Ireland kit clash frustrates colour-blind fans
 - [https://www.bbc.co.uk/news/uk-wales-60229589?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60229589?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 12:26:26+00:00

The decision to wear traditional red and green jerseys will cause problems for colour-blind people.

## Backlash after Bank boss says don't ask for big pay rise
 - [https://www.bbc.co.uk/news/business-60252340?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60252340?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 12:19:31+00:00

Unions criticise Andrew Bailey after he urges firms to moderate pay rises, with GMB calling it a "sick joke".

## Boris Johnson rocked by wave of No 10 resignations
 - [https://www.bbc.co.uk/news/uk-politics-60253231?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60253231?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 12:18:19+00:00

The PM seeks to rally remaining No 10 staff, telling them "change is good", after a fifth adviser quits.

## Logan Mwangi: Mother denies murdering five-year-old son
 - [https://www.bbc.co.uk/news/uk-wales-60259208?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60259208?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 12:12:16+00:00

Angharad Williamson pleads not guilty to the murder of her son Logan Mwangi at a pre-trial hearing.

## Southend West by-election: Anna Firth wins seat for Tories
 - [https://www.bbc.co.uk/news/uk-england-essex-60254176?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-60254176?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 12:10:51+00:00

The election in Southend West was prompted by the fatal stabbing of MP Sir David Amess.

## Children's mental health: Huge rise in severe cases, BBC analysis reveals
 - [https://www.bbc.co.uk/news/education-60197150?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-60197150?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 11:39:12+00:00

As referrals rise for self-harm and eating disorders rise by 77%, schools see a wave of other less severe issues.

## Carlisle modern slavery boss given suspended sentence
 - [https://www.bbc.co.uk/news/uk-england-cumbria-60256915?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cumbria-60256915?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 11:34:33+00:00

Peter Swailes admitted the slavery charge after a disabled man was exploited for decades.

## Energy price rise includes £68 for failed firms, says Ofgem
 - [https://www.bbc.co.uk/news/business-60257448?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60257448?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 11:16:52+00:00

Regulator Ofgem says about 10% of the latest energy price cap rise covered the cost of firms going bust.

## 'We'd be crazy not to be' - Klopp says Liverpool still keen on Fulham's Carvalho
 - [https://www.bbc.co.uk/sport/football/60256930?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60256930?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 11:04:16+00:00

Jurgen Klopp says Liverpool would "be crazy" if they were not still interested in Fulham's Fabio Carvalho after failing to seal a deadline-day deal.

## Munira Mirza: The student radical who became 'Boris's brain'
 - [https://www.bbc.co.uk/news/uk-politics-60257702?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60257702?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 10:48:13+00:00

Ex-communist Munira Mirza has been one of Boris Johnson's closest advisers for more than a decade.

## Boris Johnson makes incorrect claim on jobs
 - [https://www.bbc.co.uk/news/60245483?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/60245483?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 10:44:35+00:00

The prime minister has made a claim about employment that the statistics regulator had told No10 was incorrect.

## Beijing Winter Olympics boycott: Why are the Games so controversial?
 - [https://www.bbc.co.uk/news/explainers-59644043?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/explainers-59644043?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 10:32:42+00:00

Winter Olympics host China is being criticised over its human rights record.

## Winter Olympics: All you need to know about Beijing 2022
 - [https://www.bbc.co.uk/sport/winter-olympics/60199574?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-olympics/60199574?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 09:26:48+00:00

BBC Sport tells you all you need to know about the Beijing 2022 Winter Olympics.

## Billionaire Bezos' superyacht sparks bridge row
 - [https://www.bbc.co.uk/news/world-europe-60256966?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60256966?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 09:24:40+00:00

Rotterdam's Koningshaven Bridge may be dismantled to allow the ship to leave a shipyard.

## GB curling pair resist Australia fightback to maintain semi-final hopes
 - [https://www.bbc.co.uk/sport/winter-olympics/60256132?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-olympics/60256132?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 07:53:26+00:00

Great Britain's mixed doubles curlers Jen Dodds and Bruce Mouat survive an Australia fightback to maintain their semi-final hopes.

## Claressa Shields on fighting in the UK and Savannah Marshall possibility
 - [https://www.bbc.co.uk/sport/boxing/60218833?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/60218833?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 07:03:59+00:00

Unified middleweight champion Claressa Shields looks ahead to her UK debut in Cardiff this Saturday and a potential undisputed clash with "hater" Savannah Marshall later this summer.

## Deaf people diagnosed with cancer face 'big barriers'
 - [https://www.bbc.co.uk/news/uk-scotland-60231182?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-60231182?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 06:04:07+00:00

One patient who has been deaf since birth explains how she was left confused over her diagnosis and treatment.

## The Papers: 'Meltdown' in No 10 and living standards crisis
 - [https://www.bbc.co.uk/news/blogs-the-papers-60254207?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60254207?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 05:03:53+00:00

The resignation of key aides to the PM and the spiking cost of living dominate Friday's papers.

## From polite schoolboy to Wales' main man - Biggar's rise to the top
 - [https://www.bbc.co.uk/sport/rugby-union/60052944?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/60052944?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 04:58:19+00:00

BBC Sport Wales charts the journey of Dan Biggar, who will become the 140th man to captain Wales when they face Ireland in the Six Nations on Saturday.

## Game of Thrones studio opens door to Westeros, in Northern Ireland
 - [https://www.bbc.co.uk/news/entertainment-arts-60243681?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60243681?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 01:56:34+00:00

A major new attraction launches at one of the hit TV show's filming locations in Northern Ireland.

## Platinum Jubilee: Stamps issued to celebrate Queen's 70-year reign
 - [https://www.bbc.co.uk/news/uk-60254702?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60254702?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 01:52:12+00:00

Royal Mail issues eight stamps celebrating her 70-year reign, with photos ranging from 1957 to 2020.

## Libmeldy: World's 'most expensive' drug recommended for NHS use
 - [https://www.bbc.co.uk/news/health-60245738?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60245738?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 01:39:36+00:00

The gene therapy Libmeldy treats babies and children with a very rare genetic condition.

## Climate change: Satellites map huge methane plumes from oil and gas
 - [https://www.bbc.co.uk/news/science-environment-60203683?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-60203683?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 00:45:37+00:00

Plugging methane leaks from oil and gas fields could be an easy win in curbing climate change.

## Winter Olympics 2022: Team GB's Dave Ryding aims for more success in Beijing
 - [https://www.bbc.co.uk/sport/av/winter-olympics/60250094?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/winter-olympics/60250094?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 00:24:19+00:00

Team GB slalom skier Dave Ryding is aiming for more success in Beijing, following his World Cup win.

## From bike lanes to lost pets - how the Nextdoor network works
 - [https://www.bbc.co.uk/news/technology-60246962?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60246962?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 00:21:33+00:00

Chief executive Sarah Friar explains how the pandemic has affected the ultra-local social channel.

## Koo: India's Twitter alternative with global ambitions
 - [https://www.bbc.co.uk/news/world-asia-india-60194920?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-60194920?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 00:20:03+00:00

India's Koo expects to surpass Twitter's 25 million-strong user base in the country.

## Afghanistan women: 'I felt anxious going back to university'
 - [https://www.bbc.co.uk/news/world-asia-60236826?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-60236826?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 00:17:13+00:00

Some female students went back to campus for the first time since the Taliban takeover. How did it feel?

## How to store excess wind power underwater
 - [https://www.bbc.co.uk/news/business-60066690?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60066690?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 00:11:36+00:00

A Dutch company is testing an underwater system that can store excess energy from wind farms.

## Impossible search for the greatest shipwreck
 - [https://www.bbc.co.uk/news/science-environment-60239105?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-60239105?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 00:11:14+00:00

The latest bid to find Antarctic explorer Ernest Shackleton's lost polar yacht is set to get under way.

## Cost of living: 'We'll cut back on things that make memories'
 - [https://www.bbc.co.uk/news/business-60250347?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60250347?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 00:08:57+00:00

Suzanne Samaka and her partner work full time but will struggle to cover rising energy bills.

## Africa's week in pictures: 28 January-3 February 2022
 - [https://www.bbc.co.uk/news/world-africa-60243953?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-60243953?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-04 00:02:27+00:00

A selection of the best photos from across the African continent this week.


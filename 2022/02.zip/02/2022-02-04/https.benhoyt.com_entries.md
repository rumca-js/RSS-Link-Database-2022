## Optimizing GoAWK with a bytecode compiler and virtual machine
 - [https://benhoyt.com/writings/goawk-compiler-vm/](https://benhoyt.com/writings/goawk-compiler-vm/)
 - RSS feed: https://benhoyt.com
 - date published: 2022-02-04 22:43:35+00:00

How I sped up GoAWK by switching from a tree-walking interpreter to a bytecode compiler and virtual machine interpreter.


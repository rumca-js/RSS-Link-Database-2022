# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## Become Anonymous & Untraceable | How To Securely Install & Use Tails | Tor Tutorial
 - [https://www.youtube.com/watch?v=XwJpf5kICeg](https://www.youtube.com/watch?v=XwJpf5kICeg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2022-02-18 00:00:00+00:00

Tails - The Amnesic Incognito Live System, is the most anonymous operating system in the world. Edward Snowden used to leak the NSA documents. Here's how you can get it too.
Support me through Patreon: https://www.patreon.com/thehatedone 
- or donate anonymously:
Monero:
84DYxU8rPzQ88SxQqBF6VBNfPU9c5sjDXfTC1wXkgzWJfVMQ9zjAULL6rd11ASRGpxD1w6jQrMtqAGkkqiid5ef7QDroTPp

Bitcoin: 
1FuKzwa5LWR2xn49HqEPzS4PhTMxiRq689

Ethereum:
0x6aD936198f8758279C2C153f84C379a35865FE0F

Online anonymity sometimes demands much more than just obfuscating your location and IP address. Some threat models require that you leave no trace of your activity on the device you are using. The problem is that regular operating systems are designed to store troves of sensitive data in the hardware of your machine. Even with full-device encryption, memory logs can often be easily recovered by an adversary with physical access to your device. Not everyone has the luxury of physical security and they have to assume that their computer will likely fall into the wrong hands.  

This is why security experts with a strong sense for protecting human rights in the digital world have been working on creating a system that doesn’t remember anything about itself. A system that forensically wipes all evidence of its use immediately after a user ends their session. A system that looks exactly the same no matter who uses it or for whatever purpose. And now such a system has a name. Tails. The Amnesic Incognito Live System.

Live system, because it’s an operating system designed to run off of a USB flash drive, instead of being permanently installed on an internal drive. Incognito, because its entire traffic is routed through Tor and   the default fingerprint of each Tails installation matches perfectly with every other Tails users on the planet. Amnesic means every time you reboot, plug out your USB, or shut down, all information about your session activity is wiped from the USB flash drive as well as from the host memory. This forensic erasure leaves no files on the host system whatsoever. 

Sources
The Official Tails Website: https://tails.boum.org/
Linux Installation (followed in this video): https://tails.boum.org/install/linux/usb-overview/index.en.html
Linux Installation (command line): https://tails.boum.org/install/expert/usb/index.en.html
Official Tails Documentation: https://tails.boum.org/doc/index.en.html
How Snowden Used Tails: https://www.wired.com/2014/04/tails/ 

Credits
Music By Cuki Beats https://www.youtube.com/channel/UCSyBSyLk4ZvXd2Fj-tLojag

Follow me:
https://twitter.com/The_HatedOne_
https://www.bitchute.com/TheHatedOne/
https://www.reddit.com/r/thehatedone/
https://www.minds.com/The_HatedOne

The footage and images featured in the video were for critical analysis, commentary and parody, which are protected under the Fair Use laws of the United States Copyright act of 1976.


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joey Diaz on Action Park
 - [https://www.youtube.com/watch?v=cNT5gcjAE_Y](https://www.youtube.com/watch?v=cNT5gcjAE_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-02-17 00:00:00+00:00

Taken from JRE #1778 w/Joey Diaz:
https://open.spotify.com/episode/4Jmgdgp8C1zVKoILlmUYD7?si=8478911c5e4b4b22

## The NYPD's Secret Surveillance Fund
 - [https://www.youtube.com/watch?v=IiXmNDYE6lo](https://www.youtube.com/watch?v=IiXmNDYE6lo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-02-17 00:00:00+00:00

Taken from JRE #1778 w/Joey Diaz:
https://open.spotify.com/episode/4Jmgdgp8C1zVKoILlmUYD7?si=8478911c5e4b4b22


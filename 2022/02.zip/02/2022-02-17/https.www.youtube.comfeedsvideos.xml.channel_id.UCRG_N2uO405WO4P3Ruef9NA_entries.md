# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## We will all be running Windroid soon...
 - [https://www.youtube.com/watch?v=Om__pY_ORTQ](https://www.youtube.com/watch?v=Om__pY_ORTQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-02-18 00:00:00+00:00

Visit https://brilliant.org/TFC/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription - Sponsored by Brilliant.

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This week Google announced ways to emulate Windows on Android, streaming Android apps to Windows, ChromeOS Flex, the successor of CloudReady, and also Privacy Sandbox for Android, dropping the Advertising ID in the future.

Episode 84

This video on Nebula: https://nebula.app/videos/the-friday-checkout-we-will-all-be-running-windroid-soon
Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 
Quiz: https://link.crrowd.com/quiz

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:39 Release highlights
1:48 Android x Windows updates
3:24 ChromeOS Flex
4:40 Android - Privacy Sandbox


## Avoid the Apple App Store | Jonatan Heyman | heyman.info
 - [https://heyman.info/2022/feb/17/avoid-the-apple-app-store/](https://heyman.info/2022/feb/17/avoid-the-apple-app-store/)
 - RSS feed: https://heyman.info
 - date published: 2022-02-17 18:31:55.461656+00:00




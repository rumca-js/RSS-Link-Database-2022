# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Right to working eyeballs brought to you by Right to Repair
 - [https://www.youtube.com/watch?v=gr8XU27yq28](https://www.youtube.com/watch?v=gr8XU27yq28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-18 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://spectrum.ieee.org/bionic-eye-obsolete

https://www.youtube.com/watch?v=JV1Z0tMlZMg

00:00 Rambling bullshit
01:40 Actual start of the video

## WHAT'S IN IT FOR YOU?
 - [https://www.youtube.com/watch?v=qW4oE4gHAko](https://www.youtube.com/watch?v=qW4oE4gHAko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-18 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.bloomberg.com/news/articles/2022-02-16/nyc-mayor-tells-ceos-to-end-work-from-home-policies

## management vs board repair vs owner
 - [https://www.youtube.com/watch?v=Mxdr1x6cWCA](https://www.youtube.com/watch?v=Mxdr1x6cWCA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-18 00:00:00+00:00

https://tinyurl.com/rossmatrix


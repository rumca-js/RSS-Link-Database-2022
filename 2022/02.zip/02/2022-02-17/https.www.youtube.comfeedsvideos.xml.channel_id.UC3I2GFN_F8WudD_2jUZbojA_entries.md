# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Ty Segall & Freedom Band - Erased (Live on KEXP)
 - [https://www.youtube.com/watch?v=hezGB1xsuyc](https://www.youtube.com/watch?v=hezGB1xsuyc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-18 00:00:00+00:00

http://KEXP.ORG presents Ty Segall & Freedom Band performing “Erased” live in the KEXP studio. Recorded February 5, 2022.

Ty Segall - Vocals / Guitar
Emmett Kelly - Guitar
Mikal Cronin - Bass
Ben Boye - Keys
Charles Moothart - Drums

Host: Morgan
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://ty-segall.com
http://kexp.org

## Ty Segall & Freedom Band - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Jnix5PwZy2s](https://www.youtube.com/watch?v=Jnix5PwZy2s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-18 00:00:00+00:00

http://KEXP.ORG presents Ty Segall & Freedom Band performing live in the KEXP studio. Recorded February 5, 2022.

Songs:
Whisper
Erased
Harmonizer
Waxman

Ty Segall - Vocals / Guitar
Emmett Kelly - Guitar
Mikal Cronin - Bass
Ben Boye - Keys
Charles Moothart - Drums

Host: Morgan
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://ty-segall.com
http://kexp.org

## Ty Segall & Freedom Band - Harmonizer (Live on KEXP)
 - [https://www.youtube.com/watch?v=q7AyzfOkgj8](https://www.youtube.com/watch?v=q7AyzfOkgj8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-18 00:00:00+00:00

http://KEXP.ORG presents Ty Segall & Freedom Band performing “Harmonizer” live in the KEXP studio. Recorded February 5, 2022.

Ty Segall - Vocals / Guitar
Emmett Kelly - Guitar
Mikal Cronin - Bass
Ben Boye - Keys
Charles Moothart - Drums

Host: Morgan
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://ty-segall.com
http://kexp.org

## Ty Segall & Freedom Band - Waxman (Live on KEXP)
 - [https://www.youtube.com/watch?v=21HVihTLI5w](https://www.youtube.com/watch?v=21HVihTLI5w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-18 00:00:00+00:00

http://KEXP.ORG presents Ty Segall & Freedom Band performing “Waxman” live in the KEXP studio. Recorded February 5, 2022.

Ty Segall - Vocals / Guitar
Emmett Kelly - Guitar
Mikal Cronin - Bass
Ben Boye - Keys
Charles Moothart - Drums

Host: Morgan
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://ty-segall.com
http://kexp.org

## Ty Segall & Freedom Band - Whisper (Live on KEXP)
 - [https://www.youtube.com/watch?v=VID3I3rYU6k](https://www.youtube.com/watch?v=VID3I3rYU6k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-18 00:00:00+00:00

http://KEXP.ORG presents Ty Segall & Freedom Band performing “Whisper” live in the KEXP studio. Recorded February 5, 2022.

Ty Segall - Vocals / Guitar
Emmett Kelly - Guitar
Mikal Cronin - Bass
Ben Boye - Keys
Charles Moothart - Drums

Host: Morgan
Audio Engineer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Scott Holpainen

https://ty-segall.com
http://kexp.org


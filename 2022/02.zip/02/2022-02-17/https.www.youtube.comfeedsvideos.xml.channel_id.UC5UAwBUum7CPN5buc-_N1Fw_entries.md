# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## Google Analytics is illegal, Weird Chrome OS Flex, and Proton 7 - Linux and Open Source News
 - [https://www.youtube.com/watch?v=QBX84qLsjVo](https://www.youtube.com/watch?v=QBX84qLsjVo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-02-17 00:00:00+00:00

Get 100$ credit for your own Linux and gaming server: https://www.linode.com/linuxexperiment 

150€ off the Slimbook Executive ultrabook with code executive-laptop-nick-friends: https://slimbook.es/en/executive-en

👏 SUPPORT THE CHANNEL:
Get access to an exclusive weekly podcast, vote on the next topics I cover, and get your name in the credits:

YOUTUBE: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join

Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

🏆 FOLLOW ME ELSEWHERE:
Linux news in Youtube Shorts format: https://www.youtube.com/channel/UCtZp0mK9IBrpS2-jNzMZmoA

Join us on our Discord server: https://discord.gg/xK7ukavWmQ

Twitter : http://twitter.com/thelinuxEXP

My Gaming on Linux Channel: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw

📷 GEAR I USE:
Sony Alpha A6600 Mirrorless Camera: https://amzn.to/30zKyn7
Sigma 56mm Fixed Prime Lens: https://amzn.to/3aRvK5l
Logitech MX Master 3 Mouse: https://amzn.to/3BVI0Od
Bluetooth Space Grey Mac Keyboard: https://amzn.to/3jcJETZ
Logitech Brio 4K Webcam: https://amzn.to/3jgeTh9
LG Curved Ultrawide Monitor: https://amzn.to/3pcTVDH
Logitech White Speakers: https://amzn.to/3n6wSb0
Xbox Controller: https://amzn.to/3BWmIA3
*Amazon Links are affiliate codes and generate small commissions to support the channel*


00:00 Intro
00:31 Sponsor: Get 100$ off your own Linux or gaming server
01:42 Google Analytics is now illegal to use in France
02:40 Google has released Chrome OS Flex
03:28 Akamai bought Linode
04:12 Intel added support for Alder lake to the Linux kernel
05:04 KDE application updates
05:42 Kalendar 1.0 is out
06:26 Lutris Beta with Ubisoft and Origin support
07:11 OBS is now officially on Flathub
07:57 Wine 7.2 was released
08:27 Proton 7 was released
09:28 Valve offers Steam Deck CAD files
10:07 Check if your Steam library is compatible with the Deck
10:57 Sponsor: 150€ off your Slimbook Executive Ultrabook
11:22 Support the channel


Google Analytics is now illegal to use in France. 
https://techcrunch.com/2022/02/10/cnil-google-analytics-gdpr-breach/

Google has released Chrome OS Flex, a freely installable version of Chrome OS
https://chromeenterprise.google/os/chromeosflex/

Linode has been bought by Akamai
https://www.linode.com/press-release/akamai-to-acquire-linode/

 Intel has now released their Thread director, and it's being merged into the Linux kernel
https://hothardware.com/news/intel-thread-director-linux-boost-alder-lake-performance

KDE applications saw a bunch of updates in February
https://dot.kde.org/2022/02/10/kde-apps-update-february-2022

Kalendar 1.0 is a fantastic replacement to Korganizer, the aging calendar app for KDE.
https://claudiocambra.com/2022/02/12/kalendar-1-0-is-out/

Lutris 0.5.10 beta 1 is now out, which lets you try its new origin and ubisoft integration.
https://www.gamingonlinux.com/2022/02/lutris-0510-beta-1-is-out-with-origin-and-ubisoft-connect-integration/

OBS 27.2 was released, and while there aren't many incredible new features, it marks the first release to be officially packaged as a flatpak
https://feaneron.com/2022/02/14/obs-studio-27-2-on-flathub-get-it-while-its-hot/

Wine 7.2 was released
https://www.gamingonlinux.com/2022/02/wine-72-spilled-out-with-the-beginnings-of-a-wma-decoder/

Based on Wine 7 is also Proton 7, now available through Steam.
https://www.gamingonlinux.com/2022/02/proton-7-easy-anti-cheat-improvements-more-games-for-linux-a-steam-deck/

Speaking of which, Valve released some steam deck CAD files
https://www.gamingonlinux.com/2022/02/valve-releases-steam-deck-shell-cad-files/

Still on the Steam Deck, there's now a relatively simple way to check how much of your Steam library is currently compatible with the Steam deck.
https://www.gamingonlinux.com/2022/02/check-your-steam-library-against-steam-deck-compatibility-easily/
https://boilingsteam.com/more-than-600-games-playable-and-verified-ready-for-the-steam-deck-now/


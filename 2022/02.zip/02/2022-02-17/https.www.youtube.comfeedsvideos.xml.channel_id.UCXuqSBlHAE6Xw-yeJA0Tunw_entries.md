# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Valve's Making Everyone Else Look Bad - WAN Show February 18, 2022
 - [https://www.youtube.com/watch?v=rXHSbIS2lLs](https://www.youtube.com/watch?v=rXHSbIS2lLs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-18 00:00:00+00:00

Learn more about CORSAIR's iCUE 5000T RGB Case at https://lmg.gg/uJs27

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Get 50% off your Zoho CRM annual subscription with code ZCRM50 at: https://lmg.gg/ZohoCRMWAN

Check out the WAN Show & Podcast Gear: https://lmg.gg/podcastgear
Check out the They're Just Movies Podcast: https://lmg.gg/tjmpodcast

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/Valves-Making-Everyone-Else-Look-Bad---WAN-Show-February-18--2022-e1en6fe

Timestamps: (Courtesy of NoKi1119)
0:00 Chapters
2:39 Intro
3:36 Topic #1 - Steam Deck's ease of repair
9:14 Linus's experience with Index & out-of-warranty repairs
16:04 Valve working with iFixIt, Linus & NCIX tubing
22:04 LTTStore colored privateer t-shirt
30:28 LTTStore cropped sweatshirt, size preview
35:20 Topic #2 - Nintendo shutting down old stores 
43:58 Future of LMG, EBITDA, company lifetime, LMG staff
59:30 Sponsor - Corsair
1:00:57 Sponsor - Squarespace
1:01:56 Luke discusses NYT's abundance of ads
1:07:20 Sponsor - Zoho CRM
1:08:19 Merch Messages #1
1:25:24 Topic #3 - Windows 11 setup requires an account
1:27:21 Privateer shirts hit 420 sales
1:28:16 Windows features notes, parental lock
1:36:25 Topic #4 - Disney "house" in Rancho Mirage
1:41:16 Topic #5 - Apple SSD issues with M1
1:45:52 Topic #6 - TechTechPotato leaves AnandTech
1:49:44 Strawpoll - rug pull to fund the lab
1:52:13 Merch Messages #2
1:52:36 LTTStore screwdriver adapter & showcase
1:58:46 Cleaning laptop screen & keyboard
2:01:38 UFD Tech Newegg scandal
2:03:22 Nintendo Switch emulation
2:04:48 LTTStore archive idea, UV reactive paint
2:05:45 PC or no PC LED wall screen, LTTStore lunchbag
2:12:30 Framework mini-update, LTTStore kids toy & magnets
2:16:00 LTTStore wag pet hoodie
2:22:52 How labs will work, Linus lately letting loose
2:30:02 LTTStore backpack shaper discussion
2:32:43 Outro

## Ryzen 6000 Blew Me Away
 - [https://www.youtube.com/watch?v=wNSFKfUTGR8](https://www.youtube.com/watch?v=wNSFKfUTGR8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-17 00:00:00+00:00

Receive a $25 credit for Ting Mobile today when you sign up at https://linus.ting.com/

Learn more about CORSAIR's NEW iCUE 5000T RGB Case at https://go.corsair.com/0JXEPR

We've got a laptop with an AMD Ryzen 9 6900HS and another with an Intel i9-12900HK.  Which one is faster?

Discuss on the forum: https://linustechtips.com/topic/1412465-ryzen-6000-blew-me-away/

Check out the Zephyrus G14: https://rog.asus.com/laptops/rog-zephyrus/rog-zephyrus-g14-2022-series/

Buy a Zephyrus G14 (6900HS) at Best Buy: https://geni.us/kypk

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:50 Zen3+
1:20 Cinebench R23
2:22 Performance vs. Wattage test
3:23 The Rest of Intel's Lineup
5:00 Battery Life
5:45 RDNA2
6:35 Conclusion
7:45 Outro


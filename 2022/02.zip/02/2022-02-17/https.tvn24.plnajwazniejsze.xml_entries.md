# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Cierpią. Są coraz młodsze. Nie ma kto im pomóc
 - [https://tvn24.pl/go/programy,7/depresja-systemu--odcinki,705892/odcinek-1,S00E01,705886?source=rss](https://tvn24.pl/go/programy,7/depresja-systemu--odcinki,705892/odcinek-1,S00E01,705886?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-02-17 16:06:54+00:00

<img alt="Cierpią. Są coraz młodsze. Nie ma kto im pomóc" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i0deyq-coraz-mlodsze-dzieci-potrzebuja-pomocy-psychiatrow-5603091/alternates/LANDSCAPE_1280" />
    Istniejące szpitalne oddziały psychiatrii dzieci i młodzieży są przepełnione, dramatycznie brakuje personelu.


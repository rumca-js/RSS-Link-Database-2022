# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## 40K - WHAT IS SLAANESH? WILL THE AELDARI DESTROY THE GALAXY? | Warhammer 40,000 Lore/Discussion
 - [https://www.youtube.com/watch?v=Zzb5hz36ESs](https://www.youtube.com/watch?v=Zzb5hz36ESs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2022-02-18 00:00:00+00:00

Go to http://www.audible.com/luetin or text luetin to 500 500 to get your free trial.
► Subscribe: http://goo.gl/oeZMBS 
► Siege Studios: https://siegestudios.co.uk/
► Crystal Fortress Premium Storage: http://bit.ly/3oFuDf7
► Goblin Gaming: (Get - 20% off 40K Products) https://tinyurl.com/6vwcayvj
► Patreon: https://www.patreon.com/Luetin 
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

Timeline
0:00 Intro
1:39 Preamble
6:50 What I feared
11:28 Supplementary
21:46 Ancient Fragments
30:45 The Ynnari
46:08 The Unknown
51:56 Outro

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.


# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Children of Dune - REVIEW
 - [https://www.youtube.com/watch?v=nEr3UcBquq4](https://www.youtube.com/watch?v=nEr3UcBquq4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-02-18 00:00:00+00:00

Checkout Children of Dune here: https://amzn.to/3rYJDYA
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## BERSERK READ ALONG! -  Volumes 1-3
 - [https://www.youtube.com/watch?v=Ha_LW000UOM](https://www.youtube.com/watch?v=Ha_LW000UOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-02-17 00:00:00+00:00

My thoughts on the first Berserk Deluxe Edition - Volumes 1-3!
This covers the entirety of "The Black Swordsman" Arc.

Check out the book here: https://amzn.to/3rUk4rT 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


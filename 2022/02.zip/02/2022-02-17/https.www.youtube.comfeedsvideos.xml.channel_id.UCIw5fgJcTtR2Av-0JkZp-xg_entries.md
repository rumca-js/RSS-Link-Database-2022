# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## Never Gonna Give You Up x Plastic Love / Sessions
 - [https://www.youtube.com/watch?v=-GDimHLAU88](https://www.youtube.com/watch?v=-GDimHLAU88)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2022-02-18 00:00:00+00:00

Support my music on Patreon: https://www.patreon.com/yuriwong Download the track:
https://yuriwong.gumroad.com/l/wuwyo

Cover mashup performed by:
Vocals:  @MAYABAYU 
Glockenspiel, Guitar, Moog Bass, Beats, Percussion: Yuri Wong https://www.youtube.com/yuriwongmusic/
Electric Piano & Synths : Simmy Lor https://www.instagram.com/simmy_musiq/
Original tracks sung by Rick Astley and Mariya Takeuchi

Music arrangement by Simmy Lor & Yuri Wong
Recorded & mixed at The Factory Music Studio in Malaysia
Supported by Prima, MyCreative & Cendana

Instruments/Gear used:
Moog Sub37 
Arturia Microfreak 
Teenage Engineering OP-1
Fender Stratocaster
Novation Circuit 
Studio Electronics SE2200a

Recorded, Sequenced and mixed in Logic Pro X


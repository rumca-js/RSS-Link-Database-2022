# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Galaxy S22 Review: The iPhone of Android!
 - [https://www.youtube.com/watch?v=qWIkBMNKj1s](https://www.youtube.com/watch?v=qWIkBMNKj1s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-02-18 00:00:00+00:00

The Samsung Galaxy S22 has cemented itself as the Android default even more than the Pixel 👀

That shirt: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by Samsung for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

## On New Cybertruck Updates from Drone Footage...
 - [https://www.youtube.com/watch?v=k_OOiuaZSKc](https://www.youtube.com/watch?v=k_OOiuaZSKc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-02-17 00:00:00+00:00

The Cybertruck sitting out in the open is no coincidence. But this has its pros and cons...

That shirt: shop.mkbhd.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: http://youtube.com/20syl
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


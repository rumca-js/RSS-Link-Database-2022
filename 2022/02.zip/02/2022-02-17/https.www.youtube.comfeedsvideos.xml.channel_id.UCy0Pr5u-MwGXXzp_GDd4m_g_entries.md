# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Interrogation gone wrong...
 - [https://www.youtube.com/watch?v=6ZwwkRkFhdA](https://www.youtube.com/watch?v=6ZwwkRkFhdA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2022-02-17 00:00:00+00:00

When good cop bad cop goes too far... Subscribe to me! and then head over to @ChristianNat and subscribe there!!

Actors:  @ChristianNat  , Julie Nolke, and Jill Agopsowicz
Writer: Julie Nolke
Camera: Sam Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

Also, join my Patreon for behind the scenes videos, live q&as and early access to videos here: https://www.patreon.com/julienolke


# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## 'More like the England I know' - Canada boss Priestman after Lionesses draw
 - [https://www.bbc.co.uk/sport/football/60355842?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60355842?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 23:21:53+00:00

Canada head coach Bev Priestman says England looked "more like the England I know" after her side draw 1-1 with the Lionesses.

## Australia: The Aboriginal hairdressers delighting remote towns
 - [https://www.bbc.co.uk/news/world-australia-60412651?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-60412651?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 22:15:19+00:00

Growing up, Kyle Bambra never had access to a hairdresser - now he's determined to teach others.

## Tom Daley completes 4-day homecoming challenge for Comic Relief
 - [https://www.bbc.co.uk/news/uk-england-devon-60424835?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-devon-60424835?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 21:38:31+00:00

The Olympic gold-medallist rowed, swam, cycled and ran from London to Plymouth for charity.

## Rylee Foster: Liverpool goalkeeper on 'miracle' recovery after car accident
 - [https://www.bbc.co.uk/sport/football/60382594?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60382594?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 18:13:19+00:00

Liverpool goalkeeper Rylee Foster says she has experienced "dark" moments in her recovery from a car accident in October but has been given hope of a return to football.

## Quiz of the week: Which songs were used as a weapon?
 - [https://www.bbc.co.uk/news/world-60394107?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60394107?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 17:24:51+00:00

How closely have you been paying attention to what's been going on during the past seven days?

## Ukraine border guards on the watch for Russian advance
 - [https://www.bbc.co.uk/news/world-europe-60416620?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60416620?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 16:57:47+00:00

Fergal Keane travels to northern Ukraine to gauge the mood of those at risk of any Russian advance.

## Why are French troops leaving Mali, and what will it mean for the region?
 - [https://www.bbc.co.uk/news/world-60419799?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60419799?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 16:48:47+00:00

Will France's decision to remove 5,000 personnel weaken the fight against Islamists in Africa's Sahel?

## 'This is our home': The Americans who refuse to leave Ukraine
 - [https://www.bbc.co.uk/news/world-us-canada-60419006?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60419006?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 15:43:01+00:00

The US government has urged its citizens to leave Ukraine, but many have chosen to stay.

## Nottinghamshire father delivers own child for second time
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-60409233?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-60409233?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 14:21:55+00:00

Funeral director Dominic delivered his daughter Alice in a campervan at the side of a road.

## Child Covid vaccinations: Your questions answered
 - [https://www.bbc.co.uk/news/health-60415846?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60415846?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 12:54:11+00:00

Our health correspondents answer some of your questions.

## Ukraine: Russia will test our mettle, says Liz Truss
 - [https://www.bbc.co.uk/news/uk-politics-60414013?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60414013?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 12:28:20+00:00

The foreign secretary tells the Telegraph the West "must not be lulled into a false sense of security".

## Storm Eunice: Rare red weather warning issued for parts of the UK
 - [https://www.bbc.co.uk/news/uk-60417263?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60417263?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 12:26:21+00:00

The highest alert level means there is danger to life from flying debris, while power cuts are likely.

## British man, 35, killed in Sydney shark attack
 - [https://www.bbc.co.uk/news/world-australia-60398033?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-60398033?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 12:24:41+00:00

Simon Nellist, 35, was killed in a fatal shark attack in Sydney, a friend tells the BBC.

## Winter Olympics official says human rights abuse stories are 'lies'
 - [https://www.bbc.co.uk/sport/winter-olympics/60413992?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-olympics/60413992?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 12:01:02+00:00

The Winter Olympics faces renewed political controversy after a Games official dismissed human rights violations among the Uyghur Muslim population as "lies".

## Louis Thorold: Driver appears in court over A10 crash death
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-60416297?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-60416297?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 12:00:15+00:00

Five-month-old Louis Thorold and his mother were hit by a van in Cambridgeshire last January.

## Saudi Arabia: 28,000 women apply for 30 train driver jobs
 - [https://www.bbc.co.uk/news/world-middle-east-60414143?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-60414143?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 11:41:34+00:00

It is the first time such jobs have been advertised for women in the conservative Muslim kingdom.

## KitKat and Durex makers Nestle and Reckitt warn of price rises
 - [https://www.bbc.co.uk/news/business-60414915?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60414915?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 11:24:56+00:00

Consumer groups Nestle and Reckitt say product prices will rise to offset higher operating costs.

## Children in care looked after by grandparents 'on the cheap'
 - [https://www.bbc.co.uk/news/uk-wales-60287349?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60287349?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 11:21:44+00:00

James feels it unfair he was paid less for looking after his granddaughter because she is family.

## Wolves to host England Nations League matches in June
 - [https://www.bbc.co.uk/sport/football/60414223?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60414223?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 10:51:02+00:00

England's next two home Nations League matches - against Italy and Hungary - will be played at Wolverhampton Wanderers' Molineux ground in June.

## Paul Robson: Sex offender who fled HMP North Sea Camp recaptured
 - [https://www.bbc.co.uk/news/uk-england-lincolnshire-60382854?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lincolnshire-60382854?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 10:45:26+00:00

Paul Robson, 56, spent four days on the run after going missing from an open prison on Sunday.

## Apple boss Tim Cook faces backlash to £73m pay package
 - [https://www.bbc.co.uk/news/business-60403548?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60403548?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 10:40:56+00:00

A shareholder group says it has "significant concerns" over the size of Tim Cook's pay package.

## Spurs squad 'weakened' in January - Conte
 - [https://www.bbc.co.uk/sport/football/60411404?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60411404?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 10:16:29+00:00

Tottenham boss Antonio Conte believes his squad was "weakened" in the January transfer window despite the club signing two players.

## Winter Olympics: Great Britain women beat ROC to reach curling semi-finals
 - [https://www.bbc.co.uk/sport/av/winter-olympics/60414925?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/winter-olympics/60414925?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 09:43:06+00:00

A 9-4 victory for Great Britain's women over ROC and defeats for Japan and South Korea ensure they qualify for the curling semi-finals at the Winter Olympics in Beijing, where they will face defending champions Sweden.

## GB women join men in curling semi-finals
 - [https://www.bbc.co.uk/sport/winter-olympics/60411826?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-olympics/60411826?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 09:24:15+00:00

Great Britain's hopes of earning two curling medals are still alive as the women squeezed into the semi-finals after the men set up a last-four meeting with the United States.

## Amazon strikes global deal to accept Visa credit cards
 - [https://www.bbc.co.uk/news/business-60413957?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60413957?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 09:03:23+00:00

The online retailer says the agreement will apply worldwide and will remove surcharges on some sites.

## The divide over Scotland’s gender laws
 - [https://www.bbc.co.uk/news/uk-scotland-60214574?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-60214574?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 06:33:52+00:00

The Scottish government wants to make it easier for trans people's gender to be legally recognised.

## How farming has changed the lives of young autistic workers
 - [https://www.bbc.co.uk/news/uk-england-oxfordshire-60394476?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-oxfordshire-60394476?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 06:19:27+00:00

Young autistic people say their lives have been changed by working on an Oxfordshire farm.

## Housing: Fairy tale estate aimed at keeping young people local
 - [https://www.bbc.co.uk/news/uk-wales-60404223?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60404223?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 06:13:07+00:00

Brondanw estate is the brainchild of the architect behind the Italianate-style village Portmeirion.

## The Papers: Cash for honours probe 'deepens crisis for royals'
 - [https://www.bbc.co.uk/news/blogs-the-papers-60410983?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60410983?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 05:44:30+00:00

Thursday's front pages focus on the Met Police's investigation into Prince Charles' charity.

## Schools in England given guidance to avoid biased teaching
 - [https://www.bbc.co.uk/news/education-60405521?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-60405521?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 01:36:05+00:00

The education secretary says no subject should be off limits, but that lessons in England must be impartial.

## 'I lost my dad to prostate cancer, don't lose yours'
 - [https://www.bbc.co.uk/news/health-60390084?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60390084?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 01:12:47+00:00

Danielle Ray's father died aged 63 and more than 14,000 UK men are thought to be undiagnosed.

## Fight for payment of UK pensions lost in Yemen warzone
 - [https://www.bbc.co.uk/news/uk-england-birmingham-56803551?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-56803551?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 01:05:12+00:00

Yemenis who came to work in British factories in the 1950s have been without payments for years.

## Can Boris Johnson avoid a lockdown party fine?
 - [https://www.bbc.co.uk/news/uk-politics-60401498?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60401498?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 00:57:27+00:00

The PM is hoping his replies to police on Downing Street gatherings will get him off the hook.

## Ashutosh Kaushik: Indian actor fighting for the 'right to be forgotten'
 - [https://www.bbc.co.uk/news/world-asia-india-60373229?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-60373229?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 00:14:25+00:00

Ashutosh Kaushik says his life is still being held hostage to a youthful folly.

## The appetite for protein bars gives much to chew on
 - [https://www.bbc.co.uk/news/business-60300079?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60300079?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 00:14:12+00:00

Why are people trying to eat more protein and do protein bars live up to the healthy hype?

## Swahili's bid to become a language for all of Africa
 - [https://www.bbc.co.uk/news/world-africa-60333796?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-60333796?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 00:12:54+00:00

With 200 million speakers there is a renewed push to make Swahili a common language for Africa.

## French election: Who's vying to challenge Emmanuel Macron?
 - [https://www.bbc.co.uk/news/world-europe-59900131?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59900131?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 00:10:17+00:00

A tight and divisive race is expected when France holds a presidential election in April this year.

## Covid: What's life like for unvaccinated people in the UK?
 - [https://www.bbc.co.uk/news/uk-60316361?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60316361?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-17 00:02:14+00:00

There are around five million people in the UK who still haven't had a Covid jab.


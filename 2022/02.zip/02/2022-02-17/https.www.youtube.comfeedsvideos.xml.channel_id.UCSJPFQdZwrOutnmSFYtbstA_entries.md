# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Jurassic World Dominion - Greed Finds A Way
 - [https://www.youtube.com/watch?v=SUkZuZLOork](https://www.youtube.com/watch?v=SUkZuZLOork)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-02-17 00:00:00+00:00

So the Jurassic World Dominion trailer came out the other day, and it looks predictably rubbish. Join me as I give my thoughts on this franchise. 

Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker


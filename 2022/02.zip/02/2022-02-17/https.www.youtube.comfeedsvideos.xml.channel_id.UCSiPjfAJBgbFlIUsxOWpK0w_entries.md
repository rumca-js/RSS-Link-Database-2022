# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Jon the Baptist // Jacaranda // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=pC_MsfaBgTg](https://www.youtube.com/watch?v=pC_MsfaBgTg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-02-17 00:00:00+00:00

So the bassist from our Pomplamoose French sessions - Eliana Athayde - is also an incredible singer-songwriter. This is one of her originals, recorded with her band Jacaranda. If you want to hear more of their music (because you definitely do) go to: http://jacaranda.band/
Spotify: https://open.spotify.com/artist/467uAjGmMGVm5mtfgRmKPc?si=51uaApl3Tna5VSL5ZaCuvw
YouTube: https://www.youtube.com/c/Jacarandaband
More: https://bnd.link/jacarandaband

Listen to Jacaranda's original version of this song: https://open.spotify.com/track/05Oq0eKmCQWSgOtW1CaK2k?si=c92efc171e0840c7
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Jacaranda's "Jon the Baptist" by Pomplamoose.

MUSICIAN CREDITS
Lead Vocals/Upright Bass: Eliana Athayde
Clarinet: Maxime Stinnett
Keys: Jack Conte
Guitar: John Schroeder
Guitar: Dillon Casey
Drums: Kevin Yokota
Additional Percussion: Ben Rose
Trombone: Vikram Devasthali

AUDIO CREDITS
Engineer: Tim Sonnefeld
Assistant Engineer: Tyler Karmen
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
Director: Dom Fera
DP: Merlin Showalter
Gaffer: Arjay Ancheta
Production Designer: Katie Theel
Video Editor/Colorist: Athena Wheaton

Recorded at 64 Sound in Los Angeles.

LYRICS
Jon the Baptist 
you’ve got a righteous kind of way, 
go ‘head and tell all the people about the approaching golden age
I would not stop you from what you’re doing 

Jon, 
Jon the savior for my feeble aching heart, 
I heard your voice crying out from the alps like a beacon from the dark —
I would not stop you from what you’re doing
(I could never clothe you in chains)
You, one of few who could save my soul from going to flames…

Jon the Baptist,
I cannot believe what my eyes do see
Jon the Baptist,
Offering his sacred heart to me,
But for a moment, still…
The Baptist
Hands touching my skin they do free my soul
I’m telling you the Baptist
Let’s me leave my sins all at the door
But for a moment, still….

I would like to see you once more
Standing on that eastern shore but,
I know that you have so much left to do

Jon the Baptist
Jon, Jon the revelation that there’s nobody else, but you’ve got a few more souls so save from burning in hell
Jon the Baptist 
Jon, the savior for my feeble aching heart, the Baptist.

#Pomplamoose #Jacaranda #JonTheBaptist


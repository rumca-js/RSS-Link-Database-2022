# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Horizon Forbidden West: 10 Things The Game DOESN'T TELL YOU
 - [https://www.youtube.com/watch?v=3e0CgdbFbgA](https://www.youtube.com/watch?v=3e0CgdbFbgA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-18 00:00:00+00:00

Horizon Forbidden West (PS5, PS4) is filled with small helpful things that the game doesn't spell out for you. Here are some helpful tricks.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## UBISOFT UP FOR SALE?, BATTLEFIELD 2042 SETS NEW RECORD, & MORE
 - [https://www.youtube.com/watch?v=opvam-zQS1U](https://www.youtube.com/watch?v=opvam-zQS1U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-18 00:00:00+00:00

Thanks to Dr. Squatch for sponsoring this video. New customers can get 20% off on orders of $20 or more. Use my code DSQGAMERANX and click https://bit.ly/32gaV2J

Bioshock rumors (and a TV show!), the launch of Horizon Forbidden West, more gaming acquisition talks, and more in a week chock full of gaming news.

Jake on twitter: https://bit.ly/3gdkPqD​​​​

Instagram: https://bit.ly/3uUh9Ot


 ~~~~STORIES~~~~


Ubisoft
https://www.gamespot.com/articles/ubisoft-reveals-new-game-sales-stats-says-its-not-looking-to-sell-but-would-entertain-buyout-offer/1100-6500806/
+
https://www.videogameschronicle.com/news/ubisoft-says-skull-bones-is-now-a-multiplayer-first-game/
+
https://www.vg247.com/skull-and-bones-development-going-well-says-ubisoft


Battlefield 2042 breaks record
https://gamerant.com/battlefield-2042-lowest-steam-player-count/

Bioshock 4 delayed
https://gameranx.com/updates/id/288833/article/bioshock-4-might-be-delayed-after-reported-issues/

Netflix Bioshock
https://www.hollywoodreporter.com/movies/movie-news/bioshock-movie-neflix-1235093896/

Uncharted movie

Nintendo
https://kotaku.com/nintendo-wii-u-3ds-classic-games-mario-zelda-eshop-shop-1848544931
https://twitter.com/GameHistoryOrg/status/1494398068346654720

SW Old Republic
https://youtu.be/QgbMAdtp7aE

Gerudo Valley cover (AWESOME)
https://youtu.be/zMWhgeEx2Wk


Horizon Forbidden West
https://youtu.be/NFOFNn3Dnt4

Cyberpunk next gen and 1.5
https://youtu.be/8WP6qnR5NXM



Daedalic bought by NACON
https://www.destructoid.com/nacon-daedalic-entertainment-acquisition-gollum-industry-merger/


Platinum games
https://www.videogameschronicle.com/news/platinums-ceo-says-he-wouldnt-dismiss-acquisition-offers-as-long-as-our-freedom-is-respected/

## 10 BIGGEST Video Game Bosses of All Time
 - [https://www.youtube.com/watch?v=HhD9WQTfUQ0](https://www.youtube.com/watch?v=HhD9WQTfUQ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-17 00:00:00+00:00

Video game bosses are typically large, but these baddies are absolutely massive.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


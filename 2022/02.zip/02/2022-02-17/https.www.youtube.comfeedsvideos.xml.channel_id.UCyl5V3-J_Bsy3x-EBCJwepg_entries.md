# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## EXCLUSIVE: We've Obtained Trump's Jan. 6 Visitor Logs!
 - [https://www.youtube.com/watch?v=KeGuB6qogTU](https://www.youtube.com/watch?v=KeGuB6qogTU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-18 00:00:00+00:00

Trump's White House logs up to and including January 6 have been subpoenaed. But, being fantastic journalists, we've obtained an exclusive early look at who visited the White House on that fateful day that will live in infamy.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Bee Weekly: Metaverse or Mark of the Beast?
 - [https://www.youtube.com/watch?v=zRjMOkRffU8](https://www.youtube.com/watch?v=zRjMOkRffU8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-18 00:00:00+00:00

This episode is brought to you by Private Internet Access. Get 83% off: https://privateinternetaccess.com/TheBabylonBee

The Babylon Bee discusses life in the Metaverse, including going to church in the Metaverse, with Christian astrophysicist Dr. Jeff Zweerink from Reasons to Believe. The Bee also talks about everything else going in the writer’s room and, of course, the notorious hate group, Westboro Baptist Church.

Check out Dr. Jeff Zweerink’s work at Reasons to Believe: https://reasons.org/

This episode is also brought to you by ADF Legal. Join the fight: https://adflegal.org/babylon-bee/donate?sourcecode=10020838

This episode is brought to you by Faithful Counseling: https://www.faithfulcounseling.com/get-started/?transaction_id=102eef8b0966d0357c2eb628f9b8a2&utm_source=affiliate&utm_campaign=281&utm_medium=Desktop&utm_content=&utm_term=babylonbee&not_found=1&gor=start&go=true

## The Babylon Bee Looks Back At Joe Biden's First Year As President
 - [https://www.youtube.com/watch?v=D3_ooizzGZk](https://www.youtube.com/watch?v=D3_ooizzGZk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-17 00:00:00+00:00

Believe it or not, it has only been a little over one year of Joe Biden being the President of the United States. The Babylon Bee looks back on all the highlights.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Uncharted - Movie Review
 - [https://www.youtube.com/watch?v=jEdoZbiRFL0](https://www.youtube.com/watch?v=jEdoZbiRFL0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-02-17 00:00:00+00:00

Get the exclusive NordVPN deal here: https://nordvpn.com/jahns. It’s risk free with Nord’s 30 day money-back guarantee! Thanks to NordVPN for sponsoring this video.

The casting has always looked....well....BUT how does the UNCHARTED movie hold as an adventure based on the game franchise? Here's my review!

#Uncharted


# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Bleachers' Jack Antonoff on recording at Paisley Park, his love of FaceTime, and touring in 2022
 - [https://www.youtube.com/watch?v=UoZqSnENTbQ](https://www.youtube.com/watch?v=UoZqSnENTbQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-18 00:00:00+00:00

Ahead of Bleachers' 2022 tour, Jack Antonoff caught up with The Current's Mac Wilson about recording at Paisley Park, his love of Facetime as a way to connect with loved ones, and how he looks at touring: "It's like throwing a wedding every night."

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

Credits
Guest - Jack Antonoff
Host - Mac Wilson
Producers - Jesse Wiza, Derrick Stevens
Technical Director - Eric Romani


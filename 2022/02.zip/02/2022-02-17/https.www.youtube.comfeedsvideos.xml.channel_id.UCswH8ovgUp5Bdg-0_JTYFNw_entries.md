# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Did Hillary Spy On Trump?
 - [https://www.youtube.com/watch?v=O2KhiDfqeLI](https://www.youtube.com/watch?v=O2KhiDfqeLI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-18 00:00:00+00:00

As more is revealed about Hillary Clinton’s campaign and its alleged surveillance of Donald Trump, we ask, is it any wonder that trust in government and corporate media is at a near all-time low? 
#Trump #HillaryClinton #Russiagate 

References
https://www.wsj.com/articles/donald-trump-really-was-spied-on-2016-clinton-campaign-john-durham-court-filing-11644878973

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Johnson & Johnson Baby Powder Lawsuits
 - [https://www.youtube.com/watch?v=vCiH70DFM3k](https://www.youtube.com/watch?v=vCiH70DFM3k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-17 00:00:00+00:00

As a secret Johnson & Johnson plan to limit baby powder lawsuit payouts is revealed, we ask, is that even the worst thing about them? 
#BigPharma #BabyPowder #Johnson&Johnson 

See Reference Below...

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Join Our Community HERE: https://www.russellbrand.com/join 

To listen, subscribe to the Luminary Channel on Apple Podcasts at apple.co/russell or on the Luminary app http://luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My Weekly meditation podcast, Above the Noise, is available now on Apple & Luminary
http://apple.co/meditate
http://luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

References
https://reclaimthenet.org/jj-tried-to-block-publication-of-story-cancer-lawsuits/

https://www.reuters.com/business/healthcare-pharmaceuticals/jj-tried-get-federal-judge-block-publication-reuters-story-2022-02-04/

https://www.drugwatch.com/manufacturers/johnson-and-johnson/

https://news.sky.com/story/johnson-johnson-ordered-to-pay-572m-for-helping-fuel-opioid-crisis-11795057

https://www.theguardian.com/us-news/2019/jul/24/opioids-crisis-big-pharma-drugs-carnage

https://www.businessinsider.com/lawmakers-bought-sold-covid-19-related-stocks-during-pandemic-2021-12?r=US&IR=T


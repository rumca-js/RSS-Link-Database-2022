# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## The Story Behind Earthquake's Name
 - [https://www.youtube.com/watch?v=y8U5e8_qSSw](https://www.youtube.com/watch?v=y8U5e8_qSSw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-02-26 00:00:00+00:00

Taken from JRE #1785 w/Earthquake:
https://open.spotify.com/episode/0Qni445JFkvU0cwndz02fD?si=d93db386283d4deb

## Author Ben Burgis on Dave Chappelle and the Moralism of Canceling Comedians
 - [https://www.youtube.com/watch?v=PgfX9bvmEhs](https://www.youtube.com/watch?v=PgfX9bvmEhs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-02-25 00:00:00+00:00

Taken from JRE #1783 w/Ben Burgis:
https://open.spotify.com/episode/0UmjhCbyz0oG6bWUKlnNeF?si=f01b8269eb284514

## The Corporatization of Food
 - [https://www.youtube.com/watch?v=AmIdT42728g](https://www.youtube.com/watch?v=AmIdT42728g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-02-25 00:00:00+00:00

Taken from JRE #1784 w/Diana Rodgers and Robb Wolf:
https://open.spotify.com/episode/0r7MbKFhtLf9RLOahCT1gU?si=c07d74c3515a4f6c


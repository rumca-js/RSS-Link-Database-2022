# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Life of Azog the Defiler | Tolkien Explained
 - [https://www.youtube.com/watch?v=PHkkHq3RxW8](https://www.youtube.com/watch?v=PHkkHq3RxW8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-02-26 00:00:00+00:00

He is among the fiercest orcs to torment the dwarves of Middle-earth.  While he would become a main villain of the Hobbit film trilogy, his story of his life and death in the books is very different.  We cover his life as an orc-chieftan and leader of the orcs of Moria, his killing of King Thror, and his chilling demise at the hands of Dain Ironfoot.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Tulikoura - https://www.deviantart.com/tulikoura

Azog - Wētā
The Uruk-hai - John Howe
Azog Concept Art - Wētā
Amored Azog - Wētā
Black Trolls - Angus McBride
Azog the Defiler - Andrew Baker
Moria Orcs - John Howe
The Great Goblin - Anke Eissmann
Azog and Warg Matriarch - Wētā
Dain - Turner Mohan
Dragon - Andrea Piparo
Thror - Paul Tobin
Nargothrond - Alan Lee
Nar at the Gate of Moria - Tulikoura
The Heir of Durin - Turner Mohan
Azog and Nar - Steamey
Pyres and Great Labour - Tulikoura
The Battle of Nanduhirion - Tulikoura
Battle of Five Armies, Warriors of Dain - Tulikoura
Battle of Five Armies, King Under the Mountain - Tulikoura
Dwarves and Orcs - Wētā
Two Kings - Tulikoura
Upper Armories of the Deep - Tulikoura
Azog concept art - Wētā
Attacking orc - Wētā
King Dain - BFME2
Nain Duels Azog - Tulikoura
Dain Chases Azog - Tulikoura
Dain Ironfoot - CK Goksoy
Dain Ironfoot - Ted Nasmith
Dain Ironfoot - Nick Keller, Wētā
The Uruk-hai - Anke Eissmann
Vengeance - Steamey
Bolg - Wētā
Servants of Sauron - John Howe
The Battle Under the Mountain - Matt Stewart
Thorin - Wētā
The Great Goblin - Anke Eissmann
Tauriel - Jerry Vanderstelt

#azog #tolkien #lordoftherings


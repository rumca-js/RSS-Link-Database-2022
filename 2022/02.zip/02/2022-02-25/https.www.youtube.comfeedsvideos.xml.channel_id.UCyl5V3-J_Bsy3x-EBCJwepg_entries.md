# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## The Bee Weekly: Facebook Deletes Our Post and We Make Grammar Gooder Again
 - [https://www.youtube.com/watch?v=95yDOSzTKGU](https://www.youtube.com/watch?v=95yDOSzTKGU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-25 00:00:00+00:00

The Babylon Bee discusses how Facebook says we have gone against their community standards and have deleted our post about Amy Schneider. Adam and Jarret are joined by copy editor Kristin Oren to help us all with our grammar and to talk about some stuff that’s good like books that you really need to read. 

Kristin worked on Kyle and Joel’s new book The Postmodern Pilgrim’s Progress, which is available for Pre-Order: https://www.amazon.com/Postmodern-Pilgrims-Progress-Allegorical-Tale-ebook/dp/B09NL6J8C3/ref=sr_1_2?keywords=the+postmodern+pilgrim%27s+progress+an+allegorical+tale&qid=1645642422&sprefix=the+postmodern+pil%2Caps%2C124&sr=8-2

This episode is brought to you by My Patriot Supply: https://mypatriotsupply.com/pages/babylon-bee

This episode is also sponsored by Daily Nouri: https://dailynouri.com/

This episode is also brought to you by ADF Legal. Help support Lorie at the Supreme Court: https://adflegal.org/303-creative/donate?sourcecode=10021442&utm_source=babylonbee&utm_medium=podcast_interviews&utm_campaign=303creative

## The Christian Woman’s Starter Kit
 - [https://www.youtube.com/watch?v=Yi28WlhNEl0](https://www.youtube.com/watch?v=Yi28WlhNEl0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-25 00:00:00+00:00

So you've given your life to Christ, but now what? Let us equip you with everything a Christian woman needs… besides Jesus of course.

Become a premium subscriber:  https://babylonbee.com/plans?utm_source=YT&utm_medium=social&utm_campaign=description

Subscribe to our podcast channel: https://www.youtube.com/thebabylonbeepodcast

The Official The Babylon Bee Store: https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

#christianity #christian #jesus #women #christ


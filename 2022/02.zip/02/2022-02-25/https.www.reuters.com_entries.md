## Ukraine war flashes neon warning lights for chips | Reuters
 - [https://www.reuters.com/breakingviews/ukraine-war-flashes-neon-warning-lights-chips-2022-02-24/](https://www.reuters.com/breakingviews/ukraine-war-flashes-neon-warning-lights-chips-2022-02-24/)
 - RSS feed: https://www.reuters.com
 - date published: 2022-02-25 07:51:19.738463+00:00

Russia’s invasion of Ukraine  by land, air and sea risks reverberating across the global chip industry and exacerbating current supply-chain constraints. Ukraine is a major producer of neon gas critical for lasers used in chipmaking and supplies more than 90% of U.S. semiconductor-grade neon, according to estimates from research firm Techcet. About 35% of palladium, a rare metal also used for semiconductors, is sourced from Russia. A full-scale conflict disrupting exports of these elements might hit players like Intel , which gets about 50% of its neon from Eastern Europe according to JPMorgan.


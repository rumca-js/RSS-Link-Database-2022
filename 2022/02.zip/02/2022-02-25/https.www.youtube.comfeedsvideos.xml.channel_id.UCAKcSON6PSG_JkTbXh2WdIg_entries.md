# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Low Cut Connie Full Headline Performance Jan. 22, 2022 (The Current's 17th Anniversary Party)
 - [https://www.youtube.com/watch?v=qjqRFfq7sWQ](https://www.youtube.com/watch?v=qjqRFfq7sWQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-26 00:00:00+00:00

Adam Weiner of Low Cut Connie never delivers anything less than a committed performance. The Philadelphian rock outfit filled the stage with a raucous lineup that pounded through a set including crowd favorite “Boozeophilia”; a classic rock cover medley that included “Cream,” one of the night’s two Prince covers (“America” came later); and an absolutely epic “Charyse.”

Songs Played:
00:01 Me N Annie
05:44 Nobody Else Will Believe U
07:16 Boozophilia
10:14 Tough Cookies
12:29 Dirty Water
16:30 Love Life
19:33 All These Kids Are Way Too High/Shotgun Medley
28:43 Help Me
32:07 Charyse
37:22 Now You Know
42:00 Shake It Little Tina
48:55 Be My Baby (The Ronettes cover)
53:55 Hollywood

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

## Kiss The Tiger Full Performance Jan. 22, 2022 (The Current's 17th Anniversary Party)
 - [https://www.youtube.com/watch?v=s-f2IiIKRDE](https://www.youtube.com/watch?v=s-f2IiIKRDE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-25 00:00:00+00:00

Minneapolis five-piece rock 'n' roll act Kiss the Tiger have honed a tight attack over the years, and frontwoman Meghan Kreidler absolutely commanded the First Avenue mainstage at The Current's 17th Anniversary Party for an unforgettable set featuring tracks from their third studio record, 'Vicious Kid'.

Songs Played:
00:01 Motel Room
02:35 Who Does Her Hair?
04:44 Bad Boy
08:49 Out Of My Mind
13:34 I Miss You
17:55 Weekend
22:15 Grown Ass Woman
28:01 Hold On To Love
40:20 Bully

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/


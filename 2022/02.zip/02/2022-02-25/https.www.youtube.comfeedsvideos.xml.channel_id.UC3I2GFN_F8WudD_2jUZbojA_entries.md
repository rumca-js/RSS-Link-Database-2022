# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Silvana Estrada - Casa (Live on KEXP)
 - [https://www.youtube.com/watch?v=jam_WxXiLEQ](https://www.youtube.com/watch?v=jam_WxXiLEQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-25 00:00:00+00:00

http://KEXP.ORG presents Silvana Estrada performing “Casa” live in the KEXP studio. Recorded February 15, 2022.

Silvana Estrada - Cuatro Venezolano / Vocals
Roberto Verástegui - Piano / Vibraphone / Vocals
Alex Lozano - Drums / Vocals

Host: Albina Cabrera
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.silvanaestrada.com
http://kexp.org

## Silvana Estrada - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=WHCyOp4xEsY](https://www.youtube.com/watch?v=WHCyOp4xEsY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-25 00:00:00+00:00

http://KEXP.ORG presents Silvana Estrada performing live in the KEXP studio. Recorded February 15, 2022.

Songs:
La Corriente
Te Guardo
Ser De Ti
Casa

Silvana Estrada - Cuatro Venezolano / Vocals
Roberto Verástegui - Piano / Vibraphone / Vocals
Alex Lozano - Drums / Vocals

Host: Albina Cabrera
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.silvanaestrada.com
http://kexp.org

## Silvana Estrada - La Corriente (Live on KEXP)
 - [https://www.youtube.com/watch?v=FJu0t5CRbA8](https://www.youtube.com/watch?v=FJu0t5CRbA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-25 00:00:00+00:00

http://KEXP.ORG presents Silvana Estrada performing “La Corriente” live in the KEXP studio. Recorded February 15, 2022.

Silvana Estrada - Cuatro Venezolano / Vocals
Roberto Verástegui - Piano / Vibraphone / Vocals
Alex Lozano - Drums / Vocals

Host: Albina Cabrera
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.silvanaestrada.com
http://kexp.org

## Silvana Estrada - Ser De Ti (Live on KEXP)
 - [https://www.youtube.com/watch?v=qSVh4I4FdsQ](https://www.youtube.com/watch?v=qSVh4I4FdsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-25 00:00:00+00:00

http://KEXP.ORG presents Silvana Estrada performing “Ser De Ti” live in the KEXP studio. Recorded February 15, 2022.

Silvana Estrada - Cuatro Venezolano / Vocals
Roberto Verástegui - Piano / Vibraphone / Vocals
Alex Lozano - Drums / Vocals

Host: Albina Cabrera
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.silvanaestrada.com
http://kexp.org

## Silvana Estrada - Te Guardo (Live on KEXP)
 - [https://www.youtube.com/watch?v=OMG7ePKkLnI](https://www.youtube.com/watch?v=OMG7ePKkLnI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-02-25 00:00:00+00:00

http://KEXP.ORG presents Silvana Estrada performing “Te Guardo” live in the KEXP studio. Recorded February 15, 2022.

Silvana Estrada - Cuatro Venezolano / Vocals
Roberto Verástegui - Piano / Vibraphone / Vocals
Alex Lozano - Drums / Vocals

Host: Albina Cabrera
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://www.silvanaestrada.com
http://kexp.org


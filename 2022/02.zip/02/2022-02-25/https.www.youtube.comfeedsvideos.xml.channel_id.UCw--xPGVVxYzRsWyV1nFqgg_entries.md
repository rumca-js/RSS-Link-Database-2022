# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## KingKiller Adaptation development🛑Elden Ring Reception🏅Percy Jackson Filming📽️-FANTASY NEWS
 - [https://www.youtube.com/watch?v=UDHoP__kPf4](https://www.youtube.com/watch?v=UDHoP__kPf4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-02-25 00:00:00+00:00

Let's Jump into the Fantasy News! 
Mother Of Learning kickstarter: https://www.kickstarter.com/projects/wraithmarked/motheroflearningarc1?ref=58odqf 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 Intro

00:19 Elden Rings Reception: https://www.thegamer.com/elden-ring-highest-rated-game-opencritic/ 

01:23 New Starlight Jackets… again: https://krakenbook.com/ 

02:07 Babel presales: https://twitter.com/kuangrf/status/1496268996903161860?t=0hO3qLcX7XWrKw0IBQ1QcA&s=19 

02:36 The Meme: https://twitter.com/spiderman/status/1496486466733715459?s=21 

03:20 Sponsor 

04:20 Of Charms Ghosts and Grievances: https://thefantasyinn.com/2022/02/24/cover-reveal-of-charms-ghosts-and-grievances-by-aliette-de-bodard/ 

04:45 Kingkiller developmental stall https://variety.com/2022/film/awards/lin-manuel-miranda-defends-not-submitting-bruno-for-oscars-teases-new-little-mermaid-songs-1235182753/ 

05:42 Majora’s Mask Switch: https://www.polygon.com/22940784/the-legend-of-zelda-majoras-mask-nintendo-switch-online-release-date 

05:59 Fairly Odd Parents: https://twitter.com/DiscussingFilm/status/1496548842971570187?t=MCaBqPt_NhY-0Zc84gjhhA&s=19 

06:36 Percy Jackson to begin filming: https://twitter.com/DiscussingFilm/status/1496560052165033985?t=IcBgY9w5kEBrKBZQTx2fZg&s=19


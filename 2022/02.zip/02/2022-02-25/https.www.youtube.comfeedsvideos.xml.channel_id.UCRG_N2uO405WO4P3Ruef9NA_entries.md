# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Blackberry dies a 3rd time
 - [https://www.youtube.com/watch?v=lkkixHhdHdc](https://www.youtube.com/watch?v=lkkixHhdHdc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-02-25 00:00:00+00:00

This week OPPO released the Find X5, Blackberry died for a 3rd time through Onward Mobility, the Samsung Galaxy S22 is selling like hot cakes, and Facebook/Meta announced new AI tools to build VR worlds.

Episode 85

This video on Nebula: https://nebula.app/videos/the-friday-checkout-blackberry-dies-a-3rd-time
Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 
Quiz: https://link.crrowd.com/quiz

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:32 OPPO Find X5
1:45 Motorola Edge Plus/30 Pro
2:34 IQOO 9 series
3:07 Redmagic 7 series
4:05 PSVR2
4:31 Panasonic GH6
5:32 Blackberry's 3rd death
6:30 Samsung S22 success
7:43 Meta AI


# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Bellator Dublin: Sinead Kavanagh claims gritty win over Leah McCourt
 - [https://www.bbc.co.uk/sport/av/mixed-martial-arts/60533666?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/mixed-martial-arts/60533666?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 23:43:20+00:00

Ireland's Sinead Kavanagh claims a gritty win over Leah McCourt in Dublin despite injuring her knee in the first round.

## Ukraine: What happens next?
 - [https://www.bbc.co.uk/news/world-europe-60533425?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60533425?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 23:37:05+00:00

The gloves are off - so what might happen next? What can the West do to deter Vladimir Putin?

## Families escaping conflict in Ukraine arrive in Poland
 - [https://www.bbc.co.uk/news/world-europe-60532716?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60532716?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 23:28:35+00:00

One family included a 10-year-old child, who has been travelling with her mother from Kyiv for two days.

## 'Hank the Tank': DNA evidence spares 500lb burglar bear
 - [https://www.bbc.co.uk/news/world-us-canada-60532151?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60532151?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 20:36:34+00:00

Genetic samples show the 500lb bear linked to more than two dozen home break-ins... did not act alone.

## Birmingham pub bombings: Fight over 'confession' to Chris Mullin
 - [https://www.bbc.co.uk/news/uk-england-birmingham-60526108?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-60526108?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 20:25:21+00:00

West Midlands Police has launched a legal bid to force journalist Chris Mullin to reveal sources.

## Scottish Tory leader Douglas Ross faces no action over undeclared earnings
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-60527066?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-60527066?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 20:06:39+00:00

A watchdog finds the Scottish Tory leader did not "deliberately attempt to mislead" over his earnings.

## Ukraine conflict: BP under pressure to sell stake in Russian firm
 - [https://www.bbc.co.uk/news/business-60526891?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60526891?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 19:46:25+00:00

The oil giant's boss is warned of UK government concerns about its "overexposure to Russian interests".

## Ukrainians in the UK: 'My dad refused safety, he will protect the land'
 - [https://www.bbc.co.uk/news/uk-60524586?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60524586?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 15:45:29+00:00

UK-based Ukrainians tell of fears for their homeland's future and their attempts to help from afar.

## Ukraine crisis: Missile strikes, tanks and buildings hit in Kyiv
 - [https://www.bbc.co.uk/news/world-europe-60525995?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60525995?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 13:04:31+00:00

Russia continues its full-scale assault on Ukraine, with troops said to be in the capital.

## Ukraine invasion: UK troops will not fight against Russia says Wallace
 - [https://www.bbc.co.uk/news/uk-60522745?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60522745?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 11:50:19+00:00

The defence secretary says Britain will not be "directly" involved but is supporting Ukraine forces.

## West Ham draw Sevilla in Europa League as Rangers face Red Star Belgrade
 - [https://www.bbc.co.uk/sport/football/60523333?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60523333?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 11:50:07+00:00

Scottish champions Rangers will face Serbia's Red Star Belgrade in the Europa League last-16 while West Ham play Sevilla.

## Russia bans British airlines from its airspace
 - [https://www.bbc.co.uk/news/business-60505417?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60505417?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 11:43:30+00:00

Russia says the move is a response to the UK's 'unfriendly' decision to ban Aeroflot from the UK.

## Ukraine conflict: Kyiv braces for Russian assault
 - [https://www.bbc.co.uk/news/world-europe-60513116?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60513116?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 11:40:31+00:00

The Ministry of Defence made the call as Russian forces reached the northern outskirts of Kyiv.

## Ukraine: Kyiv residents spend night sheltering in basements and metro stations
 - [https://www.bbc.co.uk/news/world-europe-60522450?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60522450?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 11:35:19+00:00

Ukrainians tell the BBC how they spent the night sheltering from explosions and missile strikes.

## Reid Steele: Mother Natalie Steele admits killing son, 2
 - [https://www.bbc.co.uk/news/uk-wales-60515005?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60515005?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 11:24:09+00:00

Natalie Steele, 32, pleads guilty to manslaughter of Reid, who died after he was submerged in water.

## Russia stripped of Champions League final
 - [https://www.bbc.co.uk/sport/football/60520933?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60520933?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 11:18:20+00:00

The 2022 Champions League final will be played in Paris after Russia was stripped of the match following the nation's invasion of Ukraine.

## Ukraine invasion: Charities urge UK to welcome thousands of refugees
 - [https://www.bbc.co.uk/news/uk-60518801?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60518801?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 11:03:59+00:00

Charities say the UK should play a leading role, as the UN warns five million people could be displaced.

## 'Women's World Cup unlikely to be Covid-free'
 - [https://www.bbc.co.uk/sport/cricket/60504478?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/60504478?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 10:34:14+00:00

England captain Heather Knight says the Women's World Cup is unlikely to be "Covid-free" as New Zealand sees a surge in the Omicron variant.

## Oil rises as Russia invasion nears Ukraine capital
 - [https://www.bbc.co.uk/news/business-60518578?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60518578?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 10:32:20+00:00

The price of oil climbs back above $100 a barrel on renewed fears over supply constraints.

## Russian forces seize Chernobyl nuclear power plant
 - [https://www.bbc.co.uk/news/world-us-canada-60514228?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60514228?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 09:32:19+00:00

The power plant, the site of a 1986 nuclear disaster, has been taken over by Russian troops.

## Sally Kellerman: Oscar-nominated M*A*S*H actress dies at 84
 - [https://www.bbc.co.uk/news/entertainment-arts-60521458?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60521458?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 09:12:04+00:00

Sally Kellerman played "Hot Lips" Houlihan in Robert Altman's 1970 film, set in the Korean war.

## Storm Eunice: O2 Arena reopens after Storm damage
 - [https://www.bbc.co.uk/news/uk-england-london-60514858?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-60514858?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 08:28:04+00:00

A hole in the London venue's fabric, which was shredded by winds, will be visible for some time.

## Liverpool: Is this Jurgen Klopp's strongest squad?
 - [https://www.bbc.co.uk/sport/football/60409961?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60409961?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 08:04:51+00:00

Liverpool are preparing to face European champions Chelsea in Sunday's Carabao Cup final with arguably their strongest squad under manager Jurgen Klopp.

## 'The transfer ban was the best thing' - how Chelsea's youth have gone from 'mannequins' to key players
 - [https://www.bbc.co.uk/sport/football/60465360?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60465360?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 08:04:37+00:00

Chelsea youth hopefuls used to have to go elsewhere for first-team football - but now have several academy graduates in their squad, including Mason Mount and Reece James. So what changed?

## The Papers: 'A dark day for Europe' as Putin invades
 - [https://www.bbc.co.uk/news/blogs-the-papers-60518008?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60518008?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 06:16:07+00:00

The papers see echoes of World War Two and its aftermath as Russia launches an assault on Ukraine.

## Football Focus: Jadon Sancho learning from 'magician' Cristiano Ronaldo
 - [https://www.bbc.co.uk/sport/av/football/60515992?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/60515992?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 06:14:46+00:00

Manchester United's Jadon Sancho tells Football Focus that he was initially "stunned" to become a team-mate of Cristiano Ronaldo and describes the Portugal forward as "a magician".

## The Duke: Why my family stole a masterpiece portrait
 - [https://www.bbc.co.uk/news/entertainment-arts-60413468?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60413468?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 05:38:26+00:00

The real-life family secrets behind the new Jim Broadbent and Dame Helen Mirren film The Duke.

## Risk of vaccine side-effects vanishingly small, a year on
 - [https://www.bbc.co.uk/news/health-60468900?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60468900?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 02:15:39+00:00

Despite concerns over Covid vaccines, most side effects occur with hours or weeks of having a jab.

## Covid: Millions of vaccine doses destroyed in England
 - [https://www.bbc.co.uk/news/health-60506579?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60506579?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 01:35:38+00:00

Nearly two million were AstraZeneca shots that advisers said should not be given to younger adults.

## Rape cases should be tried in specialist courts, says report
 - [https://www.bbc.co.uk/news/uk-60496001?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60496001?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 01:24:46+00:00

Watchdogs say rape victims are being failed by a system beset by delays and poor communication.

## Noor Muqaddam: The high society beheading that stunned a nation
 - [https://www.bbc.co.uk/news/world-asia-59995097?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-59995097?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 00:21:37+00:00

The murder of Noor Muqaddam by the son of one of Pakistan's richest families stunned the country.

## Hair salon for autistic children opens in Sheffield
 - [https://www.bbc.co.uk/news/uk-england-south-yorkshire-60512007?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-south-yorkshire-60512007?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 00:20:15+00:00

A salon in Sheffield opens a new sensory room with toys and special equipment.

## Ukraine invaded: Anti-war protests in Russian cities lead to arrests
 - [https://www.bbc.co.uk/news/world-60518268?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60518268?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 00:19:09+00:00

Russian police make hundreds of arrests after crowds demonstrate in support of Ukraine.

## How Taiwan used simple tech to help contain Covid-19
 - [https://www.bbc.co.uk/news/business-60461732?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60461732?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-25 00:07:04+00:00

The low-tech approach that helped Taiwan efficiently fight off coronavirus.


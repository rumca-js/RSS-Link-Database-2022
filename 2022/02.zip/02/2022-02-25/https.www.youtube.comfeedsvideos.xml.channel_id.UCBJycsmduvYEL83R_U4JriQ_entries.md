# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Galaxy Tab S8 Ultra: A Monster Tablet!
 - [https://www.youtube.com/watch?v=bTYV7aFC6KE](https://www.youtube.com/watch?v=bTYV7aFC6KE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-02-25 00:00:00+00:00

Megatablet. Hypertablet. Monster tablet. S8 Ultra.

That shirt!: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Tablet provided by Samsung for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


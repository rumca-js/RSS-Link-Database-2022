# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## The Evil Business of the Metaverse
 - [https://www.youtube.com/watch?v=_BTdfJ2MbU8](https://www.youtube.com/watch?v=_BTdfJ2MbU8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2022-02-26 00:00:00+00:00

There's a side to metaverse that you should know about...

Invest in blue-chip art for the very first time by signing up for Masterworks: https://masterworks.art/moon
Purchase shares in great masterpieces from artists like Pablo Picasso, Banksy, Andy Warhol, and more.
See important Masterworks disclosures: https://mw-art.co/37WwvbD.

TIMESTAMPS:
00:00 - Living in the metaverse by 2030
01:40 - Walking into the metaverse
06:48 - Masterworks
08:06 - Total Power
13:28 - The Metaverse Rabbit Hole
16:35 - Neuralink
20:01 - The End Game



The Metaverse will bring about a new age of crypto trading, business, NFT's, and investing. But there is another side to the Metaverse.....

This video goes over the metaverse and what it means for religion, economics, business, and society. There is lots of money and wealth to be made which is why Justin Bieber performed in the Metaverse and Snoop Dog is buying up land in the metaverse. This is how Metaverse makes money.  So watch as I explain the truth behind Facebook's meta rebranding and why Metaverse is bad.

#EvilBusinessoftheMetaverse #


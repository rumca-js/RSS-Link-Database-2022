# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Trudeau Claims Truckers Only Hate Him Because He's Black
 - [https://www.youtube.com/watch?v=9OQl2V_5SXs](https://www.youtube.com/watch?v=9OQl2V_5SXs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-02 00:00:00+00:00

Justin Trudeau just released this statement where he claims the truckers hate him because he's a brave he/him of color, eh?

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Exclusive: Biden Reveals List Of Possible SCOTUS Nominees
 - [https://www.youtube.com/watch?v=IgHIuaa5YDI](https://www.youtube.com/watch?v=IgHIuaa5YDI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-01 00:00:00+00:00

From Queen Latifah and Aunt Jemima to... Greta Thunberg? Biden reveals his list of possible appointments to the highest court in the land. The Babylon Bee has the scoop.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


## the new hire who showed up is not the same person we interviewed — Ask a Manager
 - [https://www.askamanager.org/2022/01/the-new-hire-who-showed-up-is-not-the-same-person-we-interviewed.html](https://www.askamanager.org/2022/01/the-new-hire-who-showed-up-is-not-the-same-person-we-interviewed.html)
 - RSS feed: https://www.askamanager.org
 - date published: 2022-02-01 08:47:47.625540+00:00

A reader writes: This is a situation currently unfolding at my husband's office so I’m a very amused bystander and thought I’d get your opinion on this


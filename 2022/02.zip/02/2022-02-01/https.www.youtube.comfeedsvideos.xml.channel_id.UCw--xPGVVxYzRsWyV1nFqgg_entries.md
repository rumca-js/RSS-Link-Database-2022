# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## What If Luffy Found The ONE RING?☠️
 - [https://www.youtube.com/watch?v=wOtX3L5RGlc](https://www.youtube.com/watch?v=wOtX3L5RGlc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-02-02 00:00:00+00:00

What would happen if Luffy from #OnePiece found the One Ring from #LordoftheRings?
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## One Piece RESOLUTION🥤Halo Trailer😇Wheel of Time Charity -FANTASY NEWS!
 - [https://www.youtube.com/watch?v=UQZ8mEzBcss](https://www.youtube.com/watch?v=UQZ8mEzBcss)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-02-01 00:00:00+00:00

Let's jump into the FANTASY NEWS! 
Check out campfire today: https://www.campfirewriting.com/write/for-novelists?utm_source=youtube&utm_medium=video&utm_campaign=DG_Q1_22

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

NEWS: 

00:00 intro 

00:34 Halo Trailer: https://www.youtube.com/watch?v=5KZ3MKraNKY&ab_channel=ParamountPlus 

02:18 Nona the Ninth: https://twitter.com/TorDotComPub/status/1486716251363704834 

03:54 Malazan Sup-press release: https://twitter.com/SubPress/status/1486697253150547974 

04:39 Sony buys Bungie: https://twitter.com/Nibellion/status/1488210601142796290 

05:00 Wheel of Time Auction: CancerGetsLost.org 

05:23 Hourglass Throne cover: https://twitter.com/TTSPromo/status/1487108766160072706/photo/1 

06:07 IGN Audiobook: https://twitter.com/IGN/status/1488165431789723650?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Etweet 

07:07 Mary Shelley Biopic: https://variety.com/2022/film/news/fulwell-73-mary-shelley-frankenstein-1235165974/ 

08:01 One Piece Update: https://www.cbr.com/dragon-ball-one-piece-copyright-toei-animation-youtube/


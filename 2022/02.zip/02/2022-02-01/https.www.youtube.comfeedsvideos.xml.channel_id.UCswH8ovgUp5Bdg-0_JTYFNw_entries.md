# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Vaccine Passports: Increasing Global Surveillance Networks
 - [https://www.youtube.com/watch?v=_SyYMZ9UanM](https://www.youtube.com/watch?v=_SyYMZ9UanM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-02 00:00:00+00:00

Vaccine passports are being increasingly integrated into society – but are they the key to reanimating public life or the linchpin of a global surveillance network?
#VaccinePassport #Pandemic #Covid 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Don’t Be Stupid…Big Tech Planned ALL OF THIS! [PROOF]
 - [https://www.youtube.com/watch?v=VPVi1K7P9Ck](https://www.youtube.com/watch?v=VPVi1K7P9Ck)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-01 00:00:00+00:00

Professor Shoshana Zuboff explains how Google ALWAYS intended to be what it 
is today - a company that harvests our personal information as covertly as possible and invade our privacy for profit. They pretended that they are a service we could use but really 
they are using us. Are we only just starting to realise how bad it is now?!

#Google #BigTech #Surveillance #Data  

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Joe Rogan & Spotify Controversy
 - [https://www.youtube.com/watch?v=tLwVvtL4mTI](https://www.youtube.com/watch?v=tLwVvtL4mTI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-02-01 00:00:00+00:00

As Joe Rogan addresses controversy over his Spotify podcast, are there other factors at play when it comes to the movement to cancel him? 
#JoeRogan #misinformation #spotify #NeilYoung #cancel

Watch Breaking Points brilliant video on this topic here: https://www.youtube.com/watch?v=Z-AEmqvyikM&ab_channel=BreakingPoints

Read Jacobin's article here: https://www.jacobinmag.com/2022/01/joe-rogan-podcast-covid-misinformation-cdc-media

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


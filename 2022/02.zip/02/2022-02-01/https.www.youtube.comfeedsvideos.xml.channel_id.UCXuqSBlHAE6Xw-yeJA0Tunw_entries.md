# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Wait 'til you see the Bent Motherboard... - Streacom DB1 Max
 - [https://www.youtube.com/watch?v=rZ72mj1WgS0](https://www.youtube.com/watch?v=rZ72mj1WgS0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-02 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Get your custom pre-built PC with NZXT BLD: https://nzxt.co/LTTFeb2022

The Streacom DB1 Max is a teeny tiny case with BIG dreams – can it FANLESSLY dissipate the 65 watts of heat it claims? 

Discuss on the forum: https://linustechtips.com/topic/1408842-the-case-is-the-cooler-streacom-db1-max-fanless-pc/

Buy Streacom DB1
  Newegg: https://geni.us/pWqX0A

Buy ASRock thin-ITX motherboard
  Newegg: https://geni.us/HwMhTtJ

Buy AMD Ryzen 7 5700G
  Amazon: https://geni.us/5byXTS
  Best Buy: https://geni.us/gIZN
  Newegg: https://geni.us/Mhd0

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
2:23 Components
5:17 Build
6:19 Cooler adventure
7:15 Thermal paste intensifies
9:17 Instructions unclear: motherboard taco
10:14 Stress testing
12:28 3 weeks later
13:15 Stress testing... again
14:43 Closing remarks

## Fixing what YouTube couldn’t. - ThioJoe Spammer Purge
 - [https://www.youtube.com/watch?v=zo_uoFI1WXM](https://www.youtube.com/watch?v=zo_uoFI1WXM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-01 00:00:00+00:00

Thanks to MANSCAPED for sponsoring today's video! Get 20% OFF + Free Shipping at https://manscaped.com/TECH

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

YouTube’s spam problem has gotten out of hand… And it’s up to the community once again to do what YouTube can’t. Thankfully, the community has delivered…

https://github.com/ThioJoe/YT-Spammer-Purge
https://www.youtube.com/watch?v=2tRppXW_aKo
https://www.youtube.com/watch?v=c6ebWvay8dE

Discuss on the forum: https://linustechtips.com/topic/1408574-fixing-what-youtube-couldn%E2%80%99t/

Buy a Seasonic Ultra Titanium Power Supply:
On Amazon: https://geni.us/q4lnefC
On NewEgg: https://lmg.gg/8KV3S

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:45 How YouTube filters Spam
2:19 The Solution
3:25 How it works
5:24 Using it on LTT Videos
7:30 Users have a role to play!
8:23 LTT's Plan..
9:16 Why didn't YouTube do this?
11:04 Outro


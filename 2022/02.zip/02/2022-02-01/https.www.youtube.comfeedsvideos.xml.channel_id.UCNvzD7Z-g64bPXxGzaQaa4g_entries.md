# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 WEIRD Gaming Stories of January 2022
 - [https://www.youtube.com/watch?v=_u93aE6Oh3E](https://www.youtube.com/watch?v=_u93aE6Oh3E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-02-01 00:00:00+00:00

January 2022 saw no shortage of wild and strange gaming news stories. Here are some of our favorite weird ones.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources:

https://news.yahoo.com/singaporean-dad-20-000-debt-000556614.html

https://www.invenglobal.com/articles/16126/lapd-officers-fired-for-ignoring-robbery-to-catch-a-snorlax-in-pokemon-go

https://www.techradar.com/in/news/play-ps5-games-one-handed-with-custom-controller-adapter

https://interestingengineering.com/a-turkish-farmer-tests-out-vr-goggles-on-cows-to-get-more-milk

https://www.reddit.com/r/gaming/comments/sdxfmk/nms_developer_hello_games_made_a_remaster_of_a/

https://gameranx.com/updates/id/285256/article/ps5-and-xbox-series-x-scalper-jack-bayliss-claims-hes-creating-young-entrepreneurs/

https://kotaku.com/final-fantasy-vii-porn-interrupts-government-meeting-1848378136

https://www.youtube.com/watch?v=jeP9h8uF-UI&ab_channel=DanteLive4game
-------
https://www.facebook.com/groups/LogitechGOfficialCommunity/posts/1831003083759647/
------
https://kotaku.com/botw-zelda-impossible-arrow-shock-nintendo-switch-legen-1848412649


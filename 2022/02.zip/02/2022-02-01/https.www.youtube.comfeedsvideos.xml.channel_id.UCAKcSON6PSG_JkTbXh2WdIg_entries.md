# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Listen to Looch: Janet Jackson is amazing. The 'JANET' documentary? Not so much
 - [https://www.youtube.com/watch?v=oWx6LJrMNCw](https://www.youtube.com/watch?v=oWx6LJrMNCw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-02 00:00:00+00:00

This week, Mary Lucia talks about the two-part series JANET, the Janet Jackson documentary, airing and streaming now on A&E and Lifetime. 

"I'm not going to get too deep into it because it itself is not too deep," Mary says. Highlights include Jackson's return to her hometown of Gary, Indiana, and the reels and reels of performance footage from the earliest days right up to now. 

"Janet Jackson is amazing," Mary continues, but finds aspects of the documentary a little disappointing. Watch more of what Mary Lucia has to say in the video above. 

More Listen to Looch:
https://youtube.com/playlist?list=PLYClJc3TpV5J_sXyCfes-p6vCgOpCmleh

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#janetjackson #janetdocumentary #JanetJacksonDoc

## Arlo Parks - three song performances (2021)
 - [https://www.youtube.com/watch?v=sy9TEx4nstw](https://www.youtube.com/watch?v=sy9TEx4nstw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-01 00:00:00+00:00

One year ago, London singer-songwriter Arlo Parks connected with The Current for a session hosted by Jill Riley in which Parks performed songs from her debut album, "Collapsed in Sunbeams." Watch those performances.

SONGS PERFORMED
0:00 "Hope"
4:20 "Hurt"
7:22 "Green Eyes"

PERSONNEL
Arlo Parks – vocals
Alex Blake – guitar 

FIND MORE:
2021 virtual session: https://www.thecurrent.org/feature/2021/02/26/arlo-parks-virtual-session
2021 January 25 Album of the Week, "Collapsed in Sunbeams": https://www.thecurrent.org/feature/2021/01/24/album-of-the-week-arlo-parks-collapsed-in-sunbeams

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#arloparks #alexblakeguitar


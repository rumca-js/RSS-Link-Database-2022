# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## How Movies & Video Games Trick Your Brain
 - [https://www.youtube.com/watch?v=nR2YJN4OEL4](https://www.youtube.com/watch?v=nR2YJN4OEL4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2022-02-01 00:00:00+00:00

Thank you to Wren for supporting PBS. To learn more, go to https://wren.co/start/besmart 
We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart
↓↓↓ More info and sources below ↓↓↓

Movies. Video games. YouTube videos. All of them work because we accidentally figured out a way to fool your brain’s visual processing system, and you don’t even know it’s happening. In this video, I talk to neuroscientist David Eagleman about the secret illusions that make the moving picture possible.

Thank you to The Slow-Mo Guys for sharing some incredible footage with us. Here are the full videos:
https://youtu.be/3BJU2drrtCM 
https://youtu.be/omuRkUFnnv4 
https://youtu.be/eJVpYL44jUQ 

References and sources: 
https://sites.google.com/view/be-smart-illusion-of-video/home 

-----------

Special thanks to our Brain Trust Patrons:

Mehdi Damou
Barbora Bei
Ken Board
The Clinger-Hamilton Family
Attila Pix
Burt Humburg
DeliciousKashmiri
Brian Chang
Roy Lasris
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Amy Sowada
Eric Meer
Dustin
Karen Haskell
AlecZero

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/


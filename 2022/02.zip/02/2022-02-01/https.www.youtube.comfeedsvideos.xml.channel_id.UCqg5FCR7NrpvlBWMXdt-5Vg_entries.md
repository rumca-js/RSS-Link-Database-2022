# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Dying Light 2 Stay Human | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=IunQqBfNqq4](https://www.youtube.com/watch?v=IunQqBfNqq4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-02-02 00:00:00+00:00

Marty Sliva reviews Dying Light 2, developed by Techland.

Dying Light 2 on Steam: https://store.steampowered.com/app/534380/Dying_Light_2_Stay_Human/

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Praey for the Gods (Zero Punctuation)
 - [https://www.youtube.com/watch?v=wOoRFZ-fFWo](https://www.youtube.com/watch?v=wOoRFZ-fFWo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-02-02 00:00:00+00:00

This week on Zero Punctuation, Yahtzee reviews Praey for the Gods.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## We've Finished Dying Light 2 - Did It Live Up to Expectations? | Breakout
 - [https://www.youtube.com/watch?v=OcUWJvkcTc0](https://www.youtube.com/watch?v=OcUWJvkcTc0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-02-02 00:00:00+00:00

This week on Breakout we candidly discuss our impressions on Dying Light 2, Pokémon Legends: Arceus and take a look at Sony's acquisition of Bungie.

Featuring Nick Calandra, Marty Sliva and KC Nwosu, the freeform podcast dives into a bit of our daily lives, the latest games, movies, tv shows and books, the occasional craft beer review and random topics we find interesting.

New episodes every Wednesday morning from 9 AM to 10:00 AM CT. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---

Timestamps
Dying Light 2 discussion - 1:00
Pokemon Legends discussion - 30:00
Bungie acquisition discussion - 52:00

---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Yahtzee and Marty Play Five Nights at Freddy's: Security Breach | Post-ZP Stream
 - [https://www.youtube.com/watch?v=4_0QyVIHKDw](https://www.youtube.com/watch?v=4_0QyVIHKDw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-02-02 00:00:00+00:00

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Yahtzee plays two hours of Five Nights at Freddy's: Security Breach for today's Post-ZP Stream.

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist​

Want to see the next episode a week early? Check out http://www.escapistmagazine.com​ for the latest episodes of your favorite shows.

---



---


The Escapist Merch Store ►►https://teespring.com/stores/the-esca...​
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag​
Follow us on Twitter ►► https://twitter.com/EscapistMag

#ZeroPunctuation

## Bloodborne PSX | Hidden Gems with KC and Jesse
 - [https://www.youtube.com/watch?v=11OPmcFxBXk](https://www.youtube.com/watch?v=11OPmcFxBXk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-02-01 00:00:00+00:00

Starting this Tuesday, each week KC, Jesse, Amy or Will, will be checking out a new recently released indie game that they think you shouldn't skip out on. This week, we're checking out Bloodborne PSX, a demake of Bloodborne.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Dark Souls the TTRPG Is Using D&D Rules and That's Dumb | Slightly Something Else
 - [https://www.youtube.com/watch?v=tdSdCog6qQ8](https://www.youtube.com/watch?v=tdSdCog6qQ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-02-01 00:00:00+00:00

This week on Slightly Something Else, Yahtzee and Jack discuss the recent announcement that the Dark Souls TTRPG will be using D&D rules and why that's dumb. 

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


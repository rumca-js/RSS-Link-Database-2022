# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## The TRUTH about Joe Rogan, Spotify, and Misinformation!
 - [https://www.youtube.com/watch?v=720IZhRU-Jw](https://www.youtube.com/watch?v=720IZhRU-Jw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-02-02 00:00:00+00:00

Grab your Red/Blue Light Teeth Whitening Kit at https://naturalteethwhiteners.com/jp

Check Out My Merch Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

With all the controversy surrounding Joe Rogan and his podcast, Spotify, misinformation, and the attempts to get Spotify to de-platform him, there’s a lot to keep track of. What’s true and what’s false? In this video, find out the truth about Joe Rogan, Spotify, and misinformation!

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

## The Canadian Truckers CAN'T Be Stopped!
 - [https://www.youtube.com/watch?v=Sl88jzJK1Rs](https://www.youtube.com/watch?v=Sl88jzJK1Rs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-02-01 00:00:00+00:00

Grab your EMF Blocking Products at https://blublox.com/jp
Use Code "JP" for 15% Off!

Check Out My Merch Here - https://awakenwithjp.com

Take a stand against censorship. Join my Awakened Warriors Email List - https://awakenwithjp.com/joinme

The Canadian truckers can’t be stopped! A freedom convoy of over 50,000 truckers are protesting Prime Minister Justin Trudeau‘s mandates. The truckers are crusading for their Nation's freedom. Will they succeed? Here is everything you need to know.

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC
Also available everywhere else you get podcasts. Just search and subscribe to "Awaken With JP Sears Show"

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com


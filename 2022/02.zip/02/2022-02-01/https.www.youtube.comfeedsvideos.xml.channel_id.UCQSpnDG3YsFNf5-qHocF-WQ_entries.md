# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## The New 5G C-Band is a BIG Deal (But What Is It?)
 - [https://www.youtube.com/watch?v=Eb7QM5w1uLA](https://www.youtube.com/watch?v=Eb7QM5w1uLA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-02-02 00:00:00+00:00

Get paid to recommend products to friends with Recommate! ⇨ https://recommate.onelink.me/KIAp/ThioJoe (Sponsored)

▼ Time Stamps: ▼
0:00 - Intro
2:41 - A Bit About Cell Frequencies
6:05 - Why Mid-Band?
7:22 - The FCC Opens Up C-Band
9:37 - C-Band Clearing Plan
11:37 - How the Auction Worked
12:21 - The Auction Results
14:13 - Auction 110
15:18 - Current Status of Carriers

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


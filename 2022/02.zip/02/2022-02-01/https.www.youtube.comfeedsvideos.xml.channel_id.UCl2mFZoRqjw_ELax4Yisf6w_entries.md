# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## NATIONWIDE Right to Repair bill presented by Senator Jon Tester; a farmer that went into politics.
 - [https://www.youtube.com/watch?v=uTluk7QzHaM](https://www.youtube.com/watch?v=uTluk7QzHaM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-02 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.tester.senate.gov/?p=press_release&id=8866
https://youtu.be/aB_xSiGIL1s
00:00 Intro
15:54 Spicy emissions talk

## Tesla disabling seat motor if you use it too much. Who needs evidence? We have an UNCONFIRMED RUMOR!
 - [https://www.youtube.com/watch?v=pl3ohUbH18E](https://www.youtube.com/watch?v=pl3ohUbH18E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-02 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.theverge.com/2022/1/31/22911072/tesla-seat-controls-disable-lock-out-brose
🔵 https://youtu.be/oNl2q6YZXlA
🔵 https://youtu.be/xKEdi6vXMrU
🔵 https://youtu.be/YzDE7ipLcW0
 
👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

## You all made a difference, thank you.
 - [https://www.youtube.com/watch?v=Mr6yo0mdxJg](https://www.youtube.com/watch?v=Mr6yo0mdxJg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-02 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://malegislature.gov/Committees/Detail/J17/192/Bills/asc/EntityNumber/S.166?current=False&pageNumber=1
https://youtu.be/xBStv83ilZc
https://youtu.be/Z10lcK82hqs

## Meet Clinton, the best cat in the world ❤️
 - [https://www.youtube.com/watch?v=4q9o0-oPPTk](https://www.youtube.com/watch?v=4q9o0-oPPTk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-01 00:00:00+00:00

https://tinyurl.com/rossmatrix

## NYC bus driver gets $400k bill for back property taxes due to bureaucratic comedy of errors
 - [https://www.youtube.com/watch?v=uXk8Fy4d8m8](https://www.youtube.com/watch?v=uXk8Fy4d8m8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-01 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.bloomberg.com/features/2022-new-york-real-estate-property-tax-reform

https://www.bloomberg.com/graphics/2021-new-york-property-tax-benefits-rich

https://comptroller.nyc.gov/reports/annual-state-of-the-citys-economy-and-finances/

https://www.youtube.com/watch?v=yi8_9WGk3Ok

## New variant of COVID 33% more infectious; is your business prepared?
 - [https://www.youtube.com/watch?v=aX_o-p8bTXY](https://www.youtube.com/watch?v=aX_o-p8bTXY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-01 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://www.reuters.com/business/healthcare-pharmaceuticals/omicron-subvariant-ba2-more-infectious-than-original-danish-study-finds-2022-01-31/
https://www.cbsnews.com/news/covid-omicron-subvariant-ba2-vaccine-booster-dr-agus/
https://www1.nyc.gov/site/doh/covid/covid-19-data.page#daily
https://www.google.com/search?q=ny+covid+cases&oq=ny+covid+cases&aqs=chrome..69i57j69i64j69i60l3.4192j0j7&sourceid=chrome&ie=UTF-8
https://www.google.com/search?q=ny+covid+deaths&oq=ny+covid+deaths&aqs=chrome..69i57j69i64.1425j0j7&sourceid=chrome&ie=UTF-8


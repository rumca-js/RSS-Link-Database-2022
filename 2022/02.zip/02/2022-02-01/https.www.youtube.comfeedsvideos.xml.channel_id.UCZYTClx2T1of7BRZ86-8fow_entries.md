# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Can Your Cat Change Color?
 - [https://www.youtube.com/watch?v=GYeDTTb4jYI](https://www.youtube.com/watch?v=GYeDTTb4jYI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-02-01 00:00:00+00:00

Visit brilliant.org/scishow/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.

Brown cats are something of a rarity, but you may have something pretty close. 

Hosted by: Michael Aranda

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Dr. Melvin Sanicas, Sam Lutfi, Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Nazara, Ash, Jason A Saslow, Matt Curls, Eric Jensen, GrowingViolet, Jeffrey Mckishen, Christopher R Boucher, Alex Hackman, Piya Shedden, charles george, Tom Mosner, Jeremy Mysliwiec, Adam Brainard, Chris Peters, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:

https://medlineplus.gov/genetics/gene/tyr/

https://www.sciencedirect.com/topics/materials-science/amino-acids 
 
https://medlineplus.gov/ency/article/002222.htm 
 
https://academic.oup.com/jhered/article/96/4/289/2187996

https://www.ncbi.nlm.nih.gov/books/NBK459156/ 

https://vgl.ucdavis.edu/test/brown-cat 

https://link.springer.com/article/10.1007/s00335-004-2455-4 

https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1748-5827.2001.tb01798.x

https://academic.oup.com/jn/article/132/7/2037/4687395

IMAGES

https://commons.wikimedia.org/wiki/File:Havana_Brown_-_c_h_o_c_o_c_a_t.jpg
https://www.istockphoto.com/photo/beautiful-short-hair-cat-gm1143489763-307095161
https://www.istockphoto.com/photo/stunning-black-kitten-the-amanda-collection-gm820785324-134117433
https://www.istockphoto.com/photo/black-cat-on-a-hand-made-cat-tree-gm1161122878-318042059
https://www.istockphoto.com/photo/cinnamon-color-adorable-british-shorthair-cat-resting-gm1312932174-401580573
https://www.istockphoto.com/photo/feeding-little-cat-with-milk-replacer-gm1219352008-356640150


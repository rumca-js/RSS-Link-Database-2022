# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Daniel Falconer talks designing Lord of the Rings, Guillermo del Toro's Hobbit, Wētā, and more!
 - [https://www.youtube.com/watch?v=2IyrIuuiW10](https://www.youtube.com/watch?v=2IyrIuuiW10)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-02-01 00:00:00+00:00

A conversation with Daniel Falconer, Collectibles Art Director of Wētā Workshop.  He was also a designer on The Lord of the Rings and wrote the fantastic behind-the-scenes books "The Hobbit Chronicles" and "From Script to Screen: Building the World of The Lord of the Rings and The Hobbit".  We chat about his time designing Middle-earth, a possible behind-the-scenes book for Guillermo del Toro's Hobbit, adapting Tolkien, and more!

The Hobbit Chronicles (vol 1): https://amzn.to/3rI96nP
From Script to Screen book: https://amzn.to/3KCtxew
An Unexpected Party Board Game: https://amzn.to/32mH8p8

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

#lordoftherings #wetaworkshop #lotr20


# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Meta Quest 2 gets another MASSIVE Update! Zenith is INSANE!
 - [https://www.youtube.com/watch?v=8zGRCIXb3Rc](https://www.youtube.com/watch?v=8zGRCIXb3Rc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-02-02 00:00:00+00:00

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire week's worth of VR news! 
Today we'll be talking about the Half Dive, Zenith a new VR MMORPG, V37 a pretty big quest 2 update, and a ton more! Hope you enjoy this week's VR news!

Also, Zenith giveaway in my discord server and Twitch stream today! 
Discord.gg/Thrill
Twitch.tv/Thrilluwu

00:00 INTRO
00:43 HALF DIVE
02:05 ZENITH
05:07 V37 UPDATE
08:01 MEME BREAK
08:21 BEAT SABER
09:16 MAGIC LEAP
11:03 HIDEO KOJIMA
11:34 OUTRO


# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## The Tragic Tale of Twitter
 - [https://www.youtube.com/watch?v=7NXr-8rIOg8](https://www.youtube.com/watch?v=7NXr-8rIOg8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2022-02-01 00:00:00+00:00

Why did Twitter become so toxic?

Invest in blue-chip art for the very first time by signing up for Masterworks: https://masterworks.art/moon
Purchase shares in great masterpieces from artists like Pablo Picasso, Banksy, Andy Warhol, and more.
See important Masterworks disclosures: https://mw-art.co/37WwvbD.
.........

TIMSTAMPS:

00:00 - What happened to Twitter?
01:32 - The Origins
04:50 - The Consequences
06:07 - Hijacked Twitter
09:19 - Censorship
11:23 - Political Control
12:40 - Masterworks
14:15 - Twitter Today
16:15 - The Future of Twitter

Twitter is really bad because the business of Twitter relies on making money and billions in investments through censorship. The economics of Twitter is truly bad, and that's why Twitter is so toxic and destroyed society.

#TwitterRuinedSociety #Moon


# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Ukrainian civilians train for war as invasion fears grow
 - [https://www.bbc.co.uk/news/world-europe-60220422?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60220422?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 22:38:48+00:00

Many civilians are not convinced Russia will invade, but say all the war talk is unsettling.

## Under-pressure Johnson takes to world stage with Ukraine visit
 - [https://www.bbc.co.uk/news/uk-politics-60222559?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60222559?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 21:43:44+00:00

The PM emphasises Western unity as he visits Ukraine amid fears of a Russian invasion.

## First airing for news bulletin The Catch Up as BBC Three returns
 - [https://www.bbc.co.uk/news/uk-60222550?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60222550?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 21:21:50+00:00

BBC Three has returned as a fully-fledged TV channel, six years after it moved online.

## Almost 500-mile-long lightning bolt crossed three US states
 - [https://www.bbc.co.uk/news/world-us-canada-60221521?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60221521?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 20:34:10+00:00

Experts said the bolt that stretched across Mississippi, Louisiana, and Texas was 'extraordinary'.

## The myth of a 'super-charged' immune system
 - [https://www.bbc.co.uk/news/health-60171592?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60171592?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 20:31:27+00:00

Suddenly we are all talking about immunity but how much do we really understand?

## Tom Brady retires: Watch touchdown passes from his early play-off and Super Bowl wins
 - [https://www.bbc.co.uk/sport/av/american-football/60223981?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/american-football/60223981?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 19:45:38+00:00

Watch a young Tom Brady's early post-season and Super Bowl touchdown passes, as the three-time NFL MVP announces his retirement at the age of 45.

## How HIV elimination is within Australia's reach
 - [https://www.bbc.co.uk/news/world-australia-59764592?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-59764592?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 16:22:43+00:00

Australian HIV cases have hit an all-time low - and it's partly a legacy of unconventional strategy.

## UK weather: Why January 2022 was a record breaker
 - [https://www.bbc.co.uk/weather/features/60216565?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/weather/features/60216565?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 16:18:31+00:00

The start of the year has bucked trends and brought extreme conditions from warmth and sunshine to low rainfall, cloud and storms.

## Covid-19: How many people have been infected more than once?
 - [https://www.bbc.co.uk/news/health-60174478?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60174478?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 14:42:39+00:00

Reinfections have been rising sharply with Omicron, and they've now been added to official daily data.

## Sue Gray: Boris Johnson focused on saving his own skin, says Keir Starmer
 - [https://www.bbc.co.uk/news/uk-politics-60213173?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60213173?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 11:54:05+00:00

But deputy PM Dominic Raab says Boris Johnson has apologised and promised action to fix the running of No 10.

## Stamps join the digital world with barcodes
 - [https://www.bbc.co.uk/news/uk-60213179?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60213179?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 11:51:22+00:00

People receiving mail will be able to watch videos and, in the future, greetings from senders.

## Met Police: Watchdog slams misogyny and bullying within ranks
 - [https://www.bbc.co.uk/news/uk-england-london-60215575?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-60215575?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 11:44:33+00:00

The police watchdog focused on behaviour by mostly PCs based at Charing Cross Police station.

## Tesco puts 1,600 jobs at risk as it ends overnight restocking
 - [https://www.bbc.co.uk/news/business-60213085?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60213085?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 11:14:57+00:00

The supermarket's plans will mean the end of overnight restocking at some of its stores.

## 'Words can't describe how happy I am' - 16-year-old Heffernan joins AC Milan
 - [https://www.bbc.co.uk/sport/football/60214528?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60214528?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 11:07:41+00:00

Republic of Ireland defender Cathal Heffernan says "words can't describe" how happy he is at joining AC Milan on loan from Cork City.

## All US federal prisons in lockdown after deadly gang fight
 - [https://www.bbc.co.uk/news/world-us-canada-60090865?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60090865?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 10:49:49+00:00

The rare nationwide lockdown of federal prisons comes after two inmates died in a fight in Texas.

## House prices see fastest growth rate in January for 17 years
 - [https://www.bbc.co.uk/news/business-60213084?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60213084?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 09:56:17+00:00

Prices last month were up 11.2% from a year earlier, but Nationwide predicts the market will slow in 2022.

## Will travel return to normal this summer?
 - [https://www.bbc.co.uk/news/business-60208461?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60208461?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 09:42:49+00:00

Travel bosses predict a bounce back for business this summer but challenges to recruit enough staff remain.

## Moses J Moseley: 'Kind and wonderful' The Walking Dead actor dies at 31
 - [https://www.bbc.co.uk/news/entertainment-arts-60213523?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60213523?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 09:39:22+00:00

Tributes are paid to "kind and wonderful" Moses J Moseley, who was a pet zombie on the horror show.

## Curry scores 40 points as Warriors win sixth consecutive game
 - [https://www.bbc.co.uk/sport/basketball/60200633?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/basketball/60200633?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 08:19:18+00:00

Stephen Curry scores 40 points as the Golden State Warriors beat the Houston Rockets 122-108 to win their sixth game in a row.

## Fury v Whyte will be 'absolute madness'
 - [https://www.bbc.co.uk/sport/boxing/60204798?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/60204798?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 08:03:22+00:00

Tyson Fury predicts he will knockout Dillian Whyte as fans react to heavyweight clash, plus Katie Taylor and Amanda Serrano set for blockbuster bout and more in this week's Fight Talk.

## Winter Olympics: Matt Edmondson and Mollie King go head-to-head in skeleton challenge
 - [https://www.bbc.co.uk/sport/av/winter-olympics/60114072?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/winter-olympics/60114072?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 05:59:32+00:00

BBC Radio 1 presenters Mollie King and Matt Edmondson go head-to-head in a skeleton challenge.

## Free Spirits: Team GB snowsport athletes describe the perils of the job
 - [https://www.bbc.co.uk/sport/av/winter-olympics/60202160?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/winter-olympics/60202160?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 05:57:54+00:00

Team GB's James Woods, Katie Ormerod, Kirsty Muir and Katie Summerhayes recount their list of injuries.

## The Papers: 'Failure of leadership' and 'zero shame'
 - [https://www.bbc.co.uk/news/blogs-the-papers-60208827?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60208827?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 05:36:34+00:00

Sue Gray's update into her No 10 lockdown parties investigation dominates the newspaper headlines.

## Whoopi Goldberg criticised for Holocaust remarks
 - [https://www.bbc.co.uk/news/world-us-canada-60209527?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60209527?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 03:31:02+00:00

The American TV personality later apologises after saying the Holocaust "was not about race".

## Lawford: The village where the women are still in charge
 - [https://www.bbc.co.uk/news/uk-england-essex-60168712?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-60168712?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 01:34:37+00:00

In 1925, a newspaper article told how a village was "run by women". What is it like there today?

## Boris Johnson visits Ukraine for talks as Russian invasion fears rise
 - [https://www.bbc.co.uk/news/uk-politics-60204847?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60204847?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 01:16:05+00:00

The UK PM will hold talks designed to avert war, while Russia masses tens of thousands of troops.

## Austria's Covid vaccine law comes into force amid resistance
 - [https://www.bbc.co.uk/news/world-europe-60155635?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60155635?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 00:55:30+00:00

The country is the first in Europe to make vaccination against Covid-19 mandatory for over-18s.

## Earth has more tree species than we thought
 - [https://www.bbc.co.uk/news/science-environment-60198433?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-60198433?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 00:34:01+00:00

There are more tree species than previously thought but mostly in fast disappearing forests.

## Six transfer window talking points
 - [https://www.bbc.co.uk/sport/football/60203467?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60203467?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 00:24:08+00:00

Which Premier League club had the perfect winter window? And who has missed out? Phil McNulty has his say.

## Wordle: New York Times buys popular word game
 - [https://www.bbc.co.uk/news/business-60208463?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60208463?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 00:16:05+00:00

The New York Times says it bought the game from its creator for a price “in the low seven figures".

## Measles warning for children as jab rate falls in England
 - [https://www.bbc.co.uk/news/health-60200774?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60200774?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 00:10:27+00:00

MMR vaccine rates have fallen to their lowest level in a decade, data for England reveals.

## Lyme disease: Man spent £25,000 before getting diagnosis
 - [https://www.bbc.co.uk/news/uk-wales-60202952?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60202952?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 00:06:20+00:00

Steven Williams, 36, said his fit, active life was "totally devastated" by the struggle for answers.

## Winter Olympics: James Woods & the 'internal battle' when counter culture meets elite sport
 - [https://www.bbc.co.uk/sport/winter-olympics/60083316?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-olympics/60083316?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 00:04:44+00:00

James Woods left home at 15 to follow his dream. Now he's an 'old man' of a rapidly changing sport, with one more shot at Olympic success.

## Longleat welcomes first southern koala joey
 - [https://www.bbc.co.uk/news/science-environment-60204104?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-60204104?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 00:04:39+00:00

The joey was born six months ago at Longleat safari park but has only recently started leaving its mother’s pouch.

## Why cows may be hiding something but AI can spot it
 - [https://www.bbc.co.uk/news/business-59635186?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59635186?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-02-01 00:01:25+00:00

Farmers are using artificial intelligence to spot lameness in their herd before it gets serious.


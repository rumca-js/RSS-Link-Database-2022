# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## An Announcement!
 - [https://www.youtube.com/watch?v=L-BN9Db5QhY](https://www.youtube.com/watch?v=L-BN9Db5QhY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-02-01 00:00:00+00:00

We out here!
The site: https://mkbhd.com
The Studio: http://youtube.com/TheStudio
Shorts: https://www.youtube.com/channel/UC1DoqbBY6dl8CEMVV9SK2FA
Twitter: http://twitter.com/MKBHD


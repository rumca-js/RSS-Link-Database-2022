# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## Chained Woman in China - The True Story
 - [https://www.youtube.com/watch?v=68-GpzGS7ac](https://www.youtube.com/watch?v=68-GpzGS7ac)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2022-02-23 00:00:00+00:00

The woman found chained up in a shack in Eastern China has finally been confirmed to be who we all thought she was, but it goes much deeper than that. 

Daily Content from me and SerpentZA - China Fact Chasers (Subscribe!)
https://www.youtube.com/channel/UCwHPRkLWbL_guuBMGxKe2aQ

China Uncle Mikey's video on this topic - 
https://youtu.be/Gfhf5JC5ZPA

◘ Support me on Patreon to talk to me directly and support my work - http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C
◘ Odysee - http://odysee.com/@laowhy86

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music -
Big Bad Beats
https://www.youtube.com/c/bigbadbeats


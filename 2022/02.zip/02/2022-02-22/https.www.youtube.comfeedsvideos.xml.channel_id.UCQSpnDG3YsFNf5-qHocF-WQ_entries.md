# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## SSD Features Few People Know About (Learn These Before Buying)
 - [https://www.youtube.com/watch?v=8y7ZpFfZXeM](https://www.youtube.com/watch?v=8y7ZpFfZXeM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-02-23 00:00:00+00:00

Sponsored: Invest in blue-chip art for the very first time by signing up for Masterworks: https://masterworks.art/thiojoe
Purchase shares in great masterpieces from artists like Pablo Picasso, Banksy, Andy Warhol, and more.
See important Masterworks disclosures: https://www.masterworks.io/about/disclaimer

▼ Time Stamps: ▼
0:00 - Intro
2:41 - NVMe vs SATA
3:32 - Layers Per Cell
6:44 - DRAM in SSDs
9:19 - DRAM-less
9:51 - Host Memory Buffer
13:09 - Open Channel SSD
14:15 - Zoned Namespaces (ZNS)
16:10 - Endurance and Write Amplification

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Chef Daniel Holzman on Coffee Culture, Making Coffee "Right"
 - [https://www.youtube.com/watch?v=bA-Xx6daR_w](https://www.youtube.com/watch?v=bA-Xx6daR_w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-02-22 00:00:00+00:00

Taken from JRE #1782 w/Daniel Holzman:
https://open.spotify.com/episode/4pYZ2oatLSBAH7zptRXowB?si=cd33ade69b174eda

## Chef Daniel Holzman on The Best Way to Learn to Cook
 - [https://www.youtube.com/watch?v=LdE9u0-SwEY](https://www.youtube.com/watch?v=LdE9u0-SwEY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-02-22 00:00:00+00:00

Taken from JRE #1782 w/Daniel Holzman:
https://open.spotify.com/episode/4pYZ2oatLSBAH7zptRXowB?si=cd33ade69b174eda


# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Brave Great White Shark Allowed To Compete In Women's 500 Freestyle
 - [https://www.youtube.com/watch?v=Uhc4Um_CVxE](https://www.youtube.com/watch?v=Uhc4Um_CVxE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-23 00:00:00+00:00

A stunning and brave great white shark named Bruce was allowed to compete in the women's 500-yard freestyle and she is really making mincemeat out of the competition.

Follow Chandler's Youtube: https://www.YouTube.com/chandlerjuliet

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## Babylon Bee Weak-ly News Update 2/22/2022: Tyrannical Banking And The Last COVID-Free Place On Earth
 - [https://www.youtube.com/watch?v=CpFU09C-gGg](https://www.youtube.com/watch?v=CpFU09C-gGg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-02-22 00:00:00+00:00

Host Adam Yenser gives us the news of the week, including the Super Bowl Halftime Show, Canada going full potato over the trucker protest, and the last place on earth that is COVID-free.

Watch the full podcast here: https://www.youtube.com/watch?v=zRjMOkRffU8

Follow Adam on Youtube: https://www.youtube.com/user/adamyenser

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


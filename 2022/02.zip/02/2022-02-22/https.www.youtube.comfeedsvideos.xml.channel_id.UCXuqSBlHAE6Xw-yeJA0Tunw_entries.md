# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## NVIDIA REFUSED To Send Us This - NVIDIA A100
 - [https://www.youtube.com/watch?v=zBAxiQi2nPc](https://www.youtube.com/watch?v=zBAxiQi2nPc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-23 00:00:00+00:00

Get 50% Off the First Year of Bull Phish ID and 50% off setup at https://it.idagent.com/Linus

SmartDeploy: Claim your FREE IT software (worth $580!) at https://lmg.gg/Jpt4k

We've experienced a lot of crazy, top-of-the-line graphics cards on LinusTechTips, but we've been unable to get our hands on one famed card - the NVIDIA A100..... until now. ;)

Discuss on the forum: https://linustechtips.com/topic/1413995-nvidia-refused-to-send-us-this/
Fan Duct 3D Print File: https://www.thingiverse.com/thing:5145188

Buy an NVIDIA A100: https://geni.us/DfTh3c
Buy an MSI RTX 3090 Suprim X: https://geni.us/jPb6gB

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:06 How we got one, heh
1:58 Our contenders
2:38 A100 Specs
3:49 Teardown
8:38 Jake sucks at throwing
8:48 Buildup
9:43 Shroud
10:39 How to get it to boot
10:56 It works!
11:24 Blender
14:05 Can we trick windows into running games on it? & GPU-Z
15:27 Ethereum mining & afterburner options
16:45 Folding@Home
18:02 Resnet50 machine learning benchmark
18:59 Worlds most expensive lint roller
19:10 Resnet50 machine learning benchmark part 2
21:12 Closing thoughts

## I better not screw this up - Intel $5,000 Extreme Tech Upgrade
 - [https://www.youtube.com/watch?v=39Z00YkoUeA](https://www.youtube.com/watch?v=39Z00YkoUeA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-02-22 00:00:00+00:00

Thanks to Intel for continuing to sponsor this series! Check out Intel 12th Gen Processors at https://geni.us/Cb1jg

Discuss on the forum: https://linustechtips.com/topic/1413730-i-better-not-screw-this-up-intel-5000-extreme-tech-upgrade/


Check out Clarence's part list at https://lmg.gg/PGprr

Check out the Plugable UD-ULTC4K Docking Station: https://lmg.gg/cmoPv

Check out Chris Colfer's The Land of Stories book series: https://geni.us/DRXY

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

Special Intro by MBarek Abdelwassaa
https://www.instagram.com/mbarek_abdel/

CHAPTERS
---------------------------------------------------
0:00 Intro
1:17 Overview
2:46 Accounting
4:17 New Monitor
5:07 Pluggable Hub
7:56 Why Laptop?
8:45 Living Room
10:02 Books
11:19 Google Home
11:46 Living Room Upgrade
16:12 Speakers
21:19 Testing
22:54 Bed


## Mask Mandates Don’t Need to Make Sense - The Atlantic
 - [https://www.theatlantic.com/health/archive/2022/02/covid-mask-mandate-washington-dc/622860/](https://www.theatlantic.com/health/archive/2022/02/covid-mask-mandate-washington-dc/622860/)
 - RSS feed: https://www.theatlantic.com
 - date published: 2022-02-22 09:53:09+00:00

Mask Mandates Don’t Need to Make Sense - The Atlantic


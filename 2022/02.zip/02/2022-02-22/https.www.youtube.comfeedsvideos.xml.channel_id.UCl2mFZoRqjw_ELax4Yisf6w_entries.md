# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Dymo printers are putting DRM in the paper: WTF!
 - [https://www.youtube.com/watch?v=YJs9_xELKbI](https://www.youtube.com/watch?v=YJs9_xELKbI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-23 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.eff.org/deeplinks/2022/02/worst-timeline-printer-company-putting-drm-paper-now
🔵 https://www.amazon.com/s?k=dymo+450+labels&rh=p_85%3A2470955011&dc&crid=3PEEFTSQOEP4W&qid=1645587685&rnid=2470954011&sprefix=dymo+450+label%2Caps%2C65&ref=sr_nr_p_85_1
🔵 https://www.ilabmalta.com/dymo-labelwriter-550-2112552-2112722
🔵 https://www.amazon.com/gp/customer-reviews/R1582873D03Y93/ref=cm_cr_dp_d_rvw_ttl?ie=UTF8&ASIN=B08TLRL392
https://www.youtube.com/watch?v=N9VPk44zM78
🔵 https://www.youtube.com/watch?v=L0iqH5KcVM0

👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

👉 Discord: https://tinyurl.com/rossmatrix

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## NYC cleaning homeless out of subways to get ridership up; not gonna work. here's why.
 - [https://www.youtube.com/watch?v=zKsUEkhDSP8](https://www.youtube.com/watch?v=zKsUEkhDSP8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-23 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.bloomberg.com/news/articles/2022-02-22/nyc-begins-plan-to-move-homeless-from-subways-amid-crime-wave?sref=lagJc1td
 
👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio

## a quick favor, Connecticut residents
 - [https://www.youtube.com/watch?v=m38YqCDyOaI](https://www.youtube.com/watch?v=m38YqCDyOaI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-02-22 00:00:00+00:00

https://tinyurl.com/rossmatrix


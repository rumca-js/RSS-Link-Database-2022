# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Miloe Full Performance Jan. 22, 2022 (The Current's 17th Anniversary Party)
 - [https://www.youtube.com/watch?v=lugJbPmVzZY](https://www.youtube.com/watch?v=lugJbPmVzZY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-02-22 00:00:00+00:00

Watch #Minneapolis singer-songwriter Miloe play a #live set at The Current's 17th Anniversary, live from First Avenue in Minneapolis, Minn. Miloe performs a solo set of the sweet, distinctive songs that have earned him a growing national audience.

Songs Played:
03:46 Change Your Mind
07:16 Motorola
10:18 Marna
12:56 Winona
16:05 Greenhouse

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1

Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/


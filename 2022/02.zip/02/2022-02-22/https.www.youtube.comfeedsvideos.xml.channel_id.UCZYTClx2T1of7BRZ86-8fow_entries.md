# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Why Do Our Eyes Move When We Think?
 - [https://www.youtube.com/watch?v=m-42ek601jk](https://www.youtube.com/watch?v=m-42ek601jk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-02-22 00:00:00+00:00

Visit http://brilliant.org/scishow/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.

You might have heard the myth that you can tell when someone is lying based on how their eyes move. While that is not exactly true, there has been plenty of science that looks into where and how we look when we think.

Hosted by: Michael Aranda

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Bryan Cloer, Sam Lutfi, Kevin Bealer, Jacob, Christoph Schwanke, Jason A Saslow, Eric Jensen, Jeffrey Mckishen, Nazara, Ash, Matt Curls, Christopher R Boucher, Alex Hackman, Piya Shedden, Adam Brainard, charles george, Jeremy Mysliwiec, Dr. Melvin Sanicas, Chris Peters, Harrison Mills, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:
https://journals.sagepub.com/doi/abs/10.1177/0963721412436810
https://pubmed.ncbi.nlm.nih.gov/3887449/
https://journals.sagepub.com/doi/10.1111/1467-9280.02454
https://link.springer.com/article/10.3758/BF03195762
https://www.sciencedirect.com/science/article/pii/S0010027721000160
http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.475.6520&rep=rep1&type=pdf
https://www.nature.com/articles/s41598-017-10683-6
https://psycnet.apa.org/record/2003-00267-005
https://link.springer.com/article/10.3758/s13421-016-0639-2
https://www.frontiersin.org/articles/10.3389/fpsyg.2021.774961/full
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3394779/
https://www.frontiersin.org/articles/10.3389/fpsyg.2021.774961/full
https://onlinelibrary.wiley.com/doi/pdf/10.1111/cogs.12301
https://link.springer.com/article/10.3758/s13421-016-0639-2
https://www.washingtonpost.com/technology/2020/11/12/test-monitoring-student-revolt/
https://psycnet.apa.org/record/1976-21781-001

Image Sources:
https://www.storyblocks.com/video/stock/african-police-detective-showing-pictures-of-suspected-robbers-accomplice-in-the-background-there-is-a-female-detective-writing-notes-of-the-interrogation-rreayy-opkgmuti4g
https://www.storyblocks.com/video/stock/running-eyes-of-a-liar-or-a-worried-person-close-up-smkdyhkguk51evs7a
https://commons.wikimedia.org/wiki/File:This_shows_a_recording_of_the_eye_movements_of_a_participant_looking_freely_at_a_picture.webm
https://www.storyblocks.com/video/stock/afro-american-man-closed-eyes-close-up-face-of-black-man-close-up-bmya9gcrgjhdx7vk2
https://commons.wikimedia.org/wiki/File:Szakkad.jpg
https://www.istockphoto.com/photo/still-life-with-blue-bowl-ripe-apples-on-wooden-background-gm1252867440-365724065
https://www.storyblocks.com/video/stock/choker-shot-of-20-something-clean-shaven-arab-man-in-transparent-goggles-looking-at-something-with-active-rapid-eye-movements-video-suitable-for-adding-ar-vr-graphics-and-elements-sxtxvml8hk0eyqfp5
https://www.storyblocks.com/video/stock/beautiful-eye-with-glasses-close-up-isolated-on-white-background-b0mj63_pitmdct2k
https://www.storyblocks.com/video/stock/science-anatomy-scan-of-human-brain-and-nerves-glowing-rc28e6y2fjgairt9h
https://www.storyblocks.com/video/stock/police-detective-showing-photos-of-the-person-but-the-suspect-criminal-does-not-recognize-anyone-cop-questioning-offender-in-interrogation-room-hshuneq_pkgpezeyo


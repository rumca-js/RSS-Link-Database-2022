## World Economic Forum pushes digital ID system that will determine access to services
 - [https://reclaimthenet.org/world-economic-forum-pushes-digital-id](https://reclaimthenet.org/world-economic-forum-pushes-digital-id)
 - RSS feed: https://reclaimthenet.org
 - date published: 2022-02-22 18:58:40+00:00

World Economic Forum pushes digital ID system that will determine access to services


# Source:The Guardian, URL:https://www.theguardian.com/rss, language:en-UK

## Australian regulator finds large-scale emissions misreporting by coalminer Peabody
 - [https://www.theguardian.com/environment/2022/jan/31/australian-regulator-finds-large-scale-emissions-misreporting-by-coalminer-peabody](https://www.theguardian.com/environment/2022/jan/31/australian-regulator-finds-large-scale-emissions-misreporting-by-coalminer-peabody)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2022-01-30 16:03:24+00:00

<p>US giant agrees to hire auditors after calculation errors, poor record-keeping and inconsistent data collection discovered</p><p>US coalmining giant Peabody Energy has repeatedly submitted incorrect greenhouse gas emissions reports to the Australian government, prompting questions about the reliability of national climate data based on company assessments.</p><p>The Clean Energy Regulator found Peabody had a history of filing inaccurate reports required under the National Greenhouse and Energy Reporting Act due to calculation errors, poor record-keeping and inconsistent data collection and analysis.</p> <a href="https://www.theguardian.com/environment/2022/jan/31/australian-regulator-finds-large-scale-emissions-misreporting-by-coalminer-peabody">Continue reading...</a>

## Rafael Nadal: 21 grand slam salute – in pictures
 - [https://www.theguardian.com/sport/gallery/2022/jan/30/rafael-nadal-21-grand-slam-salute-in-pictures-tennis-australian-open](https://www.theguardian.com/sport/gallery/2022/jan/30/rafael-nadal-21-grand-slam-salute-in-pictures-tennis-australian-open)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2022-01-30 15:23:55+00:00

<p>Victory at the 2022 Australian Open thrusts Nadal ahead of Roger Federer and Novak Djokovic in the all-time men’s grand slam titles standings – we take a look back at the Spaniard’s triumphs</p> <a href="https://www.theguardian.com/sport/gallery/2022/jan/30/rafael-nadal-21-grand-slam-salute-in-pictures-tennis-australian-open">Continue reading...</a>


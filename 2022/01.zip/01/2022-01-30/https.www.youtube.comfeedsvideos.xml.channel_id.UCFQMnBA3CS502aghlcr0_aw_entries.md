# Source:Coffeezilla, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw, language:en-US

## This Famous Livestreamer Stole $500,000 From His Fans
 - [https://www.youtube.com/watch?v=A7MaoD4tJuc](https://www.youtube.com/watch?v=A7MaoD4tJuc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFQMnBA3CS502aghlcr0_aw
 - date published: 2022-01-31 00:00:00+00:00

I caught Ice Poseidon taking over $500,000 from the crypto project CXCOIN... so I confronted him about it. 

Paul Denino, or Ice Poseidon launched CXCOIN in July and told his skeptics that there was nothing to worry about... the money was "locked away"... this was a "long-term project". 

It turns out this was all a lie. Paul Denino, Ice Poseidon admits now on audio for the first time that he was not telling the truth about this being a long-term project... instead he worked on it for about "2 weeks". 

He took $200K from the presale wallet, there's now $250K from the marketing wallet that is missing and he admits to taking out over $290K from the liquidity pool of CXCOIN. 

When asked if he's going to return the money, Paul Denino said he's going to "look out for myself". Today we're exposing Ice Poseidon's TRUE intentions behind CXCOIN and why the project has now crashed.

IF YOU'VE BEEN SCAMMED BY CXCOIN, PLEASE REPORT YOUR LOSSES AND STORY TO https://www.ic3.gov
 
Follow Coffeezilla: 
► Twitter: https://twitter.com/coffeebreak_YT
► Instagram: https://www.instagram.com/coffeebreak_yt/
🎶 Music: https://www.youtube.com/watch?v=nMSQ1yoPT2c&list=PL4qw3AkxFDSNhEgawXD1j6r0iN1072XIB&index=1
Credits: 
3D Artist: Ed Leszczynski https://www.instagram.com/ed_leszczynski/
Video Editor: Harry Bagg  https://twitter.com/HarryBagg96

This video is an opinion and in no way should be construed as statements of fact. Scams, bad business opportunities, and fake gurus are subjective terms that mean different things to different people. I think someone who promises $100K/month for an upfront fee of $2K is a scam. Others would call it a Napoleon Hill pitch.


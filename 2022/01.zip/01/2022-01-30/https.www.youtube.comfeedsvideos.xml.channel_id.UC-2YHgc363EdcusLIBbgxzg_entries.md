# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Just How Screwed Are We If Thwaites Glacier Collapses? | Lightning Round
 - [https://www.youtube.com/watch?v=gMqpI4gpfVs](https://www.youtube.com/watch?v=gMqpI4gpfVs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-01-31 00:00:00+00:00

Visit http://www.brilliant.org/answerswithjoe to start learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.
Today I'm taking questions from the Answerphiles on Patreon. From questions about privacy to quantum physics to cosmology to the Antarctic Thwaites glacier that could doom us all, here's the quick and dirty lightning round answers for you.


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe


LINKS LINKS LINKS:
https://www.fastcompany.com/90694019/5-reasons-we-should-keep-daylight-savings-time-all-year

http://law2.umkc.edu/faculty/projects/ftrials/conlaw/rightofprivacy.html#:~:text=The%20Supreme%20Court%2C%20however%2C%20beginning,procreation%2C%20marriage%2C%20and%20termination%20of

https://constitutioncenter.org/interactive-constitution/amendment/amendment-xiv

https://www.aclu.org/blog/privacy-technology/location-tracking/supreme-courts-groundbreaking-privacy-victory-digital-age

https://news.mit.edu/2022/ultracold-atoms-quantum-0105

https://www.theguardian.com/environment/2021/nov/04/reality-check-global-co2-emissions-shooting-back-to-record-levels

https://www.cnn.com/2022/01/10/politics/us-fossil-fuel-emissions-coal-increased-2021-climate/index.html

https://interactive.pri.org/2019/05/antarctica/thwaites-glacier-collapse.html


TIMESTAMPS:
0:00 Intro
1:20 Ending Daylight Savings Time
3:05 How Do We Know The Universe Is Expanding?
5:34 Is Privacy A Protected Liberty?
8:42 What If We Could See Other Wavelengths?
10:48 MIT Quantum Supercold Experiment
12:24 Where Does Software End And Hardware Begin?
13:23 Thwaites Glacier
16:38 Sponsor and Close


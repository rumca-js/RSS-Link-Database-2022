## Justin Trudeau flees for a secret location as up to 50,000 'Freedom Convoy' truckers hit Ottawa | Daily Mail Online
 - [https://www.dailymail.co.uk/news/article-10456147/Justin-Trudeau-flees-secret-location-50-000-Freedom-Convoy-truckers-hit-Ottawa.html](https://www.dailymail.co.uk/news/article-10456147/Justin-Trudeau-flees-secret-location-50-000-Freedom-Convoy-truckers-hit-Ottawa.html)
 - RSS feed: https://www.dailymail.co.uk
 - date published: 2022-01-30 09:36:41+00:00

Justin Trudeau flees for a secret location as up to 50,000 'Freedom Convoy' truckers hit Ottawa | Daily Mail Online


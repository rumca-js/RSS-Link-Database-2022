# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Terminator - Movie Review
 - [https://www.youtube.com/watch?v=8aF-ujTdLzo](https://www.youtube.com/watch?v=8aF-ujTdLzo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-01-31 00:00:00+00:00

Go to https://NordVPN.com/jahns to get a 2-year plan plus 1 additional month with a huge discount. It’s risk free with Nord’s 30 day money-back guarantee!
Thanks to NordVPN for sponsoring this video.

I LOVE the first 2 Terminator movies, so let's talk about the epic Sci fi horror that is THE TERMINATOR!


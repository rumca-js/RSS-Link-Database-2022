# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Jaki będzie 2022?
 - [https://www.youtube.com/watch?v=vDrVGkkW4HY](https://www.youtube.com/watch?v=vDrVGkkW4HY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-01-31 00:00:00+00:00

Co przyniesie ten rok? 
Spis treści:
00:00 Wstęp: wydarzyło się w 2021…
00:40 Co przyniesie 2022 rok?
00:54 NFT
06:52 Pionowe treści w internecie
09:02 Hardware - podwyżki cen
10:14 Deglobalizacja
10:54 2022 – rokiem przełomowym dla samochodów latających
12:32 Izera – pierwszy elektryczny samochód z Polski
12:55 Metaverse w 2022 roku
15:10 Pozamykane Chiny
16:05 Bezpieczeństwo i konflikty zbrojne w 2022 roku
17:08 Mniej wolny internet
17:20 Złote rady na 2022
17:26 Rada nr 1: Załóż własną kawiarnię!
18:31 Rada nr 2: Nie bój się sprzedawać!
18:46 Rada nr 3: Bój się kupować w internecie!
18:58 Rada nr 4: Staraj się zrozumieć!
20:30 Rada nr 5: Nagrywaj pionowe filmy!
21:06 Maszyna do testowania składanych smartfonów
21:31 Rada nr 6: Zastanów się zanim kupisz nowy sprzęt!
22:20 Rada nr 7: Miej ograniczone zaufanie do swojego państwa!
27:05 Rada nr 8: Zostań agentem wirtualnych nieruchomości!
27:19 Pożegnanko
27:30 Znośnego tygodnia!

https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter


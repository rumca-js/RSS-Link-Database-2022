## Why Maus Was Banned…And Why It’s An Amazing Book
 - [https://www.cbr.com/maus-newest-banned-book-one-of-greatest-comics/](https://www.cbr.com/maus-newest-banned-book-one-of-greatest-comics/)
 - RSS feed: https://www.cbr.com
 - date published: 2022-01-30 14:02:04+00:00

Why Maus Was Banned…And Why It’s An Amazing Book


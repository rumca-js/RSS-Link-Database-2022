# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Diavol Strâin - Destino Destruccion (Live on KEXP)
 - [https://www.youtube.com/watch?v=VDwe0YkS2tM](https://www.youtube.com/watch?v=VDwe0YkS2tM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-31 00:00:00+00:00

http://KEXP.ORG presents Diavol Strâin performing “Destino Destruccion” live in the KEXP studio. Recorded December 14, 2021.

Laura Mancera - Vocal / Bass
Ignacia Borgez - Vocal / Guitar

Host: Jenn
Audio Engineers: Marcelo Morales & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://diavolstrain.bandcamp.com
http://kexp.org

## Diavol Strâin - Éter (Live on KEXP)
 - [https://www.youtube.com/watch?v=06nsFdVl_Kw](https://www.youtube.com/watch?v=06nsFdVl_Kw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-31 00:00:00+00:00

http://KEXP.ORG presents Diavol Strâin performing “Éter” live in the KEXP studio. Recorded December 14, 2021.

Laura Mancera - Vocal / Bass
Ignacia Borgez - Vocal / Guitar

Host: Jenn
Audio Engineers: Marcelo Morales & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://diavolstrain.bandcamp.com
http://kexp.org

## Diavol Strâin - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=TbrqKS5vtH0](https://www.youtube.com/watch?v=TbrqKS5vtH0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-31 00:00:00+00:00

http://KEXP.ORG presents Diavol Strâin performing live in the KEXP studio. Recorded December 14, 2021.

Songs:
Eter
Destino Destruccion
Nacidas del Fuego
Herz der Niemand

Laura Mancera - Vocal / Bass
Ignacia Borgez - Vocal / Guitar

Host: Jenn
Audio Engineers: Marcelo Morales & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://diavolstrain.bandcamp.com
http://kexp.org

## Diavol Strâin - Herz der Niemand (Live on KEXP)
 - [https://www.youtube.com/watch?v=bx0vz9C1jZ4](https://www.youtube.com/watch?v=bx0vz9C1jZ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-31 00:00:00+00:00

http://KEXP.ORG presents Diavol Strâin performing “Herz der Niemand” live in the KEXP studio. Recorded December 14, 2021.

Laura Mancera - Vocal / Bass
Ignacia Borgez - Vocal / Guitar

Host: Jenn
Audio Engineers: Marcelo Morales & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://diavolstrain.bandcamp.com
http://kexp.org

## Diavol Strâin - Nacidas del Fuego (Live on KEXP)
 - [https://www.youtube.com/watch?v=d9bhUdkF6WY](https://www.youtube.com/watch?v=d9bhUdkF6WY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-31 00:00:00+00:00

http://KEXP.ORG presents Diavol Strâin performing “Nacidas del Fuego” live in the KEXP studio. Recorded December 14, 2021.

Laura Mancera - Vocal / Bass
Ignacia Borgez - Vocal / Guitar

Host: Jenn
Audio Engineers: Marcelo Morales & Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz & Scott Holpainen
Editor: Scott Holpainen

https://diavolstrain.bandcamp.com
http://kexp.org


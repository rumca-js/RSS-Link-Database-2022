# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Iluzja bezpieczeństwa telefonów, czyli jak oszukać nasz wzrok?
 - [https://www.youtube.com/watch?v=8mftfnOXsSw](https://www.youtube.com/watch?v=8mftfnOXsSw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2022-01-30 00:00:00+00:00

Cześć!

Czy wszystko co widzą Twoje oczy, jest prawdą? A może… niektóre rzeczy tylko się wydają?
Porozmawiamy dzisiaj o tym, w jaki sposób oszukać nasz wzrok, a tym samym poczucie bezpieczeństwa.

Zapraszam!

Rozdziały:
00:00 Intro
00:17 Kolorowa dioda
01:25 Błąd znaleziony przez ZecOps
03:08 A co z restartem urządzenia?
05:25 Wnioski
06:08 Co Robić i Jak Żyć?
08:17 Podziękowania

Źródła:
👁️‍🗨️ Strona www ZecOps, autorów cytowanych filmów: https://bit.ly/3KVhZmX
▶️ Kanał youtube firmy ZecOps: https://bit.ly/3udmiEo
🐦 Twitter firmy @ZecOps: https://bit.ly/3IThmsl
🐦 Twitter badacza o skomplikowanym loginie @08Tc3wBB: https://bit.ly/3KUzjIC
🔴 Sposób na podglądanie bez uruchamiania kolorowych kropek: https://bit.ly/3s2e4Mt
📱 Udawany restart iPhone - jak to działa: https://bit.ly/3g9eTO1
🍏 Instrukcja iOS w wersji 14 opisująca działanie kropek: https://apple.co/3AIL7Jg
🤖 Dokumentacja Androida od wersji 12 opisująca działanie kropek: https://bit.ly/33VsNRz
🍏 Twardy reset dla różnych iPhone: https://apple.co/347Ezbg
📱 Jak wymusić twardy restart w Samsungu: https://bit.ly/34nFXGN
🏁 Film o porównaniu czasu startu różnych modeli iPhone:
https://www.youtube.com/watch?v=gg5ZiB3RZW4

Jeżeli nie ufasz skracanym linkom (bardzo dobrze!) to dodaj na ich końcu plusik ‘+’.
W ten sposób podejrzysz na stronie bit.ly dokąd prowadzą.

Relevant xkcd: https://xkcd.com/1807/

Dziękuję za gościnę Własne B.!
https://wlasneb.pl/

© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.

Dziękuję za Waszą uwagę. ❤️

Znajdziecie mnie również na;
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/
Podcasty na Anchor https://anchor.fm/mateusz-chrobok
Podcasty na Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR
Podcast na  Apple Podcasts https://podcasts.apple.com/us/podcast/mateusz-chrobok-bezpiecze%C5%84stwo-startupy-i-sztuczna-inteligencja/id1617335932 
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok


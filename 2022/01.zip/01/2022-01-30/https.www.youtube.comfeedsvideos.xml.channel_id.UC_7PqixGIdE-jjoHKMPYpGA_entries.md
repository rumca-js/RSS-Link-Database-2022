# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## [2/2] Analiza "Ukrytych terapii" dla WOŚP / zapis live
 - [https://www.youtube.com/watch?v=5pXr6FQ6Tpc](https://www.youtube.com/watch?v=5pXr6FQ6Tpc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2022-01-31 00:00:00+00:00

👉 https://www.siepomaga.pl/unbxwosp
👉 https://geny.altenberg.pl

W zamian za wpłatę wysyłamy model 3D miodożera. Autorką modeli jest Barbara Lemieszczuk - artystka 3D https://www.instagram.com/barbaric_concepts/

Licytacja książki:
https://allegro.pl/oferta/naukowy-belkot-ksiazka-z-notatkami-11691122386

Gość specjalny:
https://www.youtube.com/c/KasiaGandor

Inne zbiórki:
https://www.siepomaga.pl/teamgandor
https://www.siepomaga.pl/mlhdlawosp

Bingo:
https://drive.google.com/file/d/1LIGgtOkUrbB26PHbKPL3GecQZ6lr2kfd/view

Regulamin:
https://cutt.ly/TOdRVzq

Film Kasi:
https://www.youtube.com/watch?v=7fMjE4tRdzk

TED:
https://www.youtube.com/watch?v=RF8eJ2iN2Rk

Megadawki i Pauling:
https://youtu.be/HItFOF7iSn8

O publikacjach i źródłach wiedz:
https://www.youtube.com/watch?v=Avq9X0SSiLU

Efekt placebo:
https://www.youtube.com/watch?v=rgtPI8urtkE
https://www.youtube.com/watch?v=cKvLIBoOXRY

Witamina C:
https://www.youtube.com/watch?v=9CS4KYxpc4g

Dlaczego mamy sezon grypowy:
https://www.youtube.com/watch?v=75qySnZ2in4&

Pij mleko....
https://www.youtube.com/watch?v=w_lyM3HUun8

Cukrzyca od Radka:
https://www.youtube.com/watch?v=5LRo51td45w

Ignaz Semmelweis:
https://www.youtube.com/watch?v=Pn2meI8A8KM

Spojrzenia na temat badań przesiewowych:
https://www.youtube.com/watch?v=ez0E_fcGKu4

Ile może żyć człowiek?
https://naukowybelkot.pl/blog-naukowy/artykul/sto-lat-za-malo-sto-piecdziesiat-sie-zdalo

3 artykuły do sprawdzenia:
- https://naukowybelkot.pl/blog-naukowy/artykul/heurystyki-spiski-i-pralka-czyli-o-tym-dlaczego-tak-trudno-zmienic-zdanie-i-latwo-wierzyc-szarlatanom
- https://naukowybelkot.pl/blog-naukowy/artykul/trujace-przepiorki-czyli-rzecz-o-toksycznych-ptakach
- https://naukowybelkot.pl/blog-naukowy/artykul/slimaki-i-jajeczka-w-muzyce-czyli-skad-wzial-sie-zapis-nutowy

Dokonamy krytycznej analizy pierwszej książki Jerzego Zięby zatytułowanej "Ukryte terapie. Czego ci lekarz nie powie". Podzielę się wrażeniami z lektury i, przede wszystkim, postaram się merytorycznie odnieść do zawartych w niej rewelacji i twierdzeń.

To jak dużą część książki przeanalizujemy zależy tylko od Was - od tego, jak dużą kwotę zbierzemy do tej skarbonki. Każdy kolejny próg będzie "odblokowywał" fragment książki. Link do zbiórki znajdziecie powyżej!



👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/


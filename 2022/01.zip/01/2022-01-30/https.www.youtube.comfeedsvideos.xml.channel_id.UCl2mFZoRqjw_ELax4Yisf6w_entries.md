# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Linus says adblock is piracy: is he right?
 - [https://www.youtube.com/watch?v=6jUxOnoWsFU](https://www.youtube.com/watch?v=6jUxOnoWsFU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-01-30 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://twitter.com/LinusTech/status/1487125992346820609
https://en.wikipedia.org/wiki/Music_piracy
http://www.trustsoft.com/article.php?category=5&article=2448499
https://youtu.be/tSSuIu-P8RI
https://archive.fo/reTQj
https://archive.fo/yfbc7
https://twitter.com/jayrosen_nyu/status/644493677646204929
https://adage.com/article/digital/iab-surveys-options-fight-ad-blockers-including-lawsuits/300228
https://www.amazon.com/gp/product/B000066JCQ?ie=UTF8&tag=rossmanngroup-20&camp=1789&linkCode=xm2&creativeASIN=B000066JCQ
https://www.manualslib.com/manual/139608/Rca-Vcr-PlusPlus-15530130.html?page=48

00:00 Hello
00:05 My luck
00:34 Linus transparency vs. my lack of it
00:51 Adblock being piracy
02:30 My bias - youtube pays me from ads
03:28 My bias - Linus has given my nonprofit $20,000 from ad revenue
03:48 The stealing cirque du soleil example
04:00 The math of stealing from cirque du soleil
04:53 Louis is a simp
05:54 Definitions of piracy
06:20 What people get in trouble for
07:50 Why piracy was rampant in the 2000s
10:35 Violating the "implied contract"
10:52 Why the implied contract is not real
11:40 Suing adblockers
13:15 Journalism professor
13:35 History of ad blocking
14:00 Adblock on consumer VCRs
15:00 Would piracy measures be included on a VCR
15:35 Why screw over the advertiser but not the content creator?
16:15 Advertisers work into their model a lack of control over you
18:15 What's bad for the advertiser? You being served an ad you didn't watch
19:20 Are content creators mad if you do not pay attention to the ad?
21:45 Where do we draw the line?

## Louis Rossmann AMA random livestream
 - [https://www.youtube.com/watch?v=-7LrR97IpXg](https://www.youtube.com/watch?v=-7LrR97IpXg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-01-30 00:00:00+00:00

https://tinyurl.com/rossmatrix
Post a message on screen http://bit.ly/postamessage Or else I will read it in the normal chat if it is not swamped. I am sorry if I miss your message, I do my best to read as much stuff as I can that is somewhat interesting even if it is a normal unpaid message, but the chat sometimes moves way too fast for me to get things.


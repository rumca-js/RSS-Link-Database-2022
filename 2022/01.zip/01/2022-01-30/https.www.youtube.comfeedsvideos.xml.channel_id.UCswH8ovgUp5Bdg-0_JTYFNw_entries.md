# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## [PROOF] America Is In Decline
 - [https://www.youtube.com/watch?v=OKf7PWd7QgA](https://www.youtube.com/watch?v=OKf7PWd7QgA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-01-31 00:00:00+00:00

Worrying statistics show an America in decline. But why? And, if you thought the pandemic was bad, is worse still to come? 
#America #TheEnd #SuperPower 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## WHAT?! The Great Reset Is NOT a Conspiracy!
 - [https://www.youtube.com/watch?v=BXTPzFSx6oI](https://www.youtube.com/watch?v=BXTPzFSx6oI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-01-30 00:00:00+00:00

There’s a new corporate wave of homebuyers in the U.S. real estate market, with buyers stemming from Wall St making ownership for the average family increasingly difficult and forcing them to rent. So, it’s looking like the WEF were right – we will own nothing – but where’s the happiness? 
#TheGreatReset #Blackrock #WealthTransfer 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


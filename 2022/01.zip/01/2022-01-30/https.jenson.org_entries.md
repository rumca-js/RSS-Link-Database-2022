## A UX designer walks into a Tesla Bar – Scott Jenson
 - [https://jenson.org/tesla/](https://jenson.org/tesla/)
 - RSS feed: https://jenson.org
 - date published: 2022-01-30 23:07:41.507686+00:00




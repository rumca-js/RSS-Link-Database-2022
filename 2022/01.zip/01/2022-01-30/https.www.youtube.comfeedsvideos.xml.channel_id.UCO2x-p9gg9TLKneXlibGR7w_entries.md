# Source:Snazzy Labs, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w, language:en-US

## The DEFINITIVE iPhone Tier List
 - [https://www.youtube.com/watch?v=g5FpSAbsZbU](https://www.youtube.com/watch?v=g5FpSAbsZbU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO2x-p9gg9TLKneXlibGR7w
 - date published: 2022-01-31 00:00:00+00:00

We rank every iPhone ever made—except for the iPhone SE 2. Screw the iPhone SE 2.
Get PIA VPN for less than $2 a month and 4 Extra Months for FREE, which is only $1.98/Month and 83% off! https://privateinternetaccess.com/SnazzyLabs 

Buy an iPhone 13 Pro - https://amzn.to/3oeDnd8

Subscribe to my podcast Flashback! - http://relay.fm/flashback
Follow me on Twitter - http://twitter.com/snazzyq
Follow me on Instagram - http://instagram.com/snazzyq

In this episode, we fall in line with the hottest 2019 trends and rank every iPhone from best to worst. Is your favorite iPhone S-Tier or F-Tier? Watch now to decide.

0:00 Guest Star - Will Smith
0:24 iPhone 2007
2:43 iPhone 3G
4:15 iPhone 3GS
6:52 iPhone 4
9:33 iPhone 4S
10:38 iPhone 5
12:54 iPhone 5s
14:43 iPhone 5c
16:01 iPhone 6
19:04 iPhone 6s
20:43 iPhone SE
21:35 iPhone 7
22:36 Ode to 3D Touch
24:30 iPhone 8
25:40 WTF is that?!?!
25:50 iPhone X
27:26 iPhone XS
28:28 iPhone XR
30:05 iPhone 11 Pro
31:48 iPhone 11
32:25 iPhone 12 Pro
33:46 iPhone 12/12 mini
34:43 iPhone 13 Pro
36:06 iPhone 13/13 mini


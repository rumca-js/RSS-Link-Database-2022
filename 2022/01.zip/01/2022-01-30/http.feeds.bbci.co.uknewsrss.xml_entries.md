# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Winter Olympics: Why is luge the 'fastest sport on ice'?
 - [https://www.bbc.co.uk/sport/winter-olympics/60067520?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-olympics/60067520?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 21:32:38+00:00

Athletes whizz down a mile-long track of ice on a small sled in both sports - but what makes luge faster than skeleton?

## Frank Lampard's best Chelsea Premier League goals as he closes in on Stamford Bridge return as interim manager
 - [https://www.bbc.co.uk/sport/av/football/60184229?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/60184229?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 20:29:53+00:00

Watch some of Frank Lampard's best Premier League goals for Chelsea as the former England midfielder looks set to return to Stamford Bridge as interim manager until the end of the season.

## Is Nadal the greatest male tennis player?
 - [https://www.bbc.co.uk/sport/tennis/60183689?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/60183689?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 20:13:15+00:00

Not only was Rafael Nadal playing for the Australian Open title on Sunday, he was jostling for position to be crowned the Greatest of All Time.

## Bloody Sunday: 'I still miss my father, 50 years on'
 - [https://www.bbc.co.uk/news/uk-60192584?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60192584?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 18:36:21+00:00

Relatives of those killed in Londonderry have gathered to remember loved ones, 50 years on.

## In eastern Ukraine, war-weary soldiers and civilians await Russia's next move
 - [https://www.bbc.co.uk/news/world-europe-60190249?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60190249?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 14:32:07+00:00

On Ukraine's eastern front lines, in the deep winter cold, soldiers and civilians await Russia's next move.

## Luis Diaz: Liverpool sign Colombia winger from Porto in five-year deal for initial £37.5m
 - [https://www.bbc.co.uk/sport/football/60180371?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60180371?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 12:17:42+00:00

Liverpool sign Colombia winger Luis Diaz from Porto in a deal worth £37.5m, with a further £12.5m in potential bonuses.

## Bloody Sunday: Irish PM lays wreath at Bloody Sunday memorial
 - [https://www.bbc.co.uk/news/uk-northern-ireland-60130409?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-60130409?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 12:03:44+00:00

Thirteen people were killed when British soldiers opened fire on a civil rights march in Londonderry.

## National Insurance: Boris Johnson and Rishi Sunak confirm rise from April
 - [https://www.bbc.co.uk/news/uk-60185741?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60185741?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 12:01:01+00:00

It comes after pressure from opposition and some Tory MPs to cancel the hike, due to start in April.

## Ukraine-Russia tensions: British troops 'unlikely' to fight - Truss
 - [https://www.bbc.co.uk/news/uk-60188690?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60188690?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 11:49:53+00:00

The foreign secretary says the UK is using "deterrence and diplomacy" to avoid further conflict.

## Levelling up: Sheffield and Wolverhampton chosen for regeneration plans
 - [https://www.bbc.co.uk/news/uk-politics-60183453?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60183453?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 11:14:04+00:00

The government names first two places to get regeneration funds - but Labour says it's not enough.

## North Korea missile tests: Biggest launch since 2017
 - [https://www.bbc.co.uk/news/world-asia-pacific-60186538?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-pacific-60186538?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 10:19:03+00:00

Sunday's launch is the seventh this month, and is thought to be the largest in almost five years.

## Storm Corrie moves in after boy and woman die in Storm Malik
 - [https://www.bbc.co.uk/news/uk-60183035?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60183035?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 10:02:27+00:00

A day after Storm Malik hit much of Scotland and northern England, Storm Corrie is due to blow in.

## Women's Ashes: England and Australia draw Test in incredible finale
 - [https://www.bbc.co.uk/sport/cricket/60186075?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/60186075?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 08:57:49+00:00

England and Australia draw the one-off Women's Ashes Test in one of the most incredible finales cricket has seen.

## US East Coast blanketed by 'bombogenesis' snowstorm
 - [https://www.bbc.co.uk/news/world-us-canada-60177979?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60177979?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 07:44:15+00:00

The storm dumps feet of snow, with high winds and flooding leaving tens of thousands without power.

## Covid: Covid jabs offered to at-risk five to 11-year-olds in England, and National Insurance hike confirmed
 - [https://www.bbc.co.uk/news/uk-60185896?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60185896?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 07:21:45+00:00

Five things you need to know about the coronavirus pandemic this Sunday morning.

## Gary Mavin: Wife's shock at poor care before suicide death
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-60060844?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-60060844?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 07:19:41+00:00

Lea Mavin says it was shocking to hear a doctor thought her husband was feigning symptoms.

## Afcon 2021: Burkina Faso shock Tunisia in Afcon quarter-final
 - [https://www.bbc.co.uk/sport/av/football/60186063?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/60186063?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 06:10:08+00:00

Watch highlights as Burkina Faso beat Tunisia 1-0 with a goal from teenager Dango Ouattara - who was later sent off - to qualify for the semi-finals of the Africa Cup of Nations.

## The Papers: Sunak 'wins tug-of-war' over tax hike
 - [https://www.bbc.co.uk/news/blogs-the-papers-60185883?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60185883?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 05:21:39+00:00

Government announcements on levelling up plans and the planned National Insurance rise lead some papers.

## British skier Atkin withdraws from Beijing big air
 - [https://www.bbc.co.uk/sport/winter-olympics/60186601?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-olympics/60186601?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 02:52:37+00:00

Team GB freestyle skier Izzy Atkin withdraws from the big air competition at the Winter Olympics, but still plans to compete in Beijing.

## What happened to the British children born to black GIs?
 - [https://www.bbc.co.uk/news/uk-england-suffolk-59967242?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-suffolk-59967242?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 01:29:36+00:00

Children born to black US soldiers and white British women during World War Two share their stories.

## Newcastle's Covid response documented through photography
 - [https://www.bbc.co.uk/news/uk-england-tyne-60131496?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tyne-60131496?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 01:27:18+00:00

Council worker Tom Warburton was at the centre of the pandemic and documented his city's response.

## ‘I feel like me again’ - troubled Army vets are helping fix driver shortage
 - [https://www.bbc.co.uk/news/stories-60140431?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-60140431?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 01:24:51+00:00

Some UK veterans can face difficulties finding work after returning to civilian life, but one ex-soldier wants to help them get back in the driving seat.

## Ukraine crisis: What’s at stake for the UK?
 - [https://www.bbc.co.uk/news/uk-60159622?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60159622?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 01:05:33+00:00

From the disruption of gas supplies to the risk of broader war, the Ukraine crisis matters to the UK.

## Covid vaccines offered to vulnerable five-to-11-year-olds in England
 - [https://www.bbc.co.uk/news/health-60173823?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60173823?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 00:34:38+00:00

Around 500,000 young children will be offered the lower doses to protect them and vulnerable adults.

## Energy crisis: How countries are dealing with rising prices
 - [https://www.bbc.co.uk/news/business-60112068?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60112068?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 00:24:40+00:00

From cash handouts to price caps, other countries are using a variety of measures to combat soaring gas prices.

## Peru: How Ed Sheeran helped Fireboy DML's hit go global
 - [https://www.bbc.co.uk/news/newsbeat-60147212?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-60147212?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 00:23:34+00:00

The Nigerian star discusses Peru's success and his new friendship with the British singer.

## Jamie Oliver: I'm not a fan of cookery competition shows
 - [https://www.bbc.co.uk/news/entertainment-arts-59773808?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59773808?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 00:21:24+00:00

The TV chef says he had to be persuaded to launch his new cookery talent contest series on Channel 4.

## Your pictures on the theme of a fresh start
 - [https://www.bbc.co.uk/news/in-pictures-60146664?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-60146664?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 00:20:18+00:00

A selection of striking images from our readers around the world.

## Cost of living: Will parents spend less on kids' toys?
 - [https://www.bbc.co.uk/news/business-60155949?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60155949?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 00:19:06+00:00

Families will cut spending on many things before toys but soaring bills may put this to the test.

## Using food waste to make clean drinking water
 - [https://www.bbc.co.uk/news/stories-60168422?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-60168422?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 00:02:08+00:00

How old bones and vegetable peelings are being recycled to make a water filter

## 'As my world crashed down, she kept me going'
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-60075465?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-60075465?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 00:01:59+00:00

Florence, from Leicestershire, was diagnosed with rhabdomyosarcoma, a fast-growing cancer.

## Beijing Olympics: Five things to know
 - [https://www.bbc.co.uk/news/world-60173066?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-60173066?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 00:01:24+00:00

Covid bubbles, artificial snow and human rights are making 2022's Winter Olympics hit the headlines.

## Joe Jenkins: YouTube star on piano-playing popularity
 - [https://www.bbc.co.uk/news/uk-england-bristol-60163456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-60163456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-30 00:01:17+00:00

A 20-year-old piano player has an online following of nearly four million enjoying his musical stunts.


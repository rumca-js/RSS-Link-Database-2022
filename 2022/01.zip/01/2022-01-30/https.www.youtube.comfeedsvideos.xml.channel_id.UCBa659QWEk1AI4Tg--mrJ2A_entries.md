# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## Literally just three minutes where I talk about some rocks
 - [https://www.youtube.com/watch?v=EfdwRRpiYGQ](https://www.youtube.com/watch?v=EfdwRRpiYGQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-01-31 00:00:00+00:00

Hutton's Unconformity, at Siccar Point, is about an hour east of Edinburgh, in Scotland, and I've wanted to set my own two feet on it for years. And from it, I've got a bigger question: is there anything we've missed?

The story of the Hutton Unconformity:
https://www.geolsoc.org.uk/GeositesSiccarPoint
https://www.edinburghgeolsoc.org/edinburghs-geology/huttons-unconformity/
https://www.pesgb.org.uk/news/huttons-unconformity-siccar-point/

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Mario Kart 9 Needs to Go Full Smash | The Takeaway
 - [https://www.youtube.com/watch?v=qr9QszlyOoY](https://www.youtube.com/watch?v=qr9QszlyOoY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-01-31 00:00:00+00:00

Rumors about Mario Kart 9's reveal are swirling around alone and Marty has some ideas on what the next entry in the long-running series should offer.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Peacemaker is Wonderfully Weird and Fun | Your Feature Presentation
 - [https://www.youtube.com/watch?v=DOd5eTsbwT0](https://www.youtube.com/watch?v=DOd5eTsbwT0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-01-30 00:00:00+00:00

This week on Your Feature Presentation, Jack and Darren discuss what they like and dislike about Peacemaker, and then Marty and KC kick off our new Weeb segment, funded by the community. 

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---
Timestamps:

00:00 Intro
02:02 Peacemaker
26:52 Attack on Titan


---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


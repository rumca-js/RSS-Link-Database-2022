# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Babylon Bee Weak-ly News Update 1/31/2022: Rising Tensions in Ukraine and Furry Bathrooms
 - [https://www.youtube.com/watch?v=OheP83bjYrw](https://www.youtube.com/watch?v=OheP83bjYrw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-01-31 00:00:00+00:00

Host Adam Yenser gives us the news of the week, including the rising tension at the Ukraine border, Nancy Pelosi announcing she is running against time, and how schools are discouraging furries from using the bathrooms designed for humans.

Watch the full podcast here: https://www.youtube.com/watch?v=iF25ju6SnvI

Follow Adam on Youtube: https://www.youtube.com/user/adamyenser

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

## The Bee Guys Watch Cringey Christian Sermons
 - [https://www.youtube.com/watch?v=pgW73uXQhss](https://www.youtube.com/watch?v=pgW73uXQhss)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-01-31 00:00:00+00:00

These heroes of the faith preach the cringe sermons of their lives informing us that Pokémon (plural) are evil, how to smash a TV with an ax for God, and that all atheists have something in common: video games.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


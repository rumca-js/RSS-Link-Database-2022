## Nova Scotia outlaws support on highway for 'freedom' truckers days after massive protest | Fox News
 - [https://www.foxnews.com/world/nova-scotia-outlaws-gathering-highway-freedom-convoy-truckers-vaccine-mandate](https://www.foxnews.com/world/nova-scotia-outlaws-gathering-highway-freedom-convoy-truckers-vaccine-mandate)
 - RSS feed: https://www.foxnews.com
 - date published: 2022-01-30 20:35:51+00:00

Nova Scotia outlaws support on highway for 'freedom' truckers days after massive protest | Fox News


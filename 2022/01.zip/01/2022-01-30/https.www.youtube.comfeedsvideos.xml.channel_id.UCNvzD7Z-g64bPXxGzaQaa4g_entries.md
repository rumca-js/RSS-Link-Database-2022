# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## PLAYSTATION Reveals Plans For Bungie After BUYING Them
 - [https://www.youtube.com/watch?v=5FbkJU46IPA](https://www.youtube.com/watch?v=5FbkJU46IPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-31 00:00:00+00:00

Sony/PlayStation is Acquiring Bungie, the folks behind Halo and most recently Destiny 2. What does this mean? Will their games go exclusive? Let's talk.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Sources:
https://www.gamesindustry.biz/articles/2022-01-31-playstation-bungie-will-considerably-accelerate-our-journey-with-multiplatform-live-service-games

https://www.gamesindustry.biz/articles/2022-01-31-sony-buying-bungie-for-usd3-6-billion

https://blog.playstation.com/2022/01/31/bungie-is-joining-playstation/

https://www.bungie.net/en/Explore/Detail/News/50988

#Bungie #Sony

## Top 10 NEW FPS Games of 2022
 - [https://www.youtube.com/watch?v=yCiYYCqfNSo](https://www.youtube.com/watch?v=yCiYYCqfNSo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-30 00:00:00+00:00

Looking for a new FPS game on PC, PS5, PS4, and Xbox Series X/S/One in 2022? These upcoming games are worth looking forward to.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

Scorn

Platform : PC XSX|S 

Release Date : October, 2022 


Warhammer 40,000: Darktide

Platform : PC XSX|S 

Release Date : 2022 


Witchfire

Platform : PC TBA

Release Date : TBA


Tiny Tina’s Wonderlands

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : March 25, 2022 


S.T.A.L.K.E.R. 2: Heart of Chernobyl 

Platform : PC XSX|S 

Release Date : December 8, 2022 



Shadow Warrior 3

Platform : PC PS4 Xbox One 

Release Date : 2022 



Starfield

Platform : PC XSX|S 

Release Date : November 11, 2022 



Redfall 

Platform : PC XSX|S 

Release Date : 2022 



Dying Light 2 Stay Human 

Platform : PC PS4 PS5 Switch Xbox One XSX|S  

Release Date : February 4, 2022 



Atomic Heart 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : 2022 



Bonus:



Destiny 2: The Witch Queen

Platform : PC PS4 PS5 Xbox One XSX|S Stadia 

Release Date : February 22, 2022 



Crossfire X

Platform : Xbox One XSX|S

Release Date : February 10, 2022 



Boundary

Platform : PC PS4 

Release Date : TBA 2022


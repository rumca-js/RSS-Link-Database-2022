# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## River | Bishop Briggs | funk cover ft. Ben Barnes
 - [https://www.youtube.com/watch?v=p-_6th8rHRw](https://www.youtube.com/watch?v=p-_6th8rHRw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-01-31 00:00:00+00:00

Join the Vinyl Club tier by Feb. 28 to get "Technicolor Magic" AND "Best of 2021" on vinyl! http://modal.scarypocketsfunk.com/patreon

Store: https://www.scarypocketsfunk.com
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Bishop Briggs' "River" by Scary Pockets & Ben Barnes.

MUSICIAN CREDITS
Lead vocal: Ben Barnes
Drums: Abe Laboriel Jr.
Bass: Nick Campbell
Keys: Carey Frank
Guitar: Ariel Posen
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
DP: Kenzo Le 
Editor: Adam Kritzberg
Skit Editor: Jude Smith

Recorded Live at East West in Los Angeles, CA.

#ScaryPockets #Funk #BenBarnes #BishopBriggs #River


## If Looks Could Kill
 - [https://vintagecomputerstories.blogspot.com/2022/01/if-looks-could-kill.html?m=1](https://vintagecomputerstories.blogspot.com/2022/01/if-looks-could-kill.html?m=1)
 - RSS feed: https://vintagecomputerstories.blogspot.com
 - date published: 2022-01-28 09:01:44+00:00

by Leonard Tramiel At one of the many computer trade shows over the years I had a really funny interaction with Bill Gates. I was doing demo...


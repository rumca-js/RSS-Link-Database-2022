# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Home Depot introducing DRM to power tools to prevent theft.
 - [https://www.youtube.com/watch?v=y5QIjU4jRRs](https://www.youtube.com/watch?v=y5QIjU4jRRs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-01-28 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://youtu.be/oSXqO7VPKuk?t=68

🔵 Desk: https://amzn.to/3njMvN3
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3JZ2rOy
🔵 Camera: https://amzn.to/3K2H5Qw

## Large conservative outlet backs Right to Repair: bipartisanship in the making!
 - [https://www.youtube.com/watch?v=81CwGWdWFFs](https://www.youtube.com/watch?v=81CwGWdWFFs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-01-28 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://www.nationalreview.com/2022/01/right-to-repair-a-consumer-movement-that-left-and-right-should-agree-on/
👉 https://www.nationalreview.com/2020/07/a-computer-repair-expert-takes-on-big-tech/
👉 https://www.youtube.com/watch?v=oAbOpQJqKmw
👉 https://www.youtube.com/watch?v=0W0erk_mPhQ
👉 https://www.youtube.com/watch?v=aVG1WMJebg8

🔵 Desk: https://amzn.to/3njMvN3
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3JZ2rOy
🔵 Camera: https://amzn.to/3K2H5Qw


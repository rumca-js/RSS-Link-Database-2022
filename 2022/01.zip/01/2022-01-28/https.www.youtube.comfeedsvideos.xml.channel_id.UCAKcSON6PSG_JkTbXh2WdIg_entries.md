# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Anaïs Mitchell - two live performances (2019)
 - [https://www.youtube.com/watch?v=CJ_Y3X2xwHU](https://www.youtube.com/watch?v=CJ_Y3X2xwHU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-01-29 00:00:00+00:00

Anaïs Mitchell released her new, self-titled album today. In honor of that, here are two performances by Anaïs Mitchell, recorded live with the Live From Here gang in 2019; the first performance was recorded in St. Louis, Mo., in May of that year, and the second was recorded at the Town Hall in New York City in November.

SONGS PERFORMED
0:00 "Wedding Song"
2:37 "Morning Glory"

PERSONNEL
Anaïs Mitchell – guitar and vocals
Chris Thile – mandolin and backing vocals
Alex Hargreaves – fiddle
"Wedding Song"
Gabriel Kahane – piano
Chris Eldridge – guitar
Alan Hampton – bass
Josh Dion – percussion
"Morning Glory"
Mike Elizondo – bass
Armand Hirsch – guitar
Jon Cowherd – keys
Eric Doob – percussion

CREDITS
Video & Photo: Ben Miller; American Public Media
Audio: Sam Hudson; American Public Media
Production: Tom Campbell; Jeffy Hnilicka; American Public Media

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#anaismitchell

## St Paul and the Broken Bones - three live performances (2018)
 - [https://www.youtube.com/watch?v=aaShBSMsfBY](https://www.youtube.com/watch?v=aaShBSMsfBY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-01-28 00:00:00+00:00

St. Paul and the Broken Bones will release their next album, "The Alien Coast," on Friday, January 28, 2022. In anticipation of that, here are three performances by St. Paul and the Broken Bones recorded live in 2018 in Telluride, Colo., as part of Live From Here. 

SONGS PERFORMED
0:00 "Back to the Future"
3:12 "Grass is Greener"
8:53 "Sanctify"

PERSONNEL
Allen Branstetter – trumpet
Chad Fisher – trombone
Al Gamble – keyboards
Paul Janeway – vocals
Andrew Lee – drums
Browan Lollar – guitar
Jason Mingledorff – saxophone
Jesse Phillips – bass

CREDITS
Video & Photo: Ben Miller; American Public Media
Audio: Sam Hudson; American Public Media
Production: Tom Campbell; Jeffy Hnilicka; American Public Media

FIND MORE:
2014 studio session: https://www.thecurrent.org/feature/2014/06/06/st-paul-and-the-broken-bones-perform-in-the-current-studio
2014 Guitar Collection interview with Browan Lollar: https://www.thecurrent.org/feature/2014/06/11/the-current-s-guitar-collection-browan-lollar-of-st-paul-and-the-broken-bones
2019 Palace Theatre concert:
https://www.thecurrent.org/feature/2019/06/07/watch-st-paul-and-the-broken-bones-live-in-concert-at-the-palace-theatre

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#stpaulandthebrokenbones


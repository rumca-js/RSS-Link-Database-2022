# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Complete Travels of Théoden, King of Rohan | Tolkien Explained
 - [https://www.youtube.com/watch?v=ZSiPx2Fo4uo](https://www.youtube.com/watch?v=ZSiPx2Fo4uo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-01-29 00:00:00+00:00

Born in Gondor, Théoden would live the rest of his life in Rohan when his father ascends to the throne.  When his time comes, he becomes the 17th King of Rohan.  As king, he would not only rule the realm, but raise three children as a single father: Théodred, as well as his nephew Éomer and niece Éowyn. So great was Théoden in the Battle of the Pelennor Fields, that he is compared to one of the Valar.

Go to www.LordofMaps.com and use the code NERDOFMAPS to save 15% off your order of great maps!

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Donato Giancola - https://www.donatoarts.com/online-store/secure-store/Middle-earth-c34110463
Aronja Art - https://www.instagram.com/aronjaart/
Steamey - https://www.deviantart.com/steamey
Kip Rasmussen - https://www.kiprasmussen.com/
CK Goksoy - https://www.artstation.com/ckgoksoy
Ivan Cavini - https://www.instagram.com/ivan_cavini/

Theoden - Jenny Dolfen
Persuassive Words - Donato Giancola
Forth Eorlingas - Jenny Dolfen
Theoden vs Captain of the Haradrim - Kip Rasmussen
Theoden & Snowmane - Magdalena Katanska
Rider of Rohan - JG Jones
Minas Tirith - Ralph Damiani
Edoras - Ralph Damiani
Rohirrim - Matthew Stewart
Edoras - Alan Lee
Meadhall - Pete Amachree
House of Eorl, Deor - Aegeri
At the Crossing of the Mering Stream - Steamey
Theoden in the Aldburg Eastfold - Steamey
Theoden - Jenny Dolfen
Riders of Rohan - Turner Mohan
Orthanc in the Second Age - Ted Nasmith
Theoden and Grima - Alan Lee
Theoden and Wormtongue - Aegeri
Wormtongue - Steve Airola
Sons of Rohan - Jenny Dolfen
Theoden King - Jenny Dolfen
Gandalf rides to Minas Tirith - Rafael Damiani
Battle of the Fords of Isen - James Rinere
Saruman - Angus McBride
Rohirrim - Angus McBride
Approaching Edoras - Ted Nasmith
Edoras - John Howe
Gandalf the White - Andrea Piparo
Gandalf and Narya - Donato Giancola
Gandalf in Hollin - Donato Giancola
Gandalf command - Matthew Stewart
Theoden Corrupted - Steve Airola
The House of Eorl, Brego - Aegeri
Gandalf judges Grima Wormtongue - Anke Eissmann
The Rohirrim - Aegeri
Theoden - Daniel Falconer
Edoras - John Howe
Gandalf - JG Jones
Rohirrim in Battle of Pelennor Fields - Ivan Cavini
Eowyn Alone Before the Golden Hall - Matthew Stewart
Helm's Deep - John Howe
Theoden - Steve Airola
Isengard - Ivan Cavini
Gandalf Rides to Minas Tirith - Ted Nasmith
Riders of Rohan - Ted Nasmith
Merry - John Howe
The Red Arrow - Paula DiSante
The Aid of the Wild Men - Ted Nasmith
Eowyn and Merry - Matthew Stewart
Battle of Pelennor Fields - Magdalena Katanska
Orome Hunts the Creatures of Morgoth - Kip Rasmussen
Rohan charge - Tom Romain
The Black Serpent Flounders - Anke Eissmann
Eowyn and the Witch King - Angus McBride
Eowyn and Nazgul - Donato Giancola
Eowyn and the Nazgul - Matthew Stewart
Eowyn Stands Against the Witch King - Kip Rasmussen
The House of Eorl, Gram - Aegeri
The House of Eorl, Freawine - Aegeri
Eowyn - Matthew Stewart
Eowyn and the Witch King - Ivan Cavini
Eomer and Aragorn Ride to the Lands of the East - Kip Rasmussen
Ride of the Rohirrim - Anke Eissmann
Battle of the Black Gate - Ted Nasmith
Funeral of Haldad, Haldar - Steamey
Charge of the Rohirrim - John Howe

For more on the life of Théoden, check out: 
The Lord of the Rings by JRR Tolkien
Tolkien Gateway
The Encyclopedia of Arda

All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

#theoden #lordoftherings #tolkien


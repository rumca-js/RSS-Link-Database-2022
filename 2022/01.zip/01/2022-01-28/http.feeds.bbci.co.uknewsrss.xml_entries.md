# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Former England midfielder Lampard offered Everton manager job
 - [https://www.bbc.co.uk/sport/football/60174330?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60174330?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 22:11:25+00:00

Everton offer their vacant managerial position to former England midfielder Frank Lampard.

## Highway Code: How the update could improve road safety
 - [https://www.bbc.co.uk/news/business-59997523?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59997523?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 22:04:01+00:00

The revamped code is designed to make the roads safer for users who are more at risk.

## Storm Arwen: 'I was left without broadband for seven weeks'
 - [https://www.bbc.co.uk/news/business-60029578?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60029578?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 22:03:07+00:00

A holiday firm owner says he lost bookings because of the time it took to restore an internet link.

## Where are Britain's missing million workers?
 - [https://www.bbc.co.uk/news/business-60039923?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60039923?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 22:02:55+00:00

With vacancies at a record high, many firms are suffering from a shortage of skilled workers.

## Why Germany isn't sending weapons to Ukraine
 - [https://www.bbc.co.uk/news/world-europe-60155002?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60155002?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 22:01:46+00:00

Germany's refusal to arm Ukraine has puzzled and angered some allies. Here's what's behind it.

## Covid-19: Vulnerable people miss out on vital priority tests
 - [https://www.bbc.co.uk/news/uk-60161763?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60161763?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 20:07:43+00:00

England's system for rapid access to antiviral drugs is not working, some high-risk patients say.

## Lighthouse lantern worth £1m stolen from north Devon
 - [https://www.bbc.co.uk/news/uk-england-devon-60175284?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-devon-60175284?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 16:52:50+00:00

A man is arrested after the theft of the lantern, which weighs around two tonnes.

## Bridgwater United - Potential FA Cup giantkillers prepare for visit of Man Utd
 - [https://www.bbc.co.uk/sport/av/football/60173031?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/60173031?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 14:02:02+00:00

Bridgwater United Women, only formed in 2021, have had to install more seats for their Women's FA Cup visit from Man Utd. Can "little old Bridgy" pull off one big giant-killing?

## National Insurance rise: Government must do more on cost of living - minister
 - [https://www.bbc.co.uk/news/uk-60165117?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60165117?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 12:46:09+00:00

James Heappey concedes people are "feeling the squeeze", but defends the planned National Insurance rise.

## Chicago trains drive over flaming tracks
 - [https://www.bbc.co.uk/news/world-us-canada-60170962?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60170962?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 12:38:31+00:00

The tracks are set alight to prevent them from freezing over in snowy weather.

## Downing Street parties: Confusion over Sue Gray report after Met police statement
 - [https://www.bbc.co.uk/news/uk-politics-60166997?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60166997?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 12:35:18+00:00

A report into lockdown parties in Downing Street may not now be published as planned.

## Bloody Sunday: David Cameron wanted 'no doubt' over apology
 - [https://www.bbc.co.uk/news/uk-northern-ireland-60157409?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-60157409?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 12:33:32+00:00

The ex-prime minister reflects on his 2010 House of Commons statement on the events of Bloody Sunday.

## Nadal to face world number two Medvedev in Australian Open final
 - [https://www.bbc.co.uk/sport/tennis/60165435?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/60165435?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 12:21:26+00:00

Rafael Nadal is one win away from a record 21st Grand Slam men's title after beating Matteo Berrettini and faces Daniil Medvedev in the Australian Open final.

## Prince Andrew gives up honorary membership at prestigious golf club
 - [https://www.bbc.co.uk/news/uk-60170912?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60170912?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 12:18:42+00:00

Duke of York relinquishes his honorary membership of the Royal and Ancient Golf Club of St Andrews.

## Ofcom to investigate Channel 4 over subtitle outage
 - [https://www.bbc.co.uk/news/entertainment-arts-60167724?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60167724?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 12:08:28+00:00

The broadcaster experienced several major outages last year, prompting calls for action.

## Liverpool make £37m move for Porto and Colombia winger Diaz
 - [https://www.bbc.co.uk/sport/football/60165986?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60165986?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 11:13:27+00:00

Premier League side Liverpool are trying to sign Colombia winger Luis Diaz from Porto.

## F-35C fighter jet: Race is on to reach sunken US plane... before China
 - [https://www.bbc.co.uk/news/world-us-canada-60148482?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60148482?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 10:47:55+00:00

The $100m jet is fair game, in international waters. "It's the Hunt for Red October meets The Abyss."

## Bloody Sunday brought to the stage in playwright's final work
 - [https://www.bbc.co.uk/news/uk-northern-ireland-60159799?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-60159799?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 10:21:48+00:00

BBC News looks at the final work of a playwright retelling the events of 30 January 1972.

## The Queen's Gambit: Netflix denied motion to dismiss defamation case
 - [https://www.bbc.co.uk/news/entertainment-arts-60167723?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60167723?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 10:10:20+00:00

Lawyers say the fictional show tarnished the reputation of chess champion Nona Gaprindashvili.

## Stephen Kyere: Ex-Met police officer charged with rape
 - [https://www.bbc.co.uk/news/uk-england-london-60166483?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-60166483?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 09:52:14+00:00

Former PC Stephen Kyere will appear at Wimbledon Magistrates' Court next month.

## Decoding Putin's next move
 - [https://www.bbc.co.uk/news/world-europe-60152007?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60152007?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 09:46:15+00:00

Invasion or fear strategy: the Russian leader keeps everyone guessing on his real plans for Ukraine.

## Why has Sue Gray's report not appeared yet?
 - [https://www.bbc.co.uk/news/uk-politics-60157517?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60157517?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 09:14:20+00:00

Political correspondent Iain Watson looks at what the long-anticipated report is likely to find when it appears.

## Ukraine crisis: Biden warns Russia may invade next month
 - [https://www.bbc.co.uk/news/world-europe-60164537?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60164537?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 08:39:32+00:00

Tens of thousands of Russian troops are at Ukraine's border, sparking fears of an invasion.

## Defiant Knight century keeps England in the Ashes on day two
 - [https://www.bbc.co.uk/sport/cricket/60164492?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/60164492?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 07:59:43+00:00

Captain Heather Knight single-handedly repels Australia with a superb century to keep England in the Ashes on day two of the one-off Test.

## Why player-coach relationships are an issue in women's football
 - [https://www.bbc.co.uk/sport/football/59294074?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59294074?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 07:36:05+00:00

BBC Sport examines why relationships between players and coaches exist in women's football - and if it's an issue that needs addressing.

## Alisson has two red-card reprieves as Brazil held by Ecuador
 - [https://www.bbc.co.uk/sport/football/60164304?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60164304?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 07:23:35+00:00

Liverpool goalkeeper Alisson believes he has achieved a footballing first by having two red cards rescinded in Brazil's 1-1 draw with Ecuador.

## Haringey: Man in court accused of Jewish hate crime attack
 - [https://www.bbc.co.uk/news/uk-england-london-60166480?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-60166480?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 07:14:35+00:00

Two men were attacked as they were locking up their shop in Haringey, north London, on Wednesday.

## The Papers: 'Cost of living delayed by Downing Street turmoil'
 - [https://www.bbc.co.uk/news/blogs-the-papers-60164134?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60164134?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 06:16:51+00:00

Most papers on Friday report on the cost of living crisis and the rise in National Insurance due in April.

## Barnard Castle records best ever year for tourists
 - [https://www.bbc.co.uk/news/uk-england-60161533?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-60161533?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 06:14:04+00:00

A boom in UK breaks due to Covid-19 saw visitors increase at sites operated by English Heritage.

## Winter Olympics: Could Olympic skateboarder Sky Brown make it as a snowboarder?
 - [https://www.bbc.co.uk/sport/av/winter-olympics/60083510?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/winter-olympics/60083510?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 06:08:22+00:00

Olympic skateboarding bronze medallist Sky Brown meets Aimee Fuller to give snowboarding a try.

## Winter Olympics: Global sponsors quiet ahead of Beijing Games
 - [https://www.bbc.co.uk/news/business-60136347?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60136347?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 01:13:50+00:00

A week before the Beijing Games start global partners are lying low amid a US-China diplomatic spat.

## Re-doin' The Do: The resurrection of Betty Boo
 - [https://www.bbc.co.uk/news/entertainment-arts-60124008?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60124008?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 00:58:48+00:00

Thirty years after her last hit, Betty Boo is back with a song she wrote in a Sainsbury's car park.

## Plastic bags: The Aberdare woman who collected 10,000 in 50 years
 - [https://www.bbc.co.uk/news/uk-wales-60160099?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60160099?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 00:58:05+00:00

Angela Clarke has spent almost half a century amassing a 10,000 strong collection of plastic bags.

## Twitch: Concerns over streamers' mental health
 - [https://www.bbc.co.uk/news/entertainment-arts-60109997?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60109997?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 00:55:06+00:00

The company says it wants to support its streamers with the pressures of content creation.

## Novak Djokovic: Doubts over timing of Covid test
 - [https://www.bbc.co.uk/news/59999541?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/59999541?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 00:47:08+00:00

The BBC has uncovered fresh evidence questioning the timing of Novak Djokovic’s positive Covid test used to enter Australia.

## North Korea missile tests: What does Kim Jong-un want?
 - [https://www.bbc.co.uk/news/world-asia-60150121?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-60150121?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 00:41:07+00:00

Pyongyang has conducted six missile tests so far this year - but why now, and what do they want?

## The scramble for cargo aircraft as shipping costs soar
 - [https://www.bbc.co.uk/news/business-59957410?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59957410?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 00:08:44+00:00

Cargo aircraft are being rushed into service amid a worldwide shortage in shipping capacity.

## Former Nazi speaks in new BBC documentary
 - [https://www.bbc.co.uk/news/world-europe-60129088?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60129088?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-28 00:04:54+00:00

Hans Werk features in a new documentary about the last living generation of Germans in Hitler’s Third Reich.


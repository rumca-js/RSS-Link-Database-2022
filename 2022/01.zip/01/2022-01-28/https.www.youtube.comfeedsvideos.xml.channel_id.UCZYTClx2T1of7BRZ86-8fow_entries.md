# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## How to Avoid Corpse-Flavored Water
 - [https://www.youtube.com/watch?v=pDuWBDNcY1s](https://www.youtube.com/watch?v=pDuWBDNcY1s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-01-29 00:00:00+00:00

Visit brilliant.org/scishow/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.

As organisms decompose their chemical and bacterial components can leach into the surrounding ground and water. The bodies buried in cemeteries are no exception.

Hosted by: Michael Aranda

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Dr. Melvin Sanicas, Sam Lutfi, Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Nazara, Ash, Jason A Saslow, Matt Curls, Eric Jensen, GrowingViolet, Jeffrey Mckishen, Christopher R Boucher, Alex Hackman, Piya Shedden, charles george, Tom Mosner, Jeremy Mysliwiec, Adam Brainard, Chris Peters, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources: 
https://www.usgs.gov/special-topic/water-science-school/science/surface-runoff-and-water-cycle?qt-science_center_objects=0#qt-science_center_objects 
https://www.groundsure.com/resources/grave-danger-cemeteries-as-a-source-of-groundwater-pollution/ 
https://www.nrcs.usda.gov/Internet/FSE_DOCUMENTS/stelprdb1263509.pdf 
https://apps.who.int/iris/bitstream/handle/10665/108132/EUR_ICP_EHNA_01_04_01(A).pdf;sequence=1 
https://www.scielo.br/j/urbe/a/GfyVv6QbhssjhZCG3tn5jgk/?lang=en 
https://link.springer.com/content/pdf/10.1023/A:1005186919370.pdf 
https://iwaponline.com/jwh/article/13/2/285/28303/Impact-of-cemeteries-on-groundwater-contamination 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5168774/pdf/brforeignmcrev72822-0125.pdf 
https://pubmed.ncbi.nlm.nih.gov/31069064/ 
https://www.researchgate.net/publication/233885209_On_the_shoals_of_giants_Natural_catastrophes_and_the_overall_destruction_of_the_Caribbean's_archaeological_record/download 


Image Sources:
https://www.istockphoto.com/photo/water-gm641159762-116141941
https://www.istockphoto.com/photo/grave-stones-and-memorials-under-a-red-maple-tree-gm155099610-18185238
https://www.istockphoto.com/photo/a-peaceful-cemetery-in-montreal-on-a-nice-day-gm176026655-10016386
https://www.istockphoto.com/photo/trinity-church-cemetery-in-new-york-city-gm477640001-36138048
https://commons.wikimedia.org/wiki/File:Microscopic_Typhoid_Fever.jpg
https://commons.wikimedia.org/wiki/File:E._coli_Bacteria_(7316101966).jpg
https://commons.wikimedia.org/wiki/File:Embalming_fluid.jpg
https://www.istockphoto.com/photo/old-cemetery-in-new-orleans-gm1271832460-374295442
https://www.storyblocks.com/video/stock/super-slow-motion-spring-water-flows-from-the-pipe-h-nuw3-xmja9pqbwp
https://commons.wikimedia.org/wiki/File:Hillside_Graveyard_on_Mayreau_-_panoramio.jpg

## How We Could Beat Childhood Peanut Allergies | SciShow News
 - [https://www.youtube.com/watch?v=BmkiwfL_o7Q](https://www.youtube.com/watch?v=BmkiwfL_o7Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-01-28 00:00:00+00:00

Go to https://thld.co/munkpack_scishow0122 and use code SCISHOW to get 20% off your first purchase! Thanks to Munk Pack for sponsoring today’s video!

More and more kids are avoiding peanut butter due to life threatening allergies, but we could make it so that no kid goes without a PBJ.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Dr. Melvin Sanicas, Sam Lutfi, Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Nazara, Ash, Jason A Saslow, Matt Curls, Eric Jensen, GrowingViolet, Jeffrey Mckishen, Christopher R Boucher, Alex Hackman, Piya Shedden, charles george, Tom Mosner, Jeremy Mysliwiec, Adam Brainard, Chris Peters, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.eurekalert.org/news-releases/940772 
https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(21)02390-4/fulltext

https://www.nature.com/articles/d41586-022-00119-1 
https://www.cambridge.org/core/journals/antiquity/article/party-like-a-sumerian-reinterpreting-the-sceptres-from-the-maikop-kurgan/EFEEFA5BD92653748F5A0F04CD133184 

IMAGES

https://www.istockphoto.com/photo/crunchy-and-smooth-peanut-butter-on-bread-gm669160414-122259303
https://www.istockphoto.com/photo/healthcare-and-medical-concept-female-scratching-the-itch-on-her-hand-cause-of-gm1127255820-297035710
https://www.istockphoto.com/photo/young-woman-with-asthma-attack-or-respiratory-problem-gm680793694-125020811
https://www.istockphoto.com/photo/fresh-apple-sauce-gm175519926-20810153
https://www.istockphoto.com/photo/peanut-butter-gm476278344-66505393
https://www.istockphoto.com/photo/childhood-allergies-gm875554900-244423342
https://www.istockphoto.com/photo/peanut-butter-and-jelly-gm486199796-72424381
https://www.cambridge.org/core/journals/antiquity/article/party-like-a-sumerian-reinterpreting-the-sceptres-from-the-maikop-kurgan/EFEEFA5BD92653748F5A0F04CD133184#figures
https://commons.wikimedia.org/wiki/File:Kurgan-2_Maykop.JPG
https://commons.wikimedia.org/wiki/File:%D0%9A%D1%80%D0%BE%D0%BC%D0%BB%D0%B5%D1%85_%D0%BA%D1%83%D1%80%D0%B3%D0%B0%D0%BD%D0%B0_04.JPG
https://www.istockphoto.com/photo/harvesting-ripe-barley-gm1165760211-320883079
https://commons.wikimedia.org/wiki/File:Cylinder_seal_and_modern_impression-_banquet_scene_with_seated_figures_drinking_a_liquid_through_straws_MET_ss56_157_1.jpg


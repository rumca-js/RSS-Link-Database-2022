# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## Getting shocked by an electrostimulation suit in VR
 - [https://www.youtube.com/watch?v=OKeKeCTOfgU](https://www.youtube.com/watch?v=OKeKeCTOfgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-01-29 00:00:00+00:00

What if you could feel actual PAIN in virtual reality? What if whatever game or simulation you were in allowed you to feel whatever was happening to you? Would you put yourself in pain just to heighten your immersion? 

Today I am taking a look at two electrostimulation suits I tried, the hyper advanced and amazing Teslasuit and the newcomer on the block- OWO Skin. Two e-stim devices built to quite literally shock you, allowing your muscles to contract and pain to be felt through electrical pulses in the shirt/ suit. I'm honestly not sure if the world is ready for this, but it's coming anyways- and I'm so excited to see everyone's reactions. 

OWO SUIT LINK:
https://owogame.com/

My links:

DIscord.gg/Thrill
Twitter.com/Thrilluwu
Twitch.tv/Thrilluwu


# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## New Battery DOUBLES Range of Tesla Model S in Road Test
 - [https://www.youtube.com/watch?v=TFY_uqif3jY](https://www.youtube.com/watch?v=TFY_uqif3jY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2022-01-29 00:00:00+00:00

Visit https://brilliant.org/coldfusion/ to get start learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

ColdFusion Discord:  https://discord.gg/coldfusion

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

ColdFusion Merch:
INTERNATIONAL: https://store.coldfusioncollective.com/
AUSTRALIA: https://shop.coldfusioncollective.com/

If you enjoy my content, please consider subscribing!
I'm also on Patreon: https://www.patreon.com/ColdFusion_TV
Bitcoin address: 13SjyCXPB9o3iN4LitYQ2wYKeqYTShPub8

--- "New Thinking" written by Dagogo Altraide ---
This book was rated the 9th best technology history book by book authority.
In the book you’ll learn the stories of those who invented the things we use everyday and how it all fits together to form our modern world.
Get the book on Amazon: http://bit.ly/NewThinkingbook
Get the book on Google Play: http://bit.ly/NewThinkingGooglePlay
https://newthinkingbook.squarespace.com/about/

--- ColdFusion Social Media ---
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusionTV

Sources:

ONE's Experimental Testing Video: https://www.youtube.com/watch?v=fWj2YCdoc9A

https://www.forbes.com/sites/jeffkart/2022/01/16/michigan-startups-gemini-battery-powers-tesla-for-752-miles-on-a-single-charge/?sh=269adfd82d53

https://interestingengineering.com/a-prototype-battery-pack-powers-tesla-model-s-for-752-miles-on-a-single-charge

https://www.drive.com.au/caradvice/cars-best-fuel-economy-australia/

https://www.researchgate.net/publication/302842660_Structure_of_prismatic_battery_modules_with_scalable_architecture

https://one.ai/gemini/

My Music Channel:  https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

//Soundtrack//

Burn Water - Nostalgia Dreams

No Spirit - leaves covered by snow

Cahb - Secrets

Sleepy Fish - Forgot it was Monday

Burn Water - Ikigai

» Music I produce | http://burnwater.bandcamp.com or 
» http://www.soundcloud.com/burnwater
» https://www.patreon.com/ColdFusion_TV
» Collection of music used in videos: https://www.youtube.com/watch?v=YOrJJKW31OA

Producer: Dagogo Altraide


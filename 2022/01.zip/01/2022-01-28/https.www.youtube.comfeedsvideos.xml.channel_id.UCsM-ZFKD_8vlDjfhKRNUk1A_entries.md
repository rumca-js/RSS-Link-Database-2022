# Source:MuzoTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A, language:pl-PL

## Hela - Koncert (MUZO.FM)
 - [https://www.youtube.com/watch?v=gynjOjD5GkM](https://www.youtube.com/watch?v=gynjOjD5GkM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsM-ZFKD_8vlDjfhKRNUk1A
 - date published: 2022-01-28 00:00:00+00:00

Hela na żywo w MUZO.FM. Artystka wykonała w naszym studiu kawałki: Jak film, Jedną nogą, Na opał i Na swój kształt z EPki Na swój kształt. 

0:00 1. Jedną nogą
3:14 2. Na swój kształt
6:25 3. Jak film
9:53 4. Na opał

Subskrybuj nasz kanał: http://www.muzo.tv
Facebook: http://www.facebook.com/MUZO.FM
Facebook: http://www.facebook.com/MUZO.TV
Facebook Hela: http://www.facebook.com/helamusicofficial
Instagram Hela: http://www.instagram.com/hela_fine
Instagram: http://www.instagram.com/muzofm
Twitter: http://twitter.com/muzo_fm
Strona: http://www.muzo.fm 

#popolsku


## Anti-mandate 'Freedom Convoy' said to be largest truck convoy ever | KUTV
 - [https://kutv.com/news/nation-world/anti-vaccine-mandate-freedom-convoy-said-to-be-largest-ever-coronavirus-covid-canada-united-states-truck-mask-vaccinated-border-gofundme](https://kutv.com/news/nation-world/anti-vaccine-mandate-freedom-convoy-said-to-be-largest-ever-coronavirus-covid-canada-united-states-truck-mask-vaccinated-border-gofundme)
 - RSS feed: https://kutv.com
 - date published: 2022-01-28 20:38:33+00:00

Anti-mandate 'Freedom Convoy' said to be largest truck convoy ever | KUTV


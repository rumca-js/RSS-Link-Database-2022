# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## What Shopping On Amazon Feels Like
 - [https://www.youtube.com/watch?v=nQpxAvjD_30](https://www.youtube.com/watch?v=nQpxAvjD_30)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2022-01-29 00:00:00+00:00

Find out which companies have your data and reclaim it with Mine! Sign up right here: https://bit.ly/saymine-ryangeorge

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats.
Twitter/Instagram: @TheRyanGeorge


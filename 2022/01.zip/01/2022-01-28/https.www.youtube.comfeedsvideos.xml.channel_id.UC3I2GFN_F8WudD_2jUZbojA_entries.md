# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## SMooCH 10th Anniversary - A Benefit for Seattle Children’s Hospital
 - [https://www.youtube.com/watch?v=K2dt1Arp4hw](https://www.youtube.com/watch?v=K2dt1Arp4hw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-28 00:00:00+00:00

KEXP, with Sub Pop records, is proud to present SMooCH (Seattle Musicians for Children’s Hospital) 10th Anniversary Celebration.

Hosted by KEXP’s John Richards, Megan Jasper, Pete and Brandy Nordstrom, this 10th Anniversary benefit show features performances by Phantogram, Modest Mouse, Sir Mix-a-Lot, The Head and the Heart, Naked Giants, Preservation Hall Jazz Band, Redd Kross, Shiana Shepherd, Allen Stone and a special performance by Deep Sea Diver.

SMooCH also shares stories from an amazing patient and their family at Seattle Children’s Hospital.
To learn more about this event and to donate visit http://www.smoochforkids.com


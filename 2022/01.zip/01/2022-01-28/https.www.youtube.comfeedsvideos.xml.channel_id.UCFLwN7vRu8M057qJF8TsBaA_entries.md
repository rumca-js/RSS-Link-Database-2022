# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Coffee Is An Absolute Nightmare - This Is Why
 - [https://www.youtube.com/watch?v=doGP1bozpG0](https://www.youtube.com/watch?v=doGP1bozpG0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2022-01-28 22:00:12+00:00

Offset your carbon footprint with me on Wren! We'll plant 10 extra trees for the first 100 people who sign up! https://www.wren.co/start/upisnotjump

Coffee is my favorite drink. I recently began being able to drink more than one cup of coffee a day without the world starting to spin, but it’s a risky process.

Either way, join me in discovering why coffee is an absolute nightmare. This video discusses the history and geography of coffee, then the growing and processing, then its effect on the body, and finally stuff you can do to make your coffee drinking more ethical. 

I am bad at writing sentences, maybe I need to drink more coffee.. Or less.

Patreon bros: https://www.patreon.com/UpIsNotJump 
Merch-o-bros: https://www.pixelempire.com/pages/upisnotjump
Twitter-o-fish: https://twitter.com/UpIsNotJump

Editing workflow by: https://twitter.com/MudanTV

Kaldi art by:
@skutchdraws

Sources 
1. Natural Coffee Processing by Cafe Imports
2. A Film About Coffee by Brandon Lee

Links to sources, in the order they are mentioned in the video

Growing coffee in the rainforest
https://www.rainforest-alliance.org/articles/rainforest-alliance-certified-coffee

Sun grown coffee reducing biodiversity in the rainforest
https://books.google.co.uk/books?id=mpEtlI7cjRcC&amp;pg=RA2-PA14&amp;lpg=RA2-PA14&amp;dq=sun+coffee+yield+percent&amp;source=bl&amp;ots=42Ip-aTBBg&amp;sig=ACfU3U3q78j6mPLkRUrhMVmwB8msLWTv-w&amp;hl=en&amp;sa=X&amp;ved=2ahUKEwjgto2e3KXwAhU1oVwKHemWB_UQ6AEwEXoECBYQAw#v=onepage&amp;q&amp;f=false

https://birdandwild.co.uk/pages/sun-grown-vs-shade-grown-spot-the-difference#:~:text=Shade%20grown%20land%20is%20typically,than%20sun%20grown%20coffee%20plantations!&amp;text=Coffee%20is%20grown%20in%20the,coffee%20grows%20in%20the%20wild.

Sun vs Shade - flavor and damage
https://www.thecalltoconserve.com/blog/coffee#:~:text=The%20soil%20cannot%20maintain%20its,coffee%20is%20cheaper%20to%20sell.

Soil Erosion from Sun
https://birdandwild.co.uk/pages/sun-grown-vs-shade-grown-spot-the-difference#:~:text=The%20clue%20is%20in%20the,a%20year%20and%20higher%20yields.

Growing and picking of coffee process:
https://www.ncausa.org/about-coffee/10-steps-from-seed-to-cup#:~:text=A%20coffee%20bean%20is%20actually,large%20beds%20in%20shaded%20nurseries.

Shade beans are arabica 
https://www.dlgcoffee.org/news/2017/4/6/coffee-cultivation-sun-grown-shade-grown-and-how-it-impacts-the-environment-and-the-farmers

Endorphins and morphine similarities:
https://www.google.com/search?q=natural+endorphin+morphine&amp;tbm=isch&amp;ved=2ahUKEwjtwcbzsLLwAhVZ44UKHUdQAEQQ2-cCegQIABAA&amp;oq=natural+endorphin+morphine&amp;gs_lcp=CgNpbWcQA1CGZljldWDTdmgCcAB4AIABSIgBlwSSAQE5mAEAoAEBqgELZ3dzLXdpei1pbWfAAQE&amp;sclient=img&amp;ei=BnqSYO2mDtnGlwTHoIGgBA&amp;bih=1040&amp;biw=1830&amp;rlz=1C1CHBF_enGB889GB889#imgrc=n47Qapr_fmaqfM

Adenosine slows you down, coffee speeds you up
https://thebrain.mcgill.ca/flash/i/i_03/i_03_m/i_03_m_par/i_03_m_par_cafeine.html

Adenosine in sleep
https://www.frontiersin.org/articles/10.3389/fnins.2019.00740/full


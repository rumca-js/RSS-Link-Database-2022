# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## OnePlus 10 Pro Impressions: What Happened?
 - [https://www.youtube.com/watch?v=7IaYSxDp88s](https://www.youtube.com/watch?v=7IaYSxDp88s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-01-28 00:00:00+00:00

OnePlus 10 Pro is out... kinda
Sponsored by Cash App: Download from App Store/Google Play store - Use code MARQUES for $15 and $10 goes to Girls Who Code!

What Happened to OnePlus? https://youtu.be/9EOAEWC9hJ4

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds https://lnk.to/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Phone provided by brand for video.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


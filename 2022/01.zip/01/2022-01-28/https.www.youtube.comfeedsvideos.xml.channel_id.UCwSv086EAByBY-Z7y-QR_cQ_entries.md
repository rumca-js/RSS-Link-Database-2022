# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Od paszportów covidowych, do cyfrowych identyfikatorów obywatelskich
 - [https://www.youtube.com/watch?v=1-IDPae4ge0](https://www.youtube.com/watch?v=1-IDPae4ge0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-01-29 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3gaaScg
2. https://bit.ly/3iVe1yX
3. https://bit.ly/3ua28eh
4. https://bit.ly/3G97Lvz
5. https://bit.ly/3AJYqcx
6. https://bit.ly/3obhDyH
7. https://bit.ly/3s4YwaT
8. https://bit.ly/3o5UO0f
9. https://bit.ly/3ub279P
---------------------------------------------------------------
💡 Tagi: #QR #polityka
--------------------------------------------------------------

## Druk nr 1981, to prawdopodobnie najbardziej absurdalna ustawa covidowa na świecie!
 - [https://www.youtube.com/watch?v=jTSqConcqsg](https://www.youtube.com/watch?v=jTSqConcqsg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-01-28 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3o9ChPL
2. https://bit.ly/3AF6hIp
3. https://bit.ly/3Gc89JU
4. https://bit.ly/3J2Oz4L
---------------------------------------------------------------
🎴 Do kolażu wykorzystano grafikę autorstwa: 
rybnik.com.pl - https://bit.ly/3oZavq2
---
camprest.com - https://bit.ly/3HqXoF7
---------------------------------------------------------------
💡 Tagi: #praca #PCR
--------------------------------------------------------------


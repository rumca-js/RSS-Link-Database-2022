# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Actually, Intel is doing great now
 - [https://www.youtube.com/watch?v=5KweFH7Cauk](https://www.youtube.com/watch?v=5KweFH7Cauk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-01-28 00:00:00+00:00

Visit https://brilliant.org/TFC/ to get started learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This week the PC industry, including Intel, had an incredible quarter, regulators managed to stop both Facebook's Libra cryptocurrency project and the Nvidia/ARM acquisition, and the next Qualcomm chip, the 8 Gen 1+ got leaked.

Episode 81

This video on Nebula: https://nebula.app/videos/the-friday-checkout-wait-intel-is-actually-doing-great
Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 
Quiz: https://link.crrowd.com/quiz

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:30 Release highlights
1:05 PC boom
3:24 Libra/Nvidia-ARM regulatory death
5:33 Snapdragon 8 Gen 1+


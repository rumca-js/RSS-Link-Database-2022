# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## THE BEE WEEKLY: Backhanding Blue Checks and Now You Can Be A Skittle
 - [https://www.youtube.com/watch?v=iF25ju6SnvI](https://www.youtube.com/watch?v=iF25ju6SnvI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-01-28 00:00:00+00:00

Candy can be trans now, Democrats are talking about backhanding women they disagree with, and pro-life conservatives tell a pro-abortion Oklahoma state legislator that his terms are acceptable. This week at The Babylon Bee, Kyle and Adam talk to Skillet’s John Cooper about his new album, Dominion, which is lifting spirits and melting faces.

This episode is brought to you by Alliance Defending Freedom Legal Fund: go to: http://ADFLegal.org/babylonbee

This episode is also brought to you by Enduring Word Bible Commentary, which is completely free. Go to: http://enduringword.com

Kyle and Adam talk about the banger and bomb articles of the week which involve a new M&M trans character and Uyghur Muslims being forced to make Golden State Warrior jerseys. Podcast viewers can enjoy the video about the first trans Skittle. Then, Adam gives you the news you need to know this week in Weakly News. The Bee also gets caught up on all the crazy things Blue Checks say like how women should be backhanded, it’s now celebrated for a wife to renounce her husband’s thought crimes, and USA Today wants us to better understand pedophilia for some reason. Also, Trey Gowdy doesn’t understand how three times zero isn’t three. Then it’s time for The Celebrity Dating Game featuring AOC!

Kyle and Adam then talk to John Cooper from Skillet about Dominion, honoring the Emperor, and what’s causing crime to skyrocket in our cities. Of course, there is also hate mail.

In the subscriber lounge, Gavin answers the ten questions and shows off his lightsaber collection with the news that we are one step closer to making lightsabers a reality. Subscribers also get the rest of the interview with Skillet’s John Cooper!


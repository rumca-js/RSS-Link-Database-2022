# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Support of Taiwan independence could spark US military conflict with China, Chinese ambassador says
 - [https://www.cnn.com/2022/01/28/asia/china-ambassador-us-taiwan-military-conflict-warning/index.html](https://www.cnn.com/2022/01/28/asia/china-ambassador-us-taiwan-military-conflict-warning/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 23:41:41+00:00

China and the United States could end up in a military conflict if the United States encourages Taiwan's independence, Beijing's ambassador to Washington said in a US radio interview broadcast on Friday.

## Governor's unusual move cracks up CNN anchors
 - [https://www.cnn.com/videos/politics/2022/01/28/jim-justice-west-virginia-bulldog-kiss-her-hiney-sot-nr-vpx.cnn](https://www.cnn.com/videos/politics/2022/01/28/jim-justice-west-virginia-bulldog-kiss-her-hiney-sot-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 23:20:30+00:00

Gov. Jim Justice (R-WV) used his pet bulldog to fire back at critics during his annual State of the State speech - singling out Bette Midler's earlier criticism of Sen. Joe Manchin (D-WV).

## Lithuania warns that Ukraine invasion will lead to 'war of Europe'
 - [https://www.cnn.com/videos/world/2022/01/28/lithuania-foreign-minister-ctw-intl-vpx.cnn](https://www.cnn.com/videos/world/2022/01/28/lithuania-foreign-minister-ctw-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 23:02:31+00:00

Lithuanian Foreign Minister Gabrielius Landsbergis reacts to Germany's position on reinforcing Ukraine and surrounding regions, saying a possible war between Russia and Ukraine will actually be a 'war of Europe'.

## Oil executives barred from leaving Peru after massive spill causes 'ecological disaster'
 - [https://www.cnn.com/2022/01/28/americas/peru-oil-spill-travel-ban-intl/index.html](https://www.cnn.com/2022/01/28/americas/peru-oil-spill-travel-ban-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 22:50:19+00:00

Four oil executives in Peru have been barred from leaving the country as authorities investigate a massive oil spill that forced Lima to declare an environmental emergency earlier this month.

## Meryl Streep asked what President she based Netflix role on. Hear her reply
 - [https://www.cnn.com/videos/media/2022/01/28/meryl-streep-adam-mckay-amanpour-dont-look-up-president-sot-vpx.cnn](https://www.cnn.com/videos/media/2022/01/28/meryl-streep-adam-mckay-amanpour-dont-look-up-president-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 22:29:26+00:00

CNN's Christiane Amanpour speaks with Oscar-winning actress Meryl Streep and Director Adam McKay about the Netflix hit film "Don't Look Up."

## Hiker fell 700 feet to his death while trying to take a photo
 - [https://www.cnn.com/2022/01/28/us/arizona-hiker-photo-fall-death/index.html](https://www.cnn.com/2022/01/28/us/arizona-hiker-photo-fall-death/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 18:45:57+00:00

A hiker in Arizona slipped and fell hundreds of feet to his death Monday after trying to take a photo in Lost Dutchman State Park, according to the Pinal County Sheriff's Office.

## Dramatic video shows off-duty police officer stopping armed robbery
 - [https://www.cnn.com/2022/01/28/europe/barcelona-robbery-off-duty-police-scli-intl/index.html](https://www.cnn.com/2022/01/28/europe/barcelona-robbery-off-duty-police-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 17:54:01+00:00

An off-duty police officer went into a supermarket near Barcelona, Spain to buy groceries and ended up tackling a suspected armed robber.

## Bridge in Pittsburgh collapses hours before scheduled Biden visit to talk infrastructure
 - [https://www.cnn.com/collections/pittsburgh-bridge-intl-012822/](https://www.cnn.com/collections/pittsburgh-bridge-intl-012822/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 17:46:07+00:00



## See off-duty cop take down attempted armed robber
 - [https://www.cnn.com/videos/world/2022/01/28/armed-robbery-barcelona-supermarket-orig-kj.cnn](https://www.cnn.com/videos/world/2022/01/28/armed-robbery-barcelona-supermarket-orig-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 17:41:59+00:00

An officer in Spain sprung to action at a supermarket near Barcelona when he realized an armed robbery was afoot.

## Landmark moment as Iranian women in attendance to watch Iran qualify for World Cup
 - [https://www.cnn.com/2022/01/28/football/iranian-women-football-world-cup-qualification-spt-intl/index.html](https://www.cnn.com/2022/01/28/football/iranian-women-football-world-cup-qualification-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 17:18:19+00:00

Iranian women were allowed to share a landmark moment as Iran secured qualification on Thursday for November's World Cup in Qatar.

## Italy's former royal family wants the crown jewels back
 - [https://www.cnn.com/style/article/italy-crown-jewels-scli-intl/index.html](https://www.cnn.com/style/article/italy-crown-jewels-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 17:13:06+00:00

Italy's former royal family has asked the country's central bank to return the crown jewels, a lawyer for the family confirmed to CNN.

## Elon Musk just took the entire EV sector down with these comments
 - [https://www.cnn.com/2022/01/28/investing/elon-musk-tesla-stock-slide/index.html](https://www.cnn.com/2022/01/28/investing/elon-musk-tesla-stock-slide/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 17:03:18+00:00



## 'Shang-Chi' star Simu Liu voices support for vaccines after revealing he lost grandparents to Covid
 - [https://www.cnn.com/2022/01/28/entertainment/simu-liu-vaccines-covid/index.html](https://www.cnn.com/2022/01/28/entertainment/simu-liu-vaccines-covid/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 14:05:17+00:00

Simu Liu, the star of Marvel's "Shang-Chi," is voicing his support for Covid-19 vaccines after revealing he lost his grandparents to the virus.

## Lawmaker pushes conspiracy about athletes' responses to Covid vaccine
 - [https://www.cnn.com/videos/politics/2022/01/28/cillizza-fact-check-ron-johnson-false-claim-athletes-dropping-on-field-covid-vaccine-newday-bts-vpx.cnn](https://www.cnn.com/videos/politics/2022/01/28/cillizza-fact-check-ron-johnson-false-claim-athletes-dropping-on-field-covid-vaccine-newday-bts-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 14:00:16+00:00

CNN's Chris Cillizza fact-checks the entirely false claim pushed by Senator Ron Johnson (R-WI) that athletes have been "dropping dead on the field" due to the Covid-19 vaccine.

## 'Janet Jackson' tells the singer's story, but it's clear who's in control
 - [https://www.cnn.com/2022/01/28/entertainment/janet-jackson-documentary-review/index.html](https://www.cnn.com/2022/01/28/entertainment/janet-jackson-documentary-review/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 13:50:04+00:00

Janet Jackson gave a documentary crew access for five years, but with Jackson and brother Randy Jackson serving as executive producers the resulting project, "Janet Jackson," feels too conspicuously like a licensed product. Addressing some uncomfortable parts of her biography but sidestepping others, it's pretty obvious who's in control here.

## A woman has never won this Oscar. That could soon change
 - [https://www.cnn.com/style/article/women-cinematographers-oscars-ari-wegner-claire-mathon-helene-louvart-spc-intl/index.html](https://www.cnn.com/style/article/women-cinematographers-oscars-ari-wegner-claire-mathon-helene-louvart-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 09:27:17+00:00

Cinematography is the final frontier for women at the Oscars. Gendered acting categories aside, after 93 years, it is the only category that still exists for which a woman has never won an Academy Award.

## In pictures: Photography contest turns lens on life in China
 - [https://www.cnn.com/style/article/global-sinophoto-awards-2021/index.html](https://www.cnn.com/style/article/global-sinophoto-awards-2021/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 06:30:41+00:00

A village shadow puppet show, a shepherd grazing livestock and a pair of young acrobats performing handstands are among the scenes depicted in a photography competition shining a light on life in China.

## 'Working through list of missiles': Expert on North Korea testing
 - [https://www.cnn.com/videos/world/2022/01/27/north-korea-missile-tests-hancocks-pkg-ctw-intl-vpx.cnn](https://www.cnn.com/videos/world/2022/01/27/north-korea-missile-tests-hancocks-pkg-ctw-intl-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-28 02:54:03+00:00

CNN's Paula Hancocks reports as North Korea is believed to have launched a sixth missile test -- a record for the month of January.


# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Moon Knight - Official Trailer (My Thoughts)
 - [https://www.youtube.com/watch?v=8K2XHb1yjAE](https://www.youtube.com/watch?v=8K2XHb1yjAE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-01-18 00:00:00+00:00

A trailer for Marvel's MOON KNIGHT has hit Youtube, and I'm surprised! Here are my thoughts!

Watch the trailer here: https://www.youtube.com/watch?v=x7Krla_UxRg&t=2s&ab_channel=MarvelEntertainment

#MoonKnight


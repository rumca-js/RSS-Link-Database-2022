# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Lord of the Rings: The Rings of Power! Amazon Title Announcement Teaser Reaction
 - [https://www.youtube.com/watch?v=58Wuq9XkSNk](https://www.youtube.com/watch?v=58Wuq9XkSNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-01-19 00:00:00+00:00

We have a title and a teaser!! The Lord of the Rings: The Rings of Power premieres on September 2, 2022 on Amazon Prime Video!  Let's chat about what we think about this new title, what it means for the show, and when we may get the first trailer!

My History of Tolkien's Rings of Power Playlist: https://youtu.be/CH_hwIqeVJ0

Hit subscribe - and the bell so you don't miss future updates on THE RINGS OF POWER!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

#lordoftherings #ringsofpower #lotrrop


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Australia's Vaccine Apartheid
 - [https://www.youtube.com/watch?v=N_os74m9uFI](https://www.youtube.com/watch?v=N_os74m9uFI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-01-19 00:00:00+00:00

As Australian police arrest middle aged women for allegedly nor showing their vaccine passports, its politicians are considering charging the unvaccinated for healthcare. So, are we witnessing the creation of a two-tier society?  
#PoliceState #VaccinePassports #VaccineAparthied #TwoTierSociety 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## RAGE RISE & Bashing The Unvaxxed - Follow The Money!!
 - [https://www.youtube.com/watch?v=lzMxmQsTmEg](https://www.youtube.com/watch?v=lzMxmQsTmEg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-01-18 00:00:00+00:00

As passengers slap each other on planes, what is it that’s driving the increasing tribalism around vaccines, and who is it benefitting? 
#vaccines #viralvideo #masks #billionaires #WarrenBuffett 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## See? We Don’t Need To Work, They NEED US!
 - [https://www.youtube.com/watch?v=8_xLYfi10JQ](https://www.youtube.com/watch?v=8_xLYfi10JQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-01-18 00:00:00+00:00

Should we all just stop working? Can we give up our sh*t jobs and pointless work to focus on projects that really matter and add value to society? In this video I discuss with author Daniel Pinchbeck the idea of a post-work society. Is it inevitable anyway with the rise of AI and automation? What did the pandemic show in terms of what work is essential and what isn’t? Should we re-organise society now before its too late so all of these fast-moving technological advancements can benefit us and ordinary people rather than just lining the pockets of the rich?

You can listen to the rest of this Under the Skin podcast with Daniel Pinchbeck here: http://luminary.link/russell

Daniel Pinchbeck is an American author - his books include Breaking Open the Head: A Psychedelic Journey into the Heart of Contemporary Shamanism and Notes from the Edge Times.

#Revolution #Anarchism #Socialism #Elites #GreatReset 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


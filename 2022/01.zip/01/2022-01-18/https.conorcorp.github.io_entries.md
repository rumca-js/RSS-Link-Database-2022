## Make debugging suck less. Keep a logbook. 📓 | Conor Lamb
 - [https://conorcorp.github.io/posts/make-debuggin-suck-less/](https://conorcorp.github.io/posts/make-debuggin-suck-less/)
 - RSS feed: https://conorcorp.github.io
 - date published: 2022-01-18 17:07:59.170151+00:00

Scientists keep logbooks for their findings. Why don’t computer scientists? A great place to start doing this is for debugging. Debugging sucks enough as is, make it easier on yourself. A logbook will… 🗺 Enumerate where you are in the bug fix journey. You’ll forget this journey when you pick it up tomorrow, write it down. 🌳 Keep you rooted to the ground. (Creating an “issue stack”.) Related to above, it often feels like you’re completely lost in the aether when you’re 50 opened browser tabs deep into an issue that’s not even the same issue anymore, its a sub issue of a sub issue.


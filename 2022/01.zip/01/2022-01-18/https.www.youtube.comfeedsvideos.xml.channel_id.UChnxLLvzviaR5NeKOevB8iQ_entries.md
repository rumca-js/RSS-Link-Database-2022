# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## I Want You To Have This (Modular System Giveaway with Perfect Circuit)
 - [https://www.youtube.com/watch?v=8bk62olg8VM](https://www.youtube.com/watch?v=8bk62olg8VM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-01-18 00:00:00+00:00

PLEASE DO NOT ENGAGE WITH SCAMMERS
You will be contacted via an official Perfect Circuit representative, not by me, not by anyone here or on telegram or on Twitter.
Enter to win here (US only): https://www.perfectcircuit.com/contests
Check out my interview with PC about this system: https://www.perfectcircuit.com/signal/red-means-recording-interview
Watch the demos here: https://youtu.be/tkHI17XaYQY

Modules in this video: 
ALM Pamela's New Workout: https://bit.ly/2QRxnZO
VPME QD: http://bit.ly/pc_VPME_QD
Make Noise Morphagene: https://bit.ly/35RYIiS
Endorphin.es Milky Way: https://bit.ly/3mIxh48
Tubbutec 6equencer TR-Style Sequencer (1U): https://bit.ly/3qBJlVO

00:00 intro
01:11 demo selection
02:58 system walkthrough
19:18 outro

Videos on these modules: 
Pamela's New Workout: https://youtu.be/k5z6CCSfflo
VPME QD: https://youtu.be/Jo7QDkdDMPg
Make Noise Morphagene: https://youtu.be/x0Yz5BJFr78
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


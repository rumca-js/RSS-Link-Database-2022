# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## A GPU you might be able to buy… But shouldn’t. - AMD Radeon RX 6500 XT
 - [https://www.youtube.com/watch?v=KYp6pEDm4E8](https://www.youtube.com/watch?v=KYp6pEDm4E8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-19 00:00:00+00:00

Use code LINUSTECHTIPS16 for up to 16 FREE MEALS + 3 Surprise Gifts across 6 HelloFresh boxes plus free shipping at https://bit.ly/3ei8GhO!

Thanks to HelloFresh for sponsoring this video!

Go to https://privacy.com/linus ​to get $5 off your first purchase!

GPUs are impossible to buy, but AMD, Nvidia, and soon Intel are all releasing new cards. The Radeon RX 6500 XT is the first new card of 2022, on TSMC’s 6nm process. But is it TOO affordable?

Discuss on the forum: https://linustechtips.com/topic/1405067-a-gpu-you-might-be-able-to-buy%E2%80%A6-but-shouldn%E2%80%99t/

Buy an AMD Radeon GPU
Amazon: https://geni.us/BYWFs
Best Buy: https://geni.us/pBUxo
Newegg: https://geni.us/h7ewftY

Buy Radeon RX 6600
Amazon: https://geni.us/KFHcodo
Best Buy: https://geni.us/cIJSA
Newegg: https://geni.us/zuQeT

Buy GTX 1660
Amazon: https://geni.us/Dwqofbv
Newegg: https://geni.us/gkGjC
B&H: https://geni.us/QFBA

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:04 Cut all the specs!
2:05 So what is this thing?
2:45 Gaming performance
4:22 A problem appears: Bandwidth
5:39 Productivity
6:38 This is supposed to be an upgrade card
7:27 Thermals & Power
8:35 Conclusion

## Norton Crypto. It's EVEN WORSE than you think....
 - [https://www.youtube.com/watch?v=bi_xedWzfqU](https://www.youtube.com/watch?v=bi_xedWzfqU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-18 00:00:00+00:00

You can get 50% off your first month of any KiwiCo crate at: http://kiwico.com/LTT50

Norton has made an Ethereum mining pool that comes with Norton 360… is it any good? Is it a scam? Let’s find out!

Discuss on the forum: https://linustechtips.com/topic/1404870-i%E2%80%99m-crypto-mining-with-norton-360-how-bad-could-it-be/

Buy NVIDIA RTX 2080 Super
  Amazon: https://geni.us/ieFsKEa
  Newegg: https://geni.us/LfK3

Buy Noctua NH-D14
  Amazon: https://geni.us/8ZfyBMU
  Newegg: https://geni.us/d981P

Buy Intel Core i9-11900K
  Amazon: https://geni.us/VTrQR
  Best Buy: https://geni.us/kdfcPqL
  Newegg: https://geni.us/8BCe

Buy G.Skill Ripjaws 2x16GB 3600MHz
  Amazon: https://geni.us/9rD3PuM
  Newegg: https://geni.us/SJoa4b

Buy Asus Prime Z590-P
  Amazon: https://geni.us/sLvQjm
  Newegg: https://geni.us/ACb6C
  B&H: https://geni.us/BAAp3j

Buy Corsair HX1200W
  Amazon: https://geni.us/jwot
  Best Buy: https://geni.us/oLMi
  Newegg: https://geni.us/oLMi

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:03 Norton Crypto
1:41 Mining Pools
3:43 Cons
5:53 Testing
7:23 Get rid of it
8:30 Conclusion
10:30 Outro


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Top 20 NEW Open World Games of 2022
 - [https://www.youtube.com/watch?v=eVUVTV-ez74](https://www.youtube.com/watch?v=eVUVTV-ez74)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-19 00:00:00+00:00

Open world gaming isn't slowing down on PC, PS5, PS4, Xbox Series X/S/One, and Nintendo Switch. Here's everything to look forward to in 2022.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

20. Sonic Frontiers 

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : Q4 2022 



19. Atomic Heart 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : 2022 



18. Avatar: Frontiers of Pandora 

Platform : PC PS5 XSX|S LUNA STADIA 

Release Date : 2022  



17. DokeV 

Platform : PC PS5 XSX|S 

Release Date : TBA 



16. Crimson Desert 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : TBA 



15 Ark II 

Platform : PC XSX|S 

Release Date : TBA 2022 



14. The Day Before 

Platform : PC PS5 XSX|S 

Release Date : June 21, 2022  



13. State of Decay 3 

Platform : PC XSX|S 

Release Date : TBA 



12. Saints Row 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : August 23, 2022 



11. Forspoken

Platform : PC PS5 

Release Date : May 24, 2022        



10. Avowed 

Platform : PC XSX|S 

Release Date : TBA 



9. LEGO Star Wars: The Skywalker Saga 

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : Early 2022 



8. Gotham Knights 

Platform : PC PS4 PS5 Xbox One XSX|S  

Release Date : 2022 



7. Suicide Squad: Kill the Justice League 

Platform : PC PS5 XSX|S 

Release Date : 2022 



6. S.T.A.L.K.E.R. 2: Heart of Chernobyl 

Platform : PC XSX|S 

Release Date : December 8, 2022 



5. Dying Light 2: Stay Human 

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : February 4, 2022 



4. Starfield 

Platform : PC XSX|S 

Release Date : November 11, 2022 



3. Horizon Forbidden West 

Platform : PS4 PS5 

Release Date : February 18, 2022 



2. Elden Ring 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : February 25, 2022 



1. The Legend of Zelda: Breath of the Wild 2 

Platform : Switch 

Release Date : TBA 2022 



BONUS

Harry Potter: Hogwarts Legacy 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : Might be 2023 



GhostWire Tokyo

Platform : PC PS5 

Release Date : 2022  



Test Drive Unlimited Solar Crown 

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : September 22, 2022 



Fable 

Platform : PC XSX|S 

Release Date : TBA  


Sons of the Forest

Platform : PC

Release Date : 20 May 2022

0:00 Intro
0:14 - Sonic Frontiers
0:57 - Atomic Heart
1:49 - Avatar: Frontiers of Pandora
2:27 - Dokev
3:14 - Crimson Desert
3:48 - Ark 2
4:23 - The Day Before
5:08 - State of Decay 3
5:57 - Saints Row (2022)
6:58 - Forspoken
7:39 - Avowed
8:14 - LEGO Star Wars: The Skywalker Saga
9:05 - Gotham Knights
9:51 - Suicide Squad: Kill the Justice League
10:42 - S.T.A.L.K.E.R. 2: Heart of Chernobyl
11:19 - Dying Light 2: Stay Human
12:06 - Starfield
12:51 - Horizon Forbidden West
13:24 - Elden Ring
14:08 - The Legend of Zelda: Breath of the Wild 2
14:45 - Hogwarts Legacy
14:54 - Ghostwire: Tokyo
15:01 - Test Drive Unlimited Solar Crown
15:06 - Fable 4
15:12 - Sons of the Forest

## Xbox Reveals Plans For Activision Blizzard After BUYING Them
 - [https://www.youtube.com/watch?v=kXnGeOtvJ4o](https://www.youtube.com/watch?v=kXnGeOtvJ4o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-18 00:00:00+00:00

Xbox is acquiring Activision Blizzard for billions of dollars, reshaping the gaming industry for years to come. Let's dive into the details.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

#Xbox #Activision


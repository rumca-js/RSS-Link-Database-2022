# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Omicron, SA, UK, US in that order
 - [https://www.youtube.com/watch?v=uP_p0a9pWCQ](https://www.youtube.com/watch?v=uP_p0a9pWCQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-01-18 00:00:00+00:00

Avian influenza (bird flu), Is not a coronavirus

https://www.gov.uk/guidance/avian-influenza-bird-flu

H5N1 (H5N8)

Influenza A virus, subtype H5N1

Enzootic, (SE Asia) epizootic, panzootic

2003 to May 2020

861 confirmed human cases, 455 deaths

South Africa, leads the way

https://www.worldometers.info/coronavirus/country/south-africa/

SA hospital data

https://www.nicd.ac.za/diseases-a-z-index/disease-index-covid-19/surveillance-reports/daily-hospital-surveillance-datcov-report/

Zoe, Omicron wave has  peaked

https://covid.joinzoe.com/data#levels-over-time

UK data

https://coronavirus.data.gov.uk

ONS

https://www.ons.gov.uk/peoplepopulationandcommunity/healthandsocialcare/conditionsanddiseases/articles/coronaviruscovid19/latestinsights

Deaths in the UK involving coronavirus

Week ending 7 January 2022

1,023 deaths involving COVID-19

383 more than in the previous week

Accounted for around 1 in every 14 deaths (7.3%). 

Total deaths in UK, 13,886 (8.3% below the five-year average)

13 March 2020 to 7 January 2022, England and Wales

127,704 excess deaths above the five-year average

Positivity

Prevalence

England – 3,735,000 people (1 in 15)

Wales – 169,100 people (1 in 20)

Northern Ireland – 99,200 people (1 in 20)

Scotland – 297,400 people (1 in 20)

Antibodies, week beginning 20 December 2021

England, 97.5% of the adult population

Wales, 96.8% 

Northern Ireland, 97.4%

Scotland, 97.7%

Antibody thresholds, using data from Delta

Threshold of antibodies needed to provide protection from infections for those who are vaccinated

More than 88% of the population had antibodies at or above the higher threshold.

China

https://www.theguardian.com/world/live/2022/jan/17/covid-news-live-new-zealand-begins-vaccinating-children-aged-5-11-french-parliament-approves-vaccine-pass

One omicron infection detected in Beijing

Tuesday, 11th January, received a package from Toronto, via the US and Hong Kong (4 days)

Saturday 15th Patient self reported 
Pang Xinghuo, deputy director of Beijing’s CDC

Omicron virus transmits fast, please pay attention, avoid buying stuff from overseas, make sure you wear gloves, don’t bring the package indoors.

If you have to, clean the package outside with alcohol, and wash your hands

Dr Ian Mackay, virologist, University of Queensland

It’s an airborne virus. It’s not about surfaces. Technically, it can happen, sure. 

There’s a non-zero risk, sure. But is it happening again and again? No

If you see and hear horses, don’t think zebras

Transmission of SARS-CoV-2: implications for infection prevention precautions

https://www.who.int/news-room/commentaries/detail/transmission-of-sars-cov-2-implications-for-infection-prevention-precautions

SARS-CoV-2 contamination of surfaces and the survival of the virus on certain surfaces,

there are no specific reports which have directly demonstrated fomite transmission. 

People who come into contact with potentially infectious surfaces often also have close contact with the infectious person, 

Fact that other coronaviruses and respiratory viruses can transmit via fomites

Cancels public tickets for Winter Olympics in Beijing 

Selected spectators


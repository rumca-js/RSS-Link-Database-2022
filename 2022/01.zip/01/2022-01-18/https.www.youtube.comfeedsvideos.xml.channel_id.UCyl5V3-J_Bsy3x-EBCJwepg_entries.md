# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Murderer Undecided On Whether He'll Follow New Gun Laws
 - [https://www.youtube.com/watch?v=L138n7AXCD8](https://www.youtube.com/watch?v=L138n7AXCD8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-01-19 00:00:00+00:00

Gregory Ilinovich loves murdering people with illegal guns - so he's a bit concerned about all these new gun regulations. Luckily, he tends not to follow laws anyway.

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


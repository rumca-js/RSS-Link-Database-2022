# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Love Island contestants called out over social media ads
 - [https://www.bbc.co.uk/news/newsbeat-60040262?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-60040262?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-18 16:15:09+00:00

Anna Vakili, Belle Hassan and Francesca Allen are named and shamed by the advertising watchdog.

## New laws to tackle misleading crypto-asset adverts
 - [https://www.bbc.co.uk/news/technology-60032743?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60032743?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-18 16:04:53+00:00

The government is worried some consumers may not understand what they are buying.

## Microsoft plans to buy Call of Duty company Activision Blizzard for nearly $70bn
 - [https://www.bbc.co.uk/news/newsbeat-60042409?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-60042409?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-18 15:12:30+00:00

It's the biggest deal in gaming history, bringing some of the world's most popular titles to Game Pass.

## Aldi opens its first till-free supermarket
 - [https://www.bbc.co.uk/news/business-60038681?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60038681?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-18 13:20:39+00:00

The supermarket will bill people after they leave the store as part of a trial using new technology.

## US airlines warn of impending 5G flight disruption
 - [https://www.bbc.co.uk/news/business-60036831?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60036831?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-18 09:30:28+00:00

Airlines say the start of 5G mobile phone services on Wednesday will hit aircraft navigation systems.

## New campaign aims to stop more encrypted apps
 - [https://www.bbc.co.uk/news/59964656?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/59964656?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-18 01:05:36+00:00

No Place to Hide says end-to-end encryption makes it harder to detect child abuse.

## How Nigeria succeeded in clipping Twitter's wings
 - [https://www.bbc.co.uk/news/world-africa-60024742?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-60024742?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-18 00:16:23+00:00

Some fear that Twitter agreeing to new rules in Nigeria may encourage others to restrict social media.


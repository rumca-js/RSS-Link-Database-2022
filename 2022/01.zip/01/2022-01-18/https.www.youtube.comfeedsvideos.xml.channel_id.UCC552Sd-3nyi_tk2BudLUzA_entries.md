# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## When Will COVID End?
 - [https://www.youtube.com/watch?v=_1R_pg5QasA](https://www.youtube.com/watch?v=_1R_pg5QasA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2022-01-18 00:00:00+00:00

Coming up on two years of the Coronavirus pandemic, how much longer will it last? Is it like the Spanish flu or will it never go away?
Join our science mailing list: https://bit.ly/34fWU27

FOLLOW US!
Instagram: https://instagram.com/asapscience​​
Facebook: https://facebook.com/asapscience​​
Twitter: https://twitter.com/asapscience​​
TikTok: @AsapSCIENCE 

Written by: Gregory Brown & Mitchell Moffit 
Edited by: Luka Šarlija

SOURCES: 
https://www.nature.com/articles/d41586-021-03619-8
https://www.nature.com/articles/d41https://www.nature.com/articles/d41586-020-02544-6
586-021-03552-w
https://www.nature.com/articles/d41586-021-02275-2
https://www.nature.com/articles/d41586-021-00121-z
https://www.nature.com/articles/d41586-021-00268-9
https://www.gov.uk/government/publications/long-term-evolution-of-sars-cov-2-26-july-2021/long-term-evolution-of-sars-cov-2-26-july-2021
https://pubmed.ncbi.nlm.nih.gov/33831132/
https://pubmed.ncbi.nlm.nih.gov/33275900/
https://pubmed.ncbi.nlm.nih.gov/33464914/
https://pubmed.ncbi.nlm.nih.gov/32105090/
https://pubmed.ncbi.nlm.nih.gov/33289156/
https://www.nature.com/articles/d41586-021-00457-6?sap-outbound-id=382DC7C3B639EE3A28152D1161F765CCEB36860C


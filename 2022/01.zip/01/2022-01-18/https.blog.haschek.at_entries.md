## The curious case of the Raspberry Pi in the network closet
 - [https://blog.haschek.at/2019/the-curious-case-of-the-RasPi-in-our-network.html](https://blog.haschek.at/2019/the-curious-case-of-the-RasPi-in-our-network.html)
 - RSS feed: https://blog.haschek.at
 - date published: 2022-01-18 08:27:14.377498+00:00

how we found, analyzed (with the help of Reddit) and in the end caught the culprit of a malicious device in our network


## Liberal-Funded Global Fact-Checking Network Decries YouTube’s ‘Insufficient’ Censorship
 - [https://www.newsbusters.org/blogs/free-speech/joseph-vazquez/2022/01/18/liberal-funded-global-fact-checking-network-decries](https://www.newsbusters.org/blogs/free-speech/joseph-vazquez/2022/01/18/liberal-funded-global-fact-checking-network-decries)
 - RSS feed: https://www.newsbusters.org
 - date published: 2022-01-18 13:58:30+00:00

Liberal-Funded Global Fact-Checking Network Decries YouTube’s ‘Insufficient’ Censorship


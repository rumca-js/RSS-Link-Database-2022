## Jordan Peterson: Female Totalitarianism | with James Orr & Arif Ahmed (Cambridge)
 - [https://www.youtube.com/watch?v=fwow0lrwY8U](https://www.youtube.com/watch?v=fwow0lrwY8U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZViJTyN0OXTTuPQ2mimNWw
 - date published: 2022-01-18 20:59:14+00:00

Jordan Peterson: Female Totalitarianism | with James Orr & Arif Ahmed (Cambridge)


# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## RINGS OF POWER: Live Reaction
 - [https://www.youtube.com/watch?v=VMRl28_AlO4](https://www.youtube.com/watch?v=VMRl28_AlO4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-01-19 00:00:00+00:00

Let's react to the #RingsOfPower trailer! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene


Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p


Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  


P.O. Box: PO Box 7874 Henrico, VA 23231
#LordofTheRings #lotr

## The Crown Passes
 - [https://www.youtube.com/watch?v=fcCTIicRumY](https://www.youtube.com/watch?v=fcCTIicRumY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-01-19 00:00:00+00:00

Who writes the MOST fantasy today? 
To get $5 off your own personalized Magic Spoon variety pack and get a head start on your health and fitness resolutions, click this link https://magicspoon.thld.co/goblin_0122 and use code GOBLIN at checkout!

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

## Wheel of Time Tops Charts!🎬Witcher Dominates December⚔️Blood & Bone Adaptation!🩸-FANTASY NEWS
 - [https://www.youtube.com/watch?v=17FeyGBGTww](https://www.youtube.com/watch?v=17FeyGBGTww)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-01-18 00:00:00+00:00

Let's jump into the fantasy news! 
Check out today's Sponsor http://lordofmaps.com/ 
Use code DANIELTHEGREENE for 15% off

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

NEWS

00:00 intro

00:56 LotR Premier: https://twitter.com/LordOfTheRingTV/status/1481814264637583361/photo/1 

02:43 Genesis of Misery: https://www.tor.com/2022/01/12/a-space-opera-twist-on-joan-of-arc-revealing-the-genesis-of-misery-by-neon-yang/ 

04:55 Children of Blood and Bone adaptation: https://www.tor.com/2022/01/12/paramount-pictures-picks-up-tomi-adeyemis-children-of-blood-and-bone/ 

05:54 Eye of the World Bestseller AGAIN: https://twitter.com/torbooks/status/1479845358444453888?t=CT6zMOCjdeHUN-aEkqLT3A&s=19 

07:00 Witcher Dominance: https://deadline.com/2022/01/the-witcher-dominates-nielsen-streaming-chart-1234912344/ 

07:59 Black Knight: https://www.5d-blog.com/black-knight/ 

09:44 Shadow and Bone 2 Filming: https://twitter.com/DiscussingFilm/status/1481658261145219081?t=IGWPlb2l2SCCs8etTZve8w&s=19 

10:18 Kirby Returns: https://www.youtube.com/watch?v=RiPcRCWzcGo&t=3s&ab_channel=Nintendo 

11:00 X Trailer: https://www.youtube.com/watch?v=AjK2-qH-6MA&ab_channel=IGN


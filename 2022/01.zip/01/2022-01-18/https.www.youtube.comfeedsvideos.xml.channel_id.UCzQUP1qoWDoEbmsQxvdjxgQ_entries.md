# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## The Benefits of Sled Pulls for Knee Health
 - [https://www.youtube.com/watch?v=P_M0zruGWbA](https://www.youtube.com/watch?v=P_M0zruGWbA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-01-19 00:00:00+00:00

Taken from JRE #1766 w/Ben Patrick:
https://open.spotify.com/episode/2zfpB6RoKwylk3DbN3GXA0?si=7da1d1f2020947f1

## The Origins of KneesOverToesGuy
 - [https://www.youtube.com/watch?v=ppjUUwffYP8](https://www.youtube.com/watch?v=ppjUUwffYP8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-01-19 00:00:00+00:00

Taken from JRE #1766 w/Ben Patrick:
https://open.spotify.com/episode/2zfpB6RoKwylk3DbN3GXA0?si=7da1d1f2020947f1

## Phillip Frankland Lee on the Grind of Working in a Kitchen
 - [https://www.youtube.com/watch?v=HLl_VeFDTzI](https://www.youtube.com/watch?v=HLl_VeFDTzI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-01-18 00:00:00+00:00

Taken from JRE #1765 w/Phillip Frankland Lee:
https://open.spotify.com/episode/4YrIJKGWy3aGte21RUEKy1?si=7e44468cb02f479e

## Top Chef's Philip Frankland Lee on Receiving a Michelin Star
 - [https://www.youtube.com/watch?v=3qwh4wCsczI](https://www.youtube.com/watch?v=3qwh4wCsczI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-01-18 00:00:00+00:00

Taken from JRE #1765 w/Phillip Frankland Lee:
https://open.spotify.com/episode/4YrIJKGWy3aGte21RUEKy1?si=7e44468cb02f479e


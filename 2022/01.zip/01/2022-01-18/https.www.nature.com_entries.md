## The pandemic’s true death toll: millions more than official counts
 - [https://www.nature.com/articles/d41586-022-00104-8](https://www.nature.com/articles/d41586-022-00104-8)
 - RSS feed: https://www.nature.com
 - date published: 2022-01-18 09:45:12+00:00

The pandemic’s true death toll: millions more than official counts


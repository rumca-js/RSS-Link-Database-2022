# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Garage A Trois - Calm Down Cologne (Live on KEXP)
 - [https://www.youtube.com/watch?v=k5XIql1tV7M](https://www.youtube.com/watch?v=k5XIql1tV7M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-18 00:00:00+00:00

http://KEXP.ORG presents Garage A Trois performing “Calm Down Cologne” live in the KEXP studio. Recorded December 17, 2021.

Charlie Hunter - Guitar
Stanton Moore - Drums
Skerik - Saxophone

Host: Darek Mazzone
Audio Engineers: Julian Martlew & Matt Ogaz
Audio Mix and Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://royalpotatofamily.com/artists/garage-a-trois
http://kexp.org

## Garage A Trois - Etienne (Live on KEXP)
 - [https://www.youtube.com/watch?v=ian2VezUN1g](https://www.youtube.com/watch?v=ian2VezUN1g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-18 00:00:00+00:00

http://KEXP.ORG presents Garage A Trois performing “Etienne” live in the KEXP studio. Recorded December 17, 2021.

Charlie Hunter - Guitar
Stanton Moore - Drums
Skerik - Saxophone

Host: Darek Mazzone
Audio Engineers: Julian Martlew & Matt Ogaz
Audio Mix and Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://royalpotatofamily.com/artists/garage-a-trois
http://kexp.org

## Garage A Trois - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=Sy5-HT_Umng](https://www.youtube.com/watch?v=Sy5-HT_Umng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-18 00:00:00+00:00

http://KEXP.ORG presents Garage A Trois performing live in the KEXP studio. Recorded December 17, 2021.

Songs:
Calm Down Cologne
Improv 666
Etienne
Wizard Sleeve

Charlie Hunter - Guitar
Stanton Moore - Drums
Skerik - Saxophone

Host: Darek Mazzone
Audio Engineers: Julian Martlew & Matt Ogaz
Audio Mix and Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://royalpotatofamily.com/artists/garage-a-trois
http://kexp.org

## Garage A Trois - Improv 666 (Live on KEXP)
 - [https://www.youtube.com/watch?v=ELJsShaZlhE](https://www.youtube.com/watch?v=ELJsShaZlhE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-18 00:00:00+00:00

http://KEXP.ORG presents Garage A Trois performing “Improv 666” live in the KEXP studio. Recorded December 17, 2021.

Charlie Hunter - Guitar
Stanton Moore - Drums
Skerik - Saxophone

Host: Darek Mazzone
Audio Engineers: Julian Martlew & Matt Ogaz
Audio Mix and Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://royalpotatofamily.com/artists/garage-a-trois
http://kexp.org

## Garage A Trois - Wizard Sleeve (Live on KEXP)
 - [https://www.youtube.com/watch?v=wc7NaHq30p8](https://www.youtube.com/watch?v=wc7NaHq30p8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-18 00:00:00+00:00

http://KEXP.ORG presents Garage A Trois performing “Wizard Sleeve” live in the KEXP studio. Recorded December 17, 2021.

Charlie Hunter - Guitar
Stanton Moore - Drums
Skerik - Saxophone

Host: Darek Mazzone
Audio Engineers: Julian Martlew & Matt Ogaz
Audio Mix and Mastering: Julian Martlew
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://royalpotatofamily.com/artists/garage-a-trois
http://kexp.org


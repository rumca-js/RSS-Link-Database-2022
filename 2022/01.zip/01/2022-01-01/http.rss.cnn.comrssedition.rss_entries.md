# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Classic BlackBerry phones will stop working January 4
 - [https://www.cnn.com/2022/01/01/tech/blackberry-end-of-life/index.html](https://www.cnn.com/2022/01/01/tech/blackberry-end-of-life/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 22:00:19+00:00

You soon won't be able to use that old BlackBerry phone sitting at the bottom of your drawer somewhere.

## Miley Cyrus handled a New Year's wardrobe malfunction like a total pro
 - [https://www.cnn.com/2022/01/01/entertainment/miley-cyrus-new-year-show/index.html](https://www.cnn.com/2022/01/01/entertainment/miley-cyrus-new-year-show/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 21:28:49+00:00

Miley Cyrus rang in the New Year with a live performance in Miami and didn't let a small wardrobe malfunction stop the show.

## Watch out for 2022 -- Trump isn't finished just yet
 - [https://www.cnn.com/2022/01/01/opinions/trump-2022-dantonio/index.html](https://www.cnn.com/2022/01/01/opinions/trump-2022-dantonio/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 20:11:51+00:00

Ever devoted to seeking power and attention, former President Donald Trump has announced he'll hold a rally January 15 in Arizona, a key state where his allies used lies about widespread voter fraud to contest the 2020 election results.

## Desmond Tutu's daughter leads tributes at Archbishop's funeral
 - [https://www.cnn.com/2022/01/01/africa/desmond-tutu-funeral-south-africa-intl/index.html](https://www.cnn.com/2022/01/01/africa/desmond-tutu-funeral-south-africa-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 17:33:17+00:00

Archbishop Desmond Tutu's family and friends gathered for his official state funeral on New Year's Day in Cape Town, capping a week of events honoring a man long considered the moral compass of South Africa.

## Mourners pay tribute to Desmond Tutu
 - [https://www.cnn.com/videos/world/2022/01/01/desmond-tutu-funeral-video-mckenzie-pkg-vpx.cnn](https://www.cnn.com/videos/world/2022/01/01/desmond-tutu-funeral-video-mckenzie-pkg-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 17:31:34+00:00

Family, friends and dignitaries gathered for Archbishop Desmond Tutu's official state funeral on New Year's Day in Cape Town, capping a week of events honoring a man long considered to be the moral compass of South Africa.

## 874 cars were torched in France on New Year's Eve -- fewer than in previous years
 - [https://www.cnn.com/2022/01/01/europe/france-car-burning-nye-2021-intl/index.html](https://www.cnn.com/2022/01/01/europe/france-car-burning-nye-2021-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 17:00:15+00:00

A total of 874 vehicles were set ablaze across France on New Year's Eve as part of a decades-old tradition.

## Rodri seals win for Premier League leader in controversial thriller
 - [https://www.cnn.com/2022/01/01/football/arsenal-manchester-city-premier-league-spt-intl/index.html](https://www.cnn.com/2022/01/01/football/arsenal-manchester-city-premier-league-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 16:43:03+00:00

Premier League leader Manchester City moved 11 points clear of Chelsea after a 2-1 win over 10-man Arsenal in a game filled with drama and controversy.

## Dan Reeves, former NFL coach and player, has died
 - [https://www.cnn.com/2022/01/01/sport/dan-reeves-dies/index.html](https://www.cnn.com/2022/01/01/sport/dan-reeves-dies/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 16:31:32+00:00

Dan Reeves, the former National Football League head coach and Dallas Cowboys running back, has died, according to NFL.com. He was 77.

## Bernie Sanders: Pay your workers better. Warren Buffett: That's not my job
 - [https://www.cnn.com/2021/12/31/business/bernie-sanders-warren-buffett-steelworkers-strike/index.html](https://www.cnn.com/2021/12/31/business/bernie-sanders-warren-buffett-steelworkers-strike/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 16:27:29+00:00

Warren Buffett, the ninth-richest person on the planet, says it's not up to him to settle a strike by 450 steelworkers at a company he owns.

## This year, NASA will launch a mission to a valuable, unexplored world
 - [https://www.cnn.com/2022/01/01/world/new-years-wt-science-newsletter-scn/index.html](https://www.cnn.com/2022/01/01/world/new-years-wt-science-newsletter-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 16:17:13+00:00

"Where we're going, we don't need roads."

## This is the ultimate snack food — and it's better for you than you think
 - [https://www.cnn.com/2021/12/31/health/popcorn-homemade-snack-food-wellness/index.html](https://www.cnn.com/2021/12/31/health/popcorn-homemade-snack-food-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 15:50:50+00:00

We all may be full of holiday cheer, but we're also full of holiday meals. When the indulgences of the season start to catch up with us, it's time to ditch the usual dinner for something a little more whimsical: a snack night.

## Virginia Giuffre's lawyers demand proof that Prince Andrew can't sweat
 - [https://www.cnn.com/2021/12/31/us/virginia-giuffre-prince-andrew-court-filing-intl/index.html](https://www.cnn.com/2021/12/31/us/virginia-giuffre-prince-andrew-court-filing-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 14:50:08+00:00

Prince Andrew has been asked to provide documents proving his "alleged medical inability to sweat" in a court filing by attorneys for Virginia Roberts Giuffre, who has accused the royal of sexual assault in a US civil lawsuit.

## 2021: The year of space tourism
 - [https://www.cnn.com/2022/01/01/tech/space-business-year-in-review-scn/index.html](https://www.cnn.com/2022/01/01/tech/space-business-year-in-review-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 14:15:04+00:00

When future generations write about the history of space travel, 2021 may well get its own chapter. "The year of the billionaires," it might be called.

## Africa Cup of Nations: Nigeria preparations hit by Covid-19, injuries and Watford 'baring fangs'
 - [https://www.cnn.com/2022/01/01/football/nigeria-africa-cup-of-nations-emmanuel-dennis-spt-intl/index.html](https://www.cnn.com/2022/01/01/football/nigeria-africa-cup-of-nations-emmanuel-dennis-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 13:45:45+00:00

Nigeria's Africa Cup of Nations (AFCON) preparations have been hit by the loss of four players due to a mixture of Covid-19, injuries and "administrative reasons," with the tournament just over a week away.

## Biden's 2022 challenges revolve around Covid, Russia and dealing with Congress
 - [https://www.cnn.com/2022/01/01/politics/joe-biden-2022-pandemic-russia-ukraine-congress-democrats/index.html](https://www.cnn.com/2022/01/01/politics/joe-biden-2022-pandemic-russia-ukraine-congress-democrats/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 13:01:11+00:00

President Joe Biden will return to the White House from an abbreviated winter break facing a set of hurdles that will test his political, diplomatic and management skills at a trying moment for his presidency.

## Kim Jong Un focuses year-end speech on 'food problem' in North Korea
 - [https://www.cnn.com/2022/01/01/asia/kim-jong-un-year-end-speech-intl/index.html](https://www.cnn.com/2022/01/01/asia/kim-jong-un-year-end-speech-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 12:39:12+00:00

North Korean leader Kim Jong Un has again admitted there is a "food problem" in the country, during a speech which brought an important five-day meeting of his Korean Worker's Party to a close.

## Daniel Craig, Covid-19 experts and a Spice Girl recognized in UK New Year's honors list
 - [https://www.cnn.com/2021/12/31/uk/new-years-honours-list-gbr-uk-intl/index.html](https://www.cnn.com/2021/12/31/uk/new-years-honours-list-gbr-uk-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 12:12:18+00:00

Leading British Covid-19 experts have joined the likes of James Bond, Tony Blair and Emma Raducanu in receiving awards in the Queen's New Year's honors list.

## Eileen Gu makes light of travel woes for halfpipe win
 - [https://www.cnn.com/2022/01/01/sport/eileen-gu-halfpipe-spt-intl/index.html](https://www.cnn.com/2022/01/01/sport/eileen-gu-halfpipe-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 11:53:02+00:00

China's Eileen Gu took a chaotic path to the top of the podium in the halfpipe competition at the FIS Freestyle Ski World Cup in Calgary this week after briefly losing her passport and nearly missing her flight to Canada.

## Pope Francis calls violence against women an 'insult to God' in New Year's Day homily
 - [https://www.cnn.com/2022/01/01/world/pope-francis-new-years-day-intl/index.html](https://www.cnn.com/2022/01/01/world/pope-francis-new-years-day-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 11:41:47+00:00

Pope Francis has condemned violence against women as an "insult to God" in his New Year's Day homily.

## Italy's best-loved gallery tries a new way to attract tourists
 - [https://www.cnn.com/travel/article/florence-museum-russian-icons/index.html](https://www.cnn.com/travel/article/florence-museum-russian-icons/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 10:03:58+00:00

They commissioned and collected some of the most pivotal artworks of the Renaissance, building a collection of art that has now been transformed into one of the best known museums in the world.

## Orient Express returns to Italy after nearly 50 years
 - [https://www.cnn.com/travel/article/pandemic-travel-news-new-year-2022-orient-express/index.html](https://www.cnn.com/travel/article/pandemic-travel-news-new-year-2022-orient-express/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 09:29:38+00:00

Come on, 2022, give us your best shot. We're bruised and we're battered, but we're looking to brighter days ahead.

## 5 science-based strategies for nailing your New Year's resolutions
 - [https://www.cnn.com/2022/01/01/health/how-to-set-new-year-resolutions-wellness/index.html](https://www.cnn.com/2022/01/01/health/how-to-set-new-year-resolutions-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 09:01:13+00:00

It's that time of year again. Champagne bottles have been popped, balls have dropped, and now your friends, family and colleagues are starting to ask, "What's your New Year's resolution?"

## 12 killed in stampede at Indian shrine
 - [https://www.cnn.com/2022/01/01/asia/indian-stampede-intl/index.html](https://www.cnn.com/2022/01/01/asia/indian-stampede-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 08:56:52+00:00

A stampede at one of India's holiest shrines left at least 12 people dead on New Year's Day, a local official said.

## Australia starts 2022 with record Covid cases
 - [https://www.cnn.com/2022/01/01/australia/australia-starts-2022-record-covid-cases-intl-hnk/index.html](https://www.cnn.com/2022/01/01/australia/australia-starts-2022-record-covid-cases-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 06:50:29+00:00

• India's daily Covid-19 cases rise by 22,775

## See Don Lemon pop out of a lemon cake at midnight
 - [https://www.cnn.com/videos/us/2022/01/01/don-lemon-cake-celebration-midnight-nye-special-vpx.cnn](https://www.cnn.com/videos/us/2022/01/01/don-lemon-cake-celebration-midnight-nye-special-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 06:47:12+00:00

CNN's Don Lemon rings in the new year in New Orleans by jumping out of a lemon cake.

## From the Beijing Winter Olympics to Xi's likely third term: 5 things to watch in China in 2022
 - [https://www.cnn.com/2022/01/01/china/five-things-to-watch-2022-mic-intl-hnk/index.html](https://www.cnn.com/2022/01/01/china/five-things-to-watch-2022-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 06:28:49+00:00

2022 is finally here. And for China, there's no shortage of big moments on the horizon -- from the Beijing Winter Olympics to the 20th Communist Party Congress in the fall.

## Where to travel 2022: The best destinations to go
 - [https://www.cnn.com/travel/article/where-to-travel-best-destinations-2022/index.html](https://www.cnn.com/travel/article/where-to-travel-best-destinations-2022/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 03:41:18+00:00

Travel is more challenging now than it has been in a long time. Borders tentatively reopen only to slam shut again. A once-simple visa on entry is replaced with piles of paperwork. And the whole world is brushing up on the Greek alphabet whenever a new variant makes headlines.

## Hong Kong's statues are disappearing, but their symbolism may prove harder to erase
 - [https://www.cnn.com/style/article/hong-kong-statues-symbols/index.html](https://www.cnn.com/style/article/hong-kong-statues-symbols/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 02:48:17+00:00

Depicting a heap of screaming faces and contorted torsos, the "Pillar of Shame" was not just a reminder of the 1989 Tiananmen Square massacre -- it was, for many, an emblem of free speech in Hong Kong.

## Kris Jenner avoids question when Stormi interrupts
 - [https://www.cnn.com/videos/entertainment/2022/01/01/kris-jenner-stormi-pete-davidson-anderson-cooper-andy-cohen-nye-special-vpx.cnn](https://www.cnn.com/videos/entertainment/2022/01/01/kris-jenner-stormi-pete-davidson-anderson-cooper-andy-cohen-nye-special-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 02:14:54+00:00

When Andy Cohen asked Kris Jenner about Kim Kardashian's rumored relationship with comedian Pete Davidson, she had the perfect distraction as her granddaughter Stormi Jenner made a surprise appearance on screen.

## Anderson Cooper and Andy Cohen take shots in honor of Betty White
 - [https://www.cnn.com/videos/entertainment/2022/01/01/betty-white-tequila-shots-anderson-cooper-and-andy-cohen-nye-special-vpx.cnn](https://www.cnn.com/videos/entertainment/2022/01/01/betty-white-tequila-shots-anderson-cooper-and-andy-cohen-nye-special-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 01:38:59+00:00

CNN's New Year's Eve Live co-hosts Anderson Cooper and Andy Cohen take tequila shots in honor of trailblazing actress Betty White, who died at 99.

## With little time to get out, hundreds of Colorado residents lose their homes in a ferocious wildfire
 - [https://www.cnn.com/2021/12/31/us/colorado-wildfires-friday/index.html](https://www.cnn.com/2021/12/31/us/colorado-wildfires-friday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 01:06:58+00:00

A vicious wildfire that began Thursday morning in Boulder County, Colorado, swallowed about 1,600 acres in a matter of hours, burning hundreds of homes and prompting orders for some 30,000 people in two communities to evacuate.

## Watch New Year's Eve celebrations around the world
 - [https://www.cnn.com/videos/world/2021/12/31/new-years-eve-celebrations-around-world-orig-mh-gr.cnn](https://www.cnn.com/videos/world/2021/12/31/new-years-eve-celebrations-around-world-orig-mh-gr.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-01 00:47:12+00:00

Here's how countries around the world are celebrating the start of 2022.


# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Co łączy mnie z Bez Planu, Cashem i Fazą? Własne sakwy, czemu jeżdżę bez kasku i koniec z patronite
 - [https://www.youtube.com/watch?v=1PPQHukKE1I](https://www.youtube.com/watch?v=1PPQHukKE1I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2022-01-01 00:00:00+00:00

Czy książka to dobry pomysł? 📙👉 https://kolemsietoczy.pl/ksiazka/
Kurs filmowania i montażu 🎬 https://www.kursfilmowaniaimontazu.pl/
Dodatek Podróżniczy 🎬 http://filmypodroznicze.pl/

Spis treści:
00:00 - przywitanie
00:28 - Czy to koniec normalnych vlogów?
01:09 - Dlaczego zamknąłem Patronite?
01:58 - Marketing na LITOŚĆ
03:13 - Podróż jak Cash, Faza, Bez planu?
07:12 - Najważniejsze decyzje w historii KST
08:01 - Czy jeszcze mi się chce?
09:28 - Ile zarabiam w miesiącu?
10:00 - Dlaczego jeżdżę bez kasku? O dawaniu przykładu
13:12 - Czy to koniec bloga?
13:39 - Dla kogo będzie książka?
14:27 - GPS z podróży
14:52 - Siłownia
15:20 - Szlak Green Velo
16:02 - Tworzenie filmów w podróży
17:08 - Czy będą tripy z fanami?
18:53 - Kursie filmowo-montażowy - kiedy?
19:32 - Jakie filmy na kanale będą w przyszłości?
19:52 - Jak rozwaliłem drona
20:41 - Polecane drony
21:02 - Latanie dronem w parkach narodowych
22:09 - Własne sakwy i co zabrać na wyjazd 
23:33 - Kiedy ślub i dzieci?
24:26 - Plany na zimę
25:03 - Dlaczego widać mało ludzi na filmach?
25:47 - Atrakcje na Śląsku
26:08 - Plany podróżnicze na 2022
26:28 - Trochę o Maderze
28:14 - O moich filmach i ich odbiorcach
29:36 - Co robiłem po studiach?
30:13 - W tylu krajach byłem
30:18 - W te miejsca chciałbym pojechać
31:02 - Jak uczyłem się montażu?
31:39 - Kolarz górski byłby ze mnie marny
32:11 - Praca na etacie Marty, a nasze podróże
32:49 - Ile znam języków?
33:06  - Podcast Kołem Się Toczy
33:24  - Moje podróżnicze marzenie
34:06  - Najzimniejszy nocleg
34:30  - Kiedy książka?
34:41  - Podróżowanie samotne vs. z kimś
35:19 - Podróżowanie vanem albo camperem
35:42 - Chwile zwątpienia z vlogowaniem


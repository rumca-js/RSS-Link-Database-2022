# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Chory CES - dlaczego jestem w Las Vegas?
 - [https://www.youtube.com/watch?v=bMdQJrGZgUY](https://www.youtube.com/watch?v=bMdQJrGZgUY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-01-02 00:00:00+00:00

Wybrałem się do Vegas relacjonować największe targi technologiczne w tym roku. Czy w obecnej sytuacji to ma sens?
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Spis treści:
00:00 Wstęp
00:47 Życzenia noworoczne i północ w Las Vegas
01:09 Sytuacja noclegowa w Las Vegas
02:25 Konsekwencje pandemii w Las Vegas – tanie hotele
02:40 Zapowiedź rywalizacji Canona R5 z Sony FX3
03:11 Zmiany w Downtown
04:08 Konsekwencje pandemii nr 2 – pustki
04:50 Pandemia jako wytrych w życiu zawodowym i towarzyskim
05:33 Firmy technologiczne na CES a pandemia
06:50 Media technologiczne na CES a pandemia
08:08 Youtuberzy na CES a pandemia
10:07 Podsumowanie
10:29 Pierwszy timelapse
10:37 Podsumowania cd. i pożegnanie
12:16 Drugi timelapse


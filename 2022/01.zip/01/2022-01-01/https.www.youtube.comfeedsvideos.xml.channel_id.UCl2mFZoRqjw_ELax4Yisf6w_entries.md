# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## NYC urban decay followup - 6 months later
 - [https://www.youtube.com/watch?v=Wn9xZxh8Et4](https://www.youtube.com/watch?v=Wn9xZxh8Et4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-01-02 00:00:00+00:00

https://tinyurl.com/rossmatrix
https://youtu.be/OqSUhVjS77o

camera: https://amzn.to/3FP65bk
mic: https://bit.ly/rodetrrsmic

## Right to Repair in the new year, comments on medical misinformation
 - [https://www.youtube.com/watch?v=OEaNE6IzLBs](https://www.youtube.com/watch?v=OEaNE6IzLBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-01-01 00:00:00+00:00

https://tinyurl.com/rossmatrix
🔵 https://www.oklahoman.com/story/opinion/2021/12/17/watts-right-repair-increases-patient-and-cybersecurity-risks/8908073002/
🔵 https://www.fda.gov/media/113431/download
🔵 https://www.youtube.com/watch?v=JV1Z0tMlZMg
🔵 https://youtu.be/PsJG2ODOcXA
 
👉 This video was recorded with the following:
🔵 Chair: https://amzn.to/3D2J2Jb
🔵 Camera: https://amzn.to/3eO58my
🔵 Microphone: https://bit.ly/ae5400
🔵 HDMI capture: https://amzn.to/3cMzhRq
🔵 Audio interface: https://bit.ly/2i2audio


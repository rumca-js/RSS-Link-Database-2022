## How Telegram Messenger circumvents Google Translate's API | DanPetrov
 - [https://danpetrov.xyz/programming/2021/12/30/telegram-google-translate.html](https://danpetrov.xyz/programming/2021/12/30/telegram-google-translate.html)
 - RSS feed: https://danpetrov.xyz
 - date published: 2022-01-01 11:38:22.700894+00:00




# Source:PostmodernJukebox, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg, language:en-US

## Lazy New Year's Weekend Piano Request Stream 2022
 - [https://www.youtube.com/watch?v=GnKYbUPG_LE](https://www.youtube.com/watch?v=GnKYbUPG_LE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCORIeT1hk6tYBuntEXsguLg
 - date published: 2022-01-02 00:00:00+00:00

Scott's piano request channel:  http://www.youtube.com/scottbradlee
Piano Playlist on Spotify: http://smarturl.it/sbpiano
Sign up for Scott's newsletter (coming soon): https://scottbradlee.com/newsletter/


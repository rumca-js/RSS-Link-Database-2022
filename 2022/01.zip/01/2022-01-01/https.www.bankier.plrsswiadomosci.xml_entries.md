# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Rekordowe składki ZUS dla przedsiębiorców
 - [https://www.bankier.pl/wiadomosc/ZUS-wysokosc-skladki-dla-przedsiebiorcow-8385837.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ZUS-wysokosc-skladki-dla-przedsiebiorcow-8385837.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-01-01 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/3/7d6fd98b8f1439-948-568-0-0-2255-1353.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sprawdzamy wysokość składek ZUS dla osób prowadzących działalność w bieżącym roku.</p>

## Dni wolne od pracy w 2023 roku
 - [https://www.bankier.pl/wiadomosc/Dni-wolne-od-pracy-8385847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dni-wolne-od-pracy-8385847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-01-01 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/2/c6ade3e1cc3bff-948-568-0-48-2407-1444.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dni wolne od pracy to nie tylko dodatkowy dzień wolny, ale także możliwość zaplanowania dłuższego urlopu. </p>


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Doomsday Preppers - Do They Know Something We Don’t?!
 - [https://www.youtube.com/watch?v=8RRrOIv2P28](https://www.youtube.com/watch?v=8RRrOIv2P28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-01-02 00:00:00+00:00

Bradley Garrett warns that we are operating under an illusion and they’re trying to distract us from the truth! Do doomsday preppers know something we don’t?! 
#doomsdaypreppers #doomsday #offgridliving #illusion #society 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Happy New Year!! VIRAL Moments & Biggest Stories From 2021
 - [https://www.youtube.com/watch?v=l9uFSiKpOIo](https://www.youtube.com/watch?v=l9uFSiKpOIo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-01-01 00:00:00+00:00

Goodbye 2021! To celebrate the end of 2021, here are some of my favourite moments of the year!
#HappyNewYear #2022

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 8 Epic Faili bezpieczeństwa 2021
 - [https://www.youtube.com/watch?v=BDKTZWbF6Vc](https://www.youtube.com/watch?v=BDKTZWbF6Vc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2022-01-02 00:00:00+00:00

Cześć! 

Przełom roku to czas podsumowań. Dlatego mam dziś dla Was kilka epic faili ze świata bezpieczeństwa, które wydarzyły się ubiegłym roku.
To też dobry moment na osobiste podsumowanie - ilość wyświetleń materiałów na tym kanale przekroczyła już milion, a subskrybentów jest tutaj ponad 40 tysięcy.
Jestem w szoku.
Serdecznie dziękuję i życzę Wam wszystkim Szczęśliwego Nowego Roku!

Rozdziały:
00:00 Intro
00:21 Microsoft Exchange
02:32 Acer REvil
03:26 Kaseya
04:24 FragAttacks
06:39 Facebook
07:45 Twitch
09:13 Log4j i log4shell
09:56 Kryptowaluty i NFT
11:42 Co robić i jak żyć
12:27 Osobiste podsumowanie i podziękowanie

Źródła:
🐼 Microsoft o atakach chińskiej grupy Hafnium
https://bit.ly/3mJKb1Q
📧 Atak na serwery Exchange odkryty został przez Volexity
https://bit.ly/3EHLVif
🏦 Komunikat European Banking Authority o ataku na ich serwery Exchange
https://bit.ly/3Jnq9ng
⏲ Oś czasu ataku na Exchange na stronie Briana Krebsa
https://bit.ly/3Jr6mDw
🌊 Oświadczenie Twitcha dotyczące wycieku danych
https://bit.ly/3qAxVlg
📰 Media o wycieku Twitcha; Slashgear i New York Times
https://bit.ly/3EHWDoT / https://nyti.ms/3Js1VZ7
🏴‍☠️ FragAttacks - Mathy Vanhoef tłumaczy jak zaatakować WiFi
https://www.youtube.com/watch?v=vhwpCgJ9U_U
🌍 Strona Mathy Vanhoefa
https://bit.ly/3eB1HR4
🦝 Kradzieź $120M w kryptowalutach z portfeli połączonych z BadgerDAO
https://bit.ly/3pIlVPv
🕵 Kradzież $150M krypto z Bitmart
https://cnn.it/3qBWGgP
💰 Włamanie na Ascendex, straty oszacowano na $77M
https://bit.ly/3FXabOR
⭕ Scam ze Squidcoinem
https://bit.ly/3qyZImc

Jeżeli nie ufasz skracanym linkom (bardzo dobrze!) to dodaj na ich końcu plusik ‘+’.
W ten sposób podejrzysz na stronie bit.ly dokąd prowadzą.

Relevant xkcd:
https://xkcd.com/2481/

Przestawione w materiale kwestie dotyczące kryptowalut są moimi osobistymi opiniami i w żaden sposób nie próbują nawet udawać porad finansowych. Nie jestem doradcą finansowym.

Dziękuję za gościnę restauracji moodro!
https://www.instagram.com/moodro.bistro/

© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.

Dziękuję za Waszą uwagę. ❤️

Znajdziecie mnie również na;
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/
Podcasty na Anchor https://anchor.fm/mateusz-chrobok
Podcasty na Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR
Podcast na  Apple Podcasts https://podcasts.apple.com/us/podcast/mateusz-chrobok-bezpiecze%C5%84stwo-startupy-i-sztuczna-inteligencja/id1617335932 
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok


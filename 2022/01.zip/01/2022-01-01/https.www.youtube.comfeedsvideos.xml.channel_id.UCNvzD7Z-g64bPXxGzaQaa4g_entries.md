# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 WEIRD Gaming Stories of December 2021
 - [https://www.youtube.com/watch?v=Brew0hBZtR4](https://www.youtube.com/watch?v=Brew0hBZtR4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-02 00:00:00+00:00

December 2021 was a wild time for strange stories in the world of gaming news. Here are some of the weirdest.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 10 Dialogues You Shouldn't Have Skipped In Video Games
 - [https://www.youtube.com/watch?v=lZJtJwjSdlU](https://www.youtube.com/watch?v=lZJtJwjSdlU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-01 00:00:00+00:00

Some video game dialogue moments and options are truly not worth skipping. Here are some that we think were truly worth paying attention to.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


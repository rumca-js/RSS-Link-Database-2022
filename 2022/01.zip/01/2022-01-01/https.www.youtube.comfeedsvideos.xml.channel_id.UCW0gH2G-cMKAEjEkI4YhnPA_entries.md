# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Nine Rings of Power for Men (Ringwraiths) | Tolkien Explained
 - [https://www.youtube.com/watch?v=-JQK9GjcrW4](https://www.youtube.com/watch?v=-JQK9GjcrW4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-01-01 00:00:00+00:00

Continuing our dive into the Rings of Power, we cover the "Nine for Mortal Men Doomed to Die."  A likely plot point of Amazon's Lord of the Rings series, Sauron gives nine rings to men tempted by power.  The rings give them long life and help them become mighty kings, warriors, and sorcerers.  They would gradually be pulled into the Unseen until they exist entirely in the wraith world and are fully enslaved under the power of The One Ring.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html

Sauron and the Nine - Kenneth Sofia
Ringwraiths - ChrisNazgul
The Nine - Unopk
Weathertop - Anato Finnstark
Celebrimbor - Angus McBride
The Three Rings - gonzalez
Sauron and the Ring of Power - o0magnus
Celebrimbor in the Dungeons - AnotherStranger
Sauron - Spartank42
Sauron - Shadow of War
The Keeper of One of the Nine Rings - Steamey
Three Ringwraiths - WETA
Witch King - Meli Hitchcock
Witch King - kimberly80
Nazgul - Ochi Zia
Ringwraiths - fell418
Sauron in Numenor - Efelidi
The Last Alliance - Jenny Dolfen
Sauron, War of the Last Alliance - Matt DeMino
Ringwraith on horseback - Anato Finnstark
The Nine - Anato Finnstark
Nazguls - Inessa Khanenko
Nazgul Rider - William Nunez
Rivendell - Zak Seymour
Nazgul - DreadJim
Ringwraith - noitatstra
Gollum - Inger Edelfeldt
Nazgul - Rui Goncalves
Gollum - Iris Compiet
Nazgul 2 - Rui Goncalves
The Nazgul - Istrandar
Nazgul - Lukasz Jaskolski
A Shortcut to Mushrooms - Vincent Tanguay
The Nazgul - Anato Finnstark
Ringwraith - Yonaz
Black Breath - Maruisz Gandzel
Faramir's Last Charge - Hurcem Kucukdogan
Athelas - Anke Eissmann
Healing Faramir - Anke Eissmann
Healing of Eowyn - Brothers Hildebrandt
Ringwraith Speedpaint - Frerin Hagsolb
Witch King wraith world - WETA
Weathertop - CK Goksoy
Attack on Weathertop - Rafael Diaz Bauduin
Wraith World - Paul Lasaine
Frodo at Mount Doom - Minitry Prosvirnin
Rangers Scout the Ruins of Barad-dur - Ted Nasmith
Isildur and the Ring - Andrea Piparo
The One Ring - Magali Villeneuve
Isildur's Bane - Donato Giancola

#ringsofpower #lotrrop #lordoftherings


# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The BEST LOOKING VR Headset on a BUDGET - Reverb G2 V2 Review
 - [https://www.youtube.com/watch?v=-66YlpcZNpI](https://www.youtube.com/watch?v=-66YlpcZNpI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-01-02 00:00:00+00:00

Here is my official review of the HP Reverb G2 Version 2- HP's newest refresh of their high resolution PCVR headset. This is hands down the best clarity you can achieve for the price in the VR segment right now, with great audio, a good mic, pretty decent tracking- but of course there are still some downsides to this headset that you NEED to know about before you really consider this. In this video I break down the positives, negatives, and situations in which I think the G2 may be your best option for a VR headset in 2022- especially considering the competition; the Valve index and Meta Quest 2. 

My links:
Discord.gg/Thrill
Twitch.tv/Thrilluwu
Twitter.com/Thrilluwu

Actually it's on sale right now too:
https://www.hp.com/us-en/shop/pdp/hp-reverb-g2-virtual-reality-headset

00:00 INTRO
01:22 G2 BACKGROUND
03:10 CLARITY
04:22 COMFORT
05:00 AUDIO
05:45 MIC COMPARISON
06:05 FOV
06:57 TRACKING
08:21 CONTROLLERS
09:26 CONCLUSIONS
12:39 OUTRO


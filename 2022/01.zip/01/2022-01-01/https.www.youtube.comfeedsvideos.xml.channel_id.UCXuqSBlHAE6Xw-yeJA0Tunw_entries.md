# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Inspired This Product! - ASUS Laptop Panel Preview
 - [https://www.youtube.com/watch?v=xVO--p6sMgo](https://www.youtube.com/watch?v=xVO--p6sMgo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-02 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

Use code LINUS and get 25% off GlassWire at https://lmg.gg/glasswire

It's almost CES time and ASUS sent us a couple of new panel tech demos ahead of schedule that we can’t wait to show you!

Buy M1 iPad Pro 2021
On Amazon: https://geni.us/nyy2
On Best Buy: https://geni.us/EBppDa
On Newegg: https://geni.us/SEk10

Buy ASUS Zephyrus S
On Amazon: https://geni.us/NLkUxQ
On Best Buy: https://geni.us/e53K
On Newegg: https://geni.us/kUlLz

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1400682-i-inspired-this-product/

► GET MERCH: lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxm...
iTunes Download Link: https://itunes.apple.com/us/album/sup...
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGB...
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnir...

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE


CHAPTERS
---------------------------------------------------  
0:00 Intro
0:42 What's in the box?
1:40 4K 120
2:45 1080p 240
5:00 Why now?
7:00 MiniLED
9:50 Final Box
12:00 Conclusion
12:44 Outro

## Gaming on Linux is NOT Ready... - Daily Driver Challenge Finale
 - [https://www.youtube.com/watch?v=Rlg4K16ujFw](https://www.youtube.com/watch?v=Rlg4K16ujFw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-01 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Try your first eSIM with Airalo at https://lmg.gg/Airalo

It's been a month of Luke and Linus running Linux at home, and the frustrations are piling up. Just how easy is it to play whatever games you want on a Linux distro? What's the final verdict on daily driving Linux in 2021?

Buy Gigabyte AORUS FO48U Monitor
On Amazon: https://geni.us/PciPiaQ
On Best Buy: https://geni.us/yJyNl
On Newegg: https://geni.us/8ShmgSW

Buy Crucial P5
On Amazon: https://geni.us/7h1R9
On Best Buy: https://geni.us/AoaBCy
On Newegg: https://geni.us/1BbMJ

Buy TC-Helicon Vocal Effects Processor (GOXLR)
On Amazon: https://geni.us/PSOI
On Newegg: https://geni.us/FexoOZ

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1400468-gaming-on-linux-daily-driver-challenge-finale/


►GET MERCH: https://lttstore.com
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Our WAN Show & Podcast Gear: https://lmg.gg/podcastgear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Amazon Prime: https://lmg.gg/8KV1v

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:52 The Premise
2:35 Steam
5:05 Windows Native Games
7:07 Native Linux Support
8:20 Fragmentation
9:58 Troubleshooting
13:00 Proton DB
15:00 Conclusion
17:20 Outro


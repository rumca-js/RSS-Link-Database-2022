# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Firearms Expert’s MOST CURSED Weapons Of 2021
 - [https://www.youtube.com/watch?v=QnbY28EbDCM](https://www.youtube.com/watch?v=QnbY28EbDCM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2022-01-01 00:00:00+00:00

Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down some of the most cursed weapons of 2021, including one of the weakest Desert Eagles in gaming, a golden STG-44, and several of the firearms from Call of Duty: Vanguard.

In the latest video in the Firearm Expert Reacts series, Jonathan Ferguson--a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries--breaks down some of the most cursed weapons he’s seen across the past year.

If you're interested in seeing more of Jonathan's work, you can check out more from the Royal Armouries right here. - https://www.youtube.com/user/RoyalArmouries

If you would like to support the Royal Armouries, you can make a charitable donation to the museum here. - https://royalarmouries.org/support-us/donations/

And if you would like to become a member of the Royal Armouries, you can get a membership here. - https://royalarmouries.org/support-us/membership/

You can either purchase Jonathan's book here. - https://www.headstamppublishing.com/bullpup-rifle-book

Or at the Royal Armouries shop here. - https://shop.royalarmouries.org/collections/thorneycroft-to-sa80-british-bullpup-firearms-1901-2020

You can subscribe to the Armax Journal that Jonathan Associate Edited here: https://www.armaxjournal.org/


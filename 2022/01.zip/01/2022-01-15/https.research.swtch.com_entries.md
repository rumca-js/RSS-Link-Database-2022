## research!rsc: What NPM Should Do Today To Stop A New Colors Attack Tomorrow
 - [https://research.swtch.com/npm-colors](https://research.swtch.com/npm-colors)
 - RSS feed: https://research.swtch.com
 - date published: 2022-01-15 09:26:27.206181+00:00




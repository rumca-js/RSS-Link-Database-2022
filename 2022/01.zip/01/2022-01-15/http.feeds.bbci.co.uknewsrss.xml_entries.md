# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Prince Harry in legal fight to pay for UK police protection
 - [https://www.bbc.co.uk/news/uk-60012238?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60012238?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 23:14:30+00:00

The Duke of Sussex wants to be able to pay for a team of officers when he visits with his family.

## Nino Cerruti: Italian fashion great dies aged 91
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-60011771?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-60011771?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 20:51:34+00:00

The celebrated designer and businessman once said: "I have always dressed the same person, myself."

## Andy Murray loses Sydney final to Aslan Karatsev
 - [https://www.bbc.co.uk/sport/tennis/60007026?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/60007026?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 12:20:45+00:00

Andy Murray's bid for his first ATP Tour title since October 2019 ends with defeat by Russian top seed Aslan Karatsev in the Sydney Classic final.

## Covid in Wales: Rules easing welcomed by sports clubs
 - [https://www.bbc.co.uk/news/uk-wales-60001785?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-60001785?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 12:11:23+00:00

Up to 500 people are allowed to attend outdoor events from Saturday as Wales' Covid rules ease.

## England collapse again as Australia take charge of final Ashes Test
 - [https://www.bbc.co.uk/sport/cricket/60006663?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/60006663?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 11:54:23+00:00

England's batting again crumples before Australia lost late wickets on the second day of the fifth Ashes Test in Hobart.

## Tsunami hits Tonga after giant volcano eruption
 - [https://www.bbc.co.uk/news/world-asia-60007119?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-60007119?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 11:43:02+00:00

Residents report water crashing through homes as ash rained down from the sky.

## Lead or step aside, senior Tory Tobias Ellwood tells Boris Johnson
 - [https://www.bbc.co.uk/news/uk-politics-60005134?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60005134?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 11:25:55+00:00

Tobias Ellwood says "we need leadership" as MPs are inundated with messages about Downing Street parties.

## Covid: Coastguard set for busy staycation summer in 200th year
 - [https://www.bbc.co.uk/news/uk-wales-59952462?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-59952462?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 11:05:08+00:00

Rescue crews had their busiest year in 2021 but expect more emergency shouts in a landmark year.

## The Ashes: Ollie Pope takes 'flying' catch to remove David Warner for a duck
 - [https://www.bbc.co.uk/sport/av/cricket/60007222?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/60007222?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 10:26:03+00:00

Watch as Ollie Pope dives full length to take a stunning "flying" catch to remove Australia's David Warner for a duck on the second day of the final Test of the Ashes in Hobart.

## Ex-supermarket boss Lord Sainsbury of Preston Candover dies at 94
 - [https://www.bbc.co.uk/news/uk-60003334?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60003334?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 10:05:45+00:00

The company's current chief executive described John Sainsbury as a "shopkeeper to his core".

## Team GB curler Hugh Nibloe: From dominoes to the Winter Paralympics
 - [https://www.bbc.co.uk/news/uk-scotland-south-scotland-59980934?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-south-scotland-59980934?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 09:04:47+00:00

Curler Hugh Nibloe recounts his journey from an MS diagnosis to being part of Team GB in Beijing.

## Prince Andrew: Civil case accuser seeks UK witness testimony
 - [https://www.bbc.co.uk/news/uk-60005128?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60005128?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 08:32:26+00:00

Lawyers for Virginia Giuffre seek evidence from two people in the UK in the civil sex assault case.

## 'I'm just happy to have a swing' - Raducanu excited despite Covid disruption
 - [https://www.bbc.co.uk/sport/tennis/60007020?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/60007020?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 07:48:38+00:00

Britain's Emma Raducanu says her limited preparation for the Australian Open after testing positive for coronavirus has been "far from ideal".

## Covid coma pregnancy: Wolverhampton mum 'devastated' to lose son
 - [https://www.bbc.co.uk/news/uk-england-birmingham-59996683?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-59996683?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 07:07:05+00:00

The mum-to-be from Wolverhampton said she was so unwell she did not know her baby was stillborn.

## Los Angeles railway littered with thousands of parcels stolen from trains
 - [https://www.bbc.co.uk/news/world-us-canada-60006306?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60006306?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 06:22:01+00:00

The tracks have been cleared multiple times over the last three months as thieves target trains.

## The Papers: PM in 'last chance saloon' as he 'plots fightback'
 - [https://www.bbc.co.uk/news/blogs-the-papers-60004637?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-60004637?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 05:57:56+00:00

Fallout from the latest allegations of parties at Downing Street during lockdown dominate the front pages.

## Novak Djokovic: Tennis star detained ahead of deportation appeal
 - [https://www.bbc.co.uk/news/world-australia-60004874?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-60004874?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 05:36:10+00:00

The tennis star will hear on Sunday whether he can stay in the country and compete unvaccinated.

## The Ashes: 'Would you believe it!?' - Rory Burns run out for a duck by Marnus Labuschagne
 - [https://www.bbc.co.uk/sport/av/cricket/60006599?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/60006599?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 05:31:08+00:00

Watch as opener Rory Burns is run out by Marnus Labuschagne for a duck in the second over of England's first innings in fifth Ashes Test.

## The Ashes: 'Stop moving the robot!' - Stuart Broad angered by roving camera
 - [https://www.bbc.co.uk/sport/av/cricket/60006592?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/60006592?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 04:10:00+00:00

England's Stuart Broad takes issue with a camera on wheels moving during his attempts to bowl on the second day of the Ashes fifth test.

## Week in pictures: 8 - 14 January 2022
 - [https://www.bbc.co.uk/news/in-pictures-59995396?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-59995396?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 02:09:11+00:00

A selection of powerful images from all over the globe, taken this week.

## How a colossal block of ice became an obsession
 - [https://www.bbc.co.uk/news/science-environment-59998703?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-59998703?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 02:03:48+00:00

Artist Kevin Eason won't ever see his favourite iceberg up close, but he's come to know it so well.

## MH17: Families' quest for hope years after Ukraine air disaster
 - [https://www.bbc.co.uk/news/world-europe-59979885?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59979885?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 02:02:58+00:00

Since flight MH17 was shot down over Ukraine, victims' families have been on a difficult journey.

## Remi Wolf is casually rewriting the rules of pop music
 - [https://www.bbc.co.uk/news/entertainment-arts-59966722?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59966722?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 02:02:43+00:00

The former downhill skier and American Idol contestant is making some of pop's most exuberant songs.

## Omega Mart: Where art meets escape room
 - [https://www.bbc.co.uk/news/technology-59998929?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-59998929?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 02:01:42+00:00

BBC Click's Chris Fox visits a hi-tech art experience in Las Vegas.

## Prince Andrew: Ruthless royals move to limit the damage
 - [https://www.bbc.co.uk/news/uk-59916864?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59916864?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 00:33:24+00:00

The Royal Family has tried to distance itself from the allegations facing Prince Andrew.

## The woman who rowed solo across the Atlantic
 - [https://www.bbc.co.uk/news/stories-59997286?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-59997286?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 00:03:50+00:00

Tori Murden McClure almost died when she tried to row the Atlantic solo, but she went back to sea.

## Covid: 'We're so proud of how Bertie bounced back'
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-59952726?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-59952726?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 00:03:15+00:00

A five-year-old boy with autism is now thriving at school, despite the impact of lockdown.

## Kazakhstan: Who sparked deadly violence?
 - [https://www.bbc.co.uk/news/world-asia-59999612?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-59999612?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-15 00:01:48+00:00

Authorities are blaming "armed extremists" for the clashes, in which dozens are thought to have been killed.


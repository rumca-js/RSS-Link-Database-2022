# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Why is EVERYONE Buying This Gaming Mouse? - Logitech G502 HERO
 - [https://www.youtube.com/watch?v=Iek-UH9ZWUw](https://www.youtube.com/watch?v=Iek-UH9ZWUw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-16 00:00:00+00:00

Get 50% off your Zoho CRM annual subscription with code ZCRM50 at: https://lmg.gg/ZohoCRM

Use code LINUS at https://pebblehost.com/dedicated for 30% off your first month, available for the first 100 people who sign up for dedicated server hosting.

What's so good about the G502 Hero that it has almost thirty thousand ratings on Amazon with a 4.7 star rating? Let's take a look in the latest edition of Why Is Everyone Buying THIS?!

Buy Logitech G502 HERO
On Best Buy: https://geni.us/GtfZnXf
On Amazon: https://geni.us/MZQUL
On Newegg: https://geni.us/kwerrsP

Buy Logitech MX Master 3
On Best Buy: https://geni.us/fsBBNq3
On Amazon: https://geni.us/ZNS0tcU
On Newegg: https://geni.us/Pquil

Buy Razer Basilisk X Hyperspeed WIRELESS 
On Best Buy: https://geni.us/k7fn
On Amazon: https://geni.us/ANqdA

Buy Corsair Nightsword RGB
On Best Buy: https://geni.us/ZrmgKYg
On Amazon: https://geni.us/BjMj
On Newegg: https://geni.us/BjMj

Buy Razer DeathAdder Essential
On Amazon: https://geni.us/cALQ
On Best Buy: https://geni.us/7BJsI
On Newegg: https://geni.us/azJDJpU

Buy Razer Viper Mini Ultralight
On Amazon: https://geni.us/Twg6R
On Best Buy: https://geni.us/gXItCLX
On Newegg: https://geni.us/mmv0S

Buy Redragon M801
On Amazon: https://geni.us/aDvi
On Newegg: https://geni.us/3RHFc

Buy EVGA X15 MMO
On Amazon: https://geni.us/ZPSrDN1
On Newegg: https://geni.us/619VQC

Buy SteelSeries Rival 3
On Amazon: https://geni.us/DOwAbc
On Best Buy: https://geni.us/B6C51Y
On Newegg: https://geni.us/f2XhOu

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1404362-why-is-everyone-buying-this-gaming-mouse/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:13 The Beginning
3:10 A Hero Is Born
5:13 Complaints
6:40 The Double Click
7:41 The Price
9:15 Alternatives
10:23 Conclusion
11:59 Outro

## The Fatal Flaw in HP's Omen 45L broke me
 - [https://www.youtube.com/watch?v=eSqrq8v-QLs](https://www.youtube.com/watch?v=eSqrq8v-QLs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-15 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

SmartDeploy: Claim your FREE IT software (worth $696!) at https://lmg.gg/OTTP7

HP promised to shake up the PC industry with an innovative new CPU cooler design, and I was this close to declaring it the new gaming performance king of prebuilts...

Buy OMEN 45L Gaming Desktop
HP: https://geni.us/SCBswH
Best Buy: https://geni.us/OUPWnSk

Buy Intel Core i9-12900K Desktop Processor
Amazon: https://geni.us/hrzU
Best Buy: https://geni.us/1niRuZp
Newegg: https://geni.us/SLwDuCA

Buy NVIDIA RTX 3090
Amazon: https://geni.us/rMWpj
Best Buy: https://geni.us/24AQV5
Newegg: https://geni.us/4aL0

Buy Cooler Master MasterLiquid ML240L RGB V2
Amazon: https://geni.us/Pk1el
Newegg: https://geni.us/3VIFJj
B&H: https://geni.us/0OhoroT

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1404110-i-was-ready-to-give-hp-the-crown%E2%80%A6/

►GET MERCH: https://lttstore.com
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Our WAN Show & Podcast Gear: https://lmg.gg/podcastgear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Amazon Prime: https://lmg.gg/8KV1v

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:18 Specs and design theory
2:27 A quick physical tour
4:02 HP's hardware claims and some history
4:43 Testing the Cryo Chamber
6:48 Gaming and workstation performance
8:18 Predictably, HP does what HP does
9:25 Comparing against XMP
10:17 Conclusion


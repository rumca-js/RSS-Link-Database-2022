# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## 'Once in a lifetime' rare blanket octopus spotted in Australia
 - [https://www.cnn.com/videos/travel/2022/01/15/rare-octopus-blanket-great-barrier-reef-elliot-island-orig-mg-kj.cnn](https://www.cnn.com/videos/travel/2022/01/15/rare-octopus-blanket-great-barrier-reef-elliot-island-orig-mg-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-15 19:19:38+00:00

The rainbow-hued octopus, seen swimming on the Great Barrier Reef, was caught on video by marine biologist Jacinta Shackleton.

## Official who argued against vaccines dies from Covid-19, sparking big reaction online
 - [https://www.cnn.com/videos/media/2022/01/15/covid-19-anti-vaccine-deaths-mockery-smerconish-vpx.cnn](https://www.cnn.com/videos/media/2022/01/15/covid-19-anti-vaccine-deaths-mockery-smerconish-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-15 16:08:07+00:00

CNN's Michael Smerconish speaks with Los Angeles Times columnist Michael Hiltzik about his article on reacting to the Covid-19 deaths of people who spoke out against getting the vaccine.

## The ruling against Prince Andrew is another win for the Child Victims Act's lookback window
 - [https://www.cnn.com/2022/01/15/us/prince-andrew-child-victims-act/index.html](https://www.cnn.com/2022/01/15/us/prince-andrew-child-victims-act/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-15 07:00:37+00:00

In his ruling that a child sexual abuse lawsuit against Prince Andrew can move ahead, Judge Lewis Kaplan took several pages to flatly reject the royal's argument that the law undergirding the entire case is unconstitutional.

## Dave Chappelle didn't text Bob Saget back and regrets it
 - [https://www.cnn.com/2022/01/14/entertainment/dave-chappelle-bob-saget/index.html](https://www.cnn.com/2022/01/14/entertainment/dave-chappelle-bob-saget/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-15 01:44:25+00:00

Life is short and Dave Chappelle has been reminded of that with the death of his friend and fellow comedian, Bob Saget.

## Judge sets tentative sentencing date for Maxwell
 - [https://www.cnn.com/2022/01/14/us/ghislaine-maxwell-sentencing/index.html](https://www.cnn.com/2022/01/14/us/ghislaine-maxwell-sentencing/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-15 01:15:18+00:00

Convicted sex trafficker Ghislaine Maxwell will be sentenced in June after being found guilty last month on five federal charges. Judge Alison Nathan set a tentative date of June 28.

## Ranking Boris Johnson's scandals while Prime Minister
 - [https://www.cnn.com/videos/world/2022/01/14/boris-johnson-scandal-ranking-nobilo-sot-vpx.cnn](https://www.cnn.com/videos/world/2022/01/14/boris-johnson-scandal-ranking-nobilo-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-15 00:28:22+00:00

As pressure mounts on British Prime Minister Boris Johnson, CNN's Bianca Nobilo ranks scandals he has previously faced as Prime Minister.

## India's Hindu extremists are calling for genocide against Muslims. Why is little being done to stop them?
 - [https://www.cnn.com/2022/01/14/asia/india-hindu-extremist-groups-intl-hnk-dst/index.html](https://www.cnn.com/2022/01/14/asia/india-hindu-extremist-groups-intl-hnk-dst/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-15 00:22:46+00:00

At a conference in India last month, a Hindu extremist dressed head-to-toe in the religion's holy color, saffron, called on her supporters to kill Muslims and "protect" the country.

## Hopes of competing in Australian Open hanging by a thread
 - [https://www.cnn.com/2022/01/14/tennis/novak-djokovic-detention-intl/index.html](https://www.cnn.com/2022/01/14/tennis/novak-djokovic-detention-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-15 00:20:49+00:00




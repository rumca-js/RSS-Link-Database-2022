## Don't Make My Mistakes: Common Infrastructure Errors I've Made
 - [https://matduggan.com/mistakes/](https://matduggan.com/mistakes/)
 - RSS feed: https://matduggan.com
 - date published: 2022-01-15 13:42:15.302006+00:00

One surreal experience as my career has progressed is the intense feeling of deja vu you get hit with during meetings. From time to time, someone will mention something and you'll flash back to the same meeting you had about this a few jobs ago. A decision was made then,


## PayPal faces lawsuit for freezing customer accounts and funds | Engadget
 - [https://www.engadget.com/paypal-lawsuit-freezing-customer-accounts-funds-073128563.html?guccounter=1&guce_referrer=aHR0cHM6Ly9tYWlsLmdvb2dsZS5jb20v&guce_referrer_sig=AQAAADi9X5LjatxPRv7Ol5vk9NZjJCrSPrUSyNUNoOU2LUYThUEiH3rNhZg2sRJGVqNelOyLesiUFtuAT8Bj_lrbaH_DNLDy6JKT5DUveUI2rm60r-m6C_bhs2OA2X0W4YQtLBM_PYasawXSxOzjrmtV7Zob1ZMSXSOEa63kcdFiiOUY](https://www.engadget.com/paypal-lawsuit-freezing-customer-accounts-funds-073128563.html?guccounter=1&guce_referrer=aHR0cHM6Ly9tYWlsLmdvb2dsZS5jb20v&guce_referrer_sig=AQAAADi9X5LjatxPRv7Ol5vk9NZjJCrSPrUSyNUNoOU2LUYThUEiH3rNhZg2sRJGVqNelOyLesiUFtuAT8Bj_lrbaH_DNLDy6JKT5DUveUI2rm60r-m6C_bhs2OA2X0W4YQtLBM_PYasawXSxOzjrmtV7Zob1ZMSXSOEa63kcdFiiOUY)
 - RSS feed: https://www.engadget.com
 - date published: 2022-01-15 14:32:40.502256+00:00

Three PayPal users who've allegedly had their accounts frozen and funds taken by the company without explanation are proposing a class-action lawsuit..


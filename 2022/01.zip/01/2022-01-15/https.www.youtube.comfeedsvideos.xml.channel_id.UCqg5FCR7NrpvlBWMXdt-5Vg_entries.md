# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Does Resurrections Bring the Matrix Back to Life? | Your Feature Presentation
 - [https://www.youtube.com/watch?v=E_qh74ielFg](https://www.youtube.com/watch?v=E_qh74ielFg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-01-16 00:00:00+00:00

This week on Your Feature Presentation, Jack and Darren do a deep dive on their thoughts on Matrix Resurrections, Jack won't watch Boba Fett and Marty joins Darren for a surprise episode of Escape the Galaxy to discuss their in-depth thoughts on the Book of Boba Fett so far.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---
Timestamps
0:00 - Intro
1:37 - The Matrix Resurrections
17:18 - Jack won't watch Boba Fett
24:00 - The Book of Boba Fett Episodes 1 & 2


---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Cons, Combat and Common Names | Adventure is Nigh - The Jade Homunculus | EP 9
 - [https://www.youtube.com/watch?v=r3Fe88R0lKI](https://www.youtube.com/watch?v=r3Fe88R0lKI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-01-15 00:00:00+00:00

It's the season finale of Adventure is Nigh! Watch part 1 of 2 here: https://youtu.be/m4EwWdBY-aI

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Split the Party....Three-Ways | Adventure is Nigh - The Jade Homunculus | EP 8
 - [https://www.youtube.com/watch?v=m4EwWdBY-aI](https://www.youtube.com/watch?v=m4EwWdBY-aI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-01-15 00:00:00+00:00

Part 1 of the two-part Adventure is Nigh season finale! Watch part 2 here: https://youtu.be/r3Fe88R0lKI

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 6 Video Games Series That Went DOWNHILL
 - [https://www.youtube.com/watch?v=BP8i8J7dtmk](https://www.youtube.com/watch?v=BP8i8J7dtmk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-16 00:00:00+00:00

We love video games, but some games series and franchises have disappointed us lately or fell out of public favor. Let's discuss a few of them.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

## 6 HARDEST Easter Eggs In Recent Games
 - [https://www.youtube.com/watch?v=crMuaOQDGJM](https://www.youtube.com/watch?v=crMuaOQDGJM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-15 00:00:00+00:00

Some games have wildly difficult or obscure Easter Eggs. Here are some secrets from recent games that we loved.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:17 Halo Infinite
1:35 FNaF: Security Breach 
4:00 Metroid Dread
5:41 Deltarune Chapter 2 
7:36 Psychonauts 2
9:05 Inscryption

## God of War PC - Before You Buy
 - [https://www.youtube.com/watch?v=z9MQGmUFF3w](https://www.youtube.com/watch?v=z9MQGmUFF3w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-15 00:00:00+00:00

God of War (PC, PS4, PS5) finally arrives on the PC platform. How is it? Let's revisit this classic.
Subscribe for more: http://youtube.com/gameranxtv ▼▼


Watch more 'Before You Buy': https://bit.ly/2kfdxI6


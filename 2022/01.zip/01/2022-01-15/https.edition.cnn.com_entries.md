## FedEx asks FAA permission to add anti-missile system to some cargo planes - CNN
 - [https://edition.cnn.com/2022/01/14/business/fedex-anti-missile-cargo-planes/index.html](https://edition.cnn.com/2022/01/14/business/fedex-anti-missile-cargo-planes/index.html)
 - RSS feed: https://edition.cnn.com
 - date published: 2022-01-15 18:15:20.344329+00:00

FedEx wants to operate cargo planes outfitted with lasers that throw off incoming heat-seeking missiles, according to a newly published federal documents.  


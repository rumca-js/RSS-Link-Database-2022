# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Specialists now agree on endemic ending
 - [https://www.youtube.com/watch?v=U3W84wb5jKo](https://www.youtube.com/watch?v=U3W84wb5jKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-01-16 00:00:00+00:00

If you would like John’s text books, (it is free to download the PDFs)

Link to free download of my 2 textbooks (worldwide)
http://159.69.48.3/

Physiology book in hard copy (UK only)
https://www.ebay.co.uk/itm/154770452796?mkevt=1&mkcid=16&mkrid=710-127635-2958-0

Pathophysiology book in hard copy (UK only)
https://www.ebay.co.uk/itm/154770451780?mkevt=1&mkcid=16&mkrid=710-127635-2958-0

Many waited until the evidence was self evident before stating a position, better late than never.

https://ourworldindata.org/covid-metrics-previous-waves?utm_source=OWID+Newsletter&utm_campaign=57cd25901b-biweekly-digest-2022-01-14&utm_medium=email&utm_term=0_2e166c1fc1-57cd25901b-536960754

Marco Cavaleri, EMA head of biological health threats and vaccines strategy

https://www.ema.europa.eu/en/events/ema-regular-press-briefing-covid-19-11

https://www.ema.europa.eu/en/events/ema-regular-press-briefing-covid-19-11

Boosters, can be done once, or maybe twice, but it’s not something that we can think should be repeated constantly
We need to think about how we can transition from the current pandemic setting to a more endemic setting
With omicron there will be a lot of natural immunity taking place on top of vaccination,

We will be fastly moving to a scenario which is close to endemicity

Fourth dose for all

Data has not yet been generated to support this approach

Repeated vaccinations in a short time frame will not represent a sustainable long term strategy

Endemic Covid, very soon

https://www.bbc.co.uk/news/health-59970281

Omicron, endemic

Consistent and predictable, not boom and bust

Common colds, influenza, HIV, measles, malaria, tuberculosis

A new Covid-era

Prof Julian Hiscox, Chair in Infection and Global Health, University of Liverpool

UK, New and Emerging Respiratory Virus Threats Advisory Group

We're almost there, it is now the beginning of the end, at least in the UK

I think life in 2022 will be almost back to before the pandemic

Should a new variant or old variant come along, for most of us, like any other common cold coronavirus, we'll get the sniffles and a bit of a headache and then we're OK

If you're willing to tolerate zero deaths from Covid, then we're facing a whole raft of restrictions and it's not game over

in a bad flu season, 200-300 die a day over winter and nobody wears a mask or socially distances,

that's perhaps a right line to draw in the sand

Dr Elisabetta Groppelli, virologist, St George's, University of London

I am very optimistic

We'll soon be in a situation where the virus is circulating, we will take care of people at risk, but for anybody else we accept they will catch it – 

and your average person will be fine

We need to accept the fact that our flu season is also going to be a coronavirus season, and that is going to be a challenge for us

However, it is still uncertain how bad winters will be as the people who die from flu and Covid tend to be the same

(You can't die twice)

Prof Azra Ghani, epidemiologist, Imperial College London

Covid will still be around, but that we no longer need to restrict our lives

It seems like it's taken a long time, but only a year ago we started vaccinating and we're already an awful lot freer because of that

A new variant that can outcompete Omicron and be more pathogenic

Prof Eleanor Riley, immunologist, University of Edinburgh

When Omicron has finished and moved through, immunity in the UK will be high, at least for a while

70 year old overweight male who used to smoke for a lot of years

Hi John, I’m going through a period of suffering. Got the infection last Tuesday. 

Tested on Wednesday and was positive. It is what you described but the sore throat is terrible, you don’t realise how often you swallow until it’s torture to do so, 

been taking my D3 and zinc

and if nothing else my new Granddaughter will get to know her Granddad 

Mis en place 
When I woke up & feeling like I had a hangover, I immediately took my temperature, sure enough 38.7°c. 

Knew I had it, just needed confirmation. Performed a lateral flow test & bang! had a positive result in under 5 minutes. 

No really outstanding symptoms. No sore throat, no real headache (just the tightness of the head - hangover), temperature fluctuated hour to hour, 

taste bud's altered - no loss, just altered. Basically a general feeling of being unwell. 

This lasted about 30 hrs & has improved greatly over a relatively short period. 

It's now day 4 & feeling pretty good. Taste is still altered & a little phlegm but otherwise doing well & just waiting out the isolation protocol.

## Pre-infection advice
 - [https://www.youtube.com/watch?v=mZAa1BsB2ZI](https://www.youtube.com/watch?v=mZAa1BsB2ZI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2022-01-15 00:00:00+00:00

If you would like John’s text books, (it is free to download the full PDFs)

Physiology book in hard copy
https://www.ebay.co.uk/itm/154770452796?mkevt=1&mkcid=16&mkrid=710-127635-2958-0

Pathophysiology book in hard copy
https://www.ebay.co.uk/itm/154770451780?mkevt=1&mkcid=16&mkrid=710-127635-2958-0

Link to free download of my 2 textbooks

http://159.69.48.3/


Omicron exposure is inevitable, an optimised immune system is not

Omicron Symptoms

Omicron incubation 2 days

Symptomatic disease with omicron is shorter

Most people could leave isolation at 5 days

Long covid, probably less than with delta

Current symptoms

Runny nose, 73%

Headache, 68%

Fatigue, 64%

Sneezing, 60%

Sore throat, 60%

Persistent cough, 44%

Hoarse voice, 36%

Chills or shivers, 30%

Fever, 29%

Dizzy, 28%

Brain fog, 24%

Altered smell, 23%

Sore eyes, 23%

Unusual muscle pains, 23%

Skipped meals, 21%

Loss of smell, 19%

Chest pain, 19%

Swollen glands, 19%

Feeling down, 16%

Remember, the 6 Ps. Poor preparation promotes probable poor performance


# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## A very fast French song // Jacques Brel // POMPLAMOOSE
 - [https://www.youtube.com/watch?v=hvrBWn0KxEc](https://www.youtube.com/watch?v=hvrBWn0KxEc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2022-01-20 00:00:00+00:00

Vesoul. C’est très vite. This is where you get to see just how 🔥 these musicians are.
Get "Impossible à prononcer" on vinyl! http://pomplamoose.com

Save this song on Spotify: https://spoti.fi/2r3Yqkh
Follow us on instagram: https://instagram.com/pomplamoosemusic
Become a patron of our music (to vote on the songs we cover and get merch and stuff like that): http://www.patreon.com/pomplamoose

A cover of Jacques Brel's "Vesoul" by Pomplamoose.

MUSICIAN CREDITS
Lead Vocals: Nataly Dawn
Accordion: Jack Conte
Clarinet: John Tegmeyer
Piano: Ross Garren
Drums: Ben Rose
Mandolin: John Schroeder
Upright Bass: Eliana Athayde
Acoustic Guitar: Erik Miron
Background Vocals: Sarah Dugas

AUDIO CREDITS
Engineer: Tim Sonnefeld
Assistant Engineer: Branko Presley
Mixing/Mastering: Caleb Parker
Producer: John Schroeder

VIDEO CREDITS
Video Production/Direction: Ricky Chavez, George Sloan
Camera Operators: Merlin Showalter, Sammy Rothman, Dijon Herron, Charlene Gibbs
Video Editor: Dominic Mercurio
Colorist: Athena Wheaton

Recorded at The Village in Los Angeles.

LYRICS (French / English)
T'as voulu voir Vierzon / You wanted to see Vierzon 
Et on a vu Vierzon / And we saw Vierzon
T'as voulu voir Vesoul / You wanted to see Vesoul
Et on a vu Vesoul / And we saw Vesoul
T'as voulu voir Honfleur / You wanted to see Honfleur
Et on a vu Honfleur / And we saw Honfleur
T'as voulu voir Hambourg / You wanted to see Hamburg
Et on a vu Hambourg / And we saw Hamburg
J'ai voulu voir Anvers / I wanted to see Antwerp
On a revu Hambourg / We went to see Hamburg again
J'ai voulu voir ta sœur / I wanted to see your sister
Et on a vu ta mère / And we saw your mother
Comme toujours / As always

T'as plus aimé Vierzon / You no longer liked Vierzon
On a quitté Vierzon / So we left Vierzon
T'as plus aimé Vesoul / You no longer liked Vesoul
On a quitté Vesoul / So we left Vesoul
T'as plus aimé Honfleur / You no longer liked Honfleur
On a quitté Honfleur / So we left Honfleur
T'as plus aimé Hambourg / You no longer liked Hamburg
On a quitté Hambourg / So we left Hamburg
T'as voulu voir Anvers / You wanted to see Antwerp
On n'a vu qu'ses faubourgs / We only saw its suburbs
T'as plus aimé ta mère / You no longer loved your mother
On a quitté ta sœur / So we left your sister
Comme toujours / As always

Mais je te le dis / Well I’m telling you
Je n'irai pas plus loin / I will go no further
Mais je te préviens / And I warn you
J'irai pas à Paris / I won’t go to Paris
D'ailleurs j'ai horreur / Besides I can’t stand
De tous les flonflons / All the fanfare
De la valse musette / Of the Musette Waltz
Et de l’accordéon / And of the accordion

T'as voulu voir Paris / You wanted to see Paris
On a vu Paris / So we saw Paris
T'as voulu voir Dutronc / You wanted to go see Dutronc
Et on a vu Dutronc / And we saw Dutronc
J'ai voulu voir ta sœur / I wanted to see your sister
J'ai vu le mont Valérien / I saw Mont-Valérien
T'as voulu voir Hortense / You wanted to see Hortense
Elle était dans l'Cantal / She was in the Cantal region

 
J'ai voulu voir Byzance / I wanted to see Byzantium
Et on a vu Pigalle / And we ended up seeing Pigalle
À la gare Saint-Lazare / At Saint-Lazare train station
J'ai vu Les fleurs du mal / I saw Les fleurs du ma
Par hasard / By Chance

T'as plus aimé Paris / You no longer liked Paris
Et on a quitté Paris / And we left Paris
T'as plus aimé Dutronc / You didn’t like Dutronc anymore
On a quitté Dutronc / So we left Dutronc
Maintenant je confonds ta sœur / Now I confuse your sister
Et le mont Valérien / With Mont-Valérien
De ce que je sais d'Hortense, / And from what I know of Hortense,
J'irai plus dans l'Cantal / I won’t go back to the Cantal region
Et tant pis pour Byzance / And too bad for Byzantium
Puisque j'ai vu Pigalle / Since I got to see Pigalle
Et la gare Saint-Lazare / And Saint-Lazare station
C'est cher et ça fait mal / Is expensive and it hurts
Au hasard / Randomly

Mais je te le redis / Well I’ll tell you again
Je n'irai pas plus loin / I will go no further
Mais je te préviens / And I warn you
Le voyage est fini / This trip is over
D'ailleurs j'ai horreur / Besides I can’t stand
De tous les flonflons / All the fanfare
De la valse musette / Of the Musette Waltz
Et de l'accordéon / And of the accordion

Chauffe Jean, chauffe! / Faster Jean, faster!

Mais je te le re-redis / Well I’ll tell you again and again
Je n'irai pas plus loin / I will go no further
Mais je te préviens / And I warn you
Le voyage est fini / This trip is over
D'ailleurs j'ai horreur / Besides I can’t stand
De tous les flonflons / All the fanfare
De la valse musette / Of the Musette Waltz
Et de l'accordéon / And of the accordion


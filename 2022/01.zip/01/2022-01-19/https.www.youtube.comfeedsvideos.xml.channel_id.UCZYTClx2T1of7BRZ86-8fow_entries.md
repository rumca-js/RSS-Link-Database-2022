# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Mr. Frosty, the Cancer-fighting Gecko
 - [https://www.youtube.com/watch?v=ZQaYy2WH1-I](https://www.youtube.com/watch?v=ZQaYy2WH1-I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-01-20 00:00:00+00:00

Not only is this gecko adorned with beautiful coloration, but the same thing that makes it look so pretty could help us understand where some our cancers come from and how to stop them from progressing! 

Hosted by: Michael Aranda

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Dr. Melvin Sanicas, Sam Lutfi, Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Nazara, Ash, Jason A Saslow, Matt Curls, Eric Jensen, GrowingViolet, Jeffrey Mckishen, Christopher R Boucher, Alex Hackman, Piya Shedden, charles george, Tom Mosner, Jeremy Mysliwiec, Adam Brainard, Chris Peters, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:
https://journals.plos.org/plosgenetics/article?id=10.1371/journal.pgen.1009580 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6444329/ 
https://www.nature.com/articles/nrg3483 
https://www.ncbi.nlm.nih.gov/books/NBK442024/ 


Image Sources: 
https://www.istockphoto.com/photo/mango-yogurt-ice-cream-in-hand-gm1318427112-405559749
https://journals.plos.org/plosgenetics/article?id=10.1371/journal.pgen.1009580
https://commons.wikimedia.org/wiki/File:DuckyLeopardGecko.jpg
https://www.istockphoto.com/photo/leopard-gecko-sitting-on-piece-of-wood-with-black-background-gm1331089810-414325569
https://www.istockphoto.com/photo/cancer-outbreak-gm1277148522-376442007
https://www.istockphoto.com/photo/dolphin-peeking-out-of-blue-water-gm157507845-10977196
https://www.istockphoto.com/photo/close-up-of-a-female-indian-flying-fox-with-pup-gm1314795268-402934814
https://commons.wikimedia.org/wiki/File:Evolutionary_trends.svg
https://commons.wikimedia.org/wiki/File:Protein_SPINT1_PDB_1yc0.png
https://www.storyblocks.com/video/stock/embryonic-stem-cells-colony-under-a-microscope-cellular-therapy-and-research-of-regeneration-and-disease-treatment-in-seamless-3d-animation-biology-and-medicine-of-human-body-concept-loop-4k-rwapjsg-ik5ljgl56
https://www.storyblocks.com/video/stock/concept-of-cancer-cell-in-human-body-shape-animation-rosq9rg5_kpazc9ti
https://www.istockphoto.com/photo/human-cancer-cell-gm1317832692-405153101
https://www.istockphoto.com/photo/abstract-genetics-disease-gm1284442152-381578199
https://www.istockphoto.com/photo/cancer-cells-on-dna-stand-background-3d-illustration-gm1325872227-410751584
https://www.eurekalert.org/multimedia/685445

## The Bees That Eat Corpses
 - [https://www.youtube.com/watch?v=9AOxUS8kjko](https://www.youtube.com/watch?v=9AOxUS8kjko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-01-19 00:00:00+00:00

Start speaking a new language in 3 weeks with Babbel. Get up to 65% off in your subscription here: https://go.babbel.com/12m65-youtube-scishow-jan-2022/default

Bees are quite beneficial little critters: pollinating flowers, making honey, and also...helping corpses decompose.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Dr. Melvin Sanicas, Sam Lutfi, Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Nazara, Ash, Jason A Saslow, Matt Curls, Eric Jensen, GrowingViolet, Jeffrey Mckishen, Christopher R Boucher, Alex Hackman, Piya Shedden, charles george, Tom Mosner, Jeremy Mysliwiec, Adam Brainard, Chris Peters, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:
https://doi.org/10.1128/mBio.02317-21
https://arstechnica.com/science/2021/11/carnivorous-vulture-bees-have-acidic-microbiomes-to-better-digest-their-carrion/
https://doi.org/10.1038/s41598-017-15581-5 

Images:
https://www.istockphoto.com/photo/super-cute-honey-bee-sitting-on-a-leaf-gm1218469781-356053219
https://www.storyblocks.com/video/stock/swarm-of-bees-near-a-beehive-4ofmzajtgijutj8eo
https://www.istockphoto.com/photo/black-stingless-bee-gm1311170789-400352960
https://www.flickr.com/photos/52450054@N04/48698571573/in/photolist-2hcjUGn-ekhd7j-2hwA3Kr-BQUoW-BQUK9-BQUzd-xxXqY-xxWR6-dRA3wX-6sMgDz-dyaHRT-FDYW6X-28uDGTd-BQUTv-2dLUbMD-25P5c7y-25P5ehL-8C8NXV-JV8FXz-2itSndT-nLXCmL-2hRzbPR-o2pP1w-r7JBrG-boMMuF-boMMtz-boMMs6-boMMqz-6t3q3q-bfUXzX-cSWxgQ-G5KBU3-7Xf4M5-a9PZ48-7WV3ab-jGmvEk-Eytyu6-2iC5cwq-6k2hf2-dUiVAn-dUt3dj-7Xf5Nb-w49Ms-Ecm6kk-xxVQ3-zuf2rg-a9SLwb-a9SK2y-a9SKG3-a9SJHy
https://commons.wikimedia.org/wiki/File:Weiselzellen_68a.jpg
https://www.nature.com/articles/s41598-017-15581-5
https://www.istockphoto.com/photo/adult-stingless-bee-gm1348172090-425457789
https://www.istockphoto.com/photo/eastern-yellowjacket-with-food-gm637084120-113431469
https://commons.wikimedia.org/wiki/File:Waggle_Dance.webm
https://www.istockphoto.com/photo/bees-gm91076298-2920909
https://www.istockphoto.com/photo/stingless-bee-gm1092376262-293091390


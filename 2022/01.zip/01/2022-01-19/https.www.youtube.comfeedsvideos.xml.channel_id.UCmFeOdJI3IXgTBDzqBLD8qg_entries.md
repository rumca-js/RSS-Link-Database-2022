# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## You Will Never Do Anything Remarkable
 - [https://www.youtube.com/watch?v=ww7Ga6CUVVw](https://www.youtube.com/watch?v=ww7Ga6CUVVw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2022-01-19 00:00:00+00:00

You were never supposed to be make money or be happy....

Support the channel here (all funds go back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT

00:00 - 'You're meant to be poor'
01:56 - 'Childhood'
05:22 - 'Adulthood'
07:49- 'Reckless Actions'
11:07 - 'The Consequences'
14:03 - 'Escape'


This video discusses how education and reckless political leaders have hampered you're ability to make money and wealth. You were meant to be poor. Through bad education, bad business mindsets, inflation, and money printing, the majority of people don't make the money, wealth and  happiness they deserve. Instead our estates and property are no owned. We flock to bitcoins, Ethereum and cryptocurrencies and NFT's to escape inflation for a reason. The doomer meme is popular for a reason. You're investments will be ruined by inflation and keep you poor and unhappy. We are just in a rat race. So here's how you become rich and make money in 2022...


# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Listen to Looch: What I took away on a second viewing of the Beatles "Get Back"
 - [https://www.youtube.com/watch?v=lUsYUBL0tos](https://www.youtube.com/watch?v=lUsYUBL0tos)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-01-19 00:00:00+00:00

This week, Mary Lucia revisits the Beatles' "Get Back" documentary. 

"This might seem a little nutty," Mary says, "but I rewatched Get Back, the Peter Jackson, Beatles documentary in one sitting. If you've watched it more than once, there's so much to unpack. And I did get different things out of this one. And I feel like I can watch this for the rest of my life.

"My second viewing of Get Back was as fulfilling as the first," Mary continues, "and if you've watched it more than once, I'd love to know what you think too."

Mary Lucia talks about "Get Back" after the first viewing: https://youtu.be/QCOfYpPirsU 

More Listen to Looch:
https://youtube.com/playlist?list=PLYClJc3TpV5J_sXyCfes-p6vCgOpCmleh

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#TheBeatlesGetBack #PeterJackson #RingoStarr

## Songhoy Blues - three songs for The Current (2020)
 - [https://www.youtube.com/watch?v=UzXQYfD4TtI](https://www.youtube.com/watch?v=UzXQYfD4TtI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-01-19 00:00:00+00:00

In October 2020, the four members of Malian band Songhoy Blues connected with The Current to perform songs from "Optimisme," their album from that year, as well as one track from their 2017 release, "Résistance." Watch the three performances in the video above.

SONGS PERFORMED
0:00 "Worry"
3:19 "Bamako"
7:13 "Dournia"

PERSONNEL
Garba Touré – lead guitar
Aliou Touré – vocals, guitar
Oumar Touré – drums
Nathanael Dembélé – bass

CREDITS
Mali Production: Millennium Communication
Editor: Mali Davido
Cameras: Cheick Sy Kiss, Xavier Davido, Alison Mojo
MPR Production: Eric Romani; Jesse Wiza

FIND MORE:
2020 virtual session:
https://www.thecurrent.org/feature/2020/09/30/virtual-session-songhoy-blues

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#songhoyblues


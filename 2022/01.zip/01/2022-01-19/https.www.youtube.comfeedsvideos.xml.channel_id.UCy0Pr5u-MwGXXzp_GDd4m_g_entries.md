# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## What's an NFT?
 - [https://www.youtube.com/watch?v=cJzNiFLyw8k](https://www.youtube.com/watch?v=cJzNiFLyw8k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2022-01-20 00:00:00+00:00

I'm just asking for a friend... Thank you to BetterHelp for sponsoring today's video. Get 10% off your first month here: https://BetterHelp.com/nolke

Actor: Julie Nolke
Written and Shot by: Sam Larson
Editor: Alec Mckay
Production Assistant: Jill Agopsowicz

Support the channel by liking and subscribing! 
Join my Patreon for behind the scenes videos and early access to videos here: https://www.patreon.com/julienolke


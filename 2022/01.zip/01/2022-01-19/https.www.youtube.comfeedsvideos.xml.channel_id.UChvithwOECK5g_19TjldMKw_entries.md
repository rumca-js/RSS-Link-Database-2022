# Source:Laowhy86, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, language:en-US

## China Absolutely Hates Canada
 - [https://www.youtube.com/watch?v=h6sCA6gEyuE](https://www.youtube.com/watch?v=h6sCA6gEyuE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2022-01-19 00:00:00+00:00

Chinese state media, the Global Times, conducted a poll across 16 cities in China to ask Chinese people what their favorite country was. Canada was the worst. I also discuss where other countries fell on the poll, as well as whether or not China faked the entire thing. 

◘ Support me on Patreon to talk to me directly and support my work - http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C
◘ Odysee - http://odysee.com/@laowhy86

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
ADVPodcasts - https://www.youtube.com/advpodcasts

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Music -
Big Bad Beats
https://www.youtube.com/c/bigbadbeats

Sources - 
https://www.globaltimes.cn/page/202112/1243607.shtml
https://rsf.org/en/ranking
https://freedomhouse.org/country/china/freedom-world/2021
https://www.pewresearch.org/global/2021/06/30/large-majorities-say-china-does-not-respect-the-personal-freedoms-of-its-people/
https://www.pewresearch.org/fact-tank/2021/06/30/chinas-international-image-remains-broadly-negative-as-views-of-the-u-s-rebound/
https://www.pewresearch.org/global/database/indicator/24/
https://www.theguardian.com/world/2022/jan/17/dont-buy-from-abroad-chinese-told-as-covid-threatens-olympics-and-holidays


## Scientists Who Were Instrumental to COVID-19 ‘Natural Origin’ Narrative Received Over $50 Million in NIAID Funding in 2020–21
 - [https://www.theepochtimes.com/scientists-who-were-instrumental-to-covid-19-natural-origins-narrative-received-over-50-million-in-niaid-funding-in-2020-2021_4220769.html](https://www.theepochtimes.com/scientists-who-were-instrumental-to-covid-19-natural-origins-narrative-received-over-50-million-in-niaid-funding-in-2020-2021_4220769.html)
 - RSS feed: https://www.theepochtimes.com
 - date published: 2022-01-19 14:23:35+00:00

Scientists Who Were Instrumental to COVID-19 ‘Natural Origin’ Narrative Received Over $50 Million in NIAID Funding in 2020–21


# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Our First Budget Gaming Build in Over a Year!
 - [https://www.youtube.com/watch?v=lOBaA9zg3XM](https://www.youtube.com/watch?v=lOBaA9zg3XM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-20 00:00:00+00:00

New Customers Exclusive – Get a Free 240gb SSD at Micro Center: https://micro.center/889eba

Check out the Micro Center Community: https://micro.center/ae1c8d
Micro Center Community Build of the Year – 2021: https://micro.center/39f336
Submit a Build. Get $25. Learn more Here: https://micro.center/cf8640
Micro Center Custom PC Builder: https://micro.center/f1e339

AMD Ryzen 5 5600G: https://micro.center/672eaa
AMD Radeon RX 6500 XT: https://micro.center/51c9f3
ASUS B550-PLUS TUF Gaming Motherboard: https://micro.center/9db77b
G.Skill Ripjaws V 32GB (2 x 16GB) DDR4-3600 PC4-28800 CL18: https://micro.center/009ad6
Intel 660p 1TB SSD: https://micro.center/6e2935
G.Skill 650 Watt 80 Plus Bronze ATX Semi-Modular Power Supply: https://micro.center/98d2ea
Fractal Design Meshify C Tempered Glass ATX Mid-Tower Computer Case – White: https://micro.center/df4f02
Aukey KMG12 Mechanical Wired Gaming Keyboard – Black: https://micro.center/48f2f3
Logitech G G502 HERO Gaming Mouse: https://micro.center/4cdb8b
MSI Optix G241 23.8" Full HD (1920 x 1080) 144Hz Gaming Monitor: https://micro.center/ec4ad6

With the launch of AMD's $200 6500XT and Intel's entry level Alder Lake CPUs (like the 12100 and 12400), we're finally getting to a place where budget gaming rigs are...maybe...a possibility. Let's see what's sold out and what we can actually buy (for a reasonable price).

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/


FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

## A GPU you might be able to buy… But shouldn’t. - AMD Radeon RX 6500 XT
 - [https://www.youtube.com/watch?v=KYp6pEDm4E8](https://www.youtube.com/watch?v=KYp6pEDm4E8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-19 00:00:00+00:00

Use code LINUSTECHTIPS16 for up to 16 FREE MEALS + 3 Surprise Gifts across 6 HelloFresh boxes plus free shipping at https://bit.ly/3ei8GhO!

Thanks to HelloFresh for sponsoring this video!

Go to https://privacy.com/linus ​to get $5 off your first purchase!

GPUs are impossible to buy, but AMD, Nvidia, and soon Intel are all releasing new cards. The Radeon RX 6500 XT is the first new card of 2022, on TSMC’s 6nm process. But is it TOO affordable?

Discuss on the forum: https://linustechtips.com/topic/1405067-a-gpu-you-might-be-able-to-buy%E2%80%A6-but-shouldn%E2%80%99t/

Buy an AMD Radeon GPU
Amazon: https://geni.us/BYWFs
Best Buy: https://geni.us/pBUxo
Newegg: https://geni.us/h7ewftY

Buy Radeon RX 6600
Amazon: https://geni.us/KFHcodo
Best Buy: https://geni.us/cIJSA
Newegg: https://geni.us/zuQeT

Buy GTX 1660
Amazon: https://geni.us/Dwqofbv
Newegg: https://geni.us/gkGjC
B&H: https://geni.us/QFBA

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:04 Cut all the specs!
2:05 So what is this thing?
2:45 Gaming performance
4:22 A problem appears: Bandwidth
5:39 Productivity
6:38 This is supposed to be an upgrade card
7:27 Thermals & Power
8:35 Conclusion


# Source:Paul Joseph Watson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCittVh8imKanO_5KohzDbpg, language:en-US

## It's over.
 - [https://www.youtube.com/watch?v=RAUOM5V2IYE](https://www.youtube.com/watch?v=RAUOM5V2IYE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCittVh8imKanO_5KohzDbpg
 - date published: 2022-01-20 00:00:00+00:00

The end is nigh.

INTRO MUSIC: Sagittarius V - Lucidator: http://sagittariusvmusic.bandcamp.com

LOCALS (Exclusive content!): https://pauljosephwatson.locals.com/
NEW MERCH: https://www.pjwshop.com/
DONATE: https://www.subscribestar.com/paul-joseph-watson
CASH APP: https://cash.app/£PaulJosephWatson
SUMMIT NEWS: http://summit.news/newsletter

BITCOIN WALLET: 3EMQG9EhPkoFbX5F19RTGZs8rPqGYm2mp9
BITCOIN CASH WALLET: qrxhqz9ka423v68qwc7nyqc88q3mx9ea5gcpz88a0l
LITECOIN WALLET: MSs2rWgM571WM3zUnL255gccoQAdz9L6CG
ETHEREUM WALLET: 0x21221F5da5e70F46Bbfa755f89e312daDa51f115 

Odysee: https://odysee.com/@PaulJosephWatson:5
Anything Goes: https://www.youtube.com/AnythingGoesChannel
Parler: https://parler.com/profile/PJW/posts
Bitchute: https://www.bitchute.com/pauljosephwatson
Telegram: https://t.me/pjwnews
Twitter: https://twitter.com/PrisonPlanet
Minds: https://www.minds.com/PaulJosephWatson
Gab: https://gab.com/PrisonPlanet


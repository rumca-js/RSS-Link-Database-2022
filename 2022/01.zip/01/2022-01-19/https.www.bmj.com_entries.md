## Facebook versus the BMJ: when fact checking goes wrong
 - [https://www.bmj.com/content/376/bmj.o95](https://www.bmj.com/content/376/bmj.o95)
 - RSS feed: https://www.bmj.com
 - date published: 2022-01-19 12:53:33+00:00

Facebook versus the BMJ: when fact checking goes wrong


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Rings of Power Teaser BREAKDOWN - Galadriel, Howard Shore Confirmed, TV-14 Rating and MORE!
 - [https://www.youtube.com/watch?v=F4jKpV4Kyic](https://www.youtube.com/watch?v=F4jKpV4Kyic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-01-20 00:00:00+00:00

My 6 takeaways from the reveal of The Lord of the Rings: The Rings of Power! We found out the Narrator, the Rating, got a Numenor easter-egg, and of course, the title!  ALSO - we got confirmation from Amazon that HOWARD SHORE is returning to Middle-earth, and it is his music we hear in this teaser!

Watch the teaser here: https://youtu.be/QhqGCPMfkNM

Did this pump you up for the adventures of Galadriel, Elrond, Numenor, Sauron, and the Second Age?  Let me know in the comments!

Prepare for the new series with my playlist on The Second Age: https://youtube.com/playlist?list=PLLyHBx6FRJC0Z4e1o_Fv0F_lXzDBw2eqQ

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

Artwork :
The Ships of the Faithful - Ted Nasmith
Celebrimbor and Annatar - Paul Tobin, WETA
Morfyyd Clark as Galadriel - u/ChillingGarden (Reddit)
The Fall of Numenor - Darrell Sweet
Celebrimbor - Angus McBride
Sauron - Johnny Slowhand

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

#lotronprime #lotrrop #ringsofpower

## The Lord of the Rings: The Rings of Power! Amazon Title Announcement Teaser Reaction
 - [https://www.youtube.com/watch?v=58Wuq9XkSNk](https://www.youtube.com/watch?v=58Wuq9XkSNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-01-19 00:00:00+00:00

We have a title and a teaser!! The Lord of the Rings: The Rings of Power premieres on September 2, 2022 on Amazon Prime Video!  Let's chat about what we think about this new title, what it means for the show, and when we may get the first trailer!

My History of Tolkien's Rings of Power Playlist: https://youtu.be/CH_hwIqeVJ0

Hit subscribe - and the bell so you don't miss future updates on THE RINGS OF POWER!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

#lordoftherings #ringsofpower #lotrrop


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Realistic Survival Games That TRULY Test Your MIGHT
 - [https://www.youtube.com/watch?v=I5DDyTT0qMI](https://www.youtube.com/watch?v=I5DDyTT0qMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-20 00:00:00+00:00

Looking for a challenging survival game on PC, PS5, PS4, Xbox Series X/S/One, or Switch? We've got you covered with these great games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

10. Green Hell 

Platform : PC Switch PS4 Xbox One 

Release Date : September 5, 2019 



09. Medieval Dynasty 

Platform : PC 

Release Date : September 23, 2021 



08. Ancestors: The Humankind Odyssey 

Platform : PC PS4 Xbox One 

Release Date : August 27, 2019 



07. Project Zomboid 

Platform : PC Linux OS X

Release Date : 8 November 2013



06. UnReal World

Platform : PC Linux OS X 

Release Date : 1992



05. The Forest 

Platform : PC PS4

Release Date : 30 April 2018



04. RimWorld

Platform : PC Linux

Release Date : October 17, 2018 



03. Neo Scavenger

Platform : PC OS X LINUX

Release Date : 15 December 2014 



02. This war of mine

Platform : PC PS4 Xbox One Switch OS X 

Release Date : 14 November 2014 



01. The Long Dark

Platform : PC PS4 Xbox One Switch OS X LINUX 

Release Date : August 1, 2017 



Bonus: 



The Flame in the Flood 

Platform : PC PS4 Xbox One Switch 

Release Date : February 24, 2016 



Don't Starve 

Platform : PC PS3 PS4 PS Vita Xbox One Switch Wii U OS X Linux 

Release Date : April 23, 2013 



Frostpunk 

Platform : PC PS4 Xbox One 

Release Date : April 24, 2018 



0:00 Intro
0:21 Green Hell
1:39 Medieval Dynasty
2:47 Ancestors: The Humankind Odyssey
4:09 Project Zomboid
5:31 UnReal World
6:56 The Forest
8:15 RimWorld
9:38 Neo Scavenger
10:57 This war of mine
12:25  The Long Dark
14:02 Bonus:
The Flame in the Flood
Don't Starve
Frostpunk

## Top 20 NEW Open World Games of 2022
 - [https://www.youtube.com/watch?v=eVUVTV-ez74](https://www.youtube.com/watch?v=eVUVTV-ez74)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-19 00:00:00+00:00

Open world gaming isn't slowing down on PC, PS5, PS4, Xbox Series X/S/One, and Nintendo Switch. Here's everything to look forward to in 2022.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

20. Sonic Frontiers 

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : Q4 2022 



19. Atomic Heart 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : 2022 



18. Avatar: Frontiers of Pandora 

Platform : PC PS5 XSX|S LUNA STADIA 

Release Date : 2022  



17. DokeV 

Platform : PC PS5 XSX|S 

Release Date : TBA 



16. Crimson Desert 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : TBA 



15 Ark II 

Platform : PC XSX|S 

Release Date : TBA 2022 



14. The Day Before 

Platform : PC PS5 XSX|S 

Release Date : June 21, 2022  



13. State of Decay 3 

Platform : PC XSX|S 

Release Date : TBA 



12. Saints Row 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : August 23, 2022 



11. Forspoken

Platform : PC PS5 

Release Date : May 24, 2022        



10. Avowed 

Platform : PC XSX|S 

Release Date : TBA 



9. LEGO Star Wars: The Skywalker Saga 

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : Early 2022 



8. Gotham Knights 

Platform : PC PS4 PS5 Xbox One XSX|S  

Release Date : 2022 



7. Suicide Squad: Kill the Justice League 

Platform : PC PS5 XSX|S 

Release Date : 2022 



6. S.T.A.L.K.E.R. 2: Heart of Chernobyl 

Platform : PC XSX|S 

Release Date : December 8, 2022 



5. Dying Light 2: Stay Human 

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : February 4, 2022 



4. Starfield 

Platform : PC XSX|S 

Release Date : November 11, 2022 



3. Horizon Forbidden West 

Platform : PS4 PS5 

Release Date : February 18, 2022 



2. Elden Ring 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : February 25, 2022 



1. The Legend of Zelda: Breath of the Wild 2 

Platform : Switch 

Release Date : TBA 2022 



BONUS

Harry Potter: Hogwarts Legacy 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : Might be 2023 



GhostWire Tokyo

Platform : PC PS5 

Release Date : 2022  



Test Drive Unlimited Solar Crown 

Platform : PC PS4 PS5 Xbox One XSX|S Switch 

Release Date : September 22, 2022 



Fable 

Platform : PC XSX|S 

Release Date : TBA  


Sons of the Forest

Platform : PC

Release Date : 20 May 2022

0:00 Intro
0:14 - Sonic Frontiers
0:57 - Atomic Heart
1:49 - Avatar: Frontiers of Pandora
2:27 - Dokev
3:14 - Crimson Desert
3:48 - Ark 2
4:23 - The Day Before
5:08 - State of Decay 3
5:57 - Saints Row (2022)
6:58 - Forspoken
7:39 - Avowed
8:14 - LEGO Star Wars: The Skywalker Saga
9:05 - Gotham Knights
9:51 - Suicide Squad: Kill the Justice League
10:42 - S.T.A.L.K.E.R. 2: Heart of Chernobyl
11:19 - Dying Light 2: Stay Human
12:06 - Starfield
12:51 - Horizon Forbidden West
13:24 - Elden Ring
14:08 - The Legend of Zelda: Breath of the Wild 2
14:45 - Hogwarts Legacy
14:54 - Ghostwire: Tokyo
15:01 - Test Drive Unlimited Solar Crown
15:06 - Fable 4
15:12 - Sons of the Forest


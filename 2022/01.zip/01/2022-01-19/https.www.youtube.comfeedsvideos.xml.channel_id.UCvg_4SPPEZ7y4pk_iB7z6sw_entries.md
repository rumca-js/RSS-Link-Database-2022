# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## The Wacky World of Rare Xboxes
 - [https://www.youtube.com/watch?v=LFVvpFSeq4A](https://www.youtube.com/watch?v=LFVvpFSeq4A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2022-01-19 00:00:00+00:00

Well, it’s another console variations list. This time for the OG Xbox. Yeah. That’s, what the video’s about.


Twitter: https://twitter.com/WhimsuTy
Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub

Footage Credits:
Adam Koralik
NeoGamer - The Video Game Archive
LGR
rodsormen1
Gamester81
MetalJesusRocks
IGN
GoTeamScotch
SPECTRE AIR
Panzer Dragoon Legacy
IndianVideoGameCollector
OGXbox dotCOM
Xbox On
Pshyched Plays PS2
CGR Publishing


# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The US Government is going after Meta and Oculus
 - [https://www.youtube.com/watch?v=rSI3MH7hNn0](https://www.youtube.com/watch?v=rSI3MH7hNn0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-01-19 00:00:00+00:00

Thank you to MicroCenter for sponsoring this video! 
Here the link to a free 240gb SSD:

https://micro.center/8841f1

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire weeks worth of VR news! Today we will be covering the FTC lawsuit against Meta for anticompetitive practices in the VR industry, The Simula One VR headset, Apple's newest VR ventures and views on the metaverse and so much more! Hopefully you enjoy this week of VR news!

My links:
Twitch.tv/Thrilluwu
Discord.gg/Thrill
Twitter.com/Thrilluwu

TIMESTAMPS:
00:00 INTRO
00:38 AD
02:01 APPLE
03:53 SIMULA
06:57 MEME BREAK
07:16 META’S XROS
08:13 META FTC
09:23 ZENITH
10:01 SECOND LIFE 
10:53 WAL-MART
11:37 QOTW
12:15 OUTRO



SOURCES:
https://simulavr.com/
https://www.roadtovr.com/simula-one-vr-linux-standalone-kickstarter/
https://www.businessinsider.com/meta-oculus-vr-division-antitrust-investigation-ftc-report-says-2022-1#:~:text=Meta%27s%20VR%20division%20is%20under%20investigation%20by%20the,sources%20with%20knowledge%20of%20the%20matter%20told%20Bloomberg.
https://nypost.com/2022/01/18/ftc-investigates-metas-oculus-vr-business-over-market-dominance/


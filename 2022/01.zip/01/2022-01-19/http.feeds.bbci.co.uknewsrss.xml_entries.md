# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## 'An important player with special characteristics' - could Bergwijn's match-winning cameo resurrect Spurs career?
 - [https://www.bbc.co.uk/sport/football/60063315?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/60063315?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 23:48:55+00:00

Dutch striker's match-winning late cameo gives Spurs food for thought on a forward who appeared to be heading for the exit.

## Jozef Puska, 31, charged with murder of Ashling Murphy
 - [https://www.bbc.co.uk/news/world-europe-60052695?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60052695?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 21:27:05+00:00

A man appears at a special court in the Republic of Ireland charged with the murder of Ashling Murphy.

## Netball Quad Series: England lose 58-46 to Australia in final
 - [https://www.bbc.co.uk/sport/netball/60057164?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/netball/60057164?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 21:17:09+00:00

England suffer a 58-46 loss to Australia and miss out on their first ever Quad Series trophy at London's Copper Box.

## Egypt reach Afcon last 16 with win over Sudan
 - [https://www.bbc.co.uk/sport/football/59961568?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59961568?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 21:04:57+00:00

Egypt edge past Sudan to finish second in Group D and qualify for the last 16 of the Africa Cup of Nations.

## Nigeria top group after cruising to win over Guinea-Bissau
 - [https://www.bbc.co.uk/sport/football/59961567?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59961567?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 21:01:13+00:00

Nigeria beat Guinea-Bissau to become the only side at the Africa Cup of Nations to win all three group games.

## Ukraine tension: Blinken says Russia could attack at short notice
 - [https://www.bbc.co.uk/news/world-europe-60048395?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-60048395?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 20:36:26+00:00

Moscow denies any plan to attack Ukraine and says US support for the country is a threat to Russia.

## Defecting was most difficult decision - Wakeford
 - [https://www.bbc.co.uk/news/uk-politics-60060369?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60060369?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 20:07:41+00:00

The ex-Tory MP says he had "many sleepless nights" over moving to Labour, but it was the "right decision".

## Christian Wakeford's long walk to defection
 - [https://www.bbc.co.uk/news/uk-politics-60062632?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60062632?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 20:01:27+00:00

The MP's journey from the Tories to Labour follows ideological doubts and a lengthy wooing process.

## In the name of God go, David Davis tells UK PM
 - [https://www.bbc.co.uk/news/uk-politics-60056482?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60056482?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 19:48:47+00:00

The former cabinet minister joins calls for Boris Johnson to stand down, as a Tory MP defects to Labour.

## Covid: Face mask rules and Covid passes to end in England
 - [https://www.bbc.co.uk/news/uk-60047438?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60047438?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 19:26:51+00:00

Working from home guidance is also ending as England reverts to "Plan A", Boris Johnson says.

## Shrewsbury MP Daniel Kawczynski suspended for one day over bullying
 - [https://www.bbc.co.uk/news/uk-england-shropshire-60057326?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-shropshire-60057326?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 19:18:20+00:00

Daniel Kawczynski, Shrewsbury's Conservative MP, is sanctioned for undermining his own apology.

## 'We hope that she's doing OK' - leading players call for information on Peng's wellbeing
 - [https://www.bbc.co.uk/sport/tennis/60061128?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/60061128?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 19:06:32+00:00

Victoria Azarenka, Naomi Osaka and Ashleigh Barty call for more information on Chinese player Peng Shuai's wellbeing.

## Ben John: Extremist ordered to read books is jailed
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-60051861?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-60051861?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 18:42:09+00:00

Ben John, who was told to read Austen and Shakespeare, has his original suspended sentence quashed.

## Brewdog flouted US laws over beer imports
 - [https://www.bbc.co.uk/news/uk-scotland-60054053?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-60054053?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 17:56:32+00:00

Scottish beer giant shipped hundreds of kegs of beer to America which had not been legally approved.

## Working-from-home guidance shift 'may not save my shop'
 - [https://www.bbc.co.uk/news/business-60057276?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60057276?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 17:35:47+00:00

End of work-from-home guidance a boost for hospitality, while nightclubs welcome scrapping of Covid passes.

## Surging food prices push inflation to 30-year high
 - [https://www.bbc.co.uk/news/business-60050699?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60050699?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 17:33:15+00:00

The UK's cost of living surged by 5.4% in the 12 months to December, hitting its highest level since 1992.

## Unilever says it will not increase £50bn bid for rival
 - [https://www.bbc.co.uk/news/business-60053927?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60053927?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 17:29:30+00:00

Consumer goods giant Unilever says it will not sweeten its bid for the healthcare arm of GlaxoSmithKline.

## In pictures: Snow falls in Algeria's Sahara Desert
 - [https://www.bbc.co.uk/news/world-africa-60045153?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-60045153?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 17:13:54+00:00

The ice crystals leave stunning patterns in the sands of the Sahara, the world's largest hot desert.

## What high inflation means - in 90 seconds
 - [https://www.bbc.co.uk/news/business-60058675?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60058675?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 17:08:28+00:00

The BBC's consumer affairs correspondent, Colletta Smith, breaks it down.

## Inflation: Peterborough community cafe customers feel the pinch
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-60043213?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-60043213?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 17:02:13+00:00

What does the latest rise in the cost of living mean for those already struggling to make ends meet?

## Gaspard Ulliel: Moon Knight actor dies aged 37 after ski accident
 - [https://www.bbc.co.uk/news/entertainment-arts-60054237?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60054237?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 16:14:54+00:00

Gaspard Ulliel, who features in the upcoming Marvel TV series, died after an accident on the Alps.

## Tonga volcano: New images reveal scale of damage after tsunami
 - [https://www.bbc.co.uk/news/world-asia-60034179?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-60034179?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 15:57:30+00:00

Trees are torn down and buildings ripped apart following Saturday's tsunami triggered by a volcano.

## LGBT military ban: 'I was marched off RAF base for being gay'
 - [https://www.bbc.co.uk/news/uk-england-manchester-60052536?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-60052536?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 15:56:08+00:00

A man who was discharged from the military for being gay tells how it inspired his fight for change.

## Children's show Fraggle Rock returns after 33 years
 - [https://www.bbc.co.uk/news/entertainment-arts-60058997?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60058997?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 15:31:01+00:00

Classic children's show Fraggle Rock has been revived for Apple TV+, 33 years after the last series was made.

## Covid in schools: Inquiry launched to find 100,000 pupils absent in England
 - [https://www.bbc.co.uk/news/education-60054253?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-60054253?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 15:14:53+00:00

England's children's commissioner says she will "go out and find" those not on school rolls.

## Facebook Messenger: The battle over end-to-end encryption
 - [https://www.bbc.co.uk/news/technology-60055270?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60055270?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 14:43:53+00:00

The battle-lines have been drawn - but what is end-to-end encryption and why is it controversial?

## Joe Biden one year on: Has the United States become ungovernable?
 - [https://www.bbc.co.uk/news/world-us-canada-60036911?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60036911?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 13:51:50+00:00

A president who promised to unite the country is unable to bring his own party together.

## Bono: U2's name and songs make me cringe
 - [https://www.bbc.co.uk/news/entertainment-arts-60051813?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-60051813?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 11:58:31+00:00

The band's frontman says he gets "embarrassed" by his voice, and also isn't fond of their name.

## Gen Z on battling soaring inflation for the first time
 - [https://www.bbc.co.uk/news/business-60024716?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60024716?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 11:27:17+00:00

Those aged 18 to 25 have never experienced inflation before in their lives - how are they coping?

## Conservative MPs moving against Boris Johnson are 'like a jilted lover', says MP
 - [https://www.bbc.co.uk/news/uk-politics-60054353?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-60054353?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 11:26:50+00:00

Boris Johnson faces a loss of faith among newer MPs - but the PM's supporters insist he can survive.

## Wordle: 'It's just so simple,' says Countdown's Susie Dent, on the daily word game
 - [https://www.bbc.co.uk/news/uk-60054293?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-60054293?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 10:57:10+00:00

The online word game Wordle has attracted millions of daily users - including Countdown's Susie Dent.

## Joe Biden one year: How is he doing so far?
 - [https://www.bbc.co.uk/news/world-us-canada-60044270?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60044270?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 08:31:40+00:00

Twelve months in, how is he doing? Here's a visual guide to the ups and downs of the Biden presidency.

## Radar satellite's stunning map of UK and Ireland
 - [https://www.bbc.co.uk/news/science-environment-60044065?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-60044065?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 08:28:59+00:00

For some technologies there are never any clouds to spoil the view.

## CEO Secrets: 'The traditional job interview is dead'
 - [https://www.bbc.co.uk/news/business-60043376?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-60043376?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 01:11:45+00:00

Rachael Flanagan, founder and CEO of cleaning company Mrs Buckét, shares her business advice.

## The women facing rape threats and abuses on Clubhouse
 - [https://www.bbc.co.uk/news/world-asia-india-60020888?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-60020888?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 00:11:16+00:00

The women say right-wing trolls in India targeted them for criticising Narendra Modi and his government.

## Should bad science be censored on social media?
 - [https://www.bbc.co.uk/news/technology-60036861?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-60036861?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 00:08:42+00:00

A Royal Society report recommends against censoring scientific misinformation online.

## Somali survivor: The resilience of living through serial suicide attacks
 - [https://www.bbc.co.uk/news/world-africa-60039136?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-60039136?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 00:07:24+00:00

Former BBC reporter Mohamed Moalimu is recovering after being targeted on Sunday in Somalia.

## Winter Olympics 2022: China sells Xinjiang as a winter sports hub
 - [https://www.bbc.co.uk/news/world-asia-china-59991321?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-59991321?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-19 00:05:46+00:00

Many foreign firms hoping to ride the Olympics boom are investing heavily in the troubled region.


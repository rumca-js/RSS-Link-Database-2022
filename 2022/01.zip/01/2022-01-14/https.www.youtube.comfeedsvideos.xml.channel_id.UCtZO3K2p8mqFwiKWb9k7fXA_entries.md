# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## Samsung failed in China. How did Apple succeed?
 - [https://www.youtube.com/watch?v=E5aqnNEnSBA](https://www.youtube.com/watch?v=E5aqnNEnSBA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2022-01-14 00:00:00+00:00

The Bonus video: https://nebula.app/videos/techaltar-bonus-apples-first-china-victory

The Nebula / CuriosityStream bundle is no longer active. Instead, you can sign up for Nebula directly with my discount now for about $2.5 a month with a yearly plan, which includes Nebula Originals AND the whole Nebula Classes platform, too, including my own class.
Sign up here: https://go.nebula.tv/techaltar

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

Apple just reached the #1 spot in the Chinese smartphone market a few months ago, overtaking local rivals like Xiaomi, Huawei and OPPO. No other foreign brand is popular in the country, so how did Apple do it?

The Story Behind - ep. 82

Bonus video (Nebula Plus): https://nebula.app/videos/techaltar-bonus-apples-first-china-victory
This video on Nebula: https://nebula.app/videos/techaltar-samsung-failed-how-did-apple-do-it

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support TechAltar directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► Attributions ◄◄◄  

Music by Edemski: https://soundcloud.com/edemski


## North Korea hackers stole $400m of cryptocurrency in 2021, report says
 - [https://www.bbc.com/news/business-59990477](https://www.bbc.com/news/business-59990477)
 - RSS feed: https://www.bbc.com
 - date published: 2022-01-14 13:52:04+00:00

North Korea hackers stole $400m of cryptocurrency in 2021, report says


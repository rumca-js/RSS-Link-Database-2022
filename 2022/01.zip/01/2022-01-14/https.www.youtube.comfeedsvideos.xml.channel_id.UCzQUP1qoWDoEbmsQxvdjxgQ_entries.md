# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Ari, Mark, and Shane Try Jujimufu's Smelling Salts
 - [https://www.youtube.com/watch?v=PDG7SzDBTC4](https://www.youtube.com/watch?v=PDG7SzDBTC4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-01-14 00:00:00+00:00

Taken from JRE #1764 w/Ari Shaffir, Shane Gillis, and Mark Normand:
https://open.spotify.com/episode/2NdZP4tbBXYPwvpo5cwcAP?si=cca68668bbd74bf3

## Unanswered Questions About Epstein and Ghislaine
 - [https://www.youtube.com/watch?v=XJTvn_WHiXk](https://www.youtube.com/watch?v=XJTvn_WHiXk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-01-14 00:00:00+00:00

Taken from JRE #1764 w/Ari Shaffir, Shane Gillis, and Mark Normand:
https://open.spotify.com/episode/2NdZP4tbBXYPwvpo5cwcAP?si=cca68668bbd74bf3


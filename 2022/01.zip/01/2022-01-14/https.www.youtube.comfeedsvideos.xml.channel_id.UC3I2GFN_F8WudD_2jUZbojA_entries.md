# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Courtney Barnett - Before You Gotta Go (Live on KEXP)
 - [https://www.youtube.com/watch?v=kQSYpDLnK3w](https://www.youtube.com/watch?v=kQSYpDLnK3w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-14 00:00:00+00:00

http://KEXP.ORG presents Courtney Barnett performing “Before You Gotta Go” live in the KEXP studio. Recorded December 14, 2021.

Courtney Barnett - Vocals / Guitar
Bones Sloane - Bass
Stella Mozgawa - Drums

Host: Cheryl Saters
Audio Engineer: Kevin Suggs
Guest Engineer: Jason Tarulli
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://courtneybarnett.com.au
http://kexp.org

## Courtney Barnett - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=CoehsLS2YUQ](https://www.youtube.com/watch?v=CoehsLS2YUQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-14 00:00:00+00:00

http://KEXP.ORG presents Courtney Barnett performing live in the KEXP studio. Recorded December 14, 2021.

Songs:
Rae Street
Sunfair Sundown
Before You Gotta Go
Turning Green

Courtney Barnett - Vocals / Guitar
Bones Sloane - Bass
Stella Mozgawa - Drums

Host: Cheryl Saters
Audio Engineer: Kevin Suggs
Guest Engineer: Jason Tarulli
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://courtneybarnett.com.au
http://kexp.org

## Courtney Barnett - Rae Street (Live on KEXP)
 - [https://www.youtube.com/watch?v=SKde1RsXuNc](https://www.youtube.com/watch?v=SKde1RsXuNc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-14 00:00:00+00:00

http://KEXP.ORG presents Courtney Barnett performing “Rae Street” live in the KEXP studio. Recorded December 14, 2021.

Courtney Barnett - Vocals / Guitar
Bones Sloane - Bass
Stella Mozgawa - Drums

Host: Cheryl Saters
Audio Engineer: Kevin Suggs
Guest Engineer: Jason Tarulli
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://courtneybarnett.com.au
http://kexp.org

## Courtney Barnett - Sunfair Sundown (Live on KEXP)
 - [https://www.youtube.com/watch?v=hUYrAbGOTwg](https://www.youtube.com/watch?v=hUYrAbGOTwg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-14 00:00:00+00:00

http://KEXP.ORG presents Courtney Barnett performing “Sunfair Sundown” live in the KEXP studio. Recorded December 14, 2021.

Courtney Barnett - Vocals / Guitar
Bones Sloane - Bass
Stella Mozgawa - Drums

Host: Cheryl Saters
Audio Engineer: Kevin Suggs
Guest Engineer: Jason Tarulli
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://courtneybarnett.com.au
http://kexp.org

## Courtney Barnett - Turning Green (Live on KEXP)
 - [https://www.youtube.com/watch?v=qiaB6uedjFU](https://www.youtube.com/watch?v=qiaB6uedjFU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-01-14 00:00:00+00:00

http://KEXP.ORG presents Courtney Barnett performing “Turning Green” live in the KEXP studio. Recorded December 14, 2021.

Courtney Barnett - Vocals / Guitar
Bones Sloane - Bass
Stella Mozgawa - Drums

Host: Cheryl Saters
Audio Engineer: Kevin Suggs
Guest Engineer: Jason Tarulli
Mastering Engineer: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Scott Holpainen
Editor: Jim Beckmann

https://courtneybarnett.com.au
http://kexp.org


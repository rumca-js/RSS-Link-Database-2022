# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Thought Politics Was Corrupt? Watch This NEXT LEVEL SH*T!!
 - [https://www.youtube.com/watch?v=aBOVyHyv_0o](https://www.youtube.com/watch?v=aBOVyHyv_0o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-01-15 00:00:00+00:00

Recent scandals regarding the huge stock profits that politicians are making has prompted a call to ban trading in congress. So how likely is this to actually happen? 
#InsiderTrading #NancyPelosi #Corruption 

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Hang On…. Have We All Been CONNED By Jan 6th?!
 - [https://www.youtube.com/watch?v=5bkiEnKLUjI](https://www.youtube.com/watch?v=5bkiEnKLUjI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-01-14 00:00:00+00:00

The events of January 6th have been used to further polarise the population – but in terms of being unitised to suit political agendas, is this another example how Republicans and Democrats have the same objective? 
#January6th #CapitolHill #DonaldTrump #Tucker #TedCruz

Get tickets for my 2022 tour here: http://bit.ly/33_2022

Elites are taking over! Our only hope is to form our own. To learn more join my cartel here https://www.russellbrand.com/join and get weekly bulletins too incendiary for anything but your private inbox.
*not a euphemism

Listen to my Luminary Original podcast, Under The Skin, to hear from guests including Edward Snowden, Jonathan Haidt, Jordan Peterson, Naomi Klein, Kehinde Andrews, Adam Curtis and Vandana Shiva.
Subscribe to Luminary at luminary.link/russell

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

My NEW weekly meditation podcast, Above the Noise, is available now only on Luminary. Meditate with me here: luminary.link/meditate

FOOTBALL IS NICE is my free, weekly, full-length podcast - subscribe here: https://www.youtube.com/c/FootballisNiceRussellBrand

My Audible Original, ‘Revelation', is out NOW!
US: http://adbl.co/revelation
UK: http://adbl.co/revelationuk
AU: http://adbl.co/revelationau
CA: http://adbl.co/revelationca

Facebook:
https://www.facebook.com/RussellBrand/

Instagram: 
https://instagram.com/russellbrand/

Twitter: 
https://twitter.com/rustyrockets

TikTok:
https://www.tiktok.com/@russellbrand

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


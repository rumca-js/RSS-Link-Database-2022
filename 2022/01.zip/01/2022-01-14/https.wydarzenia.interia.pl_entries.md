## Rozpad Rady Medycznej. 13 członków złożyło rezygnację - Wydarzenia w INTERIA.PL
 - [https://wydarzenia.interia.pl/raport-koronawirus-chiny/news-rozpad-rady-medycznej-13-czlonkow-zlozylo-wnioski-do-premier,nId,5769419](https://wydarzenia.interia.pl/raport-koronawirus-chiny/news-rozpad-rady-medycznej-13-czlonkow-zlozylo-wnioski-do-premier,nId,5769419)
 - RSS feed: https://wydarzenia.interia.pl
 - date published: 2022-01-14 20:11:00+00:00

Rozpad Rady Medycznej. 13 członków złożyło rezygnację - Wydarzenia w INTERIA.PL


# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## "If I could give you jail time on this I would": Judge shames elderly cancer patient
 - [https://www.cnn.com/videos/us/2022/01/14/michigan-judge-shames-cancer-patient-elder-zoom-orig-kj.cnn](https://www.cnn.com/videos/us/2022/01/14/michigan-judge-shames-cancer-patient-elder-zoom-orig-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 23:18:47+00:00

Captured on Zoom, a district judge in Hamtramck, Michigan berated a 72-year-old cancer patient for his overgrown landscaping, despite his pleas.

## Alec Baldwin turns over cell phone in 'Rust' shooting investigation
 - [https://www.cnn.com/2022/01/14/entertainment/alec-baldwin-turns-over-phone-rust-shooting-investigation/index.html](https://www.cnn.com/2022/01/14/entertainment/alec-baldwin-turns-over-phone-rust-shooting-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 23:18:26+00:00

Alec Baldwin has turned over his cell phone to law enforcement officials as part of their investigation into the fatal shooting on the set of the film "Rust," the Santa Fe County District Attorney's office told CNN.

## UK energy firm apologizes for sending customers socks during heating crisis
 - [https://www.cnn.com/2022/01/14/business/british-energy-company-eon-next-socks-energy-crisis/index.html](https://www.cnn.com/2022/01/14/business/british-energy-company-eon-next-socks-energy-crisis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 23:04:56+00:00

A large British energy firm apologized to its customers Friday after sending them socks advising them to turn the heat down in the midst of the country's energy crisis.

## Thieves in LA are looting freight trains filled with packages from UPS, FedEx and Amazon
 - [https://www.cnn.com/2022/01/14/economy/la-freight-railroad-theft/index.html](https://www.cnn.com/2022/01/14/economy/la-freight-railroad-theft/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 22:48:18+00:00

Photos and videos showing piles of empty boxes littered alongside rail tracks in Los Angeles County, California have gone viral as shipping companies say they've seen a dramatic spike in railroad theft. Some of the boxes are packages from companies like UPS, Amazon and FedEx.

## Watch record setting bid for a single Spider-Man comic page
 - [https://www.cnn.com/videos/business/2022/01/14/spider-man-comic-book-auction-orig.cnn-business](https://www.cnn.com/videos/business/2022/01/14/spider-man-comic-book-auction-orig.cnn-business)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 22:44:21+00:00

A single page of a Spider-Man comic book sold for $3.36 million and became the most expensive page from a comic book ever sold at auction.

## Why House candidate left the GOP
 - [https://www.cnn.com/videos/politics/2022/01/14/house-candidate-leaves-gop-gregg-brelsford-nr-vpx.cnn](https://www.cnn.com/videos/politics/2022/01/14/house-candidate-leaves-gop-gregg-brelsford-nr-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 22:37:26+00:00

CNN's Alisyn Camerota speaks with US House candidate for Alaska, Gregg Brelsfod about his decision to leave the Republican Party and run as an independent.

## FedEx asks permission to add anti-missile system to some cargo planes
 - [https://www.cnn.com/2022/01/14/business/fedex-anti-missile-cargo-planes/index.html](https://www.cnn.com/2022/01/14/business/fedex-anti-missile-cargo-planes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 22:22:50+00:00

FedEx wants to operate cargo planes outfitted with lasers that throw off incoming heat-seeking missiles, according to a newly published federal documents.

## Djokovic faces decisive court hearing on whether he can remain in Australia
 - [https://www.cnn.com/collections/djokovic-intl-011421/](https://www.cnn.com/collections/djokovic-intl-011421/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 22:17:10+00:00



## Denmark's former defense minister charged with leaking state secrets
 - [https://www.cnn.com/2022/01/14/europe/denmark-lawmaker-charged-leaks-intl/index.html](https://www.cnn.com/2022/01/14/europe/denmark-lawmaker-charged-leaks-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 21:07:51+00:00

Denmark's former defense minister has been charged with leaking state secrets, he said in a statement Friday.

## Stocks sink as big banks get pummeled
 - [https://www.cnn.com/2022/01/14/investing/dow-stock-market-today/index.html](https://www.cnn.com/2022/01/14/investing/dow-stock-market-today/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 21:06:55+00:00

Investors clearly didn't want to go into the upcoming three-day weekend holding onto stocks. The Dow fell more than 350 points, led by a steep fall for shares of JPMorgan Chase and other big banks.

## An exhibition considers what's changed since the Black Power movement -- and what hasn't
 - [https://www.cnn.com/style/article/black-panthers-this-tender-fragile-thing-exhibition-cec/index.html](https://www.cnn.com/style/article/black-panthers-this-tender-fragile-thing-exhibition-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 20:19:51+00:00

Many will know the iconic photo of Black Panther Party co-founder Huey P. Newton sitting on a rattan peacock chair, with a spear in one hand and a shotgun in the other.

## Ohio's new congressional map overruled for 'unduly favoring' Republicans
 - [https://www.cnn.com/2022/01/14/politics/ohio-congressional-map-overturned/index.html](https://www.cnn.com/2022/01/14/politics/ohio-congressional-map-overturned/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 20:12:55+00:00

Ohio's state supreme court ruled Friday that the state's newly-drawn congressional map, which was passed by the GOP-controlled legislature, violates the state constitution because it "unduly favors the Republican Party and disfavors the Democratic Party."

## That package you're missing might have been stolen in Los Angeles
 - [https://www.cnn.com/videos/business/2022/01/14/train-theft-los-angeles-package-theft.cnn](https://www.cnn.com/videos/business/2022/01/14/train-theft-los-angeles-package-theft.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 19:42:15+00:00

Thieves are raiding freight trains along a corridor in Los Angeles and making off with packages and goods destined for all parts of the country. CNN affiliate KCAL/KCBS reports.

## Judge shames and fines cancer patient for his unkept yard
 - [https://www.cnn.com/2022/01/14/us/judge-shames-cancer-patient-yard-work-michigan-trnd/index.html](https://www.cnn.com/2022/01/14/us/judge-shames-cancer-patient-yard-work-michigan-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 19:28:03+00:00

A father and son appeared for an online court appointment for a citation they received for their unkept yard in Michigan, but instead of a slap on the wrist from the judge, the father was berated.

## Sinead O'Connor hospitalized, days after teenage son's death
 - [https://www.cnn.com/2022/01/14/entertainment/sinead-oconnor-hospital-intl-scli/index.html](https://www.cnn.com/2022/01/14/entertainment/sinead-oconnor-hospital-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 19:04:59+00:00

Sinéad O'Connor has been admitted to the hospital, one week after her 17-year-old son was found dead.

## Mary Carillo on Djokovic saga: 'I don't think he should play'
 - [https://www.cnn.com/videos/tv/2022/01/14/amanpour-mary-carillo-novak-djokovic-australian-open.cnn](https://www.cnn.com/videos/tv/2022/01/14/amanpour-mary-carillo-novak-djokovic-australian-open.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 19:03:02+00:00

The broadcaster and former tennis pro says Novak Djokovic is in "a lot of trouble" as he fights to compete in the Australian Open.

## DNA sequencing solves mystery of earliest hybrid animal's identity
 - [https://www.cnn.com/2022/01/14/world/kunga-mystery-animal-identity-revealed-scn/index.html](https://www.cnn.com/2022/01/14/world/kunga-mystery-animal-identity-revealed-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 19:02:20+00:00

Bronze Age bioengineers created the earliest hybrid animal -- a majestic horselike creature known as a kunga that had a donkey mom, a Syrian wild ass for a father and lived 4,500 years ago, according to new research based on the sequencing of DNA from the animal's skeleton.

## Alexis Ohanian, aka Mr. Serena Williams, on why parental leave is good for men
 - [https://www.cnn.com/2022/01/14/opinions/alexis-ohanian-parental-leave-wellness/index.html](https://www.cnn.com/2022/01/14/opinions/alexis-ohanian-parental-leave-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 18:49:14+00:00

The fight for universal paid parental leave has been dominated by women.

## Prosecutors say three women assaulted Delta security officer after being denied boarding
 - [https://www.cnn.com/2022/01/14/us/delta-airlines-new-york-security/index.html](https://www.cnn.com/2022/01/14/us/delta-airlines-new-york-security/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 18:44:17+00:00

Prosecutors say three "belligerent" women were indicted for allegedly punching and kicking a Delta security officer at the John F. Kennedy International Airport in New York after being told they would be denied boarding for a flight to Puerto Rico in September of last year.

## US intel: Russia plotting 'false-flag' operation to justify Ukraine invasion
 - [https://www.cnn.com/2022/01/14/politics/us-intelligence-russia-false-flag/index.html](https://www.cnn.com/2022/01/14/politics/us-intelligence-russia-false-flag/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 18:29:59+00:00

• 'Massive' cyberattack hits Ukraine govt. sites

## US intelligence indicates Russia preparing operation to justify invasion of Ukraine
 - [https://www.cnn.com/collections/ukraine-intl-011422/](https://www.cnn.com/collections/ukraine-intl-011422/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 18:07:59+00:00



## In days after January 6, McCarthy said Trump admitted bearing some responsibility for Capitol attack
 - [https://www.cnn.com/collections/intl-jan-6-011422/](https://www.cnn.com/collections/intl-jan-6-011422/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 17:24:13+00:00



## Trump admitted bearing some responsibility for Capitol attack, McCarthy said
 - [https://www.cnn.com/2022/01/14/politics/kfile-kevin-mccarthy-donald-trump-january-6/index.html](https://www.cnn.com/2022/01/14/politics/kfile-kevin-mccarthy-donald-trump-january-6/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 17:18:02+00:00

House Minority Leader Kevin McCarthy said publicly and privately in the days following the deadly riots at the US Capitol that President Donald Trump admitted personally bearing some responsibility for the attack -- one of several reasons why the select committee on January 6 wants to hear from the House's top Republican.

## How the world reacted after Djokovic's visa canceled again
 - [https://www.cnn.com/2022/01/14/tennis/novak-djokovic-reaction-australian-open-via-spt-intl/index.html](https://www.cnn.com/2022/01/14/tennis/novak-djokovic-reaction-australian-open-via-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 17:01:23+00:00

The ongoing saga surrounding Novak Djokovic's participation at this year's Australian Open took another twist on Friday and the world has been reacting to the decision to revoke the Serbian's visa for a second time.

## Opinion: Djokovic saga shows the absurd confusion of Australia's Covid fortress
 - [https://www.cnn.com/2022/01/12/opinions/novak-djokovic-covid-19-confusion-australian-open-saga-soutphommasane-stears/index.html](https://www.cnn.com/2022/01/12/opinions/novak-djokovic-covid-19-confusion-australian-open-saga-soutphommasane-stears/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 17:00:57+00:00

Many tennis commentators say Novak Djokovic is all but unbeatable in Australia. He is, after all, the winner of a remarkable nine Australian Open Grand Slam titles. And, as the Australian government discovered this week, it hasn't proven easy to defeat him in a court of law, either.

## Ed Sheeran wants to build a 'burial zone' in the grounds of his home
 - [https://www.cnn.com/2022/01/14/entertainment/ed-sheeran-crypt-scli-intl-gbr/index.html](https://www.cnn.com/2022/01/14/entertainment/ed-sheeran-crypt-scli-intl-gbr/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 16:46:06+00:00

Singer-songwriter Ed Sheeran is drawing up plans for an unusual addition to his sprawling English country estate: a burial chamber.

## The US could lose all flights to China ahead of the Beijing Winter Olympics
 - [https://www.cnn.com/2022/01/14/business/us-china-flights-olympics-intl-hnk/index.html](https://www.cnn.com/2022/01/14/business/us-china-flights-olympics-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 16:27:48+00:00

People trying to fly from the United States to China may soon be confronted with an unthinkable scenario: Starting next week, there are likely to be no commercial flights bound for the country as Beijing tries to keep coronavirus infections out ahead of the 2022 Winter Olympics.

## Britney Spears responds to her sister's tell-all book in social media exchange
 - [https://www.cnn.com/2022/01/14/entertainment/jamie-lynn-spears-britney-spears-fight-book-interview/index.html](https://www.cnn.com/2022/01/14/entertainment/jamie-lynn-spears-britney-spears-fight-book-interview/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 16:10:53+00:00

Britney Spears is not happy that her sister Jamie Lynn Spears has a new book out in which she discusses their tumultuous relationship.

## Biden and Democrats run up against relentless conservative power
 - [https://www.cnn.com/collections/intl-biden---us-pols-011422/](https://www.cnn.com/collections/intl-biden---us-pols-011422/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 16:02:12+00:00



## French mechanic dies in Dakar Rally accident
 - [https://www.cnn.com/2022/01/14/motorsport/mechanic-death-dakar-rally-spt-intl/index.html](https://www.cnn.com/2022/01/14/motorsport/mechanic-death-dakar-rally-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 15:43:18+00:00

A French mechanic died in an accident on Friday during the Dakar Rally held in Saudi Arabia, according to a statement by Dakar Rally organizers.

## Ukraine is Putin's 'last stand', says Russia expert
 - [https://www.cnn.com/videos/tv/2022/01/13/amanpour-russia-ukraine-trenin.cnn](https://www.cnn.com/videos/tv/2022/01/13/amanpour-russia-ukraine-trenin.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 14:53:26+00:00

Analyst Dmitri Trenin says Vladimir Putin is using the Russian military as leverage to halt NATO expansion towards Russia's own borders

## A page of Spider-Man comic book history just sold for $3 million
 - [https://www.cnn.com/2022/01/14/entertainment/spider-man-black-suit-comic-3-million-cec/index.html](https://www.cnn.com/2022/01/14/entertainment/spider-man-black-suit-comic-3-million-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 14:51:02+00:00

A seminal moment of Spider-Man history, sketched on a single page of a Marvel comic, just became the most expensive page from a comic book ever sold at auction.

## How many times you should wear your N95 mask
 - [https://www.cnn.com/2022/01/13/health/n95-mask-wear-care-tips-wellness/index.html](https://www.cnn.com/2022/01/13/health/n95-mask-wear-care-tips-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 14:43:28+00:00

You're ready to swap your old cloth masks for N95s as some experts recommend, but the higher price tag and two little words -- "single use" -- are giving you pause. How long can you really wear an N95 and still protect yourself and others from Covid-19 risk?

## See inside charred mayor's office damaged during violent protests
 - [https://www.cnn.com/videos/world/2022/01/14/kazakhstan-protests-almaty-aftermath-pleitgen-pkg-newday-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2022/01/14/kazakhstan-protests-almaty-aftermath-pleitgen-pkg-newday-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 13:18:59+00:00

CNN's Frederik Pleitgen takes us inside the mayor's office in Almaty, Kazakhstan, which was damaged during violent protests on January 5. At least 164 people were killed during the unrest and more than 10,000 have been detained, according to the country's Internal Affairs Ministry.

## Shakespeare doesn't get more brutal than this
 - [https://www.cnn.com/style/article/macbeth-stefan-dechant-production-design-culture-queue/index.html](https://www.cnn.com/style/article/macbeth-stefan-dechant-production-design-culture-queue/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 11:28:05+00:00

A power-hungry Scot strides down a corridor, murder on his mind. Is this another Macbeth adaptation I see before me? Undeniably, yes, but Joen Coen's take on Shakespeare's age-old tale looks unlike any other.

## India's richest man is pouring more than $80 billion into green energy
 - [https://www.cnn.com/2022/01/14/business/india-reliance-gujarat-green-energy-investment-intl-hnk/index.html](https://www.cnn.com/2022/01/14/business/india-reliance-gujarat-green-energy-investment-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 11:10:23+00:00

Indian billionaire Mukesh Ambani is going big on green energy.

## China is still the ultimate prize that Western banks can't resist
 - [https://www.cnn.com/2022/01/14/investing/china-western-banks-mic-intl-hnk/index.html](https://www.cnn.com/2022/01/14/investing/china-western-banks-mic-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 10:41:59+00:00

For many companies, doing business in China is getting trickier by the day. But Western banks and asset managers are more than willing to up their bets on the world's second biggest economy, convinced that the opportunities remain too good to pass up.

## Dogecoin soars after Elon Musk says it can be used to buy Tesla merchandise
 - [https://www.cnn.com/2022/01/14/investing/dogecoin-elon-musk-tesla/index.html](https://www.cnn.com/2022/01/14/investing/dogecoin-elon-musk-tesla/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 09:48:52+00:00

Meme-based cryptocurrency dogecoin jumped on Friday after Tesla chief Elon Musk said the electric carmaker will accept it as payment for merchandise.

## Indian court acquits Catholic bishop on charge of raping a nun, prosecutor says
 - [https://www.cnn.com/2022/01/14/india/india-catholic-bishop-acquitted-rape-nun-intl-hnk/index.html](https://www.cnn.com/2022/01/14/india/india-catholic-bishop-acquitted-rape-nun-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 09:41:36+00:00

An Indian court on Friday acquitted a Catholic bishop of rape charges, a prosecution lawyer said -- in a case that attracted international attention and shocked the country's Christian community.

## 20 of the world's best soups
 - [https://www.cnn.com/travel/article/worlds-best-wellness-soups/index.html](https://www.cnn.com/travel/article/worlds-best-wellness-soups/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 09:12:22+00:00

If a steaming bowl of soup strikes you as the ultimate in old-fashioned comfort, you've got plenty of company. Soup is one of the world's oldest and most universal foods, said Janet Clarkson, author of the book "Soup: A Global History."

## These are the world's weirdest sports
 - [https://www.cnn.com/2022/01/14/sport/futuristic-high-tech-sports-spc-intl/index.html](https://www.cnn.com/2022/01/14/sport/futuristic-high-tech-sports-spc-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-14 09:04:00+00:00

From the metaverse to non-fungible tokens (NFTs), new technology is endlessly changing how we live our lives -- and one of the biggest arenas where that's playing out is sport.


## Exploring System76's New Rust Based Desktop Environment | Devloop
 - [https://blog.edfloreshz.dev/articles/linux/system76/rust-based-desktop-environment/](https://blog.edfloreshz.dev/articles/linux/system76/rust-based-desktop-environment/)
 - RSS feed: https://blog.edfloreshz.dev
 - date published: 2022-01-14 09:27:34+00:00

This article intends to shine a light at the development of a new desktop environment for the Pop!_OS operating system.


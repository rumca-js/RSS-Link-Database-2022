# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## The Fatal Flaw in HP's Omen 45L broke me
 - [https://www.youtube.com/watch?v=eSqrq8v-QLs](https://www.youtube.com/watch?v=eSqrq8v-QLs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-15 00:00:00+00:00

Try FreshBooks free, for 30 days, no credit card required at https://www.freshbooks.com/linus

SmartDeploy: Claim your FREE IT software (worth $696!) at https://lmg.gg/OTTP7

HP promised to shake up the PC industry with an innovative new CPU cooler design, and I was this close to declaring it the new gaming performance king of prebuilts...

Buy OMEN 45L Gaming Desktop
HP: https://geni.us/SCBswH
Best Buy: https://geni.us/OUPWnSk

Buy Intel Core i9-12900K Desktop Processor
Amazon: https://geni.us/hrzU
Best Buy: https://geni.us/1niRuZp
Newegg: https://geni.us/SLwDuCA

Buy NVIDIA RTX 3090
Amazon: https://geni.us/rMWpj
Best Buy: https://geni.us/24AQV5
Newegg: https://geni.us/4aL0

Buy Cooler Master MasterLiquid ML240L RGB V2
Amazon: https://geni.us/Pk1el
Newegg: https://geni.us/3VIFJj
B&H: https://geni.us/0OhoroT

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1404110-i-was-ready-to-give-hp-the-crown%E2%80%A6/

►GET MERCH: https://lttstore.com
►SUPPORT US ON FLOATPLANE: https://www.floatplane.com/  
►LTX EXPO: https://www.ltxexpo.com/   

AFFILIATES & REFERRALS
---------------------------------------------------
►Affiliates, Sponsors & Referrals: https://lmg.gg/sponsors
►Our WAN Show & Podcast Gear: https://lmg.gg/podcastgear
►Private Internet Access VPN: https://lmg.gg/pialinus2
►Our Official Charging Partner Anker: https://lmg.gg/AnkerLTT
►Secretlabs Gaming Chairs: https://lmg.gg/SecretlabLTT
►MK Keyboards: https://lmg.gg/LyLtl
►Amazon Prime: https://lmg.gg/8KV1v

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
Twitch: https://www.twitch.tv/linustech

FOLLOW OUR OTHER CHANNELS
---------------------------------------------------  
Mac Address: https://lmg.gg/macaddress
Techquickie: https://lmg.gg/techquickieyt
TechLinked: https://lmg.gg/techlinkedyt
ShortCircuit: https://lmg.gg/shortcircuityt

LMG Clips: https://lmg.gg/lmgclipsyt
Channel Super Fun: https://lmg.gg/channelsuperfunyt
They're Just Movies: https://lmg.gg/TheyreJustMoviesYT

MUSIC CREDIT
---------------------------------------------------  
Title: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro Screen Music Credit: Approaching Nirvana - Sugar High http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:18 Specs and design theory
2:27 A quick physical tour
4:02 HP's hardware claims and some history
4:43 Testing the Cryo Chamber
6:48 Gaming and workstation performance
8:18 Predictably, HP does what HP does
9:25 Comparing against XMP
10:17 Conclusion

## Razer Got CAUGHT! - WAN Show January 14, 2022
 - [https://www.youtube.com/watch?v=sb5GlR3pjt8](https://www.youtube.com/watch?v=sb5GlR3pjt8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-14 00:00:00+00:00

Get 50% off your Zoho CRM annual subscription with code ZCRM50 at: https://lmg.gg/ZohoCRMWAN

Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Check out Secret Lab at https://lmg.gg/SecretLabWAN

Check out the WAN Show & Podcast Gear: https://lmg.gg/podcastgear
Check out the They're Just Movies Podcast: https://lmg.gg/tjmpodcast

Podcast Download: TBD

Timestamps: (Courtesy of NoKi1119)
0:00 - Chapters
0:53 - Intro
1:15 - FloatLuke & Linus's computer issues
3:13 - Topic #1 - Razer Zephyr's N95 false ratings
5:10 - Razer representatives allegedly not refunding
6:28 - Linus's experience with Razer's switches
11:08 - Razer removing N95 marketing
14:06 - Topic #2 - Nvidia releases new RTX cards
16:08 - New gen is 50% more expensive than last decade gen
19:30 - Currency & materialism inflation
22:15 - Teen Luke's rule of thumb, consoles & phone pricing
26:13 - Software revenues, Apple dictates the norms, companies follow suit
33:28 - Merch Messages #1
33:58 - LTTStore - "Expensive Edition" CPU pillow
36:38 - Apple agent calls Luke, IAP fee, flagged app e-mail
43:40 - FloatLuke moment
45:39 - Sponsor - Zoho CRM
46:27 - Sponsor - Squarespace
47:28 - Sponsor - Secretlab
48:04 - Topic #3 - White House's tech summit & corporate actions
51:16 - Donating to open-source software
53:29 - Merch Messages custom color
56:27 - Private softwares, community-made add-ons & spam filter
58:23 - Merch Messages #2
59:50 - Linus's retirement update, burning out, merch & lab
1:06:59 - MNT Reform ARM-based laptop, Alternatives to CS workflow
1:10:02 - LTX planning halted due to COVID outbreaks
1:11:40 - iPhone SE3, Linus discusses LMG branding
1:16:52 - CAT8 versus CAT6A for home gaming & encoding
1:21:40 - Topic #4 - Wordle game rip-offs drama
1:22:57 - Topic #5 - Sony ramps up Playstation 4 production
1:25:22 - Topic #6 - Cryptocurrency mining on cars
1:28:15 - Tesla S owner running Ant miner
1:30:14 - Norton bundling crypto miner with the antivirus
1:31:15 - Merch Messages #3
1:54:13 - Outro


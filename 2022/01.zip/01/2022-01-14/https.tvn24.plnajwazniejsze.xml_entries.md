# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Jak to możliwe, że ktoś nie chce być Polakiem? Przecież to najwspanialsze na świecie". Oni uważają się za odrębny naród
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-1803,S00E1803,681371?source_id=bannernewsowy&source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-1803,S00E1803,681371?source_id=bannernewsowy&source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-01-14 15:49:58+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qky8eo-slask-5743280/alternates/LANDSCAPE_1280" />
    Rozmawiał z nimi Łukasz Karusta.


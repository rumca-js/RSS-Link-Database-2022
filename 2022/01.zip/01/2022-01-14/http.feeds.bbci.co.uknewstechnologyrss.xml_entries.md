# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Ukraine cyber-attack: Russia to blame for hack, says Kyiv
 - [https://www.bbc.co.uk/news/world-europe-59992531?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59992531?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-14 16:10:23+00:00

About 70 Ukrainian government websites were targeted, including the foreign and energy ministries.

## YouTube rich list: MrBeast was the highest-paid star of 2021
 - [https://www.bbc.co.uk/news/entertainment-arts-59987711?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59987711?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-14 15:09:24+00:00

Between them, the 10 highest-paid YouTubers raked in $300m last year.

## REvil ransomware gang arrested in Russia
 - [https://www.bbc.co.uk/news/technology-59998925?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-59998925?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-14 14:42:49+00:00

Russian authorities dismantle the notorious cyber-crime gang at the request of the United States.

## Pebbles get caught in Mars rover and other tech news
 - [https://www.bbc.co.uk/news/technology-59994166?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-59994166?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-14 11:55:03+00:00

LJ Rich looks at the best of the week's technology news stories.

## Tech Tent: Has Theranos changed Silicon Valley?
 - [https://www.bbc.co.uk/news/technology-59976157?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-59976157?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-14 10:12:05+00:00

Elizabeth Holmes defrauded investors, but could the scandal usher in a change to Silicon Valley?

## Meta faces billion-pound class-action case
 - [https://www.bbc.co.uk/news/technology-59964654?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-59964654?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-14 08:20:57+00:00

Facebook's 44 million UK users could share £2.3bn in damages, a competition expert intending to sue Meta says

## North Korea hackers stole $400m of cryptocurrency in 2021, report says
 - [https://www.bbc.co.uk/news/business-59990477?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59990477?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-14 05:16:27+00:00

Blockchain research firm Chainalysis says the value extracted from the hacks grew by 40% year-on-year.

## Google will spend £730m to 'reinvigorate' its UK offices
 - [https://www.bbc.co.uk/news/business-59980216?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59980216?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-01-14 00:01:57+00:00

The tech giant is expanding UK staff capacity by 50% and wants to "reinvigorate" the work environment.


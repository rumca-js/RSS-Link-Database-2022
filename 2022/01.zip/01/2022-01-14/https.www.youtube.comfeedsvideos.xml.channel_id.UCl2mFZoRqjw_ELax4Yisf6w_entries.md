# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Car remote kill switch: another reason to not buy the cars of the future.
 - [https://www.youtube.com/watch?v=XvqdJRpELSg](https://www.youtube.com/watch?v=XvqdJRpELSg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-01-15 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://www.congress.gov/bill/117th-congress/house-bill/3684/text

🔵 Desk: https://amzn.to/3njMvN3
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3JZ2rOy
🔵 Camera: https://amzn.to/3K2H5Qw

00:00 Intro
00:16 Going through comments
00:25 How we fact checked it by checking primary sources
01:02 I do not need to support something to be against strawmanning it
01:48 Reading the actual statute
02:00 Word kill DOESN'T show up in text of bill
02:36 Section 24220 Advanced impaired driving technology
02:54 Congress' findings on DUIs
03:30 They're laying it on thick
04:05 Why they're laying it on heavy
05:39 Rest of the bill text
10:00 Summary
10:30 Bill NEVER mentions REMOTE kill switch
11:04 Andrew Cuomo can't disable my car
11:30 Cars SUCK at determining if I am driving "safely"
13:08 How my comments differ from the text of the law
13:56 I am AGAINST THIS POLICY as it is written
14:53 I am AGAINST drunk driving, even 1 drink
15:48 I do not trust the technology to judge my driving properly
16:23 I do not trust this since every car is online today
17:10 Encroachment on freedom
18:15 Do we want computers, not people, assessing our fitness to using our property?
19:39 Why I am sympathetic to slippery slope argument
20:39 This is my gut feeling
20:57 Please correct me if I am wrong

## IRS taxing side hustles NOT going over well with people
 - [https://www.youtube.com/watch?v=UHHR7ZYGzmY](https://www.youtube.com/watch?v=UHHR7ZYGzmY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-01-15 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://www.bloomberg.com/news/articles/2022-01-13/uncle-sam-wants-a-piece-of-your-side-hustle-in-irs-crackdown

🔵 Desk: https://amzn.to/3njMvN3
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3JZ2rOy
🔵 Camera: https://amzn.to/3K2H5Qw

00:00 Hello!
00:13 Snow
00:32 Intro
01:47 More people starting businesses
02:45 Easy to go after small businesses
03:19 Billionaires can afford to do taxes properly
03:41 Small business owners make mistakes
04:50 As small businesses grow, more mistakes
05:42 Hard to find what billionaires are doing wrong
06:05 Examples of small business infractions
06:40 Risk/reward is at the small business level
07:50 Income tax was made for "the rich"
09:00 and then it affected everyone
12:19 What they say they want to do to "the rich" they will do TO YOU!
14:18 People expect small businesses to break tax code
15:15 More instances of small business tax avoidance

## Thank you Tarah Wheeler for EXCELLENT Right to Repair testimony in Washington state!
 - [https://www.youtube.com/watch?v=FP-RbMrJrhU](https://www.youtube.com/watch?v=FP-RbMrJrhU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-01-15 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://tarah.org/
👉 Eric Mill https://twitter.com/konklone
👉 Joe Hall https://twitter.com/JoeBeOne 
👉 Deviant Ollam https://twitter.com/deviantollam https://www.youtube.com/user/DeviantOllam 

🔵 Desk: https://amzn.to/3njMvN3
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3JZ2rOy
🔵 Camera: https://amzn.to/3K2H5Qw

## Louis Rossmann livestream: thank you for 1.7 million
 - [https://www.youtube.com/watch?v=3O5uqqeaG0E](https://www.youtube.com/watch?v=3O5uqqeaG0E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-01-14 00:00:00+00:00

https://tinyurl.com/rossmatrix
Post a message on screen http://bit.ly/postamessage Or else I will read it in the normal chat if it is not swamped. I am sorry if I miss your message, I do my best to read as much stuff as I can that is somewhat interesting even if it is a normal unpaid message, but the chat sometimes moves way too fast for me to get things.

## NYC logic: rent hits all time high as businesses & people leave
 - [https://www.youtube.com/watch?v=Cb4kYtxDcGg](https://www.youtube.com/watch?v=Cb4kYtxDcGg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-01-14 00:00:00+00:00

https://tinyurl.com/rossmatrix
👉 https://www.census.gov/newsroom/press-releases/2021/2021-population-estimates.html
👉 https://www.bloomberg.com/news/articles/2022-01-13/manhattan-rents-surge-to-record-on-demand-for-doorman-buildings

🔵 Desk: https://amzn.to/3njMvN3
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3JZ2rOy
🔵 Camera: https://amzn.to/3K2H5Qw


## Making Your Game Go Fast by Asking Windows Nicely | Anthropic Studios
 - [https://www.anthropicstudios.com/2022/01/13/asking-windows-nicely/](https://www.anthropicstudios.com/2022/01/13/asking-windows-nicely/)
 - RSS feed: https://www.anthropicstudios.com
 - date published: 2022-01-14 00:01:35.582233+00:00

How to stop Windows throttling your game, set DPI awareness programatically, use Application Manifests in Rust and prefer discrete GPUs to integrated in OpenGL.


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 6 HARDEST Easter Eggs In Recent Games
 - [https://www.youtube.com/watch?v=crMuaOQDGJM](https://www.youtube.com/watch?v=crMuaOQDGJM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-15 00:00:00+00:00

Some games have wildly difficult or obscure Easter Eggs. Here are some secrets from recent games that we loved.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:17 Halo Infinite
1:35 FNaF: Security Breach 
4:00 Metroid Dread
5:41 Deltarune Chapter 2 
7:36 Psychonauts 2
9:05 Inscryption

## God of War PC - Before You Buy
 - [https://www.youtube.com/watch?v=z9MQGmUFF3w](https://www.youtube.com/watch?v=z9MQGmUFF3w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-15 00:00:00+00:00

God of War (PC, PS4, PS5) finally arrives on the PC platform. How is it? Let's revisit this classic.
Subscribe for more: http://youtube.com/gameranxtv ▼▼


Watch more 'Before You Buy': https://bit.ly/2kfdxI6

## DYING LIGHT 2 GAME LENGTH IS HUGE, STALKER 2 DELAYED, & MORE
 - [https://www.youtube.com/watch?v=jeUuzkaAYHE](https://www.youtube.com/watch?v=jeUuzkaAYHE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-14 00:00:00+00:00

Thank you Raycon for sponsoring this video. Go to https://buyraycon.com/gameranx for 15% off your order! Brought to you by Raycon.

Updates on PS5 availability with Sony producing more PS4 consoles,  Xbox discontinues the Xbox One, Dying Light 2 updates, and more in a week full of gaming news.

 ~~~~STORIES~~~~



Dying Light 2 size update
https://twitter.com/DyingLightGame/status/1479860453140434945
https://twitter.com/DyingLightGame/status/1480633241937891328
+
https://www.youtube.com/watch?v=2MD4gTitmzw

STALKER 2 DELAYED
https://twitter.com/stalker_thegame/status/1481279837469872129

Sony makes more PS4s to make up for PS5
https://www.bloomberg.com/news/articles/2022-01-12/sony-tackles-playstation-5-shortage-by-making-more-ps4-consoles

PS5 backwards compatible overhaul?
https://www.gamespot.com/articles/sony-files-patent-that-could-help-backwards-compatibility-on-ps5/1100-6499626/


End of Xbox One
https://www.theverge.com/2022/1/13/22881211/microsoft-discontinues-xbox-one-consoles-2020



Twisted Metal
https://gamerant.com/twisted-metal-reboot-new-developer-firesprite/

Save Red Dead Online 
https://www.ign.com/articles/save-red-dead-online-cry-for-support-rockstar

Pokemon Arceus overview gameplay
https://youtu.be/abosJrVnuCA
Kirby trailer 
https://youtu.be/RiPcRCWzcGo
Hitman 3 update 
https://youtu.be/7ATc5TaIjT8


God of War PC
https://youtu.be/_m2lpLoNiFk

AC on Switch
https://youtu.be/z0BXfN08Evs

Geico Portal thing
https://youtu.be/VtPwBz30Pww


## How I plan - stitcher.io
 - [https://stitcher.io/blog/how-i-plan](https://stitcher.io/blog/how-i-plan)
 - RSS feed: https://stitcher.io
 - date published: 2022-01-14 09:09:38.986368+00:00

My personal thoughts on the web and programming.


# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## Easy On Me - Adele (Piano + Electric Cello + Cellorchestra Cover) The Piano Guys
 - [https://www.youtube.com/watch?v=6s7ZY-xnoeo](https://www.youtube.com/watch?v=6s7ZY-xnoeo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2022-01-14 00:00:00+00:00

“Easy On Me” by Adele piano & cello cover from The Piano Guys.
Get this Song: https://smarturl.it/TPGEOMstream | WE’RE ON TOUR: https://smarturl.it/the10tour 
Subscribe: https://bit.ly/2XH4GCF | Our NEWEST videos: https://youtube.com/playlist?list=PL7j5iXGSdMwdfnzc8Faa-HJITq9hPEEdI&playnext=1&index=2

We’ve got a brand new song for you. It’s perfect for 2022. Could be the theme song for the year. After 2020, 2021, it’s time to tell 2022,

Go Easy on Me, baby.
Enjoy. Hang in there. We love you!

Learn about our beliefs here: https://smarturl.it/TPG_Beliefs 

Follow The Piano Guys:
Instagram: https://instagram.com/thepianoguys
Facebook: https://facebook.com/ThePianoGuys
TikTok: https://tiktok.com/@thepianoguys 
Twitter: https://twitter.com/thepianoguys

Watch More of The Piano Guys: 
Covers: https://youtube.com/playlist?list=PL7j5iXGSdMwc7n8Tsjl-I8zEOEZsjWydx&playnext=1&index=2 
Official Music Videos: https://youtube.com/playlist?list=PL7j5iXGSdMwfDukj_bIIB_1JhbYtaWRYg&playnext=1&index=2 
Newest Videos: https://youtube.com/playlist?list=PL7j5iXGSdMwdfnzc8Faa-HJITq9hPEEdI&playnext=1&index=2
Most Popular: https://youtube.com/playlist?list=PL7j5iXGSdMweXm56WEjskhCT5oAeEZJQF&playnext=1 

Listen to The Piano Guys: 
Spotify: https://open.spotify.com/artist/0jW6R8CVyVohuUJVcuweDI?si=8GgyFRhiTz6POs8b0ir2IA&dl_branch=1 
Apple Music: https://music.apple.com/us/artist/the-piano-guys/498030399 
Amazon Music: https://amazon.com/The-Piano-Guys/e/B00BXLTTI4 

Credits:
Easy on Me written by Adele and Greg Kurstin
The Piano Guys arrangement written by Steven Sharp Nelson
Produced by Al van der Beek & Steven Sharp Nelson
All instruments performed by Steven Sharp Nelson
Mixed and mastered by Al van der Beek

About The Piano Guys:
Paul, a Yamaha dealer who dabbled in videography, Jon, a professional pianist, Al, a music producer and studio engineer, and Steve, a cellist with a creative superpower called ADHD, all serendipitously joined forces to create the most successful YouTube instrumental music group in history. The Piano Guys’ mission is to inspire and spread hope through incomparably imaginative piano music videos filmed all over the world. On this channel you can regularly find piano covers of music from genres like top 40, pop, classic rock, R&B, hiphop, country, and more. Make sure to subscribe and enable all post notifications. For instant updates, check out The Piano Guys via their social media accounts linked above.

#Adele #PianoCover #CelloCover #Piano #Cello #ThePianoGuys


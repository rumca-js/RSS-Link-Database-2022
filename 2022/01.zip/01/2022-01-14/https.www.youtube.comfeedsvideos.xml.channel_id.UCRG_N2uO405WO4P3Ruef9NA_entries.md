# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Is OnePlus even trying?
 - [https://www.youtube.com/watch?v=C_-4qrvaK0c](https://www.youtube.com/watch?v=C_-4qrvaK0c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-01-14 00:00:00+00:00

Sponsored by Morning Brew. Sign up for free today: http://bit.ly/mbfridaycheckout4 

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

This week OnePlus released the OnePlus 10 Pro and … it's pretty underwhelming, Samsung was supposed to release the Exynos 2200, but didn't, and Google announced Ripple, a new open API for radar tech like Soli.

Episode 79

This video on Nebula: https://nebula.app/videos/the-friday-checkout-is-oneplus-even-trying
Crrowd app & Release Monitor: https://play.google.com/store/apps/details?id=com.crrowd 
Quiz: https://link.crrowd.com/quiz

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

If you want to support my work directly:  https://flattr.com/@techaltar   

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► Attributions & Time stamps◄◄◄

Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:27 Release highlights
0:58 OnePlus 10 Pro is weird
3:36 Exynos 2200 missing
5:48 Google Ripple


## Music industry is suing youtube-dl hosters
 - [https://news.i-n24.com/lifestyle/news/253970.html](https://news.i-n24.com/lifestyle/news/253970.html)
 - RSS feed: https://news.i-n24.com
 - date published: 2022-01-14 09:17:43.697144+00:00

The music industry is shifting up a gear and is now taking action against a German hosting provider. Three big labels are suing the provider Uberspace for hosting the website of the open source project youtube-dl. With the software, which is available on the code sharing platform Github, YouTube videos and music files can be… Continue reading Music industry is...


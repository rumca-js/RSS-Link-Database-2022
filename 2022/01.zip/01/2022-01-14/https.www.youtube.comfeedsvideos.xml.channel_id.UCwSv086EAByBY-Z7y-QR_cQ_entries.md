# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Programowanie predykcyjne, czyli korzystanie z dobrodziejstw sztuki i naszych demonów
 - [https://www.youtube.com/watch?v=EHmTCl6L6ek](https://www.youtube.com/watch?v=EHmTCl6L6ek)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-01-15 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3fuQvWF
2. https://bit.ly/33xOrKV
3. https://bit.ly/2XXLjWa
4. https://bit.ly/3Gxwdbd
5. https://bit.ly/3lAd946
---------------------------------------------------------------
💡 Tagi: #sztuka #technika
--------------------------------------------------------------

## Wysokie rachunki to dopiero początek wydatków! PGNiG może zbankrutować! Trzeba wpompować miliardy!
 - [https://www.youtube.com/watch?v=j2JU30eEEKs](https://www.youtube.com/watch?v=j2JU30eEEKs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2022-01-14 00:00:00+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
👀 Uszi po godzinach: https://goo.gl/cdCFKe
👀 Hello World_: http://bit.ly/31BEhnv
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@protonmail.com
------------------------------------------------------------
👺 Niecenzuralne i agresywne komentarze zostaną usunięte.  Jak już musisz zakląć dawaj znaki (&*%@%).
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
BTC: 174EmE88YFtvs6fuM8ZL5yYbik8hcaY6ud
-------------------------------------------------------------
✅ Źródła:
1. https://bit.ly/3I36ckc
2. https://bit.ly/3fqy8SS
3. https://bit.ly/3FnYDCY
4. https://bit.ly/3qpmiyB
5. https://bit.ly/3qu6VF8
6. https://bit.ly/3ribzoP
7. https://bit.ly/3GKEg4B
---------------------------------------------------------------
💡 Tagi: #gaz #polityka
--------------------------------------------------------------


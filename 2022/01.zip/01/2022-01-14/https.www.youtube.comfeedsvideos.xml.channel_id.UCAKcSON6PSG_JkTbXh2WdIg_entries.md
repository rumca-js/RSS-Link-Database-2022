# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Adam Weiner of Low Cut Connie - two songs for The Current (2020)
 - [https://www.youtube.com/watch?v=6-NNyIkXbu8](https://www.youtube.com/watch?v=6-NNyIkXbu8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-01-14 00:00:00+00:00

The Current's 17th Anniversary Party is coming up January 22, and headlining the show will be Low Cut Connie. Back in 2020, Adam Weiner of Low Cut Connie joined The Current's Jade for a session recorded in Weiner's side room at home in Philadelphia — a space now iconic thanks to Low Cut Connie's Tough Cookies concerts. As we look forward to The Current's 17th anniversary show, enjoy these performances by Adam Weiner of Low Cut Connie.

SONGS PERFORMED
0:00 "Private Lives"
4:23 "Beverly"

FIND MORE:
2016 studio session: https://www.thecurrent.org/feature/2016/02/26/low-cut-connie-perform-in-the-current-studio
2017 studio session: https://www.thecurrent.org/feature/2017/05/27/low-cut-connie-keep-the-swagger-in-rock-n-roll
2018 Rock the Garden performance:
thecurrent.org/feature/2018/07/02/low-cut-connie-ignite-the-crowd-at-rock-the-garden
2019 The Current Day Party during SXSW:
https://www.thecurrent.org/feature/2019/03/17/watch-low-cut-connie-perform-at-the-current-day-party-in-austin-texas-sxsw
2019 The Connie Club episode 4:
https://www.thecurrent.org/feature/2019/11/02/listen-the-connie-club-episode-four-with-guest-cat-oriordan
2020 Adam Weiner MicroShow at the Bryant Lake Bowl:
https://www.thecurrent.org/feature/2020/02/03/low-cut-connie-adam-weiner-plays-a-solo-microshow
2020 Adam Weiner of Low Cut Connie Virtual Session:
https://www.thecurrent.org/feature/2020/04/28/adam-weiner-of-low-cut-connie-plays-an-uplifting-live-virtual-session
2021 Interview with Jill Riley:
https://www.thecurrent.org/feature/2022/01/12/interview-low-cut-connies-adam-weiner-is-staying-positive

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1
Like/Follow:
https://www.facebook.com/TheCurrent/
https://twitter.com/TheCurrent
https://www.instagram.com/thecurrent/

#adamweiner #lowcutconnie #piano


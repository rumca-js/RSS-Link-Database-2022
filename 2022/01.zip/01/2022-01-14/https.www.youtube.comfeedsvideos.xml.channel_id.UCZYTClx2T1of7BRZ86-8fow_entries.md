# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## The Frog with Hidden Claws
 - [https://www.youtube.com/watch?v=m3uFrDD4jO8](https://www.youtube.com/watch?v=m3uFrDD4jO8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-01-15 00:00:00+00:00

A frog with retractable claws? Weird. A frog with claws that it has to push through its skin to use? Even weirder.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Dr. Melvin Sanicas, Sam Lutfi, Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Nazara, Ash, Jason A Saslow, Matt Curls, Eric Jensen, GrowingViolet, Jeffrey Mckishen, Christopher R Boucher, Alex Hackman, Piya Shedden, charles george, Tom Mosner, Jeremy Mysliwiec, Adam Brainard, Chris Peters, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:
https://doi.org/10.1098/rsbl.2008.0219
https://www.researchgate.net/profile/Madhava-Meegaskumbura/publication/259644040_AMPHIBIANS_OF_THE_INDOMALAYAN_REALM/links/00b4952d090e8b152b000000/AMPHIBIANS-OF-THE-INDOMALAYAN-REALM.pdf#page=19 
https://zslpublications.onlinelibrary.wiley.com/doi/pdf/10.1111/j.1469-7998.2009.00631.x
https://www.newscientist.com/article/dn13991-horror-frog-breaks-own-bones-to-produce-claws/
http://dx.doi.org/10.1111/j.1469-7580.2009.01068.x
 
Image Sources:
Communication with David C. Blackburn
https://www.istockphoto.com/photo/black-and-white-cat-scratches-his-nails-on-a-sofa-gm1280290840-378636221
https://commons.wikimedia.org/wiki/File:Ke_-_Trichobatrachus_robustus_-_4.jpg
https://commons.wikimedia.org/wiki/File:TrichobatrachusGreen.jpg
https://www.istockphoto.com/photo/fluffy-gray-cat-gm576748574-99127103
https://commons.wikimedia.org/wiki/File:Ke_-_Trichobatrachus_robustus_-_5.jpg
https://commons.wikimedia.org/wiki/File:Pleurodeles_waltl_by_Ark.jpg
https://commons.wikimedia.org/wiki/File:Pleurodeles_waltl04.jpg

## Counting Species out of Thin Air
 - [https://www.youtube.com/watch?v=ohA6_YDURD4](https://www.youtube.com/watch?v=ohA6_YDURD4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-01-14 00:00:00+00:00

Click here https://cometeer.com/scishow2 to get $20 off your Cometeer order + free shipping - That’s over 30% in savings!

Recent proof-of-concept studies showed that researchers were able to survey animals in an area simply by vacuuming up DNA in the air.

Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Dr. Melvin Sanicas, Sam Lutfi, Bryan Cloer, Christoph Schwanke, Kevin Bealer, Jacob, Nazara, Ash, Jason A Saslow, Matt Curls, Eric Jensen, GrowingViolet, Jeffrey Mckishen, Christopher R Boucher, Alex Hackman, Piya Shedden, charles george, Tom Mosner, Jeremy Mysliwiec, Adam Brainard, Chris Peters, Silas Emrys, Alisa Sherbow

----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: http://www.scishowtangents.org
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
----------
Sources:
https://www.sciencedirect.com/science/article/pii/S2351989418303500
https://www.cell.com/current-biology/fulltext/S0960-9822(21)01650-X
https://www.nature.com/articles/s42003-021-01760-8
https://www.eurekalert.org/news-releases/938583
https://www.cell.com/iscience/fulltext/S2589-0042(21)01487-5
https://www.eurekalert.org/news-releases/938146

Image Sources:
https://svs.gsfc.nasa.gov/14016
https://www.istockphoto.com/photo/scientist-ecologist-taking-a-water-sample-in-the-forest-gm1125152554-295666979
https://commons.wikimedia.org/wiki/File:EDNA_Water_Sampling_(36024122736).jpg
https://www.istockphoto.com/photo/vacum-cleaner-hepa-13-filter-xxxl-gm450453997-30123416
https://www.cell.com/current-biology/fulltext/S0960-9822(21)01650-X#secsectitle0015
https://commons.wikimedia.org/wiki/File:Bog_turtle_survey_team_discussing_the_turtles_(8426057485).jpg
https://commons.wikimedia.org/wiki/File:Tyrannosaurus_Rex_Holotype.jpg
https://commons.wikimedia.org/wiki/File:Citipati_embryo.jpg
https://www.eurekalert.org/multimedia/811758
https://www.eurekalert.org/multimedia/811756
https://www.istockphoto.com/photo/hatching-gm1130236156-298847075
https://www.istockphoto.com/photo/aerial-view-on-spacious-pine-forest-at-sunrise-gm495508534-78024685


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Ungoliant (Mother of Shelob) & the Spiders of the First Age | Tolkien Explained
 - [https://www.youtube.com/watch?v=8QmtTd_rdu8](https://www.youtube.com/watch?v=8QmtTd_rdu8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-01-15 00:00:00+00:00

Ungoliant was a great terror in spider form.  But where did Ungoliant come from? And where did she go after nearly killing Morgoth? We'll cover Ungoliant's complete life and travels, including how she and her spawn led to the renaming of mountains and valleys for the terror they instilled and the harm they inflicted.  The Ered Gorgoroth (Mountains of Terror) and Nan Dungortheb (the Valley of Dreadful Death) would be one of the most dark and evil places in all Beleriand.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

-------------- 
All content falls under fair use: any copying of copyrighted material done for a limited and “transformative” purpose, such as to comment upon, criticize, or parody a copyrighted work. Such uses can be done without permission from the copyright owner.   If your artwork appears and you are not listed here, please let me know! I want to make sure all artists are credited for their amazing work.

To purchase artist work, check out these amazing artists!

Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Jerry Vanderstelt - store.vandersteltstudio.com/main.sc
Anato Finnstark - https://www.artstation.com/anto-finnstark
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html

Ungoliant - Karl Levy
The Bargain with Ungoliant - Morkardfc
Ungoliant vs Morgoth - Ul die
Amazon LOTR - Phase Runner
The Music of the Gods - Kip Rasmussen
Ungoliant in the Mountains - Pablo Dominguez Montanya
Morgoth - TImo Bg Vihola
Ungoliant - Alejandro Perdomo
The Designs of Melkor, Ungoliant - Paul Raymond Gregory
Ungoliant - Pablo Dominguez Montanya
Morgoth and Ungoliant - Alvaro Fernandez Gonzalez
Morgoth and Ungoliant (2) - Alvaro Fernandez Gonzalez
Ungoliant and Melkor  - Jose L Serrano
Melkor Calls Forth Ungoliant - John Howe
The Darkening of Valinor - Sarka Skorpikova
They Are Coming - Silvana Massa
The Killing of the Trees - Lida Holubova
Of the Darkening of Valinor - Titita
Ungoliant Destroying the Trees - Angelo Montanini
Ungoliant Drinking the Light - Pablo Dominguez Montanya
Melkor Kills Finwe - Fumeres Art
Melkor and Ungoliant - Romero Leo
Ungoliant - Karl Levy
Ungoliant and Melkor - Pier Luigi Vurro
Shelob - Serban Gabriel
The Two Trees of Valinor - Felix Sotomayor
Manwe - Kimberly80
Of the Darkening of Valinor - Snow Monster
Orome - Ana Varela
Melkor and Ungoliant - Sandra
Hobbits Spiders - Andrew Johanson
Tulkas the Strong - Saphir93
The Two Trees' Doom - Ted Nasmith
Melkor - Thomas Rouillard
Ungoliant and Morgoth - Jon Torres
Shelob - Ilyazonov
Ungoliant and Melkor - Ruben Devela
Morgoth and Ungoliant - Guy Gondron
Ungoliant and Melkor - Alex Garcia
Shelob - Ozani Ferreira
Beleriand Map - Lamaarcana
Defending Morgoth from Ungoliant - Jovan Delic
Spider's Lair - JimmyJimJim
Spawn of Shelob - Herckeim
Shelob - Pablo Dominguez Montanya
The Spiders of Mirkwood - Ted Nasmith
Beren crosses Ered Gorgoroth - Peter Xavier Price
Beren in Dungortheb - Anna Kulisz
Valley of Death, Ered Gorgoroth - Crocorax
Spiders of Mirkwood - Alvaro Calvo Escudero
Nan Dungortheb - Samo Art
Beren and Luthien - Janka Lateckova
At Tarn Aeluin - Ted Nasmith
Beren the Solitary Outlaw - Peter Xavier Price
Beren crosses Ered Gorgoroth - Peter Xavier Price
Ungoliant - Eric Faure-Brac
Ungoliant's Unlight - Fabrizio Fioretti
Spiders - Andrew Baker (WETA)
Ungoliant - Alejandro Perdomo
Shelob - Daniel Govar
Shelob and Sam - Yaroslav Kovalenok
Shelob - Seth Laster
Bilbo and Spiders - Marc Daniel Goecke
Shelob full body design - Olanda Fong-Surdenas
Shelob's Lair - Baron Von Gunter
Courage - Olanda Fong-Surdenas
Forging the One Ring - Marko Manev
One Ring to Rule Them All - Anato Finnstark
One Ring to Rule Them All - Donato Giancola
The One Ring - Magali Villeneuve
Isildur and the Ring - Andrea Piparo

#ungoliant #tolkien #silmarillion


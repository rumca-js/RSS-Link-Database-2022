# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## NEW CRAZY GOOD Full Body Tracking for ANY VR HEADSET (QUEST 2)
 - [https://www.youtube.com/watch?v=TfCSKM0MyrQ](https://www.youtube.com/watch?v=TfCSKM0MyrQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2022-01-15 00:00:00+00:00

Hello! Today I do some more in depth coverage of the HaritoraX, a full body tracking device that launched a while ago in Japan but is now coming to the Unites States and possibly other countries. I love full body tracking within VR and I think it adds SO much to the experience, but it's almost always been prohibitively expensive. This is the first chance for people that can't afford basestation to have good full body tracking without having any technical knowledge. Slime VR is also very good and quite similar, but as a package this hasn't been beat yet. This is not a full review yet- I will have a unit in hand to compare to other tracking methods soon. This are my impressions at the Shiftall booth at CES 2022. 

https://en.shiftall.net/products/haritorax

My links:
Discord.gg/Thrill
Twitch.tv/Thrilluwu
Twitter.com/Thrilluwu

Timestamps:
00:00 INTRO
01:23 HARITORAX
03:04 IMPRESSIONS
03:09 SETUP
03:43 TRACKING
04:15 EXPANSION SLOTS
04:25 BATTERY LIFE
04:35 OCCLUSION
05:01 CONCLUSIONS
07:03 OUTRO


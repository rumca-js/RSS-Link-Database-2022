# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Russia-Ukraine: US warns of 'false-flag' operation
 - [https://www.bbc.co.uk/news/world-europe-59998988?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59998988?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 21:14:06+00:00

Russia is plotting to stage acts of provocation to create a pretext to invade Ukraine, a US official says.

## How many wine bottles fit in a suitcase - and other questions
 - [https://www.bbc.co.uk/news/uk-politics-59959622?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-59959622?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 18:17:14+00:00

We know some details about Downing Street drinks, but what other questions need answering?

## What titles is Prince Andrew losing?
 - [https://www.bbc.co.uk/news/explainers-59993936?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/explainers-59993936?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 18:11:01+00:00

Prince Andrew's military titles and royal patronages have been returned to the Queen

## Single page of Spider-Man comic sells for over $3.3m
 - [https://www.bbc.co.uk/news/world-us-canada-60002289?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-60002289?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 17:32:16+00:00

An auction house in Dallas erupted into cheers when the record-smashing bid won out.

## What’s really going on with Covid deaths data?
 - [https://www.bbc.co.uk/news/health-60000391?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-60000391?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 17:08:19+00:00

A bigger proportion of deaths recorded in the daily data are people who died with Covid, rather than from it.

## Eddie the Eagle's Olympic jump recreated in giant ice sculpture
 - [https://www.bbc.co.uk/news/uk-england-leeds-59985266?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-59985266?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 15:09:45+00:00

Two artists recreate the Winter Olympian's famous ski jumping effort in 100 tonnes of snow.

## Sutton Coldfield Tories vote unanimously against PM
 - [https://www.bbc.co.uk/news/uk-england-birmingham-59993504?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-59993504?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 14:22:13+00:00

The Royal Sutton Coldfield Conservative Association has withdrawn its support from Boris Johnson.

## Ashling Murphy: Vigils across island for murdered teacher
 - [https://www.bbc.co.uk/news/world-europe-59991850?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59991850?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 13:23:25+00:00

Vigils for Ashling Murphy are planned in dozens of locations across the island of Ireland.

## Downing Street apologises to Queen over lockdown parties
 - [https://www.bbc.co.uk/news/uk-politics-59997364?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-59997364?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 13:22:38+00:00

Two staff get-togethers took place in April last year, the night before Prince Philip's funeral.

## Andy Murray beats Reilly Opelka to reach Sydney Tennis Classic final but Dan Evans out
 - [https://www.bbc.co.uk/sport/tennis/59992967?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/59992967?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 13:10:12+00:00

Britain's Andy Murray fights back to beat Reilly Opelka at the Sydney Tennis Classic and reach his first ATP Tour level final since 2019.

## Empty Sheffield John Lewis to be wrapped in £100k hoarding
 - [https://www.bbc.co.uk/news/uk-england-south-yorkshire-59995771?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-south-yorkshire-59995771?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 13:07:52+00:00

Three options for the Sheffield city centre building are revealed in a new public consultation.

## Burnley game with Leicester game postponed because of Covid-19 and injuries
 - [https://www.bbc.co.uk/sport/football/59995287?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/59995287?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 12:47:42+00:00

Burnley's game at home against Leicester City on Saturday is postponed because of Covid-19 cases and injuries within the Turf Moor side's camp.

## Novak Djokovic: Australia cancels tennis star's visa
 - [https://www.bbc.co.uk/news/world-australia-59991762?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-59991762?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 12:47:27+00:00

The immigration minister says the unvaccinated tennis star may pose a public health risk.

## Covid in Wales: Restrictions to ease after Omicron peak
 - [https://www.bbc.co.uk/news/uk-wales-politics-59984873?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-politics-59984873?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 12:22:02+00:00

Restrictions to lift gradually, with sports fans returning, followed by hospitality back to normal.

## Harry Dunn crash: Anne Sacoolas UK court date postponed
 - [https://www.bbc.co.uk/news/uk-england-northamptonshire-59996219?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-northamptonshire-59996219?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 12:08:34+00:00

Magistrates were due to hear the case concerning the death of motorcyclist Harry Dunn next week.

## The Ashes: Travis Head century puts Australia on top in Hobart
 - [https://www.bbc.co.uk/sport/av/cricket/59992328?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/59992328?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 12:07:17+00:00

England's sloppy performance is punished by a superb century from Australia's Travis Head on day one of the fifth Ashes Test in Hobart.

## UK economy above pre-Covid levels in November
 - [https://www.bbc.co.uk/news/business-59991870?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59991870?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 11:54:11+00:00

Faster than expected growth meant the economy was 0.7% larger than in February 2020, official figures show.

## 'Not great for tennis, not great for Novak' - reaction to Djokovic visa saga
 - [https://www.bbc.co.uk/sport/tennis/59992976?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/59992976?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 11:46:58+00:00

Andy Murray described Novak Djokovic's visa saga as "not great for tennis, not great for the Australian Open, not great for Novak".

## Britney Spears and sister Jamie Lynn's rift grows with social media feud
 - [https://www.bbc.co.uk/news/entertainment-arts-59993346?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59993346?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 11:45:45+00:00

Britney Spears and her younger sister Jamie Lynn argue on social media over their past relationship.

## Channel migrants: Thirty rescued as man dies off French coast
 - [https://www.bbc.co.uk/news/world-europe-59992918?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59992918?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 11:43:42+00:00

The man fell overboard from a migrant boat in what is thought to be the first fatality this year.

## Head century punishes sloppy England in final Ashes Test
 - [https://www.bbc.co.uk/sport/cricket/59945361?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/59945361?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 11:33:49+00:00

England's sloppy performance is punished by a swashbuckling century from Australia's Travis Head on day one of the fifth Ashes Test in Hobart.

## Milton Keynes couple Ron and Joyce Bond celebrate 81-year marriage
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-59979000?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-59979000?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 11:31:50+00:00

Ron and Joyce Bond, aged 102 and 100, say the key to their long marriage is "give and take".

## Prince Andrew accuser welcomes decision to let legal case continue
 - [https://www.bbc.co.uk/news/uk-59991749?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59991749?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 11:01:56+00:00

The Duke of York faces a US civil action over claims he sexually assaulted Virginia Giuffre in 2001.

## Storm Arwen: Communities tell of 'mammoth task' of recovery
 - [https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-59969000?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-59969000?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 10:16:30+00:00

The storm felled trees and ripped roofs off buildings -and people in Aberdeenshire are still recovering.

## The Ashes: Marnus Labuschagne 'ends up in a heap' as Broad takes England's fourth wicket
 - [https://www.bbc.co.uk/sport/av/cricket/59992320?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/59992320?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 07:03:24+00:00

Watch Marnus Labuschagne's 'extraordinary' dismissal as the Australia batter slips and is bowled by Stuart Broad to leave Australia 83-4.

## Novak Djokovic: The twists and turns of his Australia mess
 - [https://www.bbc.co.uk/news/world-australia-59890943?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-59890943?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 06:27:16+00:00

What was meant to be the start of a new year of tennis glory has turned into a global controversy.

## Greyfriars Bobby and the dogs immortalised in statues
 - [https://www.bbc.co.uk/news/uk-scotland-59914709?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-59914709?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 06:06:51+00:00

On the 150th anniversary of his death, we tell the story of Bobby and some other dogs who have inspired statues.

## The papers: Prince Andrew 'throne out' as Queen strips his titles
 - [https://www.bbc.co.uk/news/blogs-the-papers-59989736?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-59989736?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 04:29:16+00:00

The Queen removing Prince Andrew's military titles and royal patronages dominates the front pages.

## Former child prodigy Ruth Slenczynska will release a new album at the age of 97
 - [https://www.bbc.co.uk/news/entertainment-arts-59986543?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-59986543?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 02:16:05+00:00

Pianist Ruth Slenczynska was called one of the greatest prodigies since Mozart when she was six.

## A glimpse of Jewish life before World War Two
 - [https://www.bbc.co.uk/news/world-us-canada-59989496?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-59989496?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 01:33:38+00:00

A huge trove of artefacts that was saved from the Nazis offers a fascinating glimpse of a lost era.

## Downing Street parties: Will two Tory tribes go to war with the PM?
 - [https://www.bbc.co.uk/news/uk-politics-59989546?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-59989546?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 01:08:54+00:00

It isn't just the latest Conservative intake who are worried about Boris Johnson's leadership.

## Africa Cup of Nations is 'a sign of representation' for UK fans
 - [https://www.bbc.co.uk/news/newsbeat-59972405?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-59972405?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 01:08:42+00:00

As the Africa Cup of Nations returns, Newsbeat speaks to fans supporting their home nations.

## Ukraine crisis: Risks remain as Russia and West talk
 - [https://www.bbc.co.uk/news/world-europe-59985589?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-59985589?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 00:48:33+00:00

After a week of talks, there is no sign of Russia pulling back its forces from areas near Ukraine.

## 'As a black woman in STEM I'm used for photo opportunities'
 - [https://www.bbc.co.uk/news/business-59897898?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-59897898?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 00:17:22+00:00

Chemist Cynthia Chapple talks about how to get more black girls from inner-cities into STEM careers.

## Secret audio sheds light on toppled dictator’s frantic last hours
 - [https://www.bbc.co.uk/news/world-africa-59972545?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-59972545?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 00:10:44+00:00

The BBC has obtained extraordinary recordings believed to be of phone calls made by Tunisian ex president Zine al-Abidine Ben Ali as he flew out of the country in 2011.

## Prince Andrew: Why the military titles and royal patronages meant so much
 - [https://www.bbc.co.uk/news/uk-59989886?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-59989886?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 00:06:28+00:00

The BBC's Dan Johnson explains the importance of the Duke of York's military titles and royal patronages.

## South Korea: The celebrity tattooist criminalised for his art
 - [https://www.bbc.co.uk/news/world-asia-59662783?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-59662783?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-01-14 00:06:22+00:00

Doy is one of South Korea's most famous tattoo artists, but also a criminal for doing his job.


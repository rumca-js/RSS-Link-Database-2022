# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Games With MIND-BLOWING LORE
 - [https://www.youtube.com/watch?v=H6seZ2bYg8M](https://www.youtube.com/watch?v=H6seZ2bYg8M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-17 00:00:00+00:00

Many video games give us fascinating and complex stories that only get better the deeper you dive in. Here's some of our favorite video game lore.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro 
0:23 The Dark Souls Series
2:16 Mass Effect 1-3
4:00 The Legend of Zelda
5:52 The Witcher Series
7:28 The Destiny Series
8:46 Remedy Shared Universe
10:06 The Nier Series
11:42 The Kirby Series
12:47 Bloodborne
14:15 Elder Scrolls

## 6 Video Games Series That Went DOWNHILL
 - [https://www.youtube.com/watch?v=BP8i8J7dtmk](https://www.youtube.com/watch?v=BP8i8J7dtmk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-01-16 00:00:00+00:00

We love video games, but some games series and franchises have disappointed us lately or fell out of public favor. Let's discuss a few of them.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Young and Beautiful | Lana Del Rey | funk cover ft. Kenton Chen
 - [https://www.youtube.com/watch?v=8rIZdPOGuoM](https://www.youtube.com/watch?v=8rIZdPOGuoM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-01-17 00:00:00+00:00

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Lana Del Rey's "Young and Beautiful" by Scary Pockets & Kenton Chen.

MUSICIAN CREDITS
Lead vocal: Kenton Chen
Drums: Darren King
Bass: Joe Ayoub
Synth, Percussion, BGVs: Otis McDonald
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker
Producer: Otis McDonald

VIDEO CREDITS
DP: Alejandro Echevarria
Editor: Adam Kritzberg

Recorded Live at Sunset Sound in Los Angeles, CA.

#ScaryPockets #Funk #LanaDelRey #YoungAndBeautiful #KentonChen


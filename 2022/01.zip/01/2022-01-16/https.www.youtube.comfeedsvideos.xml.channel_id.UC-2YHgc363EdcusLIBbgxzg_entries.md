# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Iron-Air Batteries: Storing Energy In Rust | Answers With Joe
 - [https://www.youtube.com/watch?v=27B8TG-WLi0](https://www.youtube.com/watch?v=27B8TG-WLi0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-01-17 00:00:00+00:00

Get 20% of a premium subscription to Brilliant when you're one of the first 200 people to sign up at http://www.brilliant.org/answerswithjoe
Grid energy storage is one of the hottest areas of research and engineering today. It's all about cheap, sustainable, and efficient materials, which makes iron-air batteries stand out amongst the others. Not only is iron plentiful and cheap, it's completely recyclable and even better - rechargeable. Let's look at iron-air battery technology and see how likely it is to transform our energy grid.

Here's Matt's video:
https://youtu.be/Ui6wWzxCrQ8


Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS:

https://www.emergenresearch.com/industry-report/residential-energy-storage-market

https://www.eia.gov/analysis/studies/electricity/batterystorage/pdf/battery_storage_2021.pdf

https://www.reuters.com/business/autos-transportation/europes-carmakers-face-raw-material-bottleneck-ev-batteries-2021-10-13/

https://www.rystadenergy.com/newsevents/news/press-releases/nickel-demand-to-outstrip-supply-by-2024-causing-headaches-for-ev-manufacturers/

https://tradingeconomics.com/commodity/lithium

https://www.utilitydive.com/news/form-energys-20kwh-100-hour-iron-air-battery-could-be-a-substantial-br/603877/

https://formenergy.com/technology/battery-technology/

https://batteryuniversity.com/article/bu-801b-how-to-define-battery-life

https://phys.org/news/2017-11-renaissance-iron-air-battery.html

https://www.sciencedirect.com/science/article/pii/S2590238519300335

https://www.sciencedirect.com/science/article/pii/S2590049821000266

https://www.cnbc.com/2021/08/25/form-energy-raises-240-million-on-iron-air-battery-promise.html

https://greatriverenergy.com/long-duration-battery-project-in-the-works/


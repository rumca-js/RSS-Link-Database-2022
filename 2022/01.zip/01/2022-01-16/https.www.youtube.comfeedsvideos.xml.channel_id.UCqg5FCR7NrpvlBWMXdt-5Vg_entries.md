# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Your Favorite Game Franchises Should Be Allowed to Die | The Takeaway
 - [https://www.youtube.com/watch?v=DlgDAtQb0cU](https://www.youtube.com/watch?v=DlgDAtQb0cU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-01-17 00:00:00+00:00

Last year we got our seventh mainline Halo title with Infinite, our eighth (tenth?) Resident Evil with Village, and the 12th mainline Assassin’s Creed game with Valhalla. Without even counting the numerous spin-offs, prequels, and remakes, that’s a lot of games dedicated to a mostly continuous story or series of events. Each of these franchises has celebrated amazing highs and embarrassing lows and even worked to reinvent itself in some ways to stay relevant to the shifting tastes of the player base. But what if the developers had just let their game franchises die?

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Does Resurrections Bring the Matrix Back to Life? | Your Feature Presentation
 - [https://www.youtube.com/watch?v=E_qh74ielFg](https://www.youtube.com/watch?v=E_qh74ielFg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-01-16 00:00:00+00:00

This week on Your Feature Presentation, Jack and Darren do a deep dive on their thoughts on Matrix Resurrections, Jack won't watch Boba Fett and Marty joins Darren for a surprise episode of Escape the Galaxy to discuss their in-depth thoughts on the Book of Boba Fett so far.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---
Timestamps
0:00 - Intro
1:37 - The Matrix Resurrections
17:18 - Jack won't watch Boba Fett
24:00 - The Book of Boba Fett Episodes 1 & 2


---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Aktualizacja bezpieczeństwa: Signal, LastPass, Telegram, Pegasus, Teams/112, Facebook i NetUSB
 - [https://www.youtube.com/watch?v=-WjDjcu0iGQ](https://www.youtube.com/watch?v=-WjDjcu0iGQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2022-01-16 00:00:00+00:00

Cześć!

Mam dla Was aktualizację informacji w kilku tematach, o których rozmawialiśmy w ostatnich miesiącach. Informacje potrafią mieć datę przydatności do spożycia, szczególnie w świecie cyberbezpieczeństwa. Stąd szybki update z mojej strony.
Zapraszam!

Rozdziały:
00:00 Intro
00:29 Alibaba Cloud & 0day log4j
02:16 Patriotyczni szwajcarzy
03:12 Telegram i malware Purple Fox
03:46 Wyciek haseł master z LastPassa
05:32 Chiński rodowód Pegasusa
06:32 Unfollow Everything i ban
08:35 Android, Microsoft Teams, i zagubiona karetka
09:33 Zainfekowane klucze USB
10:13 Signal zmienia CEO
11:31 netusb, czyli podatności routerów ciąg dalszy
13:11 Co Robić i Jak Żyć?

Źródła:
🇨🇳 Nowe chińskie prawo dotyczące błędów, w tym zeroday, w oprogramowaniu
https://bit.ly/3frbsSi

🦥 Zawieszenie współpracy z Alibaba Group
https://bit.ly/3nvFw3F

🧀 Telepolis o szwajcarskim banie na komunikatory inne niż Threema
https://bit.ly/3fJmRxj

🎖️ Techdator o Threemie w szwajcarskiej armii
https://bit.ly/33CPcCC

🇨🇭 Szwajcarski portal SRF o Threemie w armii
https://bit.ly/3twRgac

🦊 Podstawiony Telegram i atak Purple Fox
https://bit.ly/3Id5bWZ i https://bit.ly/3A0E2DA

🌊 LastPass i rzekomy wyciek haseł master
https://bit.ly/3rlJ75z

❌ Ban na facebooka dla twórcy Unfollow Everything
https://bit.ly/3GNgbdr

🚅  Wtyczka unfollow everything dla chrome 
https://bit.ly/3FyUfB2

🔥🦊 Wtyczka news eradicator 
https://mzl.la/3FxeT4M

⚖️ Cease & Desist przesłany do Louisa Barclaya
https://bit.ly/3GJJA7W

📰 Artykuł na Slate autorstwa Louisa
https://bit.ly/3nwdntj

🕶 Nadchodzi Facebook Privacy Center
https://bit.ly/3rff3IQ

🚑 Microsoft Teams na Androidzie blokuje połączenia na numery alarmowe
https://bbc.in/3FsZhz3

⏏️ FIN7 i ataki poprzez wysyłane klucze USB
https://bit.ly/33FhI6h

❌ CEO Signala rezygnuje ze swojej funkcji
https://bit.ly/33kobUs

👨‍💼 Wpis na blogu CEO Signala 
https://bit.ly/3fy0E4Q

🔒 Szyfrowanie end-to-end a bezpieczeństwo publiczne
https://bit.ly/3I7Hpvl

💸 Bruce Schneier o wprowadzeniu kryptowaluty do Signala
https://bit.ly/3nu7EnW

👨‍💻 Blogpost Maxa van Amerongena, o CVE-2021-45608, czyli luce w netusb https://bit.ly/3rktcV1

Relevant xkcd: https://xkcd.com/1996/

© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.

Dziękuję za Waszą uwagę. ❤️

Znajdziecie mnie również na;
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/
Podcasty na Anchor https://anchor.fm/mateusz-chrobok
Podcasty na Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR
Podcast na  Apple Podcasts https://podcasts.apple.com/us/podcast/mateusz-chrobok-bezpiecze%C5%84stwo-startupy-i-sztuczna-inteligencja/id1617335932 
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok

Dziękuję za gościnę showroomowi CustomForm w Chorzowie!


# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Wstęp do NFT
 - [https://www.youtube.com/watch?v=XCMIMzs_i2M](https://www.youtube.com/watch?v=XCMIMzs_i2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-01-16 00:00:00+00:00

O co chodzi z małpami, misiami i innymi niewymienialnymi tokenami?
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

Rozdziały:
00:00 Wstęp
00:06 Co to jest NFT?
00:25 Wymienialne i niewymienialne instrumenty finansowe
01:28 Niepodrabialność NFT
02:28 Kopie NFT a ich niepodrabialność
03:00 Systemy weryfikujące właściciela NFT
03:26 Polska kolekcja NFT Fancy Bears i Bored Ape Yacht Club NFT z USA
04:03 Po co ludzi kupują NFT?
05:07 Do czego służy i co NFT?
05:44 Kryptowalutowy scam
06:17 Gratisy dla właścicieli NFT
07:00 Jaka zostać sąsiadem Snoop Dogga?
07:22 Społeczność NFT – Klub
08:17 Modele inwestycyjne
09:28 Problem z NFT a powiązanie go z twórcą
10:55 Warunki ważne przy zakupie NFT
11:52 Jak kupić NFT przez OpenSea?
12:25 „Wagony” NFT
12:44 Wirtualne parcele
12:55 Historia obrotu NFT
13:23 Jaka jest przyszłość NFT?
14:02 Porównanie sprzedaży NFT do kryptowalut
14:17 Sterowanie wartością firmy
14:48 NFT – manipulacja wartością NFT
15:15 Opinia
15:23 Krytyka NFT – duże zużycie energii, zanieczyszczenie planety
15:55 Oryginał i kopie w świecie rzeczywistym i wirtualnym
16:39 W opozycji do NFT/Podsumowanie
17:08 Zakończenie


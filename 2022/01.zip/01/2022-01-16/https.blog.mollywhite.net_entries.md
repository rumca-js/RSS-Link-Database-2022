## It's not still the early days
 - [https://blog.mollywhite.net/its-not-still-the-early-days/](https://blog.mollywhite.net/its-not-still-the-early-days/)
 - RSS feed: https://blog.mollywhite.net
 - date published: 2022-01-16 10:43:18.528880+00:00

When I speak about the inefficiency of popular blockchains, or mention that we seem to be hurtling towards a 


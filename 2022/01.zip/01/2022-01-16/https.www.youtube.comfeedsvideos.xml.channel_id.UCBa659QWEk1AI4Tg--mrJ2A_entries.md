# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## There's a £100,000 coin buried under this London building
 - [https://www.youtube.com/watch?v=rssBd3fX8fw](https://www.youtube.com/watch?v=rssBd3fX8fw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-01-17 00:00:00+00:00

The 1933 British penny is one of the most famous coins in the world. I'm not saying this is definitely a heist movie waiting to happen... but I do think someone should write it. ■ Thanks to the team at Baldwin's, and the penny's owner, for letting me film it! https://www.baldwin.co.uk/

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


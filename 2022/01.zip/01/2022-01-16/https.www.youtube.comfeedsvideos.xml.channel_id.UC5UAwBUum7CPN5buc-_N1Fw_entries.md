# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## FOSS dev SABOTAGED their libraries, EAC isn't so easy, Humble Bundle disappoints - Linux News Jan.
 - [https://www.youtube.com/watch?v=nQkF4GsjoyI](https://www.youtube.com/watch?v=nQkF4GsjoyI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-01-16 00:00:00+00:00

Subscribe to Extended Lifecycle Support Services for EOL Linux by TuxCare: https://tuxcare.org/eol-linux-support

Get your Linux desktop or laptop here: https://slimbook.es/en/


👏 SUPPORT THE CHANNEL:
Get access to an exclusive weekly podcast, vote on the next topics I cover, and get your name in the credits:

YOUTUBE: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join

Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

🏆 FOLLOW ME ELSEWHERE:
I also do a Gaming Podcast: https://www.youtube.com/channel/UCbRPZ11S1quJ4ESoj42A3ug

Join us on our new Discord server: https://discord.gg/xK7ukavWmQ

Twitter : http://twitter.com/thelinuxEXP

My Gaming on Linux Channel: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw

📷 GEAR I USE:
Sony Alpha A6600 Mirrorless Camera: https://amzn.to/30zKyn7
Sigma 56mm Fixed Prime Lens: https://amzn.to/3aRvK5l
Logitech MX Master 3 Mouse: https://amzn.to/3BVI0Od
Bluetooth Space Grey Mac Keyboard: https://amzn.to/3jcJETZ
Logitech Brio 4K Webcam: https://amzn.to/3jgeTh9
LG Curved Ultrawide Monitor: https://amzn.to/3pcTVDH
Logitech White Speakers: https://amzn.to/3n6wSb0
Xbox Controller: https://amzn.to/3BWmIA3
*Amazon Links are affiliate codes and generate small commissions to support the channel*


00:00 Intro
00:36 Sponsor: Squeeze more life out of CentOS8
01:38 CENTOS8 Goes EOL
02:11 Canonical is hiring a desktop gaming manager
02:49 Linux Mint 20.3 is now out
03:41 Linux Kernel 5.16
04:23 Linux Mint reaches deal with Mozilla for Firefox
05:08 KDE Roadmap
06:06 FOSS Dev sabotages their own libraries
07:07 Pinta 2.0 Released
07:49 Heroic Games Launcher 2.0
08:31 Firefox 96 Released
09:06 System 76 Announces their new Kudu laptop
09:45 Dell XPS 13 Plus
10:24 PinePhone Pro available for pre-order
11:00 EAC isn't so easy after all
11:49 DXVK 1.9.3
12:27 Humble Choice loses Linux
13:20 Get a new Linux device
13:48 Support the channel

CentOS 8  has now finally reached end of life
https://www.centos.org/centos-linux-eol/

Canonical is hiring a desktop gaming product manager.
https://canonical.com/careers/3776036

Linux Mint 20.3 is now out
https://www.linuxmint.com/rel_una_cinnamon_whatsnew.php

The Linux Kernel version 5.16 is now out
https://www.omgubuntu.co.uk/2022/01/new-features-in-linux-kernel-5-16-release

Mint Lead Clement Lefebvre announces that Mint will now ship a vanilla implementation of Firefox, without any of the Mint customizations
https://www.omgubuntu.co.uk/2022/01/linux-mint-announces-new-partnership-with-mozilla

Nate Graham published a roadmap for KDE in 2022. 
https://pointieststick.com/2022/01/03/kde-roadmap-for-2022/

The developer of the very popular NPM libraries colors and faker has intentionally sabotaged them because they were tired of seeing their work being used by giant companies
https://www.bleepingcomputer.com/news/security/dev-corrupts-npm-libs-colors-and-faker-breaking-thousands-of-apps/


Pinta has a new release out
https://www.omgubuntu.co.uk/2022/01/pinta-2-0-released-completes-port-to-gtk3-net-6

The Heroic Games Launcher also moved to version 2.0!
https://www.gamingonlinux.com/2022/01/heroic-games-launcher-200-brings-a-much-improved-login-system-for-epic-games/

Firefox 96 is now outhttps://www.mozilla.org/en-US/firefox/96.0/releasenotes/

System 76 has announced their new Kudu laptop, which seems to be the most powerful laptop they'll have in their lineup.
https://system76.com/laptops/kudu


More laptops, with the brand new Dell XPS 13 Plus
https://thenextweb.com/news/dells-new-xps-13-plus-makes-weird-design-choices-in-the-name-of-power

The PinePhone Pro is now available for preorder, in its Explorer Edition
https://www.omgubuntu.co.uk/2022/01/pinephone-pro-available-to-pre-order

Turns out Easy Anti Cheat proton support isn't as simple to implement as we originally thought. 
https://www.gamingonlinux.com/2022/01/easy-anti-cheat-not-as-simple-as-expected-for-proton-and-steam-deck/

DXVK has a new release out, version 1.9.3.
https://github.com/doitsujin/dxvk/releases/tag/v1.9.3

Sad news to conclude, as Humble Choice, their subscription service, is dropping Mac os and Linux support at the beginning of February.
https://arstechnica.com/gaming/2022/01/humble-subscription-service-is-dumping-mac-linux-access-in-18-days/


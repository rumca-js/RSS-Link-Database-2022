# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## Italian nurse caught on video allegedly administering fake vaccine
 - [https://www.cnn.com/videos/world/2022/01/16/nurse-arrested-after-injecting-fake-vaccine-jc-orig.cnn](https://www.cnn.com/videos/world/2022/01/16/nurse-arrested-after-injecting-fake-vaccine-jc-orig.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-16 22:19:51+00:00

An Italian nurse was caught on camera allegedly giving a fake dose of the Covid-19 vaccine to a couple in Palermo.

## 'Sick to my stomach': Dollar Tree fanatics protest new $1.25 prices
 - [https://www.cnn.com/2022/01/14/business/dollar-tree-new-prices/index.html](https://www.cnn.com/2022/01/14/business/dollar-tree-new-prices/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-16 20:23:25+00:00

"I am not happy!"

## Tapper reveals the reason Trump went to Arizona
 - [https://www.cnn.com/videos/politics/2022/01/16/voting-rights-counting-mlk-donald-trump-january-6-tapper-sotu-vpx.cnn](https://www.cnn.com/videos/politics/2022/01/16/voting-rights-counting-mlk-donald-trump-january-6-tapper-sotu-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-16 16:04:00+00:00

Jake Tapper looks at former President Donald Trump's continued efforts to restrict voting rights in states across the nation on the weekend the country remembers civil rights icon Dr. Martin Luther King Jr.

## Former Miss Universe asked to 'cover-up' before boarding flight, sister says
 - [https://www.cnn.com/videos/us/2022/01/15/olivia-culpo-american-airlines-orig-jc.cnn](https://www.cnn.com/videos/us/2022/01/15/olivia-culpo-american-airlines-orig-jc.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2022-01-16 12:47:05+00:00

The former Miss Universe was asked to change into a more appropriate outfit before boarding an American Airlines flight to Cabo, according to her sister, who documented the incident on Instagram.


# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The 355 - The First Flop Of 2022
 - [https://www.youtube.com/watch?v=TgQlvuiwMoQ](https://www.youtube.com/watch?v=TgQlvuiwMoQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2022-01-17 00:00:00+00:00

I watch it so you don't have to. The 355 has the dubious honour of being the first major flop of the year, and after seeing it, I can understand why. Join me as I break down the disaster that is The 355.

Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker


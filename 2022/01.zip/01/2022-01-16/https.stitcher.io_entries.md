## "It's your fault" - stitcher.io
 - [https://stitcher.io/blog/its-your-fault](https://stitcher.io/blog/its-your-fault)
 - RSS feed: https://stitcher.io
 - date published: 2022-01-16 08:46:51.803771+00:00

My personal thoughts on the web and programming.


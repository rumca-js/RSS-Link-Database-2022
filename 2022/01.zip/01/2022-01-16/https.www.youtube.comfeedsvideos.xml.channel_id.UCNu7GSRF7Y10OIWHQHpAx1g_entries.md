# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Kubańskie graty feat. @Zlomnik_official
 - [https://www.youtube.com/watch?v=jIQBl4x2th4](https://www.youtube.com/watch?v=jIQBl4x2th4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2022-01-16 00:00:00+00:00

Złomnik: @Zlomnik_official
Tu możecie kupić książkę "Kuba - wyspa gratów": https://sklep.zlomnik.pl

Film o Daihatsu: https://www.youtube.com/watch?v=hwW4NVqNTzE
Film o Mazdzie MPV: https://www.youtube.com/watch?v=wrufDypXhiQ
Clarkson niszczy Poloneza: https://www.youtube.com/watch?v=UmFywTwKDZs

Vlogi z Kuby chronologicznie BezPlanu & Vlog Casha: 
https://youtube.com/playlist?list=PLxvi52O0l5Y2JFYHV17f28uBAi64GkbFt

Instagram: http://instagram.com/bezplanu_czukesky 
Facebook: https://www.facebook.com/BezPlanu.tv
Wsparcie na Patronite: http://bit.ly/2KsFTZk 

Sklep: https://bezplanu.com

Wszystkie odcinki BezPlanu chronologicznie: http://bit.ly/2MqAO7Q
(można też klikać w kartę "Następny odcinek" pojawiającą się pod koniec każdego filmu po prawej stronie u góry)

BezPlanu Daily: https://www.youtube.com/channel/UCHXOfJP9fwMNXWGFKstju_w

Czas akcji: styczeń 2022r.


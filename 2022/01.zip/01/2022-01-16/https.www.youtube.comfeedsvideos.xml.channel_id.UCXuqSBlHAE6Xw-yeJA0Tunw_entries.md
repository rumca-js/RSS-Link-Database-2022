# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I was FORCED to buy a Chromebook….
 - [https://www.youtube.com/watch?v=RXvzM9PPEAc](https://www.youtube.com/watch?v=RXvzM9PPEAc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-17 00:00:00+00:00

Thank you to Wealthfront for sponsoring this video! Use my link https://www.wealthfront.com/linus to open a Wealthfront investment account and get $5K managed for free. 

Get your Cablemod Keyboard cables today at: https://lmg.gg/CablemodKB 

My son needs a Chromebook for school so I began my search to find the best bang for the buck Chromebook...and of course, we tried to game on it.

Take a look at the available Chromebooks below:
  Amazon: https://geni.us/jj8ruZ
  Best Buy: https://geni.us/BF9Jru
  Newegg: https://geni.us/OCdFABC

Purchases made through some store links may provide some compensation to Linus Media Group.

Crouton Github: https://github.com/dnschneid/crouton

Installing Steam on Linux Beta: https://www.linuxmadesimple.info/2021/01/how-to-install-steam-on-chromebook-in.html

Chromebook Automatic Update Support Page: https://support.google.com/chrome/a/answer/6220366?hl=en

Discuss on the forum: https://linustechtips.com/topic/1404634-i-was-forced-to-buy-a-chromebook%E2%80%A6/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
0:44 Chromebook Penetration
1:16 are Chromebooks bad?
2:01 look how cheap they are!
2:40 Linus goes shopping!
4:10 better luck online?
6:18 IMPORTANT TECH TIP
7:30 Gaming on Chromebooks
11:14 Why did you Cheap Out??
12:58 Outro

LinusTechTips receives cash compensation from Wealthfront Advisers LLC (“Wealthfront Advisers”) for sponsored advertising materials. LinusTechTips is not a client and this is a paid endorsement. LinusTechTips and Wealthfront Advisers are not associated with one another and have no formal relationship outside of this arrangement. Nothing in this communication should be construed as a solicitation, offer, or recommendation, to buy or sell any security. Any links provided by LinusTechTips are not intended to imply that Wealthfront Advisers or its affiliates endorses, sponsors, promotes and/or is affiliated with the owners of or participants in those sites, or endorses any information contained on those sites, unless expressly stated otherwise. Investment management and advisory services are provided by Wealthfront, an SEC registered investment adviser. All investing involves risk, including the possible loss of money you invest, and past performance does not guarantee future performance.

## Why is EVERYONE Buying This Gaming Mouse? - Logitech G502 HERO
 - [https://www.youtube.com/watch?v=Iek-UH9ZWUw](https://www.youtube.com/watch?v=Iek-UH9ZWUw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-01-16 00:00:00+00:00

Get 50% off your Zoho CRM annual subscription with code ZCRM50 at: https://lmg.gg/ZohoCRM

Use code LINUS at https://pebblehost.com/dedicated for 30% off your first month, available for the first 100 people who sign up for dedicated server hosting.

What's so good about the G502 Hero that it has almost thirty thousand ratings on Amazon with a 4.7 star rating? Let's take a look in the latest edition of Why Is Everyone Buying THIS?!

Buy Logitech G502 HERO
On Best Buy: https://geni.us/GtfZnXf
On Amazon: https://geni.us/MZQUL
On Newegg: https://geni.us/kwerrsP

Buy Logitech MX Master 3
On Best Buy: https://geni.us/fsBBNq3
On Amazon: https://geni.us/ZNS0tcU
On Newegg: https://geni.us/Pquil

Buy Razer Basilisk X Hyperspeed WIRELESS 
On Best Buy: https://geni.us/k7fn
On Amazon: https://geni.us/ANqdA

Buy Corsair Nightsword RGB
On Best Buy: https://geni.us/ZrmgKYg
On Amazon: https://geni.us/BjMj
On Newegg: https://geni.us/BjMj

Buy Razer DeathAdder Essential
On Amazon: https://geni.us/cALQ
On Best Buy: https://geni.us/7BJsI
On Newegg: https://geni.us/azJDJpU

Buy Razer Viper Mini Ultralight
On Amazon: https://geni.us/Twg6R
On Best Buy: https://geni.us/gXItCLX
On Newegg: https://geni.us/mmv0S

Buy Redragon M801
On Amazon: https://geni.us/aDvi
On Newegg: https://geni.us/3RHFc

Buy EVGA X15 MMO
On Amazon: https://geni.us/ZPSrDN1
On Newegg: https://geni.us/619VQC

Buy SteelSeries Rival 3
On Amazon: https://geni.us/DOwAbc
On Best Buy: https://geni.us/B6C51Y
On Newegg: https://geni.us/f2XhOu

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1404362-why-is-everyone-buying-this-gaming-mouse/

► GET MERCH: https://lttstore.com
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------  
0:00 Intro
1:13 The Beginning
3:10 A Hero Is Born
5:13 Complaints
6:40 The Double Click
7:41 The Price
9:15 Alternatives
10:23 Conclusion
11:59 Outro


# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Krwawy Księżyc na Waszych zdjęciach. "Robi wrażenie"
 - [https://tvn24.pl/tvnmeteo/ciekawostki/krwawa-pelnia-w-pazdzierniku-koniunkcja-jowisza-i-ksiezyca-6151655?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/krwawa-pelnia-w-pazdzierniku-koniunkcja-jowisza-i-ksiezyca-6151655?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2022-10-07 09:17:22+00:00

<img alt="Krwawy Księżyc na Waszych zdjęciach. " src="https://tvn24.pl/tvnmeteo/ciekawostki/cdn-zdjecie-irwkt7-20221009205804jpg/alternates/LANDSCAPE_1280" />
    W nocy z niedzieli na poniedziałek mogliśmy podziwiać na niebie październikową pełnię nazywaną Krwawym Księżycem lub Księżycem Myśliwych. Na Kontakt 24 otrzymaliśmy zdjęcia okazale wyglądającego Srebrnego Globu.


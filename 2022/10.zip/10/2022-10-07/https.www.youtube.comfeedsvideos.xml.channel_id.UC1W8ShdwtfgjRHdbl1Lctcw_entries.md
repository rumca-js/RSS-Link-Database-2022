# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## A Day in London 1930s in color [60fps,Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=A-jb8ydfsqw](https://www.youtube.com/watch?v=A-jb8ydfsqw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2022-10-07 00:00:00+00:00

I colorized, restored and created a sound design for this video of Wonderful London 1930s, we can clearly see what is happening in broad daylight, a various shots of Trafalgar Square and various shots of Picadilly Circus and awesome train shots .

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance (not historically accurate)
✔added sound only for the ambiance
✔restoration:(stabilisation,denoise,cleand,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

B&W Video Source from: Internet Archive
B&W Video Source:https://archive.org/details/pet1136r5
B&W Video Source:https://archive.org/details/pet1138r5alondon

Rights to the black and white Video Source are held by Internet Archive. under the Creative Commons Attribution License


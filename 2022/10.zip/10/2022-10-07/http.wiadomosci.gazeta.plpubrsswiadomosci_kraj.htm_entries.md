# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Istebna. 69-latek zgubił się na grzybach. Wyszedł w środę, odnalazł się dopiero w piątek
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28999358,istebna-69-latek-zgubil-sie-na-grzybach-wyszedl-w-srode-odnalazl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28999358,istebna-69-latek-zgubil-sie-na-grzybach-wyszedl-w-srode-odnalazl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 19:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d7/a7/1b/z28999383M,Zdjecie-ilustracyjne.jpg" vspace="2" />Szczęśliwie zakończyły się w piątek poszukiwania 69-latka z Istebnej, który w środę wyszedł na grzyby do lasu. Mężczyzna odnalazł się niedaleko od domu. Wcześniej przez kilkadziesiąt godzin krążył po lesie, a w jego poszukiwania byli zaangażowani m.in. GOPR, policja i straż pożarna.

## Wysokoenergetyczny wstrząs w kopalni Ruch Rydułtowy. "Nikt nie odniósł obrażeń"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28999181,wysokoenergetyczny-wstrzas-w-kopalni-ruch-rydultowy-nikt-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28999181,wysokoenergetyczny-wstrzas-w-kopalni-ruch-rydultowy-nikt-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 17:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/71/42/1a/z27534705M,Kopalnia-Rydultowy--zdjecie-ilustracyjne-.jpg" vspace="2" />W piątek po godzinie 17 doszło do silnego, wysokoenergetycznego wstrząsu w kopalni Ruch Rydułtowy. W rozmowie z Radiem 90 rzecznik Polskiej Grupy Górniczej Tomasz Głogowski poinformował, że w wyniku wstrząsu nikt nie został poszkodowany. Trwa analiza pomiarów, która pozwoli oszacować, jak silne było zjawisko.

## Kalisz. Zarzuty dla byłej dyrektorki szkoły. Podsłuchy na korytarzach i w gabinetach, oszustwa finansowe
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28999182,kalisz-zarzuty-dla-bylej-dyrektorki-szkoly-podsluchy-na-korytarzach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28999182,kalisz-zarzuty-dla-bylej-dyrektorki-szkoly-podsluchy-na-korytarzach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 17:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/30/a7/1b/z28999216M,Zdjecie-ilustracyjne.jpg" vspace="2" />Była dyrektorka jednej z kaliskich szkół usłyszała sześć prokuratorskich zarzutów. Kobieta miała m.in. zainstalować w placówce kilkanaście podsłuchów i dokonać oszustw finansowych na szkodę miasta. Jak podaje Pulshr.pl na podstawie doniesień PAP, była dyrektorka placówki nie przyznała się do winy.

## Podkarpacie. Parafianie przyjechali po proboszcza taczkami. "Żądamy natychmiastowej zmiany"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28998937,podkarpacie-parafianie-przyjechali-po-proboszcza-taczkami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28998937,podkarpacie-parafianie-przyjechali-po-proboszcza-taczkami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 16:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0f/69/1b/z28745487M,Ksiadz--zdjecie-ilustracyjne-.jpg" vspace="2" />Parafianie z Zasowa są źli na nowego proboszcza, który podejmuje decyzje bez konsultacji z nimi. Zorganizowali więc protest - były transparenty, taczki, a na ręce biskupa złożyli petycję, w której zażądali odwołania duchownego ze sprawowanej funkcji. Postawili też ultimatum.

## Tragedia w Tatrach. Turysta zginął po upadku z dużej wysokości
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28999016,tragedia-w-tatrach-turysta-zginal-po-upadku-z-duzej-wysokosci.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28999016,tragedia-w-tatrach-turysta-zginal-po-upadku-z-duzej-wysokosci.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 15:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/81/a7/1b/z28999041M,Tatry--Zdjecie-ilustracyjne.jpg" vspace="2" />Z rejonu Przełęczy Krzyżne wraz ze zsuwem śnieżnym na stronę Doliny Roztoki spadł turysta. Jak przekazał w rozmowie z Informacyjną Agencją Radiową Tomasz Wojciechowski, ratownik dyżurny TOPR, mężczyzna poniósł śmierć na miejscu.

## 29-latek wtargnął na posesję, zmarł po szarpaninie z domownikami. Ziobro: Mieli pełne prawo do obrony
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28998686,29-latek-wtargnal-na-posesje-zmarl-po-szarpaninie-z-domownikami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28998686,29-latek-wtargnal-na-posesje-zmarl-po-szarpaninie-z-domownikami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 15:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ca/a7/1b/z28998858M,Zdjecie-ilustracyjne-.jpg" vspace="2" />- Zarzuty stawiane tej rodzinie nie były zasadne - tak o tragedii, do której doszło w ubiegłym tygodniu w Poznaniu, mówił w piątek prokurator generalny, minister sprawiedliwości Zbigniew Ziobro. Przypomnijmy: 29-letni Marcin U. wtargnął na jedną z posesji, doszło do szarpaniny z domownikami. Mężczyzna zmarł. Zarzuty postawiono trójce domowników - kobiecie, mężczyźnie i nastolatkowi

## Żona prezesa RIO w Krakowie oskarża go o przemoc. Pokazała nagrania. "Mógłbym cię przygnębić cały dzień"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28997190,zona-prezesa-rio-w-krakowie-oskarza-go-o-przemoc-pokazala-nagrania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28997190,zona-prezesa-rio-w-krakowie-oskarza-go-o-przemoc-pokazala-nagrania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 12:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/66/1b/z28730914M,Policja-zdjecie-ilustracyjne.jpg" vspace="2" />Dziennikarz Wirtualnej Polski Paweł Figurski opisał historię pani Doroty, żony prezesa Regionalnej Izby Obrachunkowej w Krakowie, która oskarża męża o przemoc domową. - Ja się nadal go boję, a od stycznia, gdy poinformowałam policję o zachowaniu męża, nie potrafię doprosić się decyzji o zakazie zbliżania się - przekazała kobieta. Jedno ze zgłoszeń, które wpłynęło na policję,

## Wielka Brytania. 14-letni Tomasz zmarł od dźgnięcia nożem. O morderstwo oskarżono jego rówieśnika
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28997060,wielka-brytania-14-letni-tomasz-zmarl-od-dzgniecia-nozem-o.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28997060,wielka-brytania-14-letni-tomasz-zmarl-od-dzgniecia-nozem-o.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 12:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e6/a7/1b/z28997350M,Wielka-Brytania--14-letni-Tomasz-zmarl-po-dzgnieci.jpg" vspace="2" />Tomasz zginął od ciosu nożem na początku października. Brytyjska prokuratura poinformowała w piątek, że oskarżonym w sprawie śmierci 14-latka jest jego rówieśnik.

## Mazowsze. Zamiast po Ubera zadzwonił na policję i zgłosił "wypadki". Słono zapłaci za kurs do aresztu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28997065,mazowsze-zamiast-po-ubera-zadzwonil-na-policje-i-zglosil-wypadki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28997065,mazowsze-zamiast-po-ubera-zadzwonil-na-policje-i-zglosil-wypadki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 11:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/24/9a/1b/z28945188M,Policja--Zdjecie-ilustracyjne-.jpg" vspace="2" />Policja z Rawy Mazowieckiej poinformowała o zdarzeniu, w którym 32-latek zawiadomił policję o dwóch nieistniejących wypadkach - wszystko po to, aby mundurowi podwieźli go na najbliższy przystanek. Zamiast tam zawieziono mężczyznę do aresztu, gdzie miał wytrzeźwieć. Za swoje żarty słono zapłaci.

## Bójka nastolatek w Brzozowie. Tłuką się nie na żarty, jak na ringu. Tłum uczniów kibicuje i nagrywa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28996476,bojka-nastolatek-w-brzozowie-jedna-z-dziewczat-uslyszala-zarzut.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28996476,bojka-nastolatek-w-brzozowie-jedna-z-dziewczat-uslyszala-zarzut.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 11:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a9/a7/1b/z28996777M,Bojka-nastolatek-w-Brzozowie--Jedna-z-dziewczat-us.jpg" vspace="2" />Bójka nastolatek w Brzozowie (woj. podkarpackie) wygląda wyjątkowo drastycznie. Wrażenie to potęguje tłum dzieciaków otaczający bijące się dziewczyny. Kibicują, nagrywają, nikt nie próbuje im przerwać. Jedna z dziewczyn miała użyć kastetu. Do bójki doszło 5 października na długiej przerwie. 17-latce prokuratura postawiła zarzut uszkodzenia ciała 15-latk

## Małopolska. Tysiące biedronek ninja w Zakopanem. Owad z Azji "uciekł spod kontroli", może też ukąsić
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28996889,malopolska-tysiace-biedronek-ninja-w-zakopanem-owad-z-azji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28996889,malopolska-tysiace-biedronek-ninja-w-zakopanem-owad-z-azji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 10:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0a/a7/1b/z28997130M,Biedronki-azjatyckie---jak-je-odroznic-.jpg" vspace="2" />W Zakopanem pojawiło się kilka tysięcy osobników biedronki azjatyckiej. Owad, zwany też arlekinem lub biedronką ninja, jest niebezpieczny dla rodzimych gatunków. Może też ukąsić człowieka, prowadząc do reakcji alergicznej.

## Gdzie są grzyby w październiku? Tu czekają najlepsze zbiory [RADAR GRZYBÓW]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28993271,gdzie-sa-grzyby-w-pazdzierniku-tu-czekaja-najlepsze-zbiory.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28993271,gdzie-sa-grzyby-w-pazdzierniku-tu-czekaja-najlepsze-zbiory.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 07:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/16/9b/1b/z28948246M,Gdzie-na-grzyby---MAPA-GRZYBOWA----zdjecie-ilustra.jpg" vspace="2" />Gdzie czeka nas najlepsze grzybobranie w październiku? Na jakie gatunki możemy liczyć w tym miesiącu? Podpowiadamy!

## Szokujące nagranie - migrant utknął na zaporze, wisiał głową w dół. Polscy strażnicy mieli szydzić: "Zaj....y jest"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28995517,szokujace-nagranie-z-granicy-migrant-utknal-na-zaporze-wisial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28995517,szokujace-nagranie-z-granicy-migrant-utknal-na-zaporze-wisial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 07:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/81/a7/1b/z28995713M,Szokujace-nagranie-z-granicy-polsko-bialoruskiej--.jpg" vspace="2" />Media społecznościowe obiegło wstrząsające nagranie z polsko-białoruskiej granicy w pobliżu Białowieży na Podlasiu. Widać na nim uchodźcę, który utknął na zaporze, wisi głową w dół. Po chwili spada z wysokości kilku metrów na ziemię. Zdarzenie w wulgarny sposób komentują polscy pogranicznicy (wskazuje na to zarówno ubiór mężczyzn, ich zachowanie, jak i 

## USA. Okulistka wyciągnęła 23 soczewki kontaktowe z oka pacjentki. Co rano zakładała nową parę [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28995557,usa-okulistka-wyciagnela-23-soczewki-kontaktowe-z-oka-pacjentki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28995557,usa-okulistka-wyciagnela-23-soczewki-kontaktowe-z-oka-pacjentki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 07:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d3/a7/1b/z28995795M,Okulistka-znalazla-23-soczewki-kontaktowe-w-oku-pa.jpg" vspace="2" />Pewna okulistka z Kalifornii spotkała się w swojej pracy z niezwykłym przypadkiem. W oku jednej ze swoich pacjentek znalazła aż 23 soczewki kontaktowe. Lekarka postanowiła nagrać proces ich usuwania.

## Wyciek danych żołnierzy służących na białoruskiej granicy. "Obawiamy się, że mogą nas namierzyć"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28995485,wyciek-danych-zolnierzy-sluzacych-na-bialoruskiej-granicy-obawiamy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28995485,wyciek-danych-zolnierzy-sluzacych-na-bialoruskiej-granicy-obawiamy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 06:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ab/71/19/z26677419M,Zolnierze-WOT--zdjecie-ilustracyjne-.jpg" vspace="2" />Doszło do wycieku wrażliwych danych osobowych polskich żołnierzy WOT służących na polsko-białoruskiej granicy - podaje Onet. Informacje miały zostać umieszczone na publicznym komunikatorze. - Obawiamy się, że służby białoruskie mogą nas namierzyć i skrzywdzić nas lub naszą rodzinę - cytuje wojskowych portal.

## Mama 4 plus nie dla każdej matki. Niejasne zasady. Wiele spraw kończy się w sądzie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28994956,mama-4-plus-nie-dla-kazdej-matki-niejasne-zasady-wiele-spraw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28994956,mama-4-plus-nie-dla-kazdej-matki-niejasne-zasady-wiele-spraw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 04:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/68/74/1b/z28789864M,Emerytka--zdjecie-ilustracyjne-.jpg" vspace="2" />Program Mama 4 plus pozwala na pobieranie emerytury kobietom, które życie zawodowe poświęciły na rzecz macierzyństwa. Świadczenie jednak nie trafia do wszystkich matek, które urodziły czworo, lub więcej dzieci. Kobiety po pieniądze idą do sądu.

## Mgły radiacyjne niemal w całej Polsce. Mogą ograniczyć widoczność do 100 metrów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28995174,mgly-radiacyjne-niemal-w-calej-polsce-moga-ograniczyc-widocznosc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28995174,mgly-radiacyjne-niemal-w-calej-polsce-moga-ograniczyc-widocznosc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 04:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/95/a6/1b/z28995221M,Mgla-radiacyjna---zdjecie-ilustracyjne.jpg" vspace="2" />W piątek 7 października w niemal całym kraju należy spodziewać się mgieł radiacyjnych. Jest to zawiesina, która rozwija się na skutek nocnego, radiacyjnego wypromieniowania ciepła.

## Kiedy zmiana czasu? Zegarki przestawimy o godzinę do przodu czy do tyłu?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28994278,kiedy-zmiana-czasu-zegarki-przestawimy-o-godzine-do-przodu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28994278,kiedy-zmiana-czasu-zegarki-przestawimy-o-godzine-do-przodu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-07 03:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ef/a6/1b/z28994287M,Zegarek--zdjecie-ilustracyjne-.jpg" vspace="2" />Zmiana czasu zbliża się wielkimi krokami. Już niebawem przestawimy swoje zegarki i przejdziemy z czasu letniego na zimowy. Wskazówki przesuniemy tym razem o godzinę do przodu czy do tyłu? Odpowiadamy.


# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## Windows Terminal NEW Features: v1.0  ⇨  v1.15
 - [https://www.youtube.com/watch?v=hA4rGwT0nC4](https://www.youtube.com/watch?v=hA4rGwT0nC4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2022-10-08 00:00:00+00:00

Did you know about these features?
My Previous Terminal Video: https://www.youtube.com/watch?v=9jQthJ2uvLI

⇒ Become a channel member for special emojis, early videos, and more! Check it out here: https://www.youtube.com/ThioJoe/join

Windows Terminal Update Blog Posts:
1.1: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-1-release/
1.2: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-2-release/
1.3: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-3-release/
1.4: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-4-release/
1.5: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-5-release/
1.6: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-6-release/
1.7: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-7-release/
1.8: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-8-release/
1.9: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-9-release/
1.10: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-10-release/
1.11: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-11-release/
1.12: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-12-release/
1.13: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-13-release/
1.14: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-14-release/
1.15: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-15-release/
1.16: https://devblogs.microsoft.com/commandline/windows-terminal-preview-1-16-release/

▼ Time Stamps: ▼
0:00 - Intro
0:40 - 1.1
1:13 - 1.2
1:28 - 1.3
2:06 - 1.4
2:21 - 1.5
2:42 - 1.6
3:47 - 1.7
4:59 - 1.8
5:43 - 1.9
6:45 - 1.10
6:53 - 1.11
7:17 - 1.12
7:34 - 1.13
8:18 - 1.14
9:01 - 1.15
9:43 - 1.16
10:26 - Final Thoughts

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬


# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Elayne & Mat First Look!👀 Malazan AI Cover Controversy?🤖 -FANTASY NEWS
 - [https://www.youtube.com/watch?v=5i8BfbpOXOw](https://www.youtube.com/watch?v=5i8BfbpOXOw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-10-07 00:00:00+00:00

Let's jump into the FANTASY NEWS! 
Check out Campfire today: https://tinyurl.com/bd4b4akj 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Merch: https://www.designbyhumans.com/shop/FantasyNews/ 

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lens: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231

NEWS: 
00:00 intro 

00:27 D&D prequel novels: https://gizmodo.com/dungeons-and-dragons-movie-prequel-novels-release-date-1849615170 

01:46 Sword of Kaigen: https://mlwangbooks.com/2022/10/06/the-sword-of-kaigen-is-getting-a-special-edition/ 

02:17 Folio Never Ending Story: https://www.youtube.com/watch?v=ub5aWc_R96g&ab_channel=TheFolioSociety 

03:22 Forge of the High Mage: https://thewertzone.blogspot.com/2022/10/ian-cameron-esslemonts-new-malazan.html 

07:51 Sponsor 

09:09 Mat and Elayne First Look: https://twitter.com/thewheeloftime/status/1578494216354791426?s=46&t=Ct8qgbhZYfFt_PycLiZAVg 

09:53 Dead Space remake: https://www.youtube.com/watch?v=cTDJNZ9cK1w&ab_channel=DeadSpace 

10:35 Dune Sisterhood: https://deadline.com/2022/10/dune-the-sisterhood-emily-watson-amp-shirley-henderson-hbo-max-series-1235135004/ 

11:41 Nosferatu Robert Eggers: https://deadline.com/2022/09/bill-skarsgard-lily-rose-depp-robert-eggers-nosferatu-focus-1235131507/

## WHEEL OF TIME ~BREAKDOWN~
 - [https://www.youtube.com/watch?v=EM5MGGmgLKE](https://www.youtube.com/watch?v=EM5MGGmgLKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-10-07 00:00:00+00:00

My breakdown for the #thewheeloftime ! 
New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene


Merch: https://www.designbyhumans.com/shop/FantasyNews/ 


Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p


Equipment: 
Camera: https://amzn.to/3siqgHv  
Lens: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  


P.O. Box: PO Box 7874 Henrico, VA 23231


# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Google doubles Pixel production
 - [https://www.youtube.com/watch?v=yvVrlIZi0eA](https://www.youtube.com/watch?v=yvVrlIZi0eA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2022-10-07 14:27:53+00:00

Get Nebula & Curiositystream at https://curiositystream.com/tfc for $15/year. Sponsored by CuriosityStream.

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► This video ◄◄◄  

This week the Google Pixel 7, Pixel 7 Pro and Google Pixel Watch were announced and the have great prices and availability, especially in Europe, YouTube tested making 4K playback a Premium feature, and the US thought about bannign sub-14nm chip tech to China.
 
Episode 117

This video on Nebula: https://nebula.tv/videos/tfc-google-doubles-production-expects-success

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► Product links ◄◄◄  

Links marked with * are affiliate links. Buying through these helps support my channel financially.

Pixel 7*: https://geni.us/PUBD4b
Pixel 7 Pro*: https://geni.us/iPcWGBu
Pixel Watch*: https://geni.us/pve3k
Pixel Buds Pro*: https://geni.us/K8nuKUs

Xiaomi Mi 12T:
 - DE/IT/ES *: https://geni.us/wgOR
 - Other regions: https://www.mi.com/global/product/xiaomi-12t-pro/
Redmi Pad: https://www.mi.com/global/product/redmi-pad/
Xiaomi Band 7 Pro: https://www.mi.com/global/product/xiaomi-smart-band-7-pro/

Steam Deck: https://www.steamdeck.com/en/

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► TechAltar links ◄◄◄  
 
Merch:  
http://enthusiast.store   
 
Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  
 
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 
►►► Attributions & Time stamps◄◄◄
 
Writing & Research: Tristan Rayner
Music by Edemski: https://soundcloud.com/edemski 
 
0:00 Intro
0:23 The Brief
3:50 Google Pixel - big news!
5:34 More US chip bans
3:11 5G overtakes 4G
6:48 YouTube Premium 4K


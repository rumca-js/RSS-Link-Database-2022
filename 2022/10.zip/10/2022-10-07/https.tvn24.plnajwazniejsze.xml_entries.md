# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## To z nią Iga Świątek zagra o finał w Ostrawie
 - [https://eurosport.tvn24.pl/to-z-ni--iga--wi-tek-zagra-o-fina--w-ostrawie,1120871.html?source=rss](https://eurosport.tvn24.pl/to-z-ni--iga--wi-tek-zagra-o-fina--w-ostrawie,1120871.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 21:09:00+00:00

<img alt="To z nią Iga Świątek zagra o finał w Ostrawie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sewe55-jekaterina-aleksandrowa-awansowala-do-polfinalu-w-ostrawie/alternates/LANDSCAPE_1280" />
    Polka zmierzy się z Rosjanką Jekatieriną Aleksandrową, która w ćwierćfinale pokonała Czeszkę Terezę Martincovą 6:1, 4:6, 6:1.

## Cudowne emocje i niesamowita wygrana Polek. Ćwierćfinał mistrzostw świata o krok
 - [https://eurosport.tvn24.pl/cudowne-emocje-i-niesamowita-wygrana-polek---wier-fina--mistrzostw--wiata-o-krok,1120852.html?source=rss](https://eurosport.tvn24.pl/cudowne-emocje-i-niesamowita-wygrana-polek---wier-fina--mistrzostw--wiata-o-krok,1120852.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 20:41:00+00:00

<img alt="Cudowne emocje i niesamowita wygrana Polek. Ćwierćfinał mistrzostw świata o krok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n9s35z-stysiak-miala-w-piatek-wielki-problem-ze-skutecznoscia/alternates/LANDSCAPE_1280" />
    Co to był za mecz!

## Kanadyjki wzięły się do pracy. Problemy Polek w drugim secie
 - [https://eurosport.tvn24.pl/polska---kanada-w-m--siatkarek--wynik-na--ywo-i-relacja,1120827.html?source=rss](https://eurosport.tvn24.pl/polska---kanada-w-m--siatkarek--wynik-na--ywo-i-relacja,1120827.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 19:30:00+00:00

<img alt="Kanadyjki wzięły się do pracy. Problemy Polek w drugim secie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qo0478-polki-licza-na-kolejne-zwyciestwo/alternates/LANDSCAPE_1280" />
    Relacja w eurosport.pl.

## W tym rankingu Lewandowski nie prowadzi
 - [https://eurosport.tvn24.pl/w-tym-rankingu-lewandowski-nie-prowadzi--pod-wzgl-dem-zarobk-w-s--od-niego-lepsi,1120839.html?source=rss](https://eurosport.tvn24.pl/w-tym-rankingu-lewandowski-nie-prowadzi--pod-wzgl-dem-zarobk-w-s--od-niego-lepsi,1120839.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 19:08:00+00:00

<img alt="W tym rankingu Lewandowski nie prowadzi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-49in25-robert-lewandowski/alternates/LANDSCAPE_1280" />
    Pod względem zarobków są od niego lepsi.

## "O co się troszczą? O księży pedofilów". Tajne kościelne dokumenty i prywatne rozmowy biskupa
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym---bielmo-odcinki,880782/odcinek-1824,S00E1824,882458?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym---bielmo-odcinki,880782/odcinek-1824,S00E1824,882458?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 19:02:22+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7zktkm-zachowaj-buffalo-w-tajemnicy-napis-obok-kosciola-6153068/alternates/LANDSCAPE_1280" />
    Ludzie, którzy przełamali zmowę milczenia, informowali Watykan i, jak twierdzą, osobiście papieża Jana Pawła II. Reportaż Marcina Gutowskiego.

## Pięć tysięcy dolarów miesięcznie za pracę, "której zwykli żołnierze nie chcą wykonywać"
 - [https://fakty.tvn24.pl/-morale-w-grupie-wagnera-jest-bardzo-niskie-,1120858.html?source=rss](https://fakty.tvn24.pl/-morale-w-grupie-wagnera-jest-bardzo-niskie-,1120858.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 18:14:57+00:00

<img alt="Pięć tysięcy dolarów miesięcznie za pracę, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-za1jqf-morale-w-grupie-wagnera-jest-bardzo-niskie-6153227/alternates/LANDSCAPE_1280" />
    Najpierw Rosja utrzymywała ją w tajemnicy, potem wykorzystywała jej bezwzględną i brutalną reputację.

## Szef norweskich szachów przyznał się do oszustwa
 - [https://eurosport.tvn24.pl/szef-norweskich-szach-w-przyzna--si--do-oszustwa---jestem-tego--wiadomy-,1120803.html?source=rss](https://eurosport.tvn24.pl/szef-norweskich-szach-w-przyzna--si--do-oszustwa---jestem-tego--wiadomy-,1120803.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 17:20:00+00:00

<img alt="Szef norweskich szachów przyznał się do oszustwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-smqmm7-to-juz-kolejne-oszustwo-na-szachownicy-w-ostatnim-czasie/alternates/LANDSCAPE_1280" />
    "Jestem tego świadomy".

## "Największy wyciek, jaki kiedykolwiek zarejestrowano" na Bałtyku. Ekipa "Faktów" w misji z naukowcami
 - [https://fakty.tvn24.pl/-to-najwi-kszy-wyciek--jaki-kiedykolwiek-zarejestrowano---ekipa--fakt-w--tvn-towarzyszy-a-naukowcom-w-niebezpiecznej-misji,1120844.html?source=rss](https://fakty.tvn24.pl/-to-najwi-kszy-wyciek--jaki-kiedykolwiek-zarejestrowano---ekipa--fakt-w--tvn-towarzyszy-a-naukowcom-w-niebezpiecznej-misji,1120844.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 17:08:10+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v89cid-0710--to-najwiekszy-wyciek-jaki-kiedykolwiek-zarejestrowano-ekipa-faktow-tvn-towarzyszyla-naukowcom-w-niebezpiecznej-misji/alternates/LANDSCAPE_1280" />
    Czy Bałtyk jest bezpieczny i jak groźne mogą być konsekwencje wycieków z gazociągów Nord Stream 1 i Nord Stream 2?

## Świątek wyciągnęła wnioski z dawnej porażki z McNally
 - [https://eurosport.tvn24.pl/-wi-tek-wyci-gn--a-wnioski-z-dawnej-pora-ki-z-mcnally---ju--nigdy-w--yciu-nie-pope-ni-am-tego-b--du-,1120830.html?source=rss](https://eurosport.tvn24.pl/-wi-tek-wyci-gn--a-wnioski-z-dawnej-pora-ki-z-mcnally---ju--nigdy-w--yciu-nie-pope-ni-am-tego-b--du-,1120830.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 16:59:16+00:00

<img alt="Świątek wyciągnęła wnioski z dawnej porażki z McNally" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0iemyk-iga-swiatek-6152926/alternates/LANDSCAPE_1280" />
    - Już nigdy w życiu nie popełniłam tego błędu - powiedziała Polka po piątkowym meczu w Ostrawie.

## Świątek wyszarpała półfinał w Ostrawie
 - [https://eurosport.tvn24.pl/-wi-tek-wyszarpa-a-p--fina--w-ostrawie--ni-ej-notowana-rywalka-postawi-a-si--faworytce,1120816.html?source=rss](https://eurosport.tvn24.pl/-wi-tek-wyszarpa-a-p--fina--w-ostrawie--ni-ej-notowana-rywalka-postawi-a-si--faworytce,1120816.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 16:12:00+00:00

<img alt="Świątek wyszarpała półfinał w Ostrawie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e3znta-iga-swiatek-walczy-o-11-tytul-w-karierze/alternates/LANDSCAPE_1280" />
    Niżej notowana rywalka postawiła się faworytce.

## Gortat przypomniał o wojnie i dał jasny przekaz koszykarzom. "Musisz coś zrozumieć, człowieku..."
 - [https://eurosport.tvn24.pl/gortat-przypomnia--o-wojnie-i-da--jasny-przekaz-koszykarzom---musisz-co--zrozumie---cz-owieku----,1120814.html?source=rss](https://eurosport.tvn24.pl/gortat-przypomnia--o-wojnie-i-da--jasny-przekaz-koszykarzom---musisz-co--zrozumie---cz-owieku----,1120814.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 15:18:00+00:00

<img alt="Gortat przypomniał o wojnie i dał jasny przekaz koszykarzom. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tcxwug-marcin-gortat/alternates/LANDSCAPE_1280" />
    Marcin Gortat nie zapomina o Ukrainie. Były koszykarz NBA próbuje wspierać ten kraj na każdym kroku, także słowem. Podczas jednej z rozmów z dziennikarzami zwrócił uwagę, że zawodnicy aktualnie występujący w najlepszej koszykarskiej lidze nie powinni na nic narzekać, bo są w zupełnie innej sytuacji, niż Ukraińcy.

## Chmura metanu po wyciekach. Kamera "Faktów" ze specjalistami nad Bałtykiem
 - [https://fakty.tvn24.pl/chmura-metanu-po-wyciekach--kamera--fakt-w--ze-specjalistami-nad-ba-tykiem,1120811.html?source=rss](https://fakty.tvn24.pl/chmura-metanu-po-wyciekach--kamera--fakt-w--ze-specjalistami-nad-ba-tykiem,1120811.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 15:00:00+00:00

<img alt="Chmura metanu po wyciekach. Kamera " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jiai5c-chmura-metanu-nad-baltykiem-niemieccy-specjalisci-sprawdzaja-gdzie-sie-znajduje/alternates/LANDSCAPE_1280" />
    Relacja Wojciecha Bojanowskiego dziś o 19:00 w TVN.

## PiS chce obnażyć hipokryzję opozycji w sprawie węgla. I manipuluje w spocie
 - [https://konkret24.tvn24.pl/r/pis-chce-obna-y--hipokryzj--opozycji-w-sprawie-w-gla--i-manipuluje-w-spocie,1120790.html?source=rss](https://konkret24.tvn24.pl/r/pis-chce-obna-y--hipokryzj--opozycji-w-sprawie-w-gla--i-manipuluje-w-spocie,1120790.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 14:53:04+00:00

<img alt="PiS chce obnażyć hipokryzję opozycji w sprawie węgla. I manipuluje w spocie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zmc0fa-untitled-1-6152732/alternates/LANDSCAPE_1280" />
    Wyjaśnia Konkret24.

## Jerzy Skolimowski: człowiek jest zły, w zwierzętach nie dostrzega żywych istot
 - [https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-26,S00E26,881598?source=rss](https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-26,S00E26,881598?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 14:35:57+00:00

<img alt="Jerzy Skolimowski: człowiek jest zły, w zwierzętach nie dostrzega żywych istot" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qbknoh-monika-olejnik-i-jerzy-skolimowski-6152699/alternates/LANDSCAPE_1280" />
    Szczerze, momentami wręcz gorzko, podsumowuje swoją karierę i życie.

## Iga Świątek gra o półfinał w Ostrawie
 - [https://eurosport.tvn24.pl/iga--wi-tek---caty-mcnally---wier-fina--w-ostrawie-na--ywo,1120784.html?source=rss](https://eurosport.tvn24.pl/iga--wi-tek---caty-mcnally---wier-fina--w-ostrawie-na--ywo,1120784.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 14:16:00+00:00

<img alt="Iga Świątek gra o półfinał w Ostrawie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j8ehy6-iga-swiatek-walczy-w-ostrawie/alternates/LANDSCAPE_1280" />
    Wynik meczu i relacja na żywo w eurosport.pl.

## Jak CBA zgubiło milion złotych
 - [https://tvn24.pl/go/programy,7/superwizjer-odcinki,10894/odcinek-1026,S00E1026,882442?source=rss](https://tvn24.pl/go/programy,7/superwizjer-odcinki,10894/odcinek-1026,S00E1026,882442?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 14:05:22+00:00

<img alt="Jak CBA zgubiło milion złotych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qnv9b7-cba-superwizjer-6152648/alternates/LANDSCAPE_1280" />
    To jedna z najbardziej nieudanych operacji specjalnych, jaką przeprowadziło Centralne Biuro Antykorupcyjne.

## Na wojnie przeszedł piekło. "Jednemu z chłopaków prasowali ręce żelazkiem, a mi rozbili głowę rurą"
 - [https://tvn24.pl/go/programy,7/polska-i-swiat-odcinki,10854/odcinek-2300,S00E2300,882439?source=rss](https://tvn24.pl/go/programy,7/polska-i-swiat-odcinki,10854/odcinek-2300,S00E2300,882439?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 12:39:43+00:00

<img alt="Na wojnie przeszedł piekło. " ch="ch" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g34ddo-kadr-z-filmu-syndrom-hamleta-6152377/alternates/LANDSCAPE_1280" />
    Rozmowa Piotra Jeziorowskiego z reżyserką i jednym z bohaterów filmu "Syndrom Hamleta".

## Polki mogą awansować do ćwierćfinału już w piątek. Co się musi wydarzyć
 - [https://eurosport.tvn24.pl/polki-mog--awansowa--do--wier-fina-u-ju--w-pi-tek--co-si--musi-wydarzy-,1120788.html?source=rss](https://eurosport.tvn24.pl/polki-mog--awansowa--do--wier-fina-u-ju--w-pi-tek--co-si--musi-wydarzy-,1120788.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 12:23:00+00:00

<img alt="Polki mogą awansować do ćwierćfinału już w piątek. Co się musi wydarzyć" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8cgi6p-polki-w-piatek-zagraja-w-lodzi-z-kanadyjkami-6152277/alternates/LANDSCAPE_1280" />
    O godz. 20.30 w łódzkiej Atlas Arenie zmierzą się z Kanadyjkami.

## Suski: nie Sasin, a "eksplozje na Bałtyku" winne ogromnych spadków na giełdzie. Sprawdzamy
 - [https://konkret24.tvn24.pl/r/suski--nie-sasin--a--eksplozje-na-ba-tyku--winne-ogromnych-spadk-w-na-gie-dzie--sprawdzamy,1120667.html?source=rss](https://konkret24.tvn24.pl/r/suski--nie-sasin--a--eksplozje-na-ba-tyku--winne-ogromnych-spadk-w-na-gie-dzie--sprawdzamy,1120667.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 12:13:00+00:00

<img alt="Suski: nie Sasin, a " src="https://tvn24.pl/najnowsze/cdn-zdjecie-uh2dq1-marek-suski-o-spadkach-na-gieldzie-6152329/alternates/LANDSCAPE_1280" />
    Za ogromne spadki na warszawskiej giełdzie odpowiadają wybuchy gazociągu Nord Stream - stwierdził poseł Marek Suski.

## Rosjanie zostali i grają w Polsce. "Szanują klub, mają wśród Polaków wielu przyjaciół"
 - [https://eurosport.tvn24.pl/rosjanie-zostali-i-graj--w-polsce---szanuj--klub--maj--w-r-d-polak-w-wielu-przyjaci---,1120666.html?source=rss](https://eurosport.tvn24.pl/rosjanie-zostali-i-graj--w-polsce---szanuj--klub--maj--w-r-d-polak-w-wielu-przyjaci---,1120666.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 09:49:51+00:00

<img alt="Rosjanie zostali i grają w Polsce. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fvvyyv-wisla-plock-z-rosjanami-w-skladzie-rywalizuje-w-lidze-mistrzow/alternates/LANDSCAPE_1280" />
    Dlaczego w ogóle wciąż grają, skoro Rosjan wyklucza się ze społeczności międzynarodowej? W Wiśle Płock oraz w Azotach Puławy i Chrobrym Głogów, klubach ekstraklasy piłki ręcznej, mają wytłumaczenie.

## Oskarżany o oszustwa szachista gra przy "wzmocnionych zabezpieczeniach"
 - [https://eurosport.tvn24.pl/oskar-any-o-oszustwa-hans-niemann-gra-przy--wzmocnionych-zabezpieczeniach-,1120783.html?source=rss](https://eurosport.tvn24.pl/oskar-any-o-oszustwa-hans-niemann-gra-przy--wzmocnionych-zabezpieczeniach-,1120783.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 09:04:55+00:00

<img alt="Oskarżany o oszustwa szachista gra przy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kvin1b-hans-niemann-jest-oskarzany-o-liczne-oszustwa/alternates/LANDSCAPE_1280" />
    Duża próba dla Hansa Niemanna. 19-latek bierze udział w mistrzostwach Stanów Zjednoczonych.

## Gaz łzawiący, gumowe kule i kibice uciekający na boisko. Jedna osoba nie żyje
 - [https://eurosport.tvn24.pl/gaz--zawi-cy--gumowe-kule-i-kibice-uciekaj-cy-na-boisko--jedna-osoba-nie--yje,1120781.html?source=rss](https://eurosport.tvn24.pl/gaz--zawi-cy--gumowe-kule-i-kibice-uciekaj-cy-na-boisko--jedna-osoba-nie--yje,1120781.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 07:29:07+00:00

<img alt="Gaz łzawiący, gumowe kule i kibice uciekający na boisko. Jedna osoba nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5mys5e-zamieszki-podczas-meczu-gimnasia-boca/alternates/LANDSCAPE_1280" />
    Tragedia podczas meczu argentyńskiej ekstraklasy.

## Gol niemal z połowy boiska. Sezon dla Polaków się skończył
 - [https://eurosport.tvn24.pl/gol-niemal-z-po-owy-boiska--sezon-dla-polak-w-si--sko-czy-,1120777.html?source=rss](https://eurosport.tvn24.pl/gol-niemal-z-po-owy-boiska--sezon-dla-polak-w-si--sko-czy-,1120777.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 07:00:28+00:00

<img alt="Gol niemal z połowy boiska. Sezon dla Polaków się skończył" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ryh3gl-karol-swiderski-i-jego-charlotte-nie-zagraja-w-play-off-w-mls/alternates/LANDSCAPE_1280" />
    Charlotte FC, którego piłkarzami są Karol Świderski, Kamil Jóźwiak i Jan Sobociński, nie zagra w play-off MLS.

## Nie żyje ojciec prezesa Legii Warszawa. Tragiczny wypadek na przejeździe kolejowym
 - [https://eurosport.tvn24.pl/nie--yje-ojciec-prezesa-legii-warszawa--tragiczny-wypadek-na-przeje-dzie-kolejowym,1120775.html?source=rss](https://eurosport.tvn24.pl/nie--yje-ojciec-prezesa-legii-warszawa--tragiczny-wypadek-na-przeje-dzie-kolejowym,1120775.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 05:53:02+00:00

<img alt="Nie żyje ojciec prezesa Legii Warszawa. Tragiczny wypadek na przejeździe kolejowym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u5zclo-dariusz-mioduski-jest-prezesem-legii-warszawa-6151522/alternates/LANDSCAPE_1280" />
    Gerard Mioduski nie żyje - poinformowała Legia Warszawa, składając kondolencje. Ojciec właściciela i prezesa klubu miał 81 lat.

## Polski bramkarz trafiony przedmiotem rzuconym z trybun
 - [https://eurosport.tvn24.pl/marcin-bu-ka-trafiony-przedmiotem-rzuconym-z-trybun,1120773.html?source=rss](https://eurosport.tvn24.pl/marcin-bu-ka-trafiony-przedmiotem-rzuconym-z-trybun,1120773.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 05:07:53+00:00

<img alt="Polski bramkarz trafiony przedmiotem rzuconym z trybun" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5v68d8-marcin-bulka-przez-kilka-minut-byl-opatrywany/alternates/LANDSCAPE_1280" />
    Niepokojące obrazki z udziałem Marcina Bułki w meczu Ligi Konferencji.

## Deklaracja Messiego. "Decyzja została już podjęta"
 - [https://eurosport.tvn24.pl/wa-na-deklaracja-messiego---decyzja-zosta-a-ju--podj-ta-,1120736.html?source=rss](https://eurosport.tvn24.pl/wa-na-deklaracja-messiego---decyzja-zosta-a-ju--podj-ta-,1120736.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 04:21:12+00:00

<img alt="Deklaracja Messiego. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7auzl3-lionel-messi-jest-gwiazda-reprezentacji-argentyny/alternates/LANDSCAPE_1280" />
    Chodzi o mistrzostwa świata.

## Wielka szansa Polski na "gigantyczny skok gospodarczy". Ekspert: musi zmienić się nastawienie państwa
 - [https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-42,S00E42,878508?source=rss](https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-42,S00E42,878508?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 04:00:00+00:00

<img alt="Wielka szansa Polski na " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ur7ya-kosmiczne-gornictwo-6151386/alternates/LANDSCAPE_1280" />
    Hubert Kijek rozmawiał z dr. inż. Adamem Janem Zwierzyńskim o kosmicznym górnictwie.

## Oskarżają Rosję o eksploatację Afryki: pieniądze za zasoby naturalne finansują wojnę w Ukrainie
 - [https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-7-pazdziernika-6151458?source=rss](https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-7-pazdziernika-6151458?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-07 03:16:45+00:00

<img alt="Oskarżają Rosję o eksploatację Afryki: pieniądze za zasoby naturalne finansują wojnę w Ukrainie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-868s03-rosjanie-w-afryce-5777257/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.


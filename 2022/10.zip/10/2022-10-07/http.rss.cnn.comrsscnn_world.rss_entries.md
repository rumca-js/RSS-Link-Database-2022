# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Eurovision names Liverpool as host city for its 2023 Song Contest honoring Ukraine
 - [https://www.cnn.com/2022/10/07/entertainment/eurovision-liverpool/index.html](https://www.cnn.com/2022/10/07/entertainment/eurovision-liverpool/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-07 21:54:46+00:00

The Beatles' hometown of Liverpool, UK will be stepping in to host the festivities at the Eurovision 2023 Song Contest next May, the competition announced Friday.

## The fate of Elon Musk's deal to buy Twitter now comes down to the money
 - [https://www.cnn.com/2022/10/07/tech/elon-musk-twitter-deal-financing/index.html](https://www.cnn.com/2022/10/07/tech/elon-musk-twitter-deal-financing/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-07 20:11:51+00:00

The countdown is now on for Elon Musk and Twitter to close their $44 billion acquisition deal by October 28 or be forced to again prepare for a trial after a judge agreed on Thursday pause the legal proceedings.

## Analysis: Iran's 'women's revolution' could be a Berlin Wall moment
 - [https://www.cnn.com/2022/10/07/politics/iran-women-protest-revolution-what-matters/index.html](https://www.cnn.com/2022/10/07/politics/iran-women-protest-revolution-what-matters/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-07 18:49:05+00:00

The Islamic regime in Iran has ruled for decades with fear and intimidation.

## Haiti government asks for international military assistance
 - [https://www.cnn.com/2022/10/07/americas/haiti-international-military-assistance-humanitarian-crisis-intl/index.html](https://www.cnn.com/2022/10/07/americas/haiti-international-military-assistance-humanitarian-crisis-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-07 18:39:23+00:00

Haiti's government has asked for international military assistance as it grapples with interlocked health, energy and security crises, according to a statement from Jean-Junior Joseph, advisor to Haiti's Prime Minister.

## US sanctions target Myanmar junta-linked businessman for procuring Russian-made weapons
 - [https://www.cnn.com/2022/10/07/asia/us-sanctions-myanmar-junta-businessman-russia-weapons-intl-hnk/index.html](https://www.cnn.com/2022/10/07/asia/us-sanctions-myanmar-junta-businessman-russia-weapons-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-07 04:15:51+00:00

The United States on Thursday imposed sanctions on a Myanmar businessman and two others involved in procuring Russian-made weapons from Belarus for the junta that seized power in the Southeast Asian country early last year, Secretary of State Antony Blinken said.

## UN rights council rejects debate on China's abuses in Xinjiang in a blow to the West
 - [https://www.cnn.com/2022/10/06/china/un-rejects-debate-china-xinjiang-uyghur-intl-hnk/index.html](https://www.cnn.com/2022/10/06/china/un-rejects-debate-china-xinjiang-uyghur-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-07 02:34:57+00:00

The UN rights council on Thursday voted down a Western-led motion to hold a debate about alleged human rights abuses by China against Uyghurs and other Muslims in Xinjiang in a victory for Beijing as it seeks to avoid further scrutiny.

## Bolsonaro speeds up payments to the poor as election looms
 - [https://www.cnn.com/2022/10/06/americas/bolsonaro-auxilio-brasil-intl-latam/index.html](https://www.cnn.com/2022/10/06/americas/bolsonaro-auxilio-brasil-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-07 01:26:37+00:00

Brazil's government has announced plans to accelerate this month's welfare payments to the needy, as President Jair Bolsonaro prepares to face leftwing rival Luiz Inacio Lula da Silva in a second-round election.


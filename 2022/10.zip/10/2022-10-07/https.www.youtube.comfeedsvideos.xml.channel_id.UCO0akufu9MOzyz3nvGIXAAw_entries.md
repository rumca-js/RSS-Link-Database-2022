## WEF has been ‘upfront’ about ‘Great Reset’ agenda
 - [https://www.youtube.com/watch?v=6Iy-YrmDMX4](https://www.youtube.com/watch?v=6Iy-YrmDMX4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO0akufu9MOzyz3nvGIXAAw
 - date published: 2022-10-07 07:19:48+00:00

WEF has been ‘upfront’ about ‘Great Reset’ agenda


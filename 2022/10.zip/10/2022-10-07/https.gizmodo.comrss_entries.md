# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## She-Hulk: Attorney at Law Episode 8 Review
 - [https://gizmodo.com/she-hulk-attorney-at-law-episode-8-review-1849633036](https://gizmodo.com/she-hulk-attorney-at-law-episode-8-review-1849633036)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-08 00:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--k4z96Bum--/c_fit,fl_progressive,q_80,w_636/da01440016a56124863eed175c29c5b3.jpg" /><p><a href="https://gizmodo.com/she-hulk-attorney-at-law-episode-8-review-1849633036">Read more...</a></p>

## V/H/S/99's Trailer Promises a Gleefully Gory Good Time
 - [https://gizmodo.com/shudder-vhs-99-found-footage-horror-gory-trailer-1849631539](https://gizmodo.com/shudder-vhs-99-found-footage-horror-gory-trailer-1849631539)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 23:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--melIRboK--/c_fit,fl_progressive,q_80,w_636/bc36df8273a761340129b483e5bd0d86.jpg" /><p>Found-footage horror—which once felt like a gimmick on its way to obscurity—just keeps finding <a href="https://gizmodo.com/shudder-deadstream-found-footage-horror-movie-review-1849616530">new ways to reinvent itself</a>. One big reason is the <em>V/H/S </em>series, which revived itself with last year’s sickeningly entertaining <a href="https://gizm

## The Full Teen Wolf: The Movie Trailer Is a Monster-Filled Delight
 - [https://gizmodo.com/teen-wolf-the-movie-trailer-paramount-tyler-posey-mtv-1849620929](https://gizmodo.com/teen-wolf-the-movie-trailer-paramount-tyler-posey-mtv-1849620929)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 22:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--DP9dZc2s--/c_fit,fl_progressive,q_80,w_636/d85ebbd8945ca37b005c76b5d73dc10c.jpg" /><p>It’s always special when a show that you think is gone forever <a href="https://gizmodo.com/teen-wolf-will-live-on-as-a-paramount-movie-1847741429">comes back in some form</a> or another. <a href="https://gizmodo.com/a-new-firefly-graphic-novel-will-explore-the-life-deat-1842900072"><em>Firefly</em></a> getting <em>Serenity</em>. <em>Beavis and Butt

## The Lord of the Rings: The Rings of Power Finale Trailer Is Here to Rule Them All
 - [https://gizmodo.com/lord-of-the-rings-rings-of-power-finale-trailer-prime-v-1849620587](https://gizmodo.com/lord-of-the-rings-rings-of-power-finale-trailer-prime-v-1849620587)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 22:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ASQlZZT9--/c_fit,fl_progressive,q_80,w_636/979e388707132c59771ce592644e55e2.jpg" /><p>The first chapter of the <a href="https://gizmodo.com/lord-of-the-rings-rings-of-power-prime-release-date-det-1848503002">latest <em>Lord of the Rings </em>saga</a> is about to close and wow does it look like it’s going to be massive. At New York Comic Con, the team behind Prime Video’s <a href="https://gizmodo.com/lord-of-the-rings-rings-of-power-e

## The Wheel of Time Takes Another Spin in Its First Season 2 Sneak Peek
 - [https://gizmodo.com/while-of-time-season-2-trailer-rosamund-pike-prime-1849627336](https://gizmodo.com/while-of-time-season-2-trailer-rosamund-pike-prime-1849627336)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--PuwZNWsD--/c_fit,fl_progressive,q_80,w_636/fba73d66e907924ebeb9433959f0d814.jpg" /><p><a href="https://gizmodo.com/lord-of-the-rings-rings-of-power-review-prime-video-1849476375"><em>Lord of the Rings: The Rings of Power</em></a> might be the epic fantasy TV series consuming all of Amazon’s attention (and money), but Prime Video doesn’t want you to forget about its TV adaptation of Robert Jordan’s <a href="https://gizmodo.com/the-whe

## Meta Sues Chinese Fake App Makers for Allegedly Breaching Over 1 Million WhatsApp Accounts
 - [https://gizmodo.com/whatsapp-facebook-fake-app-takeovers-meta-sues-1849631883](https://gizmodo.com/whatsapp-facebook-fake-app-takeovers-meta-sues-1849631883)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 21:24:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--SRNdbQh4--/c_fit,fl_progressive,q_80,w_636/61628f4f6f2fa02bf0f4fb20d57d9152.jpg" /><p>Facebook parent company Meta has filed a lawsuit against several Chinese  developers accusing them of creating  knock-off WhatsApp Android apps that were used to hijack over a million user accounts. The company also revealed it had identified some 400 apps dedicated to stealing Facebook login credentials and reported…</p><p><a href="https://gizmodo.

## This Week's Toy News Is Ready to Awkwardly Transform and Roll Out
 - [https://gizmodo.com/optimus-prime-transforming-halloween-costume-1849611100](https://gizmodo.com/optimus-prime-transforming-halloween-costume-1849611100)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 21:15:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--riI3h0ky--/c_fit,fl_progressive,q_80,w_636/b90cc0d416e1022328dbd12c80475669.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--3QL2Ti7T--/c_fit,fl_progressive,q_80,w_636/b90cc0d416e1022328dbd12c80475669.mp4" type="video/mp4" /></video><p>Welcome back to Toy Aisle, where io9 recaps the latest, greatest, and often silliest in geek merch. This week <em>Power Rangers</em> and <em>Transformers</em> compete

## Heat Waves Set Off Record Ice Melt in Greenland Last Month
 - [https://gizmodo.com/greenland-ice-melt-september-2022-heat-waves-1849630945](https://gizmodo.com/greenland-ice-melt-september-2022-heat-waves-1849630945)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 20:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--AWuwcaNw--/c_fit,fl_progressive,q_80,w_636/bdcbcf02dc23c4b27033f1791e5a9b82.jpg" /><p>September heat waves across Canada and the U.S. were so bad that the high temperatures melted ice all the way in Greenland. Strong winds from North America carried the hot air to the northeast, raising average temperatures there more than 8 degrees Celsius (14 degrees Fahrenheit) compared to past Septembers, according…</p><p><a href="https://gizmodo

## Bose Might Be Right About the QuietComfort Earbuds II Having the World’s Best ANC
 - [https://gizmodo.com/bose-quietcomfort-earbuds-ii-review-best-anc-earbuds-1849632447](https://gizmodo.com/bose-quietcomfort-earbuds-ii-review-best-anc-earbuds-1849632447)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 20:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--5Iye9MB8--/c_fit,fl_progressive,q_80,w_636/f0b041eff2db74c106c24517fca7b274.jpg" /><p>Massachusetts-based audio giant, Bose, recently released the successor to its first gen QuietComfort Earbuds, which came out two years ago. The newly released buds, named the QuietComfort Earbuds II (QC Earbuds II), brought with them a plethora of upgrades. Enhanced Active Noise Cancellation (ANC), a trimmed down…</p><p><a href="https://gizmodo.com/

## Engineers Regain Control of Moon-Bound Probe After a Frightening 4 Weeks
 - [https://gizmodo.com/capstone-probe-back-on-track-nasa-moon-1849632173](https://gizmodo.com/capstone-probe-back-on-track-nasa-moon-1849632173)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 20:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--fkZjxXJa--/c_fit,fl_progressive,q_80,w_636/3405519be82a9d084ab468f87a9a56ae.jpg" /><p>We’ve got some good news to start the weekend: A recovery team has regained control of NASA’s CAPSTONE probe, which is in the midst of a four-month journey to an elliptical halo orbit around the Moon. </p><p><a href="https://gizmodo.com/capstone-probe-back-on-track-nasa-moon-1849632173">Read more...</a></p>

## Rings of Power's Quest Stands Upon the Edge of a Knife
 - [https://gizmodo.com/lord-of-the-ring-rings-of-power-episode-7-recap-mordor-1849632294](https://gizmodo.com/lord-of-the-ring-rings-of-power-episode-7-recap-mordor-1849632294)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 20:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--koh5MJH2--/c_fit,fl_progressive,q_80,w_636/b030b980b5b0ab7ccef835b9503c315f.png" /><p><em>Rings of Power</em> has spent its entire season reminding us that it, at its core in manners similar to <em>Lord of the Rings</em> as a whole, is a <a href="https://gizmodo.com/lord-of-the-rings-rings-of-power-episode-3-recap-adar-1849518936">story of enduring hope </a>in the face of <a href="https://gizmodo.com/lord-of-the-rings-rings-of-power-

## Close-Up Photo of Jupiter's Moon Europa Shows a Bizarre Surface
 - [https://gizmodo.com/close-up-photo-of-jupiters-moon-europa-shows-a-bizarre-1849630484](https://gizmodo.com/close-up-photo-of-jupiters-moon-europa-shows-a-bizarre-1849630484)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 20:01:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--DAfrBZTX--/c_fit,fl_progressive,q_80,w_636/f286fe6e432b4e0453f3ba001cbda71a.jpg" /><p>NASA’s Juno spacecraft took images of Jupiter’s icy moon Europa during a recent flyby. One of the photos—released this week by NASA—offers an intimate view of Europa’s surface features.</p><p><a href="https://gizmodo.com/close-up-photo-of-jupiters-moon-europa-shows-a-bizarre-1849630484">Read more...</a></p>

## One of The Nation's Largest Basic Income Experiments Is Now Underway
 - [https://gizmodo.com/basic-income-cook-county-chicago-illinois-500-test-1849631779](https://gizmodo.com/basic-income-cook-county-chicago-illinois-500-test-1849631779)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 19:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--NGLqPR11--/c_fit,fl_progressive,q_80,w_636/bc147205a925601fd27ad93a523a1e54.jpg" /><p> Illinois’ Cook County, which includes Chicago, has opened up applications for one of the largest guaranteed basic income pilots in the U.S. to date.</p><p><a href="https://gizmodo.com/basic-income-cook-county-chicago-illinois-500-test-1849631779">Read more...</a></p>

## Upgraded Covid-19 Boosters Could Save 90,000 American Lives This Winter—If We Get Them
 - [https://gizmodo.com/upgraded-covid-19-boosters-could-save-90-000-american-l-1849631532](https://gizmodo.com/upgraded-covid-19-boosters-could-save-90-000-american-l-1849631532)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 19:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--elXc8nZO--/c_fit,fl_progressive,q_80,w_636/74b60a97e4cb6388648d078c859808be.jpg" /><p>The toll of covid-19 in the U.S. this winter will depend heavily on how many Americans are able and willing to get an upgraded booster shot, suggests a new expert analysis. Even a moderately successful booster campaign would save tens of thousands of lives as well as billions of dollars in medical costs, researchers…</p><p><a href="https://gizmodo.c

## Easter Island Statues Damaged in Fire Possibly Set by Humans
 - [https://gizmodo.com/easter-island-statues-damaged-in-fire-possibly-set-by-h-1849631475](https://gizmodo.com/easter-island-statues-damaged-in-fire-possibly-set-by-h-1849631475)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 19:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--3yevYmHJ--/c_fit,fl_progressive,q_80,w_636/61252c52b84a309721d5b1c1f7b16813.jpg" /><p>A fire that may have been intentionally set has caused “irreparable” damage to some of the iconic ancient moai statues on Easter Island, local authorities said this week.<br /></p><p><a href="https://gizmodo.com/easter-island-statues-damaged-in-fire-possibly-set-by-h-1849631475">Read more...</a></p>

## The Most Awesome Cosplay of New York Comic Con, Day 1
 - [https://gizmodo.com/new-york-comic-con-2022-cosplay-day-1-spider-man-batman-1849630874](https://gizmodo.com/new-york-comic-con-2022-cosplay-day-1-spider-man-batman-1849630874)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 18:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--KIIiwuOb--/c_fit,fl_progressive,q_80,w_636/a4c573c99d8f58bd3f7877619c493a02.jpg" /><p>Say cheese! <a href="https://gizmodo.com/new-york-comic-con-funko-pop-vinyl-toy-exclusives-nycc-1849625370">New York Comic Con 2022</a> is here and you know what that means? <a href="https://gizmodo.com/comic-con-2022-cosplay-gallery-day-4-1849327696">Cosplay. Lots of it.</a> Characters from every universe, every comic, every TV show, every movie—th

## Sci-Fi Magazine Heavy Metal's Metalverse Has Room for Both Movies and NFTs
 - [https://gizmodo.com/sci-fi-magazine-heavy-metal-revamping-with-nfts-1849627808](https://gizmodo.com/sci-fi-magazine-heavy-metal-revamping-with-nfts-1849627808)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 17:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--gLu8SXYw--/c_fit,fl_progressive,q_80,w_636/afb5e00999dbfca4df4f44df2a6297a9.png" /><p>Instead of doing any one thing to bring themselves back into the sci-fi cultural limelight, the heads behind the storied counterculture comic magazine Heavy Metal are taking a shotgun approach to regaining their legacy, including movies, a revamped launch schedule and—because why the hell not—NFTs.</p><p><a href="https://gizmodo.com/sci-fi-magazine-

## SpaceX to Attempt Rare Launch of Falcon Heavy Later This Month
 - [https://gizmodo.com/spacex-launch-falcon-heavy-space-force-mission-1849630237](https://gizmodo.com/spacex-launch-falcon-heavy-space-force-mission-1849630237)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 17:25:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--jZgNyzjW--/c_fit,fl_progressive,q_80,w_636/d13f4512bc34ab5e85a2a2ecfba300a6.jpg" /><p>For the first time since June 2019, we’ll get to see a SpaceX Falcon Heavy take to the skies. The U.S. Space Force has chartered a ride with the heavy-lift launch vehicle, but the details of this defense mission are a bit vague.<br /></p><p><a href="https://gizmodo.com/spacex-launch-falcon-heavy-space-force-mission-1849630237">Read more...</a></p>

## The Midnight Club's First Episode Is a Horror Record-Breaker
 - [https://gizmodo.com/netflix-horror-the-midnight-club-mike-flanagan-series-1849629931](https://gizmodo.com/netflix-horror-the-midnight-club-mike-flanagan-series-1849629931)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--lqxI2JYI--/c_fit,fl_progressive,q_80,w_636/b685f8585ab5ab0b2fd60052c024aaf5.png" /><p>Culled from an expansive library of <a href="https://gizmodo.com/horror-master-mike-flanagan-is-giving-christopher-pikes-1843271241">Christopher Pike</a> novels, <a href="https://gizmodo.com/the-midnight-club-mike-flanagan-netflix-trailer-1849557508"><em>The Midnight Club</em></a> is a new sort of Netflix venture for <a href="https://gizmodo.com/mik

## Biden Executive Order Says We'll Be More Careful When We Use European Data for Spy Stuff
 - [https://gizmodo.com/biden-executive-order-european-data-gdpr-spies-1849630714](https://gizmodo.com/biden-executive-order-european-data-gdpr-spies-1849630714)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 16:47:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--2qePLrsc--/c_fit,fl_progressive,q_80,w_636/a79d07b2899596c18f56af34ed6ef207.jpg" /><p>President Biden signed an executive order placing new restrictions on how U.S. intelligence agencies harness data as it flows between the U.S. and the E.U., the White House announced Friday. The order creates a new framework to comply with European privacy rules.</p><p><a href="https://gizmodo.com/biden-executive-order-european-data-gdpr-spies-18496

## Tesla Will Deliver Its First Semi Trucks to Pepsi in December, 3 Years Past Deadline
 - [https://gizmodo.com/elon-musk-tesla-semi-truck-pepsi-delivered-late-1849629540](https://gizmodo.com/elon-musk-tesla-semi-truck-pepsi-delivered-late-1849629540)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 16:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--OFa8fLHq--/c_fit,fl_progressive,q_80,w_636/897a94de63447dfca54615f5b39412a5.jpg" /><p>Amid <a href="https://gizmodo.com/elon-musk-twitter-deal-discount-deposition-delay-1849624404">revived drama</a> with Twitter that’s causing whiplash across the internet, Tesla CEO Elon Musk is doing one of the things he’s best at: distracting the public with a shiny new statement. </p><p><a href="https://gizmodo.com/elon-musk-tesla-semi-truck-pepsi

## Toyota Warns Thousands of Customers That They May Get Scam Emails After Data Leak
 - [https://gizmodo.com/toyota-warns-customers-they-may-get-scam-emails-after-d-1849630698](https://gizmodo.com/toyota-warns-customers-they-may-get-scam-emails-after-d-1849630698)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 16:25:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--LI3aEG-X--/c_fit,fl_progressive,q_80,w_636/57bede6f8f543e792d87a5d7887e3c8b.jpg" /><p>People who have been using Toyota’s smartphone app may have had their personal information leaked, the company reported on Friday. </p><p><a href="https://gizmodo.com/toyota-warns-customers-they-may-get-scam-emails-after-d-1849630698">Read more...</a></p>

## Archaeologists Find Underwater Salt Kitchens of the Ancient Maya
 - [https://gizmodo.com/ancient-maya-salt-kitchens-belize-1849626841](https://gizmodo.com/ancient-maya-salt-kitchens-belize-1849626841)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 16:24:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--mofGvCIv--/c_fit,fl_progressive,q_80,w_636/c2cbf6e80ce8b7c5f6de8be717b8f9b8.jpg" /><p>Recent excavations of submerged Maya salt kitchens off the coast of Belize indicate that their ancient workers lived on the sites and possibly worked in kin-based teams.<br /></p><p><a href="https://gizmodo.com/ancient-maya-salt-kitchens-belize-1849626841">Read more...</a></p>

## Neil Gaiman Delivers a Good Omens Season 2 Sneak Peek at NYCC
 - [https://gizmodo.com/good-omens-season-two-neil-gaiman-nycc-release-date-1849624118](https://gizmodo.com/good-omens-season-two-neil-gaiman-nycc-release-date-1849624118)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 16:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--dpXygyeW--/c_fit,fl_progressive,q_80,w_636/01ce3affe647c8c5cee26bfaab7621ad.png" /><p>After 2019's incredible first season on <a href="https://gizmodo.com/good-omens-season-2-reunites-its-cast-with-a-twist-1847983032">Prime Video</a>, <em>Good Omens</em> fans—demons and angels alike—have been longing for any season two news. After months of “wait and see” from both the streaming service and <a href="https://gizmodo.com/a-new-good-ome

## Google Wants to Help You Take the Perfect Selfie
 - [https://gizmodo.com/google-pixel-7-new-features-guided-frame-emoji-dictatio-1849630461](https://gizmodo.com/google-pixel-7-new-features-guided-frame-emoji-dictatio-1849630461)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--RO5OBbEe--/c_fit,fl_progressive,q_80,w_636/716bf14b63800a5edd3046350d03c2e2.png" /><p>Google may be the originator of the Android operating system, but it’s competing with other companies staking a claim on the platform. Samsung and OnePlus bundle in software features to help differentiate from the crowd, so Google leverages its search engine and Assistant smarts to entice you away from Android…</p><p><a href="https://gizmodo.com/goo

## Things Get Biblical in the First His Dark Materials Season 3 Trailer
 - [https://gizmodo.com/his-dark-materials-final-season-3-trailer-tv-hbo-1849627162](https://gizmodo.com/his-dark-materials-final-season-3-trailer-tv-hbo-1849627162)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 15:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--GClTzxPI--/c_fit,fl_progressive,q_80,w_636/2e792c6f031ab890cee80a9700f691f4.jpg" /><p>If you’ve never read Philip Pullman’s <em>His Dark Materials</em> book trilogy but have watched the <a href="https://gizmodo.com/i-really-want-to-love-his-dark-materials-but-its-getti-1840265215">HBO series</a>, you must have been bewildered at how <a href="https://gizmodo.com/his-dark-materials-most-confusing-plot-points-explained-1840028691">seaso

## Biden: We’re Closest to Nuclear Armageddon Since Cuban Missile Crisis
 - [https://gizmodo.com/biden-nuclear-armageddon-cuban-missile-crisis-putin-1849630207](https://gizmodo.com/biden-nuclear-armageddon-cuban-missile-crisis-putin-1849630207)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 15:17:35+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--yMKfFpvG--/c_fit,fl_progressive,q_80,w_636/838a75b491ec0684147e12c3a4b062d4.jpg" /><p>U.S. President Joe Biden wants to make sure the American public starts off their weekend with a nice heaping dose of existential dread.</p><p><a href="https://gizmodo.com/biden-nuclear-armageddon-cuban-missile-crisis-putin-1849630207">Read more...</a></p>

## House of the Dragon Fans Will Kneel to This Lavish Behind-the-Scenes Book
 - [https://gizmodo.com/house-of-the-dragon-making-of-book-game-of-thrones-hbo-1849626770](https://gizmodo.com/house-of-the-dragon-making-of-book-game-of-thrones-hbo-1849626770)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Yt347T6k--/c_fit,fl_progressive,q_80,w_636/48f647e408854d8d47f63930b29fd8aa.jpg" /><p>Skepticism was natural when HBO announced it would be <a href="https://gizmodo.com/the-first-game-of-thrones-spinoff-is-a-golden-age-of-h-1826680373">making a spinoff to <em>Game of Thrones</em></a>. <em>Thrones</em> had been so incredible (despite <a href="https://gizmodo.com/the-game-of-thrones-finale-got-the-important-stuff-righ-1834884402">endin

## Amazon Scraps Scout Home Delivery Robot Tests
 - [https://gizmodo.com/amazon-scraps-scout-home-delivery-robot-tests-1849629662](https://gizmodo.com/amazon-scraps-scout-home-delivery-robot-tests-1849629662)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 14:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--k5U6C8D9--/c_fit,fl_progressive,q_80,w_636/b88fcc7fdfef590614854d2c09b19eed.jpg" /><p>Amazon is putting its rectangular, rolling robot out to pasture. Scout, <a href="https://gizmodo.com/if-you-see-a-human-working-with-amazons-delivery-bots-1837033455">the chaperoned, 6-wheeled</a>  delivery bot, which has been in testing since 2019, will no longer be further tested or developed, according to reports from multiple outlets.<br /></p><

## Updates From Kingdom of the Planet of the Apes, Black Adam, and More
 - [https://gizmodo.com/kingdom-of-the-planet-of-the-apes-casting-eka-darville-1849607176](https://gizmodo.com/kingdom-of-the-planet-of-the-apes-casting-eka-darville-1849607176)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 14:25:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ocm-dkrd--/c_fit,fl_progressive,q_80,w_636/8029cee36224cd6cd7b013b9707e8d44.png" /><p>A third season of <em>Fantasy Island</em> is on the way. Get a creepy new look at the next <em>American Horror Story</em>. Plus, a ton of looks at <em>Chucky </em>season 2, <em>Reginald the Vampire</em>, <em>Pennyworth: The Origins of Batman’s Butler</em>, and much, much more. To me, my spoilers!<br /></p><p><a href="https://gizmodo.com/kingdom-of-t

## Bruce Willis is Keeping His Face
 - [https://gizmodo.com/bruce-willis-is-keeping-his-face-1849623247](https://gizmodo.com/bruce-willis-is-keeping-his-face-1849623247)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 13:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--MfeEPJWd--/c_fit,fl_progressive,q_80,w_636/e91e31f39837a60276537fb8d343fd8f.jpg" /><p><a href="https://gizmodo.com/bruce-willis-is-keeping-his-face-1849623247">Read more...</a></p>

## Aerial Images Show Alarming Extent of Hurricane Ian's Devastation in Florida
 - [https://gizmodo.com/before-after-images-hurricane-ian-florida-1849620978](https://gizmodo.com/before-after-images-hurricane-ian-florida-1849620978)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 13:14:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--8uzZC_wU--/c_fit,fl_progressive,q_80,w_636/6289183d59b56d691407f1534bbddf1c.png" /><p>Hurricane Ian tore across Florida last week, killing <a href="https://www.cnn.com/2022/10/04/us/hurricane-ian-florida-recovery-tuesday" rel="noopener noreferrer" target="_blank">at least 105</a> people in the state and leaving destruction in its wake. Hundreds of thousands of households <a href="https://poweroutage.us/area/state/florida" rel="noopen

## Binance Says $100 Million of Crypto Produced Out of Thin Air by Hackers
 - [https://gizmodo.com/binance-bnb-bitcoin-price-million-stolen-crypto-hack-1849629259](https://gizmodo.com/binance-bnb-bitcoin-price-million-stolen-crypto-hack-1849629259)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 09:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Sy_7c7gf--/c_fit,fl_progressive,q_80,w_636/0e1a27a951091212371841672223fb17.jpg" /><p>Binance estimates roughly $100-$110 million worth of its cryptocurrency BNB was taken by unknown hackers on Thursday, according to a tweet from CEO Changpeng Zhao, considerably less than the $566 million <a href="https://twitter.com/samczsun/status/1578167198203289600" rel="noopener noreferrer" target="_blank">originally estimated</a>. But don’t wor

## First Look at Legend of Vox Machina's Chaotic Season 2, With Season 3 Just Announced
 - [https://gizmodo.com/prime-video-critical-role-vox-machina-s2-first-look-1849623384](https://gizmodo.com/prime-video-critical-role-vox-machina-s2-first-look-1849623384)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 00:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--dRW0iWlZ--/c_fit,fl_progressive,q_80,w_636/05c53d606bf2434f4d83c5794458e01b.jpg" /><p>When <a href="https://gizmodo.com/d-and-d-critical-role-exandria-unlimited-calamity-playe-1849058923">Critical Role’s</a><em> </em>first season of <a href="https://gizmodo.com/critical-role-vox-machina-review-amazon-1848389619"><em>The Legend of Vox Machina</em></a> premiered earlier this year, the heroes were going through the growing pains of bein

## Adult Performers File Allegedly Leaked Offshore Bank Records in OnlyFans-Meta Bribery Suit
 - [https://gizmodo.com/onlyfans-meta-facebook-execs-wire-transfers-bribe-court-1849627800](https://gizmodo.com/onlyfans-meta-facebook-execs-wire-transfers-bribe-court-1849627800)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-07 00:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--jq3LCO0D--/c_fit,fl_progressive,q_80,w_636/98650651a4d8345e5b5972ca195d0946.jpg" /><p>A group of adult entertainers suing Meta say they were leaked new evidence of bribery—bank records that detail wire transfers from OnlyFans executives to offshore accounts for Meta executives.<br /></p><p><a href="https://gizmodo.com/onlyfans-meta-facebook-execs-wire-transfers-bribe-court-1849627800">Read more...</a></p>


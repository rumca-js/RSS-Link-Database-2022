## Byli pracownicy MF: prawdziwy deficyt budżetu to 206 mld zł
 - [https://www.wykop.pl/link/6850163/byli-pracownicy-mf-prawdziwy-deficyt-budzetu-to-206-mld-zl/](https://www.wykop.pl/link/6850163/byli-pracownicy-mf-prawdziwy-deficyt-budzetu-to-206-mld-zl/)
 - RSS feed: https://www.wykop.pl/rss/index.xml/
 - date published: 2022-10-07 17:38:01+00:00

<img src="https://www.wykop.pl/cdn/c3397993/link_1665144291iNMBJkvFAdYYBSAgVm3qFP,w104h74.jpg" /><br />
		 Gdyby policzyć wszystkie zadania realizowana poza budżetem, to dziura w kasie państwa w 2023 r. wynosiłaby ponad 206 mld zł, a nie 68 mld zł jak pokazuje rząd - mówią ekonomiści: Sławomir Dudek (główny ekonomista FOR), Ludwik Kotecki (członek RPP) oraz Hanna Majszczyk (b. wiceminister ds. budżetu).


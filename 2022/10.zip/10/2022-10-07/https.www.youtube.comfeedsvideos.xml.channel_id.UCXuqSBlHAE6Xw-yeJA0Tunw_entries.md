# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Our DIY CPU Chiller From AliExpress is RIDICULOUS
 - [https://www.youtube.com/watch?v=MozKrDoS1Dc](https://www.youtube.com/watch?v=MozKrDoS1Dc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-10-08 00:00:00+00:00

Get a 15-day free trial for unlimited backup at https://backblaze.com/LTT

Check out Zoho MarketingPlus at: https://lmg.gg/zohomarketingplus

Ryzen 7000 just launched which means one thing - we need to sub-zero it, and this time we're doing it on the cheap.

Discuss on the forum: https://linustechtips.com/topic/1459857-this-cooler-draws-2400w/

Buy an AMD 7950X: https://geni.us/k61Br
Check out the AsRock X670E Taichi: https://geni.us/NsOJJ
Buy an MSI 3090 Suprim: https://geni.us/r4Gu9K

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 - A terrible idea
0:45 - Zoho MarketingPlus!
0:57 - LTT Intro
1:07 - How TECs Work
2:29 - Mounting 20 TECs
4:22 - Power, manifolds, tubing, soldering
7:02 - Filling hot side
12:04 - Filling cold side feat. Antifreeze
14:21 - Subzero Prep
16:05 - Overclocking
19:03 - Backblaze
19:53 - Outro

## 4K YouTube Is Getting PAYWALLED - WAN Show October 7, 2022
 - [https://www.youtube.com/watch?v=ltyntSIVsjA](https://www.youtube.com/watch?v=ltyntSIVsjA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-10-07 00:00:00+00:00

Try Zoho One free for 30 days with no credit card required here: https://www.zoho.com/one/lp/linus.html
Save 10% off your Savage Jerky order today with code WANSHOW22 at https://savagejerky.com/ltt
Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Podcast Download: https://anchor.fm/thewanshowpodcast/episodes/4K-YouTube-Is-Getting-PAYWALLED---WAN-Show-October-7--2022-e1p2sgr

Timestamps: (Courtesy of NoKi1119)
0:00 Chapters
0:50 Intro
1:19 Topic #1 - YouTube restricts 4K to Premium
3:58 2160p, 10 ads & YouTube's statement
6:56 Chrome's Manifest V3
10:06 4K as premium only? discussing FP, costs, services
24:52 Lack of competition, accessibility, renting from a library
40:49 LTTStore screw-top lid, golden ABC's plush, swim trunks sale
44:10 Topic #2 - Intel Arc GPUs
45:08 Pricing, unstable gaming experience
47:46 Experience with iGPU, discussing past gens
55:44 Intel is THE competitor, 30 day Arc challenge
1:02:06 Luke hasn't seen any 4090 in person
1:02:30 Sponsor - Zoho One
1:03:27 Sponsor - Squarespace
1:04:48 Sponsor - Savage Jerky
1:06:34 Topic #3 - NVIDIA's ridiculously HUGE GPUs
1:08:08 Luke reacts to the Founders Edition
1:09:08 ASUS's ROG Strix series
1:10:52 ZOTAC's GAMING series
1:11:42 Linus returns with a 1080 to compare
1:13:02 MSI's SUPRIM X series
1:13:38 iGame's Vulcan series
1:16:10 Thoughts on the sheer size & weight of the cards
1:19:20 Comments on the AirPods 2 video, cruise control, voice auto-completion
1:43:22 Topic #4 - Super Mario Bros movie trailer
1:44:03 Watching the trailer, live commentary
1:46:17 Thoughts on trailer & Chris Pratt
1:47:55 Topic #5 - Overwatch 2's bad release
1:49:44 Expensive cosmetics, game changes
1:54:06 Topic #6 - Starforge computer review reaction
1:57:54 Linus reaffirms the logo's C&B look
1:59:32 Merch Messages #1
1:59:46 Floatplane app for TVs & NVIDIA Shield
2:00:32 Peer-to-peer to alleviate costs
2:01:36 CDN for Floatplane
2:07:52 Links of information from Labs
2:17:04 Practical gauche to keep an eye out for
2:18:32 AI on procedural generated gaming assets
2:22:28 Recommending games
2:23:10 How long until RISC-V goes x86-level mainstream?
2:24:40 Nostalgic tech that sucked
2:27:02 LMG's stability, impact on Linus's happiness
2:28:34 Tech to be excited for
2:30:00 Pimax 5K review idea
2:30:56 Paternal tech Linus uses
2:31:28 Linus on failed video ideas
2:33:32 Predicting & planning for LMG's future
2:35:23 Weirdest or coolest thing signed for fans
2:36:46 Thoughts on Google Matter
2:37:16 Rootkit development for gaming
2:38:03 Making labs benchmarking tools public
2:43:18 What does LMG do for power management?
2:44:36 Hiring people from the US
2:45:05 Items that are a must-have in cars
2:47:25 Outro


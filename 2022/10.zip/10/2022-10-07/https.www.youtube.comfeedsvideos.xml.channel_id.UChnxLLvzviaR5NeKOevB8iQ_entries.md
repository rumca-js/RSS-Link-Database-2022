# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## floating backwards (music performance)
 - [https://www.youtube.com/watch?v=EVOmsPvq6NY](https://www.youtube.com/watch?v=EVOmsPvq6NY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-10-07 00:00:00+00:00

This is my second, unreleased performance commissioned by Color Creative for the Microsoft Game Stack Live conference in Seattle. the first was released here: https://youtu.be/1Mm4xw1aro0

Deluge does polyphonic synths, blues vocal samples, and some additional drums. Modular does the rest. Solo is done with a crazy setting on found on Rings that sounds nothing like Rings. Vocals were recorded and mixed after the modular performance in Ableton.

Cat was done in Facerig.
------------------------------------
Patreon:  http://bit.ly/rmrpatreon

My Music: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
Google Play: http://bit.ly/33M9aG5
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


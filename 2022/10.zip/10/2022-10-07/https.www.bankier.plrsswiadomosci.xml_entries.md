# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Wyprzedaż na Wall Street, Wodospad na Dow Jones-ie
 - [https://www.bankier.pl/wiadomosc/Wyprzedaz-na-Wall-Street-Wodospad-na-Dow-Jones-ie-8419499.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wyprzedaz-na-Wall-Street-Wodospad-na-Dow-Jones-ie-8419499.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 21:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/8/f49599c86451cf-945-560-0-0-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Piątkowa sesja na Wall Street przyniosła mocne spadki głównych indeksów, które jeszcze przybrały na sile w ostatniej godzinie handlu. Pretekstem do sprzedaży akcji były dobre dane z amerykańskiego rynku pracy, które zwiększyły przekonanie inwestorów, że Fed będzie kontynuował po

## Soboń: Nie ma szansy na likwidację podatku Belki
 - [https://www.bankier.pl/wiadomosc/Sobon-Nie-ma-szansy-na-likwidacje-podatku-Belki-8419494.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sobon-Nie-ma-szansy-na-likwidacje-podatku-Belki-8419494.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 20:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/1/d0dbd8661ce27d-948-568-0-66-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie ma szansy na likwidację podatku Belki - powiedział  w piątek wiceminister finansów Artur Soboń. Dodał, że w resorcie analizowane są rozwiązania, które mogłyby być korzystne dla części osób z niskimi oszczędnościami.</p>

## Kotecki: Stopy procentowe powinny być wyższe niż obecne
 - [https://www.bankier.pl/wiadomosc/Kotecki-Stopy-procentowe-powinny-byc-wyzsze-niz-obecne-8419465.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kotecki-Stopy-procentowe-powinny-byc-wyzsze-niz-obecne-8419465.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 19:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/8/d7765beec5f6ea-948-568-0-488-1366-819.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stopy procentowe powinny docelowo być wyższe niż obecne 6,75 proc., choć są już na dosyć wysokim poziomie - powiedział w Polsat News członek RPP Ludwik Kotecki. Dodał, że większość RPP do dalszych podwyżek mogą skłonić wyniki listopadowej projekcji inflacji.</p>

## Szef URE zachęca do podatku od ekstrazysków. "Mogą się pojawić w przyszłym roku"
 - [https://www.bankier.pl/wiadomosc/Szef-URE-zacheca-do-podatku-od-nadzwyczajnych-zyskow-8419458.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szef-URE-zacheca-do-podatku-od-nadzwyczajnych-zyskow-8419458.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 18:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/c/d5b9d78009cad2-948-568-0-75-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W sytuacji społecznej, kiedy ceny energii są tak nieakceptowalne, warto również sięgnąć po podatek od nadzwyczajnych zysków (windfall tax), ale rozsądnie; w firmach muszą zostać środki na inwestycje - ocenił w piątek prezes prezes Urzędu Regulacji Energetyki (URE) Rafał Gawin.

## Soboń: Projekt budżetu pozwala na realizację najważniejszych priorytetów państwa
 - [https://www.bankier.pl/wiadomosc/Sobon-Projekt-budzetu-pozwala-na-realizacje-najwazniejszych-priorytetow-panstwa-8419454.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sobon-Projekt-budzetu-pozwala-na-realizacje-najwazniejszych-priorytetow-panstwa-8419454.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 18:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/6/188fae76c4f4f9-948-568-19-0-1800-1079.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prace nad projektem budżetu są bardzo zaawansowane; to budżet, który pozwala na realizację tych priorytetów, które są dziś w państwie polskim najważniejsze - powiedział  w piątek wiceminister finansów Artur Soboń.</p>

## Stan wyjątkowy w Nowym Jorku na tle kryzysu imigracyjnego
 - [https://www.bankier.pl/wiadomosc/Stan-wyjatkowy-w-Nowym-Jorku-na-tle-kryzysu-imigracyjnego-8419441.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stan-wyjatkowy-w-Nowym-Jorku-na-tle-kryzysu-imigracyjnego-8419441.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 18:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/f/0c231e20e94477-945-560-17-61-3482-2089.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Burmistrz Nowego Jorku Eric Adams ogłosił w piątek stan wyjątkowy w odpowiedzi na kryzys migracyjny, który będzie kosztował miasto 1 mld dolarów w tym roku podatkowym. Zaapelował o pomoc stanową i federalną.</p>

## MSZ Węgier: UE bardziej potrzebuje Bałkanów Zachodnich niż Bałkany Unii
 - [https://www.bankier.pl/wiadomosc/MSZ-Wegier-UE-bardziej-potrzebuje-Balkanow-Zachodnich-niz-Balkany-Unii-8419431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/MSZ-Wegier-UE-bardziej-potrzebuje-Balkanow-Zachodnich-niz-Balkany-Unii-8419431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 17:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/d/4929d16c2e984c-948-568-0-0-1736-1041.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Obecnie to Unia Europejska bardziej potrzebuje Bałkanów Zachodnich niż Bałkany Unii – powiedział w piątek minister spraw zagranicznych i handlu Węgier Peter Szijjarto podczas międzynarodowego forum bezpieczeństwa w Czarnogórze.</p>

## Gliński: Nagrody w KRRiT dla wszystkich pracowników Rady za dwa lata pracy
 - [https://www.bankier.pl/wiadomosc/Glinski-Nagrody-w-KRRiT-dla-wszystkich-pracownikow-Rady-za-dwa-lata-pracy-8419430.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Glinski-Nagrody-w-KRRiT-dla-wszystkich-pracownikow-Rady-za-dwa-lata-pracy-8419430.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 17:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/d/72ea3ccefffb7d-948-568-0-30-1754-1052.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />To nagroda dla wszystkich pracowników Krajowej Rady Radiofonii i Telewizji za dwa lata pracy –  mówił w piątek w Sejmie wicepremier, szef MKiDN Piotr Gliński odnosząc się do informacji o niemal 2 mln zł nagród dla członków i pracowników KRRiT w ostatnich dwóch latach.</p>

## Ceny prądu zamrożone. Potrzebny już tylko podpis prezydenta
 - [https://www.bankier.pl/wiadomosc/Ceny-pradu-zamrozone-Potrzebny-juz-tylko-podpis-prezydenta-8419424.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-pradu-zamrozone-Potrzebny-juz-tylko-podpis-prezydenta-8419424.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 17:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/7/0c2b2f235e1ae2-948-568-0-209-2263-1357.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm uchwalił ustawę zamrażającą ceny prądu. Do określonych limitów zużycia ceny w przyszłym roku pozostaną na niezmienionym poziomie. Zamrożone zostaną również stawki opłat dystrybucyjnych do wskazanych limitów. Ustawa trafi teraz do podpisu przez prezydenta.</p>

## Morawiecki: Cena polskiego węgla nie może być zależna od cen z Holandii
 - [https://www.bankier.pl/wiadomosc/Morawiecki-Cena-polskiego-wegla-nie-moze-byc-zalezna-od-cen-z-Holandii-8419415.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Morawiecki-Cena-polskiego-wegla-nie-moze-byc-zalezna-od-cen-z-Holandii-8419415.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 17:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/e5cd40f0c0c57d-948-568-0-0-4515-2708.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Cena węgla z krajowego wydobycia nie może być uzależniona od ceny zakupu węgla w holenderskim porcie - podkreślił w piątek premier Mateusz Morawiecki. Dodał, że trwają prace mające zapewnić uczciwe wynagrodzenie dla górników, a z drugiej, by węgiel dla energetyki nie był drogi.

## USA utrudnią produkcję i kupno chipów dla chińskiego wojska
 - [https://www.bankier.pl/wiadomosc/USA-utrudnia-produkcje-i-kupno-chipow-dla-chinskiego-wojska-8419411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-utrudnia-produkcje-i-kupno-chipow-dla-chinskiego-wojska-8419411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 17:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/72c2702cd9bcb7-948-567-0-42-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amerykańskie Biuro Przemysłu i Bezpieczeństwa (BIS) dodało 31 chińskich firm technologicznych do listy podmiotów, objętych kontrolą eksportu. Celem jest ograniczenie produkcji i kupna zaawansowanych chipów komputerowych dla chińskiego wojska.</p>

## Benefit Systems rozpoczął przegląd opcji działania dot. inwestycji w Calypso Fitness
 - [https://www.bankier.pl/wiadomosc/Benefit-Systems-rozpoczal-przeglad-opcji-dzialania-dot-inwestycji-w-Calypso-Fitness-8419396.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Benefit-Systems-rozpoczal-przeglad-opcji-dzialania-dot-inwestycji-w-Calypso-Fitness-8419396.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 17:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/58d06393f5ea1c-948-568-2-27-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Benefit Systems przeanalizuje różne scenariusze działania względem inwestycji w Calypso Fitness oraz posiadanych przez Calypso Fitness aktywów - poinformowała spółka w komunikacie.</p>

## Zarząd przymusowy w Novatek Green Energy. Co z gazem dla klientów?
 - [https://www.bankier.pl/wiadomosc/Zarzad-przymusowy-w-Novatek-Green-Energy-Co-z-pradem-dla-klientow-8419387.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zarzad-przymusowy-w-Novatek-Green-Energy-Co-z-pradem-dla-klientow-8419387.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 16:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/a/dd9f930b8af12e-948-568-0-0-2200-1319.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Minister rozwoju i technologii Waldemar Buda podjął decyzję o wprowadzeniu do Novatek Green Energy tymczasowego zarządu przymusowego - poinformował w piątek PAP resort, dodając, że pozwoli to zapewnić bezpieczeństwo energetyczne dla ponad 900 klientów spółki znajdującej się na 

## Sejm przedłużył tarczę antyinflacyjną
 - [https://www.bankier.pl/wiadomosc/Sejm-przedluzyl-tarcze-antyinflacyjna-8419379.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sejm-przedluzyl-tarcze-antyinflacyjna-8419379.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 16:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/4/0ec98bfa2d3373-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm poparł w piątek część poprawek do nowelizacji ustawy o CIT, która zawiesza na dwa lata przepisy o podatku minimalnym i wydłuża tarczę antyinflacyjną do końca 2022 r. W ustawie pozostały zapisy utrzymujące podwyższone stawki VAT 8 i 23 proc. - ich wykreślenia chcieli senato

## Bank Millennium szacuje koszt wakacji kredytowych na 1,4 mld zł
 - [https://www.bankier.pl/wiadomosc/B-Millennium-zawiaze-w-III-kw-447-mln-zl-rezerw-na-ryzyko-prawne-8419374.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/B-Millennium-zawiaze-w-III-kw-447-mln-zl-rezerw-na-ryzyko-prawne-8419374.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 16:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/b/0f0e2430df62e1-948-568-0-0-2457-1474.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bank Millennium zawiąże w III kwartale 447 mln zł rezerw na ryzyko prawne związane z walutowymi kredytami hipotecznymi udzielonymi przez bank. Dodatkowo grupa rozpoznała z góry w ciężar wyników tego okresu koszt wakacji kredytowych w wysokości 1.423 mln zł - podał bank w komuni

## Samorządowcy protestowali przeciwko drogiemu prądowi
 - [https://www.bankier.pl/wiadomosc/Samorzadowcy-protestowali-przeciwko-drogiemu-pradowi-8419362.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Samorzadowcy-protestowali-przeciwko-drogiemu-pradowi-8419362.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 16:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/059a21adbd0cbb-948-568-0-133-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zwracamy się o pilną interwencję, która pozwoli rozpocząć proces stabilizacji sytuacji na rynku energii elektrycznej - napisali do premiera Mateusza Morawieckiego samorządowcy z Ruchu "Tak! Dla Polski" oraz m.in. Związku Miast Polskich. W piątek w stolicy odbył się protest sa

## Dane z USA zdecydowały o przebiegu sesji. Bumech znów blisko miliarda kapitalizacji
 - [https://www.bankier.pl/wiadomosc/Dane-z-USA-zdecydowaly-o-przebiegu-sesji-Bumech-znow-blisko-miliarda-kapitalizacji-8419361.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dane-z-USA-zdecydowaly-o-przebiegu-sesji-Bumech-znow-blisko-miliarda-kapitalizacji-8419361.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 16:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/3/92a0f94f34fb2f-945-567-1159-148-2468-1481.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Informacje o amerykańskim rynku pracy przesądziły o wyniku sesji w piątek. Indeksy na GPW, mimo spadków, były względnie odporne na to, jak na dane w pierwszych godzinach zareagowali inwestorzy na Wall Street. Cały tydzień główne benchmarki skończyły na plusach, a gwiazdą s

## Fuzja PGNiG z PKN Orlen. Państwo zachowa kontrolę nad zasobami naturalnymi
 - [https://www.bankier.pl/wiadomosc/Fuzja-PGNiG-z-PKN-Orlen-Panstwo-zachowa-kontrole-nad-zasobami-naturalnymi-8419324.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fuzja-PGNiG-z-PKN-Orlen-Panstwo-zachowa-kontrole-nad-zasobami-naturalnymi-8419324.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 15:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/7/5f5a60c7fe9451-948-568-48-57-3157-1894-S5.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Fuzja z PKN Orlen nie grozi utratą kontroli przez państwo nad zasobami naturalnymi. Obowiązujące przepisy prawa gwarantują Skarbowi Państwa ich  własność, ale także pełny nadzór nad ich eksploatacją - zapewniło w piątek PGNiG.</p>

## Kolejny weekend bez Blika i wypłaty gotówki. Banki zapowiedziały przerwy
 - [https://www.bankier.pl/wiadomosc/Przerwy-techniczne-w-bankach-Santander-Bank-Polska-Alior-Bank-Nest-Bank-BPS-8419284.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przerwy-techniczne-w-bankach-Santander-Bank-Polska-Alior-Bank-Nest-Bank-BPS-8419284.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 15:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/ba4dd1761760fa-948-568-0-109-2189-1313.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Problemy z płatnościami online, brak dostępu do Blika i wypłaty środków z bankomatów – nadchodzący weekend minie pod znakiem utrudnień. Jak co tydzień przygotowaliśmy listę banków, które zapowiedziały planowane prace serwisowe.</p>

## Ochrona w PGG chce podwyżek. Zamierza strajkować
 - [https://www.bankier.pl/wiadomosc/Ochrona-w-PGG-chce-podwyzek-Zamierza-strajkowac-8419302.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ochrona-w-PGG-chce-podwyzek-Zamierza-strajkowac-8419302.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 15:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/f/fe2735590ecd4a-945-560-0-0-4898-2938.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 90 proc. pracowników ochrony kopalń z Grupy KOK, biorących udział w niedawnym referendum strajkowym, opowiedziało się za strajkiem w ramach trwającego w firmie sporu płacowego. Frekwencja w głosowaniu przekroczyła 70 proc. Grupa świadczy usługi głównie dla Polskiej Grupy 

## Skuza: Samorządy dostały pierwszą transzę wsparcia
 - [https://www.bankier.pl/wiadomosc/Skuza-Samorzady-dostaly-pierwsza-transza-wsparcia-8419286.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Skuza-Samorzady-dostaly-pierwsza-transza-wsparcia-8419286.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 15:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/7/47cfcad54940ce-948-568-0-26-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W piątek samorządy dostały 4,5 mld zł wsparcia, to pierwsza transza z kwoty 13,7 mld zł, którą uchwalił Sejm – powiedział podczas debaty nad projektem budżetu wiceminister finansów Sebastian Skuza.</p>

## Złożono wniosek o wydanie decyzji środowiskowej dla CPK
 - [https://www.bankier.pl/wiadomosc/Zlozono-wniosek-o-wydanie-decyzji-srodowiskowej-dla-CPK-8419263.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zlozono-wniosek-o-wydanie-decyzji-srodowiskowej-dla-CPK-8419263.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 14:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/7/04f87fa401232a-604-362-24-9-604-362.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spółka Centralny Port Komunikacyjny złożyła wniosek o wydanie decyzji środowiskowej dla lotniska oraz węzła kolejowego - poinformowali w piątek w mediach społecznościowych wiceszefowa resortu klimatu i środowiska Małgorzata Golińska oraz pełnomocnik rządu ds. CPK Marcin Horała.<

## Amerykańskie „payrollsy” zgodnie z planem. Bezrobocie najniższe od pół wieku
 - [https://www.bankier.pl/wiadomosc/Amerykanski-rynek-pracy-we-wrzesniu-2022-8419188.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Amerykanski-rynek-pracy-we-wrzesniu-2022-8419188.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 13:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/9fdc16d7f6b325-948-568-314-447-3490-2094.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wrześniowe statystyki z amerykańskiego rynku pracy wskazały
na zgodny z oczekiwaniami wzrost zatrudnienia. Stopa bezrobocia powróciła do
najniższego poziomu od przeszło pół wieku.</p>

## Deweloper budował w otulinie Kampinosu. Ukarano go... grzywną
 - [https://www.bankier.pl/wiadomosc/Deweloper-budowal-w-otulinie-Kampinosu-Ukarano-go-grzywna-8419183.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Deweloper-budowal-w-otulinie-Kampinosu-Ukarano-go-grzywna-8419183.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 13:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/9f37984dec0506-948-568-7-2-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd Rejonowy w Pruszkowie skazał prezesa spółki, która budowała osiedle w otulinie Kampinosu i rezerwatu Łosiowe Błota. Marian O. musi m.in. zapłacić 100 tys. złotych grzywny oraz wpłacić 20 tys. nawiązki na rzecz NFOŚiGW - dowiedziała się PAP.</p>

## Protokół RPP: CPI przynajmniej do połowy '23 będzie silnie podwyższona
 - [https://www.bankier.pl/wiadomosc/Protokol-RPP-CPI-przynajmniej-do-polowy-23-bedzie-silnie-podwyzszona-8419180.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Protokol-RPP-CPI-przynajmniej-do-polowy-23-bedzie-silnie-podwyzszona-8419180.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 13:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/6ff1dd8e801d5d-945-560-90-270-2053-1231.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Część RPP uważała we wrześniu, że CPI przynajmniej do połowy '23 będzie silnie podwyższona - wynika z opisu przebiegu wrześniowego posiedzenia RPP. Również część Rady wskazywała na osłabiające działanie polityki pieniężnej ze strony powszechnych wakacji kredytowych.</p>

## Senat chciał wyższych limitów taniego prądu. Komisja sejmowa przeciw
 - [https://www.bankier.pl/wiadomosc/Senat-chcial-wyzszych-limitow-taniego-pradu-Komisja-sejmowa-przeciw-8419164.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Senat-chcial-wyzszych-limitow-taniego-pradu-Komisja-sejmowa-przeciw-8419164.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 12:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/c/7683fbbf0c99b3-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejmowa komisja ds. energii opowiedziała się przeciw poprawkom Senatu podnoszącym limity zużycia energii elektrycznej w ustawie o zamrożeniu jej cen w 2023 r. Posłowie odrzucili większość merytorycznych poprawek Senatu.</p>

## Recesja i wzrost inflacji. Prognozy rządu Niemiec na 2023 r.
 - [https://www.bankier.pl/wiadomosc/Recesja-i-wzrost-inflacji-Prognozy-rzadu-Niemiec-na-2023-r-8419153.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Recesja-i-wzrost-inflacji-Prognozy-rzadu-Niemiec-na-2023-r-8419153.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 12:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/e/580fc5483f3cab-945-560-0-24-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niemiecki rząd spodziewa się w 2023 roku recesji. Z informacji, do których dotarła stacja ARD wynika, że spodziewany wzrost PKB w bieżącym roku to zaledwie 1,4 proc., a w 2023 roku niemiecka gospodarka zacznie się kurczyć. Wzrośnie również inflacja.</p>

## Budżet 2023 jak "finanse krętacza". Awantura w Sejmie
 - [https://www.bankier.pl/wiadomosc/Budzet-2023-jak-finanse-kretacza-Awantura-w-Sejmie-8419063.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Budzet-2023-jak-finanse-kretacza-Awantura-w-Sejmie-8419063.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 12:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/3/0151e3f68ccdfd-945-560-0-110-2595-1556.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Koalicja Obywatelska wniesie o odrzucenie projektu ustawy budżetowej na rok 2023 w pierwszym czytaniu- zapowiedziała w piątek Izabela Leszczyna (KO). W projekcie ustawy zapisano zawyżone dochody, zaniżone wydatki i deficyt, który "nijak się ma do deficytu budżetowego" - dodał

## Mocarne podwyżki cen paliw. Winni: OPEC i dolar
 - [https://www.bankier.pl/wiadomosc/Ceny-paliw-w-Poslce-pazdziernik-2022-8419128.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-paliw-w-Poslce-pazdziernik-2022-8419128.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 11:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/3dc19344b5af62-948-568-0-21-4380-2627.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Początek października przyniósł drakońskie podwyżki
detalicznych cen benzyn i oleju napędowego na polskich stacjach.</p>

## Bank centralny Belgii o nieuniknionej recesji. "Krótka i łagodna"
 - [https://www.bankier.pl/wiadomosc/Bank-centralny-Belgii-o-nieuniknionej-recesji-Krotka-i-lagodna-8419099.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bank-centralny-Belgii-o-nieuniknionej-recesji-Krotka-i-lagodna-8419099.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 11:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/3de308a76abbcb-948-567-0-27-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Głównym powodem recesji w Belgii, która jest nieunikniona, jest ograniczanie przez firmy produkcji ze względu na wysokie koszty energii i prac - wskazał Geert Langenus, ekonomista Belgijskiego Banku Narodowego (NBB)  dziennikowi „De Standaard”. Dodał, recesja będzie krótka i ła

## Tym będą żyły rynki: inflacyjne wątpliwości w USA i Polsce
 - [https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-inflacyjne-watpliwosci-w-USA-i-Polsce-8419036.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-inflacyjne-watpliwosci-w-USA-i-Polsce-8419036.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/1/def1f59c2e425a-948-568-97-159-1674-1004.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wstępny szacunek inflacji we wrześniu okazał się 
zaskakująco wysoki. W tym tygodniu GUS szczegółowo poinformuje, które 
towary i usługi napędzały wzrost wskaźnika. W centrum uwagi inwestorów 
globalnych również będzie inflacja, tyle że w Stanach Zjednoczonych.</p>

## Czechy wprowadzają swój podatek nadzwyczajny. Płacić go może spółka Orlenu
 - [https://www.bankier.pl/wiadomosc/Czechy-wprowadzaja-swoj-podatek-nadzwyczajny-Placic-go-moze-spolka-Orlenu-8419072.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czechy-wprowadzaja-swoj-podatek-nadzwyczajny-Placic-go-moze-spolka-Orlenu-8419072.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 10:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/1f3e274c20ab01-948-568-0-120-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czeski rząd chce opodatkować nadzwyczajne zyski energetyki, przemysłu naftowego i wydobywczego. Jedyną rafinerią działającą u naszych południowych sąsiadów jest ta wchodząca w skład Grupy Orlen.</p>

## Rząd realizuje raj podatkowy. Tak twierdzi Koalicja Polska
 - [https://www.bankier.pl/wiadomosc/Rzad-realizuje-raj-podatkowy-Tak-twierdzi-Koalicja-Polska-8419054.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-realizuje-raj-podatkowy-Tak-twierdzi-Koalicja-Polska-8419054.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 10:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/9/0705b0783498d9-945-560-0-56-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Europejska rozluźniła możliwości wydatkowe jeśli chodzi o budżet, ale to nie oznacza tworzenia raju podatkowego; taki raj podatkowy rząd realizuje - powiedział w piątek w Sejmie Czesław Siekierski (Koalicja Polska), prezentując stanowisko klubu do projektu budżetu na 2

## Irlandia mówi „nie” pustostanom. Rząd nałoży nowy podatek na właścicieli mieszkań
 - [https://www.bankier.pl/wiadomosc/Irlandia-mowi-nie-pustostanom-Rzad-nalozy-nowy-podatek-na-wlascicieli-mieszkan-8419046.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Irlandia-mowi-nie-pustostanom-Rzad-nalozy-nowy-podatek-na-wlascicieli-mieszkan-8419046.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 10:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/91a5570e0c7c70-945-560-7-172-2977-1786.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Irlandzki rząd wypowiada wojnę pustostanom i krótkoterminowemu najmowi. W ograniczeniu liczby niezamieszkałych lokali pomóc ma nowy podatek, który zacznie obowiązywać już w przyszłym roku.
</p>

## Są warunki do dalszych podwyżek stóp proc. w Polsce, ale RPP jest gołębia
 - [https://www.bankier.pl/wiadomosc/Sa-warunki-do-dalszych-podwyzek-stop-proc-w-Polsce-ale-RPP-jest-golebia-8419034.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sa-warunki-do-dalszych-podwyzek-stop-proc-w-Polsce-ale-RPP-jest-golebia-8419034.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 10:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/4/a4ae37b64f88cb-948-568-65-195-1885-1130.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada Polityki Pieniężnej prawdopodobnie nie zakończyła jeszcze cyklu podwyżek stóp - miałyby one raczej charakter dostrajający, choć są ryzyka po stronie mocnego wznowienia cyklu - oceniają ekonomiści. Niektóre ośrodki analityczne sądzą, że Rada bez względu na wyniki listopa

## We Francji brakuje paliwa. Kilometrowe kolejki samochodów do stacji
 - [https://www.bankier.pl/wiadomosc/We-Francji-brakuje-paliwa-Kilometrowe-kolejki-samochodow-do-stacji-8419030.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/We-Francji-brakuje-paliwa-Kilometrowe-kolejki-samochodow-do-stacji-8419030.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 09:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/e/85775876aee5a5-948-568-11-99-2189-1313.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na wielu stacjach benzynowych we Francji ustawiają się od kilku dni kilometrowe kolejki samochodów. Około 15 proc. stacji w kraju nie ma paliwa, głównie z powodu strajków na tle płacowym w koncernach naftowych.</p>

## Zmiana na stanowisku prezesa PERN. Nowym szefem spółki Paweł Stańczyk
 - [https://www.bankier.pl/wiadomosc/Zmiana-na-stanowisku-prezesa-PERN-Nowym-szefem-spolki-Pawel-Stanczyk-8419031.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zmiana-na-stanowisku-prezesa-PERN-Nowym-szefem-spolki-Pawel-Stanczyk-8419031.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 09:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/8/665584a26489fc-948-568-0-48-3840-2303.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nadzwyczajne Walne Zgromadzenie PERN odwołało z funkcji prezesa spółki Igora Wasilewskiego i jednocześnie powołało na to stanowisko Pawła Stańczyka, który ostatnio był prezesem zarządu spółki Grupa Azoty Zakłady Azotowe Kędzierzyn. Stanowisko prezesa PERN Stańczyk objął 7 paźd

## Tusk: mówi się, że samorządy mają dystrybuować węgiel, ale węgla nie ma
 - [https://www.bankier.pl/wiadomosc/Tusk-mowi-sie-ze-samorzady-maja-dystrybuowac-wegiel-ale-wegla-nie-ma-8419016.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tusk-mowi-sie-ze-samorzady-maja-dystrybuowac-wegiel-ale-wegla-nie-ma-8419016.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 09:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/de879bab5200f9-948-568-640-150-2333-1400.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mówi się, że samorządy mają dystrybuować węgiel, tylko rząd nie zrobił niczego, żeby węgiel był dostępny; węgla nie ma, a kiedy się pojawia, to jest w cenach nie do zaakceptowania - mówił w piątek Lider PO Donald Tusk. Dodał, że rząd obwiniania wszystkich odpowiedzialnością

## Trzy lata złotego milczenia Chin
 - [https://www.bankier.pl/wiadomosc/Trzy-lata-zlotego-milczenia-Chin-8418971.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trzy-lata-zlotego-milczenia-Chin-8418971.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/7/c1d1b4f4a23cd9-948-568-0-0-4339-2603.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od trzech lat chiński bank centralny nie raportuje zmiany rezerw złota. 
To jednak nie oznacza, że nie gromadzi "królewskiego metalu". W 
przeszłości Chińczycy "przypominali sobie" o setkach ton złota co kilka 
lat.</p>

## Manifestacja Solidarności nie jest "przeciwko rządowi"
 - [https://www.bankier.pl/wiadomosc/Manifestacja-Solidarnosci-w-Warszawie-nie-jest-przeciwko-rzadowi-8419003.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Manifestacja-Solidarnosci-w-Warszawie-nie-jest-przeciwko-rzadowi-8419003.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 09:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/b/59ded470216b8b-948-568-0-0-1024-614.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Solidarność zdecydowała o zorganizowaniu 17 listopada protestu w Warszawie. W ocenie związku propozycje rządu nie gwarantują skutecznej realizacji jego postulatów. Nie szykujemy protestu przeciwko rządowi, ale na rzecz realizacji naszych postulatów – przekazał szef związku Piotr

## Poczta Polska przyznała podwyżki swoim pracownikom. Tuż po podwyżkach dla klientów
 - [https://www.bankier.pl/wiadomosc/Poczta-Polska-daje-podwyzki-pracownikom-8418996.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Poczta-Polska-daje-podwyzki-pracownikom-8418996.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 09:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/b/0f112f9d220849-945-560-2-5-1149-689.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poczta Polska przyzna swoim pracownikom podwyżki. Wyższe wynagrodzenia wpłyną na ich konta już od 1 grudnia 2022 r. To nie jedyna zmiana w finansach spółki skarbu państwa, ponieważ od tygodnia obowiązują wyższe ceny dla klientów.</p>

## Absolwenci tego kierunku zarabiają 12 tys. zł po studiach. Nie jest to informatyka
 - [https://www.bankier.pl/wiadomosc/Zarabiaja-12-tys-zl-po-studiach-Nie-jest-to-informatyka-8418931.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zarabiaja-12-tys-zl-po-studiach-Nie-jest-to-informatyka-8418931.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 08:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/8/52ab7a26ff6410-948-568-0-143-3027-1816.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Studenci kilku polskich uczelni już w pierwszym roku po ukończeniu studiów zarabiają pięciocyfrowe kwoty. Najwyższe miesięczne wynagrodzenie wynosi 12048,25 zł – wynika z danych ogólnopolskiego systemu monitorowania ekonomicznych losów absolwentów szkół wyższych (ELA).</p>

## Na GPW będzie można kupić akcje BMW i Mercedesa w polskiej walucie. Rusza GlobalConnect
 - [https://www.bankier.pl/wiadomosc/GPW-planuje-start-nowego-rynku-spolek-zagranicznych-GlobalConnect-na-4-XI-8418967.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/GPW-planuje-start-nowego-rynku-spolek-zagranicznych-GlobalConnect-na-4-XI-8418967.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 08:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/1/c13e3174d42b18-948-568-74-119-1917-1150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już wkrótce w Warszawie ruszy rynek akcji spółek zagranicznych GlobalConnect. Według komunikatu GPW, od 4 listopada będzie można inwestować w akcje znanych spółek w polskich złotych.</p>

## "Odpowiedzialny i ambitny". Rzeczkowska o projekcie budżetu na 2023 r.
 - [https://www.bankier.pl/wiadomosc/Rzeczkowska-W-przyszlym-roku-tempo-wzrostu-PKB-spadnie-do-1-7-proc-8418964.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzeczkowska-W-przyszlym-roku-tempo-wzrostu-PKB-spadnie-do-1-7-proc-8418964.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 08:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/1/7f81cba8afe8fb-948-568-60-44-2940-1763.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2022 realny PKB wzrośnie o 4,6 proc., a w przyszłym roku nastąpi pogorszenie sytuacji gospodarczej. Przewidujemy obniżenie tempa wzrostu PKB do 1,7 proc. – powiedziała w piątek w Sejmie minister finansów Magdalena Rzeczkowska.</p>

## Walka z wiatrakami: politycznie nieopłacalna, a dla Polaków kosztowna
 - [https://www.bankier.pl/wiadomosc/Walka-z-wiatrakami-politycznie-nieoplacalna-a-dla-Polakow-kosztowna-8418966.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Walka-z-wiatrakami-politycznie-nieoplacalna-a-dla-Polakow-kosztowna-8418966.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 08:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/c/d509ac0b12c767-948-567-0-5-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już prawie trzy miesiące w sejmowej zamrażarce leży rządowy projekt nowelizacji tzw. ustawy
odległościowej. Choć badania opinii społecznej pokazują duże poparcie dla lądowej energetyki
wiatrowej, a dane rynkowe jej mocny wpływ na obniżanie cen energii, to antywiatrakowe
środowis

## Paweł Dobrowolski: czeka nas kilka dekad podwyższonej inflacji
 - [https://www.bankier.pl/wiadomosc/Pawel-Dobrowolski-czeka-nas-kilka-dekad-podwyzszonej-inflacji-8418958.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pawel-Dobrowolski-czeka-nas-kilka-dekad-podwyzszonej-inflacji-8418958.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 08:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/3/2dd2c79c2f8180-948-568-15-45-985-591.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czeka nas kilka dekad podwyższonej inflacji - powiedział w piątek w RMF FM główny ekonomista Polskiego Funduszu Rozwoju Paweł Dobrowolski. Jego zdaniem można by zbić szybko inflację do poziomu jednocyfrowego, ale kosztem dwucyfrowego bezrobocia.</p>

## Ponad połowa ukraińskich czołgów to te zdobyte w walce
 - [https://www.bankier.pl/wiadomosc/Ponad-polowa-ukrainskich-czolgow-to-te-zdobyte-w-walce-8418957.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ponad-polowa-ukrainskich-czolgow-to-te-zdobyte-w-walce-8418957.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 08:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/2f476b3be8e870-948-568-20-80-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dużą część sprzętu ukraińskiego wojska stanowi ten zdobyty w walce, a w przypadku czołgów jest to ponad połowa; to, że siły rosyjskie nie niszczą ich zanim wpadną w ręce ukraińskie, źle świadczy o wyszkoleniu Rosjan - przekazało w piątek brytyjskie ministerstwo obrony.</p>

## Premier prosi samorządowców o pomoc. "Od tego zależy bezpieczeństwo"
 - [https://www.bankier.pl/wiadomosc/Premier-prosi-samorzadowcow-o-pomoc-Od-tego-zalezy-bezpieczenstwo-8418950.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-prosi-samorzadowcow-o-pomoc-Od-tego-zalezy-bezpieczenstwo-8418950.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 08:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/b/4f2b4db52c89f9-948-568-5-0-960-576.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Potrzebujemy pełnej współpracy ws. bezpieczeństwa energetycznego polskich rodzin - podkreślił premier Mateusz Morawiecki w liście do prezydentów miast i samorządowców.</p>

## Prezes Glapiński i RPP nie mają litości dla polskiej waluty. Dolar znów po 5 zł
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-zmierza-do-okraglego-poziomu-dolar-znow-po-5-zl-8418940.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-zmierza-do-okraglego-poziomu-dolar-znow-po-5-zl-8418940.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 08:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/8/085e6ba0f3dfd7-948-568-0-241-3708-2224.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od środowej decyzji RPP ws. utrzymania stóp procentowych złoty stracił 
do euro blisko 10 groszy, a do dolara ponad 15 groszy. Tymczasem prezes 
NBP bagatelizuje osłabienie polskiej waluty.</p>

## NSZZ "Solidarność" się buntuje i chce, by rząd z nią rozmawiał
 - [https://www.bankier.pl/wiadomosc/NSZZ-Solidarnosc-sie-buntuje-i-chce-by-rzad-z-nia-rozmawial-8418934.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NSZZ-Solidarnosc-sie-buntuje-i-chce-by-rzad-z-nia-rozmawial-8418934.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 07:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/1/f0953c397f53a2-948-568-0-0-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W piątek odbędzie się nadzwyczajne posiedzenie Komisji Krajowej NSZZ "Solidarność”. Będziemy decydować o dalszych działaniach, aby rząd usiadł i zaczął faktycznie z nami rozmawiać, a nie tylko przekazywać, co ma zamiar zrobić – powiedział w piątek przewodniczącym NSZZ "Solidarn

## Adam Glapiński ponownie jednym z najgorszych bankierów centralnych Europy
 - [https://www.bankier.pl/wiadomosc/Adam-Glapinski-ponownie-jednym-z-najgorszych-bankierow-centralnych-Europy-8418899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Adam-Glapinski-ponownie-jednym-z-najgorszych-bankierow-centralnych-Europy-8418899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 07:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/a/b19ce8d2f716fa-948-568-0-28-3758-2254.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Adam Glapiński tradycyjnie znalazł się wśród najniżej ocenianych szefów 
banków centralnych Europy w rankingu przygotowanym przez magazyn "Global
 Finance".</p>

## Tak mocnego tygodniowego wzrostu cen ropy nie było od początku marca
 - [https://www.bankier.pl/wiadomosc/Tak-mocnego-tygodniowego-wzrostu-cen-ropy-nie-bylo-od-poczatku-marca-8418917.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tak-mocnego-tygodniowego-wzrostu-cen-ropy-nie-bylo-od-poczatku-marca-8418917.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 07:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/d/bafeaa7ebd18c7-948-567-0-22-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy naftowej na rynkach paliw wzrosły w tym tygodniu najmocniej od początku marca po środowej decyzji OPEC+ o zmniejszenia dostaw surowca, co zacieśni już i tak napiętą sytuację na globalnych rynkach paliw przed zbliżającą się zimą - podają maklerzy.</p>

## PGE sprzedaje węgiel po "rozsądnej", niekoniecznie rynkowej, cenie
 - [https://www.bankier.pl/wiadomosc/PGE-sprzedaje-wegiel-po-rozsadnej-cenie-Prezes-wyjasnia-po-ile-8418898.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PGE-sprzedaje-wegiel-po-rozsadnej-cenie-Prezes-wyjasnia-po-ile-8418898.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 06:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/5/f263e2c88ade34-945-560-0-101-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sprzedajemy węgiel w cenie 2100 zł netto za tonę i zależy nam, żeby do odbiorców indywidualnych trafiał on w rozsądnej cenie, a więc poniżej 3000 zł brutto - powiedział "Rzeczpospolitej" prezes PGE Wojciech Dąbrowski.</p>

## Prezydent Wrocławia kupił dom z basenem
 - [https://www.bankier.pl/wiadomosc/Prezydent-Wroclawia-kupil-dom-z-basenem-8418882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezydent-Wroclawia-kupil-dom-z-basenem-8418882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 05:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/308fd48859531d-948-568-414-342-1005-603.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad półtora miliona złotych kosztował zabytkowy dom, który kupił prezydent Wrocławia Jacek Sutryk. Polityk nabył nieruchomość na ekskluzywnym osiedlu Sępolno, na którym mieszkanie jest marzeniem wielu wrocławian - pisze w piątek "Super Express".</p>

## Deweloperski Fundusz Gwarancyjny. Nie każdy się załapie na ochronę funduszu
 - [https://www.bankier.pl/wiadomosc/Deweloperski-Fundusz-Gwarancyjny-Kto-sie-nie-zalapie-na-ochrone-funduszu-8418876.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Deweloperski-Fundusz-Gwarancyjny-Kto-sie-nie-zalapie-na-ochrone-funduszu-8418876.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 05:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/9/31816251349780-948-568-0-79-1982-1189.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Deweloperski Fundusz Gwarancyjny nie ochroni nabywcy nowego mieszkania z drugiej ręki ani przedsiębiorcy, który kupi nowy lokal pod działalność gospodarczą - mówi PAP Renata Mentlewicz z Ubezpieczeniowego Funduszu Gwarancyjnego.</p>

## Putin kończy w piątek 70 lat. "Zanim został szpiegiem, był gangsterem"
 - [https://www.bankier.pl/wiadomosc/Putin-konczy-w-piatek-70-lat-Zanim-zostal-szpiegiem-byl-gangsterem-8418875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Putin-konczy-w-piatek-70-lat-Zanim-zostal-szpiegiem-byl-gangsterem-8418875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 05:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/1/4299f985417651-948-568-0-70-1753-1051.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Putin sprawuje władzę od ponad 22 lat, a to spowodowało przegnicie wszystkich instytucji w Rosji. Zanim został szpiegiem, był gangsterem. Co robią gangsterzy? Pilnują, by nie było nowych ludzi poza tymi, z którymi dorastali. W Rosji nie ma żadnych instytucji, które mogłyby za

## Rozszerzenie NATO pod znakiem zapytania. Turcja stawia warunki
 - [https://www.bankier.pl/wiadomosc/Rozszerzenie-NATO-pod-znakiem-zapytania-Turcja-stawia-warunki-8418871.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rozszerzenie-NATO-pod-znakiem-zapytania-Turcja-stawia-warunki-8418871.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 05:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/0be015866fedae-948-568-0-93-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Turcji Recep Tayyip Erdogan powiedział w czwartek, że Ankara będzie nadal sprzeciwiać się staraniom Szwecji o członkostwo w NATO, dopóki nie zostaną spełnione żądania Turcji dotyczące zaostrzenia szwedzkiego stanowiska wobec "organizacji terrorystycznych".</p>

## Wody Polskie odpierają zarzuty. "Nie betonujemy Odry"
 - [https://www.bankier.pl/wiadomosc/Wody-Polskie-odpieraja-zarzuty-Nie-betonujemy-Odry-8418868.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wody-Polskie-odpieraja-zarzuty-Nie-betonujemy-Odry-8418868.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 05:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/4/5bb2eb87e9b19d-948-568-0-52-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inwestycje na Odrze mają sprawić, by nie wypłycała się i nie pogłębiała, nie zmieniła koryta, a woda miała swobodny przepływ; poprawi to bezpieczeństwo przeciwpowodziowe - mówi PAP wiceszef Wód Polskich Wojciech Skowyrski. Rzeka nie będzie pogłębiana ani betonowana - dodaje.</p

## Jak oszczędzać prąd w domu? Podpowiadamy
 - [https://www.bankier.pl/wiadomosc/Jak-oszczedzac-prad-w-domu-Podpowiadamy-8414557.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jak-oszczedzac-prad-w-domu-Podpowiadamy-8414557.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/17e782dc89d725-948-568-0-0-4000-2400.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Widmo drastycznych podwyżek cen prądu w przyszłym roku, które częściowo ma zniwelować Tarcza solidarnościowa, może skłonić wiele gospodarstw domowych do oszczędności. Ciężko będzie zrezygnować z lodówki, która jest jednym z najbardziej energochłonnych sprzętów AGD. Jak można wi

## Katastrofalna sprzedaż mieszkań. Deweloperzy pokazują liczby
 - [https://www.bankier.pl/wiadomosc/Katastrofalna-sprzedaz-mieszkan-Deweloperzy-pokazuja-liczby-8418431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Katastrofalna-sprzedaz-mieszkan-Deweloperzy-pokazuja-liczby-8418431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/6ce8329f0e77e8-948-568-0-22-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sprzedaż mieszkań raportowana przez giełdowych deweloperów spada w sposób gwałtowny. Liczby pokazane po trzecim kwartale wskazują na mocne tąpniecie, zwłaszcza wśród największych graczy. Branżowy indeks zaliczył na koniec września minimum trwającej bessy.</p>

## Najlepsze lokaty dla każdego – do wyboru 6 minirankingów. Prześwietlamy promocje
 - [https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-dla-kazdego-do-wyboru-6-minirankingow-Przeswietlamy-promocje-8418578.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-dla-kazdego-do-wyboru-6-minirankingow-Przeswietlamy-promocje-8418578.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/1/f4644bf4bb458a-948-568-855-81-1947-1168.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pewnie słyszeliście, że październik ochrzczono mianem miesiąca oszczędzania? A skoro kalendarz sprzyja i sprzyjają stopy procentowe, idźmy w to. Przed nami pierwszy odcinek miniserialu dla poszukujących okazji do oszczędzania. Na lokatach, kontach oszczędnościowych, a nawet 

## Włamali się, okradli i… zamknęli za sobą drzwi. Ubezpieczyciel odmówił wypłaty odszkodowania
 - [https://www.bankier.pl/wiadomosc/Wlamali-sie-okradli-i-zamkneli-za-soba-drzwi-Ubezpieczyciel-odmowil-wyplaty-odszkodowania-8418416.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wlamali-sie-okradli-i-zamkneli-za-soba-drzwi-Ubezpieczyciel-odmowil-wyplaty-odszkodowania-8418416.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/c5ed0655f06099-948-568-7-27-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nasza czytelniczka po powrocie z urlopu zastała zdemolowane mieszkanie. Doszło do włamania, ale złodzieje otworzyli zamki, nie zostawiając śladów fizycznej ingerencji. Policja uznała zdarzenie za kradzież z włamaniem. Ubezpieczyciel za „kradzież zwykłą” - i odmówił wypłaty odszk

## Grupa Wagnera drenuje Afrykę. Tak Rosja ma finansować wojnę na Ukrainie
 - [https://www.bankier.pl/wiadomosc/Grupa-Wagnera-drenuje-Afryke-Tak-Rosja-ma-finansowac-wojne-na-Ukrainie-8418854.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Grupa-Wagnera-drenuje-Afryke-Tak-Rosja-ma-finansowac-wojne-na-Ukrainie-8418854.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 02:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/0d0a7526d27d3a-763-457-0-408-763-457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stany Zjednoczone oskarżyły w czwartek rosyjskich najemników wojskowych o eksploatację zasobów naturalnych w Republice Środkowoafrykańskiej, Mali, Sudanie i innych afrykańskich krajach w celu sfinansowania wojny Moskwy na Ukrainie.</p>

## Zegar tyka. Sąd dał Elonowi Muskowi czas na sfinalizowania zakupu Twittera
 - [https://www.bankier.pl/wiadomosc/Zegar-tyka-Sad-dal-Elonowi-Muskowi-czas-na-sfinalizowania-zakupu-Twittera-8418853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zegar-tyka-Sad-dal-Elonowi-Muskowi-czas-na-sfinalizowania-zakupu-Twittera-8418853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-07 01:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/6/5c8cfe520eb3f5-948-568-60-28-1812-1087.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd w stanie Delaware w USA wstrzymał w czwartek proces z pozwu platformy społecznościowej Twitter Inc przeciwko Elonowi Muskowi, który dzień wcześniej oświadczył, że jest gotów kupić Twittera za pierwotnie uzgodnioną z serwisem cenę 44 mld dolarów.</p>


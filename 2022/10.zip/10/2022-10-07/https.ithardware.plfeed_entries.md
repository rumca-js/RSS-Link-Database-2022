# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Google Chrome to nie tylko najpopularniejsza przeglądarka, ale też najbardziej podatna na ataki
 - [https://ithardware.pl/aktualnosci/google_chrome_to_nie_tylko_najpopularniejsza_przegladarka_ale_tez_najbardziej_podatna_na_ataki-23732.html](https://ithardware.pl/aktualnosci/google_chrome_to_nie_tylko_najpopularniejsza_przegladarka_ale_tez_najbardziej_podatna_na_ataki-23732.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 21:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/23732_1.jpg" />            Google Chrome to najpopularniejsza przeglądarka internetowa, przez co jest najbardziej zagrożona na cyberataki, tak przynajmniej wynika z zestawienia&nbsp;VulDB.

Google Chrome kontroluje większość rynku i według r&oacute;żnych firm...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/google_chrome_to_nie_tylko_najpopularniejsza_przegladarka_ale_tez_najbardziej_podatna_na_ataki-23732.html">https:/

## TSMC osiągnęło rekordowe przychody. Firmy nie powstrzymało nawet zmniejszenie popytu
 - [https://ithardware.pl/aktualnosci/tsmc_osiagnelo_rekordowe_przychody_firmy_nie_powstrzymalo_nawet_zmniejszenie_popytu-23729.html](https://ithardware.pl/aktualnosci/tsmc_osiagnelo_rekordowe_przychody_firmy_nie_powstrzymalo_nawet_zmniejszenie_popytu-23729.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 20:05:20+00:00

<img src="https://ithardware.pl/artykuly/min/23729_1.jpg" />            Pomimo zmniejszenia&nbsp;popytu, w trzecim kwartale bieżącego roku, przychody TSMC osiągnęły rekordowy poziom, czyli&nbsp;19,4 mld USD. Firma podała, że wyniki w trzecim kwartale&nbsp;były o 48% wyższe rok do roku. Jednym z powod&oacute;w, dla...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tsmc_osiagnelo_rekordowe_przychody_firmy_nie_powstrzymalo_nawet_zmniejszenie_popytu-23729.html">https:/

## Electronic Arts uśmierca klienta Origin i zaprasza do instalacji EA app
 - [https://ithardware.pl/aktualnosci/electronic_arts_usmierca_klienta_origin_i_zaprasza_do_instalacji_ea_app-23731.html](https://ithardware.pl/aktualnosci/electronic_arts_usmierca_klienta_origin_i_zaprasza_do_instalacji_ea_app-23731.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 19:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/23731_1.jpg" />            Origin, kt&oacute;ry zadebiutował w 2011 roku przechodzi do historii i zostanie zastąpiony przez testowany od jakiegoś czasu program EA app, o czym poinformowało Electronic Arts.

Origin konkurencyjna platforma dla Steam ma na karku ponad 11 lat,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/electronic_arts_usmierca_klienta_origin_i_zaprasza_do_instalacji_ea_app-23731.html">https://ithardwa

## General Motors stworzy prototyp akumulatorów Ultium dla armii amerykańskiej
 - [https://ithardware.pl/aktualnosci/general_motors_stworzy_prototyp_akumulatorow_ultium_dla_armii_amerykanskiej-23730.html](https://ithardware.pl/aktualnosci/general_motors_stworzy_prototyp_akumulatorow_ultium_dla_armii_amerykanskiej-23730.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 18:49:20+00:00

<img src="https://ithardware.pl/artykuly/min/23730_1.jpg" />            General Motors poprzez swoją sp&oacute;łkę,&nbsp;GM Defense, stworzy dla armii amerykańskiej prototyp zestawu akumulator&oacute;w Ultium. Departament Obrony ma wykorzystać je do test&oacute;w oraz analiz.&nbsp;Dział ds. Innowacji Obronnych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/general_motors_stworzy_prototyp_akumulatorow_ultium_dla_armii_amerykanskiej-23730.html">https://ithardware.

## Noctua zaktualizowała mapę rozwoju produktów. Dodano nowe chłodzenie dla platformy AM5
 - [https://ithardware.pl/aktualnosci/noctua_zaktualizowala_mape_rozwoju_produktow_dodano_nowe_chlodzenie_dla_platformy_am5-23726.html](https://ithardware.pl/aktualnosci/noctua_zaktualizowala_mape_rozwoju_produktow_dodano_nowe_chlodzenie_dla_platformy_am5-23726.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 17:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/23726_1.jpg" />            Noctua dokonała aktualizacji&nbsp;publicznego planu rozwoju swoich produkt&oacute;w. Chłodzenie&nbsp;NH-D15 nowej generacji ma zadebiutować&nbsp;w pierwszym kwartale przyszłego roku. W&nbsp;czwartym kwartale 2022 roku pojawić ma się osłona pasty...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/noctua_zaktualizowala_mape_rozwoju_produktow_dodano_nowe_chlodzenie_dla_platformy_am5-23726.html">htt

## Rosja wycofuje się z "narodowego silnika gier". Kraju nie stać na taką inwestycję
 - [https://ithardware.pl/aktualnosci/rosja_wycofuje_sie_z_narodowego_silnika_gier_kraju_nie_stac_na_taka_inwestycje-23727.html](https://ithardware.pl/aktualnosci/rosja_wycofuje_sie_z_narodowego_silnika_gier_kraju_nie_stac_na_taka_inwestycje-23727.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 16:53:50+00:00

<img src="https://ithardware.pl/artykuly/min/23727_1.jpg" />            Rosja planowała stworzyć własny silnik gier, kt&oacute;ry nie tylko zastąpiłby krajowym grom Unreal Engine i Unity, ale także rzuciłby rękawice&nbsp;gigantom. Ambicje kraju rządzonego przez Władimira Putina spotkały się jednak z brutalną...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rosja_wycofuje_sie_z_narodowego_silnika_gier_kraju_nie_stac_na_taka_inwestycje-23727.html">https://ithardware

## Laptop Acer Swift Edge z procesorem AMD Ryzen Pro. Lekki i jednocześnie wydajny?
 - [https://ithardware.pl/aktualnosci/laptop_acer_swift_edge_z_procesorem_amd_ryzen_pro_lekki_i_jednoczesnie_wydajny-23725.html](https://ithardware.pl/aktualnosci/laptop_acer_swift_edge_z_procesorem_amd_ryzen_pro_lekki_i_jednoczesnie_wydajny-23725.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 15:06:40+00:00

<img src="https://ithardware.pl/artykuly/min/23725_1.jpg" />            Acer postanowił dodać swojemu&nbsp;ultraprzenośnemu laptopowi trochę profesjonalizmu. Model&nbsp;Swift Edge będzie dostępny do kupienia w wersji&nbsp;z procesorem AMD Ryzen&nbsp;7 Pro 6850U. Ten 16-calowy notebook waży zaledwie&nbsp;1,17 kg....
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/laptop_acer_swift_edge_z_procesorem_amd_ryzen_pro_lekki_i_jednoczesnie_wydajny-23725.html">https://ithard

## Inżynier NVIDII zademonstrował prototypowe radiatory i wentylatory GeForce'a RTX 4090
 - [https://ithardware.pl/aktualnosci/inzynier_nvidii_zademonstrowal_prototypowe_radiatory_i_wentylatory_geforce_a_rtx_4090-23724.html](https://ithardware.pl/aktualnosci/inzynier_nvidii_zademonstrowal_prototypowe_radiatory_i_wentylatory_geforce_a_rtx_4090-23724.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 14:08:00+00:00

<img src="https://ithardware.pl/artykuly/min/23724_1.jpg" />            Do sieci trafił materiał wideo, w kt&oacute;rym udział wziął inżynier termiczny NVIDII. Przyni&oacute;sł on ze sobą kilka prototyp&oacute;w układu&nbsp;chłodzenia oraz wentylator&oacute;w&nbsp;dla kart graficznych GeForce RTX 4090. Na nagraniu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/inzynier_nvidii_zademonstrowal_prototypowe_radiatory_i_wentylatory_geforce_a_rtx_4090-23724.html">https

## Test smartfona Asus Zenfone 9, czyli małe może... jeszcze więcej!
 - [https://ithardware.pl/testyirecenzje/test_smartfona_asus_zenfone_9_czyli_male_moze_jeszcze_wiecej-23712.html](https://ithardware.pl/testyirecenzje/test_smartfona_asus_zenfone_9_czyli_male_moze_jeszcze_wiecej-23712.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 12:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/23712_1.jpg" />            Asus Zenfone 9 to prawdziwy potw&oacute;r, tylko&hellip; taki malutki

Asus już ubiegłorocznym modelem Zenfone 8 udowadniał, że pozory mylą i w najbardziej nawet kompaktowej obudowie można upchnąć high-endową specyfikację, dla kt&oacute;rej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/test_smartfona_asus_zenfone_9_czyli_male_moze_jeszcze_wiecej-23712.html">https://ithardware.pl/testyire

## GeForce RTX 4090 - producenci autorskich wersji zalecają zasilacze o mocy nawet 1200 W
 - [https://ithardware.pl/aktualnosci/geforce_rtx_4090_producenci_autorskich_wersji_zalecaja_nawet_zasilacze_o_mocy_1200_w-23719.html](https://ithardware.pl/aktualnosci/geforce_rtx_4090_producenci_autorskich_wersji_zalecaja_nawet_zasilacze_o_mocy_1200_w-23719.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 11:16:01+00:00

<img src="https://ithardware.pl/artykuly/min/23719_1.jpg" />            Nie jest tajemnicą, że GeForce RTX 4090 będzie wymagał bardzo mocnego zasilacza. Ten model podąża bowiem śladami GeForce'a RTX 3090 Ti i spodziewamy się, że wkr&oacute;tce rozsiądzie się na tronie gamingowych kart graficznych, dzierżąc...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_4090_producenci_autorskich_wersji_zalecaja_nawet_zasilacze_o_mocy_1200_w-23719.html">https://ithard

## Tesla rezygnuje z kolejnych czujników i stawia wszystko na kamery. Czy to dobry krok?
 - [https://ithardware.pl/aktualnosci/tesla_rezygnuje_z_kolejnych_czujnikow_i_stawia_wszystko_na_kamery_czy_to_dobry_krok-23723.html](https://ithardware.pl/aktualnosci/tesla_rezygnuje_z_kolejnych_czujnikow_i_stawia_wszystko_na_kamery_czy_to_dobry_krok-23723.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 10:16:20+00:00

<img src="https://ithardware.pl/artykuly/min/23723_1.jpg" />            Tesla zdecydowała się na kolejny odważny krok, kt&oacute;ry może nie spotkać się z przychylnością użytkownik&oacute;w. Z samochod&oacute;w zniknie kolejny rodzaj czujnik&oacute;w, kt&oacute;ry zastąpiony zostanie systemem kamer Tesla...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tesla_rezygnuje_z_kolejnych_czujnikow_i_stawia_wszystko_na_kamery_czy_to_dobry_krok-23723.html">https://ithardwar

## Spider-Man Remastered, Hitman 3 i 3 inne gry z obsługą Intel XeSS
 - [https://ithardware.pl/aktualnosci/spider_man_remastered_hitman_3_i_3_inne_gry_z_obsluga_intel_xess-23720.html](https://ithardware.pl/aktualnosci/spider_man_remastered_hitman_3_i_3_inne_gry_z_obsluga_intel_xess-23720.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 10:03:01+00:00

<img src="https://ithardware.pl/artykuly/min/23720_1.jpg" />            Lista gier obsługujących technologię temporalnego upscalingu Intela rośnie z dnia na dzień. Ta jest już wspierana przez kolejne pięć tytuł&oacute;w, a karty z serii Arc A700 wciąż nie zadebiutowały jeszcze na rynku.&nbsp;

W 24 godziny...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/spider_man_remastered_hitman_3_i_3_inne_gry_z_obsluga_intel_xess-23720.html">https://ithardware.pl/aktualnosci/

## Steam Deck do kupienia od ręki. Vlave wypuściło też własną stację dokującą
 - [https://ithardware.pl/aktualnosci/steam_deck_do_kupienia_od_reki_vlave_wypuscilo_tez_wlasna_stacje_dokujaca-23718.html](https://ithardware.pl/aktualnosci/steam_deck_do_kupienia_od_reki_vlave_wypuscilo_tez_wlasna_stacje_dokujaca-23718.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 09:10:01+00:00

<img src="https://ithardware.pl/artykuly/min/23718_1.jpg" />            Valve ogłosił, że osoby zainteresowane zakupem Steam Deck nie muszą już czekać w kolejce, aby nabyć sprzęt. Jednocześnie długo oczekiwana oficjalna stacja dokująca Steam Deck jest już dostępna i to r&oacute;wnież bez kolejki...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/steam_deck_do_kupienia_od_reki_vlave_wypuscilo_tez_wlasna_stacje_dokujaca-23718.html">https://ithardware.pl/aktualnosci/st

## Samsung opracował pamięci GDDR7 o prędkości 36 Gb/s dla przyszłych GPU
 - [https://ithardware.pl/aktualnosci/samsung_opracowal_pamieci_gddr7_o_predkosci_36_gb_s_dla_przyszlych_gpu-23721.html](https://ithardware.pl/aktualnosci/samsung_opracowal_pamieci_gddr7_o_predkosci_36_gb_s_dla_przyszlych_gpu-23721.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 08:29:01+00:00

<img src="https://ithardware.pl/artykuly/min/23721_1.jpg" />            Samsung ujawnił swoje plany dotyczące rozwiązań DRAM i pamięci nowej generacji, w tym GDDR7, DDR5, LPDDR5X i V-NAND.

Firma nie zamierza zmniejszać swoich nakład&oacute;w na rozw&oacute;j pamięci, gdyż jest przekonana, że jest to niezbędne...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_opracowal_pamieci_gddr7_o_predkosci_36_gb_s_dla_przyszlych_gpu-23721.html">https://ithardware.pl/ak

## ASUS prezentuje nowe laptopy z procesorami Intel Core 12. generacji. Jest MOC!
 - [https://ithardware.pl/aktualnosci/niezrownana_wydajnosc_notebookow_asus_na_rok_2022_napedzana_najnowszymi_procesorami_intel-23722.html](https://ithardware.pl/aktualnosci/niezrownana_wydajnosc_notebookow_asus_na_rok_2022_napedzana_najnowszymi_procesorami_intel-23722.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 08:25:20+00:00

<img src="https://ithardware.pl/artykuly/min/23722_1.jpg" />            Doskonałe chłodzenie i zaawansowana konstrukcja obudowy gwarantują najlepszą w swojej klasie wydajność procesor&oacute;w Intel Core z serii H, w najnowszej generacji smukłych i lekkich laptop&oacute;w EVO.

Linia smukłych i lekkich...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/niezrownana_wydajnosc_notebookow_asus_na_rok_2022_napedzana_najnowszymi_procesorami_intel-23722.html">https://ithar

## Intel Core i9-13900K wykecony na ciekłym azocie to 8,2 GHz
 - [https://ithardware.pl/aktualnosci/intel_core_i9_13900k_wykecony_na_cieklym_azocie_to_8_2_ghz-23717.html](https://ithardware.pl/aktualnosci/intel_core_i9_13900k_wykecony_na_cieklym_azocie_to_8_2_ghz-23717.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 07:55:50+00:00

<img src="https://ithardware.pl/artykuly/min/23717_1.jpg" />            Znany overclocker Allen &bdquo;Splave&rdquo; Golibersuch podczas finału Intel's Creator Challenge podkręcił procesor Core i9-13900K do 8,2 GHz na ciekłym azocie (LN2). Flagowy CPU Raptor Lake, kt&oacute;ry będzie walczył o tytuł najlepszego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_core_i9_13900k_wykecony_na_cieklym_azocie_to_8_2_ghz-23717.html">https://ithardware.pl/aktualnosci/i

## GeForce RTX 4080 przetestowany w grach w i 3DMark. Wiemy, jak wypada na tle poprzednika
 - [https://ithardware.pl/aktualnosci/geforce_rtx_4080_przetestowany_w_grach_w_i_3dmark_wiemy_jak_wypada_na_tle_poprzednika-23716.html](https://ithardware.pl/aktualnosci/geforce_rtx_4080_przetestowany_w_grach_w_i_3dmark_wiemy_jak_wypada_na_tle_poprzednika-23716.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 07:02:55+00:00

<img src="https://ithardware.pl/artykuly/min/23716_1.png" />            Wygląda na to, że w sieci pojawiły się pierwsze gamingowe testy karty graficznej GeForce RTX 4080 16 GB. Użytkownik chińskiego forum Chiphell o nazwie &bdquo;panzerlied&rdquo; podzielił się stosownymi wynikami benchmark&oacute;w, kt&oacute;re...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_4080_przetestowany_w_grach_w_i_3dmark_wiemy_jak_wypada_na_tle_poprzednika-23716.html">https:

## Pixel Watch oficjalnie. Jest drogo, ale design urzeka
 - [https://ithardware.pl/aktualnosci/pixel_watch_oficjalnie_jest_drogo_ale_design_urzeka-23715.html](https://ithardware.pl/aktualnosci/pixel_watch_oficjalnie_jest_drogo_ale_design_urzeka-23715.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-07 06:13:41+00:00

<img src="https://ithardware.pl/artykuly/min/23715_1.jpg" />            Blisko rok od pojawienia się pierwszych plotek na temat zegarka od Google, Pixel Watch wreszcie doczekał się oficjalnej prezentacji. Urządzenie działa na systemie Wear OS 3.5 i będzie rywalizować na rynku z wearable pokroju Apple Watch czy Samsung...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pixel_watch_oficjalnie_jest_drogo_ale_design_urzeka-23715.html">https://ithardware.pl/aktualnosci/p


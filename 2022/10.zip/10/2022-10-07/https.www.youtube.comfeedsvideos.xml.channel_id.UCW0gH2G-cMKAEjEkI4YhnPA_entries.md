# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Sauron the Shapeshifter | Tolkien Explained
 - [https://www.youtube.com/watch?v=9PAjrYCXhBU](https://www.youtube.com/watch?v=9PAjrYCXhBU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-10-08 00:00:00+00:00

Today, we dive into Sauron's ability to shape-shift!  We see multiple forms of Sauron throughout the First and Second Ages and come to find that the destruction of his physical form affects this ability.

Hit subscribe - and the bell!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

To purchase artist work, check out these amazing artists!

Tulikoura - https://www.deviantart.com/tulikoura
Matthew Stewart - http://www.matthew-stewart.com/
BellaBergolts - https://www.deviantart.com/bellabergolts
Magdalena Katanska - https://www.artstation.com/magdalenakatanska/prints  https://www.instagram.com/qualiney
Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc
Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artstation.com/saramorello
Matěj Čadil - https://www.etsy.com/people/matejcadil
Tulikoura - https://www.deviantart.com/tulikoura
Aegeri - https://www.deviantart.com/aegeri
Noe Leyva - https://twitter.com/NoeLeyvArt
Clemence Morisseau - https://www.artstation.com/kahirie
Edvige Faini - www.edvigefaini.com , www.facebook.com/edvige.faini , www.instagram.com/edvige_faini

#tolkien #sauron #lordoftherings

## Rings of Power Episode 7 BREAKDOWN | Lord of the Rings on Prime Explained
 - [https://www.youtube.com/watch?v=Yp-wS_Okgb0](https://www.youtube.com/watch?v=Yp-wS_Okgb0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-10-07 00:00:00+00:00

Deep dive into Rings of Power Episode 7: "The Eye" !  We'll look for all the references to Tolkien's deeper lore, explain what is happening, and I'll give some thoughts along the way. We had some confirmation on the nature of Mithril in the series and a huge name drop that has some crazy implications!



Hit subscribe - and the bell!

Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings



Check out NOTR merch: https://nerdoftherings.creator-spring.com/



To purchase artist work, check out these amazing artists!



Tulikoura - https://www.deviantart.com/tulikoura

Matthew Stewart - http://www.matthew-stewart.com/

BellaBergolts - https://www.deviantart.com/bellabergolts

Magdalena Katanska - https://www.artstation.com/magdalenakatanska/prints  https://www.instagram.com/qualiney

Jerry Vanderstelt - https://store.vandersteltstudio.com/main.sc

Anna Podedworna - https://www.artstation.com/akreon

Jenny Dolfen - goldseven.wordpress.com/

Turner Mohan - www.instagram.com/turner_mohan

Ted Nasmith - www.tednasmith.com/shop/

Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html

Aronja Art - https://www.instagram.com/aronjaart/

Ivan Cavini - https://www.instagram.com/ivan_cavini/

Sara Morello - https://www.artstation.com/saramorello

Matěj Čadil - https://www.etsy.com/people/matejcadil

Tulikoura - https://www.deviantart.com/tulikoura

Aegeri - https://www.deviantart.com/aegeri

Noe Leyva - https://twitter.com/NoeLeyvArt

Clemence Morisseau - https://www.artstation.com/kahirie

Edvige Faini - www.edvigefaini.com , www.facebook.com/edvige.faini , www.instagram.com/edvige_faini



#theringsofpower #ringsofpower #lordoftherings


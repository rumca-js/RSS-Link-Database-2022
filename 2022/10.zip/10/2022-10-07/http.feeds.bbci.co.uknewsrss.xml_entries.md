# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Tesla's Optimus and the problem with humanoids
 - [https://www.bbc.co.uk/news/technology-63130363?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63130363?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 23:46:06+00:00

Unlike Elon Musk's latest creation, the most useful robots, experts say, do not look human - so far.

## James Bond: Duo were 'privileged' to write new ending for 007
 - [https://www.bbc.co.uk/news/entertainment-arts-63143081?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63143081?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 23:44:19+00:00

Screenwriters Neal Purvis and Robert Wade discuss what it takes to keep the James Bond franchise alive.

## The rise and fall of a legendary black nightclub
 - [https://www.bbc.co.uk/news/stories-63161434?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/stories-63161434?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 23:43:54+00:00

Racism fuelled Phil Magbotiwan's determination to open his own nightclub.

## Week in pictures: 1 - 7 October 2022
 - [https://www.bbc.co.uk/news/in-pictures-63171345?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-63171345?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 23:29:02+00:00

A selection of powerful images from all over the globe, taken in the past seven days.

## Who wields the most power in Iran?
 - [https://www.bbc.co.uk/news/world-middle-east-57260831?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-57260831?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 23:21:31+00:00

Iran's leaders are ordering the police and Revolutionary Guard to crack down on nationwide protests.

## The Papers: Minister sacked in 'sleaze row’ and ‘jab crisis’
 - [https://www.bbc.co.uk/news/blogs-the-papers-63181031?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-63181031?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 23:19:15+00:00

The firing of a cabinet minister and the ongoing energy crisis lead several of Saturday's papers.

## Lauren Parker beats Edna Malto to claim IBO intercontinental super-flyweight title
 - [https://www.bbc.co.uk/sport/boxing/63180396?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/63180396?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 22:41:09+00:00

England's Lauren Parker puts in a battling performance to beat Mexico's Edna Malto to claim the IBO intercontinental super-flyweight belt.

## Snoop Dogg and Souleye fans of Cwmbran's Mr Giant Veg
 - [https://www.bbc.co.uk/news/uk-wales-63129983?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-63129983?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 22:01:05+00:00

Gardener Kevin Fortey counts rappers Snoop Dogg and Souleye among his fans.

## Christian Dior: The French designer who brought chic to Scotland
 - [https://www.bbc.co.uk/news/uk-scotland-tayside-central-62807316?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-tayside-central-62807316?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 21:47:23+00:00

After London and Paris, the French designer staged a fashion show at Gleneagles in Perthshire.

## SNP conference: Sturgeon will seek to exploit Truss's faltering start as PM
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-63180758?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-63180758?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 21:47:10+00:00

The SNP conference will hear much about the fallout from the UK government's tax cutting mini-budget.

## Uvalde suspends school police force after mass shooting
 - [https://www.bbc.co.uk/news/world-us-canada-63180739?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63180739?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 21:27:20+00:00

The move comes after parents of the victims camped outside school offices in protest.

## What will happen if Britain has winter blackouts?
 - [https://www.bbc.co.uk/news/business-63170747?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63170747?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 21:24:09+00:00

Power cuts are very unlikely in the coming months but not impossible so what would it mean for you?

## Premiership: Bristol Bears 14-50 Exeter Chiefs - Visitors go top with seven-try haul
 - [https://www.bbc.co.uk/sport/rugby-union/63122726?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63122726?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 21:15:53+00:00

Jack Nowell and Olly Woodburn score two tries apiece as Exeter thrash Bristol in their Premiership match at Ashton Gate.

## Eurovision 2023: Liverpool beats Glasgow to be song contest host city
 - [https://www.bbc.co.uk/news/entertainment-arts-63174493?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63174493?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 21:13:47+00:00

Glasgow loses out as the UK prepares to stage the song contest next May on behalf of Ukraine.

## England 2-1 USA: Lionesses beat world champions in Wembley friendly
 - [https://www.bbc.co.uk/sport/football/63175129?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63175129?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 21:11:58+00:00

England beat world champions the United States for the first time since 2017 before more than 76,000 fans in their first meeting at Wembley Stadium.

## England 50-0 Fiji: Dominic Young stars on debut in Rugby League World Cup warm-up
 - [https://www.bbc.co.uk/sport/rugby-league/63179123?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-league/63179123?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 20:23:59+00:00

Dominic Young stars on debut as England thrash Fiji 50-0 in their final warm-up game before hosting the Rugby League World Cup.

## Eurovision in Liverpool will come at a significant cost
 - [https://www.bbc.co.uk/news/entertainment-arts-63119375?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63119375?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 19:50:39+00:00

Now we know Liverpool will host Eurovision in 2023, questions are likely to move to funding the event.

## Ellerby: Gold coins found hidden under kitchen floor sell for £754,000
 - [https://www.bbc.co.uk/news/uk-england-humber-63179607?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-humber-63179607?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 19:42:11+00:00

The coins, found during kitchen renovations in East Yorkshire, have attracted global interest.

## Customers could get £100 for cutting energy use
 - [https://www.bbc.co.uk/news/business-63175030?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63175030?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 19:31:41+00:00

Octopus energy expects customers to get £4 a day on average for cutting back consumption when demand is high.

## Eurovision: Liverpool will put on best party ever, mayor says
 - [https://www.bbc.co.uk/news/uk-england-merseyside-63176525?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-63176525?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 19:13:55+00:00

Liverpool promises to put on the best party ever for Eurovision, after the city is named as 2023 host.

## New York City declares state of emergency over migrant 'crisis situation'
 - [https://www.bbc.co.uk/news/world-us-canada-63177892?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63177892?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 19:02:27+00:00

Mayor Eric Adams said the city is on track to spend $1bn this fiscal year to care for asylum seekers.

## Why Russia but not China faces human rights action
 - [https://www.bbc.co.uk/news/world-63177266?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-63177266?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 18:55:13+00:00

The UN has examined allegations of repression and human rights violations in both countries.

## Stephen Lawrence case: Jamie Acourt to be freed in November
 - [https://www.bbc.co.uk/news/uk-england-london-63176841?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-63176841?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 17:24:55+00:00

Jamie Acourt's sentence will be reactivated unless he starts paying back £90K he made in a drugs deal.

## Creeslough: Multiple people injured in Donegal explosion
 - [https://www.bbc.co.uk/news/world-europe-63178493?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63178493?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 17:23:56+00:00

A hospital has moved to "major emergency standby" after the incident in a petrol station.

## Ukraine war: Vladimir Putin gets a tractor for his 70th birthday
 - [https://www.bbc.co.uk/news/world-europe-63176124?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63176124?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 17:23:47+00:00

Gifts for Russia's embattled president include a tractor from Belarusian ally Alexander Lukashenko.

## Ukraine war: World must act now to stop Russia, says Zelensky
 - [https://www.bbc.co.uk/news/world-europe-63173443?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63173443?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 17:02:04+00:00

In a BBC interview, Ukraine's president says urgent action is needed amid Russian nuclear threats.

## Police officers face probe over 'grossly offensive' WhatsApp messages
 - [https://www.bbc.co.uk/news/uk-63176296?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63176296?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 16:21:13+00:00

A criminal investigation is launched into messages allegedly shared by police officers on WhatsApp.

## Ed Sheeran is spotted playing in Ipswich
 - [https://www.bbc.co.uk/news/uk-england-suffolk-63173625?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-suffolk-63173625?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 16:18:48+00:00

Crowds gather to watch the star as he performs his hit song The A Team.

## Climate change: World aviation agrees 'aspirational' net zero plan
 - [https://www.bbc.co.uk/news/science-environment-63165607?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-63165607?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 15:59:27+00:00

UN member states pledge to decarbonise air travel, but green groups say the deal is weak and non-binding.

## NFL London: Green Bay Packers v New York Giants 'a dream' for MVP Aaron Rodgers
 - [https://www.bbc.co.uk/sport/american-football/63030234?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/american-football/63030234?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 15:38:59+00:00

The Green Bay Packers will become the 32nd and final NFL team to play in the UK when they face the New York Giants at Tottenham Hotspur Stadium on Sunday.

## Trade minister Conor Burns sacked from government
 - [https://www.bbc.co.uk/news/uk-politics-63177669?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63177669?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 15:24:14+00:00

Trade minister Conor Burns dismissed from government after a complaint of serious misconduct, No 10 says

## Post Office scandal: 'Why am I still fighting to clear my name?'
 - [https://www.bbc.co.uk/news/uk-scotland-63173414?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-63173414?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 15:15:21+00:00

Rab Thomson is among 700 people who may have been wrongly convicted in the Post Office scandal.

## Queen's profile created by pilot's 250-mile tribute flight
 - [https://www.bbc.co.uk/news/uk-england-london-63176832?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-63176832?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 15:07:54+00:00

Amal Larhlid flew a Piper PA-28 for two hours as it was tracked by air traffic technology.

## Man armed with knife shot dead by police in Derby
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-63173045?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-63173045?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 14:35:47+00:00

Armed officers shot the man in the secure car park of a police station in Derby.

## Alejandro Valverde and Vincenzo Nibali prepare for last race
 - [https://www.bbc.co.uk/sport/cycling/63175182?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/63175182?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 14:24:00+00:00

Il Lombardia monument marks the end of the careers of two of cycling's legends, Alejandro Valverde and Vincenzo Nibali.

## DCI Banks author Peter Robinson dies aged 72
 - [https://www.bbc.co.uk/news/uk-england-leeds-63173096?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-63173096?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 13:47:24+00:00

The writer, who was born and raised in Leeds, died after a short illness, his publisher announces.

## Nicola Sturgeon says lack of contact from Liz Truss 'absurd'
 - [https://www.bbc.co.uk/news/uk-scotland-63175102?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-63175102?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 13:33:13+00:00

The SNP leader says she has still not had a phone call from Liz Truss a month after she became PM.

## Belarus, Ukraine, Russia activists win Nobel Peace Prize
 - [https://www.bbc.co.uk/news/world-europe-63175334?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63175334?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 13:29:31+00:00

The peace prize goes to Ales Bialiatsky, Russia's Memorial and the Ukrainian Center for Civil Liberties.

## Moors Murders: Search for Keith Bennett ends with no evidence found
 - [https://www.bbc.co.uk/news/uk-england-manchester-63173146?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-63173146?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 13:23:23+00:00

Police end a search for Keith Bennett's body after finding no sign of human remains at the scene.

## Nobel Peace Prize: Moment NGO told on the phone it has won award
 - [https://www.bbc.co.uk/news/world-63170363?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-63170363?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 12:58:36+00:00

Oleksandra Romantsova, from the Center for Civil Liberties, responds emotionally upon learning of the award.

## Rugby World Cup: Why England are favourites to win
 - [https://www.bbc.co.uk/sport/rugby-union/63170766?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63170766?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 12:58:12+00:00

Professionalism, respect and a very good maul - BBC Sport explores the reasons behind England's dominance.

## Conor Benn is 'clean' despite failed drug test, says dad Nigel
 - [https://www.bbc.co.uk/sport/boxing/63173704?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/63173704?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 12:46:11+00:00

Nigel Benn says his son Conor is "clean" despite a failed drug test leading to the postponement of his fight with Chris Eubank Jr.

## Heysham explosion: Dad's anguish as boy killed by 'selfish' drunk
 - [https://www.bbc.co.uk/news/uk-england-lancashire-63171221?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lancashire-63171221?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 12:18:59+00:00

Two-year-old George Hinds died after drunken neighbour Darren Greenham cut a gas pipe for scrap.

## Public won't be told to cut energy use after PM objects
 - [https://www.bbc.co.uk/news/uk-politics-63170588?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63170588?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 12:11:38+00:00

A minister denies a full plan was blocked by Liz Truss's office and insists energy supplies are secure.

## Euro 2024 qualifying draw to take place on Sunday: All you need to know
 - [https://www.bbc.co.uk/sport/football/63035627?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63035627?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 11:58:57+00:00

The 2024 European Championship draw takes place in Frankfurt on Sunday - who could the home nations face?

## Home insulation: How can it cut energy bills?
 - [https://www.bbc.co.uk/news/explainers-60289396?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/explainers-60289396?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 11:40:59+00:00

Better home insulation could save some households hundreds of pounds a year on their energy bills.

## Covid: Protect elderly from rising virus levels in UK
 - [https://www.bbc.co.uk/news/health-63170006?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-63170006?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 11:34:00+00:00

With cases on the up, people who feel unwell are advised to avoid vulnerable relatives as a precaution.

## Marshmallow ruling helps Loughborough firm in VAT fight
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-63157432?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-63157432?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 11:27:49+00:00

A company successfully argues its extra large mallows are a baking ingredient rather than a snack.

## Complutense University: Spain investigates student 'whores' chants at women
 - [https://www.bbc.co.uk/news/world-europe-63171559?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63171559?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 11:15:13+00:00

Videos have circulated for days of male students chanting obscene misogynistic abuse in Madrid.

## Watch: Jess Fishlock’s Wales winner against Bosnia-Herzegovina
 - [https://www.bbc.co.uk/sport/av/football/63173036?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63173036?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 11:10:57+00:00

Jess Fishlock's stunning extra-time volley secures a 1-0 win against Bosnia-Herzegovina and sends Wales into the World Cup play-off final.

## Will Newcastle turn the 'big six' into 'big seven'?
 - [https://www.bbc.co.uk/sport/football/63159987?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63159987?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 11:08:16+00:00

One year on from Newcastle's controversial takeover, will they really gatecrash the Premier League's elite - and how noisy will the Saudi Arabian links become?

## Eurovision 2023: Glasgow and Liverpool await decision on UK host city
 - [https://www.bbc.co.uk/news/entertainment-arts-63158155?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63158155?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 10:57:18+00:00

Glasgow and Liverpool will find out on Friday which will stage the Eurovision Song Contest next May.

## Record excess deaths in UK's heatwave summer
 - [https://www.bbc.co.uk/news/health-63171417?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-63171417?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 10:50:52+00:00

With record-breaking temperatures, there were around 3,000 more deaths than usual in England and Wales.

## Steve Cooper: Nottingham Forest manager signs new deal until 2025
 - [https://www.bbc.co.uk/sport/football/63172328?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63172328?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 10:45:34+00:00

Nottingham Forest manager Steve Cooper signs a new contract with the club until 2025.

## Daughter's plea over vulval cancer checks
 - [https://www.bbc.co.uk/news/uk-scotland-63172959?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-63172959?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 10:44:57+00:00

Laura Christie hopes to raise awareness of vulval cancer, which claimed the life of her mother.

## Iran protests: Nika Shakarami's mother says her daughter was murdered
 - [https://www.bbc.co.uk/news/world-middle-east-63170486?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63170486?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 10:16:47+00:00

Officials are lying about how 16-year-old protester Nika Shakarami died, her mother says.

## Alexei Navalny: Russia's jailed vociferous Putin critic
 - [https://www.bbc.co.uk/news/world-europe-16057045?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-16057045?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 10:03:21+00:00

Russian anti-corruption campaigner Alexei Navalny has built up huge support on social media.

## Kevin Spacey faces New York jury in sexual assault court case
 - [https://www.bbc.co.uk/news/entertainment-arts-63169572?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63169572?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 10:02:52+00:00

The House of Cards stars is accused of a sexual assault in 1986, which he denies.

## Blind Scottish pianist reaches BBC Young Musician final
 - [https://www.bbc.co.uk/news/uk-scotland-tayside-central-63075014?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-tayside-central-63075014?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 09:54:22+00:00

Falkirk pianist Ethan Loch has been playing the piano since he was four years old.

## Rare woodpecker returns to Dorset 'due to organic farming'
 - [https://www.bbc.co.uk/news/uk-england-dorset-63158903?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-dorset-63158903?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 09:53:07+00:00

The Dorset Wildlife Trust spied the lesser spotted woodpecker at Hollis Mead farm in Corscombe.

## Nobel Peace Prize: Who is Ales Bialiatski?
 - [https://www.bbc.co.uk/news/world-europe-63172009?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63172009?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 09:26:59+00:00

A profile of a Belarusian human rights activist, one of three winners of the prestigious award in 2022.

## Nicola Sturgeon issues warning over winter energy usage
 - [https://www.bbc.co.uk/news/uk-scotland-63170734?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-63170734?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 09:14:47+00:00

The FM has said people should be "sensible" after the National Grid warned of possible blackouts.

## Molly Russell father: Social media culture must change
 - [https://www.bbc.co.uk/news/uk-63171199?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63171199?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 09:02:45+00:00

The teenager's father Ian spoke to the BBC about what he wants families to learn from his daughter's story.

## WWE: Sara Lee, Tough Enough star, dies aged 30
 - [https://www.bbc.co.uk/news/newsbeat-63170494?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-63170494?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 08:51:46+00:00

Tributes pour in for Sara Lee, the winner of the wrestling giant's 2015 Tough Enough reality series.

## Train strikes: Passengers told to avoid travel on Saturday
 - [https://www.bbc.co.uk/news/business-63170168?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63170168?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 08:43:21+00:00

The latest strike means only one in five trains will run, with services starting late and finishing early.

## Mortgage rate rises set to put pressure on house prices, says Halifax
 - [https://www.bbc.co.uk/news/business-63170108?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63170108?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 08:34:46+00:00

The Halifax says higher mortgage costs could put "significant downward pressure" on the market.

## Gateshead stabbing: Boy charged with Tomasz Oleszak murder
 - [https://www.bbc.co.uk/news/uk-england-tyne-63155128?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tyne-63155128?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 08:32:18+00:00

The teenager is due in court later charged with the murder of Tomasz Oleszak, 14, in Gateshead.

## Japanese Grand Prix: George Russell leads Mercedes one-two in wet practice
 - [https://www.bbc.co.uk/sport/formula1/63169921?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/63169921?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 07:35:41+00:00

George Russell heads Lewis Hamilton to a Mercedes one-two on a wet Friday practice at the Japanese Grand Prix.

## England: The strikers looking to challenge Harry Kane at the World Cup in Qatar
 - [https://www.bbc.co.uk/sport/football/63058152?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63058152?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 07:15:44+00:00

Gareth Southgate will soon be naming his World Cup squad and BBC Sport has run the rule over his attacking options behind Harry Kane.

## Avanti West Coast told to drastically improve rail services
 - [https://www.bbc.co.uk/news/business-63169383?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63169383?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 07:10:44+00:00

The train operator is given a short-term extension to continue running services on the west coast mainline.

## Molly Russell inquest: Family 'numb' about inquest verdict
 - [https://www.bbc.co.uk/news/uk-england-london-63157632?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-63157632?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 07:06:31+00:00

The father of Molly Russell says his family is "still processing" the verdict into her death.

## Vicky McClure's dementia choir releases debut single
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-63163972?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-63163972?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 06:54:47+00:00

The aim of the single is to show that patients "are more than their diagnosis".

## Rugby World Cup: Women’s rugby to reach new heights as ‘golden era of opportunity’ beckons
 - [https://www.bbc.co.uk/sport/rugby-union/63161938?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63161938?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 06:07:26+00:00

The Rugby World Cup begins in New Zealand on Saturday and BBC Sport explores why it is the biggest women's edition yet.

## Conor Benn v Chris Eubank Jr: Common sense prevails on 'grim day for boxing'
 - [https://www.bbc.co.uk/sport/boxing/63144183?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/63144183?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 05:29:35+00:00

BBC Sport reflects on a "grim day for boxing' after the cancellation of Conor Benn v Chris Eubank Jr and where Benn goes from here after being thrust into the centre of a doping scandal.

## Strictly Come Dancing: Ellie Simmonds' 'heart touched' by support
 - [https://www.bbc.co.uk/news/uk-england-birmingham-63167423?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-63167423?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 05:22:42+00:00

Ellie Simmonds says she is not only on a Strictly journey with her partner but the dwarfism community.

## Thailand attack: Country mourns after 37 killed, mostly children
 - [https://www.bbc.co.uk/news/world-asia-63168077?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63168077?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 05:13:30+00:00

An ex-police officer killed at least 37 people at a childcare centre before killing himself and his family.

## Easter Island: Sacred statues damaged by fire
 - [https://www.bbc.co.uk/news/world-latin-america-63167941?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-63167941?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 05:12:46+00:00

Many of the enigmatic stone-carved statues are "totally charred" according to local authorities.

## Social care: 'Jo's care will cost £1.5k a week - the system is broken'
 - [https://www.bbc.co.uk/news/uk-63160530?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63160530?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 05:00:07+00:00

A BBC poll reveals people's worries about social care. So what is the new government going to do?

## Ukraine war: Biden says nuclear risk highest since 1962 Cuban Missile Crisis
 - [https://www.bbc.co.uk/news/world-us-canada-63167947?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63167947?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 04:28:38+00:00

Joe Biden says President Putin was "not joking" when he spoke of using tactical nuclear weapons.

## Adidas puts Kanye West Yeezy deal under review
 - [https://www.bbc.co.uk/news/business-63167930?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63167930?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 03:56:29+00:00

Earlier this week, the rapper and fashion designer wore a t-shirt that read "White Lives Matter".

## The Bradford wrestling church mixing sermons with suplexes
 - [https://www.bbc.co.uk/news/uk-england-leeds-62825512?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-62825512?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 00:27:04+00:00

Baptisms and body slams are all part of a day's work for one church which aims to help young people.

## Big Butterfly Count: Sightings worryingly low, say UK conservationists
 - [https://www.bbc.co.uk/news/uk-63164826?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63164826?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 00:14:47+00:00

Conservationists say they expected this year's warm summer to be a much better one for butterflies.

## Dancers' moves help to power Glasgow music venue
 - [https://www.bbc.co.uk/news/technology-63161838?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63161838?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 00:10:18+00:00

Heat energy is being captured from people dancing to help a Glasgow venue reduce its carbon emissions.

## UK defies climate warnings with new oil and gas licences
 - [https://www.bbc.co.uk/news/science-environment-63163824?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-63163824?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-07 00:04:59+00:00

More than 100 licences are expected to be granted for new fossil fuel exploration in the North Sea.


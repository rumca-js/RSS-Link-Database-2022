# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## What to Do Immediately After You Click a Phishing Link
 - [https://lifehacker.com/what-to-do-immediately-after-you-click-a-phishing-link-1849632419](https://lifehacker.com/what-to-do-immediately-after-you-click-a-phishing-link-1849632419)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--pDYMFwiQ--/c_fit,fl_progressive,q_80,w_636/16b6d86bfa15255016aeda257ceda798.png" /><p><a href="https://lifehacker.com/what-to-do-immediately-after-you-click-a-phishing-link-1849632419">Read more...</a></p>

## Drop Everything and Get This $150 Painting Software for $10
 - [https://lifehacker.com/drop-everything-and-get-this-150-painting-software-for-1849632251](https://lifehacker.com/drop-everything-and-get-this-150-painting-software-for-1849632251)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--tTfmPGAE--/c_fit,fl_progressive,q_80,w_636/d9e567d04d5b9232d6638e85700acab0.jpg" /><p>You most likely won’t find a better opportunity than this: For its 10-year anniversary, the small studio of creatives and programmers from Escape Motions is celebrating by selling their creative apps for $10 until Oct. 13. The deal has been such a success that the website has crashed multiple times from high demand to…</p><p><a href="https://lifehac

## Amazon Is About to Sell This 4K Smart TV for Just $112
 - [https://lifehacker.com/amazon-is-about-to-sell-this-4k-smart-tv-for-just-112-1849631844](https://lifehacker.com/amazon-is-about-to-sell-this-4k-smart-tv-for-just-112-1849631844)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Sbj8AJof--/c_fit,fl_progressive,q_80,w_636/c4822647607b44b683e658aafba1d9fe.jpg" /><p>A slick 55-inch 4K Smart TV for $112? Could that even be a real thing? It might be for Amazon Prime members: Last Thursday, Amazon <a href="https://www.aboutamazon.com/news/retail/amazon-prime-early-access-sale-best-deals" rel="noopener noreferrer" target="_blank">released</a> some of the deals members can expect to find during its <a href="https://

## Five Things You're Not Cleaning in Your Washing Machine (but Should Be)
 - [https://lifehacker.com/five-things-youre-not-cleaning-in-your-washing-machine-1849631969](https://lifehacker.com/five-things-youre-not-cleaning-in-your-washing-machine-1849631969)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--OjoMbXj---/c_fit,fl_progressive,q_80,w_636/b557e0c44a40016682f7587e96780e24.png" /><p><a href="https://lifehacker.com/five-things-youre-not-cleaning-in-your-washing-machine-1849631969">Read more...</a></p>

## 13 of the Worst Breaches of Gym Etiquette, According to Reddit
 - [https://lifehacker.com/13-of-the-worst-breaches-of-gym-etiquette-according-to-1849631579](https://lifehacker.com/13-of-the-worst-breaches-of-gym-etiquette-according-to-1849631579)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 19:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--JDtZrJMv--/c_fit,fl_progressive,q_80,w_636/7428f201c215ca47911a5aa6d5454dd7.jpg" /><p>We’ve probably all made a gym faux pas at some point. As a beginner, I know I was guilty of using dumbbells right in front of the rack; it hadn’t occurred to me that I was blocking others’ access. But most of us can master the basics of gym etiquette pretty quickly. And then we look around the room and—on a very…</p><p><a href="https://lifehacker.co

## Why You Should Always Have Plumber's Putty
 - [https://lifehacker.com/why-you-should-always-have-plumbers-putty-1849630955](https://lifehacker.com/why-you-should-always-have-plumbers-putty-1849630955)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--0Cs-jRuC--/c_fit,fl_progressive,q_80,w_636/4bbf04bea23479327a1395bf108ca4fe.jpg" /><p>If you’ve ever spent any real time perusing your local hardware store, you have probably seen something called Plumber’s Putty on the shelves. Or maybe you hired a plumber to do some work and you spotted it among their tools and materials: It’s typically a compound with a base of clay or dough, combined with some…</p><p><a href="https://lifehacker.c

## The Real Difference Between the ‘Apocalypse,’ ‘Armageddon,’ and ‘Doomsday’
 - [https://lifehacker.com/the-real-difference-between-the-apocalypse-armagedd-1849631390](https://lifehacker.com/the-real-difference-between-the-apocalypse-armagedd-1849631390)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--uJHhPoYB--/c_fit,fl_progressive,q_80,w_636/85218126b5bca9e460b8ffed43e33b27.jpg" /><p>With the amount of straight-up bad news we’re confronted with every day, it’s easy to feel like we’re living in the End Times—and maybe we are. We sure <em>say</em> we’re living in a dystopia often enough, throwing around words like “apocalypse” and “armageddon.” But what do those words mean? Are they the same thing? And what…</p><p><a href="https:/

## Why You Shouldn't Pay for Anything With Zelle
 - [https://lifehacker.com/why-you-shouldnt-pay-for-anything-with-zelle-1849631440](https://lifehacker.com/why-you-shouldnt-pay-for-anything-with-zelle-1849631440)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 18:13:46+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--lPwgFfal--/c_fit,fl_progressive,q_80,w_636/9cce62d5edd7d822c99741e6aa28f15a.jpg" /><p>We tend to think that scams happen to other people, and that we’re too smart, informed, or cautious to fall for them. But we all have vulnerable moments when we can slip—it just takes the right message, item, or time. Lately, that’s been happening a lot on Zelle.<br /></p><p><a href="https://lifehacker.com/why-you-shouldnt-pay-for-anything-with-zell

## 12 of the Worst Biopics of All Time (and 12 to Watch Instead)
 - [https://lifehacker.com/12-of-the-worst-biopics-of-all-time-and-12-to-watch-in-1849625166](https://lifehacker.com/12-of-the-worst-biopics-of-all-time-and-12-to-watch-in-1849625166)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 17:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Tk8uXJ0x--/c_fit,fl_progressive,q_80,w_636/45001edb9a57422abda46106d5b4ec64.png" /><p>Andrew Dominik’s NC-17 <em>Blonde</em> has faced controversy since its inception: for its rating, for its source material (a highly fictionalized Joyce Carol Oates novel), and later for interviews <a href="https://www.bfi.org.uk/sight-and-sound/interviews/im-not-interested-reality-im-interested-images-andrew-dominik-blonde" rel="noopener noreferrer"

## The Twitter Bots Everyone Should Follow
 - [https://lifehacker.com/the-twitter-bots-everyone-should-follow-1849630465](https://lifehacker.com/the-twitter-bots-everyone-should-follow-1849630465)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--EvRInUly--/c_fit,fl_progressive,q_80,w_636/45909719f0591522264671807a328fb6.jpg" /><p>Automated Twitter accounts are responsible for a lot of spam, but there <em>are</em> exceptions. Twitter actually has some great bots that add helpful features, like adding color to photos, solving puzzles, and taking screenshots of tweets. Here are seven of our favorites.<br /></p><p><a href="https://lifehacker.com/the-twitter-bots-everyone-should-

## The Overlooked (but Serious) Symptoms of Menopause
 - [https://lifehacker.com/the-overlooked-but-serious-symptoms-of-menopause-1849628794](https://lifehacker.com/the-overlooked-but-serious-symptoms-of-menopause-1849628794)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--IrMMu9MK--/c_fit,fl_progressive,q_80,w_636/cf919ce042eaf0e1f0cc9478997fe8d7.jpg" /><p>Generally speaking, menopause, which is defined as <a href="https://www.womenshealth.gov/menopause/menopause-basics#1" rel="noopener noreferrer" target="_blank">going a full 12 months without a period</a>, can happen anytime ranging between the late 30s to late 50s, with the <a href="https://www.everydayhealth.com/menopause-pictures/menopause-sympto

## Your Child Might Actually Have a Math Learning Disorder
 - [https://lifehacker.com/your-child-might-actually-have-a-math-learning-disorder-1849627701](https://lifehacker.com/your-child-might-actually-have-a-math-learning-disorder-1849627701)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--GvpbHlnB--/c_fit,fl_progressive,q_80,w_636/336a4d66a5b441205fcf76e19cf11f18.jpg" /><p>Maybe your child hates math. Maybe you did, too, when you were a kid, or <a href="https://lifehacker.com/you-have-math-anxiety-heres-how-to-not-pass-it-down-to-1819181913">you got so anxious about math tests</a> that you had panic attacks. While math is hard for some children, there are some who do have an actual learning disability in math, called 

## How Your Guilt Can Actually Help You
 - [https://lifehacker.com/how-your-guilt-can-actually-help-you-1849630252](https://lifehacker.com/how-your-guilt-can-actually-help-you-1849630252)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 15:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--6NSirj4u--/c_fit,fl_progressive,q_80,w_636/37cdcaa8dc2d2704cca8fd3b0442fd4b.jpg" /><p>After making a mistake, feeling guilt is a good thing—it means you have empathy. Sometimes our guilt is self-imposed and unhelpful, like after you let yourself relax and subsequently don’t feel <a href="https://lifehacker.com/how-to-get-over-productivity-guilt-1831146802">productive enough</a>. Other times, guilt is a powerful motivator to do better

## The Best Time to Carve Your Pumpkin so It's Not Rotten on Halloween
 - [https://lifehacker.com/the-best-time-to-carve-your-pumpkin-so-its-not-rotten-o-1849624529](https://lifehacker.com/the-best-time-to-carve-your-pumpkin-so-its-not-rotten-o-1849624529)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--jR3o0TTy--/c_fit,fl_progressive,q_80,w_636/88885ca0393cc920f40c4cea5c3179e4.jpg" /><p>It’s officially pumpkin season, and you know what that means. If you’re a parent in suburbia, not only will you go to a pumpkin patch to enjoy a hayride, corn maze, apple cider donuts, and  pay $117 to shlep  pumpkins across a giant field, you will also wonder: When can I carve these bad boys to get maximum…</p><p><a href="https://lifehacker.com/the

## How to Pull Off the 'Hidden Kitchen' Trend
 - [https://lifehacker.com/how-to-pull-off-the-hidden-kitchen-trend-1849628983](https://lifehacker.com/how-to-pull-off-the-hidden-kitchen-trend-1849628983)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 14:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--fprYaQiv--/c_fit,fl_progressive,q_80,w_636/3353dfad03ec26f81ffce6e51d7b28ea.jpg" /><p>Interior design trends reflect the times we live in, and nearly three years into a pandemic that’s made eating at restaurants pretty risky, it’s no surprise that kitchen renovations are high on the wish list for many people. In particular, so-called “hidden” or “invisible” kitchens have gotten quite popular over the…</p><p><a href="https://lifehacke

## The Out-of-Touch Adults’ Guide to Kid Culture: Why Is Lil Yachty in Poland?
 - [https://lifehacker.com/the-out-of-touch-adults-guide-to-kid-culture-why-is-l-1849628637](https://lifehacker.com/the-out-of-touch-adults-guide-to-kid-culture-why-is-l-1849628637)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--CXYmZlrp--/c_fit,fl_progressive,q_80,w_636/8a02b04d072ad279451d51dd81e11042.png" /><p>Halloween is coming, and things are getting very weird. Rapper Lil Yachty is taking a walk  to Poland, and TikTokers are putting pumpkins on their heads, buying all the skeletons on earth, and making their pets into demons. Oh, and NFT marketers are entering the TikTok-sphere to lie to kids about the metaverse. <br /></p><p><a href="https://lifehack

## 10 Bear Facts You Need for Fat Bear Week
 - [https://lifehacker.com/10-bear-facts-you-need-for-fat-bear-week-1849627121](https://lifehacker.com/10-bear-facts-you-need-for-fat-bear-week-1849627121)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 13:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--kNFsImZ5--/c_fit,fl_progressive,q_80,w_636/15ae716e82fac456bb612d66d5832b0e.jpg" /><p>Fat Bear Week is upon us. In just a few short days, on October 11 (Fat Bear Tuesday), one of Katmai National Park’s over 2,000 Alaskan brown bears <a href="https://explore.org/fat-bear-week" rel="noopener noreferrer" target="_blank">will be crowned the fattest of them all</a> based on internet votes. So, in celebration of these ursine kings and quee

## What Actually Helps Get Rid of a Hickey (and What Makes It Worse)
 - [https://lifehacker.com/what-actually-helps-get-rid-of-a-hickey-and-what-makes-1849626619](https://lifehacker.com/what-actually-helps-get-rid-of-a-hickey-and-what-makes-1849626619)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--QIIIbVtH--/c_fit,fl_progressive,q_80,w_636/b8841ff64d6443888980b715b4107f3b.jpg" /><p>Just like with acne and angst, hickeys don’t necessarily disappear after adolescence. Hickeys are mocked as a teenage whim, but any adult with a <a href="https://lifehacker.com/11-low-effort-ways-to-majorly-improve-your-sex-life-ac-1848844935">healthy sex life</a> knows all too well what it’s like to realize you have an unseemly bruise on your neck.

## Everything You Need to Know About the Google Pixel Watch
 - [https://lifehacker.com/everything-you-need-to-know-about-the-google-pixel-watc-1849624469](https://lifehacker.com/everything-you-need-to-know-about-the-google-pixel-watc-1849624469)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 12:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--0v9UMg10--/c_fit,fl_progressive,q_80,w_636/5464406f00306ae679a7de94061594d4.png" /><p>Google’s highly anticipated Pixel Watch is finally here. After years of speculation,  <a href="https://www.businessinsider.com/inside-google-shifting-smartwatch-strategy-2019-9" rel="noopener noreferrer" target="_blank">scrapped prototypes</a>, and <a href="https://gizmodo.com/its-done-the-google-fitbit-deal-is-complete-1846057104">a Fitbit acquisit

## Please Don't Put Cooking Spray in Your Air Fryer
 - [https://lifehacker.com/please-dont-put-cooking-spray-in-your-air-fryer-1849626915](https://lifehacker.com/please-dont-put-cooking-spray-in-your-air-fryer-1849626915)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-07 12:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--k6XbsvbL--/c_fit,fl_progressive,q_80,w_636/2923b66a2d791c36233dee768e569b32.jpg" /><p>One of things everyone loves about their air fryer is how it can make foods crispy without using a ton of oil. This does not, however, prevent people from adding <em>some</em> oil to their food. After all, fat is flavor, and there can be some anxiety over things sticking to the basket tray.</p><p><a href="https://lifehacker.com/please-dont-put-cooki


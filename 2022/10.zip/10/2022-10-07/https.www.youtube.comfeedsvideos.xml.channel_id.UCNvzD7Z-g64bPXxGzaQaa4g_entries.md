# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Realistic Gameplay Mechanics That DON'T SUCK
 - [https://www.youtube.com/watch?v=3fyiGNpzyIs](https://www.youtube.com/watch?v=3fyiGNpzyIs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-10-08 00:00:00+00:00

Some games include realistic gameplay elements that truly improve the game. Here are some of our favorite examples in gaming.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:36 Number 10
2:22 Number 9
3:47 Number 8
5:19 Number 7
6:41 Number 6
8:03 Number 5
9:40 Number 4
10:32 Number 3
12:06 Number 2
13:44 Number 1

## CYBERPUNK 2077 SEQUEL ANNOUNCED, PS5 JAILBROKEN & MORE
 - [https://www.youtube.com/watch?v=ts9vgnRYoAo](https://www.youtube.com/watch?v=ts9vgnRYoAo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-10-07 00:00:00+00:00

Thanks to Established Titles for sponsoring this video. Go to https://establishedtitles.com/GAMERANX and help support the channel. They are now running an early Black Friday sale, plus 10% off on any purchase with code GAMERANX.


~~~~~SOURCES~~~~~


PS5 jailbroken
https://www.videogameschronicle.com/news/the-ps5-has-reportedly-been-jailbroken/
https://twitter.com/manfightdragon/status/1576768394707161088
MVG video: https://youtu.be/HpV2iG7IKaQ

CD Projekt Red announces a bunch
https://www.pcgamer.com/cyberpunk-2077-is-getting-a-full-sequel/
https://www.ign.com/articles/cd-projekt-red-is-going-to-put-hundreds-of-developers-on-cyberpunk-orion

Kojima’s new star
https://www.ign.com/articles/kojima-productions-reveals-another-tease-at-pax-australia-where-am-i

Steam deck
https://youtu.be/bcwkMfoUATc
https://metro.co.uk/2022/10/07/you-dont-need-a-reservation-to-buy-a-steam-deck-anymore-17523820/


Gotham Knights hands on impressions:
https://youtu.be/X1qIKXBz9dw


Mario
https://youtu.be/LLIn2HB7ud0K


NFS Unbound:
https://youtu.be/H2Y8XCe7F9E



Wild Hearts gameplay
https://youtu.be/dbJPkCD9ZTs

Pokémon Scarlet Violet
https://youtu.be/8OKbyhHUbjs

NMS on Switch
https://www.nintendo.com/store/products/no-mans-sky-switch/

Something big I forgot

Modern Warfare 2 campaign trailer
https://youtu.be/U0utVQIMZHI

Dead Space
https://youtu.be/cTDJNZ9cK1w

God of War length
https://insider-gaming.com/god-of-war-ragnarok-40-hours/

Callisto Protocol length
https://mp1st.com/news/the-callisto-protocol-game-length-to-be-around-12-14-hours-beta-paths-will-add-replay-value

0:00 PS5 jailbreak
1:23 Cyberpunk/CD Projekt Red new games
3:54 sponsor - Established Titles
5:45 Steam Deck update
6:13 Jake played Gotham Knights
8:38 Mario movie
10:12 rapid fire news


# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Biden Administration Clamps Down on China’s Access to Chip Technology
 - [https://www.nytimes.com/2022/10/07/business/economy/biden-chip-technology.html](https://www.nytimes.com/2022/10/07/business/economy/biden-chip-technology.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-07 20:12:09+00:00

The White House issued sweeping restrictions on selling semiconductors and chip-making equipment to China, an attempt to curb the country’s access to critical technologies.

## Under New Order, Europeans Can Complain to U.S. About Data Collection
 - [https://www.nytimes.com/2022/10/07/technology/under-new-order-europeans-can-complain-to-us-about-data-collection.html](https://www.nytimes.com/2022/10/07/technology/under-new-order-europeans-can-complain-to-us-about-data-collection.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-07 14:00:05+00:00

The executive order, signed by President Biden, brings the United States and the European Union closer to a broader deal on the transfer of digital data.

## Under New Order, Europeans Can Complain to U.S. About Data Collection
 - [https://www.nytimes.com/2022/10/07/technology/europe-data-collection-united-states.html](https://www.nytimes.com/2022/10/07/technology/europe-data-collection-united-states.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-07 14:00:05+00:00

The executive order, signed by President Biden, brings the United States and the European Union closer to a broader deal on the transfer of digital data.

## Elon Musk’s Hidden Twitter Motives and a Metaverse Meetup
 - [https://www.nytimes.com/2022/10/07/podcasts/hard-fork-elon-musk-twitter.html](https://www.nytimes.com/2022/10/07/podcasts/hard-fork-elon-musk-twitter.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-07 10:00:02+00:00

Is the $44 billion dollar Twitter deal actually for real this time? Our hosts disagree.

## 24 Hours in the Metaverse Version of Facebook Was Surprisingly Fun
 - [https://www.nytimes.com/2022/10/07/technology/metaverse-facebook-horizon-worlds.html](https://www.nytimes.com/2022/10/07/technology/metaverse-facebook-horizon-worlds.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-07 09:00:24+00:00

Every hour of the day and night with the gamers, parents, insomniacs, preteens and aspiring comedians who are the earliest adopters of the immersive, three-dimensional internet that Mark Zuckerberg has bet the future of his company on.

## Biden Visits IBM to Promote Investments in U.S. Semiconductor Production
 - [https://www.nytimes.com/2022/10/06/us/politics/biden-ibm-semiconductors.html](https://www.nytimes.com/2022/10/06/us/politics/biden-ibm-semiconductors.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-07 00:50:56+00:00

President Biden traveled to Poughkeepsie, N.Y., to connect a $20 billion investment by IBM to the bipartisan bill meant to spur production of critical microchips.


# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## The Start of Sober October 4 and Bert's Health Improvements
 - [https://www.youtube.com/watch?v=bK3GEO-7wXY](https://www.youtube.com/watch?v=bK3GEO-7wXY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-10-07 00:00:00+00:00

Taken from JRE #1879 Sober October 4:
https://open.spotify.com/episode/6P6ISBkgCTrsd50825Beyt?si=22cc2e1cb21a43df


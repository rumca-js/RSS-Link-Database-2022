## Migrating our monorepo seamlessly from Dep to Go Modules
 - [https://monzo.com/blog/2022/09/29/migrating-our-monorepo-seamlessly-from-dep-to-go-modules](https://monzo.com/blog/2022/09/29/migrating-our-monorepo-seamlessly-from-dep-to-go-modules)
 - RSS feed: https://monzo.com
 - date published: 2022-10-07 19:46:41.364135+00:00

Since 2018, we've used Dep to manage our monorepo dependencies, but when it was deprecated switching to Go Modules was a high risk change. This post explains how we reduced that risk by iteratively updating our dependencies for a seamless migration.


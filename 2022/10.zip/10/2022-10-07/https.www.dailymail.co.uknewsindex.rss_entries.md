# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## How a joyous new book on post-war Britain reveals the past really is another country
 - [https://www.dailymail.co.uk/news/article-11293461/How-joyous-new-book-post-war-Britain-reveals-past-really-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293461/How-joyous-new-book-post-war-Britain-reveals-past-really-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 23:57:55+00:00

In 1952, as now, anyone looking for - or even fantasising about - a substantial country house without being fixated on a particular location would turn to the pages of Country Life.

## Mississippi Methodist reverend refuses to baptize baby because her parents aren't married
 - [https://www.dailymail.co.uk/news/article-11293133/Mississippi-Methodist-reverend-refuses-baptize-baby-parents-arent-married.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293133/Mississippi-Methodist-reverend-refuses-baptize-baby-parents-arent-married.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 23:54:31+00:00

Kamri Mclendon, 18, shared a letter from Rev. Warren of Hickory Grove United Methodist Church that revealed he refused to perform her baby's baptism because she's unmarried.

## University Southern Maine students demand education professor fired told class theres only two sexes
 - [https://www.dailymail.co.uk/news/article-11293139/University-Southern-Maine-students-demand-education-professor-fired-told-class-theres-two-sexes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293139/University-Southern-Maine-students-demand-education-professor-fired-told-class-theres-two-sexes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 23:34:45+00:00

University of Southern Maine graduate students walked out of class this month and are demanding officials replace Christy Hammer, a professor of education over her remarks about the sexes.

## Free nursery hours 'could be axed' under Liz Truss's radical plans to shakeup childcare provision
 - [https://www.dailymail.co.uk/news/article-11293369/Free-nursery-hours-axed-Liz-Trusss-radical-plans-shakeup-childcare-provision.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293369/Free-nursery-hours-axed-Liz-Trusss-radical-plans-shakeup-childcare-provision.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 23:34:23+00:00

Ministers are understood to be planning reforms to make the system more affordable and boost the economy by helping parents return to the office.

## John le Carre's love life was even more audacious than his stories, discovers RICHARD KAY
 - [https://www.dailymail.co.uk/news/article-11293431/John-le-Carres-love-life-audacious-stories-discovers-RICHARD-KAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293431/John-le-Carres-love-life-audacious-stories-discovers-RICHARD-KAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 23:34:21+00:00

RICHARD KAY: The words tremble with passion on the page: 'This was sex as I had never encountered it before. This was sex that only the hero and heroine can have; sex for the cameras'.

## Female carer is FIRED after shocking video emerges of her screaming at 'bad' toddlers in a mask
 - [https://www.dailymail.co.uk/news/article-11292945/Female-carer-FIRED-shocking-video-emerges-screaming-bad-toddlers-mask.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292945/Female-carer-FIRED-shocking-video-emerges-screaming-bad-toddlers-mask.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 23:31:03+00:00

A Mississippi daycare worker, known by CeeCee, apologized in a 19-minute video after footage was released earlier this week of her terrorizing 'bad' toddlers while in a Halloween mask.

## Jimmy Carr is SUED by his estranged father over the comic's new memoir Before and Laughter
 - [https://www.dailymail.co.uk/news/article-11293137/Jimmy-Carr-SUED-estranged-father-comics-new-memoir-Laughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293137/Jimmy-Carr-SUED-estranged-father-comics-new-memoir-Laughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 23:28:06+00:00

Comedian Jimmy Carr's father Jimmy Carr Snr, 77, is allegedly suing his famous son for defamation following the release of his memoir Before and Laughter.

## President Biden stops in Philadelphia to join granddaughter Natalie, 18, on a Penn college tour
 - [https://www.dailymail.co.uk/news/article-11293297/President-Biden-stops-Philadelphia-join-granddaughter-Natalie-18-Penn-college-tour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293297/President-Biden-stops-Philadelphia-join-granddaughter-Natalie-18-Penn-college-tour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 23:28:00+00:00

President Joe Biden spent two hours with granddaughter Natalie Biden as she toured the campus of Penn University in Philadelphia.

## Melbourne teen gang armed with knife chase through crowded Hoppers Crossing shopping mall
 - [https://www.dailymail.co.uk/news/article-11291339/Melbourne-teen-gang-armed-knife-chase-crowded-Hoppers-Crossing-shopping-mall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291339/Melbourne-teen-gang-armed-knife-chase-crowded-Hoppers-Crossing-shopping-mall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 23:19:12+00:00

A 14-year-old boy was in hospital after an alleged assault was caught on camera at the Pacific Werribee shops in Hoppers Crossing, in Melbourne's west on Thursday.

## Pit bulls who mauled baby boy and his two year-old sister to death had NEVER been aggressive
 - [https://www.dailymail.co.uk/news/article-11293161/Pitbulls-mauled-baby-boy-two-year-old-sister-death-NEVER-aggressive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293161/Pitbulls-mauled-baby-boy-two-year-old-sister-death-NEVER-aggressive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 22:58:47+00:00

Kirstie Jane Bennard, 30, of Millington, spent 'over 10 minutes' trying to save her children when the family's dogs began viciously attacking them on Wednesday afternoon.

## Australian hospitals inundated: Surge in respiratory viruses among young children
 - [https://www.dailymail.co.uk/news/article-11293197/Australian-hospitals-inundated-Surge-respiratory-viruses-young-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293197/Australian-hospitals-inundated-Surge-respiratory-viruses-young-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 22:57:53+00:00

Respiratory viruses, including respiratory syncytial virus and influenza, have been hitting kids more frequently and in patterns not before seen. It's left emergency rooms inundated.

## Fake heiress Anna Sorokin, 31, is flogging 'artwork' she made behind bars for up to £18,000 a piece
 - [https://www.dailymail.co.uk/news/article-11293371/Fake-heiress-Anna-Sorokin-31-flogging-artwork-bars-18-000-piece.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293371/Fake-heiress-Anna-Sorokin-31-flogging-artwork-bars-18-000-piece.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 22:47:22+00:00

On hearing the news this week of her imminent release from Orange County Correctional Facility in New York state, an excited Anna Sorokin wasted no time making plans.

## More than 200 gay couples in China have been married in UTAH over Zoom
 - [https://www.dailymail.co.uk/news/article-11292643/More-200-gay-couples-China-married-UTAH-Zoom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292643/More-200-gay-couples-China-married-UTAH-Zoom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 22:41:27+00:00

Officiant Michael Foley has been bringing couples together for about four years, including same sex love birds from China and the Philippines.

## Was Marilyn Monroe REALLY raped by JFK? TOM LEONARD asks: What's fact and what's fiction in Blonde?
 - [https://www.dailymail.co.uk/news/article-11293333/Was-Marilyn-Monroe-REALLY-raped-JFK-TOM-LEONARD-asks-Whats-fact-whats-fiction-Blonde.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293333/Was-Marilyn-Monroe-REALLY-raped-JFK-TOM-LEONARD-asks-Whats-fact-whats-fiction-Blonde.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 22:30:49+00:00

TOM LEONARD: He is John F. Kennedy and she is Marilyn Monroe, their grubby sexual encounter so transactional that his bodyguard hasn't even bothered to close the bedroom door.

## Las Vegas showgirl stabbed to death by madman with a kitchen knife 'died in her friend's arms'
 - [https://www.dailymail.co.uk/news/article-11292981/Las-Vegas-showgirl-stabbed-death-madman-kitchen-knife-died-friends-arms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292981/Las-Vegas-showgirl-stabbed-death-madman-kitchen-knife-died-friends-arms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 22:30:36+00:00

Maris Mareen Digiovanni, 30, bled out on the strip in the arms of her friend and fellow showgirl who had also been injured in the attack in broad daylight on Thursday near the Wynn hotel in Las Veags.

## Cosmetic doctor who stars on This Morning probed by medical regulator
 - [https://www.dailymail.co.uk/news/article-11293103/Cosmetic-doctor-stars-Morning-probed-medical-regulator.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293103/Cosmetic-doctor-stars-Morning-probed-medical-regulator.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 22:30:02+00:00

Dr Tijion Esho, 40, from London, has appeared on This Morning in regular slots  with Holly and Phil for the past five years.

## Eagle-eyed viewers spot BBC's latest gaffe as Graham Norton accidentally spoils Eurovision surprise
 - [https://www.dailymail.co.uk/news/article-11292985/Eagle-eyed-viewers-spot-BBCs-latest-gaffe-Graham-Norton-accidentally-spoils-Eurovision-surprise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292985/Eagle-eyed-viewers-spot-BBCs-latest-gaffe-Graham-Norton-accidentally-spoils-Eurovision-surprise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 22:22:40+00:00

This is the moment Graham Norton suffered a toe-curling blunder as he accidentally revealed prematurely which UK city had won its bid to host Eurovision.

## Herschel Walker urged mother of his child to abort a SECOND pregnancy
 - [https://www.dailymail.co.uk/news/article-11293159/Herschel-Walker-urged-mother-child-abort-SECOND-pregnancy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293159/Herschel-Walker-urged-mother-child-abort-SECOND-pregnancy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 22:12:46+00:00

A woman who told the Daily Beast Herschel Walker paid for her to have an abortion in 2009 told the New York Times he also urged to terminate a second pregnancy - and she refused.

## Man jumps to his death from Midtown Manhattan's The Row NYC hotel
 - [https://www.dailymail.co.uk/news/article-11293009/Man-jumps-death-Midtown-Manhattans-Row-NYC-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293009/Man-jumps-death-Midtown-Manhattans-Row-NYC-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:49:31+00:00

On Friday, a man jumped to his death from Midtown Manhattan's The Row NYC hotel.

## Biological sex is just a 'concept', says trustee of trans charity Mermaids
 - [https://www.dailymail.co.uk/news/article-11293125/Biological-sex-just-concept-says-trustee-trans-charity-Mermaids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293125/Biological-sex-just-concept-says-trustee-trans-charity-Mermaids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:27:00+00:00

Dr Katie McDowell, who works at King's College Hospital in south London, complained that 'everybody is obsessed with genitals' when defining sex.

## Frightening moment woman, 36, shot her boyfriend, 42, outside Brazilian apartment over an argument
 - [https://www.dailymail.co.uk/news/article-11292487/Frightening-moment-woman-36-shot-boyfriend-42-outside-Brazilian-apartment-argument.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292487/Frightening-moment-woman-36-shot-boyfriend-42-outside-Brazilian-apartment-argument.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:26:53+00:00

Authorities in São Paulo, Brazil, have launched a search for Diana da Silva, who was caught on camera shooting her boyfriend at his condominium Thursday.

## San Antonio cop is fired after sneaking up on teenage couple and shooting startled driver
 - [https://www.dailymail.co.uk/news/article-11292901/San-Antonio-cop-fired-sneaking-teenage-couple-shooting-startled-driver.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292901/San-Antonio-cop-fired-sneaking-teenage-couple-shooting-startled-driver.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:20:59+00:00

A San Antonio cop was fired on Wednesday after he shot a teenager eating in a McDonald's parking lot, and body cam footage shows the harrowing moment when the cop opened fire.

## 'Let me start with two words - Made in America': Biden's economy speech gets off to rocky start
 - [https://www.dailymail.co.uk/news/article-11292771/Let-start-two-words-America-Bidens-economy-speech-gets-rocky-start.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292771/Let-start-two-words-America-Bidens-economy-speech-gets-rocky-start.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:18:52+00:00

President Joe Biden mocked 'socialist' Republicans who voted against the infrastructure law, but have pitched the Transportation Department for project funding in their states and districts.

## NHS soup and shake diet 'could cure Type 2 diabetes'
 - [https://www.dailymail.co.uk/news/article-11293049/NHS-soup-shake-diet-cure-Type-2-diabetes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293049/NHS-soup-shake-diet-cure-Type-2-diabetes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:17:51+00:00

Professor Jonathan Valabhji, diabetes and obesity chief at NHS England, said: 'We have seen fantastic early results. We are now planning to expand the offer nationwide.

## Workers moving to a four-day week are warned they face pay cuts
 - [https://www.dailymail.co.uk/news/article-11292937/Workers-moving-four-day-week-warned-face-pay-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292937/Workers-moving-four-day-week-warned-face-pay-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:17:42+00:00

It has emerged in new research by the Chartered Institute of Personnel and Development (CIPD) that a third of companies believe their workers will be on a four-day week within the next 10 years.

## Man killed by police in Derby was wielding 'samurai-like sword'
 - [https://www.dailymail.co.uk/news/article-11292965/Man-killed-police-Derby-wielding-samurai-like-sword.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292965/Man-killed-police-Derby-wielding-samurai-like-sword.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:15:50+00:00

Witnesses in Allenton, Derby, said police tried to taser the suspect who was carrying a 'sword' and were forced to open fire when the electrical charge failed to incapacitate him.

## 'Being gay is against human nature!': Shocking views of Qatari teacher who was Beckham's interpreter
 - [https://www.dailymail.co.uk/news/article-11293047/Being-gay-against-human-nature-Shocking-views-Qatari-teacher-Beckhams-interpreter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293047/Being-gay-against-human-nature-Shocking-views-Qatari-teacher-Beckhams-interpreter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:11:58+00:00

David Beckham will pocket an estimated £150 million over a decade for a lucrative role as a global ambassador for the world's wealthiest state. But there are cracks in Beckham's ugly deal

## NYC man returns home after being away to discover strangers turned his apartment into drug den
 - [https://www.dailymail.co.uk/news/article-11291919/NYC-man-returns-home-away-discover-strangers-turned-apartment-drug-den.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291919/NYC-man-returns-home-away-discover-strangers-turned-apartment-drug-den.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:11:52+00:00

A 28-year-old Manhattan man returned home from vacation to discover that a stranger (s) had been living in his apartment - sleeping in his bed, wearing his clothes, eating his food - and doing drugs.

## Have the Russians ALREADY planted mines on Britain's ocean cables network?
 - [https://www.dailymail.co.uk/news/article-11292961/Have-Russians-planted-mines-Britains-ocean-cables-network.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292961/Have-Russians-planted-mines-Britains-ocean-cables-network.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:11:50+00:00

Ministers have ordered an urgent survey of undersea power and internet cables amid fears Russia may have already targeted them with mines.

## Giuliani finally pays alimony to ex-wife after angry judge threatened to send him to JAIL
 - [https://www.dailymail.co.uk/news/article-11292873/Giuliani-finally-pays-alimony-ex-wife-angry-judge-threatened-send-JAIL.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292873/Giuliani-finally-pays-alimony-ex-wife-angry-judge-threatened-send-JAIL.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:05:50+00:00

Former New York City Mayor Rudy Giuliani was scolded by a judge on Friday for missing court dates and delaying divorce payments to his ex-wife, and was even threatened with jail time.

## EDEN CONFIDENTIAL: Prince Harry's book 'will end on the Queen's funeral', claims Lord Jeffrey Archer
 - [https://www.dailymail.co.uk/news/article-11292927/EDEN-CONFIDENTIAL-Prince-Harrys-book-end-Queens-funeral-claims-Lord-Jeffrey-Archer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292927/EDEN-CONFIDENTIAL-Prince-Harrys-book-end-Queens-funeral-claims-Lord-Jeffrey-Archer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:05:14+00:00

RICHARD EDEN: Friends of the Duke of Sussex said he had been left 'devastated' by perceived snubs while he was here at the time of the Queen's funeral. We may not have to wait long for his story

## Michigan judicial candidate is arrested after he is filmed allegedly WHIPPING his girlfriend
 - [https://www.dailymail.co.uk/news/article-11292575/Michigan-judicial-candidate-arrested-filmed-allegedly-WHIPPING-girlfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292575/Michigan-judicial-candidate-arrested-filmed-allegedly-WHIPPING-girlfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:04:33+00:00

A Michigan judicial candidate faces domestic assault charges after he was caught on video allegedly striking his girlfriend with a belt.

## Molly Russell's father pays a heart-rending tribute to his tragic daughter
 - [https://www.dailymail.co.uk/news/article-11292825/Molly-Russells-father-pays-heart-rending-tribute-tragic-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292825/Molly-Russells-father-pays-heart-rending-tribute-tragic-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:04:10+00:00

Even the most astute observer would not have detected the turmoil in Molly Russell's mind in the days that preceded her suicide at her home in Harrow, north west London.

## Prince William's fury over ousting of the Palace insider who 'could have stopped Megxit'
 - [https://www.dailymail.co.uk/news/article-11292983/Prince-Williams-fury-ousting-Palace-insider-stopped-Megxit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292983/Prince-Williams-fury-ousting-Palace-insider-stopped-Megxit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:03:29+00:00

Sir Christopher Geidt, a former military intelligence officer, served the Queen for 15 years as her private secretary but was forced to quit in 2017 after falling out with both King Charles and Prince Andrew.

## Police launch probe as man, 94, and woman, 84 'die while walking after being hit by driver
 - [https://www.dailymail.co.uk/news/article-11293069/Police-launch-probe-man-94-woman-84-die-walking-hit-driver.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293069/Police-launch-probe-man-94-woman-84-die-walking-hit-driver.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:02:45+00:00

They died while they were on Park Lane, pictured, at the junction of Mayfair in Reading at 10.50am yesterday morning and were hit by the car.

## Grandmother, 93, died in agony following a fall after a call handler ignored her cries
 - [https://www.dailymail.co.uk/news/article-11293101/Grandmother-93-died-agony-following-fall-call-handler-ignored-cries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293101/Grandmother-93-died-agony-following-fall-call-handler-ignored-cries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:01:35+00:00

Frail Rose Belk, 93, of South Yorkshire, died in agony after a fall when care staff failed to raise the alarm - despite her begging an emergency operator: 'Help me!'

## Prisoners 'driven 200 yards to court at cost of £2m' as secure tunnel 'too cold' to walk through
 - [https://www.dailymail.co.uk/news/article-11293023/Prisoners-driven-200-yards-court-cost-2m-secure-tunnel-cold-walk-through.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11293023/Prisoners-driven-200-yards-court-cost-2m-secure-tunnel-cold-walk-through.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 21:01:09+00:00

The Ministry of Justice has spent millions of pounds of taxpayers' money over the past six years on prisoner escort vans to complete the two-minute journey.

## NYC scammer used stolen identities to rent luxury apartments for gangs
 - [https://www.dailymail.co.uk/news/article-11292761/NYC-scammer-used-stolen-identities-rent-luxury-apartments-gangs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292761/NYC-scammer-used-stolen-identities-rent-luxury-apartments-gangs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 20:33:45+00:00

LaToya Williams covered her face with a hoodie as she was photographed by DailyMail.com emerging from the luxury apartment building on the Upper West Side.

## Michelin STRIPS stars from three famed NYC restaurants
 - [https://www.dailymail.co.uk/news/article-11292217/Michelin-STRIPS-stars-three-famed-NYC-restaurants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292217/Michelin-STRIPS-stars-three-famed-NYC-restaurants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 20:33:21+00:00

Three of New York City's most frequented and trendy restaurants have been stripped of their only Michelin stars as part of an uncharacteristically aggressive annual redistribution of stars.

## China has a secret police station in NYC as part of network around the word to hunt down dissidents
 - [https://www.dailymail.co.uk/news/article-11292653/China-secret-police-station-NYC-network-word-hunt-dissidents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292653/China-secret-police-station-NYC-network-word-hunt-dissidents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 20:33:07+00:00

A new report from Safeguard Defenders, revealed that the Chinese Communist Party has at least 54 'overseas police service stations' in 30 different countries, including one in NYC.

## US Army WILL rename nine forts named after Confederate generals at a cost of $63 million
 - [https://www.dailymail.co.uk/news/article-11292687/US-Army-rename-nine-forts-named-Confederate-generals-cost-63-million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292687/US-Army-rename-nine-forts-named-Confederate-generals-cost-63-million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 20:32:25+00:00

After half-a-decade of debate, the US Department of Defense ha announced it will rename the nine US military bases that bear named of officers of the Confederacy.

## Republican Lee Zeldin gains ground in NY governor's race
 - [https://www.dailymail.co.uk/news/article-11292719/Republican-Lee-Zeldin-gains-ground-NY-governors-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292719/Republican-Lee-Zeldin-gains-ground-NY-governors-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 20:22:15+00:00

A new poll shows Rep. Lee Zeldin, the GOP nominee for New York governor, just two points behind incumbent Democratic Gov. Kathy Hochul in what should be a blow-out race.

## Eddie Murphy agrees to pay ex Mel B $35,000 in monthly child support for daughter Angel
 - [https://www.dailymail.co.uk/news/article-11292569/Eddie-Murphy-agrees-pay-ex-Mel-B-35-000-monthly-child-support-daughter-Angel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292569/Eddie-Murphy-agrees-pay-ex-Mel-B-35-000-monthly-child-support-daughter-Angel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 20:19:29+00:00

Court documents seen by DailyMail.com show the former couple has agreed to a new child support arrangement for daughter Angel Iris Murphy Brown after Mel cited a change in income.

## Horror as sleeping woman is sexually assaulted after man broke into her home
 - [https://www.dailymail.co.uk/news/article-11292849/Horror-sleeping-woman-sexually-assaulted-man-broke-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292849/Horror-sleeping-woman-sexually-assaulted-man-broke-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 20:14:12+00:00

The assault happened in the early hours of Sunday morning in Orford Lane, Warrington, pictured. A female occupant, who had been asleep, was attacked by an unknown man, according to police.

## Gisele enters Miami building - which is home to attorney's offices - WITHOUT her wedding ring
 - [https://www.dailymail.co.uk/news/article-11292749/Gisele-enters-Miami-building-home-attorneys-offices-WITHOUT-wedding-ring.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292749/Gisele-enters-Miami-building-home-attorneys-offices-WITHOUT-wedding-ring.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 20:10:32+00:00

The Brazilian supermodel, 42, and her seven-time Super Bowl winning husband, 45, have been at the center of speculation after it was revealed they are currently living in separate houses.

## At least 84 migrants found stepping out a tractor trailer at a Texas border town residence
 - [https://www.dailymail.co.uk/news/article-11291961/At-84-migrants-stepping-tractor-trailer-Texas-border-town-residence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291961/At-84-migrants-stepping-tractor-trailer-Texas-border-town-residence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 20:00:35+00:00

U.S. Border Patrol and Texas sheriff deputies found 84 migrants after a resident spotted them jumping out of a tractor trailer near a home in Olivarez, eight miles from the border with Mexico.

## Fears for British grandfather who went missing on snorkeling trip in Bali as son insists he IS alive
 - [https://www.dailymail.co.uk/news/article-11292767/Fears-British-grandfather-went-missing-snorkeling-trip-Bali-son-insists-alive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292767/Fears-British-grandfather-went-missing-snorkeling-trip-Bali-son-insists-alive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 20:00:30+00:00

The hunt for a British grandfather who has gone missing in Bali will be brought to a close shortly, authorities on the popular Asian tourist island have said.

## Inside the life of 'Little Eshay' Wayne Russell, 12, killed in 'TikTok' crash, Wollongong
 - [https://www.dailymail.co.uk/news/article-11285927/Inside-life-Little-Eshay-Wayne-Russell-12-killed-TikTok-crash-Wollongong.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11285927/Inside-life-Little-Eshay-Wayne-Russell-12-killed-TikTok-crash-Wollongong.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 19:59:05+00:00

Wayne Russell, 12, was found seriously injured at a friend's home in Balgownie, Wollongong, about 2am on Tuesday - just half an hour after a stolen car smashed into a traffic light nearby.

## Scotland's first driverless bus system launch delayed after one of the shuttles got LOST
 - [https://www.dailymail.co.uk/news/article-11292833/Scotlands-driverless-bus-launch-delayed-one-shuttles-got-LOST.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292833/Scotlands-driverless-bus-launch-delayed-one-shuttles-got-LOST.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 19:58:59+00:00

There was chaos on the launch day of Scotland's first driverless bus service nicknamed 'Itsy Bitsy Teenie Weenie Driverless Machiney', when one of the electric shuttles got lost.

## Biden blames gas prices rising on the Saudis and Russians in major speech on economy
 - [https://www.dailymail.co.uk/news/article-11289721/Biden-blames-gas-prices-rising-Saudis-Russians-major-speech-economy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289721/Biden-blames-gas-prices-rising-Saudis-Russians-major-speech-economy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 19:33:22+00:00

Biden on Friday blamed the actions of Saudi Arabia and Russia for forcing up gas prices, as he tried to say that his administration was driving down costs - while Republicans would let them rise again.

## Miss USA INSISTS she is the rightful winner after competitors claims the beauty pageant was rigged
 - [https://www.dailymail.co.uk/news/article-11292243/Miss-USA-INSISTS-rightful-winner-competitors-claims-beauty-pageant-rigged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292243/Miss-USA-INSISTS-rightful-winner-competitors-claims-beauty-pageant-rigged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 19:22:28+00:00

'I would never enter any pageant or any competition that I would know I would win. I have a lot of integrity,' Miss USA winner R'Bonney Gabriel said

## Nazanin Zaghari-Ratcliffe warns the world 'cannot turn a blind eye to Iran'
 - [https://www.dailymail.co.uk/news/article-11292539/Nazanin-Zaghari-Ratcliffe-warns-world-turn-blind-eye-Iran.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292539/Nazanin-Zaghari-Ratcliffe-warns-world-turn-blind-eye-Iran.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 19:20:58+00:00

Nazanin Zaghari-Ratcliffe, who was imprisoned in Iran for six years before her release earlier this year, has urged Liz Truss's Government to act over Iran's human rights abuses that sparked protests.

## NYC's Barnard College will offer abortion pills to students following Roe V. Wade overturn
 - [https://www.dailymail.co.uk/news/article-11291799/NYCs-Barnard-College-offer-abortion-pills-students-following-Roe-V-Wade-overturn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291799/NYCs-Barnard-College-offer-abortion-pills-students-following-Roe-V-Wade-overturn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 19:20:01+00:00

New York City's Barnard College, a private women's university, is set to offer abortion pills to its students by next year. Officials said it was in response to the overturn of Roe v. Wade.

## Ohio Attorney General: Biden's marijuana pardon is 'cynical abuse of pardon power'
 - [https://www.dailymail.co.uk/news/article-11292733/Ohio-Attorney-General-Bidens-marijuana-pardon-cynical-abuse-pardon-power.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292733/Ohio-Attorney-General-Bidens-marijuana-pardon-cynical-abuse-pardon-power.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 19:15:48+00:00

Dave Yost said Biden's announcement on Thursday showed an 'astonishing level of cynicism' - given it was 34 days before the election and he could have done it at any time.

## 'A risk to the whole planet': Zelensky warns Russia 'already preparing citizens for nuclear war'
 - [https://www.dailymail.co.uk/news/article-11292559/A-risk-planet-Zelensky-warns-Russia-preparing-citizens-nuclear-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292559/A-risk-planet-Zelensky-warns-Russia-preparing-citizens-nuclear-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 19:09:35+00:00

Ukrainian president Zelensky called on Nato allies to use new 'preventive kicks' against Russia to halt the Kremlin's saber-rattling talk of using nuclear weapons in his country

## Father-of-three, 39, reveals his horror after he was left to pick up his own severed ear
 - [https://www.dailymail.co.uk/news/article-11292705/Father-three-39-reveals-horror-left-pick-severed-ear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292705/Father-three-39-reveals-horror-left-pick-severed-ear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 19:08:34+00:00

WARNING GRAPHIC CONTENT: Darren Melling, 39, from Old Swan, went into Liverpool town centre to meet his cousin for a drink on August 27 and was later attacked (pictured).

## MEGHAN MCCAIN: I've been terrified by Biden's warning of nuclear armageddon
 - [https://www.dailymail.co.uk/news/article-11292523/MEGHAN-MCCAIN-Ive-terrified-Bidens-warning-nuclear-armageddon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292523/MEGHAN-MCCAIN-Ive-terrified-Bidens-warning-nuclear-armageddon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 18:58:04+00:00

MCCAIN: Granted, this may be a dramatic reaction on my part but excuse me if the threat of potential nuclear holocaust causes me fear and anxiety.

## CNN anchor will be off air 'for weeks' after being taken off for 'personal leave'
 - [https://www.dailymail.co.uk/news/article-11292267/CNN-anchor-air-weeks-taken-personal-leave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292267/CNN-anchor-air-weeks-taken-personal-leave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 18:33:58+00:00

CNN mainstay Jim Sciutto will be off air 'for a few weeks' after network bosses ordered him to address a 'personal situation' stemming from a 'serious fall' he suffered while in Amsterdam.

## Democrats want to CENSURE Marjorie Taylor Greene for Twitter posts saying 'Biden is Hitler'
 - [https://www.dailymail.co.uk/news/article-11292525/Democrats-want-CENSURE-Marjorie-Taylor-Greene-Twitter-posts-saying-Biden-Hitler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292525/Democrats-want-CENSURE-Marjorie-Taylor-Greene-Twitter-posts-saying-Biden-Hitler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 18:32:43+00:00

Rep. Brad Schneider (D-Ill.) has introduced legislation that would censure Green over her Twitter post comparing President Joe Biden to Hitler.

## Officials say Ohio man, 34, may not have fallen to his death while trying to do a HANDSTAND
 - [https://www.dailymail.co.uk/news/article-11292193/Officials-say-Ohio-man-34-not-fallen-death-trying-HANDSTAND.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292193/Officials-say-Ohio-man-34-not-fallen-death-trying-HANDSTAND.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 18:32:10+00:00

Police are reinvestigating the death of an Ohio man who allegedly fell to his death from the 15th floor of a hotel room at Myrtle Beach while attempting a handstand - as the family demands more answers.

## Vegan student who teaches baby Zumba and photographer animal rebellion activists threaten MORE chaos
 - [https://www.dailymail.co.uk/news/article-11292511/Vegan-student-teaches-baby-Zumba-photographer-animal-rebellion-activists-threaten-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292511/Vegan-student-teaches-baby-Zumba-photographer-animal-rebellion-activists-threaten-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 18:31:23+00:00

Sofia Fernandes Pontes who today poured milk over two high-end London department stores in a protest against dairy products is a Zumbini instructor and vegan psychology student.

## Husband of Kamala Harris's key advisor is accused of bribery and corruption in a $1BILLION lawsuit
 - [https://www.dailymail.co.uk/news/article-11288039/Husband-Kamala-Harriss-key-advisor-accused-bribery-corruption-1BILLION-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11288039/Husband-Kamala-Harriss-key-advisor-accused-bribery-corruption-1BILLION-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 18:28:42+00:00

In 2018 Clark County Commissioner Justin Jones, 47, allegedly entered an 'illicit and corrupt deal' with Nevada Governor Steve Sisolak.

## Russian woman nicknamed 'Al Capone' is accused of attacking a police officer in pub despite ASBO
 - [https://www.dailymail.co.uk/news/article-11292409/Russian-woman-nicknamed-Al-Capone-accused-attacking-police-officer-pub-despite-ASBO.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292409/Russian-woman-nicknamed-Al-Capone-accused-attacking-police-officer-pub-despite-ASBO.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 18:20:15+00:00

Russian woman Olga Woolnough, 47, dubbed 'Al Capone' when she terrorised neighbours on the south coast, was back before the courts today charged with assaulting an off-duty police officer.

## Las Vegas journalist stabbed to death by Dem-official died quickly after cut to main neck artery
 - [https://www.dailymail.co.uk/news/article-11292253/Las-Vegas-journalist-stabbed-death-Dem-official-died-quickly-cut-main-neck-artery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292253/Las-Vegas-journalist-stabbed-death-Dem-official-died-quickly-cut-main-neck-artery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 18:19:50+00:00

Las Vegas journalist Jeff German, who was stabbed to death last month, likely died quickly due to stab wounds in his neck and torso.

## Marshmallow firm pulls victory out of the fire in tax court battle
 - [https://www.dailymail.co.uk/news/article-11292459/Marshmallow-firm-pulls-victory-fire-tax-court-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292459/Marshmallow-firm-pulls-victory-fire-tax-court-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 18:14:27+00:00

American wholesaler Innovative Bites distributes Mega Marshmallows, which were deemed to not be confectionery at the tribunal. Pictured: Roasting marshmallows (stock image).

## London knife horror as man stabs himself on train at Euston station in front of stunned passengers
 - [https://www.dailymail.co.uk/news/article-11292463/London-knife-horror-man-stabs-train-Euston-station-stunned-passengers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292463/London-knife-horror-man-stabs-train-Euston-station-stunned-passengers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 18:03:52+00:00

A man stabbed himself on board a train in front of shocked passengers On board a train at Euston station today. Officers were called to the station today to reports of a man with serious injuries.

## Netflix's Dahmer BEATS Squid Game and Bridgerton to become streamer's most-watched show in one week
 - [https://www.dailymail.co.uk/news/article-11292177/Netflixs-Dahmer-BEATS-Squid-Game-Bridgerton-streamers-watched-one-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292177/Netflixs-Dahmer-BEATS-Squid-Game-Bridgerton-streamers-watched-one-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 17:51:21+00:00

Netflix's recent series 'Monster: The Jeffrey Dahmer Story' continues to make streaming records on the platform.

## Rugby fan faces jail after smashing a glass into woman's face while watching game in a pub
 - [https://www.dailymail.co.uk/news/article-11292551/Rugby-fan-faces-jail-smashing-glass-womans-face-watching-game-pub.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292551/Rugby-fan-faces-jail-smashing-glass-womans-face-watching-game-pub.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 17:37:55+00:00

Ben England, 27, was watching the game in the Wolfpack in Fulham, west London when Kim Graham took exception to something he said about the Springboks on July 31 last year.

## Uvalde suspends ENTIRE school district police force over failed response to school massacre
 - [https://www.dailymail.co.uk/news/article-11292461/Uvalde-suspends-ENTIRE-school-district-police-force-failed-response-school-massacre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292461/Uvalde-suspends-ENTIRE-school-district-police-force-failed-response-school-massacre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 17:33:25+00:00

The entire school district police force in Uvalde, Texas, has been suspended over their failed response to the devastating massacre at Robb Elementary School.

## White House deflects questions about charges for Hunter Biden after bombshell report
 - [https://www.dailymail.co.uk/news/article-11292401/White-House-deflects-questions-charges-Hunter-Biden-bombshell-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292401/White-House-deflects-questions-charges-Hunter-Biden-bombshell-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 17:31:10+00:00

The White House dodged questions on Friday  about a bombshell report suggesting the president's son could be charged with tax crimes and lying about buying a gun.

## White House says no new intelligence that Putin is 'imminently' preparing to use nuclear weapons
 - [https://www.dailymail.co.uk/news/article-11292429/White-House-says-no-new-intelligence-Putin-imminently-preparing-use-nuclear-weapons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292429/White-House-says-no-new-intelligence-Putin-imminently-preparing-use-nuclear-weapons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 17:29:30+00:00

The White House on Friday said there is no new intelligence that caused President Joe Biden to warn of a heightened risk of Armageddon concerning Vladimir Putin's threat to use nuclear weapons.

## Nicola Sturgeon insists 'abusive men are a risk to women, not trans women' in row with JK Rowling
 - [https://www.dailymail.co.uk/news/article-11292513/Nicola-Sturgeon-insists-abusive-men-risk-women-not-trans-women-row-JK-Rowling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292513/Nicola-Sturgeon-insists-abusive-men-risk-women-not-trans-women-row-JK-Rowling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 17:28:09+00:00

Nicola Sturgeon has doubled down in her row with JK Rowling over trans rights, telling an interview that 'abusive men are the risk to women, not trans women'.

## Friends could hear the screams of murdered Purdue student through their video game headsets
 - [https://www.dailymail.co.uk/news/article-11291667/Friends-hear-screams-murdered-Purdue-student-video-game-headsets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291667/Friends-hear-screams-murdered-Purdue-student-video-game-headsets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 17:20:07+00:00

Varun Manish Chheda, 20, was heard screaming as he was killed on Wednesday morning while his friends listened to his chilling cries for help while on Discord.

## Shocking moment 19-year-old fatally stabbed two men to death outside takeaway
 - [https://www.dailymail.co.uk/news/article-11292269/Shocking-moment-19-year-old-fatally-stabbed-two-men-death-outside-takeaway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292269/Shocking-moment-19-year-old-fatally-stabbed-two-men-death-outside-takeaway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 17:16:39+00:00

Footage shows Amrit Jhagra, 19, stab Ryan Theobald, 20, three times - before going onto stab Janis Kozlovskis, 17, in Doncaster, South Yorkshire, in January this year.

## Prince Harry and Meghan Markle attend Jack Johnson gig in California
 - [https://www.dailymail.co.uk/news/article-11290751/Prince-Harry-Meghan-Markle-attend-Jack-Johnson-gig-California.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290751/Prince-Harry-Meghan-Markle-attend-Jack-Johnson-gig-California.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 17:09:04+00:00

Prince Harry and Meghan Markle had a night out at a Jack Johnson gig in California as they were seen for the first time since returning to the US after the Queen's funeral.

## Veterinary nurse who caused chaos on Thomas Cook flight after downing bottle of vodka won't lose job
 - [https://www.dailymail.co.uk/news/article-11292271/Veterinary-nurse-caused-chaos-Thomas-Cook-flight-downing-bottle-vodka-wont-lose-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292271/Veterinary-nurse-caused-chaos-Thomas-Cook-flight-downing-bottle-vodka-wont-lose-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 17:06:15+00:00

Katherine Heyes, from Wigan, was 'screaming and swearing at everyone' - including her own three-year-old child - during the Thomas Cook flight to the Turkish resort city of Antalya.

## PCSO, 37, appears in court accused of a string of sexual offences
 - [https://www.dailymail.co.uk/news/article-11292327/PCSO-37-appears-court-accused-string-sexual-offences.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292327/PCSO-37-appears-court-accused-string-sexual-offences.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:59:06+00:00

PCSO Matthew Shaw from Deryshire Police, who is accused of a string of sexual offences, including filming children in swimming pool changing rooms, has appeared in court.

## Gay Palestinian is found beheaded after he was abducted while seeking asylum in Israel
 - [https://www.dailymail.co.uk/news/article-11292195/Gay-Palestinian-beheaded-abducted-seeking-asylum-Israel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292195/Gay-Palestinian-beheaded-abducted-seeking-asylum-Israel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:58:43+00:00

Palestinian police arrested a suspect in the killing of a man who was found decapitated. Ahmad Abu Marhia had been receiving death threats because he was gay.

## Pub landlady is jailed for 10 years for stabbing barmaid
 - [https://www.dailymail.co.uk/news/article-11292457/Pub-landlady-jailed-10-years-stabbing-barmaid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292457/Pub-landlady-jailed-10-years-stabbing-barmaid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:58:38+00:00

Luisa Santos, 47, was convicted of trying to murder Hannah Pritchett, 18, after claiming her husband had called out her name in bed at the Three Horseshoes Pub in Warwickshire.

## Parents charged with murdering their 11-week-old daughter who died after suffering 'bite marks'
 - [https://www.dailymail.co.uk/news/article-11292287/Parents-charged-murdering-11-week-old-daughter-died-suffering-bite-marks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292287/Parents-charged-murdering-11-week-old-daughter-died-suffering-bite-marks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:54:46+00:00

Labourer Krunal Prajapati, 26, and Rinkalben Prajapati, 23, of Barnet, north-west London, appeared at the Old Bailey on Friday charged with murdering their daughter Hazel Prajapati.

## Stonewall survey finds more than a quarter of 'Gen Z' 16 to 25-year-olds identify as LGBTQ
 - [https://www.dailymail.co.uk/news/article-11292135/Stonewall-survey-finds-quarter-Gen-Z-16-25-year-olds-identify-LGBTQ.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292135/Stonewall-survey-finds-quarter-Gen-Z-16-25-year-olds-identify-LGBTQ.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:52:49+00:00

Stonewall claims 71 per cent of Gen Z respondents - those aged 16 to 26 -  identify as straight. For the Baby Boomer generation - those aged 56 to 75 - 91 per cent described themselves as straight.

## Infected blood inquiry reaches 'significant milestone'
 - [https://www.dailymail.co.uk/news/article-11292285/Infected-blood-inquiry-reaches-significant-milestone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292285/Infected-blood-inquiry-reaches-significant-milestone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:41:21+00:00

Theresa May, the then- UK prime minister, announced the inquiry in 2017, which began in 2018 and is due to conclude next year. Pictured: Inquiry chairman Sir Brian Langstaff in 2021.

## Panic erupts at NYC's Union Square subway station as 'mass' of people are left coughing
 - [https://www.dailymail.co.uk/news/article-11292249/Panic-erupts-NYCs-Union-Square-subway-station-mass-people-left-coughing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292249/Panic-erupts-NYCs-Union-Square-subway-station-mass-people-left-coughing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:34:08+00:00

Panic erupted at a New York City subway station after a 'mass' of people, including police officers, started coughing after 'pepper stay' was released in the air.

## Emergency services rush to scene as Irish petrol station explodes in massive fireball
 - [https://www.dailymail.co.uk/news/article-11292303/Emergency-services-rush-scene-Irish-petrol-station-explodes-massive-fireball.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292303/Emergency-services-rush-scene-Irish-petrol-station-explodes-massive-fireball.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:29:18+00:00

Several people are feared seriously injured after a petrol station in Ireland exploded this afternoon. The Applegreen filling station in Co Donegal was pictured hollowed out

## The Diddly Squat battle: Tourists praise Clarkson's farm restaurant as camp boss sees bookings surge
 - [https://www.dailymail.co.uk/news/article-11292115/The-Diddly-Squat-battle-Tourists-praise-Clarksons-farm-restaurant-camp-boss-sees-bookings-surge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292115/The-Diddly-Squat-battle-Tourists-praise-Clarksons-farm-restaurant-camp-boss-sees-bookings-surge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:28:14+00:00

EXCLUSIVE Tourists have praised Jeremy Clarkson's Diddly Squat Farm shop and campsite manager said it has seen a surge in bookings thanks to fans of the presenter amid an ongoing row the council.

## Victorian Society President Griff Rhys Jones fights to save Westminster's under-threat gas lamps
 - [https://www.dailymail.co.uk/news/article-11292021/Victorian-Society-President-Griff-Rhys-Jones-fights-save-Westminsters-threat-gas-lamps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292021/Victorian-Society-President-Griff-Rhys-Jones-fights-save-Westminsters-threat-gas-lamps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:25:39+00:00

MailOnline exclusively revealed in July last year that Westminster Council was in the process of converting the 305 lamps under its control with LED versions that it says are more eco-friendly.

## Mother is still fighting for her life after BOTH her kids were mauled to death by two pet pit bulls
 - [https://www.dailymail.co.uk/news/article-11291751/Mother-fighting-life-kids-mauled-death-two-pet-pit-bulls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291751/Mother-fighting-life-kids-mauled-death-two-pet-pit-bulls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:21:12+00:00

Kirstie Jane Bennard, 30, has both her 'arms and legs wrapped up 'completely' after fighting off her two pit bulls who fatally attacked her children on Wednesday.

## Rail strike action will bring chaos to Britain on Saturday with just one-in-15 trains running
 - [https://www.dailymail.co.uk/news/article-11291941/Rail-strike-action-bring-chaos-Britain-Saturday-just-one-15-trains-running.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291941/Rail-strike-action-bring-chaos-Britain-Saturday-just-one-15-trains-running.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:19:08+00:00

Rail passengers will face another weekend of travel chaos on Saturday with thousands of train staff set to strike in a long-running row over pay. Services across the UK will be affected.

## No parent should ever endure horror of kids mauled to death by the family pet: BETHANY MANDEL
 - [https://www.dailymail.co.uk/news/article-11291983/No-parent-endure-horror-kids-mauled-death-family-pet-BETHANY-MANDEL.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291983/No-parent-endure-horror-kids-mauled-death-family-pet-BETHANY-MANDEL.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:13:04+00:00

MANDEL: Sheepdogs were bred to herd sheep. Golden retrievers were bred to retrieve. And pit bulls were bred to bite. Why on Earth would a family with small children keep pit bulls in the home?

## Woman, 23, who survived 2016 Brussels airport ISIS bomb is 'euthanised' in Belgium
 - [https://www.dailymail.co.uk/news/article-11291995/Woman-23-survived-2016-Brussels-airport-ISIS-bomb-euthanised-Belgium.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291995/Woman-23-survived-2016-Brussels-airport-ISIS-bomb-euthanised-Belgium.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:10:26+00:00

Shanti De Corte, 23, was walking through the departures lounge of the Belgian airport in Zaventem on March 22, 2016 when Islamic State terrorists detonated a bomb

## Recording reveals John Lennon said he could do nothing to stop Vietnam War before 'bed-in for peace'
 - [https://www.dailymail.co.uk/news/article-11292107/Recording-reveals-John-Lennon-said-stop-Vietnam-War-bed-peace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292107/Recording-reveals-John-Lennon-said-stop-Vietnam-War-bed-peace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:09:55+00:00

John Lennon admitted there was nothing he could do to stop the Vietnam War, four years before his famous 'bed-in for peace' protest, a recording which has emerged 57 years on reveals.

## Poker player tries to prove $120k ring doesn't vibrate by taking it to jeweler who LENT it to her
 - [https://www.dailymail.co.uk/news/article-11291845/Poker-player-tries-prove-120k-ring-doesnt-vibrate-taking-jeweler-LENT-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291845/Poker-player-tries-prove-120k-ring-doesnt-vibrate-taking-jeweler-LENT-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 16:03:37+00:00

Robbi Jade Lew, 35, beat Garrett Adelstein during a Hustler Casino live streamed game of Texas hold'em  - but her sensational win caused rumors of cheating to swirl.

## 'Nurses can't afford petrol or school uniforms for their kids': NHS staff say why they'll strike
 - [https://www.dailymail.co.uk/news/article-11291511/Nurses-afford-petrol-school-uniforms-kids-NHS-staff-say-theyll-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291511/Nurses-afford-petrol-school-uniforms-kids-NHS-staff-say-theyll-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:59:09+00:00

NHS nurses Hilary Nelson, 46, and Julie Lamberth, 51, have told the MailOnline voting for strike action is not a decision they have taken lightly, but say they are in a 'crisis' and have 'no choice'.

## Republican James Comer: Federal charges for Hunter are just 'tip of the iceberg'
 - [https://www.dailymail.co.uk/news/article-11291977/Republican-James-Comer-Federal-charges-Hunter-just-tip-iceberg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291977/Republican-James-Comer-Federal-charges-Hunter-just-tip-iceberg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:49:52+00:00

Rep. James Comer, the ranking Republican on the House Committee on Oversight and Reform, believes the president's son is a 'national security threat'.

## Ex-swimwear model, 32, who shot dead her British millionaire ex-boyfriend in the Costa del Sol freed
 - [https://www.dailymail.co.uk/news/article-11291881/Ex-swimwear-model-32-shot-dead-British-millionaire-ex-boyfriend-Costa-del-Sol-freed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291881/Ex-swimwear-model-32-shot-dead-British-millionaire-ex-boyfriend-Costa-del-Sol-freed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:47:40+00:00

The former swimwear model who shot dead her British millionaire ex-boyfriend in his luxury Costa del Sol home has been freed from prison - just eight years after she gunned him down.

## North Carolina Father dies when GPS guided him off the edge of a bridge that washed away in 2013
 - [https://www.dailymail.co.uk/news/article-11291757/North-Carolina-Father-dies-GPS-guided-edge-bridge-washed-away-2013.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291757/North-Carolina-Father-dies-GPS-guided-edge-bridge-washed-away-2013.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:37:37+00:00

A North Carolina father of two died after his daughter's ninth birthday party, when he GPS placed on the path of a bridge that was washed away in 2013.

## Eleven activists hit with federal charges for 'physically' blockading Nashville abortion clinic
 - [https://www.dailymail.co.uk/news/article-11291753/Eleven-activists-hit-federal-charges-physically-blockading-Nashville-abortion-clinic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291753/Eleven-activists-hit-federal-charges-physically-blockading-Nashville-abortion-clinic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:32:28+00:00

They have been charged  with violating the FACE Act when they entered Carafem Health Center Clinic in Mt Juliet on March 5 2021. Eight of them face up to 11 years behind bars if convicted.

## How did war of words between JK Rowling and Nicola Sturgeon start?
 - [https://www.dailymail.co.uk/news/article-11291737/How-did-war-words-JK-Rowling-Nicola-Sturgeon-start.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291737/How-did-war-words-JK-Rowling-Nicola-Sturgeon-start.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:31:57+00:00

The foes have never been photographed together despite being arguably the two most influential women in Scotland - and have been on opposite sides on major issues since Indyref 1.

## Belarus dictator Lukashenko gives Putin a voucher for a tractor for his 70th birthday
 - [https://www.dailymail.co.uk/news/article-11292109/Belarus-dictator-Lukashenko-gives-Putin-voucher-tractor-70th-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11292109/Belarus-dictator-Lukashenko-gives-Putin-voucher-tractor-70th-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:30:13+00:00

Vladimir Putin was presented with an unusual gift for his 70th birthday today - a voucher for a tractor from the president of Belarus.

## NYC Mayor Eric Adams says city will need to spend $1 BILLION to care for 17,000 migrants
 - [https://www.dailymail.co.uk/news/article-11291889/NYC-Mayor-Eric-Adams-says-city-need-spend-1-BILLION-care-17-000-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291889/NYC-Mayor-Eric-Adams-says-city-need-spend-1-BILLION-care-17-000-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:29:51+00:00

New York City Mayor Eric Adams said the city will to spend $1billion to take care of 17,000 migrants being bussed from Southwest states as he declares a state of emergency.

## Biden has drained the oil stockpile to the lowest point in 40 years
 - [https://www.dailymail.co.uk/news/article-11291625/Biden-drained-oil-stockpile-lowest-point-40-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291625/Biden-drained-oil-stockpile-lowest-point-40-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:29:41+00:00

President Joe Biden has drained the Strategic Petroleum Reserve to its lowest level in 40 years as he tries to combat rising gas prices and shortages in crude oil tied to Russia's invasion of the Ukraine.

## Former minister Conor Burns has Tory whip suspended amid 'complaints about his behaviour'
 - [https://www.dailymail.co.uk/news/article-11291965/Former-minister-Conor-Burns-Tory-whip-suspended-amid-complaints-behaviour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291965/Former-minister-Conor-Burns-Tory-whip-suspended-amid-complaints-behaviour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:29:13+00:00

A Tory former minister has been suspended by the party amid allegations about his behaviour at its annual conference.

## Kanye West wore a lanyard with an image of a fetus during his Tucker Carlson interview
 - [https://www.dailymail.co.uk/news/article-11291669/Kanye-West-wore-lanyard-image-fetus-Tucker-Carlson-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291669/Kanye-West-wore-lanyard-image-fetus-Tucker-Carlson-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:26:33+00:00

Kanye West appeared for an interview with Tucker Carlson on the anchor's nightly Fox News program yesterday wearing a lanyard featuring an ultrasound image of a fetus.

## Senate's Number Two Democrat blasts Saudis for siding with Putin as key lawmakers push 'NOPEC' bill
 - [https://www.dailymail.co.uk/news/article-11291829/Senates-Number-Two-Democrat-blasts-Saudis-siding-Putin-key-lawmakers-push-NOPEC-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291829/Senates-Number-Two-Democrat-blasts-Saudis-siding-Putin-key-lawmakers-push-NOPEC-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:26:29+00:00

Senate Majority Whip Richard Durbin tore into Saudi Arabia after OPEC+ announced planned oil production cuts, saying it 'doesn't seem to share our values' amid Russia's war on Ukraine.

## Moment bus driver who hit and killed pensioner takes his eyes off the road to find a chocholate bar
 - [https://www.dailymail.co.uk/news/article-11291885/Moment-bus-driver-hit-killed-pensioner-takes-eyes-road-chocholate-bar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291885/Moment-bus-driver-hit-killed-pensioner-takes-eyes-road-chocholate-bar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:20:20+00:00

Garfield Balfour, 50, knocked over Arthur Gowrie, 88, in Southwark, as he rummaged around his cab for the treat, Inner London Crown Court heard.

## Scotland Yard's first black police officer rails against Met racism
 - [https://www.dailymail.co.uk/news/article-11291577/Scotland-Yards-black-police-officer-rails-against-Met-racism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291577/Scotland-Yards-black-police-officer-rails-against-Met-racism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:14:38+00:00

Retired detective sergeant Norwell Roberts, 76, signed up in 1967 and was repeatedly abused while working at Bow Street police station.

## Comic Con returns to New York City with mask mandate STILL in place
 - [https://www.dailymail.co.uk/news/article-11291433/Comic-returns-New-York-City-mask-mandate-place.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291433/Comic-returns-New-York-City-mask-mandate-place.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:14:12+00:00

The New York City Comic Con has returned and is expected to have higher attendance levels than the previous two years, despite a mask mandate still in place at the event.

## Pro-life Republican admits abortion ban 'stinks' for women
 - [https://www.dailymail.co.uk/news/article-11291663/Pro-life-Republican-admit-abortion-ban-stinks-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291663/Pro-life-Republican-admit-abortion-ban-stinks-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 15:11:52+00:00

A pro-life Utah Republican lawmaker up for re-election stunned his Democratic opponent during a Thursday night debate when commenting on abortion bans.

## Boy, 15, is locked up for 15 years for murder of father-of-three, 45
 - [https://www.dailymail.co.uk/news/article-11291917/Boy-15-locked-15-years-murder-father-three-45.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291917/Boy-15-locked-15-years-murder-father-three-45.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 14:56:16+00:00

The teenage killer, who cannot be named for legal reasons, murdered stonemason Jamie Markham, 45, after spending days shouting outside the victim's home in Chingford.

## Experts' energy saving tips that could axe nearly £500 from your bills
 - [https://www.dailymail.co.uk/news/article-11291235/Experts-energy-saving-tips-axe-nearly-500-bills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291235/Experts-energy-saving-tips-axe-nearly-500-bills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 14:36:46+00:00

Energy experts at Octopus have provided a series of eight top tips that they say could save households £488 a year - from turning down your boiler flow temperature to avoiding using the tumble drier.

## Boy, 15, is locked up for 15 years for murder of father-of-three, 45, who was stabbed to death
 - [https://www.dailymail.co.uk/news/article-11291935/Boy-15-locked-15-years-murder-father-three-45-stabbed-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291935/Boy-15-locked-15-years-murder-father-three-45-stabbed-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 14:36:28+00:00

James Markham, 45 was stabbed in the back, armpit and chest in east London on August 9 after confronting the boy - who had already been banned from the area.

## Murder suspect, 26, wipes away tears as he appears in court charged with killing two-year-old girl
 - [https://www.dailymail.co.uk/news/article-11291711/Murder-suspect-26-wipes-away-tears-appears-court-charged-killing-two-year-old-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291711/Murder-suspect-26-wipes-away-tears-appears-court-charged-killing-two-year-old-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 14:20:21+00:00

Michael Daymond, 26, has been accused of murdering Maya Louise Chappell on September 28 when she was airlifted to the Royal Victoria Infirmary in Newcastle after being found in critical condition.

## Tom Brady is 'very hurt' by Gisele Bündchen split as it emerges she's talking to a divorce attorney
 - [https://www.dailymail.co.uk/news/article-11291467/Tom-Brady-hurt-Gisele-B-ndchen-split-emerges-shes-talking-divorce-attorney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291467/Tom-Brady-hurt-Gisele-B-ndchen-split-emerges-shes-talking-divorce-attorney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 14:20:06+00:00

Tom Brady, 45, is 'very hurt' by his impending divorce from supermodel Gisele Bündchen, 42. A source said the quarterback 'doesn't want to fight' and through the divorce.

## Sadiq Khan suggests he could still plough on with ULEZ expansion despite survey opposition
 - [https://www.dailymail.co.uk/news/article-11291573/Sadiq-Khan-suggests-plough-ULEZ-expansion-despite-survey-opposition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291573/Sadiq-Khan-suggests-plough-ULEZ-expansion-despite-survey-opposition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 14:19:41+00:00

The Mayor of London today suggested he could ignore the results of TfL consultation because his plan is 'not a numbers game' and the survey is 'not a referendum'.

## 'Throuple' cop accuses police force of bullying him after his three-way relationship was revealed
 - [https://www.dailymail.co.uk/news/article-11291501/Throuple-cop-accuses-police-force-bullying-three-way-relationship-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291501/Throuple-cop-accuses-police-force-bullying-three-way-relationship-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 14:14:59+00:00

David Kowal and his wife of five years Loren Kowal are in a 'throuple' with a girlfriend they share, Alana Dean. But despite being in a position some men dream of, all is not well for the ex-cop.

## The shocking emails, texts, and photos that could land Hunter Biden in Federal prison
 - [https://www.dailymail.co.uk/news/article-11289031/Hunter-Biden-facing-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289031/Hunter-Biden-facing-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 14:13:52+00:00

Since 2019 the Bureau has been in possession of revealing emails, furtive text messages and photographs from Hunter's abandoned laptop he never intended to fall into law enforcement's hands.

## Suspect who murdered Sikh family and eight-month-old baby had year-long feud with them
 - [https://www.dailymail.co.uk/news/article-11291431/Suspect-murdered-Sikh-family-eight-month-old-baby-year-long-feud-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291431/Suspect-murdered-Sikh-family-eight-month-old-baby-year-long-feud-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 14:12:31+00:00

The man suspected of kidnapping and killing a California Sikh family, including their eight-month-old baby, worked for the family's trucking business and had a long-running feud with them.

## Chicago Mayor Lori Lightfoot shares video of herself CROONING to launch new karaoke contest
 - [https://www.dailymail.co.uk/news/article-11291465/Chicago-Mayor-Lori-Lightfoot-shares-video-CROONING-launch-new-karaoke-contest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291465/Chicago-Mayor-Lori-Lightfoot-shares-video-CROONING-launch-new-karaoke-contest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 14:11:13+00:00

Chicago Mayor Lori Lightfoot went on TikTok to promote a citywide karaoke contest while crime continues to run rampant in the Windy City, with violent crime up 37 percent from last year.

## Vladimir Putin turns 70: The images that show the Russian leader's unpredictable nature
 - [https://www.dailymail.co.uk/news/article-11291221/Vladimir-Putin-turns-70-images-Russian-leaders-unpredictable-nature.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291221/Vladimir-Putin-turns-70-images-Russian-leaders-unpredictable-nature.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 14:00:06+00:00

The Russian despot has dominated Russia for nearly 23 years since being handpicked by President Boris Yeltsin as his preferred successor in a surprise announcement on New Year's Eve 1999.

## Cruel blow in fundraiser for Melbourne rollercoaster victim Shylah Rodden
 - [https://www.dailymail.co.uk/news/melbourne/article-11290191/Cruel-blow-fundraiser-Melbourne-rollercoaster-victim-Shylah-Rodden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/melbourne/article-11290191/Cruel-blow-fundraiser-Melbourne-rollercoaster-victim-Shylah-Rodden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:57:43+00:00

A fundraiser established to help rollercoaster victim Shylah Rodden has been cruelly snubbed as she faces a long and costly recovery from horrific injuries.

## Elderly Ukrainian woman reunited with her pet dog after it ran off during Russian shelling
 - [https://www.dailymail.co.uk/news/article-11291581/Elderly-Ukrainian-woman-reunited-pet-dog-ran-Russian-shelling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291581/Elderly-Ukrainian-woman-reunited-pet-dog-ran-Russian-shelling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:53:18+00:00

A woman in Kherson, Ukraine, burst into tears after being reunited with her beloved dog after it went missing during the recent shelling of the city by Russian forces.

## How Mata Hari was executed for being a traitor after being accused of spying for Germany in WWI
 - [https://www.dailymail.co.uk/news/article-11291075/How-Mata-Hari-executed-traitor-accused-spying-Germany-WWI.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291075/How-Mata-Hari-executed-traitor-accused-spying-Germany-WWI.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:46:39+00:00

Dutch exotic dancer Mata Hari, who was enlisted to spy for France, was executed by firing squad at the age of 41 after being convicted of also acting as a double agent for Germany.

## Drugs gang take over footballer Jermaine Pennant's abandoned £3m home
 - [https://www.dailymail.co.uk/news/article-11291435/Drugs-gang-footballer-Jermaine-Pennants-abandoned-3m-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291435/Drugs-gang-footballer-Jermaine-Pennants-abandoned-3m-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:34:19+00:00

The five-bedroom luxury house was bought by Pennant in 2006 when he joined Liverpool  and he lived there for three years before moving to Spanish side Real Zaragoza.

## UK energy crisis will be worse next year than this year, expert warns
 - [https://www.dailymail.co.uk/news/article-11287843/UK-energy-crisis-worse-year-year-expert-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11287843/UK-energy-crisis-worse-year-year-expert-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:32:46+00:00

James Rogers, co-founder of the think-tank Council on Geostrategy, told MailOnline that Europe can get through this winter because it stockpiled Russia gas before the supplies were cut off.

## Man, 26, dies after tree fell across road in Manchester as another man is injured
 - [https://www.dailymail.co.uk/news/article-11291595/Man-26-dies-tree-fell-road-Manchester-man-injured.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291595/Man-26-dies-tree-fell-road-Manchester-man-injured.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:32:29+00:00

The unnamed man, 26, died when ferocious weather in Sale, Greater Manchester caused the tree to fall on top of him, smashing him to death. Another person was also injured.

## Amusing footage captures the moment a lost dog grinds traffic to a halt as he walks five miles home
 - [https://www.dailymail.co.uk/news/article-11291205/Amusing-footage-captures-moment-lost-dog-grinds-traffic-halt-walks-five-miles-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291205/Amusing-footage-captures-moment-lost-dog-grinds-traffic-halt-walks-five-miles-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:28:55+00:00

Pip the podencos wandered off while chasing squirrels on a walk in Bristol with owner, Libby Bowles, 47, on September 18. Now CCTV has captured his 4.8-mile adventure.

## Keith Bennett: Police find NO evidence of human remains on Saddleworth Moor
 - [https://www.dailymail.co.uk/news/article-11291399/Keith-Bennett-Police-NO-evidence-human-remains-Saddleworth-Moor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291399/Keith-Bennett-Police-NO-evidence-human-remains-Saddleworth-Moor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:28:31+00:00

The 12-year-old's body has been missing ever since he was snatched and slain by notorious serial killers Ian Brady and Myra Hindley 58 years ago.

## Quad bike-riding thieves steal and sell 100 sheep as criminals 'weaponise' cost of living crisis
 - [https://www.dailymail.co.uk/news/article-11291411/Quad-bike-riding-thieves-steal-sell-100-sheep-criminals-weaponise-cost-living-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291411/Quad-bike-riding-thieves-steal-sell-100-sheep-criminals-weaponise-cost-living-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:26:57+00:00

Ed Lovejoy, 40, works on his farm in Woodchurch, Kent, and was horrified when rounding up his ewes last month to find that 116 had vanished.

## Animal Rebellion activists pour milk in Fortnum & Mason and Selfridges stores
 - [https://www.dailymail.co.uk/news/article-11291391/Animal-Rebellion-activists-pour-milk-Fortnum-Mason-Selfridges-stores.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291391/Animal-Rebellion-activists-pour-milk-Fortnum-Mason-Selfridges-stores.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:24:41+00:00

Two vegan activists today poured milk over the floor of the food halls at Fortnum & Mason and Selfridges in London as part of their campaign for a 'plant-based future'.

## North Wales council refuses to accept William as the 'archaic, oppressive' Prince of Wales
 - [https://www.dailymail.co.uk/news/article-11291329/North-Wales-council-refuses-accept-William-archaic-oppressive-Prince-Wales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291329/North-Wales-council-refuses-accept-William-archaic-oppressive-Prince-Wales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:21:28+00:00

Instead of reflecting on the town's royal history with pride, one councillor described the 1969 ceremony as 'a circus' adding 'this nightmare is on us again'.

## Classic cottage where Roald Dahl's mum and sisters lived in World War II is on the market
 - [https://www.dailymail.co.uk/news/article-11291179/Classic-cottage-Roald-Dahls-mum-sisters-lived-World-War-II-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291179/Classic-cottage-Roald-Dahls-mum-sisters-lived-World-War-II-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:21:11+00:00

The quaint three bed, one bath cottage in Grendon Underwood, west Buckinghamshire, featured in Dahl's autobiography 'Going Solo'.

## Mother of woman mauled to death by her XL Bully says she warned her 'something bad' would happen
 - [https://www.dailymail.co.uk/news/article-11291089/Mother-woman-mauled-death-XL-Bully-says-warned-bad-happen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291089/Mother-woman-mauled-death-XL-Bully-says-warned-bad-happen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:16:41+00:00

Mother-of-two Joanne Robinson, 43, was killed by her American Bully XL dog, Rocco, in July. Her mother Dot has now said she 'warned her something bad was going to happen'.

## SNOW is on the way as Britain faces a week of heavy rain amid flood warnings
 - [https://www.dailymail.co.uk/news/article-11291343/SNOW-way-Britain-faces-week-heavy-rain-amid-flood-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291343/SNOW-way-Britain-faces-week-heavy-rain-amid-flood-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:15:19+00:00

Snow is on the way next week as Britain faces heavy rain, blustery winds and and 'changeable' wet and windy weather with flood warnings in some parts, as weather experts predict cold winter ahead.

## US added 263,000 jobs in September in good news for Biden
 - [https://www.dailymail.co.uk/news/article-11291447/US-added-263-000-jobs-September-good-news-Biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291447/US-added-263-000-jobs-September-good-news-Biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:09:31+00:00

The September jobs report came in better than expected, showing a cooling off in hiring but still a solid number of jobs.

## Shocking moment thug repeatedly stabs and kills a stranger in unprovoked NYC subway attack
 - [https://www.dailymail.co.uk/news/article-11291485/Shocking-moment-thug-repeatedly-stabs-kills-stranger-unprovoked-NYC-subway-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291485/Shocking-moment-thug-repeatedly-stabs-kills-stranger-unprovoked-NYC-subway-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:08:57+00:00

A New York City man has died after he was brutally stabbed by a stranger as he exited a subway train in the Bronx on Thursday night, and the shocking ordeal was captured on surveillance footage.

## DOJ told Trump lawyers he has NOT returned all White House documents
 - [https://www.dailymail.co.uk/news/article-11291421/DOJ-told-Trump-lawyers-NOT-returned-White-House-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291421/DOJ-told-Trump-lawyers-NOT-returned-White-House-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 13:05:12+00:00

A senior official at the Department of Justice told former President Donald Trump's legal team that the government does not believe he returned all the documents he took from the White House.

## Brick-wielding US tourist goes on vandalism rampage and hurls abuse at furious locals in Thailand
 - [https://www.dailymail.co.uk/news/article-11290837/Brick-wielding-tourist-goes-vandalism-rampage-hurls-abuse-furious-locals-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290837/Brick-wielding-tourist-goes-vandalism-rampage-hurls-abuse-furious-locals-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 12:55:11+00:00

The holidaymaker, named by police as Andigo, 45, was reportedly caught kicking trash bins and destroying property along a street in Nakhon Si Thammarat province on the afternoon of October 5.

## Conservative CNN analyst says she was kept off air by old boss Jeff Zucker
 - [https://www.dailymail.co.uk/news/article-11291307/Conservative-CNN-analyst-says-kept-air-old-boss-Jeff-Zucker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291307/Conservative-CNN-analyst-says-kept-air-old-boss-Jeff-Zucker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 12:54:41+00:00

Mary Katharine Ham is a conservative TV journalist and anchor who contributes to CNN and has previously worked for Fox News.

## Buxton crash driver Tyrell Edwards granted bail amid concerns he might suicide
 - [https://www.dailymail.co.uk/news/article-11291173/Buxton-crash-driver-Tyrell-Edwards-granted-bail-amid-concerns-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291173/Buxton-crash-driver-Tyrell-Edwards-granted-bail-amid-concerns-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 12:51:42+00:00

Tyrell Edwards, 18, was released on a strict conditional bail this week, a month after the horror crash that took the lives of his five young friends at Buxton, southwest of Sydney.

## Putin 'directly confronted by member of his inner circle over Ukraine war'
 - [https://www.dailymail.co.uk/news/article-11291331/Putin-directly-confronted-member-inner-circle-Ukraine-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291331/Putin-directly-confronted-member-inner-circle-Ukraine-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 12:42:41+00:00

Vladimir Putin was confronted over 'mismanagement of the war effort' and 'mistakes' made by men charged with carrying it out, according to an American security briefing.

## West Australian Perth model Maraea Te Oke Mae Hunia charged with death of baby son Jahley Poata
 - [https://www.dailymail.co.uk/news/article-11291017/West-Australian-Perth-model-Maraea-Te-Oke-Mae-Hunia-charged-death-baby-son-Jahley-Poata.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291017/West-Australian-Perth-model-Maraea-Te-Oke-Mae-Hunia-charged-death-baby-son-Jahley-Poata.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 12:30:49+00:00

Maraea Te Oke Mae Hunia, 31, and Jahley Poata, 30, were charged with child neglect after their six-month-old boy died in a Perth Hospital, on Wednesday.

## Police launch probe after girl, 8, claimed a man 'grabbed her foot' under a toilet door in Morrisons
 - [https://www.dailymail.co.uk/news/article-11291299/Police-launch-probe-girl-8-claimed-man-grabbed-foot-toilet-door-Morrisons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291299/Police-launch-probe-girl-8-claimed-man-grabbed-foot-toilet-door-Morrisons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 12:23:45+00:00

Police are investigating after an eight-year-old girl told her mother she was groped by a man who put his hand under a toilet cubicle in Morrison's supermarket in Cheadle on Wednesday afternoon

## 'Electronic stethoscope' smartphone app can monitor your heartbeat
 - [https://www.dailymail.co.uk/sciencetech/article-11291133/Electronic-stethoscope-smartphone-app-monitor-heartbeat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-11291133/Electronic-stethoscope-smartphone-app-monitor-heartbeat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 12:11:19+00:00

An app developed by a team including King's College London records not only the basic 'lub-dub' of a beating heart but the sounds in between of its valves opening and closing.

## Six police officers face criminal probe for 'grossly offensive' messages shared in WhatsApp group
 - [https://www.dailymail.co.uk/news/article-11291407/Six-police-officers-face-criminal-probe-grossly-offensive-messages-shared-WhatsApp-group.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291407/Six-police-officers-face-criminal-probe-grossly-offensive-messages-shared-WhatsApp-group.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 12:07:21+00:00

Investigators have started a criminal probe into six serving and one former police officer in Wayne Couzens' old force.

## Alex Ryder author Anthony Horowitz says he has been forced to 'shut up' by cancel culture
 - [https://www.dailymail.co.uk/news/article-11291291/Alex-Ryder-author-Anthony-Horowitz-says-forced-shut-cancel-culture.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291291/Alex-Ryder-author-Anthony-Horowitz-says-forced-shut-cancel-culture.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 12:03:32+00:00

The multi-million selling author, 67, has instead decided to write stories that don't upset anyone so that his books don't end up 'damaged'.

## Smiling Rebekah Vardy is seen for first time since Wagatha Christie fee hearing
 - [https://www.dailymail.co.uk/news/article-11291005/Smiling-Rebekah-Vardy-seen-time-Wagatha-Christie-fee-hearing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291005/Smiling-Rebekah-Vardy-seen-time-Wagatha-Christie-fee-hearing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 12:02:11+00:00

The 40-year-old looked relaxed as she strolled around a picturesque Lincolnshire park with three-year-old Olivia and an enormous German Shepherd.

## Hundreds of trafficked cats and dogs died on a Chinese death truck heading for slaughter and market
 - [https://www.dailymail.co.uk/news/article-11291013/Hundreds-trafficked-cats-dogs-died-Chinese-death-truck-heading-slaughter-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291013/Hundreds-trafficked-cats-dogs-died-Chinese-death-truck-heading-slaughter-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 11:57:56+00:00

Chinese activists and police stopped a truck crammed full of more than 1,400 cats and dogs headed to slaughterhouses for the meat trade.

## Parent hits out at school's 'atrocious' lunch offering including pasta in a cup
 - [https://www.dailymail.co.uk/news/article-11290791/Parent-hits-schools-atrocious-lunch-offering-including-pasta-cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290791/Parent-hits-schools-atrocious-lunch-offering-including-pasta-cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 11:48:12+00:00

Craig Laird, whose children attend Bulwell Academy in Nottingham, has described the lunch offerings as 'inadequate' and said he 'wouldn't even give them to dogs'.

## The battle for the Senate: DailyMail.com breaks down the key races
 - [https://www.dailymail.co.uk/news/article-11281163/The-battle-Senate-DailyMail-com-breaks-key-races.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11281163/The-battle-Senate-DailyMail-com-breaks-key-races.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 11:47:29+00:00

The Senate is already on a knife's edge. Democrats are in control by the tiniest of margins, using Vice President Kamala Harris as a tie-breaker  in the  chamber that's split 50-50.

## Ernest Shackleton's lost ship Endurance could be RAISED from Antarctica's Weddell Sea
 - [https://www.dailymail.co.uk/news/article-11291125/Ernest-Shackletons-lost-ship-Endurance-RAISED-Antarcticas-Weddell-Sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291125/Ernest-Shackletons-lost-ship-Endurance-RAISED-Antarcticas-Weddell-Sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 11:29:29+00:00

Endurance became stuck in ice and sank in the Weddell Sea off the coast of Antarctica in 1915 and had been lost until it was located by a mission vessel in February.

## Moment gangs armed with machetes and bats fight in east London street in broad daylight
 - [https://www.dailymail.co.uk/news/article-11290887/Moment-gangs-armed-machetes-bats-fight-east-London-street-broad-daylight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290887/Moment-gangs-armed-machetes-bats-fight-east-London-street-broad-daylight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 11:22:02+00:00

Footage shows the shocking incident in Tower Hamlets last week as the men clashed on the street, with some brandishing their weapons as members of the public walked past.

## Rolex Rippers pictured as the female gang target wealthy women for the first time stealing cash
 - [https://www.dailymail.co.uk/news/article-11290979/The-Rolex-Rippers-action-targeting-women-steal-purses-cash-jewellery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290979/The-Rolex-Rippers-action-targeting-women-steal-purses-cash-jewellery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 11:12:38+00:00

The Rolex Rippers are believed to have changed tact from targeting wealthy elderly men and are now targeting well-off, older women on high streets across Dorset and Hampshire.

## Historic house owned by parents of 'Gunpowder Plot whistleblower' could be yours for £700,000
 - [https://www.dailymail.co.uk/news/article-11291051/Historic-house-owned-parents-Gunpowder-Plot-whistleblower-700-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291051/Historic-house-owned-parents-Gunpowder-Plot-whistleblower-700-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 11:10:30+00:00

The Ducks Nest is one of the oldest properties in Oundle, Northamptonshire and was owned by Sir Thomas Tresham, whose eldest son, Francis, was involved in the plot.

## World of Irish dancing is rocked by sex scandal
 - [https://www.dailymail.co.uk/news/article-11290785/World-Irish-dancing-rocked-sex-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290785/World-Irish-dancing-rocked-sex-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 11:10:09+00:00

Up to a dozen Irish dance teacher and judges stand accused of colluding to award podium finishes to certain pupils after bombshell texts were leaked by an American whistleblower.

## Disabled passenger who claims she had to drag herself to the toilet on flight slams AlbaStar
 - [https://www.dailymail.co.uk/news/article-11290847/Disabled-passenger-claims-drag-toilet-flight-slams-AlbaStar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290847/Disabled-passenger-claims-drag-toilet-flight-slams-AlbaStar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 11:06:44+00:00

Disabled passenger Jennie Berry, who claims she had to drag herself to the toilet on the floor has blasted airline AlbaStar after cabin crew suggested she should have worn a nappy

## Mother-of-three, 38, over drink-drive limit 'was drinking to cope with post-natal depression'
 - [https://www.dailymail.co.uk/news/article-11291121/Mother-three-38-drink-drive-limit-drinking-cope-post-natal-depression.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291121/Mother-three-38-drink-drive-limit-drinking-cope-post-natal-depression.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 11:03:56+00:00

Kathryn McAdams, 38, was stopped at the wheel of Volkswagen Tiguan on the A41 in Ellesmere Port, Cheshire, shortly after midnight when police were alerted by a member of the public.

## How the pound's collapse could scuttle the UK's international nursing recruitment drive
 - [https://www.dailymail.co.uk/health/article-11283039/How-pounds-collapse-scuttle-UKs-international-nursing-recruitment-drive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11283039/How-pounds-collapse-scuttle-UKs-international-nursing-recruitment-drive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:58:43+00:00

EXCL: Economic chaos in the UK could demolish NHS plans to recruit more international nurses with experts warning Britain has become too reliant on finding nurses in places like India and Nepal.

## British businessman is arrested in Thailand for 'defrauding investors out of nearly £1million'
 - [https://www.dailymail.co.uk/news/article-11291045/British-businessman-arrested-Thailand-defrauding-investors-nearly-1million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291045/British-businessman-arrested-Thailand-defrauding-investors-nearly-1million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:40:15+00:00

The CEO named as Mark Edward Kirkham was seized at Suvarnabhumi Airport after South Bangkok Criminal Court issued a warrant for his arrest in December last year.

## Halifax index says average house price dropped in September from record high the month before
 - [https://www.dailymail.co.uk/news/article-11290563/Halifax-index-says-average-house-price-drops-September-record-high-month-before.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290563/Halifax-index-says-average-house-price-drops-September-record-high-month-before.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:30:05+00:00

Figures going back to the summer indicate the housing market may have already entered a more sustained period of slower growth, Halifax said in its latest house price index.

## Derby 'shooting': B&M shop evacuated in Derby as armed police rush to scene
 - [https://www.dailymail.co.uk/news/article-11291085/B-M-shop-evacuated-armed-police-rush-reported-shooting-Derby-man-taken-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291085/B-M-shop-evacuated-armed-police-rush-reported-shooting-Derby-man-taken-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:30:00+00:00

A B&amp;M shop has been evacuated in Derby after armed police officers rushed to the scene of a reported shooting.

## The heroes of Bishopsgate: Incredible footage shows how fearless passersby confront phone muggers
 - [https://www.dailymail.co.uk/news/article-11290767/The-heroes-Bishopsgate-Incredible-footage-shows-fearless-passersby-confront-phone-muggers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290767/The-heroes-Bishopsgate-Incredible-footage-shows-fearless-passersby-confront-phone-muggers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:27:54+00:00

Incredible footage of how 'have-a-go heroes' pounced on a masked gang robbing an innocent City worker and fought them off emerged this morning.

## Summer 2022 saw Britain's deadliest EVER heatwave: 40C temperatures triggered extra 2,800 deaths
 - [https://www.dailymail.co.uk/health/article-11290885/Summer-2022-saw-Britains-deadliest-heatwave-40C-temperatures-triggered-extra-2-800-deaths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11290885/Summer-2022-saw-Britains-deadliest-heatwave-40C-temperatures-triggered-extra-2-800-deaths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:27:47+00:00

Across the five heatwave periods in England and Wales - that set record temperatures as the mercury surpassed 40C (104F) - an extra 3,200 fatalities were logged.

## Grill'd founder Simon Crowe buys $22million Toorak Melbourne mansion
 - [https://www.dailymail.co.uk/news/article-11290667/Grilld-founder-Simon-Crowe-buys-22million-Toorak-Melbourne-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290667/Grilld-founder-Simon-Crowe-buys-22million-Toorak-Melbourne-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:19:49+00:00

The co-founder of a popular burger chain, which was criticised for paying thousands of young trainee staff low wages while collecting taxpayer-funded subsidies, has bought a grand mansion.

## Couple say 'cowboy' builder hasn't finished kitchen extension after two years
 - [https://www.dailymail.co.uk/news/article-11290879/Couple-say-cowboy-builder-finished-kitchen-extension-two-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290879/Couple-say-cowboy-builder-finished-kitchen-extension-two-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:19:29+00:00

A couple say they have had to live on microwave meals for months on end and have to wash their dishes in the bath as a 'cowboy' builder still has not finished their kitchen extension after two years.

## LA gas prices surge to all-time high of $6.49-a-gallon - up statewide $1.15 in a month
 - [https://www.dailymail.co.uk/news/article-11291061/LA-gas-prices-surge-time-high-6-49-gallon-statewide-1-15-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11291061/LA-gas-prices-surge-time-high-6-49-gallon-statewide-1-15-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:19:06+00:00

Across the state, the average price for a gallon of gas sits at $6.18. The horror prices have been blamed on the ongoing war in Ukraine, high taxes, green policies and refinery shutdowns.

## Furious mother, 37, faces jail after subjecting her estranged sister-in-law to a foul-mouthed tirade
 - [https://www.dailymail.co.uk/news/article-11290883/Furious-mother-37-faces-jail-subjecting-estranged-sister-law-foul-mouthed-tirade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290883/Furious-mother-37-faces-jail-subjecting-estranged-sister-law-foul-mouthed-tirade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:17:51+00:00

Sarah Janion, 37, was caught on a doorbell camera screaming foul mouthed abuse at childminder Stacey Janion  outside her Ms Janion's home in Runcton in August of this year.

## Just Stop Oil activists block roads leading to Vauxhall Bridge in London
 - [https://www.dailymail.co.uk/news/article-11290967/Just-Stop-Oil-activists-block-roads-leading-Vauxhall-Bridge-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290967/Just-Stop-Oil-activists-block-roads-leading-Vauxhall-Bridge-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:12:52+00:00

Some 25 demonstrators in several groups blocked routes to the north and south of Vauxhall Bridge in London, sitting down with banners and glueing themselves to the roads.

## British father Tony Garnett reunites with his family after refugee ex-girlfriend returned to Ukraine
 - [https://www.dailymail.co.uk/news/article-11290619/British-father-Tony-Garnett-reunites-family-refugee-ex-girlfriend-returned-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290619/British-father-Tony-Garnett-reunites-family-refugee-ex-girlfriend-returned-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 10:08:42+00:00

EXCLUSIVE: Tony Garnett, 30, his former partner Lorna, 28, and the children were able to be legally together for the first time in five months.

## Shocked Aldi shopper finds VERY rude-looking fruit in his weekly shop
 - [https://www.dailymail.co.uk/news/article-11290899/Shocked-Aldi-shopper-finds-rude-looking-fruit-weekly-shop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290899/Shocked-Aldi-shopper-finds-rude-looking-fruit-weekly-shop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:53:33+00:00

Johnny O'Connell, 43, of Morpeth, Northumberland, burst out laughing when he discovered the seven-inch fruit which bears a striking resemblance to male genitalia.

## 'Britain's FBI' arrest 30-year-old Albanian 'people smuggler'
 - [https://www.dailymail.co.uk/news/article-11290633/Britains-FBI-arrest-30-year-old-Albanian-people-smuggler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290633/Britains-FBI-arrest-30-year-old-Albanian-people-smuggler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:46:17+00:00

The suspected people smuggler was detained in the Tolworth Rise area of Surbiton, with police also seizing cash and a tablet computer.

## Nicola Sturgeon REFUSES to axe £20million independence push to help with the cost-of-living crisis
 - [https://www.dailymail.co.uk/news/article-11290983/Nicola-Sturgeon-REFUSES-axe-20million-independence-push-help-cost-living-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290983/Nicola-Sturgeon-REFUSES-axe-20million-independence-push-help-cost-living-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:45:34+00:00

The First Minister said she had a democratic mandate to push on with her plan to seek a new referendum on leaving the UK in October next year.

## Harley Street doctor struck off for having sex with patients is still making home visits to women
 - [https://www.dailymail.co.uk/news/article-11290661/Harley-Street-doctor-struck-having-sex-patients-making-home-visits-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290661/Harley-Street-doctor-struck-having-sex-patients-making-home-visits-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:29:38+00:00

Dr Theodore Soutzos, 51, was found to no longer be fit to practice in 2010 after he 'groomed' three mental health patients between 1999 and 2006 at NHS and private health clinics.

## Nobel peace prize 2022 winners announced: Jailed Belarusian human rights activist among winners
 - [https://www.dailymail.co.uk/news/article-11290889/Nobel-peace-prize-2022-winners-announced-Jailed-Belarusian-human-rights-activist-winners.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290889/Nobel-peace-prize-2022-winners-announced-Jailed-Belarusian-human-rights-activist-winners.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:28:12+00:00

Jailed Belarusian human rights activist Ales Byalyatski was named as a winner on Friday in Oslo, along with Russian human rights organisation Memorial and Ukrainian Center for Civil Liberties.

## Fraudster who blew £4.4million of other's money on cars, yachts and a racehorse found dead aged 38
 - [https://www.dailymail.co.uk/news/article-11290755/Fraudster-blew-4-4million-money-cars-yachts-racehorse-dead-aged-38.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290755/Fraudster-blew-4-4million-money-cars-yachts-racehorse-dead-aged-38.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:24:01+00:00

Stephen Evans, 38, who was jailed for five-years following a Ponzi scam in 2014, was discovered by police at his rented bungalow near the Lake District a week ago.

## Covid-19 UK: Health chiefs issue advice not to see elderly relatives if feeling unwell
 - [https://www.dailymail.co.uk/health/article-11290537/Covid-19-UK-Health-chiefs-issue-advice-not-elderly-relatives-feeling-unwell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11290537/Covid-19-UK-Health-chiefs-issue-advice-not-elderly-relatives-feeling-unwell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:21:21+00:00

Dr Susan Hopkins, chief medical advisor at the UK Health Security Agency (UKHSA), said people with 'symptoms of a respiratory infection' should wear a face covering in public.

## Freeze spending on Wales and Scotland and cut free bus passes, says Liz Truss's top economic adviser
 - [https://www.dailymail.co.uk/news/article-11290797/Freeze-spending-Wales-Scotland-cut-free-bus-passes-says-Liz-Trusss-economic-adviser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290797/Freeze-spending-Wales-Scotland-cut-free-bus-passes-says-Liz-Trusss-economic-adviser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:06:49+00:00

Matthew Sinclair, a former head of small-state advocacy group the Taxpayers' Alliance, made the suggestions in a book after the 2008 Financial Crash.

## Shark  attack at Port Hedland Western Australian beach almost rips off spearfisher's arm
 - [https://www.dailymail.co.uk/news/article-11290611/Shark-rips-spearfishers-ARM-savage-attack-Western-Australian-beach-Port-Hedland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290611/Shark-rips-spearfishers-ARM-savage-attack-Western-Australian-beach-Port-Hedland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:06:45+00:00

A man in his 30s almost had his arm torn off after a shark attack offshore at Port Hedland in Western Australia

## Patient 'was sent to Australian morgue while STILL ALIVE'
 - [https://www.dailymail.co.uk/news/article-11290693/Patient-sent-Australian-morgue-ALIVE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290693/Patient-sent-Australian-morgue-ALIVE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:05:51+00:00

Kevin Reid, a palliative care patient, died in Rockingham General Hospital, south of Perth - but whether that was on the night of September 5 or the following day on September 6 is unclear.

## Clarkson's battle to save Diddly Squat restaurant as councillors say he has gone to war with them
 - [https://www.dailymail.co.uk/news/article-11290787/Clarksons-battle-save-Diddly-Squat-restaurant-councillors-say-gone-war-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290787/Clarksons-battle-save-Diddly-Squat-restaurant-councillors-say-gone-war-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:02:42+00:00

Speaking about Jeremy Clarkson, Local Conservative councillor Dean Temple said: 'I think he was after the confrontation because it would be good for his ratings'.

## Residents' fury as '6G broadband' 40ft high telegraph poles appear on their street without warning
 - [https://www.dailymail.co.uk/news/article-11290685/Residents-fury-6G-broadband-40ft-high-telegraph-poles-appear-street-without-warning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290685/Residents-fury-6G-broadband-40ft-high-telegraph-poles-appear-street-without-warning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 09:01:00+00:00

Pauline Owen, 75, and Dorothy Price, 72, claim signs alerting locals to the poles went up just one day before their construction on Winifred Road in Bolton, Greater Manchester.

## Birdwatchers are blasted for chasing rare migratory warbler out of a bush
 - [https://www.dailymail.co.uk/news/article-11290717/Birdwatchers-blasted-chasing-rare-migratory-warbler-bush.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290717/Birdwatchers-blasted-chasing-rare-migratory-warbler-bush.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 08:56:58+00:00

Birdwatchers have been blasted for 'grim' moment when people chased a rare migratory warbler out of a bush in the Shetland Islands and around 50 people took pictures of it.

## Molly Russell's father says the tragic teenager 'cried into empty void' asking influencers for help
 - [https://www.dailymail.co.uk/news/article-11290673/Molly-Russells-father-says-tragic-teenager-cried-void-asking-influencers-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290673/Molly-Russells-father-says-tragic-teenager-cried-void-asking-influencers-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 08:45:57+00:00

Ian Russell said Molly's family had no idea about the mental health issues she was suffering, and that she seemed uninterested in social media.

## Nicola Sturgeon suggests JK Rowling is not a 'real feminist'
 - [https://www.dailymail.co.uk/news/article-11290591/Nicola-Sturgeon-suggests-JK-Rowling-not-real-feminist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290591/Nicola-Sturgeon-suggests-JK-Rowling-not-real-feminist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 08:44:50+00:00

The First Minister fought fire with fire after she was attacked by the star and declared: 'I've spent my entire life campaigning for women's rights, and I'm a passionate feminist'.

## Four friends 'who kidnapped British public schoolboy in Italy and tortured him' are to go on trial
 - [https://www.dailymail.co.uk/news/article-11290671/Four-friends-kidnapped-British-public-schoolboy-Italy-tortured-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290671/Four-friends-kidnapped-British-public-schoolboy-Italy-tortured-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 08:42:41+00:00

Four friends face trial in Italy, accused of kidnapping and torturing British public schoolboy Sam Demilecamps last year after holidaying together in summer 2021

## Teenager, 14, is charged with murdering 14-year-old Tomasz Oleszak who was stabbed to death
 - [https://www.dailymail.co.uk/news/article-11290677/Teenager-14-charged-murdering-14-year-old-schoolboy-stabbed-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290677/Teenager-14-charged-murdering-14-year-old-schoolboy-stabbed-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 08:41:48+00:00

Tomasz Oleszak, 14, was stabbed in Aycliffe Crescent area of the Springwell Estate in Gateshead on Monday evening. A boy, aged 14, has now been charged with his murder.

## NSW weather: Frightening map emerges of 400km rain bomb danger zone, flood warnings in place
 - [https://www.dailymail.co.uk/news/article-11290365/NSW-weather-Frightening-map-emerges-400km-rain-bomb-danger-zone-flood-warnings-place.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290365/NSW-weather-Frightening-map-emerges-400km-rain-bomb-danger-zone-flood-warnings-place.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 08:41:06+00:00

A severe weather warning has been issued for a large part of NSW with heavy rain, floods, high winds and landslides predicted from Saturday afternoon.

## Judge slams Alex Jones' lawyer for making 'highly improper' attacks against Sandy Hook attorney
 - [https://www.dailymail.co.uk/news/article-11290577/Judge-slams-Alex-Jones-lawyer-making-highly-improper-attacks-against-Sandy-Hook-attorney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290577/Judge-slams-Alex-Jones-lawyer-making-highly-improper-attacks-against-Sandy-Hook-attorney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 08:31:05+00:00

Norm Pattis, Alex Jones' lawyer. warned the jury in his closing remarks that his opposing attorney would attack him personally 'all in an effort to gin you up, get you angry,'

## Adorable moment a schoolboy squeals with joy after meeting Prince William and Kate
 - [https://www.dailymail.co.uk/femail/article-11290449/Adorable-moment-schoolboy-squeals-joy-meeting-Prince-William-Kate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11290449/Adorable-moment-schoolboy-squeals-joy-meeting-Prince-William-Kate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 08:00:28+00:00

The Prince and Princess of Wales  visited Northern Ireland for a number of engagements, including an impromptu walkabout where they met with schoolchildren.

## Colorado baker challenges ruling against him after he declined to bake a gender transition cake
 - [https://www.dailymail.co.uk/news/article-11290525/Colorado-baker-challenges-ruling-against-declined-bake-gender-transition-cake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290525/Colorado-baker-challenges-ruling-against-declined-bake-gender-transition-cake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 07:58:23+00:00

A lawyer for Jack Phillips (pictured) on Wednesday challenged Colorado's appeals court to overturn a ruling made last year in connection with a case brought against him by a transgender attorney

## Shocked Uber passenger, 22, is charged £35,000 for a four-mile journey that took just 15 minutes
 - [https://www.dailymail.co.uk/news/article-11290343/Shocked-Uber-passenger-22-charged-35-000-four-mile-journey-took-just-15-minutes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290343/Shocked-Uber-passenger-22-charged-35-000-four-mile-journey-took-just-15-minutes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 07:56:27+00:00

Oliver Kaplan, 22, (pictured) was told it would cost just £10 for the four-mile trip from Hyde in Greater Manchester to Ashton-Under-Lyne on a trip to see friends.

## Russia is now Ukraine's largest arms supplier
 - [https://www.dailymail.co.uk/news/article-11290455/Russia-Ukraines-largest-arms-supplier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290455/Russia-Ukraines-largest-arms-supplier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 07:52:19+00:00

Ukraine has captured more than 400 Russian tanks and 600 fighting vehicles since the war began, analysis shows, which far outstrips the number that have been donated by allies.

## Woman from Cranbourne, Melbourne wins $50million Oz Lotto jackpot and says she can't stop shaking
 - [https://www.dailymail.co.uk/news/article-11290419/Woman-Cranbourne-Melbourne-wins-50million-Oz-Lotto-jackpot-says-stop-shaking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290419/Woman-Cranbourne-Melbourne-wins-50million-Oz-Lotto-jackpot-says-stop-shaking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 07:45:03+00:00

Melbourne woman nabbed the biggest OzLotto winnings for the year,  all to herself - 'I'm 'shaking and my head is spinning! I can't believe this', she said.

## Steven Barker: Bronte businessman's relationship was 'unravelling' before murder charge
 - [https://www.dailymail.co.uk/news/article-11290275/Steven-Barker-Bronte-businessmans-relationship-unravelling-murder-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290275/Steven-Barker-Bronte-businessmans-relationship-unravelling-murder-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 07:13:50+00:00

Business development manager Steven Barker, 74, was arrested on Thursday and charged with one count of murder after police were called to a home on Bronte Road, Bronte, in Sydney's east.

## PICTURED: Suspect who 'stabbed eight people with a large kitchen knife' on Las Vegas strip
 - [https://www.dailymail.co.uk/news/article-11290197/PICTURED-Suspect-stabbed-eight-people-large-kitchen-knife-Las-Vegas-strip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290197/PICTURED-Suspect-stabbed-eight-people-large-kitchen-knife-Las-Vegas-strip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 07:09:30+00:00

Two local residents have been named as the fatal victims of crazed knife attack that also saw four showgirls get slashed in broad daylight on the Las Vegas strip.

## Mike Pompeo blasts Air Force climate action plan
 - [https://www.dailymail.co.uk/news/article-11290347/Mike-Pompeo-blasts-Air-Force-climate-action-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290347/Mike-Pompeo-blasts-Air-Force-climate-action-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 06:43:39+00:00

Former secretary of state Mike Pompeo blasted the US Air Force plan: 'I can guarantee you that the China's Air Force is not obsessing about green energy. They're focused on defeating America.'

## Shaq O'Neal Pointsbet ads spark an Ads Standards inquiry after a viewer complaint
 - [https://www.dailymail.co.uk/news/article-11290329/Shaq-ONeal-Pointsbet-ads-spark-Ads-Standards-inquiry-viewer-complaint.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290329/Shaq-ONeal-Pointsbet-ads-spark-Ads-Standards-inquiry-viewer-complaint.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 06:32:34+00:00

Shaquille O'Neal's high rotation advertisements for sports betting company PointsBet were reviewed by the Advertising Standards Authority after a complaint.

## NAB forecasts $300k house price drops as Reserve Bank of Australia warns of loan defaults
 - [https://www.dailymail.co.uk/news/article-11289957/NAB-forecasts-300k-house-price-drops-Reserve-Bank-Australia-warns-loan-defaults.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289957/NAB-forecasts-300k-house-price-drops-Reserve-Bank-Australia-warns-loan-defaults.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 06:21:59+00:00

The Reserve Bank has issued a new warning about mortgage defaults, just days after it raised interest rates for the sixth consecutive month. NAB is forecasting huge falls in Sydney and Melbourne.

## SpaceX capsule docks with International Space Station delivering crew of four
 - [https://www.dailymail.co.uk/news/article-11290337/SpaceX-capsule-docks-International-Space-Station-delivering-crew-four.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290337/SpaceX-capsule-docks-International-Space-Station-delivering-crew-four.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 06:17:45+00:00

The Crew Dragon spaceship dubbed Endurance docked with the station on Thursday, a day after launching into orbit from Florida. The linkup occurred 260 miles above the Atlantic.

## Lightning Ridge tourist attraction operator admits to murdering mother-of-four Christine Neilan
 - [https://www.dailymail.co.uk/news/article-11290261/Lightning-Ridge-tourist-attraction-operator-admits-murdering-mother-four-Christine-Neilan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290261/Lightning-Ridge-tourist-attraction-operator-admits-murdering-mother-four-Christine-Neilan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 06:06:36+00:00

Vittorio Stefanato who operated an outback tourist castle admitted to murdering mother-of-four Christine Neilan in the NSW opal mining town of Lightning Ridge in January, 2020.

## Western Australian couple charged with neglect after baby dies in hospital
 - [https://www.dailymail.co.uk/news/article-11290265/Western-Australian-couple-charged-neglect-baby-dies-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290265/Western-Australian-couple-charged-neglect-baby-dies-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 06:01:00+00:00

A West Australian couple in their 30s were charged with the neglect of a six-month-old baby who later died after being rushed to hospital. The couple are charged with failing to protect a child from harm.

## Push for zones to change in Australia as daylight saving causes five different times
 - [https://www.dailymail.co.uk/news/article-11290037/Push-zones-change-Australia-daylight-saving-causes-five-different-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290037/Push-zones-change-Australia-daylight-saving-causes-five-different-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 05:52:06+00:00

Let's Fix The Time founder Graeme Brittenden has come up with a way to reduce Australia's five different time zones to just three all year round.

## Brittany Higgins is grilled over $325,000 'book deal' text to Lisa Wilkinson and Peter FitzSimons
 - [https://www.dailymail.co.uk/news/article-11290223/Brittany-Higgins-grilled-325-000-book-deal-text-Lisa-Wilkinson-Peter-FitzSimons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290223/Brittany-Higgins-grilled-325-000-book-deal-text-Lisa-Wilkinson-Peter-FitzSimons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 05:44:11+00:00

Brittany Higgins was grilled in court over texts she sent to Lisa Wilkinson and Peter FitzSimons about a $325,000 book deal on her alleged rape by Bruce Lehrmann.

## Towradgi car crash police seize car that could have transported Wayne Russell
 - [https://www.dailymail.co.uk/news/article-11290243/Towradgi-car-crash-police-seize-car-transported-Wayne-Russell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290243/Towradgi-car-crash-police-seize-car-transported-Wayne-Russell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 05:38:37+00:00

A stolen car that could have carried 12-year-old Wayne Russell away from a car crash near Wollongong before he later died has been seized by detectives.

## Secret ice lab busted in Colebee, Sydney's west, with five men arrested and $21million drugs seized
 - [https://www.dailymail.co.uk/news/article-11290131/Secret-ice-lab-busted-Colebee-Sydneys-west-five-men-arrested-21million-drugs-seized.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290131/Secret-ice-lab-busted-Colebee-Sydneys-west-five-men-arrested-21million-drugs-seized.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 05:36:44+00:00

Five men have been arrested after a house in Colebee, in Sydney's west, was raided by police on Tuesday at about 2.20pm.

## Kanye West turns on Jared Kushner and says he only wants to 'make money'
 - [https://www.dailymail.co.uk/news/article-11290147/Kanye-West-turns-Jared-Kushner-says-wants-make-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290147/Kanye-West-turns-Jared-Kushner-says-wants-make-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 05:22:02+00:00

Jared Kushner says that he and Kanye West have been friends for over 20 years, but on Thursday night West trashed the former presidential advisor, calling him mercenary and amoral.

## Herschel Walker jokes that he needs to spank his son after Christian disowned him
 - [https://www.dailymail.co.uk/news/article-11290187/Herschel-Walker-jokes-needs-spank-son-Christian-disowned-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290187/Herschel-Walker-jokes-needs-spank-son-Christian-disowned-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 05:09:40+00:00

Even as Christian accused his former NFL star father of domestic abuse,  Walker joked about spanking his son in remarks at a prayer luncheon on Tuesday at First Baptist Atlanta.

## Thunderstorm asthma epidemic warning for south eastern Australia
 - [https://www.dailymail.co.uk/news/article-11289933/Thunderstorm-asthma-epidemic-warning-south-eastern-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289933/Thunderstorm-asthma-epidemic-warning-south-eastern-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 05:08:17+00:00

The last thunderstorm asthma event was in 2016 in Melbourne where thousands of people, many who'd never been diagnosed with asthma, were rushed to hospital.

## Video shows massive dust cloud envelop farm community outside San Diego
 - [https://www.dailymail.co.uk/news/article-11290095/Video-shows-massive-dust-cloud-envelop-farm-community-outside-San-Diego.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290095/Video-shows-massive-dust-cloud-envelop-farm-community-outside-San-Diego.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 04:51:20+00:00

The National Weather Service issued a Dust Storm warning in San Diego County on Thursday afternoon.

## Terrifying moment NYPD cruiser crashes onto  sidewalk in the Bronx - injuring ten people
 - [https://www.dailymail.co.uk/news/article-11290007/Terrifying-moment-NYPD-cruiser-crashes-sidewalk-Bronx-injuring-ten-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290007/Terrifying-moment-NYPD-cruiser-crashes-sidewalk-Bronx-injuring-ten-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 04:39:26+00:00

New video shows the terrifying moment when 10 people were injured - three of them seriously - after a NYPD cruiser plowed into a group of pedestrians at a Bronx intersection.

## Tucker Carlson alleges Kim Kardashian worked with Clintons to get Kanye to 'read from the script'
 - [https://www.dailymail.co.uk/news/article-11289887/Tucker-Carlson-alleges-Kim-Kardashian-worked-Clintons-Kanye-read-script.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289887/Tucker-Carlson-alleges-Kim-Kardashian-worked-Clintons-Kanye-read-script.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 04:39:15+00:00

Kanye West met with Fox News host Tucker Carlson for an interview where he revealed he was shocked to learn  that his former wife Kim Kardashian had a close relationship with the Clintons.

## Kanye West says White Lives Matter fashion show concept was based on a 'feeling' and 'gut instinct'
 - [https://www.dailymail.co.uk/news/article-11289667/Kanye-West-declares-hes-pro-life-wild-interview-Tucker-Carlson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289667/Kanye-West-declares-hes-pro-life-wild-interview-Tucker-Carlson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 04:38:24+00:00

Kanye West told Fox News host Tucker Carlson that his 'White Lives Matter' fashion show concept was based on a 'feeling' and 'gut instinct.'

## Joe Biden warns that the risk of nuclear AMAGEDDON is the highest since Cuban missile crisis
 - [https://www.dailymail.co.uk/news/article-11289623/Hes-not-joking-Biden-warns-Putin-deadly-using-tactical-NUKES-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289623/Hes-not-joking-Biden-warns-Putin-deadly-using-tactical-NUKES-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 04:36:57+00:00

Biden warned that Vladimir Putin was not joking about using nuclear weapons in Ukraine, and said the world was facing the prospect of Armageddon for the first time since the Cuban missile crisis.

## Daniel Andrews announces Victoria will end its Covid-19 state of emergency on Wednesday October 12
 - [https://www.dailymail.co.uk/news/article-11290155/Daniel-Andrews-announces-Victoria-end-Covid-19-state-emergency-Wednesday-October-12.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290155/Daniel-Andrews-announces-Victoria-end-Covid-19-state-emergency-Wednesday-October-12.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 04:32:30+00:00

Dan Andrews has announced Victoria's Covid-19 state of emergency will end next week. On Friday the Victorian Premier said the it will officially end on Wednesday October 12.

## Brittany Higgins and her ex exchanged messages about alleged rape
 - [https://www.dailymail.co.uk/news/article-11289993/Brittany-Higgins-ex-exchanged-messages-alleged-rape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289993/Brittany-Higgins-ex-exchanged-messages-alleged-rape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 04:22:43+00:00

In the messages, Brittany Higgins claimed she was 'literally assaulted' in former defence minister Senator Linda Reynolds' office but was offered 'no help'.

## Bronte murder: Young girl may have witnessed man allegedly kill wife in Bronte
 - [https://www.dailymail.co.uk/news/article-11289551/Bronte-murder-Young-girl-witnessed-man-allegedly-kill-wife-Bronte.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289551/Bronte-murder-Young-girl-witnessed-man-allegedly-kill-wife-Bronte.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 04:14:20+00:00

Steven Barker, 74, has been charged with one count of murder after allegedly killing his wife outside their home in Bronte, in Sydney's eastern suburbs.

## Ukrainian leader Volodymyr Zelensky praises Australia for sending him 'heavy weapons'
 - [https://www.dailymail.co.uk/news/article-11289873/Ukrainian-leader-Volodymyr-Zelensky-praises-Australia-sending-heavy-weapons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289873/Ukrainian-leader-Volodymyr-Zelensky-praises-Australia-sending-heavy-weapons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 04:07:07+00:00

Speaking to Australian policy thinktank the Lowy Institute, Volodymyr Zelensky praised Australia's aid in combatting Putin's 'nuclear blackmail'.

## Hilarious TikTok video shows the stark difference between ABC and commercial TV weather
 - [https://www.dailymail.co.uk/news/article-11289989/Hilarious-TikTok-video-shows-stark-difference-ABC-commercial-TV-weather.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289989/Hilarious-TikTok-video-shows-stark-difference-ABC-commercial-TV-weather.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 03:52:56+00:00

A hilarious video showing the contrast between the national broadcaster and commercial TV has gone viral online, as viewers struggle to decide which approach they prefer.

## Brisbane cat owner told her pet 'will disappear' unless she keeps it inside
 - [https://www.dailymail.co.uk/news/article-11289499/Brisbane-cat-owner-told-pet-disappear-unless-keeps-inside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289499/Brisbane-cat-owner-told-pet-disappear-unless-keeps-inside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 03:24:25+00:00

The woman from Brisbane shared a photo of the blunt hand-written note to Reddit, asking for advice on how to keep her rescue cat inside.

## Domenic Perre guilty of murder of Geoffrey Bowen in 1994 National Crime Authority bombing
 - [https://www.dailymail.co.uk/news/article-11290005/Domenic-Perre-guilty-murder-Geoffrey-Bowen-1994-National-Crime-Authority-bombing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11290005/Domenic-Perre-guilty-murder-Geoffrey-Bowen-1994-National-Crime-Authority-bombing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 03:21:33+00:00

National Crime Authority bomber Domenic Perre (pictured) will likely die in jail after being found guilty of the murder of Detective Sergeant Geoffrey Bowen in 1994 Adelaide attack.

## NSW council slammed over its 'unbelievable decision' to ban flying of the Australian flag
 - [https://www.dailymail.co.uk/news/article-11289493/NSW-council-slammed-unbelievable-decision-ban-flying-Australian-flag.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289493/NSW-council-slammed-unbelievable-decision-ban-flying-Australian-flag.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 03:20:58+00:00

Claims Central Coast Council will ban the flying of the Australian flag even on Australia Day has been slammed by 2GB drive show host Jim Wilson, who said councils need to 'stay in their lane'.

## 'Historic' moment mum breastfeeds while asking question on ABC Q&A TV show
 - [https://www.dailymail.co.uk/news/article-11289577/ABC-Qanda-mum-breastfeeds-asking-question-ABC-TV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289577/ABC-Qanda-mum-breastfeeds-asking-question-ABC-TV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 03:07:35+00:00

Kat Watkins, who moved to Wagga Wagga in southern NSW told Q&amp;A she is struggling with rental increases as she accidentally exposed her nipple while breastfeeding her baby.

## Photos of Mark Latham with retired escort 'Samantha X' aka Amanda Goff at Sydney bar
 - [https://www.dailymail.co.uk/news/article-11289505/Photos-Mark-Latham-retired-escort-Samantha-X-aka-Amanda-Goff-Sydney-bar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289505/Photos-Mark-Latham-retired-escort-Samantha-X-aka-Amanda-Goff-Sydney-bar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 02:58:20+00:00

Latham and the woman who was once reputably Australia's highest-paid sex worker spent two-and-a-half hours dining at Toppi Bar and Restaurant in Sydney's Martin Place on Thursday night.

## How two best friends got MARRIED to exploit Centrelink loophole, become full-time climate activists
 - [https://www.dailymail.co.uk/news/article-11289501/How-two-best-friends-got-MARRIED-exploit-Centrelink-loophole-time-climate-activists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289501/How-two-best-friends-got-MARRIED-exploit-Centrelink-loophole-time-climate-activists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 02:43:36+00:00

Two Australians have claimed they decided to marry each other in order to qualify for Centrelink payments while living in the back of a car and working as activists.

## Spotify cancels slate of 11 original podcasts as it redirects funding to big new hits
 - [https://www.dailymail.co.uk/news/article-11289857/Spotify-cancels-slate-11-original-podcasts-redirects-funding-big-new-hits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289857/Spotify-cancels-slate-11-original-podcasts-redirects-funding-big-new-hits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 02:37:43+00:00

Spotify is canceling a slate of original podcasts for the first time in the company's history as it reallocates resources after launching big new shows from Meghan Markle and Kim Kardashian.

## Australian almost wins Italian Super Jackpot after buying ticket through The Lottery Office
 - [https://www.dailymail.co.uk/news/article-11289769/Australian-wins-Italian-Super-Jackpot-buying-ticket-Lottery-Office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289769/Australian-wins-Italian-Super-Jackpot-buying-ticket-Lottery-Office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 02:33:06+00:00

A 51-year-old man from Sydney was just one number away from winning AUD$424million in the Italian Super Jackpot on Sunday but instead walked away with its division three prize.

## Pauline Hanson investigated after One Nation leader tweet about Greens senator Mehreen Faruqi
 - [https://www.dailymail.co.uk/news/article-11289633/Pauline-Hanson-investigated-One-Nation-leader-tweet-Greens-senator-Mehreen-Faruqi.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289633/Pauline-Hanson-investigated-One-Nation-leader-tweet-Greens-senator-Mehreen-Faruqi.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 02:29:10+00:00

The One Nation leader has been accused of racism after telling Ms Faruqi to return to her native country in the social media post made in September.

## Proud Boys member pleads guilty to seditious conspiracy in January 6 riot
 - [https://www.dailymail.co.uk/news/article-11289593/Proud-Boys-member-pleads-guilty-seditious-conspiracy-January-6-riot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289593/Proud-Boys-member-pleads-guilty-seditious-conspiracy-January-6-riot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 02:06:56+00:00

Jeremy Joseph Bertino, 43, entered the guilty plea in federal court for the District of Columbia on Thursday, and as part of the deal agreed to cooperate with the ongoing investigation.

## New book claims Mick Jagger slept with two members of the Rolling Stones including Keith Richards
 - [https://www.dailymail.co.uk/tvshowbiz/article-11288995/New-book-claims-Mick-Jagger-slept-two-members-Rolling-Stones-including-Keith-Richards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11288995/New-book-claims-Mick-Jagger-slept-two-members-Rolling-Stones-including-Keith-Richards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 01:32:39+00:00

ALISON BOSHOFF: A new book suggests that Rolling Stone Mick Jagger is not just a legendary ladies' man. He's also dallied with more men than is popularly realised.

## EPHRAIM HARDCASTLE: Who's really the hair to the throne?
 - [https://www.dailymail.co.uk/news/article-11289851/EPHRAIM-HARDCASTLE-Whos-really-hair-throne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289851/EPHRAIM-HARDCASTLE-Whos-really-hair-throne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 01:25:03+00:00

EPHRAIM HARDCASTLE: King Charles's full head of hair on new coins and stamps belies HM's sensitivity about his sparsely populated pate.

## Malaita Wall at Katoomba, Blue Mountains: Man falls to his death while abseiling
 - [https://www.dailymail.co.uk/news/article-11289587/Man-falls-death-abseiling-Malaita-Wall-Katoomba-Blue-Mountains.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289587/Man-falls-death-abseiling-Malaita-Wall-Katoomba-Blue-Mountains.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 01:23:49+00:00

A man has fallen to his death around 8am while abseiling at a popular tourist spot at Katoomba in the Blue Mountains. The man is believed to be aged in his 20s but is yet to be formally identified.

## Mail rejects celebrities' claims of intrusion
 - [https://www.dailymail.co.uk/news/article-11289773/Mail-rejects-celebrities-claims-intrusion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289773/Mail-rejects-celebrities-claims-intrusion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 01:14:09+00:00

The publisher of the Daily Mail unambiguously rejected 'preposterous smears' after legal claims by a group including Sir Elton John, Prince Harry and Baroness Doreen Lawrence.

## DAILY MAIL COMMENT: Cold comfort from green energy fiasco
 - [https://www.dailymail.co.uk/news/article-11289975/DAILY-MAIL-COMMENT-Cold-comfort-green-energy-fiasco.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289975/DAILY-MAIL-COMMENT-Cold-comfort-green-energy-fiasco.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 01:09:32+00:00

DAILY MAIL COMMENT: Could there be any more devastating indictment of our net-zero obsessed political class than that Britain is riding its luck when it comes to keeping our homes warm?

## David Dimbleby blasts the BBC's 'reluctance to criticise the royal family'
 - [https://www.dailymail.co.uk/news/article-11289605/David-Dimbleby-hits-Remainers-endlessly-moaning-Brexit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289605/David-Dimbleby-hits-Remainers-endlessly-moaning-Brexit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 01:08:08+00:00

The former Question Time presenter, 83, has accused the broadcaster of avoiding topics 'they feel their viewers will not like' after returning to cover the Queen's funeral last month.

## Horrified witnesses to City of London bloodbath recall actions of three brave 'have-a-go heroes'
 - [https://www.dailymail.co.uk/news/article-11289863/Horrified-witnesses-City-London-bloodbath-recall-actions-three-brave-heroes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289863/Horrified-witnesses-City-London-bloodbath-recall-actions-three-brave-heroes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 01:05:45+00:00

Metropolitan Police are currently hunting at least two suspects involved in the City of London incident, which saw three people hospitalised and sparked a mass emergency response.

## Woman dies after she was found with head injuries in an alleyway
 - [https://www.dailymail.co.uk/news/article-11289937/Woman-dies-head-injuries-alleyway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289937/Woman-dies-head-injuries-alleyway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 01:05:36+00:00

The woman was found in a alleyway, pictured, in Scunthorpe on Saturday, October 1. She was taken to hospital for treatment but sadly died as a result of her injuries on October 5.

## Covid vaccine warning to children as Dr Nick Coatsworth demands review over myocarditis side effect
 - [https://www.dailymail.co.uk/news/article-11289389/Covid-vaccine-warning-children-Dr-Nick-Coatsworth-demands-review-myocarditis-effect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289389/Covid-vaccine-warning-children-Dr-Nick-Coatsworth-demands-review-myocarditis-effect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 01:04:14+00:00

The former deputy chief medical officer said Australia should reconsider its stance on giving the dose to children above the age of five.

## Brittany Higgins, Bruce Lehrmann rape trial to hear of secret recording of call with minister
 - [https://www.dailymail.co.uk/news/article-11289471/Brittany-Higgins-Bruce-Lehrmann-rape-trial-hear-secret-recording-call-minister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289471/Brittany-Higgins-Bruce-Lehrmann-rape-trial-hear-secret-recording-call-minister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:58:51+00:00

The former Liberal staffer is the first witness in the criminal trial of Bruce Lehrmann, who she alleges sexually assaulted her inside Parliament House after a boozy night out in March, 2019.

## People are less likely to try new experiences as they approach old age, research shows
 - [https://www.dailymail.co.uk/news/article-11289879/People-likely-try-new-experiences-approach-old-age-research-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289879/People-likely-try-new-experiences-approach-old-age-research-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:54:03+00:00

Many of us savour the prospect of ticking off a 'bucket list' of things to do by the time we reach our twilight years.

## Emmanuel Macron says EU-wide migration agreement is possible if Truss backs down on NI
 - [https://www.dailymail.co.uk/news/article-11289735/Emmanuel-Macron-says-EU-wide-migration-agreement-possible-Truss-backs-NI.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289735/Emmanuel-Macron-says-EU-wide-migration-agreement-possible-Truss-backs-NI.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:50:27+00:00

France will allow Britain to strike an EU-wide migration deal only if Liz Truss backs down in the long-running Brexit row over Northern Ireland, senior French officials told the Daily Mail.

## Why could we suffer blackouts, what happens to hospitals and what about the vulnerable?
 - [https://www.dailymail.co.uk/news/article-11289837/Why-suffer-blackouts-happens-hospitals-vulnerable.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289837/Why-suffer-blackouts-happens-hospitals-vulnerable.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:49:34+00:00

Why are blackouts possible? The UK relies on natural gas to generate around 40 per cent of its electricity. But gas supplies from abroad have been disrupted by the war in Ukraine.

## Jacob Rees-Mogg backs plans to make day monarch will be crowned a public holiday
 - [https://www.dailymail.co.uk/news/article-11289809/Jacob-Rees-Mogg-backs-plans-make-day-monarch-crowned-public-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289809/Jacob-Rees-Mogg-backs-plans-make-day-monarch-crowned-public-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:49:08+00:00

It comes as some sources have said that UK Government members were against a bank holiday because of their fears over growth.

## Bombshell new book claims 'dashing' Duke of Sussex was turning into a 'seedy old roué' before Meghan
 - [https://www.dailymail.co.uk/news/article-11289571/Bombshell-new-book-claims-dashing-Duke-Sussex-turning-seedy-old-rou-Meghan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289571/Bombshell-new-book-claims-dashing-Duke-Sussex-turning-seedy-old-rou-Meghan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:48:16+00:00

The Duke of Sussex, 38, was also 'quite a wild lad' and had a reputation as a party prince following a decade in the military, according to new book Courtiers: The Hidden Power Behind the Crown.

## Rockingham General Hospital boss denies patient sent to the morgue in a body bag was still alive
 - [https://www.dailymail.co.uk/news/article-11289717/Rockingham-General-Hospital-boss-denies-patient-sent-morgue-body-bag-alive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289717/Rockingham-General-Hospital-boss-denies-patient-sent-morgue-body-bag-alive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:45:09+00:00

Kevin Reid, 55, died in a West Australian hospital but whether that was on the night of September 5 this year or the following day on September 6 has been called into question.

## Low humming plaguing locals remains a mystery after council probe draws a blank
 - [https://www.dailymail.co.uk/news/article-11289901/Low-humming-plaguing-locals-remains-mystery-council-probe-draws-blank.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289901/Low-humming-plaguing-locals-remains-mystery-council-probe-draws-blank.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:44:39+00:00

It has driven locals to distraction for years, keeping them awake at night. But despite extensive tests, the 'Holmfield Hum's' cause could not be pinpointed by an official investigation.

## Social care reforms should be delayed to avoid making 'perfect storm' worse, council chiefs warn
 - [https://www.dailymail.co.uk/news/article-11289897/Social-care-reforms-delayed-avoid-making-perfect-storm-worse-council-chiefs-warn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289897/Social-care-reforms-delayed-avoid-making-perfect-storm-worse-council-chiefs-warn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:42:18+00:00

Last month, Health Secretary Therese Coffey announced a more generous means-testing system and a lifetime cap of £86,000 on care costs from next autumn.

## Oranges gone to waste: NSW farmers hit hard by La Nina resulting in damaged produce
 - [https://www.dailymail.co.uk/news/article-11289465/Oranges-gone-waste-NSW-farmers-hit-hard-La-Nina-resulting-damaged-produce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289465/Oranges-gone-waste-NSW-farmers-hit-hard-La-Nina-resulting-damaged-produce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:35:37+00:00

Farmers across the country have been forced to dump truckloads of healthy oranges into large 'graveyards' of fruit all because consumers don't want blemished produce.

## Weather: heavy rain in eastern Australia with storms in NSW, QLD and Victoria ahead of Bathurst 1000
 - [https://www.dailymail.co.uk/news/article-11289129/Weather-heavy-rain-eastern-Australia-storms-NSW-QLD-Victoria-ahead-Bathurst-1000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289129/Weather-heavy-rain-eastern-Australia-storms-NSW-QLD-Victoria-ahead-Bathurst-1000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:19:26+00:00

Residents in New South Wales and Victoria have been warned to prepare for two more major weather events this weekend with SES on standby for possible tornados.

## Jeremy Clarkson fans blast 'jealous' locals after Diddly Squat Farm restaurant ordered to close
 - [https://www.dailymail.co.uk/news/article-11289725/Jeremy-Clarkson-fans-blast-jealous-locals-Diddly-Squat-Farm-restaurant-ordered-close.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289725/Jeremy-Clarkson-fans-blast-jealous-locals-Diddly-Squat-Farm-restaurant-ordered-close.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:04:17+00:00

Jeremy Clarkson fans were disappointed on Thursday as they arrived to find the Diddly Squat Farm restaurant and cafe closed by orders of the West Oxfordshire District Council.

## Shocking moment DPD driver is forced to haul himself over fence after being 'locked in' by customer
 - [https://www.dailymail.co.uk/news/article-11288933/Shocking-moment-DPD-driver-forced-haul-fence-locked-customer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11288933/Shocking-moment-DPD-driver-forced-haul-fence-locked-customer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:02:40+00:00

In a video shared on TikTok, the driver can be seen climbing a wheelie bin during his attempts to escape a driveway after a woman accuses him of refusing to give her a parcel.

## Cancer care and mental health services could be cut to slash NHS spending by £20billion
 - [https://www.dailymail.co.uk/news/article-11289839/Cancer-care-mental-health-services-cut-slash-NHS-spending-20billion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11289839/Cancer-care-mental-health-services-cut-slash-NHS-spending-20billion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-07 00:02:38+00:00

The warning from NHS England's chief financial officer raised fears that a 'financial hit of this magnitude' could scupper efforts to tackle record waiting lists of 6.8 million.


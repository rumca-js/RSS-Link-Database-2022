# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Dehd – Bad Love (live for The Current)
 - [https://www.youtube.com/watch?v=sb5Jp4q3GTs](https://www.youtube.com/watch?v=sb5Jp4q3GTs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-10-08 00:00:00+00:00

Chicago band Dehd, on tour in support of their latest album, 'Blue Skies,' visited The Current studio for a session hosted by Ayisha Jaffer. Watch Dehd perform the single "Bad Love" from the album. 

Band members
Emily Kempf – vocals, bass
Jason Balla – guitar, backing vocals
Eric McGrady – drums, percussion

Credits
Guests – Dehd
Host – Ayisha Jaffer
Producer – Derrick Stevens
Video – Eric Xu Romani
Camera Operators – Eric Xu Romani, Derek Ramirez
Audio – Evan Clark
Graphics – Natalia Toledo
Digital Producer – Luke Taylor 

#dehd #dehdband

## Amyl and the Sniffers – studio session at The Current (music + interview)
 - [https://www.youtube.com/watch?v=b0W1wrgHQH4](https://www.youtube.com/watch?v=b0W1wrgHQH4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-10-07 00:00:00+00:00

Ahead of their show at First Avenue in Minneapolis, Australian punk-rock band Amyl and the Sniffers visited The Current studio for a session hosted by Mac Wilson. They played two songs from their latest album, 'Comfort to Me,' after starting with a cut from their 2019 self-titled release. After the music, the band spoke with Mac Wilson about how they spent their time during pandemic-related lockdowns, and the approach they take to keeping their sets lively and fresh every night. 

Video segments
00:00:00 Gacked on Anger
00:01:58 Maggot
00:04:49 Guided By Angels
00:08:03 Interview with host Mac Wilson

Band members
Amy Taylor – vocals
Dec Martens – guitar
Fergus Romer – bass
Bryce Wilson – drums

Credits
Guests – Amyl and the Sniffers
Host – Mac Wilson
Producer – Derrick Stevens
Video Director – Erik Stromstad
Camera Operators – Erik Stromstad, Peter Ecklund
Audio – Eric Xu Romani
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

#amylandthesniffers @amylandthesniffers6771

## Dehd – studio session at The Current (music + interview)
 - [https://www.youtube.com/watch?v=z9GLMkeptXI](https://www.youtube.com/watch?v=z9GLMkeptXI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-10-07 00:00:00+00:00

Chicago band Dehd, on tour in support of their latest album, Blue Skies, visited The Current studio for a session hosted by Ayisha Jaffer. In addition to playing songs from the new record, Dehd’s Emily Kempf and Jason Balla took time to go deep on the songs’ meanings and the inspiration behind them. They also talk about how they helped bring live music to Chicagoans in a surprising way during the depths of the pandemic. And they also pull back the curtain on some stories their fans have shared on the band’s Hotline, a feature of their website. 

Video Segments
00:00:00 Bad Love
00:02:21 Stars
00:05:00 Window
00:07:49 Interview with host Ayisha Jaffer

Band members
Emily Kempf – vocals, bass
Jason Balla – guitar, backing vocals
Eric McGrady – drums, percussion

Credits
Guests – Dehd
Host – Ayisha Jaffer
Producer – Derrick Stevens
Video – Eric Xu Romani
Camera Operators – Eric Xu Romani, Derek Ramirez
Audio – Evan Clark
Graphics – Natalia Toledo
Digital Producer – Luke Taylor 

#dehd #dehdband


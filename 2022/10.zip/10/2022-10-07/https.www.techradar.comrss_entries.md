# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Papa John's is being sued for allegedly 'wiretapping' its own website
 - [https://www.techradar.com/news/papa-johns-is-being-sued-for-allegedly-wiretapping-its-own-website/](https://www.techradar.com/news/papa-johns-is-being-sued-for-allegedly-wiretapping-its-own-website/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 21:08:06+00:00

The company took session replay software too far, and broke multiple laws, lawsuit claims

## New Android 13 beta makes it easier to track battery usage on Pixel phones
 - [https://www.techradar.com/news/new-android-13-beta-makes-it-easier-to-track-battery-usage-on-pixel-phones/](https://www.techradar.com/news/new-android-13-beta-makes-it-easier-to-track-battery-usage-on-pixel-phones/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 19:35:26+00:00

Android 13 QPR1 Beta 2 tells you which apps are the most power hungry while slightly redesigning certain menus.

## Tech giants found destroying thousands of data storage devices every year - but why?
 - [https://www.techradar.com/news/tech-giants-found-destroying-thousands-of-data-storage-devices-every-year-but-why/](https://www.techradar.com/news/tech-giants-found-destroying-thousands-of-data-storage-devices-every-year-but-why/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 19:29:00+00:00

Properly decommissioning data storage equipment has many benefits, but it needs to be done right, experts say.

## Shock horror - many top mobile apps secretly collect your data
 - [https://www.techradar.com/news/shock-horror-many-top-mobile-apps-secretly-collect-your-data/](https://www.techradar.com/news/shock-horror-many-top-mobile-apps-secretly-collect-your-data/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 18:26:45+00:00

Financial gain is the top driver for app data sharing, report claims.

## Global VC funding has seen a huge drop this year
 - [https://www.techradar.com/news/global-vc-funding-has-seen-a-huge-drop-this-year/](https://www.techradar.com/news/global-vc-funding-has-seen-a-huge-drop-this-year/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 17:15:35+00:00

Venture capital funding in Q3 2022 fell to almost pre-pandemic levels, according to Crunchbase data.

## Google Pixel 7a: what to expect and what we want to see
 - [https://www.techradar.com/news/google-pixel-7a/](https://www.techradar.com/news/google-pixel-7a/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 16:49:14+00:00

The Google Pixel 7a could be Google's next phone. Here's what we've heard about it so far and what we want.

## Google Pixel 7a: what to expect and what we want to see
 - [https://www.techradar.com/news/google-pixel-7a](https://www.techradar.com/news/google-pixel-7a)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 16:49:14+00:00

The Google Pixel 7a could be Google's next phone. Here's what we've heard about it so far and what we want.

## I tried the weirdest-looking Bluetooth speaker in the world, and I utterly adore it
 - [https://www.techradar.com/news/i-tried-the-weirdest-looking-bluetooth-speaker-in-the-world-and-i-utterly-adore-it/](https://www.techradar.com/news/i-tried-the-weirdest-looking-bluetooth-speaker-in-the-world-and-i-utterly-adore-it/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 16:28:31+00:00

The GravaStar Mars Pro in 'War Damaged Yellow' is a product I wanted to dislike – but it turns out I cannot let it go.

## Splatoon 3's next big event will settle the most contentious Pokémon debate of all
 - [https://www.techradar.com/news/splatoon-3s-next-big-event-will-settle-the-most-contentious-pokemon-debate-of-all/](https://www.techradar.com/news/splatoon-3s-next-big-event-will-settle-the-most-contentious-pokemon-debate-of-all/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 16:25:44+00:00

Splatoon 3's upcoming event is Pokémon themed and will force players to make a difficult choice.

## Microsoft Teams is finally fixing one of the worst things about PowerPoint presentations
 - [https://www.techradar.com/news/microsoft-teams-is-finally-fixing-one-of-the-worst-things-about-powerpoint-presentations/](https://www.techradar.com/news/microsoft-teams-is-finally-fixing-one-of-the-worst-things-about-powerpoint-presentations/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 16:06:01+00:00

Users will be able to magnify any Microsoft Teams slides they want.

## His Dark Materials season 3 spies a late 2022 release – and Lee Scoresby's return
 - [https://www.techradar.com/news/his-dark-materials-season-3-spies-a-late-2022-release-and-lee-scoresbys-return/](https://www.techradar.com/news/his-dark-materials-season-3-spies-a-late-2022-release-and-lee-scoresbys-return/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 15:38:11+00:00

The first trailer for His Dark Materials' final season has landed online – as has its official release date.

## Amazon is hiring 150,000 temps for Christmas this year
 - [https://www.techradar.com/news/amazon-is-hiring-150000-temps-for-christmas-this-year/](https://www.techradar.com/news/amazon-is-hiring-150000-temps-for-christmas-this-year/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 14:56:46+00:00

Amazon is significantly stepping up its hiring in the run-up to what is traditionally its busiest period.

## Binance says at least $100 million stolen in blockchain attack
 - [https://www.techradar.com/news/binance-says-at-least-dollar100-million-stolen-in-blockchain-attack/](https://www.techradar.com/news/binance-says-at-least-dollar100-million-stolen-in-blockchain-attack/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 14:18:01+00:00

Binance says around $100 million was taken, but analysts argue it might be five times as much

## 7 new movies and TV shows on Netflix, Prime Video, HBO Max and more this weekend (October 7)
 - [https://www.techradar.com/news/7-new-movies-and-tv-shows-on-netflix-prime-video-hbo-max-and-more-this-weekend-october-7-2022/](https://www.techradar.com/news/7-new-movies-and-tv-shows-on-netflix-prime-video-hbo-max-and-more-this-weekend-october-7-2022/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 14:00:00+00:00

From gripping true crime documentaries to long-awaited horror revivals, there’s plenty to watch this weekend.

## Inmarsat and Viasat merger could increase in-flight Wi-Fi costs, watchdog warns
 - [https://www.techradar.com/news/inmarsat-and-viasat-merger-could-increase-in-flight-wi-fi-costs-watchdog-warns/](https://www.techradar.com/news/inmarsat-and-viasat-merger-could-increase-in-flight-wi-fi-costs-watchdog-warns/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 13:48:34+00:00

CMA investigation concludes market would be negatively impacted by transaction.

## Wear OS 3.5 is here: features, supported watches and everything you need to know
 - [https://www.techradar.com/news/wear-os-3/](https://www.techradar.com/news/wear-os-3/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 13:44:56+00:00

Wear OS 3.5 overhauls Google's smartwatch operating system with Fitbit features and more.

## SteamOS update brings fixes and better display settings to your Steam Deck
 - [https://www.techradar.com/news/steamos-update-brings-fixes-and-better-display-settings-to-your-steam-deck/](https://www.techradar.com/news/steamos-update-brings-fixes-and-better-display-settings-to-your-steam-deck/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 13:37:40+00:00

Valve has brought out a bunch of improvements and fixes to the Steam Deck, alongside features to the Steam Dock.

## Intel Raptor Lake flagship CPU hits a huge 8.2GHz overclock
 - [https://www.techradar.com/news/intel-raptor-lake-flagship-cpu-hits-a-huge-82ghz-overclock/](https://www.techradar.com/news/intel-raptor-lake-flagship-cpu-hits-a-huge-82ghz-overclock/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 13:37:35+00:00

This monster overclock is a big stride on from Alder Lake, and gives AMD something to worry about.

## The new Need For Speed avoids what the Saints Row reboot got wrong
 - [https://www.techradar.com/news/the-new-need-for-speed-avoids-what-the-saints-row-reboot-got-wrong/](https://www.techradar.com/news/the-new-need-for-speed-avoids-what-the-saints-row-reboot-got-wrong/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 12:59:08+00:00

The Need for Speed Unbound reveal trailer could spell a return to what made the series great.

## New Windows 11 update is causing headaches for IT teams now too
 - [https://www.techradar.com/news/new-windows-11-update-is-causing-headaches-for-it-teams-now-too/](https://www.techradar.com/news/new-windows-11-update-is-causing-headaches-for-it-teams-now-too/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 12:47:07+00:00

Windows 11 22H2 update is now preventing IT teams from applying provisioning packages.

## Acer’s new flagship laptop could be best MacBook Pro alternative yet
 - [https://www.techradar.com/news/acers-new-flagship-laptop-could-be-best-macbook-pro-alternative-yet/](https://www.techradar.com/news/acers-new-flagship-laptop-could-be-best-macbook-pro-alternative-yet/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 12:23:25+00:00

Acer’s new laptop brings latest Ryzen CPU and better-than-4K display in chassis.

## This DoorDash update is giving you a lot more choice - for free
 - [https://www.techradar.com/news/doordash-says-its-okay-to-get-a-meal-from-one-spot-and-a-drink-from-another/](https://www.techradar.com/news/doordash-says-its-okay-to-get-a-meal-from-one-spot-and-a-drink-from-another/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 11:51:34+00:00

Only available in the United States, Drinks with DoubleDash won't add an extra fee or enforce a minimum order size

## Microsoft says insider threats could be your company's biggest security risk
 - [https://www.techradar.com/news/microsoft-says-insider-threats-could-be-your-companys-biggest-security-risk/](https://www.techradar.com/news/microsoft-says-insider-threats-could-be-your-companys-biggest-security-risk/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 11:27:56+00:00

Insider threats, intentional or not, are a growing pain for businesses, Microsoft report claims.

## Nvidia RTX 4090 graphics card power demands could make Thor weep
 - [https://www.techradar.com/news/nvidia-rtx-4090-graphics-card-power-demands-could-make-thor-weep/](https://www.techradar.com/news/nvidia-rtx-4090-graphics-card-power-demands-could-make-thor-weep/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 10:54:39+00:00

Worried about RTX 4090 power requirements? Some high-end models won’t calm your fears, that’s for sure.

## Netflix is still king when it comes to horror and The Midnight Club proves it
 - [https://www.techradar.com/opinion/netflix-is-still-king-when-it-comes-to-horror-and-the-midnight-club-proves-it/](https://www.techradar.com/opinion/netflix-is-still-king-when-it-comes-to-horror-and-the-midnight-club-proves-it/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 10:50:55+00:00

After the success of Midnight Mass and The Haunting of Bly Manor, the streamer has another hit.

## Even Meta's staff aren't fans of the Oculus Quest 2's metaverse based on leaked memo
 - [https://www.techradar.com/news/even-metas-staff-arent-fans-of-the-oculus-quest-2s-metaverse-based-on-leaked-memo/](https://www.techradar.com/news/even-metas-staff-arent-fans-of-the-oculus-quest-2s-metaverse-based-on-leaked-memo/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 10:50:10+00:00

Meta's own developers think its Horizon Worlds metaverse app on the Oculus Quest 2 is a clunky, unstable mess right now.

## Take to the skies in Nintendo Switch Online's next N64 game
 - [https://www.techradar.com/news/take-to-the-skies-in-nintendo-switch-onlines-next-n64-game/](https://www.techradar.com/news/take-to-the-skies-in-nintendo-switch-onlines-next-n64-game/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 10:00:04+00:00

Pilotwings 64 is your next Nintendo Switch Online N64 game, and it's landing very soon.

## Pokémon Scarlet and Violet takes a big risk by going full Breath of the Wild
 - [https://www.techradar.com/news/pokemon-scarlet-and-violet-takes-a-big-risk-by-going-full-breath-of-the-wild/](https://www.techradar.com/news/pokemon-scarlet-and-violet-takes-a-big-risk-by-going-full-breath-of-the-wild/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 09:51:11+00:00

A new gameplay trailer shows that Pokémon Scarlet and Violet is going open world in a big way.

## Intel doubles down on graphics cards with next-gen Arc GPUs already in the works
 - [https://www.techradar.com/news/intel-doubles-down-on-graphics-cards-with-next-gen-arc-gpus-already-in-the-works/](https://www.techradar.com/news/intel-doubles-down-on-graphics-cards-with-next-gen-arc-gpus-already-in-the-works/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 09:36:47+00:00

Team Blue’s Arc GPU division is still going strong, says head honcho Raja Koduri.

## Google's foldable Pixel 7 alternative could be just a few months away
 - [https://www.techradar.com/news/googles-foldable-pixel-7-alternative-could-be-just-a-few-months-away/](https://www.techradar.com/news/googles-foldable-pixel-7-alternative-could-be-just-a-few-months-away/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 09:30:02+00:00

The Google Pixel Fold might land in the first few months of 2023, according to the latest leak.

## Best car vacuum2022: tried and tested by us
 - [https://www.techradar.com/news/best-car-vacuum/](https://www.techradar.com/news/best-car-vacuum/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 09:00:37+00:00

Keep your car looking showroom fresh with the best car vacuums from the likes of Dyson, Shark and Eufy.

## Marvel's Man-Thing explained: who is Werewolf by Night's other monster?
 - [https://www.techradar.com/news/marvels-man-thing-explained-who-is-werewolf-by-nights-other-monster/](https://www.techradar.com/news/marvels-man-thing-explained-who-is-werewolf-by-nights-other-monster/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 08:44:35+00:00

Here's everything you need to know about the Cthulhu-style creature in Marvel Studios' Werewolf by Night.

## The Rings of Power episode 7 recap: death, destruction, and delicious dwarven drama
 - [https://www.techradar.com/news/the-rings-of-power-episode-7-recap-death-destruction-and-delicious-dwarven-drama/](https://www.techradar.com/news/the-rings-of-power-episode-7-recap-death-destruction-and-delicious-dwarven-drama/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 07:00:00+00:00

The Rings of Power episode 7 deals with the fallout of its predecessor's shocking ending in explosive fashion.

## Samsung opens the biggest “Smart Things Home” space in the world in Dubai
 - [https://www.techradar.com/news/samsung-opens-the-biggest-smart-things-home-space-in-the-world-in-dubai/](https://www.techradar.com/news/samsung-opens-the-biggest-smart-things-home-space-in-the-world-in-dubai/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 06:04:22+00:00

Samsung's Smart Things platform has 230 million users globally and 31 million in MENA region

## These new GPU support brackets keep your graphics card safe from sag
 - [https://www.techradar.com/news/these-new-gpu-support-brackets-keep-your-graphics-card-safe-from-sag/](https://www.techradar.com/news/these-new-gpu-support-brackets-keep-your-graphics-card-safe-from-sag/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 06:00:15+00:00

Cooler Master and other manufacturers have been releasing GPU support brackets recently.

## Google Pixel 7 and Pixel 7 Pro: the 7 most exciting new camera features
 - [https://www.techradar.com/news/google-pixel-7-and-pixel-7-pro-the-7-most-exciting-new-camera-features/](https://www.techradar.com/news/google-pixel-7-and-pixel-7-pro-the-7-most-exciting-new-camera-features/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-07 05:00:00+00:00

The Google Pixel 7 and Pixel 7 Pro have just landed, which means some fancy new camera tricks. Here are our favorites.


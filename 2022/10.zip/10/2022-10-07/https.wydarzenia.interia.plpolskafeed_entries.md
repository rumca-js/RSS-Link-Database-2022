# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Nowe zakażenia koronawirusem. Ministerstwo podało aktualne dane
 - [https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-nowe-zakazenia-koronawirusem-ministerstwo-podalo-aktualne-da,nId,6332723](https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-nowe-zakazenia-koronawirusem-ministerstwo-podalo-aktualne-da,nId,6332723)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-10-07 08:30:36+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-nowe-zakazenia-koronawirusem-ministerstwo-podalo-aktualne-da,nId,6332723"><img align="left" alt="Nowe zakażenia koronawirusem. Ministerstwo podało aktualne dane" src="https://i.iplsc.com/nowe-zakazenia-koronawirusem-ministerstwo-podalo-aktualne-da/000EMH3UIFMVHVX5-C321.jpg" /></a>Ministerstwo Zdrowia poinformowało w piątek, 7 października, o wykryciu 2629 nowych zakażeń koronawirusem w ciągu ostatniej doby. Zm


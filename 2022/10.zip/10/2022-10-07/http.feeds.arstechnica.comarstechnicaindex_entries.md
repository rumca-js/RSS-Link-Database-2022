# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## The stage is set for a war between worlds in His Dark Materials S3 teaser
 - [https://arstechnica.com/?p=1888152](https://arstechnica.com/?p=1888152)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 23:15:49+00:00

"We cut off the head, and the rest will crumble."

## Unpatched Zimbra flaw under attack is letting hackers backdoor servers
 - [https://arstechnica.com/?p=1888336](https://arstechnica.com/?p=1888336)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 23:01:09+00:00

The flaw has been under attack since at least early September.

## Florida tokers inadvertently smoked rat poison; 52 sickened, 4 dead
 - [https://arstechnica.com/?p=1888312](https://arstechnica.com/?p=1888312)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 22:20:07+00:00

It's not the first time rat poison has shown up in fake weed.

## Post-impact images of DART mission have not disappointed
 - [https://arstechnica.com/?p=1888136](https://arstechnica.com/?p=1888136)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 21:56:24+00:00

Ground, space-based telescopes, and a nearby cubesat have all captured the impact.

## After 23 years, Weather Channel’s iconic computerized channel is shutting down
 - [https://arstechnica.com/?p=1884131](https://arstechnica.com/?p=1884131)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 20:16:27+00:00

Cult-favorite Weatherscan TV service launched in 1999; hobbyists aim to keep it alive.

## Why Chris Pratt’s performance in the Mario movie trailer is so distracting
 - [https://arstechnica.com/?p=1888112](https://arstechnica.com/?p=1888112)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 20:01:38+00:00

Even kids can tell something is a little off with Mario's new voice.

## No Man’s Sky adds tons of quality-of-life improvements alongside Switch launch
 - [https://arstechnica.com/?p=1888155](https://arstechnica.com/?p=1888155)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 19:33:25+00:00

Substantial changes focus on difficulty, flow, and inventory management.

## Amazon “suicide kits” have led to teen deaths, according to new lawsuit
 - [https://arstechnica.com/?p=1888101](https://arstechnica.com/?p=1888101)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 19:07:05+00:00

Lawsuit claims Amazon is No. 1 seller of deadly chemical used in suicides.

## Twitter knows you took a screenshot, asks you to share instead
 - [https://arstechnica.com/?p=1887988](https://arstechnica.com/?p=1887988)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 17:00:58+00:00

Users are being prompted to share (monetizable) links instead of screen images.

## Elon Musk can’t be trusted to complete merger, Twitter tells judge
 - [https://arstechnica.com/?p=1888043](https://arstechnica.com/?p=1888043)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 16:25:14+00:00

Twitter says there's a financing problem and that Musk won't commit to closing date.

## Pixel 7 Pro teardown shows better cooling, cleaner layout than last year’s model
 - [https://arstechnica.com/?p=1888011](https://arstechnica.com/?p=1888011)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 16:16:57+00:00

A cleaner layout enables more thermal tape over the SoC, camera, and battery.

## In sudden reversal, Valve will let a cult classic visual novel onto Steam
 - [https://arstechnica.com/?p=1888007](https://arstechnica.com/?p=1888007)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 15:07:20+00:00

Steam-maker also promises "changes to avoid situations like this in the future."

## Binance blockchain suffers $570 million hack
 - [https://arstechnica.com/?p=1887987](https://arstechnica.com/?p=1887987)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 13:49:06+00:00

World’s largest crypto exchange targeted in security breach.

## What happened to the virtual reality gaming revolution?
 - [https://arstechnica.com/?p=1885995](https://arstechnica.com/?p=1885995)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 11:30:39+00:00

VR hasn't taken over the world, but that doesn't mean it has failed.

## Rocket Report: Falcon Heavy launch on tap; South Korea seeks Russia alternative
 - [https://arstechnica.com/?p=1887499](https://arstechnica.com/?p=1887499)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 11:00:23+00:00

Also, the Ariane 6 rocket is inching closer to the launch pad.

## Acer’s Ryzen 6000-powered Swift Edge laptop has a 16-inch OLED screen for $1,500
 - [https://arstechnica.com/?p=1887624](https://arstechnica.com/?p=1887624)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-07 04:30:44+00:00

The AMD-based Swift Edge is bigger and OLED-ier than the Intel-based Swift ultralight.


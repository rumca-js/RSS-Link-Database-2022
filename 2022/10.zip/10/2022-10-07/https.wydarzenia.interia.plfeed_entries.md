# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Wojna w Ukrainie. Zełenski: Putin boi się swojego narodu
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-zelenski-putin-boi-sie-swojego-narodu,nId,6333715](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-zelenski-putin-boi-sie-swojego-narodu,nId,6333715)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 21:50:25+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-zelenski-putin-boi-sie-swojego-narodu,nId,6333715"><img align="left" alt="Wojna w Ukrainie. Zełenski: Putin boi się swojego narodu" src="https://i.iplsc.com/wojna-w-ukrainie-zelenski-putin-boi-sie-swojego-narodu/000F38U9HW655C87-C321.jpg" /></a>Prezydent Ukrainy Wołodymyr Zełenski w wywiadzie udzielonym w piątek BBC wezwał do nałożenia na Rosję sankcji wyprzedzających. Stwierdził, że władze r

## USA. Po huraganie Ian strażacy walczą z pożarami samochodów elektrycznych
 - [https://wydarzenia.interia.pl/zagranica/news-usa-po-huraganie-ian-strazacy-walcza-z-pozarami-samochodow-e,nId,6333706](https://wydarzenia.interia.pl/zagranica/news-usa-po-huraganie-ian-strazacy-walcza-z-pozarami-samochodow-e,nId,6333706)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 20:49:36+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-po-huraganie-ian-strazacy-walcza-z-pozarami-samochodow-e,nId,6333706"><img align="left" alt="USA. Po huraganie Ian strażacy walczą z pożarami samochodów elektrycznych" src="https://i.iplsc.com/usa-po-huraganie-ian-strazacy-walcza-z-pozarami-samochodow-e/000G69DIOXMBOHDF-C321.jpg" /></a>Po przejściu huraganu Ian, Floryda mierzy się z jeszcze jednym problemem - poinformował &quot;New York Post&quot;. Po rozległych powodziach - i po tym j

## USA: Kryzys migracyjny. Ogłoszono stan wyjątkowy w Nowym Jorku
 - [https://wydarzenia.interia.pl/zagranica/news-usa-kryzys-migracyjny-ogloszono-stan-wyjatkowy-w-nowym-jorku,nId,6333701](https://wydarzenia.interia.pl/zagranica/news-usa-kryzys-migracyjny-ogloszono-stan-wyjatkowy-w-nowym-jorku,nId,6333701)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 20:22:25+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-kryzys-migracyjny-ogloszono-stan-wyjatkowy-w-nowym-jorku,nId,6333701"><img align="left" alt="USA: Kryzys migracyjny. Ogłoszono stan wyjątkowy w Nowym Jorku " src="https://i.iplsc.com/usa-kryzys-migracyjny-ogloszono-stan-wyjatkowy-w-nowym-jorku/000G699UF6J8J1JM-C321.jpg" /></a>Burmistrz Nowego Jorku Eric Adams ogłosił w piątek stan wyjątkowy. To odpowiedź na kryzys migracyjny, który będzie kosztował miasto miliard dolarów w tym roku pod

## Szwecja. Nauczyciel od lat gwałcił i molestował uczniów. 15 ofiar
 - [https://wydarzenia.interia.pl/zagranica/news-szwecja-nauczyciel-od-lat-gwalcil-i-molestowal-uczniow-15-of,nId,6333693](https://wydarzenia.interia.pl/zagranica/news-szwecja-nauczyciel-od-lat-gwalcil-i-molestowal-uczniow-15-of,nId,6333693)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 20:05:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szwecja-nauczyciel-od-lat-gwalcil-i-molestowal-uczniow-15-of,nId,6333693"><img align="left" alt="Szwecja. Nauczyciel od lat gwałcił i molestował uczniów. 15 ofiar" src="https://i.iplsc.com/szwecja-nauczyciel-od-lat-gwalcil-i-molestowal-uczniow-15-of/000G6972NF7SCCPL-C321.jpg" /></a>Nauczyciel z Borås w Szwecji jest oskarżony o gwałty i molestowanie seksualne dzieci. Sprawa ma dotyczyć 15 uczniów. Do przestępstw dochodziło przez kilka lat. 

## Irańskie drony trafiły na Białoruś. Rosja chce atakować zachodnią Ukrainę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-iranskie-drony-trafily-na-bialorus-rosja-chce-atakowac-zacho,nId,6333691](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-iranskie-drony-trafily-na-bialorus-rosja-chce-atakowac-zacho,nId,6333691)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 19:56:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-iranskie-drony-trafily-na-bialorus-rosja-chce-atakowac-zacho,nId,6333691"><img align="left" alt="Irańskie drony trafiły na Białoruś. Rosja chce atakować zachodnią Ukrainę" src="https://i.iplsc.com/iranskie-drony-trafily-na-bialorus-rosja-chce-atakowac-zacho/000G696MH1N72RMV-C321.jpg" /></a>Rosjanie przerzucili na Białoruś drony-kamikadze irańskiej produkcji. Oznacza to, że możliwe są ataki przy pomocy tych ma

## Do Dumy Państwowej trafił projekt o mobilizacji. Ma liberalizować przepisy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-do-dumy-panstwowej-trafil-projekt-o-mobilizacji-ma-liberaliz,nId,6333685](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-do-dumy-panstwowej-trafil-projekt-o-mobilizacji-ma-liberaliz,nId,6333685)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 19:36:19+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-do-dumy-panstwowej-trafil-projekt-o-mobilizacji-ma-liberaliz,nId,6333685"><img align="left" alt="Do Dumy Państwowej trafił projekt o mobilizacji. Ma liberalizować przepisy" src="https://i.iplsc.com/do-dumy-panstwowej-trafil-projekt-o-mobilizacji-ma-liberaliz/000G690ROXK4SQA7-C321.jpg" /></a>Do rosyjskiej Dumy Państwowej trafił projekt ustawy, który ma precyzować procedurę mobilizacji wojskowej. Propozycja ma 

## Tragiczne odkrycie. Ciało 25-latka z odciętą głową
 - [https://wydarzenia.interia.pl/zagranica/news-tragiczne-odkrycie-cialo-25-latka-z-odcieta-glowa,nId,6333659](https://wydarzenia.interia.pl/zagranica/news-tragiczne-odkrycie-cialo-25-latka-z-odcieta-glowa,nId,6333659)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 19:10:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tragiczne-odkrycie-cialo-25-latka-z-odcieta-glowa,nId,6333659"><img align="left" alt="Tragiczne odkrycie. Ciało 25-latka z odciętą głową" src="https://i.iplsc.com/tragiczne-odkrycie-cialo-25-latka-z-odcieta-glowa/000G68VIISFTSI59-C321.jpg" /></a>Znaleziono ciało 25-latka z odciętą głową. Do tragicznego odkrycia doszło na okupowanym Zachodnim Brzegu. Z informacji wynika, że mężczyzna był homoseksualistą, a znajomi ze społeczności LGBTQ twie

## Media: Rząd Niemiec wydał wizę rosyjskiemu szpiegowi
 - [https://wydarzenia.interia.pl/zagranica/news-media-rzad-niemiec-wydal-wize-rosyjskiemu-szpiegowi,nId,6333647](https://wydarzenia.interia.pl/zagranica/news-media-rzad-niemiec-wydal-wize-rosyjskiemu-szpiegowi,nId,6333647)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 18:46:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-media-rzad-niemiec-wydal-wize-rosyjskiemu-szpiegowi,nId,6333647"><img align="left" alt="Media: Rząd Niemiec wydał wizę rosyjskiemu szpiegowi" src="https://i.iplsc.com/media-rzad-niemiec-wydal-wize-rosyjskiemu-szpiegowi/000G68UFJ8K52TXC-C321.jpg" /></a>Tuż po ataku Rosji na Ukrainę rząd Niemiec wydalił z kraju 40 domniemanych szpiegów rosyjskich. Odtąd obowiązuje zasada niewpuszczania agentów Kremla - pisze &quot;Spiegel Online&quot;. W jed

## Problemy ze Starlinkami na froncie. Awarie to "ochrona technologii"?
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-problemy-ze-starlinkami-na-froncie-awarie-to-ochrona-technol,nId,6333645](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-problemy-ze-starlinkami-na-froncie-awarie-to-ochrona-technol,nId,6333645)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 18:17:05+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-problemy-ze-starlinkami-na-froncie-awarie-to-ochrona-technol,nId,6333645"><img align="left" alt="Problemy ze Starlinkami na froncie. Awarie to &quot;ochrona technologii&quot;?" src="https://i.iplsc.com/problemy-ze-starlinkami-na-froncie-awarie-to-ochrona-technol/000G68RR4O3FU1LV-C321.jpg" /></a>Ukraińscy żołnierze zgłaszają awarie i przestoje terminali Starlink - pisze &quot;Financial Times&quot;. Co najmniej

## Iran. Służby twierdzą, że Masha Amini zmarła z powodu "choroby"
 - [https://wydarzenia.interia.pl/zagranica/news-iran-sluzby-twierdza-ze-masha-amini-zmarla-z-powodu-choroby,nId,6333642](https://wydarzenia.interia.pl/zagranica/news-iran-sluzby-twierdza-ze-masha-amini-zmarla-z-powodu-choroby,nId,6333642)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 17:45:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-iran-sluzby-twierdza-ze-masha-amini-zmarla-z-powodu-choroby,nId,6333642"><img align="left" alt="Iran. Służby twierdzą, że Masha Amini zmarła z powodu &quot;choroby&quot;" src="https://i.iplsc.com/iran-sluzby-twierdza-ze-masha-amini-zmarla-z-powodu-choroby/000G68Q1T435DJLE-C321.jpg" /></a>Irańscy kryminalni przekazali, że &quot;śmierć Mashy Amini nie była spowodowana ciosami w głowę&quot;, a była związana z &quot;operacją guza mózgu w wieku

## USA uderzają w Chiny. Decyzja dotknie wojsko
 - [https://wydarzenia.interia.pl/zagranica/news-usa-uderzaja-w-chiny-decyzja-dotknie-wojsko,nId,6333608](https://wydarzenia.interia.pl/zagranica/news-usa-uderzaja-w-chiny-decyzja-dotknie-wojsko,nId,6333608)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 17:37:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-uderzaja-w-chiny-decyzja-dotknie-wojsko,nId,6333608"><img align="left" alt="USA uderzają w Chiny. Decyzja dotknie wojsko" src="https://i.iplsc.com/usa-uderzaja-w-chiny-decyzja-dotknie-wojsko/000FA606LON88FI8-C321.jpg" /></a>Amerykańskie Biuro Przemysłu i Bezpieczeństwa (BIS) dodało 31 chińskich firm technologicznych do listy podmiotów objętych kontrolą eksportu. Urząd stwierdza, że ma to na celu ograniczenie produkcji i kupna zaawansow

## Jedna decyzja w sprawie CPK. Kilkadziesiąt pudeł, 20 tys. stron
 - [https://wydarzenia.interia.pl/kraj/news-jedna-decyzja-w-sprawie-cpk-kilkadziesiat-pudel-20-tys-stron,nId,6333629](https://wydarzenia.interia.pl/kraj/news-jedna-decyzja-w-sprawie-cpk-kilkadziesiat-pudel-20-tys-stron,nId,6333629)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 17:04:34+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jedna-decyzja-w-sprawie-cpk-kilkadziesiat-pudel-20-tys-stron,nId,6333629"><img align="left" alt="Jedna decyzja w sprawie CPK. Kilkadziesiąt pudeł, 20 tys. stron" src="https://i.iplsc.com/jedna-decyzja-w-sprawie-cpk-kilkadziesiat-pudel-20-tys-stron/000G68J4TC6TNRXD-C321.jpg" /></a>Raport oceny oddziaływania na środowisko budowy Centralnego Portu Komunikacyjnego zawiera działania, które mają pozwolić na zminimalizowanie negatywnych konsekwencji i

## Realne zagrożenie. Może uderzyć w tysiące Niemców
 - [https://wydarzenia.interia.pl/zagranica/news-realne-zagrozenie-moze-uderzyc-w-tysiace-niemcow,nId,6333567](https://wydarzenia.interia.pl/zagranica/news-realne-zagrozenie-moze-uderzyc-w-tysiace-niemcow,nId,6333567)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 16:59:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-realne-zagrozenie-moze-uderzyc-w-tysiace-niemcow,nId,6333567"><img align="left" alt="Realne zagrożenie. Może uderzyć w tysiące Niemców" src="https://i.iplsc.com/realne-zagrozenie-moze-uderzyc-w-tysiace-niemcow/000E2DUZGMVGQAAI-C321.jpg" /></a>Kryzys energetyczny coraz bardziej daje się we znaki. W Niemczech dochodzi już do odłączeń prądu i gazu. Odcięcie energii elektrycznej jest niedopuszczalne w sytuacji, kiedy istnieje ryzyko utraty życ

## Rosja szantażuje pracowników elektrowni. Grozi wysłaniem na front
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-szantazuje-pracownikow-elektrowni-grozi-wyslaniem-na-f,nId,6333501](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-szantazuje-pracownikow-elektrowni-grozi-wyslaniem-na-f,nId,6333501)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 16:49:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-szantazuje-pracownikow-elektrowni-grozi-wyslaniem-na-f,nId,6333501"><img align="left" alt="Rosja szantażuje pracowników elektrowni. Grozi wysłaniem na front" src="https://i.iplsc.com/rosja-szantazuje-pracownikow-elektrowni-grozi-wyslaniem-na-f/000G689I1013EOCL-C321.jpg" /></a>Pracownicy Zaporoskiej Elektrowni Atomowej są zmuszani do podpisywania umów współpracy z rosyjskim Rosatomem. Jeśli tego nie zrob

## "Putin" w trumnie przed rosyjską ambasadą. Życzyli mu lat więzienia
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-w-trumnie-przed-rosyjska-ambasada-zyczyli-mu-lat-wiezi,nId,6333415](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-w-trumnie-przed-rosyjska-ambasada-zyczyli-mu-lat-wiezi,nId,6333415)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 16:30:13+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-putin-w-trumnie-przed-rosyjska-ambasada-zyczyli-mu-lat-wiezi,nId,6333415"><img align="left" alt="&quot;Putin&quot; w trumnie przed rosyjską ambasadą. Życzyli mu lat więzienia" src="https://i.iplsc.com/putin-w-trumnie-przed-rosyjska-ambasada-zyczyli-mu-lat-wiezi/000G67Z6CRU0G8TH-C321.jpg" /></a>Trumna, w której spoczywała lalka, przedstawiająca prezydenta Władimira Putina, stanęła w piątek przed Ambasadą Rosji

## Pięciolatek miał wrócić do ojca przestępcy. Jest decyzja sądu
 - [https://wydarzenia.interia.pl/kraj/news-pieciolatek-mial-wrocic-do-ojca-przestepcy-jest-decyzja-sadu,nId,6333424](https://wydarzenia.interia.pl/kraj/news-pieciolatek-mial-wrocic-do-ojca-przestepcy-jest-decyzja-sadu,nId,6333424)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 16:17:59+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pieciolatek-mial-wrocic-do-ojca-przestepcy-jest-decyzja-sadu,nId,6333424"><img align="left" alt="Pięciolatek miał wrócić do ojca przestępcy. Jest decyzja sądu" src="https://i.iplsc.com/pieciolatek-mial-wrocic-do-ojca-przestepcy-jest-decyzja-sadu/000F02LIO3DN4MS6-C321.jpg" /></a>Pięcioletni Antoni nie wróci do Holandii do ojca - przestępcy, skazanego w Polsce za handel narkotykami - przekazał Rzecznik Praw Dziecka Mikołaj Pawlak. Za ojcem chłopc

## Wicepremier Kosowa: Rosja szuka punktów zapalnych
 - [https://wydarzenia.interia.pl/zagranica/news-wicepremier-kosowa-rosja-szuka-punktow-zapalnych,nId,6333595](https://wydarzenia.interia.pl/zagranica/news-wicepremier-kosowa-rosja-szuka-punktow-zapalnych,nId,6333595)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 16:16:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wicepremier-kosowa-rosja-szuka-punktow-zapalnych,nId,6333595"><img align="left" alt="Wicepremier Kosowa: Rosja szuka punktów zapalnych" src="https://i.iplsc.com/wicepremier-kosowa-rosja-szuka-punktow-zapalnych/000G687E9BR0PLS9-C321.jpg" /></a>- Polska była jednym z pierwszych krajów, które uznały niepodległość Kosowa, a uznanie nastąpiło dziewięć dni po ogłoszeniu niepodległości. Relacje na szczeblu politycznym nie zawsze się rozwijały. By

## Jest decyzja Sejmu w sprawie ustawy zamrażającej ceny energii
 - [https://wydarzenia.interia.pl/kraj/news-jest-decyzja-sejmu-w-sprawie-ustawy-zamrazajacej-ceny-energi,nId,6333323](https://wydarzenia.interia.pl/kraj/news-jest-decyzja-sejmu-w-sprawie-ustawy-zamrazajacej-ceny-energi,nId,6333323)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 16:02:23+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jest-decyzja-sejmu-w-sprawie-ustawy-zamrazajacej-ceny-energi,nId,6333323"><img align="left" alt="Jest decyzja Sejmu w sprawie ustawy zamrażającej ceny energii" src="https://i.iplsc.com/jest-decyzja-sejmu-w-sprawie-ustawy-zamrazajacej-ceny-energi/000G675I4BAHMMDW-C321.jpg" /></a>Sejm zdecydował w sprawie zamrożenia cen prądu w 2023 roku. Przyjął część poprawek Senatu, jednak większość z nich miała charakter redakcyjny lub uzupełniający. Senat ch

## Tatry: Nie żyje turysta porwany przez lawinę
 - [https://wydarzenia.interia.pl/malopolskie/news-tatry-nie-zyje-turysta-porwany-przez-lawine,nId,6333435](https://wydarzenia.interia.pl/malopolskie/news-tatry-nie-zyje-turysta-porwany-przez-lawine,nId,6333435)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 15:54:50+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-tatry-nie-zyje-turysta-porwany-przez-lawine,nId,6333435"><img align="left" alt="Tatry: Nie żyje turysta porwany przez lawinę" src="https://i.iplsc.com/tatry-nie-zyje-turysta-porwany-przez-lawine/000G689ANVGNVIVW-C321.jpg" /></a>Niewielka lawina - tak zwany zsuw śnieżny - porwała turystę w rejonie Przełęczy Krzyżne w Tatrach Wysokich. Mężczyzna nie przeżył upadku z wysokości - poinformował ratownik dyżurny TOPR Tomasz Wojciechowski. Dwa d

## Człowiek z Kremla postawił się Putinowi. Rośnie napięcie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-czlowiek-z-kremla-postawil-sie-putinowi-rosnie-napiecie,nId,6333403](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-czlowiek-z-kremla-postawil-sie-putinowi-rosnie-napiecie,nId,6333403)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 15:51:49+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-czlowiek-z-kremla-postawil-sie-putinowi-rosnie-napiecie,nId,6333403"><img align="left" alt="Człowiek z Kremla postawił się Putinowi. Rośnie napięcie" src="https://i.iplsc.com/czlowiek-z-kremla-postawil-sie-putinowi-rosnie-napiecie/000G67XMSGXCVFH7-C321.jpg" /></a>Członek wewnętrznego kręgu współpracowników Putina wygłosił w rozmowie z prezydentem krytykę wojny w Ukrainie i popełnianych w niej błędów - podał &

## "Wyczyny" polskiego kierowcy we Włoszech. Zareagowała policja
 - [https://wydarzenia.interia.pl/zagranica/news-wyczyny-polskiego-kierowcy-we-wloszech-zareagowala-policja,nId,6333399](https://wydarzenia.interia.pl/zagranica/news-wyczyny-polskiego-kierowcy-we-wloszech-zareagowala-policja,nId,6333399)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 15:32:11+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wyczyny-polskiego-kierowcy-we-wloszech-zareagowala-policja,nId,6333399"><img align="left" alt="&quot;Wyczyny&quot; polskiego kierowcy we Włoszech. Zareagowała policja " src="https://i.iplsc.com/wyczyny-polskiego-kierowcy-we-wloszech-zareagowala-policja/000G67W7NVIVX2G5-C321.jpg" /></a>Polski kierowca ciężarówki ukarany mandatem za przekroczenie prędkości przez włoską policję w Cinisello. Jak podaje &quot;Milano Today&quot;, mężczyzna dwukr

## Wniosek o odrzucenie upadł. Ustawa budżetowa trafia do komisji
 - [https://wydarzenia.interia.pl/kraj/news-wniosek-o-odrzucenie-upadl-ustawa-budzetowa-trafia-do-komisj,nId,6333359](https://wydarzenia.interia.pl/kraj/news-wniosek-o-odrzucenie-upadl-ustawa-budzetowa-trafia-do-komisj,nId,6333359)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 15:30:57+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wniosek-o-odrzucenie-upadl-ustawa-budzetowa-trafia-do-komisj,nId,6333359"><img align="left" alt="Wniosek o odrzucenie upadł. Ustawa budżetowa trafia do komisji" src="https://i.iplsc.com/wniosek-o-odrzucenie-upadl-ustawa-budzetowa-trafia-do-komisj/000G67QJTHXAJY6X-C321.jpg" /></a>Sejm odrzucił wniosek opozycji o odrzucenie w pierwszym czytaniu projektu ustawy budżetowej na 2023 rok. Projekt trafi teraz do komisji.</p><br clear="all" />

## "Trwały pokój jest możliwy". Merkel podkreśla rolę Rosji
 - [https://wydarzenia.interia.pl/zagranica/news-trwaly-pokoj-jest-mozliwy-merkel-podkresla-role-rosji,nId,6333360](https://wydarzenia.interia.pl/zagranica/news-trwaly-pokoj-jest-mozliwy-merkel-podkresla-role-rosji,nId,6333360)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 15:19:17+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-trwaly-pokoj-jest-mozliwy-merkel-podkresla-role-rosji,nId,6333360"><img align="left" alt="&quot;Trwały pokój jest możliwy&quot;. Merkel podkreśla rolę Rosji" src="https://i.iplsc.com/trwaly-pokoj-jest-mozliwy-merkel-podkresla-role-rosji/000G67QRFO6Q7RCE-C321.jpg" /></a>Angela Merkel ponownie zabrała głos na temat wojny Rosji z Ukrainą. Na spotkaniu w Monachium była kanclerz Niemiec ostrzegła przed postrzeganiem gróźb ze strony Putina jedyn

## Rekordowa kwota na Fundusz Kościelny. Wzrośnie o ponad 20 milionów
 - [https://wydarzenia.interia.pl/kraj/news-rekordowa-kwota-na-fundusz-koscielny-wzrosnie-o-ponad-20-mil,nId,6333336](https://wydarzenia.interia.pl/kraj/news-rekordowa-kwota-na-fundusz-koscielny-wzrosnie-o-ponad-20-mil,nId,6333336)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 14:49:46+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rekordowa-kwota-na-fundusz-koscielny-wzrosnie-o-ponad-20-mil,nId,6333336"><img align="left" alt="Rekordowa kwota na Fundusz Kościelny. Wzrośnie o ponad 20 milionów" src="https://i.iplsc.com/rekordowa-kwota-na-fundusz-koscielny-wzrosnie-o-ponad-20-mil/0003J6KTOF490ACY-C321.jpg" /></a>216 milionów złotych - tyle rząd planuje przeznaczyć na Fundusz Kościelny w 2023 roku. Jak podkreślają media, to o 23 mln zł więcej niż w tym roku, jest to też reko

## Śledztwo w sprawie Nord Stream. Kuriozalne żądanie Rosjan
 - [https://wydarzenia.interia.pl/zagranica/news-sledztwo-w-sprawie-nord-stream-kuriozalne-zadanie-rosjan,nId,6333331](https://wydarzenia.interia.pl/zagranica/news-sledztwo-w-sprawie-nord-stream-kuriozalne-zadanie-rosjan,nId,6333331)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 14:16:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sledztwo-w-sprawie-nord-stream-kuriozalne-zadanie-rosjan,nId,6333331"><img align="left" alt="Śledztwo w sprawie Nord Stream. Kuriozalne żądanie Rosjan" src="https://i.iplsc.com/sledztwo-w-sprawie-nord-stream-kuriozalne-zadanie-rosjan/000G67KFHJ9MD24F-C321.jpg" /></a>Premier Rosji Michaił Miszustin zwrócił się bezpośrednio do premier Szwecji Magdaleny Andresson z żądaniami udziału Moskwy w śledztwie w sprawie wybuchów, które uszkodziły gazo

## Wielokrotny gwałt, bicie. Dziecko w szpitalu, para w areszcie
 - [https://wydarzenia.interia.pl/podkarpackie/news-wielokrotny-gwalt-bicie-dziecko-w-szpitalu-para-w-areszcie,nId,6333346](https://wydarzenia.interia.pl/podkarpackie/news-wielokrotny-gwalt-bicie-dziecko-w-szpitalu-para-w-areszcie,nId,6333346)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 14:03:48+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-wielokrotny-gwalt-bicie-dziecko-w-szpitalu-para-w-areszcie,nId,6333346"><img align="left" alt="Wielokrotny gwałt, bicie. Dziecko w szpitalu, para w areszcie" src="https://i.iplsc.com/wielokrotny-gwalt-bicie-dziecko-w-szpitalu-para-w-areszcie/000G67QK0RU0E25J-C321.jpg" /></a>Jest areszt dla ukraińskiej pary, która miała dopuścić się pobicie i wielokrotnego zgwałcenia 2,5-letniego dziecka w Stalowej Woli. Chłopiec jest synem 22-letniej Ok

## Stwierdzono zgon, zapakowano ciało. Lekarz dokonał niepokojącego odkrycia
 - [https://wydarzenia.interia.pl/zagranica/news-stwierdzono-zgon-zapakowano-cialo-lekarz-dokonal-niepokojace,nId,6333341](https://wydarzenia.interia.pl/zagranica/news-stwierdzono-zgon-zapakowano-cialo-lekarz-dokonal-niepokojace,nId,6333341)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 13:59:03+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-stwierdzono-zgon-zapakowano-cialo-lekarz-dokonal-niepokojace,nId,6333341"><img align="left" alt="Stwierdzono zgon, zapakowano ciało. Lekarz dokonał niepokojącego odkrycia" src="https://i.iplsc.com/stwierdzono-zgon-zapakowano-cialo-lekarz-dokonal-niepokojace/000G67LY1M2G21WI-C321.jpg" /></a>Dokładna data śmierci Kevina Reida, który zmarł w australijskim szpitalu w Rockingham nie jest znana. Najpierw zgon mężczyzny potwierdziła doświadczona 

## Straż Graniczna złapała Polaka poszukiwanego przez Interpol
 - [https://wydarzenia.interia.pl/podkarpackie/news-straz-graniczna-zlapala-polaka-poszukiwanego-przez-interpol,nId,6333302](https://wydarzenia.interia.pl/podkarpackie/news-straz-graniczna-zlapala-polaka-poszukiwanego-przez-interpol,nId,6333302)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 13:46:45+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-straz-graniczna-zlapala-polaka-poszukiwanego-przez-interpol,nId,6333302"><img align="left" alt="Straż Graniczna złapała Polaka poszukiwanego przez Interpol" src="https://i.iplsc.com/straz-graniczna-zlapala-polaka-poszukiwanego-przez-interpol/000G66SF9Y5UTNPO-C321.jpg" /></a>37-letni Polak, poszukiwany Europejskim Nakazem Aresztowania oraz czerwoną notą Interpolu, wpadł na lotnisku w podrzeszowskiej Jasionce. Mężczyzna jest oskarżony o n

## Więcej studentów kierunków lekarskich. Ale niektóre uczelnie mają problemy
 - [https://wydarzenia.interia.pl/kraj/news-wiecej-studentow-kierunkow-lekarskich-ale-niektore-uczelnie-,nId,6333237](https://wydarzenia.interia.pl/kraj/news-wiecej-studentow-kierunkow-lekarskich-ale-niektore-uczelnie-,nId,6333237)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 13:42:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wiecej-studentow-kierunkow-lekarskich-ale-niektore-uczelnie-,nId,6333237"><img align="left" alt="Więcej studentów kierunków lekarskich. Ale niektóre uczelnie mają problemy" src="https://i.iplsc.com/wiecej-studentow-kierunkow-lekarskich-ale-niektore-uczelnie/000G66FFYBL2IHUS-C321.jpg" /></a>Z roku na rok rośnie liczba studentów kierunku lekarskiego. Rośnie też liczba uczelni, gdzie można studiować medycynę. Uczelnie kształcące przyszłych lekarzy

## Śmiertelnie bronili włamywacza, usłyszeli zarzuty. Ziobro reaguje
 - [https://wydarzenia.interia.pl/kraj/news-smiertelnie-bronili-wlamywacza-uslyszeli-zarzuty-ziobro-reag,nId,6333311](https://wydarzenia.interia.pl/kraj/news-smiertelnie-bronili-wlamywacza-uslyszeli-zarzuty-ziobro-reag,nId,6333311)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 13:34:35+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-smiertelnie-bronili-wlamywacza-uslyszeli-zarzuty-ziobro-reag,nId,6333311"><img align="left" alt="Śmiertelnie bronili włamywacza, usłyszeli zarzuty. Ziobro reaguje" src="https://i.iplsc.com/smiertelnie-bronili-wlamywacza-uslyszeli-zarzuty-ziobro-reag/000DBT8LS8SB73SR-C321.jpg" /></a>Minister Zbigniew Ziobro odniósł się do kontrowersyjnej decyzji o postawieniu zarzutów rodzinie z Poznania, która została napadnięta. W czasie szarpaniny włamywacz z

## Śmiertelnie ranili włamywacza, usłyszeli zarzuty. Ziobro reaguje
 - [https://wydarzenia.interia.pl/kraj/news-smiertelnie-ranili-wlamywacza-uslyszeli-zarzuty-ziobro-reagu,nId,6333311](https://wydarzenia.interia.pl/kraj/news-smiertelnie-ranili-wlamywacza-uslyszeli-zarzuty-ziobro-reagu,nId,6333311)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 13:34:35+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-smiertelnie-ranili-wlamywacza-uslyszeli-zarzuty-ziobro-reagu,nId,6333311"><img align="left" alt="Śmiertelnie ranili włamywacza, usłyszeli zarzuty. Ziobro reaguje" src="https://i.iplsc.com/smiertelnie-ranili-wlamywacza-uslyszeli-zarzuty-ziobro-reagu/000DBT8LS8SB73SR-C321.jpg" /></a>Minister Zbigniew Ziobro odniósł się do kontrowersyjnej decyzji o postawieniu zarzutów rodzinie z Poznania, która została napadnięta. W czasie szarpaniny włamywacz zo

## Marin zapytana o "drogę wyjścia" z konfliktu. Wypowiedź podbija sieć
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-marin-zapytana-o-droge-wyjscia-z-konfliktu-wypowiedz-podbija,nId,6333272](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-marin-zapytana-o-droge-wyjscia-z-konfliktu-wypowiedz-podbija,nId,6333272)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 12:43:26+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-marin-zapytana-o-droge-wyjscia-z-konfliktu-wypowiedz-podbija,nId,6333272"><img align="left" alt="Marin zapytana o &quot;drogę wyjścia&quot; z konfliktu. Wypowiedź podbija sieć" src="https://i.iplsc.com/marin-zapytana-o-droge-wyjscia-z-konfliktu-wypowiedz-podbija/000G66Q5XS5C9AQR-C321.jpg" /></a>Fińska premier Sanna Marin została zapytana przez dziennikarzy o &quot;drogę wyjścia&quot; z konfliktu w Ukrainie. R

## Zupy z resztek zamiast restauracji. Tak Polacy oszczędzają na jedzeniu
 - [https://wydarzenia.interia.pl/kraj/news-zupy-z-resztek-zamiast-restauracji-tak-polacy-oszczedzaja-na,nId,6333174](https://wydarzenia.interia.pl/kraj/news-zupy-z-resztek-zamiast-restauracji-tak-polacy-oszczedzaja-na,nId,6333174)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 12:38:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zupy-z-resztek-zamiast-restauracji-tak-polacy-oszczedzaja-na,nId,6333174"><img align="left" alt="Zupy z resztek zamiast restauracji. Tak Polacy oszczędzają na jedzeniu" src="https://i.iplsc.com/zupy-z-resztek-zamiast-restauracji-tak-polacy-oszczedzaja-na/000G66BVMS47MISF-C321.jpg" /></a>- Restauracja to rarytas. Nie lubię marnować jedzenia, więc często gotuję wymyślone dania &quot;z resztek&quot;, oszczędnie i pożytecznie - mówi Aneta, mieszkan

## Doradca prezydenta Ukrainy krytykuje laureatów Pokojowej Nagrody Nobla
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-doradca-prezydenta-ukrainy-krytykuje-laureatow-pokojowej-nag,nId,6333194](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-doradca-prezydenta-ukrainy-krytykuje-laureatow-pokojowej-nag,nId,6333194)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 12:23:35+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-doradca-prezydenta-ukrainy-krytykuje-laureatow-pokojowej-nag,nId,6333194"><img align="left" alt="Doradca prezydenta Ukrainy krytykuje laureatów Pokojowej Nagrody Nobla" src="https://i.iplsc.com/doradca-prezydenta-ukrainy-krytykuje-laureatow-pokojowej-nag/000G66CE3LS5DG5C-C321.jpg" /></a>&quot;Komitet Noblowski ma interesujące rozumienie słowa 'pokój'&quot; - stwierdził doradca prezydenta Ukrainy Mychajło Podo

## Serial "Wielka Woda" przypomina o powodzi z 1997 roku. Co naprawdę się wtedy wydarzyło?
 - [https://wydarzenia.interia.pl/kraj/news-serial-wielka-woda-przypomina-o-powodzi-z-1997-roku-co-napra,nId,6332848](https://wydarzenia.interia.pl/kraj/news-serial-wielka-woda-przypomina-o-powodzi-z-1997-roku-co-napra,nId,6332848)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 11:50:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-serial-wielka-woda-przypomina-o-powodzi-z-1997-roku-co-napra,nId,6332848"><img align="left" alt="Serial &quot;Wielka Woda&quot; przypomina o powodzi z 1997 roku. Co naprawdę się wtedy wydarzyło?" src="https://i.iplsc.com/serial-wielka-woda-przypomina-o-powodzi-z-1997-roku-co-napra/000G65A9JX5TSI59-C321.jpg" /></a>W tym roku minęło 25 lat od powodzi tysiąclecia - żywiołu, który w 1997 r. dotknął Wrocław oraz wiele innych miejscowości w zachodnie

## Blogerka poleca suszyć trujące muchomory. Ostrzeżenie od lekarki
 - [https://wydarzenia.interia.pl/kraj/news-blogerka-poleca-suszyc-trujace-muchomory-ostrzezenie-od-leka,nId,6333207](https://wydarzenia.interia.pl/kraj/news-blogerka-poleca-suszyc-trujace-muchomory-ostrzezenie-od-leka,nId,6333207)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 11:42:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-blogerka-poleca-suszyc-trujace-muchomory-ostrzezenie-od-leka,nId,6333207"><img align="left" alt="Blogerka poleca suszyć trujące muchomory. Ostrzeżenie od lekarki" src="https://i.iplsc.com/blogerka-poleca-suszyc-trujace-muchomory-ostrzezenie-od-leka/000G667N4U0F7NOG-C321.jpg" /></a>&quot;Większość z moich znajomych je te grzyby regularnie&quot; - chwali się w mediach społecznościowych jedna z internetowych influencerek. W taki sposób zachęca do 

## Aleś Bialacki. "Autorytet obrońców praw człowieka na całym świecie"
 - [https://wydarzenia.interia.pl/zagranica/news-ales-bialacki-autorytet-obroncow-praw-czlowieka-na-calym-swi,nId,6333184](https://wydarzenia.interia.pl/zagranica/news-ales-bialacki-autorytet-obroncow-praw-czlowieka-na-calym-swi,nId,6333184)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 11:15:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ales-bialacki-autorytet-obroncow-praw-czlowieka-na-calym-swi,nId,6333184"><img align="left" alt="Aleś Bialacki. &quot;Autorytet obrońców praw człowieka na całym świecie&quot;" src="https://i.iplsc.com/ales-bialacki-autorytet-obroncow-praw-czlowieka-na-calym-swi/000G664GSLOM3JFK-C321.jpg" /></a>Założyciel i przewodniczący najważniejszej białoruskiej organizacji praw człowieka &quot;Wiasna&quot;, Aleś Bialacki, został laureatem Pokojowej Nag

## Giorgia Meloni o słowach francuskiej minister. "To groźba ingerencji"
 - [https://wydarzenia.interia.pl/zagranica/news-giorgia-meloni-o-slowach-francuskiej-minister-to-grozba-inge,nId,6333183](https://wydarzenia.interia.pl/zagranica/news-giorgia-meloni-o-slowach-francuskiej-minister-to-grozba-inge,nId,6333183)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 11:15:36+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-giorgia-meloni-o-slowach-francuskiej-minister-to-grozba-inge,nId,6333183"><img align="left" alt="Giorgia Meloni o słowach francuskiej minister. &quot;To groźba ingerencji&quot;" src="https://i.iplsc.com/giorgia-meloni-o-slowach-francuskiej-minister-to-grozba-inge/000G664KFEQIDCJR-C321.jpg" /></a>- Niedopuszczalna groźba ingerencji - w ten sposób kandydatka na premiera Włoch Giorgia Meloni skomentowała wypowiedź francuskiej sekretarz stanu 

## Próba kradzieży 1,5 tony miału z terenu kopalni. Zatrzymano dwóch braci
 - [https://wydarzenia.interia.pl/slaskie/news-proba-kradziezy-1-5-tony-mialu-z-terenu-kopalni-zatrzymano-d,nId,6333141](https://wydarzenia.interia.pl/slaskie/news-proba-kradziezy-1-5-tony-mialu-z-terenu-kopalni-zatrzymano-d,nId,6333141)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 11:10:31+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-proba-kradziezy-1-5-tony-mialu-z-terenu-kopalni-zatrzymano-d,nId,6333141"><img align="left" alt="Próba kradzieży 1,5 tony miału z terenu kopalni. Zatrzymano dwóch braci" src="https://i.iplsc.com/proba-kradziezy-1-5-tony-mialu-z-terenu-kopalni-zatrzymano-d/000G65XE2A9HKIVS-C321.jpg" /></a>Policjanci z Rudy Śląskiej zatrzymali dwóch sprawców usiłowania kradzieży ponad 1,5 tony miału węglowego z terenu kopalni Bielszowice. Osoby wynoszące worki

## Uchodźca zawisł na granicznym płocie. Zdjęcie wywołało burzę
 - [https://wydarzenia.interia.pl/podlaskie/news-uchodzca-zawisl-na-granicznym-plocie-zdjecie-wywolalo-burze,nId,6333150](https://wydarzenia.interia.pl/podlaskie/news-uchodzca-zawisl-na-granicznym-plocie-zdjecie-wywolalo-burze,nId,6333150)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 10:45:07+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-uchodzca-zawisl-na-granicznym-plocie-zdjecie-wywolalo-burze,nId,6333150"><img align="left" alt="Uchodźca zawisł na granicznym płocie. Zdjęcie wywołało burzę" src="https://i.iplsc.com/uchodzca-zawisl-na-granicznym-plocie-zdjecie-wywolalo-burze/000G65XNI7HTQ8X2-C321.jpg" /></a>Uchodźca zwisający z muru głową w dół, zaplątany w ostry drut - zdjęcie z granicy polsko-białoruskiej wywołało burzę w sieci. Komentarzem jednego z białostockich porta

## Samorządowcy z całej Polski w stolicy. Protestują przeciwko podwyżkom cen energii
 - [https://wydarzenia.interia.pl/kraj/news-samorzadowcy-z-calej-polski-w-stolicy-protestuja-przeciwko-p,nId,6332745](https://wydarzenia.interia.pl/kraj/news-samorzadowcy-z-calej-polski-w-stolicy-protestuja-przeciwko-p,nId,6332745)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 10:25:27+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-samorzadowcy-z-calej-polski-w-stolicy-protestuja-przeciwko-p,nId,6332745"><img align="left" alt="Samorządowcy z całej Polski w stolicy. Protestują przeciwko podwyżkom cen energii " src="https://i.iplsc.com/samorzadowcy-z-calej-polski-w-stolicy-protestuja-przeciwko-p/000G65UVPJLD292J-C321.jpg" /></a>Samorządowcy z różnych regionów Polski wyruszyli do Warszawy, gdzie biorą udział w proteście przeciwko podwyżkom cen energii pod hasłem &quot;Tylko 

## Trzaskowski na strajku samorządowców: Dosyć tego! Ceny energii muszą być gwarantowane
 - [https://wydarzenia.interia.pl/kraj/news-trzaskowski-na-strajku-samorzadowcow-dosyc-tego-ceny-energii,nId,6332745](https://wydarzenia.interia.pl/kraj/news-trzaskowski-na-strajku-samorzadowcow-dosyc-tego-ceny-energii,nId,6332745)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 10:25:27+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-trzaskowski-na-strajku-samorzadowcow-dosyc-tego-ceny-energii,nId,6332745"><img align="left" alt="Trzaskowski na strajku samorządowców: Dosyć tego! Ceny energii muszą być gwarantowane" src="https://i.iplsc.com/trzaskowski-na-strajku-samorzadowcow-dosyc-tego-ceny-energii/000G663TO4LMCVD8-C321.jpg" /></a>Samorządowcy z różnych regionów Polski zjechali do Warszawy, gdzie biorą udział w proteście przeciwko podwyżkom cen energii pod hasłem &quot;Tylk

## Chile: Pożar na Wyspie Wielkanocnej. Uszkodzone słynne posągi
 - [https://wydarzenia.interia.pl/zagranica/news-chile-pozar-na-wyspie-wielkanocnej-uszkodzone-slynne-posagi,nId,6332894](https://wydarzenia.interia.pl/zagranica/news-chile-pozar-na-wyspie-wielkanocnej-uszkodzone-slynne-posagi,nId,6332894)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 10:13:49+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chile-pozar-na-wyspie-wielkanocnej-uszkodzone-slynne-posagi,nId,6332894"><img align="left" alt="Chile: Pożar na Wyspie Wielkanocnej. Uszkodzone słynne posągi" src="https://i.iplsc.com/chile-pozar-na-wyspie-wielkanocnej-uszkodzone-slynne-posagi/000G65RSDEWD7TKC-C321.jpg" /></a>Na Wyspie Wielkanocnej należącej do Chile wybuchł pożar. Żywioł spowodował liczne zniszczenia. Uszkodził m.in. tajemnicze, wyrzeźbione w kamieniu słynne posągi. Jak p

## Ukraiński minister do Rosjan: Jeszcze możecie uratować armię przed hańbą
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainski-minister-do-rosjan-jeszcze-mozecie-uratowac-armie-,nId,6332870](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainski-minister-do-rosjan-jeszcze-mozecie-uratowac-armie-,nId,6332870)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 09:58:04+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainski-minister-do-rosjan-jeszcze-mozecie-uratowac-armie-,nId,6332870"><img align="left" alt="Ukraiński minister do Rosjan: Jeszcze możecie uratować armię przed hańbą" src="https://i.iplsc.com/ukrainski-minister-do-rosjan-jeszcze-mozecie-uratowac-armie/000E17DTWHRCF4CC-C321.jpg" /></a>- Jeszcze możecie uratować Rosję przed tragedią, a armię - przed poniżeniem i hańbą - powiedział ukraiński minister obrony 

## Wąsik: Atak na Nord Stream może być przygrywką do ataku na Baltic Pipe
 - [https://wydarzenia.interia.pl/kraj/news-wasik-atak-na-nord-stream-moze-byc-przygrywka-do-ataku-na-ba,nId,6332853](https://wydarzenia.interia.pl/kraj/news-wasik-atak-na-nord-stream-moze-byc-przygrywka-do-ataku-na-ba,nId,6332853)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 09:37:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wasik-atak-na-nord-stream-moze-byc-przygrywka-do-ataku-na-ba,nId,6332853"><img align="left" alt="Wąsik: Atak na Nord Stream może być przygrywką do ataku na Baltic Pipe" src="https://i.iplsc.com/wasik-atak-na-nord-stream-moze-byc-przygrywka-do-ataku-na-ba/000G4IQEMJWWTEHB-C321.jpg" /></a>- Widzimy, że atak na Nord Stream 1 czy Nord Stream 2, to może być przygrywka do ataku na Baltic Pipe - powiedział w piątek wiceminister spraw wewnętrznych i ad

## Rosjanie urządzili centrum dowodzenia w chlewni. "Spali tam i jedli"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-urzadzili-centrum-dowodzenia-w-chlewni-spali-tam-i-,nId,6332852](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-urzadzili-centrum-dowodzenia-w-chlewni-spali-tam-i-,nId,6332852)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 09:27:27+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-urzadzili-centrum-dowodzenia-w-chlewni-spali-tam-i-,nId,6332852"><img align="left" alt="Rosjanie urządzili centrum dowodzenia w chlewni. &quot;Spali tam i jedli&quot;" src="https://i.iplsc.com/rosjanie-urzadzili-centrum-dowodzenia-w-chlewni-spali-tam-i/000G65SZE7R8X070-C321.jpg" /></a>Rosjanie urządzili centrum dowodzenia w chlewni - wynika z doniesień Służby Bezpieczeństwa Ukrainy opublikowanych w m

## Trzech laureatów tegorocznej Pokojowej Nagrody Nobla
 - [https://wydarzenia.interia.pl/zagranica/news-trzech-laureatow-tegorocznej-pokojowej-nagrody-nobla,nId,6332779](https://wydarzenia.interia.pl/zagranica/news-trzech-laureatow-tegorocznej-pokojowej-nagrody-nobla,nId,6332779)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 09:00:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-trzech-laureatow-tegorocznej-pokojowej-nagrody-nobla,nId,6332779"><img align="left" alt="Trzech laureatów tegorocznej Pokojowej Nagrody Nobla" src="https://i.iplsc.com/trzech-laureatow-tegorocznej-pokojowej-nagrody-nobla/000G65BT7P114FSO-C321.jpg" /></a>Pokojowa Nagroda Nobla 2022 została przyznana. Tegorocznymi laureatami zostali Aleś Bialacki oraz organizacje Memoriał i Centrum Wolności Obywatelskich.</p><br clear="all" />

## Nowe zakażenia koronawirusem. Ministerstwo podało aktualne dane
 - [https://wydarzenia.interia.pl/kraj/news-nowe-zakazenia-koronawirusem-ministerstwo-podalo-aktualne-da,nId,6332723](https://wydarzenia.interia.pl/kraj/news-nowe-zakazenia-koronawirusem-ministerstwo-podalo-aktualne-da,nId,6332723)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 08:30:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowe-zakazenia-koronawirusem-ministerstwo-podalo-aktualne-da,nId,6332723"><img align="left" alt="Nowe zakażenia koronawirusem. Ministerstwo podało aktualne dane" src="https://i.iplsc.com/nowe-zakazenia-koronawirusem-ministerstwo-podalo-aktualne-da/000EMH3UIFMVHVX5-C321.jpg" /></a>Ministerstwo Zdrowia poinformowało w piątek, 7 października, o wykryciu 2629 nowych zakażeń koronawirusem w ciągu ostatniej doby. Zmarło 41 osób.  </p><br clear="all" 

## Szalet publiczny za 400 tys. złotych. Stanął w centrum Białegostoku
 - [https://wydarzenia.interia.pl/podlaskie/news-szalet-publiczny-za-400-tys-zlotych-stanal-w-centrum-bialego,nId,6332791](https://wydarzenia.interia.pl/podlaskie/news-szalet-publiczny-za-400-tys-zlotych-stanal-w-centrum-bialego,nId,6332791)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 08:19:44+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-szalet-publiczny-za-400-tys-zlotych-stanal-w-centrum-bialego,nId,6332791"><img align="left" alt="Szalet publiczny za 400 tys. złotych. Stanął w centrum Białegostoku" src="https://i.iplsc.com/szalet-publiczny-za-400-tys-zlotych-stanal-w-centrum-bialego/000G658F5MNGA2G6-C321.jpg" /></a>W centrum Białegostoku przy ul. Legionowej stanął nowy szalet miejski. Ten fakt nikogo by nie zdziwił, gdyby nie upublicznione koszty wybudowania obiektu w po

## Tusk: PO chce zamrożenia cen energii. "To jest być albo nie być"
 - [https://wydarzenia.interia.pl/kraj/news-tusk-po-chce-zamrozenia-cen-energii-to-jest-byc-albo-nie-byc,nId,6332776](https://wydarzenia.interia.pl/kraj/news-tusk-po-chce-zamrozenia-cen-energii-to-jest-byc-albo-nie-byc,nId,6332776)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 07:51:09+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-po-chce-zamrozenia-cen-energii-to-jest-byc-albo-nie-byc,nId,6332776"><img align="left" alt="Tusk: PO chce zamrożenia cen energii. &quot;To jest być albo nie być&quot;" src="https://i.iplsc.com/tusk-po-chce-zamrozenia-cen-energii-to-jest-byc-albo-nie-byc/000G653BNYS48TGT-C321.jpg" /></a>- Platforma Obywatelska złoży dziś projekt ustawy o zamrożeniu cen energii w Polsce - powiedział Donald Tusk podczas specjalnej konferencji Europejskiej Par

## Viktor Orban o sankcjach: Europa się wykrwawia, a Rosja dobrze zarabia
 - [https://wydarzenia.interia.pl/zagranica/news-viktor-orban-o-sankcjach-europa-sie-wykrwawia-a-rosja-dobrze,nId,6332771](https://wydarzenia.interia.pl/zagranica/news-viktor-orban-o-sankcjach-europa-sie-wykrwawia-a-rosja-dobrze,nId,6332771)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 07:39:42+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-viktor-orban-o-sankcjach-europa-sie-wykrwawia-a-rosja-dobrze,nId,6332771"><img align="left" alt="Viktor Orban o sankcjach: Europa się wykrwawia, a Rosja dobrze zarabia" src="https://i.iplsc.com/viktor-orban-o-sankcjach-europa-sie-wykrwawia-a-rosja-dobrze/000G650X72SQDKUI-C321.jpg" /></a>Viktor Orban zamieścił w mediach społecznościowych wpis, w którym skrytykował politykę sankcji, jaką Unia Europejska prowadzi wobec Rosji. &quot;Europa się

## Złożyli wniosek, pieniędzy nie zobaczą. Dodatek węglowy i elektryczny nie dla wszystkich
 - [https://wydarzenia.interia.pl/kraj/news-zlozyli-wniosek-pieniedzy-nie-zobacza-dodatek-weglowy-i-elek,nId,6330687](https://wydarzenia.interia.pl/kraj/news-zlozyli-wniosek-pieniedzy-nie-zobacza-dodatek-weglowy-i-elek,nId,6330687)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 07:38:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zlozyli-wniosek-pieniedzy-nie-zobacza-dodatek-weglowy-i-elek,nId,6330687"><img align="left" alt="Złożyli wniosek, pieniędzy nie zobaczą. Dodatek węglowy i elektryczny nie dla wszystkich" src="https://i.iplsc.com/zlozyli-wniosek-pieniedzy-nie-zobacza-dodatek-weglowy-i-elek/000G60S0WR7NNCQO-C321.jpg" /></a>Dodatek elektryczny oraz węglowy mają wspomóc domowe budżety. Portfele Polaków drenują wysokie koszty ogrzewania, stąd nawet kilka tysięcy zło

## Sondaż: Wzrost poparcia dla PiS i KO. Polska 2050 z dużym spadkiem
 - [https://wydarzenia.interia.pl/kraj/news-sondaz-wzrost-poparcia-dla-pis-i-ko-polska-2050-z-duzym-spad,nId,6332766](https://wydarzenia.interia.pl/kraj/news-sondaz-wzrost-poparcia-dla-pis-i-ko-polska-2050-z-duzym-spad,nId,6332766)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 07:32:56+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sondaz-wzrost-poparcia-dla-pis-i-ko-polska-2050-z-duzym-spad,nId,6332766"><img align="left" alt="Sondaż: Wzrost poparcia dla PiS i KO. Polska 2050 z dużym spadkiem" src="https://i.iplsc.com/sondaz-wzrost-poparcia-dla-pis-i-ko-polska-2050-z-duzym-spad/000G0LYA1OF5DEXI-C321.jpg" /></a>Zmniejsza się różnica poparcia między PiS a KO - wynika z najnowszego sondażu IBRiS dla Radia ZET. Gdyby wybory odbyły się w najbliższą niedzielę, partia Kaczyńskie

## Brzozów. Brutalna bójka nastolatek. Uczniowie nagrywali i dopingowali
 - [https://wydarzenia.interia.pl/podkarpackie/news-brzozow-brutalna-bojka-nastolatek-uczniowie-nagrywali-i-dopi,nId,6332763](https://wydarzenia.interia.pl/podkarpackie/news-brzozow-brutalna-bojka-nastolatek-uczniowie-nagrywali-i-dopi,nId,6332763)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 07:31:13+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-brzozow-brutalna-bojka-nastolatek-uczniowie-nagrywali-i-dopi,nId,6332763"><img align="left" alt="Brzozów. Brutalna bójka nastolatek. Uczniowie nagrywali i dopingowali" src="https://i.iplsc.com/brzozow-brutalna-bojka-nastolatek-uczniowie-nagrywali-i-dopi/000G64YZL1DTX9JW-C321.jpg" /></a>Dwie nastolatki biją się w &quot;kole&quot;, starsza z nich jest uzbrojona w kastet. Nikt z zebranego tłum uczniów nie rozdziela dziewczyn - zamiast tego

## Protest samorządowców. Premier "wychodzi z inicjatywą"
 - [https://wydarzenia.interia.pl/kraj/news-protest-samorzadowcow-premier-wychodzi-z-inicjatywa,nId,6332740](https://wydarzenia.interia.pl/kraj/news-protest-samorzadowcow-premier-wychodzi-z-inicjatywa,nId,6332740)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 07:01:31+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-protest-samorzadowcow-premier-wychodzi-z-inicjatywa,nId,6332740"><img align="left" alt="Protest samorządowców. Premier &quot;wychodzi z inicjatywą&quot;" src="https://i.iplsc.com/protest-samorzadowcow-premier-wychodzi-z-inicjatywa/000G64UTRP7X3LPT-C321.jpg" /></a>&quot;Schowajmy legitymacje partyjne do szuflady, zamknijmy je i bez względu na to co nas różni szukajmy tego co nas łączy. Wierzę, że jest to przede wszystkim troska o dobro Polaków&q

## Rosyjska propaganda: Ukraińcy chcą zepsuć urodziny Władimira Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjska-propaganda-ukraincy-chca-zepsuc-urodziny-wladimira-,nId,6332736](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjska-propaganda-ukraincy-chca-zepsuc-urodziny-wladimira-,nId,6332736)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 06:55:18+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjska-propaganda-ukraincy-chca-zepsuc-urodziny-wladimira-,nId,6332736"><img align="left" alt="Rosyjska propaganda: Ukraińcy chcą zepsuć urodziny Władimira Putina" src="https://i.iplsc.com/rosyjska-propaganda-ukraincy-chca-zepsuc-urodziny-wladimira/000G64UGO4KHP3EQ-C321.jpg" /></a>Ukraińcy chcą zniszczyć urodziny Władimira Putina - stwierdził Władimir Sołowjow. W rozmowie z byłym generałem czołowy propagand

## Policjanci stawiają sprawę na ostrzu noża: Jesienią zapanuje "psia grypa"
 - [https://wydarzenia.interia.pl/kraj/news-policjanci-stawiaja-sprawe-na-ostrzu-noza-jesienia-zapanuje-,nId,6331018](https://wydarzenia.interia.pl/kraj/news-policjanci-stawiaja-sprawe-na-ostrzu-noza-jesienia-zapanuje-,nId,6331018)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 06:49:40+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-policjanci-stawiaja-sprawe-na-ostrzu-noza-jesienia-zapanuje-,nId,6331018"><img align="left" alt="Policjanci stawiają sprawę na ostrzu noża: Jesienią zapanuje &quot;psia grypa&quot;" src="https://i.iplsc.com/policjanci-stawiaja-sprawe-na-ostrzu-noza-jesienia-zapanuje/000G62Q90879OQLR-C321.jpg" /></a>&quot;Stare&quot; związki zawodowe policji wciąż zastanawiają się czy ogłosić protest. Młode już to zrobiły. - Nie będziemy się co roku &quot;łasić&

## Broń jądrowa w Polsce? USA odpowiadają prezydentowi Dudzie
 - [https://wydarzenia.interia.pl/zagranica/news-bron-jadrowa-w-polsce-usa-odpowiadaja-prezydentowi-dudzie,nId,6332703](https://wydarzenia.interia.pl/zagranica/news-bron-jadrowa-w-polsce-usa-odpowiadaja-prezydentowi-dudzie,nId,6332703)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 06:33:07+00:00

<p>- Stany Zjednoczone nie prowadzą negocjacji z Polską w sprawie możliwego rozmieszczenia broni atomowej w ramach programu Nuclear Sharing - powiedział podczas czwartkowego briefingu prasowego rzecznik amerykańskiego Departamentu Stanu Vedant Patel. Wcześniej prezydent Andrzej Duda sugerował w wywiadzie, że &quot;temat jest otwarty&quot;, a wstępne rozmowy ze stroną amerykańską już się odbyły. </p><br clear="all" />

## "Kpina i katastrofa". Pracownicy uczelni pokazują nam paski z wypłat
 - [https://wydarzenia.interia.pl/kraj/news-kpina-i-katastrofa-pracownicy-uczelni-pokazuja-nam-paski-z-w,nId,6330720](https://wydarzenia.interia.pl/kraj/news-kpina-i-katastrofa-pracownicy-uczelni-pokazuja-nam-paski-z-w,nId,6330720)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 06:11:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kpina-i-katastrofa-pracownicy-uczelni-pokazuja-nam-paski-z-w,nId,6330720"><img align="left" alt="&quot;Kpina i katastrofa&quot;. Pracownicy uczelni pokazują nam paski z wypłat" src="https://i.iplsc.com/kpina-i-katastrofa-pracownicy-uczelni-pokazuja-nam-paski-z-w/000G60MSPU8LCXOL-C321.jpg" /></a>- Kpina, katastrofa i brak szacunku - tak o zarobkach w sektorze nauki mówią nam pracownicy uczelni. Młody wykładowca zarabia dziś niewiele więcej niż m

## Nowy projekt rządu. Dzieci nie zobaczą pornografii w internecie
 - [https://wydarzenia.interia.pl/kraj/news-nowy-projekt-rzadu-dzieci-nie-zobacza-pornografii-w-internec,nId,6332685](https://wydarzenia.interia.pl/kraj/news-nowy-projekt-rzadu-dzieci-nie-zobacza-pornografii-w-internec,nId,6332685)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 05:35:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowy-projekt-rzadu-dzieci-nie-zobacza-pornografii-w-internec,nId,6332685"><img align="left" alt="Nowy projekt rządu. Dzieci nie zobaczą pornografii w internecie" src="https://i.iplsc.com/nowy-projekt-rzadu-dzieci-nie-zobacza-pornografii-w-internec/000G64JREXITLJWW-C321.jpg" /></a>Małoletni mają być chronieni przed szkodliwymi treściami, w tym pornografią w internecie. Jak informuje &quot;Rzeczpospolita&quot;, rząd przygotował projekt, w świetle

## Syria: Cios w Państwo Islamskie. Akcje amerykańskich służb
 - [https://wydarzenia.interia.pl/zagranica/news-syria-cios-w-panstwo-islamskie-akcje-amerykanskich-sluzb,nId,6332688](https://wydarzenia.interia.pl/zagranica/news-syria-cios-w-panstwo-islamskie-akcje-amerykanskich-sluzb,nId,6332688)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 05:24:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-syria-cios-w-panstwo-islamskie-akcje-amerykanskich-sluzb,nId,6332688"><img align="left" alt="Syria: Cios w Państwo Islamskie. Akcje amerykańskich służb" src="https://i.iplsc.com/syria-cios-w-panstwo-islamskie-akcje-amerykanskich-sluzb/000G64IIB4O3CHHW-C321.jpg" /></a>W czwartek amerykańskie wojsko przeprowadziło nalot w północnej Syrii, w wyniku którego zginęli Abu Ala oraz Abu Mu'ada al-Kahtani - czołowi przywódcy Państwa Islamskiego. Akc

## Był sklep, teraz nie ma żadnego. Mieszkańcy codziennych zakupów nie zrobią
 - [https://wydarzenia.interia.pl/kraj/news-byl-sklep-teraz-nie-ma-zadnego-mieszkancy-codziennych-zakupo,nId,6330914](https://wydarzenia.interia.pl/kraj/news-byl-sklep-teraz-nie-ma-zadnego-mieszkancy-codziennych-zakupo,nId,6330914)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 05:20:11+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-byl-sklep-teraz-nie-ma-zadnego-mieszkancy-codziennych-zakupo,nId,6330914"><img align="left" alt="Był sklep, teraz nie ma żadnego. Mieszkańcy codziennych zakupów nie zrobią" src="https://i.iplsc.com/byl-sklep-teraz-nie-ma-zadnego-mieszkancy-codziennych-zakupo/000G6139A3N17URA-C321.jpg" /></a>Mieszkańcy wsi Nalewajków w woj. świętokrzyskim nie zrobią już zakupów w lokalnym sklepie spożywczym. Jedyny działający został niedawno zamknięty. Koszty ut

## Atak nożownika w Las Vegas. Mężczyzna zabił dwie osoby
 - [https://wydarzenia.interia.pl/zagranica/news-atak-nozownika-w-las-vegas-mezczyzna-zabil-dwie-osoby,nId,6332678](https://wydarzenia.interia.pl/zagranica/news-atak-nozownika-w-las-vegas-mezczyzna-zabil-dwie-osoby,nId,6332678)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 04:49:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-atak-nozownika-w-las-vegas-mezczyzna-zabil-dwie-osoby,nId,6332678"><img align="left" alt="Atak nożownika w Las Vegas. Mężczyzna zabił dwie osoby" src="https://i.iplsc.com/atak-nozownika-w-las-vegas-mezczyzna-zabil-dwie-osoby/000G64HOAVIW4RKK-C321.jpg" /></a>Dwie osoby nie żyją, a sześć zostało rannych po ataku nożownika w Las Vegas. Mężczyzna dźgał ludzi w kilku miejscach, w tym także w kasynach, gdzie zapanował chaos. Policja aresztowała 

## USA: Syn Joe Bidena może usłyszeć zarzuty. Media: Śledczy mają dużo dowodów
 - [https://wydarzenia.interia.pl/zagranica/news-usa-syn-joe-bidena-moze-uslyszec-zarzuty-media-sledczy-maja-,nId,6332676](https://wydarzenia.interia.pl/zagranica/news-usa-syn-joe-bidena-moze-uslyszec-zarzuty-media-sledczy-maja-,nId,6332676)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 04:40:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-syn-joe-bidena-moze-uslyszec-zarzuty-media-sledczy-maja-,nId,6332676"><img align="left" alt="USA: Syn Joe Bidena może usłyszeć zarzuty. Media: Śledczy mają dużo dowodów" src="https://i.iplsc.com/usa-syn-joe-bidena-moze-uslyszec-zarzuty-media-sledczy-maja/000G64GNX199JY9E-C321.jpg" /></a>&quot;Washington Post&quot; opublikował w czwartek nowe informacje w sprawie śledztwa dotyczącego syna prezydenta USA. Dziennik podaje, że federalni śl

## Erdogan stawia warunki w sprawie Szwecji. "Nasze podejście nie będzie pozytywne"
 - [https://wydarzenia.interia.pl/zagranica/news-erdogan-stawia-warunki-w-sprawie-szwecji-nasze-podejscie-nie,nId,6332675](https://wydarzenia.interia.pl/zagranica/news-erdogan-stawia-warunki-w-sprawie-szwecji-nasze-podejscie-nie,nId,6332675)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 04:34:49+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-erdogan-stawia-warunki-w-sprawie-szwecji-nasze-podejscie-nie,nId,6332675"><img align="left" alt="Erdogan stawia warunki w sprawie Szwecji. &quot;Nasze podejście nie będzie pozytywne&quot;" src="https://i.iplsc.com/erdogan-stawia-warunki-w-sprawie-szwecji-nasze-podejscie-nie/000G64GK3LQXJTJ9-C321.jpg" /></a>Prezydent Turcji Recep Tayyip Erdogan powiedział w czwartek, że Ankara będzie nadal sprzeciwiać się staraniom Szwecji o członkostwo w N

## Biden ostrzega. "Grozi nam nuklearna apokalipsa"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-joe-biden-ostrzega-mamy-najwyzsze-ryzyko-nuklearnej-apokalip,nId,6332673](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-joe-biden-ostrzega-mamy-najwyzsze-ryzyko-nuklearnej-apokalip,nId,6332673)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 04:29:08+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-joe-biden-ostrzega-mamy-najwyzsze-ryzyko-nuklearnej-apokalip,nId,6332673"><img align="left" alt="Biden ostrzega. &quot;Grozi nam nuklearna apokalipsa&quot;" src="https://i.iplsc.com/biden-ostrzega-grozi-nam-nuklearna-apokalipsa/000EIOUA8J3SSJB1-C321.jpg" /></a>Ryzyko nuklearnego Armagedonu jest najwyższe od czasu kryzysu kubańskiego - stwierdził prezydent USA Joe Biden. W jego opinii &quot;Putin to człowiek, 

## Pentagon: Nie ma informacji, że Putin zdecyduje się użyć broni jądrowej
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pentagon-nie-ma-informacji-ze-putin-zdecyduje-sie-uzyc-broni,nId,6332672](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pentagon-nie-ma-informacji-ze-putin-zdecyduje-sie-uzyc-broni,nId,6332672)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 04:22:23+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pentagon-nie-ma-informacji-ze-putin-zdecyduje-sie-uzyc-broni,nId,6332672"><img align="left" alt="Pentagon: Nie ma informacji, że Putin zdecyduje się użyć broni jądrowej" src="https://i.iplsc.com/pentagon-nie-ma-informacji-ze-putin-zdecyduje-sie-uzyc-broni/000G64GBUB29656F-C321.jpg" /></a>Rzecznik Pentagonu Patrick Ryder odniósł się do spekulacji na temat potencjalnego użycia broni jądrowej przez rosyjskie wła

## USA oskarżyły Rosję o eksploatowanie zasobów naturalnych w Afryce
 - [https://wydarzenia.interia.pl/zagranica/news-usa-oskarzyly-rosje-o-eksploatowanie-zasobow-naturalnych-w-a,nId,6332671](https://wydarzenia.interia.pl/zagranica/news-usa-oskarzyly-rosje-o-eksploatowanie-zasobow-naturalnych-w-a,nId,6332671)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 04:13:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-oskarzyly-rosje-o-eksploatowanie-zasobow-naturalnych-w-a,nId,6332671"><img align="left" alt="USA oskarżyły Rosję o eksploatowanie zasobów naturalnych w Afryce" src="https://i.iplsc.com/usa-oskarzyly-rosje-o-eksploatowanie-zasobow-naturalnych-w-a/000G64G7J8IVY87A-C321.jpg" /></a>USA podczas Rady Bezpieczeństwa ONZ oskarżyły rosyjskich najemników o eksploatację zasobów naturalnych w Afryce. Dzięki temu reżim ma mieć środki na finansowani

## Wojna w Ukrainie. 226. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-226-dzien-inwazji-rosji-relacja-na-zywo,nzId,3145,akt,070724](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-226-dzien-inwazji-rosji-relacja-na-zywo,nzId,3145,akt,070724)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-07 03:32:18+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-226-dzien-inwazji-rosji-relacja-na-zywo,nzId,3145,akt,070724"><img align="left" alt="Wojna w Ukrainie. 226. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-226-dzien-inwazji-rosji-relacja-na-zywo/000G64F4JSDHDEU3-C321.jpg" /></a>Zapraszamy do śledzenia naszej relacji na żywo.</p><br clear="all" />


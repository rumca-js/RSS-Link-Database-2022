# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## 9 big questions about the ‘Super Mario Bros. Movie’ trailer
 - [https://www.washingtonpost.com/video-games/2022/10/07/mario-movie-trailer-analysis/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2022/10/07/mario-movie-trailer-analysis/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-07 16:30:16+00:00

Here's a question: How many Toads is Keegan-Michael Key playing?

## ‘Overwatch’ died for ‘Overwatch 2.’ It was totally worth it.
 - [https://www.washingtonpost.com/video-games/reviews/overwatch-2-free-review/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/reviews/overwatch-2-free-review/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-07 15:53:13+00:00

“Overwatch 2” rewards sound fundamentals such as aim and game sense over grossly overtuned abilities. That's a good thing.

## Video games harm the environment. A climate researcher wants to fix that.
 - [https://www.washingtonpost.com/video-games/2022/10/07/afterclimate-video-games-climate-change-ubisoft-microsoft/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2022/10/07/afterclimate-video-games-climate-change-ubisoft-microsoft/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-07 14:38:15+00:00

What will it take to make video games go green? "Is it by making hardware last longer? Is it by changing something about the way the game works?"

## Meta warns 1 million Facebook users their login info may have been compromised
 - [https://www.washingtonpost.com/technology/2022/10/07/facebook-malicious-apps-logins/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/10/07/facebook-malicious-apps-logins/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-07 14:01:45+00:00

Facebook parent Meta is warning 1 million users that their login information may have been compromised through malicious apps.

## They thought of everything for ‘Street Fighter 6’
 - [https://www.washingtonpost.com/video-games/2022/10/07/street-fighter-6-closed-beta-review/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2022/10/07/street-fighter-6-closed-beta-review/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-07 13:22:41+00:00

“Street Fighter 6” is a fusion of the parry system from the third game, the chunkiness of the fourth and the mechanics of the fifth. That's high praise.

## U.S. imposes tough rules to limit China’s access to high-tech chips
 - [https://www.washingtonpost.com/technology/2022/10/07/china-high-tech-chips-restrictions/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/10/07/china-high-tech-chips-restrictions/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-07 11:24:31+00:00

The U.S. is taking the toughest steps yet to restrict China's access to U.S. computing technology, saying Beijing is using it to modernize its military.

## Biden issues order boosting privacy checks for data flows from Europe
 - [https://www.washingtonpost.com/technology/2022/10/07/biden-data-transfer-executive-order/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/10/07/biden-data-transfer-executive-order/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-07 10:00:00+00:00

The order puts into practice a preliminary deal struck between President Biden and European Union leaders in March that added checks on the collection of Europeans’ personal information by U.S. intelligence agencies.

## Google won’t let you talk to the latest language AI. This startup will
 - [https://www.washingtonpost.com/technology/2022/10/07/characterai-google-lamda/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/10/07/characterai-google-lamda/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-07 08:00:47+00:00

Two top artificial intelligence talents left Google to create a new chatbot start-up that lets users experiment with the latest in language AI.

## Your boss can monitor your activities without special software
 - [https://www.washingtonpost.com/technology/2022/10/07/work-app-surveillance/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/10/07/work-app-surveillance/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-07 07:00:33+00:00

Apps like Microsoft Office, Zoom, Google Workspace and Slack may provide bosses information on workers’ digital activities. But experts say it’s not an accurate representation of productivity or performance.


# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## Google delays adblock's death, New Nvidia driver, Debian goes non free -  Linux and Open Source News
 - [https://www.youtube.com/watch?v=xO2bJtXqtHg](https://www.youtube.com/watch?v=xO2bJtXqtHg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2022-10-07 00:00:00+00:00

Get 100$ credit for your own Linux and gaming server: https://www.linode.com/linuxexperiment 
Grab a brand new laptop or desktop running Linux:https://www.tuxedocomputers.com/en#


👏 SUPPORT THE CHANNEL:
Get access to a weekly podcast, vote on the next topics I cover, and get your name in the credits:

YouTube: https://www.youtube.com/channel/UC5UAwBUum7CPN5buc-_N1Fw/join
Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want: https://paypal.me/thelinuxexp?locale.x=fr_FR

📹 MORE VIDEOS FROM ME
Linux news in Shorts format: https://www.youtube.com/channel/UCtZp0mK9IBrpS2-jNzMZmoA
Gaming on Linux: https://www.youtube.com/channel/UCaw_Lz7oifDb-PZCAcZ07kw
I'm also on ODYSEE: https://odysee.com/$/invite/@TheLinuxExperiment:e

🏆 FOLLOW ME ELSEWHERE:
Twitter : http://twitter.com/thelinuxEXP
Instagram: https://www.instagram.com/nick_thelinuxexp/
Mastodon: https://mastodon.social/web/@thelinuxEXP
Pixelfed: https://pixelfed.social/TLENick

This video is distributed under the Creative Commons Share Alike license.

#linux #news #opensource 

00:00 Intro
00:46 Sponsor: 100$ free credit for your Linux or gaming server
01:43 Google delays the end of Manifest v2 extensions
03:33 Linux kernel 6.0 is out with support for Intel ARC GPUs
05:15 New FOSS Nvidia driver from Collabora
07:13 GNOME App Updates
08:46 Debian includes non-free firmware on their installer
10:17 elementary OS7 updates
11:37 No more queue for the Deck, and big Docked mode update
13:49 Sponsor: Get a laptop or desktop that runs Linux perfectly
14:55 Support the channel



Google delays the end of Manifest v2 extensions
https://www.ghacks.net/2022/09/29/google-delays-the-death-of-manifest-v2-extensions-to-2024/

https://www.youtube.com/watch?v=8KWCLhHrblE

Linux kernel 6.0 is out with support for Intel ARC GPUs
https://www.omgubuntu.co.uk/2022/10/linux-kernel-6-released-new-features

https://www.pcworld.com/article/1341464/intel-arc-a770-a750-graphics-card-review.html



New FOSS Nvidia driver from Collabora
https://www.collabora.com/news-and-blog/news-and-events/introducing-nvk.html


GNOME App Updates
https://thisweek.gnome.org/posts/2022/09/twig-63/


Debian includes non-free firmware on their installer
https://linuxiac.com/debian-decided-to-include-non-free-firmware-in-the-installer/


elementary OS7 updates
https://blog.elementary.io/updates-for-september-2022/


No more queue for the Deck, and big Docked mode update
https://www.gamingonlinux.com/2022/10/steamos-and-steam-deck-on-top-for-linux-in-the-steam-hardware-survey/

https://steamcommunity.com/games/1675200/announcements/detail/3276955672625890260

https://www.gamingonlinux.com/2022/10/steamos-332-and-a-stable-steam-deck-client-update-are-out-now-heres-whats-new/

https://store.steampowered.com/news/app/1675200/view/3301726014486703380


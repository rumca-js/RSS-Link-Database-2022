# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Pixel 7/Pro and Watch Impressions!
 - [https://www.youtube.com/watch?v=CMtF7nxMv5A](https://www.youtube.com/watch?v=CMtF7nxMv5A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-10-07 00:00:00+00:00

Google Pixel 7 and Pixel 7 Pro are now real. But also so is the Pixel Watch.

That shirt! http://shop.MKBHD.com

On iPhone 14 Plus and benchmarks: https://youtu.be/35BkHichD2M
Check out the Google Pixel 7 Pro at https://geni.us/EM7Pt22
Check out the Google Pixel 7 at https://geni.us/xC8XD
Check out the Pixel Watch w/ WiFi at https://geni.us/8YjeK
Check out the Pixel Watch w/ WiFi + LTE at https://geni.us/EIphh1

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Intro Track: Jordyn Edmonds https://lnk.to/jordynedmonds 
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


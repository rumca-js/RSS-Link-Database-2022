# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Czy kremy z filtrem mają sens?
 - [https://www.youtube.com/watch?v=nOppM3GFEN4](https://www.youtube.com/watch?v=nOppM3GFEN4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2022-10-07 00:00:00+00:00

📚 Kup moją najnowszą książkę ► https://siedem.alt.pl

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Pytanie niby letnie... No nawet nie niby... Film nagraliśmy w lecie ale przez choroby wychodzi teraz. W październikowej zwyżce temperatury i przy pięknej pogodzie. Uwierzcie mi - nawet jesienią warto taki film obejrzeć

===
Rozkład jazdy:

0:00 To zdradliwe Słońce
2:35 Co nam daje raka?
8:07 Co nam robią kremy z filtrem?
11:54 Po co nam to robią?
14:59 I czy to jest to, o czym się mówi?
19:40 Czy są bezpieczne?
24:30 Nieważne! I tak warto je stosować!

===
Źródła (wybrane):

E. da Silva i in. - Use of sunscreen and risk of melanoma and non melanoma skin cancer: a systematic review and meta-analysis
J. van der Pols i in. - Prolonged Prevention of squamous cell carcinoma of the skin by regular sunscreen use
A. Green i in. - Reduced melanoma after regular sunscreen use: randomized trial follow-up
M. Sander i in. - The efficacy and safety of sunscreen use for the prevention of skin cancer
C. Rueegg i in. - Challenges in assessing the sunscreen-melanoma association
B. Krone i in. - Protection against melanoma by vaccination with BCG and/or vaccinia: an epideimology-based hypothesis on the nature of melanoma risk factor and its immunological control
Yong i in. - Vitamin D: one more argument for broad-spectrum ultraviolet A + ultraviolet B sunscreen protection
R. Neale i in. - The effect of sunscreen on vitamin D: a review
R. Waldman i in. - The role of sunscreen in the prevention of cutenous melanoma and nonmelanoma skin cancer
M. Ghazipura i in. - Exposure to benzophenone-3 and reproductive toxicity: A systematic review of human and animal studies
M. Matta i in. - Effect of sunscreen application under maximal use conditions on plasma cocnentration of sunscreen active ingredients


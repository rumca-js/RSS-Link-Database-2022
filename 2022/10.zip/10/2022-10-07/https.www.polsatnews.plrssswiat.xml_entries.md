# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Wielka Brytania. Liverpool gospodarzem konkursu Eurowizja 2023
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/wielka-brytania-liverpool-gospodarzem-konkursu-eurowizja-2023/](https://www.polsatnews.pl/wiadomosc/2022-10-07/wielka-brytania-liverpool-gospodarzem-konkursu-eurowizja-2023/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 19:11:00+00:00

Przyszłoroczna edycja Eurowizji, którą w imieniu Ukrainy zorganizuje Wielka Brytania, odbędzie się w Liverpoolu - podało w piątek BBC. To państwo już ośmiokrotnie gościło imprezę u siebie, ale miasto Beatlesów w roli gospodarza dopiero zadebiutuje.

## Szkocja. Energia odnawialna z tańca w klubie SWG3 w Glasgow. Zastosowano technologię BODYHEAT
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/szkocja-energia-odnawialna-z-tanca-w-klubie-swg3-w-glasgow-zastosowano-technologie-bodyheat/](https://www.polsatnews.pl/wiadomosc/2022-10-07/szkocja-energia-odnawialna-z-tanca-w-klubie-swg3-w-glasgow-zastosowano-technologie-bodyheat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 18:44:00+00:00

Energia odnawialna pochodząca z ciał tańczących ludzi - takie innowacyjne i ekologiczne rozwiązanie zostało zastosowane w klubie SWG3 w Glasgow. Wszystko dzięki opracowanej przez firmę konsultingową ds. energii geotermalnej TownRock Energy technologii BODYHEAT.

## Nord Stream. Rosja chce uczestniczyć w śledztwie dot. uszkodzenia gazociągów. Żądania wobec Szwecji
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/nord-stream-rosja-chce-uczestniczyc-w-sledztwie-dot-uszkodzenia-gazociagow-zadania-wobec-szwecji/](https://www.polsatnews.pl/wiadomosc/2022-10-07/nord-stream-rosja-chce-uczestniczyc-w-sledztwie-dot-uszkodzenia-gazociagow-zadania-wobec-szwecji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 15:55:00+00:00

Rosyjskie władze domagają się udziału w śledztwie prowadzonym ws. wybuchów, które uszkodziły gazociągi Nord Stream. Z takim żądaniem premier tego państwa Michaił Miszustin zwrócił się do swojej szwedzkiej odpowiedniczki Magdaleny Andersson.

## Wielka Brytania. Zabójstwo 14-letniego Polaka w Gateshead. Rówieśnik ofiary usłyszał zarzuty
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/wielka-brytania-zabojstwo-14-letniego-polaka-w-gateshead-rowiesnik-ofiary-uslyszal-zarzuty/](https://www.polsatnews.pl/wiadomosc/2022-10-07/wielka-brytania-zabojstwo-14-letniego-polaka-w-gateshead-rowiesnik-ofiary-uslyszal-zarzuty/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 14:26:00+00:00

W związku ze śmiercią 14-etniego Polaka w Gateshead brytyjska policja zatrzymała jego rówieśnika i rok młodszą dziewczynę. Chłopak usłyszał w piątek zarzut zabójstwa, a 13-latka opuściła areszt za kaucją.

## Postać z kreskówek "Scooby-Doo" lesbijką. Velma zakocha się w dziewczynie
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/postac-z-kreskowek-scooby-doo-lesbijka-velma-zakocha-sie-w-dziewczynie/](https://www.polsatnews.pl/wiadomosc/2022-10-07/postac-z-kreskowek-scooby-doo-lesbijka-velma-zakocha-sie-w-dziewczynie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 12:07:00+00:00

Velma, jedna z głównych bohaterek serii kreskówek Scooby-Doo, okaże się lesbijką. W najnowszym odcinku serii, twórcy zaprezentują jednoznaczną scenę, w której bohaterka zakocha się w nowopoznanej dziewczynie.

## Rosja. Rekruci dostali w zaopatrzeniu paczkę podpasek. Mobilizacyjne problemy Kremla
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/rosja-rekruci-dostali-w-zaopatrzeniu-paczke-podpasek-mobilizacyjne-problemy-kremla/](https://www.polsatnews.pl/wiadomosc/2022-10-07/rosja-rekruci-dostali-w-zaopatrzeniu-paczke-podpasek-mobilizacyjne-problemy-kremla/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 12:01:00+00:00

Jedno z krążących w internecie nagrań pokazuje, że w paczce dla zmobilizowanego oddziału znalazły się czekolada i podpaski - informują media. To jeden z licznych przykładów obrazujących problemy logistyczne rosyjskiej mobilizacji. Teraz na wojnę idzie tłum ludzi, którzy dostali mundury - podsumował anonimowo jeden z żołnierzy.

## Żaryn: W obwodzie kaliningradzkim narasta frustracja. Mieszkańcy nie chcą być "mięsem armatnim"
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/zaryn-w-obwodzie-kaliningradzkim-narasta-frustracja-mieszkancy-nie-chca-byc-miesem-armatnim/](https://www.polsatnews.pl/wiadomosc/2022-10-07/zaryn-w-obwodzie-kaliningradzkim-narasta-frustracja-mieszkancy-nie-chca-byc-miesem-armatnim/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 10:29:00+00:00

Stanisław Żaryn, sekretarz stanu w KPRM i zastępca ministra koordynatora służb specjalnych przekazał, że w obwodzie kaliningradzkim narasta niezadowolenie i frustracja związana z wojną w Ukrainie. Dodał, że mieszkańcy widzą, że Kreml szuka mięsa armatniego. W związku z uniknięciem mobilizacji z terenu Federacji Rosyjskiej uciekły setki tysięcy mężczyzn.

## Wojna w Ukrainie. Odkryto kwaterę Rosjan. Żołnierze mieszkali w... chlewie
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/wojna-w-ukrainie-odkryto-kwatere-rosjan-zolnierze-mieszkali-w-chlewie/](https://www.polsatnews.pl/wiadomosc/2022-10-07/wojna-w-ukrainie-odkryto-kwatere-rosjan-zolnierze-mieszkali-w-chlewie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 10:21:00+00:00

SBU otrzymała niepodważalne dowody na to, że psy Putina istotnie są świniami w prawdziwym życiu - napisała na Twitterze Służba Bezpieczeństwa Ukrainy, zamieszczając wideo odkrytej kwatery Rosjan. Mieściła się ona w chlewie, w okolicach miejscowości Lubymiwka w obwodzie ługańskim.

## Pożary na Wyspie Wielkanocnej. Niektóre posągi Moai spłonęły
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/pozary-na-wyspie-wielkanocnej-niektore-posagi-moai-splonely/](https://www.polsatnews.pl/wiadomosc/2022-10-07/pozary-na-wyspie-wielkanocnej-niektore-posagi-moai-splonely/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 09:13:00+00:00

Pożary na należącej do Chile Wyspie Wielkanocnej uszkodziły znajdujące się tam słynne kamienne posągi Moai. Niektóre z nich zostały zwęglone.

## Rosja. Cyryl I wezwał do modlitwy za Władimira Putina. Prezydent Rosji kończy 70 lat
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/rosja-cyryl-i-wezwal-do-modlitwy-za-wladimira-putina-dzis-prezydent-rosji-konczy-70-lat/](https://www.polsatnews.pl/wiadomosc/2022-10-07/rosja-cyryl-i-wezwal-do-modlitwy-za-wladimira-putina-dzis-prezydent-rosji-konczy-70-lat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 09:10:00+00:00

W dniu 70. urodzin Władimira Putina patriarcha Moskwy i Wszechrusi, Cyryl I, wezwał do modlitwy za prezydenta Rosji. - Prosimy cię, abyś obdarzył go swoim bogatym miłosierdziem i hojnością - przekazał duchowny. Rosyjska Cerkiew Prawosławna jest ważnym graczem politycznym i popiera wojnę Rosji w Ukrainie.

## Pokojowa Nagroda Nobla. Aleś Bialacki, Memoriał i Centrum Wolności Obywatelskich laureatami
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/pokojowa-nagroda-nobla-ales-bialecki-memorial-i-centrum-wolnosci-obywatelskich-laureatami/](https://www.polsatnews.pl/wiadomosc/2022-10-07/pokojowa-nagroda-nobla-ales-bialecki-memorial-i-centrum-wolnosci-obywatelskich-laureatami/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 09:00:00+00:00

Białoruski opozycjonista Aleś Bialacki, rosyjska organizacja Memoriał i ukraińskie Centrum Wolności Obywatelskich laureatami laureatem Pokojowej Nagrody Nobla.

## Wojna w Ukrainie. ISW: Irańskie drony nie przynoszą Rosji wymiernych wyników
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/wojna-w-ukrainie-isw-iranskie-drony-nie-przynosza-rosji-wymiernych-wynikow/](https://www.polsatnews.pl/wiadomosc/2022-10-07/wojna-w-ukrainie-isw-iranskie-drony-nie-przynosza-rosji-wymiernych-wynikow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 07:20:00+00:00

Irańskie drony nie będą raczej miały znacznego wpływu na przebieg wojny - ocenia amerykański Instytut Studiów nad Wojną (ISW). Eksperci uważają, że irański sprzęt nie przynosi Rosji wyników podobnych do tych, jakie zachodnie uzbrojenie daje Ukrainie.

## USA. Prezydent ułaskawił skazanych za marihuanę. Będą zmiany w klasyfikacji narkotyków
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/usa-prezydent-joe-biden-ulaskawil-skazanych-za-marihuane-beda-zmiany-w-klasyfikacji-narkotykow/](https://www.polsatnews.pl/wiadomosc/2022-10-07/usa-prezydent-joe-biden-ulaskawil-skazanych-za-marihuane-beda-zmiany-w-klasyfikacji-narkotykow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 06:39:00+00:00

Prezydent Stanów Zjednoczonych ułaskawił tysiące osób z przestępstwami federalnymi za posiadanie marihuany. Jednocześnie Joe Biden poddał pod wątpliwość klasyfikowanie tego narkotyku w tej samej grupie co LSD i heroina. Zmiany te spełniają obietnice z kampanii.

## USA. Dwie osoby zginęły w ataku nożownika w Las Vegas. Napastnik ranił sześć kolejnych
 - [https://www.polsatnews.pl/wiadomosc/2022-10-07/usa-dwie-osoby-zginely-w-ataku-nozownika-w-las-vegas-napastnik-ranil-szesc-kolejnych/](https://www.polsatnews.pl/wiadomosc/2022-10-07/usa-dwie-osoby-zginely-w-ataku-nozownika-w-las-vegas-napastnik-ranil-szesc-kolejnych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-07 04:08:00+00:00

Na reprezentatywnej ulicy Las Vegas doszło do napaści nożownika na przechodniów. W wyniku ataku mężczyzny dwie osoby zmarły, a sześć kolejnych trafiło do szpitala - przekazała policja. Mężczyzna został złapany.


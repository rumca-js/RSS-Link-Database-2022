# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Luis Castillo's gem gives Mariners win in first playoff game since 2001
 - [https://www.foxnews.com/sports/luis-castillos-gem-gives-mariners-win-first-playoff-game-2001](https://www.foxnews.com/sports/luis-castillos-gem-gives-mariners-win-first-playoff-game-2001)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 23:58:02+00:00

The Seattle Mariners brought in Luis Castillo to be an anchor in October, and he lived up to that billing in Seattle's first postseason game since 2001.

## Hurricane Ian victims return to battered homes as death toll continues to rise
 - [https://www.foxnews.com/us/hurricane-ian-victims-return-battered-homes-death-toll-continues-rise](https://www.foxnews.com/us/hurricane-ian-victims-return-battered-homes-death-toll-continues-rise)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 23:52:58+00:00

Hurricane Ian and its effects killed at least 132 people after the storm devastated Cuba, Florida, North Carolina and Virginia over a week ago.

## NYPD IDs 4 members of gang as subway attack suspects dressed in neon green bodysuits, all have rap sheets
 - [https://www.foxnews.com/us/nypd-ids-members-gang-neon-green-bodysuits-attacked-robbed-women](https://www.foxnews.com/us/nypd-ids-members-gang-neon-green-bodysuits-attacked-robbed-women)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 23:42:50+00:00

New York police identified four women who allegedly dressed up in neon-green bodysuits and attacked two women on a subway train last weekend.

## North Dakota football player is proving he has what it takes at age 49
 - [https://www.foxnews.com/sports/north-dakota-football-players-proving-he-has-what-it-takes-age-49](https://www.foxnews.com/sports/north-dakota-football-players-proving-he-has-what-it-takes-age-49)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 23:40:56+00:00

Ray Ruschel is an Army veteran, a night-shift mechanic at a local sugar beet factory and a 49-year-old junior college football player in North Dakota.

## Elderly LA liquor store worker dies after being struck with scooter, robbed by teens
 - [https://www.foxnews.com/us/elderly-la-liquor-store-owner-dies-being-struck-with-scooter-robbed-teens](https://www.foxnews.com/us/elderly-la-liquor-store-owner-dies-being-struck-with-scooter-robbed-teens)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 23:31:06+00:00

A 69-year-old liquor store worker has died after a group of four teenagers robbed his store and hit him over the head with a scooter before fleeing the scene.

## Sylvester Stallone, Jennifer Flavin enjoy a date in NYC as divorce is reportedly dismissed
 - [https://www.foxnews.com/entertainment/sylvester-stallone-jennifer-flavin-enjoy-date-nyc-divorce-reportedly-dismissed](https://www.foxnews.com/entertainment/sylvester-stallone-jennifer-flavin-enjoy-date-nyc-divorce-reportedly-dismissed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 23:09:20+00:00

Sylvester Stallone and Jennifer Flavin stepped out for a date, looking happy after rekindling their relationship. Flavin initially filed for divorce in August 2022.

## A moral injury for America’s veterans
 - [https://www.foxnews.com/us/moral-injury-americas-veterans](https://www.foxnews.com/us/moral-injury-americas-veterans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 23:05:32+00:00

According to new statistics from the United States military, 30,177 active duty and military veterans have passed away by suicide since September 11, 2001.

## NFLPA calling on league to adopt new concussion protocol before Sunday's games
 - [https://www.foxnews.com/sports/nflpa-calling-league-adopt-new-concussion-protocol-sundays-games](https://www.foxnews.com/sports/nflpa-calling-league-adopt-new-concussion-protocol-sundays-games)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 22:58:24+00:00

The NFLPA has agreed to change concussion protocols and is now urging the league to accept the changes before the start of Sunday's games.

## The left believes Kanye West has to be 'destroyed': Jesse Watters
 - [https://www.foxnews.com/media/left-believes-kanye-west-destroyed-jesse-watters](https://www.foxnews.com/media/left-believes-kanye-west-destroyed-jesse-watters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 22:41:39+00:00

'The Five' co-hosts discuss Tucker Carlson's interview with Kanye West about being a Black conservative and wearing a 'White Lives Matter' T-shirt at his Paris fashion show.

## Former Arizona mayor faces sentencing in ballot harvesting case, lawyer asks for leniency
 - [https://www.foxnews.com/politics/arizona-woman-faces-sentencing-ballot-harvesting-case-lawyer-asks-leniency](https://www.foxnews.com/politics/arizona-woman-faces-sentencing-ballot-harvesting-case-lawyer-asks-leniency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 22:37:20+00:00

The former mayor of San Luis, Arizona is facing possible jail time after pleading guilty to a count of ballot abuse, but her lawyer argues that any jail time would be a miscarriage of justice.

## Kesha and Dr. Luke trial will take place in summer 2023: judge
 - [https://www.foxnews.com/entertainment/kesha-dr-luke-trial-summer-2023-judge](https://www.foxnews.com/entertainment/kesha-dr-luke-trial-summer-2023-judge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 22:32:31+00:00

A New York judge announced the trial between Kesha and Dr. Luke will likely take place next summer. The trial will either start in late June or early July.

## Apples by the numbers: 10 facts about the edible fruit
 - [https://www.foxnews.com/lifestyle/apples-numbers-10-facts-edible-fruit](https://www.foxnews.com/lifestyle/apples-numbers-10-facts-edible-fruit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 22:31:38+00:00

In the U.S., apple season runs from July to November. Here are 10 number-based fun facts about the fruit to get you in the apple-picking spirit this fall.

## Missouri woman catches rare golden crappie
 - [https://www.foxnews.com/us/missouri-woman-catches-rare-golden-crappie](https://www.foxnews.com/us/missouri-woman-catches-rare-golden-crappie)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 22:18:22+00:00

A woman in Missouri recently caught an extremely rare golden crappie in a pond in her backyard.

## Cardinals bullpen, defense falter as Phillies score six in the ninth for improbable victory
 - [https://www.foxnews.com/sports/cardinals-bullpen-defense-falter-phillies-score-six-ninth-improbable-victory](https://www.foxnews.com/sports/cardinals-bullpen-defense-falter-phillies-score-six-ninth-improbable-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 22:17:13+00:00

The Phillies were down to their final two outs in Game 1 of the wild-card series, but the Cardinals choked away their lead, and they are now on the brink of elimination.

## Alaska’s ‘Fat Bear Week’ underway to crown pudgiest bear ahead of winter hibernation
 - [https://www.foxnews.com/lifestyle/alaskas-fat-bear-week-underway-pudgiest-bear-winter-hibernation](https://www.foxnews.com/lifestyle/alaskas-fat-bear-week-underway-pudgiest-bear-winter-hibernation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 22:10:58+00:00

Fat Bear Week 2022 has officially kicked off, as the public pitches in to rank some of Alaska's largest bears just ahead of their winter hibernation.

## Infamous fraudster Anna Sorokin is a free woman after her release from ICE custody
 - [https://www.foxnews.com/us/infamous-fraudster-anna-sorokin-free-woman-release-ice-custody](https://www.foxnews.com/us/infamous-fraudster-anna-sorokin-free-woman-release-ice-custody)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 21:52:32+00:00

Con artist Anna Sorokin, who inspired the hit Netflix series "Inventing Anna," was released from immigration jail Friday after 17 months behind bars fighting her deportation to Germany.

## Ahead of Arizona and Nevada rallies, Trump super PAC launches ads in each state tying Democrats to Biden
 - [https://www.foxnews.com/politics/ahead-trump-rallies-this-weekend-arizona-nevada-trump-super-pac-launches-ads-key-races](https://www.foxnews.com/politics/ahead-trump-rallies-this-weekend-arizona-nevada-trump-super-pac-launches-ads-key-races)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 21:51:22+00:00

A new Donald Trump super PAC is launching ads in crucial midterm races in Arizona and Nevada ahead of Trump’s rallies this weekend in the key battlegrounds.

## Las Vegas stabbing suspect is in US illegally, has criminal record in California: source
 - [https://www.foxnews.com/us/las-vegas-stabbing-suspect-us-illegally-has-criminal-record-california](https://www.foxnews.com/us/las-vegas-stabbing-suspect-us-illegally-has-criminal-record-california)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 21:50:24+00:00

The man accused of stabbing eight people on the Las Vegas Strip, killing two of them, is an illegal immigrant from Guatemala, sources said.

## Attorney charged after hitting Browns owner Jimmy Haslam with bottle
 - [https://www.foxnews.com/sports/attorney-charged-hitting-browns-owner-jimmy-haslam-bottle](https://www.foxnews.com/sports/attorney-charged-hitting-browns-owner-jimmy-haslam-bottle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 21:43:20+00:00

A Cleveland, Ohio-based lawyer has been charged following his arrest in September for throwing a water bottle at Browns owner Jimmy Haslam.

## Colorado police find more than 300 fentanyl pills in vehicle
 - [https://www.foxnews.com/us/colorado-police-find-more-than-300-fentanyl-pills-vehicle](https://www.foxnews.com/us/colorado-police-find-more-than-300-fentanyl-pills-vehicle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 21:37:46+00:00

A Colorado police officer found more than 300 fentanyl pills in a suspicious vehicle in an area where police were practicing "proactive" policing.

## Kansas judge gives mom no jail time after toddler dies in a house fire
 - [https://www.foxnews.com/us/kansas-judge-gives-mom-no-jail-time-toddler-dies-house-fire](https://www.foxnews.com/us/kansas-judge-gives-mom-no-jail-time-toddler-dies-house-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 21:28:41+00:00

A Kansas mom got a slap on the wrist Thursday for the death of her 17-month-old son, who died in a house fire prosecutors say was set by the child's father.

## Washington Commanders owner Dan Snyder’s lawyers send scathing letter to Congress in wake of ongoing probe
 - [https://www.foxnews.com/sports/washington-commanders-dan-snyder-lawyer-sends-letter-congress-ongoing-probe](https://www.foxnews.com/sports/washington-commanders-dan-snyder-lawyer-sends-letter-congress-ongoing-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 21:26:36+00:00

Lawyers representing Washington Commanders owner Daniel Snyder wrote an aggressively toned letter to members of the U.S. House Oversight and Reform Committee.

## Zelenskyy interview: Russia has begun to 'prepare their society' for possible use of nuclear weapons
 - [https://www.foxnews.com/world/zelenskyy-interview-russia-begun-prepare-society-possible-use-nuclear-weapons](https://www.foxnews.com/world/zelenskyy-interview-russia-begun-prepare-society-possible-use-nuclear-weapons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 21:20:43+00:00

Both Volodymyr Zelenskyy and White House press secretary Karine Jean-Pierre stressed that they've seen no signs Russia has imminent plans to use nuclear weapons.

## Migrants sent to Martha's Vineyard have left shelter at military base for alternative housing, other states
 - [https://www.foxnews.com/us/migrants-sent-marthas-vineyard-left-shelter-military-base-alternative-housing-other-states](https://www.foxnews.com/us/migrants-sent-marthas-vineyard-left-shelter-military-base-alternative-housing-other-states)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 21:08:07+00:00

The remaining Venezuelan migrants who were taken to a military base from Martha's Vineyard have left for other housing options, officials said.

## Army captain serving in Iraq surprises pregnant wife at hospital hours before birth of first child
 - [https://www.foxnews.com/lifestyle/army-captain-serving-iraq-surprises-pregnant-wife-hospital-hours-before-birth-first-child](https://www.foxnews.com/lifestyle/army-captain-serving-iraq-surprises-pregnant-wife-hospital-hours-before-birth-first-child)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 21:07:37+00:00

U.S. Army Captain Harold Rahming arranged an early return home from his deployment in Iraq, so he could be present when his wife gave birth to their first child in Illinois.

## Department of Justice charges Malaysian citizen for trafficking over $725K of rhinoceros horns
 - [https://www.foxnews.com/world/department-justice-charges-malaysian-citizen-trafficking-over-725k-rhinoceros-horns](https://www.foxnews.com/world/department-justice-charges-malaysian-citizen-trafficking-over-725k-rhinoceros-horns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 21:00:13+00:00

The United States Department of Justice anounced that Malaysian national Teo Boon Ching was charged for trafficking over $725,000 worth of rhinoceros horns.

## Biden's hometown mayor splits with Democratic Party's 'wrongheaded' defund the police mantra
 - [https://www.foxnews.com/media/bidens-hometown-mayor-splits-democratic-partys-wrongheaded-defund-police-mantra](https://www.foxnews.com/media/bidens-hometown-mayor-splits-democratic-partys-wrongheaded-defund-police-mantra)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:59:58+00:00

Wilmington Mayor Mike Purzycki called out proponents of defunding the police as counterproductive, saying Delaware's largest city has a strong support of law enforcement.

## US Marines storm beach near disputed reef in South China Sea joint military drills
 - [https://www.foxnews.com/world/us-marines-storm-beach-disputed-reef-south-china-sea-joint-military-drills](https://www.foxnews.com/world/us-marines-storm-beach-disputed-reef-south-china-sea-joint-military-drills)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:59:55+00:00

United States Marines on Friday stormed an uninhabited beach near the South China Sea in joint military exercises with the Philippines, Japan and South Korea.

## Amir Elor makes US wrestling history with gold medal match at 2022 Senior World Championships
 - [https://www.foxnews.com/sports/amir-elor-makes-us-wrestling-history-gold-medal-match-2022-senior-world-championships](https://www.foxnews.com/sports/amir-elor-makes-us-wrestling-history-gold-medal-match-2022-senior-world-championships)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:54:49+00:00

Team USA's Amit Elor became the youngest American to win a Senior World Championship title last month, winning gold in women's freestyle at 18.

## Marist College parent murder: Suspects indicted after 'unprovoked' shooting as family releases obituary
 - [https://www.foxnews.com/us/marist-college-parent-murder-suspects-indicted-unprovoked-shooting-family-releases-obituary](https://www.foxnews.com/us/marist-college-parent-murder-suspects-indicted-unprovoked-shooting-family-releases-obituary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:53:15+00:00

The pair of suspects were indicted on Friday after the Sunday shooting of a Long Island man who was killed in the lobby of a Poughkeepsie Marriott Courtyard.

## Beyoncé calls out 'Right Said Fred' over claims she did not have permission to use their song: 'Erroneous'
 - [https://www.foxnews.com/entertainment/beyonce-calls-out-right-said-fred-over-claims-she-did-not-have-permission-to-use-their-song-erroneous](https://www.foxnews.com/entertainment/beyonce-calls-out-right-said-fred-over-claims-she-did-not-have-permission-to-use-their-song-erroneous)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:47:52+00:00

Beyoncé responded on Thursday to allegations that she did not have permission to use a song from the band "Right Said Fred" on her latest album.

## Biden pardon for simple marijuana possession won’t apply to illegal immigrants
 - [https://www.foxnews.com/politics/biden-pardon-simple-marijuana-possession-wont-apply-illegal-immigrants](https://www.foxnews.com/politics/biden-pardon-simple-marijuana-possession-wont-apply-illegal-immigrants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:47:39+00:00

President Biden's pardon of federal convictions for simple marijuana possession will not apply to illegal immigrants -- a move that has angered activist groups.

## Maryland Court of Appeals upholds decision allowing election workers to count mail-in ballots early
 - [https://www.foxnews.com/politics/maryland-court-appeals-upholds-decision-allowing-election-workers-count-mail-ballots-early](https://www.foxnews.com/politics/maryland-court-appeals-upholds-decision-allowing-election-workers-count-mail-ballots-early)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:37:40+00:00

A Maryland Court of Appeals upheld a decision from a circuit court that allows county election workers to count mail-in ballots before Election Day.

## Oregon schools fire unvaccinated teachers: 'Doesn't make any sense'
 - [https://www.foxnews.com/media/oregon-schools-fire-unvaccinated-teachers-doesnt-make-sense](https://www.foxnews.com/media/oregon-schools-fire-unvaccinated-teachers-doesnt-make-sense)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:24:30+00:00

After an Oregon school board voted unanimously to fire three teachers for refusing the vaccine, the state's vaccine mandate is exacerbating the teacher shortage.

## Boston Children's Hospital says children can know they're transgender 'from the womb' in deleted video
 - [https://www.foxnews.com/media/boston-childrens-hospital-children-know-transgender-womb-deleted-video](https://www.foxnews.com/media/boston-childrens-hospital-children-know-transgender-womb-deleted-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:21:30+00:00

Boston Children's Hospital has generated controversy over a video claiming that some children know their gender identity even before they're born.

## New York father of 4 fatally shoots wife, parents before killing himself while his children were at school
 - [https://www.foxnews.com/us/new-york-father-fatally-shoots-wife-parents-killing-himself-children-school](https://www.foxnews.com/us/new-york-father-fatally-shoots-wife-parents-killing-himself-children-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:17:11+00:00

A father of four from New York killed his mother and his wife while his children were at school. He later killed his father and himself at a shooting range.

## Kanye West calls out Kim Kardashian and Pete Davidson, talks Lizzo, Ice Cube and more
 - [https://www.foxnews.com/entertainment/kanye-west-calls-out-kim-kardashian-pete-davidson-talks-lizzo-ice-cube](https://www.foxnews.com/entertainment/kanye-west-calls-out-kim-kardashian-pete-davidson-talks-lizzo-ice-cube)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:10:26+00:00

In an all-encompassing bombshell interview with Tucker Carlson, Kanye West gets candid about his ex-wife, Kim Kardashian, and how she’s portrayed in the media, as well as discussing his interactions with various celebrities.

## Texas A&M quarterback Max Johnson has broken bone in throwing hand: report
 - [https://www.foxnews.com/sports/texas-a-m-quarterback-max-johnson-broken-bone-throwing-hand-report](https://www.foxnews.com/sports/texas-a-m-quarterback-max-johnson-broken-bone-throwing-hand-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:10:24+00:00

Texas A&amp;M Aggies quarterback Max Johnson has a broken bone in his throwing hand and could miss the remainder of the regular season, according to reports.

## Emissions from airplanes using leaded fuel may be declared a public health danger by EPA
 - [https://www.foxnews.com/us/emissions-airplanes-using-leaded-fuel-declared-public-health-danger-epa](https://www.foxnews.com/us/emissions-airplanes-using-leaded-fuel-declared-public-health-danger-epa)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:10:05+00:00

The U.S. Environmental Protection Agency is proposing to declare emissions from aircrafts operating on leaded fuel a public health danger.

## Decapitated head, severed torso of gay Palestinian man discovered on side of road in West Bank
 - [https://www.foxnews.com/world/severed-head-decapitated-torso-gay-palestinian-discovered-side-road-west-bank](https://www.foxnews.com/world/severed-head-decapitated-torso-gay-palestinian-discovered-side-road-west-bank)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:06:12+00:00

A gay Palestinian 25-year-old was brutally murdered. His remains were scattered on the side of the road in the occupied West Bank. The man sought asylum in Israel two years ago.

## Potential Hunter Biden charges are 'grave problem' for Biden family: Miranda Devine
 - [https://www.foxnews.com/media/potential-hunter-biden-charges-grave-problem-biden-family-miranda-devine](https://www.foxnews.com/media/potential-hunter-biden-charges-grave-problem-biden-family-miranda-devine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 20:02:45+00:00

Fox News contributor Miranda Devine reacts on "America Reports" to a Washington Post report of potential charges against Hunter Biden after years of investigation.

## Ex-MA state police officer avoids jail in overtime abuse scheme
 - [https://www.foxnews.com/us/ex-ma-state-police-officer-avoids-jail-overtime-abuse-scheme](https://www.foxnews.com/us/ex-ma-state-police-officer-avoids-jail-overtime-abuse-scheme)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 19:57:30+00:00

A Massachusetts state police lieutenant narrowly avoided jail time by admitting to his role in a widespread overtime abuse scheme, which has already led to reform within the department.

## New Serbian beetle species named after tennis great Novak Djokovic
 - [https://www.foxnews.com/world/new-serbian-beetle-species-named-tennis-great-novak-djokovic](https://www.foxnews.com/world/new-serbian-beetle-species-named-tennis-great-novak-djokovic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 19:55:39+00:00

Serbian scientists have named a new beetle species Duvalius Dokovici after tennis player Novak Djokovic because of its speed, strength and durability.

## Delaware AG asking state Supreme Court to overturn vote-by-mail law
 - [https://www.foxnews.com/us/delaware-ag-state-supreme-court-overturn-vote-mail-law](https://www.foxnews.com/us/delaware-ag-state-supreme-court-overturn-vote-mail-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 19:23:51+00:00

Delaware's attorney general is asking the state Supreme Court to overturn a ruling which claimed the new vote-by-mail law is unconstitutional.

## Broncos lose two players, including former All-Pro, for season with leg injuries
 - [https://www.foxnews.com/sports/broncos-lose-two-players-including-former-all-pro-season-leg-injuries](https://www.foxnews.com/sports/broncos-lose-two-players-including-former-all-pro-season-leg-injuries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 19:22:57+00:00

After already losing Tim Patrick and Javonte Williams to torn ACLs, the Denver Broncos lost two more players to leg injuries in their Thursday night loss.

## Over 2.5M American teens vaped in 2022, officials say
 - [https://www.foxnews.com/us/over-2-5m-american-teens-vaped-2022-officials](https://www.foxnews.com/us/over-2-5m-american-teens-vaped-2022-officials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 19:21:22+00:00

Over 2.5 million middle and high school teenagers vaped in 2020, according to officials. One in four of those teenagers used e-cigarettes on a daily basis.

## American held in Russian penal colony for months but still not labeled 'wrongfully detained,' family says
 - [https://www.foxnews.com/world/american-held-russian-penal-colony-months-wrongfully-detained-family-says](https://www.foxnews.com/world/american-held-russian-penal-colony-months-wrongfully-detained-family-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 19:19:17+00:00

Marc Fogel's family urged the State Department to change his status, and a U.S. representative argued Fogel's case is as important as that of Brittney Griner and Paul Whelan.

## NY state police superintendent resigns amid internal investigation
 - [https://www.foxnews.com/us/ny-state-police-superintendent-resigns-amid-internal-investigation](https://www.foxnews.com/us/ny-state-police-superintendent-resigns-amid-internal-investigation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 19:18:28+00:00

New York State Police Superintendent Steven Nigrelli has resigned after his handling of internal personnel matters has come under investigation.

## Republicans demand answers from Biden officials on report China opened police arm in NYC
 - [https://www.foxnews.com/politics/republicans-demand-answers-biden-officials-report-china-opened-police-arm-nyc](https://www.foxnews.com/politics/republicans-demand-answers-biden-officials-report-china-opened-police-arm-nyc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 19:14:18+00:00

Several House Republican lawmakers sent a letter to Secretaries Antony Blinken and Lloyd Austin demanding answers on Chian's new police presence in New York City.

## Hurricane Julia on course to hit Caribbean this weekend
 - [https://www.foxnews.com/weather/hurricane-julia-course-hit-caribbean-this-weekend](https://www.foxnews.com/weather/hurricane-julia-course-hit-caribbean-this-weekend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 19:13:32+00:00

The National Hurricane Center said Tropical Storm Julia is expected to form Friday and will likely become a hurricane over the southern Caribbean this weekend.

## Shane Bieber's gem, Jose Ramirez's homer give Guardians win over Rays, lead series 1-0
 - [https://www.foxnews.com/sports/shane-biebers-gem-jose-ramirezs-homer-give-guardians-win-rays-lead-series-1-0](https://www.foxnews.com/sports/shane-biebers-gem-jose-ramirezs-homer-give-guardians-win-rays-lead-series-1-0)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 19:11:49+00:00

Shane Bieber struck out eight in 7 2/3 innings of one-run ball, and Jose Ramirez connected on a two-run home run to give the Guardians a 1-0 series lead over the Rays.

## 6 European countries pledge to increase cross-border cooperation in effort to fight organized crime
 - [https://www.foxnews.com/world/6-european-countries-pledge-increase-cross-border-cooperation-effort-fight-organized-crime](https://www.foxnews.com/world/6-european-countries-pledge-increase-cross-border-cooperation-effort-fight-organized-crime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 19:10:44+00:00

Six European countries met to discuss ways to prevent organized crime. The countries are particularly worried about drug barons battling to control the cocaine market.

## University of Southern Maine students demand professor be replaced for saying only two sexes exist
 - [https://www.foxnews.com/us/university-southern-maine-students-demand-professor-replaced-saying-two-sexes-exist](https://www.foxnews.com/us/university-southern-maine-students-demand-professor-replaced-saying-two-sexes-exist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 18:53:19+00:00

University of Southern Maine graduate students are demanding that a professor is replaced for allegedly stating that there are only two sexes.

## White House defends Biden's 'Armageddon' comment, says no indication Russia preparing to use nuclear weapons
 - [https://www.foxnews.com/politics/white-house-defends-bidens-armageddon-comment-says-no-indication-russia-preparing-use-nuclear-weapons](https://www.foxnews.com/politics/white-house-defends-bidens-armageddon-comment-says-no-indication-russia-preparing-use-nuclear-weapons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 18:24:31+00:00

The White House on Friday said it has seen no indication Russia is planning on using nuclear weapons but defended President Biden warning of "Armageddon."

## Dogs that fatally mauled Tennessee toddlers, injured mom were never violent, friend says
 - [https://www.foxnews.com/us/dogs-fatally-mauled-tennessee-toddlers-injured-mom-never-violent-friend-says](https://www.foxnews.com/us/dogs-fatally-mauled-tennessee-toddlers-injured-mom-never-violent-friend-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 18:23:47+00:00

Tennessee authorities euthanized a pair of pit bulls that fatally mauled two toddlers and seriously injured their mom when she tried to save them, officials said.

## Wrong wolf shot in effort to stop WA wolves from preying on cattle
 - [https://www.foxnews.com/us/wrong-wolf-shot-effort-stop-wolves-preying-cattle-wa](https://www.foxnews.com/us/wrong-wolf-shot-effort-stop-wolves-preying-cattle-wa)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 18:16:27+00:00

Washington’s Fish and Wildlife officials mistakenly shot a wolf pup when they were trying to cull the pack and stop further cattle attacks.

## Feminist writers, professors sound off on firing of NYU professor, state of academia: 'Dangerous precedent'
 - [https://www.foxnews.com/media/feminist-writers-professors-sound-firing-nyu-professor-state-academia-dangerous-precedent](https://www.foxnews.com/media/feminist-writers-professors-sound-firing-nyu-professor-state-academia-dangerous-precedent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 18:11:19+00:00

Liberal writers sounded off on the state of academia after a New York University professor was fired after students complained his class was too difficult.

## Lee Zeldin torches Kathy Hochul after murder of college student's father: 'Pandering to pro-criminal allies'
 - [https://www.foxnews.com/media/lee-zeldin-torches-kathy-hochul-murder-college-students-father-pandering-pro-criminal-allies](https://www.foxnews.com/media/lee-zeldin-torches-kathy-hochul-murder-college-students-father-pandering-pro-criminal-allies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 18:07:40+00:00

New York gubernatorial candidate Lee Zeldin joined "The Faulkner Focus" to discuss how crime and the border crisis has impacted his state and slams Kathy Hochul for her inaction.

## Ukrainians strengthen resolve against Russian invasion with small acts of resistance and beauty
 - [https://www.foxnews.com/opinion/ukrainians-strengthen-resolve-against-russian-invasion-small-acts-resistance-beauty](https://www.foxnews.com/opinion/ukrainians-strengthen-resolve-against-russian-invasion-small-acts-resistance-beauty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 18:00:03+00:00

Ukrainians strengthen resolve against Russian invasion with small acts of resistance and beauty designed to keep up morale while enemy PSYOP targets police.

## Slotkin amends disclosures to show husband's employment with a company awarded millions in gov't contracts
 - [https://www.foxnews.com/politics/elissa-slotkin-amends-financial-disclosure-failing-document-husbands-employment-two-years](https://www.foxnews.com/politics/elissa-slotkin-amends-financial-disclosure-failing-document-husbands-employment-two-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 17:55:35+00:00

Elissa Slotkin has amended two of her previous financial disclosures to accurately reflect her husband's employment with a company that has received millions in government contracts.

## Cori Bush says doctors continued abortion procedure after she changed her mind: 'No, I’m not ready'
 - [https://www.foxnews.com/politics/cori-bush-doctors-continued-abortion-procedure-after-changed-mind-no-im-not-ready](https://www.foxnews.com/politics/cori-bush-doctors-continued-abortion-procedure-after-changed-mind-no-im-not-ready)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 17:51:17+00:00

Democrat Congresswoman Cori Bush describes her experience telling doctors "No" while they ignored her and continued with an abortion she says she "was not ready for."

## Uvalde, Texas school district suspends its entire police department
 - [https://www.foxnews.com/us/uvalde-texas-school-district-suspends-entire-police-department](https://www.foxnews.com/us/uvalde-texas-school-district-suspends-entire-police-department)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 17:45:37+00:00

The entire Uvalde, Texas, school district police department has been suspended, the district announced Friday, citing "additional concerns."

## Compagno, 'Outnumbered' on Biden's nuclear 'Armageddon' remark: Once again, White House is in cleanup mode
 - [https://www.foxnews.com/media/compagno-outnumbered-biden-nuclear-armageddon-remark-white-house-cleanup-mode](https://www.foxnews.com/media/compagno-outnumbered-biden-nuclear-armageddon-remark-white-house-cleanup-mode)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 17:43:10+00:00

'Outnumbered' co-host Emily Compagno reacts to President Biden's "Armageddon" warning as Vladimir Putin threatens to use nuclear weapons against Ukrainian forces.

## UN to appoint expert to lead charge in scrutinizing Russia
 - [https://www.foxnews.com/world/un-appoints-expert-lead-charge-scrutinizing-russia](https://www.foxnews.com/world/un-appoints-expert-lead-charge-scrutinizing-russia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 17:15:51+00:00

The United Nation's top human rights body will be appointing a leader to lead the charge in scrutinizing Russia over its invasion of Ukraine.

## Ohio man dies after falling from South Carolina hotel balcony
 - [https://www.foxnews.com/us/ohio-man-dies-falling-south-carolina-hotel-balcony](https://www.foxnews.com/us/ohio-man-dies-falling-south-carolina-hotel-balcony)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 17:15:45+00:00

An Ohio man fell to his death last week from the 15th-floor balcony of a Myrtle Beach hotel. The incident occurred as Hurricane Ian bore down on South Carolina.

## Federal judge dismisses Wisconsin lawsuit aimed at blocking student loan forgiveness program
 - [https://www.foxnews.com/us/federal-judge-dismisses-wisconsin-lawsuit-aimed-blocking-student-loan-forgiveness](https://www.foxnews.com/us/federal-judge-dismisses-wisconsin-lawsuit-aimed-blocking-student-loan-forgiveness)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 17:14:34+00:00

A federal judge in Wisconsin dismissed a lawsuit aimed at blocking the student loan forgiveness program. A group of taxpayers argued that the program was discriminatory.

## Alabama asking court to swiftly set new execution date for Alan Miller
 - [https://www.foxnews.com/us/alabama-asking-court-swiftly-set-new-execution-date-alan-miller](https://www.foxnews.com/us/alabama-asking-court-swiftly-set-new-execution-date-alan-miller)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 17:13:56+00:00

The state of Alabama is asking a court to set a new date for the execution of Alan Miller. He had his execution called off after multiple failed attempts to connect to his veins.

## Alan Alda on 'M*A*S*H's 50th anniversary: 'I'm not sure we ever knew what kind of impact it was having'
 - [https://www.foxnews.com/entertainment/alan-alda-on-mash-50th-anniversary-im-not-sure-we-ever-knew-what-kind-of-impact-it-was-having](https://www.foxnews.com/entertainment/alan-alda-on-mash-50th-anniversary-im-not-sure-we-ever-knew-what-kind-of-impact-it-was-having)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 17:12:37+00:00

Actor Alan Alda celebrated the 50th anniversary of his beloved TV series "M*A*S*H," reflecting on the lasting, and surprising, impact of the show.

## Mexican cartels using social media to recruit smugglers amid historic border surge
 - [https://www.foxnews.com/politics/mexican-cartels-using-social-media-recruit-smugglers-historic-border-surge](https://www.foxnews.com/politics/mexican-cartels-using-social-media-recruit-smugglers-historic-border-surge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 17:07:12+00:00

Cartels moving across the southern border are using social media to recruit people -- including teenagers -- to bring migrants and contraband into the U.S.

## Friend of Purdue University student killed in residence hall speaks out: Varun was a 'really good' person
 - [https://www.foxnews.com/us/friend-purdue-university-student-killed-residence-hall-speaks-out-varun-really-good-person](https://www.foxnews.com/us/friend-purdue-university-student-killed-residence-hall-speaks-out-varun-really-good-person)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 17:06:40+00:00

A close friend remembers Varun Manish Chheda as a "really good person." Chheda was killed Wednesday at his Purdue University residence hall in Indiana.

## GOP senators sound alarm over 'windfall' student loan payments to federal workers
 - [https://www.foxnews.com/politics/gop-senators-sound-alarm-windfall-student-loan-payments-federal-workers](https://www.foxnews.com/politics/gop-senators-sound-alarm-windfall-student-loan-payments-federal-workers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 16:59:38+00:00

Republican senators worry that some federal employees may get a double benefit from the Department of Education at a massive cost to American taxpayers.

## Full hunter's moon: What to know
 - [https://www.foxnews.com/science/full-hunters-moon-what-know](https://www.foxnews.com/science/full-hunters-moon-what-know)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 16:56:47+00:00

The full hunter's moon is expected to rise on Sunday. NASA said the moon would appear full for about three days, from Saturday morning through Tuesday morning.

## Olivia Culpo gets emotional talking about her ex during trailer for new TV show 'The Culpo Sisters'
 - [https://www.foxnews.com/entertainment/olivia-culpo-emotional-ex-trailer-new-culpo-sisters-tv-show](https://www.foxnews.com/entertainment/olivia-culpo-emotional-ex-trailer-new-culpo-sisters-tv-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 16:55:35+00:00

Olivia Culpo is in a new television show with her sisters Aurora and Sophia. In the trailer for "The Culpo Sisters," Olivia gets emotional talking about one of her past relationships.

## White House denies Venezuela deal as critics warn any Maduro regime deal is a mistake
 - [https://www.foxnews.com/world/white-house-denies-venezuela-deal-critics-warn-any-deal-maduro-regime-mistake](https://www.foxnews.com/world/white-house-denies-venezuela-deal-critics-warn-any-deal-maduro-regime-mistake)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 16:17:47+00:00

Critics believe any deal with Maduro would end up costing the U.S. its morals for very little oil in return that would make no impact on gas prices for the average American.

## China’s secret police have invaded American shores: human rights advocate
 - [https://www.foxnews.com/world/chinas-secret-police-invaded-american-shores-human-rights-advocate](https://www.foxnews.com/world/chinas-secret-police-invaded-american-shores-human-rights-advocate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 16:01:59+00:00

Laura Harth of Safeguard Defenders warns that China's reported police service stations abroad are expanding the communist regime's international footprint.

## William Shatner explains why his trip to space ‘felt like a funeral’: ‘I saw death and I saw life’
 - [https://www.foxnews.com/entertainment/william-shatner-explains-trip-space-felt-funeral-saw-death-saw-life](https://www.foxnews.com/entertainment/william-shatner-explains-trip-space-felt-funeral-saw-death-saw-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 16:01:31+00:00

William Shatner, the "Star Trek" alum, has written a new book titled “Boldly Go: Reflections on a life of Awe and Wonder.” In it, he detailed his experience traveling to space in 2021.

## Late-night comedy flounders in ratings as Colbert, Kimmel, others openly root for Democrats, shred Republicans
 - [https://www.foxnews.com/media/late-night-comedy-flounders-ratings-colbert-kimmel-others-openly-root-democrats-shred-republicans](https://www.foxnews.com/media/late-night-comedy-flounders-ratings-colbert-kimmel-others-openly-root-democrats-shred-republicans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 16:00:59+00:00

There has been a fundamental transformation of the late-night comedy landscape ever since Donald Trump was elected president, causing TV hosts to alienate half the country.

## Netflix’s ‘Dahmer’ star Michael Learned on people’s obsession with serial killers: ‘I question our country’
 - [https://www.foxnews.com/entertainment/netflix-dahmer-star-michael-learned-peoples-obsession-serial-killers](https://www.foxnews.com/entertainment/netflix-dahmer-star-michael-learned-peoples-obsession-serial-killers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 16:00:57+00:00

“Dahmer: Monster – The Jeffrey Dahmer Story” stars Evan Peters of "American Horror Story" as the Milwaukee serial killer. The show also features Niecy Nash, Richard Jenkins and Molly Ringwald.

## Risks faced by first responders, police to fenantyl exposure are overstated, expert says
 - [https://www.foxnews.com/us/risks-faced-first-responders-police-fenantyl-exposure-overstated-expert-says](https://www.foxnews.com/us/risks-faced-first-responders-police-fenantyl-exposure-overstated-expert-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 16:00:25+00:00

The risk of overdosing from fentanyl that is airborne or touched is minimal, research says, yet officers have reported illnesses after coming in contact with the drug.

## NY Gov. Hochul pictured with Dem fundraiser who shared Holocaust denial, other anti-Semitic content
 - [https://www.foxnews.com/politics/ny-gov-hochul-pictured-dem-fundraiser-shared-holocaust-denial-anti-semitic-content](https://www.foxnews.com/politics/ny-gov-hochul-pictured-dem-fundraiser-shared-holocaust-denial-anti-semitic-content)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 16:00:22+00:00

New York Governor Kathy Hochul attended a Harvard Club fundraiser where she took several pictures with Maher Abdel Qader, an activist who has shared anti-Semitic conspiracies online.

## My late wife Kim taught me how to honor our loved ones by focusing on something that will outlast us
 - [https://www.foxnews.com/opinion/my-late-wife-kim-taught-me-how-honor-our-loved-ones-focusing-something-that-will-outlast-us](https://www.foxnews.com/opinion/my-late-wife-kim-taught-me-how-honor-our-loved-ones-focusing-something-that-will-outlast-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 16:00:16+00:00

My late wife Kim taught me to honor our loved ones by focusing on something that will outlast us. Jessie Rees had that same spirit as she also battled cancer.

## Halloween candy can teach your kids key lessons about taxes and America — here's how
 - [https://www.foxnews.com/lifestyle/halloween-candy-teach-kids-key-lessons-taxes-america](https://www.foxnews.com/lifestyle/halloween-candy-teach-kids-key-lessons-taxes-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 15:59:31+00:00

As millions of American children get ready to go trick-or-treating for Halloween this year, here's a fun and educational exercise that parents can try out on their young ones — for lifelong learning.

## Mob of vandals destroy minority-owned Portland coffee shop before 'Coffee with a Cop' event
 - [https://www.foxnews.com/media/mob-vandals-destroy-minority-owned-portland-coffee-shop-cop-event](https://www.foxnews.com/media/mob-vandals-destroy-minority-owned-portland-coffee-shop-cop-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 15:24:55+00:00

Bison Coffeehouse owner Loretta Guzman appeared on "Fox & Friends First" to discuss the damages to her coffeeshop after advertising a ‘Coffee with a Cop’ event in Portland.

## Yacht owned by sanctioned Russian tycoon docks in Hong Kong
 - [https://www.foxnews.com/world/yacht-owned-sanctioned-russian-tycoon-docks-hong-kong](https://www.foxnews.com/world/yacht-owned-sanctioned-russian-tycoon-docks-hong-kong)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 15:21:01+00:00

Russia tycoon Alexey Mordashov, who owns the Nord yacht, was sanctioned by the U.S., United Kingdom and European Union in February after Russia invaded Ukraine.

## Warriors GM says Draymond Green apologized to team as video of altercation with Jordan Poole circulates
 - [https://www.foxnews.com/sports/warriors-gm-says-draymond-green-apologized-team-video-altercation-with-jordan-poole-circulates](https://www.foxnews.com/sports/warriors-gm-says-draymond-green-apologized-team-video-altercation-with-jordan-poole-circulates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 15:09:43+00:00

Golden State Warriors general manager Bob Myers said that Draymond Green apologized to his teammates for punching Jordan Poole during practice. Video of the incident has emerged.

## Jonathan Turley lays out concerns Hunter Biden probe not looking at 'full scope' of potential crimes
 - [https://www.foxnews.com/media/jonathan-turley-lays-concerns-hunter-biden-probe-looking-full-scope-potential-crimes](https://www.foxnews.com/media/jonathan-turley-lays-concerns-hunter-biden-probe-looking-full-scope-potential-crimes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 15:00:44+00:00

Jonathan Turley responds to a report of potential charges against Hunter Biden and questions whether the indictment will cover the 'full scope of potential criminal conduct.'

## Longtime Hillary Clinton aide Huma Abedin joins MSNBC as contributor
 - [https://www.foxnews.com/media/longtime-hillary-clinton-aide-huma-abedin-joins-msnbc-contributor](https://www.foxnews.com/media/longtime-hillary-clinton-aide-huma-abedin-joins-msnbc-contributor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 14:59:50+00:00

Huma Abedin, a longtime Hillary Clinton aide who has worked with her in a variety of roles including her 2016 presidential campaign, has joined MSNBC as a contributor.

## Is Kanye West crazy? Arizona families keep winning and more from Fox News Opinion
 - [https://www.foxnews.com/opinion/kanye-west-crazy-arizona-families-winning-more-fox-news-opinion](https://www.foxnews.com/opinion/kanye-west-crazy-arizona-families-winning-more-fox-news-opinion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 14:57:28+00:00

Read the latest from Fox News Opinion & watch videos from Tucker Carlson, Sean Hannity, Laura Ingraham & more.

## NYC Mayor Adams declares state of emergency after 17,000 migrants spark shelter 'crisis'
 - [https://www.foxnews.com/politics/nyc-mayor-adams-declares-state-emergency-17000-migrants-spark-shelter-crisis](https://www.foxnews.com/politics/nyc-mayor-adams-declares-state-emergency-17000-migrants-spark-shelter-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 14:45:41+00:00

New York City Mayor Eric Adams declared a state of emergency on Thursday due to the continued influx of illegal immigrants from southern border states.

## Hunter Biden investigation: AG Garland taking hands-off approach, leaves charging decisions to Weiss
 - [https://www.foxnews.com/politics/hunter-biden-investigation-ag-garland-taking-hands-off-approach-leaves-charging-decisions-weiss](https://www.foxnews.com/politics/hunter-biden-investigation-ag-garland-taking-hands-off-approach-leaves-charging-decisions-weiss)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 14:38:44+00:00

Attorney General Merrick Garland is leaving all charging decisions in the Hunter Biden investigation up to U.S. Attorney for Delaware David Weiss, Fox News has learned.

## Unaccompanied minors flown from border to small NY town: 'Never seen anything like this before'
 - [https://www.foxnews.com/media/unaccompanied-minors-flown-border-small-ny-town-never-seen-anything](https://www.foxnews.com/media/unaccompanied-minors-flown-border-small-ny-town-never-seen-anything)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 14:36:14+00:00

The Biden administration continues sending flights of migrants, including minors, to areas of New York, arriving in the small town of Montgomery.

## Russell Wilson accepts blame for Broncos ugly loss to Colts, vows to respond: 'I don’t know any other way'
 - [https://www.foxnews.com/sports/russell-wilson-accepts-blame-broncos-ugly-loss-colts-vows-respond-dont-know-any-other-way](https://www.foxnews.com/sports/russell-wilson-accepts-blame-broncos-ugly-loss-colts-vows-respond-dont-know-any-other-way)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 14:24:23+00:00

Russell Wilson said he "let let the team down" on Thursday night after the Denver Broncos loss 12-9 in a touchdown-less game against the Indianapolis Colts.

## Main Streets across America are up for this key award: Did your town make the cut?
 - [https://www.foxnews.com/lifestyle/main-streets-across-america-award-did-town-make-cut](https://www.foxnews.com/lifestyle/main-streets-across-america-award-did-town-make-cut)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 14:23:07+00:00

Main Street America has released the 2023 semifinalist cities for the Great American Main Street Award. The towns are scattered across the country — here are four in the running for top honors.

## GOP dives deep on crime debate ahead of midterm elections
 - [https://www.foxnews.com/politics/gop-dives-deep-crime-debate-midterm-elections](https://www.foxnews.com/politics/gop-dives-deep-crime-debate-midterm-elections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 14:12:36+00:00

Crime is becoming a rising debate topic for midterm candidates, as Republicans appear to be leading on the issue among voters in a recent Fox News survey.

## Barnes says he'll accept midterm results after claiming 2016 election was 'rigged' and Abrams 'won' in 2018
 - [https://www.foxnews.com/politics/barnes-accept-midterm-results-tweeting-2016-election-rigged-claiming-abrams-won-2018](https://www.foxnews.com/politics/barnes-accept-midterm-results-tweeting-2016-election-rigged-claiming-abrams-won-2018)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 14:08:07+00:00

Democrat Mandela Barnes said he will accept the results of the Wisconsin Senate election, after alleging the 2016 election was "rigged."

## As Putin turns 70 former insider: 'Hitler didn't use chemical weapons, because he ran out of time'
 - [https://www.foxnews.com/world/putin-turns-70-former-insider-hitler-didnt-use-chemical-weapons-because-he-ran-time](https://www.foxnews.com/world/putin-turns-70-former-insider-hitler-didnt-use-chemical-weapons-because-he-ran-time)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 13:47:32+00:00

As Putin turns 70, Mikhail Khodorkovsky, author of "The Russia Conundrum" warns that Putin is part of a 'gangster entourage,' and warns that Putin is being egged on by extremist forces.

## Support for red flag laws turns to opposition when voters told about how they work: study
 - [https://www.foxnews.com/us/support-red-flag-laws-turns-opposition-voters-told-how-they-work-study](https://www.foxnews.com/us/support-red-flag-laws-turns-opposition-voters-told-how-they-work-study)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 13:45:25+00:00

A new survey shows that support for red flag laws drops when the question is framed differently and respondents are given more details about how they actually work.

## Rep. Comer on 'imminent' Hunter Biden charges: 'Mounting evidence’ of other major crimes
 - [https://www.foxnews.com/media/comer-imminent-hunter-biden-charges-mounting-evidence-other-major-crimes](https://www.foxnews.com/media/comer-imminent-hunter-biden-charges-mounting-evidence-other-major-crimes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 13:36:21+00:00

Rep. James Comer, R-Ky., says potential charges against Hunter Biden are only the beginning of charges against the president’s son as ‘mounting evidence’ suggests more serious crimes.

## Coast Guard settles suit with cadet over cadets-with-kids ban
 - [https://www.foxnews.com/us/coast-guard-settles-suit-cadet-cadets-kids-ban](https://www.foxnews.com/us/coast-guard-settles-suit-cadet-cadets-kids-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 13:32:08+00:00

The U.S. Coast Guard Cadet who was expelled after disclosing that he recently had a child will receive his degree in part of a legal settlement.

## 1 dead, 2 critically injured in Virginia plane crash
 - [https://www.foxnews.com/us/1-dead-2-critically-injured-virginia-plane-crash](https://www.foxnews.com/us/1-dead-2-critically-injured-virginia-plane-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 13:29:21+00:00

A small plane crashed at a Virginia airport on Thursday afternoon. One person died in the crash and two others were critically injured.

## Kentucky Supreme Court traveling to Shelbyville to hear oral questions
 - [https://www.foxnews.com/us/kentucky-supreme-court-traveling-shelbyville-hear-oral-questions](https://www.foxnews.com/us/kentucky-supreme-court-traveling-shelbyville-hear-oral-questions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 13:28:41+00:00

The Kentucky Supreme Court will hear oral questions in Shelbyville. They are going to Shelbyville as part of a public education program.

## Biden White House says congressional Republicans trying to 'defund' police, FBI amid crime crisis
 - [https://www.foxnews.com/politics/biden-white-house-says-congressional-republicans-trying-defund-police-fbi-amid-crime-crisis](https://www.foxnews.com/politics/biden-white-house-says-congressional-republicans-trying-defund-police-fbi-amid-crime-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 13:17:50+00:00

The White House is accusing Republicans of working to "defund the police" and the FBI, and instead, supporting the "gun lobby" over the fight against gun crime by opposing Democrat-backed legislation.

## Harry Styles reschedules Chicago show due to band, crew illness after fans camp outside venue
 - [https://www.foxnews.com/entertainment/harry-styles-reschedules-chicago-show-band-crew-illness-fans-camp-outside-venue](https://www.foxnews.com/entertainment/harry-styles-reschedules-chicago-show-band-crew-illness-fans-camp-outside-venue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 13:16:25+00:00

One Direction alum Harry Styles postponed his first Chicago show for his "Love on Tour" due to an illness among the band and crew.

## National Park Service funding WV recreational, restoration projects
 - [https://www.foxnews.com/us/national-park-service-funding-wv-recreational-restoration-projects](https://www.foxnews.com/us/national-park-service-funding-wv-recreational-restoration-projects)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 13:11:15+00:00

West Virginia is receiving $2.4 million to fund recreational and restoration projects in the state. The state is receiving the money from the National Parks Service.

## Department of Labor spikes Trump apprenticeship program detested by unions
 - [https://www.foxnews.com/politics/department-of-labor-spikes-trump-apprenticeship-program-detested-unions](https://www.foxnews.com/politics/department-of-labor-spikes-trump-apprenticeship-program-detested-unions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 12:02:42+00:00

The Biden administration is set to axe a Trump-era labor policy that eased regulations on apprenticeship programs.

## Lara Trump: Potential Hunter Biden charges don't even 'scratch the surface'
 - [https://www.foxnews.com/media/lara-trump-potential-hunter-biden-charges-even-scratch-surface](https://www.foxnews.com/media/lara-trump-potential-hunter-biden-charges-even-scratch-surface)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 12:02:26+00:00

Lara Trump said Friday the charges potentially coming against Hunter Biden do not deal with the Biden family's business dealings in China and elsewhere.

## Republicans plan immediate IRS oversight if they take control of the House
 - [https://www.foxnews.com/politics/republicans-plan-immediate-irs-oversight-win-control-house](https://www.foxnews.com/politics/republicans-plan-immediate-irs-oversight-win-control-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 11:59:12+00:00

Republicans are planning to launch immediate oversight of the Internal Revenue Service if they win control of the U.S. House of Representatives this November.

## 2022 MLB postseason: Everything you need to know about the new wild card round
 - [https://www.foxnews.com/sports/2022-mlb-postseason-everything-need-know-new-wild-card-round](https://www.foxnews.com/sports/2022-mlb-postseason-everything-need-know-new-wild-card-round)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 11:58:47+00:00

For the first time in baseball history, there will be 12 teams in the MLB postseason, starting with the brand new wild card round. Here's everything you need to know.

## Will Tom Brady and Gisele Bündchen's marriage 'end catastrophically' amid divorce woes? Brand expert weighs in
 - [https://www.foxnews.com/entertainment/tom-brady-gisele-bundchens-marriage-end-catastrophically-amid-divorce-woes-brand-expert](https://www.foxnews.com/entertainment/tom-brady-gisele-bundchens-marriage-end-catastrophically-amid-divorce-woes-brand-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 11:47:15+00:00

The Fox News Entertainment newsletter brings you the latest Hollywood headlines, celebrity interviews and stories from Los Angeles and beyond.

## Review: The 70th Anniversary 2023 Chevrolet Corvette Stingray is young at heart
 - [https://www.foxnews.com/auto/review-70th-anniversary-2023-chevrolet-corvette-stingray](https://www.foxnews.com/auto/review-70th-anniversary-2023-chevrolet-corvette-stingray)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 11:04:24+00:00

The 2023 Chevrolet Corvette Stingray 70th Anniversary Special Edition celebrates the milestone event for the oldest American sports car name still on sale.

## Kanye West attacked as ‘racist hatemonger’ by MSNBC blogger for ‘White Lives Matter’ shirt
 - [https://www.foxnews.com/media/kanye-west-attacked-racist-hatemonger-msnbc-blogger-wearing-white-lives-matter-shirt](https://www.foxnews.com/media/kanye-west-attacked-racist-hatemonger-msnbc-blogger-wearing-white-lives-matter-shirt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 11:00:50+00:00

The ReidOut blog writer Ja'han Jones slimed Kanye for offenses ranging from aspiring to "preppiness" to declaring he cleaned himself after leaving his last girlfriend.

## Kanye West sits down with Tucker Carlson, voters concerned as murders rise and more top headlines
 - [https://www.foxnews.com/us/kanye-west-tucker-carlson-white-lives-matter-shirt](https://www.foxnews.com/us/kanye-west-tucker-carlson-white-lives-matter-shirt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 11:00:49+00:00

Fox News First brings you Fox News' top headlines every morning.

## Why would Biden complain about reporters shouting questions? He barely answers them anyway
 - [https://www.foxnews.com/opinion/why-would-biden-complain-about-reporters-shouting-questions-barely-answers-anyway](https://www.foxnews.com/opinion/why-would-biden-complain-about-reporters-shouting-questions-barely-answers-anyway)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 11:00:36+00:00

President Biden shouldn't complain about reporters shouting out questions at him when he's recorded historic lows for press conferences and interviews.

## Pierce Brosnan files restraining order against woman stalking his family at Malibu home
 - [https://www.foxnews.com/entertainment/pierce-brosnan-files-restraining-order-against-woman-stalking-his-family-at-malibu-home](https://www.foxnews.com/entertainment/pierce-brosnan-files-restraining-order-against-woman-stalking-his-family-at-malibu-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 10:55:42+00:00

Actor Pierce Brosnan has filed a restraining order against a woman who he claims has been stalking him and his family.

## Coast Guard locates 55 Cuban migrants off Florida coast, sends them back to country
 - [https://www.foxnews.com/us/coast-guard-locates-55-cuban-migrants-florida-coast-sends-back-country](https://www.foxnews.com/us/coast-guard-locates-55-cuban-migrants-florida-coast-sends-back-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 10:50:44+00:00

The United States Coast Guard reported 55 Cuban migrants located off the coast of Florida over the past week were sent back to their home country on Wednesday.

## Pasta quiz! How well do you know these fun facts about a favorite food?
 - [https://www.foxnews.com/lifestyle/pasta-quiz-how-well-know-fun-facts-favorite-food](https://www.foxnews.com/lifestyle/pasta-quiz-how-well-know-fun-facts-favorite-food)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 10:30:40+00:00

It's National Pasta Month in October — the perfect time to celebrate the occasion by taking this fun and interactive lifestyle quiz about the dish people across the globe adore.

## Nobel Peace Prize awarded to activists from Belarus, Russia, Ukraine
 - [https://www.foxnews.com/world/nobel-peace-prize-awarded-activists-belarus-russia-ukraine](https://www.foxnews.com/world/nobel-peace-prize-awarded-activists-belarus-russia-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 09:40:10+00:00

The Nobel Peace Prize was awarded to jailed Belarus rights activist Ales Bialiatski, along with the non-profit organizations Center for Civil Liberties and Memorial.

## Hunter Biden: Twitter explodes over news federal agents have enough to file charges against president's son
 - [https://www.foxnews.com/media/hunter-biden-twitter-explodes-news-federal-agents-enough-file-charges-presidents-son](https://www.foxnews.com/media/hunter-biden-twitter-explodes-news-federal-agents-enough-file-charges-presidents-son)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 09:00:34+00:00

Social media users commented on the news that federal charges could be brought against President Biden's controversial son Hunter after a years-long investigation.

## Texas fire chief, firefighter killed in crash while returning to station from call
 - [https://www.foxnews.com/us/texas-fire-chief-firefighter-killed-crash-returning-station-call](https://www.foxnews.com/us/texas-fire-chief-firefighter-killed-crash-returning-station-call)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 08:07:49+00:00

The city of Dalhart, Texas is mourning the loss of firefighter Brendan Torres and Chief Curtis Brown after the two were killed in a collision while returning to the station from a call.

## California sheriff calls killing of kidnapped Merced family 'pure evil'
 - [https://www.foxnews.com/us/california-sheriff-calls-killing-kidnapped-merced-family-pure-evil](https://www.foxnews.com/us/california-sheriff-calls-killing-kidnapped-merced-family-pure-evil)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 07:43:44+00:00

Sheriff Vern Warnke called the killing and kidnapping of a Punjabi Sikh family in Merced, California "pure evil" as he advises prosecutors to seek the death penalty for suspect Jesus Salgado.

## Las Vegas Strip deadly stabbing suspect identified
 - [https://www.foxnews.com/us/las-vegas-strip-deadly-stabbing-suspect-identified](https://www.foxnews.com/us/las-vegas-strip-deadly-stabbing-suspect-identified)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 07:42:07+00:00

The Las Vegas Police Department identified the suspect believed to be responsible for fatally stabbing two people outside the Wynn Hotel on Las Vegas Boulevard Thursday.

## Las Vegas Strip deadly stabbing suspect identified, booked for murder
 - [https://www.foxnews.com/us/las-vegas-strip-deadly-stabbing-suspect-identified-booked-murder](https://www.foxnews.com/us/las-vegas-strip-deadly-stabbing-suspect-identified-booked-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 07:42:07+00:00

The Las Vegas Police Department identified the suspect believed to be responsible for fatally stabbing two people outside the Wynn Hotel on Las Vegas Boulevard Thursday.

## Ukraine's Zelenskyy calls for NATO to launch 'preemptive strikes' in Russia, spokesperson forced to clarify
 - [https://www.foxnews.com/world/ukraines-zelenskyy-calls-for-nato-to-launch-preemptive-strikes-in-russia-spokesperson-forced-to-clarify](https://www.foxnews.com/world/ukraines-zelenskyy-calls-for-nato-to-launch-preemptive-strikes-in-russia-spokesperson-forced-to-clarify)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 06:52:48+00:00

Ukraine's President Volodymyr Zelenskyy seemingly called for NATO countries to launch "preemptive strikes" against Russia to deter nuclear threats, blackmail.

## Boston window washer falls to his death inside JFK Library: 'Shocking and tragic'
 - [https://www.foxnews.com/us/boston-window-washer-falls-death-inside-jfk-library-shocking-tragic](https://www.foxnews.com/us/boston-window-washer-falls-death-inside-jfk-library-shocking-tragic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 06:23:22+00:00

A contracted window washer tragically fell at least five stories to his death Wednesday at the John F. Kennedy Presidential Library and Museum in Boston, Massachusetts.

## Meet the American who first planted apples in the colonies: William Blaxton, eccentric settler
 - [https://www.foxnews.com/lifestyle/meet-american-first-planted-apples-colonies-william-blaxton-settler](https://www.foxnews.com/lifestyle/meet-american-first-planted-apples-colonies-william-blaxton-settler)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 06:00:55+00:00

William Blaxton, an eccentric loner and Anglican minister, settled Boston before the Puritans and Rhode Island before Roger Williams — and planted the first apple orchards in America.

## Joe Biden has hampered domestic energy industry while pleading for more foreign oil
 - [https://www.foxnews.com/politics/joe-biden-hampered-domestic-energy-industry-despite-pleas-foreign-oil](https://www.foxnews.com/politics/joe-biden-hampered-domestic-energy-industry-despite-pleas-foreign-oil)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 06:00:46+00:00

President Biden has waged a war on fossil fuels, hampering domestic production even as he has turned to foreign dictators in Saudi Arabia and Venezuela for more oil.

## Will Tom Brady and Gisele Bündchen's marriage 'end catastrophically'? Brand expert weighs in
 - [https://www.foxnews.com/entertainment/tom-brady-gisele-bundchens-marriage-end-catastrophically-brand-expert-weighs-in](https://www.foxnews.com/entertainment/tom-brady-gisele-bundchens-marriage-end-catastrophically-brand-expert-weighs-in)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 06:00:45+00:00

A Tom Brady and Gisele Bündchen divorce benefits "no one," brand expert Eric Schiffer told Fox News Digital. Divorce lawyers have reportedly been hired by the couple.

## Elon Musk ‘wants free speech to reign on the internet’: Texas Attorney General Ken Paxton
 - [https://www.foxnews.com/tech/elon-musk-wants-free-speech-reign-internet-texas-attorney-general-ken-paxton](https://www.foxnews.com/tech/elon-musk-wants-free-speech-reign-internet-texas-attorney-general-ken-paxton)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 06:00:40+00:00

Elon Musk would likely push for more free speech on Twitter should the Tesla CEO purchase Twitter, Texas Attorney General Ken Paxton, a Republican, said.

## FBI crime report shows murders rose over 2020's historic number as midterms approach
 - [https://www.foxnews.com/us/fbi-crime-report-shows-murders-rose-over-2020s-historic-number-midterms-approach](https://www.foxnews.com/us/fbi-crime-report-shows-murders-rose-over-2020s-historic-number-midterms-approach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 06:00:39+00:00

Midterms are about a month away and a new national report from the FBI on crime for 2021 shows murders increased slightly over 2020's historically bloody year.

## Arizona families keep winning on school choice and more states need to follow our lead
 - [https://www.foxnews.com/opinion/arizona-families-keep-winning-school-choice-more-states-need-follow-our-lead](https://www.foxnews.com/opinion/arizona-families-keep-winning-school-choice-more-states-need-follow-our-lead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 06:00:17+00:00

Arizona families keep winning on school choice, defeating teachers union that tried to stop law even after it was signed. Here’s how to be victorious.

## Fetterman only has done four nationally televised interviews since May stroke
 - [https://www.foxnews.com/media/fetterman-only-has-done-four-nationally-televised-interviews-since-may-stroke](https://www.foxnews.com/media/fetterman-only-has-done-four-nationally-televised-interviews-since-may-stroke)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 06:00:02+00:00

Democratic Senate candidate John Fetterman has engaged in less than 10 interviews total since May, less than a third of interviews accepted by Dr. Mehmet Oz.

## Arizona Senate race debate: Democrat Mark Kelly, Republican Blake Masters clash over immigration, abortion
 - [https://www.foxnews.com/politics/arizona-senate-race-debate-democrat-mark-kelly-republican-blake-masters-clash-immigration-abortion](https://www.foxnews.com/politics/arizona-senate-race-debate-democrat-mark-kelly-republican-blake-masters-clash-immigration-abortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 04:43:08+00:00

Democrat Mark Kelly and Republican Blake Masters, the frontrunners in the Arizona Senate race, participated in a debate in Phoenix Thursday, alongside Libertarian nominee Marc Victor.

## GREG GUTFELD: Did New York City Councilwoman Tiffany Cabán call 911 after she urged businesses not to?
 - [https://www.foxnews.com/opinion/greg-gutfeld-new-york-city-councilwoman-tiffany-caban-call-911-urged-businesses-not-to](https://www.foxnews.com/opinion/greg-gutfeld-new-york-city-councilwoman-tiffany-caban-call-911-urged-businesses-not-to)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 04:34:55+00:00

Fox News host Greg Gutfeld tears into reports New York City Councilwoman Tiffany Cabán's office called 911 after receiving threatening phone calls as the councilwoman encouraged businesses against doing so themselves on "Gutfeld!"

## LAURA INGRAHAM: Diversity, equity and inclusion embeds itself into all aspects of corporate life
 - [https://www.foxnews.com/media/laura-ingraham-diversity-equity-inclusion-embeds-itself-all-aspects-corporate-life](https://www.foxnews.com/media/laura-ingraham-diversity-equity-inclusion-embeds-itself-all-aspects-corporate-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 04:29:34+00:00

Host Laura Ingraham discusses how the diversity, equity and inclusion initiatives absorbed into every aspect of corporate life on "The Ingraham Angle."

## On this day in history, Oct. 7, 1916, Georgia Tech football beats Cumberland 222-0
 - [https://www.foxnews.com/lifestyle/this-day-history-oct-7-georgia-tech-football-beats-cumberland-222-0](https://www.foxnews.com/lifestyle/this-day-history-oct-7-georgia-tech-football-beats-cumberland-222-0)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 04:02:58+00:00

The Georgia Tech Yellow Jackets, led by legendary coach John Heisman, routed Cumberland College 222-0 in the most lopsided game in college football history Oct. 7, 1916.

## Judy Tenuta, the 'Love Goddess' comedienne and actress, dead at 72
 - [https://www.foxnews.com/entertainment/judy-tenuta-the-love-goddess-comedienne-actress-dead-72](https://www.foxnews.com/entertainment/judy-tenuta-the-love-goddess-comedienne-actress-dead-72)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 03:57:46+00:00

The comedienne and actress Judy Tenuta, known as the "Love Goddess," died on Thursday at the age of 72. Her publicist confirmed that she died of ovarian cancer at her home in Los Angeles.

## Colts steal overtime win in sloppy touchdown-less game against Broncos
 - [https://www.foxnews.com/sports/colts-steal-overtime-win-sloppy-touchdown-less-game-broncos](https://www.foxnews.com/sports/colts-steal-overtime-win-sloppy-touchdown-less-game-broncos)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 03:55:20+00:00

The NFL's ugliest game of the year managed to have quite the ending. The Colts were awful all night, but when it mattered most, Matt Ryan and Chase McLaughlin were clutch.

## Kanye West claims he didn't know ex-wife Kim Kardashian was 'close to the Clintons'
 - [https://www.foxnews.com/media/kanye-west-claims-didnt-know-ex-wife-kim-kardashia-close-clintons](https://www.foxnews.com/media/kanye-west-claims-didnt-know-ex-wife-kim-kardashia-close-clintons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 03:38:11+00:00

The rapper now legally known as Ye spoke to Fox News' Tucker Carlson in a wide-ranging interview on Thursday night.

## New York Times columnist hopes an Elon Musk takeover 'destroys Twitter'
 - [https://www.foxnews.com/media/new-york-times-columnist-hopes-elon-musk-takeover-destroys-twitter](https://www.foxnews.com/media/new-york-times-columnist-hopes-elon-musk-takeover-destroys-twitter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 03:28:53+00:00

An opinion columnist from The New York Times openly announced her wish that potential owner Elon Musk makes Twitter worse, leading to its destruction.

## SEAN HANNITY: With 33 days until the midterms, Democrats are panicking
 - [https://www.foxnews.com/media/sean-hannity-33-days-midterms-democrats-panicking](https://www.foxnews.com/media/sean-hannity-33-days-midterms-democrats-panicking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 03:15:11+00:00

Fox News host Sean Hannity criticized Pennsylvania Democratic Senate candidate John Fetterman for his stance on crime as midterms near on "Hannity."

## 'Gutfeld!' on anti-police NYC councilwoman's hypocritical 911 call
 - [https://www.foxnews.com/transcript/gutfeld-anti-police-nyc-councilwomans-hypocritical-911-call](https://www.foxnews.com/transcript/gutfeld-anti-police-nyc-councilwomans-hypocritical-911-call)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 02:00:18+00:00

Guests: Morgan Ortagus, Robert Davi, Kat Timpf, Tyrus

## 'Hannity' on Democrats' stance ahead of midterms
 - [https://www.foxnews.com/transcript/hannity-democrats-stance-ahead-midterms](https://www.foxnews.com/transcript/hannity-democrats-stance-ahead-midterms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 01:00:28+00:00

This is a rush transcript from "Hannity," October 6, 2022

## Tucker Carlson: Is Kanye West crazy? You be the judge
 - [https://www.foxnews.com/transcript/tucker-carlson-kanye-west-crazy-judge](https://www.foxnews.com/transcript/tucker-carlson-kanye-west-crazy-judge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-07 00:00:49+00:00

This is a rush transcript of "Tucker Carlson Tonight" on October 6, 2022


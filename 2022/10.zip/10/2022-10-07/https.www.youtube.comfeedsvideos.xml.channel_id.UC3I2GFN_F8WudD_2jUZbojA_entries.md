# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Nation of Language - Automobile (Live on KEXP)
 - [https://www.youtube.com/watch?v=XYXpz51FtzQ](https://www.youtube.com/watch?v=XYXpz51FtzQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-07 00:00:00+00:00

http://KEXP.ORG presents Nation of Language performing “Automobile” live at THING festival at Fort Worden in Port Townsend, Washington. Recorded August 28, 2022.

Host: Morgan Chosnyk
KEXP Engineers: Julian Martlew & Matt Ogaz
Mixing & Mastering: Kevin Suggs
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Director: Scott Holpainen 
Editor: Jim Beckmann

https://www.nationoflanguage.com
http://kexp.org

## Nation of Language - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=0PzIKBwrcDc](https://www.youtube.com/watch?v=0PzIKBwrcDc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-07 00:00:00+00:00

http://KEXP.ORG presents Nation of Language performing live at THING festival at Fort Worden in Port Townsend, Washington. Recorded August 28, 2022.

Songs:
Miranda
September Again
Automobile
The Grey Commute

Host: Morgan Chosnyk
KEXP Engineers: Julian Martlew & Matt Ogaz
Mixing & Mastering: Kevin Suggs
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Director: Scott Holpainen 
Editor: Jim Beckmann

https://www.nationoflanguage.com
http://kexp.org

## Nation of Language - Miranda (Live on KEXP)
 - [https://www.youtube.com/watch?v=VF7MBRQHUTM](https://www.youtube.com/watch?v=VF7MBRQHUTM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-07 00:00:00+00:00

http://KEXP.ORG presents Nation of Language performing “Miranda” live at THING festival at Fort Worden in Port Townsend, Washington. Recorded August 28, 2022.

Host: Morgan Chosnyk
KEXP Engineers: Julian Martlew & Matt Ogaz
Mixing & Mastering: Kevin Suggs
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Director: Scott Holpainen 
Editor: Jim Beckmann

https://www.nationoflanguage.com
http://kexp.org

## Nation of Language - September Again (Live on KEXP)
 - [https://www.youtube.com/watch?v=Ixv72belKXo](https://www.youtube.com/watch?v=Ixv72belKXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-07 00:00:00+00:00

http://KEXP.ORG presents Nation of Language performing “September Again” live at THING festival at Fort Worden in Port Townsend, Washington. Recorded August 28, 2022.

Host: Morgan Chosnyk
KEXP Engineers: Julian Martlew & Matt Ogaz
Mixing & Mastering: Kevin Suggs
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Director: Scott Holpainen 
Editor: Jim Beckmann

https://www.nationoflanguage.com
http://kexp.org

## Nation of Language - The Grey Commute (Live on KEXP)
 - [https://www.youtube.com/watch?v=--pfTklzIJY](https://www.youtube.com/watch?v=--pfTklzIJY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-07 00:00:00+00:00

http://KEXP.ORG presents Nation of Language performing “The Grey Commute” live at THING festival at Fort Worden in Port Townsend, Washington. Recorded August 28, 2022.

Host: Morgan Chosnyk
KEXP Engineers: Julian Martlew & Matt Ogaz
Mixing & Mastering: Kevin Suggs
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Director: Scott Holpainen 
Editor: Jim Beckmann

https://www.nationoflanguage.com
http://kexp.org


# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Samsung warns of 32% hit to profits on chip slump
 - [https://www.bbc.co.uk/news/business-63167922?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63167922?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-10-07 04:54:04+00:00

Meanwhile, US chip maker AMD said its third quarter revenue would be $1bn less than forecasts.


# Source:ComputerWorld, URL:https://www.computerworld.com/index.rss, language:en-US

## Now your business can deploy virtual Mac desktops in the cloud
 - [https://www.computerworld.com/article/3676129/now-your-business-can-deploy-virtual-mac-desktops-in-the-cloud.html#tk.rss_all](https://www.computerworld.com/article/3676129/now-your-business-can-deploy-virtual-mac-desktops-in-the-cloud.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-10-07 15:50:00+00:00

<article>
	<section class="page">
<p><a href="https://www.computerworld.com/article/3619228/cloud-based-thin-client-macs-become-a-reality.html" rel="noopener" target="_blank">MacStadium</a> recently unveiled a virtual Mac desktop cloud solution, and because it's a unique option, I wanted to find out more about the company's thinking. So I reached out to MacStadium<span style="font-size: 15px;">’s Senior Vice President and CTO, Chris Chapman, to learn more about the company's thinking and strateh

## Is your company a ‘most loved' workplace? It should be
 - [https://www.computerworld.com/article/3676228/is-your-company-a-most-loved-workplace-it-should-be.html#tk.rss_all](https://www.computerworld.com/article/3676228/is-your-company-a-most-loved-workplace-it-should-be.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-10-07 15:35:00+00:00

<article>
	<section class="page">
<p><em>Disclosure: IBM and Dell are clients of the author.</em></p><p><em>Newsweek</em>’s Best Practices Institute has released its list of “<a href="https://www.newsweek.com/rankings/americas-100-most-loved-workplaces-2022" rel="noopener nofollow" target="_blank">Most Loved Workplaces</a>” and this year, there’s a clear focus from respondents on working from home. That's an important insight for companies to keep in mind at a time when the “<a href="https://www

## How to turn your car into the ultimate mobile office
 - [https://www.computerworld.com/article/3674772/how-to-turn-your-car-into-ultimate-mobile-office.html#tk.rss_all](https://www.computerworld.com/article/3674772/how-to-turn-your-car-into-ultimate-mobile-office.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-10-07 10:00:00+00:00

<article>
	<section class="page">
<p>Now that you’re used to working outside the corporate office, it’s time to stretch the boundaries beyond the kitchen table or guest bedroom to the ultimate mobile office. It might lack four walls and a water cooler, but your car offers a killer corner-office view of the world and can let you work just about anywhere.</p><p>Salespeople, insurance adjusters, utility workers, and many others have long understood the benefits of working out of a car. In a very re


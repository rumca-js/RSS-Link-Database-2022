# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## Number of Amazon’s new holiday recruits equals population of Pasadena
 - [https://www.digitaltrends.com/news/amazon-needs-150000-new-workers-for-holiday-rush/](https://www.digitaltrends.com/news/amazon-needs-150000-new-workers-for-holiday-rush/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2022-10-07 10:37:16.265258+00:00

Amazon is aiming to hire as many 150,000 extra workers across the U.S. for the holiday season, with sign-on bonuses of up to $3,000 offered in some locations.

## Microsoft says disabling these two Windows 11 features will boost gaming performance
 - [https://www.digitaltrends.com/computing/microsoft-windows-11-settings-affect-games/](https://www.digitaltrends.com/computing/microsoft-windows-11-settings-affect-games/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2022-10-07 06:26:52.817150+00:00

Microsoft has just announced that some of the settings in Windows 11 can slow down gaming performance. Here's how to disable them.

## Amazon’s Scout robot appears to have made its last delivery
 - [https://www.digitaltrends.com/news/amazon-ends-field-tests-scout-delivery-robot/](https://www.digitaltrends.com/news/amazon-ends-field-tests-scout-delivery-robot/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2022-10-07 06:26:52.809778+00:00

Amazon has announced it's ending field tests of its Scout delivery robot nearly four years after it unveiled the machine.


# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## What Is Bayesian/Frequentist Inference? (2012)
 - [https://normaldeviate.wordpress.com/2012/11/17/what-is-bayesianfrequentist-inference/](https://normaldeviate.wordpress.com/2012/11/17/what-is-bayesianfrequentist-inference/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 23:33:21+00:00

<p>Article URL: <a href="https://normaldeviate.wordpress.com/2012/11/17/what-is-bayesianfrequentist-inference/">https://normaldeviate.wordpress.com/2012/11/17/what-is-bayesianfrequentist-inference/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33128272">https://news.ycombinator.com/item?id=33128272</a></p>
<p>Points: 51</p>
<p># Comments: 12</p>

## Patients can now access all their health records digitally
 - [https://www.statnews.com/2022/10/06/health-data-information-blocking-records/](https://www.statnews.com/2022/10/06/health-data-information-blocking-records/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 22:44:48+00:00

<p>Article URL: <a href="https://www.statnews.com/2022/10/06/health-data-information-blocking-records/">https://www.statnews.com/2022/10/06/health-data-information-blocking-records/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33127810">https://news.ycombinator.com/item?id=33127810</a></p>
<p>Points: 15</p>
<p># Comments: 2</p>

## Retinoid restores eye-specific brain responses in mice with retinal degeneration
 - [https://www.cell.com/current-biology/fulltext/S0960-9822(22)01449-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS096098222201449X%3Fshowall%3Dtrue](https://www.cell.com/current-biology/fulltext/S0960-9822(22)01449-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS096098222201449X%3Fshowall%3Dtrue)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 22:30:22+00:00

<p>Article URL: <a href="https://www.cell.com/current-biology/fulltext/S0960-9822(22)01449-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS096098222201449X%3Fshowall%3Dtrue">https://www.cell.com/current-biology/fulltext/S0960-9822(22)01449-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS096098222201449X%3Fshowall%3Dtrue</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33127646">https://news.ycombinator.com/item?id=33127646</a></

## Is the FSF Fighting the Previous War?
 - [https://irreal.org/blog/?p=10864](https://irreal.org/blog/?p=10864)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 22:09:03+00:00

<p>Article URL: <a href="https://irreal.org/blog/?p=10864">https://irreal.org/blog/?p=10864</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33127463">https://news.ycombinator.com/item?id=33127463</a></p>
<p>Points: 10</p>
<p># Comments: 7</p>

## Lufthansa bans AirTags in checked luggage
 - [https://onemileatatime.com/news/lufthansa-bans-airtags/](https://onemileatatime.com/news/lufthansa-bans-airtags/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 22:07:59+00:00

<p>Article URL: <a href="https://onemileatatime.com/news/lufthansa-bans-airtags/">https://onemileatatime.com/news/lufthansa-bans-airtags/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33127459">https://news.ycombinator.com/item?id=33127459</a></p>
<p>Points: 52</p>
<p># Comments: 9</p>

## 4x4 ASCII Font
 - [https://simplifier.neocities.org/4x4.html](https://simplifier.neocities.org/4x4.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 22:02:09+00:00

<p>Article URL: <a href="https://simplifier.neocities.org/4x4.html">https://simplifier.neocities.org/4x4.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33127419">https://news.ycombinator.com/item?id=33127419</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## How I Made a Self-Quoting Tweet
 - [https://oisinmoran.com/quinetweet](https://oisinmoran.com/quinetweet)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 21:48:20+00:00

<p>Article URL: <a href="https://oisinmoran.com/quinetweet">https://oisinmoran.com/quinetweet</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33127285">https://news.ycombinator.com/item?id=33127285</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Jewish Calendar Demystified
 - [https://stevemorse.org/hebrewcalendar/hebrewcalendar.htm](https://stevemorse.org/hebrewcalendar/hebrewcalendar.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 20:46:29+00:00

<p>Article URL: <a href="https://stevemorse.org/hebrewcalendar/hebrewcalendar.htm">https://stevemorse.org/hebrewcalendar/hebrewcalendar.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33126676">https://news.ycombinator.com/item?id=33126676</a></p>
<p>Points: 14</p>
<p># Comments: 0</p>

## Blogless – Writing articles online without a blog (2021)
 - [https://blogless.datenbrei.de/](https://blogless.datenbrei.de/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 20:44:54+00:00

<p>Article URL: <a href="https://blogless.datenbrei.de/">https://blogless.datenbrei.de/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33126664">https://news.ycombinator.com/item?id=33126664</a></p>
<p>Points: 39</p>
<p># Comments: 13</p>

## Deep Learning Is Hitting a Wall
 - [https://nautil.us/deep-learning-is-hitting-a-wall-238440/](https://nautil.us/deep-learning-is-hitting-a-wall-238440/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 20:13:47+00:00

<p>Article URL: <a href="https://nautil.us/deep-learning-is-hitting-a-wall-238440/">https://nautil.us/deep-learning-is-hitting-a-wall-238440/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33126364">https://news.ycombinator.com/item?id=33126364</a></p>
<p>Points: 12</p>
<p># Comments: 2</p>

## Ukraine officially recognized the Northern Territories as part of Japan
 - [https://www.president.gov.ua/documents/6922022-44369](https://www.president.gov.ua/documents/6922022-44369)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 20:09:51+00:00

<p>Article URL: <a href="https://www.president.gov.ua/documents/6922022-44369">https://www.president.gov.ua/documents/6922022-44369</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33126316">https://news.ycombinator.com/item?id=33126316</a></p>
<p>Points: 57</p>
<p># Comments: 31</p>

## Apple’s use of Swift and SwiftUI in iOS 16
 - [https://blog.timac.org/2022/1005-state-of-swift-and-swiftui-ios16/](https://blog.timac.org/2022/1005-state-of-swift-and-swiftui-ios16/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 20:00:38+00:00

<p>Article URL: <a href="https://blog.timac.org/2022/1005-state-of-swift-and-swiftui-ios16/">https://blog.timac.org/2022/1005-state-of-swift-and-swiftui-ios16/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33126223">https://news.ycombinator.com/item?id=33126223</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## Big U.S. Banks Are Stiffing Account Takeover Victims
 - [https://krebsonsecurity.com/2022/10/report-big-u-s-banks-are-stiffing-account-takeover-victims/](https://krebsonsecurity.com/2022/10/report-big-u-s-banks-are-stiffing-account-takeover-victims/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 18:54:38+00:00

<p>Article URL: <a href="https://krebsonsecurity.com/2022/10/report-big-u-s-banks-are-stiffing-account-takeover-victims/">https://krebsonsecurity.com/2022/10/report-big-u-s-banks-are-stiffing-account-takeover-victims/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33125442">https://news.ycombinator.com/item?id=33125442</a></p>
<p>Points: 34</p>
<p># Comments: 13</p>

## Overzealous Destructuring
 - [https://www.aleksandrhovhannisyan.com/blog/overzealous-destructuring/](https://www.aleksandrhovhannisyan.com/blog/overzealous-destructuring/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 18:48:29+00:00

<p>Article URL: <a href="https://www.aleksandrhovhannisyan.com/blog/overzealous-destructuring/">https://www.aleksandrhovhannisyan.com/blog/overzealous-destructuring/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33125383">https://news.ycombinator.com/item?id=33125383</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Gcloud storage: up to 94% faster data transfers for Cloud Storage
 - [https://cloud.google.com/blog/products/storage-data-transfer/new-gcloud-storage-cli-for-your-data-transfers](https://cloud.google.com/blog/products/storage-data-transfer/new-gcloud-storage-cli-for-your-data-transfers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 18:31:49+00:00

<p>Article URL: <a href="https://cloud.google.com/blog/products/storage-data-transfer/new-gcloud-storage-cli-for-your-data-transfers">https://cloud.google.com/blog/products/storage-data-transfer/new-gcloud-storage-cli-for-your-data-transfers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33125176">https://news.ycombinator.com/item?id=33125176</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Nuclear Close Calls: Able Archer 83 (2018)
 - [https://www.atomicheritage.org/history/nuclear-close-calls-able-archer-83](https://www.atomicheritage.org/history/nuclear-close-calls-able-archer-83)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 18:30:56+00:00

<p>Article URL: <a href="https://www.atomicheritage.org/history/nuclear-close-calls-able-archer-83">https://www.atomicheritage.org/history/nuclear-close-calls-able-archer-83</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33125164">https://news.ycombinator.com/item?id=33125164</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## My Favourite Computer, an Old Mac
 - [http://muezza.ca/thoughts/favourite_computer/](http://muezza.ca/thoughts/favourite_computer/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 18:14:00+00:00

<p>Article URL: <a href="http://muezza.ca/thoughts/favourite_computer/">http://muezza.ca/thoughts/favourite_computer/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33124986">https://news.ycombinator.com/item?id=33124986</a></p>
<p>Points: 59</p>
<p># Comments: 21</p>

## Show HN: PyTorch search engine
 - [https://you.com/niche/pytorch?q=initialize+weights&fromSearchBar=true](https://you.com/niche/pytorch?q=initialize+weights&fromSearchBar=true)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 18:08:06+00:00

<p>Article URL: <a href="https://you.com/niche/pytorch?q=initialize+weights&amp;fromSearchBar=true">https://you.com/niche/pytorch?q=initialize+weights&amp;fromSearchBar=true</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33124917">https://news.ycombinator.com/item?id=33124917</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## I changed my mind about writing new JavaScript frameworks
 - [https://whitep4nth3r.com/blog/write-a-new-javascript-framework/](https://whitep4nth3r.com/blog/write-a-new-javascript-framework/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 18:07:14+00:00

<p>Article URL: <a href="https://whitep4nth3r.com/blog/write-a-new-javascript-framework/">https://whitep4nth3r.com/blog/write-a-new-javascript-framework/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33124905">https://news.ycombinator.com/item?id=33124905</a></p>
<p>Points: 6</p>
<p># Comments: 3</p>

## Papa John's sued for 'wiretap' spying on website mouse clicks, keystrokes
 - [https://www.theregister.com/2022/10/06/papa_johns_spying_lawsuit/](https://www.theregister.com/2022/10/06/papa_johns_spying_lawsuit/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 17:59:08+00:00

<p>Article URL: <a href="https://www.theregister.com/2022/10/06/papa_johns_spying_lawsuit/">https://www.theregister.com/2022/10/06/papa_johns_spying_lawsuit/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33124796">https://news.ycombinator.com/item?id=33124796</a></p>
<p>Points: 44</p>
<p># Comments: 32</p>

## MIMD Interpretation on a GPU [pdf]
 - [http://aggregate.ee.engr.uky.edu/EXHIBITS/SC09/mogsimlcpc09final.pdf](http://aggregate.ee.engr.uky.edu/EXHIBITS/SC09/mogsimlcpc09final.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 17:03:47+00:00

<p>Article URL: <a href="http://aggregate.ee.engr.uky.edu/EXHIBITS/SC09/mogsimlcpc09final.pdf">http://aggregate.ee.engr.uky.edu/EXHIBITS/SC09/mogsimlcpc09final.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33124034">https://news.ycombinator.com/item?id=33124034</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## UPchieve (YC W21) is hiring a tech lead and senior engineers
 - [https://upchieve.welcomekit.co/](https://upchieve.welcomekit.co/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 17:00:23+00:00

<p>Article URL: <a href="https://upchieve.welcomekit.co/">https://upchieve.welcomekit.co/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33123988">https://news.ycombinator.com/item?id=33123988</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Vectors are over, hashes are the future
 - [https://www.algolia.com/blog/ai/vectors-vs-hashes/](https://www.algolia.com/blog/ai/vectors-vs-hashes/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 16:59:11+00:00

<p>Article URL: <a href="https://www.algolia.com/blog/ai/vectors-vs-hashes/">https://www.algolia.com/blog/ai/vectors-vs-hashes/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33123972">https://news.ycombinator.com/item?id=33123972</a></p>
<p>Points: 30</p>
<p># Comments: 4</p>

## JetBrains Ring UI
 - [https://jetbrains.github.io/ring-ui/master/index.html](https://jetbrains.github.io/ring-ui/master/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 16:57:15+00:00

<p>Article URL: <a href="https://jetbrains.github.io/ring-ui/master/index.html">https://jetbrains.github.io/ring-ui/master/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33123948">https://news.ycombinator.com/item?id=33123948</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Recursion got into programming: intrigue, betrayal, and advanced semantics
 - [https://vanemden.wordpress.com/2014/06/18/how-recursion-got-into-programming-a-comedy-of-errors-3/](https://vanemden.wordpress.com/2014/06/18/how-recursion-got-into-programming-a-comedy-of-errors-3/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 16:55:12+00:00

<p>Article URL: <a href="https://vanemden.wordpress.com/2014/06/18/how-recursion-got-into-programming-a-comedy-of-errors-3/">https://vanemden.wordpress.com/2014/06/18/how-recursion-got-into-programming-a-comedy-of-errors-3/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33123916">https://news.ycombinator.com/item?id=33123916</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## How to distort Scrum until it no longer works
 - [https://lucasfcosta.com/2022/10/04/distorting-scrum.html](https://lucasfcosta.com/2022/10/04/distorting-scrum.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 16:48:06+00:00

<p>Article URL: <a href="https://lucasfcosta.com/2022/10/04/distorting-scrum.html">https://lucasfcosta.com/2022/10/04/distorting-scrum.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33123807">https://news.ycombinator.com/item?id=33123807</a></p>
<p>Points: 18</p>
<p># Comments: 25</p>

## Ask HN: Have you noticed an increase in the number of Stripe Disputes lately?
 - [https://news.ycombinator.com/item?id=33123756](https://news.ycombinator.com/item?id=33123756)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 16:44:37+00:00

<p>I work on a SaaS app in France. In the past few days we noticed an enormous increase of disputes in our Stripe account, all of them are linked to SEPA payment method (wire).<p>We used to have 1 every month of so, now we have had around 7 in 2 days.<p>[EDIT] - I received an email from Stripe a few minutes after I submitted this post on HN. It seems there has been an issue with the management of SEPA payments between end of september and start of october.</p>
<hr />
<p>Comments URL: <a href="ht

## Why Mastering Language Is So Difficult for AI
 - [https://undark.org/2022/10/07/interview-why-mastering-language-is-so-difficult-for-ai/](https://undark.org/2022/10/07/interview-why-mastering-language-is-so-difficult-for-ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 16:43:12+00:00

<p>Article URL: <a href="https://undark.org/2022/10/07/interview-why-mastering-language-is-so-difficult-for-ai/">https://undark.org/2022/10/07/interview-why-mastering-language-is-so-difficult-for-ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33123736">https://news.ycombinator.com/item?id=33123736</a></p>
<p>Points: 15</p>
<p># Comments: 3</p>

## The QNX Demo Disk: a full xNix OS, with GUI and browser, on just 1 1.4MB floppy
 - [http://qnx.puslapiai.lt/qnxdemo/qnx_demo_disk.htm](http://qnx.puslapiai.lt/qnxdemo/qnx_demo_disk.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 16:40:48+00:00

<p>Article URL: <a href="http://qnx.puslapiai.lt/qnxdemo/qnx_demo_disk.htm">http://qnx.puslapiai.lt/qnxdemo/qnx_demo_disk.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33123697">https://news.ycombinator.com/item?id=33123697</a></p>
<p>Points: 38</p>
<p># Comments: 6</p>

## The AI Scaling Hypothesis
 - [https://lastweekin.ai/p/the-ai-scaling-hypothesis](https://lastweekin.ai/p/the-ai-scaling-hypothesis)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 16:29:04+00:00

<p>Article URL: <a href="https://lastweekin.ai/p/the-ai-scaling-hypothesis">https://lastweekin.ai/p/the-ai-scaling-hypothesis</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33123514">https://news.ycombinator.com/item?id=33123514</a></p>
<p>Points: 17</p>
<p># Comments: 6</p>

## !!Con 2022
 - [https://bangbangcon.com/](https://bangbangcon.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 15:34:28+00:00

<p>Article URL: <a href="https://bangbangcon.com/">https://bangbangcon.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33122729">https://news.ycombinator.com/item?id=33122729</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## School vs. Wikipedia
 - [http://ratfactor.com/rss-club/school-vs-wikipedia](http://ratfactor.com/rss-club/school-vs-wikipedia)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 15:33:00+00:00

<p>Article URL: <a href="http://ratfactor.com/rss-club/school-vs-wikipedia">http://ratfactor.com/rss-club/school-vs-wikipedia</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33122705">https://news.ycombinator.com/item?id=33122705</a></p>
<p>Points: 37</p>
<p># Comments: 25</p>

## AWS doesn't make sense for scientific computing
 - [https://www.noahlebovic.com/aws-doesnt-make-sense-for-scientific-computing/](https://www.noahlebovic.com/aws-doesnt-make-sense-for-scientific-computing/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 15:28:50+00:00

<p>Article URL: <a href="https://www.noahlebovic.com/aws-doesnt-make-sense-for-scientific-computing/">https://www.noahlebovic.com/aws-doesnt-make-sense-for-scientific-computing/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33122656">https://news.ycombinator.com/item?id=33122656</a></p>
<p>Points: 29</p>
<p># Comments: 17</p>

## Ask HN: Was it worth it for Go to add generics
 - [https://news.ycombinator.com/item?id=33122514](https://news.ycombinator.com/item?id=33122514)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 15:18:22+00:00

<p>Adding Generics seemed like a massive effort, but I don’t see any major changes to existing or new Go code since their release. Maybe they weren’t so important?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33122514">https://news.ycombinator.com/item?id=33122514</a></p>
<p>Points: 20</p>
<p># Comments: 19</p>

## Mortal Kombat+
 - [https://mortalkombat.plus](https://mortalkombat.plus)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 14:49:04+00:00

<p>Article URL: <a href="https://mortalkombat.plus">https://mortalkombat.plus</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33122122">https://news.ycombinator.com/item?id=33122122</a></p>
<p>Points: 34</p>
<p># Comments: 8</p>

## RacketCon 2022
 - [https://con.racket-lang.org](https://con.racket-lang.org)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 14:37:55+00:00

<p>Article URL: <a href="https://con.racket-lang.org">https://con.racket-lang.org</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33121976">https://news.ycombinator.com/item?id=33121976</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## Using Notion as a headless CMS for our blog
 - [https://datanarratives.com/blog/notion-headless-cms/](https://datanarratives.com/blog/notion-headless-cms/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 14:14:33+00:00

<p>Article URL: <a href="https://datanarratives.com/blog/notion-headless-cms/">https://datanarratives.com/blog/notion-headless-cms/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33121628">https://news.ycombinator.com/item?id=33121628</a></p>
<p>Points: 27</p>
<p># Comments: 12</p>

## Signal is secure, as proven by hackers
 - [https://www.kaspersky.co.uk/blog/signal-hacked-but-still-secure/24864/](https://www.kaspersky.co.uk/blog/signal-hacked-but-still-secure/24864/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 13:27:36+00:00

<p>Article URL: <a href="https://www.kaspersky.co.uk/blog/signal-hacked-but-still-secure/24864/">https://www.kaspersky.co.uk/blog/signal-hacked-but-still-secure/24864/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33120969">https://news.ycombinator.com/item?id=33120969</a></p>
<p>Points: 18</p>
<p># Comments: 2</p>

## The Pursuit of Beauty (2015)
 - [https://www.newyorker.com/magazine/2015/02/02/pursuit-beauty](https://www.newyorker.com/magazine/2015/02/02/pursuit-beauty)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 13:24:52+00:00

<p>Article URL: <a href="https://www.newyorker.com/magazine/2015/02/02/pursuit-beauty">https://www.newyorker.com/magazine/2015/02/02/pursuit-beauty</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33120929">https://news.ycombinator.com/item?id=33120929</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Gmail 2FA causes the homeless to permanently lose access 3 times a year
 - [https://twitter.com/chadloder/status/1577880638044020736](https://twitter.com/chadloder/status/1577880638044020736)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 12:51:09+00:00

<p>Article URL: <a href="https://twitter.com/chadloder/status/1577880638044020736">https://twitter.com/chadloder/status/1577880638044020736</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33120534">https://news.ycombinator.com/item?id=33120534</a></p>
<p>Points: 33</p>
<p># Comments: 19</p>

## Mastodon.technology Shutdown
 - [https://ashfurrow.com/blog/mastodon-technology-shutdown/](https://ashfurrow.com/blog/mastodon-technology-shutdown/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 12:08:10+00:00

<p>Article URL: <a href="https://ashfurrow.com/blog/mastodon-technology-shutdown/">https://ashfurrow.com/blog/mastodon-technology-shutdown/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33120136">https://news.ycombinator.com/item?id=33120136</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Fractional (YC W21) Is Hiring Product Engineers
 - [https://www.ycombinator.com/companies/fractional/jobs/YftyxZJ-product-engineer](https://www.ycombinator.com/companies/fractional/jobs/YftyxZJ-product-engineer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 12:01:06+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/fractional/jobs/YftyxZJ-product-engineer">https://www.ycombinator.com/companies/fractional/jobs/YftyxZJ-product-engineer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33120075">https://news.ycombinator.com/item?id=33120075</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## $570M worth of Binance’s BNB token stolen
 - [https://www.cnbc.com/2022/10/07/more-than-100-million-worth-of-binances-bnb-token-stolen-in-another-major-crypto-hack.html](https://www.cnbc.com/2022/10/07/more-than-100-million-worth-of-binances-bnb-token-stolen-in-another-major-crypto-hack.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 11:51:24+00:00

<p>Article URL: <a href="https://www.cnbc.com/2022/10/07/more-than-100-million-worth-of-binances-bnb-token-stolen-in-another-major-crypto-hack.html">https://www.cnbc.com/2022/10/07/more-than-100-million-worth-of-binances-bnb-token-stolen-in-another-major-crypto-hack.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33120000">https://news.ycombinator.com/item?id=33120000</a></p>
<p>Points: 21</p>
<p># Comments: 2</p>

## U.S. residents fight for the right to hang laundry (2009)
 - [https://www.reuters.com/article/us-usa-laundry-idUSTRE5AH3JQ20091118](https://www.reuters.com/article/us-usa-laundry-idUSTRE5AH3JQ20091118)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 11:44:31+00:00

<p>Article URL: <a href="https://www.reuters.com/article/us-usa-laundry-idUSTRE5AH3JQ20091118">https://www.reuters.com/article/us-usa-laundry-idUSTRE5AH3JQ20091118</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33119961">https://news.ycombinator.com/item?id=33119961</a></p>
<p>Points: 14</p>
<p># Comments: 10</p>

## RIAA Thwarts Yout’s Attempt to Declare YouTube-Ripping Legal
 - [https://torrentfreak.com/riaa-thwarts-youts-attempt-to-declare-youtube-ripping-legal-221002/](https://torrentfreak.com/riaa-thwarts-youts-attempt-to-declare-youtube-ripping-legal-221002/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 11:30:50+00:00

<p>Article URL: <a href="https://torrentfreak.com/riaa-thwarts-youts-attempt-to-declare-youtube-ripping-legal-221002/">https://torrentfreak.com/riaa-thwarts-youts-attempt-to-declare-youtube-ripping-legal-221002/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33119858">https://news.ycombinator.com/item?id=33119858</a></p>
<p>Points: 24</p>
<p># Comments: 12</p>

## Reality is just a game now
 - [https://www.thenewatlantis.com/publications/reality-is-just-a-game-now](https://www.thenewatlantis.com/publications/reality-is-just-a-game-now)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 11:23:18+00:00

<p>Article URL: <a href="https://www.thenewatlantis.com/publications/reality-is-just-a-game-now">https://www.thenewatlantis.com/publications/reality-is-just-a-game-now</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33119801">https://news.ycombinator.com/item?id=33119801</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Self-Referential Tweet
 - [https://twitter.com/slweeb/status/1578155161347710976](https://twitter.com/slweeb/status/1578155161347710976)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 10:46:01+00:00

<p>Article URL: <a href="https://twitter.com/slweeb/status/1578155161347710976">https://twitter.com/slweeb/status/1578155161347710976</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33119552">https://news.ycombinator.com/item?id=33119552</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Managers with a business degree reduce employees' wages, do not increase profit
 - [https://www.nber.org/papers/w29874](https://www.nber.org/papers/w29874)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 10:34:26+00:00

<p>Article URL: <a href="https://www.nber.org/papers/w29874">https://www.nber.org/papers/w29874</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33119486">https://news.ycombinator.com/item?id=33119486</a></p>
<p>Points: 36</p>
<p># Comments: 7</p>

## 10k hours rule to master anything. Could I switch career when I am 43?
 - [https://news.ycombinator.com/item?id=33119347](https://news.ycombinator.com/item?id=33119347)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 10:10:04+00:00

<p>Throughout his book "M. Outliers: The Story of Success.", Gladwell repeatedly refers to the “10 000-hour rule,” asserting that the key to achieving true expertise in any skill is simply a matter of practicing. It could be the greatest practice myth. My american boss founded my company in Viet Nam when he was 55. I admire him a lot. Nonetheless, I am still afraid of switching to other job because time is running out when i am older. A lot of my friends who are technical guys think so.  Any adv

## All the stupid startup/app ideas I've had so far
 - [https://news.ycombinator.com/item?id=33119246](https://news.ycombinator.com/item?id=33119246)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 09:50:21+00:00

<p>Here is the list of all ideas I've had so far but never actually took time to create any of them or go further into details<p>- Church givings - not sure how it's called, but in Christianity while being in Church a person goes around and asks for the money from people, so people give a dollar or few cents. So some kind of app that does that on global scale for the Church<p>- Would you do it for a dollar? - I even coded this. Basically person can ask someone else: would you _____ for a dollar?

## Why Is The Guitar Tuned Like It Is?
 - [https://library.kiwix.org/music.stackexchange.com_en_all_2022-05/questions/1723/why-is-the-guitar-tuned-like-it-is](https://library.kiwix.org/music.stackexchange.com_en_all_2022-05/questions/1723/why-is-the-guitar-tuned-like-it-is)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 09:09:07+00:00

<p>Article URL: <a href="https://library.kiwix.org/music.stackexchange.com_en_all_2022-05/questions/1723/why-is-the-guitar-tuned-like-it-is">https://library.kiwix.org/music.stackexchange.com_en_all_2022-05/questions/1723/why-is-the-guitar-tuned-like-it-is</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33118994">https://news.ycombinator.com/item?id=33118994</a></p>
<p>Points: 18</p>
<p># Comments: 8</p>

## The Nobel Peace Prize 2022
 - [https://www.nobelpeaceprize.org/articles/nobel-peace-prize-for-2022](https://www.nobelpeaceprize.org/articles/nobel-peace-prize-for-2022)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 09:03:12+00:00

<p>Article URL: <a href="https://www.nobelpeaceprize.org/articles/nobel-peace-prize-for-2022">https://www.nobelpeaceprize.org/articles/nobel-peace-prize-for-2022</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33118952">https://news.ycombinator.com/item?id=33118952</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Ask HN: What's Your Biggest Regret?
 - [https://news.ycombinator.com/item?id=33118584](https://news.ycombinator.com/item?id=33118584)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 08:06:57+00:00

<p>If you could change anything about your past, what would it be?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33118584">https://news.ycombinator.com/item?id=33118584</a></p>
<p>Points: 5</p>
<p># Comments: 8</p>

## Transmission 4.0.0 beta 1 is out
 - [https://github.com/transmission/transmission/releases/tag/4.0.0-beta.1](https://github.com/transmission/transmission/releases/tag/4.0.0-beta.1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 07:46:47+00:00

<p>Article URL: <a href="https://github.com/transmission/transmission/releases/tag/4.0.0-beta.1">https://github.com/transmission/transmission/releases/tag/4.0.0-beta.1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33118471">https://news.ycombinator.com/item?id=33118471</a></p>
<p>Points: 32</p>
<p># Comments: 11</p>

## PhotoRoom Is Hiring a Senior Web Developer (WebAssembly, WebGL and React) in Paris
 - [https://jobs.lever.co/photoroom/ac3a361b-aa5e-479d-95d6-434d73e6eb33](https://jobs.lever.co/photoroom/ac3a361b-aa5e-479d-95d6-434d73e6eb33)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 07:00:35+00:00

<p>Article URL: <a href="https://jobs.lever.co/photoroom/ac3a361b-aa5e-479d-95d6-434d73e6eb33">https://jobs.lever.co/photoroom/ac3a361b-aa5e-479d-95d6-434d73e6eb33</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33118243">https://news.ycombinator.com/item?id=33118243</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Longevity of Recordable CDs, DVDs and Blu-Rays
 - [https://www.canada.ca/en/conservation-institute/services/conservation-preservation-publications/canadian-conservation-institute-notes/longevity-recordable-cds-dvds.html](https://www.canada.ca/en/conservation-institute/services/conservation-preservation-publications/canadian-conservation-institute-notes/longevity-recordable-cds-dvds.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 05:39:48+00:00

<p>Article URL: <a href="https://www.canada.ca/en/conservation-institute/services/conservation-preservation-publications/canadian-conservation-institute-notes/longevity-recordable-cds-dvds.html">https://www.canada.ca/en/conservation-institute/services/conservation-preservation-publications/canadian-conservation-institute-notes/longevity-recordable-cds-dvds.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33117813">https://news.ycombinator.com/item?id=33117813</a></p>
<

## Stateless – Your new state of find with Elasticsearch
 - [https://www.elastic.co/blog/stateless-your-new-state-of-find-with-elasticsearch](https://www.elastic.co/blog/stateless-your-new-state-of-find-with-elasticsearch)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 05:14:03+00:00

<p>Article URL: <a href="https://www.elastic.co/blog/stateless-your-new-state-of-find-with-elasticsearch">https://www.elastic.co/blog/stateless-your-new-state-of-find-with-elasticsearch</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33117681">https://news.ycombinator.com/item?id=33117681</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## Evrard D'Espinque’s Illuminations of De Proprietatibus Rerum (Ca. 1480)
 - [https://publicdomainreview.org/collection/despinque-anglicus-illuminations/](https://publicdomainreview.org/collection/despinque-anglicus-illuminations/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 05:08:55+00:00

<p>Article URL: <a href="https://publicdomainreview.org/collection/despinque-anglicus-illuminations/">https://publicdomainreview.org/collection/despinque-anglicus-illuminations/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33117656">https://news.ycombinator.com/item?id=33117656</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Apache Pegasus – A a distributed key-value storage system
 - [https://github.com/apache/incubator-pegasus](https://github.com/apache/incubator-pegasus)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 05:06:47+00:00

<p>Article URL: <a href="https://github.com/apache/incubator-pegasus">https://github.com/apache/incubator-pegasus</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33117650">https://news.ycombinator.com/item?id=33117650</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## On AlphaTensor’s new matrix multiplication algorithms
 - [https://fgiesen.wordpress.com/2022/10/06/on-alphatensors-new-matrix-multiplication-algorithms/](https://fgiesen.wordpress.com/2022/10/06/on-alphatensors-new-matrix-multiplication-algorithms/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 03:45:20+00:00

<p>Article URL: <a href="https://fgiesen.wordpress.com/2022/10/06/on-alphatensors-new-matrix-multiplication-algorithms/">https://fgiesen.wordpress.com/2022/10/06/on-alphatensors-new-matrix-multiplication-algorithms/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33117192">https://news.ycombinator.com/item?id=33117192</a></p>
<p>Points: 39</p>
<p># Comments: 5</p>

## Startup Builds Houses by Pumping Concrete into Inflatable Forms
 - [https://singularityhub.com/2022/10/06/this-startup-builds-houses-by-pumping-concrete-into-inflatable-forms/](https://singularityhub.com/2022/10/06/this-startup-builds-houses-by-pumping-concrete-into-inflatable-forms/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 03:42:36+00:00

<p>Article URL: <a href="https://singularityhub.com/2022/10/06/this-startup-builds-houses-by-pumping-concrete-into-inflatable-forms/">https://singularityhub.com/2022/10/06/this-startup-builds-houses-by-pumping-concrete-into-inflatable-forms/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33117180">https://news.ycombinator.com/item?id=33117180</a></p>
<p>Points: 21</p>
<p># Comments: 21</p>

## “If plan A is for you to take multiple rounds of .308 in your back...” (2000)
 - [https://web.archive.org/web/20040706001343/http://www.mallninja.com/Am%20I%20Being%20Careful%20Enough%20-%20Glock%20Talk.htm](https://web.archive.org/web/20040706001343/http://www.mallninja.com/Am%20I%20Being%20Careful%20Enough%20-%20Glock%20Talk.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 03:17:37+00:00

<p>Article URL: <a href="https://web.archive.org/web/20040706001343/http://www.mallninja.com/Am%20I%20Being%20Careful%20Enough%20-%20Glock%20Talk.htm">https://web.archive.org/web/20040706001343/http://www.mallninja.com/Am%20I%20Being%20Careful%20Enough%20-%20Glock%20Talk.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33117044">https://news.ycombinator.com/item?id=33117044</a></p>
<p>Points: 15</p>
<p># Comments: 4</p>

## Celsius exposes the names of all customers
 - [https://web3isgoinggreat.com/single/celsius-exposes-the-names-of-all-customers-and-their-recent-transactions-in-court-filing--including-their-execs](https://web3isgoinggreat.com/single/celsius-exposes-the-names-of-all-customers-and-their-recent-transactions-in-court-filing--including-their-execs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 02:58:00+00:00

<p>Article URL: <a href="https://web3isgoinggreat.com/single/celsius-exposes-the-names-of-all-customers-and-their-recent-transactions-in-court-filing--including-their-execs">https://web3isgoinggreat.com/single/celsius-exposes-the-names-of-all-customers-and-their-recent-transactions-in-court-filing--including-their-execs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33116940">https://news.ycombinator.com/item?id=33116940</a></p>
<p>Points: 50</p>
<p># Comments: 15</p>

## Study links omega-3s to improved brain structure, cognition at midlife
 - [https://news.uthscsa.edu/study-links-omega-3s-to-improved-brain-structure-cognition-at-midlife/](https://news.uthscsa.edu/study-links-omega-3s-to-improved-brain-structure-cognition-at-midlife/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 02:29:06+00:00

<p>Article URL: <a href="https://news.uthscsa.edu/study-links-omega-3s-to-improved-brain-structure-cognition-at-midlife/">https://news.uthscsa.edu/study-links-omega-3s-to-improved-brain-structure-cognition-at-midlife/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33116762">https://news.ycombinator.com/item?id=33116762</a></p>
<p>Points: 89</p>
<p># Comments: 54</p>

## Why doesn't Bash's `set -e` do what I expected?
 - [http://mywiki.wooledge.org/BashFAQ/105](http://mywiki.wooledge.org/BashFAQ/105)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 01:19:23+00:00

<p>Article URL: <a href="http://mywiki.wooledge.org/BashFAQ/105">http://mywiki.wooledge.org/BashFAQ/105</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33116310">https://news.ycombinator.com/item?id=33116310</a></p>
<p>Points: 37</p>
<p># Comments: 35</p>

## WebVM: WASM virtual machine in browser with networking via Tailscale
 - [https://leaningtech.com/webvm-virtual-machine-with-networking-via-tailscale/](https://leaningtech.com/webvm-virtual-machine-with-networking-via-tailscale/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 01:10:45+00:00

<p>Article URL: <a href="https://leaningtech.com/webvm-virtual-machine-with-networking-via-tailscale/">https://leaningtech.com/webvm-virtual-machine-with-networking-via-tailscale/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33116245">https://news.ycombinator.com/item?id=33116245</a></p>
<p>Points: 53</p>
<p># Comments: 13</p>

## Ask HN: What content/knowledge is most important?
 - [https://news.ycombinator.com/item?id=33116230](https://news.ycombinator.com/item?id=33116230)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-07 01:09:14+00:00

<p>Let's assume you could store a computer along with a few terabytes of external storage inside a faraday cage. In the event of a disaster, you also have the ability to generate enough power to use the computer.<p>What content/knowledge would you choose to store on the device and why?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33116230">https://news.ycombinator.com/item?id=33116230</a></p>
<p>Points: 29</p>
<p># Comments: 38</p>


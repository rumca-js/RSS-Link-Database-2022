# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## The best Prime Day October 2022 TV deals
 - [https://www.zdnet.com/article/best-prime-day-october-2022-tv-deals/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-prime-day-october-2022-tv-deals/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 22:46:27+00:00

Amazon's October Prime Day might be next week, but Prime Members can save big on TVs from top brands like Samsung, Sony, and LG. Other retailers like Best Buy and Walmart are also running their own sales, allowing you to save hundreds!

## How to FaceTime on Android
 - [https://www.zdnet.com/article/how-to-facetime-on-android/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-facetime-on-android/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 22:00:00+00:00

This is not a drill. Android and iPhone users can now FaceTime each other. Here's how to do it.

## Only a third of higher education students report having a great university experience
 - [https://www.zdnet.com/article/only-a-third-of-higher-education-students-report-having-a-great-university-experience/#ftag=RSSbaffb68](https://www.zdnet.com/article/only-a-third-of-higher-education-students-report-having-a-great-university-experience/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 21:35:00+00:00

Only a third of students report having a great university experience, this according to the 2022 Connected Customer Report from Salesforce, highlighting insights into the global higher education trends from over 2,600 students and staff.

## How to turn your old devices into Amazon gift cards
 - [https://www.zdnet.com/article/how-to-turn-your-old-devices-into-amazon-gift-cards/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-turn-your-old-devices-into-amazon-gift-cards/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 21:21:00+00:00

Amazon's Trade-In Program turns your unwanted electronics into Amazon gift cards. The service comes in handy with Prime Early Access Sale on the horizon.

## The best Fire TV deals on Amazon for October Prime Day
 - [https://www.zdnet.com/home-and-office/home-entertainment/best-fire-tv-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/best-fire-tv-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:58:00+00:00

Looking for a Fire TV or streaming stick during Amazon's Prime Early Access Sale? ZDNET rounded up the best early Fire TV deals we could find so you can save and stream.

## How to protect your Firefox saved passwords with a Primary Password
 - [https://www.zdnet.com/article/how-to-protect-your-firefox-saved-passwords-with-a-primary-password/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-protect-your-firefox-saved-passwords-with-a-primary-password/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:51:21+00:00

For better security, don't rely on browser syncing to manage your passwords. Here's a better way.

## Buy a 65-inch LG TV for $479, get a $25 Target gift card
 - [https://www.zdnet.com/home-and-office/home-entertainment/buy-a-65-inch-lg-tv-on-sale-get-a-25-target-gift-card/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/buy-a-65-inch-lg-tv-on-sale-get-a-25-target-gift-card/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:50:00+00:00

It's always great when any LG 4K UHD smart TV is on sale, but Target is sweetening the deal with an extra $25 in savings.

## Need more ports? This tiny, lightweight, premium-quality dock delivers
 - [https://www.zdnet.com/home-and-office/need-more-ports-this-tiny-lightweight-premium-quality-dock-delivers/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/need-more-ports-this-tiny-lightweight-premium-quality-dock-delivers/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:44:00+00:00

Check out the Satechi USB-4 Multiport adapter with 2.5 Ethernet.

## The best laptop deals on Amazon for October Prime Day
 - [https://www.zdnet.com/article/best-laptop-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-laptop-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:41:29+00:00

Before Amazon's Prime Early Access Sale kicks off, ZDNET scoured the web for the best early laptop deals. Grab a new laptop at a great discount to save time and money.

## The best camera deals on Amazon for October Prime Day
 - [https://www.zdnet.com/article/best-camera-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-camera-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:28:00+00:00

Amazon's Prime Early Access Sale has nearly landed. ZDNET has rounded up the best early camera deals so you can save time and money on photography equipment.

## The best robot vacuum deals on Amazon for October Prime Day
 - [https://www.zdnet.com/home-and-office/kitchen-household/best-robot-vacuum-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/kitchen-household/best-robot-vacuum-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:26:00+00:00

With early deals already rolling in for Amazon's Prime Early Access Sale -- aka October Prime Day -- you won't have to break the bank if you're looking to streamline your household chores with a robot vacuum. ZDNET has rounded up the best early robot vacuum deals for you to compare.

## The best security camera deals for October Prime Day
 - [https://www.zdnet.com/home-and-office/smart-home/best-security-camera-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/best-security-camera-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:23:00+00:00

We're only a few days away from Amazon's Prime Early Access Sale, also known as October Prime Day. ZDNET has searched far and wide to find the best deals on security cameras that you can get right now.

## The best security camera deals on Amazon right now
 - [https://www.zdnet.com/article/the-best-early-deals-on-security-cameras-for-prime-day-october-2022/#ftag=RSSbaffb68](https://www.zdnet.com/article/the-best-early-deals-on-security-cameras-for-prime-day-october-2022/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:23:00+00:00

We're only a few days away from Amazon's Prime Early Access Sale, also known as October Prime Day. ZDNET has scoured the interweb and found the best deals on security cameras that you can get right now.

## Ubuntu Linux tries for the office desktop
 - [https://www.zdnet.com/article/ubuntu-linux-tries-for-the-office-desktop/#ftag=RSSbaffb68](https://www.zdnet.com/article/ubuntu-linux-tries-for-the-office-desktop/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:12:24+00:00

There may never be a "Year of the Linux desktop," but Canonical thinks there's room for a Ubuntu Linux business desktop.

## The best Prime Day October 2022 gaming deals
 - [https://www.zdnet.com/article/best-prime-day-october-2022-gaming-deals/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-prime-day-october-2022-gaming-deals/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:02:29+00:00

Amazon's October Prime Day is on the 11th and 12th, but you can take advantage of awesome early deals on Luna bundles, controllers, and games. And the deals keep coming from other retailers and brands like Walmart, Newegg, and Samsung, giving you huge discounts on gaming laptops, storage, and accessories.

## The best gaming deals on Amazon for October Prime Day
 - [https://www.zdnet.com/home-and-office/home-entertainment/best-gaming-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/best-gaming-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:02:00+00:00

Amazon's Prime Early Access Sale is on the 11th and 12th, but you can take advantage of awesome early deals on Luna bundles, controllers, and games. And the deals keep coming from other retailers and brands like Walmart, Newegg, and Samsung, giving you huge discounts on gaming laptops, storage, and accessories.

## Tesla removed its ultrasonic sensors from its cars. What does that mean for your Tesla vehicle, your safety and Tesla's future?
 - [https://www.zdnet.com/article/tesla-removed-its-ultrasonic-sensors-from-its-cars-what-does-that-mean-for-your-tesla-vehicle-your-safety-and-teslas-future/#ftag=RSSbaffb68](https://www.zdnet.com/article/tesla-removed-its-ultrasonic-sensors-from-its-cars-what-does-that-mean-for-your-tesla-vehicle-your-safety-and-teslas-future/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 20:00:09+00:00

Tesla's shift away from ultrasonic sensors could mean future Tesla car owners miss out on car features such as park assist, auto-park and summon.

## Samsung Galaxy Tab S7 deal: Save $110 on Amazon
 - [https://www.zdnet.com/article/samsung-galaxy-tab-s7-deal-coupon-promo-code-sale/#ftag=RSSbaffb68](https://www.zdnet.com/article/samsung-galaxy-tab-s7-deal-coupon-promo-code-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 19:55:00+00:00

You can expect to pay $419 for as long as stock lasts.

## This powerful 140W USB-C charger is smaller than Apple's and has three ports
 - [https://www.zdnet.com/home-and-office/this-powerful-140w-usb-c-charger-is-smaller-than-apples-and-has-three-ports/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/this-powerful-140w-usb-c-charger-is-smaller-than-apples-and-has-three-ports/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 19:35:32+00:00

Looking for power? The versatile Ugreen Nexode 140W USB-C charger may be just what you need.

## How to organize your Windows 11 Start menu with folders
 - [https://www.zdnet.com/article/how-to-organize-your-windows-11-start-menu-with-folders/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-organize-your-windows-11-start-menu-with-folders/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 17:12:30+00:00

With the 2022 update to Windows 11, Microsoft has resurrected Start menu folders.

## Forget Pixel 7: The Galaxy Flip 4 is on sale at Target
 - [https://www.zdnet.com/article/samsung-galaxy-flip-4-deal/#ftag=RSSbaffb68](https://www.zdnet.com/article/samsung-galaxy-flip-4-deal/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 15:52:07+00:00

The phone just released in August, and if you've been eyeing a great deal on the 128GB model, you can save $100 on it right now.

## Step aside, AirPods. There's a new ANC champion in town
 - [https://www.zdnet.com/article/bose-quietcomfort-earbuds-ii-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/bose-quietcomfort-earbuds-ii-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 14:26:00+00:00

Review: Meet the new QuietComfort Earbuds II. The active noise cancelling on these Bose earbuds is so good I accidentally ignored my boss.

## The best Kindle deals on Amazon for October Prime Day
 - [https://www.zdnet.com/article/best-kindle-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-kindle-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 14:06:00+00:00

Nabbing an e-reader for that upcoming holiday flight home? Check out the best Kindle deals for Amazon's Prime Early Access Sale -- aka October Prime Day.

## The best Ring & Blink deals ahead of October Prime Day
 - [https://www.zdnet.com/home-and-office/smart-home/best-ring-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/best-ring-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 14:05:00+00:00

Amazon's Prime Early Access Sale -- aka October Prime Day -- is nearly here. ZDNET is rounding up the best early deals on Ring and Blink video doorbells available right now, with some of the lowest prices we've ever seen.

## The best deals under $20 on Amazon for October Prime Day
 - [https://www.zdnet.com/article/best-deals-under-20-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-deals-under-20-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 14:05:00+00:00

You can already snag amazing deals ahead of Amazon's Prime Early Access Sale -- aka October Prime Day. ZDNET is rounding up the best deals under $20.

## The best Samsung deals on Amazon for October Prime Day
 - [https://www.zdnet.com/article/best-samsung-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-samsung-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 14:04:00+00:00

Amazon's Prime Early Access Sale -- aka October Prime Day -- is nearly here. ZDNET is rounding up the best Samsung deals we could find, so you can save on Samsung TVs, phones, tablets, and more.

## The best earbuds deals on Amazon for October Prime Day
 - [https://www.zdnet.com/article/best-earbuds-deals-amazon-prime-early-access-sale-october-prime-day/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-earbuds-deals-amazon-prime-early-access-sale-october-prime-day/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 14:01:00+00:00

Earbuds and headphones are essential, whether you're constantly traveling or working from home -- but they can be pricey. We found the best earbuds and headphone deals ahead of Amazon's Prime Early Access Sale.

## The best monitor deals on Amazon for October Prime Day
 - [https://www.zdnet.com/home-and-office/smart-office/best-monitor-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-office/best-monitor-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 14:00:00+00:00

Eyeing a new monitor to complete your office setup? There are deals aplenty during Amazon's Prime Early Access Sale, some of which are available right now.

## The best Apple deals on Amazon for October Prime Day
 - [https://www.zdnet.com/article/best-apple-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-apple-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 13:50:00+00:00

Amazon's Prime Early Access Sale is nearly here and the deals have begun. If you have been thinking of buying new Apple gadgets, ZDNET rounded up the best Apple deals you can buy right now.

## The best Echo deals on Amazon for October Prime Day
 - [https://www.zdnet.com/article/best-echo-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-echo-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 13:49:00+00:00

ZDNET has rounded up the best early Echo deals we could find while you're waiting for the official Amazon Prime Early Access Sale -- aka October Prime Day -- deals to drop. We're already seeing deals for up to 75% off certain devices.

## The best Fitbit deals on Amazon for October Prime Day
 - [https://www.zdnet.com/article/best-fitbit-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-fitbit-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 13:49:00+00:00

The holiday shopping season is upon us with Thanksgiving and Black Friday sales already being promoted. So why not get started early with these October Prime Day deals on Fitbit devices and fitness trackers?

## The best tablet deals on Amazon for October Prime Day
 - [https://www.zdnet.com/article/best-tablet-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-tablet-deals-amazon-prime-early-access-sale-prime-day-october/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 13:49:00+00:00

Looking to snag a new tablet? Ahead of Amazon's October Prime Day, there are great early deals tablets from brands like Amazon, Samsung, and more.

## How to add wireless Apple CarPlay to your car
 - [https://www.zdnet.com/home-and-office/how-to-add-wireless-apple-carplay-to-your-car/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/how-to-add-wireless-apple-carplay-to-your-car/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 12:58:51+00:00

Wired connections are a pain, but wireless is not without some limitations.

## How to use Opera's new Pinboard feature (and why you should)
 - [https://www.zdnet.com/article/how-to-use-operas-new-pinboard-feature-and-why-you-should/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-use-operas-new-pinboard-feature-and-why-you-should/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 12:49:46+00:00

Here's an introduction to a new feature for the Opera web browser that allows you to collect your thoughts, links, and images in a convenient location.

## Small business tech outlook: Challenges and opportunities ahead
 - [https://www.zdnet.com/article/small-business-tech-outlook-challenges-and-opportunities-ahead/#ftag=RSSbaffb68](https://www.zdnet.com/article/small-business-tech-outlook-challenges-and-opportunities-ahead/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 12:29:00+00:00

The economic outlook is creating headwinds for small business. But many now see tech as the key to thriving in uncertain times.

## Rust programming language outlines plan for updates to style guide
 - [https://www.zdnet.com/article/rust-programming-language-outlines-plan-for-updates-to-style-guide/#ftag=RSSbaffb68](https://www.zdnet.com/article/rust-programming-language-outlines-plan-for-updates-to-style-guide/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 12:22:09+00:00

The Rust team is putting more resources into helping developers write code faster.

## Facebook users warned: You may have downloaded these password-stealing Android and iOS apps
 - [https://www.zdnet.com/article/facebook-users-warned-you-may-have-downloaded-these-password-stealing-android-and-ios-apps/#ftag=RSSbaffb68](https://www.zdnet.com/article/facebook-users-warned-you-may-have-downloaded-these-password-stealing-android-and-ios-apps/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 12:04:00+00:00

Hundreds of malicious apps available in Google Play and Apple App Store tricked users into giving away their passwords. Here's what to watch out for.

## NSA, FBI warning: Beware these 20 software flaws most used by hackers
 - [https://www.zdnet.com/article/nsa-fbi-warning-beware-these-20-software-flaws-most-used-by-hackers/#ftag=RSSbaffb68](https://www.zdnet.com/article/nsa-fbi-warning-beware-these-20-software-flaws-most-used-by-hackers/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 11:35:12+00:00

China-backed hackers like to use these flaws, so you need to make sure they are patched, says FBI, NSA and CISA.

## Boston Dynamics: We won't weaponize our robots and neither should our customers
 - [https://www.zdnet.com/article/boston-dynamics-we-wont-weaponize-our-robots-and-neither-should-our-customers/#ftag=RSSbaffb68](https://www.zdnet.com/article/boston-dynamics-we-wont-weaponize-our-robots-and-neither-should-our-customers/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 10:55:32+00:00

Can robotics firms prevent customers from weaponizing their technology?

## Managers can't agree on who to hire, and it's creating big problems at work
 - [https://www.zdnet.com/article/managers-cant-agree-on-who-to-hire-and-its-creating-big-problems-at-work/#ftag=RSSbaffb68](https://www.zdnet.com/article/managers-cant-agree-on-who-to-hire-and-its-creating-big-problems-at-work/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 09:59:57+00:00

Developers or data analysts? Programming or problem-solving capabilities? Business leaders just can't seem to can't agree on what skills they need.

## Amazon tablet sale: Pick up a Fire HD 8 for only $44
 - [https://www.zdnet.com/home-and-office/amazon-tablet-sale-fire-hd-8-deal/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/amazon-tablet-sale-fire-hd-8-deal/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 07:58:47+00:00

For less than $50, you can purchase an Amazon Fire HD 8 tablet in Target's sale.

## Apple MacBook Air (M2, 2022) review: Sleeker, faster - and more expensive
 - [https://www.zdnet.com/article/apple-macbook-air-m2-2022-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/apple-macbook-air-m2-2022-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 07:34:10+00:00

The power-efficient M2 processor allows Apple to produce one of the slimmest and lightest laptops we've seen.

## Ring camera deal: Floodlight Cam goes on sale at Target
 - [https://www.zdnet.com/home-and-office/ring-camera-deal-floodlight-cam-goes-on-sale/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/ring-camera-deal-floodlight-cam-goes-on-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 07:20:19+00:00

Want to bolster your home security? Target's latest sale includes a decent discount on the Ring Floodlight Cam.

## What is Amazon Prime Early Access Sale and when is it?
 - [https://www.zdnet.com/article/what-is-amazon-prime-early-access-sale-and-when-is-it-in-october-prime-day/#ftag=RSSbaffb68](https://www.zdnet.com/article/what-is-amazon-prime-early-access-sale-and-when-is-it-in-october-prime-day/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 03:52:00+00:00

Amazon has announced a second Prime Day-like event for October called Prime Early Access Sale. It follows Amazon's annual Prime Day sale from the summer. Here's everything you need to know about "Prime Day 2" -- including how to find the best deals.

## The 4 best travel VPNs of 2022
 - [https://www.zdnet.com/article/best-travel-vpn/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-travel-vpn/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 03:41:00+00:00

The best travel VPN for you should be compatible with all of your mobile devices and provide a secure and reliable connection.

## The 5 best iPhone 14 Pro and Pro Max cases of 2022
 - [https://www.zdnet.com/article/best-iphone-14-pro-and-pro-max-case/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-iphone-14-pro-and-pro-max-case/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 03:40:00+00:00

The newest iPhones are durable, but not indestructible (or cheap). If you invested in an iPhone 14 Pro or Pro Max, safeguard it with the best iPhone case.

## The best Echo deals on Amazon for October Prime Day
 - [https://www.zdnet.com/article/echo-deals-prime-day-amazon-prime-early-access-sale/#ftag=RSSbaffb68](https://www.zdnet.com/article/echo-deals-prime-day-amazon-prime-early-access-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 01:27:00+00:00

ZDNET has rounded up the best early Echo deals we could find while you're waiting for the official Amazon Prime Early Access Sale -- aka October Prime Day -- deals to drop. We're already seeing deals for up to 75% off certain devices.

## The best tablet deals on Amazon for October Prime Day
 - [https://www.zdnet.com/article/tablet-deals-prime-day-amazon-prime-early-access-sale/#ftag=RSSbaffb68](https://www.zdnet.com/article/tablet-deals-prime-day-amazon-prime-early-access-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 01:18:00+00:00

Looking to snag a new tablet? Ahead of Amazon's October Prime Day, there are great early deals tablets from brands like Amazon, Samsung, and more.

## Samsung's profit drops for the first time in 3 years
 - [https://www.zdnet.com/article/samsungs-profit-drops-for-the-first-time-in-3-years/#ftag=RSSbaffb68](https://www.zdnet.com/article/samsungs-profit-drops-for-the-first-time-in-3-years/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-07 00:16:22+00:00

Samsung reported its first profit drop in three years for the third quarter as demand for memory chips dip.


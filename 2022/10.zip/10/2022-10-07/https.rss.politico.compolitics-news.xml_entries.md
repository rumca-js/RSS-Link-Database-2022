# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## ‘We need help’: Eric Adams declares state of emergency amid migrant arrivals
 - [https://www.politico.com/video/2022/10/07/we-need-help-eric-adams-declares-state-of-emergency-amid-migrant-arrivals-731491](https://www.politico.com/video/2022/10/07/we-need-help-eric-adams-declares-state-of-emergency-amid-migrant-arrivals-731491)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-10-07 16:00:27+00:00



## Blake masters acknowledges Biden as president in Arizona debate
 - [https://www.politico.com/video/2022/10/07/blake-masters-acknowledges-biden-as-president-in-arizona-debate-731346](https://www.politico.com/video/2022/10/07/blake-masters-acknowledges-biden-as-president-in-arizona-debate-731346)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-10-07 11:03:25+00:00



## Dream job disappointment: Testifying against Trump
 - [https://www.politico.com/news/2022/10/07/sarah-matthews-january-6-committee-podcast-interview-00060472](https://www.politico.com/news/2022/10/07/sarah-matthews-january-6-committee-podcast-interview-00060472)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-10-07 04:09:16+00:00

Think you have a rocky relationship with your former boss? Sarah Matthews resigned as Trump's deputy press secretary after the insurrection and testified before the Jan. 6 committee.

## The nation’s cartoonists on the week in politics
 - [https://www.politico.com/gallery/2022/10/07/the-nations-cartoonists-on-the-week-in-politics-00060727](https://www.politico.com/gallery/2022/10/07/the-nations-cartoonists-on-the-week-in-politics-00060727)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-10-07 03:30:00+00:00

Every week political cartoonists throughout the country and across the political spectrum apply their ink-stained skills to capture the foibles, memes, hypocrisies and other head-slapping events in the world of politics. The fruits of these labors are hundreds of cartoons that entertain and enrage readers of all political stripes. Here's an offering of the best of this week's crop, picked fresh off the Toonosphere. Edited by Matt Wuerker.


# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Competition: Calling All Editors! | Win $1000 or A Job!
 - [https://www.youtube.com/watch?v=ksruUiv8lqM](https://www.youtube.com/watch?v=ksruUiv8lqM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-10-08 00:00:00+00:00

COMPETITION TIME. Have a watch of this! Is this you? Get entering, the competition is open for 48 hours. Know someone who would be interested? tag em in. 

Cut & Clip From This Video: https://rumble.com/v1muzr5-stay-free-with-russell-brand-007-what-happens-when-you-challenge-dominant-p.html

Download Video Here: https://drive.google.com/file/d/14B0XBC8xzN4-cW5DLkA9Of9EkTURd0bc/view?usp=sharing

Send your entries to hello@russellbrand.com subject line ‘Editor Competition’ go on, slide into my inbox.

## Did Trump Nearly Pardon Julian Assange?
 - [https://www.youtube.com/watch?v=b9-aROGWuyA](https://www.youtube.com/watch?v=b9-aROGWuyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-10-08 00:00:00+00:00

Julian Assange is in a legal battle against extradition to the US where he could face a 175 year prison sentence. His wife and former Lawyer, Stella Assange chats to Russell about his situation and to highlight the human chain demonstration on Saturday, October 8th. #assange #protest #trump

Sign up to #SurroundParliament on October 8: http://DontExtraditeAssange.com/human-chain

Act now: https://dontextraditeassange.com/take-action/

Find out more, here: https://twitter.com/StellaMoris1
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/

## This Is Seriously Worrying.
 - [https://www.youtube.com/watch?v=C0QznbSpwY8](https://www.youtube.com/watch?v=C0QznbSpwY8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-10-07 00:00:00+00:00

With a member of the UN admitting at a WEF ‘Disinformation’ event that they work with Google to influence what people see when they type “climate change” – no matter what the narrative – how can we trust that what we Google is the whole story? #WEF #BillGates #climatechange 

References
https://reclaimthenet.org/bill-gates-pushes-for-trusted-sources/
https://reclaimthenet.org/un-tells-wef-partners-tech-promote-narratives/
https://theconversation.com/private-planes-mansions-and-superyachts-what-gives-billionaires-like-musk-and-abramovich-such-a-massive-carbon-footprint-152514
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/


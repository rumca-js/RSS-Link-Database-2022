# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Watch: Doofus Tries Attacking Old Man at Traffic Light, Isn't So Tough When Old Man Flashes His Gun
 - [https://www.louderwithcrowder.com/gun-man-traffic-light-run](https://www.louderwithcrowder.com/gun-man-traffic-light-run)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-07 22:21:41+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=27625152&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Parents, teach your children well. Make sure they eat their vegetables. See to it that they get good grades. And teach them that, every so often, when they f*ck around, they may find out. This lumbering dufus never got that lesson and had to learn the hard way. He f*cked around at a traffic light. He found out that the old man behind the wh

## Florida sheriff goes beast mode over Hurricane Ian looters: 'shoot them so they look like grated cheese'
 - [https://www.louderwithcrowder.com/hurricane-ian-looters-sheriff-grady](https://www.louderwithcrowder.com/hurricane-ian-looters-sheriff-grady)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-07 21:49:34+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31880594&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C120" /><br /><br /><p>Ron DeSantis tried to warn y'all. <a href="https://www.louderwithcrowder.com/ron-desantis-looting" target="_blank">He told all would be looters</a> if they were planning on taking advantage of the destruction of Hurricane Ian, "<em>I would not want to chance that if I were you given that we're a Second Amendment state."  </em>People aren'

## Mila Kunis blasts Hollywood elite giving Will Smith a standing ovation after slapping taste out of Chris Rock's mouth
 - [https://www.louderwithcrowder.com/mila-kunis-oscars-will-smith](https://www.louderwithcrowder.com/mila-kunis-oscars-will-smith)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-07 18:20:37+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31879914&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C24%2C0" /><br /><br /><p>I'm as shocked as you are that we're still talking about Will Smith slapping Chris Rock at the Oscars. But I've always been enamored by Mila Kunis since she lit up the screen in <em>Forgetting Sarah Marshall</em> and it was an excuse to scan photos to find a thumbnail. Most importantly, she made a point I haven't heard many celebrities mak

## Inspired by Kanye (or Ye), Sharon Osbourne wants her $900k donation to BLM refunded
 - [https://www.louderwithcrowder.com/sharon-osbourne-donation](https://www.louderwithcrowder.com/sharon-osbourne-donation)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-07 17:39:52+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31879773&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C24%2C0" /><br /><br /><p>Kanye West shocked the world by calling the Marxist political organization known as Black Lives Matter as a scam. Attention turns now to all the guilt-ridden white liberals who donated money to the political organization. One of them, Sharon Osbourne, is speaking out to TMZ.</p><p class="shortcode-media shortcode-media-youtube">
<span clas

## Five most cringeworthy moments of Democrats pandering to Black and Hispanic voters
 - [https://www.louderwithcrowder.com/democrats-pandering-list](https://www.louderwithcrowder.com/democrats-pandering-list)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-07 16:46:11+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31879574&amp;width=2000&amp;height=1500&amp;coordinates=162%2C0%2C0%2C0" /><br /><br /><p>Joe Biden surprised Americans this week during a visit to Puerto Rico where he announced that he too was "sort of raised in the Puerto Rican community." In Delaware, where Puerto Ricans make up 0.39% of the population. Shameless pandering is the Democrat love language to minority voters. It's something else they stink at because <a href=

## Trans TikTok influencer faces charges on eight counts of child sexual abuse
 - [https://www.louderwithcrowder.com/abuse-australia-tiktok](https://www.louderwithcrowder.com/abuse-australia-tiktok)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-07 14:44:08+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31879023&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>Trans TikTok influencer Rachel Queen Burton appeared in an Australian court on Thursday facing charges of child sexual abuse. </p><p>Burton is known as "rachel.queen8008" on the popular social media app TikTok, where she has amassed a following of over 35,000 followers. Rachel describes herself as a "proud Trans Woman" living her "best li

## Florida EVs are catching fire because it turns out that's what happens to the batteries in a Hurricane
 - [https://www.louderwithcrowder.com/batteries-hurricane-ian-florida](https://www.louderwithcrowder.com/batteries-hurricane-ian-florida)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-07 13:56:26+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31878827&amp;width=1245&amp;height=700&amp;coordinates=0%2C59%2C0%2C60" /><br /><br /><p>Before we mock electric vehicles and the leftist push to signal your virtue by owning an electric vehicle, not all car owners asked for this. People who own far superior gas-powered cars are victims too. On behalf of all of us here at the Louder with Crowder Dot Com website, please join us in a moment of silence.</p><div class="rm-embed e

## Watch: Evil daycare workers think it's funny terrorizing little kids, but the comedy is when they get fired
 - [https://www.louderwithcrowder.com/scream-mask-daycare](https://www.louderwithcrowder.com/scream-mask-daycare)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-07 13:14:23+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31878717&amp;width=980" /><br /><br /><p>If you live in the Mississippi area and are looking for a front porch to light a bag of dog turds on fire, I can think of four. People who are entrusted to look after children thought it would be funny to <a href="https://www.louderwithcrowder.com/insane-man-subway-joker" target="_blank">terrorize</a> them and record it. Worse, it was with that dumb mask from <em>Scream</em>. Not only 

## CNN suspends contributor for criticizing Jeffrey Toobin, never tells her because pregnant women are crazy
 - [https://www.louderwithcrowder.com/cnn-toobin-katherine-ham](https://www.louderwithcrowder.com/cnn-toobin-katherine-ham)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-07 12:29:38+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31878386&amp;width=980" /><br /><br /><p>Jeffrey Toobin was caught <a href="https://www.louderwithcrowder.com/oj-simpson-jeffrey-toobin" target="_blank">whacking off on Zoom in front of his female colleagues</a>. Mary Katherine Ham criticized Jeffrey Toobin for whacking off in front of his female colleagues. Both were suspended. The difference is CNN had the professionalism to tell Toobin he was suspended. MKH only found out 


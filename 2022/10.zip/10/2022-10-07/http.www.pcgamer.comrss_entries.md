# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Major game studios believed this company was providing experienced, well-staffed QA teams—employees say that was a lie
 - [https://www.pcgamer.com/quantic-QA-tester-report](https://www.pcgamer.com/quantic-QA-tester-report)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 23:48:50+00:00

Quantic Lab first made headlines over its role in testing Cyberpunk 2077.

## Valve edits Steam Deck trailer to remove Nintendo Switch emulator icon
 - [https://www.pcgamer.com/valve-edits-steam-deck-trailer-to-remove-nintendo-switch-emulator-icon](https://www.pcgamer.com/valve-edits-steam-deck-trailer-to-remove-nintendo-switch-emulator-icon)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 23:06:27+00:00

Valve swapped out a recent Steam Deck update video after someone pointed out the Yuzu emulator was installed.

## Here's a survival game first: I just went fishing for giant moths off the edge of my blimp
 - [https://www.pcgamer.com/heres-a-survival-game-first-i-just-went-fishing-for-giant-moths-off-the-edge-of-my-blimp](https://www.pcgamer.com/heres-a-survival-game-first-i-just-went-fishing-for-giant-moths-off-the-edge-of-my-blimp)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 22:57:13+00:00

In Forever Skies you pilot a mobile airship base over the ruined skyscrapers of earth. And sometimes you go fishing for mutant moths.

## EA's Origin is officially dead
 - [https://www.pcgamer.com/eas-origin-is-officially-dead](https://www.pcgamer.com/eas-origin-is-officially-dead)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 22:50:36+00:00

The EA app is now out of open beta, and you'll soon be 'invited' to upgrade. (But it's good, so that's okay.)

## This gorgeous grid-based dungeon crawler is based on real folklore
 - [https://www.pcgamer.com/this-gorgeous-grid-based-dungeon-crawler-is-based-on-real-folklore](https://www.pcgamer.com/this-gorgeous-grid-based-dungeon-crawler-is-based-on-real-folklore)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 21:52:03+00:00

Dungeons of the Amber Griffin turns Kashubian mythology into fodder for a fantasy RPG.

## Modern Warfare 2 has the same 'no prepaid phone' requirement as Overwatch 2
 - [https://www.pcgamer.com/modern-warfare-2-has-the-same-no-prepaid-phone-requirement-as-overwatch-2](https://www.pcgamer.com/modern-warfare-2-has-the-same-no-prepaid-phone-requirement-as-overwatch-2)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 21:13:13+00:00

Just like Overwatch 2, you'll need to attach a phone number to your Battle.net account to play Modern Warfare 2—and prepaid phones aren't allowed.

## Get instantly hooked on this free fishing puzzle browser game
 - [https://www.pcgamer.com/get-instantly-hooked-on-this-free-fishing-puzzle-browser-game](https://www.pcgamer.com/get-instantly-hooked-on-this-free-fishing-puzzle-browser-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 20:49:22+00:00

Curious Fishing is fun, cute, and deceptively challenging without ever being frustrating.

## More than half a billion dollars stolen from world's largest crypto exchange
 - [https://www.pcgamer.com/more-than-half-a-billion-dollars-stolen-from-worlds-largest-crypto-exchange](https://www.pcgamer.com/more-than-half-a-billion-dollars-stolen-from-worlds-largest-crypto-exchange)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 20:33:14+00:00

Binance temporarily halted trading to investigate the breach.

## Of course everyone's Dreamlight Valley villages are prettier than mine
 - [https://www.pcgamer.com/of-course-everyones-dreamlight-valley-villages-are-prettier-than-mine](https://www.pcgamer.com/of-course-everyones-dreamlight-valley-villages-are-prettier-than-mine)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 19:37:25+00:00

I've gone looking for build inspiration and come back a bit jealous.

## Elle Stranding? Death Fanning? Actress Elle Fanning to appear in Kojima Productions project
 - [https://www.pcgamer.com/elle-stranding-death-fanning-actress-elle-fanning-to-appear-in-kojima-productions-project](https://www.pcgamer.com/elle-stranding-death-fanning-actress-elle-fanning-to-appear-in-kojima-productions-project)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 19:36:54+00:00

Kojima Productions has at least one other big game in the works aside from Death Stranding 2.

## Bethesda finally confirms it: Deathloop is a Dishonored game
 - [https://www.pcgamer.com/bethesda-finally-confirms-it-deathloop-is-a-dishonored-game](https://www.pcgamer.com/bethesda-finally-confirms-it-deathloop-is-a-dishonored-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 19:16:55+00:00

Creative director Dinga Bakaba said during an Xbox podcast that Deathloop is "one of the futures of the Dishonored world."

## Is 5 new Witcher games too many Witcher games?
 - [https://www.pcgamer.com/is-5-new-witcher-games-too-many-witcher-games](https://www.pcgamer.com/is-5-new-witcher-games-too-many-witcher-games)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 19:00:01+00:00

...and can CD Projekt even pull it off?

## The best RPGs in 2022
 - [https://www.pcgamer.com/best-rpgs-of-all-time](https://www.pcgamer.com/best-rpgs-of-all-time)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 17:30:00+00:00

Lose yourself in fantastic worlds and embark on unforgettable quests in these essential PC role-playing games.

## Score an AMD Radeon RX 6650 XT GPU for less than the price of an RTX 3050
 - [https://www.pcgamer.com/score-an-amd-radeon-rx-6650-xt-gpu-for-less-than-the-price-of-an-rtx-3050](https://www.pcgamer.com/score-an-amd-radeon-rx-6650-xt-gpu-for-less-than-the-price-of-an-rtx-3050)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 16:54:26+00:00

AMD's RTX 3060/Ti competitor is a bargain even compared to a weaker RTX 3050 right now.

## The best Amazon Prime Early Access gaming PC deals
 - [https://www.pcgamer.com/amazon-prime-day-gaming-pc-deals-2022](https://www.pcgamer.com/amazon-prime-day-gaming-pc-deals-2022)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 16:41:44+00:00

Amazon Prime Early Access could be a great time to grab a gaming PC deal now the RTX 40-series GPUs have been announced.

## How to find and open Vaults in Fortnite Chapter 3 Season 4
 - [https://www.pcgamer.com/fortnite-vault-locations-keys](https://www.pcgamer.com/fortnite-vault-locations-keys)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 16:36:29+00:00

Locate and loot these lockups.

## Steam u-turns on ban for Danganronpa dev’s game and reworks review process
 - [https://www.pcgamer.com/steam-u-turns-on-ban-for-danganronpa-devs-game-and-reworks-rejection-process](https://www.pcgamer.com/steam-u-turns-on-ban-for-danganronpa-devs-game-and-reworks-rejection-process)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 16:36:19+00:00

The gory, sci-fi visual novel had a rocky road to today's Steam release.

## Intel Arc A750 Limited Edition
 - [https://www.pcgamer.com/intel-arc-a750-review-benchmarks-performance](https://www.pcgamer.com/intel-arc-a750-review-benchmarks-performance)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 16:28:26+00:00

Intel's more affordable Arc GPU is pretty competitive.

## Stellaris's game director isn't thinking about a sequel: 'There's so much stuff for us to continue working with'
 - [https://www.pcgamer.com/stellariss-game-director-isnt-thinking-about-a-sequel-theres-so-much-stuff-for-us-to-continue-working-with](https://www.pcgamer.com/stellariss-game-director-isnt-thinking-about-a-sequel-theres-so-much-stuff-for-us-to-continue-working-with)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 16:04:38+00:00

Paradox has a plan for the 4X that goes well into the future, but Stellaris 2 isn't part of it. Yet.

## Guide a doggo astronaut home in this upcoming indie puzzle-platformer
 - [https://www.pcgamer.com/guide-a-doggo-astronaut-home-in-this-upcoming-indie-puzzle-platformer](https://www.pcgamer.com/guide-a-doggo-astronaut-home-in-this-upcoming-indie-puzzle-platformer)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 16:00:34+00:00

Space Tail: Every Journey Leads Home is coming in November, and a demo is available now in the Steam Next Fest.

## My kind of modders are re-building the first Vampire: the Masquerade in Skyrim
 - [https://www.pcgamer.com/my-kind-of-modders-are-re-building-the-first-vampire-the-masquerade-in-skyrim](https://www.pcgamer.com/my-kind-of-modders-are-re-building-the-first-vampire-the-masquerade-in-skyrim)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 15:43:44+00:00

No, not that one, the other one.

## Overwatch 2 tier lists are a mess, but most agree that one hero is coming out on top
 - [https://www.pcgamer.com/overwatch-2-tier-lists-are-a-mess-but-most-agree-that-one-hero-is-coming-out-on-top](https://www.pcgamer.com/overwatch-2-tier-lists-are-a-mess-but-most-agree-that-one-hero-is-coming-out-on-top)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 15:08:17+00:00

Look at this team, we're gonna so great..

## Public voting now open in the Golden Joystick's 40th anniversary awards
 - [https://www.pcgamer.com/public-voting-now-open-in-the-golden-joysticks-40th-anniversary-awards](https://www.pcgamer.com/public-voting-now-open-in-the-golden-joysticks-40th-anniversary-awards)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 15:00:00+00:00

The longest running public-voted game awards show there is.

## Make your gaming experience bulletproof with Decksaver's ultra-durable keyboard covers
 - [https://www.pcgamer.com/make-your-gaming-experience-bulletproof-with-decksavers-ultra-durable-keyboard-covers](https://www.pcgamer.com/make-your-gaming-experience-bulletproof-with-decksavers-ultra-durable-keyboard-covers)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 14:58:13+00:00

Protect your peripherals from dust, spills, and accidental impacts with these stylish polycarbonate covers.

## Logitech G Cloud
 - [https://www.pcgamer.com/logitech-g-cloud-review-performance](https://www.pcgamer.com/logitech-g-cloud-review-performance)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 14:56:31+00:00

Logitech's super-niche cloud-gaming handheld isn't all clear skies and rainbows.

## No Man's Sky's new update is for space captains who 'just want to chill out'
 - [https://www.pcgamer.com/no-mans-skys-new-update-is-for-space-captains-who-just-want-to-chill-out](https://www.pcgamer.com/no-mans-skys-new-update-is-for-space-captains-who-just-want-to-chill-out)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 13:24:57+00:00

The Waypoint update promises a galaxy with better vibes and bigger inventories.

## Woman confesses to murdering sister for flirting with her boyfriend in Valorant
 - [https://www.pcgamer.com/woman-confesses-to-murdering-sister-for-flirting-with-her-boyfriend-in-valorant](https://www.pcgamer.com/woman-confesses-to-murdering-sister-for-flirting-with-her-boyfriend-in-valorant)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 13:06:54+00:00

Fatiha Marzan felt 'disrespected' by the relationship her boyfriend and sister had in the game.

## Here we go again: I can't wait until Overwatch 2 players learn there's an objective
 - [https://www.pcgamer.com/here-we-go-again-i-cant-wait-until-overwatch-2-players-learn-theres-an-objective](https://www.pcgamer.com/here-we-go-again-i-cant-wait-until-overwatch-2-players-learn-theres-an-objective)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 13:01:57+00:00

But honestly, it took original Overwatch players to learn that too.

## This point-and-click game is like a dark crime thriller version of Zootopia
 - [https://www.pcgamer.com/this-point-and-click-game-is-like-a-dark-crime-thriller-version-of-zootopia](https://www.pcgamer.com/this-point-and-click-game-is-like-a-dark-crime-thriller-version-of-zootopia)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 12:52:49+00:00

Tails: The Backbone Preludes is the prequel to 2021's Backbone.

## Where to find Rebecca's shotgun in Cyberpunk 2077
 - [https://www.pcgamer.com/cyberpunk-2077-rebecca-shotgun-guts](https://www.pcgamer.com/cyberpunk-2077-rebecca-shotgun-guts)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 11:14:18+00:00

Lay your hands on the Guts shotgun from Edgerunners.

## SteelSeries Arena 7
 - [https://www.pcgamer.com/steelseries-arena-7-speakers-review](https://www.pcgamer.com/steelseries-arena-7-speakers-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 10:00:22+00:00

An immersive gaming experience with refined audio.

## Today's Wordle 475 answer and hint: Friday, October 7
 - [https://www.pcgamer.com/todays-wordle-475-answer-hint](https://www.pcgamer.com/todays-wordle-475-answer-hint)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-07 07:01:28+00:00

Wordle today: The solution and a hint for Friday's puzzle.


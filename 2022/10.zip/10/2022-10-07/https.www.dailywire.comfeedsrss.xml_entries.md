# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Musk Sides With Communist China, Suggests Giving Them Partial Control Of Taiwan To Avoid War
 - [https://www.dailywire.com/news/musk-sides-with-communist-china-suggests-giving-them-partial-control-of-taiwan-to-avoid-war](https://www.dailywire.com/news/musk-sides-with-communist-china-suggests-giving-them-partial-control-of-taiwan-to-avoid-war)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 23:59:24+00:00

Billionaire entrepreneur Elon Musk suggested this week that war could be averted with communist China by simply giving into their demands and giving them partial control of the island of Taiwan. Musk made the remarks during an interview that was published Friday in the Financial Times. It comes after he suggested earlier in the week ...

## As Russia Tries To Conquer Ukraine, Deviants Try To Conquer Everybody
 - [https://www.dailywire.com/news/as-russia-tries-to-conquer-ukraine-deviants-try-to-conquer-everybody](https://www.dailywire.com/news/as-russia-tries-to-conquer-ukraine-deviants-try-to-conquer-everybody)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 22:09:56+00:00

The following is the opening satirical monologue from “The Andrew Klavan Show.” Murderous dictatorial imperialist Vladimir Putin has accused the West of Satanism, infuriating Western leaders by interrupting their child sacrifices to the bull-headed demon god Moloch. The Russian president took time off from poisoning and imprisoning his critics to condemn America as an evil ...

## Florida Surgeon General Issues Warning For mRNA Coronavirus Vaccines: ‘FL Will Not Be Silent On The Truth’
 - [https://www.dailywire.com/news/florida-surgeon-general-issues-warning-for-mrna-coronavirus-vaccines-fl-will-not-be-silent-on-the-truth](https://www.dailywire.com/news/florida-surgeon-general-issues-warning-for-mrna-coronavirus-vaccines-fl-will-not-be-silent-on-the-truth)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 21:25:10+00:00

Florida Surgeon General Joseph A. Ladapo, MD, PhD, said in a statement Friday afternoon that the state now recommends against giving men ages 18 to 39 mRNA coronavirus vaccines, citing a heightened risk of cardiac-related death. The statement from Ladapo comes at the conclusion of an analysis conducted by the Florida Department of Health that ...

## Man Accused Of Las Vegas Mass Stabbing Spree Is Illegally In U.S., Wanted To Be Deported, Reports Say
 - [https://www.dailywire.com/news/man-accused-of-las-vegas-mass-stabbing-spree-is-illegally-in-u-s-wanted-to-be-deported-reports-say](https://www.dailywire.com/news/man-accused-of-las-vegas-mass-stabbing-spree-is-illegally-in-u-s-wanted-to-be-deported-reports-say)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 20:57:20+00:00

The man who allegedly carried out a deadly mass stabbing spree in Las Vegas this week is an illegal alien. Police responded to reports of a stabbing outside the Wynn casino off of Las Vegas Boulevard just before noon on Thursday. At least two people have died from the attack and six others were injured, ...

## Google Removes Gender Clinic Map, Citing ‘Harassment’ Violation
 - [https://www.dailywire.com/news/google-removes-gender-clinic-map-citing-harassment-violation](https://www.dailywire.com/news/google-removes-gender-clinic-map-citing-harassment-violation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 20:45:11+00:00

A user-made Google map tracking over 500 pediatric gender clinics that have sprouted up all over North America in recent years was removed by Google last week. A spokesperson for Google said the map violated their policies on “harassment.” Alix Aharon, the creator of the Gender Mapping Project, which was created using the Google Maps ...

## Police Officer Shoots Man Carrying ‘Very Large Axe’ After He Attempted To Enter Florida Elementary School
 - [https://www.dailywire.com/news/police-officer-shoots-man-with-very-large-axe-after-he-attempted-to-enter-florida-elementary-school](https://www.dailywire.com/news/police-officer-shoots-man-with-very-large-axe-after-he-attempted-to-enter-florida-elementary-school)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 20:25:30+00:00

A man who tried to enter a Jacksonville, Florida, elementary school was shot and critically wounded by a school police officer Friday afternoon. Around 2:48 p.m. a man carrying “a very large axe” walked up to the entrance of Ruth N. Upson Elementary School and attempted to get inside the building, according to Duval County ...

## Delaware Supreme Court Blocks No-Excuse Mail-In Voting, Same Day Registration
 - [https://www.dailywire.com/news/delaware-supreme-court-blocks-no-excuse-mail-in-voting-same-day-registration](https://www.dailywire.com/news/delaware-supreme-court-blocks-no-excuse-mail-in-voting-same-day-registration)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 20:06:33+00:00

The Delaware Supreme Court has blocked the state&#8217;s mail-in voting laws from taking effect. In an expedited three-page order Friday, the court, en banc, ruled that laws enacted by the Democrat-controlled state legislature and Democratic Governor John Carney earlier this year violated the state constitution. The ruling struck down a law allowing for no-excuse mail-in ...

## Candace Reacts To Kanye West On ‘Tucker Carlson Tonight’
 - [https://www.dailywire.com/news/candace-reacts-to-kanye-west-on-tucker-carlson-tonight](https://www.dailywire.com/news/candace-reacts-to-kanye-west-on-tucker-carlson-tonight)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 19:28:13+00:00

Unless you&#8217;ve been hiding under a rock, you know that Kanye West — who now goes by Ye West — and I were in Paris at his Yeezy fashion show, wearing t-shirts that said “White Lives Matter.&#8221; He went on Fox News’s Tucker Carlson Tonight for an extensive interview Thursday night, and I’d like to give ...

## Report Says Bündchen Threatened Divorce For Years, Insists She’s Done Now: ‘Is She Trying To F With Tom?’
 - [https://www.dailywire.com/news/report-says-bundchen-threatened-divorce-for-years-insists-shes-done-now-is-she-trying-to-f-with-tom](https://www.dailywire.com/news/report-says-bundchen-threatened-divorce-for-years-insists-shes-done-now-is-she-trying-to-f-with-tom)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 18:48:25+00:00

NFL quarterback Tom Brady&#8217;s wife, supermodel Gisele Bündchen, has reportedly threatened divorce for years over Brady&#8217;s NFL career and now says that there is no turning back and that her decision to leave is final. Page Six reported that Bündchen consulted a divorce attorney in 2015 after the couple allegedly secretly split up for a short ...

## ‘Loves Joe Biden More Than He Loves His Wife’: Ohio Democrat Cuts Cringey Ad Seemingly Masking Liberal Voting Record
 - [https://www.dailywire.com/news/loves-joe-biden-more-than-he-loves-his-wife-ohio-democrat-cuts-cringey-ad-seemingly-masking-liberal-voting-record](https://www.dailywire.com/news/loves-joe-biden-more-than-he-loves-his-wife-ohio-democrat-cuts-cringey-ad-seemingly-masking-liberal-voting-record)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 18:37:16+00:00

Democratic Ohio Senate candidate Tim Ryan cut a cringeworthy ad Friday in a seeming attempt to mask his liberal voting record. Ryan posted the ad to his Twitter account Friday. In the ad, he attempts to downplay his record of voting in line with President Joe Biden using the fact that he does not always ...

## ‘Liberal Left All Her Adult Life’: J.K. Rowling Slams Idea She’s ‘Right Wing’
 - [https://www.dailywire.com/news/liberal-left-all-her-adult-life-j-k-rowling-slams-idea-shes-right-wing](https://www.dailywire.com/news/liberal-left-all-her-adult-life-j-k-rowling-slams-idea-shes-right-wing)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 18:22:42+00:00

Author J.K. Rowling slammed the idea she&#8217;s &#8220;right wing&#8221; simply because she cares &#8220;about child safeguarding,&#8221; and said she&#8217;s been on the &#8220;liberal left all her adult life.&#8221; Rowling, the famed &#8220;Harry Potter&#8221; author who has been the target of transgender rights activists because of her defense of biological women, made several comments on Twitter Friday, ...

## Texas Attorney General Praises Elon Musk For Wanting ‘Free Speech To Reign On The Internet’
 - [https://www.dailywire.com/news/texas-attorney-general-praises-elon-musk-for-wanting-free-speech-to-reign-on-the-internet](https://www.dailywire.com/news/texas-attorney-general-praises-elon-musk-for-wanting-free-speech-to-reign-on-the-internet)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 18:16:27+00:00

Texas Attorney General Ken Paxton said on Friday that he would welcome Elon Musk’s leadership of Twitter. Though Musk had been attempting to cancel his deal to purchase the social media platform, earlier this week he suggested completing the transaction at the original $54.20 per share — an offer that Twitter appeared to accept before ...

## Detransitioners Pen Plea To DOJ After Doctors Seek To Silence Critics Of Trans Treatments For Minors
 - [https://www.dailywire.com/news/detransitioners-pen-plea-to-doj-after-doctors-seek-to-silence-critics-of-trans-treatments-for-minors](https://www.dailywire.com/news/detransitioners-pen-plea-to-doj-after-doctors-seek-to-silence-critics-of-trans-treatments-for-minors)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 18:12:24+00:00

A group of formerly transgender young adults wrote Attorney General Merrick Garland to counter top American medical institutions who aim to silence critics of radical transgender procedures carried out on minors. The letter from seven so-called &#8220;detransitioners&#8221; followed one sent Monday by the American Medical Association, American Academy of Pediatrics, and Children’s Hospital Association that urged the ...

## New PayPal Policy Lets Company Pull $2,500 From Users’ Accounts If They Promote ‘Misinformation’
 - [https://www.dailywire.com/news/new-paypal-policy-lets-company-pull-2500-from-users-accounts-if-they-promote-misinformation](https://www.dailywire.com/news/new-paypal-policy-lets-company-pull-2500-from-users-accounts-if-they-promote-misinformation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 17:16:50+00:00

A new policy update from PayPal will permit the firm to sanction users who advance purported “misinformation” or present risks to user “wellbeing.” The financial services company, which has repeatedly deplatformed organizations and individual commentators for their political views, will expand its “existing list of prohibited activities” on November 3. Among the changes are prohibitions ...

## Study: California Sees Second Highest Rate Of Young Wealthy Professionals Leave State In 2020
 - [https://www.dailywire.com/news/study-california-sees-second-highest-rate-of-young-wealthy-professionals-leave-state-in-2020](https://www.dailywire.com/news/study-california-sees-second-highest-rate-of-young-wealthy-professionals-leave-state-in-2020)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 17:06:21+00:00

A recent study is demonstrating the way young people view different states as potential places to live, especially when they are doing well financially. The study by Smart Asset looked into where people under 35 years of age with a minimum adjusted gross income of $100,000 are moving. The group looked at how many people ...

## WATCH: Strangers Eagerly Support Sex-Change Surgery For 5-Year-Old ‘Annie’
 - [https://www.dailywire.com/news/watch-strangers-eagerly-support-sex-change-surgery-for-5-year-old-annie](https://www.dailywire.com/news/watch-strangers-eagerly-support-sex-change-surgery-for-5-year-old-annie)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 16:53:07+00:00

Ami Horowitz, who has made an art form out of man-on-the-street interviews, has a new video out that should scare you, assuming you don’t think gender-confused pre-schoolers should undergo sex changes. Pretending to gather signatures in support of “Annie Rodriguez,” a fictitious 5 year old whose parents won’t allow her to undergo gender-swapping surgery. &nbsp; ...

## ‘We Have Not Asked For This’: NYC Mayor Declares State Of Emergency Over Illegal Immigrants
 - [https://www.dailywire.com/news/we-have-not-asked-for-this-nyc-mayor-declares-state-of-emergency-over-illegal-immigrants](https://www.dailywire.com/news/we-have-not-asked-for-this-nyc-mayor-declares-state-of-emergency-over-illegal-immigrants)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 16:28:43+00:00

New York City Mayor Eric Adams declared a state of emergency on Friday, saying that his city was not equipped to handle the influx of illegal immigrants coming via bus from Texas. Adams, who has previously boasted about the fact that New York City is a sanctuary city, delivered the statement at a press conference, ...

## Gotcha: Herschel Walker’s October Surprise Is The Oldest Play In The Book
 - [https://www.dailywire.com/news/gotcha-herschel-walkers-october-surprise-is-the-oldest-play-in-the-book](https://www.dailywire.com/news/gotcha-herschel-walkers-october-surprise-is-the-oldest-play-in-the-book)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 16:24:46+00:00

Ah, October. ’Tis the season for cooler temperatures, scary movies and shameless political stunts meant to change election outcomes. The latest victim of an attempted October Surprise is Georgia Republican senatorial candidate, professing Christian and football legend Herschel Walker, a pro-life absolutist accused in a Daily Beast “bombshell” article of paying for a girlfriend’s abortion ...

## DOJ Manipulated Evidence In Keith Raniere Case, Claim FBI Experts, Alan Dershowitz
 - [https://www.dailywire.com/news/doj-manipulated-evidence-in-keith-raniere-case-claim-fbi-experts-alan-dershowitz](https://www.dailywire.com/news/doj-manipulated-evidence-in-keith-raniere-case-claim-fbi-experts-alan-dershowitz)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 16:22:27+00:00

The Department of Justice manipulated evidence in the child-sex trafficking trial of convicted cult leader Keith Raniere, a group FBI experts backed by famed attorney Alan Dershowitz claimed Thursday. Raniere was convicted in 2019, but now the group of six veteran FBI forensic experts claims the government framed him. They held a virtual press conference on Thursday, joined by ...

## Biden: ‘Two Words: Made In America’
 - [https://www.dailywire.com/news/biden-two-words-made-in-america](https://www.dailywire.com/news/biden-two-words-made-in-america)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 16:19:21+00:00

It now seems that any time President Joe Biden gets behind a microphone, he makes a vocal error that leaves the world scratching its head. For example, on Friday, Biden displayed his inability to properly count words when he told an elated Maryland crowd, &#8220;Let me start off with two words &#8230; Made in America.&#8221; Unless ...

## John Fetterman Made $179,000 As Pennsylvania Lieutenant Governor. His Work Calendar Was Often Blank.
 - [https://www.dailywire.com/news/john-fetterman-made-179000-as-pennsylvania-lieutenant-governor-his-work-calendar-was-often-blank](https://www.dailywire.com/news/john-fetterman-made-179000-as-pennsylvania-lieutenant-governor-his-work-calendar-was-often-blank)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 16:04:26+00:00

Pennsylvania Democratic Senate candidate John Fetterman was not particularly ambitious as the lieutenant governor of the Keystone State, according to a review of his work calendars released on Thursday. An analysis from the Associated Press determined that Fetterman’s daily schedule was blank for roughly one-third of his work days from January 2019, the beginning of ...

## BREAKING: Vanderbilt Pediatric Gender Clinic Pausing Transgender Surgeries On Minors
 - [https://www.dailywire.com/news/breaking-vanderbilt-pediatric-gender-clinic-pausing-transgender-surgeries-on-minors](https://www.dailywire.com/news/breaking-vanderbilt-pediatric-gender-clinic-pausing-transgender-surgeries-on-minors)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 16:00:11+00:00

The Vanderbilt Pediatric Gender Clinic has agreed to pause all gender transition surgeries on minors, according to a letter from the clinic to a Tennessee lawmaker obtained by The Daily Wire. Vanderbilt also told the lawmakers that it would protect conscientious objectors who work at the facility and don&#8217;t want to take part in the ...

## Poll Finds Republican Lee Zeldin Neck-And-Neck With Kathy Hochul In Governor’s Race In Deep-Blue New York
 - [https://www.dailywire.com/news/poll-finds-republican-lee-zeldin-neck-and-neck-with-kathy-hochul-in-governors-race-in-deep-blue-new-york](https://www.dailywire.com/news/poll-finds-republican-lee-zeldin-neck-and-neck-with-kathy-hochul-in-governors-race-in-deep-blue-new-york)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 15:58:20+00:00

A new poll shows that Republican Congressman Lee Zeldin is running neck-and-neck with Democratic New York Governor Kathy Hochul. The poll of 1,087 likely voters, conducted by the Trafalgar Group, found that Hochul is holding onto a razor-thin lead over Zeldin, 44.5% to 42.6%; Libertarian candidate Larry Sharpe holds 3.2% of the vote, and 9.7% ...

## Biden’s Mass Pardon For Marijuana Possession Likely Benefitting Offenders Guilty Of Worse Crimes, Expert Says
 - [https://www.dailywire.com/news/bidens-mass-pardon-for-marijuana-possession-likely-benefitting-offenders-guilty-of-worse-crimes-expert-says](https://www.dailywire.com/news/bidens-mass-pardon-for-marijuana-possession-likely-benefitting-offenders-guilty-of-worse-crimes-expert-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 15:46:09+00:00

President Joe Biden’s mass pardon of those convicted of simple marijuana possession on Thursday is likely to benefit many who were arrested for more serious crimes, according to a legal expert from The Heritage Foundation. Biden announced an order Thursday pardoning thousands of people convicted of “simple possession of marijuana.” The president also called on ...

## Pink Floyd’s Roger Waters Tells Rogan Mark Zuckerberg Is ‘Now In Cahoots With FBI’
 - [https://www.dailywire.com/news/pink-floyds-roger-waters-tells-rogan-mark-zuckerberg-is-now-in-cahoots-with-fbi](https://www.dailywire.com/news/pink-floyds-roger-waters-tells-rogan-mark-zuckerberg-is-now-in-cahoots-with-fbi)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 15:33:42+00:00

Pink Floyd&#8217;s Roger Waters, who usually reserves his most unhinged vitriol for the state of Israel, trained his acid tongue on Facebook founder Mark Zuckerberg Thursday, telling Joe Rogan, the billionaire proved he is &#8220;in cahoots with FBI&#8221; by suppressing the Hunter Biden laptop story before the 2020 election. During Spotify&#8217;s &#8220;The Joe Rogan Experience&#8221; podcast Thursday, ...

## ‘I Never Quit’: Eva Mendes Says She’s Shifting ‘The Narrative’ That She Left Hollywood
 - [https://www.dailywire.com/news/i-never-quit-eva-mendes-says-shes-shifting-the-narrative-that-she-left-hollywood](https://www.dailywire.com/news/i-never-quit-eva-mendes-says-shes-shifting-the-narrative-that-she-left-hollywood)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 15:20:24+00:00

Superstar Eva Mendes said she&#8217;s shifting &#8220;the narrative&#8221; about her career in Hollywood and said she &#8220;never quit acting&#8221; as she hit back at numerous headlines claiming otherwise. The 48-year-old actress said she didn&#8217;t &#8220;stop acting&#8221; or &#8220;quit acting&#8221; in a post she shared Friday on Instagram. &#8220;I never quit acting,&#8221; Mendes captioned her post. ...

## 6 Conservative Comedians Who Aren’t Afraid To Mock The Left’s Insanity
 - [https://www.dailywire.com/news/6-conservative-comedians-who-arent-afraid-to-mock-the-lefts-insanity](https://www.dailywire.com/news/6-conservative-comedians-who-arent-afraid-to-mock-the-lefts-insanity)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 15:13:33+00:00

To hear the mainstream media tell it, “conservative comedian” is a contradiction in terms because conservatives are incapable of being funny. However, this stance ignores the enormously profitable careers of some right-leaning comedians who appeal to half the country. Let’s just say there’s a reason “Last Man Standing” was FOX’s second highest rated series and ...

## Biden Administration Orders Airport Ebola Screenings Amidst Deadly Ugandan Outbreak
 - [https://www.dailywire.com/news/biden-administration-orders-airport-ebola-screenings-amidst-deadly-ugandan-outbreak](https://www.dailywire.com/news/biden-administration-orders-airport-ebola-screenings-amidst-deadly-ugandan-outbreak)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 15:11:11+00:00

The Biden administration started screening travelers from Uganda for Ebola on Thursday amidst a deadly variant outbreak that has not been proven to respond to existing therapeutics or vaccines.  Ten deaths and 44 cases have been confirmed in the East African nation, and around two dozen other deaths are under investigation. Although no cases have ...

## Left Triggered By Kanye Truth Bombs, Says Ben Shapiro As Candace Owens’ BLM Doc Set To Drop
 - [https://www.dailywire.com/news/left-triggered-by-kanye-truth-bombs-says-ben-shapiro-as-candace-owens-blm-doc-set-to-drop](https://www.dailywire.com/news/left-triggered-by-kanye-truth-bombs-says-ben-shapiro-as-candace-owens-blm-doc-set-to-drop)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 14:51:46+00:00

Ben Shapiro defended Kanye West Friday, telling his vast podcast audience the rap and fashion mogul under fire for speaking his mind is on the money about abortion, Candace Owens, and Black Lives Matter being “a scam.” West, who began a tumultuous week by appearing with Daily Wire host Candace Owens at a Paris fashion show ...

## ‘I Was In Such A Dark Place’: YouTuber Lauren Southern Shares Powerful Detrans Story From Canada
 - [https://www.dailywire.com/news/i-was-in-such-a-dark-place-youtuber-lauren-southern-shares-powerful-detrans-story-from-canada](https://www.dailywire.com/news/i-was-in-such-a-dark-place-youtuber-lauren-southern-shares-powerful-detrans-story-from-canada)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 14:40:12+00:00

Some of the most powerful voices speaking out against the transgender movement come from individuals who have transitioned in the past and now regret it. Recently, Canadian YouTube personality Lauren Southern interviewed one such person who transitioned from female to male and then back again. Southern interviewed a family friend named Sarah, who explained her ...

## BREAKING: Entire Uvalde School Police Department Suspended By District
 - [https://www.dailywire.com/news/breaking-entire-uvalde-school-police-department-suspended-by-district](https://www.dailywire.com/news/breaking-entire-uvalde-school-police-department-suspended-by-district)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 14:32:08+00:00

The Uvalde Consolidated Independent School District suspended its entire police department on Friday amidst criticism of how it handled the mass shooting that killed over a dozen school children. &#8220;The District remains committed to resolving issues with verifiable evidence. Decisions concerning the UCISD police department have been pending the results of the Texas Police Chiefs ...

## Britain Could See Blackouts Through The Winter, Power Grid Warns
 - [https://www.dailywire.com/news/britain-could-see-blackouts-through-the-winter-power-grid-warns](https://www.dailywire.com/news/britain-could-see-blackouts-through-the-winter-power-grid-warns)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 13:23:29+00:00

The British power authority warned on Thursday of possible blackouts through the winter due to mounting geopolitical pressures in Europe. As ministers in some European countries contend with energy prices that have increased more than tenfold, the British National Grid’s Electricity System Operator revealed in a winter outlook that officials are likewise grappling with potential ...

## ESPN’s Foxworth Calls Out NFL Fans ‘Pretending’ To Care About Tua And Player Safety
 - [https://www.dailywire.com/news/espns-foxworth-calls-out-nfl-fans-pretending-to-care-about-tua-and-player-safety](https://www.dailywire.com/news/espns-foxworth-calls-out-nfl-fans-pretending-to-care-about-tua-and-player-safety)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 13:13:02+00:00

Yesterday, ESPN’s Dominique Foxworth was very upset with a certain segment of the NFL because of the way Dolphins quarterback Tua Tagovailoa’s head injury was handled. Foxworth basically called NFL fans ‘callous’ and ‘indifferent’ to the devastating effects playing in the NFL has on one’s body. So let me ask: Was he mad at the ...

## Man Arrested For Kidnapping And Killing Four Members Of A California Family
 - [https://www.dailywire.com/news/man-arrested-for-kidnapping-and-killing-four-members-of-a-california-family](https://www.dailywire.com/news/man-arrested-for-kidnapping-and-killing-four-members-of-a-california-family)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 12:53:40+00:00

A man has been arrested for allegedly kidnapping and killing four members of a California family, including their baby girl. Jesus Manuel Salgado, 48, was arrested Thursday night and charged with four counts of murder and four counts of kidnapping in the deaths of 8-month-old Aroohi Dheri and her parents Jasleen Kaur and Jasdeep Singh, ...

## Cori Bush Says She Changed Her Mind On Abortion But Doctor Wouldn’t Stop
 - [https://www.dailywire.com/news/cori-bush-says-she-changed-her-mind-on-abortion-but-doctor-wouldnt-stop](https://www.dailywire.com/news/cori-bush-says-she-changed-her-mind-on-abortion-but-doctor-wouldnt-stop)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 12:40:07+00:00

Rep. Cori Bush (D-MO) revealed details about an abortion she had as a teen. Bush said that just as the surgical abortion was about to begin, she told the abortionist that she was not ready, but the doctor and clinic staff ignored her and shut her objections down. The Democratic congresswoman related the story during an ...

## Teenager Arrested For Alleged Murder Of Two Other North Carolina Teens
 - [https://www.dailywire.com/news/teenager-arrested-for-alleged-murder-of-two-other-north-carolina-teens](https://www.dailywire.com/news/teenager-arrested-for-alleged-murder-of-two-other-north-carolina-teens)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 12:29:49+00:00

A 17-year-old has been arrested for allegedly killing two North Carolina teenagers in mid-September. The suspect, who has not been named due to his age, was accused of killing 14-year-old Lyric Woods and 18-year-old Devin Clark on September 17. Woods and Clark, who were friends, were separately reported missing by their families before being found ...

## Oregon Parents Are Fighting To Recall Progressive School Board Members
 - [https://www.dailywire.com/news/oregon-parents-are-fighting-to-recall-progressive-school-board-members](https://www.dailywire.com/news/oregon-parents-are-fighting-to-recall-progressive-school-board-members)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 11:59:26+00:00

Parents in Oregon&#8216;s capital city are fighting to recall multiple school board members whose progressive policies they say are harming students and families. A group of parents with students in the Salem-Keizer School District filed in late August to recall three school board members over a litany of allegations, including pornographic children&#8217;s books in the ...

## Elon Musk Announces Start Of Tesla Semi Production, Will Reach Clients Within Two Months
 - [https://www.dailywire.com/news/elon-musk-announces-start-of-tesla-semi-production-will-reach-clients-within-two-months](https://www.dailywire.com/news/elon-musk-announces-start-of-tesla-semi-production-will-reach-clients-within-two-months)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 11:54:41+00:00

Tesla CEO Elon Musk revealed on Thursday that the automaker started production on the Tesla Semi. Musk announced two months ago that the electric big rig, which was unveiled in 2017 and originally scheduled to be produced in 2019, would begin production by the end of the year. The first completed vehicles will be delivered ...

## Billionaire Moved To Florida Because Of Crime In Chicago. Now He’s Giving $100 Million To Elect Conservatives.
 - [https://www.dailywire.com/news/billionaire-moved-to-florida-because-of-crime-in-chicago-now-hes-giving-100-million-to-elect-conservatives](https://www.dailywire.com/news/billionaire-moved-to-florida-because-of-crime-in-chicago-now-hes-giving-100-million-to-elect-conservatives)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 10:53:03+00:00

Lori Lightfoot and J.B. Pritzker created a very expensive enemy. CEO Ken Griffin, the former richest man in Illinois and current chief executive of hedge fund Citadel, has contributed more than $100 million to Republican midterm candidates after moving his business and much of his personal estate from Chicago to Miami. The financier has donated ...

## ‘The Funniest Thing’: Fans Mock Chris Pratt’s Voice As ‘Super Mario Bros.’ Trailer Drops
 - [https://www.dailywire.com/news/the-funniest-thing-fans-mock-chris-pratts-voice-as-super-mario-bros-trailer-drops](https://www.dailywire.com/news/the-funniest-thing-fans-mock-chris-pratts-voice-as-super-mario-bros-trailer-drops)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 10:50:58+00:00

Fans are mostly impressed with the new trailer for the “Super Mario Bros.” movie, but many are not happy about Chris Pratt’s voiceover work. The Universal Pictures film in conjunction with Nintendo has a lot of eager fans excited for the 2023 release. Overall, the trailer is getting high marks for the animation, but viewers ...

## Sharon Osbourne Agrees Black Lives Matter Is A ‘Scam,’ Wants $900K Donation Back
 - [https://www.dailywire.com/news/sharon-osbourne-agrees-black-lives-matter-is-a-scam-wants-900k-donation-back](https://www.dailywire.com/news/sharon-osbourne-agrees-black-lives-matter-is-a-scam-wants-900k-donation-back)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 10:29:24+00:00

Sharon Osbourne doesn’t understand what message Kanye West is sending with White Lives Matter apparel, but she does agree with his belief that Black Lives Matter is a scam. The British TV personality made the comments when asked by a TMZ reporter how she felt about the recent controversy with Ye debuting White Lives Matter ...

## Republicans Demand Answers Over Report That 162 Scientists Who Worked At U.S. Nuclear Weapons Lab Went To Work For Communist China
 - [https://www.dailywire.com/news/republicans-demand-answers-over-report-that-162-scientists-who-worked-at-u-s-nuclear-weapons-lab-went-to-work-for-communist-china](https://www.dailywire.com/news/republicans-demand-answers-over-report-that-162-scientists-who-worked-at-u-s-nuclear-weapons-lab-went-to-work-for-communist-china)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 10:25:17+00:00

On Wednesday, Republicans led by U.S. Congressman Mike Waltz (R-FL) sent a letter noting a report alleging that 162 scientists who had worked for the Los Alamos National Laboratory in New Mexico, which performs research to support America’s nuclear weapons program, had went on to support the Chinese Communist Party. Strider Technologies, Inc. issued the ...

## Kanye And Candace’s ‘White Lives Matter’ Moment, And Why It’s So Important Right Now
 - [https://www.dailywire.com/news/kanye-and-candaces-white-lives-matter-moment-and-why-its-so-important-right-now](https://www.dailywire.com/news/kanye-and-candaces-white-lives-matter-moment-and-why-its-so-important-right-now)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 10:13:43+00:00

Billionaire Kanye West and The Daily Wire&#8217;s Candace Owens shocked the internet this week when they donned “White Lives Matter” apparel at Paris Fashion Week — and further enraged the media, brainwashed celebs, and cultural gatekeepers when they refused to back down. At a time when Big Tech, American institutions, and the State are tightening ...

## Prosecutors Scour Computer Of Trans TikTok Star Accused Of Molesting Children
 - [https://www.dailywire.com/news/prosecutors-scour-computer-of-trans-tiktok-star-accused-of-molesting-children](https://www.dailywire.com/news/prosecutors-scour-computer-of-trans-tiktok-star-accused-of-molesting-children)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 10:04:18+00:00

An Australian transgender TikTok star is facing a barrage of child sex abuse charges and authorities are examining the social media maven’s laptop to determine if more crimes against kids occurred. Rachel Queen Burton, 44, known on the app as Rachel.queen8008, is accused of charges ranging from gross indecency to performing a sex act with ...

## Gay Palestinian Beheaded And Paraded Through West Bank Streets In Sickening Display
 - [https://www.dailywire.com/news/gay-palestinian-beheaded-and-paraded-through-west-bank-streets-in-sickening-display](https://www.dailywire.com/news/gay-palestinian-beheaded-and-paraded-through-west-bank-streets-in-sickening-display)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 09:28:06+00:00

A gay Palestinian was kidnapped and beheaded this week and his body paraded through a Palestinian neighborhood in a sickening video that underscores the danger LGBTQ people face at the hands of Islamic extremists. Gruesome footage of Ahmad Hacham Hamdi Abu Marakhia’s body being carried through the West Bank city of Hebron and then left ...

## Miss USA Pageant Accused Of Rigging Competition After Non-Winners Walk Off Stage
 - [https://www.dailywire.com/news/miss-usa-pageant-accused-of-rigging-competition-after-non-winners-walk-off-stage](https://www.dailywire.com/news/miss-usa-pageant-accused-of-rigging-competition-after-non-winners-walk-off-stage)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 09:10:01+00:00

After many contestants walked off the stage when this year’s Miss USA was crowned, allegations were hurled at the pageant that the winner was chosen because of favoritism. R&#8217;Bonney Gabriel, Miss Texas, became the first Asian and Filipina American to win the title on Monday night, but after she was crowned and the credits rolled ...

## Kanye West Suggests The Clintons Tried To Manipulate Him Through Kim Kardashian
 - [https://www.dailywire.com/news/kanye-west-suggests-the-clintons-tried-to-manipulate-him-through-kim-kardashian](https://www.dailywire.com/news/kanye-west-suggests-the-clintons-tried-to-manipulate-him-through-kim-kardashian)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 08:40:41+00:00

Rapper Kanye West said during an interview this week that he had no idea how close his former wife, Kim Kardashian, was to the Clinton family and that he believes they tried to manipulate him through her. West made the remarks during a wide ranging interview Thursday night with Fox News host Tucker Carlson after arriving ...

## Biden Warns Putin ‘Not Joking’ About Using Nuclear Weapons In ‘Armageddon’ Situation; U.S. Stocks Up On Radiation Drugs
 - [https://www.dailywire.com/news/biden-warns-putin-not-joking-about-using-nuclear-weapons-in-armageddon-situation-u-s-stocks-up-on-radiation-drugs](https://www.dailywire.com/news/biden-warns-putin-not-joking-about-using-nuclear-weapons-in-armageddon-situation-u-s-stocks-up-on-radiation-drugs)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 08:09:45+00:00

President Joe Biden warned that Russian President Vladimir Putin was &#8220;not joking&#8221; about using nuclear weapons in Ukraine as the Russian military, which was widely viewed as the second most powerful military in the world before the war, is suffering battlefield losses in Ukraine. Biden&#8217;s remarks come as a Russian military train is reportedly transporting ...

## Kanye West Shreds The ‘Godless’ Media: ‘We Are In A Battle With The Media’
 - [https://www.dailywire.com/news/kanye-west-shreds-the-godless-media-we-are-in-a-battle-with-the-media](https://www.dailywire.com/news/kanye-west-shreds-the-godless-media-we-are-in-a-battle-with-the-media)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 08:01:07+00:00

Rapper Kanye West slammed the mainstream media during an interview this week where he said that God was preparing Christians for &#8220;real battles&#8221; against godless forces, which included the media. West made the remarks during a wide ranging interview Thursday night with Fox News host Tucker Carlson after arriving back in the U.S. from France where ...

## WATCH: Democrats In D.C. Run When Confronted By Reporter About Skyrocketing Crime Rates
 - [https://www.dailywire.com/news/watch-democrats-in-d-c-run-when-confronted-by-reporter-about-skyrocketing-crime-rates](https://www.dailywire.com/news/watch-democrats-in-d-c-run-when-confronted-by-reporter-about-skyrocketing-crime-rates)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 07:54:57+00:00

Fox News political analyst Gianno Caldwell pressed Republicans and Democrats in Washington, D.C., this week on the matter of rising crime rates across the country. Caldwell received responses from various Republicans about solutions to the problems, including House Minority Leader Kevin McCarthy (R-CA) and Rep. Elise Stefanik (R-NY). However, when he approached Democrats on the ...

## Kanye West Sounds Off On Abortion: ‘I Don’t Care About People’s Responses’ To Me Being Pro-Life
 - [https://www.dailywire.com/news/kanye-west-sounds-off-on-abortion-i-dont-care-about-peoples-responses-to-me-being-pro-life](https://www.dailywire.com/news/kanye-west-sounds-off-on-abortion-i-dont-care-about-peoples-responses-to-me-being-pro-life)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 07:39:54+00:00

Rapper Kanye West weighed in on the topic of abortion during an interview this week where he said he does not care about people&#8217;s reactions to him being pro-life. West made the remarks during a wide-ranging interview Thursday night with Fox News host Tucker Carlson after arriving back in the U.S. from Paris where he attended ...

## Report Sheds Light On Tom Brady’s Reaction To Looming Divorce From Gisele Bündchen: ‘Very Hurt By Her’
 - [https://www.dailywire.com/news/report-sheds-light-on-tom-bradys-reaction-to-looming-divorce-from-gisele-bundchen-very-hurt-by-her](https://www.dailywire.com/news/report-sheds-light-on-tom-bradys-reaction-to-looming-divorce-from-gisele-bundchen-very-hurt-by-her)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 07:32:43+00:00

A new report on Thursday shed more light into what was going on behind the scenes between star NFL quarterback Tom Brady and his supermodel wife Gisele Bündchen. News broke Tuesday that the power couple appeared to be heading toward divorce as Bündchen had hired a divorce lawyer amid weeks of speculation of marital problems ...

## Horrifying Video Shows Alleged Daycare Worker In Terrifying Halloween Mask Terrorizing Screaming Toddlers
 - [https://www.dailywire.com/news/horrifying-video-shows-alleged-daycare-worker-in-terrifying-halloween-mask-terrorizing-screaming-toddlers](https://www.dailywire.com/news/horrifying-video-shows-alleged-daycare-worker-in-terrifying-halloween-mask-terrorizing-screaming-toddlers)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-07 07:21:53+00:00

A Mississippi daycare has been harshly criticized after a horrifying video surfaced  that showed an alleged worker wearing a terrifying Halloween mask while screaming into toddlers’ faces and chasing them because they were “bad.” A daycare worker at Lil’ Blessings Childcare and Learning Center in Hamilton, Mississippi reportedly filmed the incidents last month showing the frightened children ...


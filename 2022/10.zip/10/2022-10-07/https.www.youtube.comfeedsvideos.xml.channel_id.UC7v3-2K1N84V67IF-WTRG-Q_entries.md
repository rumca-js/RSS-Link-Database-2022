# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Hellraiser (2022) - Movie Review
 - [https://www.youtube.com/watch?v=mk-zO0IMBeE](https://www.youtube.com/watch?v=mk-zO0IMBeE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-10-08 00:00:00+00:00

Go to https://buyraycon.com/JAHNS for 15% off your order! Brought to you by Raycon.

HELLRAISER joins the list of remade, re-booted, and otherwise re-done installments. Is this 2022 version worth your time? Here's my review of #Hellraiser

## The Super Mario Bros Movie - Official Teaser Trailer (My Thoughts)
 - [https://www.youtube.com/watch?v=JzGo-pSAfVw](https://www.youtube.com/watch?v=JzGo-pSAfVw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-10-07 00:00:00+00:00

After 3 decades, Mario is returning to the big screen, this time in animated form. We have ourselves our first teaser trailer, so here are my thoughts on it!

Watch the trailer here: https://www.youtube.com/watch?v=nMPCXuvL8EM&t=5s&ab_channel=NintendoofAmerica


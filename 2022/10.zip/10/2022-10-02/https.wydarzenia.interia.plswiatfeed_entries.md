# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Indonezja: Horror na stadionie piłkarskim. W zamieszkach zginęło 129 osób
 - [https://wydarzenia.interia.pl/zagranica/news-indonezja-horror-na-stadionie-pilkarskim-w-zamieszkach-zgine,nId,6322248](https://wydarzenia.interia.pl/zagranica/news-indonezja-horror-na-stadionie-pilkarskim-w-zamieszkach-zgine,nId,6322248)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2022-10-02 04:38:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-indonezja-horror-na-stadionie-pilkarskim-w-zamieszkach-zgine,nId,6322248"><img align="left" alt="Indonezja: Horror na stadionie piłkarskim. W zamieszkach zginęło 129 osób" src="https://i.iplsc.com/indonezja-horror-na-stadionie-pilkarskim-w-zamieszkach-zgine/000G59IEBPPFYK0A-C321.jpg" /></a>Po meczu piłkarskim w mieście Malang w inodezyjskiej prowincji Jawa Wschodnia doszło do zamieszek. Lokalna policja informuje, że co najmniej 129 osób zg


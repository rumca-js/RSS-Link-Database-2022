# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Ron DeSantis teams up with Elon Musk to provide relief to families affected by Hurricane Ian
 - [https://www.louderwithcrowder.com/starlink-elon-musk-ron-desantis](https://www.louderwithcrowder.com/starlink-elon-musk-ron-desantis)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-02 14:47:08+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31852752&amp;width=1245&amp;height=700&amp;coordinates=0%2C4%2C0%2C138" /><br /><br /><p>The latest collab just dropped! Ron DeSantis announced that he is teaming up with Elon Musk to provide internet coverage to families affected by Hurricane Ian. Musk, using his Starlink company, <a href="https://www.louderwithcrowder.com/elon-musk-ukraine-activates-starlink" target="_blank">has provided similar relief to other countries</a

## Bearded trans woman claims other women are misogynists for not wanting to be around her balls in the bathroom
 - [https://www.louderwithcrowder.com/misogynists-womens-bathroom](https://www.louderwithcrowder.com/misogynists-womens-bathroom)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-02 14:16:24+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31852625&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C120" /><br /><br /><p>When women say they are uncomfortable with trans women (aka "women" who used to be men and still have their ding dongs) sharing public bathrooms with them, one would assume it's because they have the old-timey belief that men shouldn't be allowed in women's washrooms. "Old-timey" means pre-2017, when Chris Cuomo said <a href="https://www.

## 'Attention Walmart Associates:' Chaos erupts when employees discover they're both shagging the same manager
 - [https://www.louderwithcrowder.com/walmart-employees-cheating](https://www.louderwithcrowder.com/walmart-employees-cheating)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-02 12:41:11+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31852591&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>I don't know what's going on at Walmart lately. <a href="https://www.louderwithcrowder.com/walmart-meltdown-cut-line" target="_blank">I'm just grateful for the content</a> and for the Walmart customers who think of us who  hustle content for a living. What we have for you is a story in two parts of a bizarre love triangle. Though it could


# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Szef MEiN pytany o ceny energii dla uczelni. "Nie widzę żadnego zagrożenia"
 - [https://www.bankier.pl/wiadomosc/Szef-MEiN-pytany-o-ceny-energii-dla-uczelni-Nie-widze-zadnego-zagrozenia-8415939.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szef-MEiN-pytany-o-ceny-energii-dla-uczelni-Nie-widze-zadnego-zagrozenia-8415939.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 21:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/b/a7918505142132-948-568-0-42-1200-719.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zapewniam rektorów uczelni, że ceny energii będą wyższe, ale nie wielokrotnie; uczelnie muszą mieć takie ceny energii, które będą do pokrycia z budżetu państwa, nad tym pracujemy - powiedział szef MEiN Przemysław Czarnek.</p>

## Wielka Brytania kupuje okręty do ochrony podmorskich kabli i rurociągów
 - [https://www.bankier.pl/wiadomosc/Wielka-Brytania-kupuje-okrety-do-ochrony-podmorskich-kabli-i-rurociagow-8415935.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wielka-Brytania-kupuje-okrety-do-ochrony-podmorskich-kabli-i-rurociagow-8415935.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 20:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/a/b143413ce7c62f-945-567-286-286-3785-2271.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brytyjski rząd zobowiązał się niedawno do zakupu dwóch specjalistycznych okrętów, które pomogą chronić podwodne kable oraz rurociągi - poinformował w niedzielę minister obrony Ben Wallace podczas konferencji Partii Konserwatywnej w Birmingham.</p>

## Stary-nowy lider w bułgarskim parlamencie. Wyniki z 99 proc. komisji
 - [https://www.bankier.pl/wiadomosc/Stary-nowy-lider-w-bulgarskim-parlamencie-Wyniki-exit-poll-8415918.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stary-nowy-lider-w-bulgarskim-parlamencie-Wyniki-exit-poll-8415918.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 19:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/f/e59d9a8fe20063-948-568-170-30-3830-2297.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pierwsze miejsce w niedzielnych przedterminowych wyborach parlamentarnych w Bułgarii zajęła centroprawicowa partia GERB byłego premiera Bojko Borisowa, która otrzymała 25,4 proc. głosów - poinformowała Centralna Komisja Wyborcza po przeliczeniu 99 proc. kart do głosowania.</

## Fala krytyki pod adresem rosyjskiego dowództwa wojskowego po utracie Łymanu
 - [https://www.bankier.pl/wiadomosc/Fala-krytyki-pod-adresem-rosyjskiego-dowodztwa-wojskowego-po-utracie-Lymanu-8415907.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fala-krytyki-pod-adresem-rosyjskiego-dowodztwa-wojskowego-po-utracie-Lymanu-8415907.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 18:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/b/c8f088222e5746-948-568-0-176-3201-1920.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Odbicie przez wojska ukraińskie Łymanu wywołało w Rosji falę krytyki pod adresem resortu obrony i dowódców odpowiedzialnych za rosyjskie zgrupowanie. Wśród krytyków są przywódca Czeczenii, szef najemniczej Grupy Wagnera i kilku blogerów wojskowych. „Siłowicy zaczynają się gry

## Kaczyński: Celujemy w węgiel za 1000 zł
 - [https://www.bankier.pl/wiadomosc/Kaczynski-Celujemy-w-wegiel-za-1000-zl-8415905.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaczynski-Celujemy-w-wegiel-za-1000-zl-8415905.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 18:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/578cf4755bcc22-948-568-0-23-1024-614.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będą dopłaty i cały mechanizm obniżenia ceny węgla – celem jest 1999 zł, plus 1000 zł dopłaty, czyli węgiel po 1000 zł – powiedział w niedzielę w Szczecinie prezes PiS Jarosław Kaczyński.</p>

## Zgodnie z sugestią rządu Karol III nie pojedzie na szczyt klimatyczny COP27
 - [https://www.bankier.pl/wiadomosc/Zgodnie-z-sugestia-rzadu-Karol-III-nie-pojedzie-na-szczyt-klimatyczny-COP27-8415885.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zgodnie-z-sugestia-rzadu-Karol-III-nie-pojedzie-na-szczyt-klimatyczny-COP27-8415885.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 17:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/d/b3bc32ef3ebce1-948-567-0-7-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Król Wielkiej Brytanii Karol III, od dawna angażujący się w ochronę środowiska, nie pojedzie na ONZ-owski szczyt klimatyczny COP27, który odbędzie się w listopadzie w Egipcie, choć został tam zaproszony - potwierdził w niedzielę Pałac Buckingham.</p>

## "WP": Putin zatwierdził wymianę Medwedczuka na jeńców z Mariupola mimo sprzeciwu FSB
 - [https://www.bankier.pl/wiadomosc/WP-Putin-zatwierdzil-wymiane-Medwedczuka-na-jencow-z-Mariupola-mimo-sprzeciwu-FSB-8415789.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/WP-Putin-zatwierdzil-wymiane-Medwedczuka-na-jencow-z-Mariupola-mimo-sprzeciwu-FSB-8415789.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 17:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/f/ca9cf0ba106a77-948-568-0-60-1739-1043.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Rosji Władimir Putin wyraził zgodę na wymianę jeńców, w ramach której zwolniono m.in. dowódców obrony Mariupola i prokremlowskiego oligarchę Wiktora Medwedczuka, mimo stanowczego sprzeciwu Federalnej Służby Bezpieczeństwa (FSB) – podał dziennik "Washington Post", pow

## Żołnierz z Azowstalu o rosyjskiej niewoli: Byliśmy traktowani jak zwierzęta
 - [https://www.bankier.pl/wiadomosc/Zolnierz-z-Azowstalu-o-rosyjskiej-niewoli-Bylismy-traktowani-jak-zwierzeta-8415886.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zolnierz-z-Azowstalu-o-rosyjskiej-niewoli-Bylismy-traktowani-jak-zwierzeta-8415886.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 16:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/7/7ced7af4a92cf7-948-568-0-64-1600-959.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Traktowali nas jak zwierzęta – powiedział telewizji Sky News Mychajło Dianow, żołnierz ukraińskiej piechoty morskiej, który brał udział w obronie Mariupola i zakładów Azowstal, a potem trafił do rosyjskiej niewoli.</p>

## Firmy z UE nie będą mogły przewozić ładunków po terytorium Rosji
 - [https://www.bankier.pl/wiadomosc/Rosja-zakazala-przewozu-ladunkow-po-swoim-terytorium-firmom-z-krajow-UE-8415880.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosja-zakazala-przewozu-ladunkow-po-swoim-terytorium-firmom-z-krajow-UE-8415880.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 15:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/8d91dac74bda3f-925-554-75-5-925-554.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władze Rosji zakazały przewozu ładunków po terytorium Rosji firmom z krajów UE, Wielkiej Brytanii, Norwegii i Ukrainie – poinformowało Radio Swoboda.</p>

## Niemcy, Dania i Norwegia chcą dostarczyć Ukrainie 16 haubic Zuzana 2 produkcji słowackiej
 - [https://www.bankier.pl/wiadomosc/Niemcy-Dania-i-Norwegia-chca-dostarczyc-Ukrainie-16-haubic-Zuzana-2-produkcji-slowackiej-8415879.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niemcy-Dania-i-Norwegia-chca-dostarczyc-Ukrainie-16-haubic-Zuzana-2-produkcji-slowackiej-8415879.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 15:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/6/66223d8571092b-948-568-37-405-2637-1582.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Minister obrony Christine Lambrecht zapowiedziała w niedzielę dostarczenie Ukrainie w przyszłym roku 16 haubic Zuzana 2 produkcji słowackiej. W 2023 roku "będziemy mogli dostarczyć Ukrainie 16 systemów haubicy Zuzana, finansowanych przez Niemcy wraz z Danią i Norwegią, a pro

## Airbnb od króla Karola III? Sandringham i Balmoral do wynajęcia
 - [https://www.bankier.pl/wiadomosc/Airbnb-od-krola-Karola-III-Sandringham-i-Balmoral-do-wynajecia-8401834.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Airbnb-od-krola-Karola-III-Sandringham-i-Balmoral-do-wynajecia-8401834.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 14:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/9/b14333caeeee7a-948-568-2-47-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />To już kolejna nieruchomość należąca do brytyjskiej rodziny królewskiej, którą można wynająć. Sandringham w Norfolk, a dokładniej dawny domek głównego ogrodnika, trafił do serwisu Airbnb. Jak tak dalej pójdzie, powinni oni otworzyć swój podserwis Airbnb, zwany "Heirbnb". Dzięki 

## Dyrektor krakowskiego szpitala: Inflacja w ochronie zdrowia jest znacznie wyższa, niż wynika z danych GUS
 - [https://www.bankier.pl/wiadomosc/Dyrektor-krakowskiego-szpitala-Inflacja-w-ochronie-zdrowia-jest-znacznie-wyzsza-niz-wynika-z-danych-GUS-8415070.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dyrektor-krakowskiego-szpitala-Inflacja-w-ochronie-zdrowia-jest-znacznie-wyzsza-niz-wynika-z-danych-GUS-8415070.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 13:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/6/db8904b7202c55-948-568-15-134-2985-1790.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inflacja w służbie zdrowia jest znacznie wyższa niż wynika z danych przedstawianych przez GUS – ocenił dyrektor Szpitala Uniwersyteckiego w Krakowie Marcin Jędrychowski. W placówce tej weryfikowane są wydatki związane m.in. z oświetleniem i ogrzewaniem.</p>

## Duńska Agencja Energii: gaz przestał wyciekać również z Nord Stream 1
 - [https://www.bankier.pl/wiadomosc/Dunska-Agencja-Energii-gaz-przestal-wyciekac-rowniez-z-Nord-Stream-1-8415844.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dunska-Agencja-Energii-gaz-przestal-wyciekac-rowniez-z-Nord-Stream-1-8415844.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 13:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/18410c29c7ca5c-948-568-0-2-1146-687.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Gaz przestał już wyciekać także z rurociągu Nord Stream 1 - poinformowała w niedzielę Duńska Agencja Energii. Wcześniej, w sobotę, ustąpił wyciek z Nord Stream 2.</p>

## Kaczyński: 14. emeryturę chcemy zmienić w trwałe świadczenie, wypłacane co roku
 - [https://www.bankier.pl/wiadomosc/Kaczynski-14-emeryture-chcemy-zmienic-w-trwale-swiadczenie-wyplacane-co-roku-8415687.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaczynski-14-emeryture-chcemy-zmienic-w-trwale-swiadczenie-wyplacane-co-roku-8415687.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/5/63fad046917cc6-948-568-5-17-1077-646.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czternastkę chcemy zmienić w trwałe świadczenie. Nie takie jednoroczne, jak było początkowo planowane, tylko trwałe – powiedział prezes PiS Jarosław Kaczyński podczas spotkania z działaczami w Kołobrzegu.</p>

## Morawiecki: Cieszę się ze zwycięstwa Giorgii Meloni; wygląda na to, że w Europie nadchodzi czas zmiany
 - [https://www.bankier.pl/wiadomosc/Morawiecki-skomentowal-wyniki-wyborow-parlamentarnych-we-Wloszech-8415831.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Morawiecki-skomentowal-wyniki-wyborow-parlamentarnych-we-Wloszech-8415831.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 11:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/3/69f413a6bae116-948-568-120-131-4277-2566.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Osobiście cieszę się i gratuluję z całego serca zwycięstwa Giorgii Meloni; wygląda na to, że w Europie nadchodzi czas zmiany - podkreślił w niedzielę premier Mateusz Morawiecki. Według niego, Włosi sami najlepiej wiedzą, co jest dla nich dobre i nikt nie ma prawa kwestionow

## "Guardian": rosyjscy neonaziści walczą przeciwko Ukrainie, nawołują do torturowania jeńców
 - [https://www.bankier.pl/wiadomosc/Guardian-rosyjscy-neonazisci-walcza-przeciwko-Ukrainie-nawoluja-do-torturowania-jencow-8415820.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Guardian-rosyjscy-neonazisci-walcza-przeciwko-Ukrainie-nawoluja-do-torturowania-jencow-8415820.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 11:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/6/9e2ab4dda62a19-948-568-0-36-1805-1083.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Związana z tzw. grupą Wagnera rosyjska neonazistowska bojówka Rusicz walczy na Ukrainie i dopuszcza się okrucieństw; otwarcie nawołuje też do zabijania i torturowania ukraińskich jeńców – zaalrmował w niedzielę brytyjski dziennik "Guardian".</p>

## Pierwsza morska farma wiatrowa we Francji już produkuje prąd. Koszt budowy wyniósł 2 mld euro
 - [https://www.bankier.pl/wiadomosc/Pierwsza-morska-farma-wiatrowa-we-Francji-juz-produkuje-prad-Koszt-budowy-wyniosl-2-mld-euro-8415783.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pierwsza-morska-farma-wiatrowa-we-Francji-juz-produkuje-prad-Koszt-budowy-wyniosl-2-mld-euro-8415783.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/9e55709ec1f4f9-948-568-22-59-2977-1786.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pierwsza morska farma wiatrowa we Francji z 80 turbinami wiatrowymi została otwarta nad Atlantykiem pod koniec września. Koszt tej inwestycji to 2 mld euro. Przyszłością są także dryfujące farmy, które również konstruujemy – mówi PAP dyrektor ds. energii morskich EDF Renouvel

## Ukraiński sztab: rosyjska armia straciła już ponad 60 tys. wojskowych
 - [https://www.bankier.pl/wiadomosc/Ukrainski-sztab-rosyjska-armia-stracila-juz-ponad-60-tys-wojskowych-8415786.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukrainski-sztab-rosyjska-armia-stracila-juz-ponad-60-tys-wojskowych-8415786.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 08:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/4/35d5fe2126a755-948-568-15-74-1985-1190.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od początku inwazji armia Rosji straciła już na Ukrainie ok. 60,1 tys. wojskowych  - poinformował w niedzielę Sztab Generalny Sił Zbrojnych Ukrainy. Minionej doby straty przeciwnika wyniosły pół tysiąca osób - dodano.</p>

## Z powodu inflacji coraz więcej Amerykanów żyje od wypłaty do wypłaty
 - [https://www.bankier.pl/wiadomosc/Z-powodu-inflacji-coraz-wiecej-Amerykanow-zyje-od-wyplaty-do-wyplaty-8415460.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Z-powodu-inflacji-coraz-wiecej-Amerykanow-zyje-od-wyplaty-do-wyplaty-8415460.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 08:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/794b386d53e942-945-560-1136-1136-3337-2002.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W związku z utrzymującą się inflacją, liczba Amerykanów żyjących od wypłaty do wypłaty rośnie. Prawie wszyscy odczuwają skutki coraz wyższych cen. Jak wynika z ostatniego raportu LendingClub, w sierpniu br. 60 proc. ludzi żyło od wypłaty do wypłaty. Rok temu odsetek ten w

## 60 proc. badanych przeciwko złagodzeniu sankcji na Rosję. Nawet jeśli obniżyłoby to ceny energii
 - [https://www.bankier.pl/wiadomosc/SONDAZ-8415770.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/SONDAZ-8415770.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 07:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/5/5598167f1b88d6-948-568-1244-1142-1969-1181.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prawie 60 proc. ankietowanych udzieliło odpowiedzi "nie" w sondażu SW Research dla rp.pl, w którym pytano respondentów,  czy ich zdaniem Zachód, by obniżyć ceny energii, powinien złagodzić lub wycofać się z sankcji nałożonych na Rosję. Odpowiedź "Tak" wybrało prawie 16 pr

## Ekspert: Sieci handlowe są zdeterminowane, by otwierać sklepy w niedzielę. Zaostrzenie kar nie rozwiąże problemu
 - [https://www.bankier.pl/wiadomosc/Ekspert-Sieci-handlowe-sa-zdeterminowane-by-otwierac-sklepy-w-niedziele-Zaostrzenie-kar-nie-rozwiaze-problemu-8415751.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekspert-Sieci-handlowe-sa-zdeterminowane-by-otwierac-sklepy-w-niedziele-Zaostrzenie-kar-nie-rozwiaze-problemu-8415751.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 05:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/d/41f1e2d0ace0f3-948-568-0-303-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sieci handlowe są mocno zdeterminowane, żeby znajdować luki w ustawie i otwierać sklepy w niedzielę – powiedział PAP główny ekonomista Grupy BLIX Krzysztof Łuczak. Dodał, że samo zaostrzenie kar, którego chce NSZZ "Solidarność", nie rozwiąże problemu.</p>

## Ile zarabia się w Belgii? Średnie zarobki to prawie 4 tys. euro brutto miesięcznie
 - [https://www.bankier.pl/wiadomosc/Ile-zarabia-sie-w-Belgii-Srednie-zarobki-to-prawie-4-tys-euro-brutto-miesiecznie-8413619.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ile-zarabia-sie-w-Belgii-Srednie-zarobki-to-prawie-4-tys-euro-brutto-miesiecznie-8413619.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/dbe53ee2040dc1-945-560-3-0-1496-897.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najwyższe zarobki w Belgii są w przemyśle petrochemicznym, a najmniejsze w sektorze hotelarskim - wynika z raportu Belgijskiego Urzędu Statystycznego (Statbel). Średnie wynagrodzenie w Belgii wynosi 3832 euro brutto miesięcznie.</p>

## Pieszy ze słuchawkami w uszach. Ubezpieczyciel pomniejszy wypłatę z OC
 - [https://www.bankier.pl/wiadomosc/Pieszy-ze-sluchawkami-w-uszach-Ubezpieczyciel-pomniejszy-wyplate-z-OC-8413622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pieszy-ze-sluchawkami-w-uszach-Ubezpieczyciel-pomniejszy-wyplate-z-OC-8413622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-02 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/9a10890e847440-948-568-0-0-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Piesi
oraz rowerzyści (zwłaszcza młodzi) dość często korzystają ze słuchawek. Wyjaśniamy,
jak taka sytuacja może wpływać na wysokość odszkodowania za wypadek.</p>


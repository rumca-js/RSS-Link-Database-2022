# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Bailey Zappe's first Patriots touchdown pass covered with controversy
 - [https://www.foxnews.com/sports/bailey-zappes-first-patriots-touchdown-pass-covered-controversy](https://www.foxnews.com/sports/bailey-zappes-first-patriots-touchdown-pass-covered-controversy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 23:55:59+00:00

The New England Patriots put third-string quarterback Bailey Zappe in the game after Brian Hoyer went out, and though he tossed his first touchdown, it came with some controversy.

## Trey Gowdy previews new Supreme Court term starting on Monday
 - [https://www.foxnews.com/media/trey-gowdy-previews-new-supreme-court-term-starting-monday](https://www.foxnews.com/media/trey-gowdy-previews-new-supreme-court-term-starting-monday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 23:45:02+00:00

Fox News host Trey Gowdy warned about the growing politicization of the Supreme Court ahead of a new docket of cases expected to be heard by the justices on Monday.

## American Airlines flight evacuated in Albuquerque due to security threat, authorities say
 - [https://www.foxnews.com/us/american-airlines-flight-evacuated-in-albuquerque-due-security-threat-authorities](https://www.foxnews.com/us/american-airlines-flight-evacuated-in-albuquerque-due-security-threat-authorities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 23:41:47+00:00

An American Airlines plane had to be evacuated on Sunday after an undisclosed security threat that was later determined to be non-credible.

## Texas man arrested for allegedly stabbing food truck worker during botched robbery: report
 - [https://www.foxnews.com/us/texas-man-arrested-allegedly-stabbing-food-truck-worker-botched-robbery-report](https://www.foxnews.com/us/texas-man-arrested-allegedly-stabbing-food-truck-worker-botched-robbery-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 23:23:40+00:00

The Austin Police Department arrested a man on aggravated robbery charges for allegedly stabbing a food truck worker this week during an attempted robbery.

## Democratic lawmaker slams capitalism, calls America 'a nation based on grift'
 - [https://www.foxnews.com/media/democratic-lawmaker-slams-capitalism-calls-america-nation-based-grift](https://www.foxnews.com/media/democratic-lawmaker-slams-capitalism-calls-america-nation-based-grift)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 23:16:36+00:00

Rep. Mark Pocan, D-Wis., criticized capitalism and the Republican Party during his appearance on SiriusXM's "The Dean Obeidallah Show" on Friday.

## Los Angeles Unified School District hackers release data after ransom demand denied
 - [https://www.foxnews.com/us/los-angeles-unified-school-district-hackers-release-data-ransom-demand-denied](https://www.foxnews.com/us/los-angeles-unified-school-district-hackers-release-data-ransom-demand-denied)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 23:16:21+00:00

A criminal enterprise that hacked the Los Angeles Unified School District (LAUSD) has released the information after the district refused to give into the group's demands.

## Seahawks' DK Metcalf explains why he used cart to get to bathroom during game
 - [https://www.foxnews.com/sports/seahawks-dk-metcalf-explains-why-used-cart-get-bathroom-game](https://www.foxnews.com/sports/seahawks-dk-metcalf-explains-why-used-cart-get-bathroom-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 23:10:57+00:00

DK Metcalf briefly gave Seattle Seahawks fans a scare in the fourth quarter when he was carted off the field. No worries, he just needed to use the bathroom.

## Ravens' Marcus Peters, John Harbaugh get into heated exchange on sideline: 'Emotions run high'
 - [https://www.foxnews.com/sports/ravens-marcus-peters-john-harbaugh-get-heated-exchange-sideline-emotions-run-high](https://www.foxnews.com/sports/ravens-marcus-peters-john-harbaugh-get-heated-exchange-sideline-emotions-run-high)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 23:00:42+00:00

Baltimore Ravens coach John Harbaugh commented on the sideline spat with Marcus Peters at the end of their game against the Buffalo Bills on Sunday.

## VP Kamala Harris dodges question asking about dispersing Hurricane Ian relief based on 'equity'
 - [https://www.foxnews.com/politics/kamala-harris-dodges-question-asking-about-dispersing-hurricane-ian-relief-based-equity](https://www.foxnews.com/politics/kamala-harris-dodges-question-asking-about-dispersing-hurricane-ian-relief-based-equity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 23:00:25+00:00

Vice President Kamala Harris didn't answer a question asking her to clarify comments she made on Friday when she said that "equity" will be taken into account for hurricane relief.

## Chuck Todd and Symone Sanders-Townsend excuse Biden’s ‘Jackie’ gaffe on Meet the Press: We’ve all done it
 - [https://www.foxnews.com/media/chuck-todd-symone-sanders-townsend-excuse-bidens-jackie-gaffe-meet-press-done](https://www.foxnews.com/media/chuck-todd-symone-sanders-townsend-excuse-bidens-jackie-gaffe-meet-press-done)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 22:53:44+00:00

Two media figures downplayed a now-infamous gaffe from President Biden, where he appeared to call out at a conference for a fellow politician who had recently died.

## Seahawks' offense outduels Lions, Rashaad Penny rushes for over 150 yards
 - [https://www.foxnews.com/sports/seahawks-offense-outduels-lions-rashaad-penny-rushes-over-150-yards](https://www.foxnews.com/sports/seahawks-offense-outduels-lions-rashaad-penny-rushes-over-150-yards)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 22:53:12+00:00

The Seattle Seahawks' offense was just slightly better than the Detroit Lions on the road, winning 48-45 to capture their second win of the season.

## Florida teen dead, two others injured after crashing stolen Maserati: police
 - [https://www.foxnews.com/us/florida-teen-dead-two-others-injured-crashing-stolen-maserati-police](https://www.foxnews.com/us/florida-teen-dead-two-others-injured-crashing-stolen-maserati-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 22:38:49+00:00

One teen is dead and two others are seriously injured after allegedly crashing a stolen Maserati around 3:30 a.m. on Sunday morning in St. Petersburg, Florida.

## King Charles III may remove Princess Beatrice and Princess Eugenie's royal titles due to Prince Andrew: expert
 - [https://www.foxnews.com/entertainment/king-charles-iii-may-remove-princess-beatrice-princess-eugenie-royal-titles-prince-andrew-expert](https://www.foxnews.com/entertainment/king-charles-iii-may-remove-princess-beatrice-princess-eugenie-royal-titles-prince-andrew-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 22:30:22+00:00

King Charles "making British monarchy decisions" after Queen's death, including possibly changing royal titles of Princess Beatrice and Princess Eugenie.

## Chase Elliott holds off Ryan Blaney, wins at Talladega by less than 1 second
 - [https://www.foxnews.com/sports/chase-elliott-holds-off-ryan-blaney-wins-talledega-less-than-1-second](https://www.foxnews.com/sports/chase-elliott-holds-off-ryan-blaney-wins-talledega-less-than-1-second)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 22:08:22+00:00

Chase Elliott propelled himself into the next round of the NASCAR playoffs with a win in the YellaWood 500 at Talladega Superspeedway on Sunday.

## Giants avoid embarrassment after chaos ensues on last-ditch effort from Bears
 - [https://www.foxnews.com/sports/giants-avoid-embarrassment-chaos-ensues-last-ditch-effort-bears](https://www.foxnews.com/sports/giants-avoid-embarrassment-chaos-ensues-last-ditch-effort-bears)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 21:57:55+00:00

The New York Giants avoided a touchdown on a chaotic, lateral-filled final play of the game for the Chicago Bears to improve to 3-1 on the season.

## Eagles shake off slow start vs. Jaguars, remain only unbeaten team in NFL
 - [https://www.foxnews.com/sports/eagles-shake-off-slow-start-jaguars-remain-only-unbeaten-team-nfl](https://www.foxnews.com/sports/eagles-shake-off-slow-start-jaguars-remain-only-unbeaten-team-nfl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 21:44:30+00:00

The Philadelphia Eagles bounced back from a shaky start against the Jacksonville Jaguars to remain the NFL's only unbeaten team so far this season.

## Justin Herbert, Austin Ekeler lead Chargers to win over Texans
 - [https://www.foxnews.com/sports/justin-herbert-austin-ekeler-lead-chargers-win-texans](https://www.foxnews.com/sports/justin-herbert-austin-ekeler-lead-chargers-win-texans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 21:20:25+00:00

Austin Ekeler finally had the breakout game the Los Angeles Chargers were hoping for Sunday with three touchdowns. Justin Herbert had two touchdown passes.

## University of Chicago student organization hosts 'BIPOC-only' discussion about race on campus
 - [https://www.foxnews.com/us/university-chicago-student-organization-hosts-bipoc-only-discussion-about-race-campus](https://www.foxnews.com/us/university-chicago-student-organization-hosts-bipoc-only-discussion-about-race-campus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 21:19:13+00:00

A University of Chicago student organization is hosting a "BIPOC-only" discussion on race as part of the group's "dis-orientation" that is hosted in the fall semester.

## Bills take advantage of Lamar Jackson's interceptions, Tyler Bass kicks game-winner as time expires
 - [https://www.foxnews.com/sports/bills-take-advantage-lamar-jacksons-interceptions-tyler-bass-kicks-game-winner-time-expires](https://www.foxnews.com/sports/bills-take-advantage-lamar-jacksons-interceptions-tyler-bass-kicks-game-winner-time-expires)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 21:14:47+00:00

Buffalo Bills kicker Tyler Bass knocked through the game-winning field goal, as the Baltimore Ravens' crucial turnovers led to a brutal 23-20 loss at home.

## California Gov. Gavin Newsom signs bill decriminalizing jaywalking
 - [https://www.foxnews.com/us/california-gov-gavin-newsom-signs-bill-decriminalizing-jaywalking](https://www.foxnews.com/us/california-gov-gavin-newsom-signs-bill-decriminalizing-jaywalking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 21:12:42+00:00

California Gov. Gavin Newsom on Friday signed a bill decriminalizing jaywalking in instances where it is safe to do so, which proponents say will address racial profiling.

## Zach Wilson returns to help Jets win, Kenny Pickett makes Steelers debut
 - [https://www.foxnews.com/sports/zach-wilson-returns-help-jets-win-kenny-pickett-makes-steelers-debut](https://www.foxnews.com/sports/zach-wilson-returns-help-jets-win-kenny-pickett-makes-steelers-debut)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 21:04:48+00:00

Zach Wilson had a touchdown in his return to the field for the New York Jets and the team to a victory over the Pittsburgh Steelers on Sunday.

## Derrick Henry leads Titans to win over Colts with season-high rushing total
 - [https://www.foxnews.com/sports/derrick-henry-leads-titans-win-colts-season-high-rushing-total](https://www.foxnews.com/sports/derrick-henry-leads-titans-win-colts-season-high-rushing-total)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 20:45:46+00:00

Derrick Henry looked like his old self on Sunday as he rushed for 114 yards and a touchdown in the Tennessee Titans' 24-17 victory over the Indianapolis Colts.

## Cooper Rush leads Cowboys to 3rd straight win, gets big boost from defense
 - [https://www.foxnews.com/sports/cooper-rush-leads-cowboys-3rd-straight-win-gets-big-boost-defense](https://www.foxnews.com/sports/cooper-rush-leads-cowboys-3rd-straight-win-gets-big-boost-defense)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 20:38:57+00:00

Cooper Rush did it again. The Dallas Cowboys' backup led the team to a third consecutive victory, this time against the Washington Commanders.

## Steelers rookie Kenny Pickett finds end zone on gritty runs after replacing Mitch Trubisky
 - [https://www.foxnews.com/sports/steelers-rookie-kenny-pickett-finds-end-zone-gritty-runs-replacing-mitch-trubisky](https://www.foxnews.com/sports/steelers-rookie-kenny-pickett-finds-end-zone-gritty-runs-replacing-mitch-trubisky)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 20:38:57+00:00

Kenny Pickett got his first taste of regular season NFL football as the Pittsburgh Steelers put the rookie quarterback in for Mitch Trubisky on Sunday.

## Ukraine's path to NATO membership gains support of 9 countries including some former Soviet Bloc states
 - [https://www.foxnews.com/world/9-nato-countries-support-ukraines-path-membership-support-nine-countries-former-soviet-bloc](https://www.foxnews.com/world/9-nato-countries-support-ukraines-path-membership-support-nine-countries-former-soviet-bloc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 20:38:22+00:00

Nine NATO countries expressed their support for Ukraine's aspirations to join NATO and condemned Russia's annexation in a joint statement on Sunday.

## Oakland shooting leaves 2 dead and 2 injured
 - [https://www.foxnews.com/us/oakland-shooting-leaves-dead-injured](https://www.foxnews.com/us/oakland-shooting-leaves-dead-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 20:29:00+00:00

Oakland police said that a shooting on Saturday night left two people dead as well as another two people injured just before 10 p.m., according to a report.

## HARDY, Morgan Wallen's songwriter, injured in tour bus crash
 - [https://www.foxnews.com/entertainment/hardy-morgan-wallen-songwriter-injured-tour-bus-crash](https://www.foxnews.com/entertainment/hardy-morgan-wallen-songwriter-injured-tour-bus-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 20:26:24+00:00

HARDY, country musician and songwriter for Morgan Wallen, Chris Lane and Blake Shelton, was involved in a crash in Tennessee after a show Sunday morning.

## Abortion ranks 7th as most important issue to Latino voters, behind economy and border: poll
 - [https://www.foxnews.com/politics/abortion-ranks-7th-most-important-issue-latino-voters-behind-economy-border-poll](https://www.foxnews.com/politics/abortion-ranks-7th-most-important-issue-latino-voters-behind-economy-border-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 20:24:08+00:00

Only 5% of Latino voters said abortion is the "most important issue facing the country," according to a poll released less than six weeks ahead of the midterm elections.

## Iranian officials chant 'death to America, death to Israel' in government body: watch the video
 - [https://www.foxnews.com/world/iranian-officials-chant-death-america-death-israel-government-body-watch-video](https://www.foxnews.com/world/iranian-officials-chant-death-america-death-israel-government-body-watch-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 19:42:30+00:00

The Iranian government has repeatedly claimed that the protests resulted from foreign influence, with the U.S. and Israel painted as the primary antagonists.

## Antonio Inoki, global pro wrestling icon, dead at 79
 - [https://www.foxnews.com/sports/antonio-inoki-global-pro-wrestling-icon-dead-79](https://www.foxnews.com/sports/antonio-inoki-global-pro-wrestling-icon-dead-79)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 19:34:12+00:00

Antonio Inoki, a pro wrestling legend and Japanese politician died on Friday, according to WWE and New Japan Pro-Wrestling. He was 79.

## New York City 15-year-old shot during argument in the Bronx, police searching for two suspects
 - [https://www.foxnews.com/us/new-york-city-15-year-old-shot-during-argument-bronx-police-searching-two-suspects](https://www.foxnews.com/us/new-york-city-15-year-old-shot-during-argument-bronx-police-searching-two-suspects)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 19:32:13+00:00

A 15-year-old was shot once in the ankle after getting into a "verbal dispute" with two suspects on a Bronx street on Friday evening, according to the NYPD.

## Australia CPAC stage rushed by far-left activists reportedly targeting UK's Nigel Farage
 - [https://www.foxnews.com/politics/australia-cpac-stage-rushed-far-left-activists-targeting-uk-nigel-farage](https://www.foxnews.com/politics/australia-cpac-stage-rushed-far-left-activists-targeting-uk-nigel-farage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 19:29:46+00:00

Around 100 activists rushed the entrance of the International Convention Center, but police intervened, leaving the protesters to confront attendees as they entered.

## New Virginia law mandates public schools alert parents to sexually explicit instructional material
 - [https://www.foxnews.com/us/new-virginia-law-mandates-public-schools-alert-parents-sexually-explicit-instructional-material](https://www.foxnews.com/us/new-virginia-law-mandates-public-schools-alert-parents-sexually-explicit-instructional-material)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 19:17:13+00:00

A new Virginia law would mandate public school notify parents when their children could be exposed to sexually explicit material and give them an alternative to such instruction.

## Former Missouri substitute teacher accused of raping student found dead in jail cell
 - [https://www.foxnews.com/us/former-missouri-substitute-teacher-accused-raping-student-found-dead-jail-cell](https://www.foxnews.com/us/former-missouri-substitute-teacher-accused-raping-student-found-dead-jail-cell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 19:13:08+00:00

A former substitute teacher in Missouri charged with raping a student and threatening her to be silent was found unresponsive in his jail cell this week.

## Last WWII Medal of Honor recipient's foundation carries on legacy helping Gold Star families: 'Here to serve'
 - [https://www.foxnews.com/us/last-wwii-medal-honor-recipients-foundation-carries-legacy-helping-gold-star-families-here-serve](https://www.foxnews.com/us/last-wwii-medal-honor-recipients-foundation-carries-legacy-helping-gold-star-families-here-serve)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 19:12:45+00:00

The Woody Williams Foundation, founded by the late World War II veteran Hershel Woodrow "Woody" Williams, aims to continue his legacy of honoring Gold Star families nationwide.

## Dems lose ground to Republicans with Latino voters ahead of 2022 midterm elections
 - [https://www.foxnews.com/politics/dems-lose-ground-republicans-latino-voters-2022-midterm-elections](https://www.foxnews.com/politics/dems-lose-ground-republicans-latino-voters-2022-midterm-elections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 19:05:17+00:00

The nationwide support for Democrats over Republicans from Latino voters has declined since previous election cycles, a new NBC News/Telemundo poll has found.

## St. Augustine, Florida firefighter rescues little girl during Hurricane Ian flooding
 - [https://www.foxnews.com/us/st-augustine-florida-firefighter-rescues-little-girl-during-hurricane-ian-flooding](https://www.foxnews.com/us/st-augustine-florida-firefighter-rescues-little-girl-during-hurricane-ian-flooding)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 19:00:53+00:00

A Florida firefighter was shown rescuing a little girl from rising flood waters in St. Augustine as Hurricane Ian continues to devastate the state with historic floods and rain.

## University of Minnesota researchers find ancient meteor crash site below suburb
 - [https://www.foxnews.com/us/university-minnesota-researchers-find-ancient-meteor-crash-site-below-suburb](https://www.foxnews.com/us/university-minnesota-researchers-find-ancient-meteor-crash-site-below-suburb)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:53:20+00:00

A team of researchers from the University of Minnesota discovered an ancient crater 350 feet below a Mississippi River suburb all while updating a geologic county map.

## Body cam footage shows Arizona authorities opening fire on suspect as he aims gun at K9's head
 - [https://www.foxnews.com/us/body-cam-footage-arizona-authorities-opening-fire-suspect-aims-gun-k9s-head](https://www.foxnews.com/us/body-cam-footage-arizona-authorities-opening-fire-suspect-aims-gun-k9s-head)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:50:24+00:00

A suspect in Arizona who refused to comply with a SWAT team that was surveilling him was seen on body cam footage pointing at handgun at a police dog's head as well as officers.

## AP Top 25 poll: Kansas back in the rankings for first time since 2009
 - [https://www.foxnews.com/sports/ap-top-25-poll-kansas-back-irankings-first-time-2009](https://www.foxnews.com/sports/ap-top-25-poll-kansas-back-irankings-first-time-2009)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:49:06+00:00

Kansas is back in the Associated Press Top 25 college football poll for the first time since 2009 while Alabama reclaimed the top spot.

## Biden thanks Coast Guard rescuer for hurricane heroics days before firing over vaccine policy
 - [https://www.foxnews.com/politics/biden-thanks-coast-guard-rescuer-hurricane-heroics-days-before-firing-vaccine-policy](https://www.foxnews.com/politics/biden-thanks-coast-guard-rescuer-hurricane-heroics-days-before-firing-vaccine-policy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:48:20+00:00

U.S. Coast Guard Technician Second Class Zach Loesch says he is due to be discharged over his COVID-19 vaccine stance even after getting a call from President Biden.

## Supreme Court legitimacy 'on the line,' no telling what 'damage they'll do to democracy': Donna Brazile
 - [https://www.foxnews.com/media/supreme-court-legitimacy-on-line-no-telling-what-damage-theyll-do-democracy-donna-brazile](https://www.foxnews.com/media/supreme-court-legitimacy-on-line-no-telling-what-damage-theyll-do-democracy-donna-brazile)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:47:41+00:00

Donna Brazile said Sunday on ABC's "This Week" that Supreme Court legitimacy was "on the line" ahead of the start of a "consequential term" on Monday.

## Despite Ian's punch, wedding day saved on wet Pawleys Island
 - [https://www.foxnews.com/us/despite-ian-punch-wedding-day-saved-wet-pawleys-island](https://www.foxnews.com/us/despite-ian-punch-wedding-day-saved-wet-pawleys-island)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:36:58+00:00

The aftermath of Hurricane Ian proved to make for a beautiful Saturday for a visiting family celebrating a wedding in coastal South Carolina

## Army misses recruiting goals while other branches fall behind for next year
 - [https://www.foxnews.com/us/army-misses-recruiting-goals-while-other-branches-fall-behind-next-year](https://www.foxnews.com/us/army-misses-recruiting-goals-while-other-branches-fall-behind-next-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:34:39+00:00

The Army missed its 2022 recruiting goals by 25%the other three branches will enter 2023 behind on their targets, causing speculation of a military restructure.

## Jets' Zach Wilson makes unusual impact in return from knee injury
 - [https://www.foxnews.com/sports/jets-zach-wilson-makes-unusual-impact-return-knee-injury](https://www.foxnews.com/sports/jets-zach-wilson-makes-unusual-impact-return-knee-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:25:09+00:00

New York Jets quarterback Zach Wilson returned to the starting lineup on Sunday and made an impact in an unusual way for the BYU alum.

## Border officials count 599,000 'gotaway' migrants in Fiscal Year 2022: source
 - [https://www.foxnews.com/politics/border-officials-count-599000-gotaway-migrants-fiscal-year-2022-source](https://www.foxnews.com/politics/border-officials-count-599000-gotaway-migrants-fiscal-year-2022-source)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:21:51+00:00

There were at least 599,000 migrants who crossed the southern border but were not apprehended by U.S. officials, a Customs and Border Protection source told Fox News.

## Prince Harry and Meghan Markle are house hunting for a more private mansion in Montecito: report
 - [https://www.foxnews.com/entertainment/prince-harry-meghan-markle-house-hunting-more-private-mansion-montecito-report](https://www.foxnews.com/entertainment/prince-harry-meghan-markle-house-hunting-more-private-mansion-montecito-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:21:47+00:00

Prince Harry and Meghan Markle are looking to seclude themselves even more in the ritzy area of Hope Ranch, a suburb of Santa Barbara, according to a local report.

## Season over for California high-school football team whose members acted out slave auction
 - [https://www.foxnews.com/us/season-over-for-california-high-school-football-team-whose-members-acted-out-slave-auction](https://www.foxnews.com/us/season-over-for-california-high-school-football-team-whose-members-acted-out-slave-auction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:17:27+00:00

A California high school's varsity football team is forced to forfeit its season after players were involved in acting out a slave auction, the district's superintendent told the local FOX television station.

## Adam Levine performs for first time since cheating scandal, supported by wife Behati at Shaq's charity event
 - [https://www.foxnews.com/entertainment/adam-levine-performs-first-time-cheating-scandal-supported-wife-behati-shaqs-charity-event](https://www.foxnews.com/entertainment/adam-levine-performs-first-time-cheating-scandal-supported-wife-behati-shaqs-charity-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:15:56+00:00

Adam Levine sent several inappropriate messages to women who are not his wife, Behati Prinsloo. On Saturday, he took the stage for the first time since the cheating scandal broke.

## Saints' Wil Lutz misses game-tying field goal by inches, ball hits post twice
 - [https://www.foxnews.com/sports/saints-wil-lutz-misses-game-tying-field-goal-inches-ball-hits-post-twice](https://www.foxnews.com/sports/saints-wil-lutz-misses-game-tying-field-goal-inches-ball-hits-post-twice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:15:49+00:00

New Orleans Saints kicker Wil Lutz narrowly missed a field goal Sunday that would have sent their game against the Minnesota Vikings into overtime.

## NATO chief: 'All evidence' points to German pipeline sabotage, dodges question on Ukraine membership
 - [https://www.foxnews.com/world/nato-chief-evidence-points-german-pipeline-sabotage-dodges-question-ukraine-membership](https://www.foxnews.com/world/nato-chief-evidence-points-german-pipeline-sabotage-dodges-question-ukraine-membership)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:11:24+00:00

The CIA in the summer had warned German counterparts about a possible attack on the Nord Stream pipeline system, which connects and delivers energy between Berlin and Moscow.

## NATO chief: 'All evidence' points to pipeline sabotage, dodges question on Ukraine membership
 - [https://www.foxnews.com/world/nato-chief-evidence-points-pipeline-sabotage-dodges-question-ukraine-membership](https://www.foxnews.com/world/nato-chief-evidence-points-pipeline-sabotage-dodges-question-ukraine-membership)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:11:24+00:00

The CIA in the summer had warned German counterparts about a possible attack on the Nord Stream pipeline system, which connects and delivers energy between Berlin and Moscow.

## Antonio Brown uses lewd incident to push for NFL job
 - [https://www.foxnews.com/sports/antonio-brown-uses-lewd-incident-push-nfl-job](https://www.foxnews.com/sports/antonio-brown-uses-lewd-incident-push-nfl-job)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 18:09:27+00:00

Antonio Brown suggested Sunday he's using the lewd incident at a Dubai hotel in May to push for an NFL team. He reacted to his controversy in a few tweets over the weekend.

## Hurricane Ian disaster relief: Ways to donate as the death toll mounts
 - [https://www.foxnews.com/lifestyle/hurricane-ian-diaster-relief-ways-donate-death-toll-mounts](https://www.foxnews.com/lifestyle/hurricane-ian-diaster-relief-ways-donate-death-toll-mounts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 17:51:02+00:00

These organizations are accepting donations and mobilizing efforts in the wake of Hurricane Ian. These include the American Red Cross – to which FOX Corp. donated $1 million to aid their efforts.

## Beto O'Rourke says Biden admin 'certainly' needs 'to do more' to find solutions on border crisis
 - [https://www.foxnews.com/politics/beto-orourke-says-biden-admin-certainly-needs-do-more-find-solutions-border-crisis](https://www.foxnews.com/politics/beto-orourke-says-biden-admin-certainly-needs-do-more-find-solutions-border-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 17:49:11+00:00

Texas gubernatorial nominee Beto O'Rourke said the Biden administration should "certainly" be doing more to help with the border crisis and said Gov. Abbott should work with them.

## Colorado law enforcement reexamining if disgraced social worker connected to phony bomb threat: Report
 - [https://www.foxnews.com/us/colorado-law-enforcement-reexamining-disgraced-social-worker-connected-phony-bomb-threat-report](https://www.foxnews.com/us/colorado-law-enforcement-reexamining-disgraced-social-worker-connected-phony-bomb-threat-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 17:49:05+00:00

Colorado law enforcement authorities are reportedly revisiting a phony bomb threat made at an Arapahoe County building to see if it has any connection to Robin Niceta.

## NFL legend Terry Bradshaw reveals cancer battles, working his way back to 100%
 - [https://www.foxnews.com/sports/nfl-legend-terry-bradshaw-reveals-cancer-battles-working-way-back-100](https://www.foxnews.com/sports/nfl-legend-terry-bradshaw-reveals-cancer-battles-working-way-back-100)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 17:22:36+00:00

Terry Bradshaw revealed on "FOX NFL Sunday" he had been battling cancer over the last 12 months as he addressed concerns about his health.

## Cardinals' J.J. Watt reveals heart scare in days leading up to Week 4 matchup
 - [https://www.foxnews.com/sports/cardinals-jj-watt-reveals-heart-scare-days-leading-week-4-matchup](https://www.foxnews.com/sports/cardinals-jj-watt-reveals-heart-scare-days-leading-week-4-matchup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 17:14:34+00:00

Arizona Cardinals star J.J. Watt revealed he had a scary heart issue in the week leading up to the team's game against the Carolina Panthers on Sunday.

## Biden continues to compare student loan handout to PPP, slams Republicans as hypocrites
 - [https://www.foxnews.com/politics/biden-continues-compare-student-loan-handout-ppp-slams-republicans-hypocrites](https://www.foxnews.com/politics/biden-continues-compare-student-loan-handout-ppp-slams-republicans-hypocrites)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 17:08:19+00:00

President Biden on Saturday compared his student loan handout to the Paycheck Protection Program (PPP) established by the CARES Act during the Trump administration.

## Sergio Perez wins Singapore Grand Prix, Max Verstappen's F1 championship celebration on hold
 - [https://www.foxnews.com/sports/sergio-perez-wins-singapore-grand-prix-max-verstappens-f1-championship-celebration-hold](https://www.foxnews.com/sports/sergio-perez-wins-singapore-grand-prix-max-verstappens-f1-championship-celebration-hold)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 16:58:04+00:00

Sergio Perez's win at the Singapore Grand Prix on Sunday put Max Verstappen's celebrations on hold. Charles Leclerc finished in second place, and Carlos Sainz Jr. finished in third.

## Planned Parenthood claims Ana de Armas' Marilyn Monroe film 'Blonde' is too pro-life
 - [https://www.foxnews.com/entertainment/planned-parenthood-claims-ana-de-armas-marilyn-monroe-film-blonde-too-pro-life](https://www.foxnews.com/entertainment/planned-parenthood-claims-ana-de-armas-marilyn-monroe-film-blonde-too-pro-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 16:46:09+00:00

Planned Parenthood went after Ana de Armas' Netflix film "Blonde," which portrays the actress having two illegal abortions and a fetus talking to Marilyn Monroe.

## Tab overload? How to control what happens when you start your browser
 - [https://www.foxnews.com/tech/tab-overload-how-control-what-happens-when-you-start-your-browser](https://www.foxnews.com/tech/tab-overload-how-control-what-happens-when-you-start-your-browser)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 16:33:18+00:00

Computers have massive processing power. However, there are ways to boost the power for each of the major browsers. This can allow you to access old searches.

## Manchester City's Erling Haaland makes history with hat trick in rout of United
 - [https://www.foxnews.com/sports/manchester-citys-erling-haaland-makes-history-hat-trick-rout-united](https://www.foxnews.com/sports/manchester-citys-erling-haaland-makes-history-hat-trick-rout-united)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 16:10:54+00:00

Erling Haaland has a hold on the Premier League, and his three goals against Manchester United put him in the history books. Manchester City won, 6-3.

## Georgia Gov. Kemp refuses to say whether he'll campaign with Trump
 - [https://www.foxnews.com/politics/georgia-gov-kemp-refuses-say-campaign-trump](https://www.foxnews.com/politics/georgia-gov-kemp-refuses-say-campaign-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 15:37:23+00:00

Republican Georgia Governor Brian Kemp, who is up for reelection, would not say Sunday whether he would appear at an event with former President Donald Trump.

## Pope Francis warns of nuclear war risk, appeals to Putin on Ukraine
 - [https://www.foxnews.com/world/pope-francis-warns-nuclear-war-risk-appeals-putin-ukraine](https://www.foxnews.com/world/pope-francis-warns-nuclear-war-risk-appeals-putin-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 15:33:14+00:00

Pope Francis urged Russian President Vladimir Putin to "stop this spiral of violence" in Ukraine, and asked Ukraine to be "open" to peace proposals.

## CNN reporter says DeSantis forced to 'play nice' with 'institutions' he has 'contentious' relationships with
 - [https://www.foxnews.com/media/cnn-reporter-says-desantis-forced-play-nice-institutions-he-has-contentious-relationships-with](https://www.foxnews.com/media/cnn-reporter-says-desantis-forced-play-nice-institutions-he-has-contentious-relationships-with)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 15:29:19+00:00

CNN reporter Eva McKend said Sunday that Gov. DeSantis had to "play nice" with institutions that he has had a "contentious relationship with" amid Hurricane Ian.

## Vikings' Lewis Cine suffers gruesome knee injury, taken out of game on cart
 - [https://www.foxnews.com/sports/vikings-lewis-cine-suffers-gruesome-knee-injury-taken-out-game-cart](https://www.foxnews.com/sports/vikings-lewis-cine-suffers-gruesome-knee-injury-taken-out-game-cart)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 15:21:03+00:00

Minnesota Vikings rookie defensive back Lewis Cine was taken off the field on a cart after he suffered a gruesome knee injury Sunday against the New Orleans Saints.

## LSU's Sevyn Banks leaves game on stretcher after hard hit on opening kickoff
 - [https://www.foxnews.com/sports/lsus-sevyn-banks-leaves-game-stretcher-after-hard-hit-opening-kickoff](https://www.foxnews.com/sports/lsus-sevyn-banks-leaves-game-stretcher-after-hard-hit-opening-kickoff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 15:12:29+00:00

LSU cornerback Sevyn Banks was taken off the field and transported to the hospital on a stretcher. He left the team's win over Auburn on Saturday night in the first quarter.

## Rutgers' Greg Schiano confronts Ohio State's Ryan Day after fake punt in blowout
 - [https://www.foxnews.com/sports/rutgers-greg-schiano-confronts-ohio-states-ryan-day-fake-punt-blowout](https://www.foxnews.com/sports/rutgers-greg-schiano-confronts-ohio-states-ryan-day-fake-punt-blowout)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 15:08:27+00:00

Greg Schiano stormed over to the Ohio State sideline after a Buckeyes punter ran a fake punt with under 10 minutes to play in a blowout game.

## FEMA head defends Lee County, Florida officials' Hurricane Ian prep: Storm was 'very unpredictable'
 - [https://www.foxnews.com/politics/fema-head-defends-lee-county-florida-officials-hurricane-ian-prep-storm-very-unpredictable](https://www.foxnews.com/politics/fema-head-defends-lee-county-florida-officials-hurricane-ian-prep-storm-very-unpredictable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 15:02:07+00:00

FEMA Administrator Deanne Criswell reacted to a report that Lee County, Florida officials delayed Hurricane Ian evacuations, calling the storm "very unpredictable."

## 'SNL' Weekend Update reacts to Sweeney MAGA-inspired hats controversy, talks conservative family members
 - [https://www.foxnews.com/entertainment/snl-weekend-update-reacts-sweeney-maga-inspired-hats-controversy-talks-conservative-family-members](https://www.foxnews.com/entertainment/snl-weekend-update-reacts-sweeney-maga-inspired-hats-controversy-talks-conservative-family-members)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 14:58:13+00:00

The new season of 'Saturday Night Live' was one to watch with several cast members not returning. In the premiere episode, new cast member Michael Longfellow discussed "conservative family members."

## Lake Erie fishing tournament ends in cheating controversy
 - [https://www.foxnews.com/sports/lake-erie-fishing-tournament-ends-cheating-controversy](https://www.foxnews.com/sports/lake-erie-fishing-tournament-ends-cheating-controversy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 14:52:30+00:00

Two fishermen who have been suspected of cheating in recent events were finally caught Saturday after it was discovered they had shoved weights in their fish.

## Indonesia soccer match chaos seen on video, stampede death toll at 125
 - [https://www.foxnews.com/sports/indonesia-soccer-match-chaos-seen-video-stampede-death-toll](https://www.foxnews.com/sports/indonesia-soccer-match-chaos-seen-video-stampede-death-toll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 14:13:16+00:00

Upset fans rushed a field in Indonesia Saturday night, where they were met by police deploying tear gas. The chaos was caught on video, and the death toll has been corrected.

## EXCLUSIVE: China 'would not' invade Taiwan if Beijing believes it owns the island, Asian trade official says
 - [https://www.foxnews.com/world/china-invade-taiwan-beijing-believes-owns-island-asian-trade-official-says](https://www.foxnews.com/world/china-invade-taiwan-beijing-believes-owns-island-asian-trade-official-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 14:00:01+00:00

Senior Cambodian minister Dr. Kao Kim Hourn discussed concerns over Russia's potential use of an atomic weapon and hopes that nations on the brink of conflict give diplomacy a chance.

## Romance in America: 5 honeymoon destinations in the USA worth considering
 - [https://www.foxnews.com/lifestyle/romance-america-5-honeymoon-destinations-usa-considering](https://www.foxnews.com/lifestyle/romance-america-5-honeymoon-destinations-usa-considering)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 13:58:07+00:00

Honeymoons don't have to include a beach: Think the Finger Lakes region of New York State or San Antonio, Texas, for example, for romance, fine dining and plenty of adventure for newlyweds.

## 7-year-old donates entire piggy bank to help those devastated by Hurricane Ian: 'They need it more than I do'
 - [https://www.foxnews.com/media/7-year-old-donates-entire-piggy-bank-help-devastated-hurricane-ian-need-more](https://www.foxnews.com/media/7-year-old-donates-entire-piggy-bank-help-devastated-hurricane-ian-need-more)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 13:47:39+00:00

7-year-old Dominic D'Andrea joined 'Fox & Friends Weekend' with his mom Jaclyn to share how they're stepping up to help those displaced by Hurricane Ian.

## Biden's proposed Title IX rewrite was bombarded with public comments: What comes next?
 - [https://www.foxnews.com/media/bidens-proposed-title-ix-rewrite-bombarded-public-comments-comes-next](https://www.foxnews.com/media/bidens-proposed-title-ix-rewrite-bombarded-public-comments-comes-next)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 13:22:33+00:00

Experts weigh in on when the Biden administration will issue a final Title IX rule, and what it does with the record number of public comments submitted.

## Pine Island residents recount horror, fear as Ian bore down
 - [https://www.foxnews.com/us/pine-island-residents-recount-horror-fear-ian-bore-down](https://www.foxnews.com/us/pine-island-residents-recount-horror-fear-ian-bore-down)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 13:20:36+00:00

Hurricane Ian brought destruction on Pine Island, Florida's largest barrier island, leaving its residents cut off from the mainland.

## Colorado teen arrested in connection with 14-year-old's death
 - [https://www.foxnews.com/us/colorado-teen-arrested-connection-14-year-old-death](https://www.foxnews.com/us/colorado-teen-arrested-connection-14-year-old-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 13:11:14+00:00

Denver police arrested a 17-year-old in connection with the death of a 14-year-old boy back in August. Investigators say the two had met up for the sale of a firearm.

## Republicans, pro-lifers victimized by political violence since Biden called Trump supporters ‘threat’ to U.S.
 - [https://www.foxnews.com/politics/republicans-pro-lifers-victimized-political-violence-since-biden-called-trump-supporters-threat-u-s](https://www.foxnews.com/politics/republicans-pro-lifers-victimized-political-violence-since-biden-called-trump-supporters-threat-u-s)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 12:20:23+00:00

Multiple incidents of political violence involving victims supporting conservative causes have occurred since President Biden warned of the threat MAGA extremism poses.

## Strategists and political experts weigh effect of GOP's focus on crime ahead of midterms
 - [https://www.foxnews.com/politics/strategists-political-experts-weigh-effect-gops-focus-crime-ahead-midterms](https://www.foxnews.com/politics/strategists-political-experts-weigh-effect-gops-focus-crime-ahead-midterms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 12:00:47+00:00

Political experts are sounding off on the GOP's focus on crime ahead of the midterm elections, with some saying they believe Republicans are right to highlight crime in big cities.

## The 'scary stuff' Biden's White House and DOJ might have done to attack parents: Jim Jordan
 - [https://www.foxnews.com/media/scary-stuff-bidens-white-house-doj-done-attack-parents-jim-jordan](https://www.foxnews.com/media/scary-stuff-bidens-white-house-doj-done-attack-parents-jim-jordan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 12:00:10+00:00

Rep. Jim Jordan, R-Ohio, weighed in on the alleged collusion between the National School Boards Association and President Biden's government on "Life, Liberty & Levin."

## If Jesus gave a TED talk, what do you think He would say?
 - [https://www.foxnews.com/opinion/if-jesus-gave-ted-talk-what-do-you-think-he-would-say](https://www.foxnews.com/opinion/if-jesus-gave-ted-talk-what-do-you-think-he-would-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 12:00:04+00:00

In his Sermon on the Mount, Jesus gets straight to the heart of the subjects that matter most to us: money, worry, sex, how to deal with enemies and our eternal destiny.

## Why Joe O'Dea will surprise Democrats and defeat Michael Bennet in Colorado on November 8
 - [https://www.foxnews.com/opinion/joe-odea-surprise-democrats-defeat-michael-bennet-colorado-november](https://www.foxnews.com/opinion/joe-odea-surprise-democrats-defeat-michael-bennet-colorado-november)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 11:00:02+00:00

Democrat Michael Bennet is running for reelection against Republican Joe O'Dea in Colorado. Although Bennet is the incumbent it's very possible he will be defeated by O'Dea in November.

## Washington DC firefighter on leave after assaulting usher at Nationals game: 'Completely unacceptable'
 - [https://www.foxnews.com/us/washington-dc-firefighter-leave-assaulting-usher-nationals-game-completely-unacceptable](https://www.foxnews.com/us/washington-dc-firefighter-leave-assaulting-usher-nationals-game-completely-unacceptable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 10:41:43+00:00

Video shows a Washington DC firefighter punch an usher at Nationals Park in the face while he was being escorted out of the park during Tuesday night's game against the Atlanta Braves.

## Beautiful brindle dog available for adoption in New Jersey: ‘Old school’ charmer
 - [https://www.foxnews.com/lifestyle/beautiful-brindle-dog-available-adoption-new-jersey](https://www.foxnews.com/lifestyle/beautiful-brindle-dog-available-adoption-new-jersey)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 10:30:06+00:00

Interested in adopting a pet? Meet Carmine — a brindle mix dog who is up for adoption at Sammy's Hope Animal Welfare and Adoption Center in New Jersey.

## Minnesota police investigating potentially fatal plane crash onto residential home
 - [https://www.foxnews.com/us/minnesota-police-investigating-potentially-fatal-plane-crash-residential-home](https://www.foxnews.com/us/minnesota-police-investigating-potentially-fatal-plane-crash-residential-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 10:22:08+00:00

A small aircraft crashed into the second floor of a residential building in Hermantown, Minnesota on Saturday, just before midnight.

## New photo of King Charles III, Camilla, William and Kate released by Buckingham Palace
 - [https://www.foxnews.com/entertainment/new-photo-king-charles-iii-camilla-william-kate-released-buckingham-palace](https://www.foxnews.com/entertainment/new-photo-king-charles-iii-camilla-william-kate-released-buckingham-palace)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 10:09:34+00:00

The royal family shared a new photo of King Charles III, Camilla, the queen consort, Prince William and Kate Middleton, the Princess of Wales, on Saturday.

## 2024 Watch: Youngkin ‘testing the waters’ at major donor retreat
 - [https://www.foxnews.com/politics/2024-watch-youngkin-testing-waters-major-donor-retreat](https://www.foxnews.com/politics/2024-watch-youngkin-testing-waters-major-donor-retreat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 10:00:22+00:00

Republican Gov. Glenn Youngkin of Virginia gathered with top donors on Thursday and Friday as the rising GOP star mulls a potential 2024 White House bid

## Las Vegas police to get reality-based training at $35M center 5 years after deadliest US shooting
 - [https://www.foxnews.com/us/las-vegas-police-get-reality-based-training-35m-center-5-years-deadliest-us-shooting](https://www.foxnews.com/us/las-vegas-police-get-reality-based-training-35m-center-5-years-deadliest-us-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 10:00:13+00:00

Police officers can now get reality-based training at a new $35 million facility. five years after the Oct. 1, 2017, shooting left a total of 60 people dead.

## Colorado man arrested in connection with attempted child kidnapping turned in by own parents
 - [https://www.foxnews.com/us/colorado-man-arrested-connection-attempted-child-kidnapping-turned-own-parents](https://www.foxnews.com/us/colorado-man-arrested-connection-attempted-child-kidnapping-turned-own-parents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 09:55:37+00:00

A Colorado man who was arrested and charged for trying to kidnap a young girl was turned in by his own parents after police released images of the suspect.

## Texas girl, 12, who shot father in murder plot to kill family dead from self-inflicted gunshot wound: police
 - [https://www.foxnews.com/us/texas-girl-12-shot-father-plot-friend-murder-families-dead-self-inflicted-gunshot-wound](https://www.foxnews.com/us/texas-girl-12-shot-father-plot-friend-murder-families-dead-self-inflicted-gunshot-wound)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 09:16:21+00:00

A 12-year-old Texas girl who shot her father and then herself in a pact with a friend to kill their families and flee the state died of a self-inflicted gunshot wound, police said.

## ‘Monster’: Jeffrey Dahmer survivor never recovered after harrowing escape from killer, defense attorney says
 - [https://www.foxnews.com/us/monster-jeffrey-dahmer-survivor-never-recovered-after-harrowing-escape-killer](https://www.foxnews.com/us/monster-jeffrey-dahmer-survivor-never-recovered-after-harrowing-escape-killer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 09:00:16+00:00

Defense attorney Paul Ksicinski former client, Tracy Edwards, escaped from Jeffrey Dahmer's Milwaukee, Wisconsin apartment on the night of July 22, 1991.

## Coast Guard rescues 2 people, dog stranded on Sanibel Island after Hurricane Ian
 - [https://www.foxnews.com/us/hurricane-ian-coast-guard-rescues-two-people-dog-stranded-sanibel-island](https://www.foxnews.com/us/hurricane-ian-coast-guard-rescues-two-people-dog-stranded-sanibel-island)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 08:16:31+00:00

The U.S. Coast Guard released video footage of the rescue of two people and a dog from Florida's Sanibel Island following Hurricane Ian. The strong storm left many stranded in the area.

## ‘SNL’: ‘Top Gun’ star Miles Teller hosts season 48 premiere, gets to mercilessly mock cold open
 - [https://www.foxnews.com/entertainment/snl-top-gun-star-miles-teller-hosts-season-48-premiere-gets-to-mercilessly-mock-cold-open](https://www.foxnews.com/entertainment/snl-top-gun-star-miles-teller-hosts-season-48-premiere-gets-to-mercilessly-mock-cold-open)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 06:42:04+00:00

Miles Teller of "Top Gun" fame hosted the season 48 opener of "Saturday Night Live" this weekend, playing Peyton Manning criticizing the first sketch in the cold open.

## ‘SNL’: ‘Top Gun’ star Miles Teller hosts season 48 premiere, gets to mercilessly mocks cold open
 - [https://www.foxnews.com/entertainment/snl-top-gun-star-miles-teller-hosts-season-48-premiere-gets-to-mercilessly-mocks-cold-open](https://www.foxnews.com/entertainment/snl-top-gun-star-miles-teller-hosts-season-48-premiere-gets-to-mercilessly-mocks-cold-open)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 06:42:04+00:00

Miles Teller of "Top Gun" fame hosted the season 48 opener of "Saturday Night Live" this weekend, playing Peyton Manning criticizing the first sketch in the cold open.

## Biden 'must secure our border': El Paso County judge candidate sounds off on migrant crisis
 - [https://www.foxnews.com/us/biden-must-secure-border-el-paso-county-judge-candidate-sounds-migrant-crisis](https://www.foxnews.com/us/biden-must-secure-border-el-paso-county-judge-candidate-sounds-migrant-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 06:00:37+00:00

El Paso County Judge candidate Guadalupe Giner opposes the county's plan to open a migrant processing center amid a recent surge of illegal immigration.

## Escaped inmate from Connecticut captured at his birthday party in Georgia
 - [https://www.foxnews.com/us/escaped-inmate-connecticut-captured-birthday-party-georgia](https://www.foxnews.com/us/escaped-inmate-connecticut-captured-birthday-party-georgia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 05:41:59+00:00

After nearly two months on the run, a man who escaped custody in Connecticut was arrested in Georgia Saturday while celebrating his birthday at a McDonough home.

## Putin ally recommends Russia use low-yield nuclear weapons in Ukraine
 - [https://www.foxnews.com/world/putin-ally-recommends-russia-use-low-yield-nuclear-weapons-ukraine](https://www.foxnews.com/world/putin-ally-recommends-russia-use-low-yield-nuclear-weapons-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 05:28:30+00:00

Chechen leader and Putin ally Ramzan Kadyrov said Saturday that Russia should consider using low-yield nuclear weapons in its war against Ukraine.

## FOX Bet Super 6: NFL Challenge back with $1,000,000 Prize for Week 4
 - [https://www.foxnews.com/sports/fox-bet-super-6-nfl-challenge-back-1000000-prize-week-4](https://www.foxnews.com/sports/fox-bet-super-6-nfl-challenge-back-1000000-prize-week-4)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 05:13:25+00:00

Play the FOX Bet Super 6 NFL Sunday Challenge for a chance to win the $1,000,000 jackpot. Pick the winners and margins of victory for this weekend's six marquee matchups.

## No. 5 Clemson dominates second half in win over No. 10 N.C. State
 - [https://www.foxnews.com/sports/no-5-clemson-dominates-second-half-win-no-10-nc-state](https://www.foxnews.com/sports/no-5-clemson-dominates-second-half-win-no-10-nc-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 04:03:58+00:00

DJ Uiagalelei ran for two touchdowns and threw for another one in No. 5 Clemson's win over No. 10 N.C. State as they moved to 5-0 on the season.

## LAWRENCE JONES: The American people will be the 'biggest factor' over control of Congress
 - [https://www.foxnews.com/media/lawrence-jones-american-people-biggest-factor-control-congress](https://www.foxnews.com/media/lawrence-jones-american-people-biggest-factor-control-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 03:47:55+00:00

Fox News host Lawrence Jones joins a panel of voters across the political spectrum to ask what matters most to them as election day draws closer on "Cross Country with Lawrence Jones."

## DAN BONGINO: The US is 'slow-walking its way' into World War III
 - [https://www.foxnews.com/media/dan-bongino-us-slow-walking-way-world-war-iii](https://www.foxnews.com/media/dan-bongino-us-slow-walking-way-world-war-iii)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 03:28:30+00:00

Fox News host Dan Bongino weighed in on what will become of the Nord Stream pipeline damage during the Russia-Ukraine war on "Unfiltered with Dan Bongino."

## Mets in danger of losing NL East after second straight loss to Braves
 - [https://www.foxnews.com/sports/mets-danger-losing-nl-east-second-straight-loss-braves](https://www.foxnews.com/sports/mets-danger-losing-nl-east-second-straight-loss-braves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 03:22:55+00:00

On June 1, the New York Mets led the National League East by 1.5 games. After Saturday's loss to the Atlanta Braves, they trail them by a game.

## Bond producer Michael Gregg Wilson says all would-be 007s audition with ‘From Russia With Love’ bedroom scene
 - [https://www.foxnews.com/entertainment/bond-producer-michael-gregg-wilson-says-would-be-007s-audition-with-from-russia-with-love-bedroom-scene](https://www.foxnews.com/entertainment/bond-producer-michael-gregg-wilson-says-would-be-007s-audition-with-from-russia-with-love-bedroom-scene)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-02 03:05:37+00:00

Producer Michael Gregg Wilson revealed that all actors who want to play the role of James Bond audition with the famous seduction scene from the 1963 film "From Russia With Love."


## Software engineering practices
 - [https://simonwillison.net/2022/Oct/1/software-engineering-practices/](https://simonwillison.net/2022/Oct/1/software-engineering-practices/)
 - RSS feed: https://simonwillison.net
 - date published: 2022-10-02 09:57:51.076905+00:00

Gergely Orosz started a Twitter conversation asking about recommended “software engineering practices” for development teams. (I really like his rejection of the term “best practices” here: I always feel it’s …


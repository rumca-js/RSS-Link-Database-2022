# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## New Pixel Watch leak reveals watch faces, strap styles and more
 - [https://www.techradar.com/news/new-pixel-watch-leak-reveals-watch-faces-strap-styles-and-more/](https://www.techradar.com/news/new-pixel-watch-leak-reveals-watch-faces-strap-styles-and-more/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-02 14:30:41+00:00

Count down the days to the big Pixel Watch reveal by looking at some of the bands and colors that have leaked out.

## Google Pixel 7 preorder gifts could include the Pixel Watch, Pixel Buds Pro
 - [https://www.techradar.com/news/google-pixel-7-preorder-gifts-could-include-the-pixel-watch-pixel-buds-pro/](https://www.techradar.com/news/google-pixel-7-preorder-gifts-could-include-the-pixel-watch-pixel-buds-pro/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-02 10:30:57+00:00

But there is a caveat

## Intel Arc A770 GPU leak could worry some gamers – but it shouldn’t
 - [https://www.techradar.com/news/intel-arc-a770-gpu-leak-could-worry-some-gamers-but-it-shouldnt/](https://www.techradar.com/news/intel-arc-a770-gpu-leak-could-worry-some-gamers-but-it-shouldnt/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-02 10:03:55+00:00

Intel’s readying its top-end Arc graphics cards to hit the market, but this leak might disappoint some folks.


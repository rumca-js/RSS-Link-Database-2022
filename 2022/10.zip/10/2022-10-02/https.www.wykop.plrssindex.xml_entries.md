## Facebook zlikwidował potężną rosyjską siatkę. Dezinformacja docierała też do PL
 - [https://www.wykop.pl/link/6841763/facebook-zlikwidowal-potezna-rosyjska-siatke-dezinformacja-docierala-tez-do-pl/](https://www.wykop.pl/link/6841763/facebook-zlikwidowal-potezna-rosyjska-siatke-dezinformacja-docierala-tez-do-pl/)
 - RSS feed: https://www.wykop.pl/rss/index.xml/
 - date published: 2022-10-02 06:48:01+00:00

<img src="https://www.wykop.pl/cdn/c3397993/link_1664647781ZGz0w2KddfPath5e3Jm0ZW,w104h74.jpg" /><br />
		 Sześćdziesiąt dezinformujących stron internetowych, podszywających się po znane media. Setki fałszywych kont, memy i filmy rozpowszechniane w siedmiu językach jednocześnie. Tak wyglądała rosyjska siatka, którą właśnie wykryła firma Meta, właściciel Facebooka.

## Szwecja wycofuje rekomendację szczepień na COVID dla dzieci w wieku 12-17 lat
 - [https://www.wykop.pl/link/6841853/szwecja-wycofuje-rekomendacje-szczepien-na-covid-dla-dzieci-w-wieku-12-17-lat/](https://www.wykop.pl/link/6841853/szwecja-wycofuje-rekomendacje-szczepien-na-covid-dla-dzieci-w-wieku-12-17-lat/)
 - RSS feed: https://www.wykop.pl/rss/index.xml/
 - date published: 2022-10-02 03:45:01+00:00

<img src="https://www.wykop.pl/cdn/c3397993/link_16646521774NPLDoUOo8TV3Rq9A5KSdP,w104h74.jpg" /><br />
		 Obecna wiedza i epidemiologia wskazują, że warianty wirusa SARS-CoV-2 wywołują coraz łagodniejsze objawy u zdrowych dzieci i młodzieży, a odporność w tej grupie jest bardzo wysoka&quot; - czytamy na stronie szwedzkiego odpowiednika naszego ministerstwa zdrowia.


# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Ron DeSantis Gives Update On Hurricane Damage As Death Toll Surges
 - [https://www.dailywire.com/news/ron-desantis-gives-update-on-hurricane-damage-as-death-toll-surges](https://www.dailywire.com/news/ron-desantis-gives-update-on-hurricane-damage-as-death-toll-surges)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 21:38:03+00:00

Florida Governor Ron DeSantis (R) said Sunday that he spent time on the ground handing out food and surveying the damage that Hurricane Ian inflicted on the state late last week. The update&#8217;s from the governor come as there have already been 76 confirmed deaths in Florida with entire communities completely wiped off the map ...

## Girls Volleyball Team Banned From Their Own Locker Room Over Complaint About Transgender Student
 - [https://www.dailywire.com/news/girls-volleyball-team-banned-from-their-own-locker-room-over-complaint-about-transgender-student](https://www.dailywire.com/news/girls-volleyball-team-banned-from-their-own-locker-room-over-complaint-about-transgender-student)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 21:29:58+00:00

A Vermont high school is cracking down after female students complained about a transgender student in their locker room — and the school&#8217;s solution is to ban the girls from their own locker room. According to a report from local CBS News outlet WCAX, the controversy arose when a transgender teammate allegedly made remarks that ...

## WATCH: Harris Confronted Over Controversial Racial Remarks About Distributing Natural Disaster Aid
 - [https://www.dailywire.com/news/watch-harris-confronted-over-controversial-racial-remarks-about-distributing-natural-disaster-aid](https://www.dailywire.com/news/watch-harris-confronted-over-controversial-racial-remarks-about-distributing-natural-disaster-aid)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 20:55:55+00:00

Vice President Kamala Harris (D) was confronted over the weekend in response to controversial racial remarks that she made late last week about distributing relief aid in responses to natural disasters. Speaking Friday afternoon in Washington, D.C., to leftist Priyanka Chopra at the Democratic National Committee’s Women’s Leadership Forum, Harris claimed, “It is our lowest income ...

## Bill Maher Implores Biden To Get Rid Of Kamala Harris: ‘She’s A Bad Politician,’ Not ‘Bright’
 - [https://www.dailywire.com/news/bill-maher-implores-biden-to-get-rid-of-kamala-harris-shes-a-bad-politician-not-bright](https://www.dailywire.com/news/bill-maher-implores-biden-to-get-rid-of-kamala-harris-shes-a-bad-politician-not-bright)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 20:32:17+00:00

Bill Maher, the liberal host of HBO&#8217;s &#8220;Real Time with Bill Maher,&#8221; said during his most recent show that President Joe Biden (D) needs to drop Vice President Kamala Harris (D) from the 2024 ticket should he decided to run for a second term. Maher made the remarks during a segment where he spoke with ...

## Top Democrat Official: Parents Will Kill Kids If Schools Don’t Hide Kid’s Gender Identity From Parents
 - [https://www.dailywire.com/news/top-democrat-official-parents-will-kill-kids-if-schools-dont-hide-kids-gender-identity-from-parents](https://www.dailywire.com/news/top-democrat-official-parents-will-kill-kids-if-schools-dont-hide-kids-gender-identity-from-parents)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 20:07:54+00:00

The chairman of the New Hampshire Democratic Party claimed without evidence late last week that if public schools do not withhold information from parents about their children&#8217;s behavior in school as it relates to so-called &#8220;gender identity counseling&#8221; that some parents will beat their children to death. Raymond Buckley made the outlandish claim on social ...

## Bill Gates Takes Surprising Shot At Left-Wing Climate Alarmists: ‘Just Completely Not Solvable’
 - [https://www.dailywire.com/news/bill-gates-takes-surprising-shot-at-left-wing-climate-alarmists-just-completely-not-solvable](https://www.dailywire.com/news/bill-gates-takes-surprising-shot-at-left-wing-climate-alarmists-just-completely-not-solvable)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 19:54:15+00:00

Microsoft co-founder Bill Gates took a surprising shot at left-wing climate alarmists during an interview that aired last week, saying their attempts to radically change people&#8217;s behavior for the sake of the environment were not realistic. Gates made the remarks while speaking to Bloomberg’s Zero podcast with host Akshat Rathi when he was asked by Rathi ...

## Hollywood Director ‘Finally’ Ties The Knot — After A Brief Encounter With An Uninvited Guest
 - [https://www.dailywire.com/news/hollywood-director-finally-ties-the-knot-after-a-brief-encounter-with-an-uninvited-guest](https://www.dailywire.com/news/hollywood-director-finally-ties-the-knot-after-a-brief-encounter-with-an-uninvited-guest)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 19:29:13+00:00

Film director James Gunn revealed that he &#8220;finally&#8221; married his girlfriend of seven years — &#8220;Peacemaker&#8221; star Jennifer Holland — spilling details about the pair&#8217;s Colorado ceremony and the uninvited guest who wandered by just as things were getting underway. Gunn shared a series of photos on Instagram, along with a video taken as the ...

## GOP Senate Candidate’s Blind Army Vet Husband At Center Of Legal Fight Between Her Campaign And The Seattle Seahawks
 - [https://www.dailywire.com/news/gop-senate-candidates-blind-army-vet-husband-at-center-of-legal-fight-between-her-campaign-and-the-seattle-seahawks](https://www.dailywire.com/news/gop-senate-candidates-blind-army-vet-husband-at-center-of-legal-fight-between-her-campaign-and-the-seattle-seahawks)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 18:12:37+00:00

A blind army veteran is at the center of a burgeoning legal fight between the Seattle Seahawks and his wife&#8217;s campaign for U.S. Senate. The Seattle Seahawks issued a cease-and-desist letter to Washington state Republican Senate candidate Tiffany Smiley, over the inclusion of what looks like a team jersey in one of her ads. But ...

## James Bond Film Producer Reveals The One Scene Used To Test All Would-Be 007s During Auditioning
 - [https://www.dailywire.com/news/james-bond-film-producer-reveals-the-one-scene-used-to-test-all-would-be-007s-during-auditioning](https://www.dailywire.com/news/james-bond-film-producer-reveals-the-one-scene-used-to-test-all-would-be-007s-during-auditioning)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 17:44:08+00:00

The film producer for the James Bond movie franchise revealed in an interview last last week that all would-be 007s must audition a seduction scene from one of one of the very first Bond films. Film producer Michael G. Wilson, who runs Eon Productions with Barbara Broccoli, said during an event at the British Film ...

## Trans Student Walkout Group Admits Most Just Wanted To Skip School, Boasts About Tricking Media
 - [https://www.dailywire.com/news/trans-student-walkout-group-admits-most-just-wanted-to-skip-school-boasts-about-tricking-media](https://www.dailywire.com/news/trans-student-walkout-group-admits-most-just-wanted-to-skip-school-boasts-about-tricking-media)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 17:39:02+00:00

National media covered “walkouts” by Virginia students supposedly objecting to transgender policies from Republican Gov. Glenn Youngkin’s administration, but internal video of the “student” group shows that it is led by an adult former Democrat staffer and that the group knew that a large portion of students had no interest in the cause and simply wanted to skip school.

## The University Of Colorado Fires Head Football Coach Karl Dorrell
 - [https://www.dailywire.com/news/the-university-of-colorado-fires-head-football-coach-karl-dorrell](https://www.dailywire.com/news/the-university-of-colorado-fires-head-football-coach-karl-dorrell)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 16:45:51+00:00

The University of Colorado announced Sunday afternoon that it had fired head football coach Karl Dorrell after the team lost its first five games of the season, often in embarrassing fashion. Dorrell was hired by the school in February 2020 after it lost first-year head coach Mel Tucker, who left for a better contract at ...

## JJ Watt Reveals He Underwent Medical Procedure To Shock His Heart Back Into Rhythm
 - [https://www.dailywire.com/news/jj-watt-reveals-he-underwent-medical-procedure-to-shock-his-heart-back-into-rhythm](https://www.dailywire.com/news/jj-watt-reveals-he-underwent-medical-procedure-to-shock-his-heart-back-into-rhythm)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 16:33:41+00:00

Arizona Cardinals defensive lineman J.J. Watt tweeted Sunday that his heart had to be shocked back into rhythm late last week after it went into atrial fibrillation (A-fib). Watt&#8217;s tweet came just hours before the team was set to play the Carolina Panthers Sunday afternoon. &#8220;I was just told somebody leaked some personal information about ...

## Brian Kemp Blasts Stacey Abrams After She Loses Court Battle Against Georgia Voter Integrity Laws
 - [https://www.dailywire.com/news/brian-kemp-blasts-stacey-abrams-after-she-loses-court-battle-against-georgia-voter-integrity-laws](https://www.dailywire.com/news/brian-kemp-blasts-stacey-abrams-after-she-loses-court-battle-against-georgia-voter-integrity-laws)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 16:18:08+00:00

Georgia Gov. Brian Kemp (R) blasted Stacey Abrams after she lost a court battle over her 2018 election defeat. Appearing on &#8220;Fox News Sunday,&#8221; Kemp lashed out at Abrams for using the legal fight over her loss four years ago to further her personal and political gain. Her lawsuit claimed that Georgia had suppressed voters, ...

## NFL Wide Receiver Antonio Brown Responds To Controversial Video Of Him Allegedly Exposing Himself To A Woman
 - [https://www.dailywire.com/news/nfl-wide-receiver-antonio-brown-responds-to-controversial-video-of-him-allegedly-exposing-himself-to-a-woman](https://www.dailywire.com/news/nfl-wide-receiver-antonio-brown-responds-to-controversial-video-of-him-allegedly-exposing-himself-to-a-woman)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 16:10:33+00:00

NFL free agent wide receiver Antonio Brown responded to videos published over the weekend that allegedly showed him exposing himself to a woman in a swimming pool at a high-end hotel in the Middle East. The New York Post reported that Brown, 34, was caught “shoving his bare buttocks into the face of a stunned woman” ...

## ‘We’re Going To Support All Communites’: FEMA Administrator Vows To Help ‘Everybody’ After VP Harris’s Hurricane Relief ‘Equity’ Comments
 - [https://www.dailywire.com/news/were-going-to-support-all-communites-fema-administrator-vows-to-help-everybody-after-vp-harriss-hurricane-relief-equity-comments](https://www.dailywire.com/news/were-going-to-support-all-communites-fema-administrator-vows-to-help-everybody-after-vp-harriss-hurricane-relief-equity-comments)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 14:35:44+00:00

FEMA Administrator Deanne Criswell vowed that Hurricane Ian relief would be provided to &#8220;all communities&#8221; after Vice President Kamala Harris said last week that the Biden administration would prioritize aid to minorities &#8220;based on equity.&#8221; Appearing on &#8220;Face the Nation&#8221; Sunday, Criswell was asked to respond directly to the comments made by Harris. Criswell claimed ...

## How Your View Of The End-Times Affects Your Outlook Today
 - [https://www.dailywire.com/news/how-your-view-of-the-end-times-affects-your-outlook-today](https://www.dailywire.com/news/how-your-view-of-the-end-times-affects-your-outlook-today)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 14:26:35+00:00

Are you familiar with the term eschatology? It refers to the study of the end-times, an area of focus that has intrigued Christians throughout the centuries. Interest in eschatology may prompt questions such as: Are we living in the last days? How long will it be until Jesus returns? What are the signs of the ...

## Marco Rubio: Hurricane Ian Damage To Florida’s Gulf Coast A ‘Character-Altering Event’
 - [https://www.dailywire.com/news/marco-rubio-hurricane-ian-damage-to-floridas-gulf-coast-a-character-altering-event](https://www.dailywire.com/news/marco-rubio-hurricane-ian-damage-to-floridas-gulf-coast-a-character-altering-event)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 13:03:17+00:00

Sen. Marco Rubio (R-FL) said Hurricane Ian&#8217;s damage to Florida&#8217;s Gulf Coast communities was a &#8220;character-altering event.&#8221; Appearing on ABC&#8217;s &#8220;This Week&#8221; Sunday, Rubio said that buildings in areas hit hardest were flattened, and still others would be rendered uninhabitable and need to be razed. He also said that the damage would change the economic ...

## Teacher Suspected Of Grooming, Raping Girls Found Dead In Jail Cell Under Mysterious Circumstances
 - [https://www.dailywire.com/news/teacher-suspected-of-grooming-raping-girls-found-dead-in-jail-cell-under-mysterious-circumstances](https://www.dailywire.com/news/teacher-suspected-of-grooming-raping-girls-found-dead-in-jail-cell-under-mysterious-circumstances)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 10:45:05+00:00

A St. Louis-area middle-school teacher accused of grooming and raping students was found dead in his jail cell last week. Brandon Holbrook, 30, a substitute teacher, was accused of raping a 14-year-old girl multiple times and being held in the St. Louis County Jail when he was found unresponsive Monday. He was pronounced dead at ...

## Fauci Pal At Center Of COVID Lab-Leak Suspicions Gets New Bat Virus Grant
 - [https://www.dailywire.com/news/fauci-pal-at-center-of-covid-lab-leak-suspicions-gets-new-bat-virus-grant](https://www.dailywire.com/news/fauci-pal-at-center-of-covid-lab-leak-suspicions-gets-new-bat-virus-grant)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 10:07:22+00:00

Dr. Anthony Fauci has steered another lucrative grant to study bat viruses to the same company suspected of conducting gain-of-function research at the mysterious Chinese laboratory where some experts believe COVID-19 was hatched. EcoHealth Alliance last month began a multi-year study of “viral sequences and isolates for use in vaccine development,” according to a grant ...

## Coast Guard Hero Praised By Biden For Saving Lives After Ian Facing Discharge Over COVID Jab Refusal
 - [https://www.dailywire.com/news/coast-guard-hero-praised-by-biden-for-saving-lives-after-ian-facing-discharge-over-covid-jab-refusal](https://www.dailywire.com/news/coast-guard-hero-praised-by-biden-for-saving-lives-after-ian-facing-discharge-over-covid-jab-refusal)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2022-10-02 09:37:39+00:00

President Joe Biden personally thanked a Coast Guardsman for saving a 94-year-old woman in the aftermath of Hurricane Ian, but the hero expects to be fired within days for rejecting the COVID vaccine. Aviation Survival Technician Second Class Zach Loesch earned praise in a Friday phone call from the commander in chief for kicking in ...


# Source:Kołem się toczy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw, language:pl-PL

## Gdzie te miliony?! Ile współprac odrzucam i jaka trasa z książki jest najpopularniejsza? 😊 Q&A
 - [https://www.youtube.com/watch?v=rDSJoe6s3lA](https://www.youtube.com/watch?v=rDSJoe6s3lA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCG2kQBVlgG7kOigXZTcKrQw
 - date published: 2022-10-02 07:00:26+00:00

Kurs filmowo-montażowy: http://kursfilmowaniaimontazu.pl/
Dodatek Podróżniczy: https://filmypodroznicze.pl/
Kalendarz: https://www.subscribepage.com/kalendarz2023kst
Książka RTJŚ: https://rowertojestswiat.pl/


Cześć! Ostatnio jest mniej filmów i taka tendencja się niestety pewnie utrzyma. Przepraszam i proszę o wyrozumiałość. Niestety jak to w życiu - są sprawy ważne i ważniejsze. Na tę chwilę kwestie zdrowotne są priorytetowe.

Dziś zapraszam Was na zaległy odcinek z serii "Pytania i odpowiedzi". Ostatni był dawno temu, dokładnie 1 stycznia i trochę ciekawych pytań się uzbierało. Miłego słuchania życzę, a jeśli chcecie o coś zapytać - śmiało, piszcie w komentarzach. W kolejnym filmie w miarę możliwości odpowiem

Trzymajcie się zdrowo! 
Pozdrawiam
Karol Werner

Zapraszam też na:
Facebook: http://bit.ly/2flU84f
Instagram: http://bit.ly/2eTrIMc
Blog: http://kolemsietoczy.pl/

0:00 - przywitanie
00:19 - naklejki i czapeczki
01:33 - jak lubię podróżować
01:43 - research do filmów
02:16 - kurs filmowo-montażowy
04:33 - moja najtrudniejsza i ulubiona trasa
05:32 - sztuka tworzenia interaktywnych map
05:55 - gdzie pojadę w tym roku?
06:06 - w które polskie góry jechać na weekend?
06:31 - moja lista miejsc do odwiedzenia
07:16 - czy boję się długich podjazdów?
07:52 - o współpracach
10:08 - czy bałem się podczas wypraw?
10:42 - co robię z moimi milionami?
11:23 - czy mam zwierzątko?
11:45 - Wiślana Trasa Rowerowa
12:17 - jak sprawdzam pogodę
12:41 - mój ubiór sportowy
13:12 - o sakwach rowerowych
13:46 - o Insta
13:59 - jaki rower kupić?
14:43 - czy gram w gry?
15:09 - a może trip z fanami?
15:38 - najpopularniejsza trasa z książki
16:17 - Dolina Baryczy
16:26 - znowu o sakwach
16:57 - czy zrobię torby?
17:33 - jak nie tracić na jakości wideo?
17:44 - jak dbam o zdrówko?
18:11 - czym nagrywam?
18:28 - jak serwisuję rower?
19:22 - kiedy Kujawy i okolice Warszawy?
19:50 - prawidłowy sposób wieszania papieru toaletowego
19:55 - w kasku, czy bez?
20:07 - czy będzie w książce o Chorwacji?
20:26 - przypowieść o pękających szprychach
21:18 - Krzyżtopór i czasy studenckie
21:57 - mój nowy rower
22:20 - moje autografy w książce


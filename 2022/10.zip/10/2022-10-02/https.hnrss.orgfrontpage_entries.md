# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Go Auth Lib
 - [https://github.com/go-pkgz/auth](https://github.com/go-pkgz/auth)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 23:06:11+00:00

<p>Article URL: <a href="https://github.com/go-pkgz/auth">https://github.com/go-pkgz/auth</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33061299">https://news.ycombinator.com/item?id=33061299</a></p>
<p>Points: 14</p>
<p># Comments: 6</p>

## Muon: GPU Based Electron on a Diet
 - [https://github.com/ImVexed/muon](https://github.com/ImVexed/muon)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 22:46:37+00:00

<p>Article URL: <a href="https://github.com/ImVexed/muon">https://github.com/ImVexed/muon</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33061167">https://news.ycombinator.com/item?id=33061167</a></p>
<p>Points: 27</p>
<p># Comments: 15</p>

## Photo of plutonium at Los Alamos shut down a lab for four years (2017)
 - [https://www.science.org/content/article/near-disaster-federal-nuclear-weapons-laboratory-takes-hidden-toll-america-s-arsenal](https://www.science.org/content/article/near-disaster-federal-nuclear-weapons-laboratory-takes-hidden-toll-america-s-arsenal)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 22:42:53+00:00

<p>Article URL: <a href="https://www.science.org/content/article/near-disaster-federal-nuclear-weapons-laboratory-takes-hidden-toll-america-s-arsenal">https://www.science.org/content/article/near-disaster-federal-nuclear-weapons-laboratory-takes-hidden-toll-america-s-arsenal</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33061137">https://news.ycombinator.com/item?id=33061137</a></p>
<p>Points: 79</p>
<p># Comments: 27</p>

## Collect a dossier on a person by username from thousands of sites
 - [https://github.com/soxoj/maigret](https://github.com/soxoj/maigret)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 22:35:27+00:00

<p>Article URL: <a href="https://github.com/soxoj/maigret">https://github.com/soxoj/maigret</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33061058">https://news.ycombinator.com/item?id=33061058</a></p>
<p>Points: 51</p>
<p># Comments: 28</p>

## New asteroid strike images show impact 'a lot bigger than expected'
 - [https://www.spacedaily.com/reports/New_asteroid_strike_images_show_impact_a_lot_bigger_than_expected_999.html](https://www.spacedaily.com/reports/New_asteroid_strike_images_show_impact_a_lot_bigger_than_expected_999.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 22:28:02+00:00

<p>Article URL: <a href="https://www.spacedaily.com/reports/New_asteroid_strike_images_show_impact_a_lot_bigger_than_expected_999.html">https://www.spacedaily.com/reports/New_asteroid_strike_images_show_impact_a_lot_bigger_than_expected_999.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33061000">https://news.ycombinator.com/item?id=33061000</a></p>
<p>Points: 14</p>
<p># Comments: 2</p>

## Joining the Church of Emacs
 - [https://fuzzypixelz.com/blog/joining-the-church-of-emacs/](https://fuzzypixelz.com/blog/joining-the-church-of-emacs/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 21:35:21+00:00

<p>Article URL: <a href="https://fuzzypixelz.com/blog/joining-the-church-of-emacs/">https://fuzzypixelz.com/blog/joining-the-church-of-emacs/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33060527">https://news.ycombinator.com/item?id=33060527</a></p>
<p>Points: 16</p>
<p># Comments: 5</p>

## BBSing at 300 Bits per Second
 - [https://jcs.org/2022/10/02/whisper_writer](https://jcs.org/2022/10/02/whisper_writer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 21:08:23+00:00

<p>Article URL: <a href="https://jcs.org/2022/10/02/whisper_writer">https://jcs.org/2022/10/02/whisper_writer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33060288">https://news.ycombinator.com/item?id=33060288</a></p>
<p>Points: 5</p>
<p># Comments: 2</p>

## “Please be our voice” - Message from students at Sharif University of Technology
 - [https://www.reddit.com/r/worldnews/comments/xtwnvj/iran_says_waiting_for_us_to_unfreeze_7_billion/iqsq7iq/](https://www.reddit.com/r/worldnews/comments/xtwnvj/iran_says_waiting_for_us_to_unfreeze_7_billion/iqsq7iq/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 20:38:29+00:00

<p>Article URL: <a href="https://www.reddit.com/r/worldnews/comments/xtwnvj/iran_says_waiting_for_us_to_unfreeze_7_billion/iqsq7iq/">https://www.reddit.com/r/worldnews/comments/xtwnvj/iran_says_waiting_for_us_to_unfreeze_7_billion/iqsq7iq/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33059999">https://news.ycombinator.com/item?id=33059999</a></p>
<p>Points: 48</p>
<p># Comments: 10</p>

## “Please be our voice”. Message from students at Sharif University of Technology
 - [https://old.reddit.com/r/worldnews/comments/xtwnvj/iran_says_waiting_for_us_to_unfreeze_7_billion/](https://old.reddit.com/r/worldnews/comments/xtwnvj/iran_says_waiting_for_us_to_unfreeze_7_billion/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 20:38:29+00:00

<p>Article URL: <a href="https://old.reddit.com/r/worldnews/comments/xtwnvj/iran_says_waiting_for_us_to_unfreeze_7_billion/">https://old.reddit.com/r/worldnews/comments/xtwnvj/iran_says_waiting_for_us_to_unfreeze_7_billion/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33059999">https://news.ycombinator.com/item?id=33059999</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## First make the change easy, then make the easy change
 - [https://www.adamtal.me/2019/05/first-make-the-change-easy-then-make-the-easy-change](https://www.adamtal.me/2019/05/first-make-the-change-easy-then-make-the-easy-change)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 20:29:38+00:00

<p>Article URL: <a href="https://www.adamtal.me/2019/05/first-make-the-change-easy-then-make-the-easy-change">https://www.adamtal.me/2019/05/first-make-the-change-easy-then-make-the-easy-change</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33059910">https://news.ycombinator.com/item?id=33059910</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Brazilian vote counting (real time)
 - [https://resultados.tse.jus.br/oficial/app/index.html#/m/eleicao/resultados](https://resultados.tse.jus.br/oficial/app/index.html#/m/eleicao/resultados)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 20:12:42+00:00

<p>Article URL: <a href="https://resultados.tse.jus.br/oficial/app/index.html#/m/eleicao/resultados">https://resultados.tse.jus.br/oficial/app/index.html#/m/eleicao/resultados</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33059726">https://news.ycombinator.com/item?id=33059726</a></p>
<p>Points: 29</p>
<p># Comments: 16</p>

## Ask HN: Which mailing lists would you recommend to subscribe to?
 - [https://news.ycombinator.com/item?id=33059231](https://news.ycombinator.com/item?id=33059231)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 19:17:08+00:00

<p>I am interested in genuinely interesting lists covering any and all topics, be it post-quantum cryptography or vegan cooking.<p>Please include at least a brief description alongside your suggested lists.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33059231">https://news.ycombinator.com/item?id=33059231</a></p>
<p>Points: 21</p>
<p># Comments: 9</p>

## After chess, cheating rows rock poker and fishing
 - [https://www.bbc.com/news/world-us-canada-63108879](https://www.bbc.com/news/world-us-canada-63108879)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 18:40:05+00:00

<p>Article URL: <a href="https://www.bbc.com/news/world-us-canada-63108879">https://www.bbc.com/news/world-us-canada-63108879</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33058889">https://news.ycombinator.com/item?id=33058889</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## I Just Can't Kick Lisp
 - [https://blog.djha.skin/blog/i-just-cant-kick-lisp/](https://blog.djha.skin/blog/i-just-cant-kick-lisp/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 17:56:38+00:00

<p>Article URL: <a href="https://blog.djha.skin/blog/i-just-cant-kick-lisp/">https://blog.djha.skin/blog/i-just-cant-kick-lisp/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33058450">https://news.ycombinator.com/item?id=33058450</a></p>
<p>Points: 30</p>
<p># Comments: 30</p>

## Some take meetings from home, I do it from the matrix - console webcam feed
 - [https://github.com/joschuck/matrix-webcam](https://github.com/joschuck/matrix-webcam)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 17:39:19+00:00

<p>Article URL: <a href="https://github.com/joschuck/matrix-webcam">https://github.com/joschuck/matrix-webcam</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33058242">https://news.ycombinator.com/item?id=33058242</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Japan WWII poison gas agents still scarring people today
 - [https://mainichi.jp/english/articles/20221002/p2g/00m/0na/026000c](https://mainichi.jp/english/articles/20221002/p2g/00m/0na/026000c)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 17:13:18+00:00

<p>Article URL: <a href="https://mainichi.jp/english/articles/20221002/p2g/00m/0na/026000c">https://mainichi.jp/english/articles/20221002/p2g/00m/0na/026000c</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33057946">https://news.ycombinator.com/item?id=33057946</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## OneSignal (YC S11) Is Hiring Product Engineers
 - [https://onesignal.com/careers/1d573829-e95f-4aa3-a5b0-8f2080b21b65](https://onesignal.com/careers/1d573829-e95f-4aa3-a5b0-8f2080b21b65)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 17:00:27+00:00

<p>Article URL: <a href="https://onesignal.com/careers/1d573829-e95f-4aa3-a5b0-8f2080b21b65">https://onesignal.com/careers/1d573829-e95f-4aa3-a5b0-8f2080b21b65</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33057797">https://news.ycombinator.com/item?id=33057797</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Use Bookmarklets on Chrome on Android (2020)
 - [https://paul.kinlan.me/use-bookmarklets-on-chrome-on-android/](https://paul.kinlan.me/use-bookmarklets-on-chrome-on-android/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 16:40:23+00:00

<p>Article URL: <a href="https://paul.kinlan.me/use-bookmarklets-on-chrome-on-android/">https://paul.kinlan.me/use-bookmarklets-on-chrome-on-android/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33057573">https://news.ycombinator.com/item?id=33057573</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## Ubisoft+Bungie Scrambling to Evacuate Players Games from Capsizing Google Stadia
 - [https://www.forbes.com/sites/paultassi/2022/10/02/ubisoft-bungie-scrambling-to-evacuate-players-games-and-characters-from-a-capsizing-google-stadia/](https://www.forbes.com/sites/paultassi/2022/10/02/ubisoft-bungie-scrambling-to-evacuate-players-games-and-characters-from-a-capsizing-google-stadia/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 16:23:33+00:00

<p>Article URL: <a href="https://www.forbes.com/sites/paultassi/2022/10/02/ubisoft-bungie-scrambling-to-evacuate-players-games-and-characters-from-a-capsizing-google-stadia/">https://www.forbes.com/sites/paultassi/2022/10/02/ubisoft-bungie-scrambling-to-evacuate-players-games-and-characters-from-a-capsizing-google-stadia/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33057354">https://news.ycombinator.com/item?id=33057354</a></p>
<p>Points: 14</p>
<p># Comments: 9</p>

## Tesla Vehicle Production and Deliveries for 3Q 2022
 - [https://ir.tesla.com/press-release/tesla-vehicle-production-deliveries-and-date-financial-results-webcast-third-quarter](https://ir.tesla.com/press-release/tesla-vehicle-production-deliveries-and-date-financial-results-webcast-third-quarter)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 16:11:44+00:00

<p>Article URL: <a href="https://ir.tesla.com/press-release/tesla-vehicle-production-deliveries-and-date-financial-results-webcast-third-quarter">https://ir.tesla.com/press-release/tesla-vehicle-production-deliveries-and-date-financial-results-webcast-third-quarter</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33057217">https://news.ycombinator.com/item?id=33057217</a></p>
<p>Points: 34</p>
<p># Comments: 28</p>

## Toyota CEO talks about why he isn’t all-in on EVs
 - [https://www.cnbc.com/2022/10/02/toyota-ceo-akio-toyoda-electric-vehicles-happy-dance.html](https://www.cnbc.com/2022/10/02/toyota-ceo-akio-toyoda-electric-vehicles-happy-dance.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 15:52:14+00:00

<p>Article URL: <a href="https://www.cnbc.com/2022/10/02/toyota-ceo-akio-toyoda-electric-vehicles-happy-dance.html">https://www.cnbc.com/2022/10/02/toyota-ceo-akio-toyoda-electric-vehicles-happy-dance.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33057003">https://news.ycombinator.com/item?id=33057003</a></p>
<p>Points: 53</p>
<p># Comments: 134</p>

## Cobra Maneuver
 - [https://en.wikipedia.org/wiki/Cobra_maneuver](https://en.wikipedia.org/wiki/Cobra_maneuver)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 15:51:23+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Cobra_maneuver">https://en.wikipedia.org/wiki/Cobra_maneuver</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33056993">https://news.ycombinator.com/item?id=33056993</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## Sauna use as a lifestyle practice to extend healthspan
 - [https://www.sciencedirect.com/science/article/pii/S0531556521002916](https://www.sciencedirect.com/science/article/pii/S0531556521002916)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 15:28:43+00:00

<p>Article URL: <a href="https://www.sciencedirect.com/science/article/pii/S0531556521002916">https://www.sciencedirect.com/science/article/pii/S0531556521002916</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33056743">https://news.ycombinator.com/item?id=33056743</a></p>
<p>Points: 64</p>
<p># Comments: 44</p>

## Bogotá's website has sign language titles
 - [https://bogota.gov.co/en](https://bogota.gov.co/en)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 15:11:54+00:00

<p>Article URL: <a href="https://bogota.gov.co/en">https://bogota.gov.co/en</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33056576">https://news.ycombinator.com/item?id=33056576</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## Show HN: FocusedEdit – a classic Macintosh to web browser shared text editor
 - [https://github.com/CamHenlin/FocusedEdit](https://github.com/CamHenlin/FocusedEdit)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 14:30:22+00:00

<p>I built a classic Macintosh text editor that allows users to do shared bidirection live editing with a web browser on a modern computer. Essentially it allows allows you to really quickly and easily share and edit text snippets on a classic Macintosh. I've tested the software on System 2.0 through System 7.6.1, but it should work on all PPC and 68k Macintoshes running up to MacOS 9.2.2 assuming they have a modem serial port available.<p>In addition to the github repository, I wrote up a blog 

## Meet Silicon Valley’s rattled layoff ‘survivors’
 - [https://fortune.com/2022/09/30/what-its-like-for-tech-employees-who-survive-layoffs-at-company/](https://fortune.com/2022/09/30/what-its-like-for-tech-employees-who-survive-layoffs-at-company/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 14:21:13+00:00

<p>Article URL: <a href="https://fortune.com/2022/09/30/what-its-like-for-tech-employees-who-survive-layoffs-at-company/">https://fortune.com/2022/09/30/what-its-like-for-tech-employees-who-survive-layoffs-at-company/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33056084">https://news.ycombinator.com/item?id=33056084</a></p>
<p>Points: 26</p>
<p># Comments: 24</p>

## “Rust is safe” is not some kind of absolute guarantee of code safety
 - [https://lkml.org/lkml/2022/9/19/1105#1105.php](https://lkml.org/lkml/2022/9/19/1105#1105.php)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 14:20:21+00:00

<p>Article URL: <a href="https://lkml.org/lkml/2022/9/19/1105#1105.php">https://lkml.org/lkml/2022/9/19/1105#1105.php</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33056077">https://news.ycombinator.com/item?id=33056077</a></p>
<p>Points: 24</p>
<p># Comments: 4</p>

## Ask HN: In what ways is programming more difficult today than it was years ago?
 - [https://news.ycombinator.com/item?id=33056052](https://news.ycombinator.com/item?id=33056052)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 14:17:07+00:00

<p>Reading Peter Seibel's <i>Coders at Work</i>, and this is Joe Armstrong on the issue:<p>>Also, I think today we’re kind of overburdened by choice. I mean, I just had Fortran. I don’t think we even had shell scripts. We just had batch files so you could run things, a compiler, and Fortran. And assembler possibly, if you really needed it. So there wasn’t this agony of choice. Being a young programmer today must be awful—you can choose 20 different programming languages, dozens of framework and 

## Baker's Math
 - [https://www.thefreshloaf.com/handbook/baker039s-math](https://www.thefreshloaf.com/handbook/baker039s-math)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 13:59:30+00:00

<p>Article URL: <a href="https://www.thefreshloaf.com/handbook/baker039s-math">https://www.thefreshloaf.com/handbook/baker039s-math</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33055911">https://news.ycombinator.com/item?id=33055911</a></p>
<p>Points: 29</p>
<p># Comments: 7</p>

## Norvig's Law
 - [https://norvig.com/norvigs-law.html](https://norvig.com/norvigs-law.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 13:38:18+00:00

<p>Article URL: <a href="https://norvig.com/norvigs-law.html">https://norvig.com/norvigs-law.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33055767">https://news.ycombinator.com/item?id=33055767</a></p>
<p>Points: 25</p>
<p># Comments: 13</p>

## Hyperlinks in Handwriting
 - [https://handwritten.blog/2022-10-01-hyperlinks-in-handwriting.html](https://handwritten.blog/2022-10-01-hyperlinks-in-handwriting.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 12:41:54+00:00

<p>Article URL: <a href="https://handwritten.blog/2022-10-01-hyperlinks-in-handwriting.html">https://handwritten.blog/2022-10-01-hyperlinks-in-handwriting.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33055426">https://news.ycombinator.com/item?id=33055426</a></p>
<p>Points: 5</p>
<p># Comments: 2</p>

## The First RISC: John Cocke and the IBM 801
 - [https://thechipletter.substack.com/p/the-first-risc-john-cocke-and-the](https://thechipletter.substack.com/p/the-first-risc-john-cocke-and-the)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 12:33:31+00:00

<p>Article URL: <a href="https://thechipletter.substack.com/p/the-first-risc-john-cocke-and-the">https://thechipletter.substack.com/p/the-first-risc-john-cocke-and-the</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33055361">https://news.ycombinator.com/item?id=33055361</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## How a Stable Diffusion prompt changes its output for the style of 1500 artists
 - [https://gorgeous.adityashankar.xyz](https://gorgeous.adityashankar.xyz)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 12:30:17+00:00

<p>Article URL: <a href="https://gorgeous.adityashankar.xyz">https://gorgeous.adityashankar.xyz</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33055340">https://news.ycombinator.com/item?id=33055340</a></p>
<p>Points: 13</p>
<p># Comments: 5</p>

## Debian votes for non-free firmware in the installer
 - [https://lists.debian.org/debian-vote/2022/10/msg00000.html](https://lists.debian.org/debian-vote/2022/10/msg00000.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 11:51:05+00:00

<p>Article URL: <a href="https://lists.debian.org/debian-vote/2022/10/msg00000.html">https://lists.debian.org/debian-vote/2022/10/msg00000.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33055100">https://news.ycombinator.com/item?id=33055100</a></p>
<p>Points: 31</p>
<p># Comments: 7</p>

## Ask HN: How to Stop Caring (Professionally)?
 - [https://news.ycombinator.com/item?id=33054652](https://news.ycombinator.com/item?id=33054652)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 10:24:54+00:00

<p>I get stressed out a lot by my work. The people, and the lack of autonomy.<p>It invades my evenings, my nights, I spend sometimes hours unable to sleep dreading the next day.<p>I don't have any autonomy. I'm treated as a resource to be "used". And I work with people I don't respect personally or professionally.<p>I have been looking for a way out for a while, but let's just say that quitting or finding another job is NOT an option for now, for the sake of argument - to hopefully get some acti

## Emacs-like editors written in Common Lisp
 - [https://www.cliki.net/cl-emacs](https://www.cliki.net/cl-emacs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 09:34:04+00:00

<p>Article URL: <a href="https://www.cliki.net/cl-emacs">https://www.cliki.net/cl-emacs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33054430">https://news.ycombinator.com/item?id=33054430</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Today is Gandhi Jayanti, let us remember the man who stands for non-violence
 - [https://news.ycombinator.com/item?id=33054422](https://news.ycombinator.com/item?id=33054422)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 09:33:03+00:00

<p>2nd Oct is celebrated as Gandhi Jayanti[0]. M. K. Gandhi once said "An eye for an eye will make the whole world blind." In the days of war mongering it is good to remember that non-violence can achieve the greater good without shedding blood.<p>[0] https://en.wikipedia.org/wiki/Gandhi_Jayanti</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33054422">https://news.ycombinator.com/item?id=33054422</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## From 7 Years of Apache HTTP Server Logs: 5528 Unique Recon and Attack Vectors
 - [https://gist.github.com/susam/75c37fd0aff9c5e25112eac75b9ed055](https://gist.github.com/susam/75c37fd0aff9c5e25112eac75b9ed055)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 09:25:14+00:00

<p>Article URL: <a href="https://gist.github.com/susam/75c37fd0aff9c5e25112eac75b9ed055">https://gist.github.com/susam/75c37fd0aff9c5e25112eac75b9ed055</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33054379">https://news.ycombinator.com/item?id=33054379</a></p>
<p>Points: 23</p>
<p># Comments: 4</p>

## Race Conditions Can Be Useful for Parallelism
 - [https://shwestrick.github.io/2022/09/27/useful-races.html](https://shwestrick.github.io/2022/09/27/useful-races.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 09:25:11+00:00

<p>Article URL: <a href="https://shwestrick.github.io/2022/09/27/useful-races.html">https://shwestrick.github.io/2022/09/27/useful-races.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33054378">https://news.ycombinator.com/item?id=33054378</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Capsule: the nano (WASM) functions runner
 - [https://github.com/bots-garden/capsule](https://github.com/bots-garden/capsule)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 08:56:49+00:00

<p>Article URL: <a href="https://github.com/bots-garden/capsule">https://github.com/bots-garden/capsule</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33054212">https://news.ycombinator.com/item?id=33054212</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## A computational perspective on the Nobel Prize
 - [https://www.nature.com/articles/s43588-022-00325-x](https://www.nature.com/articles/s43588-022-00325-x)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 08:40:00+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s43588-022-00325-x">https://www.nature.com/articles/s43588-022-00325-x</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33054129">https://news.ycombinator.com/item?id=33054129</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## The Contrarian: How Sridhar Vembu built Zoho questioning conventional wisdom
 - [https://foundingfuel.com/article/the-contrarian/](https://foundingfuel.com/article/the-contrarian/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 08:24:39+00:00

<p>Article URL: <a href="https://foundingfuel.com/article/the-contrarian/">https://foundingfuel.com/article/the-contrarian/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33054047">https://news.ycombinator.com/item?id=33054047</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Bizarre Vintage Photos of Steam Engines After a Boiler Explosion
 - [https://designyoutrust.com/2020/02/bizarre-vintage-photos-of-steam-engines-after-a-boiler-explosion-from-the-late-19th-and-early-20th-centuries/](https://designyoutrust.com/2020/02/bizarre-vintage-photos-of-steam-engines-after-a-boiler-explosion-from-the-late-19th-and-early-20th-centuries/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 07:41:08+00:00

<p>Article URL: <a href="https://designyoutrust.com/2020/02/bizarre-vintage-photos-of-steam-engines-after-a-boiler-explosion-from-the-late-19th-and-early-20th-centuries/">https://designyoutrust.com/2020/02/bizarre-vintage-photos-of-steam-engines-after-a-boiler-explosion-from-the-late-19th-and-early-20th-centuries/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33053823">https://news.ycombinator.com/item?id=33053823</a></p>
<p>Points: 24</p>
<p># Comments: 6</p>

## An Algorithm for Polygon Intersections
 - [https://gorillasun.de/blog/an-algorithm-for-polygon-intersections](https://gorillasun.de/blog/an-algorithm-for-polygon-intersections)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 06:07:50+00:00

<p>Article URL: <a href="https://gorillasun.de/blog/an-algorithm-for-polygon-intersections">https://gorillasun.de/blog/an-algorithm-for-polygon-intersections</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33053320">https://news.ycombinator.com/item?id=33053320</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## The Andy Warhol case that could wreck American art
 - [https://www.theatlantic.com/ideas/archive/2022/10/warhol-copyright-fair-use-supreme-court-prince/671599/](https://www.theatlantic.com/ideas/archive/2022/10/warhol-copyright-fair-use-supreme-court-prince/671599/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 06:00:34+00:00

<p>Article URL: <a href="https://www.theatlantic.com/ideas/archive/2022/10/warhol-copyright-fair-use-supreme-court-prince/671599/">https://www.theatlantic.com/ideas/archive/2022/10/warhol-copyright-fair-use-supreme-court-prince/671599/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33053286">https://news.ycombinator.com/item?id=33053286</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Haidt Quits Academic Society Due to Diversity Statement Mandate
 - [https://reason.com/2022/09/30/mandated-diversity-statement-drives-jonathan-haidt-to-quit-academic-society/](https://reason.com/2022/09/30/mandated-diversity-statement-drives-jonathan-haidt-to-quit-academic-society/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 05:32:43+00:00

<p>Article URL: <a href="https://reason.com/2022/09/30/mandated-diversity-statement-drives-jonathan-haidt-to-quit-academic-society/">https://reason.com/2022/09/30/mandated-diversity-statement-drives-jonathan-haidt-to-quit-academic-society/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33053149">https://news.ycombinator.com/item?id=33053149</a></p>
<p>Points: 54</p>
<p># Comments: 58</p>

## Comfy Software: A software aesthetic for hackers with depression
 - [https://catgirl.ai/log/comfy-software/](https://catgirl.ai/log/comfy-software/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 05:31:36+00:00

<p>Article URL: <a href="https://catgirl.ai/log/comfy-software/">https://catgirl.ai/log/comfy-software/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33053144">https://news.ycombinator.com/item?id=33053144</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Ask HN: Email sent via work email (Outlook) replied to personal Gmail
 - [https://news.ycombinator.com/item?id=33053113](https://news.ycombinator.com/item?id=33053113)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 05:25:12+00:00

<p>Has anyone seen this happen before? Or can explain why?<p>I sent an email to a client. From my work email address, setup via Outlook.<p>The client responded, to my personal email address, which is an @gmail.com address.<p>I have never emailed this client prior to this, from either address.<p>The clients’ address is an @gmail address.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33053113">https://news.ycombinator.com/item?id=33053113</a></p>
<p>Points: 5</p>
<p># C

## Adventures in dynamic software, visualisations, creating a JVM language
 - [https://luisthiamnye.substack.com/p/adventures-in-dynamic-software-visualisations](https://luisthiamnye.substack.com/p/adventures-in-dynamic-software-visualisations)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 05:00:01+00:00

<p>Article URL: <a href="https://luisthiamnye.substack.com/p/adventures-in-dynamic-software-visualisations">https://luisthiamnye.substack.com/p/adventures-in-dynamic-software-visualisations</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33053007">https://news.ycombinator.com/item?id=33053007</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Milky Way's graveyard of dead stars found
 - [https://phys.org/news/2022-09-milky-graveyard-dead-stars.html](https://phys.org/news/2022-09-milky-graveyard-dead-stars.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 03:36:07+00:00

<p>Article URL: <a href="https://phys.org/news/2022-09-milky-graveyard-dead-stars.html">https://phys.org/news/2022-09-milky-graveyard-dead-stars.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33052588">https://news.ycombinator.com/item?id=33052588</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## LSD-like molecules counter depession without the trip
 - [https://www.ucsf.edu/news/2022/09/423891/lsd-molecules-counter-depression-without-trip](https://www.ucsf.edu/news/2022/09/423891/lsd-molecules-counter-depression-without-trip)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 03:28:45+00:00

<p>Article URL: <a href="https://www.ucsf.edu/news/2022/09/423891/lsd-molecules-counter-depression-without-trip">https://www.ucsf.edu/news/2022/09/423891/lsd-molecules-counter-depression-without-trip</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33052550">https://news.ycombinator.com/item?id=33052550</a></p>
<p>Points: 56</p>
<p># Comments: 28</p>

## NetNewsWire: Free and Open Source RSS Reader for Mac and iOS
 - [https://netnewswire.com/](https://netnewswire.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 03:07:33+00:00

<p>Article URL: <a href="https://netnewswire.com/">https://netnewswire.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33052441">https://news.ycombinator.com/item?id=33052441</a></p>
<p>Points: 113</p>
<p># Comments: 30</p>

## Palantir Had Secret Plan to Crack UK’s NHS: ‘Buying Our Way In’
 - [https://www.bloomberg.com/news/articles/2022-09-30/palantir-had-plan-to-crack-uk-health-system-buying-our-way-in](https://www.bloomberg.com/news/articles/2022-09-30/palantir-had-plan-to-crack-uk-health-system-buying-our-way-in)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 02:39:12+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2022-09-30/palantir-had-plan-to-crack-uk-health-system-buying-our-way-in">https://www.bloomberg.com/news/articles/2022-09-30/palantir-had-plan-to-crack-uk-health-system-buying-our-way-in</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33052307">https://news.ycombinator.com/item?id=33052307</a></p>
<p>Points: 87</p>
<p># Comments: 14</p>

## An Elegy for GNU and RMS
 - [https://catgirl.ai/log/elegy-gnu/](https://catgirl.ai/log/elegy-gnu/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 02:07:42+00:00

<p>Article URL: <a href="https://catgirl.ai/log/elegy-gnu/">https://catgirl.ai/log/elegy-gnu/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33052127">https://news.ycombinator.com/item?id=33052127</a></p>
<p>Points: 148</p>
<p># Comments: 168</p>

## Stadia died because no one trusts Google
 - [https://techcrunch.com/2022/10/01/stadia-died-because-no-one-trusts-google/](https://techcrunch.com/2022/10/01/stadia-died-because-no-one-trusts-google/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-02 00:10:46+00:00

<p>Article URL: <a href="https://techcrunch.com/2022/10/01/stadia-died-because-no-one-trusts-google/">https://techcrunch.com/2022/10/01/stadia-died-because-no-one-trusts-google/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33051393">https://news.ycombinator.com/item?id=33051393</a></p>
<p>Points: 321</p>
<p># Comments: 256</p>


# Source:GameSpot, URL:https://www.gamespot.com/feeds/mashup, language:en-US

## The Game That Fights Dementia | MindGames
 - [https://www.gamespot.com/videos/the-game-that-fights-dementia-mindgames/2300-6459651/](https://www.gamespot.com/videos/the-game-that-fights-dementia-mindgames/2300-6459651/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-02 17:00:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1594/15941173/4041608-mindgames_dementia_thumbnail_v2_site.jpg" width="480" /> Sea Hero Quest, in both its mobile and VR forms, tasks you with sailing a small boat, memorizing maps and navigating colorful seascapes. But under the surface, it hopes to provide the data that could help humanity fight an incurable disease that affects hundreds of millions of people.

## 10 Biggest Game Releases For September 2022
 - [https://www.gamespot.com/videos/10-biggest-game-releases-for-september-2022/2300-6459675/](https://www.gamespot.com/videos/10-biggest-game-releases-for-september-2022/2300-6459675/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-02 14:00:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1574/15746725/4042745-bigoct_v0.jpg" width="480" /> Spooky season is officially here! And there is nothing spookier than being haunted by the September games you didn’t finish yet. Here are 10 of the biggest games releasing in October 2022.


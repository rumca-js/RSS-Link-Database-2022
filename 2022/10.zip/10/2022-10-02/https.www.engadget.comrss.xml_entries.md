# Source:Engadget, URL:https://www.engadget.com/rss.xml, language:en-US

## Coinbase users were unable to withdraw funds to US bank accounts for six hours
 - [https://www.engadget.com/coinbase-major-outage-withdrawals-us-bank-accounts-214635790.html?src=rss](https://www.engadget.com/coinbase-major-outage-withdrawals-us-bank-accounts-214635790.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-10-02 21:46:35+00:00

<p><a href="http://engadget.com/tag/coinbase">Coinbase</a> users were unable to carry out US bank account transactions for around six hours on Sunday. An issue with the Automated Clearing House Network, which is used for electronic transfers between bank accounts in the country, emerged just before 7AM ET. The company <a href="https://status.coinbase.com/">said on its status page</a> that it identified the problem, described as a &quot;major outage,&quot; by 8:23AM and resolved it by 12:41PM.</p

## TikTok will reportedly bring live shopping to the US this holiday season
 - [https://www.engadget.com/tiktok-live-shopping-us-talkshoplive-200040748.html?src=rss](https://www.engadget.com/tiktok-live-shopping-us-talkshoplive-200040748.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-10-02 20:15:40+00:00

<p>TikTok plans to bring its live shopping &quot;TikTok Shop&quot; feature to North America using outsourced technology, according to <a href="https://www.ft.com/content/479cd8da-c416-456d-a2a2-533af8a5b7bb"><em>The Financial Times</em></a>. It'll reportedly be launched &quot;over the next month with large brands&quot; to take advantage of holiday shopping.&nbsp;</p><p>TikTok Shop is based on a similar, successful feature on TikTok's sister app Douyin in China, and is available in Thailand, Mala

## Tesla built 365,923 electric vehicles in Q3, up 42 percent from Q2
 - [https://www.engadget.com/tesla-q3-2022-manufacturing-figures-191343981.html?src=rss](https://www.engadget.com/tesla-q3-2022-manufacturing-figures-191343981.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-10-02 19:13:43+00:00

<p>After pandemic-related disruptions in Q2, <a href="http://engadget.com/tag/tesla">Tesla</a> ramped up its manufacturing capacity again last quarter, leading the company to make a record number of deliveries between July 1st and September 30th. The company <a href="https://www.businesswire.com/news/home/20221002005048/en/Tesla-Vehicle-Production-Deliveries-and-Date-for-Financial-Results-Webcast-for-Third-Quarter-2022">built 365,923 electric vehicles</a> during the period. That marks a year ove

## Chrome's controversial new extension platform is coming in 2023
 - [https://www.engadget.com/chromes-controversial-new-manifest-v3-extension-platform-is-coming-in-2023-174806613.html?src=rss](https://www.engadget.com/chromes-controversial-new-manifest-v3-extension-platform-is-coming-in-2023-174806613.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-10-02 17:48:06+00:00

<p>Google has slowly but surely been marching towards a new extension platform called Manifest V3 for Chrome. And now there is a firm <a href="https://developer.chrome.com/blog/more-mv2-transition/">timeline</a> for its rollout. Starting with Chrome 112 in January of 2023 the company may start turning off support for Manifest V2 in the Canary, Dev and Beta channels. Then in June with Chrome 115, it will begin experimenting with turning off support in the stable channel as well.&nbsp;</p><p>To co

## Twitter gives its DMs on the Android app a more modern look
 - [https://www.engadget.com/twitter-android-dm-redesign-173020244.html?src=rss](https://www.engadget.com/twitter-android-dm-redesign-173020244.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2022-10-02 12:00:20+00:00

<p><a href="https://www.engadget.com/twitter-direct-messaging-chatbox-110541267.html">Twitter</a> has started rolling out some changes for its Android app that gives people sliding into DMs a more visually appealing interface. The social network's Android app has remained largely the same over the years, but this update, while pretty minor, was meant to give users &quot;a smoother, more consistent experience overall.&quot; Twitter says it set to work redesigning its DMs on Android after its team


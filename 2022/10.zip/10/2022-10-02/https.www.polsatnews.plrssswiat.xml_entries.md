# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Grzegorz Braun w rosyjskiej telewizji. Propaganda wykorzystała jego wypowiedź
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/grzegorz-braun-w-rosyjskiej-telewizji-propaganda-wykorzystala-jego-wypowiedz/](https://www.polsatnews.pl/wiadomosc/2022-10-02/grzegorz-braun-w-rosyjskiej-telewizji-propaganda-wykorzystala-jego-wypowiedz/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 18:39:00+00:00

Wypowiedź posła Konfederacji Grzegorza Brauna, który nawoływał do zatrzymania ukrainizacji Polski wykorzystała rosyjska propagandystka Olga Skabiejewa. Komentując nagrania z manifestacji w Warszawie uznała, że jest to głos narodu, którego nie słyszą polskie władze. W programie przeinaczono też m.in. wypowiedź wicemarszałka Senatu Michała Kamińskiego.

## Meksyk. 19-letni Joe Dobson nie żyje. Zjadł burrito ze składnikiem, na który był uczulony
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/meksyk-19-letni-joe-dobson-nie-zyje-zjadl-burrito-ze-skladnikiem-na-ktory-byl-uczulony/](https://www.polsatnews.pl/wiadomosc/2022-10-02/meksyk-19-letni-joe-dobson-nie-zyje-zjadl-burrito-ze-skladnikiem-na-ktory-byl-uczulony/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 17:43:00+00:00

Tragicznie zakończyły się wakacje w Meksyku dla 19-letniego londyńczyka. Joe Dobson po tym jak zrobił kilka kęsów burrito, stracił przytomność, a później zmarł. Okazało się, że w potrawie znajdował się składnik, na który był uczulony.

## Rosja. Aktywiści "Partii Umarłych" pozostawili list na grobie rodziców Władimira Putina
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/rosja-aktywisci-partii-umarlych-pozostawili-liscik-na-grobie-rodzicow-wladimira-putina/](https://www.polsatnews.pl/wiadomosc/2022-10-02/rosja-aktywisci-partii-umarlych-pozostawili-liscik-na-grobie-rodzicow-wladimira-putina/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 15:57:00+00:00

Drodzy rodzice! Wasz syn zachowuje się niedopuszczalnie! - brzmi początek listu, który na grobie rodziców Władimira Putina zostawili aktywiści Partii Umarłych. W ten sposób chcieli przeciwstawić się polityce prezydenta Rosji, który prowadzi inwazję na Ukrainie i odgraża się państwom Zachodu.

## USA: Nieudana próba porwania dziecka. Rodzice sprawcy wydali go policji
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/usa-nieudana-proba-porwania-dziecka-rodzice-sprawcy-wydali-go-policji/](https://www.polsatnews.pl/wiadomosc/2022-10-02/usa-nieudana-proba-porwania-dziecka-rodzice-sprawcy-wydali-go-policji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 15:53:00+00:00

28-letni Diego James Gettler z Thornton w Kolorado (USA) został oskarżony o próbę porwania 10-letniej uczennicy. Podczas szarpaniny z porywaczem dziewczynce udało się ściągnąć mu maseczkę z twarzy. Wystraszony mężczyzna uciekł, ale jego wizerunek został uwieczniony przez monitoring. Po opublikowaniu fotografii w mediach społecznościowych na policję zgłosili się... rodzice mężczyzny.

## Rosja. Sobowtóry Władimira Putina. Kyryło Budanow: Istnieją trzy, które od razu zauważam
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/rosja-sobowtory-wladimira-putina-kyrylo-budanow-istnieja-trzy-ktore-od-razu-zauwazam/](https://www.polsatnews.pl/wiadomosc/2022-10-02/rosja-sobowtory-wladimira-putina-kyrylo-budanow-istnieja-trzy-ktore-od-razu-zauwazam/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 14:37:00+00:00

Moim zdaniem istnieją trzy sobowtóry, które osobiście od razu zauważam - powiedział dla ukraińskiej stacji 1+1 Kyryło Budanow, szef ukraińskiego wywiadu. Podczas tej samej rozmowy wypowiedział się też, dlaczego Aleksandr Łukaszenka nie zdecydował się przyłączyć do inwazji na Ukrainę.

## Watykan. Papież apeluje do Putina: O zatrzymanie spirali przemocy i śmierci na Ukrainie
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/watykan-papiez-apeluje-do-putina-o-zatrzymanie-spirali-przemocy-i-smierci-na-ukrainie/](https://www.polsatnews.pl/wiadomosc/2022-10-02/watykan-papiez-apeluje-do-putina-o-zatrzymanie-spirali-przemocy-i-smierci-na-ukrainie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 12:16:00+00:00

Mój apel kieruję do prezydenta Federacji Rosyjskiej, błagając go o zatrzymanie spirali przemocy i śmierci - powiedział w czasie modlitwy Anioł Pański w niedzielę na Palcu św. Piotra w Watykanie papież Franciszek. To pierwsze tak zdecydowane wystąpienie papieża od początku wojny w Ukrainie.

## Wojna w Ukrainie. Zełenski: Łyman w pełni oczyszczony z najeźdźców
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/wojna-w-ukrainie-zelenski-lyman-w-pelni-oczyszczony-z-najezdzcow/](https://www.polsatnews.pl/wiadomosc/2022-10-02/wojna-w-ukrainie-zelenski-lyman-w-pelni-oczyszczony-z-najezdzcow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 11:09:00+00:00

Na godzinę 12:30, Łyman w pełni oczyszczony - poinformował w niedzielę w krótkim nagraniu wideo prezydent Ukrainy Wołodymyr Zełenski. 20-tysięczne przed wojną miasto w obwodzie donieckim, uznawane za kluczowe dla odzyskania całego obwodu ługańskiego, który leży dalej na wschód w kierunku granicy z Rosją, zostało wyzwolone przez ukraińskie siły zbrojne.

## Łotwa. Wybory wygrywa centroprawicowa partia obecnego premiera Krisjanisa Karinsa
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/lotwa-wybory-wygrywa-centroprawicowa-partia-obecnego-premiera-krisjanisa-karinsa/](https://www.polsatnews.pl/wiadomosc/2022-10-02/lotwa-wybory-wygrywa-centroprawicowa-partia-obecnego-premiera-krisjanisa-karinsa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 10:59:00+00:00

Rządząca centroprawicowa partia premiera Kriszjanisa Karinsza zdobyła najwięcej głosów w wyborach parlamentarnych na Łotwie. Partie określające się jako centrowe zajęły drugie miejsce, a ugrupowania prorosyjskie odniosły całkowitą porażkę i nie wejdą do parlamentu.

## Wojna w Ukrainie. Media: Putin zatwierdził wymianę jeńców mimo sprzeciwu służby bezpieczeństwa FSB
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/wojna-w-ukrainie-media-putin-zatwierdzil-wymiane-jencow-mimo-sprzeciwu-sluzby-bezpieczenstwa-fsb/](https://www.polsatnews.pl/wiadomosc/2022-10-02/wojna-w-ukrainie-media-putin-zatwierdzil-wymiane-jencow-mimo-sprzeciwu-sluzby-bezpieczenstwa-fsb/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 09:26:00+00:00

Amerykański dziennik The Washington Post twierdzi, że ostatnia duża wymiana jeńców między Kremlem a Kijowem odbyła się przy sprzeciwie rosyjskiej Federalnej Służby Bezpieczeństwa. Władimir Putin miał zdecydować o przeprowadzeniu operacji, mimo sugestii, że zwolnienie m.in. jeńców z Azowstalu zaszkodzi wizerunkowo i rozzłości nacjonalistów. Gazeta pisze także, kto zyskał na wymianie więźniów.

## Wojna w Ukrainie. Rosja podczas inwazji straciła ponad 60 tys. żołnierzy
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/wojna-w-ukrainie-rosja-podczas-inwazji-stracila-ponad-60-tys-zolnierzy/](https://www.polsatnews.pl/wiadomosc/2022-10-02/wojna-w-ukrainie-rosja-podczas-inwazji-stracila-ponad-60-tys-zolnierzy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 08:14:00+00:00

Straty armii Rosji w czasie wojny z Ukrainą przekroczyły 60 tys. żołnierzy - podał ukraiński sztab. Według dowództwa tylko w ciągu ostatniej doby Kreml stracił 500 ludzi, a największe straty Rosjanie ponieśli na kierunkach bachmuckim i kramatorskim.

## Wojna w Ukrainie. Kolejne osierocone dzieci wywiezione do Rosji
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/wojna-w-ukrainie-kolejne-osierocone-dzieci-wywiezione-do-rosji/](https://www.polsatnews.pl/wiadomosc/2022-10-02/wojna-w-ukrainie-kolejne-osierocone-dzieci-wywiezione-do-rosji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 07:40:00+00:00

76 osieroconych dzieci z obwodu ługańskiego na wschodzie Ukrainy zostało przez Rosjan wywiezionych do ośrodków dla niepełnoletnich w Rosji - poinformował w niedzielę na Telegramie lojalny wobec Kijowa szef władz obwodu ługańskiego Serhij Hajdaj.

## Wojna w Ukrainie. Polski ksiądz o działaniach świata: Nie mogę milczeć. Patrzę na dramat dzieci
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/wojna-w-ukrainie-polski-ksiadz/](https://www.polsatnews.pl/wiadomosc/2022-10-02/wojna-w-ukrainie-polski-ksiadz/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 07:32:00+00:00

- Trzeba konkretnych działań, żeby okrucieństwo wojny zminimalizować i zaprzestać (go) w tym momencie - mówił w Polsat News ks. Wojciech Stasiewicz z Charkowa. Zaangażowanie światowej dyplomacji w sprawę pokoju w Ukrainie ocenił jako mierne. - Nie mogę milczeć. Zima będzie najgorszym czasem w czasie tej wojny - dodał, apelując o pomoc i wszystko to, co jest najbardziej potrzebne podczas zimy.

## USA. Co najmniej 54 ofiary huraganu Ian. Polska dziennikarka z Florydy: Tego nie da się opisać
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/usa-co-najmniej-50-ofiar-huraganu-ian-polska-dziennikarka-z-florydy-tego-nie-da-sie-opisac/](https://www.polsatnews.pl/wiadomosc/2022-10-02/usa-co-najmniej-50-ofiar-huraganu-ian-polska-dziennikarka-z-florydy-tego-nie-da-sie-opisac/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 06:04:00+00:00

Floryda walczy ze skutkami potężnego uderzenia huraganu Ian, który przechodząc nad stanem spowodował powodzie, niszczył domy i infrastrukturę. Wciąż wiele miejsc jest odciętych od świata, a służby ratunkowe poszukują potrzebujących pomocy i ofiar. W dotknięty zniszczeniami rejon udaje się prezydent USA Joe Biden, który chce osobiście ocenić skalę kataklizmu. O żywiole mówiła mieszkająca tam Polka.

## Indonezja. Zamieszki po meczu. Co najmniej 129 osób nie żyje, wielu rannych
 - [https://www.polsatnews.pl/wiadomosc/2022-10-02/indonezja-zamieszki-po-meczu-co-najmniej-127-osob-nie-zyje/](https://www.polsatnews.pl/wiadomosc/2022-10-02/indonezja-zamieszki-po-meczu-co-najmniej-127-osob-nie-zyje/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-02 04:31:00+00:00

Zamieszki po meczu w indonezyjskiej prowincji Jawa Wschodnia. Awantura po przegranym spotkaniu doprowadziła do wybuchu paniki i zamieszek. Nie żyje co najmniej 129 osób, a 180 rannych. Według agencji Reutera to jedna z największych tragedii piłkarskich na świecie.


# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Intel Core i9-13900K oraz topowe płyty główne Z790 obsługują pamięci DDR5-7600 dzięki XMP 3.0
 - [https://ithardware.pl/aktualnosci/intel_core_i9_13900k_oraz_topowe_plyty_glowne_z790_obsluguja_pamieci_ddr5_7600_dzieki_xmp_3_0-23628.html](https://ithardware.pl/aktualnosci/intel_core_i9_13900k_oraz_topowe_plyty_glowne_z790_obsluguja_pamieci_ddr5_7600_dzieki_xmp_3_0-23628.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-02 20:30:20+00:00

<img src="https://ithardware.pl/artykuly/min/23628_1.jpg" />            W trakcie wydarzenia Intel Innovation 2022, firma ogłosiła&nbsp;obsługę pamięci&nbsp;DDR5-5600 przez procesory Raptor Lake tuż po wyjęciu z pudełka. Dzięki technologii XMP 3.0 wspierane są r&oacute;wnież&nbsp;moduły DDR5-7600, co zostało...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_core_i9_13900k_oraz_topowe_plyty_glowne_z790_obsluguja_pamieci_ddr5_7600_dzieki_xmp_3_0-23628.html">htt

## Facebook i Instagram aktualizują funkcje związane z NFT
 - [https://ithardware.pl/aktualnosci/facebook_i_instagram_aktualizuja_funkcje_zwiazane_z_nft-23630.html](https://ithardware.pl/aktualnosci/facebook_i_instagram_aktualizuja_funkcje_zwiazane_z_nft-23630.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-02 19:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/23630_1.jpg" />            Meta wprowadziła aktualizację funkcji związanych z NFT w serwisach społecznościowych Facebook i Instagram. Firma najwyraźniej nadal wierzy w niewymienny token, kt&oacute;ry ostatnio zanotował ogromny spadek wartości.

Meta poinformowała o...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/facebook_i_instagram_aktualizuja_funkcje_zwiazane_z_nft-23630.html">https://ithardware.pl/aktualnosci/facebo

## Microsoft przygotowuje nowy kontroler do Xboxa, który umie "zmieniać kolor"
 - [https://ithardware.pl/aktualnosci/microsoft_przygotowuje_nowy_kontroler_do_xboxa_ktory_umie_zmieniac_kolor-23629.html](https://ithardware.pl/aktualnosci/microsoft_przygotowuje_nowy_kontroler_do_xboxa_ktory_umie_zmieniac_kolor-23629.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-02 17:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/23629_1.jpg" />            Amazon najwyraźniej pospieszył się z prezentacją nowego kontrolera do Xbox Series X/S, kt&oacute;ry jest dość nietypowy, ponieważ potrafi &quot;zmieniać kolor&quot; pod pewnym czynnikiem.

Microsoft pracuje nad nowym kontrolerem do konsol Xbox...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_przygotowuje_nowy_kontroler_do_xboxa_ktory_umie_zmieniac_kolor-23629.html">https://ithardware

## Radeon Pro W6300 2GB, czyli jeszcze słabsza karta graficzna do komputerów stacjonarnych
 - [https://ithardware.pl/aktualnosci/radeon_pro_w6300_2gb_czyli_jeszcze_slabsza_karta_graficzna_do_komputerow_stacjonarnych-23627.html](https://ithardware.pl/aktualnosci/radeon_pro_w6300_2gb_czyli_jeszcze_slabsza_karta_graficzna_do_komputerow_stacjonarnych-23627.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-02 15:54:30+00:00

<img src="https://ithardware.pl/artykuly/min/23627_1.jpg" />            Okazuje się, że AMD chce stworzyć jeszcze słabszą kartę graficzną dla komputer&oacute;w stacjonarnych od Radeona RX 6400. Na stronie internetowej firmy pojawił się&nbsp;Radeon Pro W6300, czyli propozycja z segmentu&nbsp;low-end. Fakt faktem, że...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/radeon_pro_w6300_2gb_czyli_jeszcze_slabsza_karta_graficzna_do_komputerow_stacjonarnych-23627.html">htt

## Poznaliśmy zagraniczne ceny płyt głównych MSI B650 (AM5)
 - [https://ithardware.pl/aktualnosci/poznalismy_zagraniczne_ceny_plyt_glownych_msi_b650_am5-23626.html](https://ithardware.pl/aktualnosci/poznalismy_zagraniczne_ceny_plyt_glownych_msi_b650_am5-23626.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-02 15:07:20+00:00

<img src="https://ithardware.pl/artykuly/min/23626_1.jpg" />            Jeden z zagranicznych sprzedawc&oacute;w ujawnił ceny niekt&oacute;rych płyt gł&oacute;wnych MSI z chipsetem AMD B650. W ofercie znalazły się konstrukcje z r&oacute;żnych przedział&oacute;w cenowych, a najtańszą z nich wyceniono na 200&nbsp;USD....
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/poznalismy_zagraniczne_ceny_plyt_glownych_msi_b650_am5-23626.html">https://ithardware.pl/aktualnosci/

## Czekasz na Diablo 4? Ja też! Oto 11 rzeczy, które chcę zobaczyć w nowej odsłonie
 - [https://ithardware.pl/artykuly/diablo_4_11_rzeczy_ktore_chce_zobaczyc_w_przeboju_blizzarda-23601.html](https://ithardware.pl/artykuly/diablo_4_11_rzeczy_ktore_chce_zobaczyc_w_przeboju_blizzarda-23601.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-02 14:13:50+00:00

<img src="https://ithardware.pl/artykuly/min/23601_1.jpg" />            Premiera Diablo 4 już w przyszłym roku. Pora doprowadzić nasze wyobrażenia o najnowszej grze Blizzarda do ostatecznego stadium.

&quot;Zamieć&quot; odkryła już wiele kart, ale wciąż pozostaje przestrzeń do snucia naszych wizji na temat...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/diablo_4_11_rzeczy_ktore_chce_zobaczyc_w_przeboju_blizzarda-23601.html">https://ithardware.pl/artykuly/diablo_4_11

## YouTube. Filmy w 4K mogą być zarezerwowane dla opcji Premium
 - [https://ithardware.pl/aktualnosci/youtube_filmy_w_4k_moga_byc_zarezerwowane_dla_opcji_premium-23625.html](https://ithardware.pl/aktualnosci/youtube_filmy_w_4k_moga_byc_zarezerwowane_dla_opcji_premium-23625.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-02 13:24:08+00:00

<img src="https://ithardware.pl/artykuly/min/23625_1.jpg" />            Google stara się przekonać użytkownik&oacute;w do YouTube Premium nie tylko brakiem reklam, ale r&oacute;wnież filmami wyświetlanymi w wyższej rozdzielczości.

Użytkownik Reddita opublikował zrzut ekranu z aplikacji mobilnej YouTube w wersji...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/youtube_filmy_w_4k_moga_byc_zarezerwowane_dla_opcji_premium-23625.html">https://ithardware.pl/aktualnosci

## Likwidacja Google Stadia. Ubisoft przeniesie swoje gry do Ubisoft Connect
 - [https://ithardware.pl/aktualnosci/likwidacja_google_stadia_ubisoft_przeniesie_swoje_gry_do_ubisoft_connect-23624.html](https://ithardware.pl/aktualnosci/likwidacja_google_stadia_ubisoft_przeniesie_swoje_gry_do_ubisoft_connect-23624.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-02 11:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/23624_1.jpg" />            Zamknięcie Google Stadia, kt&oacute;re nastąpi w styczniu 2023 roku stanowi wyzwanie nie tylko dla deweloper&oacute;w gier, kt&oacute;rzy wydali lub są w trakcie udostępniania swoich tytuł&oacute;w na platformie, ale r&oacute;wnież graczy,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/likwidacja_google_stadia_ubisoft_przeniesie_swoje_gry_do_ubisoft_connect-23624.html">https://ithardware.pl/

## Karty graficzne Intel Arc A770 oraz A750 zostały przetestowane w OpenCL i Vulkan
 - [https://ithardware.pl/aktualnosci/karty_graficzne_intel_arc_a770_oraz_a750_zostaly_przetestowane_w_opencl_i_vulkan-23623.html](https://ithardware.pl/aktualnosci/karty_graficzne_intel_arc_a770_oraz_a750_zostaly_przetestowane_w_opencl_i_vulkan-23623.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-02 10:25:50+00:00

<img src="https://ithardware.pl/artykuly/min/23623_1.jpg" />            Do sieci trafiły wyniki test&oacute;w kart graficznych Intel Arc A770 oraz A750 w benchmarkach OpenCL oraz Vulkan. Flagowiec Niebieskich zdobył w teście Vulkan&nbsp;73536 punkt&oacute;w. Arc A750 był z kolei w stanie wykrzesać z siebie&nbsp;66609...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/karty_graficzne_intel_arc_a770_oraz_a750_zostaly_przetestowane_w_opencl_i_vulkan-23623.html">https:/


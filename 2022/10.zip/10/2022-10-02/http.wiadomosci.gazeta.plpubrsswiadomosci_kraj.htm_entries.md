# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Rewolucja w polskim Kościele. Żonaci mężczyźni będą mogli rozpocząć posługę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28977608,rewolucja-w-polskim-kosciele-zonaci-mezczyzni-beda-mogli-rozpoczac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28977608,rewolucja-w-polskim-kosciele-zonaci-mezczyzni-beda-mogli-rozpoczac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-02 19:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0f/69/1b/z28745487M,Ksiadz--zdjecie-ilustracyjne-.jpg" vspace="2" />Biskup kielecki Jan Piotrowski zdecydował o wprowadzeniu diakonatu stałego. Oznacza to, że świeccy mężczyźni, również żonaci, będą mogli udzielać ślubów, chrztów, czy wygłaszać kazania.

## Łódzkie. 65-latek został stratowany przez byki. Mężczyzny nie udało się uratować
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28977103,lodzkie-mezczyzna-zostal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28977103,lodzkie-mezczyzna-zostal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-02 15:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d5/a2/1b/z28977109M,Lodzkie--Mezczyzna-zostal-stratowany-przez-byki.jpg" vspace="2" />W woj. łódzkim 65-latek w został stratowany przez byki na terenie swojego gospodarstwa - przekazała straż pożarna. Mężczyzna był reanimowany, jednak nie udało się go uratować. Sprawę wyjaśni policja pod nadzorem prokuratury.

## Lubelskie. 49-latek zginął podczas przewozu drewna. Mężczyznę przygniotły drewniane bale
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28976701,lubelskie-drewniane-bale-przygniotly-49-latka-podejrzany-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28976701,lubelskie-drewniane-bale-przygniotly-49-latka-podejrzany-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-02 13:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a6/a2/1b/z28976806M,Lubelskie--Drewniane-bale-przygniotly-49-latka--Po.jpg" vspace="2" />W województwie lubelskim doszło w sobotę do wypadku, w którym zginał 49-latek. Mężczyznę przygniotły drewniane bale. Policjanci zatrzymali już podejrzewanego w tej sprawie 43-latka. W chwili zatrzymania miał ponad dwa promile alkoholu w organizmie.

## Pielgrzymka na Jasną Górę. Sanepid zawierzony Matce Bożej: Nasza praca jest służbą wobec społeczeństwa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28976379,pielgrzymka-na-jasna-gore-sanepid-zawierzony-matce-bozej-nasza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28976379,pielgrzymka-na-jasna-gore-sanepid-zawierzony-matce-bozej-nasza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-02 11:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/34/67/1a/z27687988M,Ksiadz--zdjecie-ilustracyjne-.jpg" vspace="2" />Pracownicy anepidu z całej Polski odbyli w sobotę pielgrzymkę na Jasną Górę. Pod koniec mszy główny inspektor sanitarny Krzysztof Saczka dokonał aktu zawierzenia inspekcji Matce Bożej.

## Złotoryja. 81-latek walczył w samochodzie z pszczołą. Wjechał czołowo w drzewo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28976310,zlotoryja-81-latek-walczyl-w-samochodzie-z-pszczola-wjechal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28976310,zlotoryja-81-latek-walczyl-w-samochodzie-z-pszczola-wjechal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-02 10:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c7/a2/1b/z28976327M,Wypadek-drogowy.jpg" vspace="2" />Na trasie Złotoryja-Jelenia Góra samochód osobowy czołowo wjechał w drzewo. Jak się okazało, zawiniła pszczoła. Kierujący próbując wypędzić owada z wnętrza auta, stracił panowanie nad samochodem, zjechał z drogi i uderzył w drzewo.


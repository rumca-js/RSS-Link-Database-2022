# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Paramount's Smile Opens to Box Office Success
 - [https://gizmodo.com/paramount-smile-box-office-1849606991](https://gizmodo.com/paramount-smile-box-office-1849606991)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-02 19:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s---8CzMB_q--/c_fit,fl_progressive,q_80,w_636/51d19c7d58dd13d94f5baa277317ef40.png" /><p>As it goes every year, the month of October is when horror movies shine. Such a slate for the month includes <a href="https://gizmodo.com/halloween-ends-final-trailer-jamie-lee-curtis-peacock-1849585955"><em>Halloween Ends</em></a><em> </em>and a re-release of <a href="https://gizmodo.com/trick-r-treat-2007-theatrical-release-1849492998"><em>Trick ‘

## Thanks, Cartoon Network, for 30 Years of Being You
 - [https://gizmodo.com/cartoon-network-30-year-anniversary-1849137935](https://gizmodo.com/cartoon-network-30-year-anniversary-1849137935)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-02 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--9oEjsUKN--/c_fit,fl_progressive,q_80,w_636/85cc5df4ed6cf2d9264f010059a1110d.jpg" /><p>We here at io9 have talked at length  about cartoons, whether it’s cartoons from <a href="https://gizmodo.com/digimon-adventure-dub-zatch-bell-sequel-manga-reveal-1848599854">our childhoods</a> that we’ve loved, or <a href="https://gizmodo.com/hbo-max-infinity-train-removal-warner-bros-discovery-1849428203">more recent ones</a> that deserve a wider 

## Cabinet of Curiosities' New Trailer Sets the Scary Stage
 - [https://gizmodo.com/cabinet-of-curiosities-guillermo-del-toro-trailer-1849606871](https://gizmodo.com/cabinet-of-curiosities-guillermo-del-toro-trailer-1849606871)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-02 17:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--5rjCNOP_--/c_fit,fl_progressive,q_80,w_636/faa13899d37e8543a3540e6b3ced2a87.jpg" /><p>October means Halloween, and Halloween means horror movies and shows to watch. The month boasts some <a href="https://gizmodo.com/queer-for-fear-shudder-horror-doc-series-review-dracula-1849514631">upcoming projects</a> that are sure to be delightful such as the second season of <a href="https://gizmodo.com/chucky-don-mancini-interview-syfy-usa-quee

## Open Channel: What Marvel Show Should've Been a Film, or Vice Versa?
 - [https://gizmodo.com/open-channel-mcu-show-to-film-transition-1849606743](https://gizmodo.com/open-channel-mcu-show-to-film-transition-1849606743)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-02 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ZX6xsXzV--/c_fit,fl_progressive,q_80,w_636/b0e001fa60cc65899426f58327a1c75c.jpg" /><p>Earlier in the week, Marvel up and surprised everyone with the announcement that its Don Cheadle-led miniseries <a href="https://gizmodo.com/armor-wars-movie-don-cheadle-marvel-studios-disney-plus-1849599184"><em>Armor Wars</em></a><em> </em>was transitioning into a full blown movie. The apparent reasoning for this was that the studio realized in or

## Black Adam's Theme Changes the Hierarchy of Power in Superhero Music
 - [https://gizmodo.com/black-adam-musical-theme-lorne-balfe-1849606362](https://gizmodo.com/black-adam-musical-theme-lorne-balfe-1849606362)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-02 14:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--zwYd-Yn5--/c_fit,fl_progressive,q_80,w_636/0a0ddf44aaeec597c9d80ec1e63a9fd3.jpg" /><p>The existence of Warner Bros.’ <a href="https://gizmodo.com/black-adam-trailer-justice-society-dc-films-the-rock-1849508762"><em>Black Adam</em></a><em> </em>movie has, <a href="https://gizmodo.com/an-epic-timeline-of-the-rock-willing-dc-s-black-adam-in-1846528042">for the longest time</a>, felt like it wouldn’t come to pass. But here we are, just a

## The Mascot 'La Bussi' Is Promoting Public Transportation, so Get Your Mind out of the Gutter
 - [https://gizmodo.com/la-bussi-mascot-bus-spain-public-transportation-1849601961](https://gizmodo.com/la-bussi-mascot-bus-spain-public-transportation-1849601961)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-02 13:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--s0BRq-eT--/c_fit,fl_progressive,q_80,w_636/d9ce95cf6dba49c73dbbf1cd6e6c925e.jpg" /><p>A week ago, a new bus mascot <a href="https://twitter.com/Aj_Sabadell/status/1572978946601373696?s=20&amp;t=aib39LIHEoXa6nDJ8eXzzA" rel="noopener noreferrer" target="_blank">happily presented itself</a> to the world in Sabadell, a city outside of Barcelona in Spain. For some, it was big, unique, and colorful, with a certain <em>je ne sais quoi. </em


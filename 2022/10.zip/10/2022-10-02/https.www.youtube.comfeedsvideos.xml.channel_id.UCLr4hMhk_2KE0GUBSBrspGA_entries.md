# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Tech Week: Dlaczego Świat się wali?
 - [https://www.youtube.com/watch?v=N8vpYFd2050](https://www.youtube.com/watch?v=N8vpYFd2050)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2022-10-02 00:00:00+00:00

Link do znośnych ciuchów - https://znosne.pl
Moje sociale:
https://www.instagram.com/kubaklawiter/
https://twitter.com/KubaKlawiter

W odcinku:
00:00 Wstęp
00:19 Dobry wieczór!
00:24 Świat szachów: Magnus Carlsen oświadcza, że Hans Niemann oszukiwał
02:25 Sztuczna inteligencja pisze wypracowania uczniów z USA
02:51 Nawóz z ludzi
03:43 Coolio nie żyje
03:53 Edward Snowden dostał rosyjskie obywatelstwo
04:54 Elon Musk tweetuje o tym, że Cybertruck może być łodzią
05:47 Robot humanoidalny od Tesli
07:07 Tony Blevins zwolniony z Apple
09:07 Pixel Watch w Targecie
09:40 Konta FitBit przestaną istnieć?
09:54 LG wprowadzi przezroczyste ekrany w oknach pociągów
10:45 MrWhoistheboss odkrywa puchnące baterie w Samsungach
12:02 Google zamyka Stadię
12:07 Głos Lorda Vadera przechodzi na emeryturę
12:12 Nowe etui na słuchawki od Nothing
13:15 Nowa kolekcja Smutek i Nostalgia już na znosne.pl
13:34 Dlaczego świat się wali? + zaproszenie do dyskusji
14:12 Pożegnanie
14:15 Znośnego tygodnia!

Źródła:
Magnus Carlsen oświadcza, że Hans Niemann oszukiwał: https://bit.ly/3UTjSpb
Sztuczna inteligencja pisze wypracowania za uczniów: https://bit.ly/3SuKhrR
Ludzki nawóz: https://nbcnews.to/3UXcZTW
Coolio nie żyje: https://bit.ly/3UXBRuu
Edward Snowden został Ruskiem: https://bbc.in/3SMp3W6
Musk o tym, że Cybertruck może być łodzią: https://bit.ly/3RwY3sF
Prezentacja robota humanoidalnego Tesli: https://youtu.be/UXHoWNfjJYM
Jak wejdzie na scenę i pomacha to będzie porażka: https://bit.ly/3LWOPEZ
Historia Tonego Blevinsa: https://on.wsj.com/3rr0VfW
Tony Blevins na TikToku: https://bit.ly/3LWPiad
Tony Blevins zwolniony: https://cnet.co/3SxiN4L
Pixel Watch w Targecie: https://bit.ly/3RupBig
Pożegnaj swoje konto FitBit: https://bit.ly/3SnTQZz
Przezroczyste ekrany w oknach pociągów: https://bit.ly/3UVj9Ux
MrWhoistheboss odkrył, że baterie Samsunga puchną: https://bit.ly/3dXWrul
Google zamyka Stadię: https://bit.ly/3y96402
Głos Vadera odchodzi na emeryturę: https://bit.ly/3UZGcgP
Rolka na słuchawki od Nothing: https://bit.ly/3UUQv5V
Pies narobił kobiecie do buzi i trafiła do szpitala: https://bit.ly/3Rwi02T


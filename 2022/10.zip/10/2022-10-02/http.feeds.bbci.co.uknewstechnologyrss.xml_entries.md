# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Can electrical stimulation improve your gym workout?
 - [https://www.bbc.co.uk/news/business-62887379?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62887379?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-10-02 23:01:12+00:00

Whole-body EMS suits are the new big thing in fitness, but do they work?

## April Jones: Is the internet safer after April Jones' murder?
 - [https://www.bbc.co.uk/news/uk-wales-63073562?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-63073562?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-10-02 06:21:52+00:00

Powers were granted for some after her murderer was found with imagery on his computer.


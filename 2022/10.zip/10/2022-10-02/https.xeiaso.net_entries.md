## Prompt engineering is hard - Xe
 - [https://xeiaso.net/blog/prompt-engineering](https://xeiaso.net/blog/prompt-engineering)
 - RSS feed: https://xeiaso.net
 - date published: 2022-10-02 09:53:11.662631+00:00

Prompt engineering is hard - Xe's Blog


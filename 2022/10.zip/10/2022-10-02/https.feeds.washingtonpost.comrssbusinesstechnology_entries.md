# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## This astronaut trains by flying fighter jets. We went along for the ride.
 - [https://www.washingtonpost.com/technology/2022/10/02/astronaut-training-fighter-jets/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/10/02/astronaut-training-fighter-jets/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-02 07:00:05+00:00

Spaceflight is a difficult, scary endeavor that doesn’t come with a game-over button. That's why Jared Isaacman and his crew train by flying jets — where there's no escape.


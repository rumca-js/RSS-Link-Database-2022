# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## 6 Inventors Who Were Killed By Their Own Inventions
 - [https://www.youtube.com/watch?v=utJ54odBPWA](https://www.youtube.com/watch?v=utJ54odBPWA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2022-10-03 00:00:00+00:00

Go to http://www.80000hours.org/joescott and see how 80,000 Hours can help you find a rewarding career that makes a difference in the world.
In the endless march of innovation, you're going to have some missteps along the way. From balloon accidents to questionable bed apparatuses, here are 6 inventors who were killed by their own inventions.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPGzF
Apple Podcasts 👉 https://apple.co/3j94kfq
Google Podcasts 👉 https://bit.ly/3qZCo1V

Interested in getting a Tesla or going solar? Use my referral link and get discounts and perks:
https://ts.la/joe74700

Follow me at all my places!
Instagram: https://instagram.com/answerswithjoe
TikTok: https://www.tiktok.com/@answerswithjoe
Facebook: http://www.facebook.com/answerswithjoe
Twitter: https://www.twitter.com/answerswithjoe

LINKS LINKS LINKS - 
https://en.wikipedia.org/wiki/Franz_Reichelt
https://www.youtube.com/watch?v=BKOCZ4zTKAw
https://www.healthandenvironment.org/environmental-health/social-context/history/thomas-midgley-jr.-developed-tetraethyl-lead-for-gasoline
https://today.duke.edu/2022/03/lead-exposure-last-century-shrunk-iq-scores-half-americans
https://www.thetimes.co.uk/article/leaded-petrol-reduces-intelligence-decades-later-cwlbdwkzj
https://web.archive.org/web/20081214232532/http://www.time.com/time/magazine/article/0,9171,801605,00.html
https://www.newlifeonahomestead.com/wp-content/uploads/2022/07/bantam_silkie-800x990.jpg
https://www.historyhit.com/1785-english-channel-balloon-crossing/
https://blogs.bl.uk/untoldlives/2019/01/blanchard-where-are-your-trousers-the-first-crossing-of-the-english-channel-in-a-balloon.html
https://uh.edu/engines/epi2405.htm
https://www.nationalballoonmuseum.com/about/history-of-ballooning/
https://en.wikisource.org/wiki/Wonderful_Balloon_Ascents/Part_2/Chapter_10
https://uh.edu/engines/epi2405.htm
https://en.wikipedia.org/wiki/AVE_Mizar
https://www.tortmuseum.org/ford-pinto/
https://www.mentalfloss.com/article/31341/flying-pinto-killed-its-inventor
https://medium.com/lessons-from-history/the-original-high-speed-train-was-invented-over-100-years-ago-f759ba9b4b40
https://www.theguardian.com/world/2022/sep/01/russian-oil-executive-dies-in-fall-from-moscow-hospital-window
https://www.usni.org/magazines/naval-history-magazine/2014/january/one-way-mission-h-l-hunley
https://www.history.com/news/9-groundbreaking-early-submarines
https://www.hunley.org/artifacts/
https://www.datamp.org//patents/displayPatent.php?pn=38200&id=58486
https://sites.rootsweb.com/~nygreen2/william_bullock.htm
https://www.discovermagazine.com/the-sciences/five-inventors-killed-by-their-own-creations
https://en.wikipedia.org/wiki/List_of_inventors_killed_by_their_own_invention
https://www.mentalfloss.com/article/647720/inventors-killed-by-their-own-inventions
https://www.thegentlemansjournal.com/inventors-killed-by-their-own-inventions/
https://historycollection.com/20-inventors-killed-by-their-own-inventions/15/

TIMESTAMPS
0:00 - Intro
1:55 - Thomas Midgley Jr.
3:47 - Jean François Pilâtre de Rozier 
6:49 - Harry Smolinski
8:57 - Valerian Ivanovich Abakovsky 
11:37 - Horace Lawson Hunley 
14:20 - William Bullock
16:46 - Sponsor


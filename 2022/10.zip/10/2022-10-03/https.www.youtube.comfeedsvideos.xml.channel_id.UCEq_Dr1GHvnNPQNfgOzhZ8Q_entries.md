# Source:Solid jj, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q, language:en-US

## Yu-Gi-Oh Logic
 - [https://www.youtube.com/watch?v=gIoY7wnif-w](https://www.youtube.com/watch?v=gIoY7wnif-w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q
 - date published: 2022-10-03 20:03:00+00:00

Yu-Gi-Oh like how it’s never been played before unless you played it as a kid then this is about right 

Second channel: @Solidusjj 
Patreon: https://patreon.com/solidjj


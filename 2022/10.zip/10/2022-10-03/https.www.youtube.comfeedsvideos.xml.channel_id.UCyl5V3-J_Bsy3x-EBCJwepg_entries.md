# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Twitter Employees Go BERSERK Over Elon Musk
 - [https://www.youtube.com/watch?v=jUy-tryeV1w](https://www.youtube.com/watch?v=jUy-tryeV1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2022-10-04 00:00:00+00:00

Outraged by the Elon Musk purchase of Twitter, employees formed an Elon Musk-free autonomous zone Tuesday. Long live Twitter CHAZ - err, SPAZ!

Subscribe to Chandler's Youtube: https://www.youtube.com/chandlerjuliet 

Subscribe to our new podcast channel: https://www.youtube.com/thebabylonbeepodcast

Become a premium subscriber:  https://babylonbee.com/plans

The Official The Babylon Bee Store:  https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
Twitter: https://twitter.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee


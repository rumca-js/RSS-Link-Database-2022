# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## To on krzyknął "hańba" i "kłamstwo", gdy przemawiał Kaczyński. Na spotkanie wszedł z plakietką z koncertu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28981856,to-on-krzyknal-hanba-i-klamstwo-gdy-przemawial-kaczynski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28981856,to-on-krzyknal-hanba-i-klamstwo-gdy-przemawial-kaczynski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-03 19:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c2/a3/1b/z28981954M,Maksym-Arlukowicz--to-on-krzyczal--hanba--na-spotk.jpg" vspace="2" />Wszedł na spotkanie z Jarosławem Kaczyńskim, bo miał plakietkę. Z koncertu i w innym kolorze, ale miał. To on - Maksym Arłukowicz, syn europosła PO Bartosza Arłukowicza krzyczał podczas przemówienia lidera Prawa i Sprawiedliwości "hańba" i "kłamstwo".

## Rzeszów. Złodzieje obrabowali kantor. Wybili dziurę w ścianie i ukradli 800 tys. zł. Są poszukiwani
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28981768,rzeszow-zlodzieje-obrabowali-kantor-wybili-dziure-w-scianie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28981768,rzeszow-zlodzieje-obrabowali-kantor-wybili-dziure-w-scianie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-03 18:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e6/94/12/z19481830M.jpg" vspace="2" />Złodzieje włamali się do kantoru w centrum Rzeszowa. Sprawcy wybili dziurę w budynku i weszli do niego. Ukradli około 800 tys. zł. Policja poszukuje sprawców.

## Częstochowa. Nie żyje 48-letni policjant. Zderzył się z rowerzystą na ścieżce
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28981524,czestochowa-nie-zyje-48-letni-policjant-zderzyl-sie-z-rowerzysta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28981524,czestochowa-nie-zyje-48-letni-policjant-zderzyl-sie-z-rowerzysta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-03 16:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/58/a3/1b/z28981592M,Komisariat-w-Czestochowie--Zdjecie-ilustracyjne.jpg" vspace="2" />Częstochowska policja poinformowała o śmierci 48-letniego asp. Bartłomieja Bojanowskiego. Funkcjonariusz pod koniec września został ranny w wypadku na ścieżce rowerowej. Jadący do pracy policjant zderzył się z drugim rowerzystą.

## Obowiązkowa służba wojskowa? Większość Polaków nie chce jej powrotu [SONDAŻ]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28979597,obowiazkowa-sluzba-wojskowa-wiekszosc-polakow-nie-chce-jej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28979597,obowiazkowa-sluzba-wojskowa-wiekszosc-polakow-nie-chce-jej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-03 14:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7c/a3/1b/z28980348M,Zolnierze--zdjecie-ilustracyjne-.jpg" vspace="2" />Przywrócenie poboru do wojska? Prawie 60 proc. Polaków jest temu przeciwna - wynika z sondażu IBRIS przeprowadzonego na zlecenie "Rzeczpospolitej". Jeszcze kilka miesięcy temu niechęć do przywrócenia obowiązkowej służby wojskowej była mniejsza. Najwięcej przeciwników poboru do wojska jest wśród młodych.

## Jerzy Urban nie żyje. Miał 89 lat
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28978987,jerzy-urban-nie-zyje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28978987,jerzy-urban-nie-zyje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-03 09:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5f/a2/1b/z28979039M,Jerzy-Urban-nie-zyje.jpg" vspace="2" />Zmarł Jerzy Urban, dziennikarz, publicysta, a także założyciel i długoletni redaktor naczelny tygodnika "NIE". W latach 1981-89 rzecznik prasowy Rady Ministrów PRL oraz współtwórca propagandy stanu wojennego. Miał 89 lat.

## Wypadek w Zachmielu. Jedno z aut rozpadło się na pół. Kierowała nim 19-latka, choć się tego wypierała
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28978074,wypadek-w-zachmielu-jedno-z-aut-rozpadlo-sie-na-pol-kierowala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,28978074,wypadek-w-zachmielu-jedno-z-aut-rozpadlo-sie-na-pol-kierowala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-03 08:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/39/91/1b/z28907833M,policja---zdjecie-ilustracyjne.jpg" vspace="2" />Pięć osób zostało rannych w wypadku w Zachmielu (woj. mazowieckie), do którego doszło w niedzielę wieczorem. Wszystkie wyszły z samochodów o własnych siłach. Wiadomo już, kto doprowadził do kolizji.


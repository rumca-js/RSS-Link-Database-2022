# Source:NY times, URL:https://rss.nytimes.com/services/xml/rss/nyt/World.xml, language:en-US

## Russia’s Small Nuclear Arms Are a Risk For Putin and Ukraine
 - [https://www.nytimes.com/2022/10/03/us/politics/russia-tactical-nuclear-weapons.html](https://www.nytimes.com/2022/10/03/us/politics/russia-tactical-nuclear-weapons.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 23:39:04+00:00

President Vladimir V. Putin of Russia has 2,000 small nuclear weapons, but their utility on the battlefield may not be worth the longer-term costs.

## Elon Musk Tweets About How to End  to End the War in Ukraine
 - [https://www.nytimes.com/2022/10/03/world/europe/elon-musk-ukraine-war-tweets.html](https://www.nytimes.com/2022/10/03/world/europe/elon-musk-ukraine-war-tweets.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 22:58:27+00:00

President Zelensky swiftly dismisses the entrepreneur’s suggestion on Twitter.

## Election Deniers in U.S. Push Idea of Voting Fraud in Brazil
 - [https://www.nytimes.com/2022/10/03/us/politics/election-deniers-brazil-midterms.html](https://www.nytimes.com/2022/10/03/us/politics/election-deniers-brazil-midterms.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 22:37:19+00:00

Some prominent election denialists in the United States are using Brazil to try to whip up concern about the approaching midterms.

## Brittney Griner’s Appeal Hearing Set for Oct. 25, Russian Court Says
 - [https://www.nytimes.com/2022/10/03/world/europe/brittney-griner-appeal-hearing-russia.html](https://www.nytimes.com/2022/10/03/world/europe/brittney-griner-appeal-hearing-russia.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 22:36:14+00:00

The United States has sought the release of the W.N.B.A. star, who pleaded guilty to drug possession and was sentenced to nine years.

## Your Tuesday Briefing: Indonesia Investigates Its Soccer Tragedy
 - [https://www.nytimes.com/2022/10/03/briefing/indonesia-soccer-investigate-asia.html](https://www.nytimes.com/2022/10/03/briefing/indonesia-soccer-investigate-asia.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 21:13:39+00:00

Plus Brazil’s elections move to a runoff and Ukraine surges forward in the Donbas.

## Brazil Braces for ‘White-Knuckle Race’ Between Bolsonaro and Lula
 - [https://www.nytimes.com/2022/10/03/world/americas/brazil-bolsonaro-lula-runoff.html](https://www.nytimes.com/2022/10/03/world/americas/brazil-bolsonaro-lula-runoff.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 20:18:57+00:00

President Jair Bolsonaro had once looked doomed in the country’s high-stakes election. But now, in a runoff, the right-wing incumbent has a path to re-election.

## Russian Disarray on Display as Ukraine’s Forces Advance on Two Fronts
 - [https://www.nytimes.com/live/2022/10/03/world/russia-ukraine-war-news](https://www.nytimes.com/live/2022/10/03/world/russia-ukraine-war-news)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 19:59:14+00:00

Kremlin-installed officials said they had lost ground in the east and south, as Moscow acknowledged that the borders of the territory it has illegally annexed were in flux.

## Deadly Soccer Clash in Indonesia Puts Police Tactics, and Impunity, in Spotlight
 - [https://www.nytimes.com/2022/10/03/world/asia/indonesia-soccer-stadium-stampede.html](https://www.nytimes.com/2022/10/03/world/asia/indonesia-soccer-stadium-stampede.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 19:50:00+00:00

Experts say officers are almost never held accountable for their actions. And in a huge police budget, millions are spent on tear gas, batons and other devices deployed during protests.

## A 95-Square-Foot Tokyo Apartment: ‘I Wouldn’t Live Anywhere Else’
 - [https://www.nytimes.com/2022/10/03/business/tiny-apartments-tokyo.html](https://www.nytimes.com/2022/10/03/business/tiny-apartments-tokyo.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 19:28:46+00:00

Meet the young Japanese who have decided to live in a shoe box.

## Victoria and Albert Museum Reverses Course and Removes Sackler Name
 - [https://www.nytimes.com/2022/10/03/arts/design/victoria-and-albert-museum-sacklers.html](https://www.nytimes.com/2022/10/03/arts/design/victoria-and-albert-museum-sacklers.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 18:18:45+00:00

The museum’s director had previously said he was not going to erase the name of the Sackler family, which founded Purdue Pharma, the creator of an addictive opioid painkiller.

## Iran’s Supreme Leader Condemns Protests Gripping Country
 - [https://www.nytimes.com/2022/10/03/world/middleeast/iran-ayatollah-khameini-protests.html](https://www.nytimes.com/2022/10/03/world/middleeast/iran-ayatollah-khameini-protests.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 17:50:09+00:00

Ayatollah Ali Khamenei, speaking for the first time about the uprising, accused the U.S. and Israel of fomenting unrest and voiced support for the crackdown on protesters.

## Head of Ukraine’s Zaporizhzhia Nuclear Plant Released From Detention
 - [https://www.nytimes.com/2022/10/03/world/europe/zaporizhzhia-nuclear-plant-director-general-iaea.html](https://www.nytimes.com/2022/10/03/world/europe/zaporizhzhia-nuclear-plant-director-general-iaea.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 17:13:10+00:00

The detention by Russia of Ihor Murashov had stoked concerns about the security of Europe’s largest nuclear plant.

## Éric Dupond-Moretti, French Justice Minister, Faces Trial
 - [https://www.nytimes.com/2022/10/03/world/europe/french-justice-minister-trial.html](https://www.nytimes.com/2022/10/03/world/europe/french-justice-minister-trial.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 16:22:10+00:00

Éric Dupond-Moretti opened investigations of judges he had clashed with as a lawyer, prompting accusations that he had abused his position to settle scores.

## Maggie Haberman Talks About Reporting on Donald Trump
 - [https://www.nytimes.com/2022/10/03/briefing/donald-trump-maggie-haberman-book.html](https://www.nytimes.com/2022/10/03/briefing/donald-trump-maggie-haberman-book.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 15:05:23+00:00

He often utters falsehoods, but his speaking style is more strategic than it sometimes seems. Listen for the first time to audio clips from interviews with Maggie Haberman.

## The Kremlin, after trumpeting annexation, admits it doesn’t know where the borders are.
 - [https://www.nytimes.com/live/2022/10/03/world/russia-ukraine-war-news/the-kremlin-after-trumpeting-annexation-admits-it-doesnt-know-where-the-borders-are](https://www.nytimes.com/live/2022/10/03/world/russia-ukraine-war-news/the-kremlin-after-trumpeting-annexation-admits-it-doesnt-know-where-the-borders-are)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 15:04:04+00:00



## Arema fans gather for a weeklong vigil to pay respects to the dead.
 - [https://www.nytimes.com/live/2022/10/03/world/indonesia-soccer-football-stadium/arema-fans-gather-for-a-weeklong-vigil-to-pay-respects-to-the-dead](https://www.nytimes.com/live/2022/10/03/world/indonesia-soccer-football-stadium/arema-fans-gather-for-a-weeklong-vigil-to-pay-respects-to-the-dead)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 12:24:23+00:00



## On Russian TV, the Kremlin emphasizes a fight against all of the West, not just Ukraine.
 - [https://www.nytimes.com/2022/10/03/world/europe/on-russian-tv-the-kremlin-emphasizes-a-fight-against-all-of-the-west-not-just-ukraine.html](https://www.nytimes.com/2022/10/03/world/europe/on-russian-tv-the-kremlin-emphasizes-a-fight-against-all-of-the-west-not-just-ukraine.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 11:33:48+00:00



## Ukraine’s First Lady, Olena Zelenska, Tells ‘60 Minutes’ of the War’s Impact
 - [https://www.nytimes.com/2022/10/03/world/europe/ukraine-first-lady-60-minutes.html](https://www.nytimes.com/2022/10/03/world/europe/ukraine-first-lady-60-minutes.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 10:16:32+00:00

Olena Zelenska told CBS News that Russian attacks on schools, hospitals and residential areas have been a form of terrorism.

## Unearthing Everyday Life at an Ancient Site in Greece
 - [https://www.nytimes.com/2022/10/03/travel/iklaina-archaeology-greece.html](https://www.nytimes.com/2022/10/03/travel/iklaina-archaeology-greece.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 09:00:27+00:00

Excavations in the Peloponnesian village of Iklaina are yielding rich insights into the lives of the Mycenaean civilization’s general population.

## Nobel Prize in Physiology or Medicine to Be Awarded Today
 - [https://www.nytimes.com/2022/10/03/health/nobel-prize-medicine-physiology-winner.html](https://www.nytimes.com/2022/10/03/health/nobel-prize-medicine-physiology-winner.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 08:35:09+00:00

It will be the first Nobel Prize awarded this year, with more announcements being made over the coming week.

## Indonesian human rights official says tear gas likely played a key role in the disaster.
 - [https://www.nytimes.com/2022/10/03/world/asia/tear-gas-human-rights.html](https://www.nytimes.com/2022/10/03/world/asia/tear-gas-human-rights.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 08:09:07+00:00

An initial examination shows that police also used violent force against fans. Without gas, the tragedy might have been avoided, the organization said.

## Truss, in Reversal, Drops Plan to Cut U.K. Tax Rate on High Earners
 - [https://www.nytimes.com/2022/10/03/world/europe/uk-tax-rate-cut.html](https://www.nytimes.com/2022/10/03/world/europe/uk-tax-rate-cut.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 07:43:12+00:00

The announcement was a major capitulation by the government after tax cuts it announced roiled financial markets and drew widespread criticism.

## The investigation will take two weeks, an official says.
 - [https://www.nytimes.com/2022/10/03/world/asia/the-investigation-will-take-two-weeks-an-official-says.html](https://www.nytimes.com/2022/10/03/world/asia/the-investigation-will-take-two-weeks-an-official-says.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 06:08:13+00:00



## Indonesia Appoints Independent Commission to Investigate Deaths
 - [https://www.nytimes.com/live/2022/10/03/world/indonesia-soccer-football-stadium](https://www.nytimes.com/live/2022/10/03/world/indonesia-soccer-football-stadium)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 04:57:54+00:00

Questions remain about why the police used tear gas to disperse fans in the overcrowded stadium. At least 125 people died, many trampled, after Saturday’s game.

## Your Monday Briefing
 - [https://www.nytimes.com/2022/10/03/briefing/pipeline-leakages-indonesia-soccer.html](https://www.nytimes.com/2022/10/03/briefing/pipeline-leakages-indonesia-soccer.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 04:54:54+00:00

Nord Stream leakages stop.

## Bolsonaro Outperforms Polls and Forces Runoff Against Lula in Brazil’s Presidential Election
 - [https://www.nytimes.com/2022/10/03/world/americas/brazil-elections-runoff-bolsonaro-lula.html](https://www.nytimes.com/2022/10/03/world/americas/brazil-elections-runoff-bolsonaro-lula.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 04:35:57+00:00

The two political titans will face off again later this month in a race widely seen as a major test for one of the world’s largest democracies.

## Russia’s Annexation Claim Is News to Residents of Lyman, Ukraine
 - [https://www.nytimes.com/2022/10/03/world/europe/russia-lyman-ukraine.html](https://www.nytimes.com/2022/10/03/world/europe/russia-lyman-ukraine.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
 - date published: 2022-10-03 04:01:14+00:00

Without access to electricity, radios or the internet, residents of Lyman said they were unaware of President Vladimir V. Putin’s grandiose celebration of an illegal land grab.


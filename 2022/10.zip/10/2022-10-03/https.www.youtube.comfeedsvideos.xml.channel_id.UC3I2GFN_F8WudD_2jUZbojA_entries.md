# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Durand Jones & The Indications - Cruisin' To The Parque (Live on KEXP)
 - [https://www.youtube.com/watch?v=KtNru1txQVk](https://www.youtube.com/watch?v=KtNru1txQVk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-03 00:00:00+00:00

http://KEXP.ORG presents Durand Jones & The Indications performing “Cruisin' To The Parque” live at THING festival at Fort Worden in Port Townsend, Washington. Recorded August 27, 2022.

Host: Morgan Chosnyk
KEXP Engineers: Julian Martlew & Matt Ogaz
Mixing and Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Director & Editor: Scott Holpainen

https://durandjonesandtheindications.com
http://kexp.org

## Durand Jones & The Indications - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=TZhe0H2a9Ag](https://www.youtube.com/watch?v=TZhe0H2a9Ag)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-03 00:00:00+00:00

http://KEXP.ORG presents Durand Jones & The Indications performing live at THING festival at Fort Worden in Port Townsend, Washington. Recorded August 27, 2022.

Songs:
Listen To Your Heart
You And Me
Cruisin’ To The Parque
More Than Ever

Host: Morgan Chosnyk
KEXP Engineers: Julian Martlew & Matt Ogaz
Mixing and Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Director & Editor: Scott Holpainen

https://durandjonesandtheindications.com
http://kexp.org

## Durand Jones & The Indications - Listen To Your Heart (Live on KEXP)
 - [https://www.youtube.com/watch?v=uQA3M0pPI2A](https://www.youtube.com/watch?v=uQA3M0pPI2A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-03 00:00:00+00:00

http://KEXP.ORG presents Durand Jones & The Indications performing “Listen To Your Heart” live at THING festival at Fort Worden in Port Townsend, Washington. Recorded August 27, 2022.

Host: Morgan Chosnyk
KEXP Engineers: Julian Martlew & Matt Ogaz
Mixing and Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Director & Editor: Scott Holpainen

https://durandjonesandtheindications.com
http://kexp.org

## Durand Jones & The Indications - More Than Ever (Live on KEXP)
 - [https://www.youtube.com/watch?v=v_j61yAIbUg](https://www.youtube.com/watch?v=v_j61yAIbUg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-03 00:00:00+00:00

http://KEXP.ORG presents Durand Jones & The Indications performing “More Than Ever” live at THING festival at Fort Worden in Port Townsend, Washington. Recorded August 27, 2022.

Host: Morgan Chosnyk
KEXP Engineers: Julian Martlew & Matt Ogaz
Mixing and Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Director & Editor: Scott Holpainen

https://durandjonesandtheindications.com
http://kexp.org

## Durand Jones & The Indications - You And Me (Live on KEXP)
 - [https://www.youtube.com/watch?v=k0FdDcD0O6U](https://www.youtube.com/watch?v=k0FdDcD0O6U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-03 00:00:00+00:00

http://KEXP.ORG presents Durand Jones & The Indications performing “You And Me” live at THING festival at Fort Worden in Port Townsend, Washington. Recorded August 27, 2022.

Host: Morgan Chosnyk
KEXP Engineers: Julian Martlew & Matt Ogaz
Mixing and Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro & Kendall Rock
Director & Editor: Scott Holpainen

https://durandjonesandtheindications.com
http://kexp.org


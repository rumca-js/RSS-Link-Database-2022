# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## I finally found a useful monorail.
 - [https://www.youtube.com/watch?v=Ei6LKHNFpeE](https://www.youtube.com/watch?v=Ei6LKHNFpeE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-10-03 00:00:00+00:00

The Doppelmayr Garaventa Monorack is a decades-old product. I've no idea how I missed it before. But for the third video in the Monorail Trilogy, this isn't an advert: I'm just happy to be proved wrong. ▪ More about the Monorack: https://www.doppelmayr.com/products/monorack/

Previously, Wuppertal in 2016: https://www.youtube.com/watch?v=F4KZLcvMQWg (I'm not proud of this video -- the Tim Traveller has done a much better video on the system here, and you should probably watch that instead: https://www.youtube.com/watch?v=9IFh6wFTJiQ )

And the Roadmachines monorail in 2020: https://www.youtube.com/watch?v=Irv3KJR6B80

(Thanks also to Grotto de Peo in Ronco sopra Ascona. If you're ever in the area, their food is delicious.)

Camera: Alicja Pahl
Producer: Sebastian Capeda at Viven https://viven.ch

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


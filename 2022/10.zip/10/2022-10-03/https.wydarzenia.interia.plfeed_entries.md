# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Włochy. Zajęto wille rosyjskiego oligarchy. To człowiek z otoczenia Putina
 - [https://wydarzenia.interia.pl/zagranica/news-wlochy-zajeto-wille-rosyjskiego-oligarchy-to-czlowiek-z-otoc,nId,6324712](https://wydarzenia.interia.pl/zagranica/news-wlochy-zajeto-wille-rosyjskiego-oligarchy-to-czlowiek-z-otoc,nId,6324712)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 20:43:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wlochy-zajeto-wille-rosyjskiego-oligarchy-to-czlowiek-z-otoc,nId,6324712"><img align="left" alt="Włochy. Zajęto wille rosyjskiego oligarchy. To człowiek z otoczenia Putina" src="https://i.iplsc.com/wlochy-zajeto-wille-rosyjskiego-oligarchy-to-czlowiek-z-otoc/000G5JRV0AGEO98B-C321.jpg" /></a>Włoska Gwardia Finansowa zamroziła wille rosyjskiego oligarchy Edwarda Kudajnatowa. Jedna z nich znajduje się w Portofino na Riwierze w Ligurii, a drug

## Rosja. Dmitrij Miedwiediew: Kryzys energetyczny może trwać długo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-dmitrij-miedwiediew-kryzys-energetyczny-moze-trwac-dlu,nId,6324704](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-dmitrij-miedwiediew-kryzys-energetyczny-moze-trwac-dlu,nId,6324704)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 20:21:42+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-dmitrij-miedwiediew-kryzys-energetyczny-moze-trwac-dlu,nId,6324704"><img align="left" alt="Rosja. Dmitrij Miedwiediew: Kryzys energetyczny może trwać długo" src="https://i.iplsc.com/rosja-dmitrij-miedwiediew-kryzys-energetyczny-moze-trwac-dlu/000G5JP60KVQ10UC-C321.jpg" /></a>Świat przeżywa globalny kryzys energetyczny, który może trwać długo - powiedział w poniedziałek wiceszef Rady Bezpieczeństwa Feder

## Nie żyje uczestnik londyńskiego maratonu. Upadł kilka kilometrów przed metą
 - [https://wydarzenia.interia.pl/zagranica/news-nie-zyje-uczestnik-londynskiego-maratonu-upadl-kilka-kilomet,nId,6324698](https://wydarzenia.interia.pl/zagranica/news-nie-zyje-uczestnik-londynskiego-maratonu-upadl-kilka-kilomet,nId,6324698)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 19:44:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nie-zyje-uczestnik-londynskiego-maratonu-upadl-kilka-kilomet,nId,6324698"><img align="left" alt="Nie żyje uczestnik londyńskiego maratonu. Upadł kilka kilometrów przed metą" src="https://i.iplsc.com/nie-zyje-uczestnik-londynskiego-maratonu-upadl-kilka-kilomet/000G5JN66ELQWC0Y-C321.jpg" /></a>Nie żyje 36-letni biegacz, który brał udział w niedzielnym Maratonie Londyńskim. Mężczyzna przewrócił się zaledwie 3 kilometry od mety i mimo natychmi

## Kuriozalne głosowanie w Dumie. Głosów więcej, niż osób na sali
 - [https://wydarzenia.interia.pl/zagranica/news-kuriozalne-glosowanie-w-dumie-glosow-wiecej-niz-osob-na-sali,nId,6324694](https://wydarzenia.interia.pl/zagranica/news-kuriozalne-glosowanie-w-dumie-glosow-wiecej-niz-osob-na-sali,nId,6324694)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 19:39:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kuriozalne-glosowanie-w-dumie-glosow-wiecej-niz-osob-na-sali,nId,6324694"><img align="left" alt="Kuriozalne głosowanie w Dumie. Głosów więcej, niż osób na sali" src="https://i.iplsc.com/kuriozalne-glosowanie-w-dumie-glosow-wiecej-niz-osob-na-sali/000G5JJV4XFBAIQ5-C321.jpg" /></a>Rosyjska Duma miała &quot;jednomyślnie&quot; opowiedzieć się za przyłączeniem do Rosji ukraińskich terytoriów. Jak się okazuje, za aneksją głosowało więcej osób, n

## Wzruszająca chwila. Uwolnieni obrońcy Azowstalu spotkali się z rodzinami
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wzruszajaca-chwila-uwolnieni-obroncy-azowstalu-spotkali-sie-,nId,6324669](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wzruszajaca-chwila-uwolnieni-obroncy-azowstalu-spotkali-sie-,nId,6324669)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 19:28:33+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wzruszajaca-chwila-uwolnieni-obroncy-azowstalu-spotkali-sie-,nId,6324669"><img align="left" alt="Wzruszająca chwila. Uwolnieni obrońcy Azowstalu spotkali się z rodzinami" src="https://i.iplsc.com/wzruszajaca-chwila-uwolnieni-obroncy-azowstalu-spotkali-sie/000G5JFXPT0IJ9OL-C321.jpg" /></a>Podczas wizyty w Turcji szef kancelarii prezydenta Ukrainy Andrij Jermak zorganizował spotkanie niedawno zwolnionych z rosy

## Rosja: Owsiannikowa na federalnej liście poszukiwanych. Krytykowała wojnę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-owsiannikowa-na-federalnej-liscie-poszukiwanych-krytyk,nId,6324661](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-owsiannikowa-na-federalnej-liscie-poszukiwanych-krytyk,nId,6324661)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 19:19:55+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-owsiannikowa-na-federalnej-liscie-poszukiwanych-krytyk,nId,6324661"><img align="left" alt="Rosja: Owsiannikowa na federalnej liście poszukiwanych. Krytykowała wojnę" src="https://i.iplsc.com/rosja-owsiannikowa-na-federalnej-liscie-poszukiwanych-krytyk/000F3CIAGLMAMBPK-C321.jpg" /></a>Marina Owsiannikowa została umieszczona na federalnej liście poszukiwanych - informuje &quot;The Moscow Times&quot;. Była

## Elon Musk z planem pokojowym dla Ukrainy. Melnyk nie wytrzymał
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-elon-musk-z-planem-pokojowym-dla-ukrainy-melnyk-nie-wytrzyma,nId,6324646](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-elon-musk-z-planem-pokojowym-dla-ukrainy-melnyk-nie-wytrzyma,nId,6324646)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 19:04:10+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-elon-musk-z-planem-pokojowym-dla-ukrainy-melnyk-nie-wytrzyma,nId,6324646"><img align="left" alt="Elon Musk z planem pokojowym dla Ukrainy. Melnyk nie wytrzymał" src="https://i.iplsc.com/elon-musk-z-planem-pokojowym-dla-ukrainy-melnyk-nie-wytrzyma/000G5JFRVY867HTO-C321.jpg" /></a>Elon Musk zaproponował warunki pokoju pomiędzy Ukrainą a Rosją. Te miałyby opierać się o przeprowadzone pod nadzorem ONZ referendum.

## Pogoda może zaskoczyć. Prognozy mówią o śniegu
 - [https://wydarzenia.interia.pl/kraj/news-pogoda-moze-zaskoczyc-prognozy-mowia-o-sniegu,nId,6324628](https://wydarzenia.interia.pl/kraj/news-pogoda-moze-zaskoczyc-prognozy-mowia-o-sniegu,nId,6324628)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 18:47:57+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogoda-moze-zaskoczyc-prognozy-mowia-o-sniegu,nId,6324628"><img align="left" alt="Pogoda może zaskoczyć. Prognozy mówią o śniegu" src="https://i.iplsc.com/pogoda-moze-zaskoczyc-prognozy-mowia-o-sniegu/000G5JDMGI8LCVDA-C321.jpg" /></a>- W nocy z poniedziałku na wtorek wystąpią w kraju przelotne opady deszczu. Wysoko w górach będzie padał śnieg - poinformował dyżurny synoptyk Instytutu Meteorologii i Gospodarki Wodnej Mateusz Barczyk. Opady śnieg

## Otworzył ogień podczas próby zatrzymania. Zabił 22-letnią policjantkę
 - [https://wydarzenia.interia.pl/zagranica/news-otworzyl-ogien-podczas-proby-zatrzymania-zabil-22-letnia-pol,nId,6324619](https://wydarzenia.interia.pl/zagranica/news-otworzyl-ogien-podczas-proby-zatrzymania-zabil-22-letnia-pol,nId,6324619)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 18:19:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-otworzyl-ogien-podczas-proby-zatrzymania-zabil-22-letnia-pol,nId,6324619"><img align="left" alt="Otworzył ogień podczas próby zatrzymania. Zabił 22-letnią policjantkę" src="https://i.iplsc.com/otworzyl-ogien-podczas-proby-zatrzymania-zabil-22-letnia-pol/000G5J52PKR5FQET-C321.jpg" /></a>W Czerniowcach w południowo-zachodniej części Ukrainy mężczyzna podczas próby zatrzymania w okolicach szkoły oddał strzały z kałasznikowa, zabijając 22-letn

## Amsterdam rozważa wprowadzenie zakazu turystyki konopnej. "Miasto jest na to za piękne"
 - [https://wydarzenia.interia.pl/zagranica/news-amsterdam-rozwaza-wprowadzenie-zakazu-turystyki-konopnej-mia,nId,6324609](https://wydarzenia.interia.pl/zagranica/news-amsterdam-rozwaza-wprowadzenie-zakazu-turystyki-konopnej-mia,nId,6324609)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 18:14:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-amsterdam-rozwaza-wprowadzenie-zakazu-turystyki-konopnej-mia,nId,6324609"><img align="left" alt="Amsterdam rozważa wprowadzenie zakazu turystyki konopnej. &quot;Miasto jest na to za piękne&quot;" src="https://i.iplsc.com/amsterdam-rozwaza-wprowadzenie-zakazu-turystyki-konopnej-mia/000G5J7626P27UMJ-C321.jpg" /></a>&quot;Rada miejska Amsterdamu zastanawia się, czy zakazać w mieście turystyki konopnej&quot; - donoszą zagraniczne media.  &quot

## USA: W ich dom uderzył samolot. Trzy osoby zginęły na miejscu
 - [https://wydarzenia.interia.pl/zagranica/news-usa-w-ich-dom-uderzyl-samolot-trzy-osoby-zginely-na-miejscu,nId,6324596](https://wydarzenia.interia.pl/zagranica/news-usa-w-ich-dom-uderzyl-samolot-trzy-osoby-zginely-na-miejscu,nId,6324596)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 17:41:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-w-ich-dom-uderzyl-samolot-trzy-osoby-zginely-na-miejscu,nId,6324596"><img align="left" alt="USA: W ich dom uderzył samolot. Trzy osoby zginęły na miejscu" src="https://i.iplsc.com/usa-w-ich-dom-uderzyl-samolot-trzy-osoby-zginely-na-miejscu/000G5J2O69R35I55-C321.jpg" /></a>Trzy osoby zginęły po tym, jak niewielki samolot rozbił się o dom jednorodzinny w Minnesocie w USA. Lokalna policja poinformowała, że Cessna 172 uderzyła w budynek na

## Lekarz o "aferze drobiowej": Skutki odczujemy po latach
 - [https://wydarzenia.interia.pl/autor/magdalena-raducha/news-drob-karmiony-olejami-do-produkcji-smarow-skutki-odczujemy-p,nId,6324300](https://wydarzenia.interia.pl/autor/magdalena-raducha/news-drob-karmiony-olejami-do-produkcji-smarow-skutki-odczujemy-p,nId,6324300)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 14:20:26+00:00

<p><a href="https://wydarzenia.interia.pl/autor/magdalena-raducha/news-drob-karmiony-olejami-do-produkcji-smarow-skutki-odczujemy-p,nId,6324300"><img align="left" alt="Lekarz o &quot;aferze drobiowej&quot;: Skutki odczujemy po latach" src="https://i.iplsc.com/lekarz-o-aferze-drobiowej-skutki-odczujemy-po-latach/00060BBWYKY6W5XC-C321.jpg" /></a>Do polskich sklepów trafiało mięso zwierząt, które były karmione paszą z dodatkiem komponentów do produkcji m.in. paliwa. - Ten proceder mógł narazić zdro

## Drób karmiony tłuszczem do produkcji smarów trafiał na rynek. Trwa śledztwo
 - [https://wydarzenia.interia.pl/kraj/news-drob-karmiony-tluszczem-do-produkcji-smarow-trafial-na-rynek,nId,6323889](https://wydarzenia.interia.pl/kraj/news-drob-karmiony-tluszczem-do-produkcji-smarow-trafial-na-rynek,nId,6323889)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 08:47:47+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-drob-karmiony-tluszczem-do-produkcji-smarow-trafial-na-rynek,nId,6323889"><img align="left" alt="Drób karmiony tłuszczem do produkcji smarów trafiał na rynek. Trwa śledztwo" src="https://i.iplsc.com/drob-karmiony-tluszczem-do-produkcji-smarow-trafial-na-rynek/000G5ENGC4LMDYQS-C321.jpg" /></a>Do polskich sklepów trafiało mięso zwierząt, które były karmione paszą z dodatkiem komponentów do produkcji paliwa. Czołowi potentaci w kraju kupowali ją o

## Oni zapłacą mniej za prąd. Wskazano trzy konkretne grupy
 - [https://wydarzenia.interia.pl/kraj/news-oni-zaplaca-mniej-za-prad-wskazano-trzy-konkretne-grupy,nId,6318435](https://wydarzenia.interia.pl/kraj/news-oni-zaplaca-mniej-za-prad-wskazano-trzy-konkretne-grupy,nId,6318435)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 08:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-oni-zaplaca-mniej-za-prad-wskazano-trzy-konkretne-grupy,nId,6318435"><img align="left" alt="Oni zapłacą mniej za prąd. Wskazano trzy konkretne grupy" src="https://i.iplsc.com/oni-zaplaca-mniej-za-prad-wskazano-trzy-konkretne-grupy/000G507MQN4JD979-C321.jpg" /></a>Rząd zamraża ceny energii i wprowadza wyższy limit zużycia prądu. Wiadomo już, że gospodarstwa domowe, które zużyją do 2000 kWh prądu w 2022 roku, 
tyle samo zapłacą za energię w roku 

## Zauważyła "ogromnego węża" na balkonie. Przerażona wezwała służby
 - [https://wydarzenia.interia.pl/mazowieckie/news-zauwazyla-ogromnego-weza-na-balkonie-przerazona-wezwala-sluz,nId,6323960](https://wydarzenia.interia.pl/mazowieckie/news-zauwazyla-ogromnego-weza-na-balkonie-przerazona-wezwala-sluz,nId,6323960)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 08:28:32+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-zauwazyla-ogromnego-weza-na-balkonie-przerazona-wezwala-sluz,nId,6323960"><img align="left" alt="Zauważyła &quot;ogromnego węża&quot; na balkonie. Przerażona wezwała służby" src="https://i.iplsc.com/zauwazyla-ogromnego-weza-na-balkonie-przerazona-wezwala-sluz/000G5FI0JIYDVB03-C321.jpg" /></a>Przerażona mieszkanka jednego z bloków przy ul. gen. Augusta Fieldorfa-Nila w Żyrardowie zgłosiła służbom, że na balkonie wokół barierki opleciony j

## Zginął ukraiński pułkownik. Dowodził "Duchami Kijowa"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zginal-ukrainski-pulkownik-dowodzil-duchami-kijowa,nId,6323955](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zginal-ukrainski-pulkownik-dowodzil-duchami-kijowa,nId,6323955)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 08:21:01+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zginal-ukrainski-pulkownik-dowodzil-duchami-kijowa,nId,6323955"><img align="left" alt="Zginął ukraiński pułkownik. Dowodził &quot;Duchami Kijowa&quot;" src="https://i.iplsc.com/zginal-ukrainski-pulkownik-dowodzil-duchami-kijowa/000G5FC5AUDET0JR-C321.jpg" /></a>W zestrzelonym przez Rosjan nad Morzem Czarnym myśliwcu zginął ukraiński pułkownik Mychajło Matiuszenka, pseudonim &quot;Dziadek&quot;. Dowodził on &qu

## Marek Suski: Jacek Sasin i premier Morawiecki wznosili za siebie nawzajem toasty
 - [https://wydarzenia.interia.pl/kraj/news-marek-suski-jacek-sasin-i-premier-morawiecki-wznosili-za-sie,nId,6323878](https://wydarzenia.interia.pl/kraj/news-marek-suski-jacek-sasin-i-premier-morawiecki-wznosili-za-sie,nId,6323878)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 08:12:23+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-marek-suski-jacek-sasin-i-premier-morawiecki-wznosili-za-sie,nId,6323878"><img align="left" alt="Marek Suski: Jacek Sasin i premier Morawiecki wznosili za siebie nawzajem toasty" src="https://i.iplsc.com/marek-suski-jacek-sasin-i-premier-morawiecki-wznosili-za-sie/000G5F8E1G9WTGQC-C321.jpg" /></a>- Ci, którzy myśleli, że na posiedzeniu klubu PiS odbędzie się jakaś potyczka, rozczarowaliby się, gdyby widzieli w jakiej komitywie siedzieli przy st

## Rosyjski deputowany grzmi: Gdzie się podziało 1,5 mln zestawów dla żołnierzy?
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjski-deputowany-grzmi-gdzie-sie-podzialo-1-5-mln-zestawo,nId,6323942](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjski-deputowany-grzmi-gdzie-sie-podzialo-1-5-mln-zestawo,nId,6323942)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 08:01:32+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjski-deputowany-grzmi-gdzie-sie-podzialo-1-5-mln-zestawo,nId,6323942"><img align="left" alt="Rosyjski deputowany grzmi: Gdzie się podziało 1,5 mln zestawów dla żołnierzy?" src="https://i.iplsc.com/rosyjski-deputowany-grzmi-gdzie-sie-podzialo-1-5-mln-zestawo/000G5FDPOEVBWLCU-C321.jpg" /></a>Andriej Gurulow - emerytowany generał, deputowany rosyjskiej Dumy Państwowej, znów o sobie przypomniał. W obszernym w

## Samolot z taśmą na skrzydle. Internetowy viral wymusił reakcje ekspertów
 - [https://wydarzenia.interia.pl/zagranica/news-samolot-z-tasma-na-skrzydle-internetowy-viral-wymusil-reakcj,nId,6323905](https://wydarzenia.interia.pl/zagranica/news-samolot-z-tasma-na-skrzydle-internetowy-viral-wymusil-reakcj,nId,6323905)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 07:32:39+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-samolot-z-tasma-na-skrzydle-internetowy-viral-wymusil-reakcj,nId,6323905"><img align="left" alt="Samolot z taśmą na skrzydle. Internetowy viral wymusił reakcje ekspertów" src="https://i.iplsc.com/samolot-z-tasma-na-skrzydle-internetowy-viral-wymusil-reakcj/000G5F4AMYVK5434-C321.jpg" /></a>Taśmy na skrzydle australijskiego samolotu stały się ogólnoświatowym viralem. Autor fotografii zarzucił liniom lotniczym, że przedkładają zyski nad bezpi

## USA: Przeżył huragan, dryfując na kanapie. "To było przerażające"
 - [https://wydarzenia.interia.pl/zagranica/news-usa-przezyl-huragan-dryfujac-na-kanapie-to-bylo-przerazajace,nId,6323911](https://wydarzenia.interia.pl/zagranica/news-usa-przezyl-huragan-dryfujac-na-kanapie-to-bylo-przerazajace,nId,6323911)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 07:20:02+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-przezyl-huragan-dryfujac-na-kanapie-to-bylo-przerazajace,nId,6323911"><img align="left" alt="USA: Przeżył huragan, dryfując na kanapie. &quot;To było przerażające&quot;" src="https://i.iplsc.com/usa-przezyl-huragan-dryfujac-na-kanapie-to-bylo-przerazajace/000G5F6JHJB0003F-C321.jpg" /></a>Mężczyzna z Florydy przetrwał huragan Ian, dryfując na kanapie. - Woda była bardzo zimna i drżałem. To było przerażające - relacjonował w rozmowie ze 

## Jego zdjęcie obiegło świat. Teraz ujawnia, jak wyglądała rosyjska niewola
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-jego-zdjecie-obieglo-swiat-teraz-ujawnia-jak-wygladala-rosyj,nId,6323908](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-jego-zdjecie-obieglo-swiat-teraz-ujawnia-jak-wygladala-rosyj,nId,6323908)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 07:15:04+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-jego-zdjecie-obieglo-swiat-teraz-ujawnia-jak-wygladala-rosyj,nId,6323908"><img align="left" alt="Jego zdjęcie obiegło świat. Teraz ujawnia, jak wyglądała rosyjska niewola" src="https://i.iplsc.com/jego-zdjecie-obieglo-swiat-teraz-ujawnia-jak-wygladala-rosyj/000G4R0HBVEFYJUM-C321.jpg" /></a>- Po miesiącu głodowania zamykasz oczy i zapominasz o rodzinie, kraju, o wszystkim. Myślisz tylko o jedzeniu - mówi Mycha

## ISW: Kremlowscy propagandyści niezadowoleni. Krytykują za Łyman i mobilizację
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-kremlowscy-propagandysci-niezadowoleni-krytykuja-za-lyma,nId,6323862](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-kremlowscy-propagandysci-niezadowoleni-krytykuja-za-lyma,nId,6323862)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 07:00:32+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-kremlowscy-propagandysci-niezadowoleni-krytykuja-za-lyma,nId,6323862"><img align="left" alt="ISW: Kremlowscy propagandyści niezadowoleni. Krytykują za Łyman i mobilizację " src="https://i.iplsc.com/isw-kremlowscy-propagandysci-niezadowoleni-krytykuja-za-lyma/000G5E75BILHMRV8-C321.jpg" /></a>Rosyjscy propagandyści krytykują działania rosyjskiego dowództwa wojskowego - podaje amerykański Instytut Studiów na

## Nowe zasady urlopów. Duże zmiany wkrótce wejdą w życie. Co się zmieni?
 - [https://wydarzenia.interia.pl/kraj/news-nowe-zasady-urlopow-duze-zmiany-wkrotce-wejda-w-zycie-co-sie,nId,6318570](https://wydarzenia.interia.pl/kraj/news-nowe-zasady-urlopow-duze-zmiany-wkrotce-wejda-w-zycie-co-sie,nId,6318570)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 06:55:10+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowe-zasady-urlopow-duze-zmiany-wkrotce-wejda-w-zycie-co-sie,nId,6318570"><img align="left" alt="Nowe zasady urlopów. Duże zmiany wkrótce wejdą w życie. Co się zmieni?" src="https://i.iplsc.com/nowe-zasady-urlopow-duze-zmiany-wkrotce-wejda-w-zycie-co-sie/000G50UVAS5DG4A1-C321.jpg" /></a>Dyrektywa &quot;work-life balance&quot; ma ułatwić rodzicom godzenie pracy zawodowej z obowiązkami rodzinnymi. Wiceminister rodziny, Barbara Socha podkreśliła, 

## Polacy nie chcą powrotu obowiązkowej służby wojskowej. Najnowszy sondaż
 - [https://wydarzenia.interia.pl/kraj/news-polacy-nie-chca-powrotu-obowiazkowej-sluzby-wojskowej-najnow,nId,6323854](https://wydarzenia.interia.pl/kraj/news-polacy-nie-chca-powrotu-obowiazkowej-sluzby-wojskowej-najnow,nId,6323854)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 06:40:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polacy-nie-chca-powrotu-obowiazkowej-sluzby-wojskowej-najnow,nId,6323854"><img align="left" alt="Polacy nie chcą powrotu obowiązkowej służby wojskowej. Najnowszy sondaż" src="https://i.iplsc.com/polacy-nie-chca-powrotu-obowiazkowej-sluzby-wojskowej-najnow/0006L7EGCS0M4O3G-C321.jpg" /></a>Co trzecia osoba w Polsce jest za przywróceniem poboru do armii - wynika z najnowszego sondażu przeprowadzonego przez IBRiS na zlecenie &quot;Rzeczpospolitej&q

## Amerykański senator ostrzega: Putin może uderzyć w Polskę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanski-senator-ostrzega-putin-moze-uderzyc-w-polske,nId,6323853](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanski-senator-ostrzega-putin-moze-uderzyc-w-polske,nId,6323853)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 06:00:15+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-amerykanski-senator-ostrzega-putin-moze-uderzyc-w-polske,nId,6323853"><img align="left" alt="Amerykański senator ostrzega: Putin może uderzyć w Polskę" src="https://i.iplsc.com/amerykanski-senator-ostrzega-putin-moze-uderzyc-w-polske/000G5E72Y16UP25J-C321.jpg" /></a>- Putin może zaatakować dystrybucyjne punkty na terytorium NATO, np. w Polsce. Uważam to za całkiem prawdopodobne - powiedział w niedzielę republ

## Haiti: Co najmniej siedem osób nie żyje w wyniku zachorowania na cholerę
 - [https://wydarzenia.interia.pl/zagranica/news-haiti-co-najmniej-siedem-osob-nie-zyje-w-wyniku-zachorowania,nId,6323845](https://wydarzenia.interia.pl/zagranica/news-haiti-co-najmniej-siedem-osob-nie-zyje-w-wyniku-zachorowania,nId,6323845)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 05:30:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-haiti-co-najmniej-siedem-osob-nie-zyje-w-wyniku-zachorowania,nId,6323845"><img align="left" alt="Haiti: Co najmniej siedem osób nie żyje w wyniku zachorowania na cholerę" src="https://i.iplsc.com/haiti-co-najmniej-siedem-osob-nie-zyje-w-wyniku-zachorowania/000G5E37CAGEPCKT-C321.jpg" /></a>W ostatnich tygodniach na Haiti zaobserwowano nagły nawrót cholery - groźnej choroby zakaźnej, która w 2010 roku zabiła w tym kraju około 10 tysięcy ludz

## Duża zmiana pogody. Synoptycy nie pozostawiają wątpliwości. Zacznie się już jutro
 - [https://wydarzenia.interia.pl/kraj/news-duza-zmiana-pogody-synoptycy-nie-pozostawiaja-watpliwosci-za,nId,6323859](https://wydarzenia.interia.pl/kraj/news-duza-zmiana-pogody-synoptycy-nie-pozostawiaja-watpliwosci-za,nId,6323859)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 05:23:06+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-duza-zmiana-pogody-synoptycy-nie-pozostawiaja-watpliwosci-za,nId,6323859"><img align="left" alt="Duża zmiana pogody. Synoptycy nie pozostawiają wątpliwości. Zacznie się już jutro " src="https://i.iplsc.com/duza-zmiana-pogody-synoptycy-nie-pozostawiaja-watpliwosci-za/000G5E47BWJ2O99J-C321.jpg" /></a>​Rozpoczynający się tydzień przyniesie więcej słońca i zmianę pogody. W niektórych miejscach temperatura może sięgnąć nawet 20 st. C. Wygląda na to,

## Prezydent RPA pierwszym zagranicznym przywódcą przyjętym przez Karola III
 - [https://wydarzenia.interia.pl/zagranica/news-prezydent-rpa-pierwszym-zagranicznym-przywodca-przyjetym-prz,nId,6323837](https://wydarzenia.interia.pl/zagranica/news-prezydent-rpa-pierwszym-zagranicznym-przywodca-przyjetym-prz,nId,6323837)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 04:45:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prezydent-rpa-pierwszym-zagranicznym-przywodca-przyjetym-prz,nId,6323837"><img align="left" alt="Prezydent RPA pierwszym zagranicznym przywódcą przyjętym przez Karola III" src="https://i.iplsc.com/prezydent-rpa-pierwszym-zagranicznym-przywodca-przyjetym-prz/000G1NE3PA9GJAUF-C321.jpg" /></a>W nocy z niedzieli na poniedziałek Pałac Buckingham poinformował, kogo nowy król Wielkiej Brytanii Karola III przyjmie jako pierwszego zagranicznego prz

## Bułgaria: Partia GERB wygrała wybory parlamentarne
 - [https://wydarzenia.interia.pl/zagranica/news-bulgaria-partia-gerb-wygrala-wybory-parlamentarne,nId,6323835](https://wydarzenia.interia.pl/zagranica/news-bulgaria-partia-gerb-wygrala-wybory-parlamentarne,nId,6323835)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 04:35:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bulgaria-partia-gerb-wygrala-wybory-parlamentarne,nId,6323835"><img align="left" alt="Bułgaria: Partia GERB wygrała wybory parlamentarne " src="https://i.iplsc.com/bulgaria-partia-gerb-wygrala-wybory-parlamentarne/000741LDCQO5Q93P-C321.jpg" /></a>Bułgarska Centralna Komisja Wyborcza potwierdziła na podstawie 68,99 proc. obliczonych głosów podaną wcześniej przez agencje socjologiczne informację o zwycięstwie w niedzielnych wyborach parlamen

## Bolsonaro przegrał pierwszą turę wyborów prezydenckich w Brazylii
 - [https://wydarzenia.interia.pl/zagranica/news-bolsonaro-przegral-pierwsza-ture-wyborow-prezydenckich-w-bra,nId,6323832](https://wydarzenia.interia.pl/zagranica/news-bolsonaro-przegral-pierwsza-ture-wyborow-prezydenckich-w-bra,nId,6323832)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 04:05:57+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bolsonaro-przegral-pierwsza-ture-wyborow-prezydenckich-w-bra,nId,6323832"><img align="left" alt="Bolsonaro przegrał pierwszą turę wyborów prezydenckich w Brazylii " src="https://i.iplsc.com/bolsonaro-przegral-pierwsza-ture-wyborow-prezydenckich-w-bra/000DCZPTXVMGGXCV-C321.jpg" /></a>W pierwszej turze wyborów prezydenckich w Brazylii zwyciężył były lewicowy prezydent tego kraju w latach 2003-2011, 76-letni Luiz Inacio Lula da Silva, zdobywa

## Wojna w Ukrainie. 222. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030604](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030604)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 03:35:40+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030604"><img align="left" alt="Wojna w Ukrainie. 222. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo/000G5DXNJML2KOOE-C321.jpg" /></a>Zapraszamy do śledzenia relacji na żywo. Przekazujemy najnowsze informacje z frontu.</p><br clear="all" />

## Wojna w Ukrainie. 222. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030650](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030650)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 03:35:40+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030650"><img align="left" alt="Wojna w Ukrainie. 222. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo/000G5DXNJML2KOOE-C321.jpg" /></a>Zapraszamy do śledzenia relacji na żywo. Przekazujemy najnowsze informacje z frontu.</p><br clear="all" />

## Wojna w Ukrainie. 222. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030801](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030801)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 03:35:40+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030801"><img align="left" alt="Wojna w Ukrainie. 222. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo/000G5DXNJML2KOOE-C321.jpg" /></a>Zapraszamy do śledzenia relacji na żywo. Przekazujemy najnowsze informacje z frontu.</p><br clear="all" />

## Wojna w Ukrainie. 222. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030853](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030853)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-03 03:35:40+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo,nzId,3115,akt,030853"><img align="left" alt="Wojna w Ukrainie. 222. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-222-dzien-inwazji-rosji-relacja-na-zywo/000G5DXNJML2KOOE-C321.jpg" /></a>Zapraszamy do śledzenia relacji na żywo. Przekazujemy najnowsze informacje z frontu.</p><br clear="all" />


# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## 'The Five' on global reaction to Russia's nuclear threat
 - [https://www.foxnews.com/transcript/five-global-reaction-russias-nuclear-threat](https://www.foxnews.com/transcript/five-global-reaction-russias-nuclear-threat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 21:00:28+00:00

This is a rush transcript of "The Five" on October 3, 2022

## 2 key Jets offensive linemen dead, team says
 - [https://www.foxnews.com/sports/2-key-jets-offensive-linemen-dead-team-says](https://www.foxnews.com/sports/2-key-jets-offensive-linemen-dead-team-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 20:55:58+00:00

The New York Jets announced the passing of former offensive linemen Marvin Powell and Jim Sweeney on Sunday. They were 67 and 60 years old, respectively.

## Kellyanne Conway reveals where Democrats are wrong in their midterm policy priorities
 - [https://www.foxnews.com/media/kellyanne-conway-reveals-democrats-wrong-midterm-policy-priorities](https://www.foxnews.com/media/kellyanne-conway-reveals-democrats-wrong-midterm-policy-priorities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 20:53:53+00:00

Former counselor to President Trump Kellyanne Conway weighs in on what issues Americans are focused on in the upcoming midterm elections on “The Story.”

## US government 'struggled to track' Afghan evacuees who departed military bases after withdrawal: IG
 - [https://www.foxnews.com/politics/us-government-struggled-track-afghan-evacuees-departed-military-bases-after-withdrawal](https://www.foxnews.com/politics/us-government-struggled-track-afghan-evacuees-departed-military-bases-after-withdrawal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 20:51:17+00:00

DHS watchdog found the U.S. government “struggled to track” Afghan evacuees who left U.S. military bases designated as “safe havens” on their own after the Afghanistan withdrawal.

## California's new bill that punishes doctors for COVID 'misinformation' is 'chilling' and 'dangerous:' Turley
 - [https://www.foxnews.com/media/californias-new-bill-punishes-doctors-covid-misinformation-chilling-dangerous-turley](https://www.foxnews.com/media/californias-new-bill-punishes-doctors-covid-misinformation-chilling-dangerous-turley)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 20:50:12+00:00

test

## Justin Bieber caught with his pants down at swanky Los Angeles golf club
 - [https://www.foxnews.com/sports/justin-bieber-caught-pants-down-swanky-los-angeles-golf-club](https://www.foxnews.com/sports/justin-bieber-caught-pants-down-swanky-los-angeles-golf-club)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 20:49:47+00:00

Justin Bieber was spotted at a swanky Los Angeles country club over the weekend, participating in a golf outing. Photos snapped of the singer showed him urinating behind a tree.

## Politico report claims DeSantis is asking for emergency aid from 'the president's wallet'
 - [https://www.foxnews.com/media/politico-report-claims-desantis-asking-emergency-aid-presidents-wallet](https://www.foxnews.com/media/politico-report-claims-desantis-asking-emergency-aid-presidents-wallet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 20:36:34+00:00

Politico was blasted on Twitter Monday for claiming Gov. Ron DeSantis, R-Fla., is asking for Hurricane Ian relief money from “the president’s wallet.”

## Florida man who raped his wife, cross-examined her at trial, gets life in prison
 - [https://www.foxnews.com/us/florida-man-raped-wife-cross-examined-trial-gets-life-prison](https://www.foxnews.com/us/florida-man-raped-wife-cross-examined-trial-gets-life-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 20:36:08+00:00

The deranged Florida husband who kidnaped, raped and tried to kill the mother of his five children in a failed murder-suicide plot will spend the rest of his life in prison.

## Education Secretary Cardona does not mention academics in tweet about wanting to 'raise the bar' in education
 - [https://www.foxnews.com/media/education-secretary-cardona-does-not-mention-academics-tweet-wanting-raise-the-bar-education](https://www.foxnews.com/media/education-secretary-cardona-does-not-mention-academics-tweet-wanting-raise-the-bar-education)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 20:34:47+00:00

Parent groups respond to Education Secretary Miguel Cardona's omission in tweeting about wanting to 'raise the bar' in education but not mentioning academics.

## Steelers' Minkah Fitzpatrick takes aim at Jets, says Pittsburgh is 'more talented' despite 'frustrating' loss
 - [https://www.foxnews.com/sports/steelers-minkah-fitzpatrick-takes-aim-jets-says-pittsburgh-talented-despite-frustrating-loss](https://www.foxnews.com/sports/steelers-minkah-fitzpatrick-takes-aim-jets-says-pittsburgh-talented-despite-frustrating-loss)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 20:31:27+00:00

Pittsburgh Steelers safety Minkah Fitzpatrick ripped into the New York Jets following Sunday's loss, saying it's "frustrating" losing to a team "that you know that you’re better than."

## 'Your World' on Florida search and rescue efforts
 - [https://www.foxnews.com/transcript/your-world-florida-search-rescue-efforts](https://www.foxnews.com/transcript/your-world-florida-search-rescue-efforts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 20:00:15+00:00

Guests: Richard Newton, Kelsey Bolar, Kristal Knight, James Eifert, Kenny Polcari, Art Del Cueto, Mike Yost

## NY Times political analyst says Democrats have real chance to keep the House: 'Anything can happen'
 - [https://www.foxnews.com/media/ny-times-political-analyst-democrats-have-real-chance-keep-house-anything-can-happen](https://www.foxnews.com/media/ny-times-political-analyst-democrats-have-real-chance-keep-house-anything-can-happen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 19:56:03+00:00

The New York Times' Nate Cohn wrote Monday there is a "real possibility" that Democrats can buck history and hold onto a majority in the House in November.

## Hurricane Ian: How to spot a flood-damaged used car for sale
 - [https://www.foxnews.com/auto/hurricane-ian-spot-flood-damaged-used-car-sale](https://www.foxnews.com/auto/hurricane-ian-spot-flood-damaged-used-car-sale)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 19:51:42+00:00

Used car buyers have to be on the lookout for undisclosed water damage from flooding that could cause major issues for them weeks or months after purchase.

## Debbie Collier murder: Who is trucker mentioned in 911 call?
 - [https://www.foxnews.com/us/debbie-collier-murder-who-is-trucker-mentioned-911-call](https://www.foxnews.com/us/debbie-collier-murder-who-is-trucker-mentioned-911-call)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 19:43:42+00:00

Slain Georgia office manager Debbie Collier was involved in a "minor" accident on April 30 involving a driver with a suspended license, police records show.

## Ukrainian troops make gains with burst through Russian forces
 - [https://www.foxnews.com/world/ukrainian-forces-gains-russian-forces](https://www.foxnews.com/world/ukrainian-forces-gains-russian-forces)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 19:37:04+00:00

Ukrainian troops broke through Russian defensive lines Monday and continued to advance following a string of victories as the Russian military continues to face setbacks on the battlefield.

## Journalist sues Oregon city over 2020 arrest that kept her from documenting a police sweep of homeless camp
 - [https://www.foxnews.com/us/journalist-sues-oregon-city-2020-arrest-kept-her-documenting-police-sweep-homeless-camp](https://www.foxnews.com/us/journalist-sues-oregon-city-2020-arrest-kept-her-documenting-police-sweep-homeless-camp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 19:28:47+00:00

Oregon journalist April Ehrlich is suing Medford and Jackson County over a 2020 arrest. She was arrested while covering a homeless camp sweep by the police.

## America's best Main Streets will compete for top honors: Is yours on this list?
 - [https://www.foxnews.com/lifestyle/america-best-main-streets-compete-top-honors-yours-list](https://www.foxnews.com/lifestyle/america-best-main-streets-compete-top-honors-yours-list)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 19:28:38+00:00

The semifinalists for the 2023 Great American Main Street Award are here. The award is given to the Main Street in America that best models district revitalization.

## After #FreeBritney, California Gov. Gavin Newsom limits use of conservatorships
 - [https://www.foxnews.com/us/after-freebritney-california-gov-gavin-newsom-limits-use-conservatorships](https://www.foxnews.com/us/after-freebritney-california-gov-gavin-newsom-limits-use-conservatorships)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 19:27:53+00:00

California Gov. Gavin Newsom signed a new law that limits conservatorships, a move that came after Britney Spears’ conservatorship drew national attention.

## Sweden sends diving vessel to investigate Nord Stream pipelines after leak
 - [https://www.foxnews.com/world/sweden-sends-diving-vessel-investigate-nord-stream-pipelines-leak](https://www.foxnews.com/world/sweden-sends-diving-vessel-investigate-nord-stream-pipelines-leak)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 19:26:16+00:00

Sweden on Monday sent a submarine vessel to the Baltic Sea to investigate leaks at the Nord Stream pipelines caused by ruptures last week.

## North Carolina sheriff's office stops pulling drivers over for non-moving traffic violations
 - [https://www.foxnews.com/us/north-carolina-sheriffs-office-stops-pulling-drivers-non-moving-traffic-violations](https://www.foxnews.com/us/north-carolina-sheriffs-office-stops-pulling-drivers-non-moving-traffic-violations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 19:18:26+00:00

Charlotte's Mecklenburg County Sheriff's Office announced a new policy that they will not longer enforce non-moving traffic violations, which is aimed at racial equity.

## Florence Pugh goes sheer again following criticsm over Valentino dress
 - [https://www.foxnews.com/entertainment/florence-pugh-sheer-again-following-criticsm-over-valentino-dress](https://www.foxnews.com/entertainment/florence-pugh-sheer-again-following-criticsm-over-valentino-dress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 19:13:34+00:00

Florence Pugh wore a sheer Valentino dress to a Paris Fashion Week dinner. The actress previously recieved criticism after showing her nipples in a hot pink sheer dress.

## 'The View' hosts, crowd groan when Sarah Huckabee Sanders floated as Trump running mate in 2024
 - [https://www.foxnews.com/media/the-view-hosts-crowd-groan-when-sarah-huckabee-sanders-floated-as-trump-running-mate-2024](https://www.foxnews.com/media/the-view-hosts-crowd-groan-when-sarah-huckabee-sanders-floated-as-trump-running-mate-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 18:27:05+00:00

"The View" hosts groaned as NYT's Maggie Haberman said people close to Donald Trump have mentioned Sarah Huckabee Sanders and Sen. Tim Scott as potential running mates.

## New California law will allow ex-offenders to seal criminal records
 - [https://www.foxnews.com/us/new-california-law-will-allow-ex-offenders-seal-criminal-records](https://www.foxnews.com/us/new-california-law-will-allow-ex-offenders-seal-criminal-records)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 08:01:25+00:00

A new California law signed by Democratic Gov. Gavin Newsom will automatically seal convictions and arrest records for many ex-offenders. Supports say it will help them get jobs.

## Anti-Biden chant 'Let's Go Brandon!' has been around for 1 year
 - [https://www.foxnews.com/politics/anti-biden-chant-lets-go-brandon-been-around-1-year](https://www.foxnews.com/politics/anti-biden-chant-lets-go-brandon-been-around-1-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 07:32:27+00:00

The "Let's Go Brandon!" chant, which stemmed from a NASCAR interview last year, turned one year old on Oct. 2. The phrase is a tongue-in-cheek criticism of President Biden.

## Texas human smuggling by plane becoming more common as migrants 'try to avoid detection': border officials
 - [https://www.foxnews.com/us/texas-human-smuggling-by-plane-becoming-more-common-border-officials](https://www.foxnews.com/us/texas-human-smuggling-by-plane-becoming-more-common-border-officials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 06:08:26+00:00

Human smuggling by plane is occurring more frequently at the U.S. southern border, according to Texas DPS, which stopped three human smuggling attempts via plan over 30 days.

## Biden, Democrats seek to flood millions into school model with questionable ties to critical race theory
 - [https://www.foxnews.com/media/biden-democrats-seek-deliver-millions-school-model-questionable-ties-critical-race-theory](https://www.foxnews.com/media/biden-democrats-seek-deliver-millions-school-model-questionable-ties-critical-race-theory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 06:00:59+00:00

President Biden and the Democrats are promoting a 'community schools' system which appears to be laced with critical race theory concepts.

## Native American tribes dependent on fossil fuel resources rip Biden admin for double standard
 - [https://www.foxnews.com/politics/native-american-tribes-dependent-fossil-fuel-resources-rip-biden-admin-double-standard](https://www.foxnews.com/politics/native-american-tribes-dependent-fossil-fuel-resources-rip-biden-admin-double-standard)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 06:00:53+00:00

Native American leaders said tribes nationwide continue to rely upon natural resources including fossil fuels to sustain their way of life despite attacks from the White House.

## Young mom-to-be pays off her student loan debt of $120K: 'Focus on other life goals'
 - [https://www.foxnews.com/lifestyle/mom-to-be-pays-off-student-loan-debt-120k-focus-life-goals](https://www.foxnews.com/lifestyle/mom-to-be-pays-off-student-loan-debt-120k-focus-life-goals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 06:00:42+00:00

As the Biden administration scales back its student loan handout plan, one Maryland woman who completely paid down her college debt has a story of discipline and dedication to share.

## Supreme Court's new term should bring constitutional clarity, as far left turns up the heat on justices
 - [https://www.foxnews.com/opinion/supreme-court-new-term-should-bring-constitutional-clarity-far-left-turns-up-heat-justices](https://www.foxnews.com/opinion/supreme-court-new-term-should-bring-constitutional-clarity-far-left-turns-up-heat-justices)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 06:00:35+00:00

Supreme Court's new term should bring constitutional clarity on affirmative action, voting and religious rights, as far left turns up the heat on justices.

## Army penalizing soldiers seeking religious accommodation to vaxx mandate: 'Technique of coercion'
 - [https://www.foxnews.com/politics/army-penalizing-soldiers-seeking-religious-accommodation-vaxx-mandate-technique-coercion](https://www.foxnews.com/politics/army-penalizing-soldiers-seeking-religious-accommodation-vaxx-mandate-technique-coercion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 06:00:23+00:00

The Army is actively enforcing punishments against unvaccinated service members, who are calling the tactic a "technique of coercion" to have them abandon their religious beliefs.

## Elvis Presley’s stepbrother says he spoke of God’s forgiveness before his death: 'In touch with the Lord'
 - [https://www.foxnews.com/entertainment/elvis-presley-stepbrother-says-spoke-gods-forgiveness-before-death](https://www.foxnews.com/entertainment/elvis-presley-stepbrother-says-spoke-gods-forgiveness-before-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 06:00:02+00:00

Elvis Presley passed away on Aug. 16, 1977 at age 42. Earlier this year, he was the subject of a glitzy biopic by director Baz Luhrmann titled 'Elvis' starring Austin Butler.

## Arizona man shows up for Tinder meet-up, gets robbed by armed couple
 - [https://www.foxnews.com/us/arizona-man-shows-up-tinder-meet-up-gets-robbed-armed-couple](https://www.foxnews.com/us/arizona-man-shows-up-tinder-meet-up-gets-robbed-armed-couple)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 05:40:11+00:00

A couple in Phoenix, Arizona, lured a man using Tinder to a hotel room where they robbed him of money and his car at gunpoint. The couple was arrested by police after a wild chase.

## Young child shot in Phoenix, officers investigating near Arizona elementary school
 - [https://www.foxnews.com/us/young-child-shot-phoenix-officers-investigating-near-arizona-elementary-school](https://www.foxnews.com/us/young-child-shot-phoenix-officers-investigating-near-arizona-elementary-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 04:53:20+00:00

A young girl was shot in Phoenix on Sunday night, prompting Arizona officers to investigate near Trailside Point Performing Arts Academy, an elementary school in Laveen Village.

## On this day in history, Oct. 3, 1863, Lincoln issues powerful Thanksgiving proclamation
 - [https://www.foxnews.com/lifestyle/this-day-history-oct-3-1863-lincoln-issues-powerful-thanksgiving-proclamation](https://www.foxnews.com/lifestyle/this-day-history-oct-3-1863-lincoln-issues-powerful-thanksgiving-proclamation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 04:18:13+00:00

President Abe Lincoln issued his powerful Thanksgiving proclamation on Oct. 3, 1863, asking Americans to set aside the last Thursday of November to praise "our beneficent Father."

## Brazil presidential election: Jair Bolsonaro proves polls wrong, forces socialist opponent into runoff
 - [https://www.foxnews.com/world/brazil-presidential-election-jair-bolsonaro-proves-polls-wrong-forces-socialist-opponent-runoff](https://www.foxnews.com/world/brazil-presidential-election-jair-bolsonaro-proves-polls-wrong-forces-socialist-opponent-runoff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 03:59:17+00:00

In a significant departure from polls showing a large Lula lead, the leftist leader bested incumbent Jair Bolsonaro by just four points, forcing a tight runoff at month’s end.

## Chiefs beat Bucs behind Patrick Mahomes' dazzling performance
 - [https://www.foxnews.com/sports/chiefs-beat-bucs-patrick-mahomes-dazzling-performance](https://www.foxnews.com/sports/chiefs-beat-bucs-patrick-mahomes-dazzling-performance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 03:52:33+00:00

Patrick Mahomes dazzled in Tampa on Sunday night, as the Kansas City Chiefs took down Tom Brady and the Buccaneers, 41-31, to improve to 3-1 on the season.

## Tua Tagovailoa controversy sparks advice from NFL great to younger generation about reporting head injuries
 - [https://www.foxnews.com/sports/tua-tagovailoa-controversy-sparks-advice-nfl-great-younger-generation-about-reporting-head-injuries](https://www.foxnews.com/sports/tua-tagovailoa-controversy-sparks-advice-nfl-great-younger-generation-about-reporting-head-injuries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 03:39:28+00:00

NFL legend Rodney Harrison had some wise words for the younger generation of football players days after Tua Tagovailoa's head injury.

## Tom Brady plays in Tampa Bay without Gisele Bündchen or kids in stands after evacuating due to Hurricane Ian
 - [https://www.foxnews.com/entertainment/tom-brady-plays-tampa-bay-without-gisele-bundchen-kids-stands-after-evacuating-hurricane-ian](https://www.foxnews.com/entertainment/tom-brady-plays-tampa-bay-without-gisele-bundchen-kids-stands-after-evacuating-hurricane-ian)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 03:10:44+00:00

Gisele Bündchen missed another one of Tom Brady's games as rumors of marital problems persist for the couple. It was the Buccaneers first game back in Tampa Bay since Hurricane Ian.

## Tyler Herro, Heat agree to four-year extension
 - [https://www.foxnews.com/sports/tyler-herro-heat-agree-four-year-extension](https://www.foxnews.com/sports/tyler-herro-heat-agree-four-year-extension)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 03:10:04+00:00

Miami Heat guard Tyler Herro will be with the organization for quite some time. He and the organization agreed to a four-year extension on Sunday.

## Aaron Judge takes quest to hit 62nd home run on the road after final regular-season home series
 - [https://www.foxnews.com/sports/aaron-judge-takes-quest-hit-62nd-home-run-road-final-regular-season-home-series](https://www.foxnews.com/sports/aaron-judge-takes-quest-hit-62nd-home-run-road-final-regular-season-home-series)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 02:52:19+00:00

Aaron Judge will only have four more games to hit the 62nd home run of the 2022 season as the New York Yankees hit the road for a four-game series against the Texas Rangers.

## Albert Pujols hits home run No. 702, ties Babe Ruth in another stat category
 - [https://www.foxnews.com/sports/albert-pujols-hits-home-run-no-702-ties-babe-ruth-another-stat-category](https://www.foxnews.com/sports/albert-pujols-hits-home-run-no-702-ties-babe-ruth-another-stat-category)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 02:27:00+00:00

Albert Pujols hit his 702nd home run against the Pittsburgh Pirates and tied Babe Ruth on the RBI list for second of all-time on Sunday.

## Here's what pundits keep getting wrong on the midterms: Steve Hilton
 - [https://www.foxnews.com/media/heres-what-pundits-keep-getting-wrong-midterms-steve-hilton](https://www.foxnews.com/media/heres-what-pundits-keep-getting-wrong-midterms-steve-hilton)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 02:09:41+00:00

'The Next Revolution' Steve Hilton predicted a strong Republican outcome in the November midterm elections as both parties battle for the majority in the House and Senate.

## Patrick Mahomes makes ridiculous first-half plays vs. Buccaneers
 - [https://www.foxnews.com/sports/patrick-mahomes-makes-ridiculous-first-half-plays-vs-buccaneers](https://www.foxnews.com/sports/patrick-mahomes-makes-ridiculous-first-half-plays-vs-buccaneers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 02:05:02+00:00

Patrick Mahomes delighted the NFL world with his smooth moves in the first half of the Kansas City Chiefs' Week 4 game against the Tampa Bay Buccaneers.

## Wisconsin fires head coach Paul Chryst after 2-3 start to season
 - [https://www.foxnews.com/sports/wisconsin-fires-head-coach-paul-chryst-2-3-start-season](https://www.foxnews.com/sports/wisconsin-fires-head-coach-paul-chryst-2-3-start-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 02:03:09+00:00

The University of Wisconsin announced they have fired head coach Paul Chryst in a surprising move following another blowout loss Saturday.

## Brazil's Bolsonaro, Lula going to runoff in presidential election
 - [https://www.foxnews.com/world/brazils-bolsonaro-lula-going-runoff-presidential-election](https://www.foxnews.com/world/brazils-bolsonaro-lula-going-runoff-presidential-election)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 01:56:50+00:00

Brazil's top two presidential candidates are going to a runoff election after no candidates broke 50% in the first round of elections on Sunday.

## Dr. Phil guest claims 'White supremacy is embedded in everything' in segment on cultural appropriation
 - [https://www.foxnews.com/media/dr-phil-guest-claims-white-supremacy-embedded-everything-segment-cultural-appropriation](https://www.foxnews.com/media/dr-phil-guest-claims-white-supremacy-embedded-everything-segment-cultural-appropriation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 01:54:19+00:00

Friday's episode of Dr. Phil tackled the issue of "cultural appropriation," particularly when it comes to race in America.

## Bucs launch Hurricane Ian relief efforts ahead of Chiefs game, team members wear 'Florida Strong' shirts
 - [https://www.foxnews.com/sports/bucs-launch-hurricane-ian-relief-efforts-ahead-chiefs-game-team-members-wear-florida-strong-shirts](https://www.foxnews.com/sports/bucs-launch-hurricane-ian-relief-efforts-ahead-chiefs-game-team-members-wear-florida-strong-shirts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 01:52:53+00:00

The Tampa Bay Buccaneers launched their "Florida Strong" relief efforts on Sunday, and several team members were wearing shirts supporting it.

## Texas borderland car crash leaves three people dead in human smuggling attempt
 - [https://www.foxnews.com/us/texas-borderland-car-crash-leaves-three-people-dead-human-smuggling-attempt](https://www.foxnews.com/us/texas-borderland-car-crash-leaves-three-people-dead-human-smuggling-attempt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 01:43:12+00:00

A car crash during a human smuggling attempt near Brackettville, Texas, on Sunday left three people dead and three others injured, according to Texas DPS.

## Aaron Rodgers heard dropping F-bomb during Packers drive, Tony Romo jokingly translates
 - [https://www.foxnews.com/sports/aaron-rodgers-heard-dropping-f-bomb-packers-drive-tony-romo-jokingly-translates](https://www.foxnews.com/sports/aaron-rodgers-heard-dropping-f-bomb-packers-drive-tony-romo-jokingly-translates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 01:43:04+00:00

Aaron Rodgers was caught dropping an F-bomb on a hot mic during the Green Bay Packers' matchup against the New England Patriots on Sunday.

## Levin declares a person cannot be a ‘progressive’ and ‘support the Constitution’
 - [https://www.foxnews.com/media/levin-declares-person-cannot-progressive-support-constitution](https://www.foxnews.com/media/levin-declares-person-cannot-progressive-support-constitution)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 01:40:05+00:00

Fox News host Mark Levin laid out in his Sunday monologue how being a progressive means you cannot support the U.S. Constitution.

## Texas alleged serial killer to go on trial Monday
 - [https://www.foxnews.com/us/texas-alleged-serial-killer-trial-monday](https://www.foxnews.com/us/texas-alleged-serial-killer-trial-monday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 01:28:16+00:00

A Texas man who is accused of murdering nearly two dozen older women is going on trial Monday for the death of an 87-year-old woman who was found dead at her Dallas home in early 2018.

## Josh Jacobs' two touchdowns lift Raiders past Broncos
 - [https://www.foxnews.com/sports/josh-jacobs-two-touchdowns-lift-raiders-past-broncos](https://www.foxnews.com/sports/josh-jacobs-two-touchdowns-lift-raiders-past-broncos)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 00:54:28+00:00

Josh Jacobs ran for 144 yards on the ground and scored two touchdowns to help the Las Vegas Raiders secure a win over the Denver Broncos on Sunday.

## Aaron Rodgers reaches historic milestone in Packers' overtime win over Patriots
 - [https://www.foxnews.com/sports/aaron-rodgers-reaches-historic-milestone-packers-overtime-win-patriots](https://www.foxnews.com/sports/aaron-rodgers-reaches-historic-milestone-packers-overtime-win-patriots)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 00:46:08+00:00

Aaron Rodgers made history as the Green Bay Packers beat the New England Patriots in overtime, 27-24, at Lambeau Field on Sunday afternoon.

## Victor Davis Hanson claims the far-left doesn't 'trust democracy'
 - [https://www.foxnews.com/media/victor-davis-hanson-claims-far-left-doesnt-trust-democracy](https://www.foxnews.com/media/victor-davis-hanson-claims-far-left-doesnt-trust-democracy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 00:44:12+00:00

Hoover Institute senior fellow Victor Davis Hanson spoke on “Sunday Night in America with Trey Gowdy” about the Left’s obsession with labelling opponents “far-right.”

## Falcons' clutch interception seals win over Browns
 - [https://www.foxnews.com/sports/falcons-clutch-interception-seals-win-browns](https://www.foxnews.com/sports/falcons-clutch-interception-seals-win-browns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 00:42:44+00:00

The Atlanta Falcons saw Dee Alford intercept Cleveland Browns quarterback Jacoby Brissett to seal a win on their home turf on Sunday, 23-20.

## Kyler Murray, Cardinals overcome slow first half to defeat Panthers
 - [https://www.foxnews.com/sports/kyler-murray-cardinals-overcome-slow-first-half-defeat-panthers](https://www.foxnews.com/sports/kyler-murray-cardinals-overcome-slow-first-half-defeat-panthers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 00:37:52+00:00

Kyler Murray had three total touchdowns in the Arizona Cardinals' win over the Carolina Panthers but his counterpart, Baker Mayfield, struggled.

## Wynonna Judd reflects on rehearsing for final tour without late mother Naomi Judd: 'I just lost it'
 - [https://www.foxnews.com/entertainment/wynonna-judd-reflects-rehearsing-final-tour-without-late-mother-naomi-judd-i-just-lost-it](https://www.foxnews.com/entertainment/wynonna-judd-reflects-rehearsing-final-tour-without-late-mother-naomi-judd-i-just-lost-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 00:17:53+00:00

Wynonna Judd lost mother Naomi Judd to suicide in April, and admitted going back on a final tour to sing their songs for fans was "devastatingly beautiful."

## Man at Steelers game dead after falling from Acrisure Stadium escalator
 - [https://www.foxnews.com/sports/man-steelers-game-dead-falling-acrisure-stadium-escalator](https://www.foxnews.com/sports/man-steelers-game-dead-falling-acrisure-stadium-escalator)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 00:12:02+00:00

A man died after falling from the escalator at Acrisure Stadium in Pittsburgh on Sunday. It happened shortly after the Steelers-Jets game.

## Vox writer tells parents to ‘worry’ about not letting their kids transition
 - [https://www.foxnews.com/media/vox-writer-tells-parents-worry-letting-kids-transition](https://www.foxnews.com/media/vox-writer-tells-parents-worry-letting-kids-transition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 00:09:42+00:00

Vox correspondent Emily St. James wrote a lengthy piece on Thursday encouraging parents to accept and transition their transgender kids despite medical concerns.

## Chicago teen who allegedly hijacked SUV, crashed and killed woman had felony gun warrant: report
 - [https://www.foxnews.com/us/chicago-teen-who-allegedly-hijacked-suv-crashed-killed-woman-had-felony-gun-warrant-report](https://www.foxnews.com/us/chicago-teen-who-allegedly-hijacked-suv-crashed-killed-woman-had-felony-gun-warrant-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-03 00:02:29+00:00

A Chicago teen who was one of four suspects arrested in connection with a carjacking that led to the death of a 55-year-old woman was reportedly awaiting trial for a felony gun case.


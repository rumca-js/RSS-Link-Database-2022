# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Supreme Court Takes Up Challenge to Social Media Platforms’ Shield
 - [https://www.nytimes.com/2022/10/03/us/supreme-court-social-media-section-230.html](https://www.nytimes.com/2022/10/03/us/supreme-court-social-media-section-230.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-03 23:20:30+00:00

The family of a student killed in terrorist attacks challenged a 1996 law that gives websites immunity for suits based on their users’ posts.

## U.S. Said to Plan New Limits on China’s A.I. and Supercomputing Firms
 - [https://www.nytimes.com/2022/10/03/business/us-limits-chinas-supercomputing.html](https://www.nytimes.com/2022/10/03/business/us-limits-chinas-supercomputing.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-03 18:54:14+00:00

The new rules could be the most sweeping action taken yet by the Biden administration to thwart China’s access to American technology that powers data centers and supercomputers.

## Will Smith Film ‘Emancipation’ Will Be Released in December
 - [https://www.nytimes.com/2022/10/03/business/media/will-smith-emancipation-release-date.html](https://www.nytimes.com/2022/10/03/business/media/will-smith-emancipation-release-date.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-03 18:29:35+00:00

Apple said the movie, Mr. Smith’s first since his infamous slap at the Oscars, will be in theaters on Dec. 2 and begin streaming on Dec. 9.

## Silicon Valley County Battles With Uber Over Reporting of Sexual Assault
 - [https://www.nytimes.com/2022/10/03/technology/uber-sexual-assault-reporting-santa-clara-county.html](https://www.nytimes.com/2022/10/03/technology/uber-sexual-assault-reporting-santa-clara-county.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-03 18:17:42+00:00

Uber does not inform the police of such incidents, citing advocacy group guidelines. But officials in Santa Clara County argue that it should.

## How a Tiny Elections Company Became a Conspiracy Theory Target
 - [https://www.nytimes.com/2022/10/03/technology/konnech-election-conspiracy-theories.html](https://www.nytimes.com/2022/10/03/technology/konnech-election-conspiracy-theories.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-03 09:00:20+00:00

Election deniers catapulted a Michigan firm with just 21 U.S. employees to the center of unfounded voter fraud claims, exposing it to vicious threats.


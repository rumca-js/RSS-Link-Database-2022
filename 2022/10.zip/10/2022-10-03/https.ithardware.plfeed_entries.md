# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Podsumowanie newsów ITHardware - tydzień 77. Sprawdź co Cię ominęło
 - [https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_siedemdziesiaty_siodmy_pazdziernik_2022-23659.html](https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_siedemdziesiaty_siodmy_pazdziernik_2022-23659.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 21:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/23659_1.jpg" />            Jak co tydzień zapraszamy naszych czytelnik&oacute;w do odwiedzenia kanału&nbsp;ITHardware na YouTube i do zapoznania się z materiałem prezentującym najważniejsze wydarzenia minionych 7 dni.

Za powstanie wideo odpowiada&nbsp;nasz redakcyjny...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_siedemdziesiaty_siodmy_pazdziernik_2022-23659.html">https://ithardware.pl/aktu

## Sony zablokuje przejęcie Activision Blizzard? Szef PlayStation miał odwiedzić centralę UE
 - [https://ithardware.pl/aktualnosci/sony_zablokuje_przejecie_activision_blizzard_szef_playstation_mial_odwiedzic_centrale_ue-23657.html](https://ithardware.pl/aktualnosci/sony_zablokuje_przejecie_activision_blizzard_szef_playstation_mial_odwiedzic_centrale_ue-23657.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 19:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/23657_1.jpg" />            Microsoft złożył wniosek do Komisji Europejskiej o akceptację przejęcia Activision Blizzard. Sony niechętne jest temu krokowi czemu nie raz dawało znak, ale tym razem lobbować w sprawie miał szef PlayStation, Jim Ryan.

Kupno Activison...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sony_zablokuje_przejecie_activision_blizzard_szef_playstation_mial_odwiedzic_centrale_ue-23657.html">https://it

## Ruszyła nowa promocja Lenovo - codziennie do wygrania zwrot gotówki za zakup laptopa
 - [https://ithardware.pl/aktualnosci/ruszyla_nowa_promocja_lenovo_codziennie_do_wygrania_zwrot_gotowki_za_zakup_laptopa-23656.html](https://ithardware.pl/aktualnosci/ruszyla_nowa_promocja_lenovo_codziennie_do_wygrania_zwrot_gotowki_za_zakup_laptopa-23656.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 18:40:00+00:00

<img src="https://ithardware.pl/artykuly/min/23656_1.jpg" />            Lenovo Polska ogłosiło rozpoczęcie specjalnego konkursu obejmującego laptopy z serii Yoga, IdeaPad i Legion, w&nbsp;ramach kt&oacute;rego codziennie jedna osoba wygrywa zwrot got&oacute;wki za kupione urządzenie. Akcja trwa przez cały...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ruszyla_nowa_promocja_lenovo_codziennie_do_wygrania_zwrot_gotowki_za_zakup_laptopa-23656.html">https://ithardwar

## Beyond Good & Evil 2 to najdłużej opóźniana gra, która bije Duke Nukem: Forever
 - [https://ithardware.pl/aktualnosci/beyond_good_evil_2_to_najdluzej_opozniana_gra_ktora_bije_duke_nukem_forever-23655.html](https://ithardware.pl/aktualnosci/beyond_good_evil_2_to_najdluzej_opozniana_gra_ktora_bije_duke_nukem_forever-23655.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 16:50:00+00:00

<img src="https://ithardware.pl/artykuly/min/23655_1.jpg" />            Duke Nukem: Forever uchodził za najdłużej op&oacute;źnianą grę, kt&oacute;rą na swą premierę czekała aż 14 lat. Rekord księcia demolki&nbsp;pobiła&nbsp;inna produkcja.

Powstawanie Duke Nukem: Forever zamieniło się w prawdziwą...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/beyond_good_evil_2_to_najdluzej_opozniana_gra_ktora_bije_duke_nukem_forever-23655.html">https://ithardware.pl/aktualnosc

## Sony podobno pracuje nad remasterem/remake Horizon Zero Dawn
 - [https://ithardware.pl/aktualnosci/sony_podobno_pracuje_nad_remasterem_remake_horizon_zero_dawn-23653.html](https://ithardware.pl/aktualnosci/sony_podobno_pracuje_nad_remasterem_remake_horizon_zero_dawn-23653.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 15:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/23653_1.jpg" />            Sony planuje wydać remaster lub remake&nbsp;Horizon Zero Dawn na PlayStation 5. Warto wspomnieć, że gra pozostaje dostępna także na konsoli poprzedniej generacji PS4 i&nbsp;komputerach.

Horizon Zero Dawn trafił do sprzedaży w 2017 roku na PS4,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sony_podobno_pracuje_nad_remasterem_remake_horizon_zero_dawn-23653.html">https://ithardware.pl/aktualn

## HWiNFO jest już wstępnie gotowe do obsługi procesorów AMD Zen 5
 - [https://ithardware.pl/aktualnosci/hwinfo_jest_juz_wstepnie_gotowe_do_obslugi_procesorow_amd_zen_5-23652.html](https://ithardware.pl/aktualnosci/hwinfo_jest_juz_wstepnie_gotowe_do_obslugi_procesorow_amd_zen_5-23652.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 15:29:30+00:00

<img src="https://ithardware.pl/artykuly/min/23652_1.jpg" />            Tw&oacute;rcy HWiNFO są gotowi do wprowadzenia bardzo wczesnego wsparcia dla procesor&oacute;w AMD opartych na architekturze Zen 5. Potwierdza&nbsp;to informacja na oficjalnej stronie programu&nbsp;w zakładce &quot;Nachodzące zmiany&quot;. Oznacza to,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hwinfo_jest_juz_wstepnie_gotowe_do_obslugi_procesorow_amd_zen_5-23652.html">https://ithardware.

## Tesla zwiększyła produkcję. W trzecim kwartale powstało 365 923 pojazdów elektrycznych marki
 - [https://ithardware.pl/aktualnosci/tesla_zwiekszyla_produkcje_w_trzecim_kwartale_powstalo_365_923_pojazdow_elektrycznych_marki-23650.html](https://ithardware.pl/aktualnosci/tesla_zwiekszyla_produkcje_w_trzecim_kwartale_powstalo_365_923_pojazdow_elektrycznych_marki-23650.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 14:47:00+00:00

<img src="https://ithardware.pl/artykuly/min/23650_1.jpg" />            Po kryzysie związanym z pandemią, Tesla mogła w końcu zwiększyć produkcję swoich elektrycznych pojazd&oacute;w. W trzecim kwartale z fabryk wyjechało aż&nbsp;365 923 samochod&oacute;w, co oznacza wzrost produkcji o niemalże 54% w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tesla_zwiekszyla_produkcje_w_trzecim_kwartale_powstalo_365_923_pojazdow_elektrycznych_marki-23650.html">https://ithar

## Wiemy, jak może wyglądać Samsung Galaxy A14. Do sieci trafiły rendery
 - [https://ithardware.pl/aktualnosci/wiemy_jak_moze_wygladac_samsung_galaxy_a14_do_sieci_trafily_rendery-23644.html](https://ithardware.pl/aktualnosci/wiemy_jak_moze_wygladac_samsung_galaxy_a14_do_sieci_trafily_rendery-23644.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 14:13:20+00:00

<img src="https://ithardware.pl/artykuly/min/23644_1.jpg" />            W sieci opublikowane zostały nowe rendery pokazujące możliwy wygląd Samsunga Galaxy A14. Nadchodzący smartfon r&oacute;żni się od swojego poprzednika między innymi mniej ostrym wycięciem w ekranie na przedni aparat. Doniesienia wskazują, że...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wiemy_jak_moze_wygladac_samsung_galaxy_a14_do_sieci_trafily_rendery-23644.html">https://ithardware.pl/aktu

## XFX Radeon RX 6700 XL - zdjęcia nieznanej nam dotąd karty graficznej trafiły do sieci
 - [https://ithardware.pl/aktualnosci/xfx_radeon_rx_6700_xl_zdjecia_nieznanej_nam_dotad_karty_graficznej_trafily_do_sieci-23638.html](https://ithardware.pl/aktualnosci/xfx_radeon_rx_6700_xl_zdjecia_nieznanej_nam_dotad_karty_graficznej_trafily_do_sieci-23638.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 13:41:40+00:00

<img src="https://ithardware.pl/artykuly/min/23638_1.jpg" />            Do sieci trafiły pierwsze zdjęcia Radeona RX 6700 XL w niereferencyjnym wydaniu od XFX. Karta dysponuje 10 GB pamięci VRAM i bazuje na okrojonym procesorze graficznym Navi 22. Układy Radeon RX 6700 z dopiskiem XL były sprzedawane bezpośrednio...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/xfx_radeon_rx_6700_xl_zdjecia_nieznanej_nam_dotad_karty_graficznej_trafily_do_sieci-23638.html">https://

## Pierwszy 9-osobowy samolot elektryczny Eviation Alice pomyślnie przetestowany
 - [https://ithardware.pl/aktualnosci/pierwszy_9_osobowy_samolot_elektryczny_eviation_alice_pomyslnie_przetestowany-23651.html](https://ithardware.pl/aktualnosci/pierwszy_9_osobowy_samolot_elektryczny_eviation_alice_pomyslnie_przetestowany-23651.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 12:57:20+00:00

<img src="https://ithardware.pl/artykuly/min/23651_1.jpg" />            Kolejne, wcześniej nie do pomyślenia, zastosowanie napędu elektrycznego powoli staje się rzeczywistością.&nbsp;Tym razem jest to mały samolot do przewozu os&oacute;b lub ładunk&oacute;w na kr&oacute;tsze odległości.&nbsp;Nazywa się Eviation...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pierwszy_9_osobowy_samolot_elektryczny_eviation_alice_pomyslnie_przetestowany-23651.html">https://ithardwa

## Kontrowersyjna platforma dla rozszerzeń Google Chrome nadejdzie w przyszłym roku
 - [https://ithardware.pl/aktualnosci/kontrowersyjna_platforma_dla_rozszerzen_google_chrome_nadejdzie_w_przyszlym_roku-23647.html](https://ithardware.pl/aktualnosci/kontrowersyjna_platforma_dla_rozszerzen_google_chrome_nadejdzie_w_przyszlym_roku-23647.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 12:35:01+00:00

<img src="https://ithardware.pl/artykuly/min/23647_1.jpg" />            Google powoli, ale konsekwentnie zmierza w kierunku wprowadzenia nowej platformy rozszerzeń o nazwie Manifest V3 dla przeglądarki Chrome i właśnie otrzymaliśmy&nbsp; harmonogram.&nbsp;

Począwszy od Chrome 112, kt&oacute;re zostanie wprowadzone w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kontrowersyjna_platforma_dla_rozszerzen_google_chrome_nadejdzie_w_przyszlym_roku-23647.html">https:/

## Chiny uruchamiają największy na świecie wanadowy akumulator przepływowy redoks
 - [https://ithardware.pl/aktualnosci/chiny_uruchomiaja_najwiekszy_na_swiecie_wanadowy_akumulator_przeplywowy_redoks-23649.html](https://ithardware.pl/aktualnosci/chiny_uruchomiaja_najwiekszy_na_swiecie_wanadowy_akumulator_przeplywowy_redoks-23649.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 12:14:10+00:00

<img src="https://ithardware.pl/artykuly/min/23649_1.jpg" />            Chiny mocno wkraczają w odnawialne źr&oacute;dła energii, a to niesie ze sobą zwiększone zapotrzebowanie na magazynowanie energii.&nbsp;Problem ten częściowo mają rozwiązać akumulatory przepływowe&nbsp;w Dalian, kt&oacute;re zaoferują...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chiny_uruchomiaja_najwiekszy_na_swiecie_wanadowy_akumulator_przeplywowy_redoks-23649.html">https://ithardware.pl

## Czy procesory AMD Ryzen 7000 są opłacalne? Analizujemy!
 - [https://ithardware.pl/artykuly/czy_procesory_amd_ryzen_7000_sa_oplacalne_analizujemy-23586.html](https://ithardware.pl/artykuly/czy_procesory_amd_ryzen_7000_sa_oplacalne_analizujemy-23586.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 11:41:00+00:00

<img src="https://ithardware.pl/artykuly/min/23586_1.jpg" />            Przy okazji premiery procesor&oacute;w Intel Alder Lake stworzyliśmy na bazie zebranych danych analizę opłacalności tychże jednostek przy wykorzystaniu r&oacute;żnych scenariuszy. Nie inaczej postąpimy dziś, czyli przy okazji pierwszych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/czy_procesory_amd_ryzen_7000_sa_oplacalne_analizujemy-23586.html">https://ithardware.pl/artykuly/czy_procesory_am

## Tesla AI Day: Ujawniono prototyp robota Optimus i przypuszczalną cenę końcową
 - [https://ithardware.pl/aktualnosci/tesla_ai_day_ujawniono_prototyp_robota_optimus_i_przypuszczalna_cene_koncowa-23648.html](https://ithardware.pl/aktualnosci/tesla_ai_day_ujawniono_prototyp_robota_optimus_i_przypuszczalna_cene_koncowa-23648.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 11:27:40+00:00

<img src="https://ithardware.pl/artykuly/min/23648_1.jpg" />            W końcu doczekaliśmy się Tesla AI Day, wydarzenia, na kt&oacute;rym zaprezentowano zwiastowany od dawna&nbsp;prototyp robota Optimus oraz&nbsp;ujawniono kilka szczeg&oacute;ł&oacute;w na temat jego działania i przewidywanej ceny.

Tesla...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tesla_ai_day_ujawniono_prototyp_robota_optimus_i_przypuszczalna_cene_koncowa-23648.html">https://ithardware.pl

## Google podobno skasowało kontynuację Death Stranding. Gra miała być ekskluzywem dla Stadia
 - [https://ithardware.pl/aktualnosci/google_podobno_skasowalo_kontynuacje_death_stranding_gra_miala_byc_ekskluzywem_dla_stadia-23646.html](https://ithardware.pl/aktualnosci/google_podobno_skasowalo_kontynuacje_death_stranding_gra_miala_byc_ekskluzywem_dla_stadia-23646.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 11:04:10+00:00

<img src="https://ithardware.pl/artykuly/min/23646_1.jpg" />            Jednym z gł&oacute;wnych problem&oacute;w Google Stadia od samego początku był fakt, że koncern nie postarał się o żadne wysokobudżetowe tytuły AAA na wyłączność dla swojej usługi grania w chmurze, kt&oacute;rą zamknie w styczniu. Jasne,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/google_podobno_skasowalo_kontynuacje_death_stranding_gra_miala_byc_ekskluzywem_dla_stadia-23646.html">https:/

## Genesis partnerem technologicznym Poznań Game Arena 2022 - KONKURS!
 - [https://ithardware.pl/aktualnosci/genesis_partnerem_technologicznym_poznan_game_arena_2022_konkurs-23645.html](https://ithardware.pl/aktualnosci/genesis_partnerem_technologicznym_poznan_game_arena_2022_konkurs-23645.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 10:53:00+00:00

<img src="https://ithardware.pl/artykuly/min/23645_1.jpg" />            Marka Genesis znana m.in. z gamingowych akcesori&oacute;w i peryferi&oacute;w komputerowych została partnerem technologicznym tegorocznych targ&oacute;w PGA. To już 10. raz, gdy Genesis weźmie udział w poznańskiej imprezie dla graczy.

Genesis...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/genesis_partnerem_technologicznym_poznan_game_arena_2022_konkurs-23645.html">https://ithardware.pl/aktu

## Nadchodzą zmiany w nazwach USB, które ułatwiają orientację w różnych wersjach standardu
 - [https://ithardware.pl/aktualnosci/nadchodza_zmiany_w_nazwach_usb_ktore_ulatwiaja_orientacje_w_roznych_wersjach_standardu-23635.html](https://ithardware.pl/aktualnosci/nadchodza_zmiany_w_nazwach_usb_ktore_ulatwiaja_orientacje_w_roznych_wersjach_standardu-23635.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 10:46:00+00:00

<img src="https://ithardware.pl/artykuly/min/23635_1.jpg" />            Grupa, kt&oacute;ra nadzoruje USB, planuje uprościć nazewnictwo port&oacute;w i kabli, by ułatwić nam orientację w ramach tego coraz bardziej zagmatwanego standardu. Chce porzucić nazwy, takie jak SuperSpeed ​​i USB4, wprowadzając...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nadchodza_zmiany_w_nazwach_usb_ktore_ulatwiaja_orientacje_w_roznych_wersjach_standardu-23635.html">https://ithardwar

## Pixel Watch bez tajemnic. Najnowszy przeciek z Amazonu prezentuje zegarek Google
 - [https://ithardware.pl/aktualnosci/pixel_watch_bez_tajemnic_najnowszy_przeciek_z_amazonu_prezentuje_zegarek_google-23634.html](https://ithardware.pl/aktualnosci/pixel_watch_bez_tajemnic_najnowszy_przeciek_z_amazonu_prezentuje_zegarek_google-23634.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 10:25:00+00:00

<img src="https://ithardware.pl/artykuly/min/23634_1.jpg" />            Pozostało tylko kilka dni do wielkiego wydarzenia Google Pixel, na kt&oacute;rym firma zaprezentuje smartfony Pixel 7, a także pierwszy flagowy smartwatch, kt&oacute;ry zaprojektowała we własnym zakresie (przynajmniej bez Fitbit).&nbsp;

Przecieki...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pixel_watch_bez_tajemnic_najnowszy_przeciek_z_amazonu_prezentuje_zegarek_google-23634.html">https:/

## To koniec NFT? Wolumen transkacji spadł o 97% od początku roku
 - [https://ithardware.pl/aktualnosci/to_koniec_nft_wolumen_transkacji_spadl_o_97_od_poczatku_roku-23640.html](https://ithardware.pl/aktualnosci/to_koniec_nft_wolumen_transkacji_spadl_o_97_od_poczatku_roku-23640.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 09:50:40+00:00

<img src="https://ithardware.pl/artykuly/min/23640_1.jpg" />            Początkowa mania na tokeny NFT znacznie osłabła, a wolumen transakcji spadł do&nbsp;minimum w niecały rok.&nbsp;Ciekawostką całej sytuacji jest jednak to, że liczba os&oacute;b dokonujących wcale&nbsp;nie spada drastycznie i większość z tych,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/to_koniec_nft_wolumen_transkacji_spadl_o_97_od_poczatku_roku-23640.html">https://ithardware.pl/aktualnos

## Hopper H100 - NVIDIA aktualizuje wydajność FP64 oraz FP32
 - [https://ithardware.pl/aktualnosci/hopper_h100_nvidia_aktualizuje_wydajnosc_fp64_oraz_fp32-23637.html](https://ithardware.pl/aktualnosci/hopper_h100_nvidia_aktualizuje_wydajnosc_fp64_oraz_fp32-23637.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 09:18:00+00:00

<img src="https://ithardware.pl/artykuly/min/23637_1.jpg" />            Wstępna specyfikacja układu graficznego Hopper H100 została zaktualizowana przez producenta. NVIDIA wprowadziła zmiany w kwestii wydajności pojedynczej oraz podw&oacute;jnej precyzji. Dla wersji SXM&nbsp;osiągi FP64 zwiększyły się z 30&nbsp;do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hopper_h100_nvidia_aktualizuje_wydajnosc_fp64_oraz_fp32-23637.html">https://ithardware.pl/aktualnosci/h

## Użytkownicy skarżą się na naklejki na płytach głównych ASRock. Firma będzie wymieniać sprzęt
 - [https://ithardware.pl/aktualnosci/uzytkownicy_skarza_sie_na_naklejki_na_plytach_glownych_asrock_firma_bedzie_wymieniac_sprzet-23632.html](https://ithardware.pl/aktualnosci/uzytkownicy_skarza_sie_na_naklejki_na_plytach_glownych_asrock_firma_bedzie_wymieniac_sprzet-23632.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 09:15:00+00:00

<img src="https://ithardware.pl/artykuly/min/23632_1.jpg" />            Zdaje się, że ASRock przesadziło z naklejkami na swoich nowych płytach gł&oacute;wnych. Użytkownicy Reddita zaczęli bowiem udostępniać zdjęcia modeli Asrock X670E Steel Legend z kawałkami naklejek przyklejonych do wnętrza gniazd pamięci, co...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/uzytkownicy_skarza_sie_na_naklejki_na_plytach_glownych_asrock_firma_bedzie_wymieniac_sprzet-23632.html">ht

## Intel XeSS przetestowane na GPU NVIDII i AMD. Wyniki zaskakują
 - [https://ithardware.pl/aktualnosci/intel_xess_przetestowane_na_gpu_nvidii_i_amd_wyniki_zaskakuja-23633.html](https://ithardware.pl/aktualnosci/intel_xess_przetestowane_na_gpu_nvidii_i_amd_wyniki_zaskakuja-23633.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 08:17:20+00:00

<img src="https://ithardware.pl/artykuly/min/23633_1.png" />            Intel dość niespodziewanie udostępnił swoją technologię upscalingu XeSS w zeszłym tygodniu, nie czekając na premierę kart graficznych z serii Arc A700. Ta obsługuje GPU praktycznie wszystkich producent&oacute;w, w tym NVIDII i AMD, więc...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_xess_przetestowane_na_gpu_nvidii_i_amd_wyniki_zaskakuja-23633.html">https://ithardware.pl/aktualnosci/in

## ONZ ujawniaja na konferencji WEF, jak steruje narracją poprzez wyniki wyszukiwania i influcencerów
 - [https://ithardware.pl/aktualnosci/onz_ujawniaja_na_konferencji_wef_jak_steruje_narracja_poprzez_wyniki_wyszukiwania_i_influcencerow-23636.html](https://ithardware.pl/aktualnosci/onz_ujawniaja_na_konferencji_wef_jak_steruje_narracja_poprzez_wyniki_wyszukiwania_i_influcencerow-23636.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 08:06:10+00:00

<img src="https://ithardware.pl/artykuly/min/23636_1.jpg" />            Światowe Forum Ekonomiczne (WEF) zorganizowało konferencję&nbsp;Sustainable Development Impact Meetings, na kt&oacute;rej omawiano problemy dotyczące zr&oacute;wnoważonego rozwoju, a jednym z punkt&oacute;w programu była &quot;walka z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/onz_ujawniaja_na_konferencji_wef_jak_steruje_narracja_poprzez_wyniki_wyszukiwania_i_influcencerow-23636.html">ht

## Skalpowanie Ryzenów 7000 jest ryzykowne, ale gra jest  warto świeczki
 - [https://ithardware.pl/aktualnosci/skalpowanie_ryzenow_7000_jest_ryzykowne_ale_gra_jest_warto_swieczki-23631.html](https://ithardware.pl/aktualnosci/skalpowanie_ryzenow_7000_jest_ryzykowne_ale_gra_jest_warto_swieczki-23631.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 07:10:12+00:00

<img src="https://ithardware.pl/artykuly/min/23631_1.jpg" />            Skalpowanie procesor&oacute;w to niebezpieczna zabawa, ale okazuje się, że w przypadku serii Ryzen 7000 może zdziałać cuda, znacząco obniżając temperatury CPU.&nbsp;

AMD wprowadziło już na rynek swoją najnowszą generację procesor&oacute;w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/skalpowanie_ryzenow_7000_jest_ryzykowne_ale_gra_jest_warto_swieczki-23631.html">https://ithardware.pl/aktua

## Jesienna wyprzedaż w x-komie: laptopy, akcesoria w jeszcze lepszych cenach
 - [https://ithardware.pl/aktualnosci/jesienna_wyprzedaz_w_x_komie_laptopy_akcesoria_w_jeszcze_lepszych_cenach-23608.html](https://ithardware.pl/aktualnosci/jesienna_wyprzedaz_w_x_komie_laptopy_akcesoria_w_jeszcze_lepszych_cenach-23608.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2022-10-03 05:53:00+00:00

<img src="https://ithardware.pl/artykuly/min/23608_1.jpg" />            Jesień rozgościła się już na dobre, a wraz z nią rozsiedliśmy się na kanapach. Kr&oacute;tkie dni, zamglone poranki i chłodne popołudnia nie zachęcają do wychodzenia spod ciepłego koca. Wy też w drodze z pracy marzycie wyłącznie o...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/jesienna_wyprzedaz_w_x_komie_laptopy_akcesoria_w_jeszcze_lepszych_cenach-23608.html">https://ithardware.pl/aktualnos


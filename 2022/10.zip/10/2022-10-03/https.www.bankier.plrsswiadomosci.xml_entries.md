# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Media: Wielka Brytania wprowadzi zakaz azylu dla migrantów nielegalnie przekraczających kanał La Manche
 - [https://www.bankier.pl/wiadomosc/Media-Wielka-Brytania-wprowadzi-zakaz-azylu-dla-migrantow-nielegalnie-przekraczajacych-kanal-La-Manche-8416684.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-Wielka-Brytania-wprowadzi-zakaz-azylu-dla-migrantow-nielegalnie-przekraczajacych-kanal-La-Manche-8416684.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 23:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/0/6395af1773d181-945-560-0-26-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brytyjska minister spraw wewnętrznych Suella Braverman ogłosi we wtorek projekt ustawy zakazującej  ubiegania się o azyl dla migrantów, którzy przekraczają kanał La Manche,  podał "The Times".</p>

## Biden zapowiedział kolejne sankcje przeciwko Iranowi za represje wobec demonstrantów
 - [https://www.bankier.pl/wiadomosc/Biden-zapowiedzial-kolejne-sankcje-przeciwko-Iranowi-za-represje-wobec-demonstrantow-8416682.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Biden-zapowiedzial-kolejne-sankcje-przeciwko-Iranowi-za-represje-wobec-demonstrantow-8416682.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 23:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/c/86e1fbe98324b2-948-568-0-49-1802-1081.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent USA Joe Biden zapowiedział nałożenie kolejnych sankcji przeciwko irańskiemu reżimowi w związku z represjami przeciwko demonstrującym kobietom i studentom w Iranie. Zapewnił też o poparciu USA  dla protestujących.</p>

## "Pojedynek" na plany pokojowe. Zełenski trolluje Elona Muska na Twitterze
 - [https://www.bankier.pl/wiadomosc/Pojedynek-na-plany-pokojowe-Zelenski-trolluje-Elona-Muska-na-Twitterze-8416671.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pojedynek-na-plany-pokojowe-Zelenski-trolluje-Elona-Muska-na-Twitterze-8416671.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 21:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/8/adc22a7d773677-948-568-0-0-3000-1800.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraiński prezydent Wołodymyr Zełenski i jego doradca Mychajło Podolak starli się na Twitterze z Elonem Muskiem, gdy amerykański miliarder zaproponował nowe referendum, pod nadzorem ONZ, w sprawie ukraińskich terytoriów, pozostawienie Rosji Krymu i "status neutralny" dla Ukrain

## Kolejne odbicie na Wall Street. Ale analitycy sądzą, że spadki jeszcze się nie skończyły
 - [https://www.bankier.pl/wiadomosc/Kolejne-odbicie-na-Wall-Street-Ale-analitycy-sadza-ze-spadki-jeszcze-sie-nie-skonczyly-8416667.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kolejne-odbicie-na-Wall-Street-Ale-analitycy-sadza-ze-spadki-jeszcze-sie-nie-skonczyly-8416667.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 21:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/6/ff8860c2ef3b98-948-568-10-140-1990-1193.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poniedziałkowa sesja na Wall Street zakończyła się mocnymi wzrostami. Po słabym wrześniu główne indeksy amerykańskich giełd weszły w czwarty kwartał zwyżkami przekraczającymi 2,5 proc., a Dow zyskał ponad 760 punktów.</p>

## "WSJ": Chiny z dużym zyskiem odsprzedają Europie gaz skroplony kupowany w USA
 - [https://www.bankier.pl/wiadomosc/WSJ-Chiny-z-duzym-zyskiem-odsprzedaja-Europie-gaz-skroplony-kupowany-w-USA-8416642.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/WSJ-Chiny-z-duzym-zyskiem-odsprzedaja-Europie-gaz-skroplony-kupowany-w-USA-8416642.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 19:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/f/7e5fde007eb72e-948-568-259-269-2015-1209.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chiny, które z powodu spowolnienia gospodarczego mają mniejsze zapotrzebowanie na surowce energetyczne, z dużym zyskiem odsprzedają Europie gaz skroplony (LNG) kupowany w USA - informuje w poniedziałek dziennik "Wall Street Journal".</p>

## Media: za aneksją ukraińskich ziem zagłosowało w Dumie więcej deputowanych, niż było na sali
 - [https://www.bankier.pl/wiadomosc/Media-za-aneksja-ukrainskich-ziem-zaglosowalo-w-Dumie-wiecej-deputowanych-niz-bylo-na-sali-8416641.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-za-aneksja-ukrainskich-ziem-zaglosowalo-w-Dumie-wiecej-deputowanych-niz-bylo-na-sali-8416641.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 19:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/d/f97897d72f2205-948-568-0-40-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Za aneksją ukraińskich ziem zagłosowało w poniedziałek w Dumie Państwowej, izbie niższej parlamentu Rosji, więcej deputowanych, niż było na sali obrad - informuje niezależny portal Meduza.</p>

## Oszukany „na akcje Orlenu” stracił prawie 300 tys. zł. Uwierzył w szybki i duży zysk
 - [https://www.bankier.pl/wiadomosc/Oszustwo-na-akcje-Orlenu-54-latek-stracil-prawie-300-tys-zl-8416292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oszustwo-na-akcje-Orlenu-54-latek-stracil-prawie-300-tys-zl-8416292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 19:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/75bd0f66f1463c-945-560-0-118-1053-631.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />„Apelujemy o ostrożność podczas inwestycji. Oferta szybkiego, dużego i łatwego zysku może sugerować oszustwo” – ostrzegają policjanci z Komendy Powiatowej Policji w Nowym Targu. Jako przestrogę przytaczają historię 54-latka, który stracił blisko 300 tys., choć długo był przeko

## Tabletki z jodkiem potasu dotarły do samorządów. Te wskażą punkty wydawania leku
 - [https://www.bankier.pl/wiadomosc/Tabletki-z-jodkiem-potasu-dotarly-do-samorzadow-Te-wskaza-punkty-wydawania-tabletek-8416603.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tabletki-z-jodkiem-potasu-dotarly-do-samorzadow-Te-wskaza-punkty-wydawania-tabletek-8416603.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 18:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/e2c49a7f467c82-948-568-30-30-3970-2381.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do świętokrzyskich samorządów trafiło ponad 1,7 mln tabletek jodku potasu – poinformował w poniedziałek wojewoda Zbigniew Koniusz. Nie ma na razie realnego zagrożenia i wszystko wskazuje na to, że będzie to akcja podejmowana jako tak zwana wczesna profilaktyka – dodał.</p>

## Gdańsk wyłoni dostawcę energii z wolnej ręki
 - [https://www.bankier.pl/wiadomosc/Gdansk-wyloni-dostawce-energii-z-wolnej-reki-8416602.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gdansk-wyloni-dostawce-energii-z-wolnej-reki-8416602.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 18:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/9/35962d45d3a210-948-567-0-17-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władze Gdańska planują podjęcie negocjacji z dostawcą energii wyłonionym z wolnej ręki. Zachęcają też wszystkich członków metropolitalnej grupy zakupowej do pozostania w grupie i podjęcia podobnego działania.</p>

## Węgry kontra UE. Parlament przyjął pierwsze rozwiązania antykorupcyjne w celu odblokowania unijnych funduszy
 - [https://www.bankier.pl/wiadomosc/Wegry-kontra-UE-Parlament-przyjal-pierwsze-rozwiazania-antykorupcyjne-8416594.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wegry-kontra-UE-Parlament-przyjal-pierwsze-rozwiazania-antykorupcyjne-8416594.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 17:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/a621ae41e66e42-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Węgierski parlament przyjął w poniedziałek nowelizację kodeksu postępowania karnego, co ma być pierwszym krokiem do osiągnięcia porozumienia z Komisją Europejską i odblokowania unijnych funduszy.</p>

## Marek Kuchciński szefem KPRM? "Otrzymał propozycję"
 - [https://www.bankier.pl/wiadomosc/Marek-Kuchcinski-szefem-KPRM-Otrzymal-propozycje-8416567.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Marek-Kuchcinski-szefem-KPRM-Otrzymal-propozycje-8416567.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 17:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/f/8a5d705ed01f43-948-568-0-20-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Były marszałek Sejmu Marek Kuchciński otrzymał propozycję objęcia funkcji szefa Kancelarii Prezesa Rady Ministrów - podał w poniedziałek portal i.pl. Kuchciński pytany przez portal nie skomentował tych doniesień.</p>

## Ofgem ostrzega: Wielka Brytania stoi w obliczu ryzyka niedoboru gazu i prądu
 - [https://www.bankier.pl/wiadomosc/Ofgem-ostrzega-Wielka-Brytania-stoi-w-obliczu-ryzyka-niedoboru-gazu-i-pradu-8416569.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ofgem-ostrzega-Wielka-Brytania-stoi-w-obliczu-ryzyka-niedoboru-gazu-i-pradu-8416569.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 17:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/0b43ee1e66cbd4-948-568-2-20-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wielka Brytania stoi w obliczu "znaczącego ryzyka" niedoborów gazu tej zimy, co może wpłynąć na dostawy energii elektrycznej - ostrzegł w ujawnionym w poniedziałek liście regulator rynku energii, Ofgem.</p>

## Gaz ziemny w Europie tanieje o ponad 10 proc.
 - [https://www.bankier.pl/wiadomosc/Gaz-ziemny-w-Europie-tanieje-o-ponad-10-proc-8416561.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gaz-ziemny-w-Europie-tanieje-o-ponad-10-proc-8416561.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 17:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/2/c3e743f6131eb5-948-568-8-52-1147-688.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W poniedziałek około godz. 18 gaz ziemny w holenderskim hubie TTF w kontraktach listopadowych tanieje o 10,48 proc., spadając do 169 euro za MWh. O niespełna 10 proc. tanieje gaz z dostawą w grudniu.</p>

## Kasa fiskalna w myjni później niż planował resort finansów
 - [https://www.bankier.pl/wiadomosc/Kasy-fiskalne-w-myjniach-Odroczono-termin-obowiazkowej-instalacji-8416548.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kasy-fiskalne-w-myjniach-Odroczono-termin-obowiazkowej-instalacji-8416548.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 16:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/1a303396adfcf4-948-568-0-200-3620-2172.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Resort finansów odroczył o kolejne cztery miesiące
 obowiązkowy termin instalacji kas rejestrujących w myjniach 
samochodowych. Nowy termin to 1 lutego 2023 r.</p>

## Nowe minima bessy na GPW. Mimo to sesja skończyła się na plusach
 - [https://www.bankier.pl/wiadomosc/Nowe-minima-bessy-na-GPW-Mimo-to-sesja-skonczyla-sie-na-plusach-8416506.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowe-minima-bessy-na-GPW-Mimo-to-sesja-skonczyla-sie-na-plusach-8416506.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 16:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/1/12904f258c9cd4-948-568-12-52-983-590.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inwestorzy rozpoczęli handel w nowym miesiącu od pogłębienia dotychczasowych minimów bessy na wszystkich głównych indeksach z GPW. Nic to jednak nie znaczyło wobec sentymentu płynącego z  Wall Street, który pozwolił zakończyć dzień na plusach. </p>

## Była dziennikarka TVN oskarża stację o mobbing. “Byłam poniżana, gnębiona”
 - [https://www.bankier.pl/wiadomosc/Anna-Wendzikowska-oskarza-TVN-o-mobbing-Stacja-odpowiada-8416432.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Anna-Wendzikowska-oskarza-TVN-o-mobbing-Stacja-odpowiada-8416432.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 16:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/8ac621465c1826-948-568-0-0-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Anna Wendzikowska po 15 latach pracy odeszła ze 
stacji TVN. Dziennikarka za pośrednictwem mediów społecznościowych 
oskarżyła stację o mobbing. Stacja przeprasza, wskazując, że takie historie nie powinny mieć miejsca.</p>

## Rekordowa waloryzacja. Sprawdź, o ile wzrosną emerytury w 2023 roku
 - [https://www.bankier.pl/wiadomosc/Waloryzacja-rent-i-emerytur-2023-Minimum-250-zl-8416339.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Waloryzacja-rent-i-emerytur-2023-Minimum-250-zl-8416339.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 15:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/1/c56d12eec0ba5b-948-568-0-283-4200-2519.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jak co roku w marcu emerytów czeka waloryzacja 
świadczenia wypłacanego przez ZUS. Tym razem mogą liczyć na całkiem 
sporą podwyżkę, bo aż o 13,8 proc., ale minimum 250 zł. Na razie to 
projekt, który pojawił się w wykazie prac legislacyjnych i programowych 
rządu.</p>

## Nowy rekord na lokatach. Bank proponuje 8,50 proc.
 - [https://www.bankier.pl/wiadomosc/Nowy-rekord-na-lokatach-Bank-Nowy-proponuje-8-50-proc-w-skali-roku-8416406.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowy-rekord-na-lokatach-Bank-Nowy-proponuje-8-50-proc-w-skali-roku-8416406.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 15:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/c/584a73dc4bcfbc-948-568-0-97-2441-1465.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najnowsza tabela oprocentowania w Banku Nowym to nie tylko wyższe stawki na prawie wszystkich lokatach internetowych banku, ale jednocześnie rekord na rynku. Lokata miesięczna dla nowych klientów otrzymała bowiem oprocentowanie w wysokości 8,50 proc. w skali roku.</p>

## "Wielka woda" zaleje Netfliksa już w październiku
 - [https://www.bankier.pl/wiadomosc/Wielka-woda-premiera-5-pazdziernika-na-Netflixie-8416107.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wielka-woda-premiera-5-pazdziernika-na-Netflixie-8416107.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 15:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/127133b7ef2513-948-568-187-0-2812-1687.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"W obliczu strachu znajdź w sobie siłę" - tak trailer najnowszej produkcji Netflix zachęca do serialu "Wielka woda", który przenosi nas do powodzi tysiąclecia z 1997 roku, kiedy to Wrocław walczył o utrzymanie się na powierzchni. 
 </p>

## Ponownie zwiększył się wyciek z Nord Stream 2. Przyczyna nieznana
 - [https://www.bankier.pl/wiadomosc/Ponownie-zwiekszyl-sie-wyciek-z-Nord-Stream-2-Przyczyna-nieznana-8416331.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ponownie-zwiekszyl-sie-wyciek-z-Nord-Stream-2-Przyczyna-nieznana-8416331.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 13:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/18410c29c7ca5c-948-568-0-2-1146-687.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponownie zwiększył się wyciek gazu z rurociągu Nord Stream 2 na północny wschód od Bornholmu. Przyczyna wzrostu ciśnienia nie jest znana - poinformowała w poniedziałek szwedzka Straż Przybrzeżna.</p>

## Narasta kryzys migracyjny. Szef związku policjantów wzywa do kontroli granic
 - [https://www.bankier.pl/wiadomosc/Narasta-kryzys-migracyjny-Szef-zwiazku-policjantow-wzywa-do-kontroli-granic-8416322.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Narasta-kryzys-migracyjny-Szef-zwiazku-policjantow-wzywa-do-kontroli-granic-8416322.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 13:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/9f42f2ffa57bdb-948-567-0-7-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szef niemieckiego związku zawodowego policjantów wzywa do kontroli granic, ponieważ coraz więcej migrantów wjeżdża do Republiki Federalnej nielegalnie. Jedna z głównych tras to linia kolejowa Praga-Drezno.</p>

## Konta studenckie. Banki płacą nawet 400 zł za założenie rachunku. Analiza Bankier.pl i zgarnijpremie.pl
 - [https://www.bankier.pl/wiadomosc/Konta-studenckie-Banki-kusza-bonusami-siegajacymi-nawet-400-zl-8416246.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Konta-studenckie-Banki-kusza-bonusami-siegajacymi-nawet-400-zl-8416246.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 13:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/820df50241b11a-948-568-0-0-1738-1042.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nawet 400 zł może otrzymać student, który zdecyduje się założyć konto w banku w ramach promocji – wynika z analizy Bankier.pl i serwisu zgarnijpremie.pl. Aby otrzymać bonus, wystarczy spełnić kilka prostych warunków, najczęściej związanych z aktywnością na koncie. Obecnie konta

## Rusza miniserial dla oszczędzających w Bankier.pl. Zapisz się na odcinek 1
 - [https://www.bankier.pl/wiadomosc/Rusza-miniserial-dla-oszczedzajacych-w-Bankier-pl-Zapisz-sie-na-odcinek-1-8416265.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rusza-miniserial-dla-oszczedzajacych-w-Bankier-pl-Zapisz-sie-na-odcinek-1-8416265.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 13:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/d/aee37d9be8612d-948-568-0-253-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Październik to zwyczajowo miesiąc oszczędzania. W tym sezonie wysokie 
stopy procentowe sprzyjają deponentom, a banki od kilku miesięcy 
przebijają stawki lokat. Monika Dekrewicz z redakcji Bankier.pl rusza z 
autorskim projektem, który będzie swoistym "gotowcem z oszczędzani

## Błaszczak zapowiada dodatki dla żołnierzy. Zyskają kilkaset zł miesięcznie
 - [https://www.bankier.pl/wiadomosc/Blaszczak-zapowiada-dodatki-dla-zolnierzy-Zyskaja-kilkaset-zl-miesiecznie-8416296.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Blaszczak-zapowiada-dodatki-dla-zolnierzy-Zyskaja-kilkaset-zl-miesiecznie-8416296.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 13:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/c6b17f4a473f82-945-567-36-340-4823-2894.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podjąłem decyzję, aby żołnierze w określonych jednostkach wojsk lądowych dostawali dodatek służbowy 450 zł miesięcznie; rozporządzenie w tej sprawie skierowano już do uzgodnień - poinformował w mediach społecznościowych wicepremier, szef MON Mariusz Błaszczak.</p>

## Maciej Szlinder i Dariusz Standerski kandydatami Lewicy do Rady Polityki Pieniężnej
 - [https://www.bankier.pl/wiadomosc/Maciej-Szlinder-i-Dariusz-Standerski-kandydatami-Lewicy-do-Rady-Polityki-Pienieznej-8416260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Maciej-Szlinder-i-Dariusz-Standerski-kandydatami-Lewicy-do-Rady-Polityki-Pienieznej-8416260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 12:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/d/370cd28e7a1530-948-568-552-66-1187-712.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ekonomiści Maciej Szlinder i Dariusz Standerski są kandydatami Lewicy do Rady Polityki Pieniężnej - poinformował na konferencji szef klubu Krzysztof Gawkowski. Jak podkreślił, kandydaci Lewicy są nowym pokoleniem polskiej ekonomii i w RPP byliby gwarantami nowego i odpowiedzi

## Nowy operator oferuje darmowe połączenia i internet. Czy jest tu haczyk?
 - [https://www.bankier.pl/wiadomosc/Darmowy-operator-komorkowy-wchodzi-na-polski-rynek-Co-oferuje-Fonia-8416134.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Darmowy-operator-komorkowy-wchodzi-na-polski-rynek-Co-oferuje-Fonia-8416134.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/e/a83f6858963be0-948-568-0-0-1730-1037.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brak jakichkolwiek opłat za połączenia, SMS-y i internet mobilny – takim zestawem kusi potencjalnych klientów Fonia, nowy gracz na polskim rynku operatorów komórkowych. Stawia przy tym prosty warunek: by zaoszczędzić, trzeba zgodzić się na wyświetlanie reklam. Czy za darmo napr

## Nie żyje Jerzy Urban, rzecznik prasowy rządu PRL w stanie wojennym
 - [https://www.bankier.pl/wiadomosc/Nie-zyje-Jerzy-Urban-8416180.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-zyje-Jerzy-Urban-8416180.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 10:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/0/78213486d40bf4-948-568-1251-281-1498-899-GR.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie żyje Jerzy Urban, zmarł w wieku 89 lat. Był redaktorem naczelnym "Tygodnika Nie". W latach 1981–89 jako rzecznik prasowy Rady Ministrów PRL, wspóltworzył propagandę stanu wojennego - informację o jego śmierci potwierdziła PAP redakcja Tygodnika "NIE".</p>

## Brytyjski rząd kapituluje. Podatek dla najbogatszych bez zmian
 - [https://www.bankier.pl/wiadomosc/Brytyjski-rzad-kapituluje-Podatek-dla-najbogatszych-bez-zmian-8416175.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjski-rzad-kapituluje-Podatek-dla-najbogatszych-bez-zmian-8416175.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 10:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/2/be8cf594454077-945-560-0-283-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brytyjski rząd wycofał się w poniedziałek rano z budzącej ogromne kontrowersje decyzji o zniesieniu najwyższej, 45-procentowej stawki podatkowej dla najlepiej zarabiających, która została ogłoszona zaledwie 10 dni temu.</p>

## Giełdowy pogrom na akcjach Credit Suisse. Inwestorzy boją się powtórki z Lehman Brothers
 - [https://www.bankier.pl/wiadomosc/Gieldowy-pogrom-na-akcjach-Credit-Suisse-Inwestorzy-boja-sie-powtorki-z-Lehman-Brothers-8416114.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gieldowy-pogrom-na-akcjach-Credit-Suisse-Inwestorzy-boja-sie-powtorki-z-Lehman-Brothers-8416114.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 10:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/a/f2a13e43e67724-945-567-0-146-1425-855.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Notowania Credit Suisse zaliczają kolejny dzień przeceny po tym jak w weekend nasiliły się spekulacje o trudnej sytuacji finansowej szwajcarskiego banku. Jego potencjalna niewypłacalności sprowadziła kapitalizację poniżej 10 mld CHF.</p>

## Wystawiono rekordowy mandat. Najwyższe kary już obowiązują
 - [https://www.bankier.pl/wiadomosc/Wystawiono-rekordowy-mandat-8416089.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wystawiono-rekordowy-mandat-8416089.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 10:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/c/9c6579e01d124b-945-560-0-239-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Policja wystawiła rekordowy mandat według nowych zasad. Od 17 września wzrosły bowiem kary dla "drogowych recydywistów". </p>

## PGE sprzedała na rzecz PGE GiEK udziały w sześciu spółkach
 - [https://www.bankier.pl/wiadomosc/PGE-sprzedala-na-rzecz-PGE-GiEK-udzialy-w-szesciu-spolkach-8416121.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PGE-sprzedala-na-rzecz-PGE-GiEK-udzialy-w-szesciu-spolkach-8416121.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 09:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/d/48b3ac2d41c918-948-568-0-88-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PGE podpisała z PGE Górnictwo i Energetyka Konwencjonalna umowy zbycia udziałów w spółkach Bestgum, Betrans, Elmen, Eltur – Serwis, Megaserwis oraz Ramb - poinformowała PGE w komunikacie prasowym. To działania przygotowujące grupę do wydzielenia aktywów węglowych.</p>

## OZE się opłaca. Kto zainwestował, nie narzeka
 - [https://www.bankier.pl/wiadomosc/OZE-sie-oplaca-Kto-zainwestowal-nie-narzeka-8416098.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/OZE-sie-oplaca-Kto-zainwestowal-nie-narzeka-8416098.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 09:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/a/d7961af2075325-948-567-0-30-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad czterech na pięciu posiadaczy odnawialnych źródeł energii jest zadowolonych ze swojej inwestycji – wynika z badania "Energetyczne wybory Polaków" przeprowadzonego przez ARC Rynek i Opinia na zlecenie Woltair Polska.</p>

## Kursy dolara i franka poniżej 5 zł. Złoty łapie oddech
 - [https://www.bankier.pl/wiadomosc/Kursy-dolara-i-franka-ponizej-5-zl-Zloty-lapie-oddech-8416086.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kursy-dolara-i-franka-ponizej-5-zl-Zloty-lapie-oddech-8416086.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 09:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/0/106e3f1b0c249c-948-568-65-191-1591-954.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po piątkowych danych o inflacji w Polsce wzrosły oczekiwania na podwyżkę
 stóp procentowych NBP i umocnił się złoty. Złoty kontynuował umocnPo piątkowych danych o inflacji w Polsce wzrosły oczekiwania na podwyżkę
 stóp procentowych NBP i złoty odrabiał straty po fatalnej pier

## Niemcy podnoszą płacę minimalną
 - [https://www.bankier.pl/wiadomosc/Placa-minimalna-w-Niemczech-w-gore-8415567.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Placa-minimalna-w-Niemczech-w-gore-8415567.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 09:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/0/4711420bc40887-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />1 października płaca minimalna w Niemczech wzrasta z 10,45 euro do 12 euro za godzinę; z podwyżki skorzysta 6,64 mln osób - powiadomił Instytut Badań Gospodarczych i Społecznych Fundacji Hansa Boecklera. Wśród beneficjentów tej zmiany jest 3,5 mln kobiet i 2,7 mln mężczyzn - 

## Ukraińcy wydali w Polsce w I półroczu dwa razy więcej niż rok wcześniej
 - [https://www.bankier.pl/wiadomosc/Ukraincy-wydali-w-Polsce-w-I-polroczu-2-1-mld-zl-dwa-razy-wiecej-niz-rok-wczesniej-8416081.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraincy-wydali-w-Polsce-w-I-polroczu-2-1-mld-zl-dwa-razy-wiecej-niz-rok-wczesniej-8416081.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 08:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/e/f3d8a9f646f698-945-560-0-0-3897-2338.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraińcy zostawili w sklepach i na usługi w pierwszym półroczu tego roku 2,1 mld zł, dwa razy więcej niż w analogicznym okresie rok wcześniej i o 24 proc. więcej niż w tym samym okresie pandemicznego 2020 roku - poinformował w komunikacie prasowym Personnel Service.</p>

## Pekao TFI: Wysoka inflacja na świecie może pozostać przez całą dekadę
 - [https://www.bankier.pl/wiadomosc/Pekao-TFI-Wysoka-inflacja-na-swiecie-moze-pozostac-przez-cala-dekade-8416078.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pekao-TFI-Wysoka-inflacja-na-swiecie-moze-pozostac-przez-cala-dekade-8416078.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 08:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/b/1d91929a35faf2-948-568-13-66-1759-1055.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wysoka inflacja na świecie może pozostać do końca dekady lat 20-tych, chociaż będą też w tym czasie okresy spadku cen - uważa Maciej Pielok, dyrektor ds. strategii inwestycyjnej Pekao TFI. W tych warunkach trzeba stawiać na rynki akcji, żeby ratować oszczędności, ale ważne je

## Tak galopuje inflacja w Turcji. Erdogan dolewa oliwy do ognia
 - [https://www.bankier.pl/wiadomosc/Tak-galopuje-inflacja-w-Turcji-Erdogan-dolewa-oliwy-do-ognia-8416049.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tak-galopuje-inflacja-w-Turcji-Erdogan-dolewa-oliwy-do-ognia-8416049.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 08:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/0be015866fedae-948-568-0-93-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Oficjalnie inflacja w Turcji przekracza 80 proc., nieoficjalnie - zbliża
 się do 200 proc. Oliwy do ognia dolewa prezydent Erdogan, który wymusza
 na banku centralnym obniżki stóp procentowych i zapowiada kolejne.</p>

## Cholewiński: Recesja dostarcza okazji, by kupić atrakcyjnie wycenione aktywa
 - [https://www.bankier.pl/wiadomosc/Cholewinski-Recesja-dostarcza-okazji-by-kupic-atrakcyjnie-wycenione-aktywa-8416069.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Cholewinski-Recesja-dostarcza-okazji-by-kupic-atrakcyjnie-wycenione-aktywa-8416069.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 08:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/0654caa40f2a7b-948-568-0-115-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Źródła inflacji w USA i Europie są zróżniowane, a koszty walki z nią będą bardziej odczuwalne w gospodarce strefy euro. Recesja może dostarczyć okazji, by tanio kupić atrakcyjnie wycenione aktywa - uważa Radosław Cholewiński, członek zarządu Skarbiec TFI.</p>

## Gaz tanieje. Europa może przetrwać tę zimę i kryzys energetyczny
 - [https://www.bankier.pl/wiadomosc/Gaz-tanieje-Europa-moze-przetrwac-te-zime-i-kryzys-energetyczny-8416067.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gaz-tanieje-Europa-moze-przetrwac-te-zime-i-kryzys-energetyczny-8416067.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 08:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/c/8610b76992d3e3-948-567-15-15-985-590.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny gazu w Europie spadają w reakcji na oznaki, że kraje Starego Kontynentu będą w stanie przetrwać tę zimę, w czasie gdy UE obiecuje podjęcie dalszych kroków w celu opanowania obecnego kryzysu energetycznego w regionie. Benchmarkowe kontrakty na gaz w Amsterdamie (ICE Entawex

## Gwałtowny spadek nowych zamówień w polskim przemyśle
 - [https://www.bankier.pl/wiadomosc/Gwaltowny-spadek-nowych-zamowien-w-polskim-przemysle-8416048.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gwaltowny-spadek-nowych-zamowien-w-polskim-przemysle-8416048.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 08:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/b6f85033c595ef-948-567-0-32-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />We wrześniu polski sektor przemysłowy kurczył się piąty miesiąc z rzędu -
 wynika z badania S&amp;P Global PMI. "Warunki gospodarcze nie sprzyjały
 producentom, co uwidoczniał kolejny gwałtowny spadek produkcji i nowych
 zamówień" - wskazują analitycy.</p>

## DM BOŚ obniża wycenę akcji BioMaximy
 - [https://www.bankier.pl/wiadomosc/DM-BOS-obniza-wycene-akcji-BioMaximy-do-33-90-zl-8416059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/DM-BOS-obniza-wycene-akcji-BioMaximy-do-33-90-zl-8416059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 08:14:00+00:00

<p>Analitycy DM BOŚ w raporcie z 2 października obniżyli wycenę akcji BioMaximy do 33,9 z 37,6 zł wcześniej.</p>

## Wiceszef MSZ: Nie planujemy zerwać stosunków dyplomatycznych z Rosją
 - [https://www.bankier.pl/wiadomosc/Wiceszef-MSZ-Nie-planujemy-zerwac-stosunkow-dyplomatycznych-z-Rosja-8416041.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiceszef-MSZ-Nie-planujemy-zerwac-stosunkow-dyplomatycznych-z-Rosja-8416041.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 07:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/7/0331130f64deb8-948-568-15-66-2032-1219.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeśli dogadamy się wszyscy na poziomie europejskim, że należy uciąć wszelkie możliwe kontakty z dyplomatami rosyjskimi, to Polska oczywiście również to zrobi - powiedział wiceszef polskiej dyplomacji Marcin Przydacz. Dodał, że na tym etapie Polska samodzielnie takiego kroku n

## "Zmobilizowani nie spełniali kryteriów". Moskwa reaguje
 - [https://www.bankier.pl/wiadomosc/Zmobilizowani-nie-spelniali-kryteriow-Moskwa-reaguje-8416021.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zmobilizowani-nie-spelniali-kryteriow-Moskwa-reaguje-8416021.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 07:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/4/35d5fe2126a755-948-568-15-74-1985-1190.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisarz wojskowy Kraju Chabarowskiego w azjatyckiej części Rosji stracił stanowisko, a połowę zmobilizowanych pod jego zarządem osób odesłano do domów, ponieważ nie spełniali kryteriów – podała w poniedziałek agencja Reutera, cytując gubernatora regionu Michaiła Diegtiariowa

## Brytyjczycy rzucili się po złoto. Dilerom brakuje kruszcu
 - [https://www.bankier.pl/wiadomosc/Brytyjczycy-rzucili-sie-po-zloto-Dilerom-brakuje-kruszcu-8416005.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjczycy-rzucili-sie-po-zloto-Dilerom-brakuje-kruszcu-8416005.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/4/5acd94e7a9ede0-945-560-101-371-4387-2632.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po tym, jak tąpnęły notowania funta, Brytyjczycy 
ruszyli po złoto. Londyńscy dilerzy skarżą się na braki monet i sztabek -
 donosi Bloomberg.</p>

## Deficyt w 2023 r. ma być wyższy, niż pierwotnie planowano
 - [https://www.bankier.pl/wiadomosc/Deficyt-w-2023-r-ma-byc-wyzszy-niz-pierwotnie-planowano-8416016.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Deficyt-w-2023-r-ma-byc-wyzszy-niz-pierwotnie-planowano-8416016.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/477a8cd89fda58-948-568-0-108-1600-959.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Deficyt sektora instytucji rządowych i samorządowych w 2023 wyniesie 4,5 proc. PKB vs 4,4 proc. prognozowanych w wersji projektu budżetu z sierpnia.</p>

## Zamiast wakacji marzeń, Polscy turyści utknęli w Turcji. Posypią się reklamacje
 - [https://www.bankier.pl/wiadomosc/Zamiast-wakacji-marzen-Polscy-turysci-utkneli-w-Turcji-Posypia-sie-reklamacje-8416006.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zamiast-wakacji-marzen-Polscy-turysci-utkneli-w-Turcji-Posypia-sie-reklamacje-8416006.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/3/866d82f0dfa3a8-948-567-0-57-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zostali wykwaterowani z hotelów, udali się na lotnisko, by wrócić do Polski, gdy okazało się, że ich lot nie figuruje w rozkładzie. Ponad 70 turystów z Wrocławia utknęło w Antalyi w Turcji. Ich wycieczki organizowało biuro Exim Tours. 
</p>

## Ropa drożeje po zapowiedziach OPEC+ o cięciu produkcji
 - [https://www.bankier.pl/wiadomosc/Ropa-drozeje-po-zapowiedziach-OPEC-o-cieciu-produkcji-8416008.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ropa-drozeje-po-zapowiedziach-OPEC-o-cieciu-produkcji-8416008.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 06:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/3c45cac299c715-948-567-5-2-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku wystrzeliły po doniesieniach, że kraje sojuszu OPEC+ rozważają zmniejszenie produkcji ropy o ponad 1 mln baryłek dziennie, aby "ożywić" spadające ostatnio ceny tego surowca - podają maklerzy.</p>

## Tesla bije rekordy, a i tak rozczarowuje
 - [https://www.bankier.pl/wiadomosc/Tesla-bije-rekordy-a-i-tak-rozczarowuje-8415997.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tesla-bije-rekordy-a-i-tak-rozczarowuje-8415997.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 06:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/d/43d0744f1d6f35-948-567-0-30-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W minionym kwartale Tesla dostarczyła klientom rekordową liczbę aut. 
Wynik nie sprostał jednak oczekiwaniom analityków. W tym roku akcje 
spółki straciły blisko 25 proc.</p>

## Młodzi Polacy nie chcą przywrócenia poboru do wojska
 - [https://www.bankier.pl/wiadomosc/Mlodzi-Polacy-nie-chca-przywrocenia-poboru-do-wojska-8415990.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mlodzi-Polacy-nie-chca-przywrocenia-poboru-do-wojska-8415990.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 06:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/7b70487fe8cee2-948-568-0-72-1912-1147.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Z sondażu przeprowadzonego przez IBRiS dla poniedziałkowej "Rzeczpospolitej" wynika, że tylko co trzeci badany zgadza się na przywrócenie poboru. W ciągu kilku miesięcy spadła liczba tych, którzy popierają przywrócenie obowiązkowej zasadniczej służby wojskowej w Polsce.</p>

## Prima Moda wnioskuje o restrukturyzację. Winny COVID-19
 - [https://www.bankier.pl/wiadomosc/Prima-Moda-zlozyla-wniosek-o-otwarcie-postepowania-restrukturyzacyjnego-8415985.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prima-Moda-zlozyla-wniosek-o-otwarcie-postepowania-restrukturyzacyjnego-8415985.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/6/1e4728c955c50b-948-568-0-0-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prima Moda złożyła w sądzie rejonowym we Wrocławiu wniosek o otwarcie postępowania restrukturyzacyjnego - poinformowała spółka w komunikacie.</p>

## Rząd przestraszył się najniższych emerytur. Zapowiada dla nich waloryzację
 - [https://www.bankier.pl/wiadomosc/Najnizsza-emerytura-w-2023-r-Rzad-planuje-waloryzacje-8415976.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najnizsza-emerytura-w-2023-r-Rzad-planuje-waloryzacje-8415976.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 05:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/7/722e042eb66678-948-568-0-115-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szacujemy, że najniższa emerytura wyniesie od marca 2023 r. ponad 1500 zł brutto. Rozważamy zastosowanie waloryzacji kwoto-procentowej z gwarantowanym minimalnym wzrostem – powiedział PAP wiceminister rodziny Stanisław Szwed. Dodał, że zasady wypłat czternastek będą podobne j

## Leśnicy z bronią automatyczną. Lasy Państwowe doposażają strażników
 - [https://www.bankier.pl/wiadomosc/Lesnicy-z-bronia-automatyczna-Lasy-Panstwowe-doposazaja-straznikow-8415974.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lesnicy-z-bronia-automatyczna-Lasy-Panstwowe-doposazaja-straznikow-8415974.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 05:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/7ffb41906dc56f-945-560-0-103-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Straż Leśna prowadzi działania na obszarze niemal równym powierzchni Czech i interweniuje często wobec kłusowników i złodziei drewna - powiedział PAP rzecznik prasowy Lasów Państwowych Michał Gzowski. Dodał, że Lasy Państwowe nie wykluczają dalszego doposażania strażników w b

## Młodzi Polacy spłacają długi. Ale rekordzista nadal ma ponad 708 tys. zł
 - [https://www.bankier.pl/wiadomosc/Mlodzi-Polacy-splacaja-dlugi-Ale-rekordzista-nadal-ma-ponad-708-tys-zl-8415967.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mlodzi-Polacy-splacaja-dlugi-Ale-rekordzista-nadal-ma-ponad-708-tys-zl-8415967.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 05:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/aca57592196345-948-568-2-70-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zaległe zobowiązania młodych między 18 a 24 rokiem życia zmniejszyły się do 853 mln zł  - wynika z danych Rejestru Dłużników BIG InfoMonitor.  Według analityków zaległości najczęściej nie spłacają młodzi mężczyźni, a rekordzista ma ponad 708 tys. zł długu.</p>

## Dach nad głową drenuje portfele studentów. Kosztowny powrót na uczelnie
 - [https://www.bankier.pl/wiadomosc/Dach-nad-glowa-drenuje-portfele-studentow-Kosztowny-powrot-na-studia-8414801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dach-nad-glowa-drenuje-portfele-studentow-Kosztowny-powrot-na-studia-8414801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/1/4e8a6bc0ec0bc4-948-568-7-0-2805-1682.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W rozpoczynającym się roku akademickim studenci i w pewnej części ich rodzice, będą musieli znacznie głębiej sięgnąć do portfeli niż w poprzednich latach. Powodem są drożejące miejsca w akademikach i w szczególności rosnące stawki ofertowe najmu mieszkań, przez które z portfeli

## Rozkład giełdowego imperium Leszka Czarneckiego. Od miliardów do milionów
 - [https://www.bankier.pl/wiadomosc/Rozklad-gieldowego-imperium-Leszka-Czarneckiego-Od-miliardow-do-milionow-8414859.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rozklad-gieldowego-imperium-Leszka-Czarneckiego-Od-miliardow-do-milionow-8414859.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/d/5a90432ca52d3f-945-560-0-0-1152-691.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przymusowa restrukturyzacja Getin Noble Banku oznacza, że umorzono jego akcje. Akcjonariusze kolejny raz na spółkach związanych z biznesmenem stracili swój kapitał. Na parkiecie jest coraz mniej spółek kontrolowanych przez Leszka Czarneckiego, a jedna z nich chce wypłacić po 1 z

## Podwyżki cen dławią rozwój małych i średnich firm
 - [https://www.bankier.pl/wiadomosc/95-proc-malych-i-srednich-firm-odczulo-wzrost-cen-8415963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/95-proc-malych-i-srednich-firm-odczulo-wzrost-cen-8415963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 04:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/082c878fdf440c-948-568-0-171-3120-1871.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost cen produktów i usług niezbędnych do prowadzenia działalności odczuło 95 proc. przedsiębiorców z sektora MŚP - wynika z badania „Zakupy firmowe”. Najczęściej wśród drożejących produktów firmy wymieniają paliwo i opłaty za media.</p>

## Były prezydent wygrał I turę wyborów prezydenckich w Brazylii
 - [https://www.bankier.pl/wiadomosc/Byly-prezydent-wygral-I-ture-wyborow-prezydenckich-w-Brazylii-8415955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Byly-prezydent-wygral-I-ture-wyborow-prezydenckich-w-Brazylii-8415955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-03 03:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/03ef649c3c91cf-945-567-172-221-1168-701.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W pierwszej turze wyborów prezydenckich w Brazylii zwyciężył były lewicowy prezydent tego kraju w latach 2003-2011, 76-letni Luiz Inacio Lula da Silva, zdobywając po przeliczeniu 98,8 proc. głosów poparcie 48,1 proc. uczestników wyborów. Jego rywal, urzędujący prezydent Jair


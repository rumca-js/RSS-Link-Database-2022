# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Death By Digit - JRE Toons
 - [https://www.youtube.com/watch?v=i4VaCDP3WF8](https://www.youtube.com/watch?v=i4VaCDP3WF8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-10-03 00:00:00+00:00

Another hilarious moment animated by PaulyToon from the Joe Rogan Experience #1731 with Theo Von - https://open.spotify.com/episode/3xJSIzORikzIgxvbDSngbp?si=8iLRSdvLSruT3BCr4wSeAA

## Toilet Water Moment - JRE Toons
 - [https://www.youtube.com/watch?v=eoBifsp3O-I](https://www.youtube.com/watch?v=eoBifsp3O-I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-10-03 00:00:00+00:00

Another hilarious moment animated by PaulyToon from the Joe Rogan Experience #1712 with Bert Kreischer - https://open.spotify.com/episode/4Xhq11yyTv2ERENLdlJN3u?si=0QVeHL2QRwinCpEF7tflsQ


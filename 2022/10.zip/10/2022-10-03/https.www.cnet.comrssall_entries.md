# Source:CNET, URL:https://www.cnet.com/rss/all/, language:en-US

## Japan Issues Emergency Alert After North Korean Missile Launch     - CNET
 - [https://www.cnet.com/culture/japan-issues-emergency-alert-after-north-korean-missile-launch/#ftag=CADf328eec](https://www.cnet.com/culture/japan-issues-emergency-alert-after-north-korean-missile-launch/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 23:51:00+00:00

A missile launched by North Korea on Tuesday morning local time flew over the island of Hokkaido, triggering an emergency alert to 5 million residents.

## Netflix: The 50 Absolute Best TV Shows to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/netflix-the-50-absolute-best-tv-series-to-watch-now/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/netflix-the-50-absolute-best-tv-series-to-watch-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 23:36:00+00:00

This week, it's time to watch Midnight Mass creator Mike Flanagan's new series The Midnight Club.

## Peloton to Put Its Bikes in All Hilton-Branded Hotels in the US     - CNET
 - [https://www.cnet.com/health/fitness/peloton-to-put-its-bikes-in-all-hilton-branded-hotels-in-the-us/#ftag=CADf328eec](https://www.cnet.com/health/fitness/peloton-to-put-its-bikes-in-all-hilton-branded-hotels-in-the-us/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 23:20:00+00:00

Company says nearly all 5,400 hotels in its US portfolio will have at least one of the exercise bikes by the end of the year.

## When Is FAFSA Due for 2023-24? File for College Financial Aid Early     - CNET
 - [https://www.cnet.com/personal-finance/when-is-fafsa-due-for-2023-24-file-for-college-financial-aid-early/#ftag=CADf328eec](https://www.cnet.com/personal-finance/when-is-fafsa-due-for-2023-24-file-for-college-financial-aid-early/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 23:05:00+00:00

Complete your FAFSA form ASAP to qualify for the most money possible.

## These Types of Student Loans Don't Qualify for Forgiveness     - CNET
 - [https://www.cnet.com/personal-finance/loans/these-types-of-student-loans-are-not-eligible-for-forgiveness/#ftag=CADf328eec](https://www.cnet.com/personal-finance/loans/these-types-of-student-loans-are-not-eligible-for-forgiveness/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 23:00:07+00:00

New guidance from the Biden administration narrows which loans are eligible.

## Samsung Plans to Extend a Key Tech Lead for Faster, Smaller Processors     - CNET
 - [https://www.cnet.com/tech/mobile/samsung-plans-to-extend-a-key-tech-lead-for-faster-smaller-processors/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/samsung-plans-to-extend-a-key-tech-lead-for-faster-smaller-processors/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 23:00:02+00:00

Samsung's plans for chipmaking progress now extend to 2027, an indication that Moore's Law is still ticking.

## Are Particle Physicists Wasting Time Inventing New Particles? No, but It's Complicated     - CNET
 - [https://www.cnet.com/science/are-particle-physicists-wasting-time-inventing-new-particles-no-but-its-complicated/#ftag=CADf328eec](https://www.cnet.com/science/are-particle-physicists-wasting-time-inventing-new-particles-no-but-its-complicated/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 22:38:45+00:00

Commentary: New particles haven't been discovered for decades but particle physicists are still making progress.

## Hidden Amazon Coupons: This Little-Known Page Can Save You Money     - CNET
 - [https://www.cnet.com/tech/hidden-amazon-coupons-this-little-known-page-can-save-you-money/#ftag=CADf328eec](https://www.cnet.com/tech/hidden-amazon-coupons-this-little-known-page-can-save-you-money/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 22:30:00+00:00

With just a few clicks, you can find discounts on a ton of items sold on Amazon.

## The Absolute Best Sci-Fi TV Shows on Prime Video     - CNET
 - [https://www.cnet.com/culture/entertainment/the-absolute-best-sci-fi-tv-shows-on-prime-video/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-absolute-best-sci-fi-tv-shows-on-prime-video/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 22:28:30+00:00

Prime Video is hosting a ton of excellent sci-fi series worth committing a binge to. These are the very best...

## 2023 Audi R8 GT Is a 612-HP V10 Swan Song     - CNET
 - [https://www.cnet.com/roadshow/news/2023-audi-r8-gt-rwd-v10-debut/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2023-audi-r8-gt-rwd-v10-debut/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 22:02:03+00:00

Only 333 of these rear-wheel-drive supercars will be sold worldwide.

## 'House of the Dragon' Episode 7 Recap: Say Uncle     - CNET
 - [https://www.cnet.com/culture/entertainment/house-of-the-dragon-episode-7-recap-say-uncle/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/house-of-the-dragon-episode-7-recap-say-uncle/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 22:01:00+00:00

Sunday's episode of the Game of Thrones prequel was the wildest so far.

## Amazon Subscribe and Save: An Easy Way to Buy Your Essentials at a Discount     - CNET
 - [https://www.cnet.com/deals/amazon-subscribe-and-save-an-easy-way-to-buy-your-essentials-at-a-discount/#ftag=CADf328eec](https://www.cnet.com/deals/amazon-subscribe-and-save-an-easy-way-to-buy-your-essentials-at-a-discount/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 22:00:06+00:00

This hidden Amazon shopping tip makes saving money simple. Here's how it works.

## Why I Don't Own an Electric Car (Yet)     - CNET
 - [https://www.cnet.com/roadshow/news/why-i-dont-own-an-electric-car-yet/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/why-i-dont-own-an-electric-car-yet/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 20:34:12+00:00

Commentary: People are surprised that I don't own an EV, but here are my reasons, some admittedly better than others.

## What We Expect To See In the Pixel 7 and Pixel Watch video     - CNET
 - [https://www.cnet.com/videos/what-we-expect-to-see-in-the-pixel-7-and-pixel-watch/#ftag=CADf328eec](https://www.cnet.com/videos/what-we-expect-to-see-in-the-pixel-7-and-pixel-watch/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 20:25:40+00:00

Google is set to unveil the Pixel 7 lineup and the Pixel Watch. Here's what we know so far about those long-awaited gadgets.

## Yes, You Can Make Money From That Car Sitting in Your Garage. Here's How     - CNET
 - [https://www.cnet.com/personal-finance/yes-you-can-make-money-from-that-car-sitting-in-your-garage-heres-how/#ftag=CADf328eec](https://www.cnet.com/personal-finance/yes-you-can-make-money-from-that-car-sitting-in-your-garage-heres-how/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 20:15:02+00:00

If you have a spare car or one that you don't use much, consider renting it out online to gig drivers or tourists.

## Google's Pixel 7 Event: New Phones, Watch and More to Expect     - CNET
 - [https://www.cnet.com/tech/mobile/googles-pixel-7-event-new-phones-watch-and-more-to-expect/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/googles-pixel-7-event-new-phones-watch-and-more-to-expect/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 20:08:12+00:00

The company is set to unveil the Pixel 7 phone lineup and the Pixel Watch on Thursday. Here's what we know so far about those long-awaited gadgets.

## 'Andor' Release Schedule: When Does Episode 5 Arrive on Disney Plus?     - CNET
 - [https://www.cnet.com/culture/entertainment/andor-release-schedule-when-does-episode-5-arrive-on-disney-plus/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/andor-release-schedule-when-does-episode-5-arrive-on-disney-plus/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 20:00:07+00:00

We know all the release dates and times for the eight remaining episodes of the intense Star Wars prequel show.

## How Cold Weather Affects Your Breathing and What to Do About It     - CNET
 - [https://www.cnet.com/health/medical/how-cold-weather-affects-your-breathing-and-what-to-do-about-it/#ftag=CADf328eec](https://www.cnet.com/health/medical/how-cold-weather-affects-your-breathing-and-what-to-do-about-it/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 20:00:02+00:00

Cold weather can lead to runny noses, and not just because of flu season.

## Some Brie, Camembert Cheeses Recalled Over Listeria Concerns     - CNET
 - [https://www.cnet.com/health/nutrition/some-brie-camembert-cheeses-recalled-over-listeria-concerns/#ftag=CADf328eec](https://www.cnet.com/health/nutrition/some-brie-camembert-cheeses-recalled-over-listeria-concerns/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 19:17:00+00:00

Recalled soft cheeses include different brand names sold at Safeway, Whole Foods and other retailers.

## NFL 2022: How to Watch, Stream Rams vs. 49ers, ManningCast and Monday Night Football Without Cable     - CNET
 - [https://www.cnet.com/tech/services-and-software/nfl-2022-how-to-watch-stream-rams-vs-49ers-manningcast-and-monday-night-football-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/nfl-2022-how-to-watch-stream-rams-vs-49ers-manningcast-and-monday-night-football-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 19:13:15+00:00

NFC West rivals Los Angeles and San Francisco wrap up Week 4 tonight on ESPN. You can also watch the ManningCast on ESPN2.

## Use This New Sleep Device to Fall Asleep Tonight     - CNET
 - [https://www.cnet.com/health/sleep/use-this-new-sleep-device-to-fall-asleep-tonight/#ftag=CADf328eec](https://www.cnet.com/health/sleep/use-this-new-sleep-device-to-fall-asleep-tonight/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 19:00:06+00:00

Sleep tech without harmful blue light to help you sleep.

## Tracking Your Health When You Have a Chronic Illness: The Ultimate Guide     - CNET
 - [https://www.cnet.com/health/medical/tracking-your-health-with-a-chronic-illness-the-ultimate-guide/#ftag=CADf328eec](https://www.cnet.com/health/medical/tracking-your-health-with-a-chronic-illness-the-ultimate-guide/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 19:00:02+00:00

There are a ton of different health metrics you can choose to track, but not all of them are easily measured at home.

## Knowing Your Blood Type Is Useful: 3 Easy Ways to Find Out Yours     - CNET
 - [https://www.cnet.com/health/medical/knowing-your-blood-type-is-useful-3-easy-ways-to-find-out-yours/#ftag=CADf328eec](https://www.cnet.com/health/medical/knowing-your-blood-type-is-useful-3-easy-ways-to-find-out-yours/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 19:00:00+00:00

If you don't already know your blood type, you should find out ASAP.

## National Taco Day 2022: 19 Places Offering Free Tacos and Other Tasty Deals     - CNET
 - [https://www.cnet.com/culture/national-taco-day-2022-free-tacos-taco-bell-del-taco-chevys/#ftag=CADf328eec](https://www.cnet.com/culture/national-taco-day-2022-free-tacos-taco-bell-del-taco-chevys/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 19:00:00+00:00

Oct. 4 is the ultimate Taco Tuesday.

## Twitter Rolls Out Edit Button to Subscribers in Canada, Australia and New Zealand     - CNET
 - [https://www.cnet.com/news/social-media/twitter-rolls-out-edit-button-to-subscribers-in-canada-australia-and-new-zealand/#ftag=CADf328eec](https://www.cnet.com/news/social-media/twitter-rolls-out-edit-button-to-subscribers-in-canada-australia-and-new-zealand/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 18:55:41+00:00

The feature is part of the company's subscription service Twitter Blue.

## Student Debt Loan Forgiveness FAQ: Who Gets Relief, How Much Is Canceled and When Will It Happen?     - CNET
 - [https://www.cnet.com/personal-finance/loans/student-debt-loan-forgiveness-faq-who-gets-relief-how-much-is-canceled-and-when-will-it-happen/#ftag=CADf328eec](https://www.cnet.com/personal-finance/loans/student-debt-loan-forgiveness-faq-who-gets-relief-how-much-is-canceled-and-when-will-it-happen/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 18:55:02+00:00

Get all the details on President Biden's plan for student loan debt forgiveness.

## Best Roku Device Deals: Save $10 on a Roku Express 4K Plus or Roku Ultra and More     - CNET
 - [https://www.cnet.com/deals/best-roku-device-deals/#ftag=CADf328eec](https://www.cnet.com/deals/best-roku-device-deals/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 18:43:43+00:00

See the best prices on streamers that use our favorite streaming platform for TV, movies and music.

## NASA Snaps Sun Spitting Out a Big, Dazzling X1 Solar Flare     - CNET
 - [https://www.cnet.com/science/space/nasa-snaps-sun-spitting-out-a-dazzling-x1-solar-flare/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-snaps-sun-spitting-out-a-dazzling-x1-solar-flare/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 18:19:00+00:00

The sun is so hot right now.

## Horizon Zero Dawn Remaster Reportedly in Development for PS5     - CNET
 - [https://www.cnet.com/tech/gaming/horizon-zero-dawn-remaster-reportedly-in-development-for-ps5/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/horizon-zero-dawn-remaster-reportedly-in-development-for-ps5/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 18:10:00+00:00

A spin-off multiplayer game is also reportedly coming.

## New 'Black Panther: Wakanda Forever' Trailer Reveals Namor's Threat     - CNET
 - [https://www.cnet.com/culture/entertainment/new-black-panther-wakanda-forever-trailer-reveals-namors-threat/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/new-black-panther-wakanda-forever-trailer-reveals-namors-threat/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 17:56:00+00:00

The 30th MCU movie hits theaters Nov. 11.

## I Don't Own an Electric Car and Here's Why video     - CNET
 - [https://www.cnet.com/roadshow/videos/i-dont-own-an-electric-car-and-heres-why/#ftag=CADf328eec](https://www.cnet.com/roadshow/videos/i-dont-own-an-electric-car-and-heres-why/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 17:54:10+00:00

Your friends with Teslas probably think you're an idiot, but you're actually smart to wait a bit longer.

## Grab 6 Pokemon TCG 25th Anniversary Cards for $35 or Score 12 for $63     - CNET
 - [https://www.cnet.com/deals/grab-6-pokemon-tcg-25th-anniversary-cards-for-35-or-score-12-for-63/#ftag=CADf328eec](https://www.cnet.com/deals/grab-6-pokemon-tcg-25th-anniversary-cards-for-35-or-score-12-for-63/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 17:41:00+00:00

Save up to $105 on this collection of oversized cards featuring first partners from the Kalos region of Pokemon.

## 'Ironheart': What to Know About the Upcoming Disney Plus Series     - CNET
 - [https://www.cnet.com/culture/entertainment/ironheart-what-to-know-about-the-upcoming-disney-plus-series/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/ironheart-what-to-know-about-the-upcoming-disney-plus-series/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 17:03:08+00:00

Before Dominique Thorne stars in the Disney Plus Marvel series Ironheart, she'll appear in Black Panther: Wakanda Forever​.

## iPhone Battery Meter in iOS 16: Why Apple Is Making a Change     - CNET
 - [https://www.cnet.com/tech/mobile/apple-listened-to-iphone-fans-why-the-ios-16-battery-meter-is-changing/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/apple-listened-to-iphone-fans-why-the-ios-16-battery-meter-is-changing/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 16:55:02+00:00

Apple heard the complaints about the iPhone's battery icon in iOS 16 and plans to release a design fix soon.

## Is Your Android Being Tracked by an AirTag? Here's How to Find Out     - CNET
 - [https://www.cnet.com/tech/mobile/is-your-android-being-tracked-by-an-airtag-heres-how-to-find-out/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/is-your-android-being-tracked-by-an-airtag-heres-how-to-find-out/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 16:50:02+00:00

This third-party app from Apple will let you know if you're being followed by a rogue AirTag.

## Sony Orders 2 Million PlayStation VR2 Headsets, Report Says     - CNET
 - [https://www.cnet.com/tech/gaming/sony-orders-2-million-playstation-vr2-headsets-report-says/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/sony-orders-2-million-playstation-vr2-headsets-report-says/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 16:45:00+00:00

The video game company is going all in on its new virtual reality headset, according to Bloomberg.

## HBO Max: The 21 Absolute Best Movies to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/hbo-max-the-21-absolute-best-movies-to-watch-in-october/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/hbo-max-the-21-absolute-best-movies-to-watch-in-october/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 16:32:00+00:00

This October, check out Edgar Wright's 2021 horror-thriller Last Night in Soho.

## Amazon Discounts Echo, Fire TV and More by Up to 59% Ahead of Prime Early Access Sale     - CNET
 - [https://www.cnet.com/deals/amazon-discounts-echo-fire-tv-more-by-up-to-59-percent-ahead-prime-early-access-sale/#ftag=CADf328eec](https://www.cnet.com/deals/amazon-discounts-echo-fire-tv-more-by-up-to-59-percent-ahead-prime-early-access-sale/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 16:21:00+00:00

This limited-time sale makes Amazon's highly rated devices even more affordable than usual. Grab some today.

## Firefly Alpha Rocket Finally Makes It to Orbit     - CNET
 - [https://www.cnet.com/science/space/firefly-alpha-rocket-finally-makes-it-to-orbit/#ftag=CADf328eec](https://www.cnet.com/science/space/firefly-alpha-rocket-finally-makes-it-to-orbit/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 16:20:00+00:00

Thirteen months after the space startup's first attempt ended in an explosion, it has declared "100% mission success" for Saturday's launch.

## Yes, You Can Run Microsoft Office on a Chromebook. Here's How     - CNET
 - [https://www.cnet.com/tech/computing/yes-you-can-download-microsoft-office-on-a-chromebook/#ftag=CADf328eec](https://www.cnet.com/tech/computing/yes-you-can-download-microsoft-office-on-a-chromebook/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 03:00:02+00:00

Downloading and installing Office 365 apps on a Chromebook is quick and easy with these steps.

## NASA, SpaceX Look at Sending Crew Dragon to Boost Hubble Telescope's Life     - CNET
 - [https://www.cnet.com/science/space/nasa-spacex-look-at-sending-crew-dragon-to-boost-hubble-telescopes-life/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-spacex-look-at-sending-crew-dragon-to-boost-hubble-telescopes-life/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 01:56:00+00:00

The telescope could get a boost, but the concept is only in an early study stage.

## How to Watch SpaceX Launch NASA Astronauts on Crew-5 Mission This Week     - CNET
 - [https://www.cnet.com/science/space/how-to-watch-spacex-launch-nasa-astronauts-on-crew-5-mission-this-week/#ftag=CADf328eec](https://www.cnet.com/science/space/how-to-watch-spacex-launch-nasa-astronauts-on-crew-5-mission-this-week/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 01:53:00+00:00

A crew of four is set to blast off from Florida.

## Watch YouTuber Dream Finally Reveal His Face     - CNET
 - [https://www.cnet.com/culture/internet/watch-youtuber-dream-finally-reveal-his-face/#ftag=CADf328eec](https://www.cnet.com/culture/internet/watch-youtuber-dream-finally-reveal-his-face/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 01:52:00+00:00

The Minecraft player has more than 30 million subscribers. Now they finally know what he looks like.

## McDonald's Beloved Halloween Boo Buckets: Return Is Looking More Likely     - CNET
 - [https://www.cnet.com/culture/mcdonalds-beloved-halloween-boo-buckets-return-is-looking-more-likely/#ftag=CADf328eec](https://www.cnet.com/culture/mcdonalds-beloved-halloween-boo-buckets-return-is-looking-more-likely/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 01:41:00+00:00

There's more news about the possibility that the fast-food chain could be bringing back this Happy Meal nostalgia.

## Your Router Is Collecting Data. Here's What to Know, and How to Protect Your Privacy     - CNET
 - [https://www.cnet.com/news/your-router-is-collecting-data-heres-what-to-know-and-how-to-protect-your-privacy/#ftag=CADf328eec](https://www.cnet.com/news/your-router-is-collecting-data-heres-what-to-know-and-how-to-protect-your-privacy/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 01:00:02+00:00

Wi-Fi router companies say they don't track the websites you visit, but all of them collect and share some user data.

## 'House of the Dragon' Episode 7 Recap: A Funeral and a Wedding     - CNET
 - [https://www.cnet.com/culture/entertainment/house-of-the-dragon-episode-7-recap-a-funeral-and-a-wedding/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/house-of-the-dragon-episode-7-recap-a-funeral-and-a-wedding/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-03 01:00:00+00:00

Sunday's episode of the Game of Thrones prequel was the wildest yet.


# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## The Official Ryan
 - [https://www.youtube.com/watch?v=O9x3ElUx4bk](https://www.youtube.com/watch?v=O9x3ElUx4bk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2022-10-03 00:00:00+00:00

So happy to have this motherfu**er as our spokesman. #AviationGin


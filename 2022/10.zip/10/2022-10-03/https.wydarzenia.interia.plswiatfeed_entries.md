# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Ukraina prosi o rakiety ATACMS. Deklarują, że USA będą mieć wgląd w listę celów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-prosi-o-rakiety-atacms-deklaruja-ze-usa-beda-miec-wg,nId,6324725](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-prosi-o-rakiety-atacms-deklaruja-ze-usa-beda-miec-wg,nId,6324725)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2022-10-03 21:51:17+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-prosi-o-rakiety-atacms-deklaruja-ze-usa-beda-miec-wg,nId,6324725"><img align="left" alt="Ukraina prosi o rakiety ATACMS. Deklarują, że USA będą mieć wgląd w listę celów" src="https://i.iplsc.com/ukraina-prosi-o-rakiety-atacms-deklaruja-ze-usa-beda-miec-wg/000G5JYYINS31T6A-C321.jpg" /></a>Systemy ATACMS od dawna są na szczycie ukraińskiej &quot;listy życzeń&quot;. Jednak pomimo próśb, administracja pre

## Szefowa MSZ Niemiec: Rozliczaniu się nie może być i nie będzie końca
 - [https://wydarzenia.interia.pl/zagranica/news-szefowa-msz-niemiec-rozliczaniu-sie-nie-moze-byc-i-nie-bedzi,nId,6324574](https://wydarzenia.interia.pl/zagranica/news-szefowa-msz-niemiec-rozliczaniu-sie-nie-moze-byc-i-nie-bedzi,nId,6324574)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2022-10-03 16:47:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szefowa-msz-niemiec-rozliczaniu-sie-nie-moze-byc-i-nie-bedzi,nId,6324574"><img align="left" alt="Szefowa MSZ Niemiec: Rozliczaniu się nie może być i nie będzie końca" src="https://i.iplsc.com/szefowa-msz-niemiec-rozliczaniu-sie-nie-moze-byc-i-nie-bedzi/000G5IVRNT6CAF90-C321.jpg" /></a>- Rozliczenie się i pamięć o niezmierzonych cierpieniach, jakie Niemcy wyrządziły ludziom w Polsce, pozostają ważnymi zadaniami dla naszego i przyszłych poko

## Turcja. Nie żyje muzyk Onur Sener. Miał nie spełnić prośby publiczności
 - [https://wydarzenia.interia.pl/zagranica/news-turcja-nie-zyje-muzyk-onur-sener-mial-nie-spelnic-prosby-pub,nId,6324405](https://wydarzenia.interia.pl/zagranica/news-turcja-nie-zyje-muzyk-onur-sener-mial-nie-spelnic-prosby-pub,nId,6324405)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2022-10-03 16:37:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-turcja-nie-zyje-muzyk-onur-sener-mial-nie-spelnic-prosby-pub,nId,6324405"><img align="left" alt="Turcja. Nie żyje muzyk Onur Sener. Miał nie spełnić prośby publiczności" src="https://i.iplsc.com/turcja-nie-zyje-muzyk-onur-sener-mial-nie-spelnic-prosby-pub/000G5IIN48ULD4H1-C321.jpg" /></a>Muzyk Onur Sener zmarł w wyniku obrażeń, których doznał po ataku na koncercie. Jak informują media, piosenkarz miał nie spełnić muzycznej prośby od public


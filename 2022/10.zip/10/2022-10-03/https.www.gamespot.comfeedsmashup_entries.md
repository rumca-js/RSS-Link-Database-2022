# Source:GameSpot, URL:https://www.gamespot.com/feeds/mashup, language:en-US

## God Of War: Ragnarok Leak Reveals Possible Playtime
 - [https://www.gamespot.com/articles/god-of-war-ragnarok-leak-reveals-possible-playtime/1100-6507981/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/god-of-war-ragnarok-leak-reveals-possible-playtime/1100-6507981/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 21:56:00+00:00

<p>A new leak revealed a possible approximate playtime for God of War: Ragnarok that indicates the game could include more side quests than its predecessor.</p><p>According to a report from <a href="https://insider-gaming.com/god-of-war-ragnarok-40-hours/">Insider Gaming</a>, God of War: Ragnarok will take approximately 40 hours to complete. To be clear, this includes side quests. A straight shot through the main story will take around 20 hours. The report also claims that around three and a hal

## Horizon Zero Dawn Reportedly Getting A PS5 Remake | GameSpot News
 - [https://www.gamespot.com/videos/horizon-zero-dawn-reportedly-getting-a-ps5-remake-gamespot-news/2300-6459680/](https://www.gamespot.com/videos/horizon-zero-dawn-reportedly-getting-a-ps5-remake-gamespot-news/2300-6459680/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 21:32:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1574/15746725/4043398-20221003_horizonzerodawnremake_newsv3.jpg" width="480" /> The first Horizon game is potentially getting remade, along with the franchise gaining multiplayer, the PS5 has been jailbroken, and 2 million PSVR2 units are reportedly being made.

## Ubisoft, Bungie, And Others Announce Plans To Salvage Stadia Games
 - [https://www.gamespot.com/articles/ubisoft-bungie-and-others-announce-plans-to-salvage-stadia-games/1100-6507980/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/ubisoft-bungie-and-others-announce-plans-to-salvage-stadia-games/1100-6507980/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 21:03:00+00:00

<p dir="ltr">Google Stadia will soon <a href="https://www.gamespot.com/articles/google-stadia-is-shutting-down-on-january-18-2023/1100-6507919/">die</a> an ignominous death, but several large game studios are making plans to move user accounts, data, and even games themselves from the doomed game streaming service. These developers include Ubisoft, Bungie, and IO Interactive.</p><p dir="ltr">On Friday, Ubisoft support stated that the company is working to bring games owned through Stadia to PC t

## The 7 Most Sinister And Scary, Slow Burn Horror Films To Watch This Halloween
 - [https://www.gamespot.com/gallery/the-7-most-sinister-and-scary-slow-burn-horror-films-to-watch-this-halloween/2900-4367/](https://www.gamespot.com/gallery/the-7-most-sinister-and-scary-slow-burn-horror-films-to-watch-this-halloween/2900-4367/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 20:14:00+00:00

<p><img src="https://www.gamespot.com/a/uploads/scale_large/1727/17277841/4043383-rosemarys_baby_featured_start.jpg" /><br /><h3><p> </p><p dir="ltr">Horror films can really be anything, which is more of a reflection on us as people and less on movie studios. It’s wonderful our fears can manifest themselves in such a variety of sub-genres but there’s nothing quite like dread.</p><p dir="ltr">A sensation unlike any other that’s filled and festering with the open wounds of our biggest fears and in

## Get 8 Steam Deck-Ready Games For $10
 - [https://www.gamespot.com/articles/get-8-steam-deck-ready-games-for-10/1100-6507979/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/get-8-steam-deck-ready-games-for-10/1100-6507979/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 19:32:00+00:00

<p>Fanatical has yet another new build-your-own bundle deal available, this time for up to 8 Steam games for just $10 through the Play on the Go Bundle.</p><div class="norewrite" title="">           <a href="https://www.anrdoezrs.net/links/9020176/type/dlg/sid/[subid_value]/https://www.fanatical.com/en/pick-and-mix/build-your-own-play-on-the-go-bundle-2">See at Fanatical</a> </div><p dir="ltr"> </p><p dir="ltr">As the name implies, the bundle lets you pick from 16 portable-friendly games certifi

## Loki Writer Michael Waldron Hired For Avengers: Secret Wars - Report
 - [https://www.gamespot.com/articles/loki-writer-michael-waldron-hired-for-avengers-secret-wars-report/1100-6507978/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/loki-writer-michael-waldron-hired-for-avengers-secret-wars-report/1100-6507978/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 19:25:00+00:00

<p dir="ltr">Michael Waldron (Loki executive producer, Multiverse Of Madness writer, and creator of Starz's Heels) has reportedly been hired to write Avengers: Secret Wars. According to <a href="https://deadline.com/2022/10/avengers-secret-wars-michael-waldron-marvel-studios-1235127065/">Deadline's</a> unnamed sources, Waldron "looks to be in line" for the upcoming MCU project.</p><p dir="ltr">Along with Avengers: The Kang Dynasty, Secret Wars <a href="https://www.gamespot.com/articles/two-new-a

## Fallout 25th Anniversary Plans Include Fallout 76 Free Week And A Big Fallout Shelter Update
 - [https://www.gamespot.com/articles/fallout-25th-anniversary-plans-include-fallout-76-free-week-and-a-big-fallout-shelter-update/1100-6507977/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/fallout-25th-anniversary-plans-include-fallout-76-free-week-and-a-big-fallout-shelter-update/1100-6507977/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 19:09:00+00:00

<p>The original Fallout was released in October 1997, making the franchise 25 years old this month. Bethesda is celebrating the milestone with a series of events across the franchise all month long.</p><p>To kick things off, Fallout 76 will be free for everyone from October 4-11. This will let players check out the entire game, including the newly launched The Pitt update, at no cost.</p><figure style="width: 1224px;"><a href="https://www.gamespot.com/a/uploads/original/1179/11799911/4043348-scr

## Apex Legends Mobile - Aftershow Patch Notes
 - [https://www.gamespot.com/articles/apex-legends-mobile-aftershow-patch-notes/1100-6507976/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/apex-legends-mobile-aftershow-patch-notes/1100-6507976/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 18:53:00+00:00

<p><a href="https://www.gamespot.com/games/apex-legends-mobile/">Apex Legends Mobile</a>'s upcoming Aftershow update is almost here, with a launch date set for October 4 at 5 PM PT / 8 PM ET. The announcement that the game's sophomore season is getting a third battle pass came as quite a surprise (previous seasons have had two battle passes each), leaving fans wondering what exactly the Aftershow update consists of. Today, players' questions were answered when the game's developers posted a link

## Bleach: Thousand-Year Blood War Anime To Stream On Hulu, Disney Plus
 - [https://www.gamespot.com/articles/bleach-thousand-year-blood-war-anime-to-stream-on-hulu-disney-plus/1100-6507975/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/bleach-thousand-year-blood-war-anime-to-stream-on-hulu-disney-plus/1100-6507975/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 18:34:00+00:00

<p> </p><p dir="ltr">VIZ Media has announced that the Bleach: Thousand-Year Blood War anime will be exclusively streaming on Disney+ and Hulu. According to a release, Bleach will air on Disney+ internationally, and come to Hulu in the US starting October 10.</p><p dir="ltr">The entertainment company also revealed that the anime’s English dub will feature many returning cast members, including Johnny Yong Bosch, Michelle Ruff, and Derek Stephen Prince. (The show’s returning Japanese cast also inc

## Need For Speed Game Reveal Teased By EA, Could Happen Very Soon
 - [https://www.gamespot.com/articles/need-for-speed-game-reveal-teased-by-ea-could-happen-very-soon/1100-6507974/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/need-for-speed-game-reveal-teased-by-ea-could-happen-very-soon/1100-6507974/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 18:12:00+00:00

<p>Electronic Arts is reportedly primed to announce the next Need for Speed game soon. In response to the rumor that the publisher will announce the next entry in its popular racing series this week, the publisher shared the eyes emoji. This is normally used to tease something that may be real.</p><p>Tom Henderson for <a href="https://insider-gaming.com/need-for-speed-unbound-reveal/">Insider Gaming</a> reported on September 29 that a reveal for the next Need for Speed game, which is rumored to 

## Halo Could Be Making The Jump From Slipspace To Unreal Engine - Report
 - [https://www.gamespot.com/articles/halo-could-be-making-the-jump-from-slipspace-to-unreal-engine-report/1100-6507973/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/halo-could-be-making-the-jump-from-slipspace-to-unreal-engine-report/1100-6507973/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 17:54:00+00:00

<p>343 Industries' self-made Slipspace engine used for <a href="https://www.gamespot.com/games/halo-infinite/">Halo Infinite</a> could be shelved in favor of Epic Games' popular Unreal engine, according to a <a href="https://twitter.com/JeremyPenter/status/1576617038206099456?s=20&amp;t=noPT46TUm4Ne6lbbbDarDg">report</a> from journalist Jeremy Penter.</p><p dir="ltr">According to Penter, Halo will "for sure" switch to Unreal. Penter states that the information has been confirmed by "many sources

## LOTR: Rings Of Power Season 2 Starts Production In UK, Ancient Elf Cirdan Joining The Cast
 - [https://www.gamespot.com/articles/lotr-rings-of-power-season-2-starts-production-in-uk-ancient-elf-cirdan-joining-the-cast/1100-6507972/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/lotr-rings-of-power-season-2-starts-production-in-uk-ancient-elf-cirdan-joining-the-cast/1100-6507972/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 17:34:00+00:00

<p>Amazon Studios' fantasy drama The Lord of the Rings: The Rings of Power has begun production on its second season. According to <a href="https://www.hollywoodreporter.com/tv/tv-news/the-rings-of-power-season-2-filming-1235231978/">The Hollywood Reporter</a>, production is now underway at Bray Studios outside London. There will reportedly be eight episodes in Season 2.</p><p>Filming taking place in the UK is a major change for the series, as Season 1 was filmed in New Zealand. The country is s

## Get Microsoft Office 2021 For Only $36
 - [https://www.gamespot.com/articles/get-microsoft-office-2021-for-only-36/1100-6507971/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/get-microsoft-office-2021-for-only-36/1100-6507971/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 17:27:00+00:00

<p>Microsoft Office includes some of the most popular and frequently used software on the planet. It also carries a high price tag, with a single license costing $349 for Microsoft Word, Excel, PowerPoint, and everything else in the Office lineup. Meanwhile, Microsoft 365 subscriptions start at $70 per year. If you need access to Microsoft Office for work or personal use and you don't mind sticking with the 2021 version for awhile, there's a cheap way to get the whole software suite right now. F

## HBO Explains Why House Of The Dragon's Latest Episode Was So Hard To See
 - [https://www.gamespot.com/articles/hbo-explains-why-house-of-the-dragons-latest-episode-was-so-hard-to-see/1100-6507966/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/hbo-explains-why-house-of-the-dragons-latest-episode-was-so-hard-to-see/1100-6507966/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 17:20:00+00:00

<p>The latest episode of HBO's House of the Dragon was very dark, and not just in terms of its subject matter. Many fans complained on social media that some scenes were literally had to see. Some wondered if this was an issue with their TVs, but in fact it was an intentional design choice, HBO has said.</p><p>There were sequences in Sunday's episode that took place during the evening, and the darkness of the scenes prompted confusion, frustration, and memes. Brendan Hodges on Twitter called att

## PlayStation Boss Allegedly Flew To Brussels To Voice Concerns Over Microsoft's Call of Duty Deal
 - [https://www.gamespot.com/articles/playstation-boss-allegedly-flew-to-brussels-to-voice-concerns-over-microsofts-call-of-duty-deal/1100-6507962/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/playstation-boss-allegedly-flew-to-brussels-to-voice-concerns-over-microsofts-call-of-duty-deal/1100-6507962/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 17:16:00+00:00

<p>PlayStation Boss Jim Ryan personally flew to Brussels last month to discuss Microsoft's plan to acquire Activision Blizzard, according to a new report.</p><p>According to <a href="https://www.dealreporter.com/login?d=1">Dealreporter</a> (via <a href="https://www.videogameschronicle.com/news/playstation-boss-jim-ryan-flew-to-brussels-to-voice-concerns-to-eu-over-xboxs-activision-deal/">VGC</a>), Ryan spoke to European Union regulators who are currently examining the proposed acquisition and vo

## Snag A Free Controller With This Xbox Series S Bundle
 - [https://www.gamespot.com/articles/snag-a-free-controller-with-this-xbox-series-s-bundle/1100-6507969/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/snag-a-free-controller-with-this-xbox-series-s-bundle/1100-6507969/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 17:07:00+00:00

<p>The Xbox Series S is arguably one of the best deals in gaming, as it offers modern visuals and performance at a friendly $300 price point. Things are even more enticing today, as you’ll find a <span class="norewrite">           <a href="https://www.ebay.com/itm/295189792861?toolid=10001&amp;mkcid=1&amp;campid=5338497749&amp;mkevt=1&amp;mkrid=711-53200-19255-0&amp;customid=[subid_value]">stellar bundle</a> </span> that includes the Xbox Series S console, two wireless Xbox controllers (one extr

## Tower Of Fantasy Is Finally Coming To Steam Later This Month
 - [https://www.gamespot.com/articles/tower-of-fantasy-is-finally-coming-to-steam-later-this-month/1100-6507970/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/tower-of-fantasy-is-finally-coming-to-steam-later-this-month/1100-6507970/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 17:04:00+00:00

<p>Those waiting for <a href="https://www.gamespot.com/games/tower-of-fantasy/">Tower of Fantasy</a> to arrive on Steam before diving into the anime MMORPG won't have to wait much longer, as publisher Level Infinite has confirmed that the free-to-play gacha game will be available to download and play on Valve's platform starting October 20.</p><p dir="ltr">The game has been available on PC via download from the official Tower of Fantasy site since its launch back in early August and is also avai

## Call Of Duty Modern Warfare 2 Preorders: Bonuses, Editions, And More
 - [https://www.gamespot.com/articles/call-of-duty-modern-warfare-2-preorders-bonuses-editions-and-more/1100-6504304/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/call-of-duty-modern-warfare-2-preorders-bonuses-editions-and-more/1100-6504304/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 16:40:00+00:00

<div class="norewrite" title="6504304 - Modern Warfare 2 Preorder Guide (top module)">    <div class="buylink__container">                                                                                                                                                                                               <div class="buylink__item">                  <div class="buylink__image-container clickable">                                            <img alt="" class="buylink__image" src="https://ww

## Get An Xbox Series X With Extra Controller For A Great Price
 - [https://www.gamespot.com/articles/get-an-xbox-series-x-with-extra-controller-for-a-great-price/1100-6507968/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/get-an-xbox-series-x-with-extra-controller-for-a-great-price/1100-6507968/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 16:37:00+00:00

<p>The Xbox Series X is much easier to find in stock today than it was last year, although worthwhile discounts are still rare for the popular product. But right now, you can purchase an <span class="norewrite">           <a href="https://www.ebay.com/itm/125355492761?toolid=10001&amp;mkcid=1&amp;campid=5338497749&amp;mkevt=1&amp;mkrid=711-53200-19255-0&amp;customid=[subid_value]">Xbox Series X console with an additional Wireless Controller</a> </span> for just $530, down from $560. And if you’r

## Steph Curry Is A Playable Character In PGA Tour 2K23
 - [https://www.gamespot.com/articles/steph-curry-is-a-playable-character-in-pga-tour-2k23/1100-6507967/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/steph-curry-is-a-playable-character-in-pga-tour-2k23/1100-6507967/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 16:02:00+00:00

<p dir="ltr">Steph Curry is well-known around the world for his golfing prowess, and that's finally translated into the world of gaming. Oh, and he's pretty good at basketball too. Today, 2K announced that the Golden State Warriors star will be a playable character in <a href="https://www.gamespot.com/games/pga-tour-2k23/">PGA Tour 2K23</a>, joining fellow celebrity guest Michael Jordan.</p><div><blockquote align="center" class="twitter-tweet"><p dir="ltr">His swing's as clean as his jumper! 👨‍🍳

## Black Panther: Wakanda Forever Trailer Breakdown
 - [https://www.gamespot.com/gallery/black-panther-wakanda-forever-trailer-breakdown/2900-4365/](https://www.gamespot.com/gallery/black-panther-wakanda-forever-trailer-breakdown/2900-4365/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2022-10-03 15:52:00+00:00

<p><img src="https://www.gamespot.com/a/uploads/scale_large/1562/15626911/4043061-0.jpg" /><br /><h3><p dir="ltr">A new trailer for <a href="https://www.gamespot.com/articles/new-black-panther-2-trailer-shows-off-someone-else-in-the-suit-and-ironheart/1100-6507956/">Black Panther: Wakanda Forever</a> has arrived, and guess what? It still looks fantastic. Much like the last trailer, we're still left with quite a bit of mystery surrounding the film. But we did learn a few more things.</p><p dir="l


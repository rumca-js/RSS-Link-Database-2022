# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Nioh - The Silver Mine Writhes | The Editor's Hour
 - [https://www.youtube.com/watch?v=QCPUMaF9t4s](https://www.youtube.com/watch?v=QCPUMaF9t4s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-04 00:00:00+00:00

For The Editor's Hour today, Nick's starting his playthrough of NIOH..

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Overwatch 2 (PVP) | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=_KocS-MlEcg](https://www.youtube.com/watch?v=_KocS-MlEcg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-04 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

KC Nwosu reviews Overwatch 2, developed by Blizzard Entertainment.

Overwatch 2 free to play: https://playoverwatch.com/en-us/

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Ravenbound Pushes Roguelikes Ahead by Returning to Its Roots | Preview
 - [https://www.youtube.com/watch?v=Z2qkU72libY](https://www.youtube.com/watch?v=Z2qkU72libY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-04 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

Sebastian Ruiz previews Ravenbound, developed by System Reaction.

Ravenbound on Steam: https://store.steampowered.com/app/1307660/Ravenbound/

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## We Finally Got Some Real Action and Answers in The Rings of Power | The Recap
 - [https://www.youtube.com/watch?v=jx-bf6ylQI8](https://www.youtube.com/watch?v=jx-bf6ylQI8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-04 00:00:00+00:00

This week on The Recap, we discuss Andor, The Rings of Power and House of the Dragon. Nick has also returned to Peaky Blinders to wrap up Seasons 5 and 6.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## ECHO's AI Learn from Your Actions in this Weird Action Adventure | Hidden Gems
 - [https://www.youtube.com/watch?v=IRrVhZ0V9kU](https://www.youtube.com/watch?v=IRrVhZ0V9kU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-03 00:00:00+00:00

Each week KC and Jesse check out an overlooked game on Steam and decide whether or not it's a "Hidden Gem". This week they're checking out ECHO.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Elden Ring Warrior Jar Challenge Run with Jack and Nick - Part 8
 - [https://www.youtube.com/watch?v=OCv3h3pW9TI](https://www.youtube.com/watch?v=OCv3h3pW9TI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-03 00:00:00+00:00

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Complicated Life and Death of Stadia | Slightly Something Else
 - [https://www.youtube.com/watch?v=RyCGaaaxxE0](https://www.youtube.com/watch?v=RyCGaaaxxE0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-03 00:00:00+00:00

This week on Slightly Something Else, Yahtzee and Nick discuss the life and death of Stadia.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Streaming Age Has a Writers Problem
 - [https://www.youtube.com/watch?v=VQ9jM02hXMs](https://www.youtube.com/watch?v=VQ9jM02hXMs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-03 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

Darren Mooney takes a look at the current streaming age and why it has such a wide range in quality of writing across so many different shows, even including big franchise shows.

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag


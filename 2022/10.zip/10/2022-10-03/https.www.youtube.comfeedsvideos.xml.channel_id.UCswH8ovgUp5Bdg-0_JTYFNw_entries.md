# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## This Is F*cking Pathetic
 - [https://www.youtube.com/watch?v=D-zWQC0U7ac](https://www.youtube.com/watch?v=D-zWQC0U7ac)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-10-04 00:00:00+00:00

As Hillary Clinton compares Trump supporters to Nazis, she also praises, what the left are declaring, “fascist” Giorgia Meloni’s Italian election victory. So, much like the Nazis in Ukraine, are some fascists OK, or are all these terms just manufactured for political gain? #hillaryclinton #trump  #giorgia_meloni  

References
https://www.independent.co.uk/news/world/americas/us-politics/hillary-clinton-trump-qanon-ohio-b2175188.html
https://jacobin.com/2022/09/hillary-clinton-is-wrong-electing-a-far-right-woman-is-not-a-step-forward-for-women
https://www.commondreams.org/news/2022/09/02/hillary-clinton-under-fire-supportive-remarks-far-right-pm-contender-italy
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/

## Nord Stream Pipeline: Now It Makes Sense
 - [https://www.youtube.com/watch?v=KwF5Y1oZrAw](https://www.youtube.com/watch?v=KwF5Y1oZrAw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-10-03 00:00:00+00:00

In a mystery worthy of a Cold War-era spy novel natural gas supply lines linking Russia to Europe were hit by unexplained underwater explosions in the Baltic Sea this week. The culprit is unknown, as is the precise cause, so if this is sabotage, who might have done it, and who stands to benefit most from it? #Ukraine #Russia #War 

References
https://inews.co.uk/news/nato-retaliate-nord-stream-pipeline-explosions-sabotage-1885680
https://www.telegraph.co.uk/world-news/2022/09/27/putins-nord-stream-2-sabotage-sends-warning-will-blow-pipes/
https://scheerpost.com/2022/09/29/the-timing-of-the-pipeline-attack/
--------------------------------------------------------------------------------------------------------------------------
Join Our Community HERE: https://www.russellbrand.com/join 

For meditation and breath work, subscribe to my side-channel: 
https://www.youtube.com/c/AwakeningWithRussell

Rumble:
https://rumble.com/c/russellbrand

Locals:
https://russellbrand.locals.com/


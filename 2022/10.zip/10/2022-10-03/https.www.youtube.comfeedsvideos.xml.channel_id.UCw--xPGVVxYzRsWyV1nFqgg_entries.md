# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Den of Evil - Berserk Vol. 19 [Part 2] & Vol. 20 [Part 1]
 - [https://www.youtube.com/watch?v=_lBkTeiKIN8](https://www.youtube.com/watch?v=_lBkTeiKIN8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2022-10-04 00:00:00+00:00

Let's talk about the Conviction Arc of #Berserk!
This video covers Deluxe Edition 7 - Vol. 18 [Part 2], which includes the chapters: "Straying", "Ambition Boy", "Den of Evil", "The Reunion", "Ambush", "The Cliff", "Captives", "The Iron Maiden", and "Blood Flow of the Dead 1-2" as well as "The Spider's Thread", "Those Who Dance at the Summit, Those Who Creep in the Depths", "Hell's Angels", "One Unknown in the Depths of the Depths", "The Threatened", "Omens", and "Martyrdom". 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://amzn.to/3CnKsfX
Rebels Creed: https://amzn.to/3Gtqt2p

Equipment: 
Camera: https://amzn.to/3siqgHv  
Lense: https://amzn.to/3ugGxhQ  
Lighting: https://amzn.to/3aI3brK  
Microphone: https://amzn.to/3pCGtWg  
Tripod: https://amzn.to/3kd9yq1  

P.O. Box: PO Box 7874 Henrico, VA 23231


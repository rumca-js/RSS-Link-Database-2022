# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Aktywista LGBT z Homokomando oskarżany o gwałt. Jest odpowiedź
 - [https://wydarzenia.interia.pl/kraj/news-aktywista-lgbt-z-homokomando-oskarzany-o-gwalt-jest-odpowied,nId,6324569](https://wydarzenia.interia.pl/kraj/news-aktywista-lgbt-z-homokomando-oskarzany-o-gwalt-jest-odpowied,nId,6324569)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-10-03 17:18:22+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-aktywista-lgbt-z-homokomando-oskarzany-o-gwalt-jest-odpowied,nId,6324569"><img align="left" alt="Aktywista LGBT z Homokomando oskarżany o gwałt. Jest odpowiedź" src="https://i.iplsc.com/aktywista-lgbt-z-homokomando-oskarzany-o-gwalt-jest-odpowied/000G5IVBM5VY62QJ-C321.jpg" /></a>Maciej L., znany aktywista LGBT+ i były członek zarządu Homokomando, miał dopuścić się gwałtu z bronią w ręku - informują media. W odpowiedzi na opublikowany w poniedzi

## Andrzej Duda powołał Marzenę Paczuską i Hannę Karp do KRRiT
 - [https://wydarzenia.interia.pl/kraj/news-andrzej-duda-powolal-marzene-paczuska-i-hanne-karp-do-krrit,nId,6324341](https://wydarzenia.interia.pl/kraj/news-andrzej-duda-powolal-marzene-paczuska-i-hanne-karp-do-krrit,nId,6324341)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-10-03 14:50:31+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-andrzej-duda-powolal-marzene-paczuska-i-hanne-karp-do-krrit,nId,6324341"><img align="left" alt="Andrzej Duda powołał Marzenę Paczuską i Hannę Karp do KRRiT" src="https://i.iplsc.com/andrzej-duda-powolal-marzene-paczuska-i-hanne-karp-do-krrit/000G5I9POACUAUHS-C321.jpg" /></a>W poniedziałek Marzena Paczuska i Hanna Karp zostały powołane przez prezydenta Andrzeja Dudę w skład Krajowej Rady Radiofonii i Telewizji (KRRiT). Marzena Paczuska wcześniej

## Mariusz Błaszczak zapowiada. Nowy dodatek dla żołnierzy
 - [https://wydarzenia.interia.pl/kraj/news-mariusz-blaszczak-zapowiada-nowy-dodatek-dla-zolnierzy,nId,6324135](https://wydarzenia.interia.pl/kraj/news-mariusz-blaszczak-zapowiada-nowy-dodatek-dla-zolnierzy,nId,6324135)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-10-03 12:17:35+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mariusz-blaszczak-zapowiada-nowy-dodatek-dla-zolnierzy,nId,6324135"><img align="left" alt="Mariusz Błaszczak zapowiada. Nowy dodatek dla żołnierzy" src="https://i.iplsc.com/mariusz-blaszczak-zapowiada-nowy-dodatek-dla-zolnierzy/000G5GL80U8MIMK3-C321.jpg" /></a>Dodatek służbowy w wysokości 450 zł miesięcznie - tyle będzie wynosić nowe świadczenie, które w poniedziałek ogłosił minister obrony narodowej Mariusz Błaszczak. Jak dodał, przyznawane on

## Andrzej Duda: Ponad 3 mld zł na leczenie specjalistyczne dzieci
 - [https://wydarzenia.interia.pl/kraj/news-andrzej-duda-ponad-3-mld-zl-na-leczenie-specjalistyczne-dzie,nId,6324035](https://wydarzenia.interia.pl/kraj/news-andrzej-duda-ponad-3-mld-zl-na-leczenie-specjalistyczne-dzie,nId,6324035)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-10-03 11:29:07+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-andrzej-duda-ponad-3-mld-zl-na-leczenie-specjalistyczne-dzie,nId,6324035"><img align="left" alt="Andrzej Duda: Ponad 3 mld zł na leczenie specjalistyczne dzieci" src="https://i.iplsc.com/andrzej-duda-ponad-3-mld-zl-na-leczenie-specjalistyczne-dzie/000G5G187TI57LGE-C321.jpg" /></a>W poniedziałek ogłoszono rozstrzygnięcie konkursu Funduszu Medycznego na infrastrukturę pediatryczną. Wśród 14 projektów rozdzielono 3,15 mld zł.  - Mówiliśmy, że będą

## Jarosław Kaczyński: Zadbamy o ludzi, którzy znajdą się w trudnej sytuacji
 - [https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-zadbamy-o-ludzi-ktorzy-znajda-sie-w-trudn,nId,6323985](https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-zadbamy-o-ludzi-ktorzy-znajda-sie-w-trudn,nId,6323985)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-10-03 09:37:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-zadbamy-o-ludzi-ktorzy-znajda-sie-w-trudn,nId,6323985"><img align="left" alt="Jarosław Kaczyński: Zadbamy o ludzi, którzy znajdą się w trudnej sytuacji" src="https://i.iplsc.com/jaroslaw-kaczynski-zadbamy-o-ludzi-ktorzy-znajda-sie-w-trudn/000G5FOQEJJ2N6VY-C321.jpg" /></a>Jarosław Kaczyński zapowiedział, że Prawo i Sprawiedliwość wkrótce przedstawi nowe propozycje programowe. Polityk doprecyzował, że jego ugrupowanie zamierza 

## Jerzy Urban nie żyje. Miał 89 lat
 - [https://wydarzenia.interia.pl/kraj/news-jerzy-urban-nie-zyje-mial-89-lat,nId,6324009](https://wydarzenia.interia.pl/kraj/news-jerzy-urban-nie-zyje-mial-89-lat,nId,6324009)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-10-03 09:25:15+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jerzy-urban-nie-zyje-mial-89-lat,nId,6324009"><img align="left" alt="Jerzy Urban nie żyje. Miał 89 lat" src="https://i.iplsc.com/jerzy-urban-nie-zyje-mial-89-lat/000G5FUBBHFO7WX3-C321.jpg" /></a>W wieku 89 lat zmarł Jerzy Urban - poinformował &quot;Tygodnik NIE&quot; w swoich oficjalnych mediach społecznościowych.</p><br clear="all" />

## Reparacje od Niemiec. Szef MSZ podpisał notę dyplomatyczną
 - [https://wydarzenia.interia.pl/kraj/news-reparacje-od-niemiec-szef-msz-podpisal-note-dyplomatyczna,nId,6323995](https://wydarzenia.interia.pl/kraj/news-reparacje-od-niemiec-szef-msz-podpisal-note-dyplomatyczna,nId,6323995)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-10-03 09:09:05+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-reparacje-od-niemiec-szef-msz-podpisal-note-dyplomatyczna,nId,6323995"><img align="left" alt="Reparacje od Niemiec. Szef MSZ podpisał notę dyplomatyczną" src="https://i.iplsc.com/reparacje-od-niemiec-szef-msz-podpisal-note-dyplomatyczna/000G5FW12KNOG9UJ-C321.jpg" /></a>Szef MSZ Zbigniew Rau podpisał notę dyplomatyczną w sprawie reparacji, która zostanie przekazana dyplomacji niemieckiej. - Na to czekały pokolenia Polaków - powiedział.</p><br cl

## Ambasador Rosji Siergiej Andriejew wezwany do MSZ
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ambasador-rosji-siergiej-andriejew-wezwany-do-msz,nId,6323863](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ambasador-rosji-siergiej-andriejew-wezwany-do-msz,nId,6323863)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-10-03 06:00:34+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ambasador-rosji-siergiej-andriejew-wezwany-do-msz,nId,6323863"><img align="left" alt="Ambasador Rosji Siergiej Andriejew wezwany do MSZ" src="https://i.iplsc.com/ambasador-rosji-siergiej-andriejew-wezwany-do-msz/000EV4VFDSV0EYRU-C321.jpg" /></a>Ministerstwo Spraw Zagranicznych wezwało do siebie ambasadora Rosji. Siergiej Andriejew ma usłyszeć polskie stanowisko nieuznające pseudoreferendów na Ukrainie i prób 


# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Pakistan floods: 'It’s like fighting a war with no end'
 - [https://www.bbc.co.uk/news/world-asia-63080101?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63080101?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 23:26:27+00:00

Pakistan's worst floods in years have left millions homeless and lacking clean drinking water.

## Leicester 4-0 Nottingham Forest: Steve Cooper faces an uncertain future after another Forest loss
 - [https://www.bbc.co.uk/sport/football/63126358?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63126358?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 23:11:48+00:00

Nottingham Forest manager Steve Cooper put a brave face on the 4-0 loss to Leicester, but his job is under threat with the team bottom of the table.

## Food charity Fareshare's donations from supermarkets drop
 - [https://www.bbc.co.uk/news/business-63122864?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63122864?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 23:06:47+00:00

Demand for Fareshare’s help continues to grow, but there’s been a big fall from their biggest donors.

## ‘I think there is a space for me’ - can England ignore Maddison?
 - [https://www.bbc.co.uk/sport/football/63126188?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63126188?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 23:01:37+00:00

After once again starring for Leicester in their thrashing of Nottingham Forest, can James Maddison force his way into England's World Cup squad?

## The DIY gadgets that could keep your energy bill down
 - [https://www.bbc.co.uk/news/business-62900202?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-62900202?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 23:00:43+00:00

With a little know-how people are tuning their home heating to reduce their gas consumption.

## Ros Atkins on... why protests are happening in Iran
 - [https://www.bbc.co.uk/news/world-middle-east-63125721?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63125721?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 23:00:10+00:00

Demonstrations are happening across the country following the death of a woman detained by morality police.

## Ukraine tank breakthrough in south towards Kherson
 - [https://www.bbc.co.uk/news/world-europe-63126156?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63126156?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 22:46:06+00:00

Russian officials say Ukrainian armour has made advances in the south and east.

## Jonny Bairstow: England batter out until 2023 after surgery
 - [https://www.bbc.co.uk/sport/cricket/63125895?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63125895?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 20:57:20+00:00

England batter Jonny Bairstow successfully undergoes surgery on a broken leg and dislocated ankle, and confirms he will not play again this year.

## Leicester 4-0 Nottingham Forest: James Maddison scores twice as Foxes win first game of season
 - [https://www.bbc.co.uk/sport/football/63030225?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63030225?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 20:52:10+00:00

Leicester thrash Nottingham Forest to secure their first Premier League win of the season and move off the bottom of the table.

## Danish Royal Family: Queen 'sorry' after stripping grandchildren's titles
 - [https://www.bbc.co.uk/news/world-europe-63120481?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63120481?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 20:47:31+00:00

But she did not reverse the decision to remove titles from four of her grandchildren.

## Chancellor Kwasi Kwarteng to set out debt plan earlier than planned
 - [https://www.bbc.co.uk/news/uk-politics-63123880?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63123880?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 20:03:27+00:00

The chancellor will publish plans "shortly" after pressure to calm markets over his mini-budget.

## Rugby World Cup: England's Shaunagh Brown to miss opener after positive Covid-19 test
 - [https://www.bbc.co.uk/sport/rugby-union/63123938?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63123938?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 19:43:33+00:00

Forward Shaunagh Brown will miss England's opening game of the Rugby World Cup against Fiji on Saturday after testing positive for Covid-19.

## UK summons Iran diplomat over protest crackdown
 - [https://www.bbc.co.uk/news/uk-63125102?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63125102?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 19:13:24+00:00

Iran's top diplomat in the UK is called to the Foreign Office over Tehran's crackdown on protests.

## Liverpool woman attacked by dogs and killed in Kirkdale house
 - [https://www.bbc.co.uk/news/uk-england-merseyside-63124015?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-63124015?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 19:10:34+00:00

A woman, aged in her 60s, has died after she was attacked by dogs in a Liverpool house, police say.

## Chancellor attempts to put tax U-turn behind him
 - [https://www.bbc.co.uk/news/uk-politics-63122732?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63122732?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 18:59:52+00:00

The chancellor says he wants to focus on delivering growth, after admitting it's been a "tough day".

## Millions will receive £324 cost-of-living payment in November
 - [https://www.bbc.co.uk/news/business-63121751?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63121751?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 18:54:48+00:00

Those on means-tested benefits will get the money between 8 and 23 November, the government says.

## Gold coins hidden in 7th Century found in wall
 - [https://www.bbc.co.uk/news/world-middle-east-63122180?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-63122180?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 18:48:01+00:00

The 44 coins found in Israel date to the Muslim conquest of the area in 635, archaeologists say.

## Will Smith film Emancipation to release this year
 - [https://www.bbc.co.uk/news/entertainment-arts-63115582?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63115582?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 18:37:24+00:00

The slave drama will be released in December, making it eligible for next year's Oscars.

## 'Systemic' abuse in top-level US women's football
 - [https://www.bbc.co.uk/sport/football/63125278?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63125278?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 18:33:37+00:00

Abuse and misconduct "had become systemic" in the United States' top-flight National Women's Soccer League (NWSL), an independent investigation finds.

## Liverpool v Rangers: 'Champions League will bring best version of Liverpool'
 - [https://www.bbc.co.uk/sport/football/63080301?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63080301?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 17:55:15+00:00

Rangers are preparing to face the best version of Liverpool in the Champions League, despite their struggles in the Premier League.

## Crowdfunding buys 'Tomas the tank' for Ukraine
 - [https://www.bbc.co.uk/news/world-europe-63121649?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63121649?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 16:54:05+00:00

More than 10,000 people donated to the fund, which will supply a modernised T-72 tank.

## Iga Swiatek: World number one criticises schedule and will not play Billie Jean King Cup Finals
 - [https://www.bbc.co.uk/sport/tennis/63114674?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/63114674?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 16:50:40+00:00

World number one Iga Swiatek criticises the scheduling of upcoming tennis events and says she will not be able to play at November's Billie Jean King Cup Finals.

## Alessia Russo: Manchester United forward withdraws from England squad with 'small injury'
 - [https://www.bbc.co.uk/sport/football/63118542?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63118542?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 16:32:35+00:00

Manchester United forward Alessia Russo will miss England's matches against the USA and the Czech Republic through injury.

## UK at significant risk of gas shortages this winter, warns energy regulator
 - [https://www.bbc.co.uk/news/business-63118574?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63118574?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 16:29:52+00:00

Electricity supplies to people's houses could be disrupted if the country runs short of gas.

## London Marathon 2022: Man dies after collapsing during event
 - [https://www.bbc.co.uk/news/uk-england-london-63120715?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-63120715?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 16:26:32+00:00

The 36-year-old man became unwell between miles 23 and 24 of the annual 26.2-mile event.

## Indonesia: Fans 'died in the arms' of players in stadium crush
 - [https://www.bbc.co.uk/news/world-asia-63114568?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63114568?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 16:19:31+00:00

Indonesia says dozens of children, the youngest believed to be just three, are among the dead.

## Ringo Starr cancels North American tour after catching Covid
 - [https://www.bbc.co.uk/news/entertainment-arts-63121692?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63121692?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 15:59:11+00:00

The Beatles drummer is "recovering at home" and hopes to resume shows soon, his spokesperson says.

## Nick Eardley: How tax cut policy U-turn was made
 - [https://www.bbc.co.uk/news/uk-politics-63116327?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63116327?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 15:57:53+00:00

The PM and chancellor held a series of crisis talks as it became clear the 45p tax cut policy was going to fail.

## What do government's tax changes mean for me?
 - [https://www.bbc.co.uk/news/63120283?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/63120283?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 15:04:02+00:00

The government has U-turned over its plan to abolish the 45% rate of income tax, but other tax changes are going ahead.

## Call an election if you want to change course, Nadine Dorries tells Liz Truss
 - [https://www.bbc.co.uk/news/uk-politics-63110543?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63110543?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 15:00:59+00:00

The former culture secretary accuses the new PM of dumping Boris Johnson era policies.

## Olivia Pratt-Korbel: Man in court accused of schoolgirl's murder
 - [https://www.bbc.co.uk/news/uk-england-merseyside-63115917?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-63115917?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 14:26:47+00:00

Olivia's parents were in court to see Thomas Cashman, 34, charged with murdering the nine-year-old.

## Kardashian fined over crypto 'pump and dump'
 - [https://www.bbc.co.uk/news/technology-63116235?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63116235?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 13:27:13+00:00

Kim Kardashian agrees to pay $1.26m after regulators charge her in EthereumMax case.

## Mortgage rates rise sharply as squeeze tightens
 - [https://www.bbc.co.uk/news/business-63119047?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63119047?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 12:55:20+00:00

The average two-year fixed rate is now close to 6% as major lenders raise the cost of deals sharply.

## Mr Doodle: Why I covered my entire house with doodles
 - [https://www.bbc.co.uk/news/entertainment-arts-63118482?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63118482?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 12:46:23+00:00

Artist Sam Cox, known as Mr Doodle, is living his childhood dream in a house he's adorned with his own art.

## Women's Champions League draw: Arsenal to face eight-time winners Lyon, while Chelsea meet Paris St-Germain
 - [https://www.bbc.co.uk/sport/football/63118534?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63118534?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 12:07:10+00:00

Arsenal meet eight-time winners and holders Lyon in the Women's Champions League group stage, while Chelsea face Paris St-Germain.

## King Charles to host South African president for first state visit
 - [https://www.bbc.co.uk/news/uk-63117898?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63117898?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 11:58:51+00:00

President Cyril Ramaphosa's state visit next month will be the first of King Charles' reign.

## How the late Hilaree Nelson inspired mountaineers
 - [https://www.bbc.co.uk/news/world-asia-63112666?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63112666?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 11:32:53+00:00

Fellow climbers saddened by her death in the Himalayas recall an inspirational figure to a generation of women.

## Indonesia football crush: How the disaster unfolded
 - [https://www.bbc.co.uk/news/world-asia-63113027?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63113027?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 11:31:09+00:00

Distraught fans demand justice, claiming police use of tear gas triggered a crush which killed 125 people.

## Worcester Warriors: Bath to sign Ted Hill, Ollie Lawrence, Fergus Lee-Warner and Valery Morozov on loan
 - [https://www.bbc.co.uk/sport/rugby-union/63112575?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63112575?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 11:25:33+00:00

Bath are to take four players from troubled Worcester - Ted Hill, Ollie Lawrence, Fergus Lee-Warner and Valery Morozov - on loan.

## Cancer-affected women offered skin-tone soft prosthetics
 - [https://www.bbc.co.uk/news/uk-england-london-63115407?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-63115407?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 10:52:01+00:00

Women of colour being treated at a London hospital can now choose a "softie" to match their skin tone.

## Nobel Prize goes to Svante Paabo for Neanderthal work
 - [https://www.bbc.co.uk/news/health-63116304?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-63116304?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 10:37:51+00:00

Sweden's Svante Paabo wins the prize for discoveries on humanity's extinct relatives.

## Water rebates for some customers after £150m fines for missing targets
 - [https://www.bbc.co.uk/news/uk-england-63115634?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-63115634?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 10:21:01+00:00

Thames Water and Southern Water are hardest hit and will have to return almost £80m to customers.

## Popular Minecraft YouTuber Dream reveals face
 - [https://www.bbc.co.uk/news/technology-63082329?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63082329?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 10:13:53+00:00

The YouTuber's 30 million subscribers finally find out what he looks like without a mask.

## Chris Mason: Government's U-turn won't be forgotten
 - [https://www.bbc.co.uk/news/uk-politics-63116324?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63116324?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 09:22:14+00:00

Tory MPs said the decision to offer the best paid a tax cut was unsellable, the BBC's political editor explains.

## Brazil election: The presidential race is far from over
 - [https://www.bbc.co.uk/news/world-latin-america-63115691?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-63115691?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 09:20:47+00:00

Lula and Bolsonaro go head-to-head after a closer than expected first-round result.

## Make cannabis Class A drug, say Conservative police commissioners
 - [https://www.bbc.co.uk/news/uk-politics-63115171?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63115171?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 09:14:18+00:00

A group of police and crime commissioners urge tougher penalties for supply and possession.

## Chris Wilder: Middlesbrough sack manager with club in Championship bottom three
 - [https://www.bbc.co.uk/sport/football/63116336?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63116336?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 08:45:28+00:00

Middlesbrough sack boss Chris Wilder after just two wins in their opening 11 games and the club sitting 22nd in the Championship.

## Chris Eubank Jr v Conor Benn: Eubank's lack of 'respect' for rival's punching power 'scares' Roy Jones Jr
 - [https://www.bbc.co.uk/sport/boxing/63093238?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/63093238?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 08:44:21+00:00

Roy Jones Jr speaks to BBC Sport about Chris Eubank Jr v Conor Benn and why he agreed to step aside from coaching Eubank for the fight.

## Record avian flu outbreak sees 48m birds culled in UK and EU
 - [https://www.bbc.co.uk/news/science-environment-63097119?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-63097119?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 08:04:11+00:00

The largest outbreak of avian influenza on record saw 48m birds culled in the UK and EU in the past year.

## Northern Lights captured at Kielder Observatory
 - [https://www.bbc.co.uk/news/uk-england-tyne-63115805?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tyne-63115805?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 08:02:14+00:00

Astronomer Dan Monk said it was Northumberland's best display of the aurora borealis "in ages".

## Fans of Sydney United 58 condemned for Nazi salutes during Australia Cup final
 - [https://www.bbc.co.uk/sport/football/63114667?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63114667?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 07:57:02+00:00

Supporters who displayed Nazi symbols and salutes at the Australia Cup final "should be banned for life", a senior government official says.

## Keyworth street named Britain's best for hedgehogs
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-63096303?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-63096303?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 07:53:25+00:00

Residents drilled holes in their fences to create wildlife corridors for the animals.

## Chancellor expected to back down on 45p tax rate
 - [https://www.bbc.co.uk/news/uk-63114279?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63114279?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 05:49:01+00:00

Kwasi Kwarteng is expected to make a statement on scrapping the 45p rate of income tax in the next hour, 10 days after it was announced.

## The Beatles: Rare images of early Cavern Club gigs found
 - [https://www.bbc.co.uk/news/uk-england-merseyside-63110249?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-63110249?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 05:39:28+00:00

The photos, featuring original drummer Pete Best, were taken a year before debut single Love Me Do.

## Nuclear test veterans 'need Hillsborough-level apology'
 - [https://www.bbc.co.uk/news/uk-england-kent-63079621?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-63079621?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 05:15:44+00:00

Veterans seek justice 70 years after Britain exploded its first nuclear bomb in Operation Hurricane.

## Sheffield: Incurable cancer patient chosen to model for charity campaign
 - [https://www.bbc.co.uk/news/uk-england-south-yorkshire-63095279?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-south-yorkshire-63095279?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 04:26:33+00:00

Emma, 41, is fronting a new sportswear brand collection to raise money for a breast cancer charity.

## Rikki Neave police 'ignored scientific evidence'
 - [https://www.bbc.co.uk/news/uk-63094341?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63094341?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 01:30:52+00:00

Original 1994 police inquiry ignored evidence and instead made murder case against boy’s mother, BBC finds.

## Cost of living: Young cancer patients 'in a desperate situation'
 - [https://www.bbc.co.uk/news/newsbeat-62850403?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-62850403?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 01:25:23+00:00

Young people with cancer say they are struggling with rent and bills because of soaring living costs.

## Brazil election: Lula and Bolsonaro to face run-off
 - [https://www.bbc.co.uk/news/world-latin-america-63112509?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-63112509?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 01:19:59+00:00

Neither presidential candidate got more than 50% of the overall vote, meaning they will face off on 30 October.

## Newspaper headlines: Tories threaten rebellion as 45p vote 'delayed'
 - [https://www.bbc.co.uk/news/blogs-the-papers-63112449?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-63112449?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-03 00:21:35+00:00

Growing concerns within the Conservative Party over the PM's tax plans dominate Monday's papers.


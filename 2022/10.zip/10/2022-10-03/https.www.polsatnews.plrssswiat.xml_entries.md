# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Rosja. Elon Musk zaproponował warunki pokoju między Rosją a Ukrainą. Andrij Melnyk ostro zareagował
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/rosja-elon-musk-zaproponowal-warunki-pokoju-miedzy-rosja-a-ukraina-andrij-melnyk-ostro-zareagowal/](https://www.polsatnews.pl/wiadomosc/2022-10-03/rosja-elon-musk-zaproponowal-warunki-pokoju-miedzy-rosja-a-ukraina-andrij-melnyk-ostro-zareagowal/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 19:52:00+00:00

Elon Musk - najbogatszy człowiek świata - opublikował na Twitterze swoje propozycje, które jego zdaniem miałyby doprowadzić do zawarcia pokoju między Rosją a Ukrainą. Wymienione przez niego warunki nie przypadły do gustu politykom z Kijowa, a były ambasador Ukrainy w Berlinie wyraził to w bardzo mocnych słowach.

## USA. Samolot spadł na dom. Zginęły trzy osoby
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/usa-samolot-spadl-na-dom-zginely-trzy-osoby/](https://www.polsatnews.pl/wiadomosc/2022-10-03/usa-samolot-spadl-na-dom-zginely-trzy-osoby/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 19:46:00+00:00

Mały samolot pasażerski spadł na dom w pobliżu lotniska w Minnesocie. W katastrofie zginął pilot i dwoje pasażerów. O dużym szczęściu w nieszczęściu mogą natomiast mówić mieszkańcy budynku, którym nic się nie stało.

## Wojna w Ukrainie. Postępy na południu. Największe przełamanie linii frontu od początku kontrofensywy
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/wojna-w-ukrainie-postepy-na-poludniu-najwieksze-przelamanie-linii-frontu-od-poczatku-kontrofensywy/](https://www.polsatnews.pl/wiadomosc/2022-10-03/wojna-w-ukrainie-postepy-na-poludniu-najwieksze-przelamanie-linii-frontu-od-poczatku-kontrofensywy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 18:47:00+00:00

Po sukcesach kontrofensywy na północy, przyszło największe od początku wojny przełamanie frontu na południu? Władze w Kijowie nie wydały oficjalnego komunikatu w tej sprawie, ale wiele wskazuje na to, że Ukraińcy przesunęli linię frontu o kilkadziesiąt kilometrów przemieszczając się wzdłuż Dniepru. Niepokojące informacje przekazały okupacyjne władze obwodu chersońskiego.

## Rosja. Ramzan Kadyrow chce posłać swoich synów na front. Żaden z nich nie jest pełnoletni
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/rosja-ramzan-kadyrow-chce-poslac-swoich-synow-na-front-zaden-z-nich-nie-jest-pelnoletni/](https://www.polsatnews.pl/wiadomosc/2022-10-03/rosja-ramzan-kadyrow-chce-poslac-swoich-synow-na-front-zaden-z-nich-nie-jest-pelnoletni/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 16:52:00+00:00

Nie żartuję. Czas sprawdzić się w prawdziwej walce i to jest coś, co pochwalam, że chcą zrobić - napisał o swoich trzech niepełnoletnich synach prezydent Czeczenii Ramzan Kadyrow. Oznajmił, że wszyscy nastolatkowie niebawem znajdą się na najbardziej bezpiecznych odcinkach frontu. W ten sposób chce udowodnić, że wiek nie powinien stanowić przeszkody w szkoleniu obrońców ojczyzny.

## Mount Everest. Andrzej Bargiel rezygnuje ze zdobycia szczytu. "Ryzyko jest zbyt duże"
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/mount-everest-andrzej-bargiel-rezygnuje-ze-zdobycia-szczytu-ryzyko-jest-zbyt-duze/](https://www.polsatnews.pl/wiadomosc/2022-10-03/mount-everest-andrzej-bargiel-rezygnuje-ze-zdobycia-szczytu-ryzyko-jest-zbyt-duze/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 16:07:00+00:00

Andrzej Bargiel nie zdobędzie najwyższego wierzchołka Ziemi Mount Everest (8848 m n.p.m.). Jestem zmuszony podjąć decyzję o zakończeniu wyprawy. Prognoza pogody na kolejne dni i tygodnie pogarsza się. Obfite opady śniegu i silny wiatr uniemożliwią dotarcie do celu - poinformował na Twitterze polski skialpinista.

## Duma Państwowa zatwierdziła aneksję ukraińskich terytoriów. Więcej głosów "za" niż deputowanych
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/duma-panstwowa-zatwierdzila-aneksje-ukrainskich-terytoriow-wiecej-glosow-za-niz-deputowanych/](https://www.polsatnews.pl/wiadomosc/2022-10-03/duma-panstwowa-zatwierdzila-aneksje-ukrainskich-terytoriow-wiecej-glosow-za-niz-deputowanych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 15:40:00+00:00

Rosyjska Duma Państwowa zatwierdziła aneksję czterech ukraińskich terytoriów. Niezależny portal Meduza podaje, że choć nikt się nie wstrzymał i nikt nie był przeciw - głosów za było więcej niż deputowanych na sali. Kreml ma na to wytłumaczenie.

## Mobilizacja w Rosji. "Trzech martwych" z jednej jednostki. "Atak, samobójstwo i marskość wątroby"
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/mobilizacja-w-rosji-trzech-martwych-z-jednej-jednostki-atak-samobojstwo-i-marskosc-watroby/](https://www.polsatnews.pl/wiadomosc/2022-10-03/mobilizacja-w-rosji-trzech-martwych-z-jednej-jednostki-atak-samobojstwo-i-marskosc-watroby/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 15:19:00+00:00

Potwierdzam śmierć trzech mężczyzn - zakomunikował rosyjskim mediom deputowany Dumy Państwowej z obwodu swierdłowskiego Maksym Iwanow. Osoby o których mówił, to zmobilizowani do jednej z tamtejszych jednostek wojskowych. Przyczyny śmierci każdego z nich różniły się od siebie.

## Indie. Pięcioletnia dziewczynka zgwałcona przez dwunastolatka
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/indie-pieciolatka-zgwalcona-przez-dwunastolatka/](https://www.polsatnews.pl/wiadomosc/2022-10-03/indie-pieciolatka-zgwalcona-przez-dwunastolatka/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 15:16:00+00:00

Pięcioletnia dziewczynka została zgwałcona przez dwunastolatka w wiosce Ughaiti na wschodzie Indii. Podejrzany o dokonanie przestępstwa chłopiec został zatrzymany przez policję, za swój czyn odpowie przed komisją do spraw nieletnich.

## Alpy. Polak zginął schodząc z Matterhornu. Ciało wypatrzyła załoga szwajcarskiego helikoptera
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/alpy-polak-zginal-schodzac-z-matterhornu-cialo-wypatrzyla-zaloga-szwajcarskiego-helikoptera/](https://www.polsatnews.pl/wiadomosc/2022-10-03/alpy-polak-zginal-schodzac-z-matterhornu-cialo-wypatrzyla-zaloga-szwajcarskiego-helikoptera/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 14:18:00+00:00

Nie żyje 37-letni wspinacz z Polski, który poniósł śmierć podczas zejścia ze szczytu Matterhorn na granicy Włoch i Szwajcarii. Zwłoki dostrzegła załoga śmigłowca szwajcarskiej firmy Air Zermatt podczas oblotu w poszukiwaniu zaginionego turysty.

## USA. Trzech nastolatków ukradło maserati. Ich szaleńczy rajd zakończył się śmiercią
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/usa-dwoch-nastolatkow-ofiarami-tragicznego-wypadku-maserati-ktore-wczesniej-skradli/](https://www.polsatnews.pl/wiadomosc/2022-10-03/usa-dwoch-nastolatkow-ofiarami-tragicznego-wypadku-maserati-ktore-wczesniej-skradli/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 13:37:00+00:00

15-latek z Florydy zginął w płomieniach, a jego 16-letni kolega walczy o życie po tym, jak kierowane przez ich 15-letniego kompana skradzione maserati jadąc z dużą prędkością rozbiło się o ścianę. Do wypadku doszło w miejscowości St. Petersburg - podaje lokalna stacja Fox13.

## Wojna w Ukrainie. Władze w Kijowie apelują o noszenie maseczek
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/wojna-w-ukrainie-wladze-w-kijowie-apeluja-o-noszenie-maseczek/](https://www.polsatnews.pl/wiadomosc/2022-10-03/wojna-w-ukrainie-wladze-w-kijowie-apeluja-o-noszenie-maseczek/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 12:38:00+00:00

Kijowskie merostwo wzywa mieszkańców do noszenia maseczek w związku z pandemią COVID-19. Apel do mieszkańców stolicy władze zamieściły na swoim profilu na Telegramie. Władze tłumaczą, że wskaźnik zakażeń koronawirusem gwałtownie wzrósł w ostatnich dniach.

## Belgia. Lekarze będą kierować pacjentów na wizyty... w muzeach, Rusza nowa terapia
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/belgia-lekarze-beda-kierowac-pacjentow-na-wizyty-w-muzeach-rusza-nowa-terapia/](https://www.polsatnews.pl/wiadomosc/2022-10-03/belgia-lekarze-beda-kierowac-pacjentow-na-wizyty-w-muzeach-rusza-nowa-terapia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 11:59:00+00:00

Sztuka ma pomóc w leczeniu depresji. Belgijscy lekarze jako pierwsi w Europie, oprócz tabletek, zalecają pacjentom borykającym się z depresją wizyty w muzeach.

## Niemcy. Zbrodnia w ośrodku dla uchodźców. Mężczyzna zaatakował żonę nożem na oczach dzieci
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/niemcy-zbrodnia-w-osrodku-dla-uchodzcow-mezczyzna-zaatakowal-zone-na-oczach-dzieci/](https://www.polsatnews.pl/wiadomosc/2022-10-03/niemcy-zbrodnia-w-osrodku-dla-uchodzcow-mezczyzna-zaatakowal-zone-na-oczach-dzieci/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 11:29:00+00:00

50-letni Gruzin zaatakował nożem swoją 44-letnią żonę, Ukrainkę, w ośrodku dla uchodźców w berlińskiej dzielnicy Alt-Hohenschönhausen. Świadkami zabójstwa były dzieci pary 6- i 17-letnie córki. Rodzina uciekła przed wojną z Ukrainy.

## Niemcy. Zgniłe jedzenie, myszy i nadgodziny. Szokujący raport z restauracji Burger Kinga
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/niemcy-zgnile-jedzenie-myszy-i-nadgodziny-szokujacy-raport-z-niemieckich-restauracji-burger-kinga/](https://www.polsatnews.pl/wiadomosc/2022-10-03/niemcy-zgnile-jedzenie-myszy-i-nadgodziny-szokujacy-raport-z-niemieckich-restauracji-burger-kinga/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 11:02:00+00:00

Team Wallraff - program śledczy telewizji RTL - ujawnił warunki sanitarne w niektórych niemieckich restauracjach Burger King. Śledztwo wykryło przemęczonych pracowników, myszy, larwy oraz zgniłe jedzenie. Restauracje miały problem z odpowiednimi warunkami już w przeszłości. Obecnie - po publikacji reportażu - firma zamknęła pięć oddziałów i zapowiedziała natychmiastowe działania.

## Nobel za badania nad neandertalczykiem. Szwedzki biolog z nagrodą w dziedzinie fizjologii i medycyny
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/nobel-za-badania-nad-neandertalczykiem-szwedzki-biolog-z-nagroda-w-dziedzinie-fizjologii-i-medycyny/](https://www.polsatnews.pl/wiadomosc/2022-10-03/nobel-za-badania-nad-neandertalczykiem-szwedzki-biolog-z-nagroda-w-dziedzinie-fizjologii-i-medycyny/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 10:11:00+00:00

Szwedzki biolog Svante Pääbo, który zajmuje się genetyką ewolucyjną, został laureatem Nagrody Nobla w dziedzinie fizjologii i medycyny za 2022 r. Komitet Noblowski uhonorował odkrycia dotyczące genomów wymarłych homininów i ewolucji człowieka. Naukowiec kierował m.in. badaniami genomu neandertalczyka. Uczony otrzyma nagrodę o wysokości 10 mln szwedzkich koron (ok. 4,5 mln zł).

## Wielka Brytania kupi okręty do pilnowania podwodnych przewodów i rurociągów
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/wielka-brytania-rzad-nabedzie-okrety-do-pilnowania-podwodnych-przewodow-i-rurociagow/](https://www.polsatnews.pl/wiadomosc/2022-10-03/wielka-brytania-rzad-nabedzie-okrety-do-pilnowania-podwodnych-przewodow-i-rurociagow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 10:06:00+00:00

Planujemy wejść w posiadanie dwóch specjalistycznych okrętów, które pomogą chronić podwodne kable oraz rurociągi - zapowiedział Ben Wallace, minister obrony Wielkiej Brytanii, podczas konferencji rządzącej Partii Konserwatywnej w Birmingham.

## Wojna w Ukrainie. Były doradca Putina o groźbach nuklearnych: Ostatni argument Kremla
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/wojna-w-ukrainie-byly-doradca-putina-grozbach-nuklearnych-ostatni-argument-kremla/](https://www.polsatnews.pl/wiadomosc/2022-10-03/wojna-w-ukrainie-byly-doradca-putina-grozbach-nuklearnych-ostatni-argument-kremla/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 09:07:00+00:00

Arsenał jądrowy, broń jądrowa to jest taki ostatni argument Kremla - powiedział w programie Dzień na Świecie w Polsat News były doradca Władimira Putina Gleb Pawłowski. Zaznaczył, że broń jądrowa jest bardzo zróżnicowana, ma wiele kalibrów.

## Wiceprezes Apple zwolniony za wypowiedź na TikToku. Odpowiedział na pytanie, czym się zajmuje
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/zwolniony-za-nieprzyzwoita-wypowiedz-na-tiktoku-wiceprezes-apple-znalazl-sie-w-trudnej-sytuacji/](https://www.polsatnews.pl/wiadomosc/2022-10-03/zwolniony-za-nieprzyzwoita-wypowiedz-na-tiktoku-wiceprezes-apple-znalazl-sie-w-trudnej-sytuacji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 08:57:00+00:00

Wiceprezes Apple Tony Blevins został zwolniony po tym, jak jego wypowiedź znalazła się na TikToku. Firmie nie spodobały się jego słowa o tym, czym się zajmuje. Były już wiceprezes mówił o drogich samochodach i pieszczeniu kobiet o dużych piersiach.

## Wojna w Ukrainie. Zaskoczenie w Łymanie. Nikt im nie powiedział, że przez dobę mieszkali w Rosji
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/wojna-w-ukrainie-zaskoczenie-w-lymanie-nikt-im-nie-powiedzial-ze-przez-dobe-mieszkali-w-rosji/](https://www.polsatnews.pl/wiadomosc/2022-10-03/wojna-w-ukrainie-zaskoczenie-w-lymanie-nikt-im-nie-powiedzial-ze-przez-dobe-mieszkali-w-rosji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 08:14:00+00:00

Mieszkańcy Łymanu, który w niedzielę został odzyskany przez Ukraińców z rąk Rosjan nie wiedzieli, że miasto leży na terenie, którego aneksja została ogłoszona przez Kreml po przeprowadzeniu pesudoreferendów na okupowanych obszarach należących do Ukrainy. - Nikt nam nie powiedział - powiedziała zaskoczona mieszkanka miasta amerykańskiemu dziennikarzowi.

## Były dyrektor CIA ostrzega Putina. Atak jądrowy może grozić też krajom NATO
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/byly-dyrektor-cia-ostrzega-putina-atak-jadrowy-moze-grozic-tez-krajom-nato/](https://www.polsatnews.pl/wiadomosc/2022-10-03/byly-dyrektor-cia-ostrzega-putina-atak-jadrowy-moze-grozic-tez-krajom-nato/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 08:09:00+00:00

David Petraeus, który za kadencji Baracka Obamy był dyrektorem Centralnej Agencji Wywiadowczej, zagroził zniszczeniu przez amerykańskie wojska całej armii Putina, jeżeli ten użyje broni jądrowej w Ukrainie. - Odpowiedź byłaby adekwatna - powiedział w wywiadzie dla telewizji ABC.

## Holandia: 10-tonowy wieloryb wyrzucony na wybrzeżu
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/holandia-10-tonowy-wieloryb-wyrzucony-na-wybrzezu/](https://www.polsatnews.pl/wiadomosc/2022-10-03/holandia-10-tonowy-wieloryb-wyrzucony-na-wybrzezu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 07:31:00+00:00

Mierzącego 14 metrów płetwala zwyczajnego znaleziono w niedzielę na grobli Westkapelle w Holandii. Dryfujące zwłoki ssaka były parę dni wcześniej widziane u wybrzeży Nieuwpoort.

## Rosja. Połowa zmobilizowanych mężczyzn z regionu odesłana do domu, komisarz wojskowy zwolniony
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/rosja-polowa-zmobilizowanych-mezczyzn-z-regionu-odeslana-do-domu-komisarz-wojskowy-zwolniony/](https://www.polsatnews.pl/wiadomosc/2022-10-03/rosja-polowa-zmobilizowanych-mezczyzn-z-regionu-odeslana-do-domu-komisarz-wojskowy-zwolniony/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 06:29:00+00:00

Komisarz wojskowy rosyjskiego obwodu chabarowskiego musiał pożegnać się ze stanowiskiem w związku z rażącymi błędami przy selekcji poborowych. Połowa nowo zmobilizowanego personelu została odesłana do domu, ponieważ nie spełniania kryteriów - informuje agencja Reutera powołując się na gubernatora regionu.

## Brazylia. W pierwszej turze wyborów prezydenckich wygrywa Lula da Silva. Otrzymał 48,4 proc. głosów
 - [https://www.polsatnews.pl/wiadomosc/2022-10-03/brazylia-w-pierwszej-turze-wyborow-prezydenckich-wygrywa-lula-da-silva-otrzymal-484-proc-glosow/](https://www.polsatnews.pl/wiadomosc/2022-10-03/brazylia-w-pierwszej-turze-wyborow-prezydenckich-wygrywa-lula-da-silva-otrzymal-484-proc-glosow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-03 04:04:00+00:00

Pierwsza tura wyborów prezydenckich nie przyniosła rozstrzygnięcia, żaden z kandydatów nie dostał 50 proc. poparcia. Po przeliczeniu prawie wszystkich głosów faworyt, Lula da Silva, otrzymał 48,4 proc. głosów. Jego konkurent, urzędujący prezydent Jair Bolsonaro, dostał 43,3 proc. poparcia. Druga tura wyborów odbędzie się 30 października.


# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Tytanowe Oko" dla Playera za "Skazaną", wyróżniona grupa TVN Warner Bros. Discovery
 - [https://tvn24.pl/polska/konferencja-i-wystawa-pike-2022-nagrody-dla-playera-za-serial-skazana-i-dla-tvn-warner-bros-discovery-6144655?source=rss](https://tvn24.pl/polska/konferencja-i-wystawa-pike-2022-nagrody-dla-playera-za-serial-skazana-i-dla-tvn-warner-bros-discovery-6144655?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 21:29:03+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m6zkrd-dorota-zurkowska-odebrala-nagrode-6145062/alternates/LANDSCAPE_1280" />
    Nagrody przyznano na gali Konferencji i Wystawy Polskiej Izby Komunikacji Elektronicznej (PIKE).

## "Decyzja trudna, ale spodziewana". Kapitan reprezentacji o absencji Świątek
 - [https://eurosport.tvn24.pl/-decyzja-trudna--ale-spodziewana---kapitan-reprezentacji-o-absencji--wi-tek,1120395.html?source=rss](https://eurosport.tvn24.pl/-decyzja-trudna--ale-spodziewana---kapitan-reprezentacji-o-absencji--wi-tek,1120395.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 18:18:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-blqxnt-iga-swiatek-jest-mistrzynia-us-open/alternates/LANDSCAPE_1280" />
    Dawid Celt w rozmowie z eurosport.pl.

## Na wielu granicach wracają kontrole
 - [https://fakty.tvn24.pl/migranci-chc--dosta--si--do-ue--na-wielu-granicach-wracaj--kontrole,1120397.html?source=rss](https://fakty.tvn24.pl/migranci-chc--dosta--si--do-ue--na-wielu-granicach-wracaj--kontrole,1120397.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 18:10:00+00:00

<img alt="Na wielu granicach wracają kontrole" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i6am4h-migranci-chca-dostac-sie-do-ue-na-wielu-granicach-wracaja-kontrole/alternates/LANDSCAPE_1280" />
    Bałkański szlak znów działa. Materiał "Faktów o Świecie" TVN24 BiS.

## Trener tłumaczy, dlaczego Ronaldo nie wstał z ławki w derbach
 - [https://eurosport.tvn24.pl/trener-t-umaczy--dlaczego-ronaldo-nie-wsta--z--awki-w-derbach,1120353.html?source=rss](https://eurosport.tvn24.pl/trener-t-umaczy--dlaczego-ronaldo-nie-wsta--z--awki-w-derbach,1120353.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 17:36:00+00:00

<img alt="Trener tłumaczy, dlaczego Ronaldo nie wstał z ławki w derbach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ct81p4-derby-manchesteru-ronaldo-obejrzal-z-trybun/alternates/LANDSCAPE_1280" />
    Manchester United doznał bolesnej klęski w meczu z City.

## Od ćwierć wieku jesteśmy tam, gdzie dzieje się historia
 - [https://fakty.tvn24.pl/od--wier--wieku-jeste-my-tam--gdzie-dzieje-si--historia--25-lat--fakt-w--tvn,1120375.html?source=rss](https://fakty.tvn24.pl/od--wier--wieku-jeste-my-tam--gdzie-dzieje-si--historia--25-lat--fakt-w--tvn,1120375.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 17:12:00+00:00

<img alt="Od ćwierć wieku jesteśmy tam, gdzie dzieje się historia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-psvvem-0310--od-cwierc-wieku-jestesmy-tam-gdzie-dzieje-sie-historia-25-lat-faktow-tvn/alternates/LANDSCAPE_1280" />
    25 lat "Faktów" TVN.

## 30 samorządów chciało wspólnie kupić prąd. Nie wpłynęła żadna oferta
 - [https://fakty.tvn24.pl/30-samorz-d-w-chcia-o-wsp-lnie-kupi--pr-d--nie-wp-yn--a--adna-oferta,1120382.html?source=rss](https://fakty.tvn24.pl/30-samorz-d-w-chcia-o-wsp-lnie-kupi--pr-d--nie-wp-yn--a--adna-oferta,1120382.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 17:08:00+00:00

<img alt="30 samorządów chciało wspólnie kupić prąd. Nie wpłynęła żadna oferta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-40bmib-0310--30-samorzadow-chcialo-wspolnie-kupic-prad-nie-wplynela-zadna-oferta/alternates/LANDSCAPE_1280" />
    Pomorskie samorządy stworzyły grupę zakupową.

## Pięć lat z zakazem lotów. Pierwsza taka "czarna lista" pasażerów na świecie
 - [https://tvn24.pl/biznes/ze-swiata/klm-i-transavia-lista-uciazliwych-klientow-6144491?source=rss](https://tvn24.pl/biznes/ze-swiata/klm-i-transavia-lista-uciazliwych-klientow-6144491?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 17:05:56+00:00

<img alt="Pięć lat z zakazem lotów. Pierwsza taka " src="https://tvn24.pl/najnowsze/cdn-zdjecie-n3q2j6-lotnisko-rotterdam-the-hague-boeing-samolot-samoloty-andre-muller-shutterstock2200016693-6144496/alternates/LANDSCAPE_1280" />
    Dzięki niej latanie ma być bezpieczniejsze.

## Trudne warunki, problemy z łącznością i bohaterowie drugiego planu
 - [https://fakty.tvn24.pl/trudne-warunki--problemy-z---czno-ci--i-bohaterowie-drugiego-planu,1120385.html?source=rss](https://fakty.tvn24.pl/trudne-warunki--problemy-z---czno-ci--i-bohaterowie-drugiego-planu,1120385.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 17:05:00+00:00

<img alt="Trudne warunki, problemy z łącznością i bohaterowie drugiego planu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lk2ipy-0310--trudne-warunki-problemy-z-lacznoscia-i-bohaterowie-drugiego-planu/alternates/LANDSCAPE_1280" />
    "Fakty" TVN powstają już od 25 lat. Wpadki i potknięcia to jest część naszej pracy. Zebrało się ich sporo przez te ćwierć wieku.

## Wasilewski: zmieniło się wszystko, włącznie z nami i z pogodą. Popielarska: nie, my się nie zmieniliśmy
 - [https://tvn24.pl/tvnmeteo/polska/25-lat-tvn-tomasz-wasilewski-i-maja-popielarska-prezenterzy-pogody-wspominaja-poczatki-swej-pracy-w-stacji-6144486?source=rss](https://tvn24.pl/tvnmeteo/polska/25-lat-tvn-tomasz-wasilewski-i-maja-popielarska-prezenterzy-pogody-wspominaja-poczatki-swej-pracy-w-stacji-6144486?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 16:58:16+00:00

<img alt="Wasilewski: zmieniło się wszystko, włącznie z nami i z pogodą. Popielarska: nie, my się nie zmieniliśmy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-yuk6nm-maja-popielarska-6144532/alternates/LANDSCAPE_1280" />
    25 lat TVN. Prezenterzy tvnmeteo.pl wspominali na antenie TVN24, jak wyglądały początki ich pracy w stacji.

## "Administracja USA opracowuje odpowiedzi na szereg nuklearnych scenariuszy"
 - [https://tvn24.pl/swiat/ukraina-rosja-cnn-administracja-usa-opracowuje-odpowiedzi-na-szereg-nuklearnych-scenariuszy-6144529?source=rss](https://tvn24.pl/swiat/ukraina-rosja-cnn-administracja-usa-opracowuje-odpowiedzi-na-szereg-nuklearnych-scenariuszy-6144529?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 16:38:55+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jcyptu-zniszczony-rosyjski-pojazd-w-obwodzie-charakowskim-6144546/alternates/LANDSCAPE_1280" />
    Według źródeł amerykańskiej stacji CNN Władimir Putin jest pod presją nacjonalistów.

## Grzegorz Braun u "naczelnej propagandystki Putina"? Nie, trafił w tryby rosyjskiej propagandy
 - [https://konkret24.tvn24.pl/r/grzegorz-braun-u--naczelnej-propagandystki-putina---nie--trafi--w-tryby-rosyjskiej-propagandy,1120369.html?source=rss](https://konkret24.tvn24.pl/r/grzegorz-braun-u--naczelnej-propagandystki-putina---nie--trafi--w-tryby-rosyjskiej-propagandy,1120369.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 16:18:00+00:00

<img alt="Grzegorz Braun u " src="https://tvn24.pl/najnowsze/cdn-zdjecie-zyntg8-konkretjpg/alternates/LANDSCAPE_1280" />
    Pisze Konkret24.

## W tym sklepie ceny są niskie, a płaci się punktami. "Trzeba dać medal tym, którzy o tym pomyśleli"
 - [https://tvn24.pl/polska/krakow-otwarto-pierwszy-w-miescie-sklep-socjalny-za-zakupy-placi-sie-tam-punktami-skorzystaja-najbardziej-potrzebujacy-6144448?source=rss](https://tvn24.pl/polska/krakow-otwarto-pierwszy-w-miescie-sklep-socjalny-za-zakupy-placi-sie-tam-punktami-skorzystaja-najbardziej-potrzebujacy-6144448?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 16:14:38+00:00

<img alt="W tym sklepie ceny są niskie, a płaci się punktami. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-r35rnv-sklep-socjalny-w-krakowie-6144451/alternates/LANDSCAPE_1280" />
    W Krakowie powstał sklep socjalny.

## Alarm przed mundialem. Glik kontuzjowany
 - [https://eurosport.tvn24.pl/alarm-przed-mundialem--glik-kontuzjowany,1120387.html?source=rss](https://eurosport.tvn24.pl/alarm-przed-mundialem--glik-kontuzjowany,1120387.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 16:02:00+00:00

<img alt="Alarm przed mundialem. Glik kontuzjowany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qyovcp-kamil-glik-nie-opuscil-nawet-minuty-we-wczesniejszych-meczach-serie-b-w-tym-sezonie/alternates/LANDSCAPE_1280" />
    W opinii jego klubowego trenera Fabio Cannavaro uraz może być poważny.

## 25 lat niezapomnianej rozrywki z TVN
 - [https://tvn24.pl/kultura-i-styl/25-lat-tvn-tak-zmieniala-sie-polska-rozrywka-6143836?source=rss](https://tvn24.pl/kultura-i-styl/25-lat-tvn-tak-zmieniala-sie-polska-rozrywka-6143836?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 15:56:49+00:00

<img alt="25 lat niezapomnianej rozrywki z TVN" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b4b79y-joanna-brodzik-w-serialu-magda-m-6142535/alternates/LANDSCAPE_1280" />
    Stacja stała się liderem między innymi dzięki własnym produkcjom i polskim wersjom zagranicznych formatów.

## Jest zgoda na przejęcie popularnej w Polsce sieci kawiarni
 - [https://tvn24.pl/biznes/z-kraju/uokik-wydal-zgode-na-przejecie-costa-coffee-z-warszawy-oraz-coffee-nation-z-lotwy-przez-lagardere-6144466?source=rss](https://tvn24.pl/biznes/z-kraju/uokik-wydal-zgode-na-przejecie-costa-coffee-z-warszawy-oraz-coffee-nation-z-lotwy-przez-lagardere-6144466?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 15:43:13+00:00

<img alt="Jest zgoda na przejęcie popularnej w Polsce sieci kawiarni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pe7e4v-29-wrzesnia-obchodzimy-miedzynarodowy-dzien-kawy-6134425/alternates/LANDSCAPE_1280" />
    Komunikat UOKiK.

## Nie żyje Sacheen Littlefeather. Niedawno przyjęła przeprosiny za obelgi i gwizdy podczas oscarowej gali
 - [https://tvn24.pl/swiat/sacheen-littlefeather-nie-zyje-wystapila-na-gali-wreczenia-oscarow-w-imieniu-marlona-brando-6144259?source=rss](https://tvn24.pl/swiat/sacheen-littlefeather-nie-zyje-wystapila-na-gali-wreczenia-oscarow-w-imieniu-marlona-brando-6144259?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 15:31:43+00:00

<img alt="Nie żyje Sacheen Littlefeather. Niedawno przyjęła przeprosiny za obelgi i gwizdy podczas oscarowej gali" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eebbd6-marlon-brando-nagrodzony-za-kreacje-w-ojcu-chrzestnym-nie-chcial-odebrac-statuetki-osobiscie-i-przyslal-zastepstwo-w-osobie-sacheen-littlefeather-3214411/alternates/LANDSCAPE_1280" />
    W 1973 roku, w imieniu Marlona Brando, odmówiła przyjęcia statuetki.

## Polki podbijają kosmos
 - [https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-41,S00E41,879124?source=rss](https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-41,S00E41,879124?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 15:22:38+00:00

<img alt="Polki podbijają kosmos" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hidhrt-kijek-w-kosmosie-6144481/alternates/LANDSCAPE_1280" />
    Hubert Kijek rozmawia z polskimi naukowczyniami i organizatorkami World Space Week Wrocław.

## Szykuje się duża podwyżka emerytur i rent
 - [https://tvn24.pl/biznes/dla-seniora/emerytury-i-renty-2023-wskaznik-waloryzacji-ile-wyniesie-minimalna-emerytura-6144400?source=rss](https://tvn24.pl/biznes/dla-seniora/emerytury-i-renty-2023-wskaznik-waloryzacji-ile-wyniesie-minimalna-emerytura-6144400?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 15:02:36+00:00

<img alt="Szykuje się duża podwyżka emerytur i rent" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-z7y9bj-od-1-lipca-emeryt-lub-rencista-otrzyma-co-najmniej-75-proc-swojego-swiadczenia-nawet-przy-zbiegu-egzekucji-komorniczych-4210566/alternates/LANDSCAPE_1280" />
    Podano w wykazie prac legislacyjnych rządu.

## Restrukturyzacja Getin Noble Bank. Komunikat Komisji Europejskiej
 - [https://tvn24.pl/biznes/z-kraju/getin-noble-bank-ke-zatwierdza-pomoc-panstwa-na-wsparcie-restrukturyzacji-i-uporzadkowanej-likwidacji-6144420?source=rss](https://tvn24.pl/biznes/z-kraju/getin-noble-bank-ke-zatwierdza-pomoc-panstwa-na-wsparcie-restrukturyzacji-i-uporzadkowanej-likwidacji-6144420?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 14:50:07+00:00

<img alt="Restrukturyzacja Getin Noble Bank. Komunikat Komisji Europejskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ibdul9-shutterstock2036584067-6139435/alternates/LANDSCAPE_1280" />
    KE zatwierdziła szereg środków wsparcia.

## "Widzieli państwo nieco wylęknionego Wronę w garniturze. To był rok 1998"
 - [https://tvn24.pl/polska/25-lat-tvn-marcin-wrona-wspomina-kulisy-tworzenia-programu-pod-napieciem-6144327?source=rss](https://tvn24.pl/polska/25-lat-tvn-marcin-wrona-wspomina-kulisy-tworzenia-programu-pod-napieciem-6144327?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 14:45:32+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-89ekm7-marcin-wrona-6144440/alternates/LANDSCAPE_1280" />
    Marcin Wrona, korespondent "Faktów" TVN i dawny prowadzący program "Pod napięciem", o jego początkach.

## Linette zgasła po pierwszym secie. Szybkie pożegnanie z Tunezją
 - [https://eurosport.tvn24.pl/linette-zgas-a-po-pierwszym-secie--szybkie-po-egnanie-z-tunezj-,1120359.html?source=rss](https://eurosport.tvn24.pl/linette-zgas-a-po-pierwszym-secie--szybkie-po-egnanie-z-tunezj-,1120359.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 14:26:00+00:00

<img alt="Linette zgasła po pierwszym secie. Szybkie pożegnanie z Tunezją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vlog9l-linette-liczy-na-kolejne-zwyciestwa/alternates/LANDSCAPE_1280" />
    Turniej WTA 250 w Monastyrze już bez Polki.

## Polki imponują w mistrzostwach. Dwie w czołówkach statystyk
 - [https://eurosport.tvn24.pl/polki-imponuj--w-mistrzostwach--dwie-w-czo--wkach-statystyk,1120348.html?source=rss](https://eurosport.tvn24.pl/polki-imponuj--w-mistrzostwach--dwie-w-czo--wkach-statystyk,1120348.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 14:15:56+00:00

<img alt="Polki imponują w mistrzostwach. Dwie w czołówkach statystyk" src="https://tvn24.pl/najnowsze/cdn-zdjecie-in3s8q-polki-niezle-radza-sobie-na-mistrzostwach/alternates/LANDSCAPE_1280" />
    Niezłe wyniki mają przełożenie na rankingi indywidualne.

## Szwedzi: Nord Stream 2 znów przecieka. Przyczyna nie jest znana
 - [https://tvn24.pl/biznes/ze-swiata/nord-stream-2-zwiekszenie-wycieku-gazu-6144297?source=rss](https://tvn24.pl/biznes/ze-swiata/nord-stream-2-zwiekszenie-wycieku-gazu-6144297?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 13:55:41+00:00

<img alt="Szwedzi: Nord Stream 2 znów przecieka. Przyczyna nie jest znana" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sdfpnv-wyciek-nord-stream-2-6135582/alternates/LANDSCAPE_1280" />
    Podała szwedzka Straż Przybrzeżna.

## Kobieta spadła z wieży widokowej ratusza
 - [https://tvn24.pl/polska/paczkow-opolskie-upadek-z-wiezy-widokowej-ratusza-nie-zyje-kobieta-6144330?source=rss](https://tvn24.pl/polska/paczkow-opolskie-upadek-z-wiezy-widokowej-ratusza-nie-zyje-kobieta-6144330?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 13:53:57+00:00

<img alt="Kobieta spadła z wieży widokowej ratusza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k8zhqj-ratusz-w-paczkowie-wojewodztwo-opolskie-6144328/alternates/LANDSCAPE_1280" />
    54-latka nie żyje.

## Butelki leciały w piłkarzy Legii, mecz dokończono. Zaskakujący nakaz PZPN
 - [https://eurosport.tvn24.pl/butelki-lecia-y-w-pi-karzy-legii--mecz-doko-czono--zaskakuj-cy-nakaz-pzpn,1120355.html?source=rss](https://eurosport.tvn24.pl/butelki-lecia-y-w-pi-karzy-legii--mecz-doko-czono--zaskakuj-cy-nakaz-pzpn,1120355.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 13:50:39+00:00

<img alt="Butelki leciały w piłkarzy Legii, mecz dokończono. Zaskakujący nakaz PZPN" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mojb5a-jedna-z-butelek-rzucona-z-trybun-6141925/alternates/LANDSCAPE_1280" />
    Skandaliczne obrazki z trybun przyćmiły boiskowe wydarzenia w klasyku ekstraklasy między Lechem i Legią.

## Rzeka wyglądała jak z horroru, woda miała kolor krwi
 - [https://tvn24.pl/lodz/lodz-rzeka-augustowka-jak-z-horroru-woda-miala-kolor-krwi-6144278?source=rss](https://tvn24.pl/lodz/lodz-rzeka-augustowka-jak-z-horroru-woda-miala-kolor-krwi-6144278?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 13:45:16+00:00

<img alt="Rzeka wyglądała jak z horroru, woda miała kolor krwi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lahr1a-augustowka-zmienila-kolor-na-czerwony-6144282/alternates/LANDSCAPE_1280" />
    Udało się namierzyć firmę, której pracownik miał doprowadzić do skażenia.

## Większość ofiar to dziewczynki i młode kobiety
 - [https://tvn24.pl/swiat/afganistan-kabul-zamachowiec-samobojca-wysadzil-sie-w-czasie-egzaminu-rosnie-liczba-ofiar-6144302?source=rss](https://tvn24.pl/swiat/afganistan-kabul-zamachowiec-samobojca-wysadzil-sie-w-czasie-egzaminu-rosnie-liczba-ofiar-6144302?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 13:42:52+00:00

<img alt="Większość ofiar to dziewczynki i młode kobiety" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mbit1w-rodzina-18-letniej-hasiny-ktora-zginela-w-zamachu-w-osrodku-edukacyjnym-w-kabulu-6144321/alternates/LANDSCAPE_1280" />
    Trwa dokumentacja zbrodni.

## Przyznano odszkodowanie rodzinom ofiar zamieszek na stadionie
 - [https://eurosport.tvn24.pl/przyznano-odszkodowanie-rodzinom-ofiar-zamieszek-na-stadionie,1120358.html?source=rss](https://eurosport.tvn24.pl/przyznano-odszkodowanie-rodzinom-ofiar-zamieszek-na-stadionie,1120358.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 12:33:38+00:00

<img alt="Przyznano odszkodowanie rodzinom ofiar zamieszek na stadionie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9ogy4g-rodziny-ofiar-tragedii-na-stadionie-pilkarskim-w-indonezji-dostana-odszkodowanie-6144201/alternates/LANDSCAPE_1280" />
    Władze Indonezji wypłacą pieniądze rodzinom 125 ofiar.

## Monika Olejnik o początkach "Kropki nad i": wtedy politycy byli bardziej odważni, przychodzili i dawali radę
 - [https://tvn24.pl/kultura-i-styl/25-lat-od-powstania-tvn-i-pierwszego-wydania-kropki-nad-i-monika-olejnik-wspomina-6144052?source=rss](https://tvn24.pl/kultura-i-styl/25-lat-od-powstania-tvn-i-pierwszego-wydania-kropki-nad-i-monika-olejnik-wspomina-6144052?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 12:29:13+00:00

<img alt="Monika Olejnik o początkach " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wnf5ji-olejnik-6144160/alternates/LANDSCAPE_1280" />
    Od pierwszego wydania "Kropki nad i" w poniedziałek upływa 25 lat.

## Bardzo dobre wyniki tvn24.pl, TVN24 i "Faktów" TVN. Dziękujemy!
 - [https://tvn24.pl/biznes/z-kraju/wyniki-tvn24pl-tvn24-i-faktow-tvn-we-wrzesniu-2022-dane-6143678?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-tvn24pl-tvn24-i-faktow-tvn-we-wrzesniu-2022-dane-6143678?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 12:01:24+00:00

<img alt="Bardzo dobre wyniki tvn24.pl, TVN24 i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-f0o6sl-tvn24-6143957/alternates/LANDSCAPE_1280" />
    Najnowsze dane.

## Litwa wydala szefa rosyjskiej ambasady
 - [https://tvn24.pl/swiat/litwa-wydala-szefa-rosyjskiej-ambasady-siergieja-riabokonia-6144070?source=rss](https://tvn24.pl/swiat/litwa-wydala-szefa-rosyjskiej-ambasady-siergieja-riabokonia-6144070?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 11:52:56+00:00

<img alt="Litwa wydala szefa rosyjskiej ambasady" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dfm5vf-ambasada-rosji-w-wilnie-6144103/alternates/LANDSCAPE_1280" />
    Siergiej Riabokoń ma pięć dni na opuszczenie kraju.

## Chciał oszczędzić, dodawał do pieca owies. Po miesiącu "są skutki uboczne"
 - [https://tvn24.pl/pomorze/glincz-chcial-oszczedzic-dodawal-do-pieca-owies-po-miesiacu-sa-skutki-uboczne-6143752?source=rss](https://tvn24.pl/pomorze/glincz-chcial-oszczedzic-dodawal-do-pieca-owies-po-miesiacu-sa-skutki-uboczne-6143752?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 10:52:21+00:00

<img alt="Chciał oszczędzić, dodawał do pieca owies. Po miesiącu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-on40s6-dodawal-do-pieca-owies-6143770/alternates/LANDSCAPE_1280" />
    Za tonę ekogroszku płacił 2800 złotych, a za owies od sąsiada o połowę taniej - 1400 złotych.

## Kadyrow zaapelował o użycie broni jądrowej. Kreml odpowiada
 - [https://tvn24.pl/swiat/ramzan-kadyrow-zaapelowal-o-uzyciu-w-ukrainie-niskowydajnej-broni-nuklearnej-kreml-odpowiedzial-6143668?source=rss](https://tvn24.pl/swiat/ramzan-kadyrow-zaapelowal-o-uzyciu-w-ukrainie-niskowydajnej-broni-nuklearnej-kreml-odpowiedzial-6143668?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 10:35:15+00:00

<img alt="Kadyrow zaapelował o użycie broni jądrowej. Kreml odpowiada" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g452sn-kadyrow-6143645/alternates/LANDSCAPE_1280" />
    Rzecznik Kremla Dmitrij Pieskow oświadczył w poniedziałek, że w kwestiach użycia broni jądrowej nie należy opierać się na emocjach - podała agencja Reutera.

## Szef MSZ podpisał skierowaną do Niemiec notę w sprawie reparacji
 - [https://tvn24.pl/polska/reparacje-od-niemiec-szef-msz-zbigniew-rau-podpisal-note-dyplomatyczna-skierowana-do-niemiec-6143586?source=rss](https://tvn24.pl/polska/reparacje-od-niemiec-szef-msz-zbigniew-rau-podpisal-note-dyplomatyczna-skierowana-do-niemiec-6143586?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 09:12:00+00:00

<img alt="Szef MSZ podpisał skierowaną do Niemiec notę w sprawie reparacji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ucbr8y-szef-msz-zbigniew-rau-podpisal-skierowana-do-niemiec-note-w-sprawie-reparacji-6143665/alternates/LANDSCAPE_1280" />
    Dokument zostanie przekazany dyplomacji niemieckiej.

## Jerzy Brzęczek zwolniony z Wisły Kraków
 - [https://eurosport.tvn24.pl/jerzy-brz-czek-zwolniony-z-wis-y-krak-w,1120340.html?source=rss](https://eurosport.tvn24.pl/jerzy-brz-czek-zwolniony-z-wis-y-krak-w,1120340.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 07:39:52+00:00

<img alt="Jerzy Brzęczek zwolniony z Wisły Kraków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rmshdi-jerzy-brzeczek-zwolniony-z-funkcji-trenera-wisly-krakow/alternates/LANDSCAPE_1280" />
    Przestał pełnić funkcję trenera.

## Iga Świątek nie pomoże reprezentacji
 - [https://eurosport.tvn24.pl/iga--wi-tek-nie-pomo-e-reprezentacji-w-turnieju-fina-owym-billie-jean-king-cup,1120339.html?source=rss](https://eurosport.tvn24.pl/iga--wi-tek-nie-pomo-e-reprezentacji-w-turnieju-fina-owym-billie-jean-king-cup,1120339.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 07:34:03+00:00

<img alt="Iga Świątek nie pomoże reprezentacji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cq4g3b-polki-awansowaly-do-finalow-pucharu-billie-jean-king/alternates/LANDSCAPE_1280" />
    W turnieju finałowym Billie Jean King Cup.

## Prawdziwy król lata
 - [https://eurosport.tvn24.pl/prawdziwy-kr-l-lata--kubacki-absolutnym-rekordzist--wygranych-na-igielicie,1120302.html?source=rss](https://eurosport.tvn24.pl/prawdziwy-kr-l-lata--kubacki-absolutnym-rekordzist--wygranych-na-igielicie,1120302.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 06:55:05+00:00

<img alt="Prawdziwy król lata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ljtbg4-dawid-kubacki-wygral-letnie-grand-prix/alternates/LANDSCAPE_1280" />
    Kubacki absolutnym rekordzistą wygranych na igielicie.

## Ponitka zadebiutował, Panathinaikos bez Superpucharu
 - [https://eurosport.tvn24.pl/ponitka-zadebiutowa---panathinaikos-bez-superpucharu,1120333.html?source=rss](https://eurosport.tvn24.pl/ponitka-zadebiutowa---panathinaikos-bez-superpucharu,1120333.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 06:18:55+00:00

<img alt="Ponitka zadebiutował, Panathinaikos bez Superpucharu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dsf0bt-ponitka-ma-za-soba-udane-mistrzostwa-europy/alternates/LANDSCAPE_1280" />
    Rozegrał w weekend dwa mecze w greckim zespole.

## Fin najmłodszym mistrzem świata w historii WRC
 - [https://eurosport.tvn24.pl/fin-najm-odszym-mistrzem--wiata-w-historii-wrc,1120254.html?source=rss](https://eurosport.tvn24.pl/fin-najm-odszym-mistrzem--wiata-w-historii-wrc,1120254.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 05:48:28+00:00

<img alt="Fin najmłodszym mistrzem świata w historii WRC" src="https://tvn24.pl/najnowsze/cdn-zdjecie-grcxl8-kalle-rovanpera-najmlodszym-mistrzem-swiata-w-historii/alternates/LANDSCAPE_1280" />
    Triumf zapewnił sobie w Nowej Zelandii.

## "Kopiuj i wklej"
 - [https://eurosport.tvn24.pl/-kopiuj-i-wklej---dwa-efektowne-gole-krychowiaka--oba-niemal-identyczne,1120332.html?source=rss](https://eurosport.tvn24.pl/-kopiuj-i-wklej---dwa-efektowne-gole-krychowiaka--oba-niemal-identyczne,1120332.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 05:24:31+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n30s5x-grzegorz-krychowiak-jest-reprezentantem-polski/alternates/LANDSCAPE_1280" />
    Dwa efektowne gole Krychowiaka, oba niemal identyczne.

## 17 minut, 5 punktów. Obiecujący debiut Sochana
 - [https://eurosport.tvn24.pl/obiecuj-cy-debiut-sochana-w-san-antonio-spurs,1120330.html?source=rss](https://eurosport.tvn24.pl/obiecuj-cy-debiut-sochana-w-san-antonio-spurs,1120330.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-03 04:24:10+00:00

<img alt="17 minut, 5 punktów. Obiecujący debiut Sochana" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0fj7s4-jeremy-sochan-w-akcji/alternates/LANDSCAPE_1280" />
    W pierwszym przedsezonowym meczu ligi NBA.


# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Who Made Bobby Moynihan Break Character During SNL?
 - [https://gizmodo.com/who-made-bobby-moynihan-break-character-during-snl-1849610508](https://gizmodo.com/who-made-bobby-moynihan-break-character-during-snl-1849610508)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 22:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--z3Fxu7tk--/c_fit,fl_progressive,q_80,w_636/038659a35f4f240852565aa652859e32.jpg" /><p><a href="https://gizmodo.com/who-made-bobby-moynihan-break-character-during-snl-1849610508">Read more...</a></p>

## Get a First Peek at Sci-Fi Noir Debut Novel Bang Bang Bodhisattva
 - [https://gizmodo.com/bang-bang-bodhisattva-aubrey-wood-rebellion-publishing-1849609988](https://gizmodo.com/bang-bang-bodhisattva-aubrey-wood-rebellion-publishing-1849609988)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 22:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--NBw4VVqj--/c_fit,fl_progressive,q_80,w_636/615299aa833a01b42975b25103910617.png" /><p>If you’re interested in cyberware, <a href="https://gizmodo.com/scifi-book-excerpt-queer-multiverses-fractured-infinity-1849519685">sci-fi trans-humanism</a>, and an incredible amount of <a href="https://gizmodo.com/mark-ruffalo-toni-collette-cast-in-bong-joon-ho-mickey7-1848956750">sassy characters</a>, then you’re going to want to sit down for thi

## Firefly Sends Alpha Rocket to Orbit, One Year After Explosive Launch Attempt
 - [https://gizmodo.com/firefly-alpha-rocket-reaches-orbit-second-flight-1849611021](https://gizmodo.com/firefly-alpha-rocket-reaches-orbit-second-flight-1849611021)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 21:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--xiLJXQOo--/c_fit,fl_progressive,q_80,w_636/269896bb18f85685827023eb5251e471.jpg" /><p>Private space company Firefly finally reached orbit with its  Alpha rocket, joining a short list of U.S. commercial rocket builders that have successfully launched a vehicle to orbit amidst a growing space industry. </p><p><a href="https://gizmodo.com/firefly-alpha-rocket-reaches-orbit-second-flight-1849611021">Read more...</a></p>

## OAN Is Planning to Infiltrate Homes Through Old, Decaying TV Antennas
 - [https://gizmodo.com/oan-tv-antennas-satellite-dishes-verizon-donald-trump-1849611010](https://gizmodo.com/oan-tv-antennas-satellite-dishes-verizon-donald-trump-1849611010)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 21:41:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ubp433SW--/c_fit,fl_progressive,q_80,w_636/a37e3a872308e1f2982fa2783959a76e.jpg" /><p>One America News, responsible for the some of basest pro-Donald Trump bile available anywhere, reportedly has a plan to once again help its voice crawl its way into the hearts and minds of folks all across the country. Though it’s promoting new streaming deals, the outlet once beloved by Trump has bigger plans toleak…</p><p><a href="https://gizmodo.

## FCC Is Ready to Block Calls From Telecoms That Ignore the Robocall Plague
 - [https://gizmodo.com/fcc-is-ready-to-block-calls-telecoms-robocalls-1849610620](https://gizmodo.com/fcc-is-ready-to-block-calls-telecoms-robocalls-1849610620)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 21:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--vFyFP4AQ--/c_fit,fl_progressive,q_80,w_636/501e994685e78140a701e4bb26b34a85.jpg" /><p>We’ve all <a href="https://gizmodo.com/the-robocall-nightmare-is-getting-worse-1825821386">gotten the calls</a>: IRS and insurance-themed scams beamed to your phone via spoofed numbers from your area code. On some days, the robocalls can feel endless—a tidal wave of spam barraging my back pocket. I’ve been known to leave my phone on perma-silent for

## Bumble Is Apparently Getting Into Speed Dating
 - [https://gizmodo.com/bumble-is-testing-new-speed-dating-feature-1849610524](https://gizmodo.com/bumble-is-testing-new-speed-dating-feature-1849610524)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 20:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--5ewR4Nx3--/c_fit,fl_progressive,q_80,w_636/a1aa02f4d3b58667ccd15262dcaeea92.jpg" /><p>Hey all you sexy singles, are you ready to start speed dating again? The popular dating app Bumble is reportedly testing a speed dating feature in U.K. markets where users can log on to chat with strangers digitally before matching with them and seeing their profiles.<br /></p><p><a href="https://gizmodo.com/bumble-is-testing-new-speed-dating-featur

## Telescope in Chile Spots Huge Debris Trail from NASA's Asteroid Crash Test
 - [https://gizmodo.com/telescope-spots-huge-debris-trail-nasa-dart-1849610800](https://gizmodo.com/telescope-spots-huge-debris-trail-nasa-dart-1849610800)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 20:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--RqZDOCk9--/c_fit,fl_progressive,q_80,w_636/1f18aeabd95aa17ed1b6e1d64af7261b.jpg" /><p>Last week, NASA’s DART spacecraft <a href="https://gizmodo.com/nasa-dart-crashes-into-asteroid-success-1849583961">intentionally crashed</a> into Dimorphos, a petite moonlet orbiting the larger asteroid Didymos. Now, a telescope on the ground in Chile has imaged the massive plume created by the impact in the days following the encounter.</p><p><a hr

## The Best Toys and Collectibles Revealed at Hasbro Pulse Con 2022
 - [https://gizmodo.com/hasbro-pulse-con-2022-reveals-marvel-star-wars-gi-joe-1849610126](https://gizmodo.com/hasbro-pulse-con-2022-reveals-marvel-star-wars-gi-joe-1849610126)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--gBE0zjbv--/c_fit,fl_progressive,q_80,w_636/c715b66f275a5e3ba5da30c0d9912f13.jpg" /><p>Curious what will be draining your bank account in the coming months and well into 2023? This past weekend, <a href="https://gizmodo.com/hasbros-new-power-rangers-figure-just-wants-to-know-wha-1847318957">Hasbro</a> held its <a href="https://gizmodo.com/plush-butts-star-wars-aliens-and-star-trek-army-men-l-1847231866">Pulse Con</a> 2022 event, which

## Florida Residents Reeling After Late Evacuation Orders
 - [https://gizmodo.com/florida-hurricane-ian-late-evacuation-1849610070](https://gizmodo.com/florida-hurricane-ian-late-evacuation-1849610070)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 20:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--QFsXYSbH--/c_fit,fl_progressive,q_80,w_636/de32f1b9bdd3497c9b7b92ebd484da92.jpg" /><p>Parts of Florida remain <a href="https://gizmodo.com/hurricane-ian-recovery-effort-death-toll-1849608194">disaster zones</a> in the wake of Hurricane Ian’s devastation—and, in the aftermath of the storm, some officials are coming under fire for not doing more to prepare their residents for the damage.</p><p><a href="https://gizmodo.com/florida-hurri

## Werewolf By Night Director Michael Giacchino Talks MCU Connections, Horror, and Spider Music
 - [https://gizmodo.com/werewolf-by-night-mcu-giacchino-man-thing-moon-knight-1849602859](https://gizmodo.com/werewolf-by-night-mcu-giacchino-man-thing-moon-knight-1849602859)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 19:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--SJqcN5_D--/c_fit,fl_progressive,q_80,w_636/f08b3d9483a17375e6f62709cc4ec5cd.jpg" /><p>That there’s a brand new <a href="https://gizmodo.com/werewolf-by-night-review-marvel-disney-plus-horror-stre-1849579625">Marvel Studios movie coming to Disney+</a> this week is kind of amazing all on its own. That the film introduces several brand new characters as well as a<a href="https://gizmodo.com/werewolf-by-night-monsters-mcu-1849579373"> wh

## CDC Says We Probably Can't Get Rid of Monkeypox Now
 - [https://gizmodo.com/cdc-says-we-probably-cant-get-rid-of-monkeypox-now-1849610480](https://gizmodo.com/cdc-says-we-probably-cant-get-rid-of-monkeypox-now-1849610480)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 19:32:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Z_4D3GrD--/c_fit,fl_progressive,q_80,w_636/207eb59e853332ce52dacc907c23f0f9.jpg" /><p>A new report from the U.S. Centers for Disease Control and Prevention offers some good and bad news about the country’s ongoing monkeypox outbreak. New cases are slowing down, likely thanks to a combination of vaccination and education efforts. But it’s also likely that the virus won’t be eradicated here and will…</p><p><a href="https://gizmodo.com/

## Hackers Leak 500 GB of Data Stolen From Los Angeles School District
 - [https://gizmodo.com/hackers-leak-500-gb-stolen-los-angeles-school-district-1849609626](https://gizmodo.com/hackers-leak-500-gb-stolen-los-angeles-school-district-1849609626)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 19:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--JhmBeXmI--/c_fit,fl_progressive,q_80,w_636/0be54f4e0b986259b20df0b15b3065a2.jpg" /><p>Last month, the ransomware gang Vice Society, hacked the Los Angeles Unified School District, the second largest in the country, leaving the computer system paralyzed. Two weeks after the initial attack, the perpetrators demanded money for the return of the stolen data.<br /></p><p><a href="https://gizmodo.com/hackers-leak-500-gb-stolen-los-angeles-

## The New Gundam Show Is Here, Queer, and We're Already Very Used to It
 - [https://gizmodo.com/gundam-witch-from-mercury-suletta-miorine-wives-lgbtq-1849610157](https://gizmodo.com/gundam-witch-from-mercury-suletta-miorine-wives-lgbtq-1849610157)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--D2P50Bcl--/c_fit,fl_progressive,q_80,w_636/24919dc38776346bafb906761033db35.png" /><p>Welcome to the <a href="https://gizmodo.com/the-io9-guide-to-gundam-1721095697">future of <em>Gundam</em></a>, my friends: we’ve got <a href="https://gizmodo.com/gundam-witch-from-mercury-release-date-streaming-1849500148">a robot school</a>, we’ve got megacorporation politics, and we’ve got girls defending each other’s honor by engaging in giant me

## Supreme Court Is Putting the Future of Section 230 Protections on Its Docket
 - [https://gizmodo.com/supreme-court-section-230-protections-new-cases-google-1849609879](https://gizmodo.com/supreme-court-section-230-protections-new-cases-google-1849609879)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 18:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--94yEZ0Cw--/c_fit,fl_progressive,q_80,w_636/e57b9515147287bb066bbf043516bec7.jpg" /><p>On Monday, the Supreme Court announced nine cases it intends to hear in its upcoming term, including <a href="https://www.supremecourt.gov/search.aspx?filename=/docket/docketfiles/html/public/21-1333.html" rel="noopener noreferrer" target="_blank"><em>Renaldo Gonzalez v. Google</em></a>.<em> </em>The case directly questions the protections afforded 

## Everything We Spotted in Marvel's New Black Panther: Wakanda Forever Trailer
 - [https://gizmodo.com/marvel-black-panther-2-wakanda-forever-trailer-breakdow-1849608443](https://gizmodo.com/marvel-black-panther-2-wakanda-forever-trailer-breakdow-1849608443)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 18:15:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--ZhjN94ji--/c_fit,fl_progressive,q_80,w_636/f15919069135c0100340aff41ef76c85.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--wlfwD_Db--/c_fit,fl_progressive,q_80,w_636/f15919069135c0100340aff41ef76c85.mp4" type="video/mp4" /></video><p>Full disclosure: this trailer made me scream. There’s so much about the newest <a href="https://gizmodo.com/black-panther-2-new-trailer-wakanda-forever-1849608204"><e

## NASA's Ingenuity Mars Helicopter Had Mystery Debris Stuck to Its Leg
 - [https://gizmodo.com/nasa-mars-ingenuity-helicopter-debris-stuck-to-leg-1849609061](https://gizmodo.com/nasa-mars-ingenuity-helicopter-debris-stuck-to-leg-1849609061)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 18:10:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--V69xr6EJ--/c_fit,fl_progressive,q_80,w_636/a8bbd85fbb057f2b2af76b247dff6bf3.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--pN9Mpvmg--/c_fit,fl_progressive,q_80,w_636/a8bbd85fbb057f2b2af76b247dff6bf3.mp4" type="video/mp4" /></video><p>NASA’s <a href="https://gizmodo.com/nasa-ingenuity-helicopter-mars-inclinometer-1849028558">Ingenuity helicopter</a> just completed its 33rd flight on Mars, and this 

## Team Picard Plans to Fight the Future in This Deleted Scene
 - [https://gizmodo.com/picard-season-two-star-trek-deleted-scene-blu-ray-1849609284](https://gizmodo.com/picard-season-two-star-trek-deleted-scene-blu-ray-1849609284)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 17:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--H0lrzpbL--/c_fit,fl_progressive,q_80,w_636/07e00dfc2a0b3e2e6b2663056860a310.png" /><p>The second season finale of <a href="https://gizmodo.com/star-trek-picard-season-3-trailer-tng-new-enterprise-1849513404"><em>Picard</em></a> was a <a href="https://gizmodo.com/star-trek-picard-season-2-episode-10-recap-farewell-bor-1848871733">truly bizarre</a> hour of television, full of incredibly rushed plot wrap-ups and massive new developments

## Avengers: Secret Wars Enlists a Familiar Marvel Writer
 - [https://gizmodo.com/marvel-avengers-secret-wars-writer-loki-dr-strange-1849609384](https://gizmodo.com/marvel-avengers-secret-wars-writer-loki-dr-strange-1849609384)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ThPy1ZXS--/c_fit,fl_progressive,q_80,w_636/13e63d4556258e0acc844b547ea3d726.jpg" /><p><em>Loki</em> breakout writer Michael Waldron will return to the <a href="https://gizmodo.com/marvel-release-dates-when-to-see-upcoming-mcu-movies-a-1848196856">Marvel Cinematic Universe</a> after the success of <a href="https://gizmodo.com/fantastic-four-marvel-doctor-strange-2-end-credits-mcu-1849479593"><em>Doctor Strange in the Multiverse of Mad

## Bye MOM: India's Mars Orbiter Goes Silent After Running Out of Fuel
 - [https://gizmodo.com/indias-mars-orbiter-silent-running-out-of-fuel-isro-1849609093](https://gizmodo.com/indias-mars-orbiter-silent-running-out-of-fuel-isro-1849609093)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 16:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--t2_A7h6s--/c_fit,fl_progressive,q_80,w_636/72414ac5c9d0790627048fed1518cb09.jpg" /><p>In orbit around Mars since 2014, India’s Mangalyaan spacecraft has suddenly gone silent. Mission controllers are no longer able to communicate with the orbiter, which is assumed to have run out of fuel and battery power, but only after long-exceeding its mission lifespan. <br /></p><p><a href="https://gizmodo.com/indias-mars-orbiter-silent-running-o

## Paleogeneticist Svante Pääbo Picks Up Nobel Prize for Human Origins Research
 - [https://gizmodo.com/svante-paabo-nobel-prize-human-origins-neanderthals-1849609090](https://gizmodo.com/svante-paabo-nobel-prize-human-origins-neanderthals-1849609090)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 16:54:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--zaRjCP0e--/c_fit,fl_progressive,q_80,w_636/9ba1baca178d54a14243ad2c886eae1d.jpg" /><p>The Nobel Assembly today awarded Swedish geneticist Svante Pääbo the Nobel Prize in Physiology or Medicine for his research into human origins.</p><p><a href="https://gizmodo.com/svante-paabo-nobel-prize-human-origins-neanderthals-1849609090">Read more...</a></p>

## Emergency Workers Continue Door-to-Door Search as Hurricane Ian's Death Toll Rises
 - [https://gizmodo.com/hurricane-ian-recovery-effort-death-toll-1849608194](https://gizmodo.com/hurricane-ian-recovery-effort-death-toll-1849608194)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 16:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--aQ4_2M-E--/c_fit,fl_progressive,q_80,w_636/4a5871fbd890c3ecb1d1743110f74bd4.jpg" /><p>Hurricane Ian has killed dozens of people. Though the full toll of the storm remains unclear, most deaths have been reported in Lee County, Florida, where Ian made landfall <a href="https://gizmodo.com/hurricane-ian-hits-florida-1849590270">last Wednesday</a> as a powerful Category 4 storm. <a href="https://www.reuters.com/world/us/hurricane-ravaged

## A Filmmaker Chases Love Across the Universes in This Sneak Peek at A Fractured Infinity
 - [https://gizmodo.com/scifi-book-excerpt-queer-multiverses-fractured-infinity-1849519685](https://gizmodo.com/scifi-book-excerpt-queer-multiverses-fractured-infinity-1849519685)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--QBgGVdFo--/c_fit,fl_progressive,q_80,w_636/888ac1aa0e25e2dce87aa9cb3cf7ba8f.jpg" /><p>What would you do if you fell in love—with a person who’s your husband in <a href="https://gizmodo.com/the-16-most-horrible-alternate-realities-1784081982">an alternate reality</a>? Things only get <a href="https://gizmodo.com/are-parallel-universes-real-1845216715">stranger and more confusing</a>, not to mention more dangerous, from there for the p

## Hurricane Ian Pushes NASA's Next Moon Rocket Launch Attempt to November
 - [https://gizmodo.com/nasa-artemis-1-sls-launch-november-hurricane-ian-1849608767](https://gizmodo.com/nasa-artemis-1-sls-launch-november-hurricane-ian-1849608767)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 15:40:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--y2gd68R1--/c_fit,fl_progressive,q_80,w_636/d3e39942a8fd5f734997f51cc3154adc.jpg" /><p>At first it was technical hurdles, but now a natural disaster has forced a delay to NASA’s Artemis 1 mission. With the rocket tucked inside the space agency’s gigantic assembly building and with normal ground operations set to resume this week, Space Launch System won’t take flight until November 12 at the earliest. </p><p><a href="https://gizmodo.c

## Who Should Play Jean Grey? | io9 Picks
 - [https://gizmodo.com/who-should-play-jean-grey-io9-picks-1849587389](https://gizmodo.com/who-should-play-jean-grey-io9-picks-1849587389)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 15:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--WOddzo7z--/c_fit,fl_progressive,q_80,w_636/5414d8d55d0d5a0fcfab4132462eeaf0.jpg" /><p><a href="https://gizmodo.com/who-should-play-jean-grey-io9-picks-1849587389">Read more...</a></p>

## Bruce Willis Is Not Selling His Face
 - [https://gizmodo.com/bruce-willis-deepfake-deepcake-reps-deny-face-sale-1849608270](https://gizmodo.com/bruce-willis-deepfake-deepcake-reps-deny-face-sale-1849608270)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 15:09:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Kd8Vxdzi--/c_fit,fl_progressive,q_80,w_636/6843a0ad98eebfebc694261e9e7fc33e.jpg" /><p>Bruce Willis was back in headlines last week as news broke that the actor had seemingly <a href="https://gizmodo.com/bruce-willis-sells-likeness-ai-deepfake-1849601061">sold the rights to his face</a> to Deepcake, a Russian AI company specializing in deepfakes. Willis’ representatives, however, are contesting these reports.<br /></p><p><a href="http

## Kevin Feige Teases Werewolf by Night's Importance to the MCU
 - [https://gizmodo.com/kevin-feige-werewolf-by-night-marvel-monsters-mcu-1849607170](https://gizmodo.com/kevin-feige-werewolf-by-night-marvel-monsters-mcu-1849607170)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 14:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--J8eJhXDv--/c_fit,fl_progressive,q_80,w_636/085bd5498177f9eff87bc0181340b6f2.png" /><p>Mike Dougherty is making a <em>Trick ‘R Treat</em> sequel. <em>Scream 6</em> teases its timeline after the events of the last movie. <em>The Simpsons</em> takes on <em>It</em> in the next “Treehouse of Horror” episode. Plus, what’s next on <em>Stargirl</em> and <em>House of the Dragon</em>. Spoilers, away!<br /></p><p><a href="https://gizmodo.com/ke

## Google Japan Puts Entire Keyboard on One Long Stick
 - [https://gizmodo.com/google-japan-gboard-stick-april-fools-keyboard-custom-1849608268](https://gizmodo.com/google-japan-gboard-stick-april-fools-keyboard-custom-1849608268)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 14:00:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--cLO02Zyl--/c_fit,fl_progressive,q_80,w_636/733a7d3e9f148220e1ae235c4bb78c76.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--THOwHmMH--/c_fit,fl_progressive,q_80,w_636/733a7d3e9f148220e1ae235c4bb78c76.mp4" type="video/mp4" /></video><p>Several years ago, Google Japan started cooking up weird novelty keyboards as an annual April Fools’ Day prank. Most of the creations, including a working version of 

## Google Shuts Down Translate Services in Mainland China
 - [https://gizmodo.com/google-shuts-down-translate-services-in-mainland-china-1849608265](https://gizmodo.com/google-shuts-down-translate-services-in-mainland-china-1849608265)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 13:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--DF8mXXID--/c_fit,fl_progressive,q_80,w_636/16cf59af46e1fb65f9cd67dcfed3a813.jpg" /><p>Folks on the Chinese mainland looking to find <a href="https://gizmodo.com/google-translate-can-help-doctors-bridge-the-language-g-1832881294">occasionally garbled</a> translations of foreign languages will be out of luck, as Google announced over the weekend it was pulling back on one of the few digital services it offered in the country.</p><p><a 

## Hurricanes and Climate | Extreme Earth
 - [https://gizmodo.com/hurricanes-and-climate-extreme-earth-1849608250](https://gizmodo.com/hurricanes-and-climate-extreme-earth-1849608250)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 13:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--MJVSf-Q9--/c_fit,fl_progressive,q_80,w_636/8170ed564e7522a6fef3fdb103720d0b.jpg" /><p><a href="https://gizmodo.com/hurricanes-and-climate-extreme-earth-1849608250">Read more...</a></p>

## Black Panther: Wakanda Forever's New Trailer Is a War for the Ages
 - [https://gizmodo.com/black-panther-2-new-trailer-wakanda-forever-1849608204](https://gizmodo.com/black-panther-2-new-trailer-wakanda-forever-1849608204)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 13:19:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--6xmekSlc--/c_fit,fl_progressive,q_80,w_636/450249b1de73501d988a520f98c9a38d.png" /><p>The new <a href="https://gizmodo.com/black-panther-2-wakanda-forever-runtime-ryan-coogler-1849597440"><em>Black Panther: Wakanda Forever</em></a><em> </em>trailer has just been released. The sequel to <a href="https://gizmodo.com/black-panther-wakanda-forever-mcu-trailer-1849521182">Ryan Coogler’s</a> record-breaking first installment is a tribute t

## Kim Kardashian Will Pay SEC $1.26 Million Over Instagram Ad for Worthless Crypto
 - [https://gizmodo.com/kim-kardashian-sec-million-crypto-ad-instagram-facebook-1849607978](https://gizmodo.com/kim-kardashian-sec-million-crypto-ad-instagram-facebook-1849607978)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 12:01:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--sIZyZGIw--/c_fit,fl_progressive,q_80,w_636/0c19228143d6deaf870a15a324fa5a78.jpg" /><p>Kim Kardashian has agreed to fork over $1.26 million as part of a settlement with the Securities and Exchange Commission after she posted a cryptocurrency ad to Instagram in 2021. Kardashian, who’s worth $1.8 billion, won’t admit wrongdoing but has agreed not to promote any crypto for the next three years, according…</p><p><a href="https://gizmodo.c

## Wisk Debuts Latest Air Taxi That Looks Like a Big Yellow School Bus With Wings
 - [https://gizmodo.com/wisk-air-taxi-prototype-6th-generation-yellow-1849603361](https://gizmodo.com/wisk-air-taxi-prototype-6th-generation-yellow-1849603361)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 10:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--eqVdi6XB--/c_fit,fl_progressive,q_80,w_636/0c10a9d11fdcb12d01fa0a143252bca3.jpg" /><p>The famed <a href="https://gizmodo.com/kittyhawk-air-taxi-larry-page-1849564831">Kittyhawk air taxi company is no more</a>, but one of the initiatives spawned from its failed attempts to create quiet, fast, and cheap air taxis—Wisk Aero—has a new autonomous aircraft design that the company claims may be the best chance yet to see big yellow school b

## The Walking Dead Begins the End With More of the Middle
 - [https://gizmodo.com/walking-dead-recap-lockdown-season-11-episode-17-1849590228](https://gizmodo.com/walking-dead-recap-lockdown-season-11-episode-17-1849590228)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 02:05:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--dkUoGeH_--/c_fit,fl_progressive,q_80,w_636/e655ee76cc9f1e5e98dca159fad8907c.png" /><p>The third act of<em> <a href="https://gizmodo.com/walking-dead-final-trailer-season-11-comic-con-zombies-1849196001">The Walking Dead</a></em>’s 11th and final season has begun, but it doesn’t seem like anyone notified the show. Other than a quick montage of familiar faces at the start, with a bit of narration by Judith (Cailey Fleming), it’s an unc

## House of the Dragon Brings the Fire and Blood in a Near-Perfect Episode
 - [https://gizmodo.com/house-of-the-dragon-recap-episode-7-driftmark-1849603151](https://gizmodo.com/house-of-the-dragon-recap-episode-7-driftmark-1849603151)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-03 01:59:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ijD-uVDh--/c_fit,fl_progressive,q_80,w_636/40eeaecc03b1e35640d06ac156ce0767.jpg" /><p><a href="https://gizmodo.com/targaryen-names-house-of-the-dragon-game-of-thrones-1849462873">Targaryen</a> blood has been spilled. The unbelievable tension that has been building between Rhaenyra (Emma D’Arcy) and Alicent (Olivia Cooke) since the beginning erupted in a mesmerizing episode of <a href="https://gizmodo.com/house-of-the-dragon-cut-bisex


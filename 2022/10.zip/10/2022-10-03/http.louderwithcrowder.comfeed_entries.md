# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Watch: The Daily Show(?) torches Kamala Harris over tossing the word salad, compares her to fictional 'Veep'
 - [https://www.louderwithcrowder.com/kamala-harris-veep-daily-show](https://www.louderwithcrowder.com/kamala-harris-veep-daily-show)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-03 21:12:27+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31856916&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C118" /><br /><br /><p>The Daily Show discovered Kamala Harris likes to toss the salad. <a href="https://www.louderwithcrowder.com/kamal-harris-mail-in-voting" target="_blank">Toss the WORD salad</a>. Kamala has <a href="https://www.louderwithcrowder.com/kamala-harris-joy-reid" target="_blank">a way with words</a> that exposes her as someone <a href="https://ww

## Seattle Seahawks threaten GOP candidate all because her VETERAN husband wore a jersey in a commercial
 - [https://www.louderwithcrowder.com/seattle-seahawks-smiley-cease-desist](https://www.louderwithcrowder.com/seattle-seahawks-smiley-cease-desist)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-03 20:41:31+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31856797&amp;width=1200&amp;height=600&amp;coordinates=0%2C0%2C0%2C198" /><br /><br /><p>There's something going on in Washington's U.S. Senate race. The Seattle Seahawks are the THIRD corporation to threaten Republican candidate Tiffany Smiley with a cease and desist order over a campaign commercial. Here is the offending commercial from three weeks ago.</p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-

## Joe Biden compares his... dad to Satan in order to hit Republicans on Abortion? Alrighty then.
 - [https://www.louderwithcrowder.com/joe-biden-tweet-dad-alternative](https://www.louderwithcrowder.com/joe-biden-tweet-dad-alternative)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-03 18:43:27+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31856342&amp;width=1200&amp;height=600&amp;coordinates=0%2C0%2C0%2C242" /><br /><br /><p>Democrats are desperate to make the midterm election about Roe v Wade. And I realize I'm not supposed to insult my colleagues who are social media professionals by implying their job is done by interns who take the short bus to work. That means an adult professional thought this would be a good idea for a tweet. Joe Biden using a quote fr

## Watch: SNL reaches new level of cringe with unfunny cold open about how unfunny their Trump sketches are
 - [https://www.louderwithcrowder.com/snl-cold-open-manning](https://www.louderwithcrowder.com/snl-cold-open-manning)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-03 17:44:12+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31856036&amp;width=1200&amp;height=600&amp;coordinates=0%2C0%2C0%2C198" /><br /><br /><p>SNL had its 48th season premiere on Saturday. The show hasn't been good for, at least, the last eighteen of those. For going on two decades, viewers have questioned if the <a href="https://www.louderwithcrowder.com/rob-schneider-snl-over" target="_blank">writers and cast members know that they stink</a> while making the show. And figured 

## The real reason why Trevor Noah is leaving 'The Daily Show'
 - [https://www.louderwithcrowder.com/trevor-noah-leaves-daily-show](https://www.louderwithcrowder.com/trevor-noah-leaves-daily-show)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-03 16:54:22+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31855847&amp;width=1200&amp;height=600&amp;coordinates=0%2C0%2C0%2C298" /><br /><br /><p>News broke last week that <a href="https://www.louderwithcrowder.com/search/?q=trevor+noah" target="_blank">Trevor Noah</a> is leaving The Daily Show. I know what most of you are thinking. "Oh no! What the sh*t are we going to do now?" His unique comedy staying will be tough to replace. Crowder and the gang discuss a few options:</p><p cl

## 'I don't know about you mother f***ers': Florida Man goes viral for his colorful endorsement of Ron DeSantis
 - [https://www.louderwithcrowder.com/florida-man-desantis-ian](https://www.louderwithcrowder.com/florida-man-desantis-ian)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-03 14:37:22+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31855186&amp;width=1200&amp;height=600&amp;coordinates=0%2C0%2C0%2C429" /><br /><br /><p>Hurricane Ian wreaked havoc on the state of Florida and Gov. Ron DeSantis has been quick to start putting the state back together. There have been some attempts <a href="https://www.louderwithcrowder.com/ron-desantis-looting" target="_blank">from opponents</a> and <a href="https://www.louderwithcrowder.com/ron-desantis-reporter-hurricane-

## Viola Davis' 'The Woman King' was pro-slavery? (Show Notes)
 - [https://www.louderwithcrowder.com/show-notes-woman-king](https://www.louderwithcrowder.com/show-notes-woman-king)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-03 13:54:56+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31855034&amp;width=1200&amp;height=600&amp;coordinates=0%2C0%2C0%2C120" /><br /><br /><p>Time to expose the historical inaccuracies of "The Woman King." There are a lot! Also, it's no longer hyperbole to call the Washington Post the enemy of the people. And it looks like we won't have Trevor Noah to kick around anymore.</p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; pa

## Watch: Kari Lake displays the artistry of shutting down a reporter when challenged on abortion
 - [https://www.louderwithcrowder.com/kari-lake-reporter-life](https://www.louderwithcrowder.com/kari-lake-reporter-life)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-03 13:13:15+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31854840&amp;width=1200&amp;height=600&amp;coordinates=0%2C0%2C0%2C200" /><br /><br /><p>Kari Lake has a 2.2% polling lead in the Arizona governor's race as per the RCP average. I pray she pulls off the win, because it is so enjoyable watching her handle the media. When a conservative shuts down a reporter in the best way possible, it tends to involve righteous indignation and a mic drop moment. All good things. But when Kari

## Conservative anti-crime Senate ad so hits the target, Starbucks and a liberal newspaper want to shut it down
 - [https://www.louderwithcrowder.com/starbucks-seattle-times-senate-ad](https://www.louderwithcrowder.com/starbucks-seattle-times-senate-ad)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-03 12:44:48+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=31854731&amp;width=1200&amp;height=600&amp;coordinates=0%2C0%2C0%2C383" /><br /><br /><p>Tiffany Smiley is the Republican running to unseat Sen. Patty Murray in the U.S. Senate. She just released an ad attacking Murray for being soft on crime that if Starbucks and the <em>Seattle Times</em> have their druthers you won't get to see. That's why you should watch it right now.</p><div class="rm-embed embed-media"><blockquote clas

## Billy Eichner lashes out at 'homophobes' for his graphic gay sex comedy 'Bros' tanking at the box office
 - [https://www.louderwithcrowder.com/billy-eichner-bros](https://www.louderwithcrowder.com/billy-eichner-bros)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2022-10-03 12:07:36+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=31854619&amp;width=1200&amp;height=600&amp;coordinates=0%2C64%2C0%2C134" /><br /><br /><p>When you make a Hollywood movie for a niche audience that tanks at the box office, it is best practices to attack and insult the people from outside your niche audience for your failure. That's what hateful douchebag Billy Eichner is doing over his movie <em>Bros</em>.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img 


# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## LIVE with Tyroe Muhafidin (Theo, The Rings of Power)
 - [https://www.youtube.com/watch?v=5OnZujmVR9o](https://www.youtube.com/watch?v=5OnZujmVR9o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-10-04 00:00:00+00:00

We'll chat LIVE with Tyroe Muhafidin, Theo in The Lord of the Rings: The Rings of Power!

#theringsofpower #lordoftherings #ringsofpower


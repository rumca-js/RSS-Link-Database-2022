# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Intel PLEASE let me Overclock this! - BCLK Overclocking on a B660M board
 - [https://www.youtube.com/watch?v=yayAQAC1XiE](https://www.youtube.com/watch?v=yayAQAC1XiE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-10-04 00:00:00+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off
Check out SignalRGB and sync all your RGB peripherals at https://bit.ly/LinusTips

MSI's MAG B660M Mortar Max motherboard has a secret chip up its sleeve that people all over the world won't get access to until after Raptor Lake launches. Is Base Clock Overclocking worth the hassle in modern games and productivity? Why are we locked out of this on non-K CPUs if we want to try it out?

Discuss on the forum: https://linustechtips.com/topic/1459095-stop-neutering-your-products-intel/

Buy an Intel Core i5 12500: https://geni.us/kv6yR

Buy an MSI MAG B600M Mortar: https://geni.us/eT7fa

Buy a kit of Crucial Ballistix 3200 DDR4 RAM: https://geni.us/kuXYf

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear


FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:14 B660M Mortar Max
2:25 Overclocking
6:00 5.25GHz Results
7:12 AMD
9:13 BCLK Issues
10:15 Conclusion
13:06 Outro

## I Thought My Childhood was LOST
 - [https://www.youtube.com/watch?v=foLPX4YTwHk](https://www.youtube.com/watch?v=foLPX4YTwHk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2022-10-03 00:00:00+00:00

Get $25 off all pairs of Vessi Footwear with offer code LinusTechTips at https://www.Vessi.com/LinusTechTips

Check out Crucial's gaming products at https://crucial.gg/LTT_CrucialWellPlayedGaming

Linus tries to backup some embarrassing VHS tapes from his childhood with the help of Mark's VCR.

Discuss on the forum: https://linustechtips.com/topic/1458916-i-want-my-data-back/

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:18 Will this work?
3:40 What makes a GOOD VCR?
6:49 What else you'll need
9:44 WATCHING THE TAPES
13:04 The capture setup
13:34 TEENAGE LINUS
19:01 Linus tries French
19:39 Improving the quality
21:15 Bad Backup strategies
23:15 Outro


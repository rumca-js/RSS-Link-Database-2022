# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Iran’s supreme leader breaks silence on protests, blames U.S.
 - [https://www.politico.com/news/2022/10/03/iran-supreme-leader-protests-us-00059981](https://www.politico.com/news/2022/10/03/iran-supreme-leader-protests-us-00059981)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-10-03 06:13:53+00:00

Ayatollah Ali Khamenei sharply condemned the protests as a foreign plot to destabilize Iran.


# Source:ComputerWorld, URL:https://www.computerworld.com/index.rss, language:en-US

## Apple will dominate the enterprise, says Kandji CEO
 - [https://www.computerworld.com/article/3675540/apple-will-dominate-the-enterprise-says-kandji-ceo.html#tk.rss_all](https://www.computerworld.com/article/3675540/apple-will-dominate-the-enterprise-says-kandji-ceo.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-10-03 17:02:00+00:00

<article>
	<section class="page">
<p>In yet another sign that Apple's growth in the enterprise market <a href="https://www.computerworld.com/article/3675331/apples-enterprise-it-pitch-management-security-identity.html">is still expanding</a>, Apple device management company <a href="https://www.kandji.io/" rel="nofollow noopener" target="_blank">Kandji</a> has its own news in the wake of <a href="https://www.computerworld.com/article/3674843/jamf-touts-big-boost-to-enterprise-security-at-jnuc.ht

## Windows 11 22H2 is out, so why isn’t your PC getting it?
 - [https://www.computerworld.com/article/3675334/windows-11-22h2-is-out-so-why-isnt-your-pc-getting-it.html#tk.rss_all](https://www.computerworld.com/article/3675334/windows-11-22h2-is-out-so-why-isnt-your-pc-getting-it.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-10-03 16:14:00+00:00

<article>
	<section class="page">
<p style="font-weight: 400;"><a href="https://www.computerworld.com/article/3673373/windows-11-22h2-small-but-welcome-changes.html">Windows 11 22H2</a>, released two weeks ago, is another step closer to <a href="https://www.computerworld.com/article/3673902/windows-11-2022-update-is-the-version-enterprises-can-move-to.html">being an acceptable upgrade to Windows 10</a>. But many Windows users aren't yet being offered it for download.</p><p style="font-weight: 40

## Microsoft Teams cheat sheet: How to get started
 - [https://www.computerworld.com/article/3262104/microsoft-teams-cheat-sheet.html#tk.rss_all](https://www.computerworld.com/article/3262104/microsoft-teams-cheat-sheet.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2022-10-03 10:00:00+00:00

<article>
	<section class="page">
<p>If your organization uses Office, chances are you’ve encountered Microsoft Teams, at least for video meetings. But it’s capable of a lot more, providing an effective way for groups of people to collaborate on work and advance business objectives.</p><p>Teams is, at its core, group chat software with videoconferencing capabilities and some interesting features around working with documents and spreadsheets, especially those stored in SharePoint and OneDrive fo


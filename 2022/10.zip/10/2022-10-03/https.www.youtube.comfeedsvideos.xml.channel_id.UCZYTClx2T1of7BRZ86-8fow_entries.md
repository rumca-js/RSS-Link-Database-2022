# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Why Don’t Jellyfish Look Like That?
 - [https://www.youtube.com/watch?v=Zsk9HCgFIpY](https://www.youtube.com/watch?v=Zsk9HCgFIpY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-10-04 00:00:00+00:00

Start speaking a new language in 3 weeks with Babbel. Get up to 65% off in your subscription here: https://go.babbel.com/t?bsc=1200m60-youtube-scishow-oct-2022&btp=default&utm_term=generic_v1&utm_medium=paidsocial&utm_source=YouTube&utm_content=Influencer..scishow..USA..YouTube

When you think of a jellyfish, do you imagine an angelic stingy blob? That's just one stage of the life of a jelly!

Hosted by: Stefan Chin

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Matt Curls, Alisa Sherbow, Dr. Melvin Sanicas, Harrison Mills, Adam Brainard, Chris Peters, charles george, Piya Shedden, Alex Hackman, Christopher R, Boucher, Jeffrey Mckishen, Ash, Silas Emrys, Eric Jensen, Kevin Bealer, Jason A Saslow, Tom Mosner, Tomás Lagos González, Jacob, Christoph Schwanke, Sam Lutfi, Bryan Cloer
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow #science #education
----------
Sources:

https://www.nature.com/articles/srep12037 
https://www.ingentaconnect.com/content/umrsmas/bullmar/2016/00000092/00000003/art00005;jsessionid=a4eds1b5n96k8.x-ic-live-01# (of note: this source says that the previous source is bull hockey, but I think they really agree more than they disagree)
https://www.researchgate.net/publication/248575476_Plankton_Dynamics_and_Aurelia_aurita_Production_in_Two_Contrasting_Ecosystems_Comparisons_and_Consequences 
https://www.academia.edu/20929116/The_effect_of_temperature_on_the_benthic_stages_of_Cyanea_Cnidaria_Scyphozoa_and_their_seasonal_distribution_in_the_Niantic_River_estuary_connecticut 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3432801/ 
Graphics inspiration:
https://www.nsf.gov/news/mmg/mmg_disp.jsp?med_id=65102&from=search_list (it’s public domain: https://commons.wikimedia.org/wiki/File:Reproductive_cycle_of_jellyfish.jpg )
https://www.researchgate.net/figure/A-Life-cycle-of-the-jellyfish-Aurelia-aurita-The-asexual-stage-is-polyp_fig1_51796527 The scyphistoma stage shows another polyp budding off of a polyp (asexual reproduction). The alternative strobila stage shows a juvenile medusa growing off the polyp (the mature medusa can then sexually reproduce and create the planula larva that turns into a polyp).

IMAGES

https://en.wikipedia.org/wiki/File:Mastigias_papua_-_Tokyosealifepark_-_2019_1_8.webm
https://oceanexplorer.noaa.gov/okeanos/explorations/ex1404/logs/oct4/oct4.html

https://www.gettyimages.com/detail/photo/little-girl-with-prosthetic-leg-at-occupational-royalty-free-image/1167824400?adppopup=true
https://commons.wikimedia.org/wiki/File:Reproductive_cycle_of_jellyfish.jpg
https://commons.wikimedia.org/wiki/File:Cassiopeia_xamachana_polyp.jpg
https://www.gettyimages.com/detail/photo/jellyfish-with-neon-glow-light-effect-royalty-free-image/1010016014?adppopup=true
https://commons.wikimedia.org/wiki/File:Turritopsis_rubra_10893106.jpg
https://commons.wikimedia.org/wiki/File:Cassiopea_mediterranea_09.jpg
https://www.gettyimages.com/detail/video/jellyfish-on-the-seashore-species-of-jellyfish-stock-footage/1266787434?phrase=jellyfish%20beach&adppopup=true
https://www.gettyimages.com/detail/video/spotted-jellyfish-stock-footage/641983292?phrase=jellyfish&adppopup=true
https://www.gettyimages.com/detail/photo/fishing-trawler-royalty-free-image/649765276?phrase=trawler&adppopup=true
https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0188601

## Carbon Nano-Onions are About to be a Big Deal
 - [https://www.youtube.com/watch?v=wGo68YtnKsw](https://www.youtube.com/watch?v=wGo68YtnKsw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-10-03 00:00:00+00:00

Head to https://shopify.com/scishow to learn more and for a free trial. Thanks to Shopify, a commerce platform that helps you start, grow, and manage your business, for supporting SciShow.

Don't let carbon nanotubes get all the hype! Carbon nano-onions might be the future of medicine and electronics and they just got much easier to make.

thumbnail: Takashi Shirai from NITech, Japan
by: Hank Green (he/him)

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Matt Curls, Alisa Sherbow, Dr. Melvin Sanicas, Harrison Mills, Adam Brainard, Chris Peters, charles george, Piya Shedden, Alex Hackman, Christopher R, Boucher, Jeffrey Mckishen, Ash, Silas Emrys, Eric Jensen, Kevin Bealer, Jason A Saslow, Tom Mosner, Tomás Lagos González, Jacob, Christoph Schwanke, Sam Lutfi, Bryan Cloer
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow #science #education #nanotechnology 
----------
Sources:
https://www.eurekalert.org/news-releases/960446 
https://onlinelibrary.wiley.com/doi/10.1002/cnma.201800583 
https://royalsocietypublishing.org/doi/10.1098/rsos.170981 
https://pubs.rsc.org/en/content/articlelanding/2022/GC/D1GC04785J 
https://www.sciencedirect.com/science/article/pii/S0020169317302426 
https://www.sciencedirect.com/topics/agricultural-and-biological-sciences/carbon-nanotubes 
https://www.britannica.com/science/graphene/Graphene-as-a-two-dimensional-material 
https://www.sciencedirect.com/science/article/abs/pii/S0008622314001997?via%3Dihub 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3050644 
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3601907/ 
https://www.sciencedirect.com/topics/engineering/functionalization 
https://www.sciencedirect.com/sdfe/reader/pii/S2352492820329779/pdf 
https://www.sciencedirect.com/science/article/pii/S1773224721000940 
http://www.sfu.ca/phys/346/121/resources/physics_of_microwave_ovens.pdf 
https://iopscience.iop.org/article/10.1088/2053-1591/aac05b
https://youtu.be/myrY_0JfdeA

https://www.gettyimages.com/detail/video/aerial-view-solar-panel-stock-footage/1317803000?adppopup=true
https://commons.wikimedia.org/wiki/File:Allotropes_Of_Carbon.png
https://commons.wikimedia.org/wiki/File:Blue_LED_and_Reflection.jpg
https://royalsocietypublishing.org/doi/10.1098/rsos.170981
https://commons.wikimedia.org/wiki/File:Blood_vessels_brain_english.jpg
https://www.gettyimages.com/detail/photo/woman-checking-glucose-level-with-a-remote-sensor-royalty-free-image/1160718483?adppopup=true
https://www.gettyimages.com/detail/photo/aerial-view-of-two-workers-installing-solar-panels-royalty-free-image/1368229727?adppopup=true
https://www.eurekalert.org/multimedia/944849
https://commons.wikimedia.org/wiki/File:FlyingThroughNanotube.png
https://commons.wikimedia.org/wiki/File:Graphen.jpg

No Nanodiamonds? Use Fish Scales!


# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Unusual Video Game Power-ups That Bamboozled Us
 - [https://www.youtube.com/watch?v=t_2TeNTO5co](https://www.youtube.com/watch?v=t_2TeNTO5co)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-10-04 00:00:00+00:00

Some video game power-ups come from out of nowhere and end up more strange than powerful. Here are some of our favorite examples in gaming.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:59 Number 10
2:40 Number 9
4:03 Number 8
5:33 Number 7
6:29 Number 6
7:37 Number 5
8:46 Number 4
10:00 Number 3
11:21 Number 2
12:51 Number 1

## 9 Gaming Mysteries That Were NEVER SOLVED
 - [https://www.youtube.com/watch?v=zRJLwWn3sLI](https://www.youtube.com/watch?v=zRJLwWn3sLI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-10-03 00:00:00+00:00

Some video game mysteries are still leaving gamers puzzled to this very day. Here are 9 intriguing examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1


SOURCES


9 
https://www.reddit.com/r/FF06B5/comments/wpduod/newcomer_sticky/

8
https://reddead.fandom.com/wiki/Gavin

https://reddead.fandom.com/wiki/Letter_to_Nigel_from_Tom

https://gamerant.com/red-dead-redemption-2-everything-need-know-finding-gavin/


7
https://mariomystery.fandom.com/wiki/Noki_Bay_book

6
https://half-life.fandom.com/wiki/Borealis

5
http://www.atarihq.com/museum/miscatari/mirai.html

https://forums.atariage.com/topic/65900-about-atari-mirai/

Unreleased book cover: https://www.pinterest.es/pin/185773553354331915/


3
https://hackinformer.com/2014/03/04/ps-vitas-mystery-port-explained/

https://gamefaqs.gamespot.com/boards/620272-playstation-vita/76035974

2
https://tcrf.net/Chameleon_Twist#Perfect_Code

https://www.youtube.com/watch?v=UFgI93Q_8Gc


1
https://marathon.bungie.org/story/

http://halostory.bungie.org/marathon.html

https://www.reddit.com/r/HaloStory/comments/dksgp6/was_halo_at_any_point_a_direct_sequel_to_marathon/



0:00 Intro 
0:34 Cyberpunk 2077
2:17 RDR 2
3:42 Super Mario Sunshine
5:02 Half-life
7:03 Atari Hardware
8:54 Megaman
10:51 PSVita
12:15 Chameleon Twist
13:31 Bungie


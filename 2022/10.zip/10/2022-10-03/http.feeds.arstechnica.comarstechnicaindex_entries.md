# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Walmart, CVS face trial for putting sham homeopathic products next to real meds
 - [https://arstechnica.com/?p=1886578](https://arstechnica.com/?p=1886578)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 22:28:57+00:00

A three-judge panel reversed lower courts' dismissal of the lawsuits.

## Still can’t buy a Raspberry Pi board? Things aren’t getting better anytime soon
 - [https://arstechnica.com/?p=1886515](https://arstechnica.com/?p=1886515)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 21:54:55+00:00

400,000 Pis are still being made every month, but most are going to businesses.

## Big data trove dumped after LA Unified School District says no to ransomware crooks
 - [https://arstechnica.com/?p=1886496](https://arstechnica.com/?p=1886496)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 20:25:55+00:00

Confidential incident reports, personnel records, and more are leaked online.

## SCOTUS weighs first case testing Big Tech liability for recommending content
 - [https://arstechnica.com/?p=1886430](https://arstechnica.com/?p=1886430)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 19:03:24+00:00

Section 230 to face its first Supreme Court challenge.

## Linux 6.0 arrives with support for newer chips, core fixes, and oddities
 - [https://arstechnica.com/?p=1886350](https://arstechnica.com/?p=1886350)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 17:41:06+00:00

Intel and AMD gear, yes, but support for RISC-V, LoongArch, and Gaudi2 show up.

## After an amazing run at Mars, India says its orbiter has no more fuel
 - [https://arstechnica.com/?p=1886275](https://arstechnica.com/?p=1886275)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 17:26:48+00:00

The orbiter most definitely exceeded expectations.

## Google prototypes, open sources an extra-long keyboard with one row of keys
 - [https://arstechnica.com/?p=1886356](https://arstechnica.com/?p=1886356)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 17:13:53+00:00

Open source files for Google Japan's latest joke concept are on GitHub.

## New PS5 exploit unlocks root privileges, read/write memory access
 - [https://arstechnica.com/?p=1886381](https://arstechnica.com/?p=1886381)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 16:49:07+00:00

Hack uses FreeBSD "race condition" exploit on older PS5 firmware.

## New trailer for Wakanda Forever gives us a peek at the new Black Panther
 - [https://arstechnica.com/?p=1886296](https://arstechnica.com/?p=1886296)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 16:20:57+00:00

"Only the most broken people can be great leaders."

## The Pixel 6a for $350 ($100 off) makes for an incredible deal
 - [https://arstechnica.com/?p=1886287](https://arstechnica.com/?p=1886287)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 16:08:41+00:00

The Pixel 6a was a bargain at the MSRP, and $100 off is even more tempting

## SEC fines Kim Kardashian, warns people about buying crypto touted by celebrities
 - [https://arstechnica.com/?p=1886347](https://arstechnica.com/?p=1886347)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 16:04:03+00:00

Kardashian touted EthereumMax on Instagram without revealing she was paid $250,000.

## Bruce Willis denies selling deepfake rights to Deepcake
 - [https://arstechnica.com/?p=1886277](https://arstechnica.com/?p=1886277)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 14:17:18+00:00

Willis' agent: "Bruce has no partnership or agreement with this Deepcake company."

## Nobel in Medicine goes to the man who brought us the Neanderthal genome
 - [https://arstechnica.com/?p=1886267](https://arstechnica.com/?p=1886267)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 14:00:53+00:00

Svante Pääbo played a central role in developing ways of looking into humanity's past.

## Black holes can’t trash info about what they swallow—and that’s a problem
 - [https://arstechnica.com/?p=1884061](https://arstechnica.com/?p=1884061)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 13:45:29+00:00

Solving the information paradox could unlock quantum gravity and unification of forces.

## With orbital launch, Firefly takes an early lead in the 1-ton rocket race
 - [https://arstechnica.com/?p=1886246](https://arstechnica.com/?p=1886246)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-03 13:09:22+00:00

"Firefly is at the point where the only thing holding them back is execution."


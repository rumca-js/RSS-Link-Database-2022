# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Vodafone and Three in merger talks
 - [https://www.bbc.co.uk/news/technology-63118990?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-63118990?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-10-03 13:45:07+00:00

The third and fourth largest mobile phone networks reportedly hope to strike a deal by the end of the year.

## BBC's technology evolution shown at National Museum of Computing
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-63092205?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-63092205?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-10-03 05:24:24+00:00

The National Museum of Computing at Bletchley Park is marking the corporation's 100th anniversary.


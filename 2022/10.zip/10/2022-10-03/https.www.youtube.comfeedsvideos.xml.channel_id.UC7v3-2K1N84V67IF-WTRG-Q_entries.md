# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## House of the Dragon: Episode 7 - Review
 - [https://www.youtube.com/watch?v=Ks38NFZri74](https://www.youtube.com/watch?v=Ks38NFZri74)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-10-03 00:00:00+00:00

House of the Dragon continues the show's twists, turns, and conflicts, and ends with a Bang. Here are my thoughts on HOUSE OF THE DRAGON: EPISODE 7!

#houseofthedragon


# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Whitney – three-song performance (live for The Current)
 - [https://www.youtube.com/watch?v=YMN28j0NGYw](https://www.youtube.com/watch?v=YMN28j0NGYw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-10-04 00:00:00+00:00

On the release of their new album, "Spark," Chicago band Whitney’s Julien Ehrlich and Max Kakacek visited The Current to play songs in studio. 

Watch and listen to the performances above.

Video segments:
00:00:00 Memory
00:02:36 Real Love
00:05:16 Valleys (My Love) – from the 2019 album, "Forever Turned Around"

Credits:
Guests - Whitney (Max Kakacek and Julien Ehrlich)
Host - Mac Wilson
Producer - Derrick Stevens
Camera Operators - Evan Clark, Peter Ecklund
Audio - Eric Xu Romani
Video - Evan Clark
Graphics - Natalia Toledo
Digital Producer - Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

#whitney #whitneytheband #whitneychicago

## Whitney discuss their new album, 'Spark' (interview at The Current)
 - [https://www.youtube.com/watch?v=zdfyEJgPd9E](https://www.youtube.com/watch?v=zdfyEJgPd9E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2022-10-03 00:00:00+00:00

On the release of their new album, "Spark," Chicago band Whitney’s Julien Ehrlich and Max Kakacek visited The Current to chat with host Mac Wilson.

Ehrlich and Kakacek not only discuss the writing of what became "Spark," they also share what’s important to them when searching for a place to call home, and what it’s like to be able to hold a physical copy of their records. And despite being based in Chicago, Ehrlich and Kakacek also share their special memories about Minneapolis record store Electric Fetus as well as our very on studio at The Current.

Watch and listen to the full performance here: https://www.youtube.com/watch?v=CAHNKeleNAY

Credits:
Guests - Whitney (Max Kakacek and Julien Ehrlich)
Host - Mac Wilson
Producer - Derrick Stevens
Camera Operators - Evan Clark, Peter Ecklund
Audio - Eric Xu Romani
Video - Evan Clark
Graphics - Natalia Toledo
Digital Producer - Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/

#whitney #whitneytheband #whitneychicago


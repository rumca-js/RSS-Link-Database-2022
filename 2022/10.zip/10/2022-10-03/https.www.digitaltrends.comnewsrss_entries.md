# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## Oops! Drone delivery crash knocks out power for thousands
 - [https://www.digitaltrends.com/news/drone-delivery-crash-knocks-out-power-for-thousands/](https://www.digitaltrends.com/news/drone-delivery-crash-knocks-out-power-for-thousands/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2022-10-03 04:04:30.581919+00:00

Wing has been making progress with tests involving its drone delivery service, but a recent accident highlights some of the challenges facing such projects.


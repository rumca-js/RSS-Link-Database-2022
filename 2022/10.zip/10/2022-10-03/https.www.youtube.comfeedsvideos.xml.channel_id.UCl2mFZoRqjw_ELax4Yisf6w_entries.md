# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Jabra voids headphone warranty if charge runs out for 6 months due to 💩 battery management
 - [https://www.youtube.com/watch?v=NBnqOpufuDU](https://www.youtube.com/watch?v=NBnqOpufuDU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-10-04 00:00:00+00:00

👉 Relevant links: 
🔴 Video 1: https://youtu.be/bRdL0StldJM
🔴 Video 2: https://www.youtube.com/watch?v=MjewR67uW1I

👉 Equipment used:
🔵 Chair: https://amzn.to/3MjLrnT
🔵 Microphone: https://amzn.to/3g1hsok
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av (YOU CAN FIND THIS FOR $250 ON EBAY WITH A BROKEN FLASH FROM TIME TO TIME, I HAVE NEVER SPENT MORE THAN $300 ON THIS CAMERA!)
🔵 Lighting: https://amzn.to/3RSriGC

👉 https://tinyurl.com/rossmatrix

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

## Destiny burns the last bridge
 - [https://www.youtube.com/watch?v=wgF92Wi8J7o](https://www.youtube.com/watch?v=wgF92Wi8J7o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-10-03 00:00:00+00:00

👉 Relevant links: 
🔴 https://www.youtube.com/user/destiny

👉 Equipment used:
🔵 Chair: https://amzn.to/3zOuSdf
🔵 Microphone: https://amzn.to/3g1hsok
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av (YOU CAN FIND THIS FOR $250 ON EBAY WITH A BROKEN FLASH FROM TIME TO TIME, I HAVE NEVER SPENT MORE THAN $300 ON THIS CAMERA!)
🔵 Lighting: https://amzn.to/3RSriGC

👉 https://tinyurl.com/rossmatrix

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ


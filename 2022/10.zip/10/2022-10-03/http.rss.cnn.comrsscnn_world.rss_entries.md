# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Brazil prepares for another month of political battle as run-off looms
 - [https://www.cnn.com/2022/10/03/americas/brazil-prepares-presidential-election-runoff-intl-latam/index.html](https://www.cnn.com/2022/10/03/americas/brazil-prepares-presidential-election-runoff-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-03 22:44:48+00:00

Brazilians woke up to four more weeks of campaigning after a presidential vote on Sunday destined frontrunners Luiz Inácio "Lula" da Silva and Jair Bolsonaro to a second round run-off later this month.

## 'There was blood everywhere': Witnesses describe crackdown on protesting students at Tehran university
 - [https://www.cnn.com/2022/10/03/middleeast/iran-protests-sharif-university-crackdown-intl/index.html](https://www.cnn.com/2022/10/03/middleeast/iran-protests-sharif-university-crackdown-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-03 17:37:54+00:00

When Farid's friend called crying for help on Sunday, he jumped on his bike and quickly rode to Tehran's Sharif University.

## US airstrike killed an al-Shabaab leader in Somalia on Saturday
 - [https://www.cnn.com/2022/10/03/politics/us-somalia-airstrike-al-shabaab/index.html](https://www.cnn.com/2022/10/03/politics/us-somalia-airstrike-al-shabaab/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-03 17:00:36+00:00

A US airstrike in Somalia killed an al-Shabaab militant leader on Saturday in coordination with the Somali government, US Africa Command said in a statement.

## OPEC+ to consider oil cut of over than 1 million barrels per day
 - [https://www.cnn.com/2022/10/02/energy/opec-considers-oil-cut/index.html](https://www.cnn.com/2022/10/02/energy/opec-considers-oil-cut/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-03 00:03:02+00:00

OPEC+ will consider an oil output cut of more than a million barrels per day (bpd) next week, OPEC sources said on Sunday, in what would be the biggest move yet since the COVID-19 pandemic to address oil market weakness.


# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## A New Ambient Album: The Making of On Lunar Fields
 - [https://www.youtube.com/watch?v=uv5fcpPfcy4](https://www.youtube.com/watch?v=uv5fcpPfcy4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-10-03 00:00:00+00:00

Get the album here: https://fanlink.to/h3nq
Watch the album performance here: https://youtu.be/L7GS0vwsCSo
Original art by Lou Hinks:
+ Etsy https://www.etsy.com/uk/shop/LouHinksArt
+ Instagram https://www.instagram.com/louhinksart/
+ Twitter https://twitter.com/LouHinks

00:00 intro
01:35 modular walkthrough
11:54 ableton walkthrough
26:52 the art
29:00 outro

Join me on Patreon and get access to music, presets, samples, and a great community: http://bit.ly/rmrpatreon

Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


# Source:Thoughty2, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA, language:en-US

## Why This Tiny Shrimp Is Louder Than a Jet Engine
 - [https://www.youtube.com/watch?v=iP_9eb4RY4I](https://www.youtube.com/watch?v=iP_9eb4RY4I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA
 - date published: 2022-10-03 14:59:15+00:00

Get my new book Bread and Circuses: https://bit.ly/breadandcircusesbook
Thoughty2 Audiobook: https://geni.us/t2audio
Thoughty2 Book: https://geni.us/t2book
Support Me & Get Early Access: http://bit.ly/t2club
Thoughty2 Merchandise: https://bit.ly/t2merch

Follow Thoughty2
Facebook: https://facebook.com/thoughty2
Instagram: https://instagram.com/thoughty2
Website: http://thoughty2.com

About Thoughty2
Thoughty2 (Arran) is a British YouTuber and gatekeeper of useless facts. Thoughty2 creates mind-blowing factual videos about science, tech, history, opinion and just about everything else.
#Thoughty2

Writing: Bevan Rees
Editing: Sandeep Rai


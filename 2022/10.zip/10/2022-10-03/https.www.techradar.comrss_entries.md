# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## These fake US government job ads are spreading more malware
 - [https://www.techradar.com/news/these-fake-us-government-job-ads-are-spreading-more-malware/](https://www.techradar.com/news/these-fake-us-government-job-ads-are-spreading-more-malware/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 20:14:07+00:00

Someone's using fake job ads to distribute Cobalt Strike beacons in the US and New Zealand.

## Linus Torvalds is hyped about Linux 6.0 - and the next version
 - [https://www.techradar.com/news/linus-torvalds-is-hyped-about-linux-60-and-the-next-version/](https://www.techradar.com/news/linus-torvalds-is-hyped-about-linux-60-and-the-next-version/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 19:45:01+00:00

Linux 6.0 set to bring benefits, but potentially not as many as the 6.1 update will bring.

## Amazon has a new plan for these tough economic times
 - [https://www.techradar.com/news/amazon-has-a-new-plan-for-these-tough-economic-times/](https://www.techradar.com/news/amazon-has-a-new-plan-for-these-tough-economic-times/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 19:20:49+00:00

Currently available to the US, customers will be able to pay with food stamps and put items on layaway.

## Black Friday monitor deals: our expert predictions
 - [https://www.techradar.com/news/the-best-black-friday-monitor-deals-for-every-budget/](https://www.techradar.com/news/the-best-black-friday-monitor-deals-for-every-budget/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 18:24:33+00:00

Where, when and how to get best Black Friday monitor deals in 2022 - plus the best early sales you can browse now.

## Cyberattacks are getting more costly for victims
 - [https://www.techradar.com/news/cyberattacks-are-getting-more-costly-for-victims/](https://www.techradar.com/news/cyberattacks-are-getting-more-costly-for-victims/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 18:24:21+00:00

More companies are losing over $1 million from cyberattacks.

## Samsung may snag a trick to beat the iPhone camera
 - [https://www.techradar.com/news/samsung-may-snag-a-trick-to-beat-the-iphone-camera/](https://www.techradar.com/news/samsung-may-snag-a-trick-to-beat-the-iphone-camera/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 17:01:06+00:00

A patent application shows Samsung is working on sensor stabilization, a method Apple uses on its iPhone 14 Pro

## The PS5 modding scene just had its gates thrown wide open
 - [https://www.techradar.com/news/the-ps5-modding-scene-just-had-its-gates-thrown-wide-open/](https://www.techradar.com/news/the-ps5-modding-scene-just-had-its-gates-thrown-wide-open/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 17:00:54+00:00

Someone's finally managed to jailbreak a PS5, making modding and homebrew content finally possible.

## Data leaked following LA schools ransomware attack
 - [https://www.techradar.com/news/data-leaked-following-la-schools-ransomware-attack/](https://www.techradar.com/news/data-leaked-following-la-schools-ransomware-attack/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 16:57:30+00:00

500GB data leak came after LAUSD did not cave in to ransom demands.

## Marvel's Avengers: Secret Wars has reportedly found its lead writer
 - [https://www.techradar.com/news/avengers-secret-wars-has-reportedly-found-its-lead-writer/](https://www.techradar.com/news/avengers-secret-wars-has-reportedly-found-its-lead-writer/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 16:39:54+00:00

The sixth Avengers movie has seemingly landed the writer behind the best Marvel Disney Plus show.

## There's finally a fix to this serious Microsoft Teams problem
 - [https://www.techradar.com/news/theres-finally-a-fix-to-this-serious-microsoft-teams-problem/](https://www.techradar.com/news/theres-finally-a-fix-to-this-serious-microsoft-teams-problem/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 16:03:29+00:00

Microsoft has come up with a solution to a growing problem with Teams.

## Diablo 4 leak shows you’ll be able to skip the whole campaign
 - [https://www.techradar.com/news/diablo-4-leak-shows-youll-be-able-to-skip-the-whole-campaign/](https://www.techradar.com/news/diablo-4-leak-shows-youll-be-able-to-skip-the-whole-campaign/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 16:00:00+00:00

Leaked screenshots suggest Diablo 4 is taking a leaf out of Diablo 3's campaign book.

## Destiny 2, Hitman, and Assassin’s Creed devs want to help Google Stadia players
 - [https://www.techradar.com/news/destiny-2-hitman-and-assassins-creed-devs-want-to-help-google-stadia-players/](https://www.techradar.com/news/destiny-2-hitman-and-assassins-creed-devs-want-to-help-google-stadia-players/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 15:37:10+00:00

Destiny 2, Hitman, and Assassin’s Creed developers are trying to find ways to let Google Stadia gamers keep playing their games.

## Demand for HDDs is on the slide, but SSDs are caught up too
 - [https://www.techradar.com/news/demand-for-hdds-is-on-the-slide-but-ssds-are-caught-up-too/](https://www.techradar.com/news/demand-for-hdds-is-on-the-slide-but-ssds-are-caught-up-too/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 15:08:27+00:00

A slowdown in the sale of SSDs has caused a leading memory manufacturer to cut volume.

## OnePlus Nord Watch: release date, price, specs and features
 - [https://www.techradar.com/news/oneplus-nord-watch/](https://www.techradar.com/news/oneplus-nord-watch/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 14:27:28+00:00

OnePlus has fully unveiled its affordable new Nord Watch: here's what you need to know.

## Google says Intel-powered VMs are the way forward, despite cost
 - [https://www.techradar.com/news/google-says-intel-powered-vms-are-the-way-forward-despite-cost/](https://www.techradar.com/news/google-says-intel-powered-vms-are-the-way-forward-despite-cost/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 14:15:43+00:00

New partnership sees Google try to drive “select high-growth enterprises” away from cheaper AMD and Ampere VMs in favor of Intel.

## More Microsoft Exchange zero-days exploited in the wild
 - [https://www.techradar.com/news/more-microsoft-exchange-zero-days-exploited-in-the-wild/](https://www.techradar.com/news/more-microsoft-exchange-zero-days-exploited-in-the-wild/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 13:38:19+00:00

Researchers believe Chinese hackers are using them, but mitigations are available.

## Black Panther: Wakanda Forever trailer confirms identity of new Black Panther
 - [https://www.techradar.com/news/black-panther-wakanda-forever-trailer-confirms-identity-of-new-black-panther/](https://www.techradar.com/news/black-panther-wakanda-forever-trailer-confirms-identity-of-new-black-panther/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 13:13:59+00:00

Black Panther: Wakanda Forever's official trailer seemingly reveals who takes over from T'Challa as the nation's protector.

## LG’s 27-inch OLED monitor could debut at CES 2023
 - [https://www.techradar.com/news/lgs-27-inch-oled-monitor-could-debut-at-ces-2023/](https://www.techradar.com/news/lgs-27-inch-oled-monitor-could-debut-at-ces-2023/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 12:50:20+00:00

LG Display is reportedly preparing to begin production of 27-inch and 32-inch OLED panels.

## The Rings of Power cast already know who Sauron and The Stranger are
 - [https://www.techradar.com/news/the-rings-of-power-cast-know-the-answers-to-two-of-the-shows-biggest-mysteries/](https://www.techradar.com/news/the-rings-of-power-cast-know-the-answers-to-two-of-the-shows-biggest-mysteries/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 12:48:01+00:00

Unsurprisingly, they aren't giving anything away about the series' two biggest mysteries.

## PC gamers are shunning high-end GPUs – spelling trouble for the Nvidia RTX 4090
 - [https://www.techradar.com/news/pc-gamers-are-shunning-high-end-gpus-spelling-trouble-for-the-nvidia-rtx-4090/](https://www.techradar.com/news/pc-gamers-are-shunning-high-end-gpus-spelling-trouble-for-the-nvidia-rtx-4090/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 12:20:28+00:00

Nvidia’s high-end focus with the RTX 4090 is a big gamble as new Steam hardware survey proves.

## IT pros suffer from serious misconceptions about Microsoft 365 security
 - [https://www.techradar.com/news/it-pros-suffer-from-serious-misconceptions-about-microsoft-365-security/](https://www.techradar.com/news/it-pros-suffer-from-serious-misconceptions-about-microsoft-365-security/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 12:11:42+00:00

A sizeable minority of IT professionals misunderstand the risks surounding Microsoft 365 data, new report claims.

## The next Xbox controller could ‘change color with light and motion’
 - [https://www.techradar.com/news/the-next-xbox-controller-could-change-color-with-light-and-motion/](https://www.techradar.com/news/the-next-xbox-controller-could-change-color-with-light-and-motion/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-03 08:27:54+00:00

The leaked Lunar Shift Xbox controller has a mother-of-pearl effect.


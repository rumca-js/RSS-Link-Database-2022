# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## How almost 800 burglaries go unsolved every day
 - [https://www.dailymail.co.uk/news/article-11276895/How-800-burglaries-unsolved-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276895/How-800-burglaries-unsolved-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 23:55:32+00:00

Forces logged 1.76million burglaries from 2017 to 2022 but only 5 per cent of those resulted in criminal charges or a court summons.

## Perspiration faster than Niagara Falls: HENRY DEEDES sees Kwasi Kwarteng at Tory party conference
 - [https://www.dailymail.co.uk/debate/article-11277145/Perspiration-faster-Niagara-Falls-HENRY-DEEDES-sees-Kwasi-Kwarteng-Tory-party-conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-11277145/Perspiration-faster-Niagara-Falls-HENRY-DEEDES-sees-Kwasi-Kwarteng-Tory-party-conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 23:53:47+00:00

HENRY DEEDES: This was to be his crowning moment, when he would be whooped and cheered, garlanded with flowers thrown by the adoring Tory faithful...

## Behind the scenes at Australia's 'anti woke' CPAC conference
 - [https://www.dailymail.co.uk/news/article-11273931/Behind-scenes-Australias-anti-woke-CPAC-conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273931/Behind-scenes-Australias-anti-woke-CPAC-conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 23:51:58+00:00

The CPAC event in Sydney was a chance to see Australia's right and left wing politically engaged in action, which meant there were chances to get a selfie with Donald Trump amid loud protests.

## Suitcases with children's remains moved at New Zealand storage unit
 - [https://www.dailymail.co.uk/news/article-11276951/Suitcases-childrens-remains-moved-New-Zealand-storage-unit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276951/Suitcases-childrens-remains-moved-New-Zealand-storage-unit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 23:48:25+00:00

More details are emerging about suitcases containing the remains of two children that were left in a New Zealand storage facility for four years.

## Boy, 12, dies after attending Wollongong home with horrific injuries as cops find smashed car empty
 - [https://www.dailymail.co.uk/news/article-11276853/Boy-12-dies-attending-Wollongong-home-horrific-injuries-cops-smashed-car-empty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276853/Boy-12-dies-attending-Wollongong-home-horrific-injuries-cops-smashed-car-empty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 23:38:59+00:00

Police are investigating the death of a 12-year-old boy after he attended a home with severe injuries following a mysterious car crash where officers found the vehicle destroyed and empty.

## Sue Neill-Fraser murder case: Killer released on parole 13 years after death of partner Bob Chappell
 - [https://www.dailymail.co.uk/news/article-11277069/Sue-Neill-Fraser-murder-case-Killer-released-parole-13-years-death-partner-Bob-Chappell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11277069/Sue-Neill-Fraser-murder-case-Killer-released-parole-13-years-death-partner-Bob-Chappell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 23:00:34+00:00

One of Australia's most infamous murder cases has taken its final turn as the convicted killer is released on parole after spending 13 years in prison for the mysterious death of her partner.

## Karl Stefanovic says ISIS brides and their children should not be allowed back into Australia
 - [https://www.dailymail.co.uk/news/article-11276685/Karl-Stefanovic-says-ISIS-brides-children-not-allowed-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276685/Karl-Stefanovic-says-ISIS-brides-children-not-allowed-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 22:52:26+00:00

Sixteen Australian women and 42 children have been held in al-Roj refugee camp in northeast Syria near the Iraqi border for three-and-a-half years following the fall of Islamic State in March 2019.

## Margot Robbie and Cara Delevingne's film-maker friends released from jail after attacking paparrazo
 - [https://www.dailymail.co.uk/news/article-11276255/Margot-Robbie-Cara-Delevingnes-film-maker-friends-released-jail-attacking-paparrazo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276255/Margot-Robbie-Cara-Delevingnes-film-maker-friends-released-jail-attacking-paparrazo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 22:45:38+00:00

Photos showed British film producer Josey MacNamara and key grip Jac Hopkins being led out of a Buenos Aires police station by a group of officers after spending the night in detention.

## Crypto trader who bought home with $10.4M wrongly put into account faces separate deception charge
 - [https://www.dailymail.co.uk/news/melbourne/article-11264747/Crypto-trader-bought-home-10-4M-wrongly-account-faces-separate-deception-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/melbourne/article-11264747/Crypto-trader-bought-home-10-4M-wrongly-account-faces-separate-deception-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 22:36:15+00:00

A woman who had $10.4million mistakenly transferred into her account in a Crypto.com bungle and kept it has been charged with similar offending.

## Supreme Court REJECTS challenge to the Biden administration's vaccine mandate for healthcare workers
 - [https://www.dailymail.co.uk/news/article-11276691/Supreme-Court-REJECTS-challenge-Biden-administrations-vaccine-mandate-healthcare-workers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276691/Supreme-Court-REJECTS-challenge-Biden-administrations-vaccine-mandate-healthcare-workers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 22:29:27+00:00

The high court let the vaccine mandate for health workers stand when it declined to take up appeal of a January ruling by Missouri and nine other GOP-leaning states.

## Closing statements in Kristin Smart murder trial begin today
 - [https://www.dailymail.co.uk/news/article-11272891/Closing-statements-Kristin-Smart-murder-trial-begin-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11272891/Closing-statements-Kristin-Smart-murder-trial-begin-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 22:11:17+00:00

Jurors are hearing closing statements in the Kristin Smart murder trial case against Paul Flores, while a separate jury will hear closing arguments in the case of Ruben Flores on Tuesday.

## Meghan Markle hires fact-checker for her Spotify podcast series Archetypes
 - [https://www.dailymail.co.uk/news/article-11276889/Meghan-Markle-hires-woke-fact-checker-Spotify-podcast-series-Archetypes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276889/Meghan-Markle-hires-woke-fact-checker-Spotify-podcast-series-Archetypes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:53:48+00:00

The Daily Mail's Richard Eden can reveal that Meghan has been employing a 'fact-checker' for  Archetypes, which resumes today, having been suspended after the Queen's death.

## Pub landlady knifed teen waitress in rage at imagined affair with her partner, court hears
 - [https://www.dailymail.co.uk/news/article-11276787/Pub-landlady-knifed-teen-waitress-rage-imagined-affair-partner-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276787/Pub-landlady-knifed-teen-waitress-rage-imagined-affair-partner-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:49:28+00:00

Luisa Santos, 47, told her husband Pedro that Hannah Pritchett was 'laughing' at her and ordered him to choose between the 18-year-old and his family.

## Pictured: Belfast man, 49, shot dead by two masked gunmen while watching football at social club
 - [https://www.dailymail.co.uk/news/article-11276491/Pictured-Belfast-man-49-shot-dead-two-masked-gunmen-watching-football-social-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276491/Pictured-Belfast-man-49-shot-dead-two-masked-gunmen-watching-football-social-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:45:19+00:00

Sean Fox, 49, was shot 'a number of times' by two men who reportedly walked into Donegal Celtic Social club before escaping on foot yesterday.

## Girl is denied arthritis medication in Arizona by Walgreens pharmacy because it can cause abortion
 - [https://www.dailymail.co.uk/news/article-11276449/Girl-denied-arthritis-medication-Arizona-Walgreens-pharmacy-cause-abortion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276449/Girl-denied-arthritis-medication-Arizona-Walgreens-pharmacy-cause-abortion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:41:11+00:00

An Arizona pharmacy delayed 14-year-old Emma Thompson's life-saving medication that can terminate a pregnancy following the state ban on abortions on September 24.

## NYU professor fired after students sign petition to get rid of him for making the subject 'too hard'
 - [https://www.dailymail.co.uk/news/article-11276533/NYU-professor-fired-students-sign-petition-rid-making-subject-hard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276533/NYU-professor-fired-students-sign-petition-rid-making-subject-hard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:09:13+00:00

A New York University professor has been fired after a group of students signed a petition against him suggesting his course was too difficult.

## Girlfriend of suspected killer who 'stuffed ex in suitcases used the victim's benefits card'
 - [https://www.dailymail.co.uk/news/article-11276457/Girlfriend-suspected-killer-stuffed-ex-suitcases-used-victims-benefits-card.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276457/Girlfriend-suspected-killer-stuffed-ex-suitcases-used-victims-benefits-card.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:09:04+00:00

D'Asia Johnson, 22, was found dead on September 21 - and her Electronic Benefits Transfer card was being used by her estranged boyfriend's new partner after her grim death.

## Donald Trump accuses CNN of defamation with a lawsuit seeking $475 million in punitive damages
 - [https://www.dailymail.co.uk/news/article-11276721/Donald-Trump-accuses-CNN-defamation-lawsuit-seeking-475-million-punitive-damages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276721/Donald-Trump-accuses-CNN-defamation-lawsuit-seeking-475-million-punitive-damages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:07:54+00:00

Former President Donald Trump on Monday accused CNN in federal court of defamation, launching legal proceedings seeking $475 million in punitive damages.

## Stunning drone footage shows Fall colors breaking out across the US
 - [https://www.dailymail.co.uk/news/article-11276313/Stunning-drone-footage-shows-Fall-colors-breaking-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276313/Stunning-drone-footage-shows-Fall-colors-breaking-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:07:12+00:00

Less than two weeks into fall, nature is already revealing incredible colors and foliage linked to the season! Drone footage from New Hampshire and Utah shows breathtaking views as fall moves in.

## Cost of home loans nears 6% in fallout from mini-Budget after mortgage rates rise
 - [https://www.dailymail.co.uk/news/article-11276737/Cost-home-loans-nears-6-fallout-mini-Budget-mortgage-rates-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276737/Cost-home-loans-nears-6-fallout-mini-Budget-mortgage-rates-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:03:37+00:00

Mortgage rates have risen by nearly a whole percentage point in the ten days since the mini-Budget, figures showed today.

## Leaked audio of NY1 weatherman Erick Adame performing on sex website
 - [https://www.dailymail.co.uk/news/article-11276275/Leaked-audio-NY1-weatherman-Erick-Adame-performing-sex-website.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276275/Leaked-audio-NY1-weatherman-Erick-Adame-performing-sex-website.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:03:11+00:00

Erick Adame was fired from his meteorologist job at Spectrum NY1  last week after his employers were notified of his performances on Chaturbate, an explicit site.

## Princess Diana's brother Earl Spencer says children 'miss out on so much' in history lessons
 - [https://www.dailymail.co.uk/news/article-11276735/Princess-Dianas-brother-Earl-Spencer-says-children-miss-history-lessons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276735/Princess-Dianas-brother-Earl-Spencer-says-children-miss-history-lessons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:02:54+00:00

The historian and younger brother of Princess Diana said he would like to broaden the way the subject was taught because pupils learn only about 'Hitler and Henry VIII'.

## Biden tells Puerto Rico 'all of America is with you' after Hurricane Fiona=
 - [https://www.dailymail.co.uk/news/article-11276553/Biden-tells-Puerto-Rico-America-Hurricane-Fiona.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276553/Biden-tells-Puerto-Rico-America-Hurricane-Fiona.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 21:00:53+00:00

President Joe Biden assured the people of Puerto Rico on Monday that 'all of America is with you' as the island struggles to cope with the damage from Hurricane Fiona.

## Scientologist Danny Masterson asks to postpone rape trial until after mayoral election
 - [https://www.dailymail.co.uk/news/article-11276223/Scientologist-Danny-Masterson-asks-postpone-rape-trial-mayoral-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276223/Scientologist-Danny-Masterson-asks-postpone-rape-trial-mayoral-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:52:29+00:00

That '70s Show actor Danny Masterson appeared in court today ahead of his rape trial in Los Angeles.

## Uncle fined $1,900 for placing dye in Brazilian waterfall for his pregnant niece's gender reveal
 - [https://www.dailymail.co.uk/news/article-11276145/Uncle-fined-1-900-placing-dye-Brazilian-waterfall-pregnant-nieces-gender-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276145/Uncle-fined-1-900-placing-dye-Brazilian-waterfall-pregnant-nieces-gender-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:44:37+00:00

Brazilian authorities have fined Raijan Mascarello, the uncle of a pregnant woman for pouring a dye on a waterfall to reveal the gender of her baby.

## Marjorie Taylor Greene asks Kamala Harris if she thinks her husband is 'worth less bc he's white'
 - [https://www.dailymail.co.uk/news/article-11276361/Marjorie-Taylor-Greene-asks-Kamala-Harris-thinks-husband-worth-bc-hes-white.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276361/Marjorie-Taylor-Greene-asks-Kamala-Harris-thinks-husband-worth-bc-hes-white.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:38:33+00:00

'@KamalaHarris hurricanes do not target people based on the color of their skin. Hurricanes do not discriminate,'  outspoken Congresswoman Greene wrote on Twitter.

## Premier League footballer under investigation for 'raping two women' has his bail extended
 - [https://www.dailymail.co.uk/news/article-11276591/Premier-League-footballer-29-investigation-raping-two-women-bail-extended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276591/Premier-League-footballer-29-investigation-raping-two-women-bail-extended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:38:01+00:00

The star, in his 20s, was arrested in north London on suspicion of rape in a dramatic 3am swoop by Metropolitan Police officers in July after an alleged victim came forward.

## Norwich council sparks furious backlash from women's rights group over 'trans inclusion' vote
 - [https://www.dailymail.co.uk/news/article-11275877/Norwich-council-sparks-furious-backlash-womens-rights-group-trans-inclusion-vote.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275877/Norwich-council-sparks-furious-backlash-womens-rights-group-trans-inclusion-vote.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:34:04+00:00

Norwich City Council was met with furious backlash from women's rights activists after declaring 'transphobic extremists' are 'not welcome' in the city.

## Marjorie Taylor Greene's former tantric sex guru lover offers sex retreats amid her divorce
 - [https://www.dailymail.co.uk/news/article-11275921/Marjorie-Taylor-Greenes-former-tantric-sex-guru-lover-offers-sex-retreats-amid-divorce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275921/Marjorie-Taylor-Greenes-former-tantric-sex-guru-lover-offers-sex-retreats-amid-divorce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:31:53+00:00

Craig Ivey, 44, was dubbed the 'polyamorous tantric sex guru' when DailyMail.com exclusively exposed his affair with the QAnon-supporting congresswoman last year.

## Man, 35, is charged with murder of 39-year-old found dead in Ross-on-Wye
 - [https://www.dailymail.co.uk/news/article-11276451/Man-35-charged-murder-39-year-old-dead-Ross-Wye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276451/Man-35-charged-murder-39-year-old-dead-Ross-Wye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:31:29+00:00

Kestutis Lekunas, 35, has been charged with the murder of a 39-year-old who was found dead on a quiet Ross-on-Wye street following an 'altercation' on Sunday morning.

## Sophie Wessex sports a red gown with stars and moons on it on Democratic Republic of the Congo trip
 - [https://www.dailymail.co.uk/femail/article-11276501/Sophie-Wessex-sports-red-gown-stars-moons-Democratic-Republic-Congo-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11276501/Sophie-Wessex-sports-red-gown-stars-moons-Democratic-Republic-Congo-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:28:42+00:00

The Countess of Wessex looked elegant in a red gown with stars and moons on it as she travelled in the Democratic Republic of the Congo today.

## Man, 28, charged with manslaughter for 'killing salsa dancer and friend of Cardi B' in speeding car
 - [https://www.dailymail.co.uk/news/article-11276273/Man-28-charged-manslaughter-killing-salsa-dancer-friend-Cardi-B-speeding-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276273/Man-28-charged-manslaughter-killing-salsa-dancer-friend-Cardi-B-speeding-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:10:33+00:00

Leandro Diaz Ramirez, 28, was behind the wheel of the speeding BMW when he crashed into a Subaru - which then crushed the two pedestrians in Inwood, New York.

## Jacob Rees-Mogg shrugs off protesters who heckled him at Conservative Party Conference
 - [https://www.dailymail.co.uk/news/article-11276261/Jacob-Rees-Mogg-shrugs-protesters-heckled-Conservative-Party-Conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276261/Jacob-Rees-Mogg-shrugs-protesters-heckled-Conservative-Party-Conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:09:29+00:00

Jacob Rees-Mogg has shrugged off the protesters who called him 'Tory scum' and instead applauded how having the freedom to peacefully protest is 'marvellous.'

## Shocking moment thieves steal an entire 500lb SAFE after ransacking luxury home in Los Angeles
 - [https://www.dailymail.co.uk/news/article-11276271/Shocking-moment-thieves-steal-entire-500lb-SAFE-ransacking-luxury-home-Los-Angeles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276271/Shocking-moment-thieves-steal-entire-500lb-SAFE-ransacking-luxury-home-Los-Angeles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:03:01+00:00

Surveillance footage showed the criminals using the sliding door to gain entrance to the $4million property in Rolling Hills Estates, California, while the homeowner was away.

## Thai man had metal ring stuck on his penis for FOUR MONTHS in failed bid to make it bigger
 - [https://www.dailymail.co.uk/news/article-11276139/Thai-man-metal-ring-stuck-penis-FOUR-MONTHS-failed-bid-make-bigger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276139/Thai-man-metal-ring-stuck-penis-FOUR-MONTHS-failed-bid-make-bigger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:00:59+00:00

The man was rushed to the emergency room of the Krungthai General Hospital in Nonthaburi province in Thailand on October 1 after he complained of the pain in his penis.

## Pictured: College student who was killed in Nebraska horror crash along with five others
 - [https://www.dailymail.co.uk/news/article-11276301/Pictured-College-student-killed-Nebraska-horror-crash-five-others.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276301/Pictured-College-student-killed-Nebraska-horror-crash-five-others.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:00:53+00:00

Nick Bisesi, 22, and Jonathan Koch, 22, both died in the early hours of Sunday morning when the Honda Accord they were traveling in smashed into a tree at 2.15am.

## Democrats also bus thousands of migrants to northern cities - but quietly
 - [https://www.dailymail.co.uk/news/article-11266801/Democrats-bus-thousands-migrants-northern-cities-quietly.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11266801/Democrats-bus-thousands-migrants-northern-cities-quietly.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 20:00:45+00:00

El Paso Democrats have bused more than 5,000 migrants to New York and Chicago and helped many others travel across the U.S. But unlike GOP Gov Abbott, they don't brag

## Man is shot dead in the front yard of a home in Oxley, Brisbane
 - [https://www.dailymail.co.uk/news/article-11276577/Man-shot-dead-yard-home-Oxley-Brisbane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276577/Man-shot-dead-yard-home-Oxley-Brisbane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:58:34+00:00

Police have opened a murder investigation after a man was shot dead in the front yard of a home in Brisbane in the early hours of the morning, with a gunman on the run.

## Antonio Brown posts old photo of Tom Brady's wife Gisele Bündchen hugging him amid divorce rumors
 - [https://www.dailymail.co.uk/news/article-11276085/Antonio-Brown-posts-old-photo-Tom-Bradys-wife-Gisele-B-ndchen-hugging-amid-divorce-rumors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276085/Antonio-Brown-posts-old-photo-Tom-Bradys-wife-Gisele-B-ndchen-hugging-amid-divorce-rumors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:56:38+00:00

Former NFL Tampa Bay Buccaneers wide receiver Antonio Brown posted an old photo hugging Tom Brady's wife  Gisele Bündchen amid divorce rumors.

## Is Kwasi Kwarteng about to perform his second U-turn in 24 hours?
 - [https://www.dailymail.co.uk/news/article-11276561/Is-Kwasi-Kwarteng-perform-second-U-turn-24-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276561/Is-Kwasi-Kwarteng-perform-second-U-turn-24-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:53:43+00:00

Kwasi Kwarteng is expected about to bring forward his fiscal plan to tackle Britain's enormous £2.4trillion debt mountain this month from November 23.

## Twin sisters, 21, who 'pummelled' a girl in horrific attack on night out AVOID jail
 - [https://www.dailymail.co.uk/news/article-11276427/Twin-sisters-21-pummelled-girl-horrific-attack-night-AVOID-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276427/Twin-sisters-21-pummelled-girl-horrific-attack-night-AVOID-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:53:06+00:00

Sophie Wood and Katie Wood, then both 21, had been out in Manchester city centre when Sophie barged into a group of girls. They were handed a suspended jail sentence at Manchester Crown Court.

## Just TWO customers turn up to order food at Deliveroo's new Oxford Street supermarket on opening day
 - [https://www.dailymail.co.uk/news/article-11274887/Now-Deliveroo-opens-SHOP-Delivery-giant-joins-forces-Morrisons-open-Oxford-Street-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274887/Now-Deliveroo-opens-SHOP-Delivery-giant-joins-forces-Morrisons-open-Oxford-Street-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:52:29+00:00

A new supermarket run by takeaway giant Deliveroo flopped on its first day of trading today - with just TWO customers turning up to order food in the 90 minutes of the store's doors opening.

## Margot Robbie and Cara Delvingne's film-maker friends released from jail after attacking paparrazo
 - [https://www.dailymail.co.uk/news/article-11276255/Margot-Robbie-Cara-Delvingnes-film-maker-friends-released-jail-attacking-paparrazo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276255/Margot-Robbie-Cara-Delvingnes-film-maker-friends-released-jail-attacking-paparrazo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:52:24+00:00

Photos showed British film producer Josey MacNamara and key grip Jac Hopkins being led out of a Buenos Aires police station by a group of officers after spending the night in detention.

## Democrat leads COLLAPSE in Wisconsin and Pennsylvania Senate races
 - [https://www.dailymail.co.uk/news/article-11276089/Democrat-leads-COLLAPSE-Wisconsin-Pennsylvania-Senate-races.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276089/Democrat-leads-COLLAPSE-Wisconsin-Pennsylvania-Senate-races.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:51:05+00:00

Democratic leads in two battleground states are slipping away ahead of next month's midterm Senate elections where progressive candidates are accused of being too progressive.

## 6ft 6in monster, 34, who raped a woman just months after his release from prison is jailed for life
 - [https://www.dailymail.co.uk/news/article-11276283/6ft-6in-monster-34-raped-woman-just-months-release-prison-jailed-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276283/6ft-6in-monster-34-raped-woman-just-months-release-prison-jailed-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:48:34+00:00

Andrew Cooke-Edwards, 34, lay in wait by the River Wye in Hereford for two hours before brutally raping his victim on November 19, 2020, just months after he was freed from prison.

## Barbie creator's daughter fights for her dad's legacy after toy giant Mattel cuts him out
 - [https://www.dailymail.co.uk/news/article-11259419/Barbie-creators-daughter-fights-dads-legacy-toy-giant-Mattel-cuts-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11259419/Barbie-creators-daughter-fights-dads-legacy-toy-giant-Mattel-cuts-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:47:55+00:00

Ann Ryan, 67, claims her late father Jack Ryan is the true creator of the famed doll Barbie and bashes toy company Mattel for erasing his legacy.

## Maloney used campaign and taxpayer funds to pay husband's trainer to work as a part-time driver
 - [https://www.dailymail.co.uk/news/article-11259615/Maloney-used-campaign-taxpayer-funds-pay-husbands-trainer-work-time-driver.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11259615/Maloney-used-campaign-taxpayer-funds-pay-husbands-trainer-work-time-driver.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:46:34+00:00

Rep. Sean Patrick Maloney curiously paid his husband's personal trainer as a 'part time employee' through both taxpayer funds and campaign funds.

## Recession in Australia: How could you be affected?
 - [https://www.dailymail.co.uk/news/article-11261431/Recession-Australia-affected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11261431/Recession-Australia-affected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:42:25+00:00

Last week, one of Australia's 'Big Four' banks said that continued aggressive interest rate hikes could tip Australia into a recession and economists say it would cause chaos.

## Woman in her 60s is mauled to death by 'at least two dogs inside home'
 - [https://www.dailymail.co.uk/news/article-11276143/Woman-60s-mauled-death-two-dogs-inside-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276143/Woman-60s-mauled-death-two-dogs-inside-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:40:06+00:00

At around 4.25pm today, police were called to a property on St Brigids Crescent in Vauxhall, Liverpool, where a woman in her 60s had been attacked by dogs.

## 'Where was your industry stationed when the storm hit?' DeSantis defends late Lee County evacuation
 - [https://www.dailymail.co.uk/news/article-11272435/Ron-DeSantis-lee-county-evacuation-hurricane-ian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11272435/Ron-DeSantis-lee-county-evacuation-hurricane-ian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:39:10+00:00

In a CNN clip shared by his 2022 campaign, a journalist asks the governor: 'Why do you stand behind Lee County's decision to not have that mandatory evacuation until the day before the storm?'

## Five murders have been connected by new evidence sparking concerns of a serial killer in  California
 - [https://www.dailymail.co.uk/news/article-11275715/Five-murders-connected-new-evidence-sparking-concerns-serial-killer-California.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275715/Five-murders-connected-new-evidence-sparking-concerns-serial-killer-California.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:37:49+00:00

Police in California have connected five unsolved murders of mostly Hispanic men sparking concerns of a potential serial killer.

## Shoppers cut spending on toiletries by £240million in a year by switching to cheaper own-brands
 - [https://www.dailymail.co.uk/news/article-11275983/Shoppers-cut-spending-toiletries-240million-year-switching-cheaper-brands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275983/Shoppers-cut-spending-toiletries-240million-year-switching-cheaper-brands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:37:30+00:00

Trade magazine The Grocer reported said sales of famous name products are falling in the face of rising inflation. Data suggests fewer personal care packs have been scanned through the tills.

## The best curry houses in the UK revealed
 - [https://www.dailymail.co.uk/news/article-11274915/Winners-announced-curry-industry-Oscars-did-local-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274915/Winners-announced-curry-industry-Oscars-did-local-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:20:59+00:00

Britain's best curry houses have been crowned in a national awards ceremony celebrating South Asian cuisine, with national  winners in Hertfordshire, Newcastle upon Tyne and Manchester.

## Credit Suisse crash to a record low amid market turmoil
 - [https://www.dailymail.co.uk/news/article-11276103/Credit-Suisse-share-price-slides-amid-market-turmoil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276103/Credit-Suisse-share-price-slides-amid-market-turmoil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:17:54+00:00

Traders and bankers rushed to buy Credit Default Swaps (CDS) - an insurance tool if the company goes bust - after its share price dropped by 10 per cent.

## Emma Thompson condemns plans to build car park on fields that inspired E.M Forster's Howards End
 - [https://www.dailymail.co.uk/news/article-11276311/Emma-Thompson-condemns-plans-build-car-park-fields-inspired-E-M-Forsters-Howards-End.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276311/Emma-Thompson-condemns-plans-build-car-park-fields-inspired-E-M-Forsters-Howards-End.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:17:26+00:00

Campaigners, including Extinction Rebellion activists, are battling 'baffling' plans to build on the Forster Country fields in Stevenage, Hertfordshire.

## BBC Three star who appeared in dwarfism reality show died after overdosing on antipsychotic drug
 - [https://www.dailymail.co.uk/news/article-11275779/BBC-Three-star-appeared-dwarfism-reality-died-overdosing-antipsychotic-drug.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275779/BBC-Three-star-appeared-dwarfism-reality-died-overdosing-antipsychotic-drug.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:15:35+00:00

Jasmine Burkitt, 28, died at her home at Bodelwyddan, North Wales, in June earlier this year - 12 years after she shot to fame in the four-part documentary.

## Search for Moors murder victim Keith Bennett continues for fourth day
 - [https://www.dailymail.co.uk/news/article-11275565/Search-Moors-murder-victim-Keith-Bennett-continues-fourth-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275565/Search-Moors-murder-victim-Keith-Bennett-continues-fourth-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:14:13+00:00

The search for Moors murder victim Keith Bennett is continuing into its fourth day, with forensic teams sifting through earth in Saddleworth Moor. He was one of Ian Brady and Myra Hindley's victims.

## Coolio steered clear of drugs and alcohol
 - [https://www.dailymail.co.uk/news/article-11268347/Close-friend-Coolio-says-rapper-steered-clear-drugs-did-not-overdose.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11268347/Close-friend-Coolio-says-rapper-steered-clear-drugs-did-not-overdose.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:10:32+00:00

Coolio's friend and manager, Eric Yano told DailyMail.com the rapper's cause of death appeared to be a heart attack, and  testified to his sobriety in recent years.

## Coolio's partner was aware he was seeing other women
 - [https://www.dailymail.co.uk/news/article-11266887/Coolios-long-term-girlfriend-reveals-cremated-private-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11266887/Coolios-long-term-girlfriend-reveals-cremated-private-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:08:59+00:00

Mimi Ivey, Coolio's long-term partner since 2012, told DailyMail.com the late rapper, 59, will be cremated and will not be having a funeral - per his own instructions to his family.

## Moment two humpback whales brawl with a huge pod of killer whales off the coast of Seattle
 - [https://www.dailymail.co.uk/news/article-11276193/Moment-two-humpback-whales-brawl-huge-pod-killer-whales-coast-Seattle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276193/Moment-two-humpback-whales-brawl-huge-pod-killer-whales-coast-Seattle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 19:01:02+00:00

A rare moment was captured off the coast of Seattle as two humpback whales were spotted in conflict with a pod of orcas.

## Three people are killed after small plane smashed through the roof of Minnesota home
 - [https://www.dailymail.co.uk/news/article-11275443/Three-people-killed-small-plane-smashed-roof-Minnesota-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275443/Three-people-killed-small-plane-smashed-roof-Minnesota-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:58:10+00:00

Matthew Schmidt, 31, his sister, Alyssa Schmidt, 32 and pilot Tyler Fretland, 32, died in a Minnesota plane crash late Saturday night. Fretland was a pilot with Delta Airlines but the crash is unrelated.

## Son, 49, swam half a mile through flooded streets to save his wheelchair-bound mom, 84 in Florida
 - [https://www.dailymail.co.uk/news/article-11274551/Son-49-swam-half-mile-flooded-streets-save-wheelchair-bound-mom-84-Florida.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274551/Son-49-swam-half-mile-flooded-streets-save-wheelchair-bound-mom-84-Florida.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:56:44+00:00

Johnny Lauder's mother Karen refused to evacuate as Hurricane Ian rolled in last week, so the 49-year-old father set off from his home to save her from her Naples, Florida home as it filled with water.

## Three men and and woman who traveled up to 50 MILES to loot Fort Myers Beach after Hurricane Ian
 - [https://www.dailymail.co.uk/news/article-11275337/Three-men-woman-traveled-50-MILES-loot-Fort-Myers-Beach-Hurricane-Ian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275337/Three-men-woman-traveled-50-MILES-loot-Fort-Myers-Beach-Hurricane-Ian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:54:35+00:00

The shameless individuals, aged between 33 and 20, were booked for ransacking devastated homes and businesses on Fort Myers Beach while they suffered in the wake of  the raging torrent.

## More than 33,000 migrants have crossed English Channel in small boats this year, MoD figures say
 - [https://www.dailymail.co.uk/news/article-11275445/More-33-000-migrants-crossed-English-Channel-small-boats-year-MoD-figures-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275445/More-33-000-migrants-crossed-English-Channel-small-boats-year-MoD-figures-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:47:46+00:00

Data released by the Ministry of Defence (MoD) has revealed that 33,001 people have been intercepted making the dangerous journey across the 21-mile Dover Straits in 2022.

## Biden heads to Puerto Rico to look at the carnage left by Hurricane Fiona
 - [https://www.dailymail.co.uk/news/article-11275173/Biden-heads-Puerto-Rico-look-carnage-left-Hurricane-Ian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275173/Biden-heads-Puerto-Rico-look-carnage-left-Hurricane-Ian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:47:26+00:00

Biden's trip to the island is the first of a pair of trips to view disaster damage this week. On Wednesday he flies to Florida to see damage following the devastating hit by Hurricane Ian.

## Husband, 45, is jailed for LIFE for kidnapping, raping and trying to murder his ex-wife
 - [https://www.dailymail.co.uk/news/article-11275857/Husband-45-jailed-LIFE-kidnapping-raping-trying-murder-ex-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275857/Husband-45-jailed-LIFE-kidnapping-raping-trying-murder-ex-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:45:54+00:00

Trevor Steven Summers, 45, was handed the life sentence after being found guilty of all 11 counts against him in Hillsborough County, Florida .

## Biden's dire approval on issues that matter most to Americans
 - [https://www.dailymail.co.uk/news/article-11275979/Bidens-dire-approval-issues-matter-Americans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275979/Bidens-dire-approval-issues-matter-Americans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:42:51+00:00

President Joe Biden is seeing dire approval ratings on the issues voters rank the most important to them six weeks out from the November election.

## Ukrainian refugee who was dumped by her British lover flies BACK to war-torn country
 - [https://www.dailymail.co.uk/news/article-11276065/Ukrainian-refugee-dumped-British-lover-flies-war-torn-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276065/Ukrainian-refugee-dumped-British-lover-flies-war-torn-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:40:20+00:00

Sofiia Karkadym, 22, still tearful after her break-up with security guard Tony Garnett, boarded a plane home from Manchester Airport. She is travelling to Ukraine via Poland.

## One third of inflation-ravaged U.S. households are skipping meals or cutting portion sizes
 - [https://www.dailymail.co.uk/news/article-11275561/One-inflation-ravaged-U-S-households-skipping-meals-cutting-portion-sizes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275561/One-inflation-ravaged-U-S-households-skipping-meals-cutting-portion-sizes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:38:04+00:00

Americans faced another month of economic hardship, and while average gas prices have dipped to $3.79 per gallon, the pain is being increasingly felt at grocery store checkouts.

## Mila Kunis describes how a homeless woman OVERDOSED on drugs while sitting next to her children
 - [https://www.dailymail.co.uk/news/article-11276069/Mila-Kunis-describes-homeless-woman-OVERDOSED-drugs-sitting-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276069/Mila-Kunis-describes-homeless-woman-OVERDOSED-drugs-sitting-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:34:49+00:00

The Ukrainian-born actress, who is married to Ashton Kutcher, described the ordeal her family faced a day out to an ice cream parlor during the coronavirus pandemic.

## Alex Scott's father Tony hits back at claims he 'abused' her
 - [https://www.dailymail.co.uk/news/article-11275509/Alex-Scotts-father-hits-claims-bullied-abused-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275509/Alex-Scotts-father-hits-claims-bullied-abused-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:21:34+00:00

The BBC football pundit describes her father Tony Scott as a 'controlling violent drunk' who was 'stupidly cruel'.

## Arizona man turns up for Tinder date only to be robbed at gunpoint by couple, 32 and 33
 - [https://www.dailymail.co.uk/news/article-11275013/Arizona-man-turns-Tinder-date-robbed-gunpoint-couple-32-33.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275013/Arizona-man-turns-Tinder-date-robbed-gunpoint-couple-32-33.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:13:32+00:00

A couple that used a fake Tinder account to lure a man into a hotel room in Phoenix and rob him at gunpoint were arrested after a police chase through multiple cities ended in a crash.

## Home Secretary eyes crackdown after 'massive increase' in number of student visas being issued in UK
 - [https://www.dailymail.co.uk/news/article-11276167/Home-Secretary-eyes-crackdown-massive-increase-number-student-visas-issued-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11276167/Home-Secretary-eyes-crackdown-massive-increase-number-student-visas-issued-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 18:06:44+00:00

Speaking at a fringe event at the Tory conference, the Home Secretary pledged to take a 'more discerning' approach to the number of student visas being issued.

## Conservative Party conference locked down over 'potential security alert'
 - [https://www.dailymail.co.uk/news/article-11275739/Tory-conference-locked-potential-security-alert-Kwasi-Kwartengs-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275739/Tory-conference-locked-potential-security-alert-Kwasi-Kwartengs-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:59:49+00:00

BREAKING: The Tory Party Conference, being held in Birmingham, has been put on lockdown due to an unknown security risk.

## 45p tax rate: Kwasi Kwarteng tries to laugh off bombshell U-turn
 - [https://www.dailymail.co.uk/news/article-11275667/Kwasi-Kwarteng-tries-laugh-bombshell-U-turn-abolishing-rate-tax.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275667/Kwasi-Kwarteng-tries-laugh-bombshell-U-turn-abolishing-rate-tax.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:59:08+00:00

Chancellor Kwasi Kwarteng quipped 'what a day' as he started his address to the party faithful in Birmingham - before appealing for them to 'move on' with 'no more distractions'.

## Ukrainian troops 'break through Russian lines' near Kherson
 - [https://www.dailymail.co.uk/news/article-11274353/Ukrainian-troops-break-Russian-lines-near-Kherson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274353/Ukrainian-troops-break-Russian-lines-near-Kherson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:56:11+00:00

Ukrainian forces are advancing along the Dnipro River in the southern Kherson region, have captured more territory in Donetsk, and are now attacking into Luhansk, Kyiv has said.

## Barrister leading investigation into Tim Westwood's time at BBC calls for people to come forward
 - [https://www.dailymail.co.uk/news/article-11275929/Barrister-leading-investigation-Tim-Westwoods-time-BBC-calls-people-come-forward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275929/Barrister-leading-investigation-Tim-Westwoods-time-BBC-calls-people-come-forward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:46:50+00:00

Barrister Gemma White - who is leading the investigation into former hip hop DJ Tim Westwood - is urging people with information about his time at the BBC to come forward.

## Cyclist, 21, who was 'murdered' after being chased by four men in car named locally as Kyron Lesner
 - [https://www.dailymail.co.uk/news/article-11275581/Cyclist-21-murdered-chased-four-men-car-named-locally-Kyron-Lesner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275581/Cyclist-21-murdered-chased-four-men-car-named-locally-Kyron-Lesner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:40:06+00:00

The 21-year-old victim of Sunday's 'shocking' attack in Slough, Berkshire, has today been named locally as Kyron Lesner. He died after being attacked by four men who chased him.

## Man uses his baby as a HUMAN SHIELD after abducting the child
 - [https://www.dailymail.co.uk/news/article-11275277/Man-uses-baby-HUMAN-SHIELD-abducting-child.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275277/Man-uses-baby-HUMAN-SHIELD-abducting-child.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:37:18+00:00

A man is in police custody after video shows him using his one-year-old child as a shield while deputies attempt to arrest him for kidnapping the child from his girlfriend's Florida home.

## London Marathon death: Man, aged 36, collapsed just two miles from finishing line
 - [https://www.dailymail.co.uk/news/article-11275671/Man-36-died-London-Marathon-collapsing-mile-23-24.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275671/Man-36-died-London-Marathon-collapsing-mile-23-24.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:26:02+00:00

A 36-year-old man has died after collapsing between mile 23 and 24 of the London Marathon yesterday, event organisers have confirmed

## Inspector 'throttled' boy, 16, filming police station before arresting him as suspected terrorist
 - [https://www.dailymail.co.uk/news/article-11275943/Inspector-throttled-boy-16-filming-police-station-arresting-suspected-terrorist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275943/Inspector-throttled-boy-16-filming-police-station-arresting-suspected-terrorist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:25:29+00:00

Dean Gittoes, 49, is accused of assault by beating  the teenage boy who was standing outside  to film the police station and put it online.

## Home prices across the US are posting biggest monthly declines since 2009
 - [https://www.dailymail.co.uk/news/article-11275699/Home-prices-posting-biggest-monthly-declines-2009.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275699/Home-prices-posting-biggest-monthly-declines-2009.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:11:55+00:00

Home prices continue to drop throughout the US as median home prices continued its two-month decline, reaching numbers not seen since 2009.

## Chris Cuomo is back on air as his first NewsNation show is set to debut
 - [https://www.dailymail.co.uk/news/article-11275731/Chris-Cuomo-air-NewsNation-set-debut.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275731/Chris-Cuomo-air-NewsNation-set-debut.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:10:42+00:00

Chris Cuomo, 52, is is returning to the airwaves tonight for the first time since he was ousted from CNN for journalistic breaches of ethics.

## MCCAIN: Eichner blamed 'homophobic weirdos' after his film bombed - he's the one who seems to hate
 - [https://www.dailymail.co.uk/news/article-11275359/MCCAIN-Eichner-blamed-homophobic-weirdos-film-bombed-hes-one-hate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275359/MCCAIN-Eichner-blamed-homophobic-weirdos-film-bombed-hes-one-hate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:09:41+00:00

MCCAIN: You may be surprised to learn that if you chose to go to the movies this weekend and saw the horror film 'Smile' instead of the romantic comedy 'Bros,' you're a very bad person.

## Dog owner whose five Rough Collies mauled her neighbour is fined more than £1,000
 - [https://www.dailymail.co.uk/news/article-11275851/Dog-owner-five-Rough-Collies-mauled-neighbour-fined-1-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275851/Dog-owner-five-Rough-Collies-mauled-neighbour-fined-1-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:07:47+00:00

Former Crufts winner Daphne Iley (pictured) has been fined more than £1,000 after her dogs mauled her neighbour during a walk, leaving him injured and fearing for his life.

## Water firms blasted for missing targets and polluting rivers with £150m to be returned to customers
 - [https://www.dailymail.co.uk/news/article-11274975/Water-firms-blasted-missing-targets-polluting-rivers-150m-returned-customers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274975/Water-firms-blasted-missing-targets-polluting-rivers-150m-returned-customers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:04:11+00:00

The action was taken after suppliers failed to meet target areas such as water supply interruptions, pollution incidents and internal sewer flooding.

## Artist spends two years covering every square inch of his £1.35m house in DOODLES
 - [https://www.dailymail.co.uk/news/article-11274783/Artist-spends-two-years-covering-square-inch-1-35m-house-DOODLES.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274783/Artist-spends-two-years-covering-square-inch-1-35m-house-DOODLES.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 17:04:05+00:00

Sam Cox, also known as Mr Doodle, has spent the last two years plastering the walls of his six-bedroom, neo-Georgian mansion with the signature black-and-white drawings that earned him his name.

## Caitlyn Jenner blasts radical left for 'hijacking trans issue'
 - [https://www.dailymail.co.uk/news/article-11275629/Theyre-driving-country-apart-Caitlyn-Jenner-blasts-radical-left-hijacking-trans-issue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275629/Theyre-driving-country-apart-Caitlyn-Jenner-blasts-radical-left-hijacking-trans-issue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:59:16+00:00

Members of a Vermont girls high school volleyball team were banned from using their locker room and have to change in a single bathroom stall after they complained about a transgender teammate.

## More polls show massive lead of up to 28-POINTS for Labour
 - [https://www.dailymail.co.uk/news/article-11275883/More-polls-massive-lead-28-POINTS-Labour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275883/More-polls-massive-lead-28-POINTS-Labour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:43:48+00:00

Research by Redfield & Wilton Strategies found a staggering 28-point advantage, with Keir Starmer's party backed by 52 per cent of the public.

## Anthony Bourdain 'never stopped drinking' and 'hated who he'd become', author of biography claims
 - [https://www.dailymail.co.uk/news/article-11275417/Anthony-Bourdain-never-stopped-drinking-hated-hed-author-biography-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275417/Anthony-Bourdain-never-stopped-drinking-hated-hed-author-biography-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:43:38+00:00

Bourdain killed himself in France in June 2018. His final days are revisited Down And Out In Paradise: The Life of Anthony Bourdain, a new biography by journalist Charles Leerhsen.

## Author Beezy Marsh investigates matriarchs of the criminal underworld in 1950s London
 - [https://www.dailymail.co.uk/news/article-11274601/Author-Beezy-Marsh-investigates-matriarchs-criminal-underworld-1950s-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274601/Author-Beezy-Marsh-investigates-matriarchs-criminal-underworld-1950s-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:41:08+00:00

Notorious burglar Zoe Progl (pictured) broke into her first house at the age of 13 and went on to become the first ever prisoner to escape over the wall from Holloway Prison in north London.

## Supreme Court rules Mike Lindell must face $1.3B Dominion defamation suit as it kicks off new term
 - [https://www.dailymail.co.uk/news/article-11275559/Supreme-Court-Mike-Lindell-new-term.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275559/Supreme-Court-Mike-Lindell-new-term.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:39:06+00:00

It's among several high-profile updates to kick off the high court's new term - the first for newly-minted Justice Ketanji Brown Jackson, the first black female jurist on the bench.

## Former glamour model and ex-lover of Joe Calzaghe is charged in Dubai money smuggling operation
 - [https://www.dailymail.co.uk/news/article-11275701/Former-glamour-model-ex-lover-Joe-Calzaghe-charged-Dubai-money-smuggling-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275701/Former-glamour-model-ex-lover-Joe-Calzaghe-charged-Dubai-money-smuggling-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:32:09+00:00

EXCLUSIVE: Former glamour model Jo Emma Larvin, 43, was among a dozen people charged in connection with a multi-million pound smuggling operation.

## Australia's cost of living crisis: Double Bay shoppers tell how inflation is sparing NO-ONE
 - [https://www.dailymail.co.uk/news/article-11265437/Australias-cost-living-crisis-Double-Bay-shoppers-tell-inflation-sparing-NO-ONE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11265437/Australias-cost-living-crisis-Double-Bay-shoppers-tell-inflation-sparing-NO-ONE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:30:59+00:00

Residents in the Sydney eastern suburb of Double Bay - sometimes known as 'Double Pay' because of its wealthy demographic and high prices - have shared how they are grappling with inflation.

## What is the 45p tax rate? Why has Kwasi Kwarteng scrapped it?
 - [https://www.dailymail.co.uk/news/article-11274465/45p-tax-rate-explained-Q-Kwasi-Kwarteng-scraps-plan-remove-45-rate-income-tax.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274465/45p-tax-rate-explained-Q-Kwasi-Kwarteng-scraps-plan-remove-45-rate-income-tax.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:24:15+00:00

The controversial plans, which had been revealed as part of his 'mini-budget' last week, had sparked outrage among opposition parties and even some Conservative MPs and spooked the markets.

## Gerry 'The Monk' Hutch goes on trial for murder: Security operation underway in Dublin
 - [https://www.dailymail.co.uk/news/article-11274853/Gerry-Monk-Hutch-goes-trial-murder-Security-operation-underway-Dublin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274853/Gerry-Monk-Hutch-goes-trial-murder-Security-operation-underway-Dublin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:21:32+00:00

Hutch, 59, appeared at Dublin's Special Criminal Court today accused of murder over the 2016 Regency Hotel shooting which left David Byrne, an associate of the Kinahan gang, dead.

## The mega sniper rifle Ukrainian forces are using against Putin's soldiers
 - [https://www.dailymail.co.uk/news/article-11275423/The-mega-sniper-rifle-Ukrainian-forces-using-against-Putins-soldiers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275423/The-mega-sniper-rifle-Ukrainian-forces-using-against-Putins-soldiers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:19:04+00:00

The huge weapon fires rounds that can penetrate armour that is up to one centimetre thick from a distance of around a mile away, making it a highly effective weapon against Russian armour.

## Saudi Arabia and Russia drive OPEC alliance plans to cut oil production - propping up prices
 - [https://www.dailymail.co.uk/news/article-11275669/Saudi-Arabia-Russia-drive-OPEC-alliance-plans-cut-oil-production-propping-prices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275669/Saudi-Arabia-Russia-drive-OPEC-alliance-plans-cut-oil-production-propping-prices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:04:27+00:00

The 13 members of the Organization of the Petroleum Exporting Countries (OPEC), led by Riyadh, and their 11 allies headed by Moscow will hold a meeting on Wednesday.

## Murderer still on the run six days after absconding from open prison 16 years into his life sentence
 - [https://www.dailymail.co.uk/news/article-11275287/Murderer-run-six-days-absconding-open-prison-16-years-life-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275287/Murderer-run-six-days-absconding-open-prison-16-years-life-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:03:51+00:00

Police are still searching for convicted killer Lee Nevins, 39, who escaped from HMP Sudbury an open prison in Derbyshire last Tuesday, September 29.

## Russia's military veterans condemn Ukraine war... and say Vladimir has doomed his army to defeat
 - [https://www.dailymail.co.uk/news/article-11275487/Russias-military-veterans-condemn-Ukraine-war-say-Vladimir-doomed-army-defeat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275487/Russias-military-veterans-condemn-Ukraine-war-say-Vladimir-doomed-army-defeat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 16:03:08+00:00

Vitaly Votanovsky, who rose to the rank of lieutenant-colonel in the Russian Air Force, is now a vociferous political activist who has been detained multiple times.

## Illegal adverts for cannabis 'dispensary' are fly-posted on Tube and appear on BILLBOARD in London
 - [https://www.dailymail.co.uk/news/article-11191487/Illegal-adverts-cannabis-flyposted-Tube-Dealer-claims-selling-50-000-worth-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11191487/Illegal-adverts-cannabis-flyposted-Tube-Dealer-claims-selling-50-000-worth-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:53:50+00:00

Thousands of cannabis adverts with a discount code have been 'flyposted' on London's underground, creating '£50,000 worth of cannabis sales a week', dealer behind campaign claimed.

## Child protection deaths: 100 Victorian kids and teens in child protection died in past two years
 - [https://www.dailymail.co.uk/news/article-11274941/Child-protection-deaths-100-Victorian-kids-teens-child-protection-died-past-two-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274941/Child-protection-deaths-100-Victorian-kids-teens-child-protection-died-past-two-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:48:05+00:00

Among the most common causes of death were 'SIDS, suicide, car crashes, strangulation, drowning and assault'.

## Postcode lottery for 20mph zones: Most fines in Bristol, Bath and Somerset
 - [https://www.dailymail.co.uk/news/article-11274721/Postcode-lottery-20mph-zones-fines-Bristol-Bath-Somerset.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274721/Postcode-lottery-20mph-zones-fines-Bristol-Bath-Somerset.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:47:27+00:00

Avon and Somerset Police sent out 23,338 Notice of Intended Prosecution (NIP) letters to people accused of breaking a 20mph speed limit.

## ISIS brides and children in Syria to be deradicalised before returning home to Australia
 - [https://www.dailymail.co.uk/news/article-11274733/ISIS-brides-children-Syria-deradicalised-returning-home-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274733/ISIS-brides-children-Syria-deradicalised-returning-home-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:47:21+00:00

The former ADF intelligence analyst gave an adamant answer when asked on The Project if ISIS brides and children in Syrian detention camps should return to Australia.

## Transport chiefs miss key target to cut down deaths of UK's controversial network of smart motorways
 - [https://www.dailymail.co.uk/news/article-11275633/Transport-chiefs-miss-key-target-cut-deaths-UKs-controversial-network-smart-motorways.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275633/Transport-chiefs-miss-key-target-cut-deaths-UKs-controversial-network-smart-motorways.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:47:00+00:00

National Highways had given itself until the end of September to achieve four key targets designed to cut down deaths - but it failed to meet the deadline for one of them.

## Boy, 3, is shot dead in the back seat of his mom's SUV in horrifying road rage incident in Chicago
 - [https://www.dailymail.co.uk/news/article-11274339/Boy-3-shot-dead-seat-moms-SUV-horrifying-road-rage-incident-Chicago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274339/Boy-3-shot-dead-seat-moms-SUV-horrifying-road-rage-incident-Chicago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:42:26+00:00

Mateo Zastro is the second child to be shot in the head in a car in Chicago in less than a month, prompting a community advocate to say 'We have baby killers out here on the street.'

## Smart Meter malfunction sends customers into a panic by showing prices up to £42,000
 - [https://www.dailymail.co.uk/news/article-11275015/Smart-Meter-malfunction-sends-customers-panic-showing-prices-42-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275015/Smart-Meter-malfunction-sends-customers-panic-showing-prices-42-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:39:01+00:00

A smart meter In Home Display malfunction sent customers into panic by showing hugely expensive readings, including Emily Brown, from Nottingham, whose meter said £42,670 had been spent.

## Iran blames AMERICA and Israel for riots started by death of a woman in police custody
 - [https://www.dailymail.co.uk/news/article-11275033/Iran-blames-AMERICA-Israel-riots-started-death-woman-police-custody.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275033/Iran-blames-AMERICA-Israel-riots-started-death-woman-police-custody.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:38:36+00:00

The unrest is flaring up across the country for a third week despite government efforts to crack down on the riots.

## Tory peer Lord Heseltine warns Liz Truss 'things are looking pretty bleak' ahead of next election
 - [https://www.dailymail.co.uk/news/article-11275597/Tory-peer-Lord-Heseltine-warns-Liz-Truss-things-looking-pretty-bleak-ahead-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275597/Tory-peer-Lord-Heseltine-warns-Liz-Truss-things-looking-pretty-bleak-ahead-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:37:22+00:00

The former Cabinet minister told the Prime Minister that 'a very impressive feat of political leadership' would now be needed to keep the Conservatives in power.

## Army Corporal who was accused of groping two female colleagues is cleared of sexual assault
 - [https://www.dailymail.co.uk/news/article-11275319/Army-Corporal-accused-groping-two-female-colleagues-cleared-sexual-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275319/Army-Corporal-accused-groping-two-female-colleagues-cleared-sexual-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:35:45+00:00

Corporal Andrew Cline, 34, was accused of squeezing the bottom of one female soldier and groping another's breast - but he denied both charges and has been found not guilty.

## King Charles makes joke about his string of pen mishaps
 - [https://www.dailymail.co.uk/news/article-11275425/King-Charles-makes-joke-string-pen-mishaps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275425/King-Charles-makes-joke-string-pen-mishaps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:34:53+00:00

The monarch and the Queen Consort Camilla are in Scotland where they declared Dunfermline a new city before heading to Edinburgh for more events.

## Russian official who tried to overthrow Putin is summonsed for war despite no military experience
 - [https://www.dailymail.co.uk/news/article-11275215/Russian-official-tried-overthrow-Putin-summonsed-war-despite-no-military-experience.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275215/Russian-official-tried-overthrow-Putin-summonsed-war-despite-no-military-experience.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:34:46+00:00

Dmitry Baltrukov, 43, is a municipal deputy for Putin's birthplace of Smolninskoye, and last month he and his fellow councillors tried to force the tyrant out of office.

## Eco-activist charged with criminal damage after Captain Sir Tom Moore memorial allegedly defaced
 - [https://www.dailymail.co.uk/news/article-11275441/Eco-activist-charged-criminal-damage-Captain-Sir-Tom-Moore-memorial-allegedly-defaced.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275441/Eco-activist-charged-criminal-damage-Captain-Sir-Tom-Moore-memorial-allegedly-defaced.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:34:43+00:00

Eco-zealot Madeleine Budd, 21, who allegedly poured human excrement over a memorial dedicated to Captain Sir Tom Moore has been charged with criminal damage

## Dating app users in Australia report sexual harassment, abuse in report: Hinge, Tinder, Bumble
 - [https://www.dailymail.co.uk/news/article-11275017/Dating-app-users-Australia-report-sexual-harassment-abuse-report-Hinge-Tinder-Bumble.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275017/Dating-app-users-Australia-report-sexual-harassment-abuse-report-Hinge-Tinder-Bumble.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:27:53+00:00

The report explored technology-facilitated violence with some respondents revealing they had been sent unsolicited graphic pictures or been secretly filmed while having sex.

## Man, 18, is arrested for 'arson' following blaze at historic building in Belfast's Cathedral Quarter
 - [https://www.dailymail.co.uk/news/article-11275513/Man-18-arrested-arson-following-blaze-historic-building-Belfasts-Cathedral-Quarter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275513/Man-18-arrested-arson-following-blaze-historic-building-Belfasts-Cathedral-Quarter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:23:37+00:00

A man, 18, has been arrested on suspicion of arson endangering life with intent after a fire broke out at the Old Cathedral Building (pictured) on Donegall Street, Belfast early this morning.

## Peloton will put its bikes in 5,400 Hilton-owned hotel in the US
 - [https://www.dailymail.co.uk/news/article-11275001/Peloton-bikes-5-400-Hilton-owned-hotel-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275001/Peloton-bikes-5-400-Hilton-owned-hotel-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:20:34+00:00

Peloton will now feature bikes in Hilton hotels, as the exercise equipment brand continues to expand its accessibility. Since December 2020, shares have fallen 95 percent.

## Kim Kardashian to pay $1.26m to settle with SEC over failing to disclose crypto $250k on Insta
 - [https://www.dailymail.co.uk/news/article-11274961/Kim-Kardashian-pay-1-26m-settle-SEC-failing-disclose-crypto-250k-Insta.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274961/Kim-Kardashian-pay-1-26m-settle-SEC-failing-disclose-crypto-250k-Insta.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:20:06+00:00

She has also agreed not to tout any more crypto assets for three years and to fully cooperate with ongoing investigations after accepting cash from EthereumMax to promote their EMAX tokens.

## Former ESPN sportscaster Rachel Nichols claims she was SPIED on in hotel room
 - [https://www.dailymail.co.uk/news/article-11275251/Former-ESPN-sportscaster-Rachel-Nichols-claims-SPIED-hotel-room.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275251/Former-ESPN-sportscaster-Rachel-Nichols-claims-SPIED-hotel-room.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:16:38+00:00

Rachel Nichols made her first public appearance since her departure from ESPN and said someone decided to spy on her after she left new recording equipment on.

## Stark naked man goes nuts at Union Square subway station in NYC
 - [https://www.dailymail.co.uk/news/article-11275043/Put-sub-away-Stark-naked-man-goes-nuts-Union-Square-subway-station-NYC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275043/Put-sub-away-Stark-naked-man-goes-nuts-Union-Square-subway-station-NYC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:13:23+00:00

Footage from the Union Square station in downtown Manhattan showed an unidentified man wearing nothing and sprawled on his back on the platform.

## Murder probe launched in Slough after cyclist, 21, is chased down and killed following crash
 - [https://www.dailymail.co.uk/news/article-11275063/Murder-probe-launched-Slough-cyclist-21-chased-killed-following-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275063/Murder-probe-launched-Slough-cyclist-21-chased-killed-following-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:11:02+00:00

Detectives say four males got out of the car and launched a fatal attack on the 21-year-old cyclist following the crash in Cippenham, in Slough.

## Casting agent advertises for actor to play Prince Harry in next Netflix series of The Crown
 - [https://www.dailymail.co.uk/news/article-11274741/Casting-agent-advertises-actor-play-Prince-Harry-Netflix-series-Crown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274741/Casting-agent-advertises-actor-play-Prince-Harry-Netflix-series-Crown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:04:09+00:00

A casting agent is looking for an actor to play Prince Harry for the next Netflix series of The Crown. Filming is set to start next month and the job ad closes on October 14.

## Football season cancelled after video of team acting out a 'slave auction' of their black players
 - [https://www.dailymail.co.uk/news/article-11275257/Football-season-cancelled-video-team-acting-slave-auction-black-players.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275257/Football-season-cancelled-video-team-acting-slave-auction-black-players.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 15:02:39+00:00

The shocking video purportedly shows members of River Valley High School's football team in Yuba City carrying out the 'reprehensible' act as a form of frat boy-style prank.

## Maggie Haberman says Trump WILL run for president again but suggests his heart 'may not be in it'
 - [https://www.dailymail.co.uk/news/article-11275211/Maggie-Haberman-says-Trump-run-president-suggests-heart-not-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275211/Maggie-Haberman-says-Trump-run-president-suggests-heart-not-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 14:57:53+00:00

New York Times reporter Maggie Haberman said that those close to Donald Trump predict he will run again in 2024 but many say his 'heart's not in it.'

## Deadly cobra lunges at Indian snake-catcher's face and bites him after he tried to KISS it
 - [https://www.dailymail.co.uk/news/article-11275137/Deadly-cobra-lunges-Indian-snake-catchers-face-bites-tried-KISS-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275137/Deadly-cobra-lunges-Indian-snake-catchers-face-bites-tried-KISS-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 14:53:40+00:00

Footage of the incident in India shows the man appeared to be trying to pose for a photograph when the venomous snake lashed out at him and bit him on the lips.

## Harley Street doctor, 77, appears in court accused of sexually assaulting a woman at his surgery
 - [https://www.dailymail.co.uk/news/article-11275035/Harley-Street-doctor-77-appears-court-accused-sexually-assaulting-woman-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275035/Harley-Street-doctor-77-appears-court-accused-sexually-assaulting-woman-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 14:49:38+00:00

Harley Street consultant physician Dr John Keet, 77, appeared in court today charged with sexually assaulting a woman at his surgery last year - which he denies

## Spacious 12-bedroom Grade I Listed country manor goes on the market for £1.5million
 - [https://www.dailymail.co.uk/news/article-11274927/Spacious-12-bedroom-Grade-Listed-country-manor-goes-market-1-5million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274927/Spacious-12-bedroom-Grade-Listed-country-manor-goes-market-1-5million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 14:28:55+00:00

The Grade I Listed Nunnykirk Hall in Northumberland (pictured), built in 1825 for the wealthy Orde family, has gone on the market for the first time in 200 years.

## Nicola Sturgeon is booed and cheered by crowd as she arrives in Dunfermline for city-making event
 - [https://www.dailymail.co.uk/news/article-11274619/Nicola-Sturgeon-booed-cheered-crowd-arrives-Dunfermline-city-making-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274619/Nicola-Sturgeon-booed-cheered-crowd-arrives-Dunfermline-city-making-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 14:24:50+00:00

The Scottish First Minister was loudly booed by parts of the crowd - and cheered by others - as she smiled and waved to fellow Scots outside Dunfermline City Chambers this morning.

## Surging cost of carbon dioxide could add £1.7BILLION to the price of groceries
 - [https://www.dailymail.co.uk/news/article-11274307/Surging-cost-carbon-dioxide-add-1-7BILLION-price-groceries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274307/Surging-cost-carbon-dioxide-add-1-7BILLION-price-groceries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 14:24:06+00:00

Research by the Energy and Climate Intelligence Unit (ECIU) suggests that the UK's food and drink sector could end up footing the mammoth extra bill for liquid CO2.

## Legendary Ukrainian Top Gun who led infamous 'Ghosts of Kyiv' pilot division dies in Black Sea
 - [https://www.dailymail.co.uk/news/article-11274587/Legendary-Ukrainian-Gun-led-infamous-Ghost-Kyiv-pilot-division-dies-Black-Sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274587/Legendary-Ukrainian-Gun-led-infamous-Ghost-Kyiv-pilot-division-dies-Black-Sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 14:24:05+00:00

Colonel Mykhailo Matyushenko was head of the Air Force's 40th Tactical Aviation Brigade, which guarded the skies over the Ukrainian capital.

## King Charles and Queen Consort Camilla in Dunfermline
 - [https://www.dailymail.co.uk/news/article-11274447/King-Charles-Queen-Consort-Camilla-Dunfermline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274447/King-Charles-Queen-Consort-Camilla-Dunfermline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 14:16:45+00:00

Charles and Camilla have been welcomed to  Fife by community groups including a local pipe band and schoolchildren - with the UK's new monarch stopping to speak to crowds.

## Ferrari driver is filmed speeding down dual carriageway at nearly 200mph in disturbing footage
 - [https://www.dailymail.co.uk/news/article-11274923/Ferrari-driver-filmed-speeding-dual-carriageway-nearly-200mph-disturbing-footage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274923/Ferrari-driver-filmed-speeding-dual-carriageway-nearly-200mph-disturbing-footage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 14:06:38+00:00

A reckless driver floored his Ferrari down a public dual carriageway, believed to be Derbyshire, reaching speeds close to 200mph while overtaking other cars.

## Russian nuclear military train is seen on the move in 'possible warning to the West'
 - [https://www.dailymail.co.uk/news/article-11274515/Russian-nuclear-military-train-seen-possible-warning-West.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274515/Russian-nuclear-military-train-seen-possible-warning-West.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 14:02:52+00:00

The hardware belongs to a division of Russia's Defence Ministry which is dedicated to the storage, maintenance and provision of nuclear weapons to specialist branches of the armed forces

## Pictured beside e-cigarettes and spirits: Baby formula is hidden behind the counter in Sainsbury's
 - [https://www.dailymail.co.uk/news/article-11274429/Pictured-e-cigarettes-spirits-Baby-formula-hidden-counter-Sainsburys.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274429/Pictured-e-cigarettes-spirits-Baby-formula-hidden-counter-Sainsburys.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 13:59:47+00:00

Aptamil baby formula has been pictured behind the counter in a Sainsbury's in Acton, west London. The picture comes after reports of security tags being wrapped around baby milk in Tesco and other shops.

## Number of troops referred to counter-terrorism programme DOUBLES in a year
 - [https://www.dailymail.co.uk/news/article-11274165/Number-troops-referred-counter-terrorism-programme-DOUBLES-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274165/Number-troops-referred-counter-terrorism-programme-DOUBLES-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 13:55:37+00:00

Top brass in the military are referring more troops than ever before to a terrorism prevention programme over fears they could be recruited by the far right.

## Martin Lewis demands Government DELETES tweet claiming London first-time buyers can buy a £500k home
 - [https://www.dailymail.co.uk/news/article-11274343/Martin-Lewis-demands-Government-DELETES-tweet-claiming-London-time-buyers-buy-500k-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274343/Martin-Lewis-demands-Government-DELETES-tweet-claiming-London-time-buyers-buy-500k-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 13:44:08+00:00

Consumer champion Martin Lewis today described the Government's claims that first-time buyers on £30k-a-year could buy property in London thanks to their tax cuts as 'nonsense'.

## Melbourne neo-Nazi group at Youth Fest Moonee Ponds Queen's Park: Dominic Perrottet wants ban
 - [https://www.dailymail.co.uk/news/article-11274189/Melbourne-neo-Nazi-group-Youth-Fest-Moonee-Ponds-Queens-Park-Dominic-Perrottet-wants-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274189/Melbourne-neo-Nazi-group-Youth-Fest-Moonee-Ponds-Queens-Park-Dominic-Perrottet-wants-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 13:29:06+00:00

About a dozen men attended Youth Fest in Moonee Ponds in the city's northwest holding anti-Semitic signs reading 'Demon Flesh' and 'Drag Pedos Groom Kids'.

## Coventry mosque attack: Two arrested after man was viciously stabbed in 'family feud murder'
 - [https://www.dailymail.co.uk/news/article-11274895/Coventry-mosque-attack-Two-arrested-man-viciously-stabbed-family-feud-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274895/Coventry-mosque-attack-Two-arrested-man-viciously-stabbed-family-feud-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 13:26:14+00:00

Police discovered a man, 52, named locally as Rab Nawaz, had been stabbed during a fight in the Jamiah Masjid and Institute, Coventry, that is said to have stemmed from a family feud.

## GOP Sen. Susan Collins says she wouldn't be surprised if Congress member is KILLED as threats rise
 - [https://www.dailymail.co.uk/news/article-11274957/GOP-Sen-Susan-Collins-says-wouldnt-surprised-Congress-member-KILLED-threats-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274957/GOP-Sen-Susan-Collins-says-wouldnt-surprised-Congress-member-KILLED-threats-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 13:17:08+00:00

Between 2016 and 2021, the number of threats recorded against members of Congress had increased tenfold, according to the Times. Some lawmakers are also reportedly shelling out thousands on security.

## Biggest EVER bird flu outbreak means 48MILLION chickens have now been culled across UK and Europe
 - [https://www.dailymail.co.uk/health/article-11274835/Biggest-bird-flu-outbreak-means-48MILLION-chickens-culled-UK-Europe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11274835/Biggest-bird-flu-outbreak-means-48MILLION-chickens-culled-UK-Europe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 13:14:24+00:00

The highly contagious virus - which experts fear could jump to humans and trigger another pandemic - usually dies out in the summer. Yet this year, avian influenza has persisted all-year round

## Nadine Dorries tells Liz Truss to call an ELECTION accusing her of destroying Boris Johnson's legacy
 - [https://www.dailymail.co.uk/news/article-11275165/Nadine-Dorries-tells-Liz-Truss-call-ELECTION-accusing-destroying-Boris-Johnsons-legacy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11275165/Nadine-Dorries-tells-Liz-Truss-call-ELECTION-accusing-destroying-Boris-Johnsons-legacy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 13:07:58+00:00

In the latest round of Tory infighting the ultra Boris Johnson loyalist accused the new Prime Minister of scrapping key elements of his time in power, including the licence fee review and selling off Channel 4.

## Daughter of Captain Sir Tom Moore saddened as eco-activist, 21, poured human waste on his memorial
 - [https://www.dailymail.co.uk/news/article-11274665/Daughter-Captain-Sir-Tom-Moore-saddened-eco-activist-21-poured-human-waste-memorial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274665/Daughter-Captain-Sir-Tom-Moore-saddened-eco-activist-21-poured-human-waste-memorial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 13:07:20+00:00

Captain Sir Tom Moore's daughter said his family are 'deeply saddened' after an eco-zealot was seen in a video pouring human excrement over a memorial to him.

## Countdown of chaos that pushed Liz Truss to drop tax cut for top earners
 - [https://www.dailymail.co.uk/news/article-11274441/Countdown-chaos-pushed-Liz-Truss-drop-tax-cut-earners.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274441/Countdown-chaos-pushed-Liz-Truss-drop-tax-cut-earners.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 13:02:25+00:00

Asked directly yesterday whether she would go ahead with abolishing the 45p top tax rate, Liz Truss said: 'Yes... it is part of an overall package of making our tax system simpler and lower.'

## Police in Rikki Neave murder probe 'IGNORED scientific evidence to pursue case against his mother'
 - [https://www.dailymail.co.uk/news/article-11274257/Police-Rikki-Neave-murder-probe-IGNORED-scientific-evidence-pursue-case-against-mother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274257/Police-Rikki-Neave-murder-probe-IGNORED-scientific-evidence-pursue-case-against-mother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 13:00:28+00:00

The six-year-old was found strangled, naked and arranged in a 'star pose' in woods near his home in Peterborough, the day after he was reported missing by his mother on November 28, 1994.

## Millions of Britons wrongly believe a Union flag on food means it is made with 100% UK ingredients
 - [https://www.dailymail.co.uk/news/article-11274407/Millions-Britons-wrongly-believe-Union-flag-food-means-100-UK-ingredients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274407/Millions-Britons-wrongly-believe-Union-flag-food-means-100-UK-ingredients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 12:51:39+00:00

Millions don't realise that manufacturers are allowed to display the flag on packaging provided the product is made in the UK, even if the ingredients come from overseas.

## Pilot who spent 16 years building an exact replica of the Spitfire is ready for his first flight
 - [https://www.dailymail.co.uk/news/article-11274395/Pilot-spent-16-years-building-exact-replica-Spitfire-ready-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274395/Pilot-spent-16-years-building-exact-replica-Spitfire-ready-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 12:47:50+00:00

Retired engineer Steve Markham spent an astonishing 11,250 hours painstakingly piecing the 'iconic' British aircraft together in a barn at his home in Hampshire, ably assisted by wife Kay.

## Pub landlord, 53, who accused ex-girlfriend of domestic abuse loses appeal against 16 week jail term
 - [https://www.dailymail.co.uk/news/article-11274819/Pub-landlord-53-accused-ex-girlfriend-domestic-abuse-loses-appeal-against-16-week-jail-term.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274819/Pub-landlord-53-accused-ex-girlfriend-domestic-abuse-loses-appeal-against-16-week-jail-term.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 12:41:38+00:00

Award-winning pub landlord Gareth Slattery, 53, is behind bars after a 'vile' online message about his ex partner was watched 20,000 times on Tik Tok.

## Boxing coach, 55, collapses and dies in ring during charity fight for girl, 4, battling cancer
 - [https://www.dailymail.co.uk/news/article-11274439/Boxing-coach-55-collapses-dies-ring-charity-fight-girl-4-battling-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274439/Boxing-coach-55-collapses-dies-ring-charity-fight-girl-4-battling-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 12:28:24+00:00

Jules Bevis, 55, who was described by friends as the 'nicest and most caring bloke ever', was declared dead at the scene at the World Association of Wrestling Academy in Norwich, Norfolk.

## Mugshots of Victorian criminals found inside Derby police ledger
 - [https://www.dailymail.co.uk/news/article-11274663/Mugshots-Victorian-criminals-inside-Derby-police-ledger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274663/Mugshots-Victorian-criminals-inside-Derby-police-ledger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 12:14:01+00:00

The images were discovered inside a ledger dating from between 1890 to 1920. Above: Alice Wheeldon was convicted of plotting to kill the then Prime Minister David Lloyd George.

## Rugby fan, 27, 'smashed a glass into a woman's face' while watching British Lions play South Africa
 - [https://www.dailymail.co.uk/news/article-11274761/Rugby-fan-27-smashed-glass-womans-face-watching-British-Lions-play-South-Africa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274761/Rugby-fan-27-smashed-glass-womans-face-watching-British-Lions-play-South-Africa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 12:11:42+00:00

Ben England, 27, was enjoying a drink in the Wolfpack in Fulham, west London, when Kim Graham took exception to something he said about the Springboks on July 31 last year.

## Prince William becomes his father King Charles' new landlord for Highgrove
 - [https://www.dailymail.co.uk/femail/article-11274337/Prince-William-father-King-Charles-new-landlord-Highgrove.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11274337/Prince-William-father-King-Charles-new-landlord-Highgrove.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 12:10:05+00:00

An insider told The Sun: 'The King has a long lease and pays rent on Highgrove House and surrounding land [in Gloucestershire]'.

## Kwasi Kwarteng's latest blunder: Chancellor wrongly states Crown's income comes from Civil List
 - [https://www.dailymail.co.uk/news/article-11274625/Kwasi-Kwartengs-latest-blunder-Chancellor-wrongly-states-Crowns-income-comes-Civil-List.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274625/Kwasi-Kwartengs-latest-blunder-Chancellor-wrongly-states-Crowns-income-comes-Civil-List.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 12:02:06+00:00

Quizzed by veteran broadcaster Nick Ferrari on whether the royals should pay inheritance tax, Mr Kwarteng wrongly explained how the sovereign's funding came from the Civil List.

## Solicitor, 37, who injected his own blood into food at supermarkets will remain in mental hospital
 - [https://www.dailymail.co.uk/news/article-11274629/Solicitor-37-injected-blood-food-supermarkets-remain-mental-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274629/Solicitor-37-injected-blood-food-supermarkets-remain-mental-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 11:58:34+00:00

Leoaai Elghareeb, 37, ventured into three supermarkets on Fulham Palace Road, west London carrying a bucketful of hypodermic needles on August 25 last year.

## Wealthy British expat, 82, killed after vintage Aston Martin convertible crashes into a ditch
 - [https://www.dailymail.co.uk/news/article-11274225/Wealthy-British-expat-82-killed-vintage-Aston-Martin-convertible-crashes-ditch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274225/Wealthy-British-expat-82-killed-vintage-Aston-Martin-convertible-crashes-ditch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 11:20:11+00:00

David Twaites, 82 from London, who lived in the canton of Vaud in Switzerland, was travelling in the convertible with a group of British and Swiss friends to Corsica.

## Son, 73, flies 3,000 miles in a helicopter to scatter his mother's ashes from a peanut butter jar
 - [https://www.dailymail.co.uk/news/article-11274507/Son-73-flies-3-000-miles-helicopter-scatter-mothers-ashes-peanut-butter-jar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274507/Son-73-flies-3-000-miles-helicopter-scatter-mothers-ashes-peanut-butter-jar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 10:48:32+00:00

Andrew Greenhalgh, 73, (right) from Essex, wanted to take his mother's ashes, on a final journey across the UK travelling from the Isle of Man to Wales and Jersey. His mother passed away at 95 in 2019.

## Drunk driver wrecks £70,000 Maserati Levante supercar after ploughing into set of traffic lights
 - [https://www.dailymail.co.uk/news/article-11274561/Drunk-driver-wrecks-70-000-Maserati-Levante-supercar-ploughing-set-traffic-lights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274561/Drunk-driver-wrecks-70-000-Maserati-Levante-supercar-ploughing-set-traffic-lights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 10:37:21+00:00

A drunk driver smashed up a £70,000 Maserati Levante supercar after losing control and ploughing into a railings and a traffic light pole in Birmingham.

## Ex-prisoners will face compulsory drug testing after release
 - [https://www.dailymail.co.uk/news/article-11274521/Ex-prisoners-face-compulsory-drug-testing-release.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274521/Ex-prisoners-face-compulsory-drug-testing-release.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 10:31:33+00:00

From today, offenders supervised in probation hostels - known as approved premises - will be randomly tested for 14 different drugs.

## Gary Barlow delights Cornish locals after landing his helicopter on a school playing field
 - [https://www.dailymail.co.uk/tvshowbiz/article-11274463/Gary-Barlow-delights-Cornish-locals-landing-helicopter-school-playing-field.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11274463/Gary-Barlow-delights-Cornish-locals-landing-helicopter-school-playing-field.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 10:07:40+00:00

Barlow stunned players and spectators at Truro School after the helicopter used to taxi him into the south-west county for a live show landed on an adjacent patch of grass.

## Church organist, who sexually assaulted 14 boys as young as seven, jailed for 12 years
 - [https://www.dailymail.co.uk/news/article-11274269/Church-organist-sexually-assaulted-14-boys-young-seven-jailed-12-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274269/Church-organist-sexually-assaulted-14-boys-young-seven-jailed-12-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 09:43:04+00:00

Choirmaster and church organist, Richard Owen, (pictured) 71, began his jail sentence today after he was found guilty of sexually assaulting 14 boys at St Johns Church in Altrincham (pictured).

## Seven-months pregnant British mum may have to give birth in Spanish prison amid arrest in Tenerife
 - [https://www.dailymail.co.uk/news/article-11274303/Seven-months-pregnant-British-mum-birth-Spanish-prison-amid-arrest-Tenerife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274303/Seven-months-pregnant-British-mum-birth-Spanish-prison-amid-arrest-Tenerife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 09:37:39+00:00

Jamielee Fielding (pictured) was slapped with a €420 (£367) fine in 2021 after she was involved in a drunken altercation in Malaga, but left the country without paying her debt

## Drunken mother hurled racist abuse at Turkish taxi driver in front of her two children
 - [https://www.dailymail.co.uk/news/article-11274213/Drunken-mother-hurled-racist-abuse-Turkish-taxi-driver-two-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274213/Drunken-mother-hurled-racist-abuse-Turkish-taxi-driver-two-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 09:20:35+00:00

Joanna Brophy, 32, from Warrington, Cheshire, was arrested after getting home  from a house party at 1am despite being the only adult in charge of three children.

## Paparazzo 'attacked by Margot Robbie's British film-maker friends' says it's 'a miracle' he survived
 - [https://www.dailymail.co.uk/news/article-11274115/Paparazzo-attacked-Margot-Robbies-British-film-maker-friends-says-miracle-survived.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274115/Paparazzo-attacked-Margot-Robbies-British-film-maker-friends-says-miracle-survived.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 09:01:31+00:00

Pedro Alberto Orquera was attacked by a pair of  British film-makers, who took umbrage with the paparazzo when they spotted him snapping pics of their starlet friends on Sunday morning

## Ex-wife of football legend Shay Given in court fight with her ex-fiancé over supercar and £300k ring
 - [https://www.dailymail.co.uk/news/article-11274247/Ex-wife-football-legend-Shay-Given-court-fight-ex-fianc-supercar-300k-ring.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274247/Ex-wife-football-legend-Shay-Given-court-fight-ex-fianc-supercar-300k-ring.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 09:00:26+00:00

The ex-wife of football legend Shay Given, Jane Given, 47, is locked into a court battle with her former fiancé, Andrew Ralph, over an Aston Martin and £300,000 engagement ring

## Squirming minister Chris Philp insists axing 45% tax rate to help the super rich was 'not my idea'
 - [https://www.dailymail.co.uk/news/article-11274331/Squirming-minister-Chris-Philp-insists-axing-45-tax-rate-help-super-rich-not-idea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274331/Squirming-minister-Chris-Philp-insists-axing-45-tax-rate-help-super-rich-not-idea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 08:56:54+00:00

Chris Philp, Kwasi Kwarteng's deputy, was blamed for the idea of axing the top tax rate paid by people earning more than £150,000 in the first place as the Chancellor was forced to reinstate it.

## Southport Central Apartment Towers: Daredevil filmed scaling balconies of Gold Coast high rise
 - [https://www.dailymail.co.uk/news/article-11274251/Southport-Central-Apartment-Towers-Daredevil-filmed-scaling-balconies-Gold-Coast-high-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274251/Southport-Central-Apartment-Towers-Daredevil-filmed-scaling-balconies-Gold-Coast-high-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 08:55:17+00:00

The video filmed on Sunday shows the man scaling a Southport residential tower on the Gold Coast, horrifying residents and shocked onlookers below.

## Woman claims she racially abused her neighbours because they called her 'the fat white woman'
 - [https://www.dailymail.co.uk/news/article-11274215/Woman-claims-racially-abused-neighbours-called-fat-white-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274215/Woman-claims-racially-abused-neighbours-called-fat-white-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 08:52:24+00:00

Sheree Webb, 59, called her neighbours 'n***ers' multiple times, Swindon Magistrates Court heard. She was sentenced for two racially aggravated public order offences and criminal damage.

## University of Chicago's student organization hosts 'BIPOC-only' discussion about race on campus
 - [https://www.dailymail.co.uk/news/article-11274281/University-Chicagos-student-organization-hosts-BIPOC-discussion-race-campus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274281/University-Chicagos-student-organization-hosts-BIPOC-discussion-race-campus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 08:51:04+00:00

The raciial justice group UChicago United encourages students to sign up for its events to learn about the 'real' UChicago and what the university 'doesn't want you to know.'

## Married ex-police officer jailed for starting relationship with vulnerable domestic abuse victim
 - [https://www.dailymail.co.uk/news/article-11274159/Married-ex-police-officer-jailed-starting-relationship-vulnerable-domestic-abuse-victim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274159/Married-ex-police-officer-jailed-starting-relationship-vulnerable-domestic-abuse-victim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 08:40:07+00:00

Liam Mills, 34, a former South Yorkshire Police officer, cried in the docks as he was jailed for starting a relationship with a domestic abuse victim and sending her explicit content.

## Is gold the ultimate 'safe haven' for your money?
 - [https://www.dailymail.co.uk/money/diyinvesting/article-11232097/Is-gold-ultimate-safe-haven-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/diyinvesting/article-11232097/Is-gold-ultimate-safe-haven-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 08:24:56+00:00

In volatile times investing in gold often comes to the fore - with its proponents arguing it is a long-term store of value and can help combat inflation, but is that true?

## Optus cyber attack: Telco reveals 2.1 million customers exposed: NRL text, Deloitte review
 - [https://www.dailymail.co.uk/news/article-11273987/Optus-cyber-attack-Telco-reveals-2-1-million-customers-exposed-NRL-text-Deloitte-review.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273987/Optus-cyber-attack-Telco-reveals-2-1-million-customers-exposed-NRL-text-Deloitte-review.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 08:06:15+00:00

Around 1.2 million Optus customers have had at least one number from a current and valid form of identification, and personal information compromised.

## Putin 'deploys Belgorod nuclear submarine' amid sabre-rattling over Ukraine
 - [https://www.dailymail.co.uk/news/article-11274113/Putin-deploys-Belgorod-nuclear-submarine-amid-sabre-rattling-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274113/Putin-deploys-Belgorod-nuclear-submarine-amid-sabre-rattling-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 07:56:41+00:00

The Belgorod - a huge 600ft Russian nuclear submarine - has left its base in the White Sea and may be going to test its Poseidon doomsday device, a NATO warning note has said.

## The pound surges after Truss and Kwarteng perform 45p tax U-turn
 - [https://www.dailymail.co.uk/news/article-11274173/The-pound-surges-Truss-Kwarteng-perform-45p-tax-U-turn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274173/The-pound-surges-Truss-Kwarteng-perform-45p-tax-U-turn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 07:56:40+00:00

Sterling hit 1.125 US dollars at one stage, recovering back to levels seen before the mini-budget, though it pared back some of the gains in early morning trading to stand at 1.119.

## Kwasi Kwarteng admits he should not have attended 'Champagne reception'
 - [https://www.dailymail.co.uk/news/article-11274175/Kwasi-Kwarteng-admits-not-attended-Champagne-reception.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274175/Kwasi-Kwarteng-admits-not-attended-Champagne-reception.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 07:52:14+00:00

Chancellor Kwasi Kwarteng spent the evening of September 23 at a Tory networking event - also attended by party chair Jake Berry.

## Electric car Australia: EV replacement batteries costing up large sums: Tesla, Nissan, Lexus
 - [https://www.dailymail.co.uk/news/article-11274013/Electric-car-Australia-EV-replacement-batteries-costing-large-sums-Tesla-Nissan-Lexus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274013/Electric-car-Australia-EV-replacement-batteries-costing-large-sums-Tesla-Nissan-Lexus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 07:46:16+00:00

Batteries for electric cars in Australia cost more than half the amount of the car - with manufacturers revealing the eyewatering cost of replacements.

## NSW Government used 'behavioural insights unit' to guide people's behaviour during Covid
 - [https://www.dailymail.co.uk/news/article-11273665/NSW-Government-used-behavioural-insights-unit-guide-peoples-behaviour-Covid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273665/NSW-Government-used-behavioural-insights-unit-guide-peoples-behaviour-Covid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 07:44:42+00:00

The 'Behavioural Insights Unit' operated as part of the Department of Customer Service and was made up of 14 people that gave advice to the state government.

## British teenager dies just days before 15th birthday in Portugal holiday tragedy
 - [https://www.dailymail.co.uk/news/article-11274127/British-teenager-dies-just-days-15th-birthday-Portugal-holiday-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274127/British-teenager-dies-just-days-15th-birthday-Portugal-holiday-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 07:39:41+00:00

Jack Pollock, from Edinburgh, died suddenly in Portugal on Thursday while away with hit mother Johan and his younger brother.

## Tax cut live: Chancellor Kwasi Kwarteng is set to U-turn over abolition of 45p income tax rate
 - [https://www.dailymail.co.uk/news/live/article-11274047/Tax-cut-live-Chancellor-Kwasi-Kwarteng-set-U-turn-abolition-45p-income-tax-rate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11274047/Tax-cut-live-Chancellor-Kwasi-Kwarteng-set-U-turn-abolition-45p-income-tax-rate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 07:00:52+00:00

Follow MailOnline's liveblog for updates as Chancellor Kwasi Kwarteng is expected to make an abrupt U-turn over the abolition of the top rate of income tax.

## GoFundMe's most heart wrenching Florida disaster appeals
 - [https://www.dailymail.co.uk/news/article-11273919/GoFundMes-heart-wrenching-Florida-disaster-appeals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273919/GoFundMes-heart-wrenching-Florida-disaster-appeals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 06:57:10+00:00

Dozens of victims of Hurricane Ian have been left with little recourse other than to plead for help from the public via the crowdfunding platform GoFundMe as they seek to rebuild their lives.

## Shocking moment two Indiana judges were shot and wounded during a drunken brawl at White Castle
 - [https://www.dailymail.co.uk/news/article-11273905/Shocking-moment-two-Indiana-judges-shot-wounded-drunken-brawl-White-Castle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273905/Shocking-moment-two-Indiana-judges-shot-wounded-drunken-brawl-White-Castle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 06:47:19+00:00

The video of the May 1, 2019 shooting at the downtown Indianapolis location was finally unsealed after the gunman was found guilty last week.

## Average gas prices could rise further as OPEC mulls making its biggest reduction in supply
 - [https://www.dailymail.co.uk/news/article-11273907/Average-gas-prices-rise-OPEC-mulls-making-biggest-reduction-supply.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273907/Average-gas-prices-rise-OPEC-mulls-making-biggest-reduction-supply.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 06:45:58+00:00

The already pricey cost of gas could rise even further as OPEC+ considers cutting output by more than 1 million barrels a day for its biggest reduction since the pandemic.

## Australia's 'Mr Universe' Calum von Moger slashed a man's tyres in Melbourne road rage attack
 - [https://www.dailymail.co.uk/news/article-11273925/Australias-Mr-Universe-Calum-von-Moger-slashed-mans-tyres-Melbourne-road-rage-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273925/Australias-Mr-Universe-Calum-von-Moger-slashed-mans-tyres-Melbourne-road-rage-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 06:32:31+00:00

An Australian bodybuilder and former Mr Universe was 'scared' for his own safety when he pulled out a knife and slashed the tyres of a stranger he had just rear-ended in his car, a court has heard.

## Police called to scene of worst ever car crash in Lincoln, Nebraska by IPHONE that was in car
 - [https://www.dailymail.co.uk/news/article-11273853/Police-called-scene-worst-car-crash-Lincoln-Nebraska-IPHONE-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273853/Police-called-scene-worst-car-crash-Lincoln-Nebraska-IPHONE-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 06:02:39+00:00

Six people in their 20s were killed in a car crash in Lincoln, Nebraska on Sunday. Police have described as 'the worst crash in Lincoln in recent memory'. 911 was called automatically by iPhone.

## Tory revolt forces Liz Truss to ditch plans to scrap 45p tax rate
 - [https://www.dailymail.co.uk/news/article-11274005/Tory-revolt-forces-Liz-Truss-ditch-plans-scrap-45p-tax-rate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274005/Tory-revolt-forces-Liz-Truss-ditch-plans-scrap-45p-tax-rate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 06:01:16+00:00

The plans to reduce the amount people earning £150,000-a-year pay to HMRC has been branded a 'massive distraction' and has seen the Tories fall further behind Labour in the polls.

## Sarah Everard's killer Wayne Couzens will appear at the Old Bailey today accused of flashing
 - [https://www.dailymail.co.uk/news/article-11274011/Sarah-Everards-killer-Wayne-Couzens-appear-Old-Bailey-today-accused-flashing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11274011/Sarah-Everards-killer-Wayne-Couzens-appear-Old-Bailey-today-accused-flashing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 06:00:56+00:00

Sarah Everard's killer Wayne Couzens will return to the Old Bailey to enter pleas after being charged with flashing.

## Etihad won't honour heavily discounted airfares $300 Europe flights after Skyscanner glitch
 - [https://www.dailymail.co.uk/news/article-11273913/Etihad-wont-honour-heavily-discounted-airfares-300-Europe-flights-Skyscanner-glitch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273913/Etihad-wont-honour-heavily-discounted-airfares-300-Europe-flights-Skyscanner-glitch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 05:53:51+00:00

Luxury airline Etihad Airways announced it had cancelled all tickets booked during a 'glitch' that saw return airfares to Europe marked down to a tenth of its normal price.

## Sydney United fans slammed as 'embarrassing' by Australian sports presenter Lucy Zelić
 - [https://www.dailymail.co.uk/news/article-11273805/Sydney-United-fans-slammed-embarrassing-Australian-sports-presenter-Lucy-Zeli.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273805/Sydney-United-fans-slammed-embarrassing-Australian-sports-presenter-Lucy-Zeli.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 05:44:20+00:00

Sports presenter  Lucy Zelić has weighed in on the 'embarrassing' scenes at the Australia Cup final - which saw some Sydney United fans perform Nazi Salutes and boo during the Welcome to Country.

## ABC weekend cohost Fauziah Ibrahim baffles viewers with suggestive 'knob' joke live on air
 - [https://www.dailymail.co.uk/news/article-11273795/ABC-weekend-cohost-Fauziah-Ibrahim-baffles-viewers-suggestive-knob-joke-live-air.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273795/ABC-weekend-cohost-Fauziah-Ibrahim-baffles-viewers-suggestive-knob-joke-live-air.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 05:41:41+00:00

An ABC news anchor has stunned her guest and viewers after making a suggestive 'knob' joke during a segment on satirical scientific awards -  the Ig Nobel Prize.

## Joshua Duperouzel arrested by police over fatal shooting of bikie associate Joseph Versace
 - [https://www.dailymail.co.uk/news/article-11273799/Joshua-Duperouzel-arrested-police-fatal-shooting-bikie-associate-Joseph-Versace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273799/Joshua-Duperouzel-arrested-police-fatal-shooting-bikie-associate-Joseph-Versace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 05:39:29+00:00

Joshua Colin Duperouzel, 25, was wanted by police to help them in their inquiries over the death of Joseph Versace at Gnangara, Perth, on Thursday.

## Outcry as British researcher is given ANOTHER grant by NIH to investigate COVID
 - [https://www.dailymail.co.uk/news/article-11273773/Outcry-British-researcher-given-grant-NIH-investigate-COVID.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273773/Outcry-British-researcher-given-grant-NIH-investigate-COVID.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 04:59:07+00:00

The National Institute of Allergy and Infectious Diseases, which is still led by Dr. Anthony Fauci, issued a $3.3 million grant to the EcoHealth Alliance in August, a scientific research organization.

## Penrith Panthers star kicks off Mad Monday celebrations with a hit from a vape
 - [https://www.dailymail.co.uk/news/article-11273713/Penrith-Panthers-star-kicks-Mad-Monday-celebrations-hit-vape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273713/Penrith-Panthers-star-kicks-Mad-Monday-celebrations-hit-vape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 04:57:38+00:00

Penrith Panthers front-rower James Fisher-Harris was caught vaping at a Mad Monday fan event after Sunday night's grand final win.

## Kamala Harris ignores question about giving away Hurricane Ian relief based on 'equity'
 - [https://www.dailymail.co.uk/news/article-11273761/Kamala-Harris-ignores-question-giving-away-Hurricane-Ian-relief-based-equity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273761/Kamala-Harris-ignores-question-giving-away-Hurricane-Ian-relief-based-equity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 04:39:35+00:00

Harris was asked by a reporter at the 51st annual Phoenix Awards, 'Vice President, can you clarify what you meant about equity for hurricane relief?'

## Gisele misses another of Tom Brady's games amid divorce rumors
 - [https://www.dailymail.co.uk/news/article-11273729/Gisele-misses-Tom-Bradys-games-amid-divorce-rumors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273729/Gisele-misses-Tom-Bradys-games-amid-divorce-rumors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 04:37:51+00:00

Supermodel Gisele Bündchen missed another of her star quarterback husband Tom Brady's games on Sunday as she was instead pictured walking around Miami solo amid divorce rumors.

## Urgent warning to all Westpac and Commonwealth Bank mortgage-holders
 - [https://www.dailymail.co.uk/news/article-11273885/Urgent-warning-Westpac-Commonwealth-Bank-mortgage-holders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273885/Urgent-warning-Westpac-Commonwealth-Bank-mortgage-holders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 04:22:52+00:00

One last oversized rate rise is broadly expected before the central bank is tipped to start winding its policy tightening back.

## The sophisticated AMP and ANZ scam that every Australian needs to know about
 - [https://www.dailymail.co.uk/news/article-11273589/The-sophisticated-AMP-ANZ-scam-Australian-needs-know-about.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273589/The-sophisticated-AMP-ANZ-scam-Australian-needs-know-about.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 04:02:32+00:00

A call centre in the Phillipines has been dramatically raided after innocent Australians lost hundreds of thousands of dollars in a high-level superannuation scam.

## Ivanka Trump and husband Jared Kushner take their son to a little league baseball game in Miami
 - [https://www.dailymail.co.uk/news/article-11273689/Ivanka-Trump-husband-Jared-Kushner-son-little-league-baseball-game-Miami.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273689/Ivanka-Trump-husband-Jared-Kushner-son-little-league-baseball-game-Miami.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 03:53:53+00:00

Jared Kushner and Ivanka Trump spent past of their weekend at a baseball game for their son, Theo, 6. Earlier in the week the couple had been in New Jersey as as Hurricane Ian barreled toward Florida.

## Sydney, Melbourne, Brisbane weather: Record breaking rain bomb about to strike
 - [https://www.dailymail.co.uk/news/article-11273563/Sydney-Melbourne-Brisbane-weather-Record-breaking-rain-bomb-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273563/Sydney-Melbourne-Brisbane-weather-Record-breaking-rain-bomb-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 03:42:12+00:00

Meteorologists are warning of an eight-day rain event with dangerous thunderstorms and flooding expected to hit 'virtually all' Australia.

## Brisbane bus shelters blasted by TikTok user as worst in Australia
 - [https://www.dailymail.co.uk/news/article-11273621/Brisbane-bus-shelters-blasted-TikTok-user-worst-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273621/Brisbane-bus-shelters-blasted-TikTok-user-worst-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 03:37:42+00:00

In a video shared to TikTok the traveller was catching a bus to the pub to watch the NRL grand final when he took aim at Brisbane City Council's modern bus stops.

## DeSantis used former spy to recruit Venezuelan asylum seekers in Texas to fly to Martha's Vineyard
 - [https://www.dailymail.co.uk/news/article-11273669/DeSantis-used-former-spy-recruit-Venezuelan-asylum-seekers-Texas-fly-Marthas-Vineyard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273669/DeSantis-used-former-spy-recruit-Venezuelan-asylum-seekers-Texas-fly-Marthas-Vineyard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 02:59:44+00:00

The plot to fly migrants from Texas to Martha's Vineyard in Massachusetts was orchestrated by a former spy with the US Army's counterintelligence unit

## VB, Bonds, Tim Tams, Milo, FourN'Twenty pies: No longer Australian owned
 - [https://www.dailymail.co.uk/news/article-11256903/VB-Bonds-Tim-Tams-Milo-FourNTwenty-pies-No-longer-Australian-owned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11256903/VB-Bonds-Tim-Tams-Milo-FourNTwenty-pies-No-longer-Australian-owned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 02:53:34+00:00

Does it really matter, especially if an iconic Aussie brand isn't Australian owned? To many Aussies, yes it does matter. Here's the sad tally of legendary brands gone to foreign owners.

## Surprising jobs that offer Aussies over $150k revealed
 - [https://www.dailymail.co.uk/news/article-11261349/Surprising-jobs-offer-Aussies-150k-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11261349/Surprising-jobs-offer-Aussies-150k-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 02:44:56+00:00

The surprising jobs earning Australians over $150k have been revealed as workers with tech skills reportedly raking in the most cash.

## Richardson Park asbestos dump discovered near Ludmilla Primary School in Darwin
 - [https://www.dailymail.co.uk/news/article-11273475/Richardson-Park-asbestos-dump-discovered-near-Ludmilla-Primary-School-Darwin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273475/Richardson-Park-asbestos-dump-discovered-near-Ludmilla-Primary-School-Darwin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 02:41:08+00:00

Some 1,600 cubic metres of asbestos-containing material has been found at Richardson Park at Ludmilla in Darwin, in the Northern Territory.

## Young Aussie Annabelle Knight makes surprising revelation about life in a nursing home
 - [https://www.dailymail.co.uk/news/article-11273381/Young-Aussie-Annabelle-Knight-makes-surprising-revelation-life-nursing-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273381/Young-Aussie-Annabelle-Knight-makes-surprising-revelation-life-nursing-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 02:32:23+00:00

Gold Coast Only Fans star Annabelle Knight was shocked to find out retirees living in nursing homes 'root like bunnies' and 'sneak into each others rooms'.

## Former CIA director warns the US would destroy Russia's troops if Putin uses nuclear weapons
 - [https://www.dailymail.co.uk/news/article-11273427/Former-CIA-director-warns-destroy-Russias-troops-Putin-uses-nuclear-weapons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273427/Former-CIA-director-warns-destroy-Russias-troops-Putin-uses-nuclear-weapons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 02:22:25+00:00

A former CIA director warned that the US and NATO allies would destroy Russian forces if Russian President Vladimir Putin used nuclear weapons in his war with Ukraine.

## Medicinal cannabis Australia: driver passes roadside drug test
 - [https://www.dailymail.co.uk/news/article-11273257/Medicinal-cannabis-Australia-driver-passes-roadside-drug-test.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273257/Medicinal-cannabis-Australia-driver-passes-roadside-drug-test.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 02:03:17+00:00

A driver on a road trip has highlighted Australia's  changing medicinal cannabis laws after cops waved him on his way despite admitting he'd recently got high.

## Coast Guard crew makes heroic rescues on Florida's Sanibel Island after Hurricane Ian blew it apart
 - [https://www.dailymail.co.uk/news/article-11273477/Coast-Guard-crew-makes-heroic-rescues-Floridas-Sanibel-Island-Hurricane-Ian-blew-apart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273477/Coast-Guard-crew-makes-heroic-rescues-Floridas-Sanibel-Island-Hurricane-Ian-blew-apart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 02:01:09+00:00

U.S. Coast Guard shows a Miami-based aircrew in a MH-65 Dolphin helicopter rescue several people from cut off Sanibel Island in southwest Florida. A number of rescues are depicted on the film.

## Las Vegas GOP councilwomen are reprimanded over vicious city hall CATFIGHT
 - [https://www.dailymail.co.uk/news/article-11273479/Las-Vegas-GOP-councilwomen-reprimanded-vicious-city-hall-CATFIGHT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273479/Las-Vegas-GOP-councilwomen-reprimanded-vicious-city-hall-CATFIGHT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 01:52:34+00:00

Victoria Seaman and Michele Fiore were both judged to have violated the city's code of conduct policy for the fight, which saw Fiore break Seaman's finger and  attempt to throw her to the floor.

## British PoW who was tortured by Putin's troops in Ukraine says he STILL wants to return to frontline
 - [https://www.dailymail.co.uk/news/article-11273517/British-PoW-tortured-Putins-troops-Ukraine-says-wants-return-frontline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273517/British-PoW-tortured-Putins-troops-Ukraine-says-wants-return-frontline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 01:48:43+00:00

Scaffolder Andrew Hill, 36, was freed last month as part of a deal that also saw fellow British prisoners of war Aiden Aslin and Shaun Pinner released and is now back home.

## Horrific footage shows an Indigenous boy bleeding after being arrested by cops in Coraki NSW
 - [https://www.dailymail.co.uk/news/article-11253373/Horrific-footage-shows-Indigenous-boy-bleeding-arrested-cops-Coraki-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11253373/Horrific-footage-shows-Indigenous-boy-bleeding-arrested-cops-Coraki-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 01:25:40+00:00

A video posted online shows the 14-year-old boy sitting on the ground in handcuffs with blood streaming down his face after being arrested in Coraki, in northern NSW, on September 11.

## Harry and Sandra Redknapp heartbreakingly reveal they suffered a miscarriage over 50 years ago
 - [https://www.dailymail.co.uk/tvshowbiz/article-11272957/Harry-Sandra-Redknapp-heartbreakingly-reveal-suffered-miscarriage-50-years-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11272957/Harry-Sandra-Redknapp-heartbreakingly-reveal-suffered-miscarriage-50-years-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 01:15:31+00:00

The former footballer, 75, and his hairdress wife Sandra have revealed that they tragically lost a child back in 1969, with the former hairdresser suffering a miscarriage while 12 weeks pregnant.

## More mortgage misery as NatWest hikes interest rates amid market chaos sparked by mini-Budget
 - [https://www.dailymail.co.uk/news/article-11273597/More-mortgage-misery-NatWest-hikes-rates-amid-market-chaos-sparked-mini-Budget.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273597/More-mortgage-misery-NatWest-hikes-rates-amid-market-chaos-sparked-mini-Budget.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 01:08:22+00:00

The lender's rates had previously been between three and four per cent, but a notice was issued to brokers on Sunday morning confirming this will rise to around four to six per cent.

## Admiral Lord West praises Britain's nuclear deterrent as 'ultimate safeguard' against 'madman' Putin
 - [https://www.dailymail.co.uk/news/article-11273639/Admiral-Lord-West-praises-Britains-nuclear-deterrent-ultimate-safeguard-against-madman-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273639/Admiral-Lord-West-praises-Britains-nuclear-deterrent-ultimate-safeguard-against-madman-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 01:05:17+00:00

Speaking on the 70th anniversary of the UK's first atomic bomb test, Admiral Lord West said nukes are a critical defence against hostile threats.

## DAILY MAIL COMMENT: Disunited Tories will reap electoral disaster
 - [https://www.dailymail.co.uk/news/article-11273651/DAILY-MAIL-COMMENT-Disunited-Tories-reap-electoral-disaster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273651/DAILY-MAIL-COMMENT-Disunited-Tories-reap-electoral-disaster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 01:01:30+00:00

DAILY MAIL COMMENT: In political circles, it is joked that a government that isn't trailing in the polls halfway through the electoral cycle is not doing its job correctly.

## Albanian gangs busted for 'kidnapping man and holding him to ransom in London for £400,000'
 - [https://www.dailymail.co.uk/news/article-11273619/Albanian-gangs-busted-kidnapping-man-holding-ransom-London-400-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273619/Albanian-gangs-busted-kidnapping-man-holding-ransom-London-400-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:57:36+00:00

The man was said to have been beaten and tortured during the kidnap in east London after debts hadn't been paid. The Metropolitan Police conducted raids last week to rescue him.

## Fears for Christmas turkey stock as more than three million birds are culled in bird flu outbreak
 - [https://www.dailymail.co.uk/news/article-11273559/Fears-Christmas-turkey-stock-three-million-birds-culled-bird-flu-outbreak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273559/Fears-Christmas-turkey-stock-three-million-birds-culled-bird-flu-outbreak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:57:34+00:00

Stocks of festive turkeys could be at risk if the worst bird flu outbreak in UK history spreads, farmers warn. More than three million birds have been culled and producers are increasingly concerned.

## Quality Street owner Nestle switches to paper twist wrappers in bid to slash plastic waste
 - [https://www.dailymail.co.uk/news/article-11273561/Quality-Street-owner-Nestle-switches-paper-twist-wrappers-bid-slash-plastic-waste.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273561/Quality-Street-owner-Nestle-switches-paper-twist-wrappers-bid-slash-plastic-waste.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:57:16+00:00

Quality Street twist wrappers are to be made from paper instead of plastic as Nestle switches to greener packaging in the coming months, with KitKats' wrapping to be 80 per cent recycled as well.

## Northern Territory Barkly mayor Jeffrey McLaughlin facing drug, cannabis, charges
 - [https://www.dailymail.co.uk/news/article-11228821/Northern-Territory-Barkly-mayor-Jeffrey-McLaughlin-facing-drug-cannabis-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11228821/Northern-Territory-Barkly-mayor-Jeffrey-McLaughlin-facing-drug-cannabis-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:56:03+00:00

Northern Territory mayor Jeffrey McLaughlin is facing four drug charges after allegedly testing positive for cannabis in a roadside test on Monday.

## Cooper Pugh furious at Queensland Police after Mermaid Beach robbery despite tracking items
 - [https://www.dailymail.co.uk/news/article-11273177/Cooper-Pugh-furious-Queensland-Police-Mermaid-Beach-robbery-despite-tracking-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273177/Cooper-Pugh-furious-Queensland-Police-Mermaid-Beach-robbery-despite-tracking-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:53:12+00:00

A Queensland resident whose home was robbed of $20,000 worth of items claims police offered no help in catching the thieves despite giving them an exact location of the stolen property.

## Plan to bring ISIS brides and children home to Australia poses 'unnecessary risk'
 - [https://www.dailymail.co.uk/news/article-11273449/Plan-bring-ISIS-brides-children-home-Australia-poses-unnecessary-risk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273449/Plan-bring-ISIS-brides-children-home-Australia-poses-unnecessary-risk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:44:25+00:00

The Opposition is asking questions over federal government plans to bring 16 women and 42 children who are families of Islamic State members and have been held in al-Roj detention camp in Syria.

## Large numbers of Britons in their 50s have failed to go back to work since Covid pandemic
 - [https://www.dailymail.co.uk/news/article-11273521/Large-numbers-Britons-50s-failed-work-Covid-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273521/Large-numbers-Britons-50s-failed-work-Covid-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:42:43+00:00

Work and Pensions minister Victoria Prentis told a conference fringe meeting: 'We need their skills, we need their experience... we desperately need them back.'

## Woman killed on birthday trip in after a 'nail pierced her main artery' during Hurricane Ian
 - [https://www.dailymail.co.uk/news/article-11273383/Woman-killed-birthday-trip-nail-pierced-main-artery-Hurricane-Ian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273383/Woman-killed-birthday-trip-nail-pierced-main-artery-Hurricane-Ian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:39:40+00:00

A woman celebrating her 40th birthday on a vacation in paradise with friends was tragically killed when a nail from a collapsing roof pierced her heart during Hurricane Ian.

## Analysis shows almost 23,000 younger staff have quit this year
 - [https://www.dailymail.co.uk/news/article-11273607/Analysis-shows-23-000-younger-staff-quit-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273607/Analysis-shows-23-000-younger-staff-quit-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:27:22+00:00

Last week analysis by the Nuffield Trust revealed that more than 40,000 nurses have left in the past year, one in nine of the workforce.

## Woman raped repeatedly by Jimmy Savile when she was 15 speaks out as she describes vile monster
 - [https://www.dailymail.co.uk/news/article-11273215/Woman-raped-repeatedly-Jimmy-Savile-15-speaks-describes-vile-monster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273215/Woman-raped-repeatedly-Jimmy-Savile-15-speaks-describes-vile-monster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:27:00+00:00

The victim, who has not been named to protect her identity, is one of the five women featured in the ITV documentary Exposure: The Other Side of Jimmy Savile ten years ago.

## Ukrainians queue at McDonald's restaurants as fast-food chain reopens branches in war-torn country
 - [https://www.dailymail.co.uk/news/article-11273531/Ukrainians-queue-McDonalds-restaurants-fast-food-chain-reopens-branches-war-torn-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273531/Ukrainians-queue-McDonalds-restaurants-fast-food-chain-reopens-branches-war-torn-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:24:46+00:00

McDonald's reopened some of its walk-in restaurants in Ukraine on October 1 - after starting deliveries again last week. It temporarily closed 100 branches after Russia invaded in February.

## Blowing up Redcar's steelworks clears way for 'Investment Zones' to level up. But will they work?
 - [https://www.dailymail.co.uk/news/article-11273467/Blowing-Redcars-steelworks-clears-way-Investment-Zones-level-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11273467/Blowing-Redcars-steelworks-clears-way-Investment-Zones-level-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2022-10-03 00:00:05+00:00

British Steel's former Basic Oxygen Steelmaking (BOS) plant here at Redcar involved 105,000 tons of solid steel and iron.
It took nearly two tons of explosives to bring it down.


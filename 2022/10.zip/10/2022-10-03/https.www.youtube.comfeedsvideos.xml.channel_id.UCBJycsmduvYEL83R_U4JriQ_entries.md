# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Smart Home Tech I ACTUALLY Use!
 - [https://www.youtube.com/watch?v=bmIVWe3Cux8](https://www.youtube.com/watch?v=bmIVWe3Cux8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-10-03 00:00:00+00:00

First video from the in-progress basement studio 👀

Thanks to @BestBuy for sponsoring today's video! Check out the smart home tech I showed off on my Best Buy storefront at https://bestbuy.7tiv.net/dox2Kj or the links below.

This is the tech I have set up around my home right now in 2022:

Nest Hub Max Smart Display at https://bestbuy.7tiv.net/AoZbQN
Google Nest Smart Thermostat at https://bestbuy.7tiv.net/RyQk3a 
Google Nest Doorbell Battery at https://bestbuy.7tiv.net/GjWvk9
Google Nest Camera at https://bestbuy.7tiv.net/KebD3A 
Google Nest Camera with Floodlight at https://bestbuy.7tiv.net/qnM7Xj
Google Nest x Yale - Smart Lock at https://bestbuy.7tiv.net/a1g0zo
Philips Hue Gradient Singe Table Lamp at https://bestbuy.7tiv.net/gb0272
NETGEAR Orbi AX4200 Tri-Band WiFi 6 Mesh System at https://bestbuy.7tiv.net/15xmkx
TP-Link - Kasa Smart WiFi Plug at https://bestbuy.7tiv.net/WD51zZ
Sonos Beam at https://bestbuy.7tiv.net/5brVG3
Sonos Sub at https://bestbuy.7tiv.net/kj6mv3

The links in the description are affiliate links, which means I will earn a small commission if you purchase through these links. For more information and details about these products and more, visit https://bestbuy.com


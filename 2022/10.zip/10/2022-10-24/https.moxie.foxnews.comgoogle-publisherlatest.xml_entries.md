# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Teachers' union head silent over latest US test scores showing troubling decline in math, reading
 - [https://www.foxnews.com/media/teachers-union-head-silent-latest-us-test-scores-showing-troubling-decline-math-reading](https://www.foxnews.com/media/teachers-union-head-silent-latest-us-test-scores-showing-troubling-decline-math-reading)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 23:55:43+00:00

Teachers' union head kept a low profile after new national test scores showed a significant drop in math and reading among U.S. students impacted by remote learning during the pandemic

## Brittney Griner not expecting 'any miracles' in appeal, her lawyers say
 - [https://www.foxnews.com/sports/brittney-griner-not-expecting-any-miracles-appeal-her-lawyers-say](https://www.foxnews.com/sports/brittney-griner-not-expecting-any-miracles-appeal-her-lawyers-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 23:37:39+00:00

Brittney Griner's attorneys said Monday that the WNBA star isn't hopeful ahead her appeal on Tuesday, according to a report.

## Giants rookie tight end needs eye surgery after freak injury vs. Jaguars
 - [https://www.foxnews.com/sports/giants-rookie-tight-end-needs-eye-surgery-freak-injury-jaguars](https://www.foxnews.com/sports/giants-rookie-tight-end-needs-eye-surgery-freak-injury-jaguars)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 23:28:29+00:00

New York Giants rookie tight end Daniel Bellinger needs eye surgery after a freak injury during the team's win over the Jacksonville Jaguars on Sunday.

## Greg Gutfeld: 'Nothing gets done' to tackle crime crisis
 - [https://www.foxnews.com/media/greg-gutfeld-nothing-gets-done-tackle-crime-crisis](https://www.foxnews.com/media/greg-gutfeld-nothing-gets-done-tackle-crime-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 23:24:54+00:00

Fox News host Greg Gutfeld voices his frustration over no action being taken on rising crime across America on "The Five."

## Ohio superintendent defends bringing 'anarchist bimbo' who posted about 'sex work' to high school classroom
 - [https://www.foxnews.com/media/ohio-superintendent-defends-bringing-anarchist-bimbo-posted-sex-work-high-school-classroom](https://www.foxnews.com/media/ohio-superintendent-defends-bringing-anarchist-bimbo-posted-sex-work-high-school-classroom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 23:21:01+00:00

An Ohio district official, Trent Bowers, defends a decision to bring in a speaker who posted about 'sex work' on her Twitter account.

## Judge Jeanine Pirro calls out Democrats for trying to avoid inflation: It's like a 'shell game'
 - [https://www.foxnews.com/media/judge-jeanine-pirro-calls-out-democrats-trying-avoid-inflation-shell-game](https://www.foxnews.com/media/judge-jeanine-pirro-calls-out-democrats-trying-avoid-inflation-shell-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 23:13:33+00:00

"The Five" co-host Judge Jeanine Pirro explains why the Democratic Party wants to change the conversation about inflation and how big a role it will play in the November midterms.

## Debbie Collier case: Investigators consider Georgia woman's death may not be homicide, sources say
 - [https://www.foxnews.com/us/debbie-collier-case-investigators-consider-georgia-womans-death-may-not-be-homicide](https://www.foxnews.com/us/debbie-collier-case-investigators-consider-georgia-womans-death-may-not-be-homicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 23:13:02+00:00

Georgia investigators have begun mulling the idea that the gruesome death of Debbie Collier may not be a homicide as initially suspected, sources say.

## Texas constable says he will fight blue county’s 'defunding' of his office
 - [https://www.foxnews.com/us/texas-constable-says-he-will-fight-blue-countys-defunding-his-office](https://www.foxnews.com/us/texas-constable-says-he-will-fight-blue-countys-defunding-his-office)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 23:09:32+00:00

Harris County Precinct 4 Constable Mark Herman is filing a complaint against the state this week alleging that his office is being defunded nearly $989,000.

## Texas authorities, Border Patrol make 463-pound marijuana bust
 - [https://www.foxnews.com/us/texas-authorities-border-patrol-make-436-pound-marijuana-bust-on-border](https://www.foxnews.com/us/texas-authorities-border-patrol-make-436-pound-marijuana-bust-on-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 23:01:13+00:00

A group of marijuana smugglers brought in 463 pounds of the drug on a raft into the United States from Mexico.

## White House groundskeeper has served presidents, families and pets in 50 years on the job
 - [https://www.foxnews.com/lifestyle/white-house-groundskeeper-presidents-families-pets-50-years-job](https://www.foxnews.com/lifestyle/white-house-groundskeeper-presidents-families-pets-50-years-job)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 22:59:11+00:00

In 1972, Dale Haney joined the groundskeeping staff at the White House. Now, 50 years later, he's being honored for his work and service to the famous home and across many presidencies.

## Congressman demands records from DOJ detailing FACE Act abortion prosecutions: 'Easily weaponized'
 - [https://www.foxnews.com/politics/congressman-demands-records-doj-detailing-face-act-abortion-prosecutions-easily-weaponzied](https://www.foxnews.com/politics/congressman-demands-records-doj-detailing-face-act-abortion-prosecutions-easily-weaponzied)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 22:57:39+00:00

Rep. Chip Roy of Texas demanded the Department of Justice turn over a list of people prosecuted under the FACE Act since 1994 as the law is being used to arrest pro-life activists.

## Beverly Hills police investigating antisemitic flyers left throughout city
 - [https://www.foxnews.com/us/beverly-hills-police-investigating-antisemitic-flyers-left-throughout-city](https://www.foxnews.com/us/beverly-hills-police-investigating-antisemitic-flyers-left-throughout-city)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 22:42:51+00:00

A batch of antisemitic flyers was left in an area of Beverly Hills over the weekend after demonstrators unfurled a banner over a freeway praising Kanye West's antisemitic remarks.

## Chargers lose one of top free agent additions for season
 - [https://www.foxnews.com/sports/chargers-lose-top-free-agent-addition-season-report](https://www.foxnews.com/sports/chargers-lose-top-free-agent-addition-season-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 22:40:57+00:00

Los Angeles Chargers cornerback J.C. Jackson has a ruptured patellar tendon and will miss the rest of the season after suffering the injury on Sunday.

## Missing Georgia toddler's mother tells all in televised interview days after boozy nightlife exposed
 - [https://www.foxnews.com/us/missing-georgia-toddlers-mother-tells-all-televised-interview-days-after-boozy-nightlife-exposed](https://www.foxnews.com/us/missing-georgia-toddlers-mother-tells-all-televised-interview-days-after-boozy-nightlife-exposed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 22:38:08+00:00

Leilani Simon, the mother of missing Quinton Simon, told local media she would turn herself in "if something does come up" faulting her in his disappearance.

## Jets' Breece Hall, Alijah Vera-Tucker out for the season with injuries: 'Those are two potential pro bowlers'
 - [https://www.foxnews.com/sports/jets-breece-hall-alijah-vera-tucker-out-season-injuries-those-are-two-potential-pro-bowlers](https://www.foxnews.com/sports/jets-breece-hall-alijah-vera-tucker-out-season-injuries-those-are-two-potential-pro-bowlers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 22:29:42+00:00

The New York Jets, off to a 5-2 start, will be without star running back Breece Hall and offensive lineman Alijah Vera-Tucker who suffered significant injuries in Sunday's victory.

## Midterm elections: Google manipulates search engine results against Republicans, Media Research Center says
 - [https://www.foxnews.com/media/midterm-elections-google-manipulates-search-engine-results-against-republicans-media-research-center-says](https://www.foxnews.com/media/midterm-elections-google-manipulates-search-engine-results-against-republicans-media-research-center-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 22:27:28+00:00

The Media Research Center is calling on Google to "stop its war on democracy" after a study found search engine results favor Democrats over Republicans.

## Colts bench Matt Ryan for second-year quarterback Sam Ehlinger: 'We think he’s ready'
 - [https://www.foxnews.com/sports/colts-bench-matt-ryan-second-year-quarterback-sam-ehlinger-we-think-hes-ready](https://www.foxnews.com/sports/colts-bench-matt-ryan-second-year-quarterback-sam-ehlinger-we-think-hes-ready)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 22:13:24+00:00

Veteran quarterback Matt Ryan will be benched the remainder of the season.

## 'Special Report' All-Star panel on inflation looming over midterms
 - [https://www.foxnews.com/transcript/special-report-all-star-panel-inflation-looming-midterms](https://www.foxnews.com/transcript/special-report-all-star-panel-inflation-looming-midterms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 22:00:25+00:00

Guests: Guy Benson, Mara Liasson, Ben Domenech

## In 2022 midterm elections, 'It's the economy, stupid' still applies
 - [https://www.foxnews.com/opinion/in-2022-midterm-elections-its-the-economy-stupid-still-applies](https://www.foxnews.com/opinion/in-2022-midterm-elections-its-the-economy-stupid-still-applies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 22:00:17+00:00

Government spending is a problem and we are witnessing its results with sky-high inflation. James Carville once said, "It's the economy, stupid." The same applies in 2022.

## Michigan's Jim Harbaugh has beef with Penn State's James Franklin: 'I have bigger fish to fry'
 - [https://www.foxnews.com/sports/michigans-jim-harbaugh-beef-penn-state-james-franklin](https://www.foxnews.com/sports/michigans-jim-harbaugh-beef-penn-state-james-franklin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 21:47:41+00:00

Michigan head coach Jim Harbaugh has some beef with Penn State head coach James Franklin after the latter made comments about Michigan Stadium's one tunnel where both teams go.

## Celebrities mourn the loss of Leslie Jordan: 'Put a smile on the faces of so many'
 - [https://www.foxnews.com/entertainment/celebrities-mourn-loss-leslie-jordan](https://www.foxnews.com/entertainment/celebrities-mourn-loss-leslie-jordan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 21:33:02+00:00

Leslie Jordan died on Monday at 67 after a car crash, Fox News Digital confirmed. Hollywood stars from "Will & Grace," "American Horror Story" and beyond are mourning the late star.

## Marriage crisis: Reddit poster learns her husband is cheating on her when a lawyer calls
 - [https://www.foxnews.com/lifestyle/marriage-crisis-reddit-poster-husband-cheating-lawyer-calls](https://www.foxnews.com/lifestyle/marriage-crisis-reddit-poster-husband-cheating-lawyer-calls)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 21:32:10+00:00

After a Reddit poster shared details about a betrayal by her husband — after a lawyer called her — marriage experts weighed in on steps to take to save the marriage.

## Charles Payne roasts 'despicable' Matthew Dowd for comparing GOP to Nazi Germany: 'Piece of garbage'
 - [https://www.foxnews.com/media/charles-payne-roasts-despicable-matthew-dowd-comparing-gop-nazi-germany-piece-garbage](https://www.foxnews.com/media/charles-payne-roasts-despicable-matthew-dowd-comparing-gop-nazi-germany-piece-garbage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 21:28:27+00:00

Fox Business host Charles Payne tore into MSNBC political analyst Matthew Dowd for making a "despicable" comparison between the GOP and Nazi Germany leadership.

## Katie Hobbs stumbles when pressed on refusing to debate Kari Lake: 'The debate about debates is over'
 - [https://www.foxnews.com/media/katie-hobbs-stumbles-pressed-refusing-debate-kari-lake](https://www.foxnews.com/media/katie-hobbs-stumbles-pressed-refusing-debate-kari-lake)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 21:19:32+00:00

Democratic Arizona gubernatorial candidate Katie Hobbs faced pushback on Friday regarding her refusal to debate her Republican opponent Kari Lake for the midterm elections.

## State AGs say Fauci, Zuckerberg 'colluded' to kill COVID lab leak theory
 - [https://www.foxnews.com/politics/state-ags-fauci-zuckerberg-colluded-kill-covid-lab-leak-theory](https://www.foxnews.com/politics/state-ags-fauci-zuckerberg-colluded-kill-covid-lab-leak-theory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 21:19:21+00:00

Missouri and Louisiana AGs allege that Dr. Fauci "colluded" with Big Tech platforms to censor speakers and speech related to COVID-19 and tried to bury the Wuhan lab-leak theory.

## Biden admin set to warn of threats to nation's election security: report
 - [https://www.foxnews.com/politics/biden-admin-set-warn-threats-nations-election-security-report](https://www.foxnews.com/politics/biden-admin-set-warn-threats-nations-election-security-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 21:10:12+00:00

The Biden administration is expected to issue an internal intelligence bulletin this week highlighting threats to the nation's election security.

## 'The Five' on Democrats insisting midterms are not about inflation
 - [https://www.foxnews.com/transcript/the-five-democrats-insisting-midterms-inflation](https://www.foxnews.com/transcript/the-five-democrats-insisting-midterms-inflation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 21:00:55+00:00

This is a rush transcript of "The Five" on October 24, 2022

## MSNBC’s obsession with 'fascism' blasted as 'constant fear-mongering' as network uses term 1,614 times in 2022
 - [https://www.foxnews.com/media/msnbc-obsession-fascism-blasted-constant-fear-mongering-network-uses-term-1614-times-2022](https://www.foxnews.com/media/msnbc-obsession-fascism-blasted-constant-fear-mongering-network-uses-term-1614-times-2022)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 21:00:49+00:00

MSNBC has used the terms “fascism” or “fascist” a staggering 1,614 times in 2022, often to smear Republicans, as critics believe the network is “attempting to divide.”

## Chicago man shot and killed in front of Greyhound bus station where he worked
 - [https://www.foxnews.com/us/chicago-man-shot-killed-greyhound-bus-station-where-he-worked](https://www.foxnews.com/us/chicago-man-shot-killed-greyhound-bus-station-where-he-worked)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:58:30+00:00

A gunman fatally shot someone Monday in front of a Greyhound bus station in Chicago after the victim got out of a car, police said.

## Ron DeSantis, Charlie Crist to meet on debate stage as Florida gubernatorial race enters final two weeks
 - [https://www.foxnews.com/politics/ron-desantis-charlie-crist-debate-stage-florida-gubernatorial-race-final-two-weeks](https://www.foxnews.com/politics/ron-desantis-charlie-crist-debate-stage-florida-gubernatorial-race-final-two-weeks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:51:07+00:00

Republican Ron DeSantis and Democrat Charlie Crist will face off in their one and only debate with just two weeks left in the Florida gubernatorial race before the general election.

## Family's business left shut down after truck is stolen during Walt Disney World trip: 'Dead in the water'
 - [https://www.foxnews.com/media/family-business-left-shut-down-truck-stolen-walt-disney-world-trip-dead-water](https://www.foxnews.com/media/family-business-left-shut-down-truck-stolen-walt-disney-world-trip-dead-water)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:49:19+00:00

Cassidy and Ryan McClendon's truck remains missing since it was stolen last week at a hotel off Interstate 4 in Orange County, Florida, near Walt Disney World.

## Which states have marijuana on the 2022 ballot?
 - [https://www.foxnews.com/us/which-states-marijuana-2022-ballot](https://www.foxnews.com/us/which-states-marijuana-2022-ballot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:34:44+00:00

With the 2022 election approaching, marijuana remains a question on many state ballots. Recreational marijuana will appear on ballots across the country.

## NFL to investigate game officials appearing to ask Bucs' Mike Evans for autograph: report
 - [https://www.foxnews.com/sports/nfl-investigate-game-officials-appearing-ask-bucs-mike-evans-autograph-report](https://www.foxnews.com/sports/nfl-investigate-game-officials-appearing-ask-bucs-mike-evans-autograph-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:34:19+00:00

The NFL will review video from the Bucs-Panthers game that appears to show referees asking wide receiver Mike Evans for an autograph.

## Six more people diagnosed with Monkeypox have died
 - [https://www.foxnews.com/health/six-more-people-diagnosed-monkeypox-have-died](https://www.foxnews.com/health/six-more-people-diagnosed-monkeypox-have-died)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:32:50+00:00

Six individuals in four states, including New York, Nevada, Maryland and Illinois, have died from Monkeypox over the last week.

## Storm Roslyn in Mexico has killed at least 3 people
 - [https://www.foxnews.com/world/storm-roslyn-mexico-killed-least-3-people](https://www.foxnews.com/world/storm-roslyn-mexico-killed-least-3-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:31:17+00:00

The destruction caused by Storm Roslyn in Mexico has killed at least 3 people. Power companies are working on restoring power to their customers in the country.

## Spanish man traveling to World Cup by foot reported missing in Iran
 - [https://www.foxnews.com/world/spanish-man-traveling-world-cup-foot-reported-missing-iran](https://www.foxnews.com/world/spanish-man-traveling-world-cup-foot-reported-missing-iran)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:27:59+00:00

Santiago Sánchez, 41, was travelling to the World Cup by foot and documenting his journey on Instagram, but has not been heard from since he crossed into Iran three weeks ago.

## Judge declines New England Clean Energy Connects' request to resume construction on $1 billion power line
 - [https://www.foxnews.com/us/judge-declines-new-england-clean-energy-connects-request-to-resume-construction-1-billion-power-line](https://www.foxnews.com/us/judge-declines-new-england-clean-energy-connects-request-to-resume-construction-1-billion-power-line)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:26:15+00:00

A judge declined a request from developers to resume construction on a $1 billion power line from Canada into Maine. The judge will revisit the decision next year.

## Georgia trial will determine fate of abortion law
 - [https://www.foxnews.com/us/trial-begins-allow-georgia-enforce-abortion-law](https://www.foxnews.com/us/trial-begins-allow-georgia-enforce-abortion-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:25:51+00:00

In Georgia, a two-day trial began on that will decide whether a six-week abortion ban remains legal under the state's constitution.

## Oregon sheriff's deputy stabs male patient multiple times for trying to take his gun
 - [https://www.foxnews.com/us/oregon-sheriffs-deputy-stabs-male-patient-multiple-times-trying-take-gun](https://www.foxnews.com/us/oregon-sheriffs-deputy-stabs-male-patient-multiple-times-trying-take-gun)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:25:44+00:00

An Oregon sheriff's deputy stabbed a male patient multiple times after the man tried to take his gun. The man ignored the deputy's commands to stop.

## EXPLAINER: Dirty Bombs are devices used to create fear and panic, actually cause few deaths
 - [https://www.foxnews.com/world/explainer-dirty-bombs-devices-used-create-fear-panic-cause-few-deaths](https://www.foxnews.com/world/explainer-dirty-bombs-devices-used-create-fear-panic-cause-few-deaths)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:25:13+00:00

Russia believes Ukraine is preparing to detonate "dirty bombs" in an attempt to frame them and escalate war. Western countries believe that this claim is "transparently false."

## Davante Adams makes photographers move after incident 2 weeks ago
 - [https://www.foxnews.com/sports/davante-adams-makes-photographers-move-incident-2-weeks-ago](https://www.foxnews.com/sports/davante-adams-makes-photographers-move-incident-2-weeks-ago)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 20:24:40+00:00

Las Vegas Raiders wide receiver Davante Adams ushered photographers to the side after the team's win over the Houston Texans on Sunday due to his incident two weeks prior.

## McEnany, 'Outnumbered' mock climate activists' 'ridiculous' attempt to destroy Monet painting
 - [https://www.foxnews.com/media/mcenany-outnumbered-mock-climate-activists-ridiculous-attempt-destroy-monet-painting](https://www.foxnews.com/media/mcenany-outnumbered-mock-climate-activists-ridiculous-attempt-destroy-monet-painting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 19:37:38+00:00

Co-host Kayleigh McEnany called the stunt, which targeted Claude Monet's "Les Meules" valued at $110 million, a "desperate cry for attention."

## Nearly broke Australian sports team chooses being 'woke' over millions in sponsorship money
 - [https://www.foxnews.com/world/nearly-broke-australian-chooses-being-woke-millions-sponsorship-money](https://www.foxnews.com/world/nearly-broke-australian-chooses-being-woke-millions-sponsorship-money)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 19:35:41+00:00

The Australian National Netball team lost a $14 million sponsorship after members of the team complained about offensive comments made by the company's late founder.

## Pastor running for office welcomes plan to pardon COVID offenders after being jailed for keeping church open
 - [https://www.foxnews.com/world/pastor-running-office-welcomes-plan-pardon-covid-offenders-being-jailed-keeping-church-open](https://www.foxnews.com/world/pastor-running-office-welcomes-plan-pardon-covid-offenders-being-jailed-keeping-church-open)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 19:28:29+00:00

Pastor Artur Pawlowski, who was jailed for keeping his church open during the pandemic, praised rhetoric from the new premier of Alberta promising pardons for COVID offenders.

## New study finds dyslexia is linked to 42 genetic variants
 - [https://www.foxnews.com/health/new-study-finds-dyslexia-linked-genetic-variants](https://www.foxnews.com/health/new-study-finds-dyslexia-linked-genetic-variants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 19:23:43+00:00

Researchers from multiple educational institutions conducted a recent study that found 42 genetic variants associated with dyslexia and ADHD.

## Vladimir Putin in new video sparks cancer rumors over intravenous marks on hand
 - [https://www.foxnews.com/world/vladimir-putin-new-video-sparks-cancer-rumors-intravenous-marks-hand](https://www.foxnews.com/world/vladimir-putin-new-video-sparks-cancer-rumors-intravenous-marks-hand)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 19:20:45+00:00

A mysterious blemish on Russian President Vladimir Putin's hand while meeting with reservists has some asking if he is undergoing cancer treatment.

## Chiefs' JuJu Smith-Schuster credits team chemistry to Call of Duty session: 'Kinda just showed on the field'
 - [https://www.foxnews.com/sports/chiefs-juju-smith-schuster-credits-team-chemistry-call-duty-session-kinda-just-showed-field](https://www.foxnews.com/sports/chiefs-juju-smith-schuster-credits-team-chemistry-call-duty-session-kinda-just-showed-field)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 19:16:43+00:00

Kansas City Chiefs wideout JuJu Smith-Schuster says a Friday night game session with Patrick Mahomes, Travis Kelce and Marquez Valdes-Scantling helped in Sunday's win over the 49ers.

## George Strait announces stadium tour with Chris Stapleton and Little Big Town in 2023
 - [https://www.foxnews.com/entertainment/george-strait-announces-stadium-tour-chris-stapleton-little-big-town-2023](https://www.foxnews.com/entertainment/george-strait-announces-stadium-tour-chris-stapleton-little-big-town-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 19:09:13+00:00

George Strait has announced that he is hitting the road in 2023 for a six-stop stadium tour with Chris Stapleton and Little Big Town.

## Former Philadelphia police sergeant acquitted of lying to FBI regarding drug raid
 - [https://www.foxnews.com/us/former-philadelphia-police-sergeant-acquitted-lying-fbi-drug-raid](https://www.foxnews.com/us/former-philadelphia-police-sergeant-acquitted-lying-fbi-drug-raid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 19:03:57+00:00

A former Philadelphia police sergeant was acquitted of lying to the FBI. The sergeant claimed that the prosecutors never gave him an opportunity to clarify the situation.

## Kansas undersheriff heads to trial for 2017 fatal beanbag shooting
 - [https://www.foxnews.com/us/kansas-undersheriff-heads-trial-2017-fatal-beanbag-shooting](https://www.foxnews.com/us/kansas-undersheriff-heads-trial-2017-fatal-beanbag-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 19:01:13+00:00

Virgil "Dusty" Brewer was working as a Barber County Sheriff’s Office undersheriff on Oct. 6, 2017, when he allegedly shot 42-year-old Steven Myers in the chest.

## Wynonna Judd talks about her 'healing' experience continuing to tour after Naomi Judd's death
 - [https://www.foxnews.com/entertainment/wynonna-judd-talks-healing-experience-continuing-tour-naomi-judds-death](https://www.foxnews.com/entertainment/wynonna-judd-talks-healing-experience-continuing-tour-naomi-judds-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 19:00:26+00:00

Wynonna Judd spoke in a recent interview to her experience going on tour following her mother, Naomi Judd's death, noting that it has been a "healing" experience.

## Florida 10-year-old girl escapes attempted kidnapper twice in two days, and there's video, police say
 - [https://www.foxnews.com/us/florida-10-year-old-girl-escapes-attempted-kidnapper-twice-two-days-theres-video-police-say](https://www.foxnews.com/us/florida-10-year-old-girl-escapes-attempted-kidnapper-twice-two-days-theres-video-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 18:51:17+00:00

A 10-year-old Florida girl escaped two kidnapping attempts last week according to Fort Lauderdale police, and part of her flight was caught on home security video.

## Biden admin spending $1M to research how ‘misinformation’ affects confidence in vaccines
 - [https://www.foxnews.com/politics/biden-admin-spending-1m-research-misinformation-affects-confidence-vaccines](https://www.foxnews.com/politics/biden-admin-spending-1m-research-misinformation-affects-confidence-vaccines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 18:29:36+00:00

The Department of Health and Human Services will give $1 million to a group to develop a "vaccine misinformation" tool that predicts viral social media posts.

## Decline of endangered whales species slowed but species still losing breeding females too quickly
 - [https://www.foxnews.com/great-outdoors/decline-endangered-whales-species-slowed-last-year-scientists-warn-species-losing-breeding-females-quickly](https://www.foxnews.com/great-outdoors/decline-endangered-whales-species-slowed-last-year-scientists-warn-species-losing-breeding-females-quickly)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 18:23:40+00:00

Population decline of North Atlantic right whales slowed last year. However, scientists warn that the species is still threatened due to the rapid loss of its breeding females.

## Olivia Wilde's dog Gordy was rehomed, rescue clarifies
 - [https://www.foxnews.com/entertainment/olivia-wildes-dog-gordy-rehomed-rescue-clarifies](https://www.foxnews.com/entertainment/olivia-wildes-dog-gordy-rehomed-rescue-clarifies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 18:23:15+00:00

The animal rescue that Olivia Wilde adopted her dog from set the record straight on how the pup ended up with a new owner. Wilde was accused of abandoning the dog by her former nanny.

## Brazil election: What to know about the high-stakes race
 - [https://www.foxnews.com/world/brazil-election-what-know-about-high-stakes-race](https://www.foxnews.com/world/brazil-election-what-know-about-high-stakes-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 18:22:22+00:00

As Brazil's Presidential election is days away, the incumbent President of Brazil Jair Bolsonaro heads up against socialist former President Luiz Inacio Lula da Silva.

## Maryland man killed in broad daylight outside of Nationals Park in Washington, DC
 - [https://www.foxnews.com/us/maryland-man-killed-broad-daylight-outside-nationals-park-washington-dc](https://www.foxnews.com/us/maryland-man-killed-broad-daylight-outside-nationals-park-washington-dc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 18:18:36+00:00

Police are now offering a $25,000 reward for information following the killing of a 31-year-old Maryland man outside of Nationals Park in Washington, D.C. on Sunday.

## Hispanic voters prefer DeSantis, including some Dems: poll
 - [https://www.foxnews.com/politics/hispanic-voters-prefer-desantis-including-some-dems-poll](https://www.foxnews.com/politics/hispanic-voters-prefer-desantis-including-some-dems-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 18:12:22+00:00

A new poll of Hispanic voters in Florida from Telemundo/ LX News showed that a majority would vote for GOP Gov. Ron DeSantis, including a number of registered Democrats.

## Ted Cruz triggers liberals on Twitter for attending New York Yankees' game, compared to a rat
 - [https://www.foxnews.com/media/ted-cruz-triggers-liberals-twitter-attending-new-york-yankees-game-compared-rat](https://www.foxnews.com/media/ted-cruz-triggers-liberals-twitter-attending-new-york-yankees-game-compared-rat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 18:12:08+00:00

Some liberals cheered Sen. Ted Cruz, R-Texas, being heckled at a New York Yankees' game. Cruz was in New York for an upcoming appearance on "The View."

## Biden, Dems nap through border crisis: These statistics should rouse them and terrify all Americans
 - [https://www.foxnews.com/opinion/biden-dems-nap-through-border-crisis-statistics-should-rouse-them-terrify-all-americans](https://www.foxnews.com/opinion/biden-dems-nap-through-border-crisis-statistics-should-rouse-them-terrify-all-americans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 18:00:32+00:00

Democrats are napping through the crisis at the southern border. But the numbers – apprehensions and cartel profits from human smuggling and drug trafficking – should wake them up.

## Jeb Bush says plunging US math, reading scores should be 'call to arms'
 - [https://www.foxnews.com/media/jeb-bush-says-plunging-us-math-reading-scores-call-arms](https://www.foxnews.com/media/jeb-bush-says-plunging-us-math-reading-scores-call-arms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:59:10+00:00

Former Florida Gov. Jeb Bush and a mother of two who pulled her children out of public school react to the test score report following the coronavirus pandemic.

## 15-year-old boy collapses, dies at Liverpool restaurant: report
 - [https://www.foxnews.com/world/15-year-old-boy-collapses-dies-at-liverpool-restaurant-report](https://www.foxnews.com/world/15-year-old-boy-collapses-dies-at-liverpool-restaurant-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:33:19+00:00

Police say a 15-year-old boy collapsed at a restaurant in Liverpool while out with family and friends, and later died at a hospital. The death is not considered suspicious.

## Top House Intel Republican rejects Dem claims that the GOP opposes Ukraine aid
 - [https://www.foxnews.com/politics/top-house-intel-republican-rejects-dem-claims-gop-opposes-ukraine-aid](https://www.foxnews.com/politics/top-house-intel-republican-rejects-dem-claims-gop-opposes-ukraine-aid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:24:19+00:00

The top Republican on the House Intelligence Committee dismissed concerns about future GOP support for Ukraine, saying lawmakers were committed to aid and accountability.

## Harmony Montgomery case: New Hampshire announces murder charge against missing girl's dad
 - [https://www.foxnews.com/us/harmony-montgomery-case-new-hampshires-announces-murder-charge-against-missing-girls-dad](https://www.foxnews.com/us/harmony-montgomery-case-new-hampshires-announces-murder-charge-against-missing-girls-dad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:21:23+00:00

New Hampshire dad Adam Montgomery has been charged with second-degree murder in the death of his missing daughter, who was last seen in late November 2019.

## Aaron Judge steamrolls into uncertain offseason as Yankees lose in ALCS
 - [https://www.foxnews.com/sports/yankees-aaron-judge-steamrolls-uncertain-offseason-yankees-lose-alcs](https://www.foxnews.com/sports/yankees-aaron-judge-steamrolls-uncertain-offseason-yankees-lose-alcs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:15:27+00:00

New York Yankees slugger Aaron Judge said Sunday he is going to take some time to get his bearings as he heads into free agency later this year.

## Yankees' Aaron Judge steamrolls into uncertain offseason as Yankees lose in ACLS
 - [https://www.foxnews.com/sports/yankees-aaron-judge-steamrolls-into-uncertain-offseason-as-yankees-lose-in-acls](https://www.foxnews.com/sports/yankees-aaron-judge-steamrolls-into-uncertain-offseason-as-yankees-lose-in-acls)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:15:27+00:00

New York Yankees slugger Aaron Judge said Sunday he is going to take some time to get his bearings as he heads into free agency later this year.

## Just Stop Oil activists smash cake on King Charles III waxwork at Madam Tussauds
 - [https://www.foxnews.com/world/just-stop-oil-activists-smash-cake-king-charles-iii-waxwork-madam-tussauds](https://www.foxnews.com/world/just-stop-oil-activists-smash-cake-king-charles-iii-waxwork-madam-tussauds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:10:02+00:00

Just Stop Oil activists "cake the King" at Madam Tussauds museum in London. The group released video of the cake smash online ahead of a climate change conference.

## NM trial may be delayed for men charged with kidnapping, providing materials to terrorists
 - [https://www.foxnews.com/us/nm-trial-may-be-delayed-for-men-charged-with-kidnapping-providing-materials-to-terrorists](https://www.foxnews.com/us/nm-trial-may-be-delayed-for-men-charged-with-kidnapping-providing-materials-to-terrorists)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:09:39+00:00

Defense lawyers are once again attempting to delay the trial of five men who were allegedly conspiring against the U.S. government and providing weapons to terrorists.

## Mike Rowe sounds alarm about men leaving workforce: 'The most chilling metric of all'
 - [https://www.foxnews.com/media/mike-rowe-sounds-alarm-men-leaving-workforce-chilling-metric](https://www.foxnews.com/media/mike-rowe-sounds-alarm-men-leaving-workforce-chilling-metric)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:04:41+00:00

FOX Business host Mike Rowe detailed his concern around the labor force participation rate, citing an 'unprecedented' number of able-bodied men not seeking work

## Philadelphia Phillies head to the World Series with 'Dancing on My Own' as their victory anthem
 - [https://www.foxnews.com/sports/philadelphia-phillies-head-world-series-dancing-on-my-own-victory-anthem](https://www.foxnews.com/sports/philadelphia-phillies-head-world-series-dancing-on-my-own-victory-anthem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:04:41+00:00

The Philadelphia Phillies have been playing the song "Dancing on My Own" through the baseball season. The song has become a victory anthem for the team as they head to the World Series.

## NASA team to study UFOs, release report to public in 2023
 - [https://www.foxnews.com/science/nasa-team-study-ufos-release-report-public-2023](https://www.foxnews.com/science/nasa-team-study-ufos-release-report-public-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:04:09+00:00

NASA announced a 16-member team will study "unidentified aerial phenomena" — sometimes known as UFOs — to shed light on their origins and release its findings to the public in mid-2023.

## Panthers' quarterback situation gets complicated after Walker leads Carolina to victory
 - [https://www.foxnews.com/sports/panthers-quarterback-situation-gets-complicated-pj-walker-leads-carolina-victory](https://www.foxnews.com/sports/panthers-quarterback-situation-gets-complicated-pj-walker-leads-carolina-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 17:01:58+00:00

P. J. Walker led the Carolina Panthers to victory on Sunday after holding the Tampa Bay Buccaneers to just three points.

## US Marshal Service offering reward for information leading to arrest of escaped inmate
 - [https://www.foxnews.com/us/us-marshal-offering-reward-information-leading-arrest-escaped-inmate](https://www.foxnews.com/us/us-marshal-offering-reward-information-leading-arrest-escaped-inmate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 16:35:32+00:00

The U.S. Marshals Service is offering a reward for information to help find an escaped Pimo County jail inmate. The inmate slipped out of a jail door on Thursday afternoon.

## Pat McAfee criticizes Nick Saban for playing wide receiver despite controversy: 'It’s a terrible situation'
 - [https://www.foxnews.com/sports/pat-mcafee-criticizes-nick-saban-playing-wide-receiver-despite-controversy-terrible-situation](https://www.foxnews.com/sports/pat-mcafee-criticizes-nick-saban-playing-wide-receiver-despite-controversy-terrible-situation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 16:22:04+00:00

Pat McAfee has sharp criticism of Alabama head coach Nick Saban over the decision to play Jermaine Burton after he was accused of striking a female fan last weekend.

## Kentucky emissions reduction program to fund new school buses
 - [https://www.foxnews.com/us/kentucky-emissions-reduction-program-fund-new-school-buses](https://www.foxnews.com/us/kentucky-emissions-reduction-program-fund-new-school-buses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 16:13:38+00:00

Public and private schools that own school buses in Kentucky can now apply for funding toward new replacements. The grant program is designed to reduce diesel emissions.

## Wyoming hunter accidentally shoots himself while fighting grizzly bear
 - [https://www.foxnews.com/us/wyoming-hunter-accidentally-shoots-himself-fighting-grizzly-bear](https://www.foxnews.com/us/wyoming-hunter-accidentally-shoots-himself-fighting-grizzly-bear)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 16:10:18+00:00

A Wyoming man accidentally shot himself Friday when he and his son were trying to escape a grizzly bear attack in the remote wilderness of Wyoming.

## California second-grade teacher hid missing boy, 15, for two years, police say
 - [https://www.foxnews.com/us/california-second-grade-teacher-hid-missing-boy-15-two-years-police-say](https://www.foxnews.com/us/california-second-grade-teacher-hid-missing-boy-15-two-years-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 16:10:03+00:00

A California teacher was arrested for harboring a teenager who was reported missing in June 2020, after he suddenly returned home nearly two years later, police said.

## Harvard students reveal their political party preferences. It’s not what you may expect
 - [https://www.foxnews.com/politics/harvard-students-reveal-political-party-preferences-expect](https://www.foxnews.com/politics/harvard-students-reveal-political-party-preferences-expect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 16:09:52+00:00

Ahead of the midterm elections, Harvard University students shared whether they identify as Republican or Democrat and cited policy positions that sway decisions.

## Biden falsely claims he 'passed' his student loan handout 'by a vote or two' during White House youth forum
 - [https://www.foxnews.com/politics/biden-falsely-claims-he-passed-student-loan-handout-vote-two-white-house-youth-forum](https://www.foxnews.com/politics/biden-falsely-claims-he-passed-student-loan-handout-vote-two-white-house-youth-forum)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 16:03:48+00:00

President Biden made a series of gaffes in a Sunday night NowThis youth forum while responding to questions about gun control, abortion access and his student debt relief plan.

## California school broadcasts sexually explicit books, some covering 'pedophiles,' kink and pornographic images
 - [https://www.foxnews.com/media/california-school-broadcasts-sexually-explicit-books-covering-pedophiles-kink-pornographic-images](https://www.foxnews.com/media/california-school-broadcasts-sexually-explicit-books-covering-pedophiles-kink-pornographic-images)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 16:00:58+00:00

A California public school library contained books with pornographic content, including titles such as 'Gender Queer, 'This Book is Gay' and 'Beyond Magenta.'

## Strategic Petroleum Reserve is for emergencies, not Biden’s politics. I know. I’ve had to use it.
 - [https://www.foxnews.com/opinion/strategic-petroleum-reserve-emergencies-bidens-politics](https://www.foxnews.com/opinion/strategic-petroleum-reserve-emergencies-bidens-politics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 16:00:51+00:00

Strategic Petroleum Reserve is for emergencies and presidents used it just three times before Biden made it a political tool. I know. I’ve had to use it.

## Phoenix house party shooting leaves 1 dead, 7 injured
 - [https://www.foxnews.com/us/phoenix-house-party-shooting-leaves-1-dead-7-injured](https://www.foxnews.com/us/phoenix-house-party-shooting-leaves-1-dead-7-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 16:00:25+00:00

A house party shooting in southwest Phoenix left one person dead and seven others injured. Arizona police are still searching for the shooter.

## US math, reading test scores plunge for students across country following COVID-19 pandemic
 - [https://www.foxnews.com/us/us-math-reading-test-scores-plunge-students-across-country-following-covid-19-pandemic](https://www.foxnews.com/us/us-math-reading-test-scores-plunge-students-across-country-following-covid-19-pandemic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 15:33:26+00:00

National test scores show that fourth and eighth grade students across the U.S. have declined in both mathematics and reading since the COVID-19 pandemic began.

## Commanders' Tanya Snyder faces scrutiny after 'Redskins' name drop
 - [https://www.foxnews.com/sports/commanders-tanya-snyder-faces-scrutiny-redskins-name-drop](https://www.foxnews.com/sports/commanders-tanya-snyder-faces-scrutiny-redskins-name-drop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 15:31:13+00:00

Washington Commanders co-CEO Tanya Snyder was criticized Sunday for using the "Redskins" moniker during a rally for fans at the stadium.

## 'Top Gun' star Miles Teller celebrates as Phillies head to the World Series
 - [https://www.foxnews.com/entertainment/top-gun-star-miles-teller-celebrates-phillies-head-world-series](https://www.foxnews.com/entertainment/top-gun-star-miles-teller-celebrates-phillies-head-world-series)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 15:26:46+00:00

Miles Teller joined Phillies fans celebrating the team's first World Series appearance since 2009 on Sunday night. Teller was photographed and videod cheering the team on in the stands.

## Matthew Perry reveals the surprising reason he dumped Julia Roberts
 - [https://www.foxnews.com/entertainment/matthew-perry-reveals-surprising-reason-dumped-julia-roberts](https://www.foxnews.com/entertainment/matthew-perry-reveals-surprising-reason-dumped-julia-roberts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 15:25:45+00:00

Matthew Perry revealed the heartbreaking reason why he dumped actress Julia Roberts after the two dated for a few months. When she appeared on "Friends" in season two, they were already a couple.

## Maryland couple ‘unable to sleep’ after strangers moved into home they are buying
 - [https://www.foxnews.com/us/maryland-couple-unable-sleep-strangers-moved-home-buying](https://www.foxnews.com/us/maryland-couple-unable-sleep-strangers-moved-home-buying)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 15:25:06+00:00

Melea King, a Maryland realtor representing a couple who reportedly spotted squatters in the home they have purchased, says they are "very angry" and "very upset."

## Indiana hunters find human remains in Lake County marsh
 - [https://www.foxnews.com/us/indiana-hunters-find-human-remains-lake-county-marsh](https://www.foxnews.com/us/indiana-hunters-find-human-remains-lake-county-marsh)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 15:24:56+00:00

Bird hunters found human remains in an Indiana marsh on Saturday morning. Griffith police and state officials are investigating the case.

## ‘Harry Potter’ star Daniel Radcliffe says he ‘wouldn’t want fame’ for his kids: Avoid ‘at all costs’
 - [https://www.foxnews.com/entertainment/harry-potter-star-daniel-radcliffe-wouldnt-want-fame-for-kids](https://www.foxnews.com/entertainment/harry-potter-star-daniel-radcliffe-wouldnt-want-fame-for-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 15:17:22+00:00

The "Harry Potter" film franchise ended its run in 2011. Its star, Daniel Radcliffe, has a reported net worth of $110 million with a $15 million salary.

## Three New Yorkers die of fentanyl overdose after ordering cocaine from drug delivery service
 - [https://www.foxnews.com/us/three-new-yorkers-die-fentanyl-overdose-after-ordering-cocaine-from-drug-delivery-service](https://www.foxnews.com/us/three-new-yorkers-die-fentanyl-overdose-after-ordering-cocaine-from-drug-delivery-service)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 15:14:57+00:00

Three New Yorkers attempted to order cocaine from a drug delivery service but later died of a fentanyl overdose when their batch was laced with the deadly drug.

## At least 3 killed in St. Louis high school shooting, including suspect, former student, who was killed
 - [https://www.foxnews.com/us/at-least-3-killed-st-louis-high-school-shooting-suspect-killed-security](https://www.foxnews.com/us/at-least-3-killed-st-louis-high-school-shooting-suspect-killed-security)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 15:13:48+00:00

At least two students were shot inside a St. Louis public high school on Monday, school administrators announced. The two students are being transported to the hospital.

## At least 6 rushed to hospital with various injuries following St. Louis high school shooting
 - [https://www.foxnews.com/us/at-least-6-rushed-hospital-various-injuries-following-st-louis-high-school-shooting](https://www.foxnews.com/us/at-least-6-rushed-hospital-various-injuries-following-st-louis-high-school-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 15:13:48+00:00

At least two students were shot inside a St. Louis public high school on Monday, school administrators announced. The two students are being transported to the hospital.

## 'Crumbl Cookies' franchise owner reveals why Americans are spending $5 on a single cookie
 - [https://www.foxnews.com/lifestyle/crumbl-cookies-franchise-owner-reveals-americans-spending-single-cookie](https://www.foxnews.com/lifestyle/crumbl-cookies-franchise-owner-reveals-americans-spending-single-cookie)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 15:13:03+00:00

Americans are spending $5 on a single cookie — certain single cookies, that is. A Crumbl Cookies franchise owner joined "Fox & Friends" on Oct. 24, 2022, to discuss the snack and why people love it.

## Ex-Minneapolis police officer Kueng pleads guilty in George Floyd killing
 - [https://www.foxnews.com/us/ex-minneapolis-police-officer-kueng-pleads-guilty-george-floyd-killing](https://www.foxnews.com/us/ex-minneapolis-police-officer-kueng-pleads-guilty-george-floyd-killing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 14:38:01+00:00

J. Alexander Kueng, a former Minneapolis police officer, pleaded guilty on Monday to aiding and abetting second-degree manslaughter in the killing of George Floyd.

## Fernando Alonso, Lance Stroll involved in scary crash at F1 race
 - [https://www.foxnews.com/sports/fernando-alonso-lance-stroll-involved-scary-crash-f1-race](https://www.foxnews.com/sports/fernando-alonso-lance-stroll-involved-scary-crash-f1-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 14:30:08+00:00

Fernando Alonso and Lance Stroll got caught up in a crash during the U.S. Grand Prix in Austin, Texas, on Sunday. Alonso managed to finish the race.

## Kari Lake torches Democrat opponent for refusing to debate: 'Basement Hobbs' taking page from Biden playbook
 - [https://www.foxnews.com/media/kari-lake-torches-democrat-opponent-refusing-debate-basement-hobbs-taking-page-biden-playbook](https://www.foxnews.com/media/kari-lake-torches-democrat-opponent-refusing-debate-basement-hobbs-taking-page-biden-playbook)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 14:25:33+00:00

Kari Lake joined "Fox & Friends" to discuss Katie Hobbs' refusal to debate and why her campaign has gained momentum by running on "commonsense issues."

## Zelenskyy says Russia is 'probably' paying for Iranian drones with nuclear research assistance
 - [https://www.foxnews.com/world/zelenskyy-says-russia-probably-paying-iranian-drones-nuclear-research-assistance](https://www.foxnews.com/world/zelenskyy-says-russia-probably-paying-iranian-drones-nuclear-research-assistance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 14:20:40+00:00

Iran is training Russian troops to operate Iranian-made drones in Ukraine as fears grow that Russia may launch an offensive against Ukraine out of Belarus.

## The Chevrolet Silverado EV will be a 754 horsepower muscle truck
 - [https://www.foxnews.com/auto/chevrolet-silverado-ev-horsepower-muscle-truck](https://www.foxnews.com/auto/chevrolet-silverado-ev-horsepower-muscle-truck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 14:20:29+00:00

Chevrolet has upgraded the power rating for the 2024 Silverado EV pickup to 754 horsepower and 785 lb-ft of torque ahead of its debut next year.

## Matt Yglesias says Trump’s policies are ‘not that extreme’ and ‘much more moderate’ than Romney’s
 - [https://www.foxnews.com/media/matt-yglesias-trumps-policies-extreme-much-more-moderate-than-romneys](https://www.foxnews.com/media/matt-yglesias-trumps-policies-extreme-much-more-moderate-than-romneys)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 14:10:03+00:00

Liberal political journalist Matthew Yglesias said Donald Trump's policy views were "just not that extreme," rejecting a popular media narrative.

## Max Verstappen takes home US Grand Prix title in record-tying victory
 - [https://www.foxnews.com/sports/max-verstappen-takes-home-us-grand-prix-title-record-tying-victory](https://www.foxnews.com/sports/max-verstappen-takes-home-us-grand-prix-title-record-tying-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:57:20+00:00

Max Verstappen took home his 13th Formula One victory this season crossing the finish line in first place at the U.S. Grand Prix in Austin on Sunday.

## NYPD on track to lose record number of officers as Hochul, Adams calls for more cops in subways
 - [https://www.foxnews.com/media/nypd-track-lose-record-number-officers-hochul-adams-calls-cops-subways](https://www.foxnews.com/media/nypd-track-lose-record-number-officers-hochul-adams-calls-cops-subways)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:54:00+00:00

Joe Imperatrice said an increased police presence won't quell the crime crisis unless criminals are also kept behind bars and held accountable for their actions.

## AP Top 25 poll: LSU back in the rankings after upset win, Georgia stays at No. 1
 - [https://www.foxnews.com/sports/ap-top-25-poll-lsu-back-rankings-upset-win-georgia-stays](https://www.foxnews.com/sports/ap-top-25-poll-lsu-back-rankings-upset-win-georgia-stays)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:47:05+00:00

Georgia stayed on top of the Associated Press Top 25 poll for the third straight week while Tennessee stayed at No. 3. LSU re-entered the rankings at No. 18.

## Jury selection begins in Manhattan DA trial against Trump Organization
 - [https://www.foxnews.com/politics/jury-selection-begins-manhattan-da-trial-trump-organization](https://www.foxnews.com/politics/jury-selection-begins-manhattan-da-trial-trump-organization)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:37:34+00:00

Jury selection begins Monday in the criminal case against the Trump Organization, which is accused of tax fraud and other offenses by the Manhattan DA's office.

## Chicago bloody weekend sees over 50 shot, including 14-year-old boy on playground, 5 at drag racing incident
 - [https://www.foxnews.com/us/chicago-bloody-weekend-sees-over-50-shot-including-14-year-old-boy-playground-5-drag-racing-incident](https://www.foxnews.com/us/chicago-bloody-weekend-sees-over-50-shot-including-14-year-old-boy-playground-5-drag-racing-incident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:35:47+00:00

Chicago police said that over the weekend there were 51 people shot, 10 fatally, including three men with gang affiliations during a street racing takeover incident.

## Why did Christina change her last name to Haack? The 'Flip or Flop' star has used four different last names
 - [https://www.foxnews.com/entertainment/christina-change-last-name-haack-flip-flop-star-four-different-last-names](https://www.foxnews.com/entertainment/christina-change-last-name-haack-flip-flop-star-four-different-last-names)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:31:50+00:00

Christina Hall rose to fame from the success of the HGTV show "Flip or Flop," which she starred in with her ex-husband Tarek El Moussa. She is now married to realtor Josh Hall.

## Penny Mordaunt drops out of UK prime minister race, handing Rishi Sunak the win
 - [https://www.foxnews.com/world/penny-mordaunt-drops-uk-prime-minister-race-handing-rishi-sunak-win](https://www.foxnews.com/world/penny-mordaunt-drops-uk-prime-minister-race-handing-rishi-sunak-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:26:08+00:00

Former Finance Minister Rishi Sunak will be the U.K.'s next prime minister after former defense minister Penny Mordaunt dropped out of the race Monday.

## Rishi Sunak set to be next UK prime minister after Penny Mordaunt drops out of race
 - [https://www.foxnews.com/world/rishi-sunak-set-next-uk-prime-minister-penny-mordaunt-drops-race](https://www.foxnews.com/world/rishi-sunak-set-next-uk-prime-minister-penny-mordaunt-drops-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:26:08+00:00

Former Finance Minister Rishi Sunak will be the U.K.'s next prime minister after former defense minister Penny Mordaunt dropped out of the race Monday.

## Reddit community responds to 'best things about America' query: 'God bless Teddy Roosevelt'
 - [https://www.foxnews.com/lifestyle/reddit-community-responds-best-things-america-query-god-bless-teddy-roosevelt](https://www.foxnews.com/lifestyle/reddit-community-responds-best-things-america-query-god-bless-teddy-roosevelt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:23:04+00:00

Commenters on the "Ask Reddit" social media site shared compelling answers to the question, "What is a good thing" about America? Here are some top replies — including libraries, parks and more.

## Dallas hospital shooter has lengthy criminal history: police
 - [https://www.foxnews.com/us/dallas-hospital-shooter-lengthy-criminal-history-police](https://www.foxnews.com/us/dallas-hospital-shooter-lengthy-criminal-history-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:21:27+00:00

New details have emerged regarding the Dallas hospital shooting suspect and his lengthy criminal history. Nestor Oswaldo Hernandez had an active ankle monitor at the time of the shooting.

## Dallas hospital shooting suspect has lengthy criminal history: police
 - [https://www.foxnews.com/us/dallas-hospital-shooting-suspect-lengthy-criminal-history-police](https://www.foxnews.com/us/dallas-hospital-shooting-suspect-lengthy-criminal-history-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:21:27+00:00

New details have emerged regarding the Dallas hospital shooting suspect and his lengthy criminal history. Nestor Oswaldo Hernandez had an active ankle monitor at the time of the shooting.

## Alanis Morissette praised by Halsey for her empowering anthems, as the two perform together at Hollywood Bowl
 - [https://www.foxnews.com/entertainment/alanis-morissette-praised-halsey-empowering-anthems-two-perform-together-hollywood-bowl](https://www.foxnews.com/entertainment/alanis-morissette-praised-halsey-empowering-anthems-two-perform-together-hollywood-bowl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:11:41+00:00

Alanis Morissette was thanked by singer Halsey during a concert at the Hollywood Bowl for her inspiring 'f--- you' anthems that helped Halsey achieve their own success.

## Tom Brady sums up Bucs' brutal season through seven games: 'No one feels good about where we’re at'
 - [https://www.foxnews.com/sports/tom-brady-sums-up-bucs-brutal-season-seven-games-no-one-feels-good](https://www.foxnews.com/sports/tom-brady-sums-up-bucs-brutal-season-seven-games-no-one-feels-good)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 13:06:58+00:00

Tom Brady and the Tampa Bay Buccaneers fell to 3-4 after a brutal loss to the Carolina Panthers on Sunday. He summed up his team's play through the first seven games afterward.

## Oxford school shooting: Ethan Crumbley pleads guilty to charges
 - [https://www.foxnews.com/us/oxford-school-shooting-ethan-crumbley-pleads-guilty-charges](https://www.foxnews.com/us/oxford-school-shooting-ethan-crumbley-pleads-guilty-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:54:43+00:00

Ethan Crumbley, the Michigan teenager accused of killing four students in a shooting at Oxford High School outside of Detroit in 2021, has pleaded guilty to all charges.

## Ohio's lottery numbers for Sunday, Oct. 23
 - [https://www.foxnews.com/us/ohios-lottery-numbers-sunday-oct-23](https://www.foxnews.com/us/ohios-lottery-numbers-sunday-oct-23)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:48:12+00:00

The Mega Million's estimated jackpot is $45,000,000. The Powerball estimated jackpot is $610,000,000. The Lucky For Life numbers for Sunday, Oct. 23 are 33-42-44-47-48.

## New Jersey's lottery numbers for Sunday, Oct. 23
 - [https://www.foxnews.com/us/new-jerseys-lottery-numbers-sunday-oct-23](https://www.foxnews.com/us/new-jerseys-lottery-numbers-sunday-oct-23)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:45:32+00:00

The Mega Million's estimated jackpot is $45,000,000. The Powerball estimated jackpot is $610,000,000. The Cash4Life numbers for Sunday, Oct. 23 are 07-18-24-32-35.

## Dolphins' Tua Tagovailoa talks parents' concerns for his health following scary concussion
 - [https://www.foxnews.com/sports/dolphins-tua-tagovailoa-talks-parents-concerns-health-scary-concussion](https://www.foxnews.com/sports/dolphins-tua-tagovailoa-talks-parents-concerns-health-scary-concussion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:42:31+00:00

Tua Tagovailoa spoke to NBC Sports before the Miami Dolphins' game on Sunday night against the Pittsburgh Steelers. He was playing his first game since the concussion.

## Florida's lottery numbers for Sunday, Oct. 23
 - [https://www.foxnews.com/us/floridas-lottery-numbers-sunday-oct-23](https://www.foxnews.com/us/floridas-lottery-numbers-sunday-oct-23)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:41:02+00:00

The Mega Million's estimated jackpot is $45,000,000. The Powerball estimated jackpot is $610,000,000. The Cash4Life numbers for Sunday, Oct. 23 are 07-18-24-32-35.

## Texas's lottery numbers for Sunday, Oct. 23
 - [https://www.foxnews.com/us/texass-lottery-numbers-sunday-oct-23](https://www.foxnews.com/us/texass-lottery-numbers-sunday-oct-23)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:39:48+00:00

The Mega Million's estimated jackpot is $45,000,000. The Powerball estimated jackpot is $610,000,000. The Cash 5 numbers for Sunday, Oct. 23 are 06-07-19-20-22.

## Newt Gingrich expecting GOP midterm election 'tsunami', says it could be biggest Republican win since 1920
 - [https://www.foxnews.com/media/newt-gingrich-expecting-gop-midterm-election-tsunami-biggest-republican-win-since-1920](https://www.foxnews.com/media/newt-gingrich-expecting-gop-midterm-election-tsunami-biggest-republican-win-since-1920)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:18:08+00:00

Newt Gingrich joined "Fox & Friends" to discuss why he is predicting the "biggest Republican win since 1920" in the midterm elections.

## Gwen Stefani fan credits singer for helping her survive New York City subway attack
 - [https://www.foxnews.com/entertainment/gwen-stefani-fan-credits-singer-helping-survive-new-york-city-subway-attack](https://www.foxnews.com/entertainment/gwen-stefani-fan-credits-singer-helping-survive-new-york-city-subway-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:17:10+00:00

A 22-year-old Brooklyn resident said that she was inspired by Gwen Stefani when she pulled herself up from New York City subway tracks after a man assaulted her and pushed her down.

## Colorado businessman set for retrial over border wall fund
 - [https://www.foxnews.com/us/colorado-businessman-set-retrial-border-wall-fund](https://www.foxnews.com/us/colorado-businessman-set-retrial-border-wall-fund)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:15:09+00:00

Timothy Shea, a Colorado businessman, is back in New York to face a retrial on charges that he absconded with $25 million in an online crowdfunding campaign.

## NYC subway shove victim's mother says son ‘completely traumatized,’ ‘can’t move’
 - [https://www.foxnews.com/us/nyc-subway-shove-victims-mother-says-son-completely-traumatized-cant-move](https://www.foxnews.com/us/nyc-subway-shove-victims-mother-says-son-completely-traumatized-cant-move)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:09:14+00:00

The mother of the man seen on video being shoved onto the tracks at a subway station in Brooklyn last Friday is now speaking out in the wake of the brutal attack.

## Rishi Sunak poised to win UK prime minister spot after Boris Johnson drops
 - [https://www.foxnews.com/world/rishi-sunak-poised-win-uk-prime-minister-spot-boris-johnson-drops](https://www.foxnews.com/world/rishi-sunak-poised-win-uk-prime-minister-spot-boris-johnson-drops)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:05:43+00:00

Former finance minister Rishi Sunak is widely expected to secure the U.K. prime minister spot after Boris Johnson dropped out of the race. Sunak is running on economic caution.

## Central US faces heavy rain, severe weather as storm system moves in
 - [https://www.foxnews.com/us/central-us-faces-heavy-rain-severe-weather-storm-system-moves](https://www.foxnews.com/us/central-us-faces-heavy-rain-severe-weather-storm-system-moves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 12:01:02+00:00

Severe weather set to impact the central U.S. Monday will bring risks of heavy rain, strong winds and isolated tornadoes from the Southern Plains to the Tennessee Valley.

## Pelosi avoids question on what her future holds as Dems hope to keep House control
 - [https://www.foxnews.com/politics/pelosi-avoids-question-what-future-holds-dems-hope-keep-house-control](https://www.foxnews.com/politics/pelosi-avoids-question-what-future-holds-dems-hope-keep-house-control)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 11:59:06+00:00

House Speaker Nancy Pelosi would not say what her future could hold after the midterm elections, dodging questions about whether she will remain in Democratic leadership.

## Giants' Kayvon Thibodeaux delivers message to critics: 'F--- 'em'
 - [https://www.foxnews.com/sports/giants-kayvon-thibodeaux-delivers-message-critics](https://www.foxnews.com/sports/giants-kayvon-thibodeaux-delivers-message-critics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 11:50:01+00:00

New York Giants rookie Kayvon Thibodeaux had a message for the doubters and critics as the team moved to 6-1 with a win over the Jacksonville Jaguars.

## The million-dollar Ford Mustang: Muscle car raises a fortune for hurricane relief
 - [https://www.foxnews.com/auto/million-dollar-ford-mustang-muscle-car-hurricane](https://www.foxnews.com/auto/million-dollar-ford-mustang-muscle-car-hurricane)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 11:42:42+00:00

A 2022 Ford Mustang Shelby GT500 helped raise over $1 million at the Barrett-Jackson event in Houston for charities providing relief to Hurricane Ian victims.

## Yankees make dubious history with latest ALCS loss to Astros
 - [https://www.foxnews.com/sports/yankees-make-dubious-history-latest-alcs-loss-astros](https://www.foxnews.com/sports/yankees-make-dubious-history-latest-alcs-loss-astros)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 11:19:28+00:00

The New York Yankees are again without a World Series appearance or an American League pennant following their sweeping loss to the Houston Astros.

## President Biden admits that it's 'totally legitimate' to question his age and health
 - [https://www.foxnews.com/media/president-biden-admits-totally-legitimate-question-age-health](https://www.foxnews.com/media/president-biden-admits-totally-legitimate-question-age-health)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 11:00:23+00:00

President Biden admitted on MSNBC’s “The Sunday Show” that concerns over his age and health going into the 2024 presidential elections are legitimate.

## Soft-on-crime Dems ruining communities: GOP pledges to support police, public safety
 - [https://www.foxnews.com/opinion/soft-crime-dems-ruining-communities-gop-pledges-support-police-public-safety](https://www.foxnews.com/opinion/soft-crime-dems-ruining-communities-gop-pledges-support-police-public-safety)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 11:00:14+00:00

Radical Democrats have made our communities less safe by slashing police budgets, ending cash bail, and allowing violent offenders back onto our streets.

## Kyle Larson dominates at Homestead-Miami one week after Bubba Wallace incident
 - [https://www.foxnews.com/sports/kyle-larson-dominates-homestead-miami-one-week-bubba-wallace-incident](https://www.foxnews.com/sports/kyle-larson-dominates-homestead-miami-one-week-bubba-wallace-incident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 11:00:06+00:00

Kyle Larson dominated the race at Homestead-Miami Speedway on Sunday and waved the checkered flag at the finish line one week after his incident with Bubba Wallace.

## Pie quiz! Test your knowledge of pies in this fun lifestyle quiz
 - [https://www.foxnews.com/lifestyle/pie-quiz-test-knowledge-pies-lifestyle-quiz](https://www.foxnews.com/lifestyle/pie-quiz-test-knowledge-pies-lifestyle-quiz)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 11:00:05+00:00

It's pie quiz time! Test your knowledge of this fan-favorite dessert and see if you can guess the right answer — apple, blueberry, pumpkin and more!

## Iran's assistance to Russia could make country enemy combatant, missing family found and more top headlines
 - [https://www.foxnews.com/us/biden-pursues-nuclear-deal-iran-helps-russia-in-ukraine](https://www.foxnews.com/us/biden-pursues-nuclear-deal-iran-helps-russia-in-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 10:43:06+00:00

ALLEGED WAR CRIMES - Iran's assistance to Russian war effort in Ukraine could make the country an enemy combatant, experts say

## Republicans are 'eager to weaponize' diversity, MSNBC op-ed argues
 - [https://www.foxnews.com/media/republicans-eager-weaponize-diversity-msnbc-op-ed-argues](https://www.foxnews.com/media/republicans-eager-weaponize-diversity-msnbc-op-ed-argues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 10:00:53+00:00

An MSNBC opinion piece suggested that that the Republican Party has learned to use diversity 'as a shield and a lance' in the political battlefield.

## Brad Pitt meets with Formula 1 CEO, team bosses at star-studded US Grand Prix
 - [https://www.foxnews.com/entertainment/brad-pitt-meets-formula-1-ceo-team-bosses-star-studded-us-grand-prix](https://www.foxnews.com/entertainment/brad-pitt-meets-formula-1-ceo-team-bosses-star-studded-us-grand-prix)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 09:58:27+00:00

Brad Pitt was seen at the star-studded U.S. Grand Prix over the weekend in Austin, Texas. He has been doing research for his forthcoming Formula 1 film.

## Former ‘America’s Got Talent’ finalist Zuri Craig dies at 44
 - [https://www.foxnews.com/entertainment/former-americas-got-talent-finalist-zuri-craig-dies-44](https://www.foxnews.com/entertainment/former-americas-got-talent-finalist-zuri-craig-dies-44)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 09:18:24+00:00

"America's Got Talent" finalist Zuri Craig died on Friday at the age of 44, his family announced on his Instagram. A cause of death was revealed.

## ProPublica journalist mocked for spreading ‘pathetic’ 20-year-old DeSantis gossip: ‘The walls are closing in’
 - [https://www.foxnews.com/media/propublica-journalist-mocked-spreading-pathetic-20-year-old-desantis-gossip-walls-closing](https://www.foxnews.com/media/propublica-journalist-mocked-spreading-pathetic-20-year-old-desantis-gossip-walls-closing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 09:00:46+00:00

Pro Publica reporter Alec MacGillis shared a claim on Twitter Saturday that Gov. Ron DeSantis, R-Fla., would break up with girls in college for correcting him.

## Florida woman, 8 months pregnant, polespears fish for potential world record catch
 - [https://www.foxnews.com/lifestyle/florida-woman-8-months-pregnant-polespears-fish-potential-world-record-catch](https://www.foxnews.com/lifestyle/florida-woman-8-months-pregnant-polespears-fish-potential-world-record-catch)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 06:00:45+00:00

Julie Augustine, a mother-to-be from Destin, Florida, caught a potential world record fish with a polespear while freediving in the eighth month of her pregnancy.

## The Army is scrapping Fort Hood. Here’s who it’ll be renamed after
 - [https://www.foxnews.com/us/army-scrapping-fort-hood-renamed](https://www.foxnews.com/us/army-scrapping-fort-hood-renamed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 06:00:38+00:00

Fort Hood's new name commemorates the late war hero Richard Cavazos, a four-star Army general who served with honor, according to three retired Army generals.

## RNC has launched 73 election lawsuits in 20 states: 'Most litigious' election cycle
 - [https://www.foxnews.com/politics/rnc-73-election-lawsuits-20-states-most-litigious-election-cycle](https://www.foxnews.com/politics/rnc-73-election-lawsuits-20-states-most-litigious-election-cycle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 06:00:30+00:00

The GOP is set to have the "most litigious" election cycle since 1981, launching 73 election integrity lawsuits in 20 states on issues such as poll watchers and absentee ballots.

## Prince William's giant 'garden city' slammed by climate activists
 - [https://www.foxnews.com/politics/prince-williams-giant-garden-city-slammed-climate-activists](https://www.foxnews.com/politics/prince-williams-giant-garden-city-slammed-climate-activists)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 06:00:27+00:00

Local environmentalists in southeastern England expressed concern with Prince William's plans to move forward with a sustainable 2,500-home eco village.

## Iran's assistance to Russian war effort could make the country an enemy combatant, experts say
 - [https://www.foxnews.com/world/irans-assistance-russian-war-effort-make-country-enemy-combatant](https://www.foxnews.com/world/irans-assistance-russian-war-effort-make-country-enemy-combatant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 06:00:25+00:00

Iran has supplied Russia with drones and other military equipment for its war in Ukraine that could open the country up to being considered a combatant in the conflict.

## In midterm elections, women's votes will decide our future
 - [https://www.foxnews.com/opinion/midterm-elections-womens-votes-will-decide-our-future](https://www.foxnews.com/opinion/midterm-elections-womens-votes-will-decide-our-future)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 06:00:14+00:00

Women are the most powerful voting bloc in the nation, and we have the power and the determination to shape the future of this country on Election Day.

## Biden’s history of berating, scolding and insulting reporters, from ‘stupid son of a b---h’ to ‘get educated’
 - [https://www.foxnews.com/media/bidens-history-berating-scolding-insulting-reporters-stupid-son-get-educated](https://www.foxnews.com/media/bidens-history-berating-scolding-insulting-reporters-stupid-son-get-educated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 06:00:05+00:00

President Biden scolded reporters who pressed him campaign trail appearances and abortion restrictions last week, continuing his tradition of barking at journalists.

## Biden’s ‘official’ trips as president land him in places with tight campaign races too
 - [https://www.foxnews.com/politics/biden-trips-places-with-tight-campaign-races](https://www.foxnews.com/politics/biden-trips-places-with-tight-campaign-races)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 06:00:05+00:00

President Biden’s official White House trips in recent weeks have been scheduled on the same days and in the same areas as political events, which helps defray costs incurred by Democratic political operations for campaign-related activity.

## Kevin Spacey found not liable in Anthony Rapp sex abuse case: A look at the allegations against him
 - [https://www.foxnews.com/entertainment/kevin-spacey-found-not-liable-anthony-rapp-sex-abuse-case-look-allegations-against-him](https://www.foxnews.com/entertainment/kevin-spacey-found-not-liable-anthony-rapp-sex-abuse-case-look-allegations-against-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 06:00:05+00:00

Although Kevin Spacey was found not liable in the sexual abuse case brought against him by Anthony Rapp, the "House of Cards" actor still faces another trial in the United Kingdom.

## Australian men face charges after blinding e-scooter rider with projectile potato
 - [https://www.foxnews.com/world/australian-men-face-charges-after-blinding-e-scooter-rider-projectile-potato](https://www.foxnews.com/world/australian-men-face-charges-after-blinding-e-scooter-rider-projectile-potato)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 05:07:08+00:00

Two men in Australia were arrested and charged after firing potatoes at people riding e-scooters. A young man was hit in the face and had to have surgery to remove one of his eyes.

## Astros complete sweep of Yankees, will face Phillies in World Series
 - [https://www.foxnews.com/sports/astros-complete-sweep-yankees-face-phillies-world-series](https://www.foxnews.com/sports/astros-complete-sweep-yankees-face-phillies-world-series)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 04:22:37+00:00

The Houston Astros are still the team to beat in the American League. They completed their sweep of the New York Yankees and will face the Phillies in the World Series.

## On this day in history, Oct. 24, 1861, transcontinental telegraph completed, connecting coasts for first time
 - [https://www.foxnews.com/lifestyle/this-day-history-oct-24-1861-transcontinental-telegraph-completed-connecting-us-coasts-first-time](https://www.foxnews.com/lifestyle/this-day-history-oct-24-1861-transcontinental-telegraph-completed-connecting-us-coasts-first-time)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 04:02:39+00:00

The transcontinental telegraph was completed on Oct. 24, 1861, making possible instant communication between the coasts possible for the first time. It rendered the Pony Express obsolete.

## Dolphins earn win over Steelers in Tua Tagovailoa's return
 - [https://www.foxnews.com/sports/dolphins-earn-win-steelers-tua-tagovailoas-return](https://www.foxnews.com/sports/dolphins-earn-win-steelers-tua-tagovailoas-return)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 03:55:22+00:00

The Miami Dolphins snapped a three-game losing streak on Sunday against the Pittsburgh Steelers with the return of quarterback Tua Tagovailoa, who previously suffered a concussion.

## Ellison denies knowing anyone who supports defunding police despite own support for replacing police force
 - [https://www.foxnews.com/politics/ellison-denies-knowing-anyone-supports-defunding-police-despite-own-support-replacing-police-force](https://www.foxnews.com/politics/ellison-denies-knowing-anyone-supports-defunding-police-despite-own-support-replacing-police-force)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 03:05:39+00:00

Minnesota Attorney General Keith Ellison claimed that he didn't know anyone who supports the "Defund the Police" movement despite previous support for replacing police.

## Yankees' Nestor Cortes leaves do-or-die Game 4 with injury
 - [https://www.foxnews.com/sports/yankees-nestor-cortes-leaves-do-or-die-game-4-with-injury](https://www.foxnews.com/sports/yankees-nestor-cortes-leaves-do-or-die-game-4-with-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 01:57:50+00:00

With the Yankees on the verge of being swept in the American League Championship Series, Nestor Cortes left the game with an injury in the third inning.

## 'Welcome to Plathville' star, Kim Plath, arrested for DUI in Florida: report
 - [https://www.foxnews.com/entertainment/welcome-to-plathville-star-kim-plath-arrested-dui-florida-report](https://www.foxnews.com/entertainment/welcome-to-plathville-star-kim-plath-arrested-dui-florida-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 01:37:40+00:00

"Welcome to Plathville" matriarch Kim Plath turned herself in to the Wakulla County Sheriff's Office and was arrested for DUI stemming from a crash in June

## Michigan family of four that mysteriously disappeared one week ago is located in Wisconsin
 - [https://www.foxnews.com/us/michigan-family-four-disappeared-one-week-ago-located-wisconsin](https://www.foxnews.com/us/michigan-family-four-disappeared-one-week-ago-located-wisconsin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 01:32:09+00:00

A Michigan family that disappeared on Oct. 16 after the father displayed "paranoia" during a 911 call was located in Wisconsin on Sunday, police announced.

## Washington Senate: Murray calls for gun control after being accused of being soft on crime during debate
 - [https://www.foxnews.com/politics/washington-senate-murray-calls-gun-control-after-accused-soft-crime-debate](https://www.foxnews.com/politics/washington-senate-murray-calls-gun-control-after-accused-soft-crime-debate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 01:20:42+00:00

Sen. Patty Murray defended her record against Republican challenger Tiffany Smiley during Sunday's debate as she looks to hold on a seat she has held since 1993.

## Gov. Bill Lee points to the open border as being one of the sources of crime plaguing the nation's streets
 - [https://www.foxnews.com/media/gov-bill-lee-points-open-border-being-one-sources-crime-plaguing-nations-streets](https://www.foxnews.com/media/gov-bill-lee-points-open-border-being-one-sources-crime-plaguing-nations-streets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 01:20:41+00:00

Tennessee Gov. Bill Lee, R, spoke about his efforts to combat crime and boost police in his state while appearing on “Sunday Night in America with Trey Gowdy.”

## Michigan grandmother allegedly stabbed 2-year-old grandson in head, boy recovering in hospital
 - [https://www.foxnews.com/us/michigan-grandmother-allegedly-stabbed-grandson-head-boy-recovering-hospital](https://www.foxnews.com/us/michigan-grandmother-allegedly-stabbed-grandson-head-boy-recovering-hospital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 01:17:00+00:00

A Michigan grandmother is accused of stabbing her 2-year-old grandson in the head multiple times. The boy is in stable condition in a local hospital.

## Virginia high school reports illness outbreak, 1,000 students call out sick
 - [https://www.foxnews.com/us/virginia-high-school-reports-illness-outbreak-1000-students-call-out-sick](https://www.foxnews.com/us/virginia-high-school-reports-illness-outbreak-1000-students-call-out-sick)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 01:07:34+00:00

Around 1,000 students and a few staff members at a Virginia high school called out sick last week after experiencing flu-like symptoms and stomach pains.

## 'America is being destroyed' by the Democratic Party: Mark Levin
 - [https://www.foxnews.com/media/america-destoryed-democratic-party-mark-levin](https://www.foxnews.com/media/america-destoryed-democratic-party-mark-levin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 00:51:51+00:00

Mark Levin says Democrats are destorying the country by challenging America's foundational values from within in his opening monologue on 'Life, Liberty & Levin.'

## Philadelphia Phillies fans go crazy celebrating team going to World Series
 - [https://www.foxnews.com/sports/philadelphia-phillies-fans-go-crazy-celebrating-team-going-world-series](https://www.foxnews.com/sports/philadelphia-phillies-fans-go-crazy-celebrating-team-going-world-series)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 00:50:48+00:00

The Philadelphia Phillies are headed to their first World Series since 2009 after missing the postseason for 11 years. Fans are making up for lost time.

## Josh Jacobs' hat trick propels Raiders over Texans
 - [https://www.foxnews.com/sports/josh-jacobs-hat-trick-propels-raiders-texans](https://www.foxnews.com/sports/josh-jacobs-hat-trick-propels-raiders-texans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 00:45:58+00:00

Josh Jacobs ran for 143 yards and three touchdowns, all in the second half, as the Las Vegas Raiders took down the Houston Texans on Sunday.

## Seahawks rookie running back shines in blowout win over Chargers
 - [https://www.foxnews.com/sports/seahawks-rookie-running-back-shines-blowout-win-chargers](https://www.foxnews.com/sports/seahawks-rookie-running-back-shines-blowout-win-chargers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 00:24:02+00:00

The Seattle Seahawks offense continued to dominate, this time in Los Angeles, as they defeated the Chargers thanks to a huge day from Kenneth Walker.

## Jets win fourth in a row, but at an immense cost, as Broncos falter again
 - [https://www.foxnews.com/sports/jets-win-fourth-row-immense-cost-broncos-falter-again](https://www.foxnews.com/sports/jets-win-fourth-row-immense-cost-broncos-falter-again)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 00:14:14+00:00

The New York Jets won their fourth game in a row, adding to the Denver Broncos' misery, but it come at the cost of likely losing Breece Hall for the year.

## US, Russian defense secretaries speak for second time in three days amid 'dirty bomb' claims
 - [https://www.foxnews.com/world/us-russian-defense-secretaries-speak-second-time-three-days-dirty-bomb-claims](https://www.foxnews.com/world/us-russian-defense-secretaries-speak-second-time-three-days-dirty-bomb-claims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 00:10:12+00:00

Lloyd Austin, the U.S. Secretary of Defense, spoke with his Russian counterpart for the second time in three days on Sunday, according to the Pentagon.

## Patrick Mahomes' big day spoils Christian McCaffrey's 49ers debut
 - [https://www.foxnews.com/sports/patrick-mahomes-big-day-spoils-christian-mccaffreys-49ers-debut](https://www.foxnews.com/sports/patrick-mahomes-big-day-spoils-christian-mccaffreys-49ers-debut)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 00:04:41+00:00

The San Francisco 49ers got a huge jolt when they acquired Christian McCaffrey, but the Kansas City Chiefs were just too much for them to handle.

## 'Face the Nation' focus groups of GOP, Democrat parents sound off on 'woke culture' overtaking US education
 - [https://www.foxnews.com/media/face-the-nation-focus-groups-parents-sound-off-woke-culture-overtaking-us-education](https://www.foxnews.com/media/face-the-nation-focus-groups-parents-sound-off-woke-culture-overtaking-us-education)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2022-10-24 00:03:40+00:00

A CBS focus group of parents agreed that 'woke' school curriculums have become a main concern for them and will be a voting priority in the upcoming midterms.


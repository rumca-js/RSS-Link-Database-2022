# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## This RTX 4090 GPU has a huge problem. It caught fire
 - [https://www.digitaltrends.com/computing/nvidia-geforce-rtx-4090-connector-burns-up/](https://www.digitaltrends.com/computing/nvidia-geforce-rtx-4090-connector-burns-up/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2022-10-24 18:48:21.439415+00:00

There might be a problem with the Nvidia GeForce RTX 4090, and it's bad enough that the power connector actually burned up.

## Nvidia may already be moving on from the RTX 4090, and that’s bad news for gamers
 - [https://www.digitaltrends.com/computing/nvidia-may-be-changing-priorities/](https://www.digitaltrends.com/computing/nvidia-may-be-changing-priorities/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2022-10-24 18:48:21.431745+00:00

Nvidia may be changing lanes and switching its focus away from the RTX 4090 and onto a different kind of graphics solution.

## This gorgeous triple-monitor stand can hold three 22-pound displays
 - [https://www.digitaltrends.com/computing/this-triple-monitor-stand-can-hold-three-22-pound-monitors/](https://www.digitaltrends.com/computing/this-triple-monitor-stand-can-hold-three-22-pound-monitors/)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2022-10-24 18:48:21.344150+00:00

Racing game fanatics and flight sim aficionados can finally get that immersed experience thanks to the Monoprice Dark Matter triple-monitor stand.


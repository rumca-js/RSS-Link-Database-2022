# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## SPOOKY Sound Design with Noise Engineering Plugins
 - [https://www.youtube.com/watch?v=VtIZsil4dzI](https://www.youtube.com/watch?v=VtIZsil4dzI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2022-10-25 00:00:00+00:00

Let's explore horror sound design with the suite of Noise Engineering plugins.
Get your own NE plugins (some are free!) here: https://noiseengineering.us/collections/software

00:00 intro
00:38 sound design
20:37 final track spooky 

Join me on Patreon and get access to music, presets, samples, and a great community: http://bit.ly/rmrpatreon

Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Soundcloud: http://bit.ly/2NOH9Is
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia


# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## The designers of the new ‘Apex Legends’ map want to help you die less
 - [https://www.washingtonpost.com/video-games/2022/10/24/apex-legends-broken-moon-pois/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2022/10/24/apex-legends-broken-moon-pois/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-24 15:05:06+00:00

"Apex Legends: Eclipse” will launch Nov. 1 with Broken Moon, which has a new zip rail system and larger points of interest to reduce dogpiling during drops.

## FTC brings action against CEO of alcohol delivery company over data breach
 - [https://www.washingtonpost.com/technology/2022/10/24/ftc-drizly-privacy-violations/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/10/24/ftc-drizly-privacy-violations/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-24 14:19:51+00:00

The FTC's rare decision to put Drizly CEO under order signals a new approach to privacy enforcement under Chair Lina Khan.

## Two alleged Chinese intelligence officers accused of trying to buy info about federal prosecution
 - [https://www.washingtonpost.com/national-security/2022/10/24/justice-china-telecom-giant-spy-investigation/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/national-security/2022/10/24/justice-china-telecom-giant-spy-investigation/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-24 13:24:54+00:00

Complaint accuses two alleged Chinese spies of money laundering and attempting to obstruct an investigation into a China-based telecommunications company.

## NASA proved it can deflect an asteroid. But spotting them is tricky.
 - [https://www.washingtonpost.com/technology/2022/10/24/nasa-asteroid-telescope/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/10/24/nasa-asteroid-telescope/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-24 06:00:05+00:00

The space agency is working to develop an telescope that would track many more potentially hazardous asteroids, but the project has faced funding cuts.

## She clicked sign-in with Google. Strangers got access to all her files.
 - [https://www.washingtonpost.com/technology/2022/10/21/sign-in-google-facebook/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/10/21/sign-in-google-facebook/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2022-10-24 05:00:48+00:00

Should you log in with Facebook or Google on other sites or apps? Short answer: No.


# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## am I this bad to work for?
 - [https://www.youtube.com/watch?v=9V33IVWgSas](https://www.youtube.com/watch?v=9V33IVWgSas)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2022-10-24 00:00:00+00:00




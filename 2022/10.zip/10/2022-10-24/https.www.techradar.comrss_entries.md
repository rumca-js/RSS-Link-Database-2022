# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## YouTube is finally letting you zoom in and out on videos
 - [https://www.techradar.com/news/youtube-is-finally-letting-you-zoom-in-and-out-on-videos/](https://www.techradar.com/news/youtube-is-finally-letting-you-zoom-in-and-out-on-videos/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 21:11:28+00:00

New features and a fresher design could have a big impact on how you use and perceive the video platform

## Walmart still doesn't accept Apple Pay - here's why
 - [https://www.techradar.com/news/walmart-still-doesnt-accept-apple-pay-heres-why/](https://www.techradar.com/news/walmart-still-doesnt-accept-apple-pay-heres-why/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 21:08:18+00:00

Apple Pay still not available at Walmart despite high demand.

## This typosquatting campaign is using over 200 domains to compromise Windows and Android users
 - [https://www.techradar.com/news/this-typosquatting-campaign-is-using-over-200-domains-to-compromise-windows-and-android-users/](https://www.techradar.com/news/this-typosquatting-campaign-is-using-over-200-domains-to-compromise-windows-and-android-users/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 20:25:14+00:00

More than 20 brands impersonated as crooks seek to distribute different infostealers.

## Apple Music and Apple TV+ just got price hikes – should you cancel?
 - [https://www.techradar.com/news/apple-music-and-apple-tv-just-got-price-hikes-should-you-cancel/](https://www.techradar.com/news/apple-music-and-apple-tv-just-got-price-hikes-should-you-cancel/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 19:46:52+00:00

Apple may be raising prices on its services, but they still offer very good value when compared to the competition.

## OnePlus Nord N300 5G is here but with limitations
 - [https://www.techradar.com/news/oneplus-nord-n300-5g-is-here-but-with-limitations/](https://www.techradar.com/news/oneplus-nord-n300-5g-is-here-but-with-limitations/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 19:13:26+00:00

A direct follow up to the N200, the Nord N300 5G launches with a better performing chipset and a lower resolution display.

## These malicious Android apps have already been downloaded over 20 million times
 - [https://www.techradar.com/news/these-malicious-android-apps-have-already-been-downloaded-over-20-million-times/](https://www.techradar.com/news/these-malicious-android-apps-have-already-been-downloaded-over-20-million-times/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 19:03:34+00:00

More than a dozen "clicker" Android apps found in Play Store, slowing phones down and raking in bigger bills.

## New report says the Silver Surfer is coming to Disney+ before the Fantastic Four movie
 - [https://www.techradar.com/news/new-report-says-the-silver-surfer-is-coming-to-disney-before-the-fantastic-four-movie/](https://www.techradar.com/news/new-report-says-the-silver-surfer-is-coming-to-disney-before-the-fantastic-four-movie/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 18:19:51+00:00

New rumors suggest the Silver Surfer could be getting his own TV special on Disney Plus.

## Republicans sue Google over Gmail election spam plan
 - [https://www.techradar.com/news/republicans-sue-google-over-gmail-election-spam-plan/](https://www.techradar.com/news/republicans-sue-google-over-gmail-election-spam-plan/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 18:16:22+00:00

The RNC is suing Google over claims that its end-of-month fundraising emails are being marked as spam.

## BlackByte ransomware will now stash your data in the cloud
 - [https://www.techradar.com/news/blackbyte-ransomware-will-now-stash-your-data-in-the-cloud/](https://www.techradar.com/news/blackbyte-ransomware-will-now-stash-your-data-in-the-cloud/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 17:06:48+00:00

Stolen files sent to the cloud and into a Mega folder.

## Fallout 4's PS5 and Xbox Series X upgrades may point to things to come
 - [https://www.techradar.com/news/fallout-4s-ps5-and-xbox-series-x-upgrades-may-point-to-things-to-come/](https://www.techradar.com/news/fallout-4s-ps5-and-xbox-series-x-upgrades-may-point-to-things-to-come/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 16:18:04+00:00

Bethesda has announced it will release a free next-gen upgrade for Fallout 4 in 2023.

## Our VPN testing results are in and you’ll absolutely guess who’s number one!
 - [https://www.techradar.com/news/our-vpn-testing-results-are-in-and-youll-absolutely-guess-whos-number-one/](https://www.techradar.com/news/our-vpn-testing-results-are-in-and-youll-absolutely-guess-whos-number-one/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 16:01:53+00:00

ExpressVPN continues to impress as our best overall VPN

## Parasite Eve could be the next horror game series to get a revival
 - [https://www.techradar.com/news/parasite-eve-could-be-the-next-horror-game-series-to-get-a-revival/](https://www.techradar.com/news/parasite-eve-could-be-the-next-horror-game-series-to-get-a-revival/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 15:12:38+00:00

A trademark listing filed by Square Enix suggests that the PlayStation action-horror series, Parasite Eve, is set for a revival.

## Slack says hybrid working is here to stay, and attitudes need to change
 - [https://www.techradar.com/news/slack-says-hybrid-working-is-here-to-stay-and-attitudes-need-to-change/](https://www.techradar.com/news/slack-says-hybrid-working-is-here-to-stay-and-attitudes-need-to-change/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 15:03:04+00:00

Burnout and inflexible bosses are perpetuating the Great Resignation, and a new report claims it can't go on for much longer.

## How to avoid Nvidia RTX 4090 scams when shopping online during Black Friday
 - [https://www.techradar.com/news/how-to-avoid-nvidia-rtx-4090-scams-when-shopping-online-during-black-friday/](https://www.techradar.com/news/how-to-avoid-nvidia-rtx-4090-scams-when-shopping-online-during-black-friday/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 14:32:15+00:00

Here's how you can avoid Nvidia RTX 4090 and other gadget scams when shopping for Black Friday deals.

## The world's biggest PC manufacturer is still doing big business in Russia
 - [https://www.techradar.com/news/the-worlds-biggest-pc-manufacturer-is-still-doing-big-business-in-russia/](https://www.techradar.com/news/the-worlds-biggest-pc-manufacturer-is-still-doing-big-business-in-russia/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 14:13:17+00:00

Russia-based Aquarius experiences a huge boom, but Lenovo takes an overwhelming lead in computer sales.

## Think the Nvidia RTX 4090 GPU is hard to buy now? Things could get worse
 - [https://www.techradar.com/news/think-the-nvidia-rtx-4090-gpu-is-hard-to-buy-now-things-could-get-worse/](https://www.techradar.com/news/think-the-nvidia-rtx-4090-gpu-is-hard-to-buy-now-things-could-get-worse/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 14:02:06+00:00

Rumor has it that Nvidia could be switching chip production to a more profitable product than the RTX 4090.

## Apple might be Samsung TVs' savior in the battle against Dolby Vision HDR
 - [https://www.techradar.com/news/apple-might-be-samsung-tvs-savior-in-the-battle-against-dolby-vision-hdr/](https://www.techradar.com/news/apple-might-be-samsung-tvs-savior-in-the-battle-against-dolby-vision-hdr/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 14:01:30+00:00

The Apple TV app has started rolling out support for HDR10+ on TVs – and Samsung TV owners are the biggest beneficiary.

## No, PC gaming isn't dying – Steam proves it's never been more popular
 - [https://www.techradar.com/news/no-pc-gaming-isnt-dying-steam-proves-its-never-been-more-popular/](https://www.techradar.com/news/no-pc-gaming-isnt-dying-steam-proves-its-never-been-more-popular/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 13:45:32+00:00

Is PC gaming dying, or even rather unwell? Not a chance, certainly not going by fresh stats from Steam.

## Thousands of GitHub repositories are littered with malware
 - [https://www.techradar.com/news/thousands-of-github-repositories-are-littered-with-malware/](https://www.techradar.com/news/thousands-of-github-repositories-are-littered-with-malware/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 13:12:09+00:00

One in every 10 PoC GitHub repositories is fake, and distributes malware, researchers found.

## Hackers steal 50GB data, thousands of emails from Iranian nuclear facilities
 - [https://www.techradar.com/news/hackers-steal-50gb-data-thousands-of-emails-from-iranian-nuclear-facilities/](https://www.techradar.com/news/hackers-steal-50gb-data-thousands-of-emails-from-iranian-nuclear-facilities/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 12:30:04+00:00

While the group links the attack to ongoing protests, Iran plays down potential importance of hack.

## Don't worry, Florence Pugh won't be done with Marvel movies after Thunderbolts
 - [https://www.techradar.com/news/dont-worry-florence-pugh-wont-be-done-with-marvel-movies-after-thunderbolts/](https://www.techradar.com/news/dont-worry-florence-pugh-wont-be-done-with-marvel-movies-after-thunderbolts/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 11:38:37+00:00

Florence Pugh has been tipped to reprise her role as Yelena Belova in an unnamed future Marvel project.

## New Windows 11 problem holds your USB drives hostage
 - [https://www.techradar.com/news/new-windows-11-problem-holds-your-usb-drives-hostage/](https://www.techradar.com/news/new-windows-11-problem-holds-your-usb-drives-hostage/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 11:09:09+00:00

Windows 11 gets even more annoying with this USB bug.

## Apple, let's finally see our Fitness and Health info on our Macs and iPads too
 - [https://www.techradar.com/news/apple-lets-finally-see-our-fitness-and-health-info-on-our-macs-and-ipads-too/](https://www.techradar.com/news/apple-lets-finally-see-our-fitness-and-health-info-on-our-macs-and-ipads-too/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 11:02:28+00:00

Checking my fitness on my iPhone has been the standard, but it's baffling I can't see the same on my Mac and iPad.

## Most business leaders still prefer an old-fashioned phone call to Zoom
 - [https://www.techradar.com/news/most-business-leaders-still-prefer-an-old-fashioned-phone-call-to-zoom/](https://www.techradar.com/news/most-business-leaders-still-prefer-an-old-fashioned-phone-call-to-zoom/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 10:54:38+00:00

Don’t throw away your handsets just yet, RingCentral warns.

## Ads nearly ruined the iPhone's App Store, and Apple's about to add more of them
 - [https://www.techradar.com/news/ads-nearly-ruined-the-iphones-app-store-and-apples-about-to-add-more-of-them/](https://www.techradar.com/news/ads-nearly-ruined-the-iphones-app-store-and-apples-about-to-add-more-of-them/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 10:52:32+00:00

Apple is preparing to introduce ads into the App Store's Today tab and a new "You Might Also Like" section.

## Monolith’s huge 100W desktop speakers want to knock you off your office chair
 - [https://www.techradar.com/news/monoliths-huge-100w-desktop-speakers-want-to-knock-you-off-your-office-chair/](https://www.techradar.com/news/monoliths-huge-100w-desktop-speakers-want-to-knock-you-off-your-office-chair/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 10:43:06+00:00

Monolith’s well-connected MTM 100 aptX HD desktop speakers will hugely improve your desktop PC or laptop’s audio – that's just fact.

## An Overwatch 2 bug lets you see Lucio through walls, bet you still can't catch him
 - [https://www.techradar.com/news/an-overwatch-2-bug-lets-you-see-lucio-through-walls-bet-you-still-cant-catch-him/](https://www.techradar.com/news/an-overwatch-2-bug-lets-you-see-lucio-through-walls-bet-you-still-cant-catch-him/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 10:36:21+00:00

Users on Reddit have spotted a Lucio bug that may mean the character needs to be sent off for fixing.

## The Essential Phone’s spiritual successor is a high-end handset with old-school features
 - [https://www.techradar.com/news/essential-phone-spiritual-successor-osom-solana-mobile-saga/](https://www.techradar.com/news/essential-phone-spiritual-successor-osom-solana-mobile-saga/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 10:25:39+00:00

The Saga is a top-tier crypto-focused phone with an unusual mix of specs and features.

## Lego’s gaming PC has the best Halloween costume we’ve seen in years
 - [https://www.techradar.com/news/legos-gaming-pc-has-the-best-halloween-costume-weve-seen-in-years/](https://www.techradar.com/news/legos-gaming-pc-has-the-best-halloween-costume-weve-seen-in-years/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 10:14:59+00:00

Lego dressed up an RTX 3090-powered gaming PC as a haunted house, and we can't stop thinking about it.

## 7 new iOS 16.1 features coming to your iPhone today
 - [https://www.techradar.com/news/7-new-ios-161-features-coming-to-your-iphone-today/](https://www.techradar.com/news/7-new-ios-161-features-coming-to-your-iphone-today/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 10:09:46+00:00

Improvements to the Dynamic Island and shared photo libraries in iCloud are among the changes coming in today's iOS 16.1 update.

## PS5 Discord integration seen in the wild for the first time
 - [https://www.techradar.com/news/ps5-discord-integration-seen-in-the-wild-for-the-first-time/](https://www.techradar.com/news/ps5-discord-integration-seen-in-the-wild-for-the-first-time/)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2022-10-24 09:02:07+00:00

Discord's PS5 voice integration has been added to the app's beta, signalling an update is coming soon.


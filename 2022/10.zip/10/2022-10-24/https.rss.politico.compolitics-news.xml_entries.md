# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Corporate America lobbies up in support of same-sex marriage
 - [https://www.politico.com/news/2022/10/24/corporate-america-same-sex-marriage-00063239](https://www.politico.com/news/2022/10/24/corporate-america-same-sex-marriage-00063239)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-10-24 17:27:29+00:00

Businesses are pushing for passage of legislation to add same-sex and interracial marriage protections into law.

## Abrams’ campaign chair collected millions in legal fees from voting rights organization
 - [https://www.politico.com/news/2022/10/24/stacey-abrams-fair-fight-action-00061348](https://www.politico.com/news/2022/10/24/stacey-abrams-fair-fight-action-00061348)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2022-10-24 03:30:00+00:00

Fair Fight Action, the nonprofit founded by Abrams, paid her close friend and ally’s law firm $9.4 million in 2019 and 2020, with two more years of billing yet to be disclosed.


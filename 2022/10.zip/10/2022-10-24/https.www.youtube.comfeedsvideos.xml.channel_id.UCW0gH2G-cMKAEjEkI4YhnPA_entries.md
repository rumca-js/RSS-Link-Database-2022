# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## LOTR: Return to Moria Video Game EXCLUSIVE Sneak Peek!
 - [https://www.youtube.com/watch?v=G9B5gksEba8](https://www.youtube.com/watch?v=G9B5gksEba8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2022-10-25 00:00:00+00:00

The Lord of the Rings: Return to Moria emerges from the shadows for the first time since its official announcement earlier this year for a special live roundtable on the most Dwarven of holidays – Durin’s Day! Featuring members of the development team at Free Range Games, Dr. Corey Olsen aka “The Tolkien Professor”, this live broadcast will offer the deepest look at the game to date. Viewers will be treated to in-depth discussions around the game’s setting in the Fourth Age of Middle-earth and how Free Range Games are consulting with experts in the field to ensure authenticity and consistency with the iconic fantasy world created by J.R.R. Tolkien. In addition, eager gamers will get first details regarding the game’s survival-crafting systems and mechanics, while showcasing new art, concept images and screenshots for the very first time!

#lordoftherings #returntomoria #tolkien


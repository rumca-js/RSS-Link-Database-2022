# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## TeamGroup’s radical new AIO cooler chills your SSD, too
 - [https://www.pcworld.com/article/1360274/teamgroups-latest-aio-cooler-can-cool-down-your-ssd-too.html](https://www.pcworld.com/article/1360274/teamgroups-latest-aio-cooler-can-cool-down-your-ssd-too.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-10-24 15:48:15+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>As flash storage becomes the latest PC component to <a href="https://www.pcworld.com/article/626798/your-next-ssd-upgrade-might-need-active-cooling.html" rel="noreferrer noopener" target="_blank">succumb to the temptation</a> of flashy LEDs and oversized coolers, PC suppliers are more than willing to indulge the excesses of builders. Those with more money than sense might want to check out the latest all-in-one liquid cooler from TeamGroup. Not only will the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.teamgroupinc.com/en/product/siren-duo360-all-in-one-argb-cpu-ssd-liquid-cooler&amp;xcust=2-1-1360274-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">T-Force Siren Duo360 ARGB cooler</a> (just rolls off the tongue, don&rsquo;t it?) cool <a href="https://www.pcworld.com/article/401980/best-cpus-for-gaming.html">your CPU</a> with shiny LED goodness, it&rsquo;ll cool down your <a href="https://www.pcworld.com/article/407542/best-ssds.html">fancy M.2 SSD</a> as well. </p>



<p><a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.tomshardware.com/news/team-group-launches-dual-cpu-and-ssd-liquid-cooler&amp;xcust=2-1-1360274-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Tom&rsquo;s Hardware</a> spotted the new design, scheduled to launch to the usual retail subjects sometime in November. The cooler&rsquo;s preconfigured loop includes dual translucent water blocks for the CPU and the SSD, compatible with all the latest hardware designs, including Intel LGA 1700 and AMD AM5 sockets. The SSD cooler works with M.2 modules up to 80mm in length, and yes, that includes cutting-edge PCIe Gen-5 models. If you&rsquo;re feeling creative, the RGB-LED lighting module on top of the SSD water block can be magnetically detached and stuck somewhere else inside your case. The various lights are compatible with LED manager programs from Asus, Asrock, Biostar, Gigabyte, and MSI. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Teamgroup SSD AIO cooler LED module" class="wp-image-1360296" height="655" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/detachable-led-module-teamgroup.jpg?quality=50&amp;strip=all" width="1024" /></figure><p class="imageCredit">TeamGroup</p></div>



<p>Doing the thermal work is a 396mm-long water block with three 120mm fans, naturally festooned with their own LEDs. TeamGroup claims that when it&rsquo;s all set up and ready, it can reduce the operating temperature of a full-load Gen 5 SSD by &ldquo;more than 50%&rdquo; from 100<em>&deg;</em>C. Of course in order to actually use the full system, you&rsquo;ll need a motherboard that exposes its M.2 slots somewhere in reach of the tubing going to and from both the radiator and the CPU &mdash; 430mm and 230mm, respectively. Break out the rulers before you buy it. </p>



<p>And how much does it cost, pray tell? The whole kit and kaboodle will set you back $399 when it launches next month. That&rsquo;s a lot, but honestly, if your system is so powerful and running so hot that you need custom liquid cooling just for your storage, it might just be worth it. </p>
Solid-State Drives</div>

## LEGO built a monster gaming PC inside a haunted house playset for Halloween
 - [https://www.pcworld.com/article/1360206/lego-built-a-monster-gaming-pc-inside-a-haunted-house-playset.html](https://www.pcworld.com/article/1360206/lego-built-a-monster-gaming-pc-inside-a-haunted-house-playset.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-10-24 15:11:13+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>LEGO has been appealing more and more to adult builders these days &mdash; it has to, now that every other set costs north of $300. But you won&rsquo;t find its latest creation on a Target toy shelf. The company took to Twitter this weekend to show off an enormous custom haunted house design, filled to the brim with spooky touches and monster mini-figs. But the coolest part is hiding just behind the brickwork: a fully-operational gaming PC, complete with a custom cooling loop that would make any mad scientist proud. </p>



<figure class="wp-block-embed is-type-rich is-provider-twitter wp-block-embed-twitter"><div class="wp-block-embed__wrapper">
<blockquote class="twitter-tweet"><p dir="ltr" lang="en">Just in time for Halloween &#127875; This monster, one-off, brick-built gaming PC is giving us the chills. <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://t.co/0PhL05ko8g&amp;xcust=2-1-1360206-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">pic.twitter.com/0PhL05ko8g</a></p>&mdash; LEGO (@LEGO_Group) <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://twitter.com/LEGO_Group/status/1584213446404497408?ref_src=twsrc%5Etfw&amp;xcust=2-1-1360206-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">October 23, 2022</a></blockquote></div></figure><p>The way the parts are integrated into the decor is ingenious. Cooling fans are recessed into decorative arches, reservoirs hide LEGO spiders in &ldquo;preservative,&rdquo; and every inch of both the exterior and interior is touched up with spooky little details. Open up the case with its integrated hinges and you&rsquo;ll find a huge Frankenstein monster, various balconies for minifigs to hang out (or from), a pipe organ for Dracula, and even a tiny LED showing off system temperatures with custom brick graphics. Some of the minifigs are even integrated as festive guides for cable routing. </p>



<p>The massive creation is bigger than any retail set, made from more than 20,000 LEGO bricks. Hardware specs include a Core i9-12900KF processor and a <a href="https://www.pcworld.com/article/393531/nvidia-geforce-rtx-3090-founders-edition-review.html">GeForce RTX 3090 GPU</a>, all started with a switch cunningly hidden underneath a gargoyle on the house&rsquo;s exterior. Sadly, this is an entirely promotional design: while there are <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://hackaday.com/2016/02/11/lego-gaming-computer-case/&amp;xcust=2-1-1360206-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">plenty of LEGO PCs out there</a>, this one will remain a one-of-a-kind masterpiece. </p>
Desktop PCs</div>

## Microsoft’s surprise PC Manager system optimizer takes aim at CCleaner
 - [https://www.pcworld.com/article/1360140/microsoft-releases-beta-of-a-ccleaner-style-pc-manager-tool.html](https://www.pcworld.com/article/1360140/microsoft-releases-beta-of-a-ccleaner-style-pc-manager-tool.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-10-24 14:47:39+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>Windows often gets bogged down with unnecessary files, kind of like a teenager&rsquo;s bedroom floor. Microsoft has improved both Windows itself and the tools designed to manage it in the last few years, and it looks like the company is preparing yet another way for users to keep their PCs running smoothly. A beta version of &ldquo;PC Manager&rdquo; has appeared on a Microsoft site in China, apparently offering a completed tool that should look familiar to users of the classic CCleaner freeware. </p>



<p>Though <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://pcmanager.microsoft.com/&amp;xcust=2-1-1360140-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">the site is entirely in Chinese</a>, the tool itself has Microsoft&rsquo;s publisher signature and appears to be safe and complete, and it installs in English on my PC. It offers a centralized location for several tools that are already present in disparate parts of Windows&rsquo; various settings menus and management programs. The apparently complete tool will clear away unused temp files, perform a deep scrub of storage disks, and quickly show running processes and startup programs (which has been easier to find in the Task Manager since Windows 10). The &ldquo;Security&rdquo; tab is basically an easy interface for Windows Update and Windows Security. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Microsoft PC Manager screenshots, startup, processes, security " class="wp-image-1360190" height="661" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/pc-manager-triple-pane.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">Michael Crider/IDG</p></div>



<p>The app was spotted by <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.theverge.com/2022/10/21/23416070/microsoft-pc-manager-app-performance-systems-clean-up&amp;xcust=2-1-1360140-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">The Verge</a>, which notes a lot of similarities to freeware PC optimization tools like CCleaner. It&rsquo;s also yet another example of Microsoft&rsquo;s less-than-subtle push for users to switch to its Edge browser. The &ldquo;Browser Protection&rdquo; tab offers a dedicated switch button. But bringing back an easy-to-use, easy-to-recommend cleaner tool might be a big deal for those of use who are our family&rsquo;s de facto tech support departments. </p>



<p>For more than a decade, a program called CCleaner was <a href="https://www.pcworld.com/article/439090/give-your-pc-a-quick-spring-cleaning-with-these-free-tools.html" rel="noreferrer noopener" target="_blank">at the top of every freeware recommendation list</a>. It was an idiot-proof way to clear up the often-messy Windows registry and other unwanted files gunking up a hard drive. But after the developer was acquired by Avast in 2017, bundled with the often-pushy antivirus software, and <a href="https://www.pcworld.com/article/407364/ccleaner-downloads-infected-malware.html" rel="noreferrer noopener" target="_blank">accidentally came with a trojan horse infecting millions of computers</a>, it had a hard and fast fall from grace. CCleaner is still offered by Avast in both free and paid forms, but it&rsquo;s been largely eclipsed by other freeware and more user-accessible tools built into Windows. </p>



<p>Despite the tool being marked as a &ldquo;Public Beta,&rdquo; Microsoft hasn&rsquo;t made any mention of PC Manager outside of China. We&rsquo;ll be keeping an eye out for a wider release. In the meantime, check out our guide to <a href="https://www.pcworld.com/article/443089/best-free-software-for-pc.html">the best free software for your PC</a>. Microsoft&rsquo;s new tool might just make the list once it gets a proper launch.</p>
Utilities</div>

## Best remote desktop software: From casual use to business deployment
 - [https://www.pcworld.com/article/703570/best-remote-desktop-software-from-casual-use-to-business-deployment.html](https://www.pcworld.com/article/703570/best-remote-desktop-software-from-casual-use-to-business-deployment.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-10-24 14:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>Every time I remotely control a computer to help a relative or customer overcome a vexing computer issue, my thoughts harken back to the ominous intro from the 1960s&rsquo; TV series <em>The</em> <em>Outer Limits</em>: &ldquo;There is nothing wrong with your television set. Do not attempt to adjust the picture. We are controlling transmission&hellip;.&rdquo; In fact, I&rsquo;ve actually quoted the monologue when a client starts messing with the mouse or typing while I&rsquo;m trying to work my magic from afar. </p>



<p>The point is, what was once tongue-in-cheek sci-fi, is now reality, and has been for quite a while. The fascinating and incredibly useful remote-desktop software that allows you to operate another computer over a long distance as if it were your own is now two decades old. But while it&rsquo;s not new, faster networking and broadband has rendered the remote desktop experience far speedier and more enjoyable. Under optimal conditions, it&rsquo;s nearly as facile as being there in person. </p>



<p>In addition to allowing you to help a family member of business associate with their computer problems, it&rsquo;s a handy way to access your own various work or home systems remotely. Since use cases and needs vary, our recommendations below will help lead you to the best remote-desktop software for your purposes.</p>



<p>Note that a <em>server</em> is the software on the computer to be controlled, and a <em>client</em> is the program that does the controlling.</p>



		<div class="wp-block-product-chart product-chart">
				</div>

		


		<div class="wp-block-product-chart product-chart">
					<div class="product-chart-separator"></div>
			<div class="wp-block-product-chart-item product-chart-item">
									<div class="product-chart-item__title-wrapper">
						<h3 class="product-chart-item__title-wrapper--title product-chart-title " id="1-teamviewer-best-free-remote-desktop-for-occasional-use">
							1.  TeamViewer &ndash; Best free remote desktop for occasional use						</h3>
					</div>
													<div class="large-pro-cons-product-chart-section">
											<div class="product-chart-item__image-outer-wrapper
							product-chart-item__image-outer-wrapper--large">
							<div class="product-chart-item__image-wrapper">
								<img alt="TeamViewer - Best free remote desktop for occasional use" class="product-chart-item__image" height="2000" src="https://b2c-contenthub.com/wp-content/uploads/2022/03/teamviewer.png" width="2000" /></div>
						</div>
															<div class="product-chart-body">
						<div class="product-chart-columns">
							
								<div class="product-chart-column">
									<p class="product-chart-subTitle">Pros</p>
									<ul class="product-pros-cons-list"><li> 
					Free for personal use					</li> 
										<li> 
					Easy to use, fast, and reliable					</li> 
										<li> 
					Available video-help facility					</li> 
										<li> 
					Supports desktop and mobile devices					</li> 
										<li> 
					Doesn't require installation to use					</li> 
														</ul></div>
																					<div class="product-chart-column">
								<p class="product-chart-subTitle">Cons</p>
								<ul class="product-pros-cons-list"><li> 
					Main screen can initially confuse new users					</li> 
										<li> 
					Occasional nags for free users					</li> 
													</ul></div>
													</div>
					</div>
														</div>
						
				
										<div class="product-content">
						
<p>TeamViewer is easy, free for personal/occasional use, and has all the remote-desktop software extras such as chat functionality, support for file transfers, and multiple-display support. Those features separate it from our other choice freebie&mdash;Chrome Remote Desktop. TeamViewer is also exceedingly friendly to new users/helpees with a &ldquo;portable&rdquo; mode that eliminates the need for installation. The only thing that keeps TeamViewer from being an unequivocal recommendation as a free option is that if you use it more than occasionally you will get pestered with messages essentially reminding you not to abuse the privilege. For the occasional use though, TeamViewer&rsquo;s free option can&rsquo;t be beat. </p>

<p>TeamViewer is laudable as a licensed business option for all the reasons mentioned above, as well as the additional support for Zoom meetings and video help; but in that regard, there are less pricey options.</p>
						</div>
											Read our full 
					<a class="product-chart-item__review-link" href="https://www.pcworld.com/article/622416/teamviewer-review-2.html" target="_blank">TeamViewerreview </a>
								</div>
			<div class="ad page-ad has-ad-prefix ad-article"></div>			<div class="product-chart-separator"></div>
			<div class="wp-block-product-chart-item product-chart-item">
									<div class="product-chart-item__title-wrapper">
						<h3 class="product-chart-item__title-wrapper--title product-chart-title " id="2-chrome-remote-desktop-best-free-remote-desktop-for-unlimited-use">
							2.  Chrome Remote Desktop &ndash; Best free remote desktop for unlimited use						</h3>
					</div>
													<div class="large-pro-cons-product-chart-section">
											<div class="product-chart-item__image-outer-wrapper
							product-chart-item__image-outer-wrapper--large">
							<div class="product-chart-item__image-wrapper">
								<img alt="Chrome Remote Desktop - Best free remote desktop for unlimited use" class="product-chart-item__image" height="1378" src="https://b2c-contenthub.com/wp-content/uploads/2022/04/Screen-Shot-2022-03-31-at-6.16.17-PM.png" width="2100" /></div>
						</div>
															<div class="product-chart-body">
						<div class="product-chart-columns">
							
								<div class="product-chart-column">
									<p class="product-chart-subTitle">Pros</p>
									<ul class="product-pros-cons-list"><li> 
					Free with Google account and Chrome browser (on any OS)					</li> 
										<li> 
					Easy to install and use					</li> 
										<li> 
					Permanent remote access					</li> 
										<li> 
					One-off screen sharing					</li> 
														</ul></div>
																					<div class="product-chart-column">
								<p class="product-chart-subTitle">Cons</p>
								<ul class="product-pros-cons-list"><li> 
					No chat function					</li> 
										<li> 
					No multiple-display support					</li> 
													</ul></div>
													</div>
					</div>
														</div>
						
				
										<div class="product-content">
						
<p>Fast and free, Chrome Remote Desktop is available on any operating system that supports the Chrome browser, including, of course, Chrome OS. Android and iOS are also taken care of so you can control computers using your phone. CRD supports both unattended access and one-off screen sharing sessions. It also supports file transfers, but lacks a chat function and support for multiple displays, so it&rsquo;s not a great option for pros who are supporting a number of different users and need more flexibility. </p>
						</div>
											Read our full 
					<a class="product-chart-item__review-link" href="https://www.pcworld.com/article/627906/chrome-remote-desktop-free-versatile-remote-control-for-google-ites.html" target="_blank">Chrome Remote Desktopreview </a>
								</div>
			<div class="ad page-ad has-ad-prefix ad-article"></div>			<div class="product-chart-separator"></div>
			<div class="wp-block-product-chart-item product-chart-item">
									<div class="product-chart-item__title-wrapper">
						<h3 class="product-chart-item__title-wrapper--title product-chart-title " id="3-microsoft-remote-desktop-connection-best-for-businesses-running-windows-pro">
							3.  Microsoft Remote Desktop Connection &ndash; Best for businesses running Windows Pro						</h3>
					</div>
													<div class="large-pro-cons-product-chart-section">
											<div class="product-chart-item__image-outer-wrapper
							product-chart-item__image-outer-wrapper--large">
							<div class="product-chart-item__image-wrapper">
								<img alt="Microsoft Remote Desktop Connection - Best for businesses running Windows Pro" class="product-chart-item__image" height="767" src="https://b2c-contenthub.com/wp-content/uploads/2022/04/Screen-Shot-2022-04-22-at-8.31.36-AM.png" width="1200" /></div>
						</div>
															<div class="product-chart-body">
						<div class="product-chart-columns">
							
								<div class="product-chart-column">
									<p class="product-chart-subTitle">Pros</p>
									<ul class="product-pros-cons-list"><li> 
					Free with Windows Pro or above					</li> 
										<li> 
					Excellent performance					</li> 
										<li> 
					Clients for Windows, macOS, Android, and iOS					</li> 
														</ul></div>
																					<div class="product-chart-column">
								<p class="product-chart-subTitle">Cons</p>
								<ul class="product-pros-cons-list"><li> 
					Not available with Windows Home					</li> 
										<li> 
					Firewall/network configuration may be required					</li> 
										<li> 
					Controls only Windows computers					</li> 
													</ul></div>
													</div>
					</div>
														</div>
						
				
										<div class="product-content">
						
<p>When it comes to remote-desktop software for controlling a number of business PCs, you will most likely to have to pay for a license, save for this specific scenario: The computers you want to control are all running either the Pro or Enterprise versions of Windows. The device you are using to control those machines can be running any version of Windows, macOS, Android, or iOS. If that describes your needs, Windows Remote Desktop Connection is a worthy option. </p>

<p>It requires some technical chops to configure the router and firewall properly&mdash;something any IT pro should have no problem with. The results are speedy performance, thanks to its peer-to-peer connections, and a capable, if basic feature set. You don&rsquo;t get chat, and can only transfer files Windows-to-Windows, but if saving money is your goal, this is a great way to remotely control Windows computers for free.</p>
						</div>
											Read our full 
					<a class="product-chart-item__review-link" href="https://www.pcworld.com/article/625866/microsoft-remote-desktop-review.html" target="_blank">Microsoft Remote Desktop Connectionreview </a>
								</div>
			<div class="ad page-ad has-ad-prefix ad-article"></div>			<div class="product-chart-separator"></div>
			<div class="wp-block-product-chart-item product-chart-item">
									<div class="product-chart-item__title-wrapper">
						<h3 class="product-chart-item__title-wrapper--title product-chart-title " id="4-remotepc-by-idrive-best-for-businesses-with-mixed-operating-systems">
							4.  RemotePC by iDrive &ndash; Best for businesses with mixed operating systems						</h3>
					</div>
													<div class="large-pro-cons-product-chart-section">
											<div class="product-chart-item__image-outer-wrapper
							product-chart-item__image-outer-wrapper--large">
							<div class="product-chart-item__image-wrapper">
								<img alt="RemotePC by iDrive - Best for businesses with mixed operating systems" class="product-chart-item__image" height="1440" src="https://b2c-contenthub.com/wp-content/uploads/2022/06/RemotePC-2.png" width="1904" /></div>
						</div>
															<div class="product-chart-body">
						<div class="product-chart-columns">
							
								<div class="product-chart-column">
									<p class="product-chart-subTitle">Pros</p>
									<ul class="product-pros-cons-list"><li> 
					Client/server and web access					</li> 
										<li> 
					Supports just about every operating system					</li> 
										<li> 
					Controls Android phones					</li> 
										<li> 
					Integrated online backup (costs extra / requires iDrive 360 install)					</li> 
														</ul></div>
																					<div class="product-chart-column">
								<p class="product-chart-subTitle">Cons</p>
								<ul class="product-pros-cons-list"><li> 
					Pricey when there are free options					</li> 
													</ul></div>
													</div>
					</div>
														</div>
						
									<div class="product-chart-item__information ">
					
													<div class="product-chart-item__pricing-details ">
																	<span class="product-chart-item__pricing-details--label">
										Best Prices Today:
									</span>
																<span class="product-chart-item__pricing-details--links-wrapper">
									<a class="product-chart-item__pricing-details--link" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.remotepc.com/pricing&amp;xcust=2-1-703570-6-785309-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">19.50 at  iDrive</a>								</span>
							</div>
											</div>
				
										<div class="product-content">
						
<p>We weren&rsquo;t necessarily looking for a new option in this category. Our previous pick for business, <a href="https://www.pcworld.com/article/628880/vnc-connect-remote-control-software-review-affordable-cross-platform-with-a-vengeance.html">VNC Connect</a>, was plenty versatile, with robust features. It even edged out the also-very-good <a href="https://www.pcworld.com/article/625315/gotomypc-review-reliable-remote-control-software-for-everyday-use.html">GoToMyPC </a>on price. But now along comes RemotePC, which is less expensive still, while offering the same full package of features, such as multi-monitor support, drag-and-drop file transfers, screen recording, whiteboarding, remote sound and printing, and other conveniences. </p>

<p>There are servers for all the major desktop OSes, as well as Android. Yes, with RemotePC you can access, say, a missing Android phone or tablet from afar. Nifty. Add to that the potential for easy integration with iDrive&rsquo;s backup services (for an added fee), and you can see why we felt compelled to name a new business champ.</p>
						</div>
											Read our full 
					<a class="product-chart-item__review-link" href="https://www.pcworld.com/article/634187/remotepc-by-idrive-remote-desktop-software-review.html" target="_blank">RemotePC by iDrivereview </a>
								</div>
			<div class="ad page-ad has-ad-prefix ad-article"></div>		</div>

		


<h2 id="what-to-look-for-in-remote-desktop-software">What to look for in remote desktop software</h2>



<p>All remote desktop software works the same way. It captures input from your computer, transfers it to the target computer, which returns information about the results, including the state of the user interface&mdash;i.e., you can see the remote desktop. The protocols involved include RDS/RDP for Windows, Chromoting for Chrome Remote Desktop, VNC/RFB for VNC, etc. The names vary, as do their origins, but the all work as described.</p>



<p>Which remote desktop program you choose generally comes down to which operating systems and devices you&rsquo;re using, how much you&rsquo;ll be using it, price, and features. </p>



<p><strong>Operating system/device support:</strong> The remote desktop software you choose needs to have clients (for controlling) and servers (for being controlled) for all the computers or devices you want to employ. E.g., if you want to control a Windows PC from an iPhone, there needs to be a sever for the PC and a client for iOS.</p>



<p><strong>Ease of installation and use:</strong> If you&rsquo;re dealing with less-savvy users on the other end of the connection, never underestimate the value of intuitive and easy. If you haven&rsquo;t already installed the software on the remote machine, it can be a daunting task for the helpee. Reviews or a hands-on test drive can let you know how trouble-free the process will be. </p>



<p><strong>Price</strong>: Some solutions are free, some require a license fee. The latter tend to have more features and encompass a wider variety of platforms, though this is not an absolute. Tech support is generally only available if you pay for it, as well. We suggest that end users start off free, and if it&rsquo;s not getting the job done, explore the pay options. </p>



<p><strong>Features</strong>: Capabilities such as chat, file transfer, portal-based setup (avoiding router and network hassles), support for computers running multiple displays, etc. are obviously factors if you need them. Again, start off free and see how it goes, then spend the money according the dictates of your needs.</p>



<h2 id="how-we-test-remote-desktop-software">How we test remote desktop software</h2>



<p>We test all the software both over a local network and the internet. Virtual machines on both the local and remote computers are employed to test alternate operating systems such as Linux. If mobile clients are available, we test them on a Google Pixel 4 (Android) and an Apple iPad (iOS). We control the remote machine, transfer files, check out the chat function and any other features that are available. </p>



<p>A very important criteria is speed, i.e., how nimble the remote operating system feels, and how fast files transfer. With the increased speed and bandwidth most users have access to today, remote internet performance isn&rsquo;t the issue it was back in the days of dial-up, DSL, etc. That said, there can be noticeable differences. </p>



<p>Remote-desktop software such as TeamViewer will establish a connection using the company&rsquo;s web portal, then gets out of the way to allow traffic to flow directly from machine to machine. Others such as GoToMyPC route all traffic through their portal. This has some advantages if you&rsquo;re using a web browser to view the remote PC, but can slow things down otherwise&mdash;especially on local network connections. Windows Remote Desktop Connection and Apple Remote Desktop are peer-to-peer by nature. This allows good performance both locally and across the internet, but requires configuring firewalls and routers for the latter.  </p>



<p>The other major consideration we evaluate is how intuitive and easy the software is to set up and use. In most cases, we use less tech-savvy family and friends as guinea pigs. Sorry, folks!</p>



<div class="wp-block-idg-base-theme-faq-block faq-block"><h2 class="faq-block-title" id="faq"> FAQ </h2><hr class="block-horizotal-divider" /><div class="wp-block-idg-base-theme-faq-inner-block faq-save-block"><div class="faq-save-content"><span class="faq-rank">1.</span>
<h3 id="how-do-i-remote-desktop-to-my-computer">How do I remote desktop to my computer?</h3>



<div class="wp-block-idg-base-theme-faq-answer-block how-to-tip">
<p>First you will need remote access software, such as one of the recommendations above. Once you have completed the setup on both the controlling computer and the remote computer you wish to access, it&rsquo;s as simple as selecting the computer you wish to remotely log into and then hitting connect.</p>



<p>Some remote desktop software such as Chrome Remote Desktop utilize an application on your mobile device that you open and select the remote desktop you wish to connect to via an internet connection. Others, such as TeamViewer require you to install remote access software on the computer you wish to connect to and work via their program.</p>



<p>Either way, you will be required to gain permission and most likely enter a password in order to log in to the remote access desktop.</p>
</div>
</div></div>



<div class="wp-block-idg-base-theme-faq-inner-block faq-save-block"><div class="faq-save-content"><span class="faq-rank">2.</span>
<h3 id="what-is-a-remote-desktop-good-for">What is a remote desktop good for?</h3>



<div class="wp-block-idg-base-theme-faq-answer-block how-to-tip">
<p>There are a number of reasons to use a remote desktop such as the ability to easily monitor and maintain many devices connected to a network, allow access to files on connected devices, and cheaper data security, among others. But by far the most popular usage of remote desktop is to assist with IT and computer issues from afar. Being able to assist coworkers, friends, and family with their tech problems is made infinitely easier via remote desktop than waiting until you visit your parents or relatives over the holidays.</p>
</div>
</div></div>



<div class="wp-block-idg-base-theme-faq-inner-block faq-save-block"><div class="faq-save-content"><span class="faq-rank">3.</span>
<h3 id="what-is-the-difference-between-a-virtual-and-a-remote-desktop">What is the difference between a virtual and a remote desktop?</h3>



<div class="wp-block-idg-base-theme-faq-answer-block how-to-tip">
<p>A remote desktop is a program that allows you to connect to a different physical computer somewhere else and interact with its desktop as if you were actually in front of that computer itself.</p>



<p>Without getting too technical, a virtual desktop is a program running on a computer that mimics the operation of a different computer or operating system&mdash;a pretend computer if you will. It is an image of a preconfigured operating system with applications, files, etc. that is separate from the original end device or computer and is typically run via cloud or through a host server.</p>
</div>
</div></div>
</div>
Productivity Software</div>

## Dell XPS 13 review: An absolutely stunning laptop—until you lift the lid
 - [https://www.pcworld.com/article/1355530/dell-xps-13-9315-review.html](https://www.pcworld.com/article/1355530/dell-xps-13-9315-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-10-24 10:45:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><div class="review" id="review-body"><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Incredibly thin and compact design</li><li>Beautiful and rigid machined aluminum chassis</li><li>Comfortable keyboard and touchpad</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>Lid is difficult to open</li><li>Mediocre performance</li><li>Grainy, 720p webcam</li><li>Limited ports</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">The Dell XPS 13 9315 boasts a gorgeous, incredibly thin all-metal design, but its lackluster performance, subpar webcam, and hard-to-lift lid prevent a stronger recommendation.</p>
</div>


<p>The XPS 13 is a beauty. Among midrange laptops, it boasts the sleekest, most compact design, packing a 13.4-inch 16:10 display into an enclosure that looks hardly any larger than an 11-inch Chromebook. But this is no Chromebook. Made from machined aluminum in an alluring blue hue and only a half an inch thick, the XPS 13 has premium-grade looks. For regular trips and daily commutes, the XPS 13 is an easy travel mate.&nbsp;</p>



<p>Despite its luxurious looks, the XPS 13 is a midrange ultraportable. It starts at $749 with Dell&rsquo;s current discount and our test system&rsquo;s upgrades still keep the price at a reasonable $1,149. Our test system features the baseline CPU, a 12th-gen Core i5, that provides acceptable application performance but still trails that of other midrange laptops that dial back the design touches and put more of their budget toward more capable Core i7 parts. It also lacks an OLED panel and 1080p webcam, two features that are becoming more common on midrange laptops. And we found it annoyingly difficult to open the laptop&rsquo;s lid, a seemingly small issue that became a great nuisance in quick order.</p>



<h2 id="dell-xps-13-9315-specifications">Dell XPS 13 9315 specifications</h2>



<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">

</div></figure><p><br />Our Dell XPS 13 test system is selling for $1,149 at its current discount from Dell and features the following specs:&nbsp;</p>



<ul><li>Display: 13.4 FHD+ (1920 x 1200) touch panel with 500-nit rating</li><li>Processor: Intel Core i5-1230U</li><li>Graphics: Iris Xe Graphics</li><li>Memory: 16GB</li><li>Storage: 512GB SSD</li><li>Ports: 2 Thunderbolt 4 (3.5mm dongle and USB-A to USB-C dongle included)</li><li>Camera: 720p with Windows Hello support</li><li>Battery: 51 Whr</li><li>Wireless: WiFi 6 (802.11ax), Bluetooth 5.1</li><li>Operating system: Windows 11 Home</li><li>Dimensions: 11.63 x 7.85 x 0.55 inches</li><li>Weight: 2.57 pounds</li><li>Price: Starts at $749 / $1,149 as tested</li></ul><p>The XPS 13 starts at $999, but Dell offers constantly revolving discounts on its site and the baseline model is currently discounted to $749. It features a Core i5-1230U, 8GB of RAM. a 512GB SSD, and a non-touch 13.4-inch display. While it&rsquo;s good to see a 512GB SSD offered as the default storage option instead of an undersized 256GB unit, we wish Dell skipped past the meager 8GB of RAM and offered 16GB at minimum. Our test model features the 16GB memory upgrade, which adds a hefty $150 to the bill. Adding touch support to the display adds another $100, which feels steep since it doesn&rsquo;t come with a bump in resolution or, better yet, an OLED panel.</p>



<h2 id="tough-nut-to-crack">Tough nut to crack</h2>



<p>The XPS 13 is a vision in metallic blue. The subtle shade of blue allows it to stand out from the sea of brushed aluminum laptops in silver. The lid, bottom panel and keyboard deck are tinted aluminum in a blue hue that Dell calls &ldquo;Sky.&rdquo; There is also an &ldquo;Umber&rdquo; option that&rsquo;s a purplish brown. The keyboard is made to match. The keys on our Sky test system are an icy blue and, appropriately enough, look really cool.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Dell XPS 13 lid" class="wp-image-1357602" height="900" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/Dell-XPS-13-9315-lid.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">IDG / Matthew Elliott</p></div>



<p>Opening the lid to get to the keyboard, however, is a task more difficult than it ever should be. Most laptops have a notch on the front edge that gives you the needed space for your fingertip to find purchase to raise the lid. The XPS 13 is completely devoid of such helpful notching. The front edge of the lid is angled and overhangs from the keyboard deck, but it is not wide enough for you to lift the lid without also lifting the entire laptop. I found I needed to use my fingernail to pry open the lid. In short order, opening the XPS 13 felt like trying to get to the nut inside a pistachio shell that has only the smallest sliver of an opening.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Dell XPS 13 edge of lid" class="wp-image-1357604" height="900" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/Dell-XPS-13-9315-edge-of-lid.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">IDG / Matthew Elliott</p></div>



<p>When the XPS 13 is closed it cuts a thin profile. It&rsquo;s a hair over a half an inch thick and with thin bezels on all four sides of the display, it measures only 11.63 inches wide and 7.85 inches deep. It&rsquo;s about as thin and compact as a 13.4-inch laptop gets. And it&rsquo;s light, too, and roughly 2.5 pounds. It&rsquo;s even lighter than the 2.71-pound XPS 13 Plus, Dell&rsquo;s upscale 13.4-inch model.</p>



<p>As with the display, Dell wastes no space with the keyboard &mdash; it runs from edge to edge. The keyboard feels roomy and there are no shortened keys to get accustomed to. The keys offer shallow travel and snappy feedback for a pleasant and speedy typing experience. There&rsquo;s two-level backlighting for working on a redeye or an otherwise dark environment. The power button resides in the upper-right corner of the keyboard and doubles as a fingerprint reader for easy, secure logins.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Dell XPS 13 keyboard" class="wp-image-1357607" height="900" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/Dell-XPS-13-9315-keyboard.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">IDG / Matthew Elliott</p></div>



<p>The compact design doesn&rsquo;t leave much room for the touchpad, but Dell made it about as large as can be given the limited space between the bottom of the keyboard and the bottom edge of the laptop. It offers smooth gliding and an accurate response, and the click mechanism is perfect with just the right amount of travel.</p>



<h2 id="disappointing-webcam-sparse-ports">Disappointing webcam, sparse ports</h2>



<p>The best two attributes of the XPS 13&rsquo;s display are its brightness and tallness. It has a 16:10 aspect ratio and is rated for 500 nits. At 16:10, the display is taller than a 16:9 screen, and the added vertical space makes the display feel larger than its 13.4-inch size. The effect of having a taller aspect ratio grows in importance as the size of the panel shrinks. A larger, 15- or 16-inch screen feels roomy at 16:10 or 16:9, but a smaller 13-inch screen can feel cramped at 16:9 when you are constantly scrolling through web pages and documents. The XPS 13&rsquo;s 13.4-inch screen certainly isn&rsquo;t the easiest on which to multitask, but the added height the 16:10 ratio affords does allow you to see more on the screen with less scrolling required.&nbsp;</p>



<p>I measured the panel against its 500-nit rating and found it to hit roughly 425 nits at maximum brightness. While it&rsquo;s disappointing the actual brightness wasn&rsquo;t closer to its rating, the panel is plenty bright for every indoor setting we tried, from a sunny, south-facing breakfast nook to an office under ample artificial lighting.&nbsp;</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Dell XPS 13 display" class="wp-image-1357610" height="900" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/Dell-XPS-13-9315-display.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">IDG / Matthew Elliott</p></div>



<p>The display&rsquo;s 1920&times;1200 resolution is more than sufficient for the size of the display. Dell set the display scaling to 150%, which resulted in large text and icons that remained crisp and clear. I found that setting the scaling to 125% provided a larger workspace while keeping text at a font size that was still large enough to be read easily without squinting.</p>



<p>While superior OLED panels are becoming more common in midrange laptops, the XPS 13 appears just out of reach of OLED-land. It features a basic LCD panel with decent contrast and colors but can&rsquo;t match the quality of an OLED panel that we have seen on models that cost only a bit more than the XPS 9315. It&rsquo;s a shame the touch panel option doesn&rsquo;t also come with an OLED upgrade.</p>



<p>The laptop&rsquo;s stereo speakers produce better sound than expected, although I will note I have low expectations for any laptop with only a pair of two-watt speakers. Especially on such a thin and compact system, the XPS 13&rsquo;s audio output is fairly dynamic with even a hint of bass. It has enough muscle to fill a small room, although the clarity quickly declines when you push the volume past 70%.&nbsp;</p>



<p>The webcam is a disappointment. While 1080p webcams have quickly become the de facto option on all but the must budget of laptops, the XPS 9315 features a 720p webcam that suffers from a grainy image with over saturated colors. I would expect to see a 720p camera on a low-end model from Dell&rsquo;s mainstream Inspiron line, but every XPS laptop should come equipped with a 1080p camera by now.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Dell XPS 13 right ports" class="wp-image-1357615" height="900" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/Dell-XPS-13-9315-right-port.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">IDG / Matthew Elliott</p></div>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Dell XPS 13 left ports" class="wp-image-1357616" height="900" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/Dell-XPS-13-9315-left-port.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /></figure><p class="imageCredit">IDG / Matthew Elliott</p></div>



<p>Dell offers a sparse port selection on the XPS 9315. The laptop features two Thunderbolt 4 ports &mdash; one on each side of the system. That&rsquo;s it. There&rsquo;s not even a headphone jack. To supplement the minimal ports, Dell includes two adapters in the box. There&rsquo;s one USB-C to 3.5mm jack dongle for connecting headphones and another USB-C to USB-A dongle for your USB-A peripherals. You&rsquo;re on your own for adapting to an HDMI connection.</p>



<h2 id="performance">Performance</h2>



<p>Our Dell XPS 13 features the Intel Core i5-1230U CPU, 16GB of RAM, integrated Intel Iris Xe graphics, and a 512GB SSD. The Core i5-1230U is a chip from Intel&rsquo;s 12th generation of Core processors with two performance cores and eight efficiency cores. It&rsquo;s a member of the U-series of 9-watt chips that prioritizes efficiency over power.&nbsp;</p>



<p>To see how it stacks up to its ultrabook competition, we looked at its performance against that of the Acer Aspire 5 15 based on the 15-watt Core i5-1235U. You&rsquo;ll also see the Acer Swift 5 and Samsung Galaxy Book2 Pro 360 in the charts; each features a Core i7-1260P, a chip from the P series that sits between Intel&rsquo;s efficient U-series and high-powered H-series. We also included last year&rsquo;s Dell XPS 13 2-in-1 9310 that features an 11th-gen Core i7 part. Rounding out the charts are two compact ultraportables with AMD Ryzen 7 5800U in the HP Pavilion Aero 13 and Lenovo IdeaPad Slim 7 Carbon.</p>



<p>In anecdotal testing, the XPS 13 felt peppy during general Windows use, including multitasking scenarios. Apps opened and closed quickly, and I was able to juggle multiple apps and windows without any lag. The laptop also operated in near silence, which is not always a given on a thin, compact system that can present thermal challenges.</p>



<p>Our first benchmark is PCMark 10, which measures performance on everyday computing work including office productivity tasks, web browsing, and video chats. With only two performance cores, the XPS 13 limped to a last place finish on PCMark 10, trialing the other system that featured more processing cores as well as the Acer Aspire 5 15, whose Core i5-1235U has the same number of performance (2) and efficiency (8) cores as the XPS 13&rsquo;s Core i5-1230U. The Aspire 5 15&rsquo;s CPU, however, is a 15-watt chip compared with only 9 watts for the XPS 13. That extra wattage results in greater PCMark performance.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Dell XPS 13 PCMark" class="wp-image-1357618" height="601" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/Dell-XPS-13-9315-PCMark.jpg?quality=50&amp;strip=all" width="905" /></figure><p class="imageCredit">IDG / Matthew Elliott</p></div>



<p>Our HandBrake benchmark tests how a laptop is able to handle crushing CPU loads over a lengthy period&mdash;in this case, transcoding a 30GB MKV file to a format suitable for Android tablets using HandBrake, the free video encoding utility. The XPS 13 managed to finish ahead of last year&rsquo;s Dell XPS 13 2-in-1 but took much longer to complete the test than the other systems with 12th-gen Intel processors and AMD Ryzen 7 5000-series chips.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Dell XPS 13 Handbrake" class="wp-image-1357620" height="601" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/Dell-XPS-13-9315-HandBreake.jpg?quality=50&amp;strip=all" width="905" /></figure><p class="imageCredit">IDG / Matthew Elliott</p></div>



<p>Next up is Cinebench, another CPU-intensive test but one that renders a complex 2D scene over a short period of time. The XPS 13 finished dead last and well off the pace set by the laptops with CPUs that feature a greater number of processing cores.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Dell XPS 13 Cinebench" class="wp-image-1357621" height="601" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/Dell-XPS-13-9315-Cinebench.jpg?quality=50&amp;strip=all" width="904" /></figure><p class="imageCredit">IDG / Matthew Elliott</p></div>



<p>The XPS 13&rsquo;s showing in labs testing did not improve with 3D graphics testing. On 3DMark&rsquo;s Time Spy benchmark, it finished last among the group.&nbsp;</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Dell XPS 13 3DMark" class="wp-image-1357625" height="601" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/Dell-XPS-13-9315-3DMark.jpg?quality=50&amp;strip=all" width="902" /></figure><p class="imageCredit">IDG / Matthew Elliott</p></div>



<p>To test a laptop&rsquo;s battery life, we loop a 4K video using Windows 11&rsquo;s Movies &amp; TV app, with the laptop set to Airplane mode and earbuds plugged in. We set the screen brightness at a relatively bright 250 nits to 260 nits, which is a good brightness for watching a movie in an office with the lights on. We had hoped that with its efficient Core i5 U-series chip, the XPS 13 would flip the script and finish toward the top of the chart for battery life. Sadly, it did not. It failed to top the 10-hour mark on our battery drain test, a threshold most of the ultrabooks here were able to exceed.</p>



<h2 id="conclusion">Conclusion</h2>



<p>At first blush, the Dell XPS 13 is an attractive ultraportable for its compact design, thin profile, and unique tinted aluminum material. As soon as you attempt to raise the lid, however, the bloom is off the rose. It&rsquo;s frustratingly difficult to perform the simple act of opening the laptop. In addition, competing ultrabooks offer better performance and longer battery life than the XPS 13 and its 12th-gen Core i5 chip. Further, the 720p webcam is behind the times and, with only two ports, you are forced to keep track of two tiny adapters. For roughly the same price, the slightly larger but still highly portable HP Pavilion 14 Plus offers better performance along with an OLED display and 1080p webcam.</p>
Laptops</div>

## Intel’s Core i9-13900K consumes insane power. You can tame it.
 - [https://www.pcworld.com/article/1359352/cool-down-a-deep-dive-into-13900k-power-use-and-efficiency.html](https://www.pcworld.com/article/1359352/cool-down-a-deep-dive-into-13900k-power-use-and-efficiency.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2022-10-24 10:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section><p>Hot, hungry chips. People said that of the <a href="https://www.pcworld.com/article/1074246/amd-ryzen-9-7950x-review.html">AMD Ryzen 9 7950X</a> when it launched several weeks ago&mdash;and then again when Intel launched its own new flagship desktop CPU, <a href="https://www.pcworld.com/article/1357979/intel-core-i9-13900k-review.html">the ferocious Core i9-13900K</a>, which just hit shelves on Thursday.</p>



<p>There&rsquo;s reason for it. While top-end processors have always drawn more power than the rest of their siblings, their power ratings have quietly and steadily risen in recent years. Today, you&rsquo;re looking at 253W as the maximum turbo power (TDP) for the 13900K, up from 241W for the Core i9-12900K. Which, for the record, already had some folks murmuring in the stands.</p>



<p>With warmer weather and rising energy costs looming, power draw has become a more important consideration for many CPU buyers. But even if you don&rsquo;t worry about melting in your home or the size of your electrical bill, there are still interesting nuances in the interplay between the Core i9-13900K&rsquo;s energy consumption and performance&mdash;and how those outcomes stack up against 7950X&rsquo;s. We dive deep into those details in our YouTube overview, but for the quicker version, read on.</p>



<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">

</div></figure><h2 id="youve-got-the-power">You&rsquo;ve got the power</h2>



<p>A couple of years ago, most people would simply drop a chip into a motherboard and not give much thought to the power draw. Perhaps you&rsquo;d look at a few charts outlining total system draw, but then you&rsquo;d file it in the back of your head and go about your life.</p>



<p>But now Intel and AMD&rsquo;s flagship desktop CPUs are essentially arriving with gigantic factory overclocks&mdash;they&rsquo;re tuned for maximum performance, not energy efficiency. The pipeline is left wide open for as much fuel possible.</p>



<p>If you&rsquo;re an enthusiast tinkerer, that leaves room for you to power limit the chips for improved efficiency, be it to maintain a cooler home (less electricity consumed means less heat thrown off), keep monthly utility costs down (less electricity consumed also equals fewer kWh to pay for), coax better system temperatures from your build, or because you simply think it&rsquo;s fun.</p>



<p>That doesn&rsquo;t mean that the Core i9-13900K or the rival 7950X are sloppily burning electricity in an effort to ramp up performance. On the contrary, these new processors serve up impressive performance-per-watt efficiency compared to their predecessors.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Intel Core i9-13900K benchmark Cinebench power draw perf v2" class="wp-image-1358059" height="799" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/image-4.png?w=1200" width="1200" /><figcaption><p><em>Longer bars indicate better performance.</em></p></figcaption></figure><p class="imageCredit">Gordon Mah Ung / PCWorld</p></div>



<p>Both Intel and AMD extract a heck of a lot from every watt, as demonstrated by the range of performance these chips show when we manually power limit them to specific wattages. In the case of the Core i9-13900K, it still can outperform its predecessor even when its power limit is significantly dropped. Just look at it when constrained to a maximum of 85W&mdash;it still performs about the same as the 12900K at its default max turbo power of 241W.</p>



<p>On Team Red&rsquo;s side, the Ryzen 9 7950X outperforms the Core i9-13900K when constrained by equal power limitations. In fact, not only does the 7950X at 65W handily beat the 13900K at 65W, but it almost bests the 13900K when the latter is set to 105W.</p>



<p>That&rsquo;s good info for enthusiasts looking to tinker with their system&rsquo;s power consumption and temperatures. But is the Core i9-13900K a power hog when you&rsquo;re running it at stock?</p>



<h2 id="core-i9-13900k-power-usage-in-different-workloads">Core i9-13900K power usage in different workloads</h2>



<div class="wp-container-2 wp-block-group"><div class="wp-block-group__inner-container">
<div class="wp-container-1 wp-block-group"><div class="wp-block-group__inner-container">
<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Intel Core i9-13900K total power draw w/ power limit variations v2" class="wp-image-1358060" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/image-6.png?w=1200" /><figcaption><p></p>
</figcaption></figure><p class="imageCredit">Gordon Mah Ung / PCWorld</p></div>



<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Intel Core i9-13900K power benchmarks" class="wp-image-1358032" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/5_Power_Lightroom.png?w=1200" /></figure><p class="imageCredit">Gordon Mah Ung / PCWorld</p></div>



<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Intel Core i9-13900K power benchmarks" class="wp-image-1358026" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/3_Power_Cinebench_1T.png?w=1200" /></figure><p class="imageCredit">Gordon Mah Ung / PCWorld</p></div>
</div></div>
</div></div>



<p>When you compare the two flagship chips purely on the basis of power consumption (and not how much performance you get while under manually set limitations), calling a winner gets a little more complicated. At stock settings, the Core i9-13900K typically consumes less power in single-threaded tasks, while the Ryzen 9 7950X pulls significantly less electricity during multithreaded tasks. In lightly threaded tasks, like Adobe Lightroom or the two games we tested, it&rsquo;s more of a tie.</p>



<p>The fun part is how much energy the chips draw when power limited. Notch down the Core i9-13900K to 105W or 65W, and it goes lighter on power consumption than the 7950X with the same limits. It may get outperformed by the 7950X at those TDPs, but you won&rsquo;t be paying extra in electricity costs.</p>



<div class="wp-container-3 wp-block-group"><div class="wp-block-group__inner-container">
<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Intel Core i9-13900K power benchmarks" class="wp-image-1358027" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/1_Power_Blender.png?w=1200" /></figure><p class="imageCredit">Gordon Mah Ung / PCWorld</p></div>



<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Intel Core i9-13900K power benchmarks" class="wp-image-1358025" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/7_Power_Horizon_Zero_Dawn.png?w=1200" /></figure><p class="imageCredit">Gordon Mah Ung / PCWorld</p></div>
</div></div>



<p>The takeaway from this? A little elbow grease can help you find <em>your</em> sweet spot for maximizing eye-popping performance while minimizing the hit to your monthly bills. We demonstrated the effects of power limiting here, but you should be able to achieve similar results via undervolting or even temperature limiting as well. And you&rsquo;ll always still have a reserve of extra performance in the tank if you want to let your chip run wild and free.</p>



<p>But no one will be buying the Core i9-13900K (or the 7950X) solely on the basis of power efficiency and power draw. The more appealing chip will depend on your energy concerns relative to your performance needs&mdash;and for most folks, the face-melting speed of Intel&rsquo;s best chip will be well worth the cost of keeping it running at stock.</p>



		<div class="wp-block-product-widget-block product-widget">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="">
									</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="core-i9-13900k">Core i9-13900K</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Core i9-13900K" class="product-widget__image" height="1334" src="https://b2c-contenthub.com/wp-content/uploads/2022/10/070A9689_V31.jpg?quality=50&amp;strip=all" width="2000" /></div>
					</div>
				
				
				<div class="product-widget__information">
											<div class="product-widget__information--rrp-wrapper">
								<span class="product-widget__information--rrp-label">
															</span>
								<span class="product-widget__information--rrp-value">
																</span>
							</div>
						
									</div>
			</div>
		</div>

		


		<div class="wp-block-product-widget-block product-widget">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="">
									</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="amd-ryzen-9-7950x">AMD Ryzen 9 7950X</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="AMD Ryzen 9 7950X" class="product-widget__image" height="5464" src="https://b2c-contenthub.com/wp-content/uploads/2022/09/070A9364_6.jpg?quality=50&amp;strip=all" width="8192" /></div>
					</div>
				
				
				<div class="product-widget__information">
											<div class="product-widget__information--rrp-wrapper">
								<span class="product-widget__information--rrp-label">
															</span>
								<span class="product-widget__information--rrp-value">
																</span>
							</div>
						
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.amazon.ca/dp/B0BBHD5D8Y?tag=macworld00-20&amp;linkCode=ogi&amp;th=1&amp;psc=1&amp;xcust=2-1-1359352-5-1102495-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">$929.00 at  Amazon</a>							</span>
						</div>
									</div>
			</div>
		</div>
CPUs and Processors</div>


# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Bizarre Republican Ad Blames Biden for Anti-Asian Violence Incited by Trump
 - [https://theintercept.com/2022/10/24/anti-asian-ad-trump-citizens-for-sanity/](https://theintercept.com/2022/10/24/anti-asian-ad-trump-citizens-for-sanity/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2022-10-24 19:08:31+00:00

<p>A new attack ad blames Joe Biden for the spike in Covid-era violence against Asian Americans that community leaders say Donald Trump fueled.</p>
<p>The post <a href="https://theintercept.com/2022/10/24/anti-asian-ad-trump-citizens-for-sanity/" rel="nofollow">Bizarre Republican Ad Blames Biden for Anti-Asian Violence Incited by Trump</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>


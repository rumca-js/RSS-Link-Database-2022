# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## Deep learning with light
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59284](https://www.codeproject.com/script/News/View.aspx?nwid=59284)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-10-24 04:00:00+00:00

I'm so bright, my mother called me sonny

## Microsoft’s PC Manager is like CCleaner for your computer
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59279](https://www.codeproject.com/script/News/View.aspx?nwid=59279)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-10-24 04:00:00+00:00

They do know where all the cruft is stored

## Need to buy a headset, any good recommendation?
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59276](https://www.codeproject.com/script/News/View.aspx?nwid=59276)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-10-24 04:00:00+00:00

"Life's the same, I'm moving in stereo"

## Our brains use quantum computation
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59281](https://www.codeproject.com/script/News/View.aspx?nwid=59281)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-10-24 04:00:00+00:00

That explains why I can only rub two or three thoughts together some days

## Report: Elon Musk plans to gut Twitter workforce by 75% after acquisition
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59280](https://www.codeproject.com/script/News/View.aspx?nwid=59280)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-10-24 04:00:00+00:00

Why not go for the full 100% and save us all?

## Request for advice
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59277](https://www.codeproject.com/script/News/View.aspx?nwid=59277)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-10-24 04:00:00+00:00

"The truth which makes men free is for the most part the truth which men prefer not to hear."

## Someone wrote a Javascript app that accurately emulates Windows 95 on almost any platform
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59283](https://www.codeproject.com/script/News/View.aspx?nwid=59283)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-10-24 04:00:00+00:00

No standing in line for the midnight launch required

## Support reminder for older versions of Visual Studio
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59278](https://www.codeproject.com/script/News/View.aspx?nwid=59278)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-10-24 04:00:00+00:00

If you're still using VS 2012, it might be time to think about an upgrade

## Typosquat campaign mimics 27 brands to push Windows, Android malware
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59285](https://www.codeproject.com/script/News/View.aspx?nwid=59285)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-10-24 04:00:00+00:00

Is that why no one answers my posts on c0dproject.com?

## Why functional programming should be the future of software development
 - [https://www.codeproject.com/script/News/View.aspx?nwid=59282](https://www.codeproject.com/script/News/View.aspx?nwid=59282)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2022-10-24 04:00:00+00:00

Won't you take me to func-y town?


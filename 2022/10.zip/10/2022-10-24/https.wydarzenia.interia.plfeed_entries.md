# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Kolejna fala migracji? Powodem ataki Rosjan na infrastrukturę krytyczną i zima
 - [https://wydarzenia.interia.pl/zagranica/news-kolejna-fala-migracji-powodem-ataki-rosjan-na-infrastrukture,nId,6368023](https://wydarzenia.interia.pl/zagranica/news-kolejna-fala-migracji-powodem-ataki-rosjan-na-infrastrukture,nId,6368023)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 21:39:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kolejna-fala-migracji-powodem-ataki-rosjan-na-infrastrukture,nId,6368023"><img align="left" alt="Kolejna fala migracji? Powodem ataki Rosjan na infrastrukturę krytyczną i zima" src="https://i.iplsc.com/kolejna-fala-migracji-powodem-ataki-rosjan-na-infrastrukture/000ENKOHSLL8C3EQ-C321.jpg" /></a>O możliwej drugiej fali uchodźców z Ukrainy mówił w poniedziałek wiceminister spraw wewnętrznych i administracji Bartosz Grodecki. Zgodnie z jego słowami, to Polska będzie głównym krajem przyjmującym tę falę. Podczas konferencji o migracji komisarz Unii Europejskiej Ylva Johansson zwróciła także uwagę, że na Bałkańskim szlaku do Europy jest trzykrotnie więcej osób niż w roku ubiegłym.</p><br clear="all" />

## Zełenski podsumował osiem miesięcy wojny. "Od teraz Rosja będzie żebrakiem"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-podsumowal-osiem-miesiecy-wojny-od-teraz-rosja-bedz,nId,6368013](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-podsumowal-osiem-miesiecy-wojny-od-teraz-rosja-bedz,nId,6368013)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 20:32:53+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-podsumowal-osiem-miesiecy-wojny-od-teraz-rosja-bedz,nId,6368013"><img align="left" alt="Zełenski podsumował osiem miesięcy wojny. &quot;Od teraz Rosja będzie żebrakiem&quot;" src="https://i.iplsc.com/zelenski-podsumowal-osiem-miesiecy-wojny-od-teraz-rosja-bedz/000G8X0NFSTP3A63-C321.jpg" /></a>Prezydent Ukrainy Wołodymyr Zełenski w swoim przemówieniu opublikowanym w mediach społecznościowych przypomniał, że od rozpoczęcia rosyjskiej inwazji minęło osiem miesięcy. - Już nigdy Rosja nie będzie podmiotem, który może komuś coś dyktować - powiedział. Dodał, że Ukraińcy bohatersko bronią swojego kraju i pokonują &quot;tzw. drugą armię świata&quot;.</p><br clear="all" />

## Wojna w Ukrainie. Andrea Bocelli adoptował psa Dżeka uratowanego z Kupiańska
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-andrea-bocelli-adoptowal-psa-dzeka-uratowan,nId,6367996](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-andrea-bocelli-adoptowal-psa-dzeka-uratowan,nId,6367996)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 19:56:54+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-andrea-bocelli-adoptowal-psa-dzeka-uratowan,nId,6367996"><img align="left" alt="Wojna w Ukrainie. Andrea Bocelli adoptował psa Dżeka uratowanego z Kupiańska " src="https://i.iplsc.com/wojna-w-ukrainie-andrea-bocelli-adoptowal-psa-dzeka-uratowan/000G8WU2RKMD0YS3-C321.jpg" /></a>Pies uratowany z wyzwolonego miasta Kupiańsk na wschodzie Ukrainy znalazł nowy dom. Zwierzę zamieszkało we Włoszech z rodziną światowej sławy tenora Andrei Bocellego. 
</p><br clear="all" />

## Seria kontrowersyjnych tweetów Sikorskiego. "Thank you, friend in ***"
 - [https://wydarzenia.interia.pl/kraj/news-seria-kontrowersyjnych-tweetow-sikorskiego-thank-you-friend-,nId,6368006](https://wydarzenia.interia.pl/kraj/news-seria-kontrowersyjnych-tweetow-sikorskiego-thank-you-friend-,nId,6368006)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 19:55:07+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-seria-kontrowersyjnych-tweetow-sikorskiego-thank-you-friend-,nId,6368006"><img align="left" alt="Seria kontrowersyjnych tweetów Sikorskiego. &quot;Thank you, friend in ***&quot;" src="https://i.iplsc.com/seria-kontrowersyjnych-tweetow-sikorskiego-thank-you-friend/000EGSAQ6OVFJECJ-C321.jpg" /></a>Radosław Sikorski zamieścił w mediach społecznościowych kontrowersyjne wpisy. Były szef polskiego MSZ, a obecnie europoseł Koalicji Obywatelskiej odniósł się do komentarzy po emisji filmu &quot;Pan z Chobielina&quot;. Polityk postanowił &quot;zażartować&quot; na temat swojej znajomości języka angielskiego. Tym samym odniósł się do dawnej wypowiedzi prezydenta Andrzeja Dudy. </p><br clear="all" />

## Auto zakleszczone pomiędzy ciężarówkami. W środku rodzina z dzieckiem
 - [https://wydarzenia.interia.pl/kujawsko-pomorskie/news-auto-zakleszczone-pomiedzy-ciezarowkami-w-srodku-rodzina-z-d,nId,6367957](https://wydarzenia.interia.pl/kujawsko-pomorskie/news-auto-zakleszczone-pomiedzy-ciezarowkami-w-srodku-rodzina-z-d,nId,6367957)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 19:10:44+00:00

<p><a href="https://wydarzenia.interia.pl/kujawsko-pomorskie/news-auto-zakleszczone-pomiedzy-ciezarowkami-w-srodku-rodzina-z-d,nId,6367957"><img align="left" alt="Auto zakleszczone pomiędzy ciężarówkami. W środku rodzina z dzieckiem " src="https://i.iplsc.com/auto-zakleszczone-pomiedzy-ciezarowkami-w-srodku-rodzina-z-d/000G8WN59K4W9HO0-C321.jpg" /></a>Na drodze krajowej nr 91 w okolicach miejscowości Głogówko Królewskie (woj. kujawsko-pomorskie) doszło do wypadku, w wyniku którego auto osobowe zostało zakleszczone pomiędzy dwiema ciężarówkami. Skodą Fabią podróżowali rodzice i ich trzyletnie dziecko. Udało im się samodzielnie wyjść z pojazdu. </p><br clear="all" />

## USA: Strzelanina w szkole. Trzy osoby nie żyją
 - [https://wydarzenia.interia.pl/zagranica/news-usa-strzelanina-w-szkole-trzy-osoby-nie-zyja,nId,6367964](https://wydarzenia.interia.pl/zagranica/news-usa-strzelanina-w-szkole-trzy-osoby-nie-zyja,nId,6367964)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 18:41:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-strzelanina-w-szkole-trzy-osoby-nie-zyja,nId,6367964"><img align="left" alt="USA: Strzelanina w szkole. Trzy osoby nie żyją" src="https://i.iplsc.com/usa-strzelanina-w-szkole-trzy-osoby-nie-zyja/000G8WN0XWR5DIFK-C321.jpg" /></a>W poniedziałek w szkole publicznej w St. Louis około 20-letni mężczyzna zastrzelił nastolatkę, dorosłą kobietę i zranił kilka innych osób. Napastnik zmarł w szpitalu w wyniku obrażeń. </p><br clear="all" />

## Spór Doroty Bawołek i TVP. Unijny komisarz reaguje
 - [https://wydarzenia.interia.pl/zagranica/news-spor-doroty-bawolek-i-tvp-unijny-komisarz-reaguje,nId,6367953](https://wydarzenia.interia.pl/zagranica/news-spor-doroty-bawolek-i-tvp-unijny-komisarz-reaguje,nId,6367953)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 18:28:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-spor-doroty-bawolek-i-tvp-unijny-komisarz-reaguje,nId,6367953"><img align="left" alt="Spór Doroty Bawołek i TVP. Unijny komisarz reaguje " src="https://i.iplsc.com/spor-doroty-bawolek-i-tvp-unijny-komisarz-reaguje/000G8WP7MOHHX8FD-C321.jpg" /></a>Nie milkną echa ataku TVP na korespondentkę Polsat News Dorotę Bawołek. Telewizja publiczna zarzuciła, że dziennikarka &quot;przeszkodziła&quot; ekipie TVP w rozmowie z Donaldem Tuskiem. Kilka dni temu do sprawy odniosło się międzynarodowe stowarzyszenie dziennikarzy API-IPA. Swój komentarz w mediach społecznościowych zamieścił również Didier Reynders, unijny komisarz ds. sprawiedliwości. &quot;W UE nie ma miejsca na oszczercze kampanie przeciwko dziennikarzom&quot; - napisał. </p><br clear="all" />

## Kardynał Hollerich: Uznanie aborcji za prawo podstawowe to absurd
 - [https://wydarzenia.interia.pl/zagranica/news-kardynal-hollerich-uznanie-aborcji-za-prawo-podstawowe-to-ab,nId,6367945](https://wydarzenia.interia.pl/zagranica/news-kardynal-hollerich-uznanie-aborcji-za-prawo-podstawowe-to-ab,nId,6367945)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 18:16:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kardynal-hollerich-uznanie-aborcji-za-prawo-podstawowe-to-ab,nId,6367945"><img align="left" alt="Kardynał Hollerich: Uznanie aborcji za prawo podstawowe to absurd" src="https://i.iplsc.com/kardynal-hollerich-uznanie-aborcji-za-prawo-podstawowe-to-ab/000G8WK8OPLVNNAI-C321.jpg" /></a>Przewodniczący Komisji Episkopatów Wspólnoty Europejskiej (Comece) kardynał Jean-Claude Hollerich w wywiadzie dla watykańskiego dziennika &quot;L’Osservatore Romano&quot; stwierdził, że martwi się, gdy słyszy, że w Parlamencie Europejskim są ci, którzy apelują o uznanie aborcji za prawo podstawowe. &quot;To absurd&quot; - uważa duchowny. Jean-Claude Hollerich podkreślił jednak, że w Królestwie Bożym &quot;nikt nie jest wykluczony; ani rozwiedzeni w nowych związkach, ani homoseksualiści, nikt&quot;. </p><br clear="all" />

## Kompletnie pijany Ukrainiec kierował autem. Miał prawie sześć promili
 - [https://wydarzenia.interia.pl/wielkopolskie/news-kompletnie-pijany-ukrainiec-kierowal-autem-mial-prawie-szesc,nId,6367935](https://wydarzenia.interia.pl/wielkopolskie/news-kompletnie-pijany-ukrainiec-kierowal-autem-mial-prawie-szesc,nId,6367935)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 18:00:55+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-kompletnie-pijany-ukrainiec-kierowal-autem-mial-prawie-szesc,nId,6367935"><img align="left" alt="Kompletnie pijany Ukrainiec kierował autem. Miał prawie sześć promili" src="https://i.iplsc.com/kompletnie-pijany-ukrainiec-kierowal-autem-mial-prawie-szesc/000G8WFT7Q390BJQ-C321.jpg" /></a>Do dwóch lat więzienia grozi kierowcy z Ukrainy, który w Nowym Tomyślu (woj. wielkopolskie) prowadził auto mając blisko sześć promili alkoholu w organizmie. Doszło do obywatelskiego zatrzymania, a następnie sprawcę przejęła policja. </p><br clear="all" />

## Warszawa: Syryjski boss gangu sutenerów skazany
 - [https://wydarzenia.interia.pl/mazowieckie/news-warszawa-syryjski-boss-gangu-sutenerow-skazany,nId,6367925](https://wydarzenia.interia.pl/mazowieckie/news-warszawa-syryjski-boss-gangu-sutenerow-skazany,nId,6367925)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 17:55:12+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-warszawa-syryjski-boss-gangu-sutenerow-skazany,nId,6367925"><img align="left" alt="Warszawa: Syryjski boss gangu sutenerów skazany" src="https://i.iplsc.com/warszawa-syryjski-boss-gangu-sutenerow-skazany/000G8WCQ55A1ABRX-C321.jpg" /></a>W poniedziałek w Sądzie Rejonowym dla Warszawy-Wola zapadł wyrok w sprawie grupy oskarżonej o przestępstwa związane z wykorzystywaniem co najmniej 15 kobiet zajmujących się prostytucją. Jego członkowie pochodzili z Polski, Ukrainy i Syrii. Szef gangu sutenerów, Syryjczyk Mohamad A., został skazany na trzy lata więzienia. 

</p><br clear="all" />

## Niemcy: Policjant śmiertelnie postrzelił agresywnego 31-latka z nożem
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-policjant-smiertelnie-postrzelil-agresywnego-31-latka,nId,6367924](https://wydarzenia.interia.pl/zagranica/news-niemcy-policjant-smiertelnie-postrzelil-agresywnego-31-latka,nId,6367924)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 17:50:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-policjant-smiertelnie-postrzelil-agresywnego-31-latka,nId,6367924"><img align="left" alt="Niemcy: Policjant śmiertelnie postrzelił agresywnego 31-latka z nożem" src="https://i.iplsc.com/niemcy-policjant-smiertelnie-postrzelil-agresywnego-31-latka/000G8WGKHB4O4I7I-C321.jpg" /></a>W miejscowości Zuelpich (Nadrenia-Północna Westfalia) policjanci otrzymali zgłoszenie o awanturze domowej. W czasie interwencji policjant zastrzelił agresywnego 31-latka. Mężczyzna ruszył w stronę funkcjonariuszy z nożem. To kolejny atak nożownika w ostatnich miesiącach. </p><br clear="all" />

## Gdynia: Komendant policji jechał pod prąd. Nie dostał mandatu
 - [https://wydarzenia.interia.pl/pomorskie/news-gdynia-komendant-policji-jechal-pod-prad-nie-dostal-mandatu,nId,6367913](https://wydarzenia.interia.pl/pomorskie/news-gdynia-komendant-policji-jechal-pod-prad-nie-dostal-mandatu,nId,6367913)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 17:40:48+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-gdynia-komendant-policji-jechal-pod-prad-nie-dostal-mandatu,nId,6367913"><img align="left" alt="Gdynia: Komendant policji jechał pod prąd. Nie dostał mandatu" src="https://i.iplsc.com/gdynia-komendant-policji-jechal-pod-prad-nie-dostal-mandatu/000G8WEAWX05TMPO-C321.jpg" /></a>Komendant miejskiej policji w Gdyni został zatrzymany na kontrbuspasie przez patrol drogówki. Nie dostał jednak mandatu, a jedynie pouczenie. Sprawa trafiła do jego przełożonych z Komendy Wojewódzkiej Policji w Gdańsku. </p><br clear="all" />

## Irańskie władze brutalnie tłumią protesty po śmierci Mahsy Amini
 - [https://wydarzenia.interia.pl/zagranica/news-iranskie-wladze-brutalnie-tlumia-protesty-po-smierci-mahsy-a,nId,6367903](https://wydarzenia.interia.pl/zagranica/news-iranskie-wladze-brutalnie-tlumia-protesty-po-smierci-mahsy-a,nId,6367903)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 17:26:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-iranskie-wladze-brutalnie-tlumia-protesty-po-smierci-mahsy-a,nId,6367903"><img align="left" alt="Irańskie władze brutalnie tłumią protesty po śmierci Mahsy Amini" src="https://i.iplsc.com/iranskie-wladze-brutalnie-tlumia-protesty-po-smierci-mahsy-a/000G8WBTWPU57I0H-C321.jpg" /></a>Na ulicach irańskich miast trwają demonstracje, które rozpoczęły się po śmierci Mahsy Amini. Władze brutalnie tłumią protesty. Atakowani są przechodnie. Funkcjonariusze służb bezpieczeństwa strzelają do demonstrantów. </p><br clear="all" />

## Niemcy: Polak zatrzymany na lotnisku. Był poszukiwany
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-polak-zatrzymany-na-lotnisku-byl-poszukiwany,nId,6367712](https://wydarzenia.interia.pl/zagranica/news-niemcy-polak-zatrzymany-na-lotnisku-byl-poszukiwany,nId,6367712)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 17:15:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-polak-zatrzymany-na-lotnisku-byl-poszukiwany,nId,6367712"><img align="left" alt="Niemcy: Polak zatrzymany na lotnisku. Był poszukiwany" src="https://i.iplsc.com/niemcy-polak-zatrzymany-na-lotnisku-byl-poszukiwany/000G8VTGF34A61N8-C321.jpg" /></a>30-letni Polak został zatrzymany na lotnisku w Hamburgu. Początkowo chodziło o jego zagubiony dowód osobisty, jednak policja szybko zorientowała się, że mężczyzna jest poszukiwany.</p><br clear="all" />

## "Mój Prąd 4.0". Nowe zasady programu. Kto dostanie największe pieniądze?
 - [https://wydarzenia.interia.pl/kraj/news-moj-prad-4-0-nowe-zasady-programu-kto-dostanie-najwieksze-pi,nId,6362210](https://wydarzenia.interia.pl/kraj/news-moj-prad-4-0-nowe-zasady-programu-kto-dostanie-najwieksze-pi,nId,6362210)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 17:08:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-moj-prad-4-0-nowe-zasady-programu-kto-dostanie-najwieksze-pi,nId,6362210"><img align="left" alt="&quot;Mój Prąd 4.0&quot;. Nowe zasady programu. Kto dostanie największe pieniądze?" src="https://i.iplsc.com/moj-prad-4-0-nowe-zasady-programu-kto-dostanie-najwieksze-pi/000G8TO93BE1YT9R-C321.jpg" /></a>Program &quot;Mój Prąd&quot; stworzono dla osób pragnących zainwestować w fotowoltaikę. Prokonsumenci, którym marzy się większa niezależność energetyczna, w ramach nowej puli dotacji mogą starać się o dofinansowanie do mikroinstalacji (PV) i urządzeń gromadzenia energii. Polacy mogą zaoszczędzić duże pieniądze, jednak wcześniej muszą spełnić określone warunki i złożyć wniosek o dopłatę do fotowoltaiki w ramach &quot;Mojego Prądu 4.0&quot;. </p><br clear="all" />

## USA: Iluzjonista aresztowany za pedofilię. Przez lata pracował z dziećmi
 - [https://wydarzenia.interia.pl/zagranica/news-usa-iluzjonista-aresztowany-za-pedofilie-przez-lata-pracowal,nId,6367888](https://wydarzenia.interia.pl/zagranica/news-usa-iluzjonista-aresztowany-za-pedofilie-przez-lata-pracowal,nId,6367888)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 16:44:49+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-iluzjonista-aresztowany-za-pedofilie-przez-lata-pracowal,nId,6367888"><img align="left" alt="USA: Iluzjonista aresztowany za pedofilię. Przez lata pracował z dziećmi " src="https://i.iplsc.com/usa-iluzjonista-aresztowany-za-pedofilie-przez-lata-pracowal/000G8W574FSRERMT-C321.jpg" /></a>45-letni Scott Jameson, mieszkaniec Sutton w amerykańskim stanie Massachusetts, został aresztowany pod zarzutem posiadania pornografii dziecięcej. Mężczyzna to iluzjonista z ponad 20-letnim doświadczeniem, który często organizował występy dla dzieci. </p><br clear="all" />

## GTA na Podlasiu. Kradziony autobus wpadł mu do rowu, więc poszedł po drugi
 - [https://wydarzenia.interia.pl/podlaskie/news-gta-na-podlasiu-kradziony-autobus-wpadl-mu-do-rowu-wiec-posz,nId,6367890](https://wydarzenia.interia.pl/podlaskie/news-gta-na-podlasiu-kradziony-autobus-wpadl-mu-do-rowu-wiec-posz,nId,6367890)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 16:10:29+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-gta-na-podlasiu-kradziony-autobus-wpadl-mu-do-rowu-wiec-posz,nId,6367890"><img align="left" alt="GTA na Podlasiu. Kradziony autobus wpadł mu do rowu, więc poszedł po drugi" src="https://i.iplsc.com/gta-na-podlasiu-kradziony-autobus-wpadl-mu-do-rowu-wiec-posz/000G8W648L9J0CPK-C321.jpg" /></a>19-latek z powiatu sokólskiego może na 10 lat trafić do więzienia po tym, jak ukradł z parkingu autobus i uszkodził drugi. Mężczyzna został zatrzymany przez policję i usłyszał zarzuty kradzieży z włamaniem, jej usiłowania, oraz zniszczenia mienia.</p><br clear="all" />

## Zaginiony 70-latek odnaleziony w lesie. Pomogła fotopułapka
 - [https://wydarzenia.interia.pl/lubelskie/news-zaginiony-70-latek-odnaleziony-w-lesie-pomogla-fotopulapka,nId,6367726](https://wydarzenia.interia.pl/lubelskie/news-zaginiony-70-latek-odnaleziony-w-lesie-pomogla-fotopulapka,nId,6367726)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 15:54:42+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-zaginiony-70-latek-odnaleziony-w-lesie-pomogla-fotopulapka,nId,6367726"><img align="left" alt="Zaginiony 70-latek odnaleziony w lesie. Pomogła fotopułapka " src="https://i.iplsc.com/zaginiony-70-latek-odnaleziony-w-lesie-pomogla-fotopulapka/000G8VPX52SW62U2-C321.jpg" /></a>Policjanci z Białej Podlaskiej (woj. lubelskie) odnaleźli zaginionego 70-latka, który przebywał w lesie. Jeden z funkcjonariuszy zwrócił uwagę na mężczyznę, który pojawił się na zdjęciach zrobionych przez fotopułapkę, co pomogło w ustaleniu miejsca jego pobytu. </p><br clear="all" />

## Niemcy: Tylko wegeteriańskie posiłki w szkołach i żłobkach we Freiburgu
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-tylko-wegeterianskie-posilki-w-szkolach-i-zlobkach-we,nId,6367714](https://wydarzenia.interia.pl/zagranica/news-niemcy-tylko-wegeterianskie-posilki-w-szkolach-i-zlobkach-we,nId,6367714)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 15:35:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-tylko-wegeterianskie-posilki-w-szkolach-i-zlobkach-we,nId,6367714"><img align="left" alt="Niemcy: Tylko wegeteriańskie posiłki w szkołach i żłobkach we Freiburgu" src="https://i.iplsc.com/niemcy-tylko-wegeterianskie-posilki-w-szkolach-i-zlobkach-we/000G8VP61CL073SS-C321.jpg" /></a>Od stycznia dzieci w miejskich żłobkach i szkołach podstawowych we Freiburgu będą mogły jeść wyłącznie wegetariańskie lub wegańskie potrawy. Decyzję w tej sprawie podjęła rada miasta, tłumacząc się cięciem kosztów oraz dbaniem o środowisko. Zapowiedziano również stopniowy wzrost cen posiłków. Wprowadzenie wegetariańskiego menu krytykują rodzice oraz przedstawiciele ministerstwa. </p><br clear="all" />

## Londyn: Figura króla Karola III obrzucona ciastem
 - [https://wydarzenia.interia.pl/zagranica/news-londyn-figura-krola-karola-iii-obrzucona-ciastem,nId,6367695](https://wydarzenia.interia.pl/zagranica/news-londyn-figura-krola-karola-iii-obrzucona-ciastem,nId,6367695)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 15:30:53+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-londyn-figura-krola-karola-iii-obrzucona-ciastem,nId,6367695"><img align="left" alt="Londyn: Figura króla Karola III obrzucona ciastem " src="https://i.iplsc.com/londyn-figura-krola-karola-iii-obrzucona-ciastem/000G8VP2SDH9XVMH-C321.jpg" /></a>Eksponowana w londyńskim muzeum Madame Tussaud figura woskowa przedstawiająca króla Karola III została obrzucona ciastem czekoladowym przez aktywistów klimatycznych z brytyjskiej organizacji Just Stop Oil. To forma protestu przeciwko wydawaniu przez brytyjski rząd nowych licencji na wydobywanie paliw kopalnych. Ekolodzy mają na koncie już m.in. rzucenie zupą pomidorową w jeden z obrazów z serii &quot;Słoneczniki&quot; Vincenta van Gogha. 
</p><br clear="all" />

## Tarnów. Są wstępne wyniki sekcji zwłok czteroosobowej rodziny
 - [https://wydarzenia.interia.pl/kraj/news-tarnow-sa-wstepne-wyniki-sekcji-zwlok-czteroosobowej-rodziny,nId,6367233](https://wydarzenia.interia.pl/kraj/news-tarnow-sa-wstepne-wyniki-sekcji-zwlok-czteroosobowej-rodziny,nId,6367233)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 15:23:41+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tarnow-sa-wstepne-wyniki-sekcji-zwlok-czteroosobowej-rodziny,nId,6367233"><img align="left" alt="Tarnów. Są wstępne wyniki sekcji zwłok czteroosobowej rodziny" src="https://i.iplsc.com/tarnow-sa-wstepne-wyniki-sekcji-zwlok-czteroosobowej-rodziny/000G8RABBKX071KP-C321.jpg" /></a>Przyczyną śmierci czteroosobowej rodziny były rany cięte szyi - przekazała Prokuratura Okręgowa w Tarnowie. Ciała 41-letniej Katarzyny O., 43-letniego Tomasza O. oraz ich dwóch córek znaleziono w piątek w jednym z domów przy ul. Św. Marcina. </p><br clear="all" />

## Tarnów. Są wyniki sekcji zwłok czteroosobowej rodziny
 - [https://wydarzenia.interia.pl/kraj/news-tarnow-sa-wyniki-sekcji-zwlok-czteroosobowej-rodziny,nId,6367233](https://wydarzenia.interia.pl/kraj/news-tarnow-sa-wyniki-sekcji-zwlok-czteroosobowej-rodziny,nId,6367233)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 15:23:41+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tarnow-sa-wyniki-sekcji-zwlok-czteroosobowej-rodziny,nId,6367233"><img align="left" alt="Tarnów. Są wyniki sekcji zwłok czteroosobowej rodziny" src="https://i.iplsc.com/tarnow-sa-wyniki-sekcji-zwlok-czteroosobowej-rodziny/000G8RABBKX071KP-C321.jpg" /></a>Przyczyną śmierci czteroosobowej rodziny były rany cięte szyi - przekazała Prokuratura Okręgowa w Tarnowie. Ciała 41-letniej Katarzyny O., 43-letniego Tomasza O. oraz ich dwóch córek znaleziono w piątek w jednym z domów przy ul. Św. Marcina. </p><br clear="all" />

## Podwójna emerytura przysługuje trzem grupom osób. Czy jesteś w jednej z nich?
 - [https://wydarzenia.interia.pl/kraj/news-podwojna-emerytura-przysluguje-trzem-grupom-osob-czy-jestes-,nId,6362348](https://wydarzenia.interia.pl/kraj/news-podwojna-emerytura-przysluguje-trzem-grupom-osob-czy-jestes-,nId,6362348)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 15:20:42+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-podwojna-emerytura-przysluguje-trzem-grupom-osob-czy-jestes-,nId,6362348"><img align="left" alt="Podwójna emerytura przysługuje trzem grupom osób. Czy jesteś w jednej z nich?" src="https://i.iplsc.com/podwojna-emerytura-przysluguje-trzem-grupom-osob-czy-jestes/000FZ649J2PCOCQP-C321.jpg" /></a>Podwójna emerytura nie jest dostępna dla wszystkich, ale niektórzy mogą się o nią z powodzeniem ubiegać. Trzeba jednak spełniać odpowiednie warunki i złożyć wnioski we właściwych miejscach. W Polsce druga emerytura przysługuje w trzech przypadkach. Jakich? Kto ma prawo do pobierania dwóch świadczeń emerytalnych?</p><br clear="all" />

## Koalicja Obywatelska wyprzedza Prawo i Sprawiedliwość. Najnowszy sondaż
 - [https://wydarzenia.interia.pl/kraj/news-koalicja-obywatelska-wyprzedza-prawo-i-sprawiedliwosc-najnow,nId,6367671](https://wydarzenia.interia.pl/kraj/news-koalicja-obywatelska-wyprzedza-prawo-i-sprawiedliwosc-najnow,nId,6367671)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 14:29:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-koalicja-obywatelska-wyprzedza-prawo-i-sprawiedliwosc-najnow,nId,6367671"><img align="left" alt="Koalicja Obywatelska wyprzedza Prawo i Sprawiedliwość. Najnowszy sondaż" src="https://i.iplsc.com/koalicja-obywatelska-wyprzedza-prawo-i-sprawiedliwosc-najnow/0007H7UNO0XOOCN9-C321.jpg" /></a>Z najnowszego sondażu przeprowadzonego przez Kantar Public wynika, że Koalicja Obywatelska cieszy się większym poparciem niż Prawo i Sprawiedliwość. KO uzyskało 31 proc. poparcia, a partia rządząca 28 proc. Na trzecim miejscu uplasowała się Polska 2050. </p><br clear="all" />

## Zmiażdżona ręka pracownika gminy. Przygotowywał plac do dystrybucji węgla
 - [https://wydarzenia.interia.pl/lubelskie/news-zmiazdzona-reka-pracownika-gminy-przygotowywal-plac-do-dystr,nId,6367683](https://wydarzenia.interia.pl/lubelskie/news-zmiazdzona-reka-pracownika-gminy-przygotowywal-plac-do-dystr,nId,6367683)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 14:22:48+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-zmiazdzona-reka-pracownika-gminy-przygotowywal-plac-do-dystr,nId,6367683"><img align="left" alt="Zmiażdżona ręka pracownika gminy. Przygotowywał plac do dystrybucji węgla" src="https://i.iplsc.com/zmiazdzona-reka-pracownika-gminy-przygotowywal-plac-do-dystr/000G8VGV4B5V0BJV-C321.jpg" /></a>W czasie przygotowywań placu pod dystrybucję węgla doszło do poważnego wypadku, w którym ucierpiał pracownik gminy Wojciechów. 49-latek doznał poważnego urazu ręki. Został przetransportowany do szpitala śmigłowcem Lotniczego Pogotowia Ratunkowego. </p><br clear="all" />

## Kraków: Mieszkańcy zapłacą większe podatki. Urząd zyska 52 mln zł
 - [https://wydarzenia.interia.pl/malopolskie/news-krakow-mieszkancy-zaplaca-wieksze-podatki-urzad-zyska-52-mln,nId,6367673](https://wydarzenia.interia.pl/malopolskie/news-krakow-mieszkancy-zaplaca-wieksze-podatki-urzad-zyska-52-mln,nId,6367673)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 14:17:08+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-krakow-mieszkancy-zaplaca-wieksze-podatki-urzad-zyska-52-mln,nId,6367673"><img align="left" alt="Kraków: Mieszkańcy zapłacą większe podatki. Urząd zyska 52 mln zł" src="https://i.iplsc.com/krakow-mieszkancy-zaplaca-wieksze-podatki-urzad-zyska-52-mln/000G8UJB80DRTUTJ-C321.jpg" /></a>Władze Krakowa zamierzają podnieść podatki od nieruchomości. W ten sposób chcą pozyskać od mieszkańców i firm dodatkowe 52 mln zł. Projekt w tej sprawie trafi w środę pod obrady rady miasta.</p><br clear="all" />

## Smartfony mogą pokazać, kiedy umrzemy. Najnowsze badania naukowców
 - [https://wydarzenia.interia.pl/zagranica/news-smartfony-moga-pokazac-kiedy-umrzemy-najnowsze-badania-nauko,nId,6367662](https://wydarzenia.interia.pl/zagranica/news-smartfony-moga-pokazac-kiedy-umrzemy-najnowsze-badania-nauko,nId,6367662)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 14:10:33+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-smartfony-moga-pokazac-kiedy-umrzemy-najnowsze-badania-nauko,nId,6367662"><img align="left" alt="Smartfony mogą pokazać, kiedy umrzemy. Najnowsze badania naukowców" src="https://i.iplsc.com/smartfony-moga-pokazac-kiedy-umrzemy-najnowsze-badania-nauko/000G8VB44V3QJIYA-C321.jpg" /></a>W przyszłości smartfony mogą zyskać dodatkową funkcję. Zdaniem naukowców telefony będą mogły określić ryzyko naszej śmierci w ciągu najbliższych pięciu lat. W badaniu wzięło udział ponad 100 tys. osób. Rezultaty zostały opublikowane w medycznym czasopiśmie PLOS Digital Health. </p><br clear="all" />

## Najmłodszy od ponad 200 lat. Kim jest nowy premier Wielkiej Brytanii?
 - [https://wydarzenia.interia.pl/zagranica/news-najmlodszy-od-ponad-200-lat-kim-jest-nowy-premier-wielkiej-b,nId,6367646](https://wydarzenia.interia.pl/zagranica/news-najmlodszy-od-ponad-200-lat-kim-jest-nowy-premier-wielkiej-b,nId,6367646)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 13:47:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-najmlodszy-od-ponad-200-lat-kim-jest-nowy-premier-wielkiej-b,nId,6367646"><img align="left" alt="Najmłodszy od ponad 200 lat. Kim jest nowy premier Wielkiej Brytanii? " src="https://i.iplsc.com/najmlodszy-od-ponad-200-lat-kim-jest-nowy-premier-wielkiej-b/000G8UJ1PCM6X640-C321.jpg" /></a>Rishi Sunak, nowy lider rządzącej w Wielkiej Brytanii Partii Konserwatywnej, będzie pierwszym premierem kraju wywodzącym się z mniejszości etnicznej, najmłodszym obejmującym urząd od ponad 200 lat, a także trzecim szefem brytyjskiego rządu w ciągu dwóch miesięcy.
</p><br clear="all" />

## Analitycy brytyjskiego wywiadu publikują najnowszą mapę frontową
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-analitycy-brytyjskiego-wywiadu-publikuja-najnowsza-mape-fron,nId,6367629](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-analitycy-brytyjskiego-wywiadu-publikuja-najnowsza-mape-fron,nId,6367629)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 13:46:11+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-analitycy-brytyjskiego-wywiadu-publikuja-najnowsza-mape-fron,nId,6367629"><img align="left" alt="Analitycy brytyjskiego wywiadu publikują najnowszą mapę frontową" src="https://i.iplsc.com/analitycy-brytyjskiego-wywiadu-publikuja-najnowsza-mape-fron/000G8UFLBM755AY3-C321.jpg" /></a>Ukraina kontynuuje kontrofensywę na zajętych przez wojska rosyjskie terenach. Najnowsze wydarzenia frontowe na dzień 24 października opracowane są przez analityków z brytyjskiego wywiadu. - Rosjanie stworzyli iluzję, że wycofują się z Chersonia, a w rzeczywistości wysyłają tam nowe wojska i przygotowują się do obrony w okupowanym mieście – powiedział w wywiadzie dla portalu Ukrainska Prawda szef wywiadu wojskowego Ukrainy Kyryło Budanow. </p><br clear="all" />

## Ksiądz molestował dwóch chłopców. Sąd złagodził wyrok
 - [https://wydarzenia.interia.pl/lubelskie/news-ksiadz-molestowal-dwoch-chlopcow-sad-zlagodzil-wyrok,nId,6367650](https://wydarzenia.interia.pl/lubelskie/news-ksiadz-molestowal-dwoch-chlopcow-sad-zlagodzil-wyrok,nId,6367650)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 13:38:34+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-ksiadz-molestowal-dwoch-chlopcow-sad-zlagodzil-wyrok,nId,6367650"><img align="left" alt="Ksiądz molestował dwóch chłopców. Sąd złagodził wyrok" src="https://i.iplsc.com/ksiadz-molestowal-dwoch-chlopcow-sad-zlagodzil-wyrok/0006I0MDSTO26P26-C321.jpg" /></a>Koszmar chłopców trwał rok. Ksiądz Tomasz F. regularnie ich wykorzystywał. Obaj nie mieli wtedy jeszcze 15 lat. Choć sąd pierwszej instancji skazał duchownego na 10 lat więzienia, to sąd drugiej instancji, a następnie Sąd Apelacyjny wymiar kary łagodziły. </p><br clear="all" />

## Zaćmienie Słońca: O której faza maksimum w poszczególnych miastach w Polsce?
 - [https://wydarzenia.interia.pl/kraj/news-zacmienie-slonca-o-ktorej-faza-maksimum-w-poszczegolnych-mia,nId,6367545](https://wydarzenia.interia.pl/kraj/news-zacmienie-slonca-o-ktorej-faza-maksimum-w-poszczegolnych-mia,nId,6367545)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 13:01:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zacmienie-slonca-o-ktorej-faza-maksimum-w-poszczegolnych-mia,nId,6367545"><img align="left" alt="Zaćmienie Słońca: O której faza maksimum w poszczególnych miastach w Polsce?" src="https://i.iplsc.com/zacmienie-slonca-o-ktorej-faza-maksimum-w-poszczegolnych-mia/000G8TTEUOXL8D7W-C321.jpg" /></a>Częściowe zaćmienie Słońca już we wtorek 25 października 2022 roku. To niezwykłe zjawisko, podczas którego Słońce lub jego część zostaje zakryte przez Księżyc, będzie można obserwować również w Polsce. Będzie to najgłębsze zaćmienie widoczne z naszego kraju od ponad siedmiu lat. O której godzinie będzie można obserwować zaćmienie Słońca? Jak bezpiecznie oglądać to zjawisko? Wyjaśniamy.</p><br clear="all" />

## Partia Konserwatywna podjęła decyzję. Jest nowy premier Wielkiej Brytanii
 - [https://wydarzenia.interia.pl/zagranica/news-partia-konserwatywna-podjela-decyzje-jest-nowy-premier-wielk,nId,6367561](https://wydarzenia.interia.pl/zagranica/news-partia-konserwatywna-podjela-decyzje-jest-nowy-premier-wielk,nId,6367561)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 13:00:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-partia-konserwatywna-podjela-decyzje-jest-nowy-premier-wielk,nId,6367561"><img align="left" alt="Partia Konserwatywna podjęła decyzję. Jest nowy premier Wielkiej Brytanii " src="https://i.iplsc.com/partia-konserwatywna-podjela-decyzje-jest-nowy-premier-wielk/000G8UAFHSH1ODT3-C321.jpg" /></a>O godz. 14 czasu londyńskiego (godz. 15 w Polsce) ogłoszono wyniki wewnętrznego głosowania w Partii Konserwatywnej. Jedynym kandydatem, który zdobył wymagane poparcie ze strony co najmniej 100 posłów, jest były kanclerz skarbu Rishi Sunak. To właśnie on zostanie nowym przewodniczącym ugrupowania, a zarazem premierem Wielkiej Brytanii. Urząd może objąć już we wtorek. </p><br clear="all" />

## Pijany kierowca uciekał przed policją. Wiózł trójkę dzieci
 - [https://wydarzenia.interia.pl/mazowieckie/news-pijany-kierowca-uciekal-przed-policja-wiozl-trojke-dzieci,nId,6367546](https://wydarzenia.interia.pl/mazowieckie/news-pijany-kierowca-uciekal-przed-policja-wiozl-trojke-dzieci,nId,6367546)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 12:54:59+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-pijany-kierowca-uciekal-przed-policja-wiozl-trojke-dzieci,nId,6367546"><img align="left" alt="Pijany kierowca uciekał przed policją. Wiózł trójkę dzieci" src="https://i.iplsc.com/pijany-kierowca-uciekal-przed-policja-wiozl-trojke-dzieci/0004XOUQAHNQTW1I-C321.jpg" /></a>Patrol policji z Garwolina (woj. mazowieckie) zatrzymał pijanego kierowcę po pościgu. Razem z 33-latkiem w samochodzie przebywało jeszcze troje dzieci.</p><br clear="all" />

## Uczniowie piszą egzaminy w "czapkach przeciwko oszustwom". Zdjęcia hitem sieci
 - [https://wydarzenia.interia.pl/zagranica/news-uczniowie-pisza-egzaminy-w-czapkach-przeciwko-oszustwom-zdje,nId,6367480](https://wydarzenia.interia.pl/zagranica/news-uczniowie-pisza-egzaminy-w-czapkach-przeciwko-oszustwom-zdje,nId,6367480)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 12:44:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-uczniowie-pisza-egzaminy-w-czapkach-przeciwko-oszustwom-zdje,nId,6367480"><img align="left" alt="Uczniowie piszą egzaminy w &quot;czapkach przeciwko oszustwom&quot;. Zdjęcia hitem sieci" src="https://i.iplsc.com/uczniowie-pisza-egzaminy-w-czapkach-przeciwko-oszustwom-zdje/000G8TRHIMK1HAY2-C321.jpg" /></a>W sieci pojawiły się zdjęcia uczniów z Filipin, którzy egzaminy na studia piszą w specjalnych &quot;czapkach przeciwko oszustwom&quot;. Fotografie niekonwencjonalnych nakryć głowy obiegły internet.</p><br clear="all" />

## Andrzej Duda odniósł się do swojej rozmowy z prezydentem Iranu
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-andrzej-duda-odniosl-sie-do-swojej-rozmowy-z-prezydentem-ira,nId,6367573](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-andrzej-duda-odniosl-sie-do-swojej-rozmowy-z-prezydentem-ira,nId,6367573)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 12:33:59+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-andrzej-duda-odniosl-sie-do-swojej-rozmowy-z-prezydentem-ira,nId,6367573"><img align="left" alt="Andrzej Duda odniósł się do swojej rozmowy z prezydentem Iranu" src="https://i.iplsc.com/andrzej-duda-odniosl-sie-do-swojej-rozmowy-z-prezydentem-ira/000G8U1ZJ40M8APP-C321.jpg" /></a>Rozmowa z prezydentem Iranu rzeczywiście odbyła się, jesteśmy w tym kraju przyjmowani z szacunkiem. Podejmujemy różne działania, aby życie Ukraińców nie było rujnowane, żeby ich domy nie były bombardowane - powiedział prezydent Andrzej Duda.</p><br clear="all" />

## Rosja chce danych od ONZ i żąda korekty umowy w sprawie zboża
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-chce-danych-od-onz-i-zada-korekty-umowy-w-sprawie-zboz,nId,6367506](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-chce-danych-od-onz-i-zada-korekty-umowy-w-sprawie-zboz,nId,6367506)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 12:08:02+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-chce-danych-od-onz-i-zada-korekty-umowy-w-sprawie-zboz,nId,6367506"><img align="left" alt="Rosja chce danych od ONZ i żąda korekty umowy w sprawie zboża" src="https://i.iplsc.com/rosja-chce-danych-od-onz-i-zada-korekty-umowy-w-sprawie-zboz/000G8TL35H3WCXQX-C321.jpg" /></a>Rosyjski minister spraw zagranicznych Siergiej Ławrow poinformował, że Moskwa zwróciła się do Organizacji Narodów Zjednoczonych o dane dotyczące przeznaczenia i odbiorców końcowych ukraińskich dostaw zboża. Podkreślił, że od tego będą zależeć &quot;korekty&quot; umowy o odblokowaniu ukraińskiego eksportu zboża przez Morze Czarne.</p><br clear="all" />

## Rzecznik MSZ wskazał nowego wiceszefa resortu. To poseł PiS
 - [https://wydarzenia.interia.pl/kraj/news-rzecznik-msz-wskazal-nowego-wiceszefa-resortu-to-posel-pis,nId,6367522](https://wydarzenia.interia.pl/kraj/news-rzecznik-msz-wskazal-nowego-wiceszefa-resortu-to-posel-pis,nId,6367522)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 11:28:33+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rzecznik-msz-wskazal-nowego-wiceszefa-resortu-to-posel-pis,nId,6367522"><img align="left" alt="Rzecznik MSZ wskazał nowego wiceszefa resortu. To poseł PiS" src="https://i.iplsc.com/rzecznik-msz-wskazal-nowego-wiceszefa-resortu-to-posel-pis/000G8TOP4LOKUKBV-C321.jpg" /></a>Poseł Arkadiusz Mularczyk zostanie w najbliższym czasie wiceministrem spraw zagranicznych - przekazał rzecznik MSZ Łukasz Jasina podczas konferencji prasowej w Jordanii. To skutek zmiany stanowiska dotychczasowego wiceszefa dyplomacji Szymona Szynkowskiego vel Sęka, który objął urząd ministra ds. Unii Europejskiej.</p><br clear="all" />

## Media: Piloci Su-30 stracili przytomność w trakcie lotu. "To mógł być azot"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-piloci-su-30-stracili-przytomnosc-w-trakcie-lotu-to-mo,nId,6367476](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-piloci-su-30-stracili-przytomnosc-w-trakcie-lotu-to-mo,nId,6367476)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 11:12:49+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-piloci-su-30-stracili-przytomnosc-w-trakcie-lotu-to-mo,nId,6367476"><img align="left" alt="Media: Piloci Su-30 stracili przytomność w trakcie lotu. &quot;To mógł być azot&quot;" src="https://i.iplsc.com/media-piloci-su-30-stracili-przytomnosc-w-trakcie-lotu-to-mo/000G8TEH24GXAPN7-C321.jpg" /></a>Piloci myśliwca Su-30 mogli stracić przytomność - przekazują rosyjskie media. Według nieoficjalnych informacji w aparaturze tlenowej pilotów, których maszyna spadła na dom w Irkucku, mogły znajdować się resztki azotu. To kolejna katastrofa rosyjskiego samolotu w ostatnim czasie.</p><br clear="all" />

## Wpisów Sikorskiego użyła rosyjska propaganda. Ozdoba kieruje wniosek do ABW
 - [https://wydarzenia.interia.pl/kraj/news-wpisow-sikorskiego-uzyla-rosyjska-propaganda-ozdoba-kieruje-,nId,6367494](https://wydarzenia.interia.pl/kraj/news-wpisow-sikorskiego-uzyla-rosyjska-propaganda-ozdoba-kieruje-,nId,6367494)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 10:55:26+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wpisow-sikorskiego-uzyla-rosyjska-propaganda-ozdoba-kieruje-,nId,6367494"><img align="left" alt="Wpisów Sikorskiego użyła rosyjska propaganda. Ozdoba kieruje wniosek do ABW" src="https://i.iplsc.com/wpisow-sikorskiego-uzyla-rosyjska-propaganda-ozdoba-kieruje/000G8TENEDPEWE8Y-C321.jpg" /></a>Internetowy wpis Radosława Sikorskiego, w którym &quot;dziękował&quot; Stanom Zjednoczonym za uszkodzenie gazociągu Nord Stream, stał się przedmiotem debaty publicznej. Wykorzystała go również rosyjska propaganda. Teraz poseł Solidarnej Polski Jacek Ozdoba chce, by aktywność Sikorskiego prześledziła ABW.</p><br clear="all" />

## Jan Duda zostaje na stanowisku. Nie dopuszczono do głosowania
 - [https://wydarzenia.interia.pl/malopolskie/news-jan-duda-zostaje-na-stanowisku-nie-dopuszczono-do-glosowania,nId,6367486](https://wydarzenia.interia.pl/malopolskie/news-jan-duda-zostaje-na-stanowisku-nie-dopuszczono-do-glosowania,nId,6367486)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 10:50:49+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-jan-duda-zostaje-na-stanowisku-nie-dopuszczono-do-glosowania,nId,6367486"><img align="left" alt="Jan Duda zostaje na stanowisku. Nie dopuszczono do głosowania" src="https://i.iplsc.com/jan-duda-zostaje-na-stanowisku-nie-dopuszczono-do-glosowania/000E3AJF9WSA199H-C321.jpg" /></a>Przewodniczący Sejmiku Województwa Małopolskiego Jan Duda (PiS) pozostaje na stanowisku. W poniedziałek radni wojewódzcy mieli głosować nad projektem uchwały o jego odwołanie zgłoszony przez KO, ale - na wniosek ugrupowania rządzącego - do głosowania nie doszło.</p><br clear="all" />

## Iran. Media: Władze zatrzymały 10 agentów Mossadu
 - [https://wydarzenia.interia.pl/zagranica/news-iran-media-wladze-zatrzymaly-10-agentow-mossadu,nId,6367482](https://wydarzenia.interia.pl/zagranica/news-iran-media-wladze-zatrzymaly-10-agentow-mossadu,nId,6367482)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 10:48:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-iran-media-wladze-zatrzymaly-10-agentow-mossadu,nId,6367482"><img align="left" alt="Iran. Media: Władze zatrzymały 10 agentów Mossadu" src="https://i.iplsc.com/iran-media-wladze-zatrzymaly-10-agentow-mossadu/000G8TDQX5TRFRO1-C321.jpg" /></a>Władze Iranu aresztowały 10 agentów izraelskiej agencji wywiadowczej Mossad w prowincji Azerbejdżan Zachodni - podała agencja Fars. Izrael jak dotąd nie potwierdził tych doniesień, ani im nie zaprzeczył. W połowie października media informowały, że Izrael dostarcza Ukrainie informacji wywiadowczych o irańskich dronach używanych przez armię rosyjską. 

</p><br clear="all" />

## Związali, pobili i zostawili prawie nagiego. Okrutny finał libacji
 - [https://wydarzenia.interia.pl/pomorskie/news-zwiazali-pobili-i-zostawili-prawie-nagiego-okrutny-final-lib,nId,6367422](https://wydarzenia.interia.pl/pomorskie/news-zwiazali-pobili-i-zostawili-prawie-nagiego-okrutny-final-lib,nId,6367422)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 10:35:15+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-zwiazali-pobili-i-zostawili-prawie-nagiego-okrutny-final-lib,nId,6367422"><img align="left" alt="Związali, pobili i zostawili prawie nagiego. Okrutny finał libacji" src="https://i.iplsc.com/zwiazali-pobili-i-zostawili-prawie-nagiego-okrutny-final-lib/000G8T3QK657LFDM-C321.jpg" /></a>Policjanci z Gdańska zatrzymali trzech mężczyzn - dwóch 21-latków i 38-latka, którzy brutalnie pobili mężczyznę, rozebrali go do bielizny, skrępowali taśmą klejącą i zostawili na dworze.</p><br clear="all" />

## Mundial w oparach absurdu. Restrykcje dotyczą także alkoholu i seksu
 - [https://wydarzenia.interia.pl/zagranica/news-mundial-w-oparach-absurdu-restrykcje-dotycza-takze-alkoholu-,nId,6367421](https://wydarzenia.interia.pl/zagranica/news-mundial-w-oparach-absurdu-restrykcje-dotycza-takze-alkoholu-,nId,6367421)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 10:35:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-mundial-w-oparach-absurdu-restrykcje-dotycza-takze-alkoholu-,nId,6367421"><img align="left" alt="Mundial w oparach absurdu. Restrykcje dotyczą także alkoholu i seksu" src="https://i.iplsc.com/mundial-w-oparach-absurdu-restrykcje-dotycza-takze-alkoholu/000G8TEPVSEKOPIH-C321.jpg" /></a>O mistrzostwach świata w Katarze mówi się sporo jeszcze przed rozpoczęciem turnieju. Kontrowersje wywołało już samo przyznanie organizacji imprezy właśnie Katarowi. Poczynając od łamania praw człowieka, poprzez termin rozegrania turnieju, po ograniczenia dotyczące możliwości spożywania alkoholu a nawet uprawiania seksu - argumenty przeciwko katarskiej kandydaturze można mnożyć.</p><br clear="all" />

## Rosja. Wzywał na antenie do topienia ukraińskich dzieci. Teraz przeprasza
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wzywal-na-antenie-do-topienia-ukrainskich-dzieci-teraz,nId,6367412](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wzywal-na-antenie-do-topienia-ukrainskich-dzieci-teraz,nId,6367412)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 10:19:51+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-wzywal-na-antenie-do-topienia-ukrainskich-dzieci-teraz,nId,6367412"><img align="left" alt="Rosja. Wzywał na antenie do topienia ukraińskich dzieci. Teraz przeprasza" src="https://i.iplsc.com/rosja-wzywal-na-antenie-do-topienia-ukrainskich-dzieci-teraz/000G8T4NRA3LPTYF-C321.jpg" /></a>Prezenter rosyjskiej telewizji Anton Krasowski przeprosił w poniedziałek za wezwanie do topienia ukraińskich dzieci, ponieważ rosyjski państwowy komitet śledczy poinformował, że bada jego wypowiedź. Stacja zawiesiła mężczyznę i wydała oświadczenie.</p><br clear="all" />

## "Największy organizm na świecie" w polskich lasach. Czy jest jadalny?
 - [https://wydarzenia.interia.pl/ciekawostki/news-najwiekszy-organizm-na-swiecie-w-polskich-lasach-czy-jest-ja,nId,6367276](https://wydarzenia.interia.pl/ciekawostki/news-najwiekszy-organizm-na-swiecie-w-polskich-lasach-czy-jest-ja,nId,6367276)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 10:15:45+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-najwiekszy-organizm-na-swiecie-w-polskich-lasach-czy-jest-ja,nId,6367276"><img align="left" alt="&quot;Największy organizm na świecie&quot; w polskich lasach. Czy jest jadalny?" src="https://i.iplsc.com/najwiekszy-organizm-na-swiecie-w-polskich-lasach-czy-jest-ja/000G8RZLM1BHHYF9-C321.jpg" /></a>Opieńki na pierwszy rzut oka wyglądają niepozornie, jednak głęboko pod powierzchnią skrywają &quot;mroczną tajemnicę&quot;. Niewiele osób zdaje sobie sprawę z tego, że są &quot;największymi organizmami na świecie&quot;. Mogą jednak powoli zabijać korzenie drzew. A to nie koniec sekretów tych fascynujących grzybów.</p><br clear="all" />

## Ten grzyb skrywa "mroczną tajemnicę". Czy jest jadalny?
 - [https://wydarzenia.interia.pl/ciekawostki/news-ten-grzyb-skrywa-mroczna-tajemnice-czy-jest-jadalny,nId,6367276](https://wydarzenia.interia.pl/ciekawostki/news-ten-grzyb-skrywa-mroczna-tajemnice-czy-jest-jadalny,nId,6367276)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 10:15:45+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-ten-grzyb-skrywa-mroczna-tajemnice-czy-jest-jadalny,nId,6367276"><img align="left" alt="Ten grzyb skrywa &quot;mroczną tajemnicę&quot;. Czy jest jadalny?" src="https://i.iplsc.com/ten-grzyb-skrywa-mroczna-tajemnice-czy-jest-jadalny/000G8RZLM1BHHYF9-C321.jpg" /></a>Opieńki na pierwszy rzut oka wyglądają niepozornie, jednak głęboko pod powierzchnią skrywają &quot;mroczną tajemnicę&quot;. Niewiele osób zdaje sobie sprawę z tego, że są &quot;największymi organizmami na świecie&quot;. W polskich lasach bardzo łatwo można pomylić je z innymi, trującymi grzybami. Opieńki miodowe i opieńki ciemne mają wiele sekretów, dlatego podajemy krótki opis tych grzybów i wyjaśniamy, czy są jadalne.</p><br clear="all" />

## Tornado i gwałtowne burze nawiedziły północną Francję. Straty są poważne
 - [https://wydarzenia.interia.pl/zagranica/news-tornado-i-gwaltowne-burze-nawiedzily-polnocna-francje-straty,nId,6367415](https://wydarzenia.interia.pl/zagranica/news-tornado-i-gwaltowne-burze-nawiedzily-polnocna-francje-straty,nId,6367415)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 10:12:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tornado-i-gwaltowne-burze-nawiedzily-polnocna-francje-straty,nId,6367415"><img align="left" alt="Tornado i gwałtowne burze nawiedziły północną Francję. Straty są poważne" src="https://i.iplsc.com/tornado-i-gwaltowne-burze-nawiedzily-polnocna-francje-straty/000G8T3M4CE1WIWX-C321.jpg" /></a>Niedzielne gwałtowne burze oraz tornado spowodowały poważne zniszczenia w trzech departamentach regionu na północy Francji. Wichura zniszczyła domy, zerwała dach z kościoła i powywracała samochody, a jedna osoba odniosła niegroźne obrażenia. - Odbudowa tego wszystkiego zajmie nam miesiące - relacjonował mer miasteczka Bihucourt.</p><br clear="all" />

## Kradną drewno, wycinają drzewa. Za "darmowy" opał mogą surowo zapłacić
 - [https://wydarzenia.interia.pl/raporty/raport-kryzys-energetyczny/aktualnosci/news-kradna-drewno-wycinaja-drzewa-za-darmowy-opal-moga-surowo-za,nId,6367314](https://wydarzenia.interia.pl/raporty/raport-kryzys-energetyczny/aktualnosci/news-kradna-drewno-wycinaja-drzewa-za-darmowy-opal-moga-surowo-za,nId,6367314)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 10:11:11+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-kryzys-energetyczny/aktualnosci/news-kradna-drewno-wycinaja-drzewa-za-darmowy-opal-moga-surowo-za,nId,6367314"><img align="left" alt="Kradną drewno, wycinają drzewa. Za &quot;darmowy&quot; opał mogą surowo zapłacić" src="https://i.iplsc.com/kradna-drewno-wycinaja-drzewa-za-darmowy-opal-moga-surowo-za/000G8S66I420T5AY-C321.jpg" /></a>70-latek i jego 66-letni brat zostali zatrzymani na gorącym uczynku, gdy układali pociętą sosnę na wozie. Zauważył ich właściciel działki leśnej w gminie Baranów (woj. lubelskie). W tym samym województwie, kilka dni wcześniej, policjanci zatrzymali trzech 23-latków, którzy sprzedawali drewno w sieci - dla swoich klientów wyrąbali ponad 170 drzew. W woj. świętokrzyskim od początku września takich kradzieży było kilkanaście. Lasy Państwowe w rozmowie z Interią przyznają, że co roku jesienią zainteresowanie drewnem z lasu, również tym...</p><br clear="all" />

## Wywiad: Rosjanie planują obronę w Chersoniu. Informacje o ewakuacji nieprawdziwe
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wywiad-rosjanie-planuja-obrone-w-chersoniu-informacje-o-ewak,nId,6367383](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wywiad-rosjanie-planuja-obrone-w-chersoniu-informacje-o-ewak,nId,6367383)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 09:52:58+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wywiad-rosjanie-planuja-obrone-w-chersoniu-informacje-o-ewak,nId,6367383"><img align="left" alt="Wywiad: Rosjanie planują obronę w Chersoniu. Informacje o ewakuacji nieprawdziwe" src="https://i.iplsc.com/wywiad-rosjanie-planuja-obrone-w-chersoniu-informacje-o-ewak/000G8SUIWXWUI0II-C321.jpg" /></a>Rosjanie stworzyli iluzję, że wycofują się z Chersonia, a w rzeczywistości wysyłają tam nowe wojska i przygotowują ulice okupowanego miasta do obrony - powiedział w wywiadzie dla portalu Ukrainska Prawda szef wywiadu wojskowego Ukrainy Kyryło Budanow.</p><br clear="all" />

## Sukcesy Izraela w Syrii. Poważne uderzenie w wojskową infrastrukturę Iranu
 - [https://wydarzenia.interia.pl/zagranica/news-sukcesy-izraela-w-syrii-powazne-uderzenie-w-wojskowa-infrast,nId,6367355](https://wydarzenia.interia.pl/zagranica/news-sukcesy-izraela-w-syrii-powazne-uderzenie-w-wojskowa-infrast,nId,6367355)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 09:40:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sukcesy-izraela-w-syrii-powazne-uderzenie-w-wojskowa-infrast,nId,6367355"><img align="left" alt="Sukcesy Izraela w Syrii. Poważne uderzenie w wojskową infrastrukturę Iranu" src="https://i.iplsc.com/sukcesy-izraela-w-syrii-powazne-uderzenie-w-wojskowa-infrast/000G8SP7KR7NNCPM-C321.jpg" /></a>Armia Izraela zniszczyła około 90 proc. wojskowej infrastruktury Iranu w Syrii. W ten sposób zlikwidowano szlaki irańskich dostaw broni do tego kraju - poinformował dziennik &quot;Jerusalem Post&quot;, powołując się na źródła w izraelskiej administracji państwowej.</p><br clear="all" />

## Ukraina. Przerwy w dostawie prądu. W windach w Kijowie pojawiły się "worki życia"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-przerwy-w-dostawie-pradu-w-windach-w-kijowie-pojawil,nId,6367340](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-przerwy-w-dostawie-pradu-w-windach-w-kijowie-pojawil,nId,6367340)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 09:21:45+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-przerwy-w-dostawie-pradu-w-windach-w-kijowie-pojawil,nId,6367340"><img align="left" alt="Ukraina. Przerwy w dostawie prądu. W windach w Kijowie pojawiły się &quot;worki życia&quot;" src="https://i.iplsc.com/ukraina-przerwy-w-dostawie-pradu-w-windach-w-kijowie-pojawil/000G8SPOJQ39099J-C321.jpg" /></a>W prawie wszystkich regionach Ukrainy wprowadzono ograniczenia w zużyciu prądu. Mieszkańcy Kijowa nie będą mieli dostępu do niego przez osiem godzin na dobę. W windach pojawiły się tzw. worki życia, w przypadku utknięcia w nich z powodu braku prądu.</p><br clear="all" />

## Rosyjskie rodziny pochowały pierwszych zmobilizowanych. Nie kryją żalu
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-rodziny-pochowaly-pierwszych-zmobilizowanych-nie-k,nId,6367373](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-rodziny-pochowaly-pierwszych-zmobilizowanych-nie-k,nId,6367373)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 09:10:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-rodziny-pochowaly-pierwszych-zmobilizowanych-nie-k,nId,6367373"><img align="left" alt="Rosyjskie rodziny pochowały pierwszych zmobilizowanych. Nie kryją żalu" src="https://i.iplsc.com/rosyjskie-rodziny-pochowaly-pierwszych-zmobilizowanych-nie-k/000G8SOMBF908658-C321.jpg" /></a>Buriacja pochowała pierwszych zmarłych na Ukrainie zmobilizowanych z tego regionu. Pogrzeb odbył się we wsi Ilka, skąd pochodził 23-letni Dmitrij Sidorow. Poborowy zmarł 4 października, 12 dni po mobilizacji. Samochód, którym podróżował, eksplodował. Trumna z żołnierzem nie była otwierana.</p><br clear="all" />

## Ukraińcy utarli nosa Łukaszance. Wywiesili flagi, których nie znosi
 - [https://wydarzenia.interia.pl/zagranica/news-ukraincy-utarli-nosa-lukaszance-wywiesili-flagi-ktorych-nie-,nId,6367362](https://wydarzenia.interia.pl/zagranica/news-ukraincy-utarli-nosa-lukaszance-wywiesili-flagi-ktorych-nie-,nId,6367362)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 09:07:12+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ukraincy-utarli-nosa-lukaszance-wywiesili-flagi-ktorych-nie-,nId,6367362"><img align="left" alt="Ukraińcy utarli nosa Łukaszance. Wywiesili flagi, których nie znosi" src="https://i.iplsc.com/ukraincy-utarli-nosa-lukaszance-wywiesili-flagi-ktorych-nie/000G8SMUUNT5B3JG-C321.jpg" /></a>Biało-czerwono-białe flagi białoruskiej opozycji zawisły po ukraińskiej stronie granicy z Białorusią. Fakt zirytował reżim Łukaszenki do tego stopnia, że propagandyści z telewizji państwowej przygotowali o tym cały materiał, nazywając sytuację &quot;oburzającą prowokacją&quot;.</p><br clear="all" />

## Premier o proteście związkowców: Rosja odpowiada za skutki gospodarcze
 - [https://wydarzenia.interia.pl/kraj/news-premier-o-protescie-zwiazkowcow-rosja-odpowiada-za-skutki-go,nId,6367335](https://wydarzenia.interia.pl/kraj/news-premier-o-protescie-zwiazkowcow-rosja-odpowiada-za-skutki-go,nId,6367335)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 08:49:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-o-protescie-zwiazkowcow-rosja-odpowiada-za-skutki-go,nId,6367335"><img align="left" alt="Premier o proteście związkowców: Rosja odpowiada za skutki gospodarcze" src="https://i.iplsc.com/premier-o-protescie-zwiazkowcow-rosja-odpowiada-za-skutki-go/000G8SKGCF7PXK1F-C321.jpg" /></a>Premier Morawiecki podczas wystąpienia w bazie lotniczej w Łasku odniósł się do akcji związkowców Sierpnia 80 i próby zamurowania jego biura poselskiego. - W jakimś stopniu adresatem wielu słusznych postulatów, z wielu stron płynących, powinien być Putin i jego zbiry. Krem, Moskwa i jej polityka - ocenił.</p><br clear="all" />

## USA. Zastrzelił pielęgniarki w szpitalu, gdy jego dziewczyna rodziła
 - [https://wydarzenia.interia.pl/zagranica/news-usa-zastrzelil-pielegniarki-w-szpitalu-gdy-jego-dziewczyna-r,nId,6367331](https://wydarzenia.interia.pl/zagranica/news-usa-zastrzelil-pielegniarki-w-szpitalu-gdy-jego-dziewczyna-r,nId,6367331)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 08:44:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-zastrzelil-pielegniarki-w-szpitalu-gdy-jego-dziewczyna-r,nId,6367331"><img align="left" alt="USA. Zastrzelił pielęgniarki w szpitalu, gdy jego dziewczyna rodziła" src="https://i.iplsc.com/usa-zastrzelil-pielegniarki-w-szpitalu-gdy-jego-dziewczyna-r/000G8SLBYE37P393-C321.jpg" /></a>30-letni mężczyzna został oskarżony o zabicie dwóch pielęgniarek. Otworzył ogień, podczas gdy jego dziewczyna rodziła w szpitalu w Dallas w amerykańskim stanie Teksas - przekazał Daily Mail. Jak dodano, napastnik był na zwolnieniu warunkowym. </p><br clear="all" />

## Koronawirus w Polsce. Ministerstwo Zdrowia podało najnowsze dane
 - [https://wydarzenia.interia.pl/kraj/news-koronawirus-w-polsce-ministerstwo-zdrowia-podalo-najnowsze-d,nId,6367346](https://wydarzenia.interia.pl/kraj/news-koronawirus-w-polsce-ministerstwo-zdrowia-podalo-najnowsze-d,nId,6367346)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 08:28:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-koronawirus-w-polsce-ministerstwo-zdrowia-podalo-najnowsze-d,nId,6367346"><img align="left" alt="Koronawirus w Polsce. Ministerstwo Zdrowia podało najnowsze dane" src="https://i.iplsc.com/koronawirus-w-polsce-ministerstwo-zdrowia-podalo-najnowsze-d/000CQWJBME4DKR5D-C321.jpg" /></a>Ministerstwo Zdrowia przekazało we wtorek 24 października najświeższe dane dotyczące koronawirusa w naszym kraju. W Polsce wykryto 173 nowe przypadki COVID-19. W ciągu ostatniej doby nie odnotowano nowych zgonów</p><br clear="all" />

## Koronawirus w Polsce. Ministerstwo Zdrowia podało najnowszy bilans
 - [https://wydarzenia.interia.pl/kraj/news-koronawirus-w-polsce-ministerstwo-zdrowia-podalo-najnowszy-b,nId,6367346](https://wydarzenia.interia.pl/kraj/news-koronawirus-w-polsce-ministerstwo-zdrowia-podalo-najnowszy-b,nId,6367346)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 08:28:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-koronawirus-w-polsce-ministerstwo-zdrowia-podalo-najnowszy-b,nId,6367346"><img align="left" alt="Koronawirus w Polsce. Ministerstwo Zdrowia podało najnowszy bilans" src="https://i.iplsc.com/koronawirus-w-polsce-ministerstwo-zdrowia-podalo-najnowszy-b/000G8SHTMKY87EBH-C321.jpg" /></a>Ministerstwo Zdrowia przekazało najświeższe dane dotyczące koronawirusa w naszym kraju. Minionej doby wykryto 173 nowe przypadki zakażeń - to mniej niż w poprzedni poniedziałek i dwa tygodnie temu. Nie odnotowano natomiast żadnych zgonów.</p><br clear="all" />

## Brazylia: Polityk rzucał granatami w policjantów podczas próby aresztowania
 - [https://wydarzenia.interia.pl/zagranica/news-brazylia-polityk-rzucal-granatami-w-policjantow-podczas-prob,nId,6367305](https://wydarzenia.interia.pl/zagranica/news-brazylia-polityk-rzucal-granatami-w-policjantow-podczas-prob,nId,6367305)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 08:28:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-brazylia-polityk-rzucal-granatami-w-policjantow-podczas-prob,nId,6367305"><img align="left" alt="Brazylia: Polityk rzucał granatami w policjantów podczas próby aresztowania" src="https://i.iplsc.com/brazylia-polityk-rzucal-granatami-w-policjantow-podczas-prob/000G8S845HXBOKQ2-C321.jpg" /></a>Roberto Jefferson podczas próby aresztowania rzucał w policjantów granatami. Ranił przy tym dwóch funkcjonariuszy. Teraz polityk, który należy do sojuszników prezydenta Jaira Bolsonaro, przebywa w areszcie.</p><br clear="all" />

## Związkowcy przed biurem Morawieckiego. Chcieli zamurować wejście
 - [https://wydarzenia.interia.pl/kraj/news-zwiazkowcy-przed-biurem-morawieckiego-chcieli-zamurowac-wejs,nId,6367326](https://wydarzenia.interia.pl/kraj/news-zwiazkowcy-przed-biurem-morawieckiego-chcieli-zamurowac-wejs,nId,6367326)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 07:57:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zwiazkowcy-przed-biurem-morawieckiego-chcieli-zamurowac-wejs,nId,6367326"><img align="left" alt="Związkowcy przed biurem Morawieckiego. Chcieli zamurować wejście" src="https://i.iplsc.com/zwiazkowcy-przed-biurem-morawieckiego-chcieli-zamurowac-wejs/000G8S70WTC87AVL-C321.jpg" /></a>Działacze związku Sierpień'80 próbowali zamurować wejście do biura poselskiego Mateusza Morawieckiego. Jak sami mówią, premier nie chce się z nimi spotkać, więc biuro

## "Magiczne grzybki". Szwedzi badają, czy pomagają na depresję
 - [https://wydarzenia.interia.pl/ciekawostki/news-magiczne-grzybki-szwedzi-badaja-czy-pomagaja-na-depresje,nId,6367310](https://wydarzenia.interia.pl/ciekawostki/news-magiczne-grzybki-szwedzi-badaja-czy-pomagaja-na-depresje,nId,6367310)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 07:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-magiczne-grzybki-szwedzi-badaja-czy-pomagaja-na-depresje,nId,6367310"><img align="left" alt="&quot;Magiczne grzybki&quot;. Szwedzi badają, czy pomagają na depresję" src="https://i.iplsc.com/magiczne-grzybki-szwedzi-badaja-czy-pomagaja-na-depresje/000G8S3ZOG8R8TGU-C321.jpg" /></a>Szwedzcy naukowcy sprawdzają, czy znajdująca się w grzybkach halucynogennych psylocybina może być odpowiednią metodą w leczeniu klinicznym depresji. </p><br clea

## System o nich zapomniał. "Damian nie chce być tam, gdzie wciąż ktoś umiera"
 - [https://wydarzenia.interia.pl/kraj/news-system-o-nich-zapomnial-damian-nie-chce-byc-tam-gdzie-wciaz-,nId,6364243](https://wydarzenia.interia.pl/kraj/news-system-o-nich-zapomnial-damian-nie-chce-byc-tam-gdzie-wciaz-,nId,6364243)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 07:29:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-system-o-nich-zapomnial-damian-nie-chce-byc-tam-gdzie-wciaz-,nId,6364243"><img align="left" alt="System o nich zapomniał. &quot;Damian nie chce być tam, gdzie wciąż ktoś umiera&quot;" src="https://i.iplsc.com/system-o-nich-zapomnial-damian-nie-chce-byc-tam-gdzie-wciaz/000G8S5ZXUGP94UX-C321.jpg" /></a>Piekł ciastka, uwielbiał &quot;rządzić&quot; domownikami, cieszył się, że jest komuś potrzebny. Wszystko się zmieniło, kiedy skończył 25 lat. Od t

## Kwaśniewski o przyszłości Putina: Mnie daje do myślenia, że Nawalny żyje
 - [https://wydarzenia.interia.pl/kraj/news-kwasniewski-o-przyszlosci-putina-mnie-daje-do-myslenia-ze-na,nId,6367277](https://wydarzenia.interia.pl/kraj/news-kwasniewski-o-przyszlosci-putina-mnie-daje-do-myslenia-ze-na,nId,6367277)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 07:25:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kwasniewski-o-przyszlosci-putina-mnie-daje-do-myslenia-ze-na,nId,6367277"><img align="left" alt="Kwaśniewski o przyszłości Putina: Mnie daje do myślenia, że Nawalny żyje" src="https://i.iplsc.com/kwasniewski-o-przyszlosci-putina-mnie-daje-do-myslenia-ze-na/000G8RZ8UOSXE7TH-C321.jpg" /></a>- To mogłoby oznaczać, że jest przygotowywany wariant alternatywny, gdyby to się wszystko posypało. (...) Putina poświęcą w pierwszej kolejności - powiedział 

## Huragan Roslyn uderzył w Meksyk. Są pierwsze ofiary śmiertelne
 - [https://wydarzenia.interia.pl/zagranica/news-huragan-roslyn-uderzyl-w-meksyk-sa-pierwsze-ofiary-smierteln,nId,6367284](https://wydarzenia.interia.pl/zagranica/news-huragan-roslyn-uderzyl-w-meksyk-sa-pierwsze-ofiary-smierteln,nId,6367284)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 07:24:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-huragan-roslyn-uderzyl-w-meksyk-sa-pierwsze-ofiary-smierteln,nId,6367284"><img align="left" alt="Huragan Roslyn uderzył w Meksyk. Są pierwsze ofiary śmiertelne" src="https://i.iplsc.com/huragan-roslyn-uderzyl-w-meksyk-sa-pierwsze-ofiary-smierteln/000G8S3YDBFA4QDM-C321.jpg" /></a>Dwie osoby zginęły wskutek huraganu Rosyln, który w niedzielę uderzył w zachodnie wybrzeże Meksyku - podały lokalne władze. Po wejściu na ląd jego siła zaczęła sto

## SG: 72 cudzoziemców próbowało przedostać się z Białorusi do Polski
 - [https://wydarzenia.interia.pl/kraj/news-sg-72-cudzoziemcow-probowalo-przedostac-sie-z-bialorusi-do-p,nId,6367301](https://wydarzenia.interia.pl/kraj/news-sg-72-cudzoziemcow-probowalo-przedostac-sie-z-bialorusi-do-p,nId,6367301)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 07:20:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sg-72-cudzoziemcow-probowalo-przedostac-sie-z-bialorusi-do-p,nId,6367301"><img align="left" alt="SG: 72 cudzoziemców próbowało przedostać się z Białorusi do Polski" src="https://i.iplsc.com/sg-72-cudzoziemcow-probowalo-przedostac-sie-z-bialorusi-do-p/000G8S2TMHJC16SI-C321.jpg" /></a>72 cudzoziemców próbowało w niedzielę nielegalnie dostać się do Polski przez granicę z Białorusią, m.in. przez rzeki graniczne. Zatrzymano również trzech &quot;kuri

## Salman Rushdie stracił wzrok w jednym oku. Powodem atak nożownika
 - [https://wydarzenia.interia.pl/zagranica/news-salman-rushdie-stracil-wzrok-w-jednym-oku-powodem-atak-nozow,nId,6367268](https://wydarzenia.interia.pl/zagranica/news-salman-rushdie-stracil-wzrok-w-jednym-oku-powodem-atak-nozow,nId,6367268)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 07:17:49+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-salman-rushdie-stracil-wzrok-w-jednym-oku-powodem-atak-nozow,nId,6367268"><img align="left" alt="Salman Rushdie stracił wzrok w jednym oku. Powodem atak nożownika" src="https://i.iplsc.com/salman-rushdie-stracil-wzrok-w-jednym-oku-powodem-atak-nozow/000G8RNQ17W087AT-C321.jpg" /></a>Pisarz Salman Rushdie stracił wzrok w jednym oku i władzę w lewej ręce w rezultacie ataku nożownika w sierpniu br., w stanie Nowy Jork - poinformował jego agent

## Władimir Oseczkin: Byli funkcjonariusze reżimu Putina uciekają z Rosji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wladimir-oseczkin-byli-funkcjonariusze-rezimu-putina-uciekaj,nId,6367292](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wladimir-oseczkin-byli-funkcjonariusze-rezimu-putina-uciekaj,nId,6367292)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 07:10:43+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wladimir-oseczkin-byli-funkcjonariusze-rezimu-putina-uciekaj,nId,6367292"><img align="left" alt="Władimir Oseczkin: Byli funkcjonariusze reżimu Putina uciekają z Rosji" src="https://i.iplsc.com/wladimir-oseczkin-byli-funkcjonariusze-rezimu-putina-uciekaj/000G8S2DMPPG21XO-C321.jpg" /></a>Byli rosyjscy urzędnicy, agenci, a nawet najemnicy z Grupy Wagnera uciekają z Rosji i chcą zeznawać o zbrodniach reżimu Puti

## ISW: Rozmowy ministra obrony Rosji mają na celu zastraszenie NATO
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-rozmowy-ministra-obrony-rosji-maja-na-celu-zastraszenie-,nId,6367283](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-rozmowy-ministra-obrony-rosji-maja-na-celu-zastraszenie-,nId,6367283)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 06:54:06+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-rozmowy-ministra-obrony-rosji-maja-na-celu-zastraszenie-,nId,6367283"><img align="left" alt="ISW: Rozmowy ministra obrony Rosji mają na celu zastraszenie NATO" src="https://i.iplsc.com/isw-rozmowy-ministra-obrony-rosji-maja-na-celu-zastraszenie/000G8RTU8UOVC14K-C321.jpg" /></a>&quot;Słowa Szojgu, wzmacniane przez przekaz rosyjskich mediów państwowych, mają najpewniej na celu zastraszenie krajów zachodnich

## Rosyjski propagandysta pojechał do Ukrainy. Stanął na minie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjski-propagandysta-pojechal-do-ukrainy-stanal-na-minie,nId,6367271](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjski-propagandysta-pojechal-do-ukrainy-stanal-na-minie,nId,6367271)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 06:50:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjski-propagandysta-pojechal-do-ukrainy-stanal-na-minie,nId,6367271"><img align="left" alt="Rosyjski propagandysta pojechał do Ukrainy. Stanął na minie" src="https://i.iplsc.com/rosyjski-propagandysta-pojechal-do-ukrainy-stanal-na-minie/000G8RK8530T420V-C321.jpg" /></a>Rosyjski propagandysta Siemion Pegow został ranny pod Donieckiem w trakcie kręcenia materiału o wojnie w Ukrainie. Według rosyjskich mediów

## Małopolskie. Pożar samochodu na autostradzie. Utworzył się kilkumetrowy korek
 - [https://wydarzenia.interia.pl/malopolskie/news-malopolskie-pozar-samochodu-na-autostradzie-utworzyl-sie-kil,nId,6367270](https://wydarzenia.interia.pl/malopolskie/news-malopolskie-pozar-samochodu-na-autostradzie-utworzyl-sie-kil,nId,6367270)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 06:48:17+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-malopolskie-pozar-samochodu-na-autostradzie-utworzyl-sie-kil,nId,6367270"><img align="left" alt="Małopolskie. Pożar samochodu na autostradzie. Utworzył się kilkumetrowy korek" src="https://i.iplsc.com/malopolskie-pozar-samochodu-na-autostradzie-utworzyl-sie-kil/000G8ROG6EIEH9S7-C321.jpg" /></a>W wyniku pożaru samochodu na pasie awaryjnym autostrady A4 w Niepołomicach utworzył się kilkumetrowy korek w kierunku Krakowa. Ruch odbywa się lew

## Ukraina niszczy kolejny sprzęt wroga. Nagranie z ataku na S-300
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-niszczy-kolejny-sprzet-wroga-nagranie-z-ataku-na-s-3,nId,6367260](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-niszczy-kolejny-sprzet-wroga-nagranie-z-ataku-na-s-3,nId,6367260)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 06:32:44+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-niszczy-kolejny-sprzet-wroga-nagranie-z-ataku-na-s-3,nId,6367260"><img align="left" alt="Ukraina niszczy kolejny sprzęt wroga. Nagranie z ataku na S-300" src="https://i.iplsc.com/ukraina-niszczy-kolejny-sprzet-wroga-nagranie-z-ataku-na-s-3/000G8RLFS8ORU0DW-C321.jpg" /></a>Ukraina nie zwalnia tempa i niszczy kolejny rosyjski sprzęt. Tym razem opublikowano nagranie, na którym widać, jak z powietrza ukra

## Media: Izrael przekazał Ukrainie ważne informacje. Chodzi o irańskie drony
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-izrael-przekazal-ukrainie-wazne-informacje-chodzi-o-ir,nId,6367261](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-izrael-przekazal-ukrainie-wazne-informacje-chodzi-o-ir,nId,6367261)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 06:24:26+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-media-izrael-przekazal-ukrainie-wazne-informacje-chodzi-o-ir,nId,6367261"><img align="left" alt="Media: Izrael przekazał Ukrainie ważne informacje. Chodzi o irańskie drony" src="https://i.iplsc.com/media-izrael-przekazal-ukrainie-wazne-informacje-chodzi-o-ir/000G8RH1VHSI5AY2-C321.jpg" /></a>Izrael przekazał Ukrainie dane wywiadowcze, przydatne do walki z irańskimi dronami - donosi amerykański &quot;New York T

## Wielka woda zalewa Nigerię. Giną ludzie, eksport gazu zagrożony
 - [https://wydarzenia.interia.pl/zagranica/news-wielka-woda-zalewa-nigerie-gina-ludzie-eksport-gazu-zagrozon,nId,6367264](https://wydarzenia.interia.pl/zagranica/news-wielka-woda-zalewa-nigerie-gina-ludzie-eksport-gazu-zagrozon,nId,6367264)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 06:18:12+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wielka-woda-zalewa-nigerie-gina-ludzie-eksport-gazu-zagrozon,nId,6367264"><img align="left" alt="Wielka woda zalewa Nigerię. Giną ludzie, eksport gazu zagrożony" src="https://i.iplsc.com/wielka-woda-zalewa-nigerie-gina-ludzie-eksport-gazu-zagrozon/000G8RNGOKR8SDHB-C321.jpg" /></a>Tragiczne w skutkach powodzie nawiedzają Nigerię. Nie żyje już ponad 600 osób, a około 1,4 miliona żywioł zmusił do ucieczki. Woda zniszczyła 440 000 hektarów upr

## Zderzenie pięciu aut na obwodnicy Trójmiasta. Są utrudnienia
 - [https://wydarzenia.interia.pl/pomorskie/news-zderzenie-pieciu-aut-na-obwodnicy-trojmiasta-sa-utrudnienia,nId,6367259](https://wydarzenia.interia.pl/pomorskie/news-zderzenie-pieciu-aut-na-obwodnicy-trojmiasta-sa-utrudnienia,nId,6367259)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 06:12:10+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-zderzenie-pieciu-aut-na-obwodnicy-trojmiasta-sa-utrudnienia,nId,6367259"><img align="left" alt="Zderzenie pięciu aut na obwodnicy Trójmiasta. Są utrudnienia" src="https://i.iplsc.com/zderzenie-pieciu-aut-na-obwodnicy-trojmiasta-sa-utrudnienia/000E4TWEMCWITNS2-C321.jpg" /></a>Doszło do wypadku na obwodnicy Trójmiasta. Pomiędzy węzłem Gdynia Port a Gdynia Chwarzno zderzyło się pięć aut osobowych. Na trasie są utrudnienia.</p><br clear="all" 

## Rosja przeszła do defensywy. Pokazali, jak budują umocnienia obronne
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-przeszla-do-defensywy-pokazali-jak-buduja-umocnienia-o,nId,6367253](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-przeszla-do-defensywy-pokazali-jak-buduja-umocnienia-o,nId,6367253)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 05:55:49+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-przeszla-do-defensywy-pokazali-jak-buduja-umocnienia-o,nId,6367253"><img align="left" alt="Rosja przeszła do defensywy. Pokazali, jak budują umocnienia obronne" src="https://i.iplsc.com/rosja-przeszla-do-defensywy-pokazali-jak-buduja-umocnienia-o/000G8RC27GO15OWL-C321.jpg" /></a>Na początku wojny Rosjanie chcieli zająć Kijów w trzy dni. W 243. dniu wojny budują zapory przeciwczołgowe w obawie przed ukra

## Zbrodnia w Miłoszycach. Zbigniew Ziobro wnosi kasację, chce wyższych kar
 - [https://wydarzenia.interia.pl/kraj/news-zbrodnia-w-miloszycach-zbigniew-ziobro-wnosi-kasacje-chce-wy,nId,6367250](https://wydarzenia.interia.pl/kraj/news-zbrodnia-w-miloszycach-zbigniew-ziobro-wnosi-kasacje-chce-wy,nId,6367250)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 05:47:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zbrodnia-w-miloszycach-zbigniew-ziobro-wnosi-kasacje-chce-wy,nId,6367250"><img align="left" alt="Zbrodnia w Miłoszycach. Zbigniew Ziobro wnosi kasację, chce wyższych kar" src="https://i.iplsc.com/zbrodnia-w-miloszycach-zbigniew-ziobro-wnosi-kasacje-chce-wy/000G8RBA9WVOT2SW-C321.jpg" /></a>Kara jest za niska - uważa Prokurator Generalny Zbigniew Ziobro. Wniósł on do Sądu Najwyższego kasację na niekorzyść dwójki sprawców skazanych za gwałt i zabó

## Dodatki do ogrzewania. Do kiedy można składać wnioski? Niektóre terminy już blisko
 - [https://wydarzenia.interia.pl/kraj/news-dodatki-do-ogrzewania-do-kiedy-mozna-skladac-wnioski-niektor,nId,6362066](https://wydarzenia.interia.pl/kraj/news-dodatki-do-ogrzewania-do-kiedy-mozna-skladac-wnioski-niektor,nId,6362066)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 05:42:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dodatki-do-ogrzewania-do-kiedy-mozna-skladac-wnioski-niektor,nId,6362066"><img align="left" alt="Dodatki do ogrzewania. Do kiedy można składać wnioski? Niektóre terminy już blisko" src="https://i.iplsc.com/dodatki-do-ogrzewania-do-kiedy-mozna-skladac-wnioski-niektor/000E3JAAIAVLBT8L-C321.jpg" /></a>Obecny sezon grzewczy jest szczególnie trudny ze względu na rosnące ceny opały i energii. Rząd, aby to zrekompensować, zaproponował dodatki do ogrze

## Wypadek lotniczy na Filipinach. Na pokładzie były 173 osoby
 - [https://wydarzenia.interia.pl/zagranica/news-wypadek-lotniczy-na-filipinach-na-pokladzie-byly-173-osoby,nId,6367231](https://wydarzenia.interia.pl/zagranica/news-wypadek-lotniczy-na-filipinach-na-pokladzie-byly-173-osoby,nId,6367231)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 05:30:11+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wypadek-lotniczy-na-filipinach-na-pokladzie-byly-173-osoby,nId,6367231"><img align="left" alt="Wypadek lotniczy na Filipinach. Na pokładzie były 173 osoby" src="https://i.iplsc.com/wypadek-lotniczy-na-filipinach-na-pokladzie-byly-173-osoby/000G8R9AJOVEDM06-C321.jpg" /></a>Samolot linii Korean Air ze 162 pasażerami i 11 członkami załogi nie zmieścił się na pasach podczas lądowania na międzynarodowym lotnisku Mactan-Cebu na Filipinach. Wedłu

## Sondaż IBRiS: Partia Jarosława Kaczyńskiego ze stabilnym prowadzeniem
 - [https://wydarzenia.interia.pl/kraj/news-sondaz-ibris-partia-jaroslawa-kaczynskiego-ze-stabilnym-prow,nId,6367226](https://wydarzenia.interia.pl/kraj/news-sondaz-ibris-partia-jaroslawa-kaczynskiego-ze-stabilnym-prow,nId,6367226)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 05:10:35+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sondaz-ibris-partia-jaroslawa-kaczynskiego-ze-stabilnym-prow,nId,6367226"><img align="left" alt="Sondaż IBRiS: Partia Jarosława Kaczyńskiego ze stabilnym prowadzeniem" src="https://i.iplsc.com/sondaz-ibris-partia-jaroslawa-kaczynskiego-ze-stabilnym-prow/000G8R9BNWNKWTGT-C321.jpg" /></a>Jak wynika z najnowszego sondażu IBRiS, Prawo i Sprawiedliwość może liczyć na na 33-procentowe poparcie. Donaldowi Tuskowi i Koalicji Obywatelskiej zaufałoby 26,

## Czarna seria zatruć czadem. W weekend zginęło pięć osób
 - [https://wydarzenia.interia.pl/kraj/news-czarna-seria-zatruc-czadem-w-weekend-zginelo-piec-osob,nId,6367220](https://wydarzenia.interia.pl/kraj/news-czarna-seria-zatruc-czadem-w-weekend-zginelo-piec-osob,nId,6367220)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 04:55:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-czarna-seria-zatruc-czadem-w-weekend-zginelo-piec-osob,nId,6367220"><img align="left" alt="Czarna seria zatruć czadem. W weekend zginęło pięć osób" src="https://i.iplsc.com/czarna-seria-zatruc-czadem-w-weekend-zginelo-piec-osob/000G8R8M4W8EDPDT-C321.jpg" /></a>Trwa czarna seria zatruć czadem. Od piątku do niedzieli z powodu zatrucia tlenkiem węgla zginęło pięć osób. Łącznie od października, czyli od początku umownego sezonu grzewczego w wyniku 

## Boris Johnson zrezygnował ze startu. Jest oświadczenie
 - [https://wydarzenia.interia.pl/zagranica/news-boris-johnson-zrezygnowal-ze-startu-jest-oswiadczenie,nId,6367215](https://wydarzenia.interia.pl/zagranica/news-boris-johnson-zrezygnowal-ze-startu-jest-oswiadczenie,nId,6367215)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 04:50:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-boris-johnson-zrezygnowal-ze-startu-jest-oswiadczenie,nId,6367215"><img align="left" alt="Boris Johnson zrezygnował ze startu. Jest oświadczenie " src="https://i.iplsc.com/boris-johnson-zrezygnowal-ze-startu-jest-oswiadczenie/000G8R8A8MINQSRI-C321.jpg" /></a>- Obawiam się, że najlepszym rozwiązaniem będzie to, by nie dopuścić do mojej nominacji - napisał w oświadczeniu były premier Boris Johnson, decydując się na rezygnację z ubiegania się

## Czy to już? Zmiana czasu coraz bliżej. Tej nocy pośpimy dłużej
 - [https://wydarzenia.interia.pl/ciekawostki/news-czy-to-juz-zmiana-czasu-coraz-blizej-tej-nocy-pospimy-dluzej,nId,6360226](https://wydarzenia.interia.pl/ciekawostki/news-czy-to-juz-zmiana-czasu-coraz-blizej-tej-nocy-pospimy-dluzej,nId,6360226)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 04:29:29+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-czy-to-juz-zmiana-czasu-coraz-blizej-tej-nocy-pospimy-dluzej,nId,6360226"><img align="left" alt="Czy to już? Zmiana czasu coraz bliżej. Tej nocy pośpimy dłużej" src="https://i.iplsc.com/czy-to-juz-zmiana-czasu-coraz-blizej-tej-nocy-pospimy-dluzej/000G8B8YL60LWVMH-C321.jpg" /></a>Jak co roku w ostatnią niedzielę października nastąpi zmiana czasu z letniego na zimowy. Dla wielu osób jest to dobra wiadomość, oznacza bowiem, że będziemy spać

## Wymiana ognia między Koreą Południową i Koreą Północną
 - [https://wydarzenia.interia.pl/zagranica/news-wymiana-ognia-miedzy-korea-poludniowa-i-korea-polnocna,nId,6367212](https://wydarzenia.interia.pl/zagranica/news-wymiana-ognia-miedzy-korea-poludniowa-i-korea-polnocna,nId,6367212)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 04:22:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wymiana-ognia-miedzy-korea-poludniowa-i-korea-polnocna,nId,6367212"><img align="left" alt="Wymiana ognia między Koreą Południową i Koreą Północną" src="https://i.iplsc.com/wymiana-ognia-miedzy-korea-poludniowa-i-korea-polnocna/000G8R7T8D6P27UQ-C321.jpg" /></a>W nocy z niedzieli na poniedziałek i w poniedziałek nad ranem, czasu lokalnego, doszło do wymiany ognia artyleryjskiego między Koreą Północną i Południową - wynika z komunikatów dowód

## Wojna w Ukrainie. 243. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo,nzId,3229,akt,240542](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo,nzId,3229,akt,240542)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 03:37:33+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo,nzId,3229,akt,240542"><img align="left" alt="Wojna w Ukrainie. 243. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo/000G8R65TFN3FU1K-C321.jpg" /></a>Zapraszamy do śledzenia naszej relacji na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 243. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo,nzId,3229,akt,240707](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo,nzId,3229,akt,240707)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 03:37:33+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo,nzId,3229,akt,240707"><img align="left" alt="Wojna w Ukrainie. 243. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo/000G8R65TFN3FU1K-C321.jpg" /></a>Zapraszamy do śledzenia naszej relacji na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 243. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo,nzId,3229,akt,240749](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo,nzId,3229,akt,240749)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2022-10-24 03:37:33+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo,nzId,3229,akt,240749"><img align="left" alt="Wojna w Ukrainie. 243. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-243-dzien-inwazji-rosji-relacja-na-zywo/000G8R65TFN3FU1K-C321.jpg" /></a>Zapraszamy do śledzenia naszej relacji na żywo.</p><br clear="all" />


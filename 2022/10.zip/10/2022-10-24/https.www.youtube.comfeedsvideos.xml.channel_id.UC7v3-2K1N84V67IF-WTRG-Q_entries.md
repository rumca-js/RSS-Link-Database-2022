# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## House of the Dragon: Season 1 FINALE - Review
 - [https://www.youtube.com/watch?v=YuK1lW09HIc](https://www.youtube.com/watch?v=YuK1lW09HIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2022-10-25 00:00:00+00:00

Video Sponsored by Ridge Wallet. Check them out here: https://ridge.com/jahns. Use Code “JAHNS” for 10% off your order

HOUSE OF THE DRAGON Season1 has ended! Solid season of television, and ends with much to look forward to. Here are my thoughts!

#HouseOfTheDragon #HouseOfTheDragonFinale


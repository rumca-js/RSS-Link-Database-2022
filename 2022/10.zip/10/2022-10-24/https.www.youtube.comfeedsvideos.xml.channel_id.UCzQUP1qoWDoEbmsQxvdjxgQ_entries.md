# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Asks Maynard James Keenan About His Vineyard
 - [https://www.youtube.com/watch?v=VHs_JyPhmtE](https://www.youtube.com/watch?v=VHs_JyPhmtE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-10-25 00:00:00+00:00

Taken from JRE #1887 w/Maynard James Keenan:
https://open.spotify.com/episode/62ZE9Pb59rQuyIHXpUrldr?si=292c03bc973343d8

## Joe's Thoughts on UFC 280
 - [https://www.youtube.com/watch?v=V1inYnciMrk](https://www.youtube.com/watch?v=V1inYnciMrk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2022-10-25 00:00:00+00:00

Taken from JRE #1887 w/Maynard James Keenan:
https://open.spotify.com/episode/62ZE9Pb59rQuyIHXpUrldr?si=292c03bc973343d8


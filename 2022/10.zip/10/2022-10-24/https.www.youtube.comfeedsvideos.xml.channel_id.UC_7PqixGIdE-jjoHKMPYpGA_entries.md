# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Dlaczego liście tak robią?
 - [https://www.youtube.com/watch?v=VaZU37y2T_Q](https://www.youtube.com/watch?v=VaZU37y2T_Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2022-10-24 15:25:16+00:00

Kup moją nową książkę!
📚📚📚 7 CZĄSTECZEK 📚📚📚 
wejdź na https://siedem.alt.pl

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja pierwsza książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Liście zmieniają kolor na zimę. To fakt. Powszechnie znany. Ale odpowiedź na pytanie: dlaczego to robią już tak oczywista nie jest. Serio - to bardziej skomplikowane niż się może Wam wydawać!

===
Rozkład jazdy:

0:00 Rozum i godność rośliny
2:56 Dlaczego zrzucają
5:53 Reguła van't Hoffa vs. fotosynteza
7:05 Problematyczna fotosynteza
11:30 Spór o kolor czerwony

===
Źródła (wybrane):

T. S. Field i in. - Why leaves turn red in autumn. The role of anthocyanins in senescing leaves of red-osier dogwood
W. A. Hoch i in. - Resorption protection. Anthocyanins facilitate nutrient recovery in autumn by shielding leaves from potentially damaging light levels
M. Archetti i in. - Unraveling the evolution of autumn colours: an interdisciplinary approach
C.C. Labandeira i in. - Ninety-seven million years of angiosperm-insect association: paleobiological insight into the meaning of coevolution
D. W. Lee - Why Leaves Turn Red
M. Archetti i in. - The coevolution theory of autumn colours
M. Archetti - Evidence from the domestication of apple for the maintance of autumn colours by coevolution
M. Archetti - Loss of autumn colors under domestication

S. Mancuso - The Revolutionary Genius of Plants: A New Understanding of Plant Intelligence and Behavior


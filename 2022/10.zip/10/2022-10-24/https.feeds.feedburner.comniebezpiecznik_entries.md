# Source:Niebezpiecznik, URL:https://feeds.feedburner.com/niebezpiecznik/, language:pl-PL

## &#x2139;&#xfe0f; Centralne Biuro Zwalczania Cyberprzestępczości wysyła SMS-y poszkodowanym
 - [https://niebezpiecznik.pl/post/centralne-biuro-zwalczania-cyberprzestepczosci-wysyla-sms-y-poszkodowanym/](https://niebezpiecznik.pl/post/centralne-biuro-zwalczania-cyberprzestepczosci-wysyla-sms-y-poszkodowanym/)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2022-10-24 11:00:07+00:00

<a href="https://niebezpiecznik.pl/post/centralne-biuro-zwalczania-cyberprzestepczosci-wysyla-sms-y-poszkodowanym/"><img align="left" alt="" class="alignleft wp-post-image tfe" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2022/10/cbzc-sms-600x537.jpg" title="" width="100" /></a>Informujecie nas, że otrzymujecie SMS-y z numeru &#8220;669979971&#8220;, które przywołują w treści marki &#8220;Inpost&#8221; i &#8220;PGE&#8221;. Wiadomości zachęcają do odwiedzenia strony CBZC i zastanawiacie się o co chodzi&#8230; Uspokajamy: to nie atak, to akcja Centralnego Biura Zwalczania Cyberprzestępczości. Policjanci ostatnio złapali szajkę okradającą Polaków takimi SMS-ami i aktualnie poszukują poszkodowanych, którzy w wyniku złośliwych SMS-ów mogli stracić [&#8230;]

## Więzień ukradł 50 milionów złotych w trakcie wyroku, korzystając przemyconego smartfona
 - [https://niebezpiecznik.pl/post/wiezien-ukradl-50-milionow-zlotych-w-trakcie-wyroku-korzystajac-przemyconego-smartfona/](https://niebezpiecznik.pl/post/wiezien-ukradl-50-milionow-zlotych-w-trakcie-wyroku-korzystajac-przemyconego-smartfona/)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2022-10-24 09:56:58+00:00

<a href="https://niebezpiecznik.pl/post/wiezien-ukradl-50-milionow-zlotych-w-trakcie-wyroku-korzystajac-przemyconego-smartfona/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2022/10/charles-schwab-150x150.jpg" width="100" /></a>Myślicie, że jak kogoś zamknęli to nie może już kraść i oszukiwać? Historia więźnia Artura, to dowód na to, że nawet odbywając wyrok można dalej kraść i całkiem nieźle zarobić. Wybierz miliardera na ofiarę To oszustwo zaczęło się 5 czerwca z w 2020 roku, kiedy Arthur Lee Cofield, więzień odbywający 14-letni wyrok za napad i [&#8230;]


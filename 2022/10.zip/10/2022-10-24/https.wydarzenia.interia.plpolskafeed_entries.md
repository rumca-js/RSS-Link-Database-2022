# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Kosiniak-Kamysz: Możliwe, że wiosną Morawiecki będzie chciał, by doszło do zmiany premiera
 - [https://wydarzenia.interia.pl/kraj/news-kosiniak-kamysz-mozliwe-ze-wiosna-morawiecki-bedzie-chcial-b,nId,6367453](https://wydarzenia.interia.pl/kraj/news-kosiniak-kamysz-mozliwe-ze-wiosna-morawiecki-bedzie-chcial-b,nId,6367453)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-10-24 11:19:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kosiniak-kamysz-mozliwe-ze-wiosna-morawiecki-bedzie-chcial-b,nId,6367453"><img align="left" alt="Kosiniak-Kamysz: Możliwe, że wiosną Morawiecki będzie chciał, by doszło do zmiany premiera" src="https://i.iplsc.com/kosiniak-kamysz-mozliwe-ze-wiosna-morawiecki-bedzie-chcial-b/000FGI5Y2F0OII1K-C321.jpg" /></a>- Możliwe, że wiosną sytuacja będzie dla PiS-u tak fatalna, że Mateusz Morawiecki sam będzie oczekiwał zmiany na stanowisku premiera - mówi Interii Władysław Kosiniak-Kamysz. Lider Polskiego Stronnictwa Ludowego ocenia też, że w Sejmie nie ma wystarczającej większości do przegłosowania konstruktywnego wotum nieufności. - Na razie możliwości matematyczne nie dają gwarancji sukcesu - przyznaje polityk.</p><br clear="all" />

## Masz tylko kilka dni, by dostać dodatkowe 3 tys. zł. Termin na złożenie wniosku już blisko
 - [https://wydarzenia.interia.pl/kraj/news-masz-tylko-kilka-dni-by-dostac-dodatkowe-3-tys-zl-termin-na-,nId,6362066](https://wydarzenia.interia.pl/kraj/news-masz-tylko-kilka-dni-by-dostac-dodatkowe-3-tys-zl-termin-na-,nId,6362066)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2022-10-24 05:42:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-masz-tylko-kilka-dni-by-dostac-dodatkowe-3-tys-zl-termin-na-,nId,6362066"><img align="left" alt="Masz tylko kilka dni, by dostać dodatkowe 3 tys. zł. Termin na złożenie wniosku już blisko " src="https://i.iplsc.com/masz-tylko-kilka-dni-by-dostac-dodatkowe-3-tys-zl-termin-na/000E3JAAIAVLBT8L-C321.jpg" /></a>Obecny sezon grzewczy jest szczególnie trudny ze względu na rosnące ceny opały i energii. Rząd, aby to zrekompensować, zaproponował dodatki do ogrzewania. Dotyczą one różnych źródeł ciepła i różnią się między sobą kwotami wypłacanego świadczenia. Sprawdź, jakie są możliwości otrzymania dofinansowania i do kiedy trzeba złożyć wnioski o dodatek do ogrzewania.</p><br clear="all" />


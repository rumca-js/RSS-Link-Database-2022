# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## Stop Using These Recalled Unilever Brands of Dry Shampoo, FDA Says
 - [https://lifehacker.com/stop-using-these-recalled-unilever-brands-of-dry-shampo-1849695946](https://lifehacker.com/stop-using-these-recalled-unilever-brands-of-dry-shampo-1849695946)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 21:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--UUgpMUXW--/c_fit,fl_progressive,q_80,w_636/4e3e9488e4ead47a092ddcb4bf22afcd.jpg" /><p>The U.S. Food and Drug Administration (FDA) has <a href="https://www.fda.gov/safety/recalls-market-withdrawals-safety-alerts/unilever-issues-voluntary-us-recall-select-dry-shampoos-due-potential-presence-benzene#recall-announcement" rel="noopener noreferrer" target="_blank">announced</a> that shampoo company Unilever  has <a href="https://www.unileverrecall.com/" rel="noopener noreferrer" target="_blank">voluntarily recalled</a> a number of their dry shampoos over potentially elevated levels of benzene, a chemical known to cause cancer.<br /></p><p><a href="https://lifehacker.com/stop-using-these-recalled-unilever-brands-of-dry-shampo-1849695946">Read more...</a></p>

## These Are the Best Pairings of Halloween Candy and Booze
 - [https://lifehacker.com/these-are-the-best-pairings-of-halloween-candy-and-booz-1849694335](https://lifehacker.com/these-are-the-best-pairings-of-halloween-candy-and-booz-1849694335)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 21:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--iTFrlsvy--/c_fit,fl_progressive,q_80,w_636/fd27aa93b7462812c6e78031f1e53638.jpg" /><p>As Halloween approaches, adults everywhere are faced with the usual questions: How sexy is <em>too</em> sexy when it comes to costumes? How much candy can you confiscate from your children before you become a monster? And, most importantly, can you pair alcohol with that stolen candy—and if so, how does one do that with the…</p><p><a href="https://lifehacker.com/these-are-the-best-pairings-of-halloween-candy-and-booz-1849694335">Read more...</a></p>

## A Bunch of Exclusive New iPadOS Features Just Dropped
 - [https://lifehacker.com/a-bunch-of-exclusive-new-ipados-features-just-dropped-1849694753](https://lifehacker.com/a-bunch-of-exclusive-new-ipados-features-just-dropped-1849694753)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 20:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--xJKIimCM--/c_fit,fl_progressive,q_80,w_636/2834ed9daeba337957b9d8db73af6c74.jpg" /><p>After an extra month or so delay, Apple has finally released iPadOS 16 to the public. Well, technically, it’s iPadOS 16.1. The wait means we’ve already skipped a version and are onto a “point update,” and that before anyone outside of beta testers even had a chance to try iPadOS 16. No matter what Apple is calling it,…</p><p><a href="https://lifehacker.com/a-bunch-of-exclusive-new-ipados-features-just-dropped-1849694753">Read more...</a></p>

## What's New on HBO Max in November 2022
 - [https://lifehacker.com/whats-new-on-hbo-max-in-november-2022-1849695235](https://lifehacker.com/whats-new-on-hbo-max-in-november-2022-1849695235)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 20:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--S2zZ8_Pl--/c_fit,fl_progressive,q_80,w_636/a521f84ac6ef4d33d312abbc9f037325.jpg" /><p>If the risk/reward ratio for making a movie sequel grows more skewed with both how beloved the original is and how much time has passed<em>, A Christmas Story Christmas</em> may be one of the most fraught films ever made. I certainly can’t help but greet the followup to 1983's perennial basic cable classic <em>A Christmas Story</em>,…</p><p><a href="https://lifehacker.com/whats-new-on-hbo-max-in-november-2022-1849695235">Read more...</a></p>

## Should You Work From Home or Take a Real Sick Day?
 - [https://lifehacker.com/should-you-work-from-home-or-take-a-real-sick-day-1849695187](https://lifehacker.com/should-you-work-from-home-or-take-a-real-sick-day-1849695187)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 19:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--iZLB9ybA--/c_fit,fl_progressive,q_80,w_636/4d2f3f20e7f8d839bbcdefbc433ebf32.jpg" /><p>If your only options when you’re sick are going into the office or calling off, then obviously if you’re contagious, you should call off. But now that so many of us have the option of working from home when we can’t make it to the office, the decision becomes a little trickier. </p><p><a href="https://lifehacker.com/should-you-work-from-home-or-take-a-real-sick-day-1849695187">Read more...</a></p>

## What a Professional Housecleaner Will Clean (and What They Won't)
 - [https://lifehacker.com/what-a-professional-housecleaner-will-clean-and-what-t-1849694908](https://lifehacker.com/what-a-professional-housecleaner-will-clean-and-what-t-1849694908)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--V3Z6np29--/c_fit,fl_progressive,q_80,w_636/718246f8b4c9faceafa499366ef05546.jpg" /><p>Hiring a house cleaning service can be hugely helpful if you’re busy, unorganized, or in a rush, but there is some <a href="https://lifehacker.com/a-beginners-guide-to-hiring-a-housecleaner-1849539839">etiquette you have to know</a> before hiring a stranger to clean up your messes. For instance, there are some things a professional cleaner shouldn’t—or can’t—clean. Sometimes it’s a time or efficiency issue,…</p><p><a href="https://lifehacker.com/what-a-professional-housecleaner-will-clean-and-what-t-1849694908">Read more...</a></p>

## Your Halloween Party Needs These Chocolate Peanut Butter Bat Cookies
 - [https://lifehacker.com/your-halloween-party-needs-these-chocolate-peanut-butte-1849694663](https://lifehacker.com/your-halloween-party-needs-these-chocolate-peanut-butte-1849694663)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 18:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--o3JTW1i5--/c_fit,fl_progressive,q_80,w_636/0f257282ff85709b6871ffad70a77699.jpg" /><p>Besides agonizing over the details of your elaborate Rings of Power group Halloween costume, part of the allure of Oct. 31 is the excuse to eat copious amounts of sweets. Although I truly believe that Reese’s Peanut Butter Cups are gross, I also recognize the flavor combination of chocolate and peanut butter itself is…</p><p><a href="https://lifehacker.com/your-halloween-party-needs-these-chocolate-peanut-butte-1849694663">Read more...</a></p>

## 20 New iOS 16.1 Features You Need to Know About
 - [https://lifehacker.com/20-new-ios-16-1-features-you-need-to-know-about-1849621298](https://lifehacker.com/20-new-ios-16-1-features-you-need-to-know-about-1849621298)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 17:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--O5ZH3ZEI--/c_fit,fl_progressive,q_80,w_636/7fb97f38e9a304edb8d2b565bbd26089.jpg" /><p>Here we go again: Apple’s next big iPhone update, iOS 16.1, is  here, bringing a host of tweaks and improvements to the operating just over a month <a href="https://lifehacker.com/26-of-the-best-new-features-in-ios-16-1849524600">after it launched</a>. Once it hits your iPhone, you’ll be able to peruse <a href="https://9to5mac.com/2022/10/18/ios-16-1-release-date-features/" rel="noopener noreferrer" target="_blank">Apple’s short list of the new features and changes</a>, including the launch of iCloud Shared Photo…</p><p><a href="https://lifehacker.com/20-new-ios-16-1-features-you-need-to-know-about-1849621298">Read more...</a></p>

## What You Need to Know About RSV, the Respiratory Illness Surging in Children
 - [https://lifehacker.com/what-you-need-to-know-about-rsv-the-respiratory-illnes-1849693964](https://lifehacker.com/what-you-need-to-know-about-rsv-the-respiratory-illnes-1849693964)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 17:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--FiZS8zW8--/c_fit,fl_progressive,q_80,w_636/66953b1422e07357ae464a175bc7a1ad.jpg" /><p>Respiratory syncytial virus, better known as RSV, is surging <a href="https://lifehacker.com/what-parents-should-know-about-the-summer-surge-of-rsv-1847522724">again</a>, to the point where people who work in healthcare are worried about hospital resources becoming overwhelmed. The illness can be serious in babies and in elderly people, so read on for more about what to know.</p><p><a href="https://lifehacker.com/what-you-need-to-know-about-rsv-the-respiratory-illnes-1849693964">Read more...</a></p>

## These 20 States Are Sending Out Stimulus Checks
 - [https://lifehacker.com/these-20-states-are-sending-out-stimulus-checks-1849693645](https://lifehacker.com/these-20-states-are-sending-out-stimulus-checks-1849693645)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--bNlGq2qH--/c_fit,fl_progressive,q_80,w_636/845dd56f2324757e2dae2bde5a5cb381.jpg" /><p>Although there’s little to see in terms of federal <a href="https://lifehacker.com/how-inflation-might-help-lower-your-taxes-in-2023-1849683814">relief from record-breaking inflation</a>, some states are stepping up to help their residents face our current economic reality. Twenty states are sending (or already sent) one-time rebate checks or other payments to eligible taxpayers. While these payment amounts aren’t…</p><p><a href="https://lifehacker.com/these-20-states-are-sending-out-stimulus-checks-1849693645">Read more...</a></p>

## Quickly Class Up a Room With Painted Faux-Arches
 - [https://lifehacker.com/quickly-class-up-a-room-with-painted-faux-arches-1849693677](https://lifehacker.com/quickly-class-up-a-room-with-painted-faux-arches-1849693677)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 16:23:01+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--2RebWzGA--/c_fit,fl_progressive,q_80,w_636/7b7fb6272a07b132f4cc2aea4f457f79.jpg" /><p>Arches are a good way to give any room an eye-catching focal point, but having an arched door installed or building an arched alcove is time-consuming and potentially expensive. Instead, add a painted arch or two, netting some of the same curvy appeal without breaking the bank. Here are some tips on how to paint one,…</p><p><a href="https://lifehacker.com/quickly-class-up-a-room-with-painted-faux-arches-1849693677">Read more...</a></p>

## How to Fix Your Noisy Radiator Based on the Sound It’s Making
 - [https://lifehacker.com/how-to-fix-your-noisy-radiator-based-on-the-sound-it-s-1849693196](https://lifehacker.com/how-to-fix-your-noisy-radiator-based-on-the-sound-it-s-1849693196)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 15:46:16+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--DB1H0k_I--/c_fit,fl_progressive,q_80,w_636/aab716b6c0f21a36f92db177f2d85f4a.jpg" /><p>Part of the charm of city living are the no-frills accommodations. Plain white paint coats your walls, trim, and door frames, <a href="https://lifehacker.com/please-get-rid-of-this-boob-light-fixture-in-your-apart-1848052539">a standard boob light</a> is mounted on your ceiling, and you probably have an austere radiator in the corner in every room. Nondescript, metallic, and efficient, these things heat your home…</p><p><a href="https://lifehacker.com/how-to-fix-your-noisy-radiator-based-on-the-sound-it-s-1849693196">Read more...</a></p>

## Take These Safety Precautions Before Any DIY Project
 - [https://lifehacker.com/take-these-safety-precautions-before-any-diy-project-1849691246](https://lifehacker.com/take-these-safety-precautions-before-any-diy-project-1849691246)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 15:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Jnjd9SEg--/c_fit,fl_progressive,q_80,w_636/cb4c5f174f5c17ec961984cedeaa8390.jpg" /><p>Doing your own home improvement projects and maintenance can be rewarding: In addition to saving money, there’s a sense of accomplishment that comes with completing a task yourself. But accident rates for DIY enthusiasts might be higher than you think, so practicing some basic safety precautions when you’re using…</p><p><a href="https://lifehacker.com/take-these-safety-precautions-before-any-diy-project-1849691246">Read more...</a></p>

## How to Get Over Your Messy-House Shame
 - [https://lifehacker.com/how-to-get-over-your-messy-house-shame-1849692092](https://lifehacker.com/how-to-get-over-your-messy-house-shame-1849692092)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 14:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--VCpnxHZn--/c_fit,fl_progressive,q_80,w_636/a3d752c483fc06ff0b1fc4083276b5d6.jpg" /><p>Scrolling through social media, with its carefully curated images of beautiful, clutter-free living spaces, often has the effect of making you feel inadequate about your own home. Whether it’s the dishes in the kitchen sink, the piles of laundry you can never quite find the time to put away, or the scattered toys you…</p><p><a href="https://lifehacker.com/how-to-get-over-your-messy-house-shame-1849692092">Read more...</a></p>

## You're Wrong About the Origins of These 12 Common Words
 - [https://lifehacker.com/youre-wrong-about-the-origins-of-these-12-common-words-1849687781](https://lifehacker.com/youre-wrong-about-the-origins-of-these-12-common-words-1849687781)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--ek5ZdDey--/c_fit,fl_progressive,q_80,w_636/dd38ed832edfc130b70c3711b2f076bb.jpg" /><p>Whether we’re talking about “shit,” “fuck,” or “sirloin,” people love inventing amusing stories to explain the origins of common words. False etymology<em> is</em> fun—explaining that “fuck” derives from signs adulterers wore reading “for unlawful carnal knowledge” is way more amusing than pointing out the Indo-European root -<em></em>…</p><p><a href="https://lifehacker.com/youre-wrong-about-the-origins-of-these-12-common-words-1849687781">Read more...</a></p>

## What to Do If You Realize You're 'Parenting' Your Partner
 - [https://lifehacker.com/what-to-do-if-you-realize-youre-parenting-your-partner-1849683337](https://lifehacker.com/what-to-do-if-you-realize-youre-parenting-your-partner-1849683337)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 13:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--BWm9Tbh2--/c_fit,fl_progressive,q_80,w_636/1e7451292a90638bb99059d0797f4d78.jpg" /><p>Every relationship is different, including when it comes to power dynamics. Even when a couple strives for an equal partnership—and, in some cases, genuinely believes they have one—the reality is that they may be falling into certain unhealthy patterns of behavior.</p><p><a href="https://lifehacker.com/what-to-do-if-you-realize-youre-parenting-your-partner-1849683337">Read more...</a></p>

## Start These Ferments Now and Use Them All Holiday Season
 - [https://lifehacker.com/start-these-ferments-now-and-use-them-all-holiday-seaso-1849679086](https://lifehacker.com/start-these-ferments-now-and-use-them-all-holiday-seaso-1849679086)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--k5ObUIg5--/c_fit,fl_progressive,q_80,w_636/94a329daadf062ca10dce588533eed4a.jpg" /><p>Honey is good. Fermented honey is double plus good. Fermented honey is also one of the easiest, surest bets for fermentation out there, if you’ve been waiting to try it for yourself. You don’t need your own hive, either. You can grab raw honey at your regular grocery store, and in most cases, it’s not more expensive…</p><p><a href="https://lifehacker.com/start-these-ferments-now-and-use-them-all-holiday-seaso-1849679086">Read more...</a></p>

## 25 of the Most Useful macOS Ventura Features
 - [https://lifehacker.com/25-of-the-most-useful-macos-ventura-features-1849676873](https://lifehacker.com/25-of-the-most-useful-macos-ventura-features-1849676873)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 12:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--tTQzyHs_--/c_fit,fl_progressive,q_80,w_636/2d10a6e4b078f11534ca7e1716abdae0.png" /><p>A fresh update can make your old tech feel new. You might be tempted to upgrade your MacBook for a fancy M2 machine, but maybe all you need is to install macOS 13 Ventura. These 25 new features include a new window management system, the ability to use your iPhone as a seamless webcam, and the ability to edit your…</p><p><a href="https://lifehacker.com/25-of-the-most-useful-macos-ventura-features-1849676873">Read more...</a></p>

## The 7 Deadly Sins of Grocery Shopping
 - [https://lifehacker.com/the-7-deadly-sins-of-grocery-shopping-1849688725](https://lifehacker.com/the-7-deadly-sins-of-grocery-shopping-1849688725)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2022-10-24 12:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--8Bu54gGX--/c_fit,fl_progressive,q_80,w_636/0cc6c8583e444596790c1ea7867ba3c0.jpg" /><p>You are grocery shopping all wrong. Sadly, I can’t personally accompany you to the Piggly Wiggly and <em>force</em> you to navigate the supermarket correctly. I mean, I’m working on an army of atomic super-robots will be able to handle that, but until a naive venture capitalist shows up with first round of funding, you’ll have…</p><p><a href="https://lifehacker.com/the-7-deadly-sins-of-grocery-shopping-1849688725">Read more...</a></p>


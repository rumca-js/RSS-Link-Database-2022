# Source:Brad Colbow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A, language:en-US

## 10th Gen iPad Review
 - [https://www.youtube.com/watch?v=IsAwsIwdjt8](https://www.youtube.com/watch?v=IsAwsIwdjt8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A
 - date published: 2022-10-24 13:08:08+00:00

My New course: http://bradsartschool.com

The new iPad has a great new design but left out a couple features that a lot of designers and illustrators would probably love to have.

Discounts for my Courses (US) https://bradcolbow.channel
Discounts for my Courses (worldwide) http://brad.site/learn/
Email Newsletter: http://brad.site/signup/

-----------------------------------------------------

Twitter: 
https://twitter.com/bradcolbow

Instagram:
https://www.instagram.com/bcolbow/

Drawing Tech Top 10 lists:
http://brad.site/

My Drawing and video gear: 
http://brad.site/mygear/


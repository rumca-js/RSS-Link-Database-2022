# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Jan Duda pozostaje na stanowisku przewodniczącego Sejmiku. "Sejmik już nie jest wojewódzki"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29063835,jan-duda-pozostaje-na-stanowisku-przewodniczacego-sejmiku-sejmik.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29063835,jan-duda-pozostaje-na-stanowisku-przewodniczacego-sejmiku-sejmik.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-24 17:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c7/b7/1b/z29064135M,Jan-Duda.jpg" vspace="2" />Jan Duda pozostanie na stanowisku przewodniczącego Sejmiku Województwa Małopolskiego. W poniedziałek nad projektem uchwały w sprawie jego odwołania mieli głosować radni. Jednak na wniosek Prawa i Sprawiedliwości głosowanie się nie odbyło. "To złamanie prawa" - skomentował tę decyzję poseł PO Marek Sowa.

## Tarnów. Śmierć czteroosobowej rodziny. 41-latka we wrześniu wnioskowała o niebieską kartę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29063823,tarnow-smierc-czteroosobowej-rodziny-41-latka-we-wrzesniu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29063823,tarnow-smierc-czteroosobowej-rodziny-41-latka-we-wrzesniu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-24 15:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c8/b7/1b/z29063880M,Tragedia-w-Tarnowie.jpg" vspace="2" />Trwa wyjaśnianie okoliczności śmierci czteroosobowej rodziny w Tarnowie (Małopolska). Ciała kobiety, mężczyzny i dwójki dzieci z ranami ciętymi i kłutymi znaleziono w domu jednorodzinnym w piątek. Jak ujawniła policja, kobieta kilka tygodni przed śmiercią złożyła wniosek o założenie niebieskiej karty w związku z przemocą domową.

## Afera respiratorowa. Służby nie ostrzegły resortu przed Andrzejem I., choć już wtedy toczyło się śledztwo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29062835,afera-respiratorowa-sluzby-nie-ostrzegly-resortu-przed-andrzejem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29062835,afera-respiratorowa-sluzby-nie-ostrzegly-resortu-przed-andrzejem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-24 13:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a7/6d/1a/z27710631M,CBA--zdjecie-ilustracyjne-.jpg" vspace="2" />Ministerstwo Zdrowia podpisało przed dwoma laty umowę z Andrzejem I. na dostawę respiratorów, choć już wtedy od trzech lat w Bydgoszczy toczyło się śledztwo ws. innej transakcji z udziałem tego biznesmena. Jak podaje Wp.pl, spółka reprezentowana przez Andrzeja I. miała narazić państwową firmę na szkody w wysokości ok. 5 mln zł.

## Sosnowiec. Pościg ulicami miasta. By dopaść kierowcę, policja staranowała jego auto i strzelała w koła
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29062130,sosnowiec-poscig-ulicami-miasta-pijany-46-latek-uciekal-przed.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29062130,sosnowiec-poscig-ulicami-miasta-pijany-46-latek-uciekal-przed.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-24 12:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9f/b7/1b/z29062303M,Policjanci-zatrzymali-mezczyzne--ktory-uciekal-uli.jpg" vspace="2" />W Sosnowcu 46-latek nie zatrzymał się do kontroli drogowej, a następnie próbował dwukrotnie uciekać przed policjantami. Aby dogonić i zatrzymać ściganego kierowcę, staranowali jego auto, a później strzelili w koła samochodu. Okazało się, że kierował pod wpływem alkoholu, odpowie też za naruszenie nietykalności policjanta.

## Do sądu trafił ponowny akt oskarżenia przeciwko liderkom Strajku Kobiet. Zarzuty dot. protestów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29062180,do-sadu-trafil-ponowny-akt-oskarzenia-przeciwko-liderkom-strajku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29062180,do-sadu-trafil-ponowny-akt-oskarzenia-przeciwko-liderkom-strajku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-24 11:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7a/0b/1a/z27310714M,Od-lewej--Klementyna-Suchanow--Marta-Lempart-i-Agn.jpg" vspace="2" />Niemal dokładnie w drugą rocznicę protestów po orzeczeniu TK w sprawie aborcji prokuratura Okręgowa w Warszawie ponownie skierowała do sądu akt oskarżenia przeciwko liderkom Strajku Kobiet. Dotyczy on Marty Lempart, Klementyny Suchanow oraz Agnieszki Czeredereckiej-Fabin.

## Fundacja Życie i Rodzina. Kaja Godek z nowym projektem. Chce karać organizacje pomagające w aborcji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29060966,fundacja-zycie-i-rodzina-kaja-godek-z-nowym-projektem-chce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29060966,fundacja-zycie-i-rodzina-kaja-godek-z-nowym-projektem-chce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-24 11:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1f/b7/1b/z29061151M,Kaja-Godek.jpg" vspace="2" />Fundacja Życie i Rodzina Kai Godek skieruje do Sejmu projekt, który ma ograniczać działanie organizacji, które pomagają kobietom chcącym przerwać ciążę. - Projekt ma na celu likwidację systemowego pomocnictwa w aborcji - informuje Kaja Godek w rozmowie z "Rzeczpospolitą".

## Zaćmienie Słońca w Polsce już we wtorek. Jak i kiedy obserwować? Czekaliśmy na to 7 lat [MAPA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29061924,zacmienie-slonca-w-polsce-juz-we-wtorek-jak-i-kiedy-obserwowac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29061924,zacmienie-slonca-w-polsce-juz-we-wtorek-jak-i-kiedy-obserwowac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-24 11:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/18/b6/1b/z29059096M,Zacmienie-slonca---zdjecie-ilustracyjne.jpg" vspace="2" />Już we wtorek 25 października będzie można obserwować zaćmienie Słońca. W Polsce Księżyc zasłoni maksymalnie 46 proc. tarczy gwiazdy. Jak przygotować się do obserwacji, by było to bezpieczne dla naszego wzroku?

## Kiedy ferie 2023? Oto rozpiska przerwy zimowej z podziałem na województwa [HARMONOGRAM]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29061171,kiedy-ferie-2023-oto-rozpiska-przerwy-zimowej-z-podzialem-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29061171,kiedy-ferie-2023-oto-rozpiska-przerwy-zimowej-z-podzialem-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-24 09:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/38/a0/1b/z28970296M,Ferie-zimowe-2023--Podajemy-terminy-dla-poszczegol.jpg" vspace="2" />Ferie zimowe to jedna z kilku dłuższych przerw od nauki, którymi mogą cieszyć się uczniowie. Ich data nie jest jednak stała i zależy od województwa. Przedstawiamy rozpiskę z datami ferii zimowych 2023.

## Zbrodnia miłoszycka. Ziobro złożył kasację ws. morderców Małgosi. Uznał wyroki za "rażąco łagodne"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29061357,zbrodnia-miloszycka-ziobro-zlozyl-kasacje-ws-mordercow-malgosi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29061357,zbrodnia-miloszycka-ziobro-zlozyl-kasacje-ws-mordercow-malgosi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-24 08:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/74/ab/1b/z29015668M.jpg" vspace="2" />Prokurator Generalny skierował do Sądu Najwyższego kasację na niekorzyść sprawców brutalnego gwałtu i zabójstwa 15-letniej Małgosi K. w noc sylwestrową 1996/97 w Miłoszycach. Zbigniew Ziobro uznał kary 25 i 15 lat pozbawienia wolności za rażąco łagodne. Za zbrodnię tę pierwotnie został skazany Tomasz Komenda.

## Bydgoszcz. Pożar w szpitalu dziecięcym ugaszony. Konieczna była ewakuacja 200 osób
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29061217,bydgoszcz-pozar-w-szpitalu-dzieciecym-ugaszony-konieczna-byla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29061217,bydgoszcz-pozar-w-szpitalu-dzieciecym-ugaszony-konieczna-byla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-24 07:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/93/b7/1b/z29061267M,Wojewodzki-Szpital-Dzieciecy-w-Bydgoszczy.jpg" vspace="2" />W bydgoskim szpitalu dziecięcym doszło w poniedziałek do pożaru. Jak podają media, zapalił się szyb wentylacyjny znajdujący się w pobliżu izby przyjęć placówki. Konieczna była ewakuacja około 200 osób, sytuacja została jednak opanowana.

## Zachodniopomorskie. Myśliwy zabił karmiącą żubrzycę. "Twierdzi, że strzelał w obronie własnej"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29060888,zachodniopomorskie-znaleziono-martwego-zubra-czwarty-przypadek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29060888,zachodniopomorskie-znaleziono-martwego-zubra-czwarty-przypadek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2022-10-24 06:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/b6/1b/z29060953M,Zachodniopomorskie--Znaleziono-martwego-zubra--czw.jpg" vspace="2" />Na terenie Nadleśnictwa Świerczyna w województwie zachodniopomorskim w niedzielę znaleziono zastrzeloną samicę żubra. Zwierzę zabił myśliwy. To już czwarty przypadek w tym województwie w ostatnich dwóch miesiącach.


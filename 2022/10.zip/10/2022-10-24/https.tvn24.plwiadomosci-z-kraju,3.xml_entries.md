# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Bankomaty na celowniku gangów. "Mogą spowodować nawet zawalenie się budynków"
 - [https://tvn24.pl/swiat/przestepcy-i-gangi-wysadzaja-bankomaty-z-pieniedzmi-uzywaja-materialow-wybuchowych-europol-ostrzega-6176503?source=rss](https://tvn24.pl/swiat/przestepcy-i-gangi-wysadzaja-bankomaty-z-pieniedzmi-uzywaja-materialow-wybuchowych-europol-ostrzega-6176503?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2022-10-24 06:04:02+00:00

<img alt="Bankomaty na celowniku gangów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wi56lp-bankomat-bank-platnosci-4659429/alternates/LANDSCAPE_1280" />
    W całej Europie drastycznie rośnie liczba spektakularnych ataków na bankomaty - oceniła rzeczniczka Europolu Claire Georges cytowana przez tygodnik "Spiegel". Dodała, że maszyny są wysadzane w powietrze przez wyspecjalizowane gangi. "Sprawcy są pozbawieni skrupułów, nie interesuje ich bezpieczeństwo ludzi, troszczą się tylko o pieniądze" 


# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Na Wall Street dalszy ciąg odbicia
 - [https://www.bankier.pl/wiadomosc/Na-Wall-Street-dalszy-ciag-odbicia-8428208.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Na-Wall-Street-dalszy-ciag-odbicia-8428208.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 21:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/7/d4e0db65abc5fc-948-568-105-175-1895-1136.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poniedziałkowa sesja na Wall Street zakończyła się solidnymi wzrostami głównych indeksów. To druga z rzędu wzrostowa sesja na amerykańskich giełdach, a inwestorzy utrzymują swoje pozytywne nastawienie do ryzyka.</p>

## Niedzielski: W produkcji leków musimy być niezależni od Chin i Indii
 - [https://www.bankier.pl/wiadomosc/Niedzielski-W-produkcji-lekow-musimy-byc-niezalezni-od-Chin-i-Indii-8428207.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niedzielski-W-produkcji-lekow-musimy-byc-niezalezni-od-Chin-i-Indii-8428207.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 21:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/4/6574c0aa4a9ae2-948-568-0-9-3600-2159.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pandemia i wojna na Ukrainie pokazały, że jednym z kluczowych wyzwań jest uniezależnienie produkcji leków w Europie od Indii i Chin - powiedział PAP minister zdrowia Adam Niedzielski. Minister wziął udział w konferencji nt. polsko-amerykańskiej współpracy w biotechnologii, zorganizowanej w Waszyngtonie. Jak ocenił, współpraca z USA jest ważna dla spełnienia polskich ambicji stania się regionalnym liderem w obszarze biotechnologii.</p>

## Gróbarczyk: rozpoczęła się fizyczna budowa promów w gdańskiej stoczni
 - [https://www.bankier.pl/wiadomosc/Grobarczyk-rozpoczela-sie-fizyczna-budowa-promow-w-gdanskiej-stoczni-8428186.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Grobarczyk-rozpoczela-sie-fizyczna-budowa-promow-w-gdanskiej-stoczni-8428186.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 19:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/8c147e176d79a7-945-560-15-52-2985-1790.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dziś w Gdańsku rozpoczęto cięcie blach pod budowę promów dla Polskiej Żeglugi Morskiej i Polskiej Żeglugi Bałtyckiej. Tym samym ruszyło fizyczne rozpoczęcie ich budowy – podał w poniedziałek w mediach społecznościowych wiceminister infrastruktury Marek Gróbarczyk.</p>

## Kantar: 31 proc. KO; 28 proc. PiS. W Sejmie też Polska2050, Lewica i  Konfederacja
 - [https://www.bankier.pl/wiadomosc/Kantar-31-proc-KO-28-proc-PiS-W-Sejmie-tez-Polska2050-Lewica-i-Konfederacja-8428179.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kantar-31-proc-KO-28-proc-PiS-W-Sejmie-tez-Polska2050-Lewica-i-Konfederacja-8428179.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 19:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/4/0ec98bfa2d3373-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Gdyby wybory odbyły się w październiku 31 proc. uzyskałaby Koalicja Obywatelska, 28 proc. PiS, 10 proc. Polska 2050, 7 proc. Lewica i 5 proc. Konfederacja - wynika z najnowszego sondażu Kantar Public. Pozostałe ugrupowania nie przekroczyłyby progu wyborczego.</p>

## Buda: Sądzę, że węgiel będzie po 1,9 tys. zł za tonę. Kiedy? Tego nie wiadomo
 - [https://www.bankier.pl/wiadomosc/Buda-Sadze-ze-wegiel-bedzie-po-1-9-tys-zl-za-tone-Kiedy-Tego-nie-wiadomo-8428176.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Buda-Sadze-ze-wegiel-bedzie-po-1-9-tys-zl-za-tone-Kiedy-Tego-nie-wiadomo-8428176.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 18:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/d/038224399a15ca-948-568-0-44-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W samorządowych punktach węgiel nie powinien być droższy niż 2 tys. zł za tonę, a sądzę, że będzie on po 1,8-1,9 tys. zł za tonę – powiedział w poniedziałek w Polsat News minister rozwoju i technologii Waldemar Buda.</p>

## Rosyjskie reparacje powinny wynieść bilion dolarów
 - [https://www.bankier.pl/wiadomosc/Rosyjskie-reparacje-powinny-wyniesc-bilion-dolarow-8428174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosyjskie-reparacje-powinny-wyniesc-bilion-dolarow-8428174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 18:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/0/1d2447b8a6c213-948-568-125-0-1875-1124.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosyjskie reparacje za wojnę na Ukrainie powinny wynosić 750 mld USD - 1 bln USD - uważa William Taylor, były ambasador USA na Ukrainie, cytowany w poniedziałek przez The Kyiv Independent.</p>

## Przyspawani do stołków i po wyborach? PiS chce powołania Rady ds. bezpieczeństwa strategicznego
 - [https://www.bankier.pl/wiadomosc/PiS-chce-powolania-Rady-ds-bezpieczenstwa-strategicznego-8428157.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PiS-chce-powolania-Rady-ds-bezpieczenstwa-strategicznego-8428157.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 18:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/a/940d811ac536c1-948-568-0-47-1729-1037.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PiS chce powołania Rady ds. bezpieczeństwa strategicznego, która wydawałaby opinie w sprawie odwołania członków organów nadzorczych oraz odwołania i zawieszenia w czynnościach członków organów zarządzających spółek PKN Orlen, PERN, PSE, Gaz-System i Polfa Tarchomin - wynika z projektu ustawy złożonego przez grupę posłów PiS. Rozwiązanie miałoby zwiększyć stabilność składu rad nadzorczych i zarządów tych spółek.</p>

## Talibowie otworzą ambasadę w Izraelu? Na razie chcą nawiązać stosunki
 - [https://www.bankier.pl/wiadomosc/Talibowie-otworza-ambasade-w-Izraelu-Na-razie-chca-nawiazac-stosunki-8428152.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Talibowie-otworza-ambasade-w-Izraelu-Na-razie-chca-nawiazac-stosunki-8428152.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 18:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/f/e0ca88ff79d4b4-948-568-121-0-2400-1440.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niektórzy przedstawiciele rządzącego Afganistanem Talibanu są skłonni nawiązać stosunki z Izraelem - poinformował w poniedziałek portal Israel Today, powołując się na pragnącego zachować anonimowość przedstawiciela afgańskich władz.</p>

## WIG20 pozostaje w konsolidacji. Warto obserwować indeks S&P500;
 - [https://www.bankier.pl/wiadomosc/WIG20-pozostaje-w-konsolidacji-Warto-obserwowac-indeks-S-P500-8428125.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/WIG20-pozostaje-w-konsolidacji-Warto-obserwowac-indeks-S-P500-8428125.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 17:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/6002bf98f2266b-945-560-25-56-1706-1023.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Indeks WIG20 pozostaje w konsolidacji i dopiero przełamanie oporu na poziomie 1.450 pkt. da nadzieję na rozpoczęcie średnioterminowej korekty wzrostowej - ocenił w rozmowie z PAP Biznes Przemysław Smoliński, analityk BM PKO BP. W najbliższym czasie inwestorzy powinni obserwować zachowanie indeksów w USA, szczególnie S&amp;P500.</p>

## Iran sprzedał Rosji 40 turbin do gazociągów. Tak twierdzą ukraińskie media
 - [https://www.bankier.pl/wiadomosc/Iran-sprzedal-Rosji-40-turbin-do-gazociagow-Tak-twierdza-ukrainskie-media-8428122.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Iran-sprzedal-Rosji-40-turbin-do-gazociagow-Tak-twierdza-ukrainskie-media-8428122.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 17:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/549d5b95cd3c5f-945-560-0-90-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Iran ogłosił w poniedziałek, że podpisał z Rosją kontrakt na dostawę 40 turbin do gazociągów - poinformowała agencja Ukrinform, powołując się na izraelski dziennik "Times of Israel".</p>

## Orange na dobrej drodze do realizacji celów na '22; pracuje nad ograniczeniem wpływu inflacji na koszty
 - [https://www.bankier.pl/wiadomosc/Orange-na-dobrej-drodze-do-realizacji-celow-na-22-pracuje-nad-ograniczeniem-wplywu-inflacji-na-koszty-opis-8428112.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Orange-na-dobrej-drodze-do-realizacji-celow-na-22-pracuje-nad-ograniczeniem-wplywu-inflacji-na-koszty-opis-8428112.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 17:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/4/0ae23a2997544e-948-568-0-51-1475-884.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Orange Polska jest na dobrej drodze do realizacji celów całorocznych. Jednocześnie grupa pracuje nad ograniczeniem wpływu wyższej inflacji na przyszłe koszty operacyjne - podała spółka w komunikacie.</p>

## Borys: Dobrze byłoby uruchomić fundusze UE, choć je przeceniamy
 - [https://www.bankier.pl/wiadomosc/Borys-Dobrze-byloby-uruchomic-fundusze-UE-choc-je-przeceniamy-8428093.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Borys-Dobrze-byloby-uruchomic-fundusze-UE-choc-je-przeceniamy-8428093.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 16:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/9892333dc9b372-948-568-0-31-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jednym z priorytetów jest utrzymywanie płynności złotowej na jak najniższym poziomie, po to, żeby trzymać kurs walutowy w ryzach - powiedział prezes Polskiego Funduszu Rozwoju Paweł Borys.</p>

## Bank Millennium "policzył" wakacje kredytowe. Wyniki poniżej wymaganych minimów
 - [https://www.bankier.pl/wiadomosc/B-Millennium-liczy-ze-jego-wspolczynniki-kapitalowe-znajda-sie-powyzej-wymagan-do-III-kw-23-8428084.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/B-Millennium-liczy-ze-jego-wspolczynniki-kapitalowe-znajda-sie-powyzej-wymagan-do-III-kw-23-8428084.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 16:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/343e26377d5d7f-945-560-34-107-1691-1014.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bank Millennium liczy, że od IV kwartału jego wyniki będą się poprawiły, a do III kwartału 2023 roku współczynniki kapitałowe znajdą się powyżej minimalnych poziomów. Bank chce zawierać kwartalnie ok. 2 tys. ugód w sprawie kredytów CHF, a w IV kwartale nie spodziewa się większych zmian kosztów ryzyka - poinformowali w poniedziałek przedstawiciele banku.</p>

## Ponad 60 mld zł. Tyle możemy zapłacić za obsługę długu publicznego w 2023 roku
 - [https://www.bankier.pl/wiadomosc/Ponad-60-mld-zl-Tyle-mozemy-zaplacic-za-obsluge-dlugu-publicznego-w-2023-roku-8428062.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ponad-60-mld-zl-Tyle-mozemy-zaplacic-za-obsluge-dlugu-publicznego-w-2023-roku-8428062.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 16:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/3/3394d8418d2b23-948-568-0-0-2924-1754.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W przyszłym roku Polacy zapłacą za obsługę długu publicznego 66 mld zł. To oznacza, że każdy z nas za nieudolność rządzących zapłaci z własnej kieszeni 1,7 tys. zł - mówił w poniedziałek lider Polski2050 Szymon Hołownia. Wezwał rząd do natychmiastowych oszczędności i porozumienia ws. KPO.</p>

## Hiszpańska marynarka wojenna śledzi ruch rosyjskich statków w pobliżu podwodnych kabli
 - [https://www.bankier.pl/wiadomosc/Hiszpanska-marynarka-wojenna-sledzi-ruch-rosyjskich-statkow-w-poblizu-podwodnych-kabli-8428048.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hiszpanska-marynarka-wojenna-sledzi-ruch-rosyjskich-statkow-w-poblizu-podwodnych-kabli-8428048.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 15:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/5/f431102d148dde-948-567-5-27-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Hiszpańska marynarka wojenna patroluje wody terytorialne kraju w związku ze zwiększeniem się w ostatnim roku ruchu tranzytowego rosyjskich statków w pobliżu dużych podmorskich kabli internetowych - poinformowały źródła wojskowe, na które powołał się dziennik "El Periodico de Catalunya".</p>

## PKN Orlen: Trudno połączyć zapewnienie zasobów "na teraz" z transformacją
 - [https://www.bankier.pl/wiadomosc/PKN-Orlen-Trudno-polaczyc-zapewnienie-zasobow-na-teraz-z-transformacja-8428042.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKN-Orlen-Trudno-polaczyc-zapewnienie-zasobow-na-teraz-z-transformacja-8428042.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 15:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/9/fe11d5bf216c82-948-568-0-130-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jesteśmy obecnie w momencie, w którym największe wyzwanie stanowi połączenie krótkookresowej potrzeby zapewnienia bezpieczeństwa energetycznego z długookresowymi wyzwaniami transformacji. Transformacja to zadanie dla pokolenia – mówił Karol Wolff, dyrektor Biura Strategii i Projektów Strategicznych w PKN ORLEN, podczas panelu „Transformacja energetyczna gwarantem bezpieczeństwa?”, który odbył się w trakcie Krynica Forum ’22.</p>

## Węglowa wolna amerykanka. Resort klimatu chce zawieszenia jego norm jakościowych
 - [https://www.bankier.pl/wiadomosc/Resort-klimatu-chce-do-30-kwietnia-2023-zawiesic-normy-jakosciowe-dla-wegla-8428039.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Resort-klimatu-chce-do-30-kwietnia-2023-zawiesic-normy-jakosciowe-dla-wegla-8428039.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 15:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/5/f22d06d51a484f-948-567-0-90-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 27 października br. do 30 kwietnia 2023 r. mają zostać zawieszone normy jakościowe dla paliw stałych - wynika z opublikowanego w poniedziałek projektu rozporządzenia w tej sprawie. Według MKiŚ nowe przepisy pozwolą obniżyć cenę surowca i poprawić dostępność węgla dla gospodarstw domowych.</p>

## Zyski portugalskiego koncernu paliwowego wyższe o 86 proc.
 - [https://www.bankier.pl/wiadomosc/Zyski-portugalskiego-koncernu-paliwowego-wyzsze-o-86-proc-8428024.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zyski-portugalskiego-koncernu-paliwowego-wyzsze-o-86-proc-8428024.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 15:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/2/6d9c046da081a9-948-568-87-0-1050-630.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Największa paliwowa spółka Portugalii firma Galp zanotowała pomiędzy styczniem a wrześniem 2022 r. zysk netto na poziomie 608 mln euro, czyli o 86 proc. więcej w porównaniu do analogicznego okresu w minionym roku - podały w poniedziałek władze koncernu.</p>

## Terminal logistyczny w Rumunii połączy cztery europejskie morza
 - [https://www.bankier.pl/wiadomosc/Terminal-logistyczny-w-Rumunii-polaczy-cztery-europejskie-morza-8428011.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Terminal-logistyczny-w-Rumunii-polaczy-cztery-europejskie-morza-8428011.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 14:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/4/e7bf327aa603d5-948-567-5-70-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Budowany w Siedmiogrodzie, w środkowej Rumunii terminal logistyczny, zostanie połączony z trasami do czterech europejskich mórz: Bałtyku, Czarnego, Północnego oraz Adriatyku - podały w poniedziałek bukareszteńskie media.</p>

## Mołdawia ma problem z prądem. Położona w prorosyjskim Naddniestrzu elektrownia zredukowała dostawy
 - [https://www.bankier.pl/wiadomosc/Moldawia-ma-problem-z-pradem-Polozona-w-prorosyjskim-Naddniestrzu-elektrownia-zredukowala-dostawy-8427998.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Moldawia-ma-problem-z-pradem-Polozona-w-prorosyjskim-Naddniestrzu-elektrownia-zredukowala-dostawy-8427998.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 14:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/c61783e4146a4a-948-569-0-70-991-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Elektrownia Cuciurgan, położona w separatystycznym Naddniestrzu, zredukowała w poniedziałek dostawy energii elektrycznej do Mołdawii - poinformowały w poniedziałek władze tego kraju, cytowane przez kiszyniowską telewizję TV8.</p>

## Koszt jazdy elektrykiem porównywalny z autem spalinowym [Raport]
 - [https://www.bankier.pl/wiadomosc/Koszt-jazdy-elektrykiem-porownywalny-z-autem-spalinowym-Raport-8427995.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koszt-jazdy-elektrykiem-porownywalny-z-autem-spalinowym-Raport-8427995.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 14:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/5/e31fb0ead28cec-948-568-0-79-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosnące ceny energii sprawiają, że koszt przejechania 100 km elektrykiem staje się porównywalny z tym ponoszonym przez posiadaczy aut spalinowych - wynika z opublikowanego w poniedziałek raportu serwisu autobaza.pl.</p>

## Eksperci: w III kw. podwyżki cen wielu materiałów budowlanych spowolniły
 - [https://www.bankier.pl/wiadomosc/Eksperci-w-III-kw-podwyzki-cen-wielu-materialow-budowlanych-spowolnily-8427976.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Eksperci-w-III-kw-podwyzki-cen-wielu-materialow-budowlanych-spowolnily-8427976.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 14:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/2/884585f5c65925-948-568-0-11-4300-2580.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W III kw. 2022 r. podwyżki cen wielu materiałów budowlanych spowolniły, a części spadły - wynika z analizy portalu GetHome.pl. Eksperci zwrócili uwagę, że przyspieszył natomiast wzrost kosztów robocizny.</p>

## Rishi Sunak nowym premierem Wielkiej Brytanii. Był ministrem finansów
 - [https://www.bankier.pl/wiadomosc/Rishi-Sunak-nowym-premierem-Wielkiej-Brytanii-Byl-ministrem-finansow-8427963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rishi-Sunak-nowym-premierem-Wielkiej-Brytanii-Byl-ministrem-finansow-8427963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 14:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/a/0301fc6403c5b1-948-568-0-70-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rishi Sunak, były minister finansów Wielkiej Brytanii, został w poniedziałek nowym liderem rządzącej Partii Konserwatywnej i w efekcie obejmie urząd premiera kraju. Sunak jako jedyny z pretendentów do przywództwa w partii uzyskał wymagane poparcie minimum 100 posłów.</p>

## Mbappé rozbił bank. Największy kontrakt w historii sportu
 - [https://www.bankier.pl/wiadomosc/Mbappe-rozbil-bank-Najwiekszy-kontrakt-w-historii-sportu-8427900.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mbappe-rozbil-bank-Najwiekszy-kontrakt-w-historii-sportu-8427900.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 13:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/b/acd438d370fb05-948-568-0-0-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Napastnik Paris Saint-Germain, Kylian Mbappé, po wielu spekulacjach zdecydował się zostać w dotychczasowym klubie. Skusić go miały pieniądze — i to olbrzymie, nawet jak na "piłkarskie" standardy wynika z informacji "Le Parisien".</p>

## Kilkuset rolników złożyło wnioski o zakup miałów węglowych z PGG
 - [https://www.bankier.pl/wiadomosc/Kilkuset-rolnikow-zlozylo-wnioski-o-zakup-mialow-weglowych-z-PGG-8427949.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kilkuset-rolnikow-zlozylo-wnioski-o-zakup-mialow-weglowych-z-PGG-8427949.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 13:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/2/1bb2286a03ceb2-945-560-7-157-2987-1792.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska Grupa Górnicza otrzymała dotychczas kilkaset wniosków od rolników zainteresowanych ofertą zakupu miałów energetycznych do celów związanych z produkcją rolną. Pula węgla dla rolników nie została jeszcze wyczerpana - wynika z informacji przekazanej PAP w poniedziałek przez PGG.</p>

## Wrocław otrzymał ponad 175 mln zł z funduszy unijnych na rozbudowę lotniska
 - [https://www.bankier.pl/wiadomosc/Wroclaw-otrzymal-ponad-175-mln-zl-z-funduszy-unijnych-na-rozbudowe-lotniska-8427931.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wroclaw-otrzymal-ponad-175-mln-zl-z-funduszy-unijnych-na-rozbudowe-lotniska-8427931.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 13:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/67a90da7d81757-948-568-50-322-3981-2388.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 175 mln zł dofinansowania unijnego otrzymał projekt rozbudowy i modernizacji Portu Lotniczego Wrocław. Powstaną m.in. nowa płyta postojowa, równoległa droga kołowania. Dzięki rozbudowie zwiększy się przepustowość lotniska.</p>

## Będzie "Plan Marshalla" dla Ukrainy? Potrzeba minimum 750 mld dolarów
 - [https://www.bankier.pl/wiadomosc/Bedzie-Plan-Marshalla-dla-Ukrainy-Potrzeba-minimum-750-mld-dolarow-8427907.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bedzie-Plan-Marshalla-dla-Ukrainy-Potrzeba-minimum-750-mld-dolarow-8427907.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 13:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/8/f6bd1402de5bfc-948-568-9-204-3694-2216.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przewodnicząca Komisji Europejskiej Ursula von der Leyen i kanclerz Niemiec Olaf Scholz (SPD) prowadzą kampanię na rzecz opracowania "Planu Marshalla" na rzecz odbudowy Ukrainy. Projekt ten ma być dyskutowany podczas poniedziałkowej konferencji w Berlinie - poinformował "Tagesschau".</p>

## Niepewny gazociąg BarMar w Morzu Śródziemnym? "Przechodzi przez obszar pod ochroną"
 - [https://www.bankier.pl/wiadomosc/Niepewny-gazociag-BarMar-w-Morzu-Srodziemnym-Przechodzi-przez-obszar-pod-ochrona-8427895.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niepewny-gazociag-BarMar-w-Morzu-Srodziemnym-Przechodzi-przez-obszar-pod-ochrona-8427895.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 12:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/2/92250483bf3db7-948-569-0-17-1716-1030.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ogłoszona w czwartek przez władze Hiszpanii, Francji i Portugalii budowa podwodnego gazociągu BarMar jest planowana w akwenie Morza Śródziemnego o dużych walorach ekologicznych i częściowo znajdującym się pod ochroną - powiadomiły w poniedziałek hiszpańskie media.</p>

## Logowanie bez PIN-u i wniosek o dodatek węglowy. mObywatel z nowymi funkcjami
 - [https://www.bankier.pl/wiadomosc/Aktualizacja-aplikacji-mObywatel-Rzad-wprowadzil-kilka-waznych-zmian-8427883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Aktualizacja-aplikacji-mObywatel-Rzad-wprowadzil-kilka-waznych-zmian-8427883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 12:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/2/94b27a5ef991db-948-568-412-0-1352-811.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najświeższa aktualizacja aplikacji mObywatel pozwala już korzystać z kilku interesujących funkcji, na które użytkownicy czekali od dłuższego czasu. Dotyczy to nie tylko dokumentów przechowywanych w wirtualnym portfelu, ale także sposobu logowania.
</p>

## Starcie o Downing Street trwa. Niejasna przyszłość kandydatury Mordaunt
 - [https://www.bankier.pl/wiadomosc/Starcie-o-Downing-Street-trwa-Niejasna-przyszlosc-kandydatury-Mordaunt-8427873.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Starcie-o-Downing-Street-trwa-Niejasna-przyszlosc-kandydatury-Mordaunt-8427873.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 12:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/0aac10620281a7-945-567-417-0-2941-1765.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ubiegająca się o przywództwo w Partii Konserwatywnej przewodnicząca brytyjskiej Izby Gmin Penny Mordaunt ma już poparcie 90 posłów - twierdzą źródła z jej obozu. Aby pozostać w wyścigu o urząd premiera Mordaunt musi do godz. 15 polskiego czasu zdobyć poparcie 100 deputowanych.</p>

## We Francji powstanie kopalnia litu. Pierwsza w kraju i jedna z największych w Europie
 - [https://www.bankier.pl/wiadomosc/We-Francji-powstanie-kopalnia-litu-Pierwsza-w-kraju-i-jedna-z-najwiekszych-w-Europie-8427865.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/We-Francji-powstanie-kopalnia-litu-Pierwsza-w-kraju-i-jedna-z-najwiekszych-w-Europie-8427865.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 12:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/b7e0e1cb5d6561-945-567-9-67-1910-1146.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa wydobywcza Imerys zamierza zostać europejskim liderem produkcji litu. Ma to umożliwić wyceniana na ok. 1 mld euro inwestycja we francuskim Allier w uruchomienie pierwszej w kraju i jednej z największych w Europie kopalni tego metalu - ogłosiła spółka w poniedziałek.</p>

## Musk planuje zwolnienia w Twitterze. I to ogromne
 - [https://www.bankier.pl/wiadomosc/Musk-planuje-zwolnienia-w-Twitterze-I-to-ogromne-8427832.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Musk-planuje-zwolnienia-w-Twitterze-I-to-ogromne-8427832.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 12:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/d/8971e6b8c5a5bd-948-568-0-4-1822-1093.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kolejny rozdział sagi pt. "Elon Musk i Twitter". Miliarder ma planować zwolnienie 75 proc. pracowników Twittera — informuje Washington Post.</p>

## Poważne kłopoty byłego szefa Banku Narodowego Ukrainy. Jest poszukiwany
 - [https://www.bankier.pl/wiadomosc/Powazne-klopoty-bylego-szefa-Banku-Narodowego-Ukrainy-Jest-poszukiwany-8427858.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powazne-klopoty-bylego-szefa-Banku-Narodowego-Ukrainy-Jest-poszukiwany-8427858.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 12:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/fcecabf543f518-948-568-0-103-4559-2735.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Narodowe Biuro Antykorupcyjne Ukrainy (NABU) poinformowało, że poszukiwany jest były szef Narodowego Banku Ukrainy Kyryło Szewczenko. Trwa również dochodzenie w sprawie dwóch innych osób, które miały popełnić przestępstwa finansowe, piastując kierownicze stanowiska w Ukrhazbanku w latach 2014-2019.</p>

## Czy tym razem sprawdzony cykl wyznaczy dno na bitcoinie?
 - [https://www.bankier.pl/wiadomosc/Czy-tym-razem-sprawdzony-cykl-wyznaczy-dno-na-bitcoinie-8427856.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czy-tym-razem-sprawdzony-cykl-wyznaczy-dno-na-bitcoinie-8427856.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 12:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/3/b73b26532424e9-948-568-700-0-3033-1820.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W najbliższym czasie może dojść do interesującego połączenia dwóch czynników, które mogą wspierać rynek kryptowalut. W momencie, gdy od roku trwa rynek niedźwiedzia, spekulanci próbują znaleźć potencjalne światełko w tunelu. Takie może się pojawić tej jesieni - sugeruje ekspert.</p>

## Mocna korekta na polskich obligacjach
 - [https://www.bankier.pl/wiadomosc/Mocna-korekta-na-polskich-obligacjach-8427844.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mocna-korekta-na-polskich-obligacjach-8427844.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 11:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/f/1e47d3be30bbb9-945-560-10-10-3990-2393.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poniedziałkowe przedpołudnie stało pod znakiem gwałtownego spadku
rentowności emitowanych przez rząd Polski.</p>

## Idą zmiany dla Ukraińców. Obowiązkowy PESEL, dopłaty do pobytu - a to nie koniec
 - [https://www.bankier.pl/wiadomosc/Ida-zmiany-dla-Ukraincow-Obowiazkowy-PESEL-doplaty-do-pobytu-a-to-nie-koniec-8427127.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ida-zmiany-dla-Ukraincow-Obowiazkowy-PESEL-doplaty-do-pobytu-a-to-nie-koniec-8427127.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 11:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/c/7847c9e97f0e8f-948-568-26-0-3516-2109.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W RCL został opublikowany projekt nowelizacji ustawy o pomocy obywatelom Ukrainy. Zgodnie z nim uchodźcy - z wyjątkami - zaczną pokrywać część kosztów utrzymania w miejscach zbiorowego zakwaterowania. Obowiązkowe stanie się ponadto wnioskowanie o PESEL. Zmiany mają też uszczelnić system świadczeń.</p>

## Tarcza antyinflacyjna przedłużona, jest podpis prezydenta. VAT na energię, paliwa czy żywność obniżony
 - [https://www.bankier.pl/wiadomosc/Tarcza-antyinflacyjna-przedluzona-jest-podpis-prezydenta-VAT-na-energie-paliwa-czy-zywnosc-obnizony-8427812.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tarcza-antyinflacyjna-przedluzona-jest-podpis-prezydenta-VAT-na-energie-paliwa-czy-zywnosc-obnizony-8427812.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 11:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/f/43b1f721f4abf4-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda podpisał ustawę 
przedłużającą tarczę antyinflacyjną - poinformowała w poniedziałek 
Kancelaria Prezydenta RP. Oznacza to, że niższe stawki VAT m.in. na 
żywność, paliwa, a także zwolnienie z akcyzy energii elektrycznej będą 
obowiązywać do 31 grudnia br.</p>

## Morawiecki: Polski system finansów publicznych jest stabilny
 - [https://www.bankier.pl/wiadomosc/Morawiecki-Polski-system-finansow-publicznych-jest-stabilny-8427801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Morawiecki-Polski-system-finansow-publicznych-jest-stabilny-8427801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 10:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/7/fad5a703a9db58-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska ma zapewnione 30-35 proc. prefinansowania na rok przyszły - poinformował w poniedziałek podczas konferencji prasowej premier Mateusz Morawiecki. Dodał, że aukcje obligacji będą organizowane, kiedy wydarzą się ku temu najlepsze, najwłaściwsze warunki.</p>

## 5 godzin przerwy w pracy dla rodzica. Pomysł radykalnych zmian w Kodeksie pracy
 - [https://www.bankier.pl/wiadomosc/5-godzin-przerwy-w-pracy-dla-rodzica-Pomysl-radykalnych-zmian-w-Kodeksie-pracy-8427795.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/5-godzin-przerwy-w-pracy-dla-rodzica-Pomysl-radykalnych-zmian-w-Kodeksie-pracy-8427795.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 10:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/15491630bf0d26-948-568-0-55-2228-1336.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Planowane zmiany w Kodeksie pracy przewidują, że pracownicy wychowujący dziecko, do ukończenia przez nie ośmiu lat, będą mogli wnioskować o przerywany czas pracy, nawet do 5 godzin dziennie. Firmom będzie trudno odmówić takim żądaniom, a za naruszenia w tym zakresie czekają je drakońskie kary – informuje serwis Prawo.pl.</p>

## InPost dba o bezpieczeństwo klientów. Są ważne zmiany w etykietach
 - [https://www.bankier.pl/wiadomosc/InPost-wprowadzil-zmiany-w-etykietach-Ktore-informacje-z-nich-zniknely-8427729.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/InPost-wprowadzil-zmiany-w-etykietach-Ktore-informacje-z-nich-zniknely-8427729.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 10:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/2/e2a413fe145264-945-560-0-81-1632-979.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Osoby korzystające z usług firmy InPost zapewne zdążyły już zauważyć, że etykiety umieszczane na paczkach uległy znaczącym zmianom. Najważniejszą z nich jest większa anonimizacja danych nadawców i odbiorców. To jednak tylko sam początek listy.</p>

## EuroPMI najniżej od niemal dwóch lat. Recesja nieunikniona?
 - [https://www.bankier.pl/wiadomosc/Wskazniki-PMI-w-strefie-euro-pazdziernik-2022-8427754.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wskazniki-PMI-w-strefie-euro-pazdziernik-2022-8427754.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 09:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/5873b001de3eac-948-567-5-0-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wskaźnik PMI dla gospodarki strefy euro znalazł się na
najniższym poziomie od 23- miesięcy – donosi S&amp;P Global.</p>

## Kurs euro poniżej 4,80 zł. Dolar i frank „odpadły” od linii 5 zł
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-ponizej-4-80-zl-8427724.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-ponizej-4-80-zl-8427724.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 09:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/3/84a612531c9a9d-948-567-25-55-955-572.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs euro pozostał poniżej 4,80 zł. Notowania dolara
amerykańskiego i franka szwajcarskiego znalazły się już wyraźnie poniżej
bariery 5 zł.</p>

## Kierunek: drożyzna. Większość średnich i dużych firm w Polsce chce podnosić ceny
 - [https://www.bankier.pl/wiadomosc/Kierunek-drozyzna-Wiekszosc-srednich-i-duzych-firm-w-Polsce-chce-podnosic-ceny-8427719.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kierunek-drozyzna-Wiekszosc-srednich-i-duzych-firm-w-Polsce-chce-podnosic-ceny-8427719.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 09:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/9/c06ce0f59239ff-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />76 proc. średnich i dużych firm w Polsce chce w najbliższych 12 miesiącach podnosić ceny swoich produktów - wskazano w raporcie firmy Grant Thornton. Największy wzrost odsetka firm planujących podwyżki jest w Irlandii, Grecji i Szwecji - podano.</p>

## Masłowska (RPP) przedstawiła dwie strategie ws. stóp procentowych. Sama jest przeciwniczką radykalnych podwyżek
 - [https://www.bankier.pl/wiadomosc/Maslowska-RPP-przedstawila-dwie-strategie-ws-stop-procentowych-Sama-jest-przeciwniczka-radykalnych-podwyzek-8427714.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Maslowska-RPP-przedstawila-dwie-strategie-ws-stop-procentowych-Sama-jest-przeciwniczka-radykalnych-podwyzek-8427714.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 08:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/3/41f4a99fbd4ab2-948-568-1105-552-1570-942.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po listopadowej projekcji inflacji należy podjąć decyzję, czy dalej umiarkowanie podwyższać stopy procentowe, czy też pozostawić je bez zmian, ale na dłużej - napisała w artykule dla Radia Maryja członkini RPP Gabriela Masłowska. Ekonomistka jest przeciwniczką radykalnych podwyżek stóp.</p>

## Ceny gazu mocno w dół
 - [https://www.bankier.pl/wiadomosc/Ceny-gazy-mocno-w-dol-8427710.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-gazy-mocno-w-dol-8427710.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 08:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/3/ae14239b33a59b-948-568-0-92-1156-693.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W poniedziałek ok. godz. 9.30 gaz ziemny w holenderskim hubie TTF w kontraktach na listopad taniał o ponad 8 proc., do 103,6 euro za MWh. Taniały również kontrakty grudniowe, do 136,75 euro za MWh, oraz styczniowe, do 143,36 euro za MWh.</p>

## Kryzys, jaki kryzys? Kancelaria Premiera przeznaczy 10 mln zł więcej na podwyżki i etaty w 2023 roku
 - [https://www.bankier.pl/wiadomosc/10-mln-zl-wiecej-na-podwyzki-i-etaty-w-Kancelarii-Premiera-8427686.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/10-mln-zl-wiecej-na-podwyzki-i-etaty-w-Kancelarii-Premiera-8427686.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 08:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/1/202fdc51f26718-948-568-0-149-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na nowe etaty i podwyżki dla pracowników Kancelarii Prezesa Rady Ministrów z budżetu państwa zostanie przeznaczone o 10 mln zł więcej niż obecnie. Łącznie na wydatki KPRM pochłoną 1,5 mld zł – podaje "Fakt".</p>

## Drogo, coraz drożej. Wzrost cen w turystyce odstrasza Polaków
 - [https://www.bankier.pl/wiadomosc/Drogo-coraz-drozej-Wzrost-cen-w-turystyce-odstrasza-Polakow-8427690.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Drogo-coraz-drozej-Wzrost-cen-w-turystyce-odstrasza-Polakow-8427690.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 07:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/b/8d4c9518840ac0-945-560-686-652-3131-1878.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Hotele i apartamenty windują ceny, właściciele mniejszych obiektów noclegowych wciąż decydują czy w ogóle działać w sezonie zimowym. O ile liczba rezerwacji na święta jest zbliżona do zeszłorocznej, to sylwestrowych rezerwacji jest o jedną czwartą mniej niż w zeszłym roku o

## Silna przecena na chińskich giełdach
 - [https://www.bankier.pl/wiadomosc/Silna-przecena-na-chinskich-gieldach-8427675.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Silna-przecena-na-chinskich-gieldach-8427675.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 07:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/a/7e3daa07521a84-948-568-12-168-2487-1492.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chińskie giełdy reagują silną przeceną na wyniki zakończonego Zjazdu KPCh oraz opublikowane z opóźnieniem dane makroekonomiczne.</p>

## Drogie wakacje kredytowe. Bank Millennium z dużą stratą w III kw. 2022 r.
 - [https://www.bankier.pl/wiadomosc/Strata-netto-Banku-Millennium-w-III-kw-wyniosla-1-001-mln-zl-zgodna-z-oczekiwaniami-8427660.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Strata-netto-Banku-Millennium-w-III-kw-wyniosla-1-001-mln-zl-zgodna-z-oczekiwaniami-8427660.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 06:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/6910f3fed830aa-945-567-14-0-1780-1068.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Strata netto grupy Banku Millennium w trzecim kwartale 2022 roku wyniosła 1.000,9 mln zł podczas gdy rok wcześniej strata wynosiła 311,3 mln zł - poinformował bank w raporcie. Wynik banku okazał zgodny z oczekiwaniami, bowiem konsensus PAP Biznes zakładał stratę na poziomie 98

## Branża kurierska podnosi ceny. Dostawa prezentu pod choinkę będzie wyjątkowo droga
 - [https://www.bankier.pl/wiadomosc/Branza-kurierska-podnosi-ceny-Dostawa-prezentu-pod-choinke-bedzie-wyjatkowo-droga-8427659.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Branza-kurierska-podnosi-ceny-Dostawa-prezentu-pod-choinke-bedzie-wyjatkowo-droga-8427659.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 06:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/4318847f466346-945-567-96-218-3403-2042.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tegoroczny świąteczny szczyt paczkowy będzie inny niż wszystkie do tej pory – zamiast boomu czeka nas hamowanie. Firmy z branży kurierskiej podnoszą ceny usług i wprowadzają dodatkowe opłaty - pisze w poniedziałek "Rzeczpospolita”.</p>

## Regiony górnicze przygotowują się na życie po węglu
 - [https://www.bankier.pl/wiadomosc/Regiony-gornicze-przygotowuja-sie-na-zycie-po-weglu-8427623.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Regiony-gornicze-przygotowuja-sie-na-zycie-po-weglu-8427623.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 05:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/6/5ede240917d9a6-948-568-0-0-4608-2764.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Odchodzenie od węgla jest w Polsce nieuchronne - 
nie tylko ze względu na politykę klimatyczną UE, ale i fakt, że 
wytwarzanie energii z tego surowca jest nieopłacalne, a poza tym jego 
rezerwy powoli się kończą. Transformacja energetyczna, która wiąże się 
z zamykaniem kopalń 

## Rynek kredytów hipotecznych w coraz większym kryzysie. Banki walczą o klientów posiadających zdolność kredytową
 - [https://www.bankier.pl/wiadomosc/Rynek-kredytow-hipotecznych-w-coraz-wiekszym-kryzysie-Banki-walcza-o-klientow-posiadajacych-zdolnosc-kredytowa-8427622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rynek-kredytow-hipotecznych-w-coraz-wiekszym-kryzysie-Banki-walcza-o-klientow-posiadajacych-zdolnosc-kredytowa-8427622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 05:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/c/6efe1e17eb8edf-948-568-0-130-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kilka ostatnich miesięcy było najgorszym okresem na 
rynku kredytów hipotecznych od wielu lat. Podwyżki stóp procentowych 
i rekomendacje KNF spowodowały, że hipoteki stały się dostępne tylko 
dla nielicznych, a część klientów boi się zaciągać takie zobowiązanie 
w obecnym, n

## WIBOR kontra WIRON. PKO BP nie będzie oferował równolegle kredytów opartych na obu wskaźnikach
 - [https://www.bankier.pl/wiadomosc/WIBOR-kontra-WIRON-PKO-BP-nie-bedzie-oferowal-rownolegle-kredytow-opartych-na-obu-wskaznikach-8427612.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/WIBOR-kontra-WIRON-PKO-BP-nie-bedzie-oferowal-rownolegle-kredytow-opartych-na-obu-wskaznikach-8427612.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 05:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/50ea7e1f7bf709-948-568-12-151-2410-1446.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Udostępnienie produktów opartych na WIRON odbędzie się przy wycofaniu oferty opartej na WIBOR – podał bank PKO BP w odpowiedzi na pytania PAP.</p>

## KRD: 31 grudnia firmy mogą stracić miliardy złotych z nieopłaconych faktur
 - [https://www.bankier.pl/wiadomosc/KRD-31-grudnia-firmy-moga-stracic-miliardy-zlotych-z-nieoplaconych-faktur-8427609.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KRD-31-grudnia-firmy-moga-stracic-miliardy-zlotych-z-nieoplaconych-faktur-8427609.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/07a31c14b89389-948-567-25-0-975-584.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />31 grudnia br. przedawnią się faktury wystawione przez firmy w 2020 r. - przepaść mogą miliardy złotych, bo część należności jest płacona przez klientów z opóźnieniem - zauważa szef KRD Adam Łącki. Pieniądze można odzyskać, jeśli przedsiębiorcy zdecydują się np. na windykację po

## Chciała „strukturę”, dostała obligacje GetBack jako "inwestycyjną okazję". Bank ma zwrócić klientce pieniądze
 - [https://www.bankier.pl/wiadomosc/Chciala-strukture-dostala-obligacje-GetBack-jako-inwestycyjna-okazje-Bank-ma-zwrocic-klientce-pieniadze-8427519.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chciala-strukture-dostala-obligacje-GetBack-jako-inwestycyjna-okazje-Bank-ma-zwrocic-klientce-pieniadze-8427519.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/54de6169aa617d-948-568-0-290-4311-2586.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W wydanym we wrześniu wyroku krakowski sąd orzekł, że bank
powinien zwrócić klientce 45 tys. zł. Kwota ta ma stanowić wyrównanie straty
poniesionej po nabyciu za pośrednictwem banku obligacji firmy GetBack. W uzasadnieniu
wskazano, że instytucja dopuściła się missellingu.</p>

## Na Bankier.pl rusza Akademia Blockchain
 - [https://www.bankier.pl/wiadomosc/Akademia-Blockchain-w-Bankier-pl-Idea-program-eksperci-8422285.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Akademia-Blockchain-w-Bankier-pl-Idea-program-eksperci-8422285.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/9/c10f3f97021b10-948-568-23-9-1871-1122.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />28 października rusza Akademia Blockchain, cykl edukacyjnych webinarów realizowany przez Fundację Cyberium we współpracy z Bankier.pl. W 
pierwszym odcinku opowiemy o tym, czym blockchain jest, w jakich 
branżach może znaleźć zastosowanie i kogo w związku z tym powinien 
inter

## Najlepsze TERAZ konta oszczędnościowe. Trzy banki dadzą zarobić 8 proc. rocznie
 - [https://www.bankier.pl/wiadomosc/Ranking-kont-oszczednosciowych-pazdziernik-2022-Najlepsze-konto-8426183.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-kont-oszczednosciowych-pazdziernik-2022-Najlepsze-konto-8426183.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/ea5944eb32ef09-948-568-0-0-3233-1940.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />8 proc. w skali roku to stawka, którą można otrzymać nie tylko za zamrożenie środków na lokacie terminowej. Takie oprocentowanie jest dostępne na kontach oszczędnościowych w trzech bankach i to nie tylko dla nowych klientów.</p>

## Revolut i blokady kont. Klienci skarżą się na utrudniony dostęp do pieniędzy: "zaczyna to wyglądać jak kradzież środków"
 - [https://www.bankier.pl/wiadomosc/Revolut-i-blokady-kont-Klienci-skarza-sie-na-utrudniony-dostep-do-pieniedzy-zaczyna-to-wygladac-jak-kradziez-srodkow-8426005.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Revolut-i-blokady-kont-Klienci-skarza-sie-na-utrudniony-dostep-do-pieniedzy-zaczyna-to-wygladac-jak-kradziez-srodkow-8426005.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/d6309057f472c2-948-568-0-214-3178-1906.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Revolut to jedna z najpopularniejszych aplikacji finansowych - w Polsce korzysta z niej już 1,7 mln klientów. Każdej aplikacji zdarzają się jednak problemy i Revolut nie jest wyjątkiem. Czytelnicy skarżą się nam na blokady dostępu do środków, problemy z obsługą przez konsulta

## Sprzedający zaczęli obniżać oczekiwania. Tańsze mieszkania głównie na rynku wtórnym
 - [https://www.bankier.pl/wiadomosc/Ceny-ofertowe-mieszkan-pazdziernik-2022-Raport-Bankier-pl-8426816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-ofertowe-mieszkan-pazdziernik-2022-Raport-Bankier-pl-8426816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/b/0c663fbbf1616d-948-568-0-286-4250-2549.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wrzesień przyniósł odważniejsze obniżki oczekiwań sprzedających mieszkania na rynku wtórnym – wynika z danych Bankier.pl udostępnionych przez serwis nieruchomości Otodom. Mniej skorzy do tego byli deweloperzy, choć i na rynku pierwotnym można było znaleźć miasta i metraże, w 

## Gwałtowny wzrost imigracji do USA z Ameryki Łacińskiej
 - [https://www.bankier.pl/wiadomosc/Gwaltowny-wzrost-imigracji-do-USA-z-Ameryki-Lacinskiej-8427600.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gwaltowny-wzrost-imigracji-do-USA-z-Ameryki-Lacinskiej-8427600.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2022-10-24 02:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/0954a5f91a2cf2-945-560-0-0-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Gwałtowny wzrost imigracji do USA z Wenezueli, Kuby i Nikaragui we wrześniu zwiększył liczbę nielegalnych imigrantów w zakończonym 30 września roku podatkowym do najwyższego z dotychczasowych poziomu . Na granicy z Meksykiem zatrzymano w ciągu 12 miesięcy 227 547 osób.</p>


# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## 10 Final Fantasy 14 tips to conquer tank anxiety
 - [https://www.pcgamer.com/final-fantasy-14-tanking-guide-tips](https://www.pcgamer.com/final-fantasy-14-tanking-guide-tips)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 23:46:46+00:00

Here's how I learned to stop worrying and love tanking in FF14.

## V Rising, the other vampire survival hit of 2022, is going free to play for Halloween
 - [https://www.pcgamer.com/v-rising-the-other-vampire-survival-hit-of-2022-is-going-free-to-play-for-halloween](https://www.pcgamer.com/v-rising-the-other-vampire-survival-hit-of-2022-is-going-free-to-play-for-halloween)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 23:43:23+00:00

There's also free Halloween-themed DLC and a big new patch out today.

## Everything videogames have taught you about medieval pigs was a lie
 - [https://www.pcgamer.com/everything-videogames-have-taught-you-about-medieval-pigs-was-a-lie](https://www.pcgamer.com/everything-videogames-have-taught-you-about-medieval-pigs-was-a-lie)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 23:20:55+00:00

This little piggy is lacking in historical accuracy!

## 'Sexual assault' custom game mode reveals a glaring Overwatch moderation problem
 - [https://www.pcgamer.com/sexual-assault-custom-game-mode-reveals-a-glaring-overwatch-moderation-problem](https://www.pcgamer.com/sexual-assault-custom-game-mode-reveals-a-glaring-overwatch-moderation-problem)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 22:25:33+00:00

Blizzard has removed the listing for an offensive mode, but it's still available to play through a unique code.

## This gaming chair will literally keep you on the edge of your seat
 - [https://www.pcgamer.com/this-gaming-chair-will-literally-keep-you-on-the-edge-of-your-seat](https://www.pcgamer.com/this-gaming-chair-will-literally-keep-you-on-the-edge-of-your-seat)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 21:58:43+00:00

The Playseat Active Gaming Seat is designed for 'attack mode' gamers.

## From his hospital bed, this young Valorant player demolished the opposing team
 - [https://www.pcgamer.com/from-his-hospital-bed-this-young-valorant-player-demolished-the-opposing-team](https://www.pcgamer.com/from-his-hospital-bed-this-young-valorant-player-demolished-the-opposing-team)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 21:00:52+00:00

Nishil Shah was hospitalized with a medical emergency, but that didn't keep him out of the match.

## The best Sims 4 custom content for gorgeous Sims and homes
 - [https://www.pcgamer.com/sims-4-cc-maxis-match-custom-content](https://www.pcgamer.com/sims-4-cc-maxis-match-custom-content)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 20:36:41+00:00

We've collected some of the best Sims 4 CC you can install to turn your Sims into style icons and homes into catalog shots.

## World's foremost PC gamer is back as Superman
 - [https://www.pcgamer.com/worlds-foremost-pc-gamer-is-back-as-superman](https://www.pcgamer.com/worlds-foremost-pc-gamer-is-back-as-superman)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 20:34:48+00:00

Henry Cavill confirms he's putting the cape on once again.

## The best Fallout game was almost just an expansion pack
 - [https://www.pcgamer.com/the-best-fallout-game-was-almost-just-an-expansion-pack](https://www.pcgamer.com/the-best-fallout-game-was-almost-just-an-expansion-pack)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 19:54:16+00:00

Obsidian's RPG masterpiece, Fallout: New Vegas, wasn't originally going to be a standalone game.

## It looks like Discord voice chat is coming to PS5, too
 - [https://www.pcgamer.com/it-looks-like-discord-voice-chat-is-coming-to-ps5-too](https://www.pcgamer.com/it-looks-like-discord-voice-chat-is-coming-to-ps5-too)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 19:46:03+00:00

PC gaming's biggest chat client may be building another bridge to landlocked consoles.

## 'Activision's effect on Blizzard was like a frog in a boiling pot of water' says former Blizzard director
 - [https://www.pcgamer.com/activisions-effect-on-blizzard-was-like-a-frog-in-a-boiling-pot-of-water-says-former-blizzard-director](https://www.pcgamer.com/activisions-effect-on-blizzard-was-like-a-frog-in-a-boiling-pot-of-water-says-former-blizzard-director)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 19:40:30+00:00

And why you shouldn't blame the French for Blizzard North's closure.

## Terraria becomes the first indie hit to break 1M positive user reviews on Steam
 - [https://www.pcgamer.com/terraria-becomes-the-first-indie-hit-to-break-1m-positive-user-reviews-on-steam](https://www.pcgamer.com/terraria-becomes-the-first-indie-hit-to-break-1m-positive-user-reviews-on-steam)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 19:23:27+00:00

It's also the only one of the five most-reviewed games on Steam to have an "overwhelmingly popular" user rating.

## Horror developers: please let P.T. have its eternal rest
 - [https://www.pcgamer.com/horror-developers-please-let-pt-have-its-eternal-rest](https://www.pcgamer.com/horror-developers-please-let-pt-have-its-eternal-rest)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 18:25:29+00:00

Perpetually tired.

## 2022 games: all the new and upcoming games this year
 - [https://www.pcgamer.com/new-games-2022](https://www.pcgamer.com/new-games-2022)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 18:05:09+00:00

The calendar of new games coming to PC in 2022, broken down month-by-month.

## Victoria 3 review
 - [https://www.pcgamer.com/victoria-3-review](https://www.pcgamer.com/victoria-3-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 16:00:14+00:00

Time for some revolutions.

## Don't bend 600W RTX 4090 power cable to reduce risk of overheating says CableMod
 - [https://www.pcgamer.com/dont-bend-600w-rtx-4090-power-cable-to-reduce-risk-of-overheating-says-cablemod](https://www.pcgamer.com/dont-bend-600w-rtx-4090-power-cable-to-reduce-risk-of-overheating-says-cablemod)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 15:44:22+00:00

Fresh concerns for the 12VHPWR connector have arisen following one user's unfortunate run-in with a faulty unit.

## Fallout 4 is getting a free 4K update next year
 - [https://www.pcgamer.com/fallout-4-is-getting-a-free-4k-update-next-year](https://www.pcgamer.com/fallout-4-is-getting-a-free-4k-update-next-year)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 15:41:09+00:00

The update will also include bug fixes and performance mode features for high frame rates.

## Diablo 3 took so long to get rid of its auction house because 'it was on the box'
 - [https://www.pcgamer.com/diablo-3-took-so-long-to-get-rid-of-its-auction-house-because-it-was-on-the-box](https://www.pcgamer.com/diablo-3-took-so-long-to-get-rid-of-its-auction-house-because-it-was-on-the-box)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 15:19:52+00:00

Lawyer up.

## Where to find haunted furniture in Fortnite
 - [https://www.pcgamer.com/fortnite-haunted-furniture-destroy](https://www.pcgamer.com/fortnite-haunted-furniture-destroy)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 15:10:12+00:00

And how to destroy it for the Fortnitemares quest.

## It just got much easier to find the best mods in Teardown
 - [https://www.pcgamer.com/it-just-got-much-easier-to-find-the-best-mods-in-teardown](https://www.pcgamer.com/it-just-got-much-easier-to-find-the-best-mods-in-teardown)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 15:08:31+00:00

The 1.2 update adds recommendations from the devs themselves.

## Former Bayonetta VA walks back claims she was only offered $4,000 for new game
 - [https://www.pcgamer.com/former-bayonetta-va-walks-back-claims-she-was-only-offered-dollar4000-for-new-game](https://www.pcgamer.com/former-bayonetta-va-walks-back-claims-she-was-only-offered-dollar4000-for-new-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 15:08:30+00:00

Hellena Taylor is now saying at least part of a Bloomberg report is true.

## Things to do before World of Warcraft: Dragonflight launches
 - [https://www.pcgamer.com/world-of-warcraft-what-to-do-before-wow-dragonflight](https://www.pcgamer.com/world-of-warcraft-what-to-do-before-wow-dragonflight)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 14:50:38+00:00

Tie up all those loose ends before leaving the Shadowlands behind.

## These scripts use AI to turn Minecraft worlds into adorable picturesque scenes
 - [https://www.pcgamer.com/minecraft-ai-stable-diffusion-image-generation](https://www.pcgamer.com/minecraft-ai-stable-diffusion-image-generation)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 14:20:28+00:00

This is what happens when you combine Minecraft with Stable Diffusion AI image generator.

## A single chip has managed to transfer the entire internet's traffic in a single second
 - [https://www.pcgamer.com/a-single-chip-has-managed-to-transfer-the-entire-internets-traffic-in-a-single-second](https://www.pcgamer.com/a-single-chip-has-managed-to-transfer-the-entire-internets-traffic-in-a-single-second)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 12:38:51+00:00

Researchers prove there's a lot more room to grow for the internet with silicon photonics.

## This TikTok account is testing weird thermal paste patterns so you don't have to
 - [https://www.pcgamer.com/this-tiktok-account-is-testing-weird-thermal-paste-patterns-so-you-dont-have-to](https://www.pcgamer.com/this-tiktok-account-is-testing-weird-thermal-paste-patterns-so-you-dont-have-to)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 12:19:17+00:00

Is the best thermal paste pattern a blob? A line? Or perhaps the Half-Life logo?

## Disco Elysium writer is suing developer ZA/UM
 - [https://www.pcgamer.com/disco-elysium-writer-is-suing-developer-zaum](https://www.pcgamer.com/disco-elysium-writer-is-suing-developer-zaum)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 12:02:30+00:00

Robert Kurvitz filed a suit on behalf of his own company Telomer OÜ.

## The vibes are immaculate in Victoria 3's 'LoFi VicHop tracks to chill or industrialise to' video
 - [https://www.pcgamer.com/the-vibes-are-immaculate-in-victoria-3s-lofi-vichop-tracks-to-chill-or-industrialise-to-video](https://www.pcgamer.com/the-vibes-are-immaculate-in-victoria-3s-lofi-vichop-tracks-to-chill-or-industrialise-to-video)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 11:27:26+00:00

You can almost taste the smog.

## Today's Wordle 492 answer and hint: Monday, October 24
 - [https://www.pcgamer.com/todays-wordle-492-answer-hint](https://www.pcgamer.com/todays-wordle-492-answer-hint)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 07:01:28+00:00

Wordle today: The solution and a hint for Monday's puzzle.

## Secret messages found in Silent Hill Townfall's promotional material
 - [https://www.pcgamer.com/secret-messages-found-in-silent-hill-townfalls-promotional-material](https://www.pcgamer.com/secret-messages-found-in-silent-hill-townfalls-promotional-material)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 04:13:23+00:00

Enjoy the Silents.

## Having trouble finding an RTX 4090? It may be about to get harder
 - [https://www.pcgamer.com/having-trouble-finding-an-rtx-4090-it-may-be-about-to-get-harder](https://www.pcgamer.com/having-trouble-finding-an-rtx-4090-it-may-be-about-to-get-harder)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 02:02:15+00:00

Nvidia can make a lot more money pumping out enterprise GPUs.

## Five new Steam games you probably missed (October 24, 2022)
 - [https://www.pcgamer.com/five-new-steam-games-you-probably-missed-october-24-2022](https://www.pcgamer.com/five-new-steam-games-you-probably-missed-october-24-2022)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2022-10-24 00:07:12+00:00

Sorting through every new game on Steam so you don't have to.


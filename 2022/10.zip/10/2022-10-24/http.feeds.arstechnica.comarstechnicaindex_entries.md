# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Children’s hospitals fill up amid up early surge in respiratory infections
 - [https://arstechnica.com/?p=1892525](https://arstechnica.com/?p=1892525)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 22:56:41+00:00

Now is the time to get flu shots as well as COVID boosters, experts advise.

## We were not wowed by our first Meta Quest Pro experience
 - [https://arstechnica.com/?p=1892497](https://arstechnica.com/?p=1892497)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 21:04:01+00:00

Best Buy demo doesn't put Meta's best foot forward.

## Slow Roads offers a chill, endless driving experience in your browser
 - [https://arstechnica.com/?p=1892326](https://arstechnica.com/?p=1892326)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 19:54:25+00:00

Free, meditative driving game with no strings attached might help you escape the grind.

## Comcast’s new higher upload speeds require $25-per-month xFi Complete add-on
 - [https://arstechnica.com/?p=1892437](https://arstechnica.com/?p=1892437)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 19:45:03+00:00

10Mbps uploads become 100Mbps—but only with xFi Complete hardware rental plan.

## Marvel drops official trailer for Ant-Man and the Wasp: Quantumania
 - [https://arstechnica.com/?p=1892377](https://arstechnica.com/?p=1892377)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 19:14:33+00:00

Kang the Conqueror makes his MCU debut as next big cross-movie villain.

## On eve of first launch, Relativity Space seeks to join SpaceX as “disruptor”
 - [https://arstechnica.com/?p=1892255](https://arstechnica.com/?p=1892255)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 18:57:23+00:00

"Almost from the beginning of the company, I wanted to build a Falcon 9 competitor."

## Apple releases OS updates for basically everything, including iPadOS and macOS
 - [https://arstechnica.com/?p=1892379](https://arstechnica.com/?p=1892379)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 17:48:55+00:00

Everything from the iPhone to the HomePod gets a software update today.

## Apple raises prices for Music and TV+ for the first time
 - [https://arstechnica.com/?p=1892353](https://arstechnica.com/?p=1892353)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 17:22:29+00:00

The price of the Apple One subscription bundle is also going up.

## After complaints, Volkswagen will ditch capacitive steering wheel controls
 - [https://arstechnica.com/?p=1892362](https://arstechnica.com/?p=1892362)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 17:18:58+00:00

Recent VWs have shipped with capacitive multifunction steering wheels, and they're bad.

## The $228 OnePlus Nord N300 packs good looks, 33 W charging
 - [https://arstechnica.com/?p=1892314](https://arstechnica.com/?p=1892314)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 17:08:54+00:00

The 90 Hz display sounds nice, but 720p does not.

## Microsoft’s “Project Volterra” becomes an Arm-powered mini PC with 32GB of RAM
 - [https://arstechnica.com/?p=1892225](https://arstechnica.com/?p=1892225)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 17:00:27+00:00

"Windows Dev Kit 2023" is dramatically more powerful than previous efforts.

## New Webb images illuminate the formation of a galaxy cluster
 - [https://arstechnica.com/?p=1892324](https://arstechnica.com/?p=1892324)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 16:22:42+00:00

Webb's hardware tells us how fast material is moving.

## macOS 13 Ventura: The Ars Technica review
 - [https://arstechnica.com/?p=1881068](https://arstechnica.com/?p=1881068)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 16:00:52+00:00

A pleasantly surprising new multitasking UI and app redesigns define macOS 13.

## Company that makes rent-setting software for landlords sued for collusion
 - [https://arstechnica.com/?p=1892303](https://arstechnica.com/?p=1892303)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2022-10-24 14:21:28+00:00

RealPage worked with some of the nation’s largest landlords to raise rents, says lawsuit.


# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## How Did House of the Dragon’s First Season Stack Up to Thrones’? | The Recap
 - [https://www.youtube.com/watch?v=UCyJzxlcKuA](https://www.youtube.com/watch?v=UCyJzxlcKuA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-25 00:00:00+00:00

This week on The Recap, we discuss the season finale of House of the Dragon, Darren's horror movie recommendations and Andor!

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## The Last Hero of Nostalgaia | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=jzUkPv7NHkc](https://www.youtube.com/watch?v=jzUkPv7NHkc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-25 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

Sebastian Ruiz reviews The Last Hero of Nostalgaia, developed by Over the Moon.

The Last Hero of Nostalgaia on Steam: https://store.steampowered.com/app/1766100/The_Last_Hero_of_Nostalgaia/

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Why Portal 2's Co-op Was Harder to Make Than You Think
 - [https://www.youtube.com/watch?v=qnQpkM9nbsU](https://www.youtube.com/watch?v=qnQpkM9nbsU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-25 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

In today's episode JM8 takes a dive back into Portal 2 to breakdown its Co-op mode. The ups and downs of designing for multiplayer and how it can go wrong if not enough attention is given to the correct places.

If you want to see more game design content a new Anatomy episode will release every other week, or you can subscribe to JM8s personal channel for similar content: https://www.youtube.com/c/JM8GameDesign

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Is Mario Still Relevant? | Slightly Something Else
 - [https://www.youtube.com/watch?v=ZxPEqtrRZhY](https://www.youtube.com/watch?v=ZxPEqtrRZhY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-24 00:00:00+00:00

This week on Slightly Something Else, Yahtzee and Marty talk about the Mario franchise as this week is the 5th anniversary of Mario Odyssey. 

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## John Carpenter Captures the End of the World Like Nobody Else
 - [https://www.youtube.com/watch?v=OieraFdob8s](https://www.youtube.com/watch?v=OieraFdob8s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-24 00:00:00+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## War Mongrels is a Brutal WWII Stealth Tactics Game | Hidden Gems
 - [https://www.youtube.com/watch?v=JPbxeh3h69U](https://www.youtube.com/watch?v=JPbxeh3h69U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2022-10-24 00:00:00+00:00

This video is sponsored by War Mongrels. Check out War Mongrels on Steam today: https://game.page/warmongrels/The%20Escapist

Each week KC and Jesse check out an overlooked game on Steam and decide whether or not it's a "Hidden Gem". This week they're checking out War Mongrels.

Join YouTube Memberships and support our content for Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

#sponsored #warmongrels


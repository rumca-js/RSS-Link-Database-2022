# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## W czasie cesarskiego cięcia "doszło do nieumyślnego nacięcia skóry u noworodka" przez lekarza
 - [https://tvn24.pl/wroclaw/glogow-w-czasie-cesarskiego-ciecia-doszlo-do-nieumyslnego-naciecia-skory-u-noworodka-przez-lekarza-6177333?source=rss](https://tvn24.pl/wroclaw/glogow-w-czasie-cesarskiego-ciecia-doszlo-do-nieumyslnego-naciecia-skory-u-noworodka-przez-lekarza-6177333?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 13:12:00+00:00

<img alt="W czasie cesarskiego cięcia " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lijslz-lekarz-przypadkowo-nacial-noworodka-podczas-cesarskiego-cecia-6177383/alternates/LANDSCAPE_1280" />
    W trakcie wykonywania zabiegu cesarskiego cięcia lekarz ze szpitala w Głogowie (województwo dolnośląskie) naciął skórę noworodka. Obrażenia zostały szybko zauważone, dziecko po konsultacjach przetransportowano do placówki we Wrocławiu. Jego stan jest dobry. Szpital, w którym doszło do zdarzenia, poinformował nas, że wszczął standardowe "wewnętrzne postępowanie, mające wyjaśnić, czy dochowane zostały wszelkie procedury". - Postępowanie wykazało, że uraz powstał przypadkowo - powiedziała rzeczniczka.

## Zatrzymany podczas rutynowej kontroli. Policja: miał dożywotni zakaz prowadzenia
 - [https://tvn24.pl/tvnwarszawa/najnowsze/ciechanow-jechal-samochodem-bez-prawa-jazdy-i-orzeczonym-sadowym-zakazem-prowadzenia-6177343?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/ciechanow-jechal-samochodem-bez-prawa-jazdy-i-orzeczonym-sadowym-zakazem-prowadzenia-6177343?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 11:40:12+00:00

<img alt="Zatrzymany podczas rutynowej kontroli. Policja: miał dożywotni zakaz prowadzenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ux9qt6-policja-5646109/alternates/LANDSCAPE_1280" />
    62-letni mieszkaniec Ciechanowa od kilku lat miał orzeczony dożywotni zakaz prowadzenia pojazdów. Mimo to jechał samochodem. Jak informuje policja, został zatrzymany do rutynowej kontroli, podczas której okazało się, że kieruje bez uprawień. Grozi mu do pięciu lat więzienia.

## Matthew Perry o dramatycznej walce z nałogiem. "Otarłem się o śmierć"
 - [https://tvn24.pl/kultura-i-styl/matthew-perry-chandler-z-serialu-przyjaciele-o-uzaleznieniu-od-alkoholu-i-opioidow-6175123?source=rss](https://tvn24.pl/kultura-i-styl/matthew-perry-chandler-z-serialu-przyjaciele-o-uzaleznieniu-od-alkoholu-i-opioidow-6175123?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:59:06+00:00

<img alt="Matthew Perry o dramatycznej walce z nałogiem. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xvs9fa-gettyimages-477289386-6176791/alternates/LANDSCAPE_1280" />
    Znany z serialu "Przyjaciele" aktor Matthew Perry ujawnił, że przez uzależnienie od alkoholu i opioidów "otarł się o śmierć". W biografii, która ukaże się na początku listopada, opisuje swoją drogę do trzeźwości. "Jestem wdzięczny, że żyję" - pisze.

## "Makaron numer 1 we Włoszech" nie jest z Włoch. Para z USA pozwała producenta
 - [https://tvn24.pl/biznes/ze-swiata/usa-pozew-przeciwko-barilla-produkuje-makaron-tez-poza-wlochami-6174482?source=rss](https://tvn24.pl/biznes/ze-swiata/usa-pozew-przeciwko-barilla-produkuje-makaron-tez-poza-wlochami-6174482?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:50:53+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lzixul-gotowanie-makaron-shutterstock1213068637-6097161/alternates/LANDSCAPE_1280" />
    Do sądu w Kalifornii wpłynął pozew przeciwko firmie Barilla. Pozywający twierdzą, że używany przez firmę slogan "Makaron numer 1 we Włoszech" wprowadza w błąd sugerując, że makarony te są produkowane we Włoszech. W rzeczywistości makarony tej marki sprzedawane na rynku amerykańskim są produkowane w USA. Sąd częściowo uznał pozew, a proces ma ruszyć w l

## Eksplozję było słychać w promieniu kilku kilometrów. Sąsiedzi wyciągnęli rannego spod gruzów
 - [https://tvn24.pl/lodz/skalmierz-woj-lodzkie-wybuch-gazu-59-latek-trafil-do-szpitala-6176749?source=rss](https://tvn24.pl/lodz/skalmierz-woj-lodzkie-wybuch-gazu-59-latek-trafil-do-szpitala-6176749?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:50:33+00:00

<img alt="Eksplozję było słychać w promieniu kilku kilometrów. Sąsiedzi wyciągnęli rannego spod gruzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bbz3cl-jedna-osoba-zostala-ranna-6176779/alternates/LANDSCAPE_1280" />
    Rozszczelnienie butli najprawdopodobniej było przyczyną wybuchu gazu, do którego doszło w jednym z mieszkań w Skalmierzu (woj. łódzkie). Jedna osoba została ranna. - Przypomnieliśmy sobie, że od niedawna mieszkał tam nowy lokator. Zaczęliśmy go wołać, a potem wyciągnęliśmy spo

## Wyższe koszty i dodatkowe opłaty. Dostawa świątecznego prezentu może być wyjątkowo droga
 - [https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-swiateczne-zakupy-online-beda-drozsze-wysokie-koszty-transportu-i-uslug-kurierskich-6176751?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-swiateczne-zakupy-online-beda-drozsze-wysokie-koszty-transportu-i-uslug-kurierskich-6176751?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:48:23+00:00

<img alt="Wyższe koszty i dodatkowe opłaty. Dostawa świątecznego prezentu może być wyjątkowo droga " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1mf8ic-swiateczne-prezenty-4785358/alternates/LANDSCAPE_1280" />
    Tegoroczny świąteczny szczyt paczkowy będzie inny niż wszystkie do tej pory – zamiast boomu czeka nas hamowanie. Firmy z branży kurierskiej podnoszą ceny usług i wprowadzają dodatkowe opłaty - pisze w poniedziałek "Rzeczpospolita”.

## Kowalski: Niemcy wydają "zero euro" na naukę języka polskiego jako ojczystego. To nieprawda
 - [https://konkret24.tvn24.pl/najnowsze/niemcy-wydaja-zero-euro-na-nauke-jezyka-polskiego-jako-ojczystego-wiceminister-kowalski-nie-ma-racji-6171042?source=rss](https://konkret24.tvn24.pl/najnowsze/niemcy-wydaja-zero-euro-na-nauke-jezyka-polskiego-jako-ojczystego-wiceminister-kowalski-nie-ma-racji-6171042?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:48:06+00:00

<img alt="Kowalski: Niemcy wydają " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3b9deb-janusz-kowalski-o-nauczaniu-jezyka-polskiego-w-niemczech-6170936/alternates/LANDSCAPE_1280" />
    Janusz Kowalski twierdzi, że Niemcy w ogóle nie finansują nauki języka polskiego jako ojczystego oraz że polski rząd nie odebrał "ani złotówki" mniejszości niemieckiej na naukę jej języka. Wyjaśniamy, dlaczego w obu sprawach wiceminister się myli.

## Leszek Miller o dziurze budżetowej: pachnie, niestety, najgorszym scenariuszem
 - [https://tvn24.pl/polska/dziura-budzetowa-a-zagrozone-unijne-pieniadze-z-funduszu-spojnosci-leszek-miller-komentuje-6176681?source=rss](https://tvn24.pl/polska/dziura-budzetowa-a-zagrozone-unijne-pieniadze-z-funduszu-spojnosci-leszek-miller-komentuje-6176681?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:42:00+00:00

<img alt="Leszek Miller o dziurze budżetowej: pachnie, niestety, najgorszym scenariuszem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cbdmm4-lawy-rzadowe-w-sejmie-6172549/alternates/LANDSCAPE_1280" />
    Trzeba po te pieniądze jechać do siedziby partii, która nazywa się Prawo i Sprawiedliwość. To jest dobry adres - powiedział w "Rozmowie Piaseckiego" były premier, a obecnie eurodeputowany Leszek Miller, odnosząc się do perspektywy nieotrzymania unijnych pieniędzy przez Polskę w ramach Funduszu 

## Generał Waldemar Skrzypczak: Rosjanie zamierzają przejść do obrony. Ukraińcy mogą wykonać kluczowe uderzenie
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-general-waldemar-skrzypczak-o-tym-jak-moze-wygladac-zima-na-froncie-analiza-mapy-6176699?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-general-waldemar-skrzypczak-o-tym-jak-moze-wygladac-zima-na-froncie-analiza-mapy-6176699?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:35:24+00:00

<img alt="Generał Waldemar Skrzypczak: Rosjanie zamierzają przejść do obrony. Ukraińcy mogą wykonać kluczowe uderzenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rf0am7-general-skrzypczak-6176758/alternates/LANDSCAPE_1280" />
    Prowadzenie głębokich prac inżynieryjnych świadczy o tym, że Rosjanie zamierzają do zimy przejść do obrony - mówił w TVN24 generał Waldemar Skrzypczak. Były dowódca Wojsk Lądowych oceniał, jak może rozwinąć się konflikt w Ukrainie w najbliższych miesiącach. - Intencją

## Wiatr zerwał znaki drogowe, tornado zmiotło ściany. "Odbudowa wszystkiego zajmie miesiące"
 - [https://tvn24.pl/tvnmeteo/swiat/francja-przez-polnoc-kraju-przeszlo-tornado-gigantyczne-zniszczenia-6176664?source=rss](https://tvn24.pl/tvnmeteo/swiat/francja-przez-polnoc-kraju-przeszlo-tornado-gigantyczne-zniszczenia-6176664?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:28:08+00:00

<img alt="Wiatr zerwał znaki drogowe, tornado zmiotło ściany. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-be2uhg-burza-porywa-znak-drogowy-we-francji-6176735/alternates/LANDSCAPE_1280" />
    Tornado przeszło w niedzielę nad północną Francją. Lokalne media podają, że żywioł spustoszył kilka miejscowości położonych w departamentach Somma i Pas-de-Calais, a w mediach społecznościowych pojawiły się nagrania zniszczeń wywołanych przez silne podmuchy.

## WIBOR mocno w górę. "Rynek obstawia, że RPP będzie zmuszona do kolejnych podwyżek stóp"
 - [https://tvn24.pl/biznes/pieniadze/stopy-procentowe-wibor-3m-i-wibor-6m-mocno-w-gore-rafal-mundry-komentuje-6176696?source=rss](https://tvn24.pl/biznes/pieniadze/stopy-procentowe-wibor-3m-i-wibor-6m-mocno-w-gore-rafal-mundry-komentuje-6176696?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:27:02+00:00

<img alt="WIBOR mocno w górę. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie18585394aa10e8d28c5f09701f3a6cd1-informacje-z-grecji-konflikt-na-ukrainie-stoja-za-poniedzialkowym-znacznym-oslabieniem-zlotowki-uwazaja-analitycy-3768304/alternates/LANDSCAPE_1280" />
    Stawki WIBOR rosną. "Rynek obstawia, że RPP będzie zmuszona do kolejnych podwyżek stóp" - wskazał ekonomista Rafał Mundry. WIBOR trzymiesięczny (3M) i sześciomiesięczny (6M) rosną nieprzerwanie od 12 października. Od WIBOR-u zale

## Samolot w ulewnym deszczu wypadł z pasa i rozbił się. Na pokładzie były 173 osoby
 - [https://tvn24.pl/swiat/filipiny-samolot-rozbil-sie-podczas-ladowania-w-prowincji-cebu-173-osoby-na-pokladzie-6176629?source=rss](https://tvn24.pl/swiat/filipiny-samolot-rozbil-sie-podczas-ladowania-w-prowincji-cebu-173-osoby-na-pokladzie-6176629?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:26:37+00:00

<img alt="Samolot w ulewnym deszczu wypadł z pasa i rozbił się. Na pokładzie były 173 osoby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3dqfrk-mid-epa10262236-6176619/alternates/LANDSCAPE_1280" />
    Samolot pasażerski linii Korean Air ze 173 osobami na pokładzie wypadł z pasa i rozbił się podczas próby lądowania na Filipinach. Do wypadku doszło w niedzielę w trudnych warunkach pogodowych, była to trzecia próba lądowania maszyny. Władze lotniska poinformowały, że wszyscy pasażerowie i personel

## "Barbara Nowak swoją postawą daje przykład. A ten przykład brzmi: 'mogę nie respektować wyroków'"
 - [https://tvn24.pl/premium/edukacja-kurator-barbara-nowak-nie-wykonala-wyroku-minister-przemyslaw-czarnek-mowil-nieprawde-co-laczy-te-sprawy-6171052?source=rss](https://tvn24.pl/premium/edukacja-kurator-barbara-nowak-nie-wykonala-wyroku-minister-przemyslaw-czarnek-mowil-nieprawde-co-laczy-te-sprawy-6171052?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:11:57+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tpevld-pap20220614077-6171046/alternates/LANDSCAPE_1280" />
    Minister edukacji i nauki Przemysław Czarnek publicznie opowiada o polskiej gminie, która oddała komputery bardziej potrzebującym Niemcom, choć to nieprawda. Barbara Nowak, małopolska kurator oświaty, nawet zobowiązana wyrokiem sądu, nie chce przeprosić za swoje nieprawdziwe wypowiedzi. Co ich łączy? - Lekceważą obywateli i niszczą zaufanie do instytucji publicznych - mówi praw

## Poważny wypadek na Służewie, kierowca był zakleszczony w aucie
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-powazny-wypadek-na-sluzewiu-kierowca-byl-zakleszczony-w-aucie-6176666?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-powazny-wypadek-na-sluzewiu-kierowca-byl-zakleszczony-w-aucie-6176666?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2022-10-24 07:06:46+00:00

<img alt="Poważny wypadek na Służewie, kierowca był zakleszczony w aucie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-cui63c-wypadek-przy-metrze-sluzew-6176687/alternates/LANDSCAPE_1280" />
    W niedziele po południu przy stacji metra Służew doszło do poważnego wypadku z udziałem dwóch aut. Jak informuje policja, trzy osoby zostały ranne. Stan jednej z nich jest ciężki.


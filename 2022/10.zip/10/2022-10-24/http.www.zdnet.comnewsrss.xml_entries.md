# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## NASA kicks off UFO study with 16-member team
 - [https://www.zdnet.com/article/nasa-kicks-off-ufo-study-with-16-member-team/#ftag=RSSbaffb68](https://www.zdnet.com/article/nasa-kicks-off-ufo-study-with-16-member-team/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 23:10:19+00:00

The nine-month study, conducted by a team of 16 experts including former astronaut Scott Kelly, will examine how unclassified data could help us learn more about unidentified aerial phenomena.

## Jabra Elite 85t deal: Save $90 on the earbuds
 - [https://www.zdnet.com/article/jabra-elite-85t-noise-canceling-earbuds-deal/#ftag=RSSbaffb68](https://www.zdnet.com/article/jabra-elite-85t-noise-canceling-earbuds-deal/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 22:04:00+00:00

Get up to 5.5 hours of streaming and adjustable active noise cancelation with this great low price.

## The 5 best wireless car chargers of 2022
 - [https://www.zdnet.com/article/best-wireless-car-charger-and-mount/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-wireless-car-charger-and-mount/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 21:24:00+00:00

Keeping your phone powered during road trips is essential for entertainment, navigation, and more. The best wireless car chargers give you this capability without any cords.

## AI critic Gary Marcus: Meta's LeCun is finally coming around to the things I said years ago
 - [https://www.zdnet.com/article/ai-critic-gary-marcus-metas-lecun-is-finally-coming-around-to-the-things-i-said-years-ago/#ftag=RSSbaffb68](https://www.zdnet.com/article/ai-critic-gary-marcus-metas-lecun-is-finally-coming-around-to-the-things-i-said-years-ago/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 21:15:16+00:00

Deep learning gadfly Gary Marcus says he and Meta's chief AI scientist, Yann LeCun, are in alignment about the most important challenges facing the field.

## Apple is increasing prices for Apple Music, Apple TV+, and Apple One
 - [https://www.zdnet.com/article/apple-is-increasing-prices-for-apple-music-apple-tv-and-apple-one/#ftag=RSSbaffb68](https://www.zdnet.com/article/apple-is-increasing-prices-for-apple-music-apple-tv-and-apple-one/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 21:03:30+00:00

Beginning today, Apple is raising the prices for its popular subscription services

## Get a Samsung Galaxy Tab 8+ for only $250: Save $650
 - [https://www.zdnet.com/article/get-a-samsung-galaxy-tab-8-for-only-249/#ftag=RSSbaffb68](https://www.zdnet.com/article/get-a-samsung-galaxy-tab-8-for-only-249/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 19:32:00+00:00

Samsung Week is back in action, and you can get a brand new tablet for only $249. Here's how.

## The 5 best rugged laptops of 2022
 - [https://www.zdnet.com/article/best-rugged-laptop/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-rugged-laptop/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 19:23:00+00:00

Getting your hands on a rugged laptop is easier than ever now that brands like Lenovo, MSI, and Asus have models that are tested against MIL-STD-810 standards for moisture, dust, and drop resistance.

## How to set up SSH key authentication in Linux for more secure logins
 - [https://www.zdnet.com/article/how-to-set-up-ssh-key-authentication-in-linux-for-more-secure-logins/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-set-up-ssh-key-authentication-in-linux-for-more-secure-logins/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 19:06:00+00:00

Here's how easy it is to add a layer of security to your secure shell logins on Linux.

## How to create a LinkedIn Poll for quick, valuable engagement
 - [https://www.zdnet.com/article/how-to-create-a-linkedin-poll/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-create-a-linkedin-poll/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 19:00:17+00:00

With LinkedIn being a networking essential, employees and business owners alike can gain insights via surveys and questionnaires. Here's how to create a LinkedIn Poll.

## Save 42% on the Treblab HD77 Bluetooth speaker
 - [https://www.zdnet.com/home-and-office/home-entertainment/treblab-speaker-deal-coupon-promo-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/treblab-speaker-deal-coupon-promo-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 18:51:00+00:00

You can save $50 on an excellent Bluetooth speaker before the holiday season kicks off. Right now, the Treblab HD77 rugged outdoor speaker is 42% off on Amazon.

## Your keyboard is disgusting. Here's why you should clean it with slime
 - [https://www.zdnet.com/home-and-office/your-keyboard-is-disgusting-heres-why-you-should-clean-it-with-slime/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/your-keyboard-is-disgusting-heres-why-you-should-clean-it-with-slime/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 18:39:25+00:00

Take a look at your keyboard. Is it bad? It's probably very bad.

## Your keyboard is disgusting. Here's why you should clean it with slime
 - [https://www.zdnet.com/home-and-office/smart-office/your-keyboard-is-disgusting-heres-why-you-should-clean-it-with-slime/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-office/your-keyboard-is-disgusting-heres-why-you-should-clean-it-with-slime/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 18:39:00+00:00

Take a look at your keyboard. Is it bad? It's probably very bad.

## How to secure your sensitive OneDrive files with a Personal Vault
 - [https://www.zdnet.com/article/how-to-secure-your-sensitive-onedrive-files-with-a-personal-vault/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-secure-your-sensitive-onedrive-files-with-a-personal-vault/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 17:36:59+00:00

The Personal Vault adds an extra layer of protection to protect sensitive OneDrive files.

## The 5 best portable solar chargers of 2022
 - [https://www.zdnet.com/home-and-office/yard-outdoors/best-portable-solar-charger/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/yard-outdoors/best-portable-solar-charger/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 17:12:00+00:00

The best portable solar chargers are lightweight, powerful, and durable. We found the top solar chargers that you can rely on during your next wilderness adventure.

## Microsoft starts shipping its Windows on Arm device for developers: Windows Dev Kit 2023
 - [https://www.zdnet.com/article/microsoft-starts-shipping-its-windows-on-arm-device-for-developers-windows-dev-kit-2023/#ftag=RSSbaffb68](https://www.zdnet.com/article/microsoft-starts-shipping-its-windows-on-arm-device-for-developers-windows-dev-kit-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 17:00:53+00:00

Microsoft's 'Project Volterra' $599 device for developing, testing and running Windows-on-Arm apps is shipping in eight countries, starting today.

## The Google Pixel 6 is $200 off at Target right now
 - [https://www.zdnet.com/article/google-pixel-6-deal-coupon-promo-code-sale/#ftag=RSSbaffb68](https://www.zdnet.com/article/google-pixel-6-deal-coupon-promo-code-sale/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 15:09:00+00:00

With 128GB of storage and its 50MP camera, the Google Pixel 6 can capture all your favorite moments. Right now, you can save $200 on the phone at Target.

## The 5 best 50-inch TVs of 2022
 - [https://www.zdnet.com/home-and-office/home-entertainment/best-50-inch-tv/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/best-50-inch-tv/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 14:47:00+00:00

Upgrade your holiday movie nights with one of the best 50-inch TVs on the market. Samsung has the top TV, but TCL and LG give the brand a run for its money.

## IT leaders aren't getting listened to, and now they're ready to walk away
 - [https://www.zdnet.com/article/it-leaders-arent-getting-listened-to-and-now-theyre-ready-to-walk-away/#ftag=RSSbaffb68](https://www.zdnet.com/article/it-leaders-arent-getting-listened-to-and-now-theyre-ready-to-walk-away/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 14:00:00+00:00

Tech managers say they are being shunned when it comes to implementing new tech and new working models in the workplace.

## iPad 2022 (10th Gen) review: Better than the Pro in two ways
 - [https://www.zdnet.com/article/ipad-2022-10th-gen-review-better-than-the-pro-in-two-ways/#ftag=RSSbaffb68](https://www.zdnet.com/article/ipad-2022-10th-gen-review-better-than-the-pro-in-two-ways/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 13:39:00+00:00

The 10th-generation iPad gets a refreshed design that puts it closer to the rest of the iPad family and further from its budget roots.

## The 65-inch Hisense Smart TV just dropped by $400 at Best Buy
 - [https://www.zdnet.com/home-and-office/home-entertainment/hisense-65-quantum-4k-smart-tv-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/hisense-65-quantum-4k-smart-tv-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 13:38:00+00:00

You can pick up an excellent smart TV at Best Buy with a 33% discount. Upgrade your living room TV and save $400, just in time for the holiday season.

## Mac Studio vs. Mac Pro and Mac Mini: How to choose
 - [https://www.zdnet.com/home-and-office/smart-office/mac-studio-vs-mac-pro-and-mac-mini-how-to-choose/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-office/mac-studio-vs-mac-pro-and-mac-mini-how-to-choose/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 13:24:52+00:00

We're all waiting on a new Mac Mini and a new Mac Pro. Until they arrive, we can help you choose between Apple's three headless Mac models.

## Apple iPad (2022) hands-on: Better than the Pro in two ways
 - [https://www.zdnet.com/article/apple-ipad-2022-hands-on-better-than-the-pro-in-two-ways/#ftag=RSSbaffb68](https://www.zdnet.com/article/apple-ipad-2022-hands-on-better-than-the-pro-in-two-ways/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 13:00:00+00:00

The 10th-generation iPad gets a refreshed design that puts it closer to the rest of the iPad family and further from its budget roots.

## iPad Pro (2022) review: I'm cautiously optimistic. Or foolish
 - [https://www.zdnet.com/article/ipad-pro-2022-review-im-cautiously-optimistic-or-foolish/#ftag=RSSbaffb68](https://www.zdnet.com/article/ipad-pro-2022-review-im-cautiously-optimistic-or-foolish/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 13:00:00+00:00

Apple's latest iPad Pro gets a small spec bump over last year's model, but there's a lot of hope among iPad Pro fans that the software experience will finally catch up.

## Criminals are starting to exploit the metaverse, says Interpol. So police are heading there too
 - [https://www.zdnet.com/article/criminals-are-starting-to-exploit-the-metaverse-says-interpol-so-police-are-heading-there-too/#ftag=RSSbaffb68](https://www.zdnet.com/article/criminals-are-starting-to-exploit-the-metaverse-says-interpol-so-police-are-heading-there-too/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 12:15:00+00:00

An international police organization is using the metaverse and wants to understand how crime could evolve.

## Developers are in short supply, and that's keeping IT services companies busy
 - [https://www.zdnet.com/article/developers-are-in-short-supply-and-thats-keeping-it-services-companies-busy/#ftag=RSSbaffb68](https://www.zdnet.com/article/developers-are-in-short-supply-and-thats-keeping-it-services-companies-busy/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 11:44:30+00:00

IT services will grow this year despite recession fears.

## FBI warning: This ransomware group is targeting poorly protected VPN servers
 - [https://www.zdnet.com/article/fbi-warning-this-ransomware-group-is-targeting-poorly-protected-vpn-servers/#ftag=RSSbaffb68](https://www.zdnet.com/article/fbi-warning-this-ransomware-group-is-targeting-poorly-protected-vpn-servers/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 10:36:33+00:00

Attackers are using VPN servers to gain access, and then SSH and RDP to spread through networks.

## Metaverse and immersive experiences: How one company is getting started on the journey
 - [https://www.zdnet.com/article/metaverse-and-immersive-experiences-how-one-company-is-getting-started-on-the-journey/#ftag=RSSbaffb68](https://www.zdnet.com/article/metaverse-and-immersive-experiences-how-one-company-is-getting-started-on-the-journey/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 10:15:20+00:00

Holiday firm TUI is investigating uses cases across all kinds of immersive experiences and its explorations provide lessons for others.

## Hisense 65" Quantum 4K smart TV just dropped to less than $800 at Best Buy
 - [https://www.zdnet.com/home-and-office/hisense-65-quantum-4k-smart-tv-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/hisense-65-quantum-4k-smart-tv-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 06:51:58+00:00

Best Buy is offering 33% off a smart TV, perfect for your living room, just in time for the holiday season.

## Pro streamer sale: Over $100 off the IOGEAR Upstream Pro video capture card
 - [https://www.zdnet.com/home-and-office/pro-streamer-iogear-upstream-pro-video-capture-card-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/pro-streamer-iogear-upstream-pro-video-capture-card-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 06:46:12+00:00

You can enjoy up to 35% off the IOGEAR Upstream Pro video capture card.

## The 4 best game consoles of 2022
 - [https://www.zdnet.com/home-and-office/best-game-console/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/best-game-console/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 02:54:00+00:00

What is the best game console? Sony's PlayStation 5 is ZDNet's top choice. With a futuristic look, it truly brings in next-gen style along with its next-gen internal components. But it's not the only console worth considering. We analyzed design, pricing, functionality and more to come up with the four best gaming consoles.

## The 5 best fire extinguishers of 2022
 - [https://www.zdnet.com/home-and-office/kitchen-household/best-fire-extinguisher/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/kitchen-household/best-fire-extinguisher/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 02:26:00+00:00

October is Fire Safety Month! A fire extinguisher is an important device to have in your home all year-round, but especially during Halloween since Jack-o-Lantern candles and other decorations can be dangerous and cause damage if left unattended.

## The best webcams for streaming of 2022
 - [https://www.zdnet.com/article/best-streaming-webcam/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-streaming-webcam/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 02:18:13+00:00

Whether you're just starting out or an experienced content creator, the right webcam can go a long way toward elevating your vlogs, streams, and scripted content. Brands like Logitech offer budget-friendly options for beginners while creator-centric brands like Elgato offer higher-end models for more experienced streamers who need high-quality video.

## The 5 best tablets for reading in 2022
 - [https://www.zdnet.com/article/best-reading-tablet/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-reading-tablet/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2022-10-24 02:11:06+00:00

Looking to put down the book and pick up a tablet instead? The best tablets for reading are handheld in size, have sharp displays, and long battery lives so you can spend a whole afternoon with your favorite book.


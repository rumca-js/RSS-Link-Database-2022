# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Your Cat Knows When You're Using Your 'Cat Talk' Voice
 - [https://gizmodo.com/your-cat-knows-when-youre-using-your-cat-talk-voice-1849695518](https://gizmodo.com/your-cat-knows-when-youre-using-your-cat-talk-voice-1849695518)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-25 00:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--xGguqfUe--/c_fit,fl_progressive,q_80,w_636/63cdfd725ef1e37218cd94520ba17082.jpg" /><p>New research suggests that cats can distinguish their owner’s voice from that of a stranger’s, while also being able to identify when their owner is specifically talking to them. The findings are the latest to indicate that cats can indeed form strong social bonds with humans.</p><p><a href="https://gizmodo.com/your-cat-knows-when-youre-using-your-cat-talk-voice-1849695518">Read more...</a></p>

## Oh Great, Britain's New Prime Minister is a Crypto Bro
 - [https://gizmodo.com/rishi-sunak-new-uk-prime-minister-is-crypto-bro-bitcoin-1849693897](https://gizmodo.com/rishi-sunak-new-uk-prime-minister-is-crypto-bro-bitcoin-1849693897)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 23:46:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--2Z4ctPXW--/c_fit,fl_progressive,q_80,w_636/86f6efff8aeb003e0bd74f8e115c43f1.jpg" /><p>As the United Kingdom prepares to welcome a new Prime Minister amidst dire <a href="https://www.theguardian.com/commentisfree/2022/oct/17/economy-crisis-tories-britain-brexit-johnson-truss-us" rel="noopener noreferrer" target="_blank">economic headwinds</a>,  it seems necessary to point out that the guy they’ve elected to fix things is a certified Crypto Bro™️ who once <a href="https://news.sky.com/story/rishi-sunak-to-launch-an-nft-issued-by-the-royal-mint-to-help-make-uk-global-cryptoasset-hub-12582312" rel="noopener noreferrer" target="_blank">requested</a> that the Royal Mint issue an NFT.</p><p><a href="https://gizmodo.com/rishi-sunak-new-uk-prime-minister-is-crypto-bro-bitcoin-1849693897">Read more...</a></p>

## Interview With the Vampire Brings Out the Bodies
 - [https://gizmodo.com/interview-with-the-vampire-episode-5-recap-season-1-1849696603](https://gizmodo.com/interview-with-the-vampire-episode-5-recap-season-1-1849696603)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 23:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--nUCzKc3L--/c_fit,fl_progressive,q_80,w_636/9dea11ab63d0818a4c2a8295eb736919.png" /><p>Before we get started, a warning. <a href="https://gizmodo.com/interview-with-the-vampire-ep-four-s1-recap-claudia-1849688512">This episode</a> is incredibly brutal for a few reasons, and I want to give y’all a heads up about what we’re going to be diving into today.<a href="https://gizmodo.com/interview-with-the-vampire-ep-3-recap-season-1-1849667792"> Episode Five</a> of <a href="https://gizmodo.com/interview-with-the-vampire-review-amc-anne-rice-sexy-1849591433"><em>Interview With The Vampire</em></a>, titled “A Vile Hunger For Your Hammering Heart,” deals with rape, implied suicidal ideation, explicit…</p><p><a href="https://gizmodo.com/interview-with-the-vampire-episode-5-recap-season-1-1849696603">Read more...</a></p>

## When Do Fat Girls Get to Be the Main Character?
 - [https://gizmodo.com/fat-main-character-plus-size-five-crowns-of-okrith-1849688940](https://gizmodo.com/fat-main-character-plus-size-five-crowns-of-okrith-1849688940)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 21:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--XlJp8DRn--/c_fit,fl_progressive,q_80,w_636/64594dbb564fba758892cd93522a9df7.jpg" /><p>We’re not used to reading about bigger bodies that are lovable and heroic—let alone <em>desirable</em>. I’ve had people tell me that a <a href="https://gizmodo.com/what-we-do-in-the-shadows-guillermo-de-la-cruz-badass-1849401674">plus size character</a> is “unrealistic.” Really? You believe in <a href="https://gizmodo.com/56-new-scifi-fantasy-horror-books-releasing-oct-2022-1849503298">fae</a> and <a href="https://gizmodo.com/nasa-halloween-posters-1849673830">monsters</a> and <a href="https://gizmodo.com/freya-marske-a-restless-truth-lesbian-romance-fantasy-1849686422">magic</a>, but not a fat main character?<br /></p><p><a href="https://gizmodo.com/fat-main-character-plus-size-five-crowns-of-okrith-1849688940">Read more...</a></p>

## Documents Reveal the Navy's Ambitious Plans for Terrifying Drone Swarms
 - [https://gizmodo.com/navy-drones-1849695894](https://gizmodo.com/navy-drones-1849695894)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 20:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--jhZ-rGpn--/c_fit,fl_progressive,q_80,w_636/4be743f447e2a0c53f908de98d586956.jpg" /><p>The U.S. Navy is reportedly working towards making the nightmarish drone swarms seen in Call of Duty and movies like <em>Angel has Fallen </em>a reality in modern combat. These AI enabled flocks of autonomous buzzing drones could potentially be launched to overwhelm air defense or nose dive from the sky in kamikaze-esque …</p><p><a href="https://gizmodo.com/navy-drones-1849695894">Read more...</a></p>

## Everything We Saw in the Ant-Man and the Wasp: Quantumania Trailer
 - [https://gizmodo.com/antman-2-trailer-breakdown-quantumania-kang-paul-rudd-1849694289](https://gizmodo.com/antman-2-trailer-breakdown-quantumania-kang-paul-rudd-1849694289)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 20:30:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--opAbNEHi--/c_fit,fl_progressive,q_80,w_636/ec4d107ae3df33bfacd28cd22ecae939.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--Vi4-GTf9--/c_fit,fl_progressive,q_80,w_636/ec4d107ae3df33bfacd28cd22ecae939.mp4" type="video/mp4" /></video><p>So, you’ve watched the <a href="https://gizmodo.com/ant-man-new-trailer-wasp-quantumania-2-1849693168">newest trailer</a> for <a href="https://gizmodo.com/ant-man-3-quantumania-wasp-marvel-kang-paul-rudd-1849191638"><em>Ant-Man and the Wasp: Quantumania</em></a><em> </em>and you have questions. I do too! So it’s time for another <a href="https://gizmodo.com/marvel-black-panther-2-wakanda-forever-trailer-breakdow-1849608443">trailer breakdown</a> to dig into <a href="https://gizmodo.com/marvel-thor-4-trailer-breakdown-taika-waititi-natalie-p-1848805743">everything we spotted in this newest glimpse</a> at the upcoming Marvel sequel.<br /></p><p><a href="https://gizmodo.com/antman-2-trailer-breakdown-quantumania-kang-paul-rudd-1849694289">Read more...</a></p>

## Apple Is Sneaking More Ads Onto Your Phone
 - [https://gizmodo.com/apple-app-store-ads-today-tab-homepage-1849694826](https://gizmodo.com/apple-app-store-ads-today-tab-homepage-1849694826)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 20:19:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--rfxo5cg5--/c_fit,fl_progressive,q_80,w_636/4d2909a0b9109347d3f830fa905e7f93.png" /><p>Starting tomorrow, Apple will start showing more ads in its App Store, according to an email reviewed by <a href="https://www.macrumors.com/2022/10/22/apple-announces-more-app-store-ads/" rel="noopener noreferrer" target="_blank">MacRumors</a>. The change is small, but it’s the latest chapter in a growing trend. After years of branding itself as the privacy company, Apple is gunning for the digital ad business—albeit one that’s a little bit…</p><p><a href="https://gizmodo.com/apple-app-store-ads-today-tab-homepage-1849694826">Read more...</a></p>

## U.S. Claims Chinese Intelligence Seeking Confidential Huawei Information Were Duped by FBI Double Agent
 - [https://gizmodo.com/huawei-china-fbi-1849695508](https://gizmodo.com/huawei-china-fbi-1849695508)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 19:52:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s---MEwmqft--/c_fit,fl_progressive,q_80,w_636/b52f51746a371bc12969e98455695e8a.jpg" /><p>Top U.S. law enforcement authorities revealed three newly unsealed cases Monday involving Chinese intelligence agents they say engaged in “malign influence efforts” targeting the United States. One allegedly involving a failed attempt to bribe a U.S official to give up confidential information related to Huawei, a…</p><p><a href="https://gizmodo.com/huawei-china-fbi-1849695508">Read more...</a></p>

## Doctor Who Ends Jodie Whittaker's Era With an Infuriating Mess
 - [https://gizmodo.com/doctor-who-power-of-the-doctor-recap-jodie-whittaker-1849695272](https://gizmodo.com/doctor-who-power-of-the-doctor-recap-jodie-whittaker-1849695272)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 19:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--Jo-lphfa--/c_fit,fl_progressive,q_80,w_636/854274685a3e3f97e634e2c7604b03ea.png" /><p>The <a href="https://gizmodo.com/10-great-doctor-who-moments-from-jodie-whittakers-13th-1847397772">era of the 13th Doctor</a> is over, and it went out how ultimately much of Chris Chibnall’s time as <em>Doctor Who</em>’s showrunner went over the last four years: with moments of brilliance outshined by a plodding, unwieldy mess of narratives that threatened to drag its excellent star down with it. In that way, it’s perhaps a…</p><p><a href="https://gizmodo.com/doctor-who-power-of-the-doctor-recap-jodie-whittaker-1849695272">Read more...</a></p>

## From E. Coli to Flesh-Eating Bacteria, Floodwaters Are a Health Nightmare
 - [https://gizmodo.com/health-dangers-floodwaters-1849657637](https://gizmodo.com/health-dangers-floodwaters-1849657637)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 19:36:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--08RiCfLw--/c_fit,fl_progressive,q_80,w_636/eb2a769d38a6910f04275081e9e78e2b.jpg" /><p>Hurricane Ian hit Florida as category 4 storm in late September, bringing torrential rains and a storm surge that left much of coastal and central Florida underwater. But while the immediate dangers involved drowning and injuries, an invisible threat would soon sicken some people who came in contact with the water:…</p><p><a href="https://gizmodo.com/health-dangers-floodwaters-1849657637">Read more...</a></p>

## Ernie Hudson | First Fandoms
 - [https://gizmodo.com/ernie-hudson-first-fandoms-1849688019](https://gizmodo.com/ernie-hudson-first-fandoms-1849688019)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 19:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--rGwNTXUZ--/c_fit,fl_progressive,q_80,w_636/c055d8dc17b51f0b68df89d0408bbfd3.jpg" /><p><a href="https://gizmodo.com/ernie-hudson-first-fandoms-1849688019">Read more...</a></p>

## Oldest Human DNA Found in the UK Reveals Origins of Early Britons
 - [https://gizmodo.com/oldest-human-dna-found-in-the-uk-reveals-origins-of-ear-1849694469](https://gizmodo.com/oldest-human-dna-found-in-the-uk-reveals-origins-of-ear-1849694469)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 18:46:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--OnTw4vxq--/c_fit,fl_progressive,q_80,w_636/a90977b5cce656e31e0220b76fd1b1ae.png" /><p>Researchers investigating ancient remains found in England and Wales have determined that they contain some of the oldest human DNA ever obtained in the United Kingdom. The DNA indicates Britain was occupied by two unrelated groups, which the scientists believe migrated to the island at the end of the last ice age. </p><p><a href="https://gizmodo.com/oldest-human-dna-found-in-the-uk-reveals-origins-of-ear-1849694469">Read more...</a></p>

## Secretary of Transportation on Elon Musk's Hyperloop: 'Not on Our Dime'
 - [https://gizmodo.com/hyperloop-pete-buttigieg-elon-musk-high-speed-rail-1849693605](https://gizmodo.com/hyperloop-pete-buttigieg-elon-musk-high-speed-rail-1849693605)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 18:20:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--TgZsQ-ho--/c_fit,fl_progressive,q_80,w_636/105f0afc3e5ef8897272c113ef31ccf7.png" /><p>U.S. Department of Transportation Secretary Pete Buttigieg says that although Elon Musk’s “Hyperloop” idea is “super interesting,” he doesn’t believe government money should fund it. “Sure, try it,” he said, “but we’ll probably not try it on our dime.”<br /></p><p><a href="https://gizmodo.com/hyperloop-pete-buttigieg-elon-musk-high-speed-rail-1849693605">Read more...</a></p>

## Henry Thomas Recalls the Moment He Knew E.T. Was a Classic
 - [https://gizmodo.com/henry-thomas-et-spielberg-cloak-dagger-universal-thing-1849684012](https://gizmodo.com/henry-thomas-et-spielberg-cloak-dagger-universal-thing-1849684012)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 18:15:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--QaEkGWz3--/c_fit,fl_progressive,q_80,w_636/423b9d835d1748286da0a5e64467f702.jpg" /><p>There’s a difference between talking to a legend <a href="https://gizmodo.com/all-the-details-that-prove-enders-game-is-a-unique-spa-1216181140">about a new project</a> and talking to them about the project <a href="https://gizmodo.com/harrison-ford-says-han-solos-lines-in-the-force-awakens-1746996774">that made them a legend</a>. Actor Henry Thomas <a href="https://gizmodo.com/this-tearful-e-t-audition-will-make-you-fall-in-love-w-5953553">has been around forever</a>. In recent years, in fact, he’s become a staple of the horror genre working with Netflix on shows like <a href="https://gizmodo.com/netflixs-the-haunting-of-hill-house-is-a-deeply-disturb-1829601290"><em>The Haunting of Hill House</em></a> and <em>The</em>…</p><p><a href="https://gizmodo.com/henry-thomas-et-spielberg-cloak-dagger-universal-thing-1849684012">Read more...</a></p>

## After Fallout With Russia, SpaceX Rival Launches 36 Satellites Aboard India's Big Rocket
 - [https://gizmodo.com/oneweb-launches-internet-satellites-indias-big-rocket-1849693795](https://gizmodo.com/oneweb-launches-internet-satellites-indias-big-rocket-1849693795)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 18:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--kjAFWW4u--/c_fit,fl_progressive,q_80,w_636/41c67f17686b87f6b475ee7fa6755f85.jpg" /><p>British company OneWeb has resumed its plans of building an internet constellation in low Earth orbit despite suffering a frustrating setback earlier this year.</p><p><a href="https://gizmodo.com/oneweb-launches-internet-satellites-indias-big-rocket-1849693795">Read more...</a></p>

## Bono Finally Apologizes for U2's 2014 iTunes Ambush
 - [https://gizmodo.com/u2-itunes-bono-apple-1849694264](https://gizmodo.com/u2-itunes-bono-apple-1849694264)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 18:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--UEo0iLD1--/c_fit,fl_progressive,q_80,w_636/2bfef9aac3ec237b7a13e7fa64d1f263.jpg" /><p>Before you could stream your favorite album at will on the likes of <a href="https://gizmodo.com/spotify-promoted-white-supremacist-artists-adl-report-1849579291">Spotify</a> or <a href="https://gizmodo.com/apple-ai-music-acquisition-1848496216">Apple Music</a>, there was iTunes. In an experimental release strategy, U2's <em>Songs of Innocence</em> was uploaded to the iTunes libraries of users across the world, resulting in <a href="https://gizmodo.com/apple-doesnt-get-that-u2-is-lame-as-hell-1739051978">a wave of backlash</a>. Eight years later, the band’s frontman Bono has…</p><p><a href="https://gizmodo.com/u2-itunes-bono-apple-1849694264">Read more...</a></p>

## YouTube Hopes Its Makeover Will Entice You Away From TikTok
 - [https://gizmodo.com/youtube-gets-redesign-pinch-to-zoom-ambient-mode-1849694129](https://gizmodo.com/youtube-gets-redesign-pinch-to-zoom-ambient-mode-1849694129)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 17:50:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--kH1vyH2I--/c_fit,fl_progressive,q_80,w_636/86a1047bd74a656c7ff524bd78a8570f.jpg" /><p>YouTube is getting a <a href="https://blog.youtube/news-and-events/an-updated-look-and-feel-for-youtube/" rel="noopener noreferrer" target="_blank">slight makeover</a> to keep you engaged on the video platform. The new look includes improved playback options, a better mechanism for scrubbing through video, and the ability to pinch and zoom. The update is rolling out today to iOS and Android devices, with some features also coming to the web…</p><p><a href="https://gizmodo.com/youtube-gets-redesign-pinch-to-zoom-ambient-mode-1849694129">Read more...</a></p>

## Neo-Nazis Are Celebrating Kanye West and Calling Him the Greatest 'Since Adolf Hitler'
 - [https://gizmodo.com/kanye-west-jews-nazis-white-supremacists-adolf-hitler-1849694164](https://gizmodo.com/kanye-west-jews-nazis-white-supremacists-adolf-hitler-1849694164)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 17:48:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--p0CRpqrq--/c_fit,fl_progressive,q_80,w_636/8792e40dddceede79f780f4d737d9683.png" /><p>Kanye West’s recent <a href="https://gizmodo.com/kanye-west-locked-out-of-twitter-antisemitic-tweet-1849636096">antisemitic ravings</a> have inspired celebration and calls to action among white supremacists, neo-Nazis, and other extremist groups online, according to the Anti-Defamation League. Over the weekend, one group took its support of West and his hateful vitriol to new level, dropping a banner stating…</p><p><a href="https://gizmodo.com/kanye-west-jews-nazis-white-supremacists-adolf-hitler-1849694164">Read more...</a></p>

## This Flight Simulator Recreates the Worst Part of Flying: Being a Passenger
 - [https://gizmodo.com/flight-simulator-simulates-being-a-passenger-alex-shake-1849694158](https://gizmodo.com/flight-simulator-simulates-being-a-passenger-alex-shake-1849694158)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 17:40:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--OfiLlqMg--/c_fit,fl_progressive,q_80,w_636/4d92f7c9fbfd06951b350bfdc423245d.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--UnpuC0Yq--/c_fit,fl_progressive,q_80,w_636/4d92f7c9fbfd06951b350bfdc423245d.mp4" type="video/mp4" /></video><p>When you hear the words ‘flight simulator’ you probably picture a complex setup involving giant screens and a painstakingly recreated cockpit that gives flight enthusiasts the chance to live out their pilot fantasies without leaving the ground. <a href="https://www.youtube.com/c/AlexShakespeare/videos" rel="noopener noreferrer" target="_blank">Alex Shakespeare’s</a> “<a href="https://www.youtube.com/watch?v=LW9LAy7qPyU" rel="noopener noreferrer" target="_blank">Alternative flight simulator</a>” provides an entirely…</p><p><a href="https://gizmodo.com/flight-simulator-simulates-being-a-passenger-alex-shake-1849694158">Read more...</a></p>

## 380 Million Tons of Plastic Are Made Every Year. None of It Is Truly Recyclable
 - [https://gizmodo.com/380-million-tons-of-plastic-are-made-every-year-none-o-1849694554](https://gizmodo.com/380-million-tons-of-plastic-are-made-every-year-none-o-1849694554)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 17:35:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--5LhzzSvc--/c_fit,fl_progressive,q_80,w_636/43d9a75801402a1e075053507c44d009.jpg" /><p><em>This story was originally published by <a href="https://grist.org/" rel="noopener noreferrer" target="_blank">Grist</a>. You can <a href="https://go.grist.org/signup/weekly?utm_campaign=signup-page&amp;utm_medium=web&amp;utm_source=grist&amp;utm_content=weekly" rel="noopener noreferrer" target="_blank">subscribe to its weekly newsletter here</a>.<br /></em></p><p><a href="https://gizmodo.com/380-million-tons-of-plastic-are-made-every-year-none-o-1849694554">Read more...</a></p>

## House of the Dragon Showrunner Reveals What That Finale Means For Season 2
 - [https://gizmodo.com/house-of-the-dragon-game-of-thrones-finale-explained-1849694137](https://gizmodo.com/house-of-the-dragon-game-of-thrones-finale-explained-1849694137)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 17:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--KFpzvuFF--/c_fit,fl_progressive,q_80,w_636/51b8a6e0786d9aeda94650698cbdb570.png" /><p>Last night’s <a href="https://gizmodo.com/house-of-the-dragon-finale-recap-black-queen-episode-10-1849692400">stunning season finale of <em>House of the Dragon</em></a> left us with quite a cliffhanger—and we’ll have to wait a while to see what comes next. Shooting for season two of <a href="https://gizmodo.com/house-of-the-dragon-season-1-finale-leak-1849690427"><em>House of the Dragon</em></a><em> </em>will begin in 2023 with its release to be determined, but the <a href="https://gizmodo.com/game-of-thrones-house-of-the-dragon-new-book-spoilers-1849688701"><em>Game of Thrones</em></a> series can likely be expected to bow in 2024. …</p><p><a href="https://gizmodo.com/house-of-the-dragon-game-of-thrones-finale-explained-1849694137">Read more...</a></p>

## Henry Cavill Confirms His Superman Return, to the Surprise of No One
 - [https://gizmodo.com/dc-superman-henry-cavill-return-black-adam-cameo-1849693912](https://gizmodo.com/dc-superman-henry-cavill-return-black-adam-cameo-1849693912)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 16:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--hHdvt-kI--/c_fit,fl_progressive,q_80,w_636/cd5fe830dd7cce68dffd67c4a3acdf01.jpg" /><p><a href="https://gizmodo.com/its-not-fair-that-henry-cavill-is-this-much-of-a-nerd-1842863208">Henry Cavill</a> has officially confirmed what thousands of moviegoers—and <a href="https://gizmodo.com/black-adam-superman-cameo-end-credits-dc-comics-twitter-1849683145">anyone who keeps tabs on movie spoilers</a>—already knows. After <a href="https://gizmodo.com/black-adam-end-credits-superman-henry-cavill-man-of-ste-1849678984">reprising his Superman role</a> at the very end of <a href="https://gizmodo.com/black-adam-review-dwayne-johnson-the-rock-superman-dc-1849627545"><em>Black Adam</em></a>, he is  “back” as the DC hero, though it’s not clear yet exactly where (perhaps the rumored <a href="https://gizmodo.com/dc-man-of-steel-2-batman-villains-wonder-woman-3-update-1849669386"><em>Man of Steel 2</em></a>?) he’ll appear as the…</p><p><a href="https://gizmodo.com/dc-superman-henry-cavill-return-black-adam-cameo-1849693912">Read more...</a></p>

## Saudi Arabia Breaks Ground on Massive Sci-Fi Megacity
 - [https://gizmodo.com/saudi-arabia-the-line-megacity-1849693431](https://gizmodo.com/saudi-arabia-the-line-megacity-1849693431)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 16:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--cgBq1Gtl--/c_fit,fl_progressive,q_80,w_636/2306c0fd1d22828ff1e86658ff0fc20b.png" /><p>The future starts now? Drone footage shows construction beginning on Saudi Arabia’s sci-fi megacity called <a href="https://gizmodo.com/video-mbs-saudi-arabia-dystopian-city-utopia-line-1849331062">The Line</a>—a city planned to be 105 miles (170 kilometers) long that people can live and work in without ever leaving.<br /></p><p><a href="https://gizmodo.com/saudi-arabia-the-line-megacity-1849693431">Read more...</a></p>

## Ant-Man's New Trailer Flies Onto Screens
 - [https://gizmodo.com/ant-man-new-trailer-wasp-quantumania-2-1849693168](https://gizmodo.com/ant-man-new-trailer-wasp-quantumania-2-1849693168)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 16:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--zD981t5Y--/c_fit,fl_progressive,q_80,w_636/5fae23a7195471db85e95a1aaa7d911b.png" /><p>After our <a href="https://twitter.com/MarvelStudios/status/1584575500311154688?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1584575500311154688%7Ctwgr%5E588f91a2fd1a8a326e7563e2ae292cb1b7b9673d%7Ctwcon%5Es1_c10&amp;ref_url=https%3A%2F%2Fkinja.com%2Fembed%2Finset%2Fiframe%3Fautosize%3D1id%3Dtwitter-1584575500311154688" rel="noopener noreferrer" target="_blank">first look</a> at the new Ant-Man film at San <a href="https://gizmodo.com/ant-man-3-quantumania-wasp-marvel-kang-paul-rudd-1849191638">Diego Comic-Con</a>, fans have been eagerly waiting for the long form trailer for <a href="https://gizmodo.com/avengers-kang-dynasty-snags-ant-man-quantumania-writer-1849537343"><em>Ant-Man and the Wasp: Quantumania</em></a>. The film will star Paul Rudd as Scott Lang/Ant-Man and Evangeline Lily as Hope Pym/The Wasp. Also making an appearance in this film—his first feature…</p><p><a href="https://gizmodo.com/ant-man-new-trailer-wasp-quantumania-2-1849693168">Read more...</a></p>

## McLaren’s Putting Kindle Screens on Its Formula 1 Cars
 - [https://gizmodo.com/mclaren-s-putting-e-ink-screens-formula-1-cars-ads-1849693462](https://gizmodo.com/mclaren-s-putting-e-ink-screens-formula-1-cars-ads-1849693462)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 15:55:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--YeIxygWk--/c_fit,fl_progressive,q_80,w_636/70f4b00a7c3f0d3eff9a7e7e5e1c6401.jpg" /><p>McLaren’s multi-million dollar 2022 Formula 1 car and the e-reader you keep on your bedside table now have something in common: they each feature an electronic paper display. But while your Kindle helps you fall asleep each night, McLaren Racing is instead <a href="https://www.mclaren.com/racing/partners/seamless-digital/mclaren-racing-and-seamless-digital-announce-new-multi-year-agreement/" rel="noopener noreferrer" target="_blank">leveraging the unique display technology</a> to help revolutionize <a href="https://goodereader.com/blog/technology/philips-launches-two-in-one-monitor-with-lcd-and-e-ink-panels" rel="noopener noreferrer" target="_blank">…</a></p><p><a href="https://gizmodo.com/mclaren-s-putting-e-ink-screens-formula-1-cars-ads-1849693462">Read more...</a></p>

## Instagram is Testing Adding Songs to Your Profile
 - [https://gizmodo.com/instagram-is-testing-adding-songs-to-your-profile-1849693182](https://gizmodo.com/instagram-is-testing-adding-songs-to-your-profile-1849693182)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 15:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--1AefDGKo--/c_fit,fl_progressive,q_80,w_636/dd764ba651c165ce5bf46357b45c0bf2.jpg" /><p><a href="https://gizmodo.com/instagram-is-testing-adding-songs-to-your-profile-1849693182">Read more...</a></p>

## On House of the Dragon, Rhaenyra Gave Peace a Chance
 - [https://gizmodo.com/house-of-the-dragon-finale-recap-black-queen-episode-10-1849692400](https://gizmodo.com/house-of-the-dragon-finale-recap-black-queen-episode-10-1849692400)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 15:30:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--0xkdoW3u--/c_fit,fl_progressive,q_80,w_636/f98d41122fa231e72e97e9b175dd020a.jpg" /><p> “I wasn’t ready to be Queen of the Seven Kingdoms,” Rhaenyra tells her young son Jacaerys, speaking about when Viserys <a href="https://gizmodo.com/house-of-the-dragon-premiere-recap-game-of-thrones-1849435926">first named her his heir</a>, all those years ago. “But… it was my duty. And in time, I came to understand I had to earn my inheritance.” What Rhaenyra doesn’t know much more she’ll need to do to earn…</p><p><a href="https://gizmodo.com/house-of-the-dragon-finale-recap-black-queen-episode-10-1849692400">Read more...</a></p>

## Doctor Who Reveals David Tennant as The Doctor, Again
 - [https://gizmodo.com/doctor-who-60th-anniversary-trailer-david-tennant-1849693096](https://gizmodo.com/doctor-who-60th-anniversary-trailer-david-tennant-1849693096)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 14:45:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--I1ECa1Rc--/c_fit,fl_progressive,q_80,w_636/6b4d5bea3949e31a09c34fb89febbff3.jpg" /><p>Last night, the BBC announced the return of <a href="https://gizmodo.com/liz-truss-resigns-doctor-who-jodie-whittaker-lettuce-1849681996"><em>Doctor Who</em></a> with a <a href="https://gizmodo.com/doctor-who-60th-anniversary-ncuti-gatwa-david-tennant-1849406080">three-episode special starring </a>none other than <a href="https://gizmodo.com/good-omens-season-two-neil-gaiman-nycc-release-date-1849624118">David Tennant</a>! Sure, he was the tenth doctor, but he was beloved, and there’s got to be an interesting story behind this new regeneration following the death of <a href="https://gizmodo.com/doctor-who-jodie-whittaker-power-of-the-doctor-bbc-1849563840">Jodie Whittaker’s</a> Thirteenth Doctor. </p><p><a href="https://gizmodo.com/doctor-who-60th-anniversary-trailer-david-tennant-1849693096">Read more...</a></p>

## EU Gives Final Approval for USB-C Standard
 - [https://gizmodo.com/charger-usb-c-standard-1849693058](https://gizmodo.com/charger-usb-c-standard-1849693058)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 14:25:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--YjJ70t7u--/c_fit,fl_progressive,q_80,w_636/03657c1e57e32b22aa933de2537a58f3.jpg" /><p>Though some wondered if the day would actually ever come, Europe appears prepared to finally move forward with a common USB-C charging standard.</p><p><a href="https://gizmodo.com/charger-usb-c-standard-1849693058">Read more...</a></p>

## Harvard's Robotic Tentacle Gripper Is Pure Nightmare Fuel
 - [https://gizmodo.com/harvard-debuts-robotic-tentacle-gripper-1849692898](https://gizmodo.com/harvard-debuts-robotic-tentacle-gripper-1849692898)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 14:10:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--H4xtw-en--/c_fit,fl_progressive,q_80,w_636/1f329b1935f6f76ad0bea4448090ab01.jpg" /><p>Part of the versatility of the human hand’s ability to pick up almost anything comes from being able to apply a gentle touch for frail or oddly-shaped objects. That’s something robots struggle with, particularly when functioning autonomously, and unfortunately the solution could lie with an <a href="https://www.seas.harvard.edu/news/2022/10/tentacle-robot-can-gently-grasp-fragile-objects" rel="noopener noreferrer" target="_blank">unorthodox gripper design</a>…</p><p><a href="https://gizmodo.com/harvard-debuts-robotic-tentacle-gripper-1849692898">Read more...</a></p>

## Updates From Black Panther: Wakanda Forever and More
 - [https://gizmodo.com/black-panther-wakanda-forever-teaser-namor-ironheart-1849691993](https://gizmodo.com/black-panther-wakanda-forever-teaser-namor-ironheart-1849691993)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 14:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--H0LGYkxj--/c_fit,fl_progressive,q_80,w_636/b8514c0bc7465d812a17e62b652de48d.png" /><p>Chad Stahleski’s <em>Black Samurai</em> adaptation finds a new writer. Anson Mount is ready for <em>Strange New Worlds</em> season 2. Plus, what’s coming on <em>Stargirl</em> and <em>American Horror Story: NYC</em>. To me, my spoilers!<br /></p><p><a href="https://gizmodo.com/black-panther-wakanda-forever-teaser-namor-ironheart-1849691993">Read more...</a></p>

## The Best Mirrorless Cameras For Video, Beginners, and Low Budgets
 - [https://gizmodo.com/best-mirrorless-cameras-sony-nikon-canon-fuji-budget-1849650887](https://gizmodo.com/best-mirrorless-cameras-sony-nikon-canon-fuji-budget-1849650887)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 13:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--9Zz0_nnh--/c_fit,fl_progressive,q_80,w_636/73ff2375a539daa009dd36f523c287e3.png" /><p>The earliest mirrorless cameras played catchup to DSLRs, which have decades of development behind them. Today’s models are different, capable of everything from professional portraits and video to documenting a night out.<br /></p><p><a href="https://gizmodo.com/best-mirrorless-cameras-sony-nikon-canon-fuji-budget-1849650887">Read more...</a></p>

## Freeway, Crypto Platform That Promised 43% Returns, Halts Withdrawals
 - [https://gizmodo.com/freeway-crypto-bitcoin-price-staking-gold-withdrawals-1849692235](https://gizmodo.com/freeway-crypto-bitcoin-price-staking-gold-withdrawals-1849692235)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 10:00:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--yJFey7J9--/c_fit,fl_progressive,q_80,w_636/f02479f3e25c64e7b16fb49aaf2336f9.png" /><p>Freeway, a UK-based crypto platform that promised annual returns up to a mind-boggling 43%, halted withdrawals on Sunday, according to a notice published to the company’s website. Freeway’s native cryptocurrency, which goes by the ticker FWT, plummeted 74% following the announcement and, to top it all off, the Freeway…</p><p><a href="https://gizmodo.com/freeway-crypto-bitcoin-price-staking-gold-withdrawals-1849692235">Read more...</a></p>

## Damon Lindelof Is Developing a Star Wars Film, And It Now Has a Director
 - [https://gizmodo.com/damon-lindelof-star-wars-film-sharmeen-obaid-chinoy-1849692231](https://gizmodo.com/damon-lindelof-star-wars-film-sharmeen-obaid-chinoy-1849692231)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 03:34:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--DSFGXO09--/c_fit,fl_progressive,q_80,w_636/de6fdb1882f63acfeb9fcd2c2f4593f7.jpg" /><p>Damon Lindelof <a href="https://gizmodo.com/what-did-damon-lindelof-add-to-prometheus-the-biggest-5960275">is working on a</a> <em>Star Wars </em>movie and now it has a director. Deadline reports that Lindelof, best known for his work on <em>Lost, The Leftovers </em>and <a href="https://gizmodo.com/watchmens-season-finale-was-a-devastating-goodbye-a

## The Commonwealth Gets Serious(ly Fascist) on The Walking Dead
 - [https://gizmodo.com/walking-dead-recap-season-11-episode-20-what-was-lost-1849682400](https://gizmodo.com/walking-dead-recap-season-11-episode-20-what-was-lost-1849682400)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2022-10-24 02:03:00+00:00

<img src="https://i.kinja-img.com/gawker-media/image/upload/s--DlLg_0LM--/c_fit,fl_progressive,q_80,w_636/da7b12fd3f0a1b2c04be34a7b0ab2667.jpg" /><p>Good news, <a href="https://gizmodo.com/walking-dead-final-season-11-who-dies-zombies-1849610980"><em>Walking Dead</em></a> fans—er, people who have been watching the show so long that they feel compelled to watch it until the end, regardless of how much pleasure <a href="https://gizmodo.com/walking-dead-recap-variant-season-11-episode-19-1849644481


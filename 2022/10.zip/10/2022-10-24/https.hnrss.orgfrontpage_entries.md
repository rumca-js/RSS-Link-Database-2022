# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Antibody responses to Omicron BA.4/BA.5 bivalent mRNA vaccine booster shot
 - [https://www.biorxiv.org/content/10.1101/2022.10.22.513349v1](https://www.biorxiv.org/content/10.1101/2022.10.22.513349v1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 23:12:39+00:00

<p>Article URL: <a href="https://www.biorxiv.org/content/10.1101/2022.10.22.513349v1">https://www.biorxiv.org/content/10.1101/2022.10.22.513349v1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33323877">https://news.ycombinator.com/item?id=33323877</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Salary Transparency
 - [https://xeiaso.net/salary-transparency](https://xeiaso.net/salary-transparency)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 23:06:36+00:00

<p>Article URL: <a href="https://xeiaso.net/salary-transparency">https://xeiaso.net/salary-transparency</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33323826">https://news.ycombinator.com/item?id=33323826</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Jack Dorsey Unveils Bluesky Social, the Decentralized Twitter-Killer
 - [https://ssaurel.medium.com/jack-dorsey-unveils-bluesky-social-the-decentralized-twitter-killer-cc6eec0c56e5](https://ssaurel.medium.com/jack-dorsey-unveils-bluesky-social-the-decentralized-twitter-killer-cc6eec0c56e5)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 23:05:09+00:00

<p>Article URL: <a href="https://ssaurel.medium.com/jack-dorsey-unveils-bluesky-social-the-decentralized-twitter-killer-cc6eec0c56e5">https://ssaurel.medium.com/jack-dorsey-unveils-bluesky-social-the-decentralized-twitter-killer-cc6eec0c56e5</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33323815">https://news.ycombinator.com/item?id=33323815</a></p>
<p>Points: 73</p>
<p># Comments: 50</p>

## The Surreal Horror of PAM (2021)
 - [https://xeiaso.net/talks/surreal-horror-pam-2021-11-09](https://xeiaso.net/talks/surreal-horror-pam-2021-11-09)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 22:50:23+00:00

<p>Article URL: <a href="https://xeiaso.net/talks/surreal-horror-pam-2021-11-09">https://xeiaso.net/talks/surreal-horror-pam-2021-11-09</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33323683">https://news.ycombinator.com/item?id=33323683</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## New Psychedelic Entactogens
 - [https://psychedelicreview.com/new-psychedelic-entactogens-designer-drugs-produce-designer-effects/](https://psychedelicreview.com/new-psychedelic-entactogens-designer-drugs-produce-designer-effects/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 22:41:22+00:00

<p>Article URL: <a href="https://psychedelicreview.com/new-psychedelic-entactogens-designer-drugs-produce-designer-effects/">https://psychedelicreview.com/new-psychedelic-entactogens-designer-drugs-produce-designer-effects/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33323599">https://news.ycombinator.com/item?id=33323599</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Windows on Arm Project
 - [https://www.linaro.org/windows-on-arm/](https://www.linaro.org/windows-on-arm/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 22:27:31+00:00

<p>Article URL: <a href="https://www.linaro.org/windows-on-arm/">https://www.linaro.org/windows-on-arm/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33323470">https://news.ycombinator.com/item?id=33323470</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Asdf – the language tool version manager
 - [https://asdf-vm.com/guide/introduction.html](https://asdf-vm.com/guide/introduction.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 22:06:34+00:00

<p>Article URL: <a href="https://asdf-vm.com/guide/introduction.html">https://asdf-vm.com/guide/introduction.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33323261">https://news.ycombinator.com/item?id=33323261</a></p>
<p>Points: 30</p>
<p># Comments: 12</p>

## Ask HN: What do you use for encrypting your personal stuff?
 - [https://news.ycombinator.com/item?id=33322789](https://news.ycombinator.com/item?id=33322789)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 21:17:26+00:00

<p>I used to use Truecrypt (file based virtual encrypted disk). But it shut down under mysterious circumstances. 
Now there is veracrypt based on the same source code, but I am not sure I trust it. Are there better alternatives? What does everyone use?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33322789">https://news.ycombinator.com/item?id=33322789</a></p>
<p>Points: 19</p>
<p># Comments: 7</p>

## Ask HN: Is long-term employee commitment to the same company still appreciated?
 - [https://news.ycombinator.com/item?id=33322522](https://news.ycombinator.com/item?id=33322522)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 20:50:10+00:00

<p>I often times see a Linkedin/resume of a senior engineer where they have jumped ship every couple of months, staying max <=2 years in every company they have worked at. Imho, I always thought this was a red flag during the hiring process at a new company, as it doesn't show any long term commitment. I can understand junior/graduate employees jumping ship often in the beginning, but for +10 YOE software engineers, I find it odd.<p>In contrast, staying too long at a single place could make it seem like a developer doesn't want any changes.<p>What is your opinion on this?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33322522">https://news.ycombinator.com/item?id=33322522</a></p>
<p>Points: 17</p>
<p># Comments: 26</p>

## A Shocking Amount of US “Recycling” Goes Straight to the Landfill
 - [https://futurism.com/plastic-recycling-landfill-greenpeace](https://futurism.com/plastic-recycling-landfill-greenpeace)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 20:22:57+00:00

<p>Article URL: <a href="https://futurism.com/plastic-recycling-landfill-greenpeace">https://futurism.com/plastic-recycling-landfill-greenpeace</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33322154">https://news.ycombinator.com/item?id=33322154</a></p>
<p>Points: 55</p>
<p># Comments: 41</p>

## My thoughts on the Framework laptop (from a professional kernel developer)
 - [https://ruscur.au/framework/](https://ruscur.au/framework/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 20:22:13+00:00

<p>Article URL: <a href="https://ruscur.au/framework/">https://ruscur.au/framework/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33322143">https://news.ycombinator.com/item?id=33322143</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## How to Make a Roguelike
 - [https://www.gamedeveloper.com/design/how-to-make-a-roguelike](https://www.gamedeveloper.com/design/how-to-make-a-roguelike)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 19:54:09+00:00

<p>Article URL: <a href="https://www.gamedeveloper.com/design/how-to-make-a-roguelike">https://www.gamedeveloper.com/design/how-to-make-a-roguelike</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33321695">https://news.ycombinator.com/item?id=33321695</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## The Enduring Genius of ‘The Craft of Dying’
 - [https://thereader.mitpress.mit.edu/the-enduring-genius-of-the-craft-of-dying/](https://thereader.mitpress.mit.edu/the-enduring-genius-of-the-craft-of-dying/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 19:52:44+00:00

<p>Article URL: <a href="https://thereader.mitpress.mit.edu/the-enduring-genius-of-the-craft-of-dying/">https://thereader.mitpress.mit.edu/the-enduring-genius-of-the-craft-of-dying/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33321668">https://news.ycombinator.com/item?id=33321668</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## My next Mac might be the last
 - [https://morrick.me/archives/9667](https://morrick.me/archives/9667)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 19:39:57+00:00

<p>Article URL: <a href="https://morrick.me/archives/9667">https://morrick.me/archives/9667</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33321475">https://news.ycombinator.com/item?id=33321475</a></p>
<p>Points: 57</p>
<p># Comments: 88</p>

## Only virgin type of olive oil reduces the risk of mortality
 - [https://www.nature.com/articles/s41430-022-01221-3](https://www.nature.com/articles/s41430-022-01221-3)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 19:28:10+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s41430-022-01221-3">https://www.nature.com/articles/s41430-022-01221-3</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33321283">https://news.ycombinator.com/item?id=33321283</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## I’m Not Sure That (If?) GitHub Copilot Is a Problem
 - [https://michaelweinberg.org/blog/2022/10/24/github-copilot-problem/](https://michaelweinberg.org/blog/2022/10/24/github-copilot-problem/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 19:17:20+00:00

<p>Article URL: <a href="https://michaelweinberg.org/blog/2022/10/24/github-copilot-problem/">https://michaelweinberg.org/blog/2022/10/24/github-copilot-problem/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33321126">https://news.ycombinator.com/item?id=33321126</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## Office Vacancy Rate in San Francisco Just Hit a New High
 - [https://socketsite.com/archives/2022/10/enough-empty-office-space-for-over-150000-employees-in-san-francisco.html](https://socketsite.com/archives/2022/10/enough-empty-office-space-for-over-150000-employees-in-san-francisco.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 18:57:10+00:00

<p>Article URL: <a href="https://socketsite.com/archives/2022/10/enough-empty-office-space-for-over-150000-employees-in-san-francisco.html">https://socketsite.com/archives/2022/10/enough-empty-office-space-for-over-150000-employees-in-san-francisco.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33320817">https://news.ycombinator.com/item?id=33320817</a></p>
<p>Points: 26</p>
<p># Comments: 20</p>

## Mesh shaders talk at XDC 2022
 - [https://rg3.name/202210222107.html](https://rg3.name/202210222107.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 18:56:49+00:00

<p>Article URL: <a href="https://rg3.name/202210222107.html">https://rg3.name/202210222107.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33320811">https://news.ycombinator.com/item?id=33320811</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Attacking Weak RC4-Like Ciphers the Hard Way
 - [https://research.checkpoint.com/2022/attacking-very-weak-rc4-like-ciphers-the-hard-way/](https://research.checkpoint.com/2022/attacking-very-weak-rc4-like-ciphers-the-hard-way/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 18:43:08+00:00

<p>Article URL: <a href="https://research.checkpoint.com/2022/attacking-very-weak-rc4-like-ciphers-the-hard-way/">https://research.checkpoint.com/2022/attacking-very-weak-rc4-like-ciphers-the-hard-way/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33320659">https://news.ycombinator.com/item?id=33320659</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## RISC-V Celebrates Upstreaming of Android Open Source Project RISC-V Port
 - [https://riscv.org/blog/2022/10/risc-v-celebrates-upstreaming-of-android-open-source-project-risc-v-port-risc-v-international/](https://riscv.org/blog/2022/10/risc-v-celebrates-upstreaming-of-android-open-source-project-risc-v-port-risc-v-international/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 18:38:38+00:00

<p>Article URL: <a href="https://riscv.org/blog/2022/10/risc-v-celebrates-upstreaming-of-android-open-source-project-risc-v-port-risc-v-international/">https://riscv.org/blog/2022/10/risc-v-celebrates-upstreaming-of-android-open-source-project-risc-v-port-risc-v-international/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33320597">https://news.ycombinator.com/item?id=33320597</a></p>
<p>Points: 13</p>
<p># Comments: 2</p>

## The Docker+WASM Technical Preview
 - [https://www.docker.com/blog/docker-wasm-technical-preview/](https://www.docker.com/blog/docker-wasm-technical-preview/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 18:33:43+00:00

<p>Article URL: <a href="https://www.docker.com/blog/docker-wasm-technical-preview/">https://www.docker.com/blog/docker-wasm-technical-preview/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33320530">https://news.ycombinator.com/item?id=33320530</a></p>
<p>Points: 18</p>
<p># Comments: 4</p>

## Elasticsearch SQL
 - [https://www.elastic.co/what-is/elasticsearch-sql](https://www.elastic.co/what-is/elasticsearch-sql)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 18:29:21+00:00

<p>Article URL: <a href="https://www.elastic.co/what-is/elasticsearch-sql">https://www.elastic.co/what-is/elasticsearch-sql</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33320477">https://news.ycombinator.com/item?id=33320477</a></p>
<p>Points: 14</p>
<p># Comments: 14</p>

## Forgetting the Asbestos: Or, how we lose knowledge and technologies.
 - [https://1517.substack.com/p/forgetting-the-asbestos](https://1517.substack.com/p/forgetting-the-asbestos)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 18:16:57+00:00

<p>Article URL: <a href="https://1517.substack.com/p/forgetting-the-asbestos">https://1517.substack.com/p/forgetting-the-asbestos</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33320294">https://news.ycombinator.com/item?id=33320294</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## Happy Diwali Everyone
 - [https://en.wikipedia.org/wiki/Diwali](https://en.wikipedia.org/wiki/Diwali)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 18:06:57+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Diwali">https://en.wikipedia.org/wiki/Diwali</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33320181">https://news.ycombinator.com/item?id=33320181</a></p>
<p>Points: 79</p>
<p># Comments: 16</p>

## Most children who think they’re transgender are going through a ‘phase’ – NHS
 - [https://news.yahoo.com/children-think-transgender-just-going-144919057.html](https://news.yahoo.com/children-think-transgender-just-going-144919057.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 18:05:14+00:00

<p>Article URL: <a href="https://news.yahoo.com/children-think-transgender-just-going-144919057.html">https://news.yahoo.com/children-think-transgender-just-going-144919057.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33320162">https://news.ycombinator.com/item?id=33320162</a></p>
<p>Points: 20</p>
<p># Comments: 8</p>

## Accelerated forgetting of a trauma event after a single dose of hydrocortisone
 - [https://www.nature.com/articles/s41398-022-02126-2](https://www.nature.com/articles/s41398-022-02126-2)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 18:04:39+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s41398-022-02126-2">https://www.nature.com/articles/s41398-022-02126-2</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33320156">https://news.ycombinator.com/item?id=33320156</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## WebKit Features in Safari 16.1
 - [https://webkit.org/blog/13399/webkit-features-in-safari-16-1/](https://webkit.org/blog/13399/webkit-features-in-safari-16-1/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 18:01:00+00:00

<p>Article URL: <a href="https://webkit.org/blog/13399/webkit-features-in-safari-16-1/">https://webkit.org/blog/13399/webkit-features-in-safari-16-1/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33320111">https://news.ycombinator.com/item?id=33320111</a></p>
<p>Points: 9</p>
<p># Comments: 5</p>

## Available Today: Windows Dev Kit 2023 a.k.a. Project Volterra
 - [https://blogs.windows.com/windowsdeveloper/2022/10/24/available-today-windows-dev-kit-2023-aka-project-volterra/](https://blogs.windows.com/windowsdeveloper/2022/10/24/available-today-windows-dev-kit-2023-aka-project-volterra/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 17:21:09+00:00

<p>Article URL: <a href="https://blogs.windows.com/windowsdeveloper/2022/10/24/available-today-windows-dev-kit-2023-aka-project-volterra/">https://blogs.windows.com/windowsdeveloper/2022/10/24/available-today-windows-dev-kit-2023-aka-project-volterra/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33319535">https://news.ycombinator.com/item?id=33319535</a></p>
<p>Points: 67</p>
<p># Comments: 52</p>

## macOS Ventura is now available
 - [https://www.apple.com/newsroom/2022/10/macos-ventura-is-now-available/](https://www.apple.com/newsroom/2022/10/macos-ventura-is-now-available/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 17:09:06+00:00

<p>Article URL: <a href="https://www.apple.com/newsroom/2022/10/macos-ventura-is-now-available/">https://www.apple.com/newsroom/2022/10/macos-ventura-is-now-available/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33319367">https://news.ycombinator.com/item?id=33319367</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## SimulaVR: Meta's Subpoena Has Been Dropped
 - [https://simulavr.com/blog/simula-one-vs-quest-pro/](https://simulavr.com/blog/simula-one-vs-quest-pro/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 16:37:35+00:00

<p>Article URL: <a href="https://simulavr.com/blog/simula-one-vs-quest-pro/">https://simulavr.com/blog/simula-one-vs-quest-pro/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33318956">https://news.ycombinator.com/item?id=33318956</a></p>
<p>Points: 31</p>
<p># Comments: 18</p>

## Not the Time to Get Greedy: House Flippers Getting Burned by US Housing Downturn
 - [https://moneywise.com/real-estate/not-the-time-to-get-greedy-for-house-flippers](https://moneywise.com/real-estate/not-the-time-to-get-greedy-for-house-flippers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 16:35:00+00:00

<p>Article URL: <a href="https://moneywise.com/real-estate/not-the-time-to-get-greedy-for-house-flippers">https://moneywise.com/real-estate/not-the-time-to-get-greedy-for-house-flippers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33318917">https://news.ycombinator.com/item?id=33318917</a></p>
<p>Points: 50</p>
<p># Comments: 41</p>

## Cuckoo Filter: Practically Better Than Bloom (2014) [pdf]
 - [https://www.eecs.harvard.edu/~michaelm/postscripts/cuckoo-conext2014.pdf](https://www.eecs.harvard.edu/~michaelm/postscripts/cuckoo-conext2014.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 16:26:22+00:00

<p>Article URL: <a href="https://www.eecs.harvard.edu/~michaelm/postscripts/cuckoo-conext2014.pdf">https://www.eecs.harvard.edu/~michaelm/postscripts/cuckoo-conext2014.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33318788">https://news.ycombinator.com/item?id=33318788</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Show HN: Open-source non-blocking NIO Java HTTP Server
 - [https://github.com/FusionAuth/java-http](https://github.com/FusionAuth/java-http)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 16:22:40+00:00

<p>Article URL: <a href="https://github.com/FusionAuth/java-http">https://github.com/FusionAuth/java-http</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33318725">https://news.ycombinator.com/item?id=33318725</a></p>
<p>Points: 10</p>
<p># Comments: 2</p>

## Every Door – OpenStreetMap editor for POIs and entrances
 - [https://every-door.app/](https://every-door.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 16:17:28+00:00

<p>Article URL: <a href="https://every-door.app/">https://every-door.app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33318659">https://news.ycombinator.com/item?id=33318659</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Memtest86 v6.00 with UEFI support released
 - [https://www.memtest.org/](https://www.memtest.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 16:11:57+00:00

<p>Article URL: <a href="https://www.memtest.org/">https://www.memtest.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33318590">https://news.ycombinator.com/item?id=33318590</a></p>
<p>Points: 28</p>
<p># Comments: 5</p>

## Show HN: IHP v1.0 (Batteries-included web framework built on Haskell and Nix)
 - [https://ihp.digitallyinduced.com/blog/c479f341-1374-496a-96d6-7af647005b21-ihp-1-0](https://ihp.digitallyinduced.com/blog/c479f341-1374-496a-96d6-7af647005b21-ihp-1-0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 16:00:08+00:00

<p>Article URL: <a href="https://ihp.digitallyinduced.com/blog/c479f341-1374-496a-96d6-7af647005b21-ihp-1-0">https://ihp.digitallyinduced.com/blog/c479f341-1374-496a-96d6-7af647005b21-ihp-1-0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33318432">https://news.ycombinator.com/item?id=33318432</a></p>
<p>Points: 33</p>
<p># Comments: 5</p>

## Imagorvideo – video thumbnail server using RMSE in Go and FFmpeg C bindings
 - [https://github.com/cshum/imagorvideo](https://github.com/cshum/imagorvideo)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 15:51:16+00:00

<p>Article URL: <a href="https://github.com/cshum/imagorvideo">https://github.com/cshum/imagorvideo</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33318314">https://news.ycombinator.com/item?id=33318314</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## A follow-up on our analysis of the anomalous restriction map of SARS-CoV-2
 - [https://alexwasburne.substack.com/p/open-letter-to-the-world](https://alexwasburne.substack.com/p/open-letter-to-the-world)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 15:50:50+00:00

<p>Article URL: <a href="https://alexwasburne.substack.com/p/open-letter-to-the-world">https://alexwasburne.substack.com/p/open-letter-to-the-world</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33318307">https://news.ycombinator.com/item?id=33318307</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## What’s wrong with medieval pigs in videogames
 - [https://www.leidenmedievalistsblog.nl/articles/whats-wrong-with-medieval-pigs-in-videogames](https://www.leidenmedievalistsblog.nl/articles/whats-wrong-with-medieval-pigs-in-videogames)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 15:45:06+00:00

<p>Article URL: <a href="https://www.leidenmedievalistsblog.nl/articles/whats-wrong-with-medieval-pigs-in-videogames">https://www.leidenmedievalistsblog.nl/articles/whats-wrong-with-medieval-pigs-in-videogames</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33318215">https://news.ycombinator.com/item?id=33318215</a></p>
<p>Points: 38</p>
<p># Comments: 5</p>

## Show HN: Bolt.css – Another classless CSS library
 - [https://boltcss.com](https://boltcss.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 15:37:20+00:00

<p>Article URL: <a href="https://boltcss.com">https://boltcss.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33318108">https://news.ycombinator.com/item?id=33318108</a></p>
<p>Points: 29</p>
<p># Comments: 12</p>

## Exposure to environmental toxins may be root of rise in neurological disorders
 - [https://www.theguardian.com/us-news/2022/oct/23/environmental-toxins-neurological-disorders-parkinsons-alzheimers](https://www.theguardian.com/us-news/2022/oct/23/environmental-toxins-neurological-disorders-parkinsons-alzheimers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 15:22:45+00:00

<p>Article URL: <a href="https://www.theguardian.com/us-news/2022/oct/23/environmental-toxins-neurological-disorders-parkinsons-alzheimers">https://www.theguardian.com/us-news/2022/oct/23/environmental-toxins-neurological-disorders-parkinsons-alzheimers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33317898">https://news.ycombinator.com/item?id=33317898</a></p>
<p>Points: 29</p>
<p># Comments: 4</p>

## California Poised to Overtake Germany as World’s No. 4 Economy
 - [https://www.washingtonpost.com/business/energy/california-poised-to-overtakegermany-as-worlds-no-4-economy/2022/10/24/d4df35a2-538b-11ed-ac8b-08bbfab1c5a5_story.html](https://www.washingtonpost.com/business/energy/california-poised-to-overtakegermany-as-worlds-no-4-economy/2022/10/24/d4df35a2-538b-11ed-ac8b-08bbfab1c5a5_story.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 15:09:32+00:00

<p>Article URL: <a href="https://www.washingtonpost.com/business/energy/california-poised-to-overtakegermany-as-worlds-no-4-economy/2022/10/24/d4df35a2-538b-11ed-ac8b-08bbfab1c5a5_story.html">https://www.washingtonpost.com/business/energy/california-poised-to-overtakegermany-as-worlds-no-4-economy/2022/10/24/d4df35a2-538b-11ed-ac8b-08bbfab1c5a5_story.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33317718">https://news.ycombinator.com/item?id=33317718</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Putting Kids in Debt
 - [https://idiallo.com/blog/too-young-for-big-school-debt](https://idiallo.com/blog/too-young-for-big-school-debt)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 15:08:52+00:00

<p>Article URL: <a href="https://idiallo.com/blog/too-young-for-big-school-debt">https://idiallo.com/blog/too-young-for-big-school-debt</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33317708">https://news.ycombinator.com/item?id=33317708</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Show HN: Topaz: open-source authorization combining the best of OPA and Zanzibar
 - [https://github.com/aserto-dev/topaz](https://github.com/aserto-dev/topaz)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 15:01:44+00:00

<p>Article URL: <a href="https://github.com/aserto-dev/topaz">https://github.com/aserto-dev/topaz</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33317597">https://news.ycombinator.com/item?id=33317597</a></p>
<p>Points: 28</p>
<p># Comments: 5</p>

## Open Source Seed Initiative
 - [https://osseeds.org/](https://osseeds.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 15:00:22+00:00

<p>Article URL: <a href="https://osseeds.org/">https://osseeds.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33317575">https://news.ycombinator.com/item?id=33317575</a></p>
<p>Points: 22</p>
<p># Comments: 2</p>

## Company that makes rent-setting software for landlords sued for collusion
 - [https://www.propublica.org/article/realpage-accused-of-collusion-in-new-lawsuit](https://www.propublica.org/article/realpage-accused-of-collusion-in-new-lawsuit)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 14:51:02+00:00

<p>Article URL: <a href="https://www.propublica.org/article/realpage-accused-of-collusion-in-new-lawsuit">https://www.propublica.org/article/realpage-accused-of-collusion-in-new-lawsuit</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33317414">https://news.ycombinator.com/item?id=33317414</a></p>
<p>Points: 24</p>
<p># Comments: 0</p>

## Microsoft 3D Movie Maker from 1995 Is Now Open-Source
 - [https://www.howtogeek.com/803277/microsoft-3d-movie-maker-from-1995-is-now-open-source/](https://www.howtogeek.com/803277/microsoft-3d-movie-maker-from-1995-is-now-open-source/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 14:33:05+00:00

<p>Article URL: <a href="https://www.howtogeek.com/803277/microsoft-3d-movie-maker-from-1995-is-now-open-source/">https://www.howtogeek.com/803277/microsoft-3d-movie-maker-from-1995-is-now-open-source/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33317173">https://news.ycombinator.com/item?id=33317173</a></p>
<p>Points: 56</p>
<p># Comments: 18</p>

## The first rule of Microsoft Excel: Don’t tell anyone you’re good at it
 - [https://www.wsj.com/articles/the-first-rule-of-microsoft-exceldont-tell-anyone-youre-good-at-it-1538754380](https://www.wsj.com/articles/the-first-rule-of-microsoft-exceldont-tell-anyone-youre-good-at-it-1538754380)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 14:32:43+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/the-first-rule-of-microsoft-exceldont-tell-anyone-youre-good-at-it-1538754380">https://www.wsj.com/articles/the-first-rule-of-microsoft-exceldont-tell-anyone-youre-good-at-it-1538754380</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33317169">https://news.ycombinator.com/item?id=33317169</a></p>
<p>Points: 86</p>
<p># Comments: 48</p>

## The Evolution of the Data Engineer Role
 - [https://airbyte.com/blog/data-engineering-past-present-and-future](https://airbyte.com/blog/data-engineering-past-present-and-future)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 14:30:02+00:00

<p>Article URL: <a href="https://airbyte.com/blog/data-engineering-past-present-and-future">https://airbyte.com/blog/data-engineering-past-present-and-future</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33317126">https://news.ycombinator.com/item?id=33317126</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Are Real Numbers Real? (2017)
 - [https://ptolemy.berkeley.edu/~eal/pnerd/blog/are-real-numbers-real.html](https://ptolemy.berkeley.edu/~eal/pnerd/blog/are-real-numbers-real.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 14:07:26+00:00

<p>Article URL: <a href="https://ptolemy.berkeley.edu/~eal/pnerd/blog/are-real-numbers-real.html">https://ptolemy.berkeley.edu/~eal/pnerd/blog/are-real-numbers-real.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33316803">https://news.ycombinator.com/item?id=33316803</a></p>
<p>Points: 9</p>
<p># Comments: 6</p>

## The scary sound of Earth’s magnetic field
 - [https://www.esa.int/Applications/Observing_the_Earth/FutureEO/Swarm/The_scary_sound_of_Earth_s_magnetic_field](https://www.esa.int/Applications/Observing_the_Earth/FutureEO/Swarm/The_scary_sound_of_Earth_s_magnetic_field)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 14:03:12+00:00

<p>Article URL: <a href="https://www.esa.int/Applications/Observing_the_Earth/FutureEO/Swarm/The_scary_sound_of_Earth_s_magnetic_field">https://www.esa.int/Applications/Observing_the_Earth/FutureEO/Swarm/The_scary_sound_of_Earth_s_magnetic_field</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33316743">https://news.ycombinator.com/item?id=33316743</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Launch HN: Noloco (YC S21) – Build internal tools from data without code
 - [https://noloco.io](https://noloco.io)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 13:58:57+00:00

<p>Hi all, we’re Darragh and Simon, cofounders of Noloco (<a href="https://noloco.io" rel="nofollow">https://noloco.io</a>), a no-code platform for teams to create internal tools from their business data.<p>Noloco lets you create internal apps from data sources like PostgreSQL, Airtable and Google Sheets without writing any code. This makes building internal tools and configuring views a lot faster than building them with code and SQL queries. It also enables non-technical team members like those in ops, customer support or sales to make changes without having to rely on engineers.<p>Building internal tools is time-consuming and resource intensive, not just for the original build but the ongoing maintenance as well. It’s also not the kind of work that developers typically want to do, nor usually the most valuable use of their time.<p>From our prior experience at tech companies like HubSpot, TripAdvisor, Revolut and Flipdish, we experienced some of the pains around internal tooling first hand. As a PM leading the Payments team in one company, Simon would have to prepare SQL scripts every week to update customer data, and hound developers to run them. Most of the time, businesses simply didn’t have the resources to invest in updating tooling.<p>Since launching in November 2021, we have a wide variety of customers using Noloco for internal tools. For example, one real estate company is using Noloco to manage payment approvals to contractors hired across their property portfolio. An accounting firm uses Noloco as an internal practice management tool to keep track of proposals made to clients and relevant pieces of work. And a lead generation business used Noloco to build a sophisticated CRM and customer portal to track leads provided to their customers.<p>Most platforms that enable building internal tools are either targeted at developers, or are ‘low-code’ and still require some coding expertise to build something useful. Other no-code platforms typically connect to more no-code backends like Google Sheets and often focus more on B2C use cases, enabling building of publicly accessible websites, for example. Often these solutions fall short when it comes to building sophisticated internal tools around data.<p>Noloco is a fully no-code solution focused solely on web apps. We connect to relational databases like PostgreSQL as well as no-code backends like Airtable and Google Sheets, enabling companies to build powerful apps on top of their existing business data from multiple sources. We believe that we’ve got the balance right between simplicity and enhanced configuration ability for power users who want to go deep with customisation: filtering, validation rules, database permission rules etc.<p>It took us a couple of pivots to arrive at this system. Initially we were building a feature-rich full-stack website and web app builder—but no one could build anything useful with it. We decided to revamp the product to make it much simpler. A few weeks later, we had our first version of our client portal builder. This was a step in the right direction, but our value proposition around centralising customer interactions in a custom-made client portal wasn’t resonating with prospects. Finally we realized that what our most successful customers wanted was to share their existing data with their team or customers. This led us to revamp the product once more to make the focus on connecting your existing data. Once you do so, we’re able to automatically build an app around your data meaning that you can launch a whole lot faster with much less of a learning curve.<p>The starting point for building an app with Noloco is adding data. If using an external data source like Airtable or Postgres, you provide your connection details, choose what tables you want to import and then Noloco syncs your data across.  Once the initial import has finished, Noloco instantly builds an app for you around your data—including collections, forms and record pages for each database record. From there, you can customise the app and select the most appropriate layout options to display your data like tables, kanban boards, calendars and charts.<p>You can set database permissions by user role to control what records different users have access to and what fields they can view and edit. This means that you can confidently invite your team or customers and allow them to view, create and update data.<p>In case you’re interested, here’s a video of us building a Lending App from Postgres data:<p><a href="https://www.youtube.com/watch?v=CVDHCvPqgsg" rel="nofollow">https://www.youtube.com/watch?v=CVDHCvPqgsg</a><p>If you’re interested in trying the product, we recently launched our free tier and you get a free trial of all premium features when you sign up. Here’s a link to our sign-up page:<p><a href="https://portals.noloco.io/register" rel="nofollow">https://portals.noloco.io/register</a><p>We’d love to hear from the HN community about your experiences using and building internal tools.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33316694">https://news.ycombinator.com/item?id=33316694</a></p>
<p>Points: 6</p>
<p># Comments: 5</p>

## Tech CEO fired two engineers for having second full-time jobs
 - [https://www.zdnet.com/article/this-tech-ceo-fired-two-engineers-for-having-second-full-time-jobs-warns-theyre-part-of-a-new-trend/](https://www.zdnet.com/article/this-tech-ceo-fired-two-engineers-for-having-second-full-time-jobs-warns-theyre-part-of-a-new-trend/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 13:54:01+00:00

<p>Article URL: <a href="https://www.zdnet.com/article/this-tech-ceo-fired-two-engineers-for-having-second-full-time-jobs-warns-theyre-part-of-a-new-trend/">https://www.zdnet.com/article/this-tech-ceo-fired-two-engineers-for-having-second-full-time-jobs-warns-theyre-part-of-a-new-trend/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33316627">https://news.ycombinator.com/item?id=33316627</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Rishi Sunak will be next UK prime minister
 - [https://www.bbc.co.uk/news/av/uk-politics-63373382](https://www.bbc.co.uk/news/av/uk-politics-63373382)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 13:42:29+00:00

<p>Article URL: <a href="https://www.bbc.co.uk/news/av/uk-politics-63373382">https://www.bbc.co.uk/news/av/uk-politics-63373382</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33316496">https://news.ycombinator.com/item?id=33316496</a></p>
<p>Points: 21</p>
<p># Comments: 1</p>

## Google removes Drink Champs interview from your Google Drive
 - [https://old.reddit.com/r/WestSubEver/comments/yb4pfq/google_is_trying_to_remove_drink_champs_interview/](https://old.reddit.com/r/WestSubEver/comments/yb4pfq/google_is_trying_to_remove_drink_champs_interview/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 13:39:20+00:00

<p>Article URL: <a href="https://old.reddit.com/r/WestSubEver/comments/yb4pfq/google_is_trying_to_remove_drink_champs_interview/">https://old.reddit.com/r/WestSubEver/comments/yb4pfq/google_is_trying_to_remove_drink_champs_interview/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33316465">https://news.ycombinator.com/item?id=33316465</a></p>
<p>Points: 10</p>
<p># Comments: 3</p>

## Tomorrow the Unix timestamp will get to 1,666,666,666
 - [https://time.is/Unix_time](https://time.is/Unix_time)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 13:36:17+00:00

<p>Article URL: <a href="https://time.is/Unix_time">https://time.is/Unix_time</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33316429">https://news.ycombinator.com/item?id=33316429</a></p>
<p>Points: 36</p>
<p># Comments: 7</p>

## Ask HN: HN, but for Scientists?
 - [https://news.ycombinator.com/item?id=33316373](https://news.ycombinator.com/item?id=33316373)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 13:32:19+00:00

<p>Are there platforms/communities such as HN but mostly with scientists instead of CS/engineering people?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33316373">https://news.ycombinator.com/item?id=33316373</a></p>
<p>Points: 40</p>
<p># Comments: 22</p>

## Building the SHAKTI Microprocessor
 - [https://cacm.acm.org/magazines/2022/11/265822-building-the-shakti-microprocessor/fulltext](https://cacm.acm.org/magazines/2022/11/265822-building-the-shakti-microprocessor/fulltext)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 13:29:47+00:00

<p>Article URL: <a href="https://cacm.acm.org/magazines/2022/11/265822-building-the-shakti-microprocessor/fulltext">https://cacm.acm.org/magazines/2022/11/265822-building-the-shakti-microprocessor/fulltext</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33316351">https://news.ycombinator.com/item?id=33316351</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## Apple’s App Review Fix Fails to Placate Developers
 - [https://www.wired.com/story/apples-app-store-review-fix-fails-placate-developers/](https://www.wired.com/story/apples-app-store-review-fix-fails-placate-developers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 13:15:53+00:00

<p>Article URL: <a href="https://www.wired.com/story/apples-app-store-review-fix-fails-placate-developers/">https://www.wired.com/story/apples-app-store-review-fix-fails-placate-developers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33316221">https://news.ycombinator.com/item?id=33316221</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## We improved React loading times with Next.js
 - [https://www.causal.app/blog/next-js](https://www.causal.app/blog/next-js)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 13:01:39+00:00

<p>Article URL: <a href="https://www.causal.app/blog/next-js">https://www.causal.app/blog/next-js</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33316070">https://news.ycombinator.com/item?id=33316070</a></p>
<p>Points: 33</p>
<p># Comments: 7</p>

## The bosses who silently nudge out workers
 - [https://www.bbc.com/worklife/article/20221021-the-bosses-who-silently-nudge-out-workers](https://www.bbc.com/worklife/article/20221021-the-bosses-who-silently-nudge-out-workers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 12:45:51+00:00

<p>Article URL: <a href="https://www.bbc.com/worklife/article/20221021-the-bosses-who-silently-nudge-out-workers">https://www.bbc.com/worklife/article/20221021-the-bosses-who-silently-nudge-out-workers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33315949">https://news.ycombinator.com/item?id=33315949</a></p>
<p>Points: 15</p>
<p># Comments: 6</p>

## Our buildings are making us sick
 - [https://www.vox.com/the-highlight/23377638/buildings-indoor-air-quality-pollution-toxic-sick](https://www.vox.com/the-highlight/23377638/buildings-indoor-air-quality-pollution-toxic-sick)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 12:35:45+00:00

<p>Article URL: <a href="https://www.vox.com/the-highlight/23377638/buildings-indoor-air-quality-pollution-toxic-sick">https://www.vox.com/the-highlight/23377638/buildings-indoor-air-quality-pollution-toxic-sick</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33315866">https://news.ycombinator.com/item?id=33315866</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## A brief demonstration of my Titanium Cyborg Eye as a flashlight [video]
 - [https://www.tiktok.com/@bsmachinist/video/7157587293451062574](https://www.tiktok.com/@bsmachinist/video/7157587293451062574)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 12:23:01+00:00

<p>Article URL: <a href="https://www.tiktok.com/@bsmachinist/video/7157587293451062574">https://www.tiktok.com/@bsmachinist/video/7157587293451062574</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33315758">https://news.ycombinator.com/item?id=33315758</a></p>
<p>Points: 337</p>
<p># Comments: 113</p>

## Guy turned his eye into a flashlight
 - [https://old.reddit.com/r/nextfuckinglevel/comments/ybisa1/this_guy_turned_his_eye_into_a_flashlight/](https://old.reddit.com/r/nextfuckinglevel/comments/ybisa1/this_guy_turned_his_eye_into_a_flashlight/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 12:23:01+00:00

<p>Article URL: <a href="https://old.reddit.com/r/nextfuckinglevel/comments/ybisa1/this_guy_turned_his_eye_into_a_flashlight/">https://old.reddit.com/r/nextfuckinglevel/comments/ybisa1/this_guy_turned_his_eye_into_a_flashlight/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33315758">https://news.ycombinator.com/item?id=33315758</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## In Defense of Missile Defense
 - [https://www.navalgazing.net/In-Defense-of-Missile-Defense](https://www.navalgazing.net/In-Defense-of-Missile-Defense)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 11:53:13+00:00

<p>Article URL: <a href="https://www.navalgazing.net/In-Defense-of-Missile-Defense">https://www.navalgazing.net/In-Defense-of-Missile-Defense</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33315531">https://news.ycombinator.com/item?id=33315531</a></p>
<p>Points: 16</p>
<p># Comments: 7</p>

## Record-breaking chip can transmit entire internet's traffic per second
 - [https://newatlas.com/telecommunications/optical-chip-fastest-data-transmission-record-entire-internet-traffic/](https://newatlas.com/telecommunications/optical-chip-fastest-data-transmission-record-entire-internet-traffic/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 11:36:31+00:00

<p>Article URL: <a href="https://newatlas.com/telecommunications/optical-chip-fastest-data-transmission-record-entire-internet-traffic/">https://newatlas.com/telecommunications/optical-chip-fastest-data-transmission-record-entire-internet-traffic/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33315392">https://news.ycombinator.com/item?id=33315392</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## Ask HN: How to show a not “so perfect” MVP to potential customers?
 - [https://news.ycombinator.com/item?id=33315352](https://news.ycombinator.com/item?id=33315352)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 11:31:27+00:00

<p>Hello.<p>I know that MVP is not about the finished product, but you need at least to show some reliable experience to potential customers.<p>I have an MVP in the AI field, but in order to have accuracy and a fully satisfactory experience, it requires some conditions, because it deals with random variables that I still don't have full control over (i.e:  I need people to speak with good diction/utterance).<p>How can I present this to potential customers so "random variables" wouldn't discredit my product?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33315352">https://news.ycombinator.com/item?id=33315352</a></p>
<p>Points: 6</p>
<p># Comments: 5</p>

## An alternative to Elasticsearch that runs on a few MBs of RAM
 - [https://github.com/valeriansaliou/sonic](https://github.com/valeriansaliou/sonic)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 11:17:42+00:00

<p>Article URL: <a href="https://github.com/valeriansaliou/sonic">https://github.com/valeriansaliou/sonic</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33315237">https://news.ycombinator.com/item?id=33315237</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## The End of Windows Software
 - [https://hardcoresoftware.learningbyshipping.com/p/103-end-of-windows-software](https://hardcoresoftware.learningbyshipping.com/p/103-end-of-windows-software)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 09:37:09+00:00

<p>Article URL: <a href="https://hardcoresoftware.learningbyshipping.com/p/103-end-of-windows-software">https://hardcoresoftware.learningbyshipping.com/p/103-end-of-windows-software</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33314526">https://news.ycombinator.com/item?id=33314526</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Plastic recycling remains a 'myth': Greenpeace study
 - [https://phys.org/news/2022-10-plastic-recycling-myth-greenpeace.html](https://phys.org/news/2022-10-plastic-recycling-myth-greenpeace.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 09:17:23+00:00

<p>Article URL: <a href="https://phys.org/news/2022-10-plastic-recycling-myth-greenpeace.html">https://phys.org/news/2022-10-plastic-recycling-myth-greenpeace.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33314434">https://news.ycombinator.com/item?id=33314434</a></p>
<p>Points: 18</p>
<p># Comments: 9</p>

## The Horrors of the Alpha Channel [video]
 - [https://www.youtube.com/watch?v=XobSAXZaKJ8](https://www.youtube.com/watch?v=XobSAXZaKJ8)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 09:00:49+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=XobSAXZaKJ8">https://www.youtube.com/watch?v=XobSAXZaKJ8</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33314353">https://news.ycombinator.com/item?id=33314353</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## I help seniors with technology issues. A regular came in with a Lenovo laptop
 - [https://twitter.com/i/status/1583169632516509697](https://twitter.com/i/status/1583169632516509697)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 08:47:36+00:00

<p>Article URL: <a href="https://twitter.com/i/status/1583169632516509697">https://twitter.com/i/status/1583169632516509697</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33314291">https://news.ycombinator.com/item?id=33314291</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## I help seniors with technology issues. A regular came in with a Lenovo laptop
 - [https://twitter.com/_danilo/status/1583169632516509697](https://twitter.com/_danilo/status/1583169632516509697)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 08:47:36+00:00

<p>Article URL: <a href="https://twitter.com/_danilo/status/1583169632516509697">https://twitter.com/_danilo/status/1583169632516509697</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33314291">https://news.ycombinator.com/item?id=33314291</a></p>
<p>Points: 863</p>
<p># Comments: 563</p>

## Show HN: Share and Discover Side Projects
 - [https://sideprojects.fazier.com/](https://sideprojects.fazier.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 08:34:35+00:00

<p>Article URL: <a href="https://sideprojects.fazier.com/">https://sideprojects.fazier.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33314220">https://news.ycombinator.com/item?id=33314220</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## Game Boy SM83 CPU Core
 - [https://github.com/Gekkio/gb-research/tree/main/sm83-cpu-core](https://github.com/Gekkio/gb-research/tree/main/sm83-cpu-core)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 08:02:46+00:00

<p>Article URL: <a href="https://github.com/Gekkio/gb-research/tree/main/sm83-cpu-core">https://github.com/Gekkio/gb-research/tree/main/sm83-cpu-core</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33314045">https://news.ycombinator.com/item?id=33314045</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## 27 years since the Financial Times killed one of England’s finest poets
 - [https://twitter.com/mulberrycoates/status/1584116278150602752](https://twitter.com/mulberrycoates/status/1584116278150602752)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 07:22:12+00:00

<p>Article URL: <a href="https://twitter.com/mulberrycoates/status/1584116278150602752">https://twitter.com/mulberrycoates/status/1584116278150602752</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33313835">https://news.ycombinator.com/item?id=33313835</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## The Rise of Discmaster
 - [https://blog.archive.org/2022/10/24/the-rise-of-discmaster/](https://blog.archive.org/2022/10/24/the-rise-of-discmaster/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 07:16:32+00:00

<p>Article URL: <a href="https://blog.archive.org/2022/10/24/the-rise-of-discmaster/">https://blog.archive.org/2022/10/24/the-rise-of-discmaster/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33313799">https://news.ycombinator.com/item?id=33313799</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Behind TikTok's Boom: A Legion of Traumatized, $10-a-Day Content Moderators
 - [https://www.thebureauinvestigates.com/stories/2022-10-20/behind-tiktoks-boom-a-legion-of-traumatised-10-a-day-content-moderators](https://www.thebureauinvestigates.com/stories/2022-10-20/behind-tiktoks-boom-a-legion-of-traumatised-10-a-day-content-moderators)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 06:56:28+00:00

<p>Article URL: <a href="https://www.thebureauinvestigates.com/stories/2022-10-20/behind-tiktoks-boom-a-legion-of-traumatised-10-a-day-content-moderators">https://www.thebureauinvestigates.com/stories/2022-10-20/behind-tiktoks-boom-a-legion-of-traumatised-10-a-day-content-moderators</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33313687">https://news.ycombinator.com/item?id=33313687</a></p>
<p>Points: 15</p>
<p># Comments: 2</p>

## Largest score declines in NAEP mathematics at grades 4 and 8
 - [https://www.nationsreportcard.gov/highlights/mathematics/2022/](https://www.nationsreportcard.gov/highlights/mathematics/2022/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 05:33:46+00:00

<p>Article URL: <a href="https://www.nationsreportcard.gov/highlights/mathematics/2022/">https://www.nationsreportcard.gov/highlights/mathematics/2022/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33313253">https://news.ycombinator.com/item?id=33313253</a></p>
<p>Points: 9</p>
<p># Comments: 3</p>

## Fake Books
 - [https://lcamtuf.substack.com/p/fake-books](https://lcamtuf.substack.com/p/fake-books)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 05:24:32+00:00

<p>Article URL: <a href="https://lcamtuf.substack.com/p/fake-books">https://lcamtuf.substack.com/p/fake-books</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33313211">https://news.ycombinator.com/item?id=33313211</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## The making of Chapter 46 of The Feynman Lectures (2021)
 - [https://physicstoday.scitation.org/do/10.1063/pt.6.3.20211209a/full/](https://physicstoday.scitation.org/do/10.1063/pt.6.3.20211209a/full/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 05:00:00+00:00

<p>Article URL: <a href="https://physicstoday.scitation.org/do/10.1063/pt.6.3.20211209a/full/">https://physicstoday.scitation.org/do/10.1063/pt.6.3.20211209a/full/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33313094">https://news.ycombinator.com/item?id=33313094</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Why Gen X Failed
 - [https://compactmag.com/article/why-gen-x-failed](https://compactmag.com/article/why-gen-x-failed)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 04:01:02+00:00

<p>Article URL: <a href="https://compactmag.com/article/why-gen-x-failed">https://compactmag.com/article/why-gen-x-failed</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33312813">https://news.ycombinator.com/item?id=33312813</a></p>
<p>Points: 13</p>
<p># Comments: 5</p>

## I proudly wake up at 8:59 a.m., one minute before starting my remote work job
 - [https://fortune.com/2022/10/23/waking-up-one-minute-before-remote-job/](https://fortune.com/2022/10/23/waking-up-one-minute-before-remote-job/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 03:45:16+00:00

<p>Article URL: <a href="https://fortune.com/2022/10/23/waking-up-one-minute-before-remote-job/">https://fortune.com/2022/10/23/waking-up-one-minute-before-remote-job/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33312753">https://news.ycombinator.com/item?id=33312753</a></p>
<p>Points: 17</p>
<p># Comments: 8</p>

## Buffers on the Edge: Python and Rust
 - [https://alexgaynor.net/2022/oct/23/buffers-on-the-edge/](https://alexgaynor.net/2022/oct/23/buffers-on-the-edge/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 02:52:53+00:00

<p>Article URL: <a href="https://alexgaynor.net/2022/oct/23/buffers-on-the-edge/">https://alexgaynor.net/2022/oct/23/buffers-on-the-edge/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33312508">https://news.ycombinator.com/item?id=33312508</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Why are there so few dead bugs on windshields these days?
 - [https://www.washingtonpost.com/business/2022/10/21/dead-bugs-on-windshields/](https://www.washingtonpost.com/business/2022/10/21/dead-bugs-on-windshields/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 02:44:28+00:00

<p>Article URL: <a href="https://www.washingtonpost.com/business/2022/10/21/dead-bugs-on-windshields/">https://www.washingtonpost.com/business/2022/10/21/dead-bugs-on-windshields/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33312469">https://news.ycombinator.com/item?id=33312469</a></p>
<p>Points: 33</p>
<p># Comments: 2</p>

## JPEG of Shakespeare is also a zip file containing his complete works (2018)
 - [https://twitter.com/david3141593/status/1057042085029822464](https://twitter.com/david3141593/status/1057042085029822464)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 02:38:49+00:00

<p>Article URL: <a href="https://twitter.com/david3141593/status/1057042085029822464">https://twitter.com/david3141593/status/1057042085029822464</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33312441">https://news.ycombinator.com/item?id=33312441</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## A guide for getting started with Self Hosting
 - [https://github.com/mikeroyal/Self-Hosting-Guide](https://github.com/mikeroyal/Self-Hosting-Guide)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 02:21:10+00:00

<p>Article URL: <a href="https://github.com/mikeroyal/Self-Hosting-Guide">https://github.com/mikeroyal/Self-Hosting-Guide</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33312336">https://news.ycombinator.com/item?id=33312336</a></p>
<p>Points: 25</p>
<p># Comments: 1</p>

## Typical CO2 Levels at Home Test
 - [https://www.co2meter.com/blogs/news/co2-levels-at-home](https://www.co2meter.com/blogs/news/co2-levels-at-home)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 02:15:20+00:00

<p>Article URL: <a href="https://www.co2meter.com/blogs/news/co2-levels-at-home">https://www.co2meter.com/blogs/news/co2-levels-at-home</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33312298">https://news.ycombinator.com/item?id=33312298</a></p>
<p>Points: 4</p>
<p># Comments: 2</p>

## Debugging C with Cosmopolitan Libc
 - [https://ahgamut.github.io/2022/10/23/debugging-c-with-cosmo/](https://ahgamut.github.io/2022/10/23/debugging-c-with-cosmo/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 01:24:29+00:00

<p>Article URL: <a href="https://ahgamut.github.io/2022/10/23/debugging-c-with-cosmo/">https://ahgamut.github.io/2022/10/23/debugging-c-with-cosmo/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33312012">https://news.ycombinator.com/item?id=33312012</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## WebAuthN and Fido for Linux
 - [https://github.com/AlfioEmanueleFresta/xdg-credentials-portal](https://github.com/AlfioEmanueleFresta/xdg-credentials-portal)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2022-10-24 00:48:46+00:00

<p>Article URL: <a href="https://github.com/AlfioEmanueleFresta/xdg-credentials-portal">https://github.com/AlfioEmanueleFresta/xdg-credentials-portal</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=33311807">https://news.ycombinator.com/item?id=33311807</a></p>
<p>Points: 23</p>
<p># Comments: 3</p>


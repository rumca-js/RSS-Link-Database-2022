# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Our House of Cards is Crumbling! News Update
 - [https://www.youtube.com/watch?v=kRndt2c15YA](https://www.youtube.com/watch?v=kRndt2c15YA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-10-25 00:00:00+00:00

Grab your Black Out Sleep Mask at https://boncharge.com/jp  
Use Code "JP" for 15% Off!

Be the first to see my Comedy Special at https://pleasecensorthis.locals.com

Get your Freedom Merch Here - https://bit.ly/3SqObSZ

Upcoming LIVE shows - https://awakenwithjp.com/pages/tour

Get updates from me via email here: https://awakenwithjp.com/joinme

Our whole house of cards is crumbling! But we’re still trying to save it with our top stories that we’ll deceive you about this evening...

Listen and Subscribe to my Podcast here: 
https://apple.co/3fFTbPC

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
https://rumble.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

## Please Censor This! Live Q&A
 - [https://www.youtube.com/watch?v=-avXvhtez5Y](https://www.youtube.com/watch?v=-avXvhtez5Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2022-10-24 00:00:00+00:00

Join me for a live Q&A Monday night at 8PM CT to chat about my new Comedy special, "Please Censor This!" and the Freedom Lovers Community on Locals! http://pleasecensorthis.locals.com/


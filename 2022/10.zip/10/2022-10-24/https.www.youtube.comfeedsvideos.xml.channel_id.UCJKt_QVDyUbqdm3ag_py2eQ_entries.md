# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## Amiga Paula does XM: Elwood - After Hours (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=-wTZx8nd_GE](https://www.youtube.com/watch?v=-wTZx8nd_GE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-10-25 00:00:00+00:00

"After Hours" (1998) by Elwood (Jussi Salmela).
Art "Obsolete" by jok, 6th at Revision 2013.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- Module reports 30 channels
- 100% flawless playback not guaranteed (the XM replayer is not perfect)

Visit my channel for more Amiga music.

## Amiga music: Skip & Grogon - Viesuav Goas (A1200🎧Dolbyfied)
 - [https://www.youtube.com/watch?v=4ze-YNdWN18](https://www.youtube.com/watch?v=4ze-YNdWN18)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2022-10-24 00:00:00+00:00

"Viesuav Goas" (2001-2022) by Skip & Grogon (Przemyslaw Tkaczyk & Andrzej Dobrowolski).
Art "The Inner Portal - Duality of Life" by Critikill/Brainstorm^Rebels^SWEET16, 1st at Xenium 2022.

Made using real A1200 Rev. 1D.4 audio. Playback from DeliTracker 2.34 with 14Bit-NotePlayer 4.30:
- 14-bit calibrated Paula output
- Exact interpolation with 44336 Hz mixing frequency
- No panning, no 3D and DSP off. Anti-click enabled
- 4 channel Protracker module

Visit my channel for more Amiga music.


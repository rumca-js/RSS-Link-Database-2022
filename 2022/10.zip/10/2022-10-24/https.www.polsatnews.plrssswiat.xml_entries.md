# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Wielka Brytania. Prezenter radiowy Tim Gough zmarł podczas audycji
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/wielka-brytania-prezenter-radiowy-tim-gough-zmarl-podczas-audycji/](https://www.polsatnews.pl/wiadomosc/2022-10-24/wielka-brytania-prezenter-radiowy-tim-gough-zmarl-podczas-audycji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 21:13:00+00:00

55-letni prezenter radiowy Tim Gough zmarł godzinę po rozpoczęciu porannej audycji - informuje CNN. Stacja GenX Radio Suffolk z Wielkiej Brytanii, w której pracował, zamieściła kondolencje w mediach społecznościowych. W chwili śmierci mężczyzny muzyka nagle przestała grać, a w głośnikach słuchaczy zapadła głucha cisza. Prowadzący nie powrócił już na antenę.

## Watykan. Macron przekazał papieżowi Franciszkowi bezcenną książkę. Jeden szczegół wywołał burzę
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/watykan-macron-przekazal-franciszkowi-cenna-ksiazke-jeden-szczegol-wywolal-burze-w-internecie/](https://www.polsatnews.pl/wiadomosc/2022-10-24/watykan-macron-przekazal-franciszkowi-cenna-ksiazke-jeden-szczegol-wywolal-burze-w-internecie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 20:04:00+00:00

Prezydent Francji Emmanuel Macron odwiedził w poniedziałek Stolicę Apostolską, gdzie spotkał się z papieżem. Podczas prywatnej audiencji ofiarował głowie Kościoła pierwsze francuskie wydanie książki Immanuela Kanta z końca XVIII wieku. Ale gdy do sieci wyciekła strona tytułowa dzieła, w mediach społecznościowych rozpętała się burza.

## Gigantyczna asteroida przeleci tuż obok Ziemi. Ma 740 metrów średnicy
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/gigantyczna-asteroida-przeleci-tuz-obok-ziemi-ma-740-metrow-srednicy/](https://www.polsatnews.pl/wiadomosc/2022-10-24/gigantyczna-asteroida-przeleci-tuz-obok-ziemi-ma-740-metrow-srednicy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 19:53:00+00:00

Mająca od 300 do 740 metrów średnicy asteroida nazwana 2022 RM4 ma minąć Ziemię 1 listopada. Obiekt mknie w kierunku naszej planety z prędkością do 85 tys. kilometrów na godzinę.

## Spór Doroty Bawołek i TVP: Unijny komisarz ds. sprawiedliwości reaguje
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/spor-doroty-bawolek-i-tvp-unijny-komisarz-ds-sprawiedliwosci-reaguje/](https://www.polsatnews.pl/wiadomosc/2022-10-24/spor-doroty-bawolek-i-tvp-unijny-komisarz-ds-sprawiedliwosci-reaguje/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 19:34:00+00:00

W UE nie ma miejsca na oszczercze kampanie przeciwko dziennikarzom - napisał na Twitterze Didier Reynders, unijny komisarz ds. sprawiedliwości. Wpisem odniósł się do sporu między dziennikarską Polsat News Dorotą Bawołek i TVP.

## USA. Poszła na zabieg wypełniania ust. Wizyta zakończyła się w szpitalu
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/usa-poszla-na-zabieg-wypelniania-ust-wizyta-zakonczyla-sie-w-szpitalu/](https://www.polsatnews.pl/wiadomosc/2022-10-24/usa-poszla-na-zabieg-wypelniania-ust-wizyta-zakonczyla-sie-w-szpitalu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 16:18:00+00:00

Amerykanka z Las Vegas była w szoku, gdy po jednej z wizyt w gabinecie kosmetycznym zobaczyła swoją twarz w lustrze. Jej zaskoczenie było tym większe, że już wcześniej przeprowadzała podobny zabieg. Tym razem jednak coś poszło nie tak.

## Wielka Brytania: Kolejna akcja aktywistów. Obrzucili ciastem figurę króla Karola III
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/wielka-brytania-kolejna-akcja-aktywistow-obrzucili-ciastem-figure-krola-karola-iii/](https://www.polsatnews.pl/wiadomosc/2022-10-24/wielka-brytania-kolejna-akcja-aktywistow-obrzucili-ciastem-figure-krola-karola-iii/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 15:09:00+00:00

Aktywiści z organizacji Just Stop Oil obrzucili woskową figurę króla Karola III ciastem czekoladowym. Do incydentu doszło w Muzeum Figur Woskowych Madame Tussaud w Londynie.

## Francja. Wichury i tornado w północnej części kraju. Ogromne zniszczenia
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/francja-wichury-i-tornado-w-polnocnej-czesci-kraju-ogromne-zniszczenia/](https://www.polsatnews.pl/wiadomosc/2022-10-24/francja-wichury-i-tornado-w-polnocnej-czesci-kraju-ogromne-zniszczenia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 14:59:00+00:00

Tornado uderzyło w wioskę Bihucourt w północnej Francji w niedzielę. Towarzyszący burzy silny wiatr zrywał dachy z budynków i zniszczył wiekowy kościół.

## Indie. Słonie sterroryzowały mieszkańców wioski. Zadeptały mężczyznę w zemście za zabicie młodego
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/indie-slonie-sterroryzowaly-mieszkancow-wioski-zadeptaly-mezczyzne-w-zemscie-za-zabicie-mlodego/](https://www.polsatnews.pl/wiadomosc/2022-10-24/indie-slonie-sterroryzowaly-mieszkancow-wioski-zadeptaly-mezczyzne-w-zemscie-za-zabicie-mlodego/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 14:51:00+00:00

Stado słoni wpadło w szał po tym, jak jedno z należących do grupy cieląt zostało zabite przez mieszkańców indyjskiej wsi. Wściekłe zwierzęta spustoszyły osadę, zadeptując jednego z mężczyzn. Lokalne media spekulują, że słonie mogły dokonać w ten sposób aktu zemsty.

## Wielka Brytania. Rishi Sunak nowym premierem. Kim jest nowy szef brytyjskiego rządu?
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/wielka-brytania-rishi-sunak-nowym-premierem-kim-jest-nowy-szef-rzadu-jego-krolewskiej-mosci/](https://www.polsatnews.pl/wiadomosc/2022-10-24/wielka-brytania-rishi-sunak-nowym-premierem-kim-jest-nowy-szef-rzadu-jego-krolewskiej-mosci/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 14:15:00+00:00

Rishi Sunak został w poniedziałek nowym szefem sprawującej władzę w Wielkiej Brytanii Partii Konserwatywnej, a co za tym idzie nowym premierem brytyjskiego rządu. To trzecia zmiana na tym urzędzie w ciągu ostatnich dwóch miesięcy. Kim jest Rishi Sunak?

## Ukraina: Poszukiwania byłego szefa Narodowego Banku. Chodzi o kradzież ponad 200 mln hrywien
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/ukraina-poszukiwania-bylego-szefa-narodowego-banku-chodzi-o-kradziez-ponad-200-mln-hrywien/](https://www.polsatnews.pl/wiadomosc/2022-10-24/ukraina-poszukiwania-bylego-szefa-narodowego-banku-chodzi-o-kradziez-ponad-200-mln-hrywien/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 14:02:00+00:00

Były szef Narodowego Banku Ukrainy Kyryło Szewczenko oraz dwóch kierowników Ukrgasbanku są poszukiwani przez ukraińskie organy ścigania. Bankowcy są podejrzewani o kradzież ponad 200 milionów hrywien.

## Szwecja. Kobra królewska uciekła z terrarium. Trwają poszukiwania węża
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/szwecja-kobra-krolewska-uciekla-z-terrarium-trwaja-poszukiwania-weza/](https://www.polsatnews.pl/wiadomosc/2022-10-24/szwecja-kobra-krolewska-uciekla-z-terrarium-trwaja-poszukiwania-weza/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 13:49:00+00:00

Z zoo w Sztokholmie uciekła 2,5 metrowa kobra królewska. Wąż wydostał się z terrarium przez szparę w zamontowanej w suficie lampie. Kobra królewska jest największym jadowitym wężem świata.

## USA: Odmówiła upieczenia tortu na ślub homoseksualnej pary. Sąd przyznał jej rację
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/usa-odmowila-upieczenia-tortu-na-slub-homoseksualnej-pary-sad-przyznal-jej-racje/](https://www.polsatnews.pl/wiadomosc/2022-10-24/usa-odmowila-upieczenia-tortu-na-slub-homoseksualnej-pary-sad-przyznal-jej-racje/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 13:27:00+00:00

Właścicielka cukierni, która odmówiła przygotowania tortu weselnego dla pary jednopłciowej działała zgodnie z prawem - orzekł sędzia Eric Bradshow, który prowadził sprawę. Kobiecie zarzucano dyskryminację i naruszenie kalifornijskiej ustawy Unruh dot. praw obywatelskich.

## Wielka Brytania: Partia Konserwatywna ma nowego lidera. Rishi Sunak zostanie nowym premierem
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/wielka-brytania-partia-konserwatywna-ma-nowego-lidera-x-zostanie-nowym-premierem/](https://www.polsatnews.pl/wiadomosc/2022-10-24/wielka-brytania-partia-konserwatywna-ma-nowego-lidera-x-zostanie-nowym-premierem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 13:00:00+00:00

Rishi Sunak uzyskał poparcie posłów Partii Konserwatywnej, zostając tym samym nowym liderem ugrupowania. Następca Liz Truss po audiencji u króla Karola III zostanie ogłoszony premierem Wielkiej Brytanii.

## Wojna w Ukrainie: Rosjanie walczą o skradzione arbuzy. Owoce pochodzą z Ukrainy
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/wojna-w-ukrainie-rosjanie-walcza-o-skradzione-arbuzy-owoce-pochodza-z-ukrainy/](https://www.polsatnews.pl/wiadomosc/2022-10-24/wojna-w-ukrainie-rosjanie-walcza-o-skradzione-arbuzy-owoce-pochodza-z-ukrainy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 12:52:00+00:00

W sieciach pojawiło się wideo z rosyjskiego targowiska. Widać na nim ludzi walczących o arbuzy. Owoce mają pochodzić z Ukrainy.

## Rosja: Propagandysta Anton Krasowski wzywał do topienia dzieci. Został zwieszony
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/rosja-propagandysta-anton-krasowski-wzywal-do-topienia-dzieci-zostal-zwieszony/](https://www.polsatnews.pl/wiadomosc/2022-10-24/rosja-propagandysta-anton-krasowski-wzywal-do-topienia-dzieci-zostal-zwieszony/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 12:15:00+00:00

Rosyjski propagandysta Anton Krasowski, który na antenie Russia Today wzywał do wrzucania ukraińskich dzieci do rzeki lub palenia ich w domach został zawieszony. Te słowa były dzikie i obrzydliwe. Być może Anton wyjaśni, co spowodowało to chwilowe szaleństwo - napisała redaktor naczelna RT Margarita Simonjan.

## Niezwykłe zachowanie psów w Ukrainie. Czekały w kolejce do jedzenia
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/wojna-w-ukrainie-bezdomne-psy-czekaja-na-swoja-kolej-jedzenia-niezwykle-zachowanie-czworonogow/](https://www.polsatnews.pl/wiadomosc/2022-10-24/wojna-w-ukrainie-bezdomne-psy-czekaja-na-swoja-kolej-jedzenia-niezwykle-zachowanie-czworonogow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 10:37:00+00:00

Nagranie z odbitego przez ukraińskie siły Kramatorska pokazało niesamowite zachowanie bezpańskich psów. Czworonogi posłusznie czekają na swoją kolej, aby zjeść w karmniku. - Nigdy nie widziałem czegoś takiego - powiedział pomysłodawca dokarmiania bezdomnych zwierząt w Ukrainie, Nate Mook.

## Brazylia: Polityk nazwał sędzię prostytutką. Gdy przyszła policja, rzucił w nią granatem
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/brazylia-policjanci-mieli-aresztowac-polityka-rzucil-w-nich-granatem/](https://www.polsatnews.pl/wiadomosc/2022-10-24/brazylia-policjanci-mieli-aresztowac-polityka-rzucil-w-nich-granatem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 10:19:00+00:00

Brazylijski polityk Roberto Jefferson podczas próby aresztowania otworzył ogień w stronę radiowozu, a później rzucił granatem w policjantów. Dwóch oficerów zostało rannych i przewiezionych do szpitala. Jefferson odsiadywał wcześniej wyrok za pranie pieniędzy i korupcję, został jednak ułaskawiony przez prezydenta.

## "Wrzątek, prąd i wieszanie kobiet". Ukrainka opowiedziała o torturach Rosjan
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/wrzatek-prad-i-wieszanie-kobiet-ukrainka-opowiedziala-o-torturach-rosjan/](https://www.polsatnews.pl/wiadomosc/2022-10-24/wrzatek-prad-i-wieszanie-kobiet-ukrainka-opowiedziala-o-torturach-rosjan/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 08:29:00+00:00

Ukraińska wojskowa, która ostatnie pół roku spędziła w rosyjskiej niewoli opowiedziała o torturach stosowanych przez okupantów. Jak przyznała, bicie i rażenie prądem były najłagodniejszymi rzeczami. Odnosząc się do jedzenia dla jeńców stwierdziła, że nawet psom nie podaje się czegoś takiego. Hanna znalazła się wśród 108 kobiet, które zostały niedawno zwolnione z rosyjskiej niewoli.

## Rosyjski propagandysta mówił o topieniu ukraińskich dzieci
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/rosja-dziennikarz-mowi-o-topieniu-ukrainskich-dzieci-zapowiada-rozstrzelanie-ukraincow/](https://www.polsatnews.pl/wiadomosc/2022-10-24/rosja-dziennikarz-mowi-o-topieniu-ukrainskich-dzieci-zapowiada-rozstrzelanie-ukraincow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 07:35:00+00:00

Znany rosyjski propagandysta Anton Krasowski stwierdził, że ukraińskie dzieci, które mówią, że okupuje ich Moskwa, powinno się od razu wrzucić do rzeki z silnym nurtem. Powiedział też, że Ukraińcy, którzy zostaną w kraju po wojnie zostaną rozstrzelani.

## Wymiana ognia między Koreą Północną a Południową
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/wymiana-ognia-miedzy-korea-polnocna-a-poludniowa/](https://www.polsatnews.pl/wiadomosc/2022-10-24/wymiana-ognia-miedzy-korea-polnocna-a-poludniowa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 06:25:00+00:00

W nocy z niedzieli na poniedziałek doszło do wymiany ognia między okrętami Korei Południowej i Północnej. Pretekstem do oddania strzałów ostrzegawczych był statek handlowy Korei Północnej, który przekroczył linię graniczną - przekazali Połączeni Szefowie Sztabów Południa (JCS). W odpowiedzi wojsko Północy wystrzeliło 10 pocisków artyleryjskich.

## USA: Kłótnia nastolatek w pociągu. Jedna osoba w szpitalu
 - [https://www.polsatnews.pl/wiadomosc/2022-10-24/usa-klotnia-nastolatek-w-pociagu-jedna-osoba-w-szpitalu/](https://www.polsatnews.pl/wiadomosc/2022-10-24/usa-klotnia-nastolatek-w-pociagu-jedna-osoba-w-szpitalu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2022-10-24 04:20:00+00:00

14-letnia dziewczyna została dźgnięta nożem w klatkę piersiową po tym, jak pokłóciła się z dwiema innymi nastolatkami. Dziewczynę przewieziono do szpitala w stabilnym stanie. Ranny został też 13-latek, który odniósł powierzchowne obrażenia. Policja szuka napastniczek.


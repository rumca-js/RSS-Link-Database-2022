## Rodzice oburzeni. Pierwsze niemieckie miasto z taką regulacją
 - [https://www.wykop.pl/link/6873985/rodzice-oburzeni-pierwsze-niemieckie-miasto-z-taka-regulacja/](https://www.wykop.pl/link/6873985/rodzice-oburzeni-pierwsze-niemieckie-miasto-z-taka-regulacja/)
 - RSS feed: https://www.wykop.pl/rss/index.xml/
 - date published: 2022-10-24 23:35:02+00:00

<img src="https://www.wykop.pl/cdn/c3397993/link_1666642369bVYbejdOIgwgncGbxNLvkd,w104h74.jpg" /><br />
		 Od stycznia dzieci w miejskich żłobkach i szkołach podstawowych we Freiburgu będą mogły jeść wyłącznie wegetariańskie lub wegańskie potrawy. Decyzję w tej sprawie podjęła rada miasta, tłumacząc się cięciem kosztów oraz dbaniem o środowisko. Zapowiedziano również stopniowy wzrost cen posiłków.

## Badanie świateł w nocy sugeruje, że dyktatury kłamią na temat gospodarki. [ENG]
 - [https://www.wykop.pl/link/6873425/badanie-swiatel-w-nocy-sugeruje-ze-dyktatury-klamia-na-temat-gospodarki-eng/](https://www.wykop.pl/link/6873425/badanie-swiatel-w-nocy-sugeruje-ze-dyktatury-klamia-na-temat-gospodarki-eng/)
 - RSS feed: https://www.wykop.pl/rss/index.xml/
 - date published: 2022-10-24 14:21:01+00:00

<img src="https://www.wykop.pl/cdn/c3397993/link_1666617390fcN5BHgiWCcrYoz6iXaPGG,w104h74.jpg" /><br />
		 Co mówią zdjęcia satelitarne krajów nocą? Zdaniem ekonomisty Luisa Martineza te zdjęcia to &quot;koronny dowód&quot; jak kraje manipulują statystykami związanych z PKB. wg. analizy zdjęć skumulowany wzrost PKB w latach 2002-2021 w krajach &quot;nie wolnych&quot; jest średnio prawie o połowę niższy niż deklarowany.

## Polityczna organizacja Trumpa wydaje 91% zebranych pieniędzy na koszty własne.
 - [https://www.wykop.pl/link/6873285/polityczna-organizacja-trumpa-wydaje-91-zebranych-pieniedzy-na-koszty-wlasne/](https://www.wykop.pl/link/6873285/polityczna-organizacja-trumpa-wydaje-91-zebranych-pieniedzy-na-koszty-wlasne/)
 - RSS feed: https://www.wykop.pl/rss/index.xml/
 - date published: 2022-10-24 14:19:01+00:00

<img src="https://www.wykop.pl/cdn/c3397993/link_1666611693qgjPtNPyhxIQ5eqaNAmWSX,w104h74.jpg" /><br />
		 Były prezydent zbiera rekordowe ilości pieniędzy od darczyńców, ale niemal całość idzie na koszty administracyjne jego ruchu politycznego, a nie na cele statutowe.


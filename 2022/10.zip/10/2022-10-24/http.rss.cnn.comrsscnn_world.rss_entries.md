# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Kraft Heinz CEO: Inflation and supply shortages are here to stay for a while
 - [https://www.cnn.com/2022/10/24/economy/kraft-heinz-ceo-inflation-supply-shortage/index.html](https://www.cnn.com/2022/10/24/economy/kraft-heinz-ceo-inflation-supply-shortage/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-24 20:58:55+00:00

Kraft Heinz CEO Miguel Patricio says higher inflation and supply issues are coursing through the food industry, forcing companies to adopt new strategies for everything from production to promotion to packaging.

## London-based TV channel sparks Iranian leaders' ire amid protests
 - [https://www.cnn.com/2022/10/24/middleeast/saudi-iran-media-protests-mime-intl/index.html](https://www.cnn.com/2022/10/24/middleeast/saudi-iran-media-protests-mime-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-24 19:43:15+00:00

A top Iranian military official issued a warning to Saudi Arabia last week as his government continued to face off against protesters at home. "You are involved in this matter and know that you are vulnerable, it is better to be careful," he said at the sidelines of a military drill.

## Arshad Sharif, prominent journalist who fled Pakistan, killed in shooting in Kenya
 - [https://www.cnn.com/2022/10/24/media/pakistan-arshad-sharif-journalist-killed-kenya-lgs-intl/index.html](https://www.cnn.com/2022/10/24/media/pakistan-arshad-sharif-journalist-killed-kenya-lgs-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-24 15:15:31+00:00

Arshad Sharif, a prominent Pakistani journalist who fled the country after he was charged with sedition, has died in Kenya after he was shot by police responding to reports of a stolen vehicle, authorities said.

## New UK prime minister faces huge economic challenges as well as messy politics
 - [https://www.cnn.com/2022/10/24/economy/uk-economy-prime-minister/index.html](https://www.cnn.com/2022/10/24/economy/uk-economy-prime-minister/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-24 12:06:32+00:00

Britain's third prime minister in seven weeks will face the huge challenge of projecting stability after a period of historic political and financial market chaos. But their other task — shepherding the country through a recession — is poised to be just as daunting.

## The economy may be in better shape than you think — for now
 - [https://www.cnn.com/2022/10/23/investing/stocks-week-ahead/index.html](https://www.cnn.com/2022/10/23/investing/stocks-week-ahead/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2022-10-24 11:40:37+00:00

The housing market is rapidly losing steam. Interest rates continue to rise. The stock market remains volatile. And inflation continues to be a major problem for people trying to pay their bills.


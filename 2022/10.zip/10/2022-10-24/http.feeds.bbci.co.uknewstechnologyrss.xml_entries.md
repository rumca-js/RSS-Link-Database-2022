# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## The ships full of gas waiting off Europe’s coast
 - [https://www.bbc.co.uk/news/business-63331709?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63331709?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-10-24 23:25:00+00:00

In the middle of an energy crisis, giant ships full of liquefied natural gas are waiting off Europe's coast.

## US charges alleged Chinese spies in telecoms probe case
 - [https://www.bbc.co.uk/news/world-us-canada-63378817?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63378817?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2022-10-24 19:04:52+00:00

US officials believe China tried to obstruct an investigation, steal technology and intimidate dissidents.


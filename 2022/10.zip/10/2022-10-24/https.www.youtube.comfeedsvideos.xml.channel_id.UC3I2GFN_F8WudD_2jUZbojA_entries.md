# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Fin Del Mundo - El Incendio (Live on KEXP)
 - [https://www.youtube.com/watch?v=82VHgyqKoPE](https://www.youtube.com/watch?v=82VHgyqKoPE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-25 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Fin del Mundo performing “El Incendio” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Julieta Heredia - Guitar
Julieta Limia - Drums
Lucía Masnatta - Guitar / Vocals
Yanina Silva - Bass

Live Sound Engineer: Pablo Leal 
Sound Mix: Nicolás Aimo 
Assistants: Mariano Esain, Matías Figueredo, Martín Rulli, Jorge Ignacio Correa, Mauricio Godoy, Sebastián Ayala, Diego Fraga, Fernando Figueroa

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/FinDelMundo
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Fin del Mundo - Cuando Todo Termine (Live on KEXP)
 - [https://www.youtube.com/watch?v=GRPDlEP-ykc](https://www.youtube.com/watch?v=GRPDlEP-ykc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-25 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Fin del Mundo performing “Cuando Todo Termine” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Julieta Heredia - Guitar
Julieta Limia - Drums
Lucía Masnatta - Guitar / Vocals
Yanina Silva - Bass

Live Sound Engineer: Pablo Leal 
Sound Mix: Nicolás Aimo 
Assistants: Mariano Esain, Matías Figueredo, Martín Rulli, Jorge Ignacio Correa, Mauricio Godoy, Sebastián Ayala, Diego Fraga, Fernando Figueroa

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/FinDelMundo
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Fin del Mundo - El Fin del Mundo (Live on KEXP)
 - [https://www.youtube.com/watch?v=MW8McEz42iQ](https://www.youtube.com/watch?v=MW8McEz42iQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-25 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Fin del Mundo performing “El Fin del Mundo” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Julieta Heredia - Guitar
Julieta Limia - Drums
Lucía Masnatta - Guitar / Vocals
Yanina Silva - Bass

Live Sound Engineer: Pablo Leal 
Sound Mix: Nicolás Aimo 
Assistants: Mariano Esain, Matías Figueredo, Martín Rulli, Jorge Ignacio Correa, Mauricio Godoy, Sebastián Ayala, Diego Fraga, Fernando Figueroa

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/FinDelMundo
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Fin del Mundo - El Próximo Verano (Live on KEXP)
 - [https://www.youtube.com/watch?v=v0Wy625gKts](https://www.youtube.com/watch?v=v0Wy625gKts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-25 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Fin del Mundo performing “El Próximo Verano” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Julieta Heredia - Guitar
Julieta Limia - Drums
Lucía Masnatta - Guitar / Vocals
Yanina Silva - Bass

Live Sound Engineer: Pablo Leal 
Sound Mix: Nicolás Aimo 
Assistants: Mariano Esain, Matías Figueredo, Martín Rulli, Jorge Ignacio Correa, Mauricio Godoy, Sebastián Ayala, Diego Fraga, Fernando Figueroa

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/FinDelMundo
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Fin del Mundo - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=EpXIt_7uso8](https://www.youtube.com/watch?v=EpXIt_7uso8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-25 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Fin del Mundo performing live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Songs:
La noche
El próximo verano
Cuando todo termine
El fin del mundo
El incendio

Julieta Heredia - Guitar
Julieta Limia - Drums
Lucía Masnatta - Guitar / Vocals
Yanina Silva - Bass

Live Sound Engineer: Pablo Leal 
Sound Mix: Nicolás Aimo 
Assistants: Mariano Esain, Matías Figueredo, Martín Rulli, Jorge Ignacio Correa, Mauricio Godoy, Sebastián Ayala, Diego Fraga, Fernando Figueroa

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Host: Cheryl Waters
Interpretar: Eugenia Segovia
Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/FinDelMundo
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Fin del Mundo - La Noche (Live on KEXP)
 - [https://www.youtube.com/watch?v=zB2ZtvW2iLs](https://www.youtube.com/watch?v=zB2ZtvW2iLs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-25 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Fin del Mundo performing “SONG” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 22, 2022.

Julieta Heredia - Guitar
Julieta Limia - Drums
Lucía Masnatta - Guitar / Vocals
Yanina Silva - Bass

Live Sound Engineer: Pablo Leal 
Sound Mix: Nicolás Aimo 
Assistants: Mariano Esain, Matías Figueredo, Martín Rulli, Jorge Ignacio Correa, Mauricio Godoy, Sebastián Ayala, Diego Fraga, Fernando Figueroa

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/FinDelMundo
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Riel - 1990 (Live on KEXP)
 - [https://www.youtube.com/watch?v=jn4gtr5SN1Y](https://www.youtube.com/watch?v=jn4gtr5SN1Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-24 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Riel performing “1990” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 21, 2022.

Mora Riel - Guitar / Vocals
Germán Loretti - Drums
Estanislao López - Bass
Federico Stuart - Guitar

Session Mix: Estanislao López
Stage Assistant: Santiago Rocca

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/losriel
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Riel - BB (Live on KEXP)
 - [https://www.youtube.com/watch?v=-9mCaxd0ov0](https://www.youtube.com/watch?v=-9mCaxd0ov0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-24 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Riel performing “BB” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 21, 2022.

Mora Riel - Guitar / Vocals
Germán Loretti - Drums
Estanislao López - Bass
Federico Stuart - Guitar

Session Mix: Estanislao López
Stage Assistant: Santiago Rocca

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/losriel
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Riel - Blanco y Negro (Live on KEXP)
 - [https://www.youtube.com/watch?v=tmWLNUMv1Ro](https://www.youtube.com/watch?v=tmWLNUMv1Ro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-24 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Riel performing “Blanco y Negro” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 21, 2022.

Mora Riel - Guitar / Vocals
Germán Loretti - Drums
Estanislao López - Bass
Federico Stuart - Guitar

Session Mix: Estanislao López
Stage Assistant: Santiago Rocca

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/losriel
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Riel - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=I-FLnugFMmY](https://www.youtube.com/watch?v=I-FLnugFMmY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-24 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Riel performing live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 21, 2022.

Songs:
Más Allá del Mar
1990
Tkm
Blanco & Negro
Bb

Mora Riel - Guitar / Vocals
Germán Loretti - Drums
Estanislao López - Bass
Federico Stuart - Guitar

Session Mix: Estanislao López
Stage Assistant: Santiago Rocca

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Host: Cheryl Waters
Interpretar: Eugenia Segovia
Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/losriel
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Riel - Más Allá del Mar (Live on KEXP)
 - [https://www.youtube.com/watch?v=fCuzovUpoOc](https://www.youtube.com/watch?v=fCuzovUpoOc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-24 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Riel performing “Más Allá del Mar” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 21, 2022.

Mora Riel - Guitar / Vocals
Germán Loretti - Drums
Estanislao López - Bass
Federico Stuart - Guitar

Session Mix: Estanislao López
Stage Assistant: Santiago Rocca

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/losriel
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org

## Riel - TKM (Live on KEXP)
 - [https://www.youtube.com/watch?v=0M5Qlpb1KKo](https://www.youtube.com/watch?v=0M5Qlpb1KKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2022-10-24 00:00:00+00:00

http://KEXP.ORG and the Ministry of Culture of Argentina present KEXP live from Argentina with Riel performing “TKM” live at the Kirchner Cultural Center in Buenos Aires, Argentina. Recorded September 21, 2022.

Mora Riel - Guitar / Vocals
Germán Loretti - Drums
Estanislao López - Bass
Federico Stuart - Guitar

Session Mix: Estanislao López
Stage Assistant: Santiago Rocca

-----------------
KEXP live from Argentina is a partnership with the Argentine Ministry of Culture, MICA, and the Kirchner Cultural Center.

Realization, technical production: Centro Cultural Kirchner and KEXP

Sound Engineer: Pablo Nelken
Audio Mastering: Matt Ogaz
Videographers: Jim Beckmann, Sebastián Cáceres, Carlos Cruz & Alaia D’Alessandro
Live Director: Diego Laber
Editor: Scott Holpainen

Art: Lucila Rojo & team (stage design and art)
Lighting: Omar Posematto
Production Assistant: Gonzalo Vazquez
Media Fixer: Melissa Restrepo
Production and communication at Dirección Nacional de Integración Federal y Cooperación Internacional (Ministerio de Cultura de Argentina): Viviana Luna, Paloma Moccia, Pablo Murillo, Marcos Ribas, Lucia Soberal, Luciana Malavolta, Mariana Leder Kremer Hernández

Ministerio de Cultura de Argentina:
Tristán Bauer - Ministro de Cultura de la Nación Argentina
Lucrecia Cardoso - Secretaria de Desarrollo Cultural
Ariela Peretti - Directora Nacional de Integración Federal y Cooperación Internacional

https://linktr.ee/losriel
https://www.argentina.gob.ar/cultura
https://mica.gob.ar/inicio
https://www.cck.gob.ar
http://kexp.org


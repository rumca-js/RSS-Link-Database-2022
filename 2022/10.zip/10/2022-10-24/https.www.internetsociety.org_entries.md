## The EU's Proposed Cyber Resilience Act Will Damage the Open Source Ecosystem - Internet Society
 - [https://www.internetsociety.org/blog/2022/10/the-eus-proposed-cyber-resilience-act-will-damage-the-open-source-ecosystem/](https://www.internetsociety.org/blog/2022/10/the-eus-proposed-cyber-resilience-act-will-damage-the-open-source-ecosystem/)
 - RSS feed: https://www.internetsociety.org
 - date published: 2022-10-24 19:03:22+00:00

The EU's Proposed Cyber Resilience Act Will Damage the Open Source Ecosystem - Internet Society


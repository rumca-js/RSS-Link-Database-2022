# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The sand doodler who conquered her Somali Islamic critics
 - [https://www.bbc.co.uk/news/world-africa-63217445?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-63217445?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 23:47:29+00:00

Nujuum Hashi has overcome traditional prejudice to become a respected artist in Somalia.

## The Papers: 'Here comes the Sunak' and 'We must unite or die'
 - [https://www.bbc.co.uk/news/blogs-the-papers-63381455?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-63381455?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 23:36:30+00:00

Tuesday's front pages all focus on Rishi Sunak becoming the UK's third prime minister this year.

## Russia accused of sabotaging Ukraine water pipe to Mykolaiv
 - [https://www.bbc.co.uk/digihub/politics-63092858?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/digihub/politics-63092858?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 23:32:43+00:00

A BBC investigation finds evidence that Russian forces deliberately destroyed a pipeline to Mykolaiv.

## What is a ‘dirty bomb’ and why does Russia claim Ukraine might use one?
 - [https://www.bbc.co.uk/news/world-63373637?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-63373637?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 23:29:08+00:00

Russia’s defence minister has made claims that Ukraine could explode a 'dirty bomb'.

## Lola: France's far right adopts murdered schoolgirl
 - [https://www.bbc.co.uk/news/world-europe-63373494?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63373494?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 23:21:07+00:00

The alleged rape and murder of 12-year-old Lola by an illegal migrant has inflamed French politics.

## West Ham 2-0 Bournemouth: Gary O'Neil furious as VAR decisions go against Cherries
 - [https://www.bbc.co.uk/sport/football/63381825?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63381825?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 23:05:50+00:00

Bournemouth caretaker boss Gary O'Neil says video assistant referee decisions are "getting ridiculous" after his side lose 2-0 at West Ham.

## Energy crisis pushing people onto prepayment meters, says Uswitch
 - [https://www.bbc.co.uk/news/business-63378460?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63378460?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 23:02:45+00:00

Uswitch says prepayment meter users are more likely to be vulnerable and at risk of running out of credit.

## Fernando Alonso: Alpine driver questions Formula 1 direction after US GP penalty
 - [https://www.bbc.co.uk/sport/formula1/63381586?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/63381586?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 22:09:44+00:00

Fernando Alonso questions Formula 1's direction before the appeal against a penalty that left him out of the points at the United States Grand Prix.

## Poet laureate Simon Armitage reads the BBC's centenary poem
 - [https://www.bbc.co.uk/news/entertainment-arts-63381775?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63381775?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 21:56:51+00:00

Simon Armitage’s poem Transmission Report celebrates 100 years of the BBC.

## US crime: Is America seeing a surge in violence?
 - [https://www.bbc.co.uk/news/57581270?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/57581270?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 21:55:23+00:00

Law and order promises to be a key talking point in the US midterms. We look at the numbers.

## Leslie Jordan: Will and Grace star dies aged 67
 - [https://www.bbc.co.uk/news/entertainment-arts-63381485?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63381485?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 21:29:20+00:00

US media reported the actor was killed after being involved in a car crash on Monday.

## West Ham 2-0 Bournemouth: Kurt Zouma scores controversial goal as Hammers beat Cherries
 - [https://www.bbc.co.uk/sport/football/63280716?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63280716?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 21:11:51+00:00

West Ham move up seven places to 10th in the Premier League table as Kurt Zouma's controversial goal helps them beat Bournemouth.

## Rishi Sunak: World leaders welcome next UK prime minister
 - [https://www.bbc.co.uk/news/uk-63378673?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63378673?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 21:03:50+00:00

Leaders and commentators around the world welcomed Mr Sunak as the UK's next prime minister.

## Rugby League World Cup: Tonga 'sensational' try ruled out against Wales
 - [https://www.bbc.co.uk/sport/av/rugby-league/63380983?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/rugby-league/63380983?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 20:42:38+00:00

Watch the moment Tonga produce a sensational piece of play against Wales only for video referee to rule the try out at the Rugby League World Cup.

## Akshata Murty: Tech heiress and Rishi Sunak's wife
 - [https://www.bbc.co.uk/news/uk-politics-63371276?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63371276?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 20:34:23+00:00

The daughter of an Indian billionaire, she has previously come under the spotlight over her tax affairs.

## Rugby League World Cup: Tonga 32-6 Wales - Tonga cruise to victory after early scare
 - [https://www.bbc.co.uk/sport/rugby-league/63378130?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-league/63378130?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 20:25:44+00:00

Tonga put one foot in the Rugby League World Cup quarter-finals but are made to work hard before beating a gutsy Wales side 32-6.

## Rishi Sunak: Your questions answered
 - [https://www.bbc.co.uk/news/uk-politics-63380804?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63380804?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 20:15:10+00:00

The BBC's Ione Wells answers your questions on the UK's next prime minister.

## Is the Conservative Party ready to unite behind Rishi Sunak?
 - [https://www.bbc.co.uk/news/uk-politics-63371272?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63371272?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 18:20:44+00:00

Will Tory MPs' enthusiasm for their new leader last when his government confronts tough problems?

## Lady Leshurr assaulted ex-girlfriend, court hears
 - [https://www.bbc.co.uk/news/uk-england-london-63379069?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-63379069?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 18:14:45+00:00

Two women were taken to hospital after reports of a fight in east London on Saturday.

## Aston Villa: Unai Emery prime target to succeed Steven Gerrard as head coach
 - [https://www.bbc.co.uk/sport/football/63379963?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63379963?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 18:07:12+00:00

Villarreal's former Arsenal manager Unai Emery emerges as Aston Villa's prime target to succeed the sacked Steven Gerrard.

## St Louis: Three dead, six injured after school shooting
 - [https://www.bbc.co.uk/news/world-us-canada-63375659?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63375659?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 18:04:39+00:00

Police "quickly stopped" a gunman in his 20s who entered a Missouri public school on Monday morning.

## Rishi Sunak: 'Does he really drive a Kia?' - Inside Indian family WhatsApp groups
 - [https://www.bbc.co.uk/news/uk-politics-63378352?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63378352?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 17:29:32+00:00

Asian family WhatsApp groups often buzz with blessings and useless facts. What about when Sunak was named as next PM?

## Murdered student's mum to meet killer in prison
 - [https://www.bbc.co.uk/news/uk-england-humber-63374090?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-humber-63374090?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 17:13:50+00:00

Lisa Squire says Pawel Relowicz has agreed to meet her in prison.

## Rishi Sunak: Another UK prime minister... the whirlwind day in 58 seconds
 - [https://www.bbc.co.uk/news/uk-63379215?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63379215?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 16:54:13+00:00

Rishi Sunak will be the UK's next prime minister after winning the Conservative Party leadership contest.

## Rugby League World Cup: Five scintillating tries from this weekend
 - [https://www.bbc.co.uk/sport/av/rugby-league/63368617?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/rugby-league/63368617?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 16:24:50+00:00

Watch the five best tries from this weekend's action at the Rugby League World Cup, featuring Dallin Watene-Zelezniak's hat-trick try for New Zealand.

## Krasovsky: Russia bans 'burn Ukrainian kids' TV presenter
 - [https://www.bbc.co.uk/news/world-europe-63378613?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63378613?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 16:21:14+00:00

Russian state TV suspends a famous presenter - but its anti-Ukrainian rhetoric continues.

## Tornado damages zoo and properties in Hampshire
 - [https://www.bbc.co.uk/news/uk-england-hampshire-63376546?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-hampshire-63376546?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 16:08:59+00:00

Residents clear up after a tornado that hit parts of Hampshire including Marwell Zoo.

## Ukraine war: Russian forces preparing to defend Kherson, says Ukrainian spy chief
 - [https://www.bbc.co.uk/news/world-europe-63377946?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63377946?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 16:08:10+00:00

Ukraine had suggested some Russian units were leaving Kherson, a city that fell early in the war.

## Ukraine war: 'NI should prepare for surge in refugees'
 - [https://www.bbc.co.uk/news/uk-northern-ireland-63370511?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-63370511?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 16:01:38+00:00

The Hope for Ukraine group says more people could come to NI as fighting intensifies in Ukraine.

## Lucy Letby trial: Nurse thought 'not again' over baby collapse
 - [https://www.bbc.co.uk/news/uk-england-merseyside-63378514?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-63378514?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 15:36:58+00:00

A nurse thought "not again" when a baby suddenly collapsed in hospital, the trial of Lucy Letby hears.

## Rishi Sunak makes first public address since winning Tory leadership contest
 - [https://www.bbc.co.uk/news/uk-politics-63376995?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63376995?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 15:30:32+00:00

The incoming prime minister gives a statement at the Conservative party headquarters in London.

## Rishi Sunak: The most urgent problems facing the new prime minister
 - [https://www.bbc.co.uk/news/uk-63373258?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63373258?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 15:28:24+00:00

Rishi Sunak, the fifth Conservative prime minister in seven years, inherits many pressing challenges.

## Tributes paid to radio presenter who died on air
 - [https://www.bbc.co.uk/news/uk-england-suffolk-63377458?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-suffolk-63377458?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 15:11:22+00:00

Tim Gough, 55, dies from a suspected heart attack while broadcasting from his home in Suffolk.

## Shaun Murphy: Ex-world champion opens up on reasons for "life-changing" stomach surgery
 - [https://www.bbc.co.uk/sport/snooker/63373974?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/snooker/63373974?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 15:02:26+00:00

Shaun Murphy says reaching "the bottom of my mental health" convinced him to brave "life-changing" stomach surgery.

## NFL: Aaron Jones, Breece Hall, Duron Harmon in plays of the week
 - [https://www.bbc.co.uk/sport/av/american-football/63378240?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/american-football/63378240?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 14:14:59+00:00

A stunning catch by Green Bay Packers' Aaron Jones and scintillating run by the New York Jets' Breece Hall feature in NFL plays of the week.

## First-time buyers hit by drop in mortgage deals
 - [https://www.bbc.co.uk/news/business-63376031?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63376031?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:58:00+00:00

Those with smaller deposits are likely to have less choice from lenders, figures show.

## Rishi Sunak: What might the new Tory leader do as PM?
 - [https://www.bbc.co.uk/news/uk-politics-63374316?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63374316?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:52:02+00:00

The former chancellor has not made any new pledges during the four-day contest to replace Liz Truss.

## Michael Carrick: Middlesbrough name former Manchester United midfielder as boss
 - [https://www.bbc.co.uk/sport/football/63297825?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63297825?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:47:48+00:00

Middlesbrough appoint ex-Manchester United and England midfielder Michael Carrick as their head coach.

## Myanmar crisis: 50 killed in air raid on Kachin rebels, reports say
 - [https://www.bbc.co.uk/news/world-asia-63370732?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63370732?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:34:45+00:00

Villagers said there was no warning before the air force dropped bombs on a concert in Kachin state.

## 'The third prime minister in a matter of seven weeks'
 - [https://www.bbc.co.uk/news/uk-politics-63372838?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63372838?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:32:19+00:00

The BBC's political editor Chris Mason reports on the Tory leadership announcement.

## T20 World Cup: Heavy rain forces draw between Zimbabwe and South Africa
 - [https://www.bbc.co.uk/sport/av/cricket/63377012?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/63377012?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:30:48+00:00

Watch the T20 World Cup match between South Africa and Zimbabwe come to a premature end as players lose their footing amid torrential rain.

## Madame Tussauds: Protesters throw cake on King Charles waxwork
 - [https://www.bbc.co.uk/news/entertainment-arts-63374080?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63374080?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:28:58+00:00

Activists throw cake into the face of King Charles's waxwork at London's Madame Tussauds.

## Martine Croxall: BBC News presenter being investigated over impartiality
 - [https://www.bbc.co.uk/news/entertainment-arts-63376310?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63376310?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:26:28+00:00

It follows complaints on social media about comments made by Martine Croxall on Sunday's newspaper review.

## Rishi Sunak set to become first British Asian PM as Penny Mordaunt bows out
 - [https://www.bbc.co.uk/news/uk-politics-63375281?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63375281?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:26:14+00:00

Almost 200 Tory MPs publicly backed the ex-chancellor, who was elected party leader without a vote.

## Rishi Sunak announced as next UK prime minister
 - [https://www.bbc.co.uk/news/uk-politics-63373382?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63373382?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:17:36+00:00

Rishi Sunak will be the next prime minister after no other rivals came forward to challenge him.

## Rishi Sunak: What will new prime minister mean for Scotland?
 - [https://www.bbc.co.uk/news/uk-scotland-63371904?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-63371904?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:07:16+00:00

What does the former Chancellor's appointment as Conservative leader mean for politics in Scotland?

## Rishi Sunak: A quick guide to the UK’s next prime minister
 - [https://www.bbc.co.uk/news/uk-63345272?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-63345272?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 13:03:23+00:00

Rishi Sunak lost the race to be PM - then staged a comeback. Here's what you need to know about him.

## Ilona Golabek murder: Crippen trial questions used to secure conviction
 - [https://www.bbc.co.uk/news/uk-england-lincolnshire-63351055?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lincolnshire-63351055?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 12:57:23+00:00

Kamil Ranoszek was jailed for life after questions from an infamous 1910 trial were used in court.

## University staff latest to agree to go on strike
 - [https://www.bbc.co.uk/news/education-63351675?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-63351675?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 12:46:42+00:00

Lecturers, librarians and admin staff across the UK vote to take action over pay and pensions.

## T20 World Cup: South Africa-Zimbabwe rained off in strange fashion
 - [https://www.bbc.co.uk/sport/cricket/63371503?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/63371503?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 12:45:35+00:00

South Africa and Zimbabwe's opening Super 12s game at the T20 World Cup is finally abandoned because of rain in a strange conclusion.

## Owen Farrell: Saracens fly-half one of three withdrawals from England training camp in Jersey
 - [https://www.bbc.co.uk/sport/rugby-union/63375888?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63375888?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 12:36:34+00:00

Owen Farrell is one of three withdrawals from the England squad for their training camp in Jersey after sustaining a concussion.

## Women's Super League: Chelsea's Harder leads WSL best goals of weekend
 - [https://www.bbc.co.uk/sport/av/football/63372867?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/63372867?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 12:33:56+00:00

Watch the best goals from the weekend's Women's Super League including Chelsea's Pernille Harder and Manchester City's Khadija Shaw.

## Ukraine war: Russian spy chief blames West for nuclear tension
 - [https://www.bbc.co.uk/news/world-europe-63373728?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63373728?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 12:06:16+00:00

The head of Russia's foreign intelligence service falsely accuses the West of nuclear war threats.

## Rugby World Cup: England's Rosie Galligan on setbacks and comebacks
 - [https://www.bbc.co.uk/sport/rugby-union/63364337?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/63364337?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 11:36:50+00:00

England second row Rosie Galligan, who spent three years out of Test rugby through injury, illness and lockdowns, tells Rugby Union Weekly she has returned a better player.

## Doctor Who: Critics praise Jodie Whittaker's swansong
 - [https://www.bbc.co.uk/news/entertainment-arts-63346244?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63346244?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 11:36:17+00:00

Reviews of Sunday's finale were broadly positive, although some said too much was packed into the episode.

## Cunning cheat or unplayable genius? Inside Maradona's World Cup glory
 - [https://www.bbc.co.uk/sport/football/63291332?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63291332?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 11:29:27+00:00

As part of BBC Sport's World Cup icons series, Guillem Balague tells the inside story of how Diego Maradona led Argentina to glory in 1986.

## Arshad Sharif killing: Prominent Pakistani journalist shot dead in Kenya
 - [https://www.bbc.co.uk/news/world-africa-63372440?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-63372440?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 11:20:32+00:00

Arhsad Sharif was killed by Kenyan police officers in what they say was a case of mistaken identity.

## Aston Villa: Sporting Lisbon boss Ruben Amorim in contention for manager's job
 - [https://www.bbc.co.uk/sport/football/63370422?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/63370422?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 11:02:56+00:00

Sporting Lisbon coach Ruben Amorim is one of the main contenders to succeed Steven Gerrard as Aston Villa manager.

## US midterms: Here's what you need to know
 - [https://www.bbc.co.uk/news/world-us-canada-62807061?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-62807061?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 10:57:45+00:00

Get up to speed with everything you need to know this election season.

## Protesters throw pies on King Charles waxwork
 - [https://www.bbc.co.uk/news/articles/c5149gjwnl7o?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/c5149gjwnl7o?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 10:50:38+00:00

Activists throw custard pies into the face of King Charles's waxwork at London's Madame Tussauds.

## NHS ambulance workers begin to vote on strike in pay dispute
 - [https://www.bbc.co.uk/news/uk-england-63371669?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-63371669?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 09:59:51+00:00

The GMB union says the "biggest ambulance strike for 30 years" could be staged before Christmas.

## UK set to be sick man of Europe, says Tory backer
 - [https://www.bbc.co.uk/news/business-63371743?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63371743?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 09:08:13+00:00

Guy Hands, a leading investor, says the UK faces higher taxes, lower benefits and a possible IMF bailout.

## Korean Air crash: Plane overruns runway in bad weather
 - [https://www.bbc.co.uk/news/world-asia-63372564?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-63372564?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 09:03:47+00:00

A Korean Air plane overran on the runway while landing at Mactan-Cebu International Airport in the Philippines.

## Unholy: Kim Petras 'grateful' for hit song with Sam Smith
 - [https://www.bbc.co.uk/news/newsbeat-63335819?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-63335819?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 09:01:04+00:00

The German singer tells BBC Newsbeat her chart success with Sam Smith has been a dream come true.

## What we just learned about China's economy
 - [https://www.bbc.co.uk/news/business-63296229?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63296229?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 07:37:55+00:00

Hong Kong's benchmark Hang Seng stock index fell more than 6% on investor concerns over Xi Jinping's policies.

## Escaped Essex serpent gives woman shock in bedroom
 - [https://www.bbc.co.uk/news/uk-england-essex-63370819?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-63370819?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 07:22:36+00:00

After the woman flees, an RSPCA officer has to search the room again to find the reptile hiding.

## Rishi Sunak ahead of Penny Mordaunt as PM race enters final hours
 - [https://www.bbc.co.uk/news/uk-politics-63370359?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63370359?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 06:56:06+00:00

Attention now turns to whether Penny Mordaunt has enough backers by the Monday afternoon deadline.

## Sports Direct-owner Frasers lifts Asos and Hugo Boss stakes
 - [https://www.bbc.co.uk/news/business-63370575?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63370575?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 06:50:38+00:00

Frasers Group is now the fourth-largest shareholder in Asos, which owns the Topshop brand.

## Health of nation study calls on millions to sign up
 - [https://www.bbc.co.uk/news/health-63331805?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-63331805?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 06:38:34+00:00

The aim is to uncover better ways to prevent, spot and treat diseases like dementia and cancer.

## Should disposable vapes be banned?
 - [https://www.bbc.co.uk/news/science-environment-63037553?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-63037553?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 06:38:18+00:00

Campaigners say the popular single-use vapes are an environmental nightmare.

## Pound gains as Rishi Sunak seen on track to become PM
 - [https://www.bbc.co.uk/news/business-63367738?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63367738?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 05:54:11+00:00

Sterling initially rose against the dollar after Boris Johnson dropped out of the leadership contest.

## NFL week seven review: Tom Brady & Aaron Rodgers both lose and Chiefs beat 49ers
 - [https://www.bbc.co.uk/sport/american-football/63369025?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/american-football/63369025?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 05:32:31+00:00

Legendary quarterbacks Aaron Rodgers and Tom Brady both lose again in their worst combined start to an NFL season.

## Newmarket: King Charles to sell 14 of Queen's horses
 - [https://www.bbc.co.uk/news/uk-england-berkshire-63350756?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-berkshire-63350756?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 05:09:36+00:00

The King is selling 14 of her late Majesty's racehorses at Newmarket auction house Tattersalls.

## US midterms predictions: The top US Senate races to watch
 - [https://www.bbc.co.uk/news/world-us-canada-63291205?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-63291205?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 03:33:30+00:00

In a Senate split 50-50 between two parties, every race counts. Here are the six closest ones.

## Ukraine war: Kyiv denounces Russia's 'dirty bomb' claims
 - [https://www.bbc.co.uk/news/world-europe-63369175?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-63369175?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 00:57:28+00:00

Kyiv says Russia may be planning provocations with conventional explosives with radioactive material.

## 'When I couldn't fix George, I climbed a mountain'
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-63144810?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leicestershire-63144810?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 00:48:38+00:00

A father carried his son's weight up Mount Kilimanjaro to raise awareness of meningitis.

## Anthony Ogogo: 'When I started boxing I was an angry little boy'
 - [https://www.bbc.co.uk/news/uk-england-suffolk-63265882?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-suffolk-63265882?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 00:47:58+00:00

Former boxer Anthony Ogogo shares his story from the UK's most easterly point to Olympic success.

## The political guard is changing again
 - [https://www.bbc.co.uk/news/uk-politics-63369200?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-63369200?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 00:05:40+00:00

September's loser appears on the verge of becoming October's prime minister, political editor Chris Mason writes.

## The papers: 'Boris quits race' and 'Sunak set for power'
 - [https://www.bbc.co.uk/news/blogs-the-papers-63368993?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-63368993?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2022-10-24 00:03:57+00:00

Boris Johnson bows out of the Tory leadership race as Rishi Sunak takes the lead, Monday's papers say.


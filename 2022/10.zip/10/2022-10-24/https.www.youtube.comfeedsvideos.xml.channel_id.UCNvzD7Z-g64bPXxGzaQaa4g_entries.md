# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Modern Warfare 2 - Before You Buy
 - [https://www.youtube.com/watch?v=6WrNERKerbc](https://www.youtube.com/watch?v=6WrNERKerbc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-10-25 00:00:00+00:00

Call of Duty Modern Warfare 2 (PC, PS5, PS4, Xbox Series X/S/One) continues the adventure of characters revamped in 2019. How is the campaign? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼▼

Buy MW2: https://amzn.to/3WdofMC


Watch more 'Before You Buy': https://bit.ly/2kfdxI6

## Top 10 NEW Games of November 2022
 - [https://www.youtube.com/watch?v=qW_t4PWW2xQ](https://www.youtube.com/watch?v=qW_t4PWW2xQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2022-10-24 00:00:00+00:00

Looking for something new to play on PC, PS5, PS4, Xbox Series X/S/One and Switch this November? We've got you covered with these new game releases and their release dates.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:16 The Dark Pictures Anthology: The Devil in Me 
1:45 Warhammer 40,000: Darktide 
2:51 Vail VR 
4:37 Goat Simulator 3 
5:31 Sonic Frontiers
7:11 Spider-Man: Miles Morales PC 
8:02 Pokémon Scarlet and Violet 
9:20 Evil West
10:13 Gungrave G.O.R.E.
11:20 God of War Ragnarök


#10 The Dark Pictures Anthology: The Devil in Me 

Platform : PC PS4 PS5 XSX|S Xbox One

Release Date : November 18, 2022



#9 Warhammer 40,000: Darktide 

Platform : PC

Release Date : November 30, 2022



#8 Vail VR 

Platform : PC 

Release Date : November 17, 2022



#7 Goat Simulator 3 

Platform : PC PS5 XSX|S

Release Date : November 17, 2022



#6 Sonic Frontiers

Platform : Switch PC PS4 PS5 XSX|S Xbox One

Release Date : November 8, 2022



#5 Spider-Man: Miles Morales PC 

Platform : PC 

Release Date : November 18, 2022



#4 Pokémon Scarlet and Violet 

Platform : Switch

Release Date : November 18, 2022



#3 Evil West  

Platform : PC PS4 PS5 XSX|S Xbox One 

Release Date : November 22, 2022

 

#2 Gungrave G.O.R.E. 

Platform : PC PS4 PS5 XSX|S Xbox One 

Release Date : November 22, 2022



#1 God of War Ragnarök

Platform : PS5 PS4

Release Date : November 9, 2022 



Bonus:- 

Call of Duty: Warzone 2.0 

Platform : PC PS4 PS5 Xbox One XSX|S 

Release Date : November 16, 2022


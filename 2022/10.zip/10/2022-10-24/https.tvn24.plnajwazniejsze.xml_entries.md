# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Utytułowany trener przejął drużynę Polaków
 - [https://eurosport.tvn24.pl/utytu-owany-trener-przej---klub-polak-w,1122508.html?source=rss](https://eurosport.tvn24.pl/utytu-owany-trener-przej---klub-polak-w,1122508.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 20:07:00+00:00

<img alt="Utytułowany trener przejął drużynę Polaków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-goep7x-unai-emery/alternates/LANDSCAPE_1280" />
    Aston Villa zakontraktowała nowego szkoleniowca.

## Joachim Loew jest gotowy wrócić do pracy
 - [https://eurosport.tvn24.pl/joachim-loew-jest-gotowy-wr-ci--do-pracy,1122507.html?source=rss](https://eurosport.tvn24.pl/joachim-loew-jest-gotowy-wr-ci--do-pracy,1122507.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 19:00:04+00:00

<img alt="Joachim Loew jest gotowy wrócić do pracy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-smxvrs-joachim-loew/alternates/LANDSCAPE_1280" />
    Po blisko półtorarocznej przerwie.

## Radomiak przełamał wyjazdową niemoc
 - [https://eurosport.tvn24.pl/radomiak-prze-ama--wyjazdow--niemoc,1122502.html?source=rss](https://eurosport.tvn24.pl/radomiak-prze-ama--wyjazdow--niemoc,1122502.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 18:06:50+00:00

<img alt="Radomiak przełamał wyjazdową niemoc" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zqouk7-radomiak-radom/alternates/LANDSCAPE_1280" />
    Cenna wygrana z Piastem.

## Węgrzy mają dość Orbana i drożyzny. "Tam się dzieje cywilizacyjna klęska"
 - [https://fakty.tvn24.pl/w-grzy-maj--do---orbana-i-dro-yzny---tam-si--dzieje-cywilizacyjna-kl-ska-,1122490.html?source=rss](https://fakty.tvn24.pl/w-grzy-maj--do---orbana-i-dro-yzny---tam-si--dzieje-cywilizacyjna-kl-ska-,1122490.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 17:06:00+00:00

<img alt="Węgrzy mają dość Orbana i drożyzny. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-92lfak-protesty-na-wegrzech-w-budapeszcie-6178144/alternates/LANDSCAPE_1280" />
    Na Węgrzech wybuchają masowe demonstracje przeciwko rządowi.

## Piłkarz Bayernu wzburzony kontrolą. Celników porównał do klaunów
 - [https://eurosport.tvn24.pl/pi-karz-bayernu-wzburzony-kontrol---celnik-w-por-wna--do-klaun-w,1122477.html?source=rss](https://eurosport.tvn24.pl/pi-karz-bayernu-wzburzony-kontrol---celnik-w-por-wna--do-klaun-w,1122477.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 16:46:00+00:00

<img alt="Piłkarz Bayernu wzburzony kontrolą. Celników porównał do klaunów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7rmyve-bouna-sarr-i-sadio-mane/alternates/LANDSCAPE_1280" />
    Twierdzi, że został potraktowany jak diler.

## Samochód wpadł na torowisko w centrum Warszawy
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-wypadek-w-alejach-jerozolimskich-na-wysokosci-na-placu-starynkiewicza-nie-jezdza-tramwaje-6177821?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-wypadek-w-alejach-jerozolimskich-na-wysokosci-na-placu-starynkiewicza-nie-jezdza-tramwaje-6177821?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 16:04:22+00:00

<img alt="Samochód wpadł na torowisko w centrum Warszawy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-xnbp7s-zderzenie-na-placu-starynkiewicza-6177863/alternates/LANDSCAPE_1280" />
    Na miejscu ogromne utrudnienia.

## Lider Polaków zaskoczył planami wobec reprezentacji. "To jest jakieś nieporozumienie"
 - [https://eurosport.tvn24.pl/ponitka-zaskoczy--planami-wobec-reprezentacji---to-jest-jakie--nieporozumienie-,1122462.html?source=rss](https://eurosport.tvn24.pl/ponitka-zaskoczy--planami-wobec-reprezentacji---to-jest-jakie--nieporozumienie-,1122462.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 16:01:00+00:00

<img alt="Lider Polaków zaskoczył planami wobec reprezentacji. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-scr7ck-mateusz-ponitka-jest-liderem-bialo-czerwonych/alternates/LANDSCAPE_1280" />
     - Funkcja kapitana to z jednej strony wielkie wyróżnienie, ale i konkretne obowiązki - komentuje słowa Ponitki były kadrowicz Maciej Zieliński w rozmowie z eurosport.pl.

## Hurkacz rozpoczął turniej od zwycięstwa
 - [https://eurosport.tvn24.pl/hurkacz-od-zwyci-stwa-rozpocz---turniej-w-wiedniu--polak-i-brazylijczyk-awansowali-w-deblu,1122457.html?source=rss](https://eurosport.tvn24.pl/hurkacz-od-zwyci-stwa-rozpocz---turniej-w-wiedniu--polak-i-brazylijczyk-awansowali-w-deblu,1122457.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 14:12:00+00:00

<img alt="Hurkacz rozpoczął turniej od zwycięstwa " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qskzm9-hubert-hurkacz/alternates/LANDSCAPE_1280" />
    Awansował w deblu.

## Dwunastu kandydatów na burmistrza, najwięcej głosów na trenera
 - [https://eurosport.tvn24.pl/dwunastu-kandydat-w-na-burmistrza--najwi-cej-g-os-w-na-trenera---to-dopiero-pierwsza-po-owa-,1122455.html?source=rss](https://eurosport.tvn24.pl/dwunastu-kandydat-w-na-burmistrza--najwi-cej-g-os-w-na-trenera---to-dopiero-pierwsza-po-owa-,1122455.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 14:03:00+00:00

<img alt="Dwunastu kandydatów na burmistrza, najwięcej głosów na trenera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z512kg-maciej-bartoszek/alternates/LANDSCAPE_1280" />
    - Zarządzanie miastem jest podobne do sportu - mówi eurosport.pl 45-letni szkoleniowiec. Przekonuje, że doświadczenia, które wyniósł z futbolu, mogą mu tylko pomóc.

## "Kontrakt stulecia". Francuzi ujawnili szczegóły umowy Mbappe
 - [https://eurosport.tvn24.pl/-kontrakt-stulecia---francuzi-ujawnili-szczeg--y-umowy-mbappe,1122452.html?source=rss](https://eurosport.tvn24.pl/-kontrakt-stulecia---francuzi-ujawnili-szczeg--y-umowy-mbappe,1122452.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 13:34:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-muuqqj-mbappe-zarabia-w-paryzu-krocie/alternates/LANDSCAPE_1280" />
    Nikt nie ma wątpliwości, że do pozostania w PSG przekonał Francuza nowy kontrakt.

## Lewandowski porównany do gwiazd NBA
 - [https://eurosport.tvn24.pl/lewandowski-por-wnany-do-graczy-nba---tylko--e-zamiast-mia-d-y--obr-cze--niszczy-bramki-,1122442.html?source=rss](https://eurosport.tvn24.pl/lewandowski-por-wnany-do-graczy-nba---tylko--e-zamiast-mia-d-y--obr-cze--niszczy-bramki-,1122442.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 13:04:00+00:00

<img alt="Lewandowski porównany do gwiazd NBA" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tzqvwy-lewy-strzelil-bardzo-podobnego-gola-do-tego-w-meczu-z-villarrealem/alternates/LANDSCAPE_1280" />
    "Tylko że zamiast miażdżyć obręcze, niszczy bramki".

## Wyznawca hinduizmu, zięć indyjskiego miliardera. Kim jest Rishi Sunak, kandydat na premiera Wielkiej Brytanii
 - [https://tvn24.pl/swiat/rishi-sunak-kim-jest-kandydat-na-premiera-wielkiej-brytanii-6177136?source=rss](https://tvn24.pl/swiat/rishi-sunak-kim-jest-kandydat-na-premiera-wielkiej-brytanii-6177136?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 12:04:31+00:00

<img alt="Wyznawca hinduizmu, zięć indyjskiego miliardera. Kim jest Rishi Sunak, kandydat na premiera Wielkiej Brytanii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-551uen-rishi-sunak-kandydat-na-premiera-wielkiej-brytanii-6177064/alternates/LANDSCAPE_1280" />
    42-latek jest uznawany za jednego z najbogatszych polityków na Wyspach.

## Ostatnia deska ratunku Ronaldo. United blisko ważnej decyzji
 - [https://eurosport.tvn24.pl/ostatnia-deska-ratunku-ronaldo--united-blisko-wa-nej-decyzji,1122453.html?source=rss](https://eurosport.tvn24.pl/ostatnia-deska-ratunku-ronaldo--united-blisko-wa-nej-decyzji,1122453.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 11:56:23+00:00

<img alt="Ostatnia deska ratunku Ronaldo. United blisko ważnej decyzji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x4nq2h-cristiano-ronaldo-jest-pilkarzem-manchesteru-united/alternates/LANDSCAPE_1280" />
    Pisze "The Sun".

## Jeden mecz, dwie kontuzje. Alarm w Barcelonie
 - [https://eurosport.tvn24.pl/jeden-mecz--dwie-kontuzje--alarm-w-barcelonie,1122449.html?source=rss](https://eurosport.tvn24.pl/jeden-mecz--dwie-kontuzje--alarm-w-barcelonie,1122449.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 11:44:16+00:00

<img alt="Jeden mecz, dwie kontuzje. Alarm w Barcelonie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y7kmod-na-jak-dlugo-barcelonie-wypadna-gavi-i-sergi-roberto/alternates/LANDSCAPE_1280" />
    Wysokie zwycięstwo 4:0 z Athletikiem Bilbao Barcelona okupiła bolesnymi stratami.

## Zachwycający występ Kurakowej. Najlepszy wynik polskiej łyżwiarki od blisko 25 lat
 - [https://eurosport.tvn24.pl/zachwycaj-cy-wyst-p-kurakowej--najlepszy-wynik-polskiej--y-wiarki-od-blisko-25-lat,1122438.html?source=rss](https://eurosport.tvn24.pl/zachwycaj-cy-wyst-p-kurakowej--najlepszy-wynik-polskiej--y-wiarki-od-blisko-25-lat,1122438.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 11:20:00+00:00

<img alt="Zachwycający występ Kurakowej. Najlepszy wynik polskiej łyżwiarki od blisko 25 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4pft2k-jekaterina-kurakowa-zajela-piate-miejsce-w-skate-america/alternates/LANDSCAPE_1280" />
    Ręce same składają się do oklasków.

## Czwarta w historii. Świątek wśród legend
 - [https://eurosport.tvn24.pl/czwarta-w-historii---wi-tek-w-r-d-legend,1122451.html?source=rss](https://eurosport.tvn24.pl/czwarta-w-historii---wi-tek-w-r-d-legend,1122451.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 10:58:00+00:00

<img alt="Czwarta w historii. Świątek wśród legend" src="https://tvn24.pl/najnowsze/cdn-zdjecie-twmwj6-iga-swiatek-nadal-liderka-rankingu-wta/alternates/LANDSCAPE_1280" />
    Trzydziestka Igi Świątek.

## Bolid pędził na tylnych kołach. Niebezpieczna sytuacja w Formule 1
 - [https://eurosport.tvn24.pl/bolid-p-dzi--na-tylnych-ko-ach--niebezpieczna-sytuacja-w-formule-1,1122447.html?source=rss](https://eurosport.tvn24.pl/bolid-p-dzi--na-tylnych-ko-ach--niebezpieczna-sytuacja-w-formule-1,1122447.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 09:31:00+00:00

<img alt="Bolid pędził na tylnych kołach. Niebezpieczna sytuacja w Formule 1" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o4hu4b-sport-cue-16-fhdniejpg/alternates/LANDSCAPE_1280" />
    Nie obyło się bez kary.

## Reprezentant Polski pokonał Barcelonę i obronił klubowe mistrzostwo świata
 - [https://eurosport.tvn24.pl/barcelona-pokonana--reprezentant-polski-obroni--klubowe-mistrzostwo--wiata,1122445.html?source=rss](https://eurosport.tvn24.pl/barcelona-pokonana--reprezentant-polski-obroni--klubowe-mistrzostwo--wiata,1122445.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 07:56:00+00:00

<img alt="Reprezentant Polski pokonał Barcelonę i obronił klubowe mistrzostwo świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e7gdpo-chrapkowski-ma-dobra-passe-w-magdeburgu-6176817/alternates/LANDSCAPE_1280" />
    SC Magdeburg, w którym występuje Piotr Chrapkowski, wygrał 15. edycję IHF Super Globe, imprezy uznawanej za klubowe mistrzostwa świata.

## Lewandowski zaskakuje. "Strzelanie goli nie jest moim głównym zadaniem"
 - [https://eurosport.tvn24.pl/lewandowski-zaskakuje---strzelenie-goli-nie-jest-moim-g--wnym-zdaniem-,1122440.html?source=rss](https://eurosport.tvn24.pl/lewandowski-zaskakuje---strzelenie-goli-nie-jest-moim-g--wnym-zdaniem-,1122440.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 06:54:00+00:00

<img alt="Lewandowski zaskakuje. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v93y4k-ousmane-dembele-i-robert-lewandowski/alternates/LANDSCAPE_1280" />
    Robert Lewandowski o swojej roli na boisku.

## Kolorowe skarpetki i poseł nazwany "zerem". Kulisy "matki wszystkich afer"
 - [https://tvn24.pl/go/programy,7/to-byl-temat-odcinki,888539/odcinek-2,S01E02,894610?source=rss](https://tvn24.pl/go/programy,7/to-byl-temat-odcinki,888539/odcinek-2,S01E02,894610?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 05:51:48+00:00

<img alt="Kolorowe skarpetki i poseł nazwany " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6l422y-afera-rywina-6176614/alternates/LANDSCAPE_1280" />
    Skandal, który doprowadził do powstania pierwszej w historii III RP komisji śledczej i utorował drogę do władzy dwóm nowym partiom.

## Napastnik kompletny. Imponuje nie tylko skutecznością
 - [https://eurosport.tvn24.pl/napastnik-kompletny--lewandowski-imponuje-nie-tylko-skuteczno-ci-,1122428.html?source=rss](https://eurosport.tvn24.pl/napastnik-kompletny--lewandowski-imponuje-nie-tylko-skuteczno-ci-,1122428.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 04:45:09+00:00

<img alt="Napastnik kompletny. Imponuje nie tylko skutecznością" src="https://tvn24.pl/najnowsze/cdn-zdjecie-82tlk7-robert-lewandowski-swietnie-strzela-ale-rownie-dobrze-podaje/alternates/LANDSCAPE_1280" />
    Robert Lewandowski po meczu Barcelony z Athletikiem Bilbao jest nie tylko najlepszym strzelcem rozgrywek.

## Legenda tenisa nie ma dobrych wiadomości dla rywalek Igi Świątek
 - [https://eurosport.tvn24.pl/legenda-tenisa-nie-ma-dobrych-wiadomo-ci-dla-rywalek-igi--wi-tek,1122411.html?source=rss](https://eurosport.tvn24.pl/legenda-tenisa-nie-ma-dobrych-wiadomo-ci-dla-rywalek-igi--wi-tek,1122411.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2022-10-24 04:18:05+00:00

<img alt="Legenda tenisa nie ma dobrych wiadomości dla rywalek Igi Świątek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jr8unl-martina-navratilova-i-iga-swiatek-po-finale-us-open/alternates/LANDSCAPE_1280" />
    Martina Navratilova o dominacji Polki w kobiecym tourze.


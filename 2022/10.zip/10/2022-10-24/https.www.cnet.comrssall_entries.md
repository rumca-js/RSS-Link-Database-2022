# Source:CNET, URL:https://www.cnet.com/rss/all/, language:en-US

## White House Denies Report of Elon Musk National Security Reviews     - CNET
 - [https://www.cnet.com/tech/white-house-denies-report-of-musk-national-security-reviews/#ftag=CADf328eec](https://www.cnet.com/tech/white-house-denies-report-of-musk-national-security-reviews/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 23:52:00+00:00

"Not true," the White House says.

## Engineering Students Design 'Anti-Cheating' Helmets, and They're Genius     - CNET
 - [https://www.cnet.com/culture/engineering-students-design-anti-cheating-helmets-and-theyre-genius/#ftag=CADf328eec](https://www.cnet.com/culture/engineering-students-design-anti-cheating-helmets-and-theyre-genius/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 23:51:00+00:00

A professor in the Philippines asks young engineers to craft hats that prevent peers from copying exam answers, and they deliver some amazing creations.

## Discover: 2022 Home Equity Review     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/discover-home-equity-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/discover-home-equity-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 23:48:57+00:00

This major lender offers a variety of banking services, credit cards and home equity loans, but not HELOCs.

## More People Should Watch This South Korean Horror-Thriller on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/more-people-should-watch-this-south-korean-horror-thriller-on-netflix/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/more-people-should-watch-this-south-korean-horror-thriller-on-netflix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 23:39:08+00:00

The Call is an impeccable cat-and-mouse time travel thriller with the same editor as Parasite.

## The Best Fantasy TV Shows on Netflix Right Now     - CNET
 - [https://www.cnet.com/culture/entertainment/best-fantasy-tv-shows-netflix/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/best-fantasy-tv-shows-netflix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 23:22:00+00:00

Netflix has a lot of world class fantasy.

## FTC Takes Action Against Drizly for 2020 Data Breach     - CNET
 - [https://www.cnet.com/tech/services-and-software/ftc-takes-action-against-drizly-for-2020-data-breach/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/ftc-takes-action-against-drizly-for-2020-data-breach/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 23:01:00+00:00

The alcohol delivery company agrees to tighten data security practices amid allegations it knew of security lapses two years before a hacker stole 2.5 million customers' personal information.

## New Pokemon Scarlet and Violet Trailer Focusing on Ghost Pokemon Coming Oct. 25     - CNET
 - [https://www.cnet.com/tech/gaming/new-pokemon-scarlet-and-violet-trailer-focusing-on-ghost-pokemon-coming-oct-25/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/new-pokemon-scarlet-and-violet-trailer-focusing-on-ghost-pokemon-coming-oct-25/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 22:48:13+00:00

Pokemon is offering a spooky look at the Paldea region ahead of Halloween.

## Intel CEO: Taiwan's Place in Tech Industry Is 'Precarious'     - CNET
 - [https://www.cnet.com/tech/computing/intel-ceo-taiwans-place-in-tech-industry-is-precarious/#ftag=CADf328eec](https://www.cnet.com/tech/computing/intel-ceo-taiwans-place-in-tech-industry-is-precarious/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 22:46:00+00:00

There's plenty of fretting about China trying to reclaim Taiwan. Geopolitics should help spur more chipmaking in the US and Europe, Pat Gelsinger argues.

## Early Voting in 2022: Here Are the Deadlines for Every State     - CNET
 - [https://www.cnet.com/news/politics/early-voting-in-2022-here-are-the-deadlines-for-every-state/#ftag=CADf328eec](https://www.cnet.com/news/politics/early-voting-in-2022-here-are-the-deadlines-for-every-state/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 22:15:02+00:00

Early voting for Election Day 2022 is available in most states now. Check to see when it'll end where you live.

## More People Need To Watch The Best Show on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/more-people-need-to-watch-the-best-show-on-netflix/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/more-people-need-to-watch-the-best-show-on-netflix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 22:12:00+00:00

Years later, I'm still completely obsessed with this show.

## 'Great British Baking Show': Meet a Guy Able to Rescue Even the Worst Bakes     - CNET
 - [https://www.cnet.com/culture/entertainment/great-british-baking-show-meet-a-man-able-to-rescue-even-the-worst-bakes/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/great-british-baking-show-meet-a-man-able-to-rescue-even-the-worst-bakes/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 22:05:00+00:00

Illustrator Tom Hovey's drawings are the show's delicious secret ingredient. But don't expect to see him in the tent much.

## Third Federal Savings & Loan: 2022 Home Equity Review     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/third-federal-savings-loan-home-equity-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/third-federal-savings-loan-home-equity-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 21:32:55+00:00

This lender offers home equity loans and HELOCs to those who need a long repayment period and want the option to choose a fixed rate or variable rate loan.

## 'House of the Dragon' Episode 10: Alicent and Rhaenyra's Torn Page Explained     - CNET
 - [https://www.cnet.com/culture/entertainment/house-of-the-dragon-episode-10-alicent-and-rhaenyras-torn-page-explained/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/house-of-the-dragon-episode-10-alicent-and-rhaenyras-torn-page-explained/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 21:32:48+00:00

What book did the page come from and where did we first see it?

## Anker's First 3D Printer Is Up for Preorder and It's Already Impressed Me     - CNET
 - [https://www.cnet.com/tech/computing/ankers-first-3d-printer-is-up-for-preorder-and-its-already-impressed-me/#ftag=CADf328eec](https://www.cnet.com/tech/computing/ankers-first-3d-printer-is-up-for-preorder-and-its-already-impressed-me/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 21:32:00+00:00

Fast and accurate, the $799 AnkerMake M5 offered mostly solid performance during my first two weeks with it -- but there were some quirks.

## Best Desks 2022: Standing Desks, Gaming Desks and Everything in Between     - CNET
 - [https://www.cnet.com/news/best-desks/#ftag=CADf328eec](https://www.cnet.com/news/best-desks/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 21:24:08+00:00

Working from home means you need a place to work. You might not need an office, but you will need a desk.

## Students' Wild Homemade 'Anti-Cheating' Hats Get Top Marks for Creativity     - CNET
 - [https://www.cnet.com/culture/students-wild-homemade-anti-cheating-hats-get-top-marks-for-creativity/#ftag=CADf328eec](https://www.cnet.com/culture/students-wild-homemade-anti-cheating-hats-get-top-marks-for-creativity/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 21:23:00+00:00

A professor in the Philippines asks students to craft hats that prevent their peers from copying exam answers, and they deliver in a big, heady way.

## 'House of the Dragon' Finale Pulled HBO's Biggest Finale Audience Since 'Game of Thrones'     - CNET
 - [https://www.cnet.com/culture/entertainment/house-of-the-dragon-finale-pulled-hbos-biggest-finale-audience-since-game-of-thrones/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/house-of-the-dragon-finale-pulled-hbos-biggest-finale-audience-since-game-of-thrones/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 21:07:59+00:00

It had 10 million less viewers than GOT's final episode, however.

## McDonald's Boo Buckets Are Gone After Halloween: How to Get One Now     - CNET
 - [https://www.cnet.com/culture/mcdonalds-boo-buckets-are-gone-after-halloween-how-to-get-one-now/#ftag=CADf328eec](https://www.cnet.com/culture/mcdonalds-boo-buckets-are-gone-after-halloween-how-to-get-one-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 20:36:00+00:00

The nostalgic Happy Meal containers are back, but they won't be around for long.

## Why You Should Understand Your HRV Even if You're Not a Professional Athlete     - CNET
 - [https://www.cnet.com/health/fitness/why-you-should-understand-your-hrv-even-if-youre-not-a-professional-athlete/#ftag=CADf328eec](https://www.cnet.com/health/fitness/why-you-should-understand-your-hrv-even-if-youre-not-a-professional-athlete/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 20:34:00+00:00

Heart-rate variability can give insight into your overall health, stress, fitness levels and so much more.

## 'The Watcher' on Netflix: The True Story Behind Those Ominous Letters     - CNET
 - [https://www.cnet.com/culture/entertainment/the-watcher-on-netflix-the-true-story-behind-those-ominous-anonymous-letters/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-watcher-on-netflix-the-true-story-behind-those-ominous-anonymous-letters/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 20:12:00+00:00

A real New Jersey family received chilling letters after purchasing a new home, but Netflix made up a lot of details.

## 2 New iOS 16 Features That Actually Just Drain Your iPhone Battery     - CNET
 - [https://www.cnet.com/tech/mobile/2-new-ios-16-features-that-actually-just-drain-your-iphone-battery/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/2-new-ios-16-features-that-actually-just-drain-your-iphone-battery/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 20:05:02+00:00

We'll show you how to disable them.

## How One Barren Planet Could 'Dramatically Narrow' the Search for Alien Life     - CNET
 - [https://www.cnet.com/science/space/how-one-barren-planet-could-dramatically-narrow-the-search-for-alien-life/#ftag=CADf328eec](https://www.cnet.com/science/space/how-one-barren-planet-could-dramatically-narrow-the-search-for-alien-life/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 20:04:29+00:00

We still don't know where aliens are, but here's where they probably aren't.

## A Veterinarian's Top 5 Dog Breeds: See If Yours Is on the List     - CNET
 - [https://www.cnet.com/culture/a-veterinarians-top-5-dog-breeds-see-if-yours-is-on-the-list/#ftag=CADf328eec](https://www.cnet.com/culture/a-veterinarians-top-5-dog-breeds-see-if-yours-is-on-the-list/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 19:59:41+00:00

Sorry, bulldog owners. Your furry friend is one of the many breeds not on the list.

## World's Oldest Known Map of Stars Found Hiding in Medieval Manuscript     - CNET
 - [https://www.cnet.com/science/space/oldest-known-map-of-stars-found-hiding-in-medieval-manuscript/#ftag=CADf328eec](https://www.cnet.com/science/space/oldest-known-map-of-stars-found-hiding-in-medieval-manuscript/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 19:55:00+00:00

Multispectral imaging of an ancient Greek palimpsest reveals fragments of astronomer Hipparchus' fabled treatise on the night sky.

## How to Measure Your Heart Rate: 4 Ways and What's Normal     - CNET
 - [https://www.cnet.com/health/fitness/how-to-measure-your-heart-rate-4-ways-and-whats-normal/#ftag=CADf328eec](https://www.cnet.com/health/fitness/how-to-measure-your-heart-rate-4-ways-and-whats-normal/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 19:50:56+00:00

When's the last time you measured your own pulse?

## Best Buy's Upgrade Plus Lets MacBook Buyers Upgrade Every 3 Years     - CNET
 - [https://www.cnet.com/tech/computing/best-buys-upgrade-plus-lets-macbook-buyers-upgrade-every-3-years/#ftag=CADf328eec](https://www.cnet.com/tech/computing/best-buys-upgrade-plus-lets-macbook-buyers-upgrade-every-3-years/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 19:42:00+00:00

You're already paying subscriptions for everything, so why not a MacBook?

## NASA's Webb Telescope Spots Galaxies Merging Around 'Monster' Black Hole     - CNET
 - [https://www.cnet.com/science/space/nasas-webb-telescope-spots-galaxies-merging-around-monster-black-hole/#ftag=CADf328eec](https://www.cnet.com/science/space/nasas-webb-telescope-spots-galaxies-merging-around-monster-black-hole/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 19:35:00+00:00

The next-gen instrument captures a rare, and rather extreme, cosmic scene.

## Dancing Demogorgon! It's a 'Stranger Things' Musical     - CNET
 - [https://www.cnet.com/culture/entertainment/dancing-demogorgon-its-a-stranger-things-musical/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/dancing-demogorgon-its-a-stranger-things-musical/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 19:32:00+00:00

The Hawkins crew sashays its way through an off-Broadway satire of the Netflix horror series that finally brings justice for Barb.

## Bizarre Tentacle Robot Looks Like It Emerged From 'The Matrix'     - CNET
 - [https://www.cnet.com/science/bizarre-tentacle-robot-looks-like-it-emerged-from-the-matrix/#ftag=CADf328eec](https://www.cnet.com/science/bizarre-tentacle-robot-looks-like-it-emerged-from-the-matrix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 19:24:41+00:00

The robot might appear creepy, but it has a gentle touch.

## Veterinarian Reveals the Four Cat Breeds He'd Never Pick     - CNET
 - [https://www.cnet.com/culture/viral-tiktok-veterinarian-reveals-the-four-cat-breeds-hed-never-choose/#ftag=CADf328eec](https://www.cnet.com/culture/viral-tiktok-veterinarian-reveals-the-four-cat-breeds-hed-never-choose/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 19:17:00+00:00

TikTok's favorite vet Ben Simpson-Vernon is back to share some opinions on cats.

## Medicare Premiums and Deductibles: Here Are the Prices for 2023     - CNET
 - [https://www.cnet.com/personal-finance/medicare-premiums-and-deductibles-here-are-the-prices-for-2023/#ftag=CADf328eec](https://www.cnet.com/personal-finance/medicare-premiums-and-deductibles-here-are-the-prices-for-2023/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 19:15:02+00:00

Find out how much cheaper Medicare Part B premiums will be next year, and how much extra you'll pay for Medicare Part A.

## 'Succession' Season 4 Trailer Teases 'Rebel Alliance' Against Logan Roy     - CNET
 - [https://www.cnet.com/culture/entertainment/succession-season-4-trailer-teases-rebel-alliance-against-logan-roy/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/succession-season-4-trailer-teases-rebel-alliance-against-logan-roy/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 18:10:00+00:00

HBO's Emmy-winning dark comedy returns in the spring of 2023.

## How to Get Equity Out of Your House     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/how-to-get-equity-out-of-your-house/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/how-to-get-equity-out-of-your-house/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 18:09:54+00:00

You probably have a lot more equity in your home than you did two years ago. Here's how to tap into it and access cash.

## 'House of the Dragon' Finale: The Ending Explained and Your Questions Answered     - CNET
 - [https://www.cnet.com/culture/entertainment/house-of-the-dragon-finale-the-ending-explained-and-your-questions-answered/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/house-of-the-dragon-finale-the-ending-explained-and-your-questions-answered/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 18:03:00+00:00

It wouldn't be a Game of Thrones show without at least one significant death. Spoilers ahead.

## OnePlus Nord N300 Budget Phone Launching in November for $228     - CNET
 - [https://www.cnet.com/tech/mobile/oneplus-nord-n300-budget-phone-launching-in-november-for-228/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/oneplus-nord-n300-budget-phone-launching-in-november-for-228/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:44:00+00:00

It'll be available from T-Mobile.

## 'House of the Dragon' Season Finale Recap: This Means War     - CNET
 - [https://www.cnet.com/culture/entertainment/house-of-the-dragon-season-finale-recap-this-means-war/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/house-of-the-dragon-season-finale-recap-this-means-war/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:38:00+00:00

Episode 10 of House of the Dragon's first season saw Rhaenyra and Daemon prepare for battle with the Hightowers.

## iPadOS 16 Is Out Now for the iPad. Here's How You Can Get It     - CNET
 - [https://www.cnet.com/tech/services-and-software/ipados-16-is-out-now-for-the-ipad-heres-how-you-can-get-it/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/ipados-16-is-out-now-for-the-ipad-heres-how-you-can-get-it/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:30:00+00:00

Apple's latest mobile software update for the iPad is now available to download.

## USB-C Universal Law Receives Final Approval in EU     - CNET
 - [https://www.cnet.com/tech/mobile/usb-c-universal-law-receives-final-approval-in-eu/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/usb-c-universal-law-receives-final-approval-in-eu/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:25:00+00:00

The plug will be the common charger in the EU starting in 2024.

## 'Stranger Things' Parody Musical Finally Brings Justice for Barb     - CNET
 - [https://www.cnet.com/culture/entertainment/stranger-things-parody-musical-finally-brings-justice-for-barb/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/stranger-things-parody-musical-finally-brings-justice-for-barb/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:18:00+00:00

Dancing Demogorgon! The Hawkins crew sashays its way through an off-Broadway satire of the Netflix horror series.

## Best Buy's Early Black Friday Deals Knock Hundreds Off Google Nest Devices     - CNET
 - [https://www.cnet.com/deals/best-buys-early-black-friday-deals-knock-hundreds-off-google-nest-devices/#ftag=CADf328eec](https://www.cnet.com/deals/best-buys-early-black-friday-deals-knock-hundreds-off-google-nest-devices/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:16:32+00:00

Best Buy is kicking off the holiday shopping season early with huge discounts on Google smart displays, speaker and routers.

## 'Ant-Man and the Wasp: Quantumania' Trailer Goes Deep Into the Quantum Realm     - CNET
 - [https://www.cnet.com/culture/entertainment/ant-man-and-the-wasp-quantumania-trailer-sucks-everyone-into-quantum-realm/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/ant-man-and-the-wasp-quantumania-trailer-sucks-everyone-into-quantum-realm/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:14:00+00:00

The MCU is taking another trip into the quantum realm, which has more going on than you might have thought.

## 2023 Kia Niro EV Starts at a Hair Over $40,000     - CNET
 - [https://www.cnet.com/roadshow/news/2023-kia-niro-ev-pricing/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2023-kia-niro-ev-pricing/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:09:11+00:00

Both available trims use the same 64.8-kilowatt-hour battery, offering an EPA-estimated 253 miles of range.

## Inflation Hits Apple Services: Apple Music, Apple TV Plus and Apple One Increase Prices     - CNET
 - [https://www.cnet.com/news/inflation-hits-apple-services-apple-music-apple-tv-plus-and-apple-one-increase-prices/#ftag=CADf328eec](https://www.cnet.com/news/inflation-hits-apple-services-apple-music-apple-tv-plus-and-apple-one-increase-prices/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:04:07+00:00

The iPhone maker attributed the increases in part to higher licensing costs.

## Harry Potter Movies Coming Back to HBO Max in November     - CNET
 - [https://www.cnet.com/culture/entertainment/harry-potter-movies-coming-back-to-hbo-max-in-november/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/harry-potter-movies-coming-back-to-hbo-max-in-november/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:03:00+00:00

All eight movies will return to the service after being removed this past summer.

## How a Foot Massage Can Actually Help You Sleep Better     - CNET
 - [https://www.cnet.com/health/sleep/how-a-foot-massage-can-actually-help-you-sleep-better/#ftag=CADf328eec](https://www.cnet.com/health/sleep/how-a-foot-massage-can-actually-help-you-sleep-better/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:00:08+00:00

A foot massage can help create a deeper sleep by reducing anxiety and relieving chronic pain.

## Best Wireless Earbuds and Headphones for Samsung Phones     - CNET
 - [https://www.cnet.com/tech/mobile/best-wireless-earbuds-and-headphones-for-samsung-phones/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/best-wireless-earbuds-and-headphones-for-samsung-phones/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:00:03+00:00

Looking for new wireless headphones for the Galaxy S22? Here are CNET's top picks.

## iOS 16.1 Is Here. How to Download the Latest iPhone Update Right Now     - CNET
 - [https://www.cnet.com/tech/mobile/ios-16-1-is-here-how-to-download-the-latest-iphone-update-right-now/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/ios-16-1-is-here-how-to-download-the-latest-iphone-update-right-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 17:00:00+00:00

iOS 16.1 brings several new features to the iPhone, including Live Activities and iCloud Shared Photo Library.

## Stop Getting Hangry: How to Tweak Your Diet for Balanced Blood Sugar     - CNET
 - [https://www.cnet.com/health/nutrition/stop-getting-hangry-how-to-tweak-your-diet-for-balanced-blood-sugar/#ftag=CADf328eec](https://www.cnet.com/health/nutrition/stop-getting-hangry-how-to-tweak-your-diet-for-balanced-blood-sugar/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 16:52:23+00:00

Keeping your blood sugar levels balanced throughout the day is not only healthy for you -- it's also a lot more pleasant.

## Apple TV Plus: Every New TV Show Arriving in October     - CNET
 - [https://www.cnet.com/culture/entertainment/apple-tv-plus-tv-shows-to-watch-now-in-october-this-week/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/apple-tv-plus-tv-shows-to-watch-now-in-october-this-week/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 16:44:37+00:00

Here's a complete list of shows coming in October.

## Atmosphere-less Planet Could 'Dramatically Narrow' Search for Extraterrestrial Life     - CNET
 - [https://www.cnet.com/science/space/atmosphere-less-planet-could-dramatically-narrow-search-for-extraterrestrial-life/#ftag=CADf328eec](https://www.cnet.com/science/space/atmosphere-less-planet-could-dramatically-narrow-search-for-extraterrestrial-life/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 16:39:29+00:00

We still don't know where aliens are, but here's where they probably aren't.

## The Best Movies on Apple TV Plus     - CNET
 - [https://www.cnet.com/culture/entertainment/the-best-movies-to-check-out-on-apple-tv-plus-now-this-week/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-best-movies-to-check-out-on-apple-tv-plus-now-this-week/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 16:36:51+00:00

Apple TV Plus has an assortment of options, from dramas to music documentaries and animated movies.

## The Absolute Best Fantasy Movies on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-fantasy-movies-you-can-stream-over-this-week/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-fantasy-movies-you-can-stream-over-this-week/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 16:23:48+00:00

Netflix's fantasy options range from pure magic to touching allegories of the human condition.

## Social Security COLA for 2023: Here's How Much More You'll Be Getting Next Year     - CNET
 - [https://www.cnet.com/personal-finance/social-security-cola-for-2023-heres-how-much-more-youll-get/#ftag=CADf328eec](https://www.cnet.com/personal-finance/social-security-cola-for-2023-heres-how-much-more-youll-get/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 16:19:00+00:00

The 8.7% cost-of-living increase is the highest in four decades.

## You Should Still Apply for Student Loan Debt Relief ASAP. Here's How     - CNET
 - [https://www.cnet.com/personal-finance/loans/you-should-still-apply-for-student-loan-debt-relief-asap-heres-how/#ftag=CADf328eec](https://www.cnet.com/personal-finance/loans/you-should-still-apply-for-student-loan-debt-relief-asap-heres-how/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 16:15:03+00:00

Student loan debt forgiveness has been temporarily blocked, but you can still apply for up to $20,000 in relief.

## Pixel 7 Pro Actually Challenges My $10,000 DSLR Camera Setup     - CNET
 - [https://www.cnet.com/tech/mobile/google-pixel-7-pro-challenges-my-10000-dslr-camera-gear/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/google-pixel-7-pro-challenges-my-10000-dslr-camera-gear/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 16:10:00+00:00

My full-frame Canon camera is better. But the Google smartphone's zoom, macro and Night Sight skills open creative options far beyond snapshots.

## 2022 GMC Hummer EV Recalled for Improperly Sealed Batteries     - CNET
 - [https://www.cnet.com/roadshow/news/2022-gmc-hummer-ev-recall-improperly-sealed-batteries/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2022-gmc-hummer-ev-recall-improperly-sealed-batteries/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 16:05:18+00:00

Of all the things that could enter an electric car's battery pack, water is not really ideal.

## How to Avoid Having Your Flight Delayed or Canceled Over Thanksgiving     - CNET
 - [https://www.cnet.com/culture/how-to-avoid-having-your-flight-delayed-or-canceled-over-thanksgiving/#ftag=CADf328eec](https://www.cnet.com/culture/how-to-avoid-having-your-flight-delayed-or-canceled-over-thanksgiving/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 16:00:07+00:00

More than half of Americans say they plan to travel over the holidays.

## What Apple Hasn't Released in 2022: AR/VR headset, new Mac Pro and More video     - CNET
 - [https://www.cnet.com/videos/what-apple-hasnt-released-in-2022-arvr-headset-new-mac-pro-and-more/#ftag=CADf328eec](https://www.cnet.com/videos/what-apple-hasnt-released-in-2022-arvr-headset-new-mac-pro-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 16:00:01+00:00

An Apple mixed-reality headset, an Apple silicon Mac Pro and some sort of car situation? We're still waiting impatiently for these rumored Apple products to make their debut.

## Freeze-Proof Plants: 10 Flowers That Can Weather a Snowstorm     - CNET
 - [https://www.cnet.com/how-to/freeze-proof-plants-10-flowers-that-can-weather-a-snowstorm/#ftag=CADf328eec](https://www.cnet.com/how-to/freeze-proof-plants-10-flowers-that-can-weather-a-snowstorm/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 15:59:35+00:00

Make sure your landscaping comes back strong every spring with plants that won't kick the bucket over a hard winter.

## NASA Webb Telescope Reveals Massive Galaxy Merger Around 'Monster' Black Hole     - CNET
 - [https://www.cnet.com/science/space/nasa-webb-telescope-reveals-massive-galaxy-merger-around-monster-black-hole/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-webb-telescope-reveals-massive-galaxy-merger-around-monster-black-hole/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 15:48:27+00:00

This might be one of the JWST's most extreme images yet.

## YouTube App Gets Pinch-to-Zoom, Precise Seeking and Other Updates     - CNET
 - [https://www.cnet.com/tech/services-and-software/youtube-app-gets-pinch-to-zoom-precise-seeking-and-other-updates/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/youtube-app-gets-pinch-to-zoom-precise-seeking-and-other-updates/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 15:38:00+00:00

The new features begin rolling out on Monday.

## Stop Letting This One Setting Wreck Your TV's Picture     - CNET
 - [https://www.cnet.com/tech/home-entertainment/stop-letting-one-setting-wreck-your-tvs-picture/#ftag=CADf328eec](https://www.cnet.com/tech/home-entertainment/stop-letting-one-setting-wreck-your-tvs-picture/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 15:19:53+00:00

Turn this one setting down for better picture quality.

## The Days of Free Netflix Password Sharing Are Coming to an End     - CNET
 - [https://www.cnet.com/culture/entertainment/free-netflix-password-sharing-is-coming-to-an-end/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/free-netflix-password-sharing-is-coming-to-an-end/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 15:03:06+00:00

Early next year, Netflix will start charging you fees when you share your account.

## Monday Night Football: How to Watch, Stream Bears vs. Patriots, ManningCast Without Cable     - CNET
 - [https://www.cnet.com/tech/services-and-software/monday-night-football-how-to-watch-stream-bears-vs-patriots-manningcast-tonight-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/monday-night-football-how-to-watch-stream-bears-vs-patriots-manningcast-tonight-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 15:00:33+00:00

Chicago and New England wrap up Week 7 tonight on ESPN. And Peyton and Eli are back on ESPN2.

## Activists Vandalize Glass-Covered Monet with Mashed Potatoes, Painting Unharmed     - CNET
 - [https://www.cnet.com/news/activists-vandalize-glass-covered-monet-with-mashed-potatoes-painting-unharmed/#ftag=CADf328eec](https://www.cnet.com/news/activists-vandalize-glass-covered-monet-with-mashed-potatoes-painting-unharmed/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 14:35:00+00:00

Claude Monet's Grainstack, currently in Potsdam, Germany, is unharmed and will be on display again by Wednesday, according to The New York Times.

## Get Affordable Travel Gear For Your Next Trip at Woot     - CNET
 - [https://www.cnet.com/deals/get-affordable-travel-gear-for-your-next-trip-at-woot/#ftag=CADf328eec](https://www.cnet.com/deals/get-affordable-travel-gear-for-your-next-trip-at-woot/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 14:33:00+00:00

There's a bunch of affordable luggage on sale that's perfect for visiting friends and family this holiday season.

## Rishi Sunak Is Next UK Prime Minister     - CNET
 - [https://www.cnet.com/news/politics/rishi-sunak-is-next-uk-prime-minister/#ftag=CADf328eec](https://www.cnet.com/news/politics/rishi-sunak-is-next-uk-prime-minister/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 14:18:30+00:00

He'll be the first person of color and the youngest to hold the office.

## Save Up to $100 On Ultrapopular Beats Earbuds Right Now at Amazon     - CNET
 - [https://www.cnet.com/deals/save-up-to-100-on-ultra-popular-beats-earbuds-right-now-at-amazon/#ftag=CADf328eec](https://www.cnet.com/deals/save-up-to-100-on-ultra-popular-beats-earbuds-right-now-at-amazon/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 14:04:00+00:00

You can save up to 40% on nearly all models of Beats earbuds, including the all-time lowest price we've seen on the Beats Studio Buds.

## This Sterling Forever Sale Offers You 20% Off All Rings     - CNET
 - [https://www.cnet.com/deals/this-sterling-forever-sale-offers-you-20-off-all-rings/#ftag=CADf328eec](https://www.cnet.com/deals/this-sterling-forever-sale-offers-you-20-off-all-rings/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 13:51:00+00:00

Accessorize your holiday outfits with new simple rings for less.

## SSI Beneficiaries Are Getting Their COLA Increase in December. Here's Why     - CNET
 - [https://www.cnet.com/personal-finance/ssi-beneficiaries-are-getting-their-cola-increase-in-december-heres-why/#ftag=CADf328eec](https://www.cnet.com/personal-finance/ssi-beneficiaries-are-getting-their-cola-increase-in-december-heres-why/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 13:46:00+00:00

Supplemental Security Income recipients won't have to wait until 2023 to get their first check with their payment increase. We'll explain.

## Pixel 6A Deal Brings Record Low Price of $299 For Limited Time     - CNET
 - [https://www.cnet.com/deals/pixel-6a-record-low-pricing-299/#ftag=CADf328eec](https://www.cnet.com/deals/pixel-6a-record-low-pricing-299/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 13:44:45+00:00

You're not going to find a better value Android device out there for the money right now.

## The M2 MacBook Air Is the Ultimate Laptop Gift     - CNET
 - [https://www.cnet.com/tech/computing/m2-macbook-air-is-the-ultimate-laptop-gift/#ftag=CADf328eec](https://www.cnet.com/tech/computing/m2-macbook-air-is-the-ultimate-laptop-gift/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 13:41:57+00:00

With a new camera, new colors and a bigger screen, the MacBook Air remains one of the most universally useful laptops you can get.

## 5 States Have Put Abortion Access on the Ballot on Election Day     - CNET
 - [https://www.cnet.com/how-to/these-states-have-put-abortion-on-the-ballot-in-november/#ftag=CADf328eec](https://www.cnet.com/how-to/these-states-have-put-abortion-on-the-ballot-in-november/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 13:00:15+00:00

Nov. 8 will see the highest number of abortion-related referendums before voters in a single year.

## Here Are Today's Refinance Rates, Oct. 24, 2022: Rates Move Higher     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/here-are-todays-refinance-rates-oct-24-2022-rates-move-higher/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/here-are-todays-refinance-rates-oct-24-2022-rates-move-higher/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 13:00:11+00:00

Multiple important refinance rates were higher today. If you haven't locked in a rate yet, now's a good time to assess your options.

## Netflix: The 45 Absolute Best Movies to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/netflix-the-45-absolute-best-movies-to-watch/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/netflix-the-45-absolute-best-movies-to-watch/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 13:00:04+00:00

This week, catch The Good Nurse, starring Eddie Redmayne and Jessica Chastain.

## Today's Mortgage Rates for Oct. 24, 2022: Rates Move Higher     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/todays-mortgage-rates-for-oct-24-2022-rates-move-higher/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/todays-mortgage-rates-for-oct-24-2022-rates-move-higher/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 13:00:04+00:00

Today a few major mortgage rates inched up. See how the Fed's interest rate hikes could affect your home loan payments.

## iPad 10th Gen and iPad Pro: Which iPad Should You Buy Now? video     - CNET
 - [https://www.cnet.com/videos/ipad-10th-gen-and-ipad-pro-which-ipad-should-you-buy-now/#ftag=CADf328eec](https://www.cnet.com/videos/ipad-10th-gen-and-ipad-pro-which-ipad-should-you-buy-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 13:00:01+00:00

The newest iPads have upgrades, but also downsides. Which one's best for you is a tougher choice than ever.

## iPad 10th Gen Review: Better Design, Worse Price     - CNET
 - [https://www.cnet.com/tech/computing/ipad-10th-gen-review-better-design-worse-price/#ftag=CADf328eec](https://www.cnet.com/tech/computing/ipad-10th-gen-review-better-design-worse-price/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 13:00:00+00:00

The step-up entry-level iPad isn't the most affordable or even necessarily the best one.

## Separation Anxiety? Here's How to Sleep Better When Alone     - CNET
 - [https://www.cnet.com/health/sleep/separation-anxiety-heres-how-to-sleep-better-when-alone/#ftag=CADf328eec](https://www.cnet.com/health/sleep/separation-anxiety-heres-how-to-sleep-better-when-alone/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 12:00:02+00:00

Separation anxiety is common in children, but it happens in adults too.

## Taking Screenshots Is Easy on Windows 10 and 11. Here's How     - CNET
 - [https://www.cnet.com/tech/services-and-software/taking-screenshots-is-easy-on-windows-10-and-11-heres-how/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/taking-screenshots-is-easy-on-windows-10-and-11-heres-how/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 11:00:10+00:00

There are plenty of ways to take screenshots on your PC.

## Heart-Rate Variability Is a Key Health Metric That You Need to Start Tracking     - CNET
 - [https://www.cnet.com/health/fitness/heart-rate-variability-is-a-key-health-metric-that-you-need-to-start-tracking/#ftag=CADf328eec](https://www.cnet.com/health/fitness/heart-rate-variability-is-a-key-health-metric-that-you-need-to-start-tracking/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 11:00:07+00:00

Heart-rate variability can give insight into your overall health, stress, fitness levels and so much more.

## How Much Cheaper Is Trader Joe's Than Other Grocery Stores? We Do the Math     - CNET
 - [https://www.cnet.com/how-to/how-much-cheaper-is-trader-joes-than-other-grocery-stores-we-do-the-math/#ftag=CADf328eec](https://www.cnet.com/how-to/how-much-cheaper-is-trader-joes-than-other-grocery-stores-we-do-the-math/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 11:00:02+00:00

We priced out nearly 50 groceries from Trader Joe's and a conventional supermarket chain. Here's how much TJ's might you save you in a single trip.

## Your VPN Is Useless Without This Essential Security Feature     - CNET
 - [https://www.cnet.com/tech/services-and-software/your-vpn-is-useless-without-this-essential-security-feature/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/your-vpn-is-useless-without-this-essential-security-feature/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 10:15:02+00:00

A VPN kill switch is crucial for your online privacy and security. Here's how it works.

## Halloween Deals at Baskin-Robbins, Dunkin', Chipotle and More     - CNET
 - [https://www.cnet.com/culture/halloween-deals-baskin-robbins-dunkin-chipotle/#ftag=CADf328eec](https://www.cnet.com/culture/halloween-deals-baskin-robbins-dunkin-chipotle/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 10:00:02+00:00

Where to score discounts and freebies during the spooky season.

## 2022 Rimac Nevera First Drive Review: The New Hypercar Benchmark     - CNET
 - [https://www.cnet.com/roadshow/news/2022-rimac-nevera-ev-hypercar-first-drive-review/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/2022-rimac-nevera-ev-hypercar-first-drive-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 09:00:08+00:00

This electric Croatian hypercar completely rewrites the definition of speed.

## Best Music Streaming Service for 2022     - CNET
 - [https://www.cnet.com/tech/services-and-software/best-music-streaming-service/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/best-music-streaming-service/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 09:00:03+00:00

With new features like spatial music and podcasts, competition between Spotify, Apple Music and YouTube Music is keener than ever.

## 'House of the Dragon' Finale: What Page Did Alicent Send Rhaenyra?     - CNET
 - [https://www.cnet.com/culture/entertainment/house-of-the-dragon-finale-what-page-did-alicent-send-rhaenyra/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/house-of-the-dragon-finale-what-page-did-alicent-send-rhaenyra/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 05:38:00+00:00

Where did the page with the pretty writing and striking image come from?

## 'House of the Dragon:' That Ending Explained and All Your Questions Answered     - CNET
 - [https://www.cnet.com/culture/entertainment/house-of-the-dragon-that-ending-explained-and-all-your-questions-answered/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/house-of-the-dragon-that-ending-explained-and-all-your-questions-answered/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 03:50:00+00:00

It wouldn't be a Game of Thrones show without at least one significant death. Spoilers inside.

## These Sneakers for Horses go for $1,200. Per Shoe     - CNET
 - [https://www.cnet.com/culture/these-sneakers-for-horses-go-for-1200-per-shoe/#ftag=CADf328eec](https://www.cnet.com/culture/these-sneakers-for-horses-go-for-1200-per-shoe/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 03:08:00+00:00

Yup, sneakers for equines are a thing.

## 'House of the Dragon' Finale Recap: This Means War     - CNET
 - [https://www.cnet.com/culture/entertainment/house-of-the-dragon-finale-recap-this-means-war/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/house-of-the-dragon-finale-recap-this-means-war/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2022-10-24 02:12:00+00:00

Episode 10 of House of the Dragon's first season saw Rhaenyra and Daemon prepare for battle with the Hightowers.


# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Justice Dept. Charges 2 Chinese Citizens With Spying for Huawei
 - [https://www.nytimes.com/2022/10/24/us/politics/justice-dept-huawei.html](https://www.nytimes.com/2022/10/24/us/politics/justice-dept-huawei.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-24 23:26:57+00:00

Huawei has been a persistent target of the United States government since the administration of President Donald J. Trump.

## Tesla Cuts Prices in China in Sign of Slowing Demand
 - [https://www.nytimes.com/2022/10/24/business/tesla-china-price-cut.html](https://www.nytimes.com/2022/10/24/business/tesla-china-price-cut.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2022-10-24 16:37:40+00:00

Shares of the company slumped as investors worried about increasing competition.


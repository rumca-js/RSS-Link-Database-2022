# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Rishi Sunak - THIS Is What They’re Not Telling You
 - [https://www.youtube.com/watch?v=6uKibtKuSe8](https://www.youtube.com/watch?v=6uKibtKuSe8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-10-25 00:00:00+00:00

Rishi Sunak is the new UK prime minister. What does his background of private schools, Goldman Sachs, a billionaire wife and connections to the WEF reveal about him? #uk #economy #politics 

Watch Full Episode On Rumble: https://bit.ly/3TStUWj

## This Is F*cking DANGEROUS
 - [https://www.youtube.com/watch?v=ue6A05KTptI](https://www.youtube.com/watch?v=ue6A05KTptI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2022-10-24 00:00:00+00:00

As California Governor Gavin Newsom signs a bill meaning doctors could be sacked for spreading COVID “misinformation” to patients, we ask, if doctors can’t give health advice, who can? #covid #pandemic #misinformation 

References
https://www.healthline.com/health-news/did-california-just-ban-medical-misinformation-what-we-know
https://www.nytimes.com/2022/08/29/technology/california-doctors-covid-misinformation.html
https://www.washingtonpost.com/opinions/2022/10/20/children-covid-vaccine-boosters-guidance/
--------------------------------------------------------------------------------------------------------------------------
FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand

Join The Community STAY FREE AF: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/

NEW MERCH! https://stuff.russellbrand.com/


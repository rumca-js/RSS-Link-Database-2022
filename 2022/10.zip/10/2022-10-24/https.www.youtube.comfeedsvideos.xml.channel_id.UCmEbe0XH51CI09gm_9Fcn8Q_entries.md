# Source:Glass Reflection, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmEbe0XH51CI09gm_9Fcn8Q, language:en-US

## I Watched Made In Abyss S2 (And now so do you...) | GR Anime Review
 - [https://www.youtube.com/watch?v=MUFsIJi-s2c](https://www.youtube.com/watch?v=MUFsIJi-s2c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmEbe0XH51CI09gm_9Fcn8Q
 - date published: 2022-10-24 17:53:59+00:00

🍁Use Code "GLASS" to get $5 off for your first #Sakuraco box through this link: https://team.sakura.co/glassreflection-SC2210 and #TokyoTreat box through this link: https://team.tokyotreat.com/glassreflection-TT2210
🎃 Check their Halloween Giveaway and win Japanese goodies here: https://bit.ly/TT-halloween22

► Support me on Patreon: http://www.patreon.com/Arkada
► Follow me on Twitter: http://www.twitter.com/GlassReflection

#Anime #Discussion #madeinabyss #madeinabyssseason2   #animeanalysis #Analysis #Opening #OP #ED #GlassReflection


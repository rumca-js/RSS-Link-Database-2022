# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## The government approves of this shark now.
 - [https://www.youtube.com/watch?v=zCDIhq9nMBE](https://www.youtube.com/watch?v=zCDIhq9nMBE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2022-10-24 00:00:00+00:00

The Headington Shark, in Oxford, UK, is a local icon: but it was protest art, put up without permission. Now, the local government wants to protect it. ▪ The Shark House: https://www.headingtonshark.com/

Edited by Michelle Martin https://twitter.com/mrsmmartin

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo


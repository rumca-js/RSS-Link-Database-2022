# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Got Your Back | David Ryan Harris ft. John Mayer!!! LIVE at The Troubadour
 - [https://www.youtube.com/watch?v=Ho90qnoI5Bw](https://www.youtube.com/watch?v=Ho90qnoI5Bw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2022-10-24 00:00:00+00:00

See us LIVE with David Ryan Harris & John Scofield, November 16 at Echoplex in Los Angeles! Tickets: https://www.ticketmaster.com/event/09005D46CBA957C0

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of "Got Your Back" by David Ryan Harris & Scary Pockets

MUSICIAN CREDITS
Lead Vocals: David Ryan Harris
Guitar: Ryan Lerman
Guitar: John Mayer
Bass: Sean Hurley
Organ: Larry Goldings
Keys: Charles Jones
Drums: Lemar Carter
BGVs: India Carney, Carlos Ricketts Jr, Tiffany Palmer
Percussion: Lenny Castro

AUDIO CREDITS
Recording Engineer: Caleb Parker
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
Director: Ricky Chavez
DP: Merlin Showalter
Camera Operators: Isaac Park, Jenny Baumert
Editor: Adam Kritzberg 

Recorded Live at The Troubadour in Los Angeles, CA.

#ScaryPockets #Funk


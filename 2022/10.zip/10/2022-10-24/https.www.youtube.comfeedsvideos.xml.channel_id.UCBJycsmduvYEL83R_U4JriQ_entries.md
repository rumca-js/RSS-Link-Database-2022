# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## The New iPad is Weird!
 - [https://www.youtube.com/watch?v=C6Ni9rH6VmA](https://www.youtube.com/watch?v=C6Ni9rH6VmA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2022-10-25 00:00:00+00:00

The new 10th gen iPad is one of the weirdest releases in years.

Get that Camo Windbreaker: https://mkbhd.com/

Apple iPad 10th Gen at https://geni.us/rn0yzoD
Apple Pencil 1st Gen at https://geni.us/yVw2Bs
Apple Pencil 2nd Gen at https://geni.us/uWT5
Apple Lightning Adapter at https://geni.us/aYcYLS

Tech I'm using right now:
https://www.amazon.com/shop/MKBHD
Intro Track: Jordyn Edmonds http://smarturl.it/jordynedmonds
Playlist of MKBHD Intro music: https://goo.gl/B3AWV5
Tablet provided by Apple for review.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD


# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Plants Will Absolutely Murder Each Other
 - [https://www.youtube.com/watch?v=yLtcZfVQcc4](https://www.youtube.com/watch?v=yLtcZfVQcc4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2022-10-25 00:00:00+00:00

Check out http://rocketmoney.com/scishow to start managing your personal finances today. Thank you to Rocket Money for sponsoring today's video! #rocketmoney #personalfinance

If you've noticed that your garden is looking a little sad, it might be due to sabotage from other plants!



Hosted by: Hank Green

SciShow is on TikTok!  Check us out at https://www.tiktok.com/@scishow 
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever:

Matt Curls, Alisa Sherbow, Dr. Melvin Sanicas, Harrison Mills, Adam Brainard, Chris Peters, charles george, Piya Shedden, Alex Hackman, Christopher R, Boucher, Jeffrey Mckishen, Ash, Silas Emrys, Eric Jensen, Kevin Bealer, Jason A Saslow, Tom Mosner, Tomás Lagos González, Jacob, Christoph Schwanke, Sam Lutfi, Bryan Cloer
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
Facebook: http://www.facebook.com/scishow
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
#SciShow #science #education
----------
Sources:

https://dergipark.org.tr/tr/download/article-file/703871 
https://www.extension.purdue.edu/extmedia/ho/ho-193.pdf 
https://www.frontiersin.org/articles/10.3389/fpls.2015.01020/full
https://doi.org/10.1023/a:1026242418333 
https://jem-online.org/forrex/index.php/jem/article/view/119
https://www.cabdirect.org/cabdirect/abstract/20093256372
https://www.mdpi.com/1422-0067/22/22/12606

https://www.gettyimages.com/detail/photo/black-walnut-buds-close-up-walnut-blooms-branch-royalty-free-image/1056372440?phrase=black%20walnut%20tree%20bud&adppopup=true
https://commons.wikimedia.org/wiki/File:Black_Walnut_nut_and_leave_detail.JPG#/media/File:Black_Walnut_nut_and_leave_detail.JPG
https://www.gettyimages.com/detail/photo/black-walnut-tree-in-autumn-royalty-free-image/140236080?phrase=black%20walnut%20tree&adppopup=true
https://www.gettyimages.com/detail/photo/devastated-tomatoes-as-a-result-of-long-time-royalty-free-image/1337075726?phrase=tomatoes%20garden%20dead&adppopup=true
https://www.gettyimages.com/detail/photo/field-of-sorghum-royalty-free-image/530592641?phrase=%20sorghum&adppopup=true
https://commons.wikimedia.org/wiki/File:Sorghum_halepense_stolons2_(7412712596).jpg
https://www.gettyimages.com/detail/photo/row-of-onions-royalty-free-image/892022394?phrase=onions%20plant&adppopup=true
https://www.gettyimages.com/detail/photo/fresh-red-tomatoes-and-eggplants-top-view-royalty-free-image/1224981257?phrase=tomato%20eggplant&adppopup=true
https://www.gettyimages.com/detail/photo/spotted-knapweed-in-bloom-close-up-view-with-green-royalty-free-image/1346488862?phrase=%20spotted%20knapweed&adppopup=true
https://www.gettyimages.com/detail/video/crop-duster-spraying-chemicals-over-a-cotton-field-slow-stock-footage/1050055890?phrase=crops%20herbicide&adppopup=true
https://www.gettyimages.com/detail/photo/herbicide-spraying-non-organic-vegetables-royalty-free-image/1146896346?phrase=glyphosate&adppopup=true
https://www.gettyimages.com/detail/photo/cucumber-crop-failure-in-the-dry-season-royalty-free-image/1392794517?phrase=cucumbers%20plant%20dead&adppopup=true
https://www.gettyimages.com/detail/photo/fresh-ripe-cucumbers-growing-in-greenhouse-royalty-free-image/627728100?phrase=cucumbers%20plant&adppopup=true
https://www.gettyimages.com/detail/photo/close-up-of-melon-fruit-with-leaves-in-the-farm-royalty-free-image/1194501295?phrase=muskmelon%20plant&adppopup=true
https://www.gettyimages.com/detail/photo/melon-plant-royalty-free-image/916486812?phrase=muskmelon%20plant&adppopup=true
https://www.gettyimages.com/detail/photo/row-of-onions-royalty-free-image/892022394?phrase=onions%20plant&adppopup=true
https://www.gettyimages.com/photos/snap-beans?assettype=image&license=rf&alloweduse=availableforalluses&family=creative&phrase=snap%20beans&sort=best&agreements=pa%3A125487
https://www.gettyimages.com/detail/photo/close-up-filled-frame-photo-of-parsnips-royalty-free-image/1300959090?phrase=parsnip&adppopup=true
https://www.gettyimages.com/photos/parsnip?assettype=image&license=rf&alloweduse=availableforalluses&agreements=pa%3A125487&family=creative&phrase=parsnip&sort=best

These Plants Poison The Competition

